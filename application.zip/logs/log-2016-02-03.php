<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-03 06:06:58 --> Config Class Initialized
INFO - 2016-02-03 06:06:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 06:06:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 06:06:58 --> Utf8 Class Initialized
INFO - 2016-02-03 06:06:58 --> URI Class Initialized
INFO - 2016-02-03 06:06:58 --> Router Class Initialized
INFO - 2016-02-03 06:06:58 --> Output Class Initialized
INFO - 2016-02-03 06:06:58 --> Security Class Initialized
DEBUG - 2016-02-03 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 06:06:58 --> Input Class Initialized
INFO - 2016-02-03 06:06:58 --> Language Class Initialized
INFO - 2016-02-03 06:06:58 --> Loader Class Initialized
INFO - 2016-02-03 06:06:58 --> Helper loaded: url_helper
INFO - 2016-02-03 06:06:58 --> Helper loaded: file_helper
INFO - 2016-02-03 06:06:58 --> Helper loaded: date_helper
INFO - 2016-02-03 06:06:58 --> Database Driver Class Initialized
INFO - 2016-02-03 06:06:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 06:06:59 --> Controller Class Initialized
INFO - 2016-02-03 06:06:59 --> Model Class Initialized
INFO - 2016-02-03 06:06:59 --> Model Class Initialized
INFO - 2016-02-03 06:06:59 --> Helper loaded: form_helper
INFO - 2016-02-03 06:06:59 --> Form Validation Class Initialized
INFO - 2016-02-03 06:06:59 --> Helper loaded: text_helper
INFO - 2016-02-03 06:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 06:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-03 06:06:59 --> Final output sent to browser
DEBUG - 2016-02-03 06:06:59 --> Total execution time: 1.1957
INFO - 2016-02-03 06:07:02 --> Config Class Initialized
INFO - 2016-02-03 06:07:02 --> Hooks Class Initialized
DEBUG - 2016-02-03 06:07:02 --> UTF-8 Support Enabled
INFO - 2016-02-03 06:07:02 --> Utf8 Class Initialized
INFO - 2016-02-03 06:07:02 --> URI Class Initialized
DEBUG - 2016-02-03 06:07:02 --> No URI present. Default controller set.
INFO - 2016-02-03 06:07:02 --> Router Class Initialized
INFO - 2016-02-03 06:07:02 --> Output Class Initialized
INFO - 2016-02-03 06:07:02 --> Security Class Initialized
DEBUG - 2016-02-03 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 06:07:02 --> Input Class Initialized
INFO - 2016-02-03 06:07:02 --> Language Class Initialized
INFO - 2016-02-03 06:07:02 --> Loader Class Initialized
INFO - 2016-02-03 06:07:02 --> Helper loaded: url_helper
INFO - 2016-02-03 06:07:02 --> Helper loaded: file_helper
INFO - 2016-02-03 06:07:02 --> Helper loaded: date_helper
INFO - 2016-02-03 06:07:02 --> Database Driver Class Initialized
INFO - 2016-02-03 06:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 06:07:03 --> Controller Class Initialized
INFO - 2016-02-03 06:07:03 --> Model Class Initialized
INFO - 2016-02-03 06:07:03 --> Model Class Initialized
INFO - 2016-02-03 06:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 06:07:03 --> Pagination Class Initialized
INFO - 2016-02-03 06:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 06:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 06:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 06:07:03 --> Final output sent to browser
DEBUG - 2016-02-03 06:07:03 --> Total execution time: 1.0950
INFO - 2016-02-03 06:07:14 --> Config Class Initialized
INFO - 2016-02-03 06:07:14 --> Hooks Class Initialized
DEBUG - 2016-02-03 06:07:14 --> UTF-8 Support Enabled
INFO - 2016-02-03 06:07:14 --> Utf8 Class Initialized
INFO - 2016-02-03 06:07:14 --> URI Class Initialized
INFO - 2016-02-03 06:07:14 --> Router Class Initialized
INFO - 2016-02-03 06:07:14 --> Output Class Initialized
INFO - 2016-02-03 06:07:14 --> Security Class Initialized
DEBUG - 2016-02-03 06:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 06:07:14 --> Input Class Initialized
INFO - 2016-02-03 06:07:14 --> Language Class Initialized
INFO - 2016-02-03 06:07:14 --> Loader Class Initialized
INFO - 2016-02-03 06:07:14 --> Helper loaded: url_helper
INFO - 2016-02-03 06:07:14 --> Helper loaded: file_helper
INFO - 2016-02-03 06:07:14 --> Helper loaded: date_helper
INFO - 2016-02-03 06:07:14 --> Database Driver Class Initialized
INFO - 2016-02-03 06:07:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 06:07:15 --> Controller Class Initialized
INFO - 2016-02-03 06:07:15 --> Model Class Initialized
INFO - 2016-02-03 06:07:15 --> Model Class Initialized
INFO - 2016-02-03 06:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 06:07:15 --> Pagination Class Initialized
INFO - 2016-02-03 06:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 06:07:15 --> Helper loaded: text_helper
ERROR - 2016-02-03 06:07:15 --> Severity: Notice --> Undefined index: result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 78
INFO - 2016-02-03 06:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 06:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 06:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 06:07:15 --> Final output sent to browser
DEBUG - 2016-02-03 06:07:15 --> Total execution time: 1.1671
INFO - 2016-02-03 06:07:17 --> Config Class Initialized
INFO - 2016-02-03 06:07:17 --> Hooks Class Initialized
DEBUG - 2016-02-03 06:07:17 --> UTF-8 Support Enabled
INFO - 2016-02-03 06:07:17 --> Utf8 Class Initialized
INFO - 2016-02-03 06:07:17 --> URI Class Initialized
DEBUG - 2016-02-03 06:07:17 --> No URI present. Default controller set.
INFO - 2016-02-03 06:07:17 --> Router Class Initialized
INFO - 2016-02-03 06:07:17 --> Output Class Initialized
INFO - 2016-02-03 06:07:17 --> Security Class Initialized
DEBUG - 2016-02-03 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 06:07:17 --> Input Class Initialized
INFO - 2016-02-03 06:07:17 --> Language Class Initialized
INFO - 2016-02-03 06:07:17 --> Loader Class Initialized
INFO - 2016-02-03 06:07:17 --> Helper loaded: url_helper
INFO - 2016-02-03 06:07:17 --> Helper loaded: file_helper
INFO - 2016-02-03 06:07:17 --> Helper loaded: date_helper
INFO - 2016-02-03 06:07:17 --> Database Driver Class Initialized
INFO - 2016-02-03 06:07:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 06:07:18 --> Controller Class Initialized
INFO - 2016-02-03 06:07:18 --> Model Class Initialized
INFO - 2016-02-03 06:07:18 --> Model Class Initialized
INFO - 2016-02-03 06:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 06:07:18 --> Pagination Class Initialized
INFO - 2016-02-03 06:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 06:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 06:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 06:07:18 --> Final output sent to browser
DEBUG - 2016-02-03 06:07:18 --> Total execution time: 1.1225
INFO - 2016-02-03 07:35:33 --> Config Class Initialized
INFO - 2016-02-03 07:35:33 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:35:33 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:35:33 --> Utf8 Class Initialized
INFO - 2016-02-03 07:35:33 --> URI Class Initialized
INFO - 2016-02-03 07:35:33 --> Router Class Initialized
INFO - 2016-02-03 07:35:33 --> Output Class Initialized
INFO - 2016-02-03 07:35:33 --> Security Class Initialized
DEBUG - 2016-02-03 07:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:35:33 --> Input Class Initialized
INFO - 2016-02-03 07:35:33 --> Language Class Initialized
INFO - 2016-02-03 07:35:33 --> Loader Class Initialized
INFO - 2016-02-03 07:35:33 --> Helper loaded: url_helper
INFO - 2016-02-03 07:35:33 --> Helper loaded: file_helper
INFO - 2016-02-03 07:35:33 --> Helper loaded: date_helper
INFO - 2016-02-03 07:35:33 --> Database Driver Class Initialized
INFO - 2016-02-03 07:35:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:35:34 --> Controller Class Initialized
INFO - 2016-02-03 07:35:34 --> Model Class Initialized
INFO - 2016-02-03 07:35:34 --> Model Class Initialized
INFO - 2016-02-03 07:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:35:34 --> Pagination Class Initialized
INFO - 2016-02-03 07:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:35:34 --> Helper loaded: text_helper
INFO - 2016-02-03 07:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:35:34 --> Final output sent to browser
DEBUG - 2016-02-03 07:35:34 --> Total execution time: 1.1599
INFO - 2016-02-03 07:35:37 --> Config Class Initialized
INFO - 2016-02-03 07:35:37 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:35:37 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:35:37 --> Utf8 Class Initialized
INFO - 2016-02-03 07:35:37 --> URI Class Initialized
INFO - 2016-02-03 07:35:37 --> Router Class Initialized
INFO - 2016-02-03 07:35:37 --> Output Class Initialized
INFO - 2016-02-03 07:35:37 --> Security Class Initialized
DEBUG - 2016-02-03 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:35:37 --> Input Class Initialized
INFO - 2016-02-03 07:35:37 --> Language Class Initialized
INFO - 2016-02-03 07:35:37 --> Loader Class Initialized
INFO - 2016-02-03 07:35:37 --> Helper loaded: url_helper
INFO - 2016-02-03 07:35:37 --> Helper loaded: file_helper
INFO - 2016-02-03 07:35:37 --> Helper loaded: date_helper
INFO - 2016-02-03 07:35:37 --> Database Driver Class Initialized
INFO - 2016-02-03 07:35:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:35:38 --> Controller Class Initialized
INFO - 2016-02-03 07:35:38 --> Model Class Initialized
INFO - 2016-02-03 07:35:38 --> Model Class Initialized
INFO - 2016-02-03 07:35:38 --> Helper loaded: form_helper
INFO - 2016-02-03 07:35:38 --> Form Validation Class Initialized
INFO - 2016-02-03 07:35:38 --> Helper loaded: text_helper
INFO - 2016-02-03 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 07:35:38 --> Model Class Initialized
ERROR - 2016-02-03 07:35:38 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-03 07:35:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-03 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:35:38 --> Final output sent to browser
DEBUG - 2016-02-03 07:35:38 --> Total execution time: 1.1193
INFO - 2016-02-03 07:35:40 --> Config Class Initialized
INFO - 2016-02-03 07:35:40 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:35:40 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:35:40 --> Utf8 Class Initialized
INFO - 2016-02-03 07:35:40 --> URI Class Initialized
DEBUG - 2016-02-03 07:35:40 --> No URI present. Default controller set.
INFO - 2016-02-03 07:35:40 --> Router Class Initialized
INFO - 2016-02-03 07:35:40 --> Output Class Initialized
INFO - 2016-02-03 07:35:40 --> Security Class Initialized
DEBUG - 2016-02-03 07:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:35:40 --> Input Class Initialized
INFO - 2016-02-03 07:35:40 --> Language Class Initialized
INFO - 2016-02-03 07:35:40 --> Loader Class Initialized
INFO - 2016-02-03 07:35:40 --> Helper loaded: url_helper
INFO - 2016-02-03 07:35:40 --> Helper loaded: file_helper
INFO - 2016-02-03 07:35:40 --> Helper loaded: date_helper
INFO - 2016-02-03 07:35:40 --> Database Driver Class Initialized
INFO - 2016-02-03 07:35:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:35:41 --> Controller Class Initialized
INFO - 2016-02-03 07:35:41 --> Model Class Initialized
INFO - 2016-02-03 07:35:41 --> Model Class Initialized
INFO - 2016-02-03 07:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:35:41 --> Pagination Class Initialized
INFO - 2016-02-03 07:35:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:35:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:35:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:35:41 --> Final output sent to browser
DEBUG - 2016-02-03 07:35:41 --> Total execution time: 1.1063
INFO - 2016-02-03 07:35:45 --> Config Class Initialized
INFO - 2016-02-03 07:35:45 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:35:45 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:35:45 --> Utf8 Class Initialized
INFO - 2016-02-03 07:35:45 --> URI Class Initialized
INFO - 2016-02-03 07:35:45 --> Router Class Initialized
INFO - 2016-02-03 07:35:45 --> Output Class Initialized
INFO - 2016-02-03 07:35:45 --> Security Class Initialized
DEBUG - 2016-02-03 07:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:35:45 --> Input Class Initialized
INFO - 2016-02-03 07:35:45 --> Language Class Initialized
INFO - 2016-02-03 07:35:45 --> Loader Class Initialized
INFO - 2016-02-03 07:35:45 --> Helper loaded: url_helper
INFO - 2016-02-03 07:35:45 --> Helper loaded: file_helper
INFO - 2016-02-03 07:35:45 --> Helper loaded: date_helper
INFO - 2016-02-03 07:35:45 --> Database Driver Class Initialized
INFO - 2016-02-03 07:35:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:35:46 --> Controller Class Initialized
INFO - 2016-02-03 07:35:46 --> Model Class Initialized
INFO - 2016-02-03 07:35:46 --> Model Class Initialized
INFO - 2016-02-03 07:35:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:35:46 --> Pagination Class Initialized
INFO - 2016-02-03 07:35:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:35:46 --> Helper loaded: text_helper
INFO - 2016-02-03 07:35:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:35:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:35:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:35:46 --> Final output sent to browser
DEBUG - 2016-02-03 07:35:46 --> Total execution time: 1.1559
INFO - 2016-02-03 07:37:25 --> Config Class Initialized
INFO - 2016-02-03 07:37:25 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:37:25 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:37:25 --> Utf8 Class Initialized
INFO - 2016-02-03 07:37:25 --> URI Class Initialized
DEBUG - 2016-02-03 07:37:25 --> No URI present. Default controller set.
INFO - 2016-02-03 07:37:25 --> Router Class Initialized
INFO - 2016-02-03 07:37:25 --> Output Class Initialized
INFO - 2016-02-03 07:37:25 --> Security Class Initialized
DEBUG - 2016-02-03 07:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:37:25 --> Input Class Initialized
INFO - 2016-02-03 07:37:25 --> Language Class Initialized
INFO - 2016-02-03 07:37:25 --> Loader Class Initialized
INFO - 2016-02-03 07:37:25 --> Helper loaded: url_helper
INFO - 2016-02-03 07:37:25 --> Helper loaded: file_helper
INFO - 2016-02-03 07:37:25 --> Helper loaded: date_helper
INFO - 2016-02-03 07:37:25 --> Database Driver Class Initialized
INFO - 2016-02-03 07:37:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:37:26 --> Controller Class Initialized
INFO - 2016-02-03 07:37:26 --> Model Class Initialized
INFO - 2016-02-03 07:37:26 --> Model Class Initialized
INFO - 2016-02-03 07:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:37:26 --> Pagination Class Initialized
INFO - 2016-02-03 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:37:26 --> Final output sent to browser
DEBUG - 2016-02-03 07:37:26 --> Total execution time: 1.0939
INFO - 2016-02-03 07:37:28 --> Config Class Initialized
INFO - 2016-02-03 07:37:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:37:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:37:28 --> Utf8 Class Initialized
INFO - 2016-02-03 07:37:28 --> URI Class Initialized
INFO - 2016-02-03 07:37:28 --> Router Class Initialized
INFO - 2016-02-03 07:37:28 --> Output Class Initialized
INFO - 2016-02-03 07:37:28 --> Security Class Initialized
DEBUG - 2016-02-03 07:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:37:28 --> Input Class Initialized
INFO - 2016-02-03 07:37:28 --> Language Class Initialized
INFO - 2016-02-03 07:37:28 --> Loader Class Initialized
INFO - 2016-02-03 07:37:28 --> Helper loaded: url_helper
INFO - 2016-02-03 07:37:28 --> Helper loaded: file_helper
INFO - 2016-02-03 07:37:28 --> Helper loaded: date_helper
INFO - 2016-02-03 07:37:28 --> Database Driver Class Initialized
INFO - 2016-02-03 07:37:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:37:29 --> Controller Class Initialized
INFO - 2016-02-03 07:37:29 --> Model Class Initialized
INFO - 2016-02-03 07:37:29 --> Model Class Initialized
INFO - 2016-02-03 07:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:37:29 --> Pagination Class Initialized
INFO - 2016-02-03 07:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:37:29 --> Helper loaded: text_helper
INFO - 2016-02-03 07:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:37:29 --> Final output sent to browser
DEBUG - 2016-02-03 07:37:29 --> Total execution time: 1.1402
INFO - 2016-02-03 07:38:01 --> Config Class Initialized
INFO - 2016-02-03 07:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:38:01 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:38:01 --> Utf8 Class Initialized
INFO - 2016-02-03 07:38:01 --> URI Class Initialized
INFO - 2016-02-03 07:38:01 --> Router Class Initialized
INFO - 2016-02-03 07:38:01 --> Output Class Initialized
INFO - 2016-02-03 07:38:01 --> Security Class Initialized
DEBUG - 2016-02-03 07:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:38:01 --> Input Class Initialized
INFO - 2016-02-03 07:38:01 --> Language Class Initialized
INFO - 2016-02-03 07:38:01 --> Loader Class Initialized
INFO - 2016-02-03 07:38:01 --> Helper loaded: url_helper
INFO - 2016-02-03 07:38:01 --> Helper loaded: file_helper
INFO - 2016-02-03 07:38:01 --> Helper loaded: date_helper
INFO - 2016-02-03 07:38:01 --> Database Driver Class Initialized
INFO - 2016-02-03 07:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:38:02 --> Controller Class Initialized
INFO - 2016-02-03 07:38:02 --> Model Class Initialized
INFO - 2016-02-03 07:38:02 --> Model Class Initialized
INFO - 2016-02-03 07:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:38:02 --> Pagination Class Initialized
INFO - 2016-02-03 07:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:38:02 --> Helper loaded: text_helper
INFO - 2016-02-03 07:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:38:02 --> Final output sent to browser
DEBUG - 2016-02-03 07:38:02 --> Total execution time: 1.1558
INFO - 2016-02-03 07:38:18 --> Config Class Initialized
INFO - 2016-02-03 07:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:38:18 --> Utf8 Class Initialized
INFO - 2016-02-03 07:38:18 --> URI Class Initialized
DEBUG - 2016-02-03 07:38:18 --> No URI present. Default controller set.
INFO - 2016-02-03 07:38:18 --> Router Class Initialized
INFO - 2016-02-03 07:38:18 --> Output Class Initialized
INFO - 2016-02-03 07:38:18 --> Security Class Initialized
DEBUG - 2016-02-03 07:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:38:18 --> Input Class Initialized
INFO - 2016-02-03 07:38:18 --> Language Class Initialized
INFO - 2016-02-03 07:38:18 --> Loader Class Initialized
INFO - 2016-02-03 07:38:18 --> Helper loaded: url_helper
INFO - 2016-02-03 07:38:18 --> Helper loaded: file_helper
INFO - 2016-02-03 07:38:18 --> Helper loaded: date_helper
INFO - 2016-02-03 07:38:18 --> Database Driver Class Initialized
INFO - 2016-02-03 07:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:38:19 --> Controller Class Initialized
INFO - 2016-02-03 07:38:19 --> Model Class Initialized
INFO - 2016-02-03 07:38:19 --> Model Class Initialized
INFO - 2016-02-03 07:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:38:19 --> Pagination Class Initialized
INFO - 2016-02-03 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:38:19 --> Final output sent to browser
DEBUG - 2016-02-03 07:38:19 --> Total execution time: 1.1203
INFO - 2016-02-03 07:38:21 --> Config Class Initialized
INFO - 2016-02-03 07:38:21 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:38:21 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:38:21 --> Utf8 Class Initialized
INFO - 2016-02-03 07:38:21 --> URI Class Initialized
INFO - 2016-02-03 07:38:21 --> Router Class Initialized
INFO - 2016-02-03 07:38:21 --> Output Class Initialized
INFO - 2016-02-03 07:38:21 --> Security Class Initialized
DEBUG - 2016-02-03 07:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:38:21 --> Input Class Initialized
INFO - 2016-02-03 07:38:21 --> Language Class Initialized
INFO - 2016-02-03 07:38:21 --> Loader Class Initialized
INFO - 2016-02-03 07:38:21 --> Helper loaded: url_helper
INFO - 2016-02-03 07:38:21 --> Helper loaded: file_helper
INFO - 2016-02-03 07:38:21 --> Helper loaded: date_helper
INFO - 2016-02-03 07:38:21 --> Database Driver Class Initialized
INFO - 2016-02-03 07:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:38:22 --> Controller Class Initialized
INFO - 2016-02-03 07:38:22 --> Model Class Initialized
INFO - 2016-02-03 07:38:22 --> Model Class Initialized
INFO - 2016-02-03 07:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:38:22 --> Pagination Class Initialized
INFO - 2016-02-03 07:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:38:22 --> Helper loaded: text_helper
INFO - 2016-02-03 07:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:38:22 --> Final output sent to browser
DEBUG - 2016-02-03 07:38:22 --> Total execution time: 1.1735
INFO - 2016-02-03 07:38:51 --> Config Class Initialized
INFO - 2016-02-03 07:38:51 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:38:51 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:38:51 --> Utf8 Class Initialized
INFO - 2016-02-03 07:38:51 --> URI Class Initialized
INFO - 2016-02-03 07:38:51 --> Router Class Initialized
INFO - 2016-02-03 07:38:51 --> Output Class Initialized
INFO - 2016-02-03 07:38:51 --> Security Class Initialized
DEBUG - 2016-02-03 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:38:51 --> Input Class Initialized
INFO - 2016-02-03 07:38:51 --> Language Class Initialized
INFO - 2016-02-03 07:38:51 --> Loader Class Initialized
INFO - 2016-02-03 07:38:51 --> Helper loaded: url_helper
INFO - 2016-02-03 07:38:51 --> Helper loaded: file_helper
INFO - 2016-02-03 07:38:51 --> Helper loaded: date_helper
INFO - 2016-02-03 07:38:51 --> Database Driver Class Initialized
INFO - 2016-02-03 07:38:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:38:52 --> Controller Class Initialized
INFO - 2016-02-03 07:38:52 --> Model Class Initialized
INFO - 2016-02-03 07:38:52 --> Model Class Initialized
INFO - 2016-02-03 07:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:38:52 --> Pagination Class Initialized
INFO - 2016-02-03 07:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:38:52 --> Helper loaded: text_helper
INFO - 2016-02-03 07:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:38:52 --> Final output sent to browser
DEBUG - 2016-02-03 07:38:52 --> Total execution time: 1.1911
INFO - 2016-02-03 07:38:57 --> Config Class Initialized
INFO - 2016-02-03 07:38:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:38:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:38:57 --> Utf8 Class Initialized
INFO - 2016-02-03 07:38:57 --> URI Class Initialized
DEBUG - 2016-02-03 07:38:57 --> No URI present. Default controller set.
INFO - 2016-02-03 07:38:57 --> Router Class Initialized
INFO - 2016-02-03 07:38:57 --> Output Class Initialized
INFO - 2016-02-03 07:38:57 --> Security Class Initialized
DEBUG - 2016-02-03 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:38:57 --> Input Class Initialized
INFO - 2016-02-03 07:38:57 --> Language Class Initialized
INFO - 2016-02-03 07:38:57 --> Loader Class Initialized
INFO - 2016-02-03 07:38:57 --> Helper loaded: url_helper
INFO - 2016-02-03 07:38:57 --> Helper loaded: file_helper
INFO - 2016-02-03 07:38:57 --> Helper loaded: date_helper
INFO - 2016-02-03 07:38:57 --> Database Driver Class Initialized
INFO - 2016-02-03 07:38:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:38:58 --> Controller Class Initialized
INFO - 2016-02-03 07:38:58 --> Model Class Initialized
INFO - 2016-02-03 07:38:58 --> Model Class Initialized
INFO - 2016-02-03 07:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:38:58 --> Pagination Class Initialized
INFO - 2016-02-03 07:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:38:58 --> Final output sent to browser
DEBUG - 2016-02-03 07:38:58 --> Total execution time: 1.0942
INFO - 2016-02-03 07:39:00 --> Config Class Initialized
INFO - 2016-02-03 07:39:00 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:39:00 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:39:00 --> Utf8 Class Initialized
INFO - 2016-02-03 07:39:00 --> URI Class Initialized
INFO - 2016-02-03 07:39:00 --> Router Class Initialized
INFO - 2016-02-03 07:39:00 --> Output Class Initialized
INFO - 2016-02-03 07:39:00 --> Security Class Initialized
DEBUG - 2016-02-03 07:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:39:00 --> Input Class Initialized
INFO - 2016-02-03 07:39:00 --> Language Class Initialized
INFO - 2016-02-03 07:39:00 --> Loader Class Initialized
INFO - 2016-02-03 07:39:00 --> Helper loaded: url_helper
INFO - 2016-02-03 07:39:00 --> Helper loaded: file_helper
INFO - 2016-02-03 07:39:00 --> Helper loaded: date_helper
INFO - 2016-02-03 07:39:00 --> Database Driver Class Initialized
INFO - 2016-02-03 07:39:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:39:01 --> Controller Class Initialized
INFO - 2016-02-03 07:39:01 --> Model Class Initialized
INFO - 2016-02-03 07:39:01 --> Model Class Initialized
INFO - 2016-02-03 07:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:39:01 --> Pagination Class Initialized
INFO - 2016-02-03 07:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:39:01 --> Final output sent to browser
DEBUG - 2016-02-03 07:39:01 --> Total execution time: 1.1032
INFO - 2016-02-03 07:39:08 --> Config Class Initialized
INFO - 2016-02-03 07:39:08 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:39:08 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:39:08 --> Utf8 Class Initialized
INFO - 2016-02-03 07:39:08 --> URI Class Initialized
INFO - 2016-02-03 07:39:08 --> Router Class Initialized
INFO - 2016-02-03 07:39:08 --> Output Class Initialized
INFO - 2016-02-03 07:39:08 --> Security Class Initialized
DEBUG - 2016-02-03 07:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:39:08 --> Input Class Initialized
INFO - 2016-02-03 07:39:08 --> Language Class Initialized
INFO - 2016-02-03 07:39:08 --> Loader Class Initialized
INFO - 2016-02-03 07:39:08 --> Helper loaded: url_helper
INFO - 2016-02-03 07:39:08 --> Helper loaded: file_helper
INFO - 2016-02-03 07:39:08 --> Helper loaded: date_helper
INFO - 2016-02-03 07:39:08 --> Database Driver Class Initialized
INFO - 2016-02-03 07:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:39:09 --> Controller Class Initialized
INFO - 2016-02-03 07:39:09 --> Model Class Initialized
INFO - 2016-02-03 07:39:09 --> Model Class Initialized
INFO - 2016-02-03 07:39:09 --> Helper loaded: form_helper
INFO - 2016-02-03 07:39:09 --> Form Validation Class Initialized
INFO - 2016-02-03 07:39:09 --> Helper loaded: text_helper
INFO - 2016-02-03 07:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-03 07:39:09 --> Final output sent to browser
DEBUG - 2016-02-03 07:39:09 --> Total execution time: 1.1416
INFO - 2016-02-03 07:39:13 --> Config Class Initialized
INFO - 2016-02-03 07:39:13 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:39:13 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:39:13 --> Utf8 Class Initialized
INFO - 2016-02-03 07:39:13 --> URI Class Initialized
INFO - 2016-02-03 07:39:13 --> Router Class Initialized
INFO - 2016-02-03 07:39:13 --> Output Class Initialized
INFO - 2016-02-03 07:39:13 --> Security Class Initialized
DEBUG - 2016-02-03 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:39:13 --> Input Class Initialized
INFO - 2016-02-03 07:39:13 --> Language Class Initialized
INFO - 2016-02-03 07:39:13 --> Loader Class Initialized
INFO - 2016-02-03 07:39:13 --> Helper loaded: url_helper
INFO - 2016-02-03 07:39:13 --> Helper loaded: file_helper
INFO - 2016-02-03 07:39:13 --> Helper loaded: date_helper
INFO - 2016-02-03 07:39:13 --> Database Driver Class Initialized
INFO - 2016-02-03 07:39:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:39:14 --> Controller Class Initialized
INFO - 2016-02-03 07:39:14 --> Model Class Initialized
INFO - 2016-02-03 07:39:14 --> Model Class Initialized
INFO - 2016-02-03 07:39:14 --> Helper loaded: form_helper
INFO - 2016-02-03 07:39:14 --> Form Validation Class Initialized
INFO - 2016-02-03 07:39:14 --> Helper loaded: text_helper
INFO - 2016-02-03 07:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 07:39:14 --> Model Class Initialized
ERROR - 2016-02-03 07:39:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-03 07:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-03 07:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:39:14 --> Final output sent to browser
DEBUG - 2016-02-03 07:39:14 --> Total execution time: 1.1438
INFO - 2016-02-03 07:40:16 --> Config Class Initialized
INFO - 2016-02-03 07:40:16 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:40:16 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:40:16 --> Utf8 Class Initialized
INFO - 2016-02-03 07:40:16 --> URI Class Initialized
INFO - 2016-02-03 07:40:16 --> Router Class Initialized
INFO - 2016-02-03 07:40:16 --> Output Class Initialized
INFO - 2016-02-03 07:40:16 --> Security Class Initialized
DEBUG - 2016-02-03 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:40:16 --> Input Class Initialized
INFO - 2016-02-03 07:40:16 --> Language Class Initialized
INFO - 2016-02-03 07:40:16 --> Loader Class Initialized
INFO - 2016-02-03 07:40:16 --> Helper loaded: url_helper
INFO - 2016-02-03 07:40:16 --> Helper loaded: file_helper
INFO - 2016-02-03 07:40:16 --> Helper loaded: date_helper
INFO - 2016-02-03 07:40:16 --> Database Driver Class Initialized
INFO - 2016-02-03 07:40:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:40:17 --> Controller Class Initialized
INFO - 2016-02-03 07:40:17 --> Model Class Initialized
INFO - 2016-02-03 07:40:17 --> Model Class Initialized
INFO - 2016-02-03 07:40:17 --> Helper loaded: form_helper
INFO - 2016-02-03 07:40:17 --> Form Validation Class Initialized
INFO - 2016-02-03 07:40:17 --> Helper loaded: text_helper
INFO - 2016-02-03 07:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 07:40:17 --> Model Class Initialized
INFO - 2016-02-03 07:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:40:17 --> Final output sent to browser
DEBUG - 2016-02-03 07:40:17 --> Total execution time: 1.1359
INFO - 2016-02-03 07:41:05 --> Config Class Initialized
INFO - 2016-02-03 07:41:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:41:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:41:05 --> Utf8 Class Initialized
INFO - 2016-02-03 07:41:05 --> URI Class Initialized
DEBUG - 2016-02-03 07:41:05 --> No URI present. Default controller set.
INFO - 2016-02-03 07:41:05 --> Router Class Initialized
INFO - 2016-02-03 07:41:05 --> Output Class Initialized
INFO - 2016-02-03 07:41:05 --> Security Class Initialized
DEBUG - 2016-02-03 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:41:05 --> Input Class Initialized
INFO - 2016-02-03 07:41:05 --> Language Class Initialized
INFO - 2016-02-03 07:41:05 --> Loader Class Initialized
INFO - 2016-02-03 07:41:05 --> Helper loaded: url_helper
INFO - 2016-02-03 07:41:05 --> Helper loaded: file_helper
INFO - 2016-02-03 07:41:05 --> Helper loaded: date_helper
INFO - 2016-02-03 07:41:05 --> Database Driver Class Initialized
INFO - 2016-02-03 07:41:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:41:06 --> Controller Class Initialized
INFO - 2016-02-03 07:41:06 --> Model Class Initialized
INFO - 2016-02-03 07:41:06 --> Model Class Initialized
INFO - 2016-02-03 07:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:41:06 --> Pagination Class Initialized
INFO - 2016-02-03 07:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:41:06 --> Final output sent to browser
DEBUG - 2016-02-03 07:41:06 --> Total execution time: 1.1227
INFO - 2016-02-03 07:41:09 --> Config Class Initialized
INFO - 2016-02-03 07:41:09 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:41:09 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:41:09 --> Utf8 Class Initialized
INFO - 2016-02-03 07:41:09 --> URI Class Initialized
INFO - 2016-02-03 07:41:09 --> Router Class Initialized
INFO - 2016-02-03 07:41:09 --> Output Class Initialized
INFO - 2016-02-03 07:41:09 --> Security Class Initialized
DEBUG - 2016-02-03 07:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:41:09 --> Input Class Initialized
INFO - 2016-02-03 07:41:09 --> Language Class Initialized
INFO - 2016-02-03 07:41:09 --> Loader Class Initialized
INFO - 2016-02-03 07:41:09 --> Helper loaded: url_helper
INFO - 2016-02-03 07:41:09 --> Helper loaded: file_helper
INFO - 2016-02-03 07:41:09 --> Helper loaded: date_helper
INFO - 2016-02-03 07:41:09 --> Database Driver Class Initialized
INFO - 2016-02-03 07:41:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:41:10 --> Controller Class Initialized
INFO - 2016-02-03 07:41:10 --> Model Class Initialized
INFO - 2016-02-03 07:41:10 --> Model Class Initialized
INFO - 2016-02-03 07:41:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:41:10 --> Pagination Class Initialized
INFO - 2016-02-03 07:41:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:41:10 --> Helper loaded: text_helper
INFO - 2016-02-03 07:41:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:41:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:41:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:41:10 --> Final output sent to browser
DEBUG - 2016-02-03 07:41:10 --> Total execution time: 1.1521
INFO - 2016-02-03 07:41:50 --> Config Class Initialized
INFO - 2016-02-03 07:41:50 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:41:50 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:41:50 --> Utf8 Class Initialized
INFO - 2016-02-03 07:41:50 --> URI Class Initialized
INFO - 2016-02-03 07:41:50 --> Router Class Initialized
INFO - 2016-02-03 07:41:50 --> Output Class Initialized
INFO - 2016-02-03 07:41:50 --> Security Class Initialized
DEBUG - 2016-02-03 07:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:41:50 --> Input Class Initialized
INFO - 2016-02-03 07:41:50 --> Language Class Initialized
INFO - 2016-02-03 07:41:50 --> Loader Class Initialized
INFO - 2016-02-03 07:41:50 --> Helper loaded: url_helper
INFO - 2016-02-03 07:41:50 --> Helper loaded: file_helper
INFO - 2016-02-03 07:41:50 --> Helper loaded: date_helper
INFO - 2016-02-03 07:41:50 --> Database Driver Class Initialized
INFO - 2016-02-03 07:41:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:41:51 --> Controller Class Initialized
INFO - 2016-02-03 07:41:51 --> Model Class Initialized
INFO - 2016-02-03 07:41:51 --> Model Class Initialized
INFO - 2016-02-03 07:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:41:51 --> Pagination Class Initialized
INFO - 2016-02-03 07:41:51 --> Config Class Initialized
INFO - 2016-02-03 07:41:51 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:41:51 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:41:51 --> Utf8 Class Initialized
INFO - 2016-02-03 07:41:51 --> URI Class Initialized
INFO - 2016-02-03 07:41:51 --> Router Class Initialized
INFO - 2016-02-03 07:41:51 --> Output Class Initialized
INFO - 2016-02-03 07:41:51 --> Security Class Initialized
DEBUG - 2016-02-03 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:41:51 --> Input Class Initialized
INFO - 2016-02-03 07:41:51 --> Language Class Initialized
INFO - 2016-02-03 07:41:51 --> Loader Class Initialized
INFO - 2016-02-03 07:41:51 --> Helper loaded: url_helper
INFO - 2016-02-03 07:41:51 --> Helper loaded: file_helper
INFO - 2016-02-03 07:41:51 --> Helper loaded: date_helper
INFO - 2016-02-03 07:41:51 --> Database Driver Class Initialized
INFO - 2016-02-03 07:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:41:52 --> Controller Class Initialized
INFO - 2016-02-03 07:41:52 --> Model Class Initialized
INFO - 2016-02-03 07:41:52 --> Model Class Initialized
INFO - 2016-02-03 07:41:52 --> Helper loaded: form_helper
INFO - 2016-02-03 07:41:52 --> Form Validation Class Initialized
INFO - 2016-02-03 07:41:52 --> Helper loaded: text_helper
INFO - 2016-02-03 07:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-03 07:41:52 --> Final output sent to browser
DEBUG - 2016-02-03 07:41:52 --> Total execution time: 1.1824
INFO - 2016-02-03 07:41:56 --> Config Class Initialized
INFO - 2016-02-03 07:41:56 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:41:56 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:41:56 --> Utf8 Class Initialized
INFO - 2016-02-03 07:41:56 --> URI Class Initialized
DEBUG - 2016-02-03 07:41:56 --> No URI present. Default controller set.
INFO - 2016-02-03 07:41:56 --> Router Class Initialized
INFO - 2016-02-03 07:41:56 --> Output Class Initialized
INFO - 2016-02-03 07:41:56 --> Security Class Initialized
DEBUG - 2016-02-03 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:41:56 --> Input Class Initialized
INFO - 2016-02-03 07:41:56 --> Language Class Initialized
INFO - 2016-02-03 07:41:56 --> Loader Class Initialized
INFO - 2016-02-03 07:41:56 --> Helper loaded: url_helper
INFO - 2016-02-03 07:41:56 --> Helper loaded: file_helper
INFO - 2016-02-03 07:41:56 --> Helper loaded: date_helper
INFO - 2016-02-03 07:41:56 --> Database Driver Class Initialized
INFO - 2016-02-03 07:41:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:41:57 --> Controller Class Initialized
INFO - 2016-02-03 07:41:57 --> Model Class Initialized
INFO - 2016-02-03 07:41:57 --> Model Class Initialized
INFO - 2016-02-03 07:41:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:41:57 --> Pagination Class Initialized
INFO - 2016-02-03 07:41:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:41:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 07:41:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:41:57 --> Final output sent to browser
DEBUG - 2016-02-03 07:41:57 --> Total execution time: 1.1193
INFO - 2016-02-03 07:56:44 --> Config Class Initialized
INFO - 2016-02-03 07:56:44 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:56:44 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:56:44 --> Utf8 Class Initialized
INFO - 2016-02-03 07:56:44 --> URI Class Initialized
INFO - 2016-02-03 07:56:44 --> Router Class Initialized
INFO - 2016-02-03 07:56:44 --> Output Class Initialized
INFO - 2016-02-03 07:56:44 --> Security Class Initialized
DEBUG - 2016-02-03 07:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:56:44 --> Input Class Initialized
INFO - 2016-02-03 07:56:44 --> Language Class Initialized
INFO - 2016-02-03 07:56:44 --> Loader Class Initialized
INFO - 2016-02-03 07:56:44 --> Helper loaded: url_helper
INFO - 2016-02-03 07:56:44 --> Helper loaded: file_helper
INFO - 2016-02-03 07:56:44 --> Helper loaded: date_helper
INFO - 2016-02-03 07:56:44 --> Database Driver Class Initialized
INFO - 2016-02-03 07:56:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:56:45 --> Controller Class Initialized
INFO - 2016-02-03 07:56:45 --> Model Class Initialized
INFO - 2016-02-03 07:56:45 --> Model Class Initialized
INFO - 2016-02-03 07:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:56:45 --> Pagination Class Initialized
INFO - 2016-02-03 07:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:56:45 --> Helper loaded: text_helper
INFO - 2016-02-03 07:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:56:45 --> Final output sent to browser
DEBUG - 2016-02-03 07:56:45 --> Total execution time: 1.1699
INFO - 2016-02-03 07:56:47 --> Config Class Initialized
INFO - 2016-02-03 07:56:47 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:56:47 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:56:47 --> Utf8 Class Initialized
INFO - 2016-02-03 07:56:47 --> URI Class Initialized
INFO - 2016-02-03 07:56:47 --> Router Class Initialized
INFO - 2016-02-03 07:56:47 --> Output Class Initialized
INFO - 2016-02-03 07:56:47 --> Security Class Initialized
DEBUG - 2016-02-03 07:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:56:47 --> Input Class Initialized
INFO - 2016-02-03 07:56:47 --> Language Class Initialized
INFO - 2016-02-03 07:56:47 --> Loader Class Initialized
INFO - 2016-02-03 07:56:47 --> Helper loaded: url_helper
INFO - 2016-02-03 07:56:47 --> Helper loaded: file_helper
INFO - 2016-02-03 07:56:47 --> Helper loaded: date_helper
INFO - 2016-02-03 07:56:47 --> Database Driver Class Initialized
INFO - 2016-02-03 07:56:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:56:48 --> Controller Class Initialized
INFO - 2016-02-03 07:56:48 --> Model Class Initialized
INFO - 2016-02-03 07:56:48 --> Model Class Initialized
INFO - 2016-02-03 07:56:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:56:48 --> Pagination Class Initialized
INFO - 2016-02-03 07:56:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:56:48 --> Helper loaded: text_helper
INFO - 2016-02-03 07:56:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:56:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:56:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:56:48 --> Final output sent to browser
DEBUG - 2016-02-03 07:56:48 --> Total execution time: 1.1627
INFO - 2016-02-03 07:57:42 --> Config Class Initialized
INFO - 2016-02-03 07:57:42 --> Hooks Class Initialized
DEBUG - 2016-02-03 07:57:42 --> UTF-8 Support Enabled
INFO - 2016-02-03 07:57:42 --> Utf8 Class Initialized
INFO - 2016-02-03 07:57:42 --> URI Class Initialized
INFO - 2016-02-03 07:57:42 --> Router Class Initialized
INFO - 2016-02-03 07:57:42 --> Output Class Initialized
INFO - 2016-02-03 07:57:42 --> Security Class Initialized
DEBUG - 2016-02-03 07:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 07:57:42 --> Input Class Initialized
INFO - 2016-02-03 07:57:42 --> Language Class Initialized
INFO - 2016-02-03 07:57:42 --> Loader Class Initialized
INFO - 2016-02-03 07:57:42 --> Helper loaded: url_helper
INFO - 2016-02-03 07:57:42 --> Helper loaded: file_helper
INFO - 2016-02-03 07:57:42 --> Helper loaded: date_helper
INFO - 2016-02-03 07:57:42 --> Database Driver Class Initialized
INFO - 2016-02-03 07:57:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 07:57:43 --> Controller Class Initialized
INFO - 2016-02-03 07:57:43 --> Model Class Initialized
INFO - 2016-02-03 07:57:43 --> Model Class Initialized
INFO - 2016-02-03 07:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 07:57:43 --> Pagination Class Initialized
INFO - 2016-02-03 07:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 07:57:43 --> Helper loaded: text_helper
INFO - 2016-02-03 07:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 07:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 07:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 07:57:43 --> Final output sent to browser
DEBUG - 2016-02-03 07:57:43 --> Total execution time: 1.2390
INFO - 2016-02-03 08:03:11 --> Config Class Initialized
INFO - 2016-02-03 08:03:11 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:03:11 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:03:11 --> Utf8 Class Initialized
INFO - 2016-02-03 08:03:11 --> URI Class Initialized
INFO - 2016-02-03 08:03:11 --> Router Class Initialized
INFO - 2016-02-03 08:03:11 --> Output Class Initialized
INFO - 2016-02-03 08:03:11 --> Security Class Initialized
DEBUG - 2016-02-03 08:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:03:11 --> Input Class Initialized
INFO - 2016-02-03 08:03:11 --> Language Class Initialized
INFO - 2016-02-03 08:03:11 --> Loader Class Initialized
INFO - 2016-02-03 08:03:11 --> Helper loaded: url_helper
INFO - 2016-02-03 08:03:11 --> Helper loaded: file_helper
INFO - 2016-02-03 08:03:11 --> Helper loaded: date_helper
INFO - 2016-02-03 08:03:11 --> Database Driver Class Initialized
INFO - 2016-02-03 08:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:03:12 --> Controller Class Initialized
INFO - 2016-02-03 08:03:12 --> Model Class Initialized
INFO - 2016-02-03 08:03:12 --> Model Class Initialized
INFO - 2016-02-03 08:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:03:12 --> Pagination Class Initialized
INFO - 2016-02-03 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:03:12 --> Helper loaded: text_helper
INFO - 2016-02-03 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:03:12 --> Final output sent to browser
DEBUG - 2016-02-03 08:03:12 --> Total execution time: 1.1225
INFO - 2016-02-03 08:07:00 --> Config Class Initialized
INFO - 2016-02-03 08:07:00 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:07:00 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:07:00 --> Utf8 Class Initialized
INFO - 2016-02-03 08:07:00 --> URI Class Initialized
INFO - 2016-02-03 08:07:00 --> Router Class Initialized
INFO - 2016-02-03 08:07:00 --> Output Class Initialized
INFO - 2016-02-03 08:07:00 --> Security Class Initialized
DEBUG - 2016-02-03 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:07:00 --> Input Class Initialized
INFO - 2016-02-03 08:07:00 --> Language Class Initialized
INFO - 2016-02-03 08:07:00 --> Loader Class Initialized
INFO - 2016-02-03 08:07:00 --> Helper loaded: url_helper
INFO - 2016-02-03 08:07:00 --> Helper loaded: file_helper
INFO - 2016-02-03 08:07:00 --> Helper loaded: date_helper
INFO - 2016-02-03 08:07:00 --> Database Driver Class Initialized
INFO - 2016-02-03 08:07:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:07:01 --> Controller Class Initialized
INFO - 2016-02-03 08:07:01 --> Model Class Initialized
INFO - 2016-02-03 08:07:01 --> Model Class Initialized
INFO - 2016-02-03 08:07:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:07:01 --> Pagination Class Initialized
INFO - 2016-02-03 08:07:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:07:01 --> Helper loaded: text_helper
INFO - 2016-02-03 08:07:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:07:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:07:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:07:01 --> Final output sent to browser
DEBUG - 2016-02-03 08:07:01 --> Total execution time: 1.1850
INFO - 2016-02-03 08:07:01 --> Config Class Initialized
INFO - 2016-02-03 08:07:01 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:07:01 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:07:01 --> Utf8 Class Initialized
INFO - 2016-02-03 08:07:01 --> URI Class Initialized
INFO - 2016-02-03 08:07:01 --> Router Class Initialized
INFO - 2016-02-03 08:07:01 --> Output Class Initialized
INFO - 2016-02-03 08:07:01 --> Security Class Initialized
DEBUG - 2016-02-03 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:07:01 --> Input Class Initialized
INFO - 2016-02-03 08:07:02 --> Language Class Initialized
INFO - 2016-02-03 08:07:02 --> Loader Class Initialized
INFO - 2016-02-03 08:07:02 --> Helper loaded: url_helper
INFO - 2016-02-03 08:07:02 --> Helper loaded: file_helper
INFO - 2016-02-03 08:07:02 --> Helper loaded: date_helper
INFO - 2016-02-03 08:07:02 --> Database Driver Class Initialized
INFO - 2016-02-03 08:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:07:03 --> Controller Class Initialized
INFO - 2016-02-03 08:07:03 --> Model Class Initialized
INFO - 2016-02-03 08:07:03 --> Model Class Initialized
INFO - 2016-02-03 08:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:07:03 --> Pagination Class Initialized
INFO - 2016-02-03 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:07:03 --> Helper loaded: text_helper
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 4
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 13
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 18
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 22
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 23
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-03 08:07:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 51
INFO - 2016-02-03 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:07:03 --> Final output sent to browser
DEBUG - 2016-02-03 08:07:03 --> Total execution time: 1.3055
INFO - 2016-02-03 08:07:57 --> Config Class Initialized
INFO - 2016-02-03 08:07:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:07:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:07:57 --> Utf8 Class Initialized
INFO - 2016-02-03 08:07:57 --> URI Class Initialized
INFO - 2016-02-03 08:07:57 --> Router Class Initialized
INFO - 2016-02-03 08:07:57 --> Output Class Initialized
INFO - 2016-02-03 08:07:57 --> Security Class Initialized
DEBUG - 2016-02-03 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:07:57 --> Input Class Initialized
INFO - 2016-02-03 08:07:57 --> Language Class Initialized
INFO - 2016-02-03 08:07:57 --> Loader Class Initialized
INFO - 2016-02-03 08:07:57 --> Helper loaded: url_helper
INFO - 2016-02-03 08:07:57 --> Helper loaded: file_helper
INFO - 2016-02-03 08:07:57 --> Helper loaded: date_helper
INFO - 2016-02-03 08:07:57 --> Database Driver Class Initialized
INFO - 2016-02-03 08:07:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:07:58 --> Controller Class Initialized
INFO - 2016-02-03 08:07:58 --> Model Class Initialized
INFO - 2016-02-03 08:07:58 --> Model Class Initialized
INFO - 2016-02-03 08:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:07:58 --> Pagination Class Initialized
INFO - 2016-02-03 08:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:07:58 --> Helper loaded: text_helper
INFO - 2016-02-03 08:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:07:58 --> Final output sent to browser
DEBUG - 2016-02-03 08:07:58 --> Total execution time: 1.2061
INFO - 2016-02-03 08:10:22 --> Config Class Initialized
INFO - 2016-02-03 08:10:22 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:10:22 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:10:22 --> Utf8 Class Initialized
INFO - 2016-02-03 08:10:22 --> URI Class Initialized
INFO - 2016-02-03 08:10:22 --> Router Class Initialized
INFO - 2016-02-03 08:10:22 --> Output Class Initialized
INFO - 2016-02-03 08:10:22 --> Security Class Initialized
DEBUG - 2016-02-03 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:10:22 --> Input Class Initialized
INFO - 2016-02-03 08:10:22 --> Language Class Initialized
INFO - 2016-02-03 08:10:22 --> Loader Class Initialized
INFO - 2016-02-03 08:10:22 --> Helper loaded: url_helper
INFO - 2016-02-03 08:10:22 --> Helper loaded: file_helper
INFO - 2016-02-03 08:10:22 --> Helper loaded: date_helper
INFO - 2016-02-03 08:10:22 --> Database Driver Class Initialized
INFO - 2016-02-03 08:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:10:23 --> Controller Class Initialized
INFO - 2016-02-03 08:10:23 --> Model Class Initialized
INFO - 2016-02-03 08:10:23 --> Model Class Initialized
INFO - 2016-02-03 08:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:10:23 --> Pagination Class Initialized
INFO - 2016-02-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:10:23 --> Helper loaded: text_helper
INFO - 2016-02-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:10:23 --> Final output sent to browser
DEBUG - 2016-02-03 08:10:23 --> Total execution time: 1.2868
INFO - 2016-02-03 08:10:41 --> Config Class Initialized
INFO - 2016-02-03 08:10:41 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:10:41 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:10:41 --> Utf8 Class Initialized
INFO - 2016-02-03 08:10:41 --> URI Class Initialized
INFO - 2016-02-03 08:10:41 --> Router Class Initialized
INFO - 2016-02-03 08:10:41 --> Output Class Initialized
INFO - 2016-02-03 08:10:41 --> Security Class Initialized
DEBUG - 2016-02-03 08:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:10:41 --> Input Class Initialized
INFO - 2016-02-03 08:10:41 --> Language Class Initialized
INFO - 2016-02-03 08:10:41 --> Loader Class Initialized
INFO - 2016-02-03 08:10:41 --> Helper loaded: url_helper
INFO - 2016-02-03 08:10:41 --> Helper loaded: file_helper
INFO - 2016-02-03 08:10:41 --> Helper loaded: date_helper
INFO - 2016-02-03 08:10:41 --> Database Driver Class Initialized
INFO - 2016-02-03 08:10:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:10:42 --> Controller Class Initialized
INFO - 2016-02-03 08:10:42 --> Model Class Initialized
INFO - 2016-02-03 08:10:42 --> Model Class Initialized
INFO - 2016-02-03 08:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:10:42 --> Pagination Class Initialized
INFO - 2016-02-03 08:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:10:42 --> Helper loaded: text_helper
INFO - 2016-02-03 08:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:10:42 --> Final output sent to browser
DEBUG - 2016-02-03 08:10:42 --> Total execution time: 1.1845
INFO - 2016-02-03 08:12:05 --> Config Class Initialized
INFO - 2016-02-03 08:12:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:12:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:12:05 --> Utf8 Class Initialized
INFO - 2016-02-03 08:12:05 --> URI Class Initialized
INFO - 2016-02-03 08:12:05 --> Router Class Initialized
INFO - 2016-02-03 08:12:05 --> Output Class Initialized
INFO - 2016-02-03 08:12:05 --> Security Class Initialized
DEBUG - 2016-02-03 08:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:12:05 --> Input Class Initialized
INFO - 2016-02-03 08:12:05 --> Language Class Initialized
INFO - 2016-02-03 08:12:05 --> Loader Class Initialized
INFO - 2016-02-03 08:12:05 --> Helper loaded: url_helper
INFO - 2016-02-03 08:12:05 --> Helper loaded: file_helper
INFO - 2016-02-03 08:12:05 --> Helper loaded: date_helper
INFO - 2016-02-03 08:12:05 --> Database Driver Class Initialized
INFO - 2016-02-03 08:12:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:12:07 --> Controller Class Initialized
INFO - 2016-02-03 08:12:07 --> Model Class Initialized
INFO - 2016-02-03 08:12:07 --> Model Class Initialized
INFO - 2016-02-03 08:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:12:07 --> Pagination Class Initialized
INFO - 2016-02-03 08:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:12:07 --> Helper loaded: text_helper
INFO - 2016-02-03 08:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:12:07 --> Final output sent to browser
DEBUG - 2016-02-03 08:12:07 --> Total execution time: 1.1534
INFO - 2016-02-03 08:12:10 --> Config Class Initialized
INFO - 2016-02-03 08:12:10 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:12:10 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:12:10 --> Utf8 Class Initialized
INFO - 2016-02-03 08:12:10 --> URI Class Initialized
DEBUG - 2016-02-03 08:12:10 --> No URI present. Default controller set.
INFO - 2016-02-03 08:12:10 --> Router Class Initialized
INFO - 2016-02-03 08:12:10 --> Output Class Initialized
INFO - 2016-02-03 08:12:10 --> Security Class Initialized
DEBUG - 2016-02-03 08:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:12:10 --> Input Class Initialized
INFO - 2016-02-03 08:12:10 --> Language Class Initialized
INFO - 2016-02-03 08:12:10 --> Loader Class Initialized
INFO - 2016-02-03 08:12:10 --> Helper loaded: url_helper
INFO - 2016-02-03 08:12:10 --> Helper loaded: file_helper
INFO - 2016-02-03 08:12:10 --> Helper loaded: date_helper
INFO - 2016-02-03 08:12:10 --> Database Driver Class Initialized
INFO - 2016-02-03 08:12:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:12:11 --> Controller Class Initialized
INFO - 2016-02-03 08:12:11 --> Model Class Initialized
INFO - 2016-02-03 08:12:11 --> Model Class Initialized
INFO - 2016-02-03 08:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:12:11 --> Pagination Class Initialized
INFO - 2016-02-03 08:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 08:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:12:11 --> Final output sent to browser
DEBUG - 2016-02-03 08:12:11 --> Total execution time: 1.0926
INFO - 2016-02-03 08:12:34 --> Config Class Initialized
INFO - 2016-02-03 08:12:34 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:12:34 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:12:34 --> Utf8 Class Initialized
INFO - 2016-02-03 08:12:34 --> URI Class Initialized
DEBUG - 2016-02-03 08:12:34 --> No URI present. Default controller set.
INFO - 2016-02-03 08:12:34 --> Router Class Initialized
INFO - 2016-02-03 08:12:34 --> Output Class Initialized
INFO - 2016-02-03 08:12:34 --> Security Class Initialized
DEBUG - 2016-02-03 08:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:12:34 --> Input Class Initialized
INFO - 2016-02-03 08:12:34 --> Language Class Initialized
INFO - 2016-02-03 08:12:34 --> Loader Class Initialized
INFO - 2016-02-03 08:12:34 --> Helper loaded: url_helper
INFO - 2016-02-03 08:12:34 --> Helper loaded: file_helper
INFO - 2016-02-03 08:12:34 --> Helper loaded: date_helper
INFO - 2016-02-03 08:12:34 --> Database Driver Class Initialized
INFO - 2016-02-03 08:12:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:12:36 --> Controller Class Initialized
INFO - 2016-02-03 08:12:36 --> Model Class Initialized
INFO - 2016-02-03 08:12:36 --> Model Class Initialized
INFO - 2016-02-03 08:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:12:36 --> Pagination Class Initialized
INFO - 2016-02-03 08:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 08:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:12:36 --> Final output sent to browser
DEBUG - 2016-02-03 08:12:36 --> Total execution time: 1.0999
INFO - 2016-02-03 08:12:38 --> Config Class Initialized
INFO - 2016-02-03 08:12:38 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:12:38 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:12:38 --> Utf8 Class Initialized
INFO - 2016-02-03 08:12:38 --> URI Class Initialized
INFO - 2016-02-03 08:12:38 --> Router Class Initialized
INFO - 2016-02-03 08:12:38 --> Output Class Initialized
INFO - 2016-02-03 08:12:38 --> Security Class Initialized
DEBUG - 2016-02-03 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:12:38 --> Input Class Initialized
INFO - 2016-02-03 08:12:38 --> Language Class Initialized
INFO - 2016-02-03 08:12:38 --> Loader Class Initialized
INFO - 2016-02-03 08:12:38 --> Helper loaded: url_helper
INFO - 2016-02-03 08:12:38 --> Helper loaded: file_helper
INFO - 2016-02-03 08:12:38 --> Helper loaded: date_helper
INFO - 2016-02-03 08:12:38 --> Database Driver Class Initialized
INFO - 2016-02-03 08:12:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:12:39 --> Controller Class Initialized
INFO - 2016-02-03 08:12:39 --> Model Class Initialized
INFO - 2016-02-03 08:12:39 --> Model Class Initialized
INFO - 2016-02-03 08:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:12:39 --> Pagination Class Initialized
INFO - 2016-02-03 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:12:39 --> Helper loaded: text_helper
INFO - 2016-02-03 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:12:39 --> Final output sent to browser
DEBUG - 2016-02-03 08:12:39 --> Total execution time: 1.1397
INFO - 2016-02-03 08:28:45 --> Config Class Initialized
INFO - 2016-02-03 08:28:45 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:28:45 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:28:45 --> Utf8 Class Initialized
INFO - 2016-02-03 08:28:45 --> URI Class Initialized
INFO - 2016-02-03 08:28:45 --> Router Class Initialized
INFO - 2016-02-03 08:28:45 --> Output Class Initialized
INFO - 2016-02-03 08:28:45 --> Security Class Initialized
DEBUG - 2016-02-03 08:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:28:45 --> Input Class Initialized
INFO - 2016-02-03 08:28:45 --> Language Class Initialized
INFO - 2016-02-03 08:28:45 --> Loader Class Initialized
INFO - 2016-02-03 08:28:45 --> Helper loaded: url_helper
INFO - 2016-02-03 08:28:45 --> Helper loaded: file_helper
INFO - 2016-02-03 08:28:45 --> Helper loaded: date_helper
INFO - 2016-02-03 08:28:45 --> Database Driver Class Initialized
INFO - 2016-02-03 08:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:28:46 --> Controller Class Initialized
INFO - 2016-02-03 08:28:46 --> Model Class Initialized
INFO - 2016-02-03 08:28:46 --> Model Class Initialized
INFO - 2016-02-03 08:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:28:46 --> Pagination Class Initialized
INFO - 2016-02-03 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:28:46 --> Helper loaded: text_helper
INFO - 2016-02-03 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:28:46 --> Final output sent to browser
DEBUG - 2016-02-03 08:28:46 --> Total execution time: 1.2331
INFO - 2016-02-03 08:28:56 --> Config Class Initialized
INFO - 2016-02-03 08:28:56 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:28:56 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:28:56 --> Utf8 Class Initialized
INFO - 2016-02-03 08:28:56 --> URI Class Initialized
INFO - 2016-02-03 08:28:56 --> Router Class Initialized
INFO - 2016-02-03 08:28:56 --> Output Class Initialized
INFO - 2016-02-03 08:28:56 --> Security Class Initialized
DEBUG - 2016-02-03 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:28:56 --> Input Class Initialized
INFO - 2016-02-03 08:28:56 --> Language Class Initialized
INFO - 2016-02-03 08:28:56 --> Loader Class Initialized
INFO - 2016-02-03 08:28:56 --> Helper loaded: url_helper
INFO - 2016-02-03 08:28:56 --> Helper loaded: file_helper
INFO - 2016-02-03 08:28:56 --> Helper loaded: date_helper
INFO - 2016-02-03 08:28:56 --> Database Driver Class Initialized
INFO - 2016-02-03 08:28:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:28:57 --> Controller Class Initialized
INFO - 2016-02-03 08:28:57 --> Model Class Initialized
INFO - 2016-02-03 08:28:57 --> Model Class Initialized
INFO - 2016-02-03 08:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:28:57 --> Pagination Class Initialized
INFO - 2016-02-03 08:28:57 --> Config Class Initialized
INFO - 2016-02-03 08:28:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:28:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:28:57 --> Utf8 Class Initialized
INFO - 2016-02-03 08:28:57 --> URI Class Initialized
INFO - 2016-02-03 08:28:57 --> Router Class Initialized
INFO - 2016-02-03 08:28:57 --> Output Class Initialized
INFO - 2016-02-03 08:28:58 --> Security Class Initialized
DEBUG - 2016-02-03 08:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:28:58 --> Input Class Initialized
INFO - 2016-02-03 08:28:58 --> Language Class Initialized
INFO - 2016-02-03 08:28:58 --> Loader Class Initialized
INFO - 2016-02-03 08:28:58 --> Helper loaded: url_helper
INFO - 2016-02-03 08:28:58 --> Helper loaded: file_helper
INFO - 2016-02-03 08:28:58 --> Helper loaded: date_helper
INFO - 2016-02-03 08:28:58 --> Database Driver Class Initialized
INFO - 2016-02-03 08:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:28:59 --> Controller Class Initialized
INFO - 2016-02-03 08:28:59 --> Model Class Initialized
INFO - 2016-02-03 08:28:59 --> Model Class Initialized
INFO - 2016-02-03 08:28:59 --> Helper loaded: form_helper
INFO - 2016-02-03 08:28:59 --> Form Validation Class Initialized
INFO - 2016-02-03 08:28:59 --> Helper loaded: text_helper
INFO - 2016-02-03 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-03 08:28:59 --> Final output sent to browser
DEBUG - 2016-02-03 08:28:59 --> Total execution time: 1.0790
INFO - 2016-02-03 08:29:20 --> Config Class Initialized
INFO - 2016-02-03 08:29:20 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:29:20 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:29:20 --> Utf8 Class Initialized
INFO - 2016-02-03 08:29:20 --> URI Class Initialized
INFO - 2016-02-03 08:29:20 --> Router Class Initialized
INFO - 2016-02-03 08:29:20 --> Output Class Initialized
INFO - 2016-02-03 08:29:20 --> Security Class Initialized
DEBUG - 2016-02-03 08:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:29:20 --> Input Class Initialized
INFO - 2016-02-03 08:29:20 --> Language Class Initialized
INFO - 2016-02-03 08:29:20 --> Loader Class Initialized
INFO - 2016-02-03 08:29:20 --> Helper loaded: url_helper
INFO - 2016-02-03 08:29:20 --> Helper loaded: file_helper
INFO - 2016-02-03 08:29:20 --> Helper loaded: date_helper
INFO - 2016-02-03 08:29:20 --> Database Driver Class Initialized
INFO - 2016-02-03 08:29:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:29:21 --> Controller Class Initialized
INFO - 2016-02-03 08:29:21 --> Model Class Initialized
INFO - 2016-02-03 08:29:21 --> Model Class Initialized
INFO - 2016-02-03 08:29:21 --> Helper loaded: form_helper
INFO - 2016-02-03 08:29:21 --> Form Validation Class Initialized
INFO - 2016-02-03 08:29:21 --> Helper loaded: text_helper
INFO - 2016-02-03 08:29:21 --> Config Class Initialized
INFO - 2016-02-03 08:29:21 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:29:21 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:29:21 --> Utf8 Class Initialized
INFO - 2016-02-03 08:29:21 --> URI Class Initialized
INFO - 2016-02-03 08:29:21 --> Router Class Initialized
INFO - 2016-02-03 08:29:21 --> Output Class Initialized
INFO - 2016-02-03 08:29:21 --> Security Class Initialized
DEBUG - 2016-02-03 08:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:29:21 --> Input Class Initialized
INFO - 2016-02-03 08:29:21 --> Language Class Initialized
INFO - 2016-02-03 08:29:21 --> Loader Class Initialized
INFO - 2016-02-03 08:29:21 --> Helper loaded: url_helper
INFO - 2016-02-03 08:29:21 --> Helper loaded: file_helper
INFO - 2016-02-03 08:29:21 --> Helper loaded: date_helper
INFO - 2016-02-03 08:29:21 --> Database Driver Class Initialized
INFO - 2016-02-03 08:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:29:22 --> Controller Class Initialized
INFO - 2016-02-03 08:29:22 --> Model Class Initialized
INFO - 2016-02-03 08:29:22 --> Model Class Initialized
INFO - 2016-02-03 08:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:29:22 --> Pagination Class Initialized
INFO - 2016-02-03 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:29:22 --> Helper loaded: text_helper
INFO - 2016-02-03 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:29:22 --> Final output sent to browser
DEBUG - 2016-02-03 08:29:22 --> Total execution time: 1.1673
INFO - 2016-02-03 08:29:25 --> Config Class Initialized
INFO - 2016-02-03 08:29:25 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:29:25 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:29:25 --> Utf8 Class Initialized
INFO - 2016-02-03 08:29:25 --> URI Class Initialized
INFO - 2016-02-03 08:29:25 --> Router Class Initialized
INFO - 2016-02-03 08:29:25 --> Output Class Initialized
INFO - 2016-02-03 08:29:25 --> Security Class Initialized
DEBUG - 2016-02-03 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:29:25 --> Input Class Initialized
INFO - 2016-02-03 08:29:25 --> Language Class Initialized
INFO - 2016-02-03 08:29:25 --> Loader Class Initialized
INFO - 2016-02-03 08:29:25 --> Helper loaded: url_helper
INFO - 2016-02-03 08:29:25 --> Helper loaded: file_helper
INFO - 2016-02-03 08:29:25 --> Helper loaded: date_helper
INFO - 2016-02-03 08:29:25 --> Database Driver Class Initialized
INFO - 2016-02-03 08:29:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:29:26 --> Controller Class Initialized
INFO - 2016-02-03 08:29:26 --> Model Class Initialized
INFO - 2016-02-03 08:29:26 --> Model Class Initialized
INFO - 2016-02-03 08:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:29:26 --> Pagination Class Initialized
INFO - 2016-02-03 08:29:26 --> Config Class Initialized
INFO - 2016-02-03 08:29:26 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:29:26 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:29:26 --> Utf8 Class Initialized
INFO - 2016-02-03 08:29:26 --> URI Class Initialized
INFO - 2016-02-03 08:29:26 --> Router Class Initialized
INFO - 2016-02-03 08:29:26 --> Output Class Initialized
INFO - 2016-02-03 08:29:26 --> Security Class Initialized
DEBUG - 2016-02-03 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:29:26 --> Input Class Initialized
INFO - 2016-02-03 08:29:26 --> Language Class Initialized
INFO - 2016-02-03 08:29:26 --> Loader Class Initialized
INFO - 2016-02-03 08:29:26 --> Helper loaded: url_helper
INFO - 2016-02-03 08:29:26 --> Helper loaded: file_helper
INFO - 2016-02-03 08:29:26 --> Helper loaded: date_helper
INFO - 2016-02-03 08:29:26 --> Database Driver Class Initialized
INFO - 2016-02-03 08:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:29:27 --> Controller Class Initialized
INFO - 2016-02-03 08:29:27 --> Model Class Initialized
INFO - 2016-02-03 08:29:27 --> Model Class Initialized
INFO - 2016-02-03 08:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:29:27 --> Pagination Class Initialized
INFO - 2016-02-03 08:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:29:27 --> Helper loaded: text_helper
INFO - 2016-02-03 08:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:29:27 --> Final output sent to browser
DEBUG - 2016-02-03 08:29:27 --> Total execution time: 1.1343
INFO - 2016-02-03 08:32:20 --> Config Class Initialized
INFO - 2016-02-03 08:32:20 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:32:20 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:32:20 --> Utf8 Class Initialized
INFO - 2016-02-03 08:32:20 --> URI Class Initialized
INFO - 2016-02-03 08:32:20 --> Router Class Initialized
INFO - 2016-02-03 08:32:20 --> Output Class Initialized
INFO - 2016-02-03 08:32:20 --> Security Class Initialized
DEBUG - 2016-02-03 08:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:32:20 --> Input Class Initialized
INFO - 2016-02-03 08:32:20 --> Language Class Initialized
INFO - 2016-02-03 08:32:20 --> Loader Class Initialized
INFO - 2016-02-03 08:32:20 --> Helper loaded: url_helper
INFO - 2016-02-03 08:32:20 --> Helper loaded: file_helper
INFO - 2016-02-03 08:32:20 --> Helper loaded: date_helper
INFO - 2016-02-03 08:32:20 --> Database Driver Class Initialized
INFO - 2016-02-03 08:32:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:32:21 --> Controller Class Initialized
INFO - 2016-02-03 08:32:21 --> Model Class Initialized
INFO - 2016-02-03 08:32:21 --> Model Class Initialized
INFO - 2016-02-03 08:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:32:21 --> Pagination Class Initialized
INFO - 2016-02-03 08:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:32:21 --> Helper loaded: text_helper
INFO - 2016-02-03 08:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:32:21 --> Final output sent to browser
DEBUG - 2016-02-03 08:32:21 --> Total execution time: 1.1353
INFO - 2016-02-03 08:32:26 --> Config Class Initialized
INFO - 2016-02-03 08:32:26 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:32:26 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:32:26 --> Utf8 Class Initialized
INFO - 2016-02-03 08:32:26 --> URI Class Initialized
INFO - 2016-02-03 08:32:26 --> Router Class Initialized
INFO - 2016-02-03 08:32:26 --> Output Class Initialized
INFO - 2016-02-03 08:32:26 --> Security Class Initialized
DEBUG - 2016-02-03 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:32:26 --> Input Class Initialized
INFO - 2016-02-03 08:32:26 --> Language Class Initialized
INFO - 2016-02-03 08:32:26 --> Loader Class Initialized
INFO - 2016-02-03 08:32:26 --> Helper loaded: url_helper
INFO - 2016-02-03 08:32:26 --> Helper loaded: file_helper
INFO - 2016-02-03 08:32:26 --> Helper loaded: date_helper
INFO - 2016-02-03 08:32:26 --> Database Driver Class Initialized
INFO - 2016-02-03 08:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:32:27 --> Controller Class Initialized
INFO - 2016-02-03 08:32:27 --> Model Class Initialized
INFO - 2016-02-03 08:32:27 --> Model Class Initialized
INFO - 2016-02-03 08:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:32:27 --> Pagination Class Initialized
INFO - 2016-02-03 08:32:27 --> Config Class Initialized
INFO - 2016-02-03 08:32:27 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:32:27 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:32:27 --> Utf8 Class Initialized
INFO - 2016-02-03 08:32:27 --> URI Class Initialized
INFO - 2016-02-03 08:32:27 --> Router Class Initialized
INFO - 2016-02-03 08:32:27 --> Output Class Initialized
INFO - 2016-02-03 08:32:27 --> Security Class Initialized
DEBUG - 2016-02-03 08:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:32:27 --> Input Class Initialized
INFO - 2016-02-03 08:32:27 --> Language Class Initialized
INFO - 2016-02-03 08:32:27 --> Loader Class Initialized
INFO - 2016-02-03 08:32:27 --> Helper loaded: url_helper
INFO - 2016-02-03 08:32:27 --> Helper loaded: file_helper
INFO - 2016-02-03 08:32:27 --> Helper loaded: date_helper
INFO - 2016-02-03 08:32:27 --> Database Driver Class Initialized
INFO - 2016-02-03 08:32:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:32:28 --> Controller Class Initialized
INFO - 2016-02-03 08:32:28 --> Model Class Initialized
INFO - 2016-02-03 08:32:28 --> Model Class Initialized
INFO - 2016-02-03 08:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:32:28 --> Pagination Class Initialized
INFO - 2016-02-03 08:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 08:32:28 --> Helper loaded: text_helper
INFO - 2016-02-03 08:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 08:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 08:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 08:32:28 --> Final output sent to browser
DEBUG - 2016-02-03 08:32:28 --> Total execution time: 1.1438
INFO - 2016-02-03 08:40:27 --> Config Class Initialized
INFO - 2016-02-03 08:40:27 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:40:27 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:40:27 --> Utf8 Class Initialized
INFO - 2016-02-03 08:40:27 --> URI Class Initialized
INFO - 2016-02-03 08:40:27 --> Router Class Initialized
INFO - 2016-02-03 08:40:27 --> Output Class Initialized
INFO - 2016-02-03 08:40:27 --> Security Class Initialized
DEBUG - 2016-02-03 08:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:40:27 --> Input Class Initialized
INFO - 2016-02-03 08:40:27 --> Language Class Initialized
INFO - 2016-02-03 08:40:27 --> Loader Class Initialized
INFO - 2016-02-03 08:40:27 --> Helper loaded: url_helper
INFO - 2016-02-03 08:40:27 --> Helper loaded: file_helper
INFO - 2016-02-03 08:40:27 --> Helper loaded: date_helper
INFO - 2016-02-03 08:40:27 --> Database Driver Class Initialized
INFO - 2016-02-03 08:40:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:40:28 --> Controller Class Initialized
INFO - 2016-02-03 08:40:28 --> Model Class Initialized
INFO - 2016-02-03 08:40:28 --> Model Class Initialized
INFO - 2016-02-03 08:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:40:28 --> Pagination Class Initialized
ERROR - 2016-02-03 08:40:28 --> Severity: Warning --> Missing argument 1 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\vote.php on line 53 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-03 08:40:28 --> Severity: Warning --> Missing argument 2 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\vote.php on line 53 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-03 08:40:28 --> Severity: Notice --> Undefined variable: limit C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-03 08:40:28 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-03 08:40:28 --> Severity: Notice --> Undefined variable: total C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 3
ERROR - 2016-02-03 08:40:28 --> Severity: Notice --> Undefined variable: result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:40:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:40:28 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 31
INFO - 2016-02-03 08:40:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 08:40:28 --> Final output sent to browser
DEBUG - 2016-02-03 08:40:28 --> Total execution time: 1.6814
INFO - 2016-02-03 08:41:00 --> Config Class Initialized
INFO - 2016-02-03 08:41:00 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:41:00 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:41:00 --> Utf8 Class Initialized
INFO - 2016-02-03 08:41:00 --> URI Class Initialized
INFO - 2016-02-03 08:41:00 --> Router Class Initialized
INFO - 2016-02-03 08:41:00 --> Output Class Initialized
INFO - 2016-02-03 08:41:00 --> Security Class Initialized
DEBUG - 2016-02-03 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:41:00 --> Input Class Initialized
INFO - 2016-02-03 08:41:00 --> Language Class Initialized
INFO - 2016-02-03 08:41:00 --> Loader Class Initialized
INFO - 2016-02-03 08:41:00 --> Helper loaded: url_helper
INFO - 2016-02-03 08:41:01 --> Helper loaded: file_helper
INFO - 2016-02-03 08:41:01 --> Helper loaded: date_helper
INFO - 2016-02-03 08:41:01 --> Database Driver Class Initialized
INFO - 2016-02-03 08:41:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:41:02 --> Controller Class Initialized
INFO - 2016-02-03 08:41:02 --> Model Class Initialized
INFO - 2016-02-03 08:41:02 --> Model Class Initialized
INFO - 2016-02-03 08:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:41:02 --> Pagination Class Initialized
ERROR - 2016-02-03 08:41:02 --> Severity: Warning --> Missing argument 1 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\vote.php on line 53 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-03 08:41:02 --> Severity: Warning --> Missing argument 2 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\vote.php on line 53 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-03 08:41:02 --> Severity: Notice --> Undefined variable: limit C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-03 08:41:02 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-03 08:41:02 --> Severity: Notice --> Undefined variable: total C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 3
ERROR - 2016-02-03 08:41:02 --> Severity: Notice --> Undefined variable: result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:41:02 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 31
INFO - 2016-02-03 08:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 08:41:02 --> Final output sent to browser
DEBUG - 2016-02-03 08:41:02 --> Total execution time: 1.1991
INFO - 2016-02-03 08:43:15 --> Config Class Initialized
INFO - 2016-02-03 08:43:15 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:43:15 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:43:15 --> Utf8 Class Initialized
INFO - 2016-02-03 08:43:15 --> URI Class Initialized
INFO - 2016-02-03 08:43:15 --> Router Class Initialized
INFO - 2016-02-03 08:43:15 --> Output Class Initialized
INFO - 2016-02-03 08:43:15 --> Security Class Initialized
DEBUG - 2016-02-03 08:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:43:15 --> Input Class Initialized
INFO - 2016-02-03 08:43:15 --> Language Class Initialized
INFO - 2016-02-03 08:43:15 --> Loader Class Initialized
INFO - 2016-02-03 08:43:15 --> Helper loaded: url_helper
INFO - 2016-02-03 08:43:15 --> Helper loaded: file_helper
INFO - 2016-02-03 08:43:15 --> Helper loaded: date_helper
INFO - 2016-02-03 08:43:15 --> Database Driver Class Initialized
INFO - 2016-02-03 08:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:43:16 --> Controller Class Initialized
INFO - 2016-02-03 08:43:16 --> Model Class Initialized
INFO - 2016-02-03 08:43:16 --> Model Class Initialized
INFO - 2016-02-03 08:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:43:16 --> Pagination Class Initialized
ERROR - 2016-02-03 08:43:16 --> Severity: Notice --> Undefined variable: total C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 3
ERROR - 2016-02-03 08:43:16 --> Severity: Notice --> Undefined variable: result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
ERROR - 2016-02-03 08:43:16 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 31
INFO - 2016-02-03 08:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 08:43:16 --> Final output sent to browser
DEBUG - 2016-02-03 08:43:16 --> Total execution time: 1.1295
INFO - 2016-02-03 08:44:28 --> Config Class Initialized
INFO - 2016-02-03 08:44:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:44:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:44:28 --> Utf8 Class Initialized
INFO - 2016-02-03 08:44:28 --> URI Class Initialized
INFO - 2016-02-03 08:44:28 --> Router Class Initialized
INFO - 2016-02-03 08:44:28 --> Output Class Initialized
INFO - 2016-02-03 08:44:28 --> Security Class Initialized
DEBUG - 2016-02-03 08:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:44:28 --> Input Class Initialized
INFO - 2016-02-03 08:44:28 --> Language Class Initialized
INFO - 2016-02-03 08:44:28 --> Loader Class Initialized
INFO - 2016-02-03 08:44:28 --> Helper loaded: url_helper
INFO - 2016-02-03 08:44:28 --> Helper loaded: file_helper
INFO - 2016-02-03 08:44:28 --> Helper loaded: date_helper
INFO - 2016-02-03 08:44:28 --> Database Driver Class Initialized
INFO - 2016-02-03 08:44:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:44:29 --> Controller Class Initialized
INFO - 2016-02-03 08:44:29 --> Model Class Initialized
INFO - 2016-02-03 08:44:29 --> Model Class Initialized
INFO - 2016-02-03 08:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:44:29 --> Pagination Class Initialized
INFO - 2016-02-03 08:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 08:44:29 --> Final output sent to browser
DEBUG - 2016-02-03 08:44:29 --> Total execution time: 1.1263
INFO - 2016-02-03 08:44:58 --> Config Class Initialized
INFO - 2016-02-03 08:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:44:58 --> Utf8 Class Initialized
INFO - 2016-02-03 08:44:58 --> URI Class Initialized
INFO - 2016-02-03 08:44:58 --> Router Class Initialized
INFO - 2016-02-03 08:44:58 --> Output Class Initialized
INFO - 2016-02-03 08:44:58 --> Security Class Initialized
DEBUG - 2016-02-03 08:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:44:58 --> Input Class Initialized
INFO - 2016-02-03 08:44:58 --> Language Class Initialized
INFO - 2016-02-03 08:44:58 --> Loader Class Initialized
INFO - 2016-02-03 08:44:58 --> Helper loaded: url_helper
INFO - 2016-02-03 08:44:58 --> Helper loaded: file_helper
INFO - 2016-02-03 08:44:58 --> Helper loaded: date_helper
INFO - 2016-02-03 08:44:58 --> Database Driver Class Initialized
INFO - 2016-02-03 08:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:44:59 --> Controller Class Initialized
INFO - 2016-02-03 08:44:59 --> Model Class Initialized
INFO - 2016-02-03 08:44:59 --> Model Class Initialized
INFO - 2016-02-03 08:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:44:59 --> Pagination Class Initialized
INFO - 2016-02-03 08:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 08:44:59 --> Final output sent to browser
DEBUG - 2016-02-03 08:44:59 --> Total execution time: 1.1343
INFO - 2016-02-03 08:45:19 --> Config Class Initialized
INFO - 2016-02-03 08:45:19 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:45:19 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:45:19 --> Utf8 Class Initialized
INFO - 2016-02-03 08:45:19 --> URI Class Initialized
INFO - 2016-02-03 08:45:19 --> Router Class Initialized
INFO - 2016-02-03 08:45:19 --> Output Class Initialized
INFO - 2016-02-03 08:45:19 --> Security Class Initialized
DEBUG - 2016-02-03 08:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:45:19 --> Input Class Initialized
INFO - 2016-02-03 08:45:19 --> Language Class Initialized
INFO - 2016-02-03 08:45:19 --> Loader Class Initialized
INFO - 2016-02-03 08:45:19 --> Helper loaded: url_helper
INFO - 2016-02-03 08:45:19 --> Helper loaded: file_helper
INFO - 2016-02-03 08:45:19 --> Helper loaded: date_helper
INFO - 2016-02-03 08:45:19 --> Database Driver Class Initialized
INFO - 2016-02-03 08:45:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:45:20 --> Controller Class Initialized
INFO - 2016-02-03 08:45:20 --> Model Class Initialized
INFO - 2016-02-03 08:45:20 --> Model Class Initialized
INFO - 2016-02-03 08:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:45:20 --> Pagination Class Initialized
INFO - 2016-02-03 08:45:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 08:45:20 --> Final output sent to browser
DEBUG - 2016-02-03 08:45:20 --> Total execution time: 1.0849
INFO - 2016-02-03 08:45:57 --> Config Class Initialized
INFO - 2016-02-03 08:45:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:45:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:45:57 --> Utf8 Class Initialized
INFO - 2016-02-03 08:45:57 --> URI Class Initialized
INFO - 2016-02-03 08:45:57 --> Router Class Initialized
INFO - 2016-02-03 08:45:57 --> Output Class Initialized
INFO - 2016-02-03 08:45:57 --> Security Class Initialized
DEBUG - 2016-02-03 08:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:45:57 --> Input Class Initialized
INFO - 2016-02-03 08:45:57 --> Language Class Initialized
INFO - 2016-02-03 08:45:57 --> Loader Class Initialized
INFO - 2016-02-03 08:45:57 --> Helper loaded: url_helper
INFO - 2016-02-03 08:45:57 --> Helper loaded: file_helper
INFO - 2016-02-03 08:45:57 --> Helper loaded: date_helper
INFO - 2016-02-03 08:45:57 --> Database Driver Class Initialized
INFO - 2016-02-03 08:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:45:58 --> Controller Class Initialized
INFO - 2016-02-03 08:45:58 --> Model Class Initialized
INFO - 2016-02-03 08:45:58 --> Model Class Initialized
INFO - 2016-02-03 08:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:45:58 --> Pagination Class Initialized
INFO - 2016-02-03 08:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 08:45:58 --> Final output sent to browser
DEBUG - 2016-02-03 08:45:58 --> Total execution time: 1.0953
INFO - 2016-02-03 08:46:46 --> Config Class Initialized
INFO - 2016-02-03 08:46:46 --> Hooks Class Initialized
DEBUG - 2016-02-03 08:46:46 --> UTF-8 Support Enabled
INFO - 2016-02-03 08:46:46 --> Utf8 Class Initialized
INFO - 2016-02-03 08:46:46 --> URI Class Initialized
INFO - 2016-02-03 08:46:46 --> Router Class Initialized
INFO - 2016-02-03 08:46:46 --> Output Class Initialized
INFO - 2016-02-03 08:46:46 --> Security Class Initialized
DEBUG - 2016-02-03 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 08:46:46 --> Input Class Initialized
INFO - 2016-02-03 08:46:46 --> Language Class Initialized
INFO - 2016-02-03 08:46:46 --> Loader Class Initialized
INFO - 2016-02-03 08:46:46 --> Helper loaded: url_helper
INFO - 2016-02-03 08:46:46 --> Helper loaded: file_helper
INFO - 2016-02-03 08:46:46 --> Helper loaded: date_helper
INFO - 2016-02-03 08:46:46 --> Database Driver Class Initialized
INFO - 2016-02-03 08:46:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 08:46:47 --> Controller Class Initialized
INFO - 2016-02-03 08:46:47 --> Model Class Initialized
INFO - 2016-02-03 08:46:47 --> Model Class Initialized
INFO - 2016-02-03 08:46:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 08:46:47 --> Pagination Class Initialized
INFO - 2016-02-03 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 08:46:47 --> Final output sent to browser
DEBUG - 2016-02-03 08:46:47 --> Total execution time: 1.1143
INFO - 2016-02-03 09:11:00 --> Config Class Initialized
INFO - 2016-02-03 09:11:00 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:11:00 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:11:00 --> Utf8 Class Initialized
INFO - 2016-02-03 09:11:00 --> URI Class Initialized
INFO - 2016-02-03 09:11:00 --> Router Class Initialized
INFO - 2016-02-03 09:11:00 --> Output Class Initialized
INFO - 2016-02-03 09:11:00 --> Security Class Initialized
DEBUG - 2016-02-03 09:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:11:00 --> Input Class Initialized
INFO - 2016-02-03 09:11:00 --> Language Class Initialized
INFO - 2016-02-03 09:11:00 --> Loader Class Initialized
INFO - 2016-02-03 09:11:00 --> Helper loaded: url_helper
INFO - 2016-02-03 09:11:00 --> Helper loaded: file_helper
INFO - 2016-02-03 09:11:00 --> Helper loaded: date_helper
INFO - 2016-02-03 09:11:00 --> Database Driver Class Initialized
INFO - 2016-02-03 09:11:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:11:01 --> Controller Class Initialized
INFO - 2016-02-03 09:11:01 --> Model Class Initialized
INFO - 2016-02-03 09:11:01 --> Model Class Initialized
INFO - 2016-02-03 09:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:11:01 --> Pagination Class Initialized
INFO - 2016-02-03 09:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\json.php
INFO - 2016-02-03 09:11:01 --> Final output sent to browser
DEBUG - 2016-02-03 09:11:01 --> Total execution time: 1.1134
INFO - 2016-02-03 09:11:44 --> Config Class Initialized
INFO - 2016-02-03 09:11:44 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:11:44 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:11:44 --> Utf8 Class Initialized
INFO - 2016-02-03 09:11:44 --> URI Class Initialized
INFO - 2016-02-03 09:11:44 --> Router Class Initialized
INFO - 2016-02-03 09:11:44 --> Output Class Initialized
INFO - 2016-02-03 09:11:44 --> Security Class Initialized
DEBUG - 2016-02-03 09:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:11:44 --> Input Class Initialized
INFO - 2016-02-03 09:11:44 --> Language Class Initialized
INFO - 2016-02-03 09:11:44 --> Loader Class Initialized
INFO - 2016-02-03 09:11:44 --> Helper loaded: url_helper
INFO - 2016-02-03 09:11:44 --> Helper loaded: file_helper
INFO - 2016-02-03 09:11:44 --> Helper loaded: date_helper
INFO - 2016-02-03 09:11:44 --> Database Driver Class Initialized
INFO - 2016-02-03 09:11:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:11:45 --> Controller Class Initialized
INFO - 2016-02-03 09:11:45 --> Model Class Initialized
INFO - 2016-02-03 09:11:45 --> Model Class Initialized
INFO - 2016-02-03 09:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:11:45 --> Pagination Class Initialized
INFO - 2016-02-03 09:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:11:45 --> Final output sent to browser
DEBUG - 2016-02-03 09:11:45 --> Total execution time: 1.0963
INFO - 2016-02-03 09:12:02 --> Config Class Initialized
INFO - 2016-02-03 09:12:02 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:12:02 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:12:02 --> Utf8 Class Initialized
INFO - 2016-02-03 09:12:02 --> URI Class Initialized
INFO - 2016-02-03 09:12:02 --> Router Class Initialized
INFO - 2016-02-03 09:12:02 --> Output Class Initialized
INFO - 2016-02-03 09:12:02 --> Security Class Initialized
DEBUG - 2016-02-03 09:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:12:02 --> Input Class Initialized
INFO - 2016-02-03 09:12:02 --> Language Class Initialized
INFO - 2016-02-03 09:12:02 --> Loader Class Initialized
INFO - 2016-02-03 09:12:02 --> Helper loaded: url_helper
INFO - 2016-02-03 09:12:02 --> Helper loaded: file_helper
INFO - 2016-02-03 09:12:02 --> Helper loaded: date_helper
INFO - 2016-02-03 09:12:02 --> Database Driver Class Initialized
INFO - 2016-02-03 09:12:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:12:03 --> Controller Class Initialized
INFO - 2016-02-03 09:12:03 --> Model Class Initialized
INFO - 2016-02-03 09:12:03 --> Model Class Initialized
INFO - 2016-02-03 09:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:12:03 --> Pagination Class Initialized
INFO - 2016-02-03 09:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:12:03 --> Final output sent to browser
DEBUG - 2016-02-03 09:12:03 --> Total execution time: 1.1481
INFO - 2016-02-03 09:12:13 --> Config Class Initialized
INFO - 2016-02-03 09:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:12:13 --> Utf8 Class Initialized
INFO - 2016-02-03 09:12:13 --> URI Class Initialized
INFO - 2016-02-03 09:12:13 --> Router Class Initialized
INFO - 2016-02-03 09:12:13 --> Output Class Initialized
INFO - 2016-02-03 09:12:13 --> Security Class Initialized
DEBUG - 2016-02-03 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:12:13 --> Input Class Initialized
INFO - 2016-02-03 09:12:13 --> Language Class Initialized
INFO - 2016-02-03 09:12:13 --> Loader Class Initialized
INFO - 2016-02-03 09:12:13 --> Helper loaded: url_helper
INFO - 2016-02-03 09:12:13 --> Helper loaded: file_helper
INFO - 2016-02-03 09:12:13 --> Helper loaded: date_helper
INFO - 2016-02-03 09:12:13 --> Database Driver Class Initialized
INFO - 2016-02-03 09:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:12:14 --> Controller Class Initialized
INFO - 2016-02-03 09:12:14 --> Model Class Initialized
INFO - 2016-02-03 09:12:14 --> Model Class Initialized
INFO - 2016-02-03 09:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:12:14 --> Pagination Class Initialized
INFO - 2016-02-03 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:12:14 --> Final output sent to browser
DEBUG - 2016-02-03 09:12:14 --> Total execution time: 1.1296
INFO - 2016-02-03 09:12:24 --> Config Class Initialized
INFO - 2016-02-03 09:12:24 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:12:24 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:12:24 --> Utf8 Class Initialized
INFO - 2016-02-03 09:12:24 --> URI Class Initialized
INFO - 2016-02-03 09:12:24 --> Router Class Initialized
INFO - 2016-02-03 09:12:24 --> Output Class Initialized
INFO - 2016-02-03 09:12:24 --> Security Class Initialized
DEBUG - 2016-02-03 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:12:24 --> Input Class Initialized
INFO - 2016-02-03 09:12:24 --> Language Class Initialized
INFO - 2016-02-03 09:12:24 --> Loader Class Initialized
INFO - 2016-02-03 09:12:24 --> Helper loaded: url_helper
INFO - 2016-02-03 09:12:24 --> Helper loaded: file_helper
INFO - 2016-02-03 09:12:24 --> Helper loaded: date_helper
INFO - 2016-02-03 09:12:24 --> Database Driver Class Initialized
INFO - 2016-02-03 09:12:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:12:25 --> Controller Class Initialized
INFO - 2016-02-03 09:12:25 --> Model Class Initialized
INFO - 2016-02-03 09:12:25 --> Model Class Initialized
INFO - 2016-02-03 09:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:12:25 --> Pagination Class Initialized
INFO - 2016-02-03 09:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:12:25 --> Final output sent to browser
DEBUG - 2016-02-03 09:12:25 --> Total execution time: 1.0939
INFO - 2016-02-03 09:12:41 --> Config Class Initialized
INFO - 2016-02-03 09:12:41 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:12:41 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:12:41 --> Utf8 Class Initialized
INFO - 2016-02-03 09:12:41 --> URI Class Initialized
INFO - 2016-02-03 09:12:41 --> Router Class Initialized
INFO - 2016-02-03 09:12:41 --> Output Class Initialized
INFO - 2016-02-03 09:12:41 --> Security Class Initialized
DEBUG - 2016-02-03 09:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:12:41 --> Input Class Initialized
INFO - 2016-02-03 09:12:41 --> Language Class Initialized
INFO - 2016-02-03 09:12:41 --> Loader Class Initialized
INFO - 2016-02-03 09:12:41 --> Helper loaded: url_helper
INFO - 2016-02-03 09:12:41 --> Helper loaded: file_helper
INFO - 2016-02-03 09:12:41 --> Helper loaded: date_helper
INFO - 2016-02-03 09:12:41 --> Database Driver Class Initialized
INFO - 2016-02-03 09:12:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:12:42 --> Controller Class Initialized
INFO - 2016-02-03 09:12:42 --> Model Class Initialized
INFO - 2016-02-03 09:12:42 --> Model Class Initialized
INFO - 2016-02-03 09:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:12:42 --> Pagination Class Initialized
INFO - 2016-02-03 09:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:12:42 --> Final output sent to browser
DEBUG - 2016-02-03 09:12:42 --> Total execution time: 1.0859
INFO - 2016-02-03 09:12:49 --> Config Class Initialized
INFO - 2016-02-03 09:12:49 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:12:49 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:12:49 --> Utf8 Class Initialized
INFO - 2016-02-03 09:12:49 --> URI Class Initialized
INFO - 2016-02-03 09:12:49 --> Router Class Initialized
INFO - 2016-02-03 09:12:49 --> Output Class Initialized
INFO - 2016-02-03 09:12:49 --> Security Class Initialized
DEBUG - 2016-02-03 09:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:12:49 --> Input Class Initialized
INFO - 2016-02-03 09:12:49 --> Language Class Initialized
INFO - 2016-02-03 09:12:49 --> Loader Class Initialized
INFO - 2016-02-03 09:12:49 --> Helper loaded: url_helper
INFO - 2016-02-03 09:12:49 --> Helper loaded: file_helper
INFO - 2016-02-03 09:12:49 --> Helper loaded: date_helper
INFO - 2016-02-03 09:12:49 --> Database Driver Class Initialized
INFO - 2016-02-03 09:12:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:12:50 --> Controller Class Initialized
INFO - 2016-02-03 09:12:50 --> Model Class Initialized
INFO - 2016-02-03 09:12:50 --> Model Class Initialized
INFO - 2016-02-03 09:12:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:12:50 --> Pagination Class Initialized
INFO - 2016-02-03 09:12:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:12:50 --> Final output sent to browser
DEBUG - 2016-02-03 09:12:50 --> Total execution time: 1.1518
INFO - 2016-02-03 09:13:18 --> Config Class Initialized
INFO - 2016-02-03 09:13:18 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:13:18 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:13:18 --> Utf8 Class Initialized
INFO - 2016-02-03 09:13:18 --> URI Class Initialized
INFO - 2016-02-03 09:13:18 --> Router Class Initialized
INFO - 2016-02-03 09:13:18 --> Output Class Initialized
INFO - 2016-02-03 09:13:18 --> Security Class Initialized
DEBUG - 2016-02-03 09:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:13:18 --> Input Class Initialized
INFO - 2016-02-03 09:13:18 --> Language Class Initialized
INFO - 2016-02-03 09:13:18 --> Loader Class Initialized
INFO - 2016-02-03 09:13:18 --> Helper loaded: url_helper
INFO - 2016-02-03 09:13:18 --> Helper loaded: file_helper
INFO - 2016-02-03 09:13:18 --> Helper loaded: date_helper
INFO - 2016-02-03 09:13:18 --> Database Driver Class Initialized
INFO - 2016-02-03 09:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:13:19 --> Controller Class Initialized
INFO - 2016-02-03 09:13:19 --> Model Class Initialized
INFO - 2016-02-03 09:13:19 --> Model Class Initialized
INFO - 2016-02-03 09:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:13:19 --> Pagination Class Initialized
INFO - 2016-02-03 09:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:13:19 --> Final output sent to browser
DEBUG - 2016-02-03 09:13:19 --> Total execution time: 1.1271
INFO - 2016-02-03 09:13:50 --> Config Class Initialized
INFO - 2016-02-03 09:13:50 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:13:50 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:13:50 --> Utf8 Class Initialized
INFO - 2016-02-03 09:13:50 --> URI Class Initialized
INFO - 2016-02-03 09:13:50 --> Router Class Initialized
INFO - 2016-02-03 09:13:50 --> Output Class Initialized
INFO - 2016-02-03 09:13:50 --> Security Class Initialized
DEBUG - 2016-02-03 09:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:13:50 --> Input Class Initialized
INFO - 2016-02-03 09:13:50 --> Language Class Initialized
INFO - 2016-02-03 09:13:50 --> Loader Class Initialized
INFO - 2016-02-03 09:13:50 --> Helper loaded: url_helper
INFO - 2016-02-03 09:13:50 --> Helper loaded: file_helper
INFO - 2016-02-03 09:13:50 --> Helper loaded: date_helper
INFO - 2016-02-03 09:13:50 --> Database Driver Class Initialized
INFO - 2016-02-03 09:13:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:13:51 --> Controller Class Initialized
INFO - 2016-02-03 09:13:51 --> Model Class Initialized
INFO - 2016-02-03 09:13:51 --> Model Class Initialized
INFO - 2016-02-03 09:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:13:51 --> Pagination Class Initialized
INFO - 2016-02-03 09:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:13:51 --> Final output sent to browser
DEBUG - 2016-02-03 09:13:51 --> Total execution time: 1.1049
INFO - 2016-02-03 09:14:18 --> Config Class Initialized
INFO - 2016-02-03 09:14:18 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:18 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:18 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:18 --> URI Class Initialized
INFO - 2016-02-03 09:14:18 --> Router Class Initialized
INFO - 2016-02-03 09:14:18 --> Output Class Initialized
INFO - 2016-02-03 09:14:18 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:18 --> Input Class Initialized
INFO - 2016-02-03 09:14:18 --> Language Class Initialized
INFO - 2016-02-03 09:14:18 --> Loader Class Initialized
INFO - 2016-02-03 09:14:18 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:18 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:18 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:18 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:19 --> Controller Class Initialized
INFO - 2016-02-03 09:14:19 --> Model Class Initialized
INFO - 2016-02-03 09:14:19 --> Model Class Initialized
INFO - 2016-02-03 09:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:19 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:14:19 --> Helper loaded: text_helper
INFO - 2016-02-03 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:14:19 --> Final output sent to browser
DEBUG - 2016-02-03 09:14:19 --> Total execution time: 1.2085
INFO - 2016-02-03 09:14:23 --> Config Class Initialized
INFO - 2016-02-03 09:14:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:23 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:23 --> URI Class Initialized
INFO - 2016-02-03 09:14:23 --> Router Class Initialized
INFO - 2016-02-03 09:14:23 --> Output Class Initialized
INFO - 2016-02-03 09:14:23 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:23 --> Input Class Initialized
INFO - 2016-02-03 09:14:23 --> Language Class Initialized
INFO - 2016-02-03 09:14:23 --> Loader Class Initialized
INFO - 2016-02-03 09:14:23 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:23 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:23 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:23 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:24 --> Controller Class Initialized
INFO - 2016-02-03 09:14:24 --> Model Class Initialized
INFO - 2016-02-03 09:14:24 --> Model Class Initialized
INFO - 2016-02-03 09:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:24 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:24 --> Config Class Initialized
INFO - 2016-02-03 09:14:24 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:24 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:24 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:24 --> URI Class Initialized
INFO - 2016-02-03 09:14:24 --> Router Class Initialized
INFO - 2016-02-03 09:14:24 --> Output Class Initialized
INFO - 2016-02-03 09:14:24 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:24 --> Input Class Initialized
INFO - 2016-02-03 09:14:24 --> Language Class Initialized
INFO - 2016-02-03 09:14:24 --> Loader Class Initialized
INFO - 2016-02-03 09:14:24 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:24 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:24 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:24 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:25 --> Controller Class Initialized
INFO - 2016-02-03 09:14:25 --> Model Class Initialized
INFO - 2016-02-03 09:14:25 --> Model Class Initialized
INFO - 2016-02-03 09:14:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:25 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:14:25 --> Helper loaded: text_helper
INFO - 2016-02-03 09:14:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:14:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:14:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:14:25 --> Final output sent to browser
DEBUG - 2016-02-03 09:14:25 --> Total execution time: 1.1087
INFO - 2016-02-03 09:14:41 --> Config Class Initialized
INFO - 2016-02-03 09:14:41 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:41 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:41 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:41 --> URI Class Initialized
INFO - 2016-02-03 09:14:41 --> Router Class Initialized
INFO - 2016-02-03 09:14:41 --> Output Class Initialized
INFO - 2016-02-03 09:14:41 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:41 --> Input Class Initialized
INFO - 2016-02-03 09:14:41 --> Language Class Initialized
INFO - 2016-02-03 09:14:41 --> Loader Class Initialized
INFO - 2016-02-03 09:14:41 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:41 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:41 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:41 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:42 --> Controller Class Initialized
INFO - 2016-02-03 09:14:42 --> Model Class Initialized
INFO - 2016-02-03 09:14:42 --> Model Class Initialized
INFO - 2016-02-03 09:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:42 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:14:42 --> Helper loaded: text_helper
INFO - 2016-02-03 09:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:14:42 --> Final output sent to browser
DEBUG - 2016-02-03 09:14:42 --> Total execution time: 1.1246
INFO - 2016-02-03 09:14:44 --> Config Class Initialized
INFO - 2016-02-03 09:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:44 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:44 --> URI Class Initialized
INFO - 2016-02-03 09:14:44 --> Router Class Initialized
INFO - 2016-02-03 09:14:44 --> Output Class Initialized
INFO - 2016-02-03 09:14:44 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:44 --> Input Class Initialized
INFO - 2016-02-03 09:14:44 --> Language Class Initialized
INFO - 2016-02-03 09:14:44 --> Loader Class Initialized
INFO - 2016-02-03 09:14:44 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:44 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:44 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:44 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:45 --> Controller Class Initialized
INFO - 2016-02-03 09:14:45 --> Model Class Initialized
INFO - 2016-02-03 09:14:45 --> Model Class Initialized
INFO - 2016-02-03 09:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:45 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:45 --> Config Class Initialized
INFO - 2016-02-03 09:14:45 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:14:45 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:14:45 --> Utf8 Class Initialized
INFO - 2016-02-03 09:14:45 --> URI Class Initialized
INFO - 2016-02-03 09:14:45 --> Router Class Initialized
INFO - 2016-02-03 09:14:45 --> Output Class Initialized
INFO - 2016-02-03 09:14:45 --> Security Class Initialized
DEBUG - 2016-02-03 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:14:45 --> Input Class Initialized
INFO - 2016-02-03 09:14:45 --> Language Class Initialized
INFO - 2016-02-03 09:14:45 --> Loader Class Initialized
INFO - 2016-02-03 09:14:45 --> Helper loaded: url_helper
INFO - 2016-02-03 09:14:45 --> Helper loaded: file_helper
INFO - 2016-02-03 09:14:45 --> Helper loaded: date_helper
INFO - 2016-02-03 09:14:45 --> Database Driver Class Initialized
INFO - 2016-02-03 09:14:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:14:46 --> Controller Class Initialized
INFO - 2016-02-03 09:14:46 --> Model Class Initialized
INFO - 2016-02-03 09:14:46 --> Model Class Initialized
INFO - 2016-02-03 09:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:14:46 --> Pagination Class Initialized
INFO - 2016-02-03 09:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:14:46 --> Helper loaded: text_helper
INFO - 2016-02-03 09:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:14:46 --> Final output sent to browser
DEBUG - 2016-02-03 09:14:46 --> Total execution time: 1.1063
INFO - 2016-02-03 09:16:01 --> Config Class Initialized
INFO - 2016-02-03 09:16:01 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:16:01 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:16:01 --> Utf8 Class Initialized
INFO - 2016-02-03 09:16:01 --> URI Class Initialized
INFO - 2016-02-03 09:16:01 --> Router Class Initialized
INFO - 2016-02-03 09:16:01 --> Output Class Initialized
INFO - 2016-02-03 09:16:01 --> Security Class Initialized
DEBUG - 2016-02-03 09:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:16:01 --> Input Class Initialized
INFO - 2016-02-03 09:16:01 --> Language Class Initialized
INFO - 2016-02-03 09:16:01 --> Loader Class Initialized
INFO - 2016-02-03 09:16:01 --> Helper loaded: url_helper
INFO - 2016-02-03 09:16:01 --> Helper loaded: file_helper
INFO - 2016-02-03 09:16:01 --> Helper loaded: date_helper
INFO - 2016-02-03 09:16:01 --> Database Driver Class Initialized
INFO - 2016-02-03 09:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:16:02 --> Controller Class Initialized
INFO - 2016-02-03 09:16:02 --> Model Class Initialized
INFO - 2016-02-03 09:16:02 --> Model Class Initialized
INFO - 2016-02-03 09:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:16:02 --> Pagination Class Initialized
INFO - 2016-02-03 09:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:16:02 --> Helper loaded: text_helper
INFO - 2016-02-03 09:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:16:02 --> Final output sent to browser
DEBUG - 2016-02-03 09:16:02 --> Total execution time: 1.1707
INFO - 2016-02-03 09:16:44 --> Config Class Initialized
INFO - 2016-02-03 09:16:44 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:16:44 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:16:44 --> Utf8 Class Initialized
INFO - 2016-02-03 09:16:44 --> URI Class Initialized
INFO - 2016-02-03 09:16:44 --> Router Class Initialized
INFO - 2016-02-03 09:16:44 --> Output Class Initialized
INFO - 2016-02-03 09:16:44 --> Security Class Initialized
DEBUG - 2016-02-03 09:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:16:44 --> Input Class Initialized
INFO - 2016-02-03 09:16:44 --> Language Class Initialized
INFO - 2016-02-03 09:16:44 --> Loader Class Initialized
INFO - 2016-02-03 09:16:44 --> Helper loaded: url_helper
INFO - 2016-02-03 09:16:44 --> Helper loaded: file_helper
INFO - 2016-02-03 09:16:44 --> Helper loaded: date_helper
INFO - 2016-02-03 09:16:44 --> Database Driver Class Initialized
INFO - 2016-02-03 09:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:16:45 --> Controller Class Initialized
INFO - 2016-02-03 09:16:45 --> Model Class Initialized
INFO - 2016-02-03 09:16:45 --> Model Class Initialized
INFO - 2016-02-03 09:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:16:45 --> Pagination Class Initialized
INFO - 2016-02-03 09:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:16:45 --> Helper loaded: text_helper
INFO - 2016-02-03 09:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:16:45 --> Final output sent to browser
DEBUG - 2016-02-03 09:16:45 --> Total execution time: 1.2504
INFO - 2016-02-03 09:17:04 --> Config Class Initialized
INFO - 2016-02-03 09:17:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:17:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:17:04 --> Utf8 Class Initialized
INFO - 2016-02-03 09:17:04 --> URI Class Initialized
INFO - 2016-02-03 09:17:04 --> Router Class Initialized
INFO - 2016-02-03 09:17:04 --> Output Class Initialized
INFO - 2016-02-03 09:17:04 --> Security Class Initialized
DEBUG - 2016-02-03 09:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:17:04 --> Input Class Initialized
INFO - 2016-02-03 09:17:04 --> Language Class Initialized
INFO - 2016-02-03 09:17:04 --> Loader Class Initialized
INFO - 2016-02-03 09:17:04 --> Helper loaded: url_helper
INFO - 2016-02-03 09:17:04 --> Helper loaded: file_helper
INFO - 2016-02-03 09:17:04 --> Helper loaded: date_helper
INFO - 2016-02-03 09:17:04 --> Database Driver Class Initialized
INFO - 2016-02-03 09:17:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:17:05 --> Controller Class Initialized
INFO - 2016-02-03 09:17:05 --> Model Class Initialized
INFO - 2016-02-03 09:17:05 --> Model Class Initialized
INFO - 2016-02-03 09:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:17:05 --> Pagination Class Initialized
INFO - 2016-02-03 09:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:17:05 --> Helper loaded: text_helper
INFO - 2016-02-03 09:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:17:05 --> Final output sent to browser
DEBUG - 2016-02-03 09:17:05 --> Total execution time: 1.1410
INFO - 2016-02-03 09:17:58 --> Config Class Initialized
INFO - 2016-02-03 09:17:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:17:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:17:58 --> Utf8 Class Initialized
INFO - 2016-02-03 09:17:58 --> URI Class Initialized
INFO - 2016-02-03 09:17:58 --> Router Class Initialized
INFO - 2016-02-03 09:17:58 --> Output Class Initialized
INFO - 2016-02-03 09:17:58 --> Security Class Initialized
DEBUG - 2016-02-03 09:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:17:58 --> Input Class Initialized
INFO - 2016-02-03 09:17:58 --> Language Class Initialized
INFO - 2016-02-03 09:17:58 --> Loader Class Initialized
INFO - 2016-02-03 09:17:58 --> Helper loaded: url_helper
INFO - 2016-02-03 09:17:58 --> Helper loaded: file_helper
INFO - 2016-02-03 09:17:58 --> Helper loaded: date_helper
INFO - 2016-02-03 09:17:58 --> Database Driver Class Initialized
INFO - 2016-02-03 09:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:17:59 --> Controller Class Initialized
INFO - 2016-02-03 09:17:59 --> Model Class Initialized
INFO - 2016-02-03 09:17:59 --> Model Class Initialized
INFO - 2016-02-03 09:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:17:59 --> Pagination Class Initialized
INFO - 2016-02-03 09:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:17:59 --> Helper loaded: text_helper
INFO - 2016-02-03 09:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:17:59 --> Final output sent to browser
DEBUG - 2016-02-03 09:17:59 --> Total execution time: 1.1945
INFO - 2016-02-03 09:18:47 --> Config Class Initialized
INFO - 2016-02-03 09:18:47 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:18:47 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:18:47 --> Utf8 Class Initialized
INFO - 2016-02-03 09:18:47 --> URI Class Initialized
INFO - 2016-02-03 09:18:47 --> Router Class Initialized
INFO - 2016-02-03 09:18:47 --> Output Class Initialized
INFO - 2016-02-03 09:18:47 --> Security Class Initialized
DEBUG - 2016-02-03 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:18:47 --> Input Class Initialized
INFO - 2016-02-03 09:18:47 --> Language Class Initialized
INFO - 2016-02-03 09:18:47 --> Loader Class Initialized
INFO - 2016-02-03 09:18:47 --> Helper loaded: url_helper
INFO - 2016-02-03 09:18:47 --> Helper loaded: file_helper
INFO - 2016-02-03 09:18:47 --> Helper loaded: date_helper
INFO - 2016-02-03 09:18:47 --> Database Driver Class Initialized
INFO - 2016-02-03 09:18:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:18:48 --> Controller Class Initialized
INFO - 2016-02-03 09:18:48 --> Model Class Initialized
INFO - 2016-02-03 09:18:48 --> Model Class Initialized
INFO - 2016-02-03 09:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:18:48 --> Pagination Class Initialized
INFO - 2016-02-03 09:18:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:18:48 --> Helper loaded: text_helper
INFO - 2016-02-03 09:18:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:18:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:18:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:18:48 --> Final output sent to browser
DEBUG - 2016-02-03 09:18:48 --> Total execution time: 1.1413
INFO - 2016-02-03 09:18:49 --> Config Class Initialized
INFO - 2016-02-03 09:18:49 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:18:49 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:18:49 --> Utf8 Class Initialized
INFO - 2016-02-03 09:18:49 --> URI Class Initialized
DEBUG - 2016-02-03 09:18:49 --> No URI present. Default controller set.
INFO - 2016-02-03 09:18:49 --> Router Class Initialized
INFO - 2016-02-03 09:18:49 --> Output Class Initialized
INFO - 2016-02-03 09:18:49 --> Security Class Initialized
DEBUG - 2016-02-03 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:18:49 --> Input Class Initialized
INFO - 2016-02-03 09:18:49 --> Language Class Initialized
INFO - 2016-02-03 09:18:49 --> Loader Class Initialized
INFO - 2016-02-03 09:18:49 --> Helper loaded: url_helper
INFO - 2016-02-03 09:18:49 --> Helper loaded: file_helper
INFO - 2016-02-03 09:18:49 --> Helper loaded: date_helper
INFO - 2016-02-03 09:18:49 --> Database Driver Class Initialized
INFO - 2016-02-03 09:18:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:18:50 --> Controller Class Initialized
INFO - 2016-02-03 09:18:50 --> Model Class Initialized
INFO - 2016-02-03 09:18:50 --> Model Class Initialized
INFO - 2016-02-03 09:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:18:50 --> Pagination Class Initialized
INFO - 2016-02-03 09:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 09:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:18:50 --> Final output sent to browser
DEBUG - 2016-02-03 09:18:50 --> Total execution time: 1.0901
INFO - 2016-02-03 09:18:51 --> Config Class Initialized
INFO - 2016-02-03 09:18:51 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:18:51 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:18:51 --> Utf8 Class Initialized
INFO - 2016-02-03 09:18:51 --> URI Class Initialized
INFO - 2016-02-03 09:18:51 --> Router Class Initialized
INFO - 2016-02-03 09:18:51 --> Output Class Initialized
INFO - 2016-02-03 09:18:51 --> Security Class Initialized
DEBUG - 2016-02-03 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:18:51 --> Input Class Initialized
INFO - 2016-02-03 09:18:51 --> Language Class Initialized
INFO - 2016-02-03 09:18:51 --> Loader Class Initialized
INFO - 2016-02-03 09:18:51 --> Helper loaded: url_helper
INFO - 2016-02-03 09:18:51 --> Helper loaded: file_helper
INFO - 2016-02-03 09:18:51 --> Helper loaded: date_helper
INFO - 2016-02-03 09:18:51 --> Database Driver Class Initialized
INFO - 2016-02-03 09:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:18:53 --> Controller Class Initialized
INFO - 2016-02-03 09:18:53 --> Model Class Initialized
INFO - 2016-02-03 09:18:53 --> Model Class Initialized
INFO - 2016-02-03 09:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:18:53 --> Pagination Class Initialized
INFO - 2016-02-03 09:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:18:53 --> Helper loaded: text_helper
INFO - 2016-02-03 09:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:18:53 --> Final output sent to browser
DEBUG - 2016-02-03 09:18:53 --> Total execution time: 1.1939
INFO - 2016-02-03 09:18:57 --> Config Class Initialized
INFO - 2016-02-03 09:18:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:18:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:18:57 --> Utf8 Class Initialized
INFO - 2016-02-03 09:18:57 --> URI Class Initialized
DEBUG - 2016-02-03 09:18:57 --> No URI present. Default controller set.
INFO - 2016-02-03 09:18:57 --> Router Class Initialized
INFO - 2016-02-03 09:18:57 --> Output Class Initialized
INFO - 2016-02-03 09:18:57 --> Security Class Initialized
DEBUG - 2016-02-03 09:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:18:57 --> Input Class Initialized
INFO - 2016-02-03 09:18:57 --> Language Class Initialized
INFO - 2016-02-03 09:18:57 --> Loader Class Initialized
INFO - 2016-02-03 09:18:57 --> Helper loaded: url_helper
INFO - 2016-02-03 09:18:57 --> Helper loaded: file_helper
INFO - 2016-02-03 09:18:57 --> Helper loaded: date_helper
INFO - 2016-02-03 09:18:57 --> Database Driver Class Initialized
INFO - 2016-02-03 09:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:18:58 --> Controller Class Initialized
INFO - 2016-02-03 09:18:58 --> Model Class Initialized
INFO - 2016-02-03 09:18:58 --> Model Class Initialized
INFO - 2016-02-03 09:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:18:58 --> Pagination Class Initialized
INFO - 2016-02-03 09:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 09:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:18:58 --> Final output sent to browser
DEBUG - 2016-02-03 09:18:58 --> Total execution time: 1.0994
INFO - 2016-02-03 09:19:15 --> Config Class Initialized
INFO - 2016-02-03 09:19:15 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:19:15 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:19:15 --> Utf8 Class Initialized
INFO - 2016-02-03 09:19:15 --> URI Class Initialized
DEBUG - 2016-02-03 09:19:15 --> No URI present. Default controller set.
INFO - 2016-02-03 09:19:15 --> Router Class Initialized
INFO - 2016-02-03 09:19:15 --> Output Class Initialized
INFO - 2016-02-03 09:19:15 --> Security Class Initialized
DEBUG - 2016-02-03 09:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:19:15 --> Input Class Initialized
INFO - 2016-02-03 09:19:15 --> Language Class Initialized
INFO - 2016-02-03 09:19:15 --> Loader Class Initialized
INFO - 2016-02-03 09:19:15 --> Helper loaded: url_helper
INFO - 2016-02-03 09:19:15 --> Helper loaded: file_helper
INFO - 2016-02-03 09:19:15 --> Helper loaded: date_helper
INFO - 2016-02-03 09:19:15 --> Database Driver Class Initialized
INFO - 2016-02-03 09:19:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:19:16 --> Controller Class Initialized
INFO - 2016-02-03 09:19:16 --> Model Class Initialized
INFO - 2016-02-03 09:19:16 --> Model Class Initialized
INFO - 2016-02-03 09:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:19:16 --> Pagination Class Initialized
INFO - 2016-02-03 09:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 09:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:19:16 --> Final output sent to browser
DEBUG - 2016-02-03 09:19:16 --> Total execution time: 1.1315
INFO - 2016-02-03 09:19:17 --> Config Class Initialized
INFO - 2016-02-03 09:19:17 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:19:17 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:19:17 --> Utf8 Class Initialized
INFO - 2016-02-03 09:19:17 --> URI Class Initialized
INFO - 2016-02-03 09:19:17 --> Router Class Initialized
INFO - 2016-02-03 09:19:17 --> Output Class Initialized
INFO - 2016-02-03 09:19:17 --> Security Class Initialized
DEBUG - 2016-02-03 09:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:19:17 --> Input Class Initialized
INFO - 2016-02-03 09:19:17 --> Language Class Initialized
INFO - 2016-02-03 09:19:17 --> Loader Class Initialized
INFO - 2016-02-03 09:19:17 --> Helper loaded: url_helper
INFO - 2016-02-03 09:19:17 --> Helper loaded: file_helper
INFO - 2016-02-03 09:19:17 --> Helper loaded: date_helper
INFO - 2016-02-03 09:19:17 --> Database Driver Class Initialized
INFO - 2016-02-03 09:19:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:19:18 --> Controller Class Initialized
INFO - 2016-02-03 09:19:18 --> Model Class Initialized
INFO - 2016-02-03 09:19:18 --> Model Class Initialized
INFO - 2016-02-03 09:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:19:18 --> Pagination Class Initialized
INFO - 2016-02-03 09:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:19:18 --> Helper loaded: text_helper
INFO - 2016-02-03 09:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:19:18 --> Final output sent to browser
DEBUG - 2016-02-03 09:19:18 --> Total execution time: 1.1447
INFO - 2016-02-03 09:19:30 --> Config Class Initialized
INFO - 2016-02-03 09:19:30 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:19:30 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:19:30 --> Utf8 Class Initialized
INFO - 2016-02-03 09:19:30 --> URI Class Initialized
INFO - 2016-02-03 09:19:30 --> Router Class Initialized
INFO - 2016-02-03 09:19:30 --> Output Class Initialized
INFO - 2016-02-03 09:19:30 --> Security Class Initialized
DEBUG - 2016-02-03 09:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:19:30 --> Input Class Initialized
INFO - 2016-02-03 09:19:30 --> Language Class Initialized
INFO - 2016-02-03 09:19:30 --> Loader Class Initialized
INFO - 2016-02-03 09:19:30 --> Helper loaded: url_helper
INFO - 2016-02-03 09:19:30 --> Helper loaded: file_helper
INFO - 2016-02-03 09:19:30 --> Helper loaded: date_helper
INFO - 2016-02-03 09:19:30 --> Database Driver Class Initialized
INFO - 2016-02-03 09:19:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:19:31 --> Controller Class Initialized
INFO - 2016-02-03 09:19:31 --> Model Class Initialized
INFO - 2016-02-03 09:19:31 --> Model Class Initialized
INFO - 2016-02-03 09:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:19:31 --> Pagination Class Initialized
INFO - 2016-02-03 09:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:19:31 --> Helper loaded: text_helper
INFO - 2016-02-03 09:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:19:31 --> Final output sent to browser
DEBUG - 2016-02-03 09:19:31 --> Total execution time: 1.1942
INFO - 2016-02-03 09:20:14 --> Config Class Initialized
INFO - 2016-02-03 09:20:14 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:20:14 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:20:14 --> Utf8 Class Initialized
INFO - 2016-02-03 09:20:14 --> URI Class Initialized
INFO - 2016-02-03 09:20:14 --> Router Class Initialized
INFO - 2016-02-03 09:20:14 --> Output Class Initialized
INFO - 2016-02-03 09:20:14 --> Security Class Initialized
DEBUG - 2016-02-03 09:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:20:15 --> Input Class Initialized
INFO - 2016-02-03 09:20:15 --> Language Class Initialized
INFO - 2016-02-03 09:20:15 --> Loader Class Initialized
INFO - 2016-02-03 09:20:15 --> Helper loaded: url_helper
INFO - 2016-02-03 09:20:15 --> Helper loaded: file_helper
INFO - 2016-02-03 09:20:15 --> Helper loaded: date_helper
INFO - 2016-02-03 09:20:15 --> Database Driver Class Initialized
INFO - 2016-02-03 09:20:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:20:16 --> Controller Class Initialized
INFO - 2016-02-03 09:20:16 --> Model Class Initialized
INFO - 2016-02-03 09:20:16 --> Model Class Initialized
INFO - 2016-02-03 09:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:20:16 --> Pagination Class Initialized
INFO - 2016-02-03 09:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 09:20:16 --> Helper loaded: text_helper
INFO - 2016-02-03 09:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 09:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 09:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 09:20:16 --> Final output sent to browser
DEBUG - 2016-02-03 09:20:16 --> Total execution time: 1.2459
INFO - 2016-02-03 09:20:50 --> Config Class Initialized
INFO - 2016-02-03 09:20:50 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:20:50 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:20:50 --> Utf8 Class Initialized
INFO - 2016-02-03 09:20:50 --> URI Class Initialized
INFO - 2016-02-03 09:20:50 --> Router Class Initialized
INFO - 2016-02-03 09:20:50 --> Output Class Initialized
INFO - 2016-02-03 09:20:50 --> Security Class Initialized
DEBUG - 2016-02-03 09:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:20:50 --> Input Class Initialized
INFO - 2016-02-03 09:20:50 --> Language Class Initialized
INFO - 2016-02-03 09:20:50 --> Loader Class Initialized
INFO - 2016-02-03 09:20:50 --> Helper loaded: url_helper
INFO - 2016-02-03 09:20:50 --> Helper loaded: file_helper
INFO - 2016-02-03 09:20:50 --> Helper loaded: date_helper
INFO - 2016-02-03 09:20:50 --> Database Driver Class Initialized
INFO - 2016-02-03 09:20:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:20:51 --> Controller Class Initialized
INFO - 2016-02-03 09:20:51 --> Model Class Initialized
INFO - 2016-02-03 09:20:51 --> Model Class Initialized
INFO - 2016-02-03 09:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:20:51 --> Pagination Class Initialized
INFO - 2016-02-03 09:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:20:51 --> Final output sent to browser
DEBUG - 2016-02-03 09:20:51 --> Total execution time: 1.0821
INFO - 2016-02-03 09:20:58 --> Config Class Initialized
INFO - 2016-02-03 09:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 09:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 09:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 09:20:58 --> URI Class Initialized
INFO - 2016-02-03 09:20:58 --> Router Class Initialized
INFO - 2016-02-03 09:20:58 --> Output Class Initialized
INFO - 2016-02-03 09:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 09:20:58 --> Input Class Initialized
INFO - 2016-02-03 09:20:58 --> Language Class Initialized
INFO - 2016-02-03 09:20:58 --> Loader Class Initialized
INFO - 2016-02-03 09:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 09:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 09:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 09:20:58 --> Database Driver Class Initialized
INFO - 2016-02-03 09:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 09:20:59 --> Controller Class Initialized
INFO - 2016-02-03 09:20:59 --> Model Class Initialized
INFO - 2016-02-03 09:20:59 --> Model Class Initialized
INFO - 2016-02-03 09:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 09:20:59 --> Pagination Class Initialized
INFO - 2016-02-03 09:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 09:20:59 --> Final output sent to browser
DEBUG - 2016-02-03 09:20:59 --> Total execution time: 1.0892
INFO - 2016-02-03 10:16:07 --> Config Class Initialized
INFO - 2016-02-03 10:16:07 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:16:07 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:16:07 --> Utf8 Class Initialized
INFO - 2016-02-03 10:16:07 --> URI Class Initialized
INFO - 2016-02-03 10:16:07 --> Router Class Initialized
INFO - 2016-02-03 10:16:07 --> Output Class Initialized
INFO - 2016-02-03 10:16:07 --> Security Class Initialized
DEBUG - 2016-02-03 10:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:16:07 --> Input Class Initialized
INFO - 2016-02-03 10:16:07 --> Language Class Initialized
INFO - 2016-02-03 10:16:07 --> Loader Class Initialized
INFO - 2016-02-03 10:16:07 --> Helper loaded: url_helper
INFO - 2016-02-03 10:16:07 --> Helper loaded: file_helper
INFO - 2016-02-03 10:16:07 --> Helper loaded: date_helper
INFO - 2016-02-03 10:16:07 --> Database Driver Class Initialized
INFO - 2016-02-03 10:16:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:16:08 --> Controller Class Initialized
INFO - 2016-02-03 10:16:08 --> Model Class Initialized
INFO - 2016-02-03 10:16:08 --> Model Class Initialized
INFO - 2016-02-03 10:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:16:08 --> Pagination Class Initialized
INFO - 2016-02-03 10:16:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 10:16:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 10:16:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 10:16:08 --> Final output sent to browser
DEBUG - 2016-02-03 10:16:08 --> Total execution time: 1.0816
INFO - 2016-02-03 10:16:11 --> Config Class Initialized
INFO - 2016-02-03 10:16:11 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:16:11 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:16:11 --> Utf8 Class Initialized
INFO - 2016-02-03 10:16:11 --> URI Class Initialized
INFO - 2016-02-03 10:16:11 --> Router Class Initialized
INFO - 2016-02-03 10:16:11 --> Output Class Initialized
INFO - 2016-02-03 10:16:11 --> Security Class Initialized
DEBUG - 2016-02-03 10:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:16:11 --> Input Class Initialized
INFO - 2016-02-03 10:16:11 --> Language Class Initialized
INFO - 2016-02-03 10:16:11 --> Loader Class Initialized
INFO - 2016-02-03 10:16:11 --> Helper loaded: url_helper
INFO - 2016-02-03 10:16:11 --> Helper loaded: file_helper
INFO - 2016-02-03 10:16:11 --> Helper loaded: date_helper
INFO - 2016-02-03 10:16:11 --> Database Driver Class Initialized
INFO - 2016-02-03 10:16:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:16:12 --> Controller Class Initialized
INFO - 2016-02-03 10:16:12 --> Model Class Initialized
INFO - 2016-02-03 10:16:12 --> Model Class Initialized
INFO - 2016-02-03 10:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:16:12 --> Pagination Class Initialized
INFO - 2016-02-03 10:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 10:16:12 --> Final output sent to browser
DEBUG - 2016-02-03 10:16:12 --> Total execution time: 1.1202
INFO - 2016-02-03 10:17:20 --> Config Class Initialized
INFO - 2016-02-03 10:17:20 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:17:20 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:17:20 --> Utf8 Class Initialized
INFO - 2016-02-03 10:17:20 --> URI Class Initialized
INFO - 2016-02-03 10:17:20 --> Router Class Initialized
INFO - 2016-02-03 10:17:20 --> Output Class Initialized
INFO - 2016-02-03 10:17:20 --> Security Class Initialized
DEBUG - 2016-02-03 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:17:20 --> Input Class Initialized
INFO - 2016-02-03 10:17:20 --> Language Class Initialized
INFO - 2016-02-03 10:17:20 --> Loader Class Initialized
INFO - 2016-02-03 10:17:20 --> Helper loaded: url_helper
INFO - 2016-02-03 10:17:20 --> Helper loaded: file_helper
INFO - 2016-02-03 10:17:20 --> Helper loaded: date_helper
INFO - 2016-02-03 10:17:20 --> Database Driver Class Initialized
INFO - 2016-02-03 10:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:17:21 --> Controller Class Initialized
INFO - 2016-02-03 10:17:21 --> Model Class Initialized
INFO - 2016-02-03 10:17:21 --> Model Class Initialized
INFO - 2016-02-03 10:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:17:21 --> Pagination Class Initialized
INFO - 2016-02-03 10:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 10:17:21 --> Final output sent to browser
DEBUG - 2016-02-03 10:17:21 --> Total execution time: 1.0922
INFO - 2016-02-03 10:20:37 --> Config Class Initialized
INFO - 2016-02-03 10:20:37 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:20:37 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:20:37 --> Utf8 Class Initialized
INFO - 2016-02-03 10:20:37 --> URI Class Initialized
INFO - 2016-02-03 10:20:37 --> Router Class Initialized
INFO - 2016-02-03 10:20:37 --> Output Class Initialized
INFO - 2016-02-03 10:20:37 --> Security Class Initialized
DEBUG - 2016-02-03 10:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:20:37 --> Input Class Initialized
INFO - 2016-02-03 10:20:37 --> Language Class Initialized
INFO - 2016-02-03 10:20:37 --> Loader Class Initialized
INFO - 2016-02-03 10:20:37 --> Helper loaded: url_helper
INFO - 2016-02-03 10:20:37 --> Helper loaded: file_helper
INFO - 2016-02-03 10:20:37 --> Helper loaded: date_helper
INFO - 2016-02-03 10:20:37 --> Database Driver Class Initialized
INFO - 2016-02-03 10:20:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:20:38 --> Controller Class Initialized
INFO - 2016-02-03 10:20:38 --> Model Class Initialized
INFO - 2016-02-03 10:20:38 --> Model Class Initialized
INFO - 2016-02-03 10:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:20:38 --> Pagination Class Initialized
INFO - 2016-02-03 10:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\test.php
INFO - 2016-02-03 10:20:38 --> Final output sent to browser
DEBUG - 2016-02-03 10:20:38 --> Total execution time: 1.1607
INFO - 2016-02-03 10:22:06 --> Config Class Initialized
INFO - 2016-02-03 10:22:06 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:22:06 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:22:06 --> Utf8 Class Initialized
INFO - 2016-02-03 10:22:06 --> URI Class Initialized
INFO - 2016-02-03 10:22:06 --> Router Class Initialized
INFO - 2016-02-03 10:22:06 --> Output Class Initialized
INFO - 2016-02-03 10:22:06 --> Security Class Initialized
DEBUG - 2016-02-03 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:22:06 --> Input Class Initialized
INFO - 2016-02-03 10:22:06 --> Language Class Initialized
INFO - 2016-02-03 10:22:06 --> Loader Class Initialized
INFO - 2016-02-03 10:22:06 --> Helper loaded: url_helper
INFO - 2016-02-03 10:22:06 --> Helper loaded: file_helper
INFO - 2016-02-03 10:22:06 --> Helper loaded: date_helper
INFO - 2016-02-03 10:22:06 --> Database Driver Class Initialized
INFO - 2016-02-03 10:22:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:22:07 --> Controller Class Initialized
INFO - 2016-02-03 10:22:07 --> Model Class Initialized
INFO - 2016-02-03 10:22:07 --> Model Class Initialized
INFO - 2016-02-03 10:22:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:22:07 --> Pagination Class Initialized
INFO - 2016-02-03 10:22:07 --> Final output sent to browser
DEBUG - 2016-02-03 10:22:07 --> Total execution time: 1.1096
INFO - 2016-02-03 10:22:49 --> Config Class Initialized
INFO - 2016-02-03 10:22:49 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:22:49 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:22:49 --> Utf8 Class Initialized
INFO - 2016-02-03 10:22:49 --> URI Class Initialized
INFO - 2016-02-03 10:22:49 --> Router Class Initialized
INFO - 2016-02-03 10:22:49 --> Output Class Initialized
INFO - 2016-02-03 10:22:49 --> Security Class Initialized
DEBUG - 2016-02-03 10:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:22:49 --> Input Class Initialized
INFO - 2016-02-03 10:22:49 --> Language Class Initialized
INFO - 2016-02-03 10:22:49 --> Loader Class Initialized
INFO - 2016-02-03 10:22:49 --> Helper loaded: url_helper
INFO - 2016-02-03 10:22:49 --> Helper loaded: file_helper
INFO - 2016-02-03 10:22:49 --> Helper loaded: date_helper
INFO - 2016-02-03 10:22:49 --> Database Driver Class Initialized
INFO - 2016-02-03 10:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:22:50 --> Controller Class Initialized
INFO - 2016-02-03 10:22:50 --> Model Class Initialized
INFO - 2016-02-03 10:22:50 --> Model Class Initialized
INFO - 2016-02-03 10:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:22:50 --> Pagination Class Initialized
INFO - 2016-02-03 10:22:50 --> Final output sent to browser
DEBUG - 2016-02-03 10:22:50 --> Total execution time: 1.1465
INFO - 2016-02-03 10:23:32 --> Config Class Initialized
INFO - 2016-02-03 10:23:32 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:23:32 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:23:32 --> Utf8 Class Initialized
INFO - 2016-02-03 10:23:32 --> URI Class Initialized
INFO - 2016-02-03 10:23:32 --> Router Class Initialized
INFO - 2016-02-03 10:23:32 --> Output Class Initialized
INFO - 2016-02-03 10:23:32 --> Security Class Initialized
DEBUG - 2016-02-03 10:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:23:32 --> Input Class Initialized
INFO - 2016-02-03 10:23:32 --> Language Class Initialized
INFO - 2016-02-03 10:23:32 --> Loader Class Initialized
INFO - 2016-02-03 10:23:32 --> Helper loaded: url_helper
INFO - 2016-02-03 10:23:32 --> Helper loaded: file_helper
INFO - 2016-02-03 10:23:32 --> Helper loaded: date_helper
INFO - 2016-02-03 10:23:32 --> Database Driver Class Initialized
INFO - 2016-02-03 10:23:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:23:33 --> Controller Class Initialized
INFO - 2016-02-03 10:23:33 --> Model Class Initialized
INFO - 2016-02-03 10:23:33 --> Model Class Initialized
INFO - 2016-02-03 10:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:23:33 --> Pagination Class Initialized
INFO - 2016-02-03 10:23:33 --> Final output sent to browser
DEBUG - 2016-02-03 10:23:33 --> Total execution time: 1.1016
INFO - 2016-02-03 10:24:52 --> Config Class Initialized
INFO - 2016-02-03 10:24:52 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:24:52 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:24:52 --> Utf8 Class Initialized
INFO - 2016-02-03 10:24:52 --> URI Class Initialized
INFO - 2016-02-03 10:24:52 --> Router Class Initialized
INFO - 2016-02-03 10:24:52 --> Output Class Initialized
INFO - 2016-02-03 10:24:52 --> Security Class Initialized
DEBUG - 2016-02-03 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:24:52 --> Input Class Initialized
INFO - 2016-02-03 10:24:52 --> Language Class Initialized
INFO - 2016-02-03 10:24:52 --> Loader Class Initialized
INFO - 2016-02-03 10:24:52 --> Helper loaded: url_helper
INFO - 2016-02-03 10:24:52 --> Helper loaded: file_helper
INFO - 2016-02-03 10:24:52 --> Helper loaded: date_helper
INFO - 2016-02-03 10:24:52 --> Database Driver Class Initialized
INFO - 2016-02-03 10:24:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:24:53 --> Controller Class Initialized
INFO - 2016-02-03 10:24:53 --> Model Class Initialized
INFO - 2016-02-03 10:24:53 --> Model Class Initialized
INFO - 2016-02-03 10:24:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:24:53 --> Pagination Class Initialized
INFO - 2016-02-03 10:24:53 --> Final output sent to browser
DEBUG - 2016-02-03 10:24:53 --> Total execution time: 1.1179
INFO - 2016-02-03 10:25:37 --> Config Class Initialized
INFO - 2016-02-03 10:25:37 --> Hooks Class Initialized
DEBUG - 2016-02-03 10:25:37 --> UTF-8 Support Enabled
INFO - 2016-02-03 10:25:37 --> Utf8 Class Initialized
INFO - 2016-02-03 10:25:37 --> URI Class Initialized
INFO - 2016-02-03 10:25:37 --> Router Class Initialized
INFO - 2016-02-03 10:25:37 --> Output Class Initialized
INFO - 2016-02-03 10:25:37 --> Security Class Initialized
DEBUG - 2016-02-03 10:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 10:25:37 --> Input Class Initialized
INFO - 2016-02-03 10:25:37 --> Language Class Initialized
INFO - 2016-02-03 10:25:37 --> Loader Class Initialized
INFO - 2016-02-03 10:25:37 --> Helper loaded: url_helper
INFO - 2016-02-03 10:25:37 --> Helper loaded: file_helper
INFO - 2016-02-03 10:25:37 --> Helper loaded: date_helper
INFO - 2016-02-03 10:25:37 --> Database Driver Class Initialized
INFO - 2016-02-03 10:25:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 10:25:38 --> Controller Class Initialized
INFO - 2016-02-03 10:25:38 --> Model Class Initialized
INFO - 2016-02-03 10:25:38 --> Model Class Initialized
INFO - 2016-02-03 10:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 10:25:38 --> Pagination Class Initialized
INFO - 2016-02-03 10:25:38 --> Final output sent to browser
DEBUG - 2016-02-03 10:25:38 --> Total execution time: 1.1288
INFO - 2016-02-03 12:03:50 --> Config Class Initialized
INFO - 2016-02-03 12:03:50 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:03:50 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:03:50 --> Utf8 Class Initialized
INFO - 2016-02-03 12:03:50 --> URI Class Initialized
DEBUG - 2016-02-03 12:03:50 --> No URI present. Default controller set.
INFO - 2016-02-03 12:03:50 --> Router Class Initialized
INFO - 2016-02-03 12:03:50 --> Output Class Initialized
INFO - 2016-02-03 12:03:50 --> Security Class Initialized
DEBUG - 2016-02-03 12:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:03:50 --> Input Class Initialized
INFO - 2016-02-03 12:03:50 --> Language Class Initialized
INFO - 2016-02-03 12:03:50 --> Loader Class Initialized
INFO - 2016-02-03 12:03:50 --> Helper loaded: url_helper
INFO - 2016-02-03 12:03:50 --> Helper loaded: file_helper
INFO - 2016-02-03 12:03:50 --> Helper loaded: date_helper
INFO - 2016-02-03 12:03:50 --> Database Driver Class Initialized
INFO - 2016-02-03 12:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:03:51 --> Controller Class Initialized
INFO - 2016-02-03 12:03:51 --> Model Class Initialized
INFO - 2016-02-03 12:03:51 --> Model Class Initialized
INFO - 2016-02-03 12:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:03:51 --> Pagination Class Initialized
INFO - 2016-02-03 12:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:03:51 --> Final output sent to browser
DEBUG - 2016-02-03 12:03:51 --> Total execution time: 1.1344
INFO - 2016-02-03 12:03:56 --> Config Class Initialized
INFO - 2016-02-03 12:03:56 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:03:56 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:03:56 --> Utf8 Class Initialized
INFO - 2016-02-03 12:03:56 --> URI Class Initialized
DEBUG - 2016-02-03 12:03:56 --> No URI present. Default controller set.
INFO - 2016-02-03 12:03:56 --> Router Class Initialized
INFO - 2016-02-03 12:03:56 --> Output Class Initialized
INFO - 2016-02-03 12:03:56 --> Security Class Initialized
DEBUG - 2016-02-03 12:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:03:56 --> Input Class Initialized
INFO - 2016-02-03 12:03:56 --> Language Class Initialized
INFO - 2016-02-03 12:03:56 --> Loader Class Initialized
INFO - 2016-02-03 12:03:56 --> Helper loaded: url_helper
INFO - 2016-02-03 12:03:56 --> Helper loaded: file_helper
INFO - 2016-02-03 12:03:56 --> Helper loaded: date_helper
INFO - 2016-02-03 12:03:56 --> Database Driver Class Initialized
INFO - 2016-02-03 12:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:03:57 --> Controller Class Initialized
INFO - 2016-02-03 12:03:57 --> Model Class Initialized
INFO - 2016-02-03 12:03:57 --> Model Class Initialized
INFO - 2016-02-03 12:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:03:57 --> Pagination Class Initialized
INFO - 2016-02-03 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:03:57 --> Final output sent to browser
DEBUG - 2016-02-03 12:03:57 --> Total execution time: 1.1194
INFO - 2016-02-03 12:11:59 --> Config Class Initialized
INFO - 2016-02-03 12:11:59 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:11:59 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:11:59 --> Utf8 Class Initialized
INFO - 2016-02-03 12:11:59 --> URI Class Initialized
DEBUG - 2016-02-03 12:11:59 --> No URI present. Default controller set.
INFO - 2016-02-03 12:11:59 --> Router Class Initialized
INFO - 2016-02-03 12:11:59 --> Output Class Initialized
INFO - 2016-02-03 12:11:59 --> Security Class Initialized
DEBUG - 2016-02-03 12:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:11:59 --> Input Class Initialized
INFO - 2016-02-03 12:11:59 --> Language Class Initialized
INFO - 2016-02-03 12:11:59 --> Loader Class Initialized
INFO - 2016-02-03 12:11:59 --> Helper loaded: url_helper
INFO - 2016-02-03 12:11:59 --> Helper loaded: file_helper
INFO - 2016-02-03 12:11:59 --> Helper loaded: date_helper
INFO - 2016-02-03 12:11:59 --> Database Driver Class Initialized
INFO - 2016-02-03 12:12:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:12:00 --> Controller Class Initialized
INFO - 2016-02-03 12:12:00 --> Model Class Initialized
INFO - 2016-02-03 12:12:00 --> Model Class Initialized
INFO - 2016-02-03 12:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:12:00 --> Pagination Class Initialized
INFO - 2016-02-03 12:12:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:12:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:12:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:12:00 --> Final output sent to browser
DEBUG - 2016-02-03 12:12:00 --> Total execution time: 1.1102
INFO - 2016-02-03 12:15:45 --> Config Class Initialized
INFO - 2016-02-03 12:15:45 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:15:45 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:15:45 --> Utf8 Class Initialized
INFO - 2016-02-03 12:15:45 --> URI Class Initialized
DEBUG - 2016-02-03 12:15:45 --> No URI present. Default controller set.
INFO - 2016-02-03 12:15:45 --> Router Class Initialized
INFO - 2016-02-03 12:15:45 --> Output Class Initialized
INFO - 2016-02-03 12:15:45 --> Security Class Initialized
DEBUG - 2016-02-03 12:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:15:45 --> Input Class Initialized
INFO - 2016-02-03 12:15:45 --> Language Class Initialized
INFO - 2016-02-03 12:15:45 --> Loader Class Initialized
INFO - 2016-02-03 12:15:45 --> Helper loaded: url_helper
INFO - 2016-02-03 12:15:45 --> Helper loaded: file_helper
INFO - 2016-02-03 12:15:45 --> Helper loaded: date_helper
INFO - 2016-02-03 12:15:45 --> Helper loaded: form_helper
INFO - 2016-02-03 12:17:26 --> Config Class Initialized
INFO - 2016-02-03 12:17:26 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:17:26 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:17:26 --> Utf8 Class Initialized
INFO - 2016-02-03 12:17:26 --> URI Class Initialized
DEBUG - 2016-02-03 12:17:26 --> No URI present. Default controller set.
INFO - 2016-02-03 12:17:26 --> Router Class Initialized
INFO - 2016-02-03 12:17:26 --> Output Class Initialized
INFO - 2016-02-03 12:17:26 --> Security Class Initialized
DEBUG - 2016-02-03 12:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:17:26 --> Input Class Initialized
INFO - 2016-02-03 12:17:26 --> Language Class Initialized
INFO - 2016-02-03 12:17:26 --> Loader Class Initialized
INFO - 2016-02-03 12:17:26 --> Helper loaded: url_helper
INFO - 2016-02-03 12:17:26 --> Helper loaded: file_helper
INFO - 2016-02-03 12:17:26 --> Helper loaded: date_helper
INFO - 2016-02-03 12:17:26 --> Helper loaded: form_helper
INFO - 2016-02-03 12:19:10 --> Config Class Initialized
INFO - 2016-02-03 12:19:10 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:19:10 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:19:10 --> Utf8 Class Initialized
INFO - 2016-02-03 12:19:10 --> URI Class Initialized
DEBUG - 2016-02-03 12:19:10 --> No URI present. Default controller set.
INFO - 2016-02-03 12:19:10 --> Router Class Initialized
INFO - 2016-02-03 12:19:10 --> Output Class Initialized
INFO - 2016-02-03 12:19:10 --> Security Class Initialized
DEBUG - 2016-02-03 12:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:19:10 --> Input Class Initialized
INFO - 2016-02-03 12:19:10 --> Language Class Initialized
INFO - 2016-02-03 12:19:10 --> Loader Class Initialized
INFO - 2016-02-03 12:19:10 --> Helper loaded: url_helper
INFO - 2016-02-03 12:19:10 --> Helper loaded: file_helper
INFO - 2016-02-03 12:19:10 --> Helper loaded: date_helper
INFO - 2016-02-03 12:19:10 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:57 --> Config Class Initialized
INFO - 2016-02-03 12:20:57 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:57 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:57 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:57 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:57 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:57 --> Router Class Initialized
INFO - 2016-02-03 12:20:57 --> Output Class Initialized
INFO - 2016-02-03 12:20:57 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:57 --> Input Class Initialized
INFO - 2016-02-03 12:20:57 --> Language Class Initialized
INFO - 2016-02-03 12:20:57 --> Loader Class Initialized
INFO - 2016-02-03 12:20:57 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:57 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:57 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:57 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:58 --> Router Class Initialized
INFO - 2016-02-03 12:20:58 --> Output Class Initialized
INFO - 2016-02-03 12:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:58 --> Input Class Initialized
INFO - 2016-02-03 12:20:58 --> Language Class Initialized
INFO - 2016-02-03 12:20:58 --> Loader Class Initialized
INFO - 2016-02-03 12:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:58 --> Router Class Initialized
INFO - 2016-02-03 12:20:58 --> Output Class Initialized
INFO - 2016-02-03 12:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:58 --> Input Class Initialized
INFO - 2016-02-03 12:20:58 --> Language Class Initialized
INFO - 2016-02-03 12:20:58 --> Loader Class Initialized
INFO - 2016-02-03 12:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:58 --> Router Class Initialized
INFO - 2016-02-03 12:20:58 --> Output Class Initialized
INFO - 2016-02-03 12:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:58 --> Input Class Initialized
INFO - 2016-02-03 12:20:58 --> Language Class Initialized
INFO - 2016-02-03 12:20:58 --> Loader Class Initialized
INFO - 2016-02-03 12:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:58 --> Router Class Initialized
INFO - 2016-02-03 12:20:58 --> Output Class Initialized
INFO - 2016-02-03 12:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:58 --> Input Class Initialized
INFO - 2016-02-03 12:20:58 --> Language Class Initialized
INFO - 2016-02-03 12:20:58 --> Loader Class Initialized
INFO - 2016-02-03 12:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:58 --> Router Class Initialized
INFO - 2016-02-03 12:20:58 --> Output Class Initialized
INFO - 2016-02-03 12:20:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:58 --> Input Class Initialized
INFO - 2016-02-03 12:20:58 --> Language Class Initialized
INFO - 2016-02-03 12:20:58 --> Loader Class Initialized
INFO - 2016-02-03 12:20:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:58 --> Config Class Initialized
INFO - 2016-02-03 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:59 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:59 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:59 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:59 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:59 --> Router Class Initialized
INFO - 2016-02-03 12:20:59 --> Output Class Initialized
INFO - 2016-02-03 12:20:59 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:59 --> Input Class Initialized
INFO - 2016-02-03 12:20:59 --> Language Class Initialized
INFO - 2016-02-03 12:20:59 --> Loader Class Initialized
INFO - 2016-02-03 12:20:59 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:59 --> Config Class Initialized
INFO - 2016-02-03 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:59 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:59 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:59 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:59 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:59 --> Router Class Initialized
INFO - 2016-02-03 12:20:59 --> Output Class Initialized
INFO - 2016-02-03 12:20:59 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:59 --> Input Class Initialized
INFO - 2016-02-03 12:20:59 --> Language Class Initialized
INFO - 2016-02-03 12:20:59 --> Loader Class Initialized
INFO - 2016-02-03 12:20:59 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: form_helper
INFO - 2016-02-03 12:20:59 --> Config Class Initialized
INFO - 2016-02-03 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:20:59 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:20:59 --> Utf8 Class Initialized
INFO - 2016-02-03 12:20:59 --> URI Class Initialized
DEBUG - 2016-02-03 12:20:59 --> No URI present. Default controller set.
INFO - 2016-02-03 12:20:59 --> Router Class Initialized
INFO - 2016-02-03 12:20:59 --> Output Class Initialized
INFO - 2016-02-03 12:20:59 --> Security Class Initialized
DEBUG - 2016-02-03 12:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:20:59 --> Input Class Initialized
INFO - 2016-02-03 12:20:59 --> Language Class Initialized
INFO - 2016-02-03 12:20:59 --> Loader Class Initialized
INFO - 2016-02-03 12:20:59 --> Helper loaded: url_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: file_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: date_helper
INFO - 2016-02-03 12:20:59 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:01 --> Config Class Initialized
INFO - 2016-02-03 12:22:01 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:01 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:01 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:01 --> URI Class Initialized
DEBUG - 2016-02-03 12:22:01 --> No URI present. Default controller set.
INFO - 2016-02-03 12:22:01 --> Router Class Initialized
INFO - 2016-02-03 12:22:01 --> Output Class Initialized
INFO - 2016-02-03 12:22:01 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:01 --> Input Class Initialized
INFO - 2016-02-03 12:22:01 --> Language Class Initialized
INFO - 2016-02-03 12:22:01 --> Loader Class Initialized
INFO - 2016-02-03 12:22:01 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:01 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:01 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:01 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:03 --> Config Class Initialized
INFO - 2016-02-03 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:03 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:03 --> URI Class Initialized
DEBUG - 2016-02-03 12:22:03 --> No URI present. Default controller set.
INFO - 2016-02-03 12:22:03 --> Router Class Initialized
INFO - 2016-02-03 12:22:03 --> Output Class Initialized
INFO - 2016-02-03 12:22:03 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:03 --> Input Class Initialized
INFO - 2016-02-03 12:22:03 --> Language Class Initialized
INFO - 2016-02-03 12:22:03 --> Loader Class Initialized
INFO - 2016-02-03 12:22:03 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:03 --> Config Class Initialized
INFO - 2016-02-03 12:22:03 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:03 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:03 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:03 --> URI Class Initialized
DEBUG - 2016-02-03 12:22:03 --> No URI present. Default controller set.
INFO - 2016-02-03 12:22:03 --> Router Class Initialized
INFO - 2016-02-03 12:22:03 --> Output Class Initialized
INFO - 2016-02-03 12:22:03 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:03 --> Input Class Initialized
INFO - 2016-02-03 12:22:03 --> Language Class Initialized
INFO - 2016-02-03 12:22:03 --> Loader Class Initialized
INFO - 2016-02-03 12:22:03 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:03 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:07 --> Config Class Initialized
INFO - 2016-02-03 12:22:07 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:07 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:07 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:07 --> URI Class Initialized
DEBUG - 2016-02-03 12:22:07 --> No URI present. Default controller set.
INFO - 2016-02-03 12:22:07 --> Router Class Initialized
INFO - 2016-02-03 12:22:07 --> Output Class Initialized
INFO - 2016-02-03 12:22:07 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:07 --> Input Class Initialized
INFO - 2016-02-03 12:22:07 --> Language Class Initialized
INFO - 2016-02-03 12:22:07 --> Loader Class Initialized
INFO - 2016-02-03 12:22:07 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:07 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:07 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:07 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:33 --> Config Class Initialized
INFO - 2016-02-03 12:22:33 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:33 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:33 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:33 --> URI Class Initialized
DEBUG - 2016-02-03 12:22:33 --> No URI present. Default controller set.
INFO - 2016-02-03 12:22:33 --> Router Class Initialized
INFO - 2016-02-03 12:22:33 --> Output Class Initialized
INFO - 2016-02-03 12:22:33 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:33 --> Input Class Initialized
INFO - 2016-02-03 12:22:33 --> Language Class Initialized
INFO - 2016-02-03 12:22:33 --> Loader Class Initialized
INFO - 2016-02-03 12:22:33 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:33 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:33 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:33 --> Helper loaded: form_helper
INFO - 2016-02-03 12:22:40 --> Config Class Initialized
INFO - 2016-02-03 12:22:40 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:22:40 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:22:40 --> Utf8 Class Initialized
INFO - 2016-02-03 12:22:40 --> URI Class Initialized
INFO - 2016-02-03 12:22:40 --> Router Class Initialized
INFO - 2016-02-03 12:22:40 --> Output Class Initialized
INFO - 2016-02-03 12:22:40 --> Security Class Initialized
DEBUG - 2016-02-03 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:22:40 --> Input Class Initialized
INFO - 2016-02-03 12:22:40 --> Language Class Initialized
INFO - 2016-02-03 12:22:40 --> Loader Class Initialized
INFO - 2016-02-03 12:22:40 --> Helper loaded: url_helper
INFO - 2016-02-03 12:22:40 --> Helper loaded: file_helper
INFO - 2016-02-03 12:22:40 --> Helper loaded: date_helper
INFO - 2016-02-03 12:22:40 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:28 --> Config Class Initialized
INFO - 2016-02-03 12:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:28 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:28 --> URI Class Initialized
DEBUG - 2016-02-03 12:27:28 --> No URI present. Default controller set.
INFO - 2016-02-03 12:27:28 --> Router Class Initialized
INFO - 2016-02-03 12:27:28 --> Output Class Initialized
INFO - 2016-02-03 12:27:28 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:28 --> Input Class Initialized
INFO - 2016-02-03 12:27:28 --> Language Class Initialized
INFO - 2016-02-03 12:27:28 --> Loader Class Initialized
INFO - 2016-02-03 12:27:28 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:28 --> Config Class Initialized
INFO - 2016-02-03 12:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:28 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:28 --> URI Class Initialized
DEBUG - 2016-02-03 12:27:28 --> No URI present. Default controller set.
INFO - 2016-02-03 12:27:28 --> Router Class Initialized
INFO - 2016-02-03 12:27:28 --> Output Class Initialized
INFO - 2016-02-03 12:27:28 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:28 --> Input Class Initialized
INFO - 2016-02-03 12:27:28 --> Language Class Initialized
INFO - 2016-02-03 12:27:28 --> Loader Class Initialized
INFO - 2016-02-03 12:27:28 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:28 --> Config Class Initialized
INFO - 2016-02-03 12:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:28 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:28 --> URI Class Initialized
DEBUG - 2016-02-03 12:27:28 --> No URI present. Default controller set.
INFO - 2016-02-03 12:27:28 --> Router Class Initialized
INFO - 2016-02-03 12:27:28 --> Output Class Initialized
INFO - 2016-02-03 12:27:28 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:28 --> Input Class Initialized
INFO - 2016-02-03 12:27:28 --> Language Class Initialized
INFO - 2016-02-03 12:27:28 --> Loader Class Initialized
INFO - 2016-02-03 12:27:28 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:28 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:28 --> Config Class Initialized
INFO - 2016-02-03 12:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:28 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:28 --> URI Class Initialized
DEBUG - 2016-02-03 12:27:29 --> No URI present. Default controller set.
INFO - 2016-02-03 12:27:29 --> Router Class Initialized
INFO - 2016-02-03 12:27:29 --> Output Class Initialized
INFO - 2016-02-03 12:27:29 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:29 --> Input Class Initialized
INFO - 2016-02-03 12:27:29 --> Language Class Initialized
INFO - 2016-02-03 12:27:29 --> Loader Class Initialized
INFO - 2016-02-03 12:27:29 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:29 --> Config Class Initialized
INFO - 2016-02-03 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:29 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:29 --> URI Class Initialized
DEBUG - 2016-02-03 12:27:29 --> No URI present. Default controller set.
INFO - 2016-02-03 12:27:29 --> Router Class Initialized
INFO - 2016-02-03 12:27:29 --> Output Class Initialized
INFO - 2016-02-03 12:27:29 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:29 --> Input Class Initialized
INFO - 2016-02-03 12:27:29 --> Language Class Initialized
INFO - 2016-02-03 12:27:29 --> Loader Class Initialized
INFO - 2016-02-03 12:27:29 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:29 --> Config Class Initialized
INFO - 2016-02-03 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:29 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:29 --> URI Class Initialized
INFO - 2016-02-03 12:27:29 --> Router Class Initialized
INFO - 2016-02-03 12:27:29 --> Output Class Initialized
INFO - 2016-02-03 12:27:29 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:29 --> Input Class Initialized
INFO - 2016-02-03 12:27:29 --> Language Class Initialized
INFO - 2016-02-03 12:27:29 --> Loader Class Initialized
INFO - 2016-02-03 12:27:29 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:29 --> Config Class Initialized
INFO - 2016-02-03 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:29 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:29 --> URI Class Initialized
INFO - 2016-02-03 12:27:29 --> Router Class Initialized
INFO - 2016-02-03 12:27:29 --> Output Class Initialized
INFO - 2016-02-03 12:27:29 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:29 --> Input Class Initialized
INFO - 2016-02-03 12:27:29 --> Language Class Initialized
INFO - 2016-02-03 12:27:29 --> Loader Class Initialized
INFO - 2016-02-03 12:27:29 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:29 --> Config Class Initialized
INFO - 2016-02-03 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:29 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:29 --> URI Class Initialized
INFO - 2016-02-03 12:27:29 --> Router Class Initialized
INFO - 2016-02-03 12:27:29 --> Output Class Initialized
INFO - 2016-02-03 12:27:29 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:29 --> Input Class Initialized
INFO - 2016-02-03 12:27:29 --> Language Class Initialized
INFO - 2016-02-03 12:27:29 --> Loader Class Initialized
INFO - 2016-02-03 12:27:29 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:29 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:30 --> Config Class Initialized
INFO - 2016-02-03 12:27:30 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:30 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:30 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:30 --> URI Class Initialized
INFO - 2016-02-03 12:27:30 --> Router Class Initialized
INFO - 2016-02-03 12:27:30 --> Output Class Initialized
INFO - 2016-02-03 12:27:30 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:30 --> Input Class Initialized
INFO - 2016-02-03 12:27:30 --> Language Class Initialized
INFO - 2016-02-03 12:27:30 --> Loader Class Initialized
INFO - 2016-02-03 12:27:30 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:30 --> Config Class Initialized
INFO - 2016-02-03 12:27:30 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:30 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:30 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:30 --> URI Class Initialized
INFO - 2016-02-03 12:27:30 --> Router Class Initialized
INFO - 2016-02-03 12:27:30 --> Output Class Initialized
INFO - 2016-02-03 12:27:30 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:30 --> Input Class Initialized
INFO - 2016-02-03 12:27:30 --> Language Class Initialized
INFO - 2016-02-03 12:27:30 --> Loader Class Initialized
INFO - 2016-02-03 12:27:30 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:30 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:31 --> Config Class Initialized
INFO - 2016-02-03 12:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:31 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:31 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:31 --> URI Class Initialized
INFO - 2016-02-03 12:27:31 --> Router Class Initialized
INFO - 2016-02-03 12:27:31 --> Output Class Initialized
INFO - 2016-02-03 12:27:31 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:31 --> Input Class Initialized
INFO - 2016-02-03 12:27:31 --> Language Class Initialized
INFO - 2016-02-03 12:27:31 --> Loader Class Initialized
INFO - 2016-02-03 12:27:31 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:31 --> Config Class Initialized
INFO - 2016-02-03 12:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:31 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:31 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:31 --> URI Class Initialized
INFO - 2016-02-03 12:27:31 --> Router Class Initialized
INFO - 2016-02-03 12:27:31 --> Output Class Initialized
INFO - 2016-02-03 12:27:31 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:31 --> Input Class Initialized
INFO - 2016-02-03 12:27:31 --> Language Class Initialized
INFO - 2016-02-03 12:27:31 --> Loader Class Initialized
INFO - 2016-02-03 12:27:31 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: form_helper
INFO - 2016-02-03 12:27:31 --> Config Class Initialized
INFO - 2016-02-03 12:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:27:31 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:27:31 --> Utf8 Class Initialized
INFO - 2016-02-03 12:27:31 --> URI Class Initialized
INFO - 2016-02-03 12:27:31 --> Router Class Initialized
INFO - 2016-02-03 12:27:31 --> Output Class Initialized
INFO - 2016-02-03 12:27:31 --> Security Class Initialized
DEBUG - 2016-02-03 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:27:31 --> Input Class Initialized
INFO - 2016-02-03 12:27:31 --> Language Class Initialized
INFO - 2016-02-03 12:27:31 --> Loader Class Initialized
INFO - 2016-02-03 12:27:31 --> Helper loaded: url_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: file_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: date_helper
INFO - 2016-02-03 12:27:31 --> Helper loaded: form_helper
INFO - 2016-02-03 12:32:43 --> Config Class Initialized
INFO - 2016-02-03 12:32:43 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:32:43 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:32:43 --> Utf8 Class Initialized
INFO - 2016-02-03 12:32:43 --> URI Class Initialized
DEBUG - 2016-02-03 12:32:43 --> No URI present. Default controller set.
INFO - 2016-02-03 12:32:43 --> Router Class Initialized
INFO - 2016-02-03 12:32:43 --> Output Class Initialized
INFO - 2016-02-03 12:32:43 --> Security Class Initialized
DEBUG - 2016-02-03 12:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:32:43 --> Input Class Initialized
INFO - 2016-02-03 12:32:43 --> Language Class Initialized
INFO - 2016-02-03 12:32:43 --> Loader Class Initialized
INFO - 2016-02-03 12:32:43 --> Helper loaded: url_helper
INFO - 2016-02-03 12:32:43 --> Helper loaded: file_helper
INFO - 2016-02-03 12:32:43 --> Helper loaded: date_helper
INFO - 2016-02-03 12:32:43 --> Helper loaded: form_helper
INFO - 2016-02-03 12:32:53 --> Config Class Initialized
INFO - 2016-02-03 12:32:53 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:32:53 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:32:53 --> Utf8 Class Initialized
INFO - 2016-02-03 12:32:53 --> URI Class Initialized
DEBUG - 2016-02-03 12:32:53 --> No URI present. Default controller set.
INFO - 2016-02-03 12:32:53 --> Router Class Initialized
INFO - 2016-02-03 12:32:53 --> Output Class Initialized
INFO - 2016-02-03 12:32:53 --> Security Class Initialized
DEBUG - 2016-02-03 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:32:53 --> Input Class Initialized
INFO - 2016-02-03 12:32:53 --> Language Class Initialized
INFO - 2016-02-03 12:32:53 --> Loader Class Initialized
INFO - 2016-02-03 12:32:53 --> Helper loaded: url_helper
INFO - 2016-02-03 12:32:53 --> Helper loaded: file_helper
INFO - 2016-02-03 12:32:53 --> Helper loaded: date_helper
INFO - 2016-02-03 12:32:53 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:21 --> Config Class Initialized
INFO - 2016-02-03 12:35:21 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:21 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:21 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:21 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:21 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:21 --> Router Class Initialized
INFO - 2016-02-03 12:35:21 --> Output Class Initialized
INFO - 2016-02-03 12:35:21 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:21 --> Input Class Initialized
INFO - 2016-02-03 12:35:21 --> Language Class Initialized
INFO - 2016-02-03 12:35:21 --> Loader Class Initialized
INFO - 2016-02-03 12:35:21 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:21 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:21 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:21 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:23 --> Input Class Initialized
INFO - 2016-02-03 12:35:23 --> Language Class Initialized
INFO - 2016-02-03 12:35:23 --> Loader Class Initialized
INFO - 2016-02-03 12:35:23 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:23 --> Input Class Initialized
INFO - 2016-02-03 12:35:23 --> Language Class Initialized
INFO - 2016-02-03 12:35:23 --> Loader Class Initialized
INFO - 2016-02-03 12:35:23 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:23 --> Input Class Initialized
INFO - 2016-02-03 12:35:23 --> Language Class Initialized
INFO - 2016-02-03 12:35:23 --> Loader Class Initialized
INFO - 2016-02-03 12:35:23 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:23 --> Input Class Initialized
INFO - 2016-02-03 12:35:23 --> Language Class Initialized
INFO - 2016-02-03 12:35:23 --> Loader Class Initialized
INFO - 2016-02-03 12:35:23 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:23 --> Input Class Initialized
INFO - 2016-02-03 12:35:23 --> Language Class Initialized
INFO - 2016-02-03 12:35:23 --> Loader Class Initialized
INFO - 2016-02-03 12:35:23 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:23 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:23 --> Config Class Initialized
INFO - 2016-02-03 12:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:23 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:23 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:23 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:23 --> Router Class Initialized
INFO - 2016-02-03 12:35:23 --> Output Class Initialized
INFO - 2016-02-03 12:35:23 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:24 --> Input Class Initialized
INFO - 2016-02-03 12:35:24 --> Language Class Initialized
INFO - 2016-02-03 12:35:24 --> Loader Class Initialized
INFO - 2016-02-03 12:35:24 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:24 --> Config Class Initialized
INFO - 2016-02-03 12:35:24 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:24 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:24 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:24 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:24 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:24 --> Router Class Initialized
INFO - 2016-02-03 12:35:24 --> Output Class Initialized
INFO - 2016-02-03 12:35:24 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:24 --> Input Class Initialized
INFO - 2016-02-03 12:35:24 --> Language Class Initialized
INFO - 2016-02-03 12:35:24 --> Loader Class Initialized
INFO - 2016-02-03 12:35:24 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:24 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:28 --> Config Class Initialized
INFO - 2016-02-03 12:35:28 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:28 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:28 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:28 --> URI Class Initialized
INFO - 2016-02-03 12:35:28 --> Router Class Initialized
INFO - 2016-02-03 12:35:28 --> Output Class Initialized
INFO - 2016-02-03 12:35:28 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:28 --> Input Class Initialized
INFO - 2016-02-03 12:35:28 --> Language Class Initialized
INFO - 2016-02-03 12:35:28 --> Loader Class Initialized
INFO - 2016-02-03 12:35:28 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:28 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:28 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:28 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:54 --> Config Class Initialized
INFO - 2016-02-03 12:35:54 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:54 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:54 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:54 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:54 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:54 --> Router Class Initialized
INFO - 2016-02-03 12:35:54 --> Output Class Initialized
INFO - 2016-02-03 12:35:54 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:54 --> Input Class Initialized
INFO - 2016-02-03 12:35:54 --> Language Class Initialized
INFO - 2016-02-03 12:35:54 --> Loader Class Initialized
INFO - 2016-02-03 12:35:54 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:54 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:54 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:54 --> Helper loaded: form_helper
INFO - 2016-02-03 12:35:58 --> Config Class Initialized
INFO - 2016-02-03 12:35:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:35:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:35:58 --> Utf8 Class Initialized
INFO - 2016-02-03 12:35:58 --> URI Class Initialized
DEBUG - 2016-02-03 12:35:58 --> No URI present. Default controller set.
INFO - 2016-02-03 12:35:58 --> Router Class Initialized
INFO - 2016-02-03 12:35:58 --> Output Class Initialized
INFO - 2016-02-03 12:35:58 --> Security Class Initialized
DEBUG - 2016-02-03 12:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:35:58 --> Input Class Initialized
INFO - 2016-02-03 12:35:58 --> Language Class Initialized
INFO - 2016-02-03 12:35:58 --> Loader Class Initialized
INFO - 2016-02-03 12:35:58 --> Helper loaded: url_helper
INFO - 2016-02-03 12:35:58 --> Helper loaded: file_helper
INFO - 2016-02-03 12:35:58 --> Helper loaded: date_helper
INFO - 2016-02-03 12:35:58 --> Helper loaded: form_helper
INFO - 2016-02-03 12:36:06 --> Config Class Initialized
INFO - 2016-02-03 12:36:06 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:36:06 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:36:06 --> Utf8 Class Initialized
INFO - 2016-02-03 12:36:06 --> URI Class Initialized
INFO - 2016-02-03 12:36:06 --> Router Class Initialized
INFO - 2016-02-03 12:36:06 --> Output Class Initialized
INFO - 2016-02-03 12:36:06 --> Security Class Initialized
DEBUG - 2016-02-03 12:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:36:06 --> Input Class Initialized
INFO - 2016-02-03 12:36:06 --> Language Class Initialized
INFO - 2016-02-03 12:36:06 --> Loader Class Initialized
INFO - 2016-02-03 12:36:06 --> Helper loaded: url_helper
INFO - 2016-02-03 12:36:06 --> Helper loaded: file_helper
INFO - 2016-02-03 12:36:06 --> Helper loaded: date_helper
INFO - 2016-02-03 12:36:06 --> Helper loaded: form_helper
INFO - 2016-02-03 12:36:32 --> Config Class Initialized
INFO - 2016-02-03 12:36:32 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:36:32 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:36:32 --> Utf8 Class Initialized
INFO - 2016-02-03 12:36:32 --> URI Class Initialized
DEBUG - 2016-02-03 12:36:32 --> No URI present. Default controller set.
INFO - 2016-02-03 12:36:32 --> Router Class Initialized
INFO - 2016-02-03 12:36:32 --> Output Class Initialized
INFO - 2016-02-03 12:36:32 --> Security Class Initialized
DEBUG - 2016-02-03 12:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:36:32 --> Input Class Initialized
INFO - 2016-02-03 12:36:32 --> Language Class Initialized
INFO - 2016-02-03 12:36:32 --> Loader Class Initialized
INFO - 2016-02-03 12:36:32 --> Helper loaded: url_helper
INFO - 2016-02-03 12:36:32 --> Helper loaded: file_helper
INFO - 2016-02-03 12:36:32 --> Helper loaded: date_helper
INFO - 2016-02-03 12:36:32 --> Helper loaded: form_helper
INFO - 2016-02-03 12:36:37 --> Config Class Initialized
INFO - 2016-02-03 12:36:37 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:36:37 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:36:37 --> Utf8 Class Initialized
INFO - 2016-02-03 12:36:37 --> URI Class Initialized
DEBUG - 2016-02-03 12:36:37 --> No URI present. Default controller set.
INFO - 2016-02-03 12:36:37 --> Router Class Initialized
INFO - 2016-02-03 12:36:37 --> Output Class Initialized
INFO - 2016-02-03 12:36:37 --> Security Class Initialized
DEBUG - 2016-02-03 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:36:37 --> Input Class Initialized
INFO - 2016-02-03 12:36:37 --> Language Class Initialized
INFO - 2016-02-03 12:36:37 --> Loader Class Initialized
INFO - 2016-02-03 12:36:37 --> Helper loaded: url_helper
INFO - 2016-02-03 12:36:37 --> Helper loaded: file_helper
INFO - 2016-02-03 12:36:37 --> Helper loaded: date_helper
INFO - 2016-02-03 12:36:37 --> Helper loaded: form_helper
INFO - 2016-02-03 12:36:42 --> Config Class Initialized
INFO - 2016-02-03 12:36:42 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:36:42 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:36:42 --> Utf8 Class Initialized
INFO - 2016-02-03 12:36:42 --> URI Class Initialized
INFO - 2016-02-03 12:36:42 --> Router Class Initialized
INFO - 2016-02-03 12:36:42 --> Output Class Initialized
INFO - 2016-02-03 12:36:42 --> Security Class Initialized
DEBUG - 2016-02-03 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:36:42 --> Input Class Initialized
INFO - 2016-02-03 12:36:42 --> Language Class Initialized
INFO - 2016-02-03 12:36:42 --> Loader Class Initialized
INFO - 2016-02-03 12:36:42 --> Helper loaded: url_helper
INFO - 2016-02-03 12:36:42 --> Helper loaded: file_helper
INFO - 2016-02-03 12:36:42 --> Helper loaded: date_helper
INFO - 2016-02-03 12:36:42 --> Helper loaded: form_helper
INFO - 2016-02-03 12:40:32 --> Config Class Initialized
INFO - 2016-02-03 12:40:33 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:40:33 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:40:33 --> Utf8 Class Initialized
INFO - 2016-02-03 12:40:33 --> URI Class Initialized
DEBUG - 2016-02-03 12:40:33 --> No URI present. Default controller set.
INFO - 2016-02-03 12:40:33 --> Router Class Initialized
INFO - 2016-02-03 12:40:33 --> Output Class Initialized
INFO - 2016-02-03 12:40:33 --> Security Class Initialized
DEBUG - 2016-02-03 12:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:40:33 --> Input Class Initialized
INFO - 2016-02-03 12:40:33 --> Language Class Initialized
INFO - 2016-02-03 12:40:33 --> Loader Class Initialized
INFO - 2016-02-03 12:40:33 --> Helper loaded: url_helper
INFO - 2016-02-03 12:40:33 --> Helper loaded: file_helper
INFO - 2016-02-03 12:40:33 --> Helper loaded: date_helper
INFO - 2016-02-03 12:40:33 --> Database Driver Class Initialized
INFO - 2016-02-03 12:40:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:40:34 --> Controller Class Initialized
INFO - 2016-02-03 12:40:34 --> Model Class Initialized
INFO - 2016-02-03 12:40:34 --> Model Class Initialized
INFO - 2016-02-03 12:40:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:40:34 --> Pagination Class Initialized
INFO - 2016-02-03 12:40:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:40:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:40:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:40:34 --> Final output sent to browser
DEBUG - 2016-02-03 12:40:34 --> Total execution time: 1.2021
INFO - 2016-02-03 12:40:42 --> Config Class Initialized
INFO - 2016-02-03 12:40:42 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:40:42 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:40:42 --> Utf8 Class Initialized
INFO - 2016-02-03 12:40:42 --> URI Class Initialized
DEBUG - 2016-02-03 12:40:42 --> No URI present. Default controller set.
INFO - 2016-02-03 12:40:42 --> Router Class Initialized
INFO - 2016-02-03 12:40:42 --> Output Class Initialized
INFO - 2016-02-03 12:40:42 --> Security Class Initialized
DEBUG - 2016-02-03 12:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:40:42 --> Input Class Initialized
INFO - 2016-02-03 12:40:42 --> Language Class Initialized
INFO - 2016-02-03 12:40:42 --> Loader Class Initialized
INFO - 2016-02-03 12:40:42 --> Helper loaded: url_helper
INFO - 2016-02-03 12:40:42 --> Helper loaded: file_helper
INFO - 2016-02-03 12:40:42 --> Helper loaded: date_helper
INFO - 2016-02-03 12:40:42 --> Database Driver Class Initialized
INFO - 2016-02-03 12:40:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:40:43 --> Controller Class Initialized
INFO - 2016-02-03 12:40:43 --> Model Class Initialized
INFO - 2016-02-03 12:40:43 --> Model Class Initialized
INFO - 2016-02-03 12:40:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:40:43 --> Pagination Class Initialized
INFO - 2016-02-03 12:40:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:40:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:40:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:40:43 --> Final output sent to browser
DEBUG - 2016-02-03 12:40:43 --> Total execution time: 1.1351
INFO - 2016-02-03 12:41:05 --> Config Class Initialized
INFO - 2016-02-03 12:41:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:41:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:41:05 --> Utf8 Class Initialized
INFO - 2016-02-03 12:41:05 --> URI Class Initialized
INFO - 2016-02-03 12:41:05 --> Router Class Initialized
INFO - 2016-02-03 12:41:05 --> Output Class Initialized
INFO - 2016-02-03 12:41:05 --> Security Class Initialized
DEBUG - 2016-02-03 12:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:41:05 --> Input Class Initialized
INFO - 2016-02-03 12:41:05 --> Language Class Initialized
INFO - 2016-02-03 12:41:05 --> Loader Class Initialized
INFO - 2016-02-03 12:41:05 --> Helper loaded: url_helper
INFO - 2016-02-03 12:41:05 --> Helper loaded: file_helper
INFO - 2016-02-03 12:41:05 --> Helper loaded: date_helper
INFO - 2016-02-03 12:41:05 --> Database Driver Class Initialized
INFO - 2016-02-03 12:41:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:41:06 --> Controller Class Initialized
INFO - 2016-02-03 12:41:06 --> Model Class Initialized
INFO - 2016-02-03 12:41:06 --> Model Class Initialized
INFO - 2016-02-03 12:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:41:06 --> Pagination Class Initialized
INFO - 2016-02-03 12:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:41:06 --> Helper loaded: text_helper
INFO - 2016-02-03 12:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:41:06 --> Final output sent to browser
DEBUG - 2016-02-03 12:41:06 --> Total execution time: 1.2187
INFO - 2016-02-03 12:42:19 --> Config Class Initialized
INFO - 2016-02-03 12:42:19 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:42:19 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:42:19 --> Utf8 Class Initialized
INFO - 2016-02-03 12:42:19 --> URI Class Initialized
INFO - 2016-02-03 12:42:19 --> Router Class Initialized
INFO - 2016-02-03 12:42:19 --> Output Class Initialized
INFO - 2016-02-03 12:42:19 --> Security Class Initialized
DEBUG - 2016-02-03 12:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:42:19 --> Input Class Initialized
INFO - 2016-02-03 12:42:19 --> Language Class Initialized
INFO - 2016-02-03 12:42:19 --> Loader Class Initialized
INFO - 2016-02-03 12:42:19 --> Helper loaded: url_helper
INFO - 2016-02-03 12:42:19 --> Helper loaded: file_helper
INFO - 2016-02-03 12:42:19 --> Helper loaded: date_helper
INFO - 2016-02-03 12:42:19 --> Database Driver Class Initialized
INFO - 2016-02-03 12:42:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:42:20 --> Controller Class Initialized
INFO - 2016-02-03 12:42:20 --> Model Class Initialized
INFO - 2016-02-03 12:42:20 --> Model Class Initialized
INFO - 2016-02-03 12:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:42:20 --> Pagination Class Initialized
INFO - 2016-02-03 12:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:42:20 --> Helper loaded: text_helper
INFO - 2016-02-03 12:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:42:20 --> Final output sent to browser
DEBUG - 2016-02-03 12:42:20 --> Total execution time: 1.2070
INFO - 2016-02-03 12:42:47 --> Config Class Initialized
INFO - 2016-02-03 12:42:47 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:42:47 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:42:47 --> Utf8 Class Initialized
INFO - 2016-02-03 12:42:47 --> URI Class Initialized
INFO - 2016-02-03 12:42:47 --> Router Class Initialized
INFO - 2016-02-03 12:42:47 --> Output Class Initialized
INFO - 2016-02-03 12:42:47 --> Security Class Initialized
DEBUG - 2016-02-03 12:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:42:47 --> Input Class Initialized
INFO - 2016-02-03 12:42:47 --> Language Class Initialized
INFO - 2016-02-03 12:42:47 --> Loader Class Initialized
INFO - 2016-02-03 12:42:47 --> Helper loaded: url_helper
INFO - 2016-02-03 12:42:47 --> Helper loaded: file_helper
INFO - 2016-02-03 12:42:47 --> Helper loaded: date_helper
INFO - 2016-02-03 12:42:47 --> Database Driver Class Initialized
INFO - 2016-02-03 12:42:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:42:48 --> Controller Class Initialized
INFO - 2016-02-03 12:42:48 --> Model Class Initialized
INFO - 2016-02-03 12:42:48 --> Model Class Initialized
INFO - 2016-02-03 12:42:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:42:48 --> Pagination Class Initialized
INFO - 2016-02-03 12:42:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:42:48 --> Helper loaded: text_helper
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 4
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 13
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 18
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 22
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 23
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-03 12:42:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 51
INFO - 2016-02-03 12:42:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:42:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:42:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:42:48 --> Final output sent to browser
DEBUG - 2016-02-03 12:42:48 --> Total execution time: 1.2116
INFO - 2016-02-03 12:43:09 --> Config Class Initialized
INFO - 2016-02-03 12:43:09 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:09 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:09 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:09 --> URI Class Initialized
INFO - 2016-02-03 12:43:09 --> Router Class Initialized
INFO - 2016-02-03 12:43:09 --> Output Class Initialized
INFO - 2016-02-03 12:43:09 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:09 --> Input Class Initialized
INFO - 2016-02-03 12:43:09 --> Language Class Initialized
INFO - 2016-02-03 12:43:09 --> Loader Class Initialized
INFO - 2016-02-03 12:43:09 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:09 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:09 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:09 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:10 --> Controller Class Initialized
INFO - 2016-02-03 12:43:10 --> Model Class Initialized
INFO - 2016-02-03 12:43:10 --> Model Class Initialized
INFO - 2016-02-03 12:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:10 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:10 --> Helper loaded: text_helper
INFO - 2016-02-03 12:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:10 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:10 --> Total execution time: 1.1731
INFO - 2016-02-03 12:43:27 --> Config Class Initialized
INFO - 2016-02-03 12:43:27 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:27 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:27 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:27 --> URI Class Initialized
INFO - 2016-02-03 12:43:27 --> Router Class Initialized
INFO - 2016-02-03 12:43:27 --> Output Class Initialized
INFO - 2016-02-03 12:43:27 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:27 --> Input Class Initialized
INFO - 2016-02-03 12:43:27 --> Language Class Initialized
INFO - 2016-02-03 12:43:27 --> Loader Class Initialized
INFO - 2016-02-03 12:43:27 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:27 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:27 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:27 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:28 --> Controller Class Initialized
INFO - 2016-02-03 12:43:28 --> Model Class Initialized
INFO - 2016-02-03 12:43:28 --> Model Class Initialized
INFO - 2016-02-03 12:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:28 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:28 --> Helper loaded: text_helper
INFO - 2016-02-03 12:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:28 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:28 --> Total execution time: 1.1731
INFO - 2016-02-03 12:43:30 --> Config Class Initialized
INFO - 2016-02-03 12:43:30 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:30 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:30 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:30 --> URI Class Initialized
INFO - 2016-02-03 12:43:30 --> Router Class Initialized
INFO - 2016-02-03 12:43:30 --> Output Class Initialized
INFO - 2016-02-03 12:43:30 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:30 --> Input Class Initialized
INFO - 2016-02-03 12:43:30 --> Language Class Initialized
INFO - 2016-02-03 12:43:30 --> Loader Class Initialized
INFO - 2016-02-03 12:43:30 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:30 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:30 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:30 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:31 --> Controller Class Initialized
INFO - 2016-02-03 12:43:31 --> Model Class Initialized
INFO - 2016-02-03 12:43:31 --> Model Class Initialized
INFO - 2016-02-03 12:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:31 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:31 --> Helper loaded: text_helper
INFO - 2016-02-03 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:31 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:31 --> Total execution time: 1.1996
INFO - 2016-02-03 12:43:33 --> Config Class Initialized
INFO - 2016-02-03 12:43:33 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:33 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:33 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:33 --> URI Class Initialized
INFO - 2016-02-03 12:43:33 --> Router Class Initialized
INFO - 2016-02-03 12:43:33 --> Output Class Initialized
INFO - 2016-02-03 12:43:33 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:33 --> Input Class Initialized
INFO - 2016-02-03 12:43:33 --> Language Class Initialized
INFO - 2016-02-03 12:43:33 --> Loader Class Initialized
INFO - 2016-02-03 12:43:33 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:33 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:33 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:33 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:34 --> Controller Class Initialized
INFO - 2016-02-03 12:43:34 --> Model Class Initialized
INFO - 2016-02-03 12:43:34 --> Model Class Initialized
INFO - 2016-02-03 12:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:34 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:34 --> Helper loaded: text_helper
INFO - 2016-02-03 12:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:34 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:34 --> Total execution time: 1.2698
INFO - 2016-02-03 12:43:37 --> Config Class Initialized
INFO - 2016-02-03 12:43:37 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:37 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:37 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:37 --> URI Class Initialized
DEBUG - 2016-02-03 12:43:37 --> No URI present. Default controller set.
INFO - 2016-02-03 12:43:37 --> Router Class Initialized
INFO - 2016-02-03 12:43:37 --> Output Class Initialized
INFO - 2016-02-03 12:43:37 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:37 --> Input Class Initialized
INFO - 2016-02-03 12:43:37 --> Language Class Initialized
INFO - 2016-02-03 12:43:37 --> Loader Class Initialized
INFO - 2016-02-03 12:43:37 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:37 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:37 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:37 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:38 --> Controller Class Initialized
INFO - 2016-02-03 12:43:38 --> Model Class Initialized
INFO - 2016-02-03 12:43:38 --> Model Class Initialized
INFO - 2016-02-03 12:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:38 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:38 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:38 --> Total execution time: 1.1458
INFO - 2016-02-03 12:43:39 --> Config Class Initialized
INFO - 2016-02-03 12:43:39 --> Hooks Class Initialized
DEBUG - 2016-02-03 12:43:39 --> UTF-8 Support Enabled
INFO - 2016-02-03 12:43:39 --> Utf8 Class Initialized
INFO - 2016-02-03 12:43:39 --> URI Class Initialized
INFO - 2016-02-03 12:43:39 --> Router Class Initialized
INFO - 2016-02-03 12:43:39 --> Output Class Initialized
INFO - 2016-02-03 12:43:39 --> Security Class Initialized
DEBUG - 2016-02-03 12:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 12:43:39 --> Input Class Initialized
INFO - 2016-02-03 12:43:39 --> Language Class Initialized
INFO - 2016-02-03 12:43:39 --> Loader Class Initialized
INFO - 2016-02-03 12:43:39 --> Helper loaded: url_helper
INFO - 2016-02-03 12:43:39 --> Helper loaded: file_helper
INFO - 2016-02-03 12:43:39 --> Helper loaded: date_helper
INFO - 2016-02-03 12:43:39 --> Database Driver Class Initialized
INFO - 2016-02-03 12:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 12:43:41 --> Controller Class Initialized
INFO - 2016-02-03 12:43:41 --> Model Class Initialized
INFO - 2016-02-03 12:43:41 --> Model Class Initialized
INFO - 2016-02-03 12:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 12:43:41 --> Pagination Class Initialized
INFO - 2016-02-03 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 12:43:41 --> Helper loaded: text_helper
INFO - 2016-02-03 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 12:43:41 --> Final output sent to browser
DEBUG - 2016-02-03 12:43:41 --> Total execution time: 1.1567
INFO - 2016-02-03 13:03:49 --> Config Class Initialized
INFO - 2016-02-03 13:03:49 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:03:49 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:03:49 --> Utf8 Class Initialized
INFO - 2016-02-03 13:03:49 --> URI Class Initialized
DEBUG - 2016-02-03 13:03:49 --> No URI present. Default controller set.
INFO - 2016-02-03 13:03:49 --> Router Class Initialized
INFO - 2016-02-03 13:03:49 --> Output Class Initialized
INFO - 2016-02-03 13:03:49 --> Security Class Initialized
DEBUG - 2016-02-03 13:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:03:49 --> Input Class Initialized
INFO - 2016-02-03 13:03:49 --> Language Class Initialized
INFO - 2016-02-03 13:03:49 --> Loader Class Initialized
INFO - 2016-02-03 13:03:49 --> Helper loaded: url_helper
INFO - 2016-02-03 13:03:49 --> Helper loaded: file_helper
INFO - 2016-02-03 13:03:49 --> Helper loaded: date_helper
INFO - 2016-02-03 13:03:49 --> Database Driver Class Initialized
INFO - 2016-02-03 13:03:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:03:50 --> Controller Class Initialized
INFO - 2016-02-03 13:03:50 --> Model Class Initialized
INFO - 2016-02-03 13:03:50 --> Model Class Initialized
INFO - 2016-02-03 13:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:03:50 --> Pagination Class Initialized
INFO - 2016-02-03 13:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:03:50 --> Final output sent to browser
DEBUG - 2016-02-03 13:03:50 --> Total execution time: 1.1271
INFO - 2016-02-03 13:33:46 --> Config Class Initialized
INFO - 2016-02-03 13:33:46 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:33:46 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:33:46 --> Utf8 Class Initialized
INFO - 2016-02-03 13:33:46 --> URI Class Initialized
DEBUG - 2016-02-03 13:33:46 --> No URI present. Default controller set.
INFO - 2016-02-03 13:33:46 --> Router Class Initialized
INFO - 2016-02-03 13:33:46 --> Output Class Initialized
INFO - 2016-02-03 13:33:46 --> Security Class Initialized
DEBUG - 2016-02-03 13:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:33:46 --> Input Class Initialized
INFO - 2016-02-03 13:33:46 --> Language Class Initialized
INFO - 2016-02-03 13:33:46 --> Loader Class Initialized
INFO - 2016-02-03 13:33:46 --> Helper loaded: url_helper
INFO - 2016-02-03 13:33:46 --> Helper loaded: file_helper
INFO - 2016-02-03 13:33:46 --> Helper loaded: date_helper
INFO - 2016-02-03 13:33:46 --> Database Driver Class Initialized
INFO - 2016-02-03 13:33:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:33:47 --> Controller Class Initialized
INFO - 2016-02-03 13:33:47 --> Model Class Initialized
INFO - 2016-02-03 13:33:47 --> Model Class Initialized
INFO - 2016-02-03 13:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:33:47 --> Pagination Class Initialized
INFO - 2016-02-03 13:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:33:47 --> Final output sent to browser
DEBUG - 2016-02-03 13:33:47 --> Total execution time: 1.1438
INFO - 2016-02-03 13:34:00 --> Config Class Initialized
INFO - 2016-02-03 13:34:00 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:34:00 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:34:00 --> Utf8 Class Initialized
INFO - 2016-02-03 13:34:00 --> URI Class Initialized
DEBUG - 2016-02-03 13:34:00 --> No URI present. Default controller set.
INFO - 2016-02-03 13:34:00 --> Router Class Initialized
INFO - 2016-02-03 13:34:00 --> Output Class Initialized
INFO - 2016-02-03 13:34:00 --> Security Class Initialized
DEBUG - 2016-02-03 13:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:34:00 --> Input Class Initialized
INFO - 2016-02-03 13:34:00 --> Language Class Initialized
INFO - 2016-02-03 13:34:00 --> Loader Class Initialized
INFO - 2016-02-03 13:34:00 --> Helper loaded: url_helper
INFO - 2016-02-03 13:34:00 --> Helper loaded: file_helper
INFO - 2016-02-03 13:34:00 --> Helper loaded: date_helper
INFO - 2016-02-03 13:34:00 --> Database Driver Class Initialized
INFO - 2016-02-03 13:34:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:34:01 --> Controller Class Initialized
INFO - 2016-02-03 13:34:01 --> Model Class Initialized
INFO - 2016-02-03 13:34:01 --> Model Class Initialized
INFO - 2016-02-03 13:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:34:01 --> Pagination Class Initialized
INFO - 2016-02-03 13:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:34:01 --> Final output sent to browser
DEBUG - 2016-02-03 13:34:01 --> Total execution time: 1.1323
INFO - 2016-02-03 13:34:04 --> Config Class Initialized
INFO - 2016-02-03 13:34:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:34:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:34:04 --> Utf8 Class Initialized
INFO - 2016-02-03 13:34:04 --> URI Class Initialized
DEBUG - 2016-02-03 13:34:04 --> No URI present. Default controller set.
INFO - 2016-02-03 13:34:04 --> Router Class Initialized
INFO - 2016-02-03 13:34:04 --> Output Class Initialized
INFO - 2016-02-03 13:34:04 --> Security Class Initialized
DEBUG - 2016-02-03 13:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:34:04 --> Input Class Initialized
INFO - 2016-02-03 13:34:04 --> Language Class Initialized
INFO - 2016-02-03 13:34:04 --> Loader Class Initialized
INFO - 2016-02-03 13:34:04 --> Helper loaded: url_helper
INFO - 2016-02-03 13:34:04 --> Helper loaded: file_helper
INFO - 2016-02-03 13:34:04 --> Helper loaded: date_helper
INFO - 2016-02-03 13:34:04 --> Database Driver Class Initialized
INFO - 2016-02-03 13:34:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:34:05 --> Controller Class Initialized
INFO - 2016-02-03 13:34:05 --> Model Class Initialized
INFO - 2016-02-03 13:34:05 --> Model Class Initialized
INFO - 2016-02-03 13:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:34:05 --> Pagination Class Initialized
INFO - 2016-02-03 13:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:34:05 --> Final output sent to browser
DEBUG - 2016-02-03 13:34:05 --> Total execution time: 1.1234
INFO - 2016-02-03 13:34:50 --> Config Class Initialized
INFO - 2016-02-03 13:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:34:50 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:34:50 --> Utf8 Class Initialized
INFO - 2016-02-03 13:34:50 --> URI Class Initialized
DEBUG - 2016-02-03 13:34:50 --> No URI present. Default controller set.
INFO - 2016-02-03 13:34:50 --> Router Class Initialized
INFO - 2016-02-03 13:34:50 --> Output Class Initialized
INFO - 2016-02-03 13:34:50 --> Security Class Initialized
DEBUG - 2016-02-03 13:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:34:50 --> Input Class Initialized
INFO - 2016-02-03 13:34:50 --> Language Class Initialized
INFO - 2016-02-03 13:34:50 --> Loader Class Initialized
INFO - 2016-02-03 13:34:50 --> Helper loaded: url_helper
INFO - 2016-02-03 13:34:50 --> Helper loaded: file_helper
INFO - 2016-02-03 13:34:50 --> Helper loaded: date_helper
INFO - 2016-02-03 13:34:50 --> Database Driver Class Initialized
INFO - 2016-02-03 13:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:34:51 --> Controller Class Initialized
INFO - 2016-02-03 13:34:51 --> Model Class Initialized
INFO - 2016-02-03 13:34:51 --> Model Class Initialized
INFO - 2016-02-03 13:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:34:51 --> Pagination Class Initialized
INFO - 2016-02-03 13:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:34:51 --> Final output sent to browser
DEBUG - 2016-02-03 13:34:51 --> Total execution time: 1.1152
INFO - 2016-02-03 13:34:54 --> Config Class Initialized
INFO - 2016-02-03 13:34:54 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:34:54 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:34:54 --> Utf8 Class Initialized
INFO - 2016-02-03 13:34:54 --> URI Class Initialized
DEBUG - 2016-02-03 13:34:54 --> No URI present. Default controller set.
INFO - 2016-02-03 13:34:54 --> Router Class Initialized
INFO - 2016-02-03 13:34:54 --> Output Class Initialized
INFO - 2016-02-03 13:34:54 --> Security Class Initialized
DEBUG - 2016-02-03 13:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:34:54 --> Input Class Initialized
INFO - 2016-02-03 13:34:54 --> Language Class Initialized
INFO - 2016-02-03 13:34:54 --> Loader Class Initialized
INFO - 2016-02-03 13:34:54 --> Helper loaded: url_helper
INFO - 2016-02-03 13:34:54 --> Helper loaded: file_helper
INFO - 2016-02-03 13:34:54 --> Helper loaded: date_helper
INFO - 2016-02-03 13:34:54 --> Database Driver Class Initialized
INFO - 2016-02-03 13:34:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:34:55 --> Controller Class Initialized
INFO - 2016-02-03 13:34:55 --> Model Class Initialized
INFO - 2016-02-03 13:34:55 --> Model Class Initialized
INFO - 2016-02-03 13:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:34:55 --> Pagination Class Initialized
INFO - 2016-02-03 13:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:34:55 --> Final output sent to browser
DEBUG - 2016-02-03 13:34:55 --> Total execution time: 1.1343
INFO - 2016-02-03 13:34:56 --> Config Class Initialized
INFO - 2016-02-03 13:34:56 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:34:56 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:34:56 --> Utf8 Class Initialized
INFO - 2016-02-03 13:34:56 --> URI Class Initialized
INFO - 2016-02-03 13:34:56 --> Router Class Initialized
INFO - 2016-02-03 13:34:56 --> Output Class Initialized
INFO - 2016-02-03 13:34:56 --> Security Class Initialized
DEBUG - 2016-02-03 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:34:56 --> Input Class Initialized
INFO - 2016-02-03 13:34:56 --> Language Class Initialized
INFO - 2016-02-03 13:34:56 --> Loader Class Initialized
INFO - 2016-02-03 13:34:56 --> Helper loaded: url_helper
INFO - 2016-02-03 13:34:56 --> Helper loaded: file_helper
INFO - 2016-02-03 13:34:56 --> Helper loaded: date_helper
INFO - 2016-02-03 13:34:56 --> Database Driver Class Initialized
INFO - 2016-02-03 13:34:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:34:57 --> Controller Class Initialized
INFO - 2016-02-03 13:34:57 --> Model Class Initialized
INFO - 2016-02-03 13:34:57 --> Model Class Initialized
INFO - 2016-02-03 13:34:57 --> Helper loaded: form_helper
INFO - 2016-02-03 13:34:57 --> Form Validation Class Initialized
INFO - 2016-02-03 13:34:57 --> Helper loaded: text_helper
INFO - 2016-02-03 13:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-03 13:34:57 --> Final output sent to browser
DEBUG - 2016-02-03 13:34:57 --> Total execution time: 1.1251
INFO - 2016-02-03 13:35:02 --> Config Class Initialized
INFO - 2016-02-03 13:35:02 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:35:02 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:35:02 --> Utf8 Class Initialized
INFO - 2016-02-03 13:35:02 --> URI Class Initialized
DEBUG - 2016-02-03 13:35:02 --> No URI present. Default controller set.
INFO - 2016-02-03 13:35:02 --> Router Class Initialized
INFO - 2016-02-03 13:35:02 --> Output Class Initialized
INFO - 2016-02-03 13:35:02 --> Security Class Initialized
DEBUG - 2016-02-03 13:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:35:02 --> Input Class Initialized
INFO - 2016-02-03 13:35:02 --> Language Class Initialized
INFO - 2016-02-03 13:35:02 --> Loader Class Initialized
INFO - 2016-02-03 13:35:02 --> Helper loaded: url_helper
INFO - 2016-02-03 13:35:02 --> Helper loaded: file_helper
INFO - 2016-02-03 13:35:02 --> Helper loaded: date_helper
INFO - 2016-02-03 13:35:02 --> Database Driver Class Initialized
INFO - 2016-02-03 13:35:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:35:03 --> Controller Class Initialized
INFO - 2016-02-03 13:35:03 --> Model Class Initialized
INFO - 2016-02-03 13:35:03 --> Model Class Initialized
INFO - 2016-02-03 13:35:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:35:03 --> Pagination Class Initialized
INFO - 2016-02-03 13:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:35:03 --> Final output sent to browser
DEBUG - 2016-02-03 13:35:03 --> Total execution time: 1.1327
INFO - 2016-02-03 13:42:07 --> Config Class Initialized
INFO - 2016-02-03 13:42:07 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:42:07 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:42:07 --> Utf8 Class Initialized
INFO - 2016-02-03 13:42:07 --> URI Class Initialized
DEBUG - 2016-02-03 13:42:07 --> No URI present. Default controller set.
INFO - 2016-02-03 13:42:07 --> Router Class Initialized
INFO - 2016-02-03 13:42:07 --> Output Class Initialized
INFO - 2016-02-03 13:42:07 --> Security Class Initialized
DEBUG - 2016-02-03 13:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:42:07 --> Input Class Initialized
INFO - 2016-02-03 13:42:07 --> Language Class Initialized
INFO - 2016-02-03 13:42:07 --> Loader Class Initialized
INFO - 2016-02-03 13:42:07 --> Helper loaded: url_helper
INFO - 2016-02-03 13:42:07 --> Helper loaded: file_helper
INFO - 2016-02-03 13:42:07 --> Helper loaded: date_helper
INFO - 2016-02-03 13:42:07 --> Database Driver Class Initialized
INFO - 2016-02-03 13:42:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:42:09 --> Controller Class Initialized
INFO - 2016-02-03 13:42:09 --> Model Class Initialized
INFO - 2016-02-03 13:42:09 --> Model Class Initialized
INFO - 2016-02-03 13:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:42:09 --> Pagination Class Initialized
INFO - 2016-02-03 13:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:42:09 --> Final output sent to browser
DEBUG - 2016-02-03 13:42:09 --> Total execution time: 1.1186
INFO - 2016-02-03 13:45:58 --> Config Class Initialized
INFO - 2016-02-03 13:45:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:45:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:45:58 --> Utf8 Class Initialized
INFO - 2016-02-03 13:45:58 --> URI Class Initialized
DEBUG - 2016-02-03 13:45:58 --> No URI present. Default controller set.
INFO - 2016-02-03 13:45:58 --> Router Class Initialized
INFO - 2016-02-03 13:45:58 --> Output Class Initialized
INFO - 2016-02-03 13:45:58 --> Security Class Initialized
DEBUG - 2016-02-03 13:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:45:58 --> Input Class Initialized
INFO - 2016-02-03 13:45:58 --> Language Class Initialized
INFO - 2016-02-03 13:45:58 --> Loader Class Initialized
INFO - 2016-02-03 13:45:58 --> Helper loaded: url_helper
INFO - 2016-02-03 13:45:58 --> Helper loaded: file_helper
INFO - 2016-02-03 13:45:58 --> Helper loaded: date_helper
INFO - 2016-02-03 13:45:58 --> Database Driver Class Initialized
INFO - 2016-02-03 13:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:45:59 --> Controller Class Initialized
INFO - 2016-02-03 13:45:59 --> Model Class Initialized
INFO - 2016-02-03 13:45:59 --> Model Class Initialized
INFO - 2016-02-03 13:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:45:59 --> Pagination Class Initialized
INFO - 2016-02-03 13:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:45:59 --> Final output sent to browser
DEBUG - 2016-02-03 13:45:59 --> Total execution time: 1.1036
INFO - 2016-02-03 13:46:12 --> Config Class Initialized
INFO - 2016-02-03 13:46:12 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:46:12 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:46:12 --> Utf8 Class Initialized
INFO - 2016-02-03 13:46:12 --> URI Class Initialized
INFO - 2016-02-03 13:46:12 --> Router Class Initialized
INFO - 2016-02-03 13:46:12 --> Output Class Initialized
INFO - 2016-02-03 13:46:12 --> Security Class Initialized
DEBUG - 2016-02-03 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:46:12 --> Input Class Initialized
INFO - 2016-02-03 13:46:12 --> Language Class Initialized
INFO - 2016-02-03 13:46:12 --> Loader Class Initialized
INFO - 2016-02-03 13:46:12 --> Helper loaded: url_helper
INFO - 2016-02-03 13:46:12 --> Helper loaded: file_helper
INFO - 2016-02-03 13:46:12 --> Helper loaded: date_helper
INFO - 2016-02-03 13:46:12 --> Database Driver Class Initialized
INFO - 2016-02-03 13:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:46:13 --> Controller Class Initialized
INFO - 2016-02-03 13:46:13 --> Model Class Initialized
INFO - 2016-02-03 13:46:13 --> Model Class Initialized
INFO - 2016-02-03 13:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:46:13 --> Pagination Class Initialized
INFO - 2016-02-03 13:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:46:13 --> Helper loaded: text_helper
INFO - 2016-02-03 13:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 13:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 13:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:46:13 --> Final output sent to browser
DEBUG - 2016-02-03 13:46:13 --> Total execution time: 1.1840
INFO - 2016-02-03 13:46:17 --> Config Class Initialized
INFO - 2016-02-03 13:46:17 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:46:17 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:46:17 --> Utf8 Class Initialized
INFO - 2016-02-03 13:46:17 --> URI Class Initialized
DEBUG - 2016-02-03 13:46:17 --> No URI present. Default controller set.
INFO - 2016-02-03 13:46:17 --> Router Class Initialized
INFO - 2016-02-03 13:46:17 --> Output Class Initialized
INFO - 2016-02-03 13:46:17 --> Security Class Initialized
DEBUG - 2016-02-03 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:46:17 --> Input Class Initialized
INFO - 2016-02-03 13:46:17 --> Language Class Initialized
INFO - 2016-02-03 13:46:17 --> Loader Class Initialized
INFO - 2016-02-03 13:46:17 --> Helper loaded: url_helper
INFO - 2016-02-03 13:46:17 --> Helper loaded: file_helper
INFO - 2016-02-03 13:46:17 --> Helper loaded: date_helper
INFO - 2016-02-03 13:46:17 --> Database Driver Class Initialized
INFO - 2016-02-03 13:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:46:18 --> Controller Class Initialized
INFO - 2016-02-03 13:46:18 --> Model Class Initialized
INFO - 2016-02-03 13:46:18 --> Model Class Initialized
INFO - 2016-02-03 13:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:46:18 --> Pagination Class Initialized
INFO - 2016-02-03 13:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:46:18 --> Final output sent to browser
DEBUG - 2016-02-03 13:46:18 --> Total execution time: 1.1137
INFO - 2016-02-03 13:47:43 --> Config Class Initialized
INFO - 2016-02-03 13:47:43 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:47:43 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:47:43 --> Utf8 Class Initialized
INFO - 2016-02-03 13:47:43 --> URI Class Initialized
DEBUG - 2016-02-03 13:47:43 --> No URI present. Default controller set.
INFO - 2016-02-03 13:47:43 --> Router Class Initialized
INFO - 2016-02-03 13:47:43 --> Output Class Initialized
INFO - 2016-02-03 13:47:43 --> Security Class Initialized
DEBUG - 2016-02-03 13:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:47:43 --> Input Class Initialized
INFO - 2016-02-03 13:47:43 --> Language Class Initialized
INFO - 2016-02-03 13:47:43 --> Loader Class Initialized
INFO - 2016-02-03 13:47:43 --> Helper loaded: url_helper
INFO - 2016-02-03 13:47:43 --> Helper loaded: file_helper
INFO - 2016-02-03 13:47:43 --> Helper loaded: date_helper
INFO - 2016-02-03 13:47:44 --> Database Driver Class Initialized
INFO - 2016-02-03 13:47:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:47:45 --> Controller Class Initialized
INFO - 2016-02-03 13:47:45 --> Model Class Initialized
INFO - 2016-02-03 13:47:45 --> Model Class Initialized
INFO - 2016-02-03 13:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:47:45 --> Pagination Class Initialized
INFO - 2016-02-03 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:47:45 --> Final output sent to browser
DEBUG - 2016-02-03 13:47:45 --> Total execution time: 1.1085
INFO - 2016-02-03 13:55:01 --> Config Class Initialized
INFO - 2016-02-03 13:55:01 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:55:01 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:55:01 --> Utf8 Class Initialized
INFO - 2016-02-03 13:55:01 --> URI Class Initialized
DEBUG - 2016-02-03 13:55:01 --> No URI present. Default controller set.
INFO - 2016-02-03 13:55:01 --> Router Class Initialized
INFO - 2016-02-03 13:55:01 --> Output Class Initialized
INFO - 2016-02-03 13:55:01 --> Security Class Initialized
DEBUG - 2016-02-03 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:55:01 --> Input Class Initialized
INFO - 2016-02-03 13:55:01 --> Language Class Initialized
INFO - 2016-02-03 13:55:01 --> Loader Class Initialized
INFO - 2016-02-03 13:55:01 --> Helper loaded: url_helper
INFO - 2016-02-03 13:55:01 --> Helper loaded: file_helper
INFO - 2016-02-03 13:55:01 --> Helper loaded: date_helper
INFO - 2016-02-03 13:55:01 --> Database Driver Class Initialized
INFO - 2016-02-03 13:55:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:55:02 --> Controller Class Initialized
INFO - 2016-02-03 13:55:03 --> Model Class Initialized
INFO - 2016-02-03 13:55:03 --> Model Class Initialized
INFO - 2016-02-03 13:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:55:03 --> Pagination Class Initialized
INFO - 2016-02-03 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:55:03 --> Final output sent to browser
DEBUG - 2016-02-03 13:55:03 --> Total execution time: 1.1195
INFO - 2016-02-03 13:56:18 --> Config Class Initialized
INFO - 2016-02-03 13:56:18 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:56:18 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:56:18 --> Utf8 Class Initialized
INFO - 2016-02-03 13:56:18 --> URI Class Initialized
DEBUG - 2016-02-03 13:56:18 --> No URI present. Default controller set.
INFO - 2016-02-03 13:56:18 --> Router Class Initialized
INFO - 2016-02-03 13:56:18 --> Output Class Initialized
INFO - 2016-02-03 13:56:18 --> Security Class Initialized
DEBUG - 2016-02-03 13:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:56:18 --> Input Class Initialized
INFO - 2016-02-03 13:56:18 --> Language Class Initialized
INFO - 2016-02-03 13:56:18 --> Loader Class Initialized
INFO - 2016-02-03 13:56:18 --> Helper loaded: url_helper
INFO - 2016-02-03 13:56:18 --> Helper loaded: file_helper
INFO - 2016-02-03 13:56:18 --> Helper loaded: date_helper
INFO - 2016-02-03 13:56:18 --> Database Driver Class Initialized
INFO - 2016-02-03 13:56:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:56:19 --> Controller Class Initialized
INFO - 2016-02-03 13:56:19 --> Model Class Initialized
INFO - 2016-02-03 13:56:19 --> Model Class Initialized
INFO - 2016-02-03 13:56:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:56:19 --> Pagination Class Initialized
INFO - 2016-02-03 13:56:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:56:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:56:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:56:19 --> Final output sent to browser
DEBUG - 2016-02-03 13:56:19 --> Total execution time: 1.1101
INFO - 2016-02-03 13:58:14 --> Config Class Initialized
INFO - 2016-02-03 13:58:14 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:58:14 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:58:14 --> Utf8 Class Initialized
INFO - 2016-02-03 13:58:14 --> URI Class Initialized
DEBUG - 2016-02-03 13:58:14 --> No URI present. Default controller set.
INFO - 2016-02-03 13:58:14 --> Router Class Initialized
INFO - 2016-02-03 13:58:14 --> Output Class Initialized
INFO - 2016-02-03 13:58:14 --> Security Class Initialized
DEBUG - 2016-02-03 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:58:14 --> Input Class Initialized
INFO - 2016-02-03 13:58:14 --> Language Class Initialized
INFO - 2016-02-03 13:58:14 --> Loader Class Initialized
INFO - 2016-02-03 13:58:14 --> Helper loaded: url_helper
INFO - 2016-02-03 13:58:14 --> Helper loaded: file_helper
INFO - 2016-02-03 13:58:14 --> Helper loaded: date_helper
INFO - 2016-02-03 13:58:14 --> Database Driver Class Initialized
INFO - 2016-02-03 13:58:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:58:15 --> Controller Class Initialized
INFO - 2016-02-03 13:58:15 --> Model Class Initialized
INFO - 2016-02-03 13:58:15 --> Model Class Initialized
INFO - 2016-02-03 13:58:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:58:15 --> Pagination Class Initialized
INFO - 2016-02-03 13:58:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:58:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:58:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:58:15 --> Final output sent to browser
DEBUG - 2016-02-03 13:58:15 --> Total execution time: 1.1097
INFO - 2016-02-03 13:59:10 --> Config Class Initialized
INFO - 2016-02-03 13:59:10 --> Hooks Class Initialized
DEBUG - 2016-02-03 13:59:10 --> UTF-8 Support Enabled
INFO - 2016-02-03 13:59:10 --> Utf8 Class Initialized
INFO - 2016-02-03 13:59:10 --> URI Class Initialized
DEBUG - 2016-02-03 13:59:10 --> No URI present. Default controller set.
INFO - 2016-02-03 13:59:10 --> Router Class Initialized
INFO - 2016-02-03 13:59:10 --> Output Class Initialized
INFO - 2016-02-03 13:59:10 --> Security Class Initialized
DEBUG - 2016-02-03 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 13:59:10 --> Input Class Initialized
INFO - 2016-02-03 13:59:10 --> Language Class Initialized
INFO - 2016-02-03 13:59:10 --> Loader Class Initialized
INFO - 2016-02-03 13:59:10 --> Helper loaded: url_helper
INFO - 2016-02-03 13:59:10 --> Helper loaded: file_helper
INFO - 2016-02-03 13:59:10 --> Helper loaded: date_helper
INFO - 2016-02-03 13:59:10 --> Database Driver Class Initialized
INFO - 2016-02-03 13:59:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 13:59:11 --> Controller Class Initialized
INFO - 2016-02-03 13:59:11 --> Model Class Initialized
INFO - 2016-02-03 13:59:11 --> Model Class Initialized
INFO - 2016-02-03 13:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 13:59:11 --> Pagination Class Initialized
INFO - 2016-02-03 13:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 13:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 13:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 13:59:11 --> Final output sent to browser
DEBUG - 2016-02-03 13:59:11 --> Total execution time: 1.1156
INFO - 2016-02-03 14:00:39 --> Config Class Initialized
INFO - 2016-02-03 14:00:39 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:00:39 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:00:39 --> Utf8 Class Initialized
INFO - 2016-02-03 14:00:39 --> URI Class Initialized
DEBUG - 2016-02-03 14:00:39 --> No URI present. Default controller set.
INFO - 2016-02-03 14:00:39 --> Router Class Initialized
INFO - 2016-02-03 14:00:39 --> Output Class Initialized
INFO - 2016-02-03 14:00:39 --> Security Class Initialized
DEBUG - 2016-02-03 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:00:39 --> Input Class Initialized
INFO - 2016-02-03 14:00:39 --> Language Class Initialized
INFO - 2016-02-03 14:00:39 --> Loader Class Initialized
INFO - 2016-02-03 14:00:39 --> Helper loaded: url_helper
INFO - 2016-02-03 14:00:39 --> Helper loaded: file_helper
INFO - 2016-02-03 14:00:39 --> Helper loaded: date_helper
INFO - 2016-02-03 14:00:39 --> Database Driver Class Initialized
INFO - 2016-02-03 14:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:00:40 --> Controller Class Initialized
INFO - 2016-02-03 14:00:40 --> Model Class Initialized
INFO - 2016-02-03 14:00:40 --> Model Class Initialized
INFO - 2016-02-03 14:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:00:40 --> Pagination Class Initialized
INFO - 2016-02-03 14:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:00:40 --> Final output sent to browser
DEBUG - 2016-02-03 14:00:40 --> Total execution time: 1.1008
INFO - 2016-02-03 14:03:27 --> Config Class Initialized
INFO - 2016-02-03 14:03:27 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:03:27 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:03:27 --> Utf8 Class Initialized
INFO - 2016-02-03 14:03:27 --> URI Class Initialized
DEBUG - 2016-02-03 14:03:27 --> No URI present. Default controller set.
INFO - 2016-02-03 14:03:27 --> Router Class Initialized
INFO - 2016-02-03 14:03:27 --> Output Class Initialized
INFO - 2016-02-03 14:03:27 --> Security Class Initialized
DEBUG - 2016-02-03 14:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:03:27 --> Input Class Initialized
INFO - 2016-02-03 14:03:27 --> Language Class Initialized
INFO - 2016-02-03 14:03:27 --> Loader Class Initialized
INFO - 2016-02-03 14:03:27 --> Helper loaded: url_helper
INFO - 2016-02-03 14:03:27 --> Helper loaded: file_helper
INFO - 2016-02-03 14:03:27 --> Helper loaded: date_helper
INFO - 2016-02-03 14:03:27 --> Database Driver Class Initialized
INFO - 2016-02-03 14:03:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:03:28 --> Controller Class Initialized
INFO - 2016-02-03 14:03:28 --> Model Class Initialized
INFO - 2016-02-03 14:03:28 --> Model Class Initialized
INFO - 2016-02-03 14:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:03:28 --> Pagination Class Initialized
INFO - 2016-02-03 14:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:03:28 --> Final output sent to browser
DEBUG - 2016-02-03 14:03:28 --> Total execution time: 1.1391
INFO - 2016-02-03 14:11:29 --> Config Class Initialized
INFO - 2016-02-03 14:11:29 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:11:29 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:11:29 --> Utf8 Class Initialized
INFO - 2016-02-03 14:11:29 --> URI Class Initialized
DEBUG - 2016-02-03 14:11:29 --> No URI present. Default controller set.
INFO - 2016-02-03 14:11:29 --> Router Class Initialized
INFO - 2016-02-03 14:11:29 --> Output Class Initialized
INFO - 2016-02-03 14:11:29 --> Security Class Initialized
DEBUG - 2016-02-03 14:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:11:29 --> Input Class Initialized
INFO - 2016-02-03 14:11:29 --> Language Class Initialized
INFO - 2016-02-03 14:11:29 --> Loader Class Initialized
INFO - 2016-02-03 14:11:29 --> Helper loaded: url_helper
INFO - 2016-02-03 14:11:29 --> Helper loaded: file_helper
INFO - 2016-02-03 14:11:29 --> Helper loaded: date_helper
INFO - 2016-02-03 14:11:29 --> Database Driver Class Initialized
INFO - 2016-02-03 14:11:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:11:31 --> Controller Class Initialized
INFO - 2016-02-03 14:11:31 --> Model Class Initialized
INFO - 2016-02-03 14:11:31 --> Model Class Initialized
INFO - 2016-02-03 14:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:11:31 --> Pagination Class Initialized
INFO - 2016-02-03 14:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:11:31 --> Final output sent to browser
DEBUG - 2016-02-03 14:11:31 --> Total execution time: 1.1280
INFO - 2016-02-03 14:11:45 --> Config Class Initialized
INFO - 2016-02-03 14:11:45 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:11:45 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:11:45 --> Utf8 Class Initialized
INFO - 2016-02-03 14:11:45 --> URI Class Initialized
INFO - 2016-02-03 14:11:45 --> Router Class Initialized
INFO - 2016-02-03 14:11:45 --> Output Class Initialized
INFO - 2016-02-03 14:11:45 --> Security Class Initialized
DEBUG - 2016-02-03 14:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:11:45 --> Input Class Initialized
INFO - 2016-02-03 14:11:45 --> Language Class Initialized
INFO - 2016-02-03 14:11:45 --> Loader Class Initialized
INFO - 2016-02-03 14:11:45 --> Helper loaded: url_helper
INFO - 2016-02-03 14:11:45 --> Helper loaded: file_helper
INFO - 2016-02-03 14:11:45 --> Helper loaded: date_helper
INFO - 2016-02-03 14:11:45 --> Database Driver Class Initialized
INFO - 2016-02-03 14:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:11:46 --> Controller Class Initialized
INFO - 2016-02-03 14:11:46 --> Model Class Initialized
INFO - 2016-02-03 14:11:46 --> Model Class Initialized
INFO - 2016-02-03 14:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:11:46 --> Pagination Class Initialized
INFO - 2016-02-03 14:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:11:46 --> Final output sent to browser
DEBUG - 2016-02-03 14:11:46 --> Total execution time: 1.1072
INFO - 2016-02-03 14:11:47 --> Config Class Initialized
INFO - 2016-02-03 14:11:47 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:11:47 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:11:47 --> Utf8 Class Initialized
INFO - 2016-02-03 14:11:47 --> URI Class Initialized
INFO - 2016-02-03 14:11:47 --> Router Class Initialized
INFO - 2016-02-03 14:11:47 --> Output Class Initialized
INFO - 2016-02-03 14:11:47 --> Security Class Initialized
DEBUG - 2016-02-03 14:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:11:47 --> Input Class Initialized
INFO - 2016-02-03 14:11:47 --> Language Class Initialized
INFO - 2016-02-03 14:11:47 --> Loader Class Initialized
INFO - 2016-02-03 14:11:47 --> Helper loaded: url_helper
INFO - 2016-02-03 14:11:47 --> Helper loaded: file_helper
INFO - 2016-02-03 14:11:47 --> Helper loaded: date_helper
INFO - 2016-02-03 14:11:47 --> Database Driver Class Initialized
INFO - 2016-02-03 14:11:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:11:48 --> Controller Class Initialized
INFO - 2016-02-03 14:11:48 --> Model Class Initialized
INFO - 2016-02-03 14:11:48 --> Model Class Initialized
INFO - 2016-02-03 14:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:11:48 --> Pagination Class Initialized
INFO - 2016-02-03 14:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:11:48 --> Final output sent to browser
DEBUG - 2016-02-03 14:11:48 --> Total execution time: 1.1085
INFO - 2016-02-03 14:11:53 --> Config Class Initialized
INFO - 2016-02-03 14:11:53 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:11:53 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:11:53 --> Utf8 Class Initialized
INFO - 2016-02-03 14:11:53 --> URI Class Initialized
INFO - 2016-02-03 14:11:53 --> Router Class Initialized
INFO - 2016-02-03 14:11:53 --> Output Class Initialized
INFO - 2016-02-03 14:11:53 --> Security Class Initialized
DEBUG - 2016-02-03 14:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:11:53 --> Input Class Initialized
INFO - 2016-02-03 14:11:53 --> Language Class Initialized
INFO - 2016-02-03 14:11:53 --> Loader Class Initialized
INFO - 2016-02-03 14:11:53 --> Helper loaded: url_helper
INFO - 2016-02-03 14:11:53 --> Helper loaded: file_helper
INFO - 2016-02-03 14:11:53 --> Helper loaded: date_helper
INFO - 2016-02-03 14:11:53 --> Database Driver Class Initialized
INFO - 2016-02-03 14:11:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:11:54 --> Controller Class Initialized
INFO - 2016-02-03 14:11:54 --> Model Class Initialized
INFO - 2016-02-03 14:11:54 --> Model Class Initialized
INFO - 2016-02-03 14:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:11:54 --> Pagination Class Initialized
INFO - 2016-02-03 14:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:11:54 --> Helper loaded: text_helper
INFO - 2016-02-03 14:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 14:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 14:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:11:54 --> Final output sent to browser
DEBUG - 2016-02-03 14:11:54 --> Total execution time: 1.1605
INFO - 2016-02-03 14:11:56 --> Config Class Initialized
INFO - 2016-02-03 14:11:56 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:11:56 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:11:56 --> Utf8 Class Initialized
INFO - 2016-02-03 14:11:56 --> URI Class Initialized
DEBUG - 2016-02-03 14:11:56 --> No URI present. Default controller set.
INFO - 2016-02-03 14:11:56 --> Router Class Initialized
INFO - 2016-02-03 14:11:56 --> Output Class Initialized
INFO - 2016-02-03 14:11:56 --> Security Class Initialized
DEBUG - 2016-02-03 14:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:11:56 --> Input Class Initialized
INFO - 2016-02-03 14:11:56 --> Language Class Initialized
INFO - 2016-02-03 14:11:56 --> Loader Class Initialized
INFO - 2016-02-03 14:11:56 --> Helper loaded: url_helper
INFO - 2016-02-03 14:11:56 --> Helper loaded: file_helper
INFO - 2016-02-03 14:11:56 --> Helper loaded: date_helper
INFO - 2016-02-03 14:11:56 --> Database Driver Class Initialized
INFO - 2016-02-03 14:11:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:11:57 --> Controller Class Initialized
INFO - 2016-02-03 14:11:57 --> Model Class Initialized
INFO - 2016-02-03 14:11:57 --> Model Class Initialized
INFO - 2016-02-03 14:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:11:57 --> Pagination Class Initialized
INFO - 2016-02-03 14:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:11:57 --> Final output sent to browser
DEBUG - 2016-02-03 14:11:57 --> Total execution time: 1.1018
INFO - 2016-02-03 14:12:04 --> Config Class Initialized
INFO - 2016-02-03 14:12:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:12:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:12:04 --> Utf8 Class Initialized
INFO - 2016-02-03 14:12:04 --> URI Class Initialized
INFO - 2016-02-03 14:12:04 --> Router Class Initialized
INFO - 2016-02-03 14:12:04 --> Output Class Initialized
INFO - 2016-02-03 14:12:04 --> Security Class Initialized
DEBUG - 2016-02-03 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:12:04 --> Input Class Initialized
INFO - 2016-02-03 14:12:04 --> Language Class Initialized
INFO - 2016-02-03 14:12:04 --> Loader Class Initialized
INFO - 2016-02-03 14:12:04 --> Helper loaded: url_helper
INFO - 2016-02-03 14:12:04 --> Helper loaded: file_helper
INFO - 2016-02-03 14:12:04 --> Helper loaded: date_helper
INFO - 2016-02-03 14:12:04 --> Database Driver Class Initialized
INFO - 2016-02-03 14:12:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:12:05 --> Controller Class Initialized
INFO - 2016-02-03 14:12:05 --> Model Class Initialized
INFO - 2016-02-03 14:12:05 --> Model Class Initialized
INFO - 2016-02-03 14:12:05 --> Helper loaded: form_helper
INFO - 2016-02-03 14:12:05 --> Form Validation Class Initialized
INFO - 2016-02-03 14:12:05 --> Helper loaded: text_helper
INFO - 2016-02-03 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 14:12:05 --> Model Class Initialized
INFO - 2016-02-03 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 14:12:05 --> Final output sent to browser
DEBUG - 2016-02-03 14:12:05 --> Total execution time: 1.1314
INFO - 2016-02-03 14:12:25 --> Config Class Initialized
INFO - 2016-02-03 14:12:25 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:12:25 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:12:25 --> Utf8 Class Initialized
INFO - 2016-02-03 14:12:25 --> URI Class Initialized
DEBUG - 2016-02-03 14:12:25 --> No URI present. Default controller set.
INFO - 2016-02-03 14:12:25 --> Router Class Initialized
INFO - 2016-02-03 14:12:25 --> Output Class Initialized
INFO - 2016-02-03 14:12:25 --> Security Class Initialized
DEBUG - 2016-02-03 14:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:12:25 --> Input Class Initialized
INFO - 2016-02-03 14:12:25 --> Language Class Initialized
INFO - 2016-02-03 14:12:25 --> Loader Class Initialized
INFO - 2016-02-03 14:12:25 --> Helper loaded: url_helper
INFO - 2016-02-03 14:12:25 --> Helper loaded: file_helper
INFO - 2016-02-03 14:12:25 --> Helper loaded: date_helper
INFO - 2016-02-03 14:12:25 --> Database Driver Class Initialized
INFO - 2016-02-03 14:12:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:12:26 --> Controller Class Initialized
INFO - 2016-02-03 14:12:26 --> Model Class Initialized
INFO - 2016-02-03 14:12:26 --> Model Class Initialized
INFO - 2016-02-03 14:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:12:26 --> Pagination Class Initialized
INFO - 2016-02-03 14:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:12:26 --> Final output sent to browser
DEBUG - 2016-02-03 14:12:26 --> Total execution time: 1.1150
INFO - 2016-02-03 14:15:18 --> Config Class Initialized
INFO - 2016-02-03 14:15:18 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:15:18 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:15:18 --> Utf8 Class Initialized
INFO - 2016-02-03 14:15:18 --> URI Class Initialized
INFO - 2016-02-03 14:15:18 --> Router Class Initialized
INFO - 2016-02-03 14:15:18 --> Output Class Initialized
INFO - 2016-02-03 14:15:18 --> Security Class Initialized
DEBUG - 2016-02-03 14:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:15:18 --> Input Class Initialized
INFO - 2016-02-03 14:15:18 --> Language Class Initialized
INFO - 2016-02-03 14:15:18 --> Loader Class Initialized
INFO - 2016-02-03 14:15:18 --> Helper loaded: url_helper
INFO - 2016-02-03 14:15:18 --> Helper loaded: file_helper
INFO - 2016-02-03 14:15:18 --> Helper loaded: date_helper
INFO - 2016-02-03 14:15:18 --> Database Driver Class Initialized
INFO - 2016-02-03 14:15:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:15:19 --> Controller Class Initialized
INFO - 2016-02-03 14:15:19 --> Model Class Initialized
INFO - 2016-02-03 14:15:19 --> Model Class Initialized
INFO - 2016-02-03 14:15:19 --> Helper loaded: form_helper
INFO - 2016-02-03 14:15:19 --> Form Validation Class Initialized
INFO - 2016-02-03 14:15:19 --> Helper loaded: text_helper
INFO - 2016-02-03 14:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 14:15:19 --> Model Class Initialized
INFO - 2016-02-03 14:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 14:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:15:19 --> Final output sent to browser
DEBUG - 2016-02-03 14:15:19 --> Total execution time: 1.1374
INFO - 2016-02-03 14:16:04 --> Config Class Initialized
INFO - 2016-02-03 14:16:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:16:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:16:04 --> Utf8 Class Initialized
INFO - 2016-02-03 14:16:04 --> URI Class Initialized
INFO - 2016-02-03 14:16:04 --> Router Class Initialized
INFO - 2016-02-03 14:16:04 --> Output Class Initialized
INFO - 2016-02-03 14:16:04 --> Security Class Initialized
DEBUG - 2016-02-03 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:16:04 --> Input Class Initialized
INFO - 2016-02-03 14:16:04 --> Language Class Initialized
INFO - 2016-02-03 14:16:04 --> Loader Class Initialized
INFO - 2016-02-03 14:16:04 --> Helper loaded: url_helper
INFO - 2016-02-03 14:16:04 --> Helper loaded: file_helper
INFO - 2016-02-03 14:16:04 --> Helper loaded: date_helper
INFO - 2016-02-03 14:16:04 --> Database Driver Class Initialized
INFO - 2016-02-03 14:16:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:16:05 --> Controller Class Initialized
INFO - 2016-02-03 14:16:05 --> Model Class Initialized
INFO - 2016-02-03 14:16:05 --> Model Class Initialized
INFO - 2016-02-03 14:16:05 --> Helper loaded: form_helper
INFO - 2016-02-03 14:16:05 --> Form Validation Class Initialized
INFO - 2016-02-03 14:16:05 --> Helper loaded: text_helper
INFO - 2016-02-03 14:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-03 14:16:05 --> Model Class Initialized
INFO - 2016-02-03 14:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 14:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:16:05 --> Final output sent to browser
DEBUG - 2016-02-03 14:16:05 --> Total execution time: 1.1362
INFO - 2016-02-03 14:16:13 --> Config Class Initialized
INFO - 2016-02-03 14:16:13 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:16:13 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:16:13 --> Utf8 Class Initialized
INFO - 2016-02-03 14:16:13 --> URI Class Initialized
DEBUG - 2016-02-03 14:16:13 --> No URI present. Default controller set.
INFO - 2016-02-03 14:16:13 --> Router Class Initialized
INFO - 2016-02-03 14:16:13 --> Output Class Initialized
INFO - 2016-02-03 14:16:13 --> Security Class Initialized
DEBUG - 2016-02-03 14:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:16:13 --> Input Class Initialized
INFO - 2016-02-03 14:16:13 --> Language Class Initialized
INFO - 2016-02-03 14:16:13 --> Loader Class Initialized
INFO - 2016-02-03 14:16:13 --> Helper loaded: url_helper
INFO - 2016-02-03 14:16:13 --> Helper loaded: file_helper
INFO - 2016-02-03 14:16:13 --> Helper loaded: date_helper
INFO - 2016-02-03 14:16:13 --> Database Driver Class Initialized
INFO - 2016-02-03 14:16:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:16:15 --> Controller Class Initialized
INFO - 2016-02-03 14:16:15 --> Model Class Initialized
INFO - 2016-02-03 14:16:15 --> Model Class Initialized
INFO - 2016-02-03 14:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:16:15 --> Pagination Class Initialized
INFO - 2016-02-03 14:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:16:15 --> Final output sent to browser
DEBUG - 2016-02-03 14:16:15 --> Total execution time: 1.1406
INFO - 2016-02-03 14:23:40 --> Config Class Initialized
INFO - 2016-02-03 14:23:40 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:23:40 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:23:40 --> Utf8 Class Initialized
INFO - 2016-02-03 14:23:40 --> URI Class Initialized
DEBUG - 2016-02-03 14:23:40 --> No URI present. Default controller set.
INFO - 2016-02-03 14:23:40 --> Router Class Initialized
INFO - 2016-02-03 14:23:40 --> Output Class Initialized
INFO - 2016-02-03 14:23:40 --> Security Class Initialized
DEBUG - 2016-02-03 14:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:23:40 --> Input Class Initialized
INFO - 2016-02-03 14:23:40 --> Language Class Initialized
INFO - 2016-02-03 14:23:40 --> Loader Class Initialized
INFO - 2016-02-03 14:23:40 --> Helper loaded: url_helper
INFO - 2016-02-03 14:23:40 --> Helper loaded: file_helper
INFO - 2016-02-03 14:23:40 --> Helper loaded: date_helper
INFO - 2016-02-03 14:23:40 --> Database Driver Class Initialized
INFO - 2016-02-03 14:23:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:23:41 --> Controller Class Initialized
INFO - 2016-02-03 14:23:41 --> Model Class Initialized
INFO - 2016-02-03 14:23:41 --> Model Class Initialized
INFO - 2016-02-03 14:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:23:41 --> Pagination Class Initialized
INFO - 2016-02-03 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:23:41 --> Final output sent to browser
DEBUG - 2016-02-03 14:23:41 --> Total execution time: 1.1266
INFO - 2016-02-03 14:25:32 --> Config Class Initialized
INFO - 2016-02-03 14:25:32 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:25:32 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:25:32 --> Utf8 Class Initialized
INFO - 2016-02-03 14:25:32 --> URI Class Initialized
DEBUG - 2016-02-03 14:25:32 --> No URI present. Default controller set.
INFO - 2016-02-03 14:25:32 --> Router Class Initialized
INFO - 2016-02-03 14:25:32 --> Output Class Initialized
INFO - 2016-02-03 14:25:32 --> Security Class Initialized
DEBUG - 2016-02-03 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:25:32 --> Input Class Initialized
INFO - 2016-02-03 14:25:32 --> Language Class Initialized
INFO - 2016-02-03 14:25:32 --> Loader Class Initialized
INFO - 2016-02-03 14:25:32 --> Helper loaded: url_helper
INFO - 2016-02-03 14:25:32 --> Helper loaded: file_helper
INFO - 2016-02-03 14:25:32 --> Helper loaded: date_helper
INFO - 2016-02-03 14:25:32 --> Database Driver Class Initialized
INFO - 2016-02-03 14:25:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:25:33 --> Controller Class Initialized
INFO - 2016-02-03 14:25:33 --> Model Class Initialized
INFO - 2016-02-03 14:25:33 --> Model Class Initialized
INFO - 2016-02-03 14:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:25:33 --> Pagination Class Initialized
INFO - 2016-02-03 14:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:25:33 --> Final output sent to browser
DEBUG - 2016-02-03 14:25:33 --> Total execution time: 1.1491
INFO - 2016-02-03 14:27:59 --> Config Class Initialized
INFO - 2016-02-03 14:27:59 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:27:59 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:27:59 --> Utf8 Class Initialized
INFO - 2016-02-03 14:27:59 --> URI Class Initialized
DEBUG - 2016-02-03 14:27:59 --> No URI present. Default controller set.
INFO - 2016-02-03 14:27:59 --> Router Class Initialized
INFO - 2016-02-03 14:28:00 --> Output Class Initialized
INFO - 2016-02-03 14:28:00 --> Security Class Initialized
DEBUG - 2016-02-03 14:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:28:00 --> Input Class Initialized
INFO - 2016-02-03 14:28:00 --> Language Class Initialized
INFO - 2016-02-03 14:28:00 --> Loader Class Initialized
INFO - 2016-02-03 14:28:00 --> Helper loaded: url_helper
INFO - 2016-02-03 14:28:00 --> Helper loaded: file_helper
INFO - 2016-02-03 14:28:00 --> Helper loaded: date_helper
INFO - 2016-02-03 14:28:00 --> Database Driver Class Initialized
INFO - 2016-02-03 14:28:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:28:01 --> Controller Class Initialized
INFO - 2016-02-03 14:28:01 --> Model Class Initialized
INFO - 2016-02-03 14:28:01 --> Model Class Initialized
INFO - 2016-02-03 14:28:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:28:01 --> Pagination Class Initialized
INFO - 2016-02-03 14:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:28:01 --> Final output sent to browser
DEBUG - 2016-02-03 14:28:01 --> Total execution time: 1.1380
INFO - 2016-02-03 14:30:08 --> Config Class Initialized
INFO - 2016-02-03 14:30:08 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:30:08 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:30:08 --> Utf8 Class Initialized
INFO - 2016-02-03 14:30:08 --> URI Class Initialized
DEBUG - 2016-02-03 14:30:08 --> No URI present. Default controller set.
INFO - 2016-02-03 14:30:08 --> Router Class Initialized
INFO - 2016-02-03 14:30:08 --> Output Class Initialized
INFO - 2016-02-03 14:30:08 --> Security Class Initialized
DEBUG - 2016-02-03 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:30:08 --> Input Class Initialized
INFO - 2016-02-03 14:30:08 --> Language Class Initialized
INFO - 2016-02-03 14:30:08 --> Loader Class Initialized
INFO - 2016-02-03 14:30:08 --> Helper loaded: url_helper
INFO - 2016-02-03 14:30:08 --> Helper loaded: file_helper
INFO - 2016-02-03 14:30:08 --> Helper loaded: date_helper
INFO - 2016-02-03 14:30:08 --> Database Driver Class Initialized
INFO - 2016-02-03 14:30:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:30:09 --> Controller Class Initialized
INFO - 2016-02-03 14:30:09 --> Model Class Initialized
INFO - 2016-02-03 14:30:09 --> Model Class Initialized
INFO - 2016-02-03 14:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:30:09 --> Pagination Class Initialized
INFO - 2016-02-03 14:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:30:09 --> Final output sent to browser
DEBUG - 2016-02-03 14:30:09 --> Total execution time: 1.1083
INFO - 2016-02-03 14:31:05 --> Config Class Initialized
INFO - 2016-02-03 14:31:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:31:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:31:05 --> Utf8 Class Initialized
INFO - 2016-02-03 14:31:05 --> URI Class Initialized
DEBUG - 2016-02-03 14:31:05 --> No URI present. Default controller set.
INFO - 2016-02-03 14:31:05 --> Router Class Initialized
INFO - 2016-02-03 14:31:05 --> Output Class Initialized
INFO - 2016-02-03 14:31:05 --> Security Class Initialized
DEBUG - 2016-02-03 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:31:05 --> Input Class Initialized
INFO - 2016-02-03 14:31:05 --> Language Class Initialized
INFO - 2016-02-03 14:31:05 --> Loader Class Initialized
INFO - 2016-02-03 14:31:05 --> Helper loaded: url_helper
INFO - 2016-02-03 14:31:05 --> Helper loaded: file_helper
INFO - 2016-02-03 14:31:05 --> Helper loaded: date_helper
INFO - 2016-02-03 14:31:05 --> Database Driver Class Initialized
INFO - 2016-02-03 14:31:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:31:06 --> Controller Class Initialized
INFO - 2016-02-03 14:31:06 --> Model Class Initialized
INFO - 2016-02-03 14:31:06 --> Model Class Initialized
INFO - 2016-02-03 14:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:31:06 --> Pagination Class Initialized
INFO - 2016-02-03 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:31:06 --> Final output sent to browser
DEBUG - 2016-02-03 14:31:06 --> Total execution time: 1.1331
INFO - 2016-02-03 14:33:15 --> Config Class Initialized
INFO - 2016-02-03 14:33:15 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:33:15 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:33:15 --> Utf8 Class Initialized
INFO - 2016-02-03 14:33:15 --> URI Class Initialized
DEBUG - 2016-02-03 14:33:15 --> No URI present. Default controller set.
INFO - 2016-02-03 14:33:15 --> Router Class Initialized
INFO - 2016-02-03 14:33:15 --> Output Class Initialized
INFO - 2016-02-03 14:33:15 --> Security Class Initialized
DEBUG - 2016-02-03 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:33:15 --> Input Class Initialized
INFO - 2016-02-03 14:33:15 --> Language Class Initialized
INFO - 2016-02-03 14:33:15 --> Loader Class Initialized
INFO - 2016-02-03 14:33:15 --> Helper loaded: url_helper
INFO - 2016-02-03 14:33:15 --> Helper loaded: file_helper
INFO - 2016-02-03 14:33:15 --> Helper loaded: date_helper
INFO - 2016-02-03 14:33:15 --> Database Driver Class Initialized
INFO - 2016-02-03 14:33:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:33:16 --> Controller Class Initialized
INFO - 2016-02-03 14:33:16 --> Model Class Initialized
INFO - 2016-02-03 14:33:16 --> Model Class Initialized
INFO - 2016-02-03 14:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:33:16 --> Pagination Class Initialized
INFO - 2016-02-03 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:33:16 --> Final output sent to browser
DEBUG - 2016-02-03 14:33:16 --> Total execution time: 1.2226
INFO - 2016-02-03 14:37:04 --> Config Class Initialized
INFO - 2016-02-03 14:37:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:37:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:37:04 --> Utf8 Class Initialized
INFO - 2016-02-03 14:37:04 --> URI Class Initialized
DEBUG - 2016-02-03 14:37:04 --> No URI present. Default controller set.
INFO - 2016-02-03 14:37:04 --> Router Class Initialized
INFO - 2016-02-03 14:37:04 --> Output Class Initialized
INFO - 2016-02-03 14:37:04 --> Security Class Initialized
DEBUG - 2016-02-03 14:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:37:04 --> Input Class Initialized
INFO - 2016-02-03 14:37:04 --> Language Class Initialized
INFO - 2016-02-03 14:37:04 --> Loader Class Initialized
INFO - 2016-02-03 14:37:04 --> Helper loaded: url_helper
INFO - 2016-02-03 14:37:04 --> Helper loaded: file_helper
INFO - 2016-02-03 14:37:04 --> Helper loaded: date_helper
INFO - 2016-02-03 14:37:04 --> Database Driver Class Initialized
INFO - 2016-02-03 14:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:37:05 --> Controller Class Initialized
INFO - 2016-02-03 14:37:05 --> Model Class Initialized
INFO - 2016-02-03 14:37:05 --> Model Class Initialized
INFO - 2016-02-03 14:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:37:05 --> Pagination Class Initialized
INFO - 2016-02-03 14:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:37:05 --> Final output sent to browser
DEBUG - 2016-02-03 14:37:05 --> Total execution time: 1.1063
INFO - 2016-02-03 14:37:53 --> Config Class Initialized
INFO - 2016-02-03 14:37:53 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:37:53 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:37:53 --> Utf8 Class Initialized
INFO - 2016-02-03 14:37:53 --> URI Class Initialized
DEBUG - 2016-02-03 14:37:53 --> No URI present. Default controller set.
INFO - 2016-02-03 14:37:53 --> Router Class Initialized
INFO - 2016-02-03 14:37:53 --> Output Class Initialized
INFO - 2016-02-03 14:37:53 --> Security Class Initialized
DEBUG - 2016-02-03 14:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:37:53 --> Input Class Initialized
INFO - 2016-02-03 14:37:53 --> Language Class Initialized
INFO - 2016-02-03 14:37:53 --> Loader Class Initialized
INFO - 2016-02-03 14:37:53 --> Helper loaded: url_helper
INFO - 2016-02-03 14:37:53 --> Helper loaded: file_helper
INFO - 2016-02-03 14:37:53 --> Helper loaded: date_helper
INFO - 2016-02-03 14:37:53 --> Database Driver Class Initialized
INFO - 2016-02-03 14:37:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:37:54 --> Controller Class Initialized
INFO - 2016-02-03 14:37:54 --> Model Class Initialized
INFO - 2016-02-03 14:37:54 --> Model Class Initialized
INFO - 2016-02-03 14:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:37:54 --> Pagination Class Initialized
INFO - 2016-02-03 14:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:37:54 --> Final output sent to browser
DEBUG - 2016-02-03 14:37:54 --> Total execution time: 1.1290
INFO - 2016-02-03 14:38:05 --> Config Class Initialized
INFO - 2016-02-03 14:38:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:38:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:38:05 --> Utf8 Class Initialized
INFO - 2016-02-03 14:38:05 --> URI Class Initialized
DEBUG - 2016-02-03 14:38:05 --> No URI present. Default controller set.
INFO - 2016-02-03 14:38:05 --> Router Class Initialized
INFO - 2016-02-03 14:38:05 --> Output Class Initialized
INFO - 2016-02-03 14:38:05 --> Security Class Initialized
DEBUG - 2016-02-03 14:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:38:05 --> Input Class Initialized
INFO - 2016-02-03 14:38:05 --> Language Class Initialized
INFO - 2016-02-03 14:38:05 --> Loader Class Initialized
INFO - 2016-02-03 14:38:05 --> Helper loaded: url_helper
INFO - 2016-02-03 14:38:05 --> Helper loaded: file_helper
INFO - 2016-02-03 14:38:05 --> Helper loaded: date_helper
INFO - 2016-02-03 14:38:05 --> Database Driver Class Initialized
INFO - 2016-02-03 14:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:38:06 --> Controller Class Initialized
INFO - 2016-02-03 14:38:06 --> Model Class Initialized
INFO - 2016-02-03 14:38:06 --> Model Class Initialized
INFO - 2016-02-03 14:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:38:06 --> Pagination Class Initialized
INFO - 2016-02-03 14:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:38:06 --> Final output sent to browser
DEBUG - 2016-02-03 14:38:06 --> Total execution time: 1.1345
INFO - 2016-02-03 14:39:04 --> Config Class Initialized
INFO - 2016-02-03 14:39:04 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:39:04 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:39:04 --> Utf8 Class Initialized
INFO - 2016-02-03 14:39:04 --> URI Class Initialized
DEBUG - 2016-02-03 14:39:04 --> No URI present. Default controller set.
INFO - 2016-02-03 14:39:04 --> Router Class Initialized
INFO - 2016-02-03 14:39:04 --> Output Class Initialized
INFO - 2016-02-03 14:39:04 --> Security Class Initialized
DEBUG - 2016-02-03 14:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:39:04 --> Input Class Initialized
INFO - 2016-02-03 14:39:04 --> Language Class Initialized
INFO - 2016-02-03 14:39:04 --> Loader Class Initialized
INFO - 2016-02-03 14:39:04 --> Helper loaded: url_helper
INFO - 2016-02-03 14:39:04 --> Helper loaded: file_helper
INFO - 2016-02-03 14:39:04 --> Helper loaded: date_helper
INFO - 2016-02-03 14:39:04 --> Database Driver Class Initialized
INFO - 2016-02-03 14:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:39:05 --> Controller Class Initialized
INFO - 2016-02-03 14:39:05 --> Model Class Initialized
INFO - 2016-02-03 14:39:05 --> Model Class Initialized
INFO - 2016-02-03 14:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:39:05 --> Pagination Class Initialized
INFO - 2016-02-03 14:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:39:05 --> Final output sent to browser
DEBUG - 2016-02-03 14:39:05 --> Total execution time: 1.1265
INFO - 2016-02-03 14:39:20 --> Config Class Initialized
INFO - 2016-02-03 14:39:20 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:39:20 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:39:20 --> Utf8 Class Initialized
INFO - 2016-02-03 14:39:20 --> URI Class Initialized
INFO - 2016-02-03 14:39:20 --> Router Class Initialized
INFO - 2016-02-03 14:39:20 --> Output Class Initialized
INFO - 2016-02-03 14:39:20 --> Security Class Initialized
DEBUG - 2016-02-03 14:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:39:20 --> Input Class Initialized
INFO - 2016-02-03 14:39:20 --> Language Class Initialized
INFO - 2016-02-03 14:39:20 --> Loader Class Initialized
INFO - 2016-02-03 14:39:20 --> Helper loaded: url_helper
INFO - 2016-02-03 14:39:20 --> Helper loaded: file_helper
INFO - 2016-02-03 14:39:20 --> Helper loaded: date_helper
INFO - 2016-02-03 14:39:20 --> Database Driver Class Initialized
INFO - 2016-02-03 14:39:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:39:21 --> Controller Class Initialized
INFO - 2016-02-03 14:39:21 --> Model Class Initialized
INFO - 2016-02-03 14:39:21 --> Model Class Initialized
INFO - 2016-02-03 14:39:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:39:21 --> Pagination Class Initialized
INFO - 2016-02-03 14:39:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:39:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:39:21 --> Helper loaded: text_helper
INFO - 2016-02-03 14:39:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 14:39:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 14:39:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:39:21 --> Final output sent to browser
DEBUG - 2016-02-03 14:39:21 --> Total execution time: 1.1524
INFO - 2016-02-03 14:39:34 --> Config Class Initialized
INFO - 2016-02-03 14:39:34 --> Hooks Class Initialized
DEBUG - 2016-02-03 14:39:34 --> UTF-8 Support Enabled
INFO - 2016-02-03 14:39:34 --> Utf8 Class Initialized
INFO - 2016-02-03 14:39:34 --> URI Class Initialized
DEBUG - 2016-02-03 14:39:34 --> No URI present. Default controller set.
INFO - 2016-02-03 14:39:34 --> Router Class Initialized
INFO - 2016-02-03 14:39:34 --> Output Class Initialized
INFO - 2016-02-03 14:39:34 --> Security Class Initialized
DEBUG - 2016-02-03 14:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 14:39:34 --> Input Class Initialized
INFO - 2016-02-03 14:39:34 --> Language Class Initialized
INFO - 2016-02-03 14:39:34 --> Loader Class Initialized
INFO - 2016-02-03 14:39:34 --> Helper loaded: url_helper
INFO - 2016-02-03 14:39:34 --> Helper loaded: file_helper
INFO - 2016-02-03 14:39:34 --> Helper loaded: date_helper
INFO - 2016-02-03 14:39:34 --> Database Driver Class Initialized
INFO - 2016-02-03 14:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 14:39:35 --> Controller Class Initialized
INFO - 2016-02-03 14:39:35 --> Model Class Initialized
INFO - 2016-02-03 14:39:35 --> Model Class Initialized
INFO - 2016-02-03 14:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 14:39:35 --> Pagination Class Initialized
INFO - 2016-02-03 14:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 14:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 14:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 14:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 14:39:35 --> Final output sent to browser
DEBUG - 2016-02-03 14:39:35 --> Total execution time: 1.1467
INFO - 2016-02-03 16:45:42 --> Config Class Initialized
INFO - 2016-02-03 16:45:42 --> Hooks Class Initialized
DEBUG - 2016-02-03 16:45:42 --> UTF-8 Support Enabled
INFO - 2016-02-03 16:45:42 --> Utf8 Class Initialized
INFO - 2016-02-03 16:45:42 --> URI Class Initialized
INFO - 2016-02-03 16:45:42 --> Router Class Initialized
INFO - 2016-02-03 16:45:42 --> Output Class Initialized
INFO - 2016-02-03 16:45:42 --> Security Class Initialized
DEBUG - 2016-02-03 16:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 16:45:42 --> Input Class Initialized
INFO - 2016-02-03 16:45:42 --> Language Class Initialized
INFO - 2016-02-03 16:45:42 --> Loader Class Initialized
INFO - 2016-02-03 16:45:42 --> Helper loaded: url_helper
INFO - 2016-02-03 16:45:42 --> Helper loaded: file_helper
INFO - 2016-02-03 16:45:42 --> Helper loaded: date_helper
INFO - 2016-02-03 16:45:42 --> Database Driver Class Initialized
INFO - 2016-02-03 16:45:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 16:45:43 --> Controller Class Initialized
INFO - 2016-02-03 16:45:43 --> Model Class Initialized
INFO - 2016-02-03 16:45:43 --> Model Class Initialized
INFO - 2016-02-03 16:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 16:45:43 --> Pagination Class Initialized
INFO - 2016-02-03 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 16:45:43 --> Helper loaded: text_helper
INFO - 2016-02-03 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 16:45:43 --> Final output sent to browser
DEBUG - 2016-02-03 16:45:43 --> Total execution time: 1.1719
INFO - 2016-02-03 16:52:05 --> Config Class Initialized
INFO - 2016-02-03 16:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-03 16:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-03 16:52:05 --> Utf8 Class Initialized
INFO - 2016-02-03 16:52:05 --> URI Class Initialized
INFO - 2016-02-03 16:52:05 --> Router Class Initialized
INFO - 2016-02-03 16:52:05 --> Output Class Initialized
INFO - 2016-02-03 16:52:05 --> Security Class Initialized
DEBUG - 2016-02-03 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 16:52:05 --> Input Class Initialized
INFO - 2016-02-03 16:52:05 --> Language Class Initialized
INFO - 2016-02-03 16:52:05 --> Loader Class Initialized
INFO - 2016-02-03 16:52:05 --> Helper loaded: url_helper
INFO - 2016-02-03 16:52:05 --> Helper loaded: file_helper
INFO - 2016-02-03 16:52:05 --> Helper loaded: date_helper
INFO - 2016-02-03 16:52:05 --> Database Driver Class Initialized
INFO - 2016-02-03 16:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 16:52:06 --> Controller Class Initialized
INFO - 2016-02-03 16:52:06 --> Model Class Initialized
INFO - 2016-02-03 16:52:06 --> Model Class Initialized
INFO - 2016-02-03 16:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 16:52:06 --> Pagination Class Initialized
INFO - 2016-02-03 16:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 16:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 16:52:06 --> Helper loaded: text_helper
INFO - 2016-02-03 16:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 16:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 16:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 16:52:07 --> Final output sent to browser
DEBUG - 2016-02-03 16:52:07 --> Total execution time: 1.1961
INFO - 2016-02-03 17:39:55 --> Config Class Initialized
INFO - 2016-02-03 17:39:55 --> Hooks Class Initialized
DEBUG - 2016-02-03 17:39:55 --> UTF-8 Support Enabled
INFO - 2016-02-03 17:39:55 --> Utf8 Class Initialized
INFO - 2016-02-03 17:39:55 --> URI Class Initialized
DEBUG - 2016-02-03 17:39:55 --> No URI present. Default controller set.
INFO - 2016-02-03 17:39:55 --> Router Class Initialized
INFO - 2016-02-03 17:39:55 --> Output Class Initialized
INFO - 2016-02-03 17:39:55 --> Security Class Initialized
DEBUG - 2016-02-03 17:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 17:39:55 --> Input Class Initialized
INFO - 2016-02-03 17:39:55 --> Language Class Initialized
INFO - 2016-02-03 17:39:55 --> Loader Class Initialized
INFO - 2016-02-03 17:39:55 --> Helper loaded: url_helper
INFO - 2016-02-03 17:39:55 --> Helper loaded: file_helper
INFO - 2016-02-03 17:39:55 --> Helper loaded: date_helper
INFO - 2016-02-03 17:39:55 --> Database Driver Class Initialized
INFO - 2016-02-03 17:39:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 17:39:56 --> Controller Class Initialized
INFO - 2016-02-03 17:39:56 --> Model Class Initialized
INFO - 2016-02-03 17:39:56 --> Model Class Initialized
INFO - 2016-02-03 17:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 17:39:56 --> Pagination Class Initialized
INFO - 2016-02-03 17:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 17:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 17:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-03 17:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 17:39:56 --> Final output sent to browser
DEBUG - 2016-02-03 17:39:56 --> Total execution time: 1.1468
INFO - 2016-02-03 17:39:58 --> Config Class Initialized
INFO - 2016-02-03 17:39:58 --> Hooks Class Initialized
DEBUG - 2016-02-03 17:39:58 --> UTF-8 Support Enabled
INFO - 2016-02-03 17:39:58 --> Utf8 Class Initialized
INFO - 2016-02-03 17:39:58 --> URI Class Initialized
INFO - 2016-02-03 17:39:58 --> Router Class Initialized
INFO - 2016-02-03 17:39:58 --> Output Class Initialized
INFO - 2016-02-03 17:39:58 --> Security Class Initialized
DEBUG - 2016-02-03 17:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-03 17:39:58 --> Input Class Initialized
INFO - 2016-02-03 17:39:58 --> Language Class Initialized
INFO - 2016-02-03 17:39:58 --> Loader Class Initialized
INFO - 2016-02-03 17:39:58 --> Helper loaded: url_helper
INFO - 2016-02-03 17:39:58 --> Helper loaded: file_helper
INFO - 2016-02-03 17:39:58 --> Helper loaded: date_helper
INFO - 2016-02-03 17:39:58 --> Database Driver Class Initialized
INFO - 2016-02-03 17:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-03 17:39:59 --> Controller Class Initialized
INFO - 2016-02-03 17:39:59 --> Model Class Initialized
INFO - 2016-02-03 17:39:59 --> Model Class Initialized
INFO - 2016-02-03 17:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-03 17:39:59 --> Pagination Class Initialized
INFO - 2016-02-03 17:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-03 17:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-03 17:39:59 --> Helper loaded: text_helper
INFO - 2016-02-03 17:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-03 17:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-03 17:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-03 17:39:59 --> Final output sent to browser
DEBUG - 2016-02-03 17:39:59 --> Total execution time: 1.1868
