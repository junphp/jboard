<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-30 08:46:40 --> Config Class Initialized
INFO - 2016-01-30 08:46:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 08:46:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 08:46:40 --> Utf8 Class Initialized
INFO - 2016-01-30 08:46:40 --> URI Class Initialized
DEBUG - 2016-01-30 08:46:40 --> No URI present. Default controller set.
INFO - 2016-01-30 08:46:40 --> Router Class Initialized
INFO - 2016-01-30 08:46:40 --> Output Class Initialized
INFO - 2016-01-30 08:46:40 --> Security Class Initialized
DEBUG - 2016-01-30 08:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 08:46:40 --> Input Class Initialized
INFO - 2016-01-30 08:46:40 --> Language Class Initialized
INFO - 2016-01-30 08:46:40 --> Loader Class Initialized
INFO - 2016-01-30 08:46:40 --> Helper loaded: url_helper
INFO - 2016-01-30 08:46:40 --> Helper loaded: file_helper
INFO - 2016-01-30 08:46:40 --> Helper loaded: date_helper
INFO - 2016-01-30 08:46:40 --> Database Driver Class Initialized
INFO - 2016-01-30 08:46:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 08:46:41 --> Controller Class Initialized
INFO - 2016-01-30 08:46:41 --> Model Class Initialized
INFO - 2016-01-30 08:46:41 --> Model Class Initialized
INFO - 2016-01-30 08:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 08:46:41 --> Pagination Class Initialized
INFO - 2016-01-30 08:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 08:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 08:46:41 --> Final output sent to browser
DEBUG - 2016-01-30 08:46:41 --> Total execution time: 1.1197
INFO - 2016-01-30 09:05:44 --> Config Class Initialized
INFO - 2016-01-30 09:05:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:05:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:05:44 --> Utf8 Class Initialized
INFO - 2016-01-30 09:05:44 --> URI Class Initialized
DEBUG - 2016-01-30 09:05:44 --> No URI present. Default controller set.
INFO - 2016-01-30 09:05:44 --> Router Class Initialized
INFO - 2016-01-30 09:05:44 --> Output Class Initialized
INFO - 2016-01-30 09:05:44 --> Security Class Initialized
DEBUG - 2016-01-30 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:05:44 --> Input Class Initialized
INFO - 2016-01-30 09:05:44 --> Language Class Initialized
INFO - 2016-01-30 09:05:44 --> Loader Class Initialized
INFO - 2016-01-30 09:05:44 --> Helper loaded: url_helper
INFO - 2016-01-30 09:05:44 --> Helper loaded: file_helper
INFO - 2016-01-30 09:05:44 --> Helper loaded: date_helper
INFO - 2016-01-30 09:05:44 --> Database Driver Class Initialized
INFO - 2016-01-30 09:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:05:45 --> Controller Class Initialized
INFO - 2016-01-30 09:05:45 --> Model Class Initialized
INFO - 2016-01-30 09:05:45 --> Model Class Initialized
INFO - 2016-01-30 09:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:05:45 --> Pagination Class Initialized
INFO - 2016-01-30 09:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:05:45 --> Final output sent to browser
DEBUG - 2016-01-30 09:05:45 --> Total execution time: 1.1138
INFO - 2016-01-30 09:07:43 --> Config Class Initialized
INFO - 2016-01-30 09:07:43 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:07:43 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:07:43 --> Utf8 Class Initialized
INFO - 2016-01-30 09:07:43 --> URI Class Initialized
DEBUG - 2016-01-30 09:07:43 --> No URI present. Default controller set.
INFO - 2016-01-30 09:07:43 --> Router Class Initialized
INFO - 2016-01-30 09:07:43 --> Output Class Initialized
INFO - 2016-01-30 09:07:43 --> Security Class Initialized
DEBUG - 2016-01-30 09:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:07:43 --> Input Class Initialized
INFO - 2016-01-30 09:07:43 --> Language Class Initialized
INFO - 2016-01-30 09:07:43 --> Loader Class Initialized
INFO - 2016-01-30 09:07:43 --> Helper loaded: url_helper
INFO - 2016-01-30 09:07:43 --> Helper loaded: file_helper
INFO - 2016-01-30 09:07:43 --> Helper loaded: date_helper
INFO - 2016-01-30 09:07:43 --> Database Driver Class Initialized
INFO - 2016-01-30 09:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:07:44 --> Controller Class Initialized
INFO - 2016-01-30 09:07:44 --> Model Class Initialized
INFO - 2016-01-30 09:07:44 --> Model Class Initialized
INFO - 2016-01-30 09:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:07:44 --> Pagination Class Initialized
INFO - 2016-01-30 09:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:07:44 --> Final output sent to browser
DEBUG - 2016-01-30 09:07:44 --> Total execution time: 1.1370
INFO - 2016-01-30 09:08:11 --> Config Class Initialized
INFO - 2016-01-30 09:08:11 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:08:11 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:08:11 --> Utf8 Class Initialized
INFO - 2016-01-30 09:08:11 --> URI Class Initialized
DEBUG - 2016-01-30 09:08:11 --> No URI present. Default controller set.
INFO - 2016-01-30 09:08:11 --> Router Class Initialized
INFO - 2016-01-30 09:08:11 --> Output Class Initialized
INFO - 2016-01-30 09:08:11 --> Security Class Initialized
DEBUG - 2016-01-30 09:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:08:11 --> Input Class Initialized
INFO - 2016-01-30 09:08:11 --> Language Class Initialized
INFO - 2016-01-30 09:08:11 --> Loader Class Initialized
INFO - 2016-01-30 09:08:11 --> Helper loaded: url_helper
INFO - 2016-01-30 09:08:11 --> Helper loaded: file_helper
INFO - 2016-01-30 09:08:11 --> Helper loaded: date_helper
INFO - 2016-01-30 09:08:11 --> Database Driver Class Initialized
INFO - 2016-01-30 09:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:08:12 --> Controller Class Initialized
INFO - 2016-01-30 09:08:12 --> Model Class Initialized
INFO - 2016-01-30 09:08:12 --> Model Class Initialized
INFO - 2016-01-30 09:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:08:12 --> Pagination Class Initialized
INFO - 2016-01-30 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:08:12 --> Final output sent to browser
DEBUG - 2016-01-30 09:08:12 --> Total execution time: 1.1604
INFO - 2016-01-30 09:09:21 --> Config Class Initialized
INFO - 2016-01-30 09:09:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:09:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:09:21 --> Utf8 Class Initialized
INFO - 2016-01-30 09:09:21 --> URI Class Initialized
DEBUG - 2016-01-30 09:09:21 --> No URI present. Default controller set.
INFO - 2016-01-30 09:09:21 --> Router Class Initialized
INFO - 2016-01-30 09:09:21 --> Output Class Initialized
INFO - 2016-01-30 09:09:21 --> Security Class Initialized
DEBUG - 2016-01-30 09:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:09:21 --> Input Class Initialized
INFO - 2016-01-30 09:09:21 --> Language Class Initialized
INFO - 2016-01-30 09:09:21 --> Loader Class Initialized
INFO - 2016-01-30 09:09:21 --> Helper loaded: url_helper
INFO - 2016-01-30 09:09:21 --> Helper loaded: file_helper
INFO - 2016-01-30 09:09:21 --> Helper loaded: date_helper
INFO - 2016-01-30 09:09:21 --> Database Driver Class Initialized
INFO - 2016-01-30 09:09:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:09:22 --> Controller Class Initialized
INFO - 2016-01-30 09:09:22 --> Model Class Initialized
INFO - 2016-01-30 09:09:22 --> Model Class Initialized
INFO - 2016-01-30 09:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:09:22 --> Pagination Class Initialized
INFO - 2016-01-30 09:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:09:22 --> Final output sent to browser
DEBUG - 2016-01-30 09:09:22 --> Total execution time: 1.1457
INFO - 2016-01-30 09:10:18 --> Config Class Initialized
INFO - 2016-01-30 09:10:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:10:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:10:18 --> Utf8 Class Initialized
INFO - 2016-01-30 09:10:18 --> URI Class Initialized
DEBUG - 2016-01-30 09:10:18 --> No URI present. Default controller set.
INFO - 2016-01-30 09:10:18 --> Router Class Initialized
INFO - 2016-01-30 09:10:18 --> Output Class Initialized
INFO - 2016-01-30 09:10:18 --> Security Class Initialized
DEBUG - 2016-01-30 09:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:10:18 --> Input Class Initialized
INFO - 2016-01-30 09:10:18 --> Language Class Initialized
INFO - 2016-01-30 09:10:18 --> Loader Class Initialized
INFO - 2016-01-30 09:10:18 --> Helper loaded: url_helper
INFO - 2016-01-30 09:10:18 --> Helper loaded: file_helper
INFO - 2016-01-30 09:10:18 --> Helper loaded: date_helper
INFO - 2016-01-30 09:10:18 --> Database Driver Class Initialized
INFO - 2016-01-30 09:10:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:10:19 --> Controller Class Initialized
INFO - 2016-01-30 09:10:19 --> Model Class Initialized
INFO - 2016-01-30 09:10:19 --> Model Class Initialized
INFO - 2016-01-30 09:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:10:19 --> Pagination Class Initialized
INFO - 2016-01-30 09:10:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:10:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:10:19 --> Final output sent to browser
DEBUG - 2016-01-30 09:10:19 --> Total execution time: 1.1632
INFO - 2016-01-30 09:11:45 --> Config Class Initialized
INFO - 2016-01-30 09:11:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:11:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:11:45 --> Utf8 Class Initialized
INFO - 2016-01-30 09:11:45 --> URI Class Initialized
DEBUG - 2016-01-30 09:11:45 --> No URI present. Default controller set.
INFO - 2016-01-30 09:11:45 --> Router Class Initialized
INFO - 2016-01-30 09:11:45 --> Output Class Initialized
INFO - 2016-01-30 09:11:45 --> Security Class Initialized
DEBUG - 2016-01-30 09:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:11:45 --> Input Class Initialized
INFO - 2016-01-30 09:11:45 --> Language Class Initialized
INFO - 2016-01-30 09:11:45 --> Loader Class Initialized
INFO - 2016-01-30 09:11:45 --> Helper loaded: url_helper
INFO - 2016-01-30 09:11:45 --> Helper loaded: file_helper
INFO - 2016-01-30 09:11:45 --> Helper loaded: date_helper
INFO - 2016-01-30 09:11:45 --> Database Driver Class Initialized
INFO - 2016-01-30 09:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:11:46 --> Controller Class Initialized
INFO - 2016-01-30 09:11:46 --> Model Class Initialized
INFO - 2016-01-30 09:11:46 --> Model Class Initialized
INFO - 2016-01-30 09:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:11:46 --> Pagination Class Initialized
INFO - 2016-01-30 09:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:11:46 --> Final output sent to browser
DEBUG - 2016-01-30 09:11:46 --> Total execution time: 1.1604
INFO - 2016-01-30 09:12:40 --> Config Class Initialized
INFO - 2016-01-30 09:12:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:12:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:12:40 --> Utf8 Class Initialized
INFO - 2016-01-30 09:12:40 --> URI Class Initialized
DEBUG - 2016-01-30 09:12:40 --> No URI present. Default controller set.
INFO - 2016-01-30 09:12:40 --> Router Class Initialized
INFO - 2016-01-30 09:12:40 --> Output Class Initialized
INFO - 2016-01-30 09:12:40 --> Security Class Initialized
DEBUG - 2016-01-30 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:12:40 --> Input Class Initialized
INFO - 2016-01-30 09:12:40 --> Language Class Initialized
INFO - 2016-01-30 09:12:40 --> Loader Class Initialized
INFO - 2016-01-30 09:12:40 --> Helper loaded: url_helper
INFO - 2016-01-30 09:12:40 --> Helper loaded: file_helper
INFO - 2016-01-30 09:12:40 --> Helper loaded: date_helper
INFO - 2016-01-30 09:12:40 --> Database Driver Class Initialized
INFO - 2016-01-30 09:12:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:12:42 --> Controller Class Initialized
INFO - 2016-01-30 09:12:42 --> Model Class Initialized
INFO - 2016-01-30 09:12:42 --> Model Class Initialized
INFO - 2016-01-30 09:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:12:42 --> Pagination Class Initialized
INFO - 2016-01-30 09:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:12:42 --> Final output sent to browser
DEBUG - 2016-01-30 09:12:42 --> Total execution time: 1.1582
INFO - 2016-01-30 09:13:15 --> Config Class Initialized
INFO - 2016-01-30 09:13:15 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:13:15 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:13:15 --> Utf8 Class Initialized
INFO - 2016-01-30 09:13:15 --> URI Class Initialized
DEBUG - 2016-01-30 09:13:15 --> No URI present. Default controller set.
INFO - 2016-01-30 09:13:15 --> Router Class Initialized
INFO - 2016-01-30 09:13:15 --> Output Class Initialized
INFO - 2016-01-30 09:13:15 --> Security Class Initialized
DEBUG - 2016-01-30 09:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:13:15 --> Input Class Initialized
INFO - 2016-01-30 09:13:15 --> Language Class Initialized
INFO - 2016-01-30 09:13:15 --> Loader Class Initialized
INFO - 2016-01-30 09:13:15 --> Helper loaded: url_helper
INFO - 2016-01-30 09:13:15 --> Helper loaded: file_helper
INFO - 2016-01-30 09:13:15 --> Helper loaded: date_helper
INFO - 2016-01-30 09:13:15 --> Database Driver Class Initialized
INFO - 2016-01-30 09:13:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:13:16 --> Controller Class Initialized
INFO - 2016-01-30 09:13:16 --> Model Class Initialized
INFO - 2016-01-30 09:13:16 --> Model Class Initialized
INFO - 2016-01-30 09:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:13:16 --> Pagination Class Initialized
INFO - 2016-01-30 09:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:13:16 --> Final output sent to browser
DEBUG - 2016-01-30 09:13:16 --> Total execution time: 1.1344
INFO - 2016-01-30 09:13:38 --> Config Class Initialized
INFO - 2016-01-30 09:13:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:13:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:13:39 --> Utf8 Class Initialized
INFO - 2016-01-30 09:13:39 --> URI Class Initialized
DEBUG - 2016-01-30 09:13:39 --> No URI present. Default controller set.
INFO - 2016-01-30 09:13:39 --> Router Class Initialized
INFO - 2016-01-30 09:13:39 --> Output Class Initialized
INFO - 2016-01-30 09:13:39 --> Security Class Initialized
DEBUG - 2016-01-30 09:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:13:39 --> Input Class Initialized
INFO - 2016-01-30 09:13:39 --> Language Class Initialized
INFO - 2016-01-30 09:13:39 --> Loader Class Initialized
INFO - 2016-01-30 09:13:39 --> Helper loaded: url_helper
INFO - 2016-01-30 09:13:39 --> Helper loaded: file_helper
INFO - 2016-01-30 09:13:39 --> Helper loaded: date_helper
INFO - 2016-01-30 09:13:39 --> Database Driver Class Initialized
INFO - 2016-01-30 09:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:13:40 --> Controller Class Initialized
INFO - 2016-01-30 09:13:40 --> Model Class Initialized
INFO - 2016-01-30 09:13:40 --> Model Class Initialized
INFO - 2016-01-30 09:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:13:40 --> Pagination Class Initialized
INFO - 2016-01-30 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:13:40 --> Final output sent to browser
DEBUG - 2016-01-30 09:13:40 --> Total execution time: 1.1417
INFO - 2016-01-30 09:14:18 --> Config Class Initialized
INFO - 2016-01-30 09:14:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:14:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:14:18 --> Utf8 Class Initialized
INFO - 2016-01-30 09:14:18 --> URI Class Initialized
DEBUG - 2016-01-30 09:14:18 --> No URI present. Default controller set.
INFO - 2016-01-30 09:14:18 --> Router Class Initialized
INFO - 2016-01-30 09:14:18 --> Output Class Initialized
INFO - 2016-01-30 09:14:18 --> Security Class Initialized
DEBUG - 2016-01-30 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:14:18 --> Input Class Initialized
INFO - 2016-01-30 09:14:18 --> Language Class Initialized
INFO - 2016-01-30 09:14:18 --> Loader Class Initialized
INFO - 2016-01-30 09:14:18 --> Helper loaded: url_helper
INFO - 2016-01-30 09:14:18 --> Helper loaded: file_helper
INFO - 2016-01-30 09:14:18 --> Helper loaded: date_helper
INFO - 2016-01-30 09:14:18 --> Database Driver Class Initialized
INFO - 2016-01-30 09:14:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:14:19 --> Controller Class Initialized
INFO - 2016-01-30 09:14:19 --> Model Class Initialized
INFO - 2016-01-30 09:14:19 --> Model Class Initialized
INFO - 2016-01-30 09:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:14:19 --> Pagination Class Initialized
INFO - 2016-01-30 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:14:19 --> Final output sent to browser
DEBUG - 2016-01-30 09:14:19 --> Total execution time: 1.1606
INFO - 2016-01-30 09:14:24 --> Config Class Initialized
INFO - 2016-01-30 09:14:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:14:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:14:24 --> Utf8 Class Initialized
INFO - 2016-01-30 09:14:24 --> URI Class Initialized
DEBUG - 2016-01-30 09:14:24 --> No URI present. Default controller set.
INFO - 2016-01-30 09:14:24 --> Router Class Initialized
INFO - 2016-01-30 09:14:24 --> Output Class Initialized
INFO - 2016-01-30 09:14:24 --> Security Class Initialized
DEBUG - 2016-01-30 09:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:14:24 --> Input Class Initialized
INFO - 2016-01-30 09:14:24 --> Language Class Initialized
INFO - 2016-01-30 09:14:24 --> Loader Class Initialized
INFO - 2016-01-30 09:14:24 --> Helper loaded: url_helper
INFO - 2016-01-30 09:14:24 --> Helper loaded: file_helper
INFO - 2016-01-30 09:14:24 --> Helper loaded: date_helper
INFO - 2016-01-30 09:14:24 --> Database Driver Class Initialized
INFO - 2016-01-30 09:14:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:14:26 --> Controller Class Initialized
INFO - 2016-01-30 09:14:26 --> Model Class Initialized
INFO - 2016-01-30 09:14:26 --> Model Class Initialized
INFO - 2016-01-30 09:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:14:26 --> Pagination Class Initialized
INFO - 2016-01-30 09:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:14:26 --> Final output sent to browser
DEBUG - 2016-01-30 09:14:26 --> Total execution time: 1.1613
INFO - 2016-01-30 09:21:20 --> Config Class Initialized
INFO - 2016-01-30 09:21:20 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:21:20 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:21:20 --> Utf8 Class Initialized
INFO - 2016-01-30 09:21:20 --> URI Class Initialized
DEBUG - 2016-01-30 09:21:20 --> No URI present. Default controller set.
INFO - 2016-01-30 09:21:20 --> Router Class Initialized
INFO - 2016-01-30 09:21:20 --> Output Class Initialized
INFO - 2016-01-30 09:21:20 --> Security Class Initialized
DEBUG - 2016-01-30 09:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:21:20 --> Input Class Initialized
INFO - 2016-01-30 09:21:20 --> Language Class Initialized
INFO - 2016-01-30 09:21:20 --> Loader Class Initialized
INFO - 2016-01-30 09:21:20 --> Helper loaded: url_helper
INFO - 2016-01-30 09:21:20 --> Helper loaded: file_helper
INFO - 2016-01-30 09:21:20 --> Helper loaded: date_helper
INFO - 2016-01-30 09:21:20 --> Database Driver Class Initialized
INFO - 2016-01-30 09:21:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:21:21 --> Controller Class Initialized
INFO - 2016-01-30 09:21:21 --> Model Class Initialized
INFO - 2016-01-30 09:21:21 --> Model Class Initialized
INFO - 2016-01-30 09:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:21:21 --> Pagination Class Initialized
INFO - 2016-01-30 09:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:21:21 --> Final output sent to browser
DEBUG - 2016-01-30 09:21:21 --> Total execution time: 1.1671
INFO - 2016-01-30 09:24:49 --> Config Class Initialized
INFO - 2016-01-30 09:24:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:24:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:24:49 --> Utf8 Class Initialized
INFO - 2016-01-30 09:24:49 --> URI Class Initialized
DEBUG - 2016-01-30 09:24:49 --> No URI present. Default controller set.
INFO - 2016-01-30 09:24:49 --> Router Class Initialized
INFO - 2016-01-30 09:24:49 --> Output Class Initialized
INFO - 2016-01-30 09:24:49 --> Security Class Initialized
DEBUG - 2016-01-30 09:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:24:49 --> Input Class Initialized
INFO - 2016-01-30 09:24:49 --> Language Class Initialized
INFO - 2016-01-30 09:24:49 --> Loader Class Initialized
INFO - 2016-01-30 09:24:49 --> Helper loaded: url_helper
INFO - 2016-01-30 09:24:49 --> Helper loaded: file_helper
INFO - 2016-01-30 09:24:49 --> Helper loaded: date_helper
INFO - 2016-01-30 09:24:49 --> Database Driver Class Initialized
INFO - 2016-01-30 09:24:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:24:50 --> Controller Class Initialized
INFO - 2016-01-30 09:24:50 --> Model Class Initialized
INFO - 2016-01-30 09:24:50 --> Model Class Initialized
INFO - 2016-01-30 09:24:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:24:50 --> Pagination Class Initialized
INFO - 2016-01-30 09:24:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:24:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:24:50 --> Final output sent to browser
DEBUG - 2016-01-30 09:24:50 --> Total execution time: 1.1490
INFO - 2016-01-30 09:26:16 --> Config Class Initialized
INFO - 2016-01-30 09:26:16 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:26:16 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:26:16 --> Utf8 Class Initialized
INFO - 2016-01-30 09:26:16 --> URI Class Initialized
DEBUG - 2016-01-30 09:26:16 --> No URI present. Default controller set.
INFO - 2016-01-30 09:26:16 --> Router Class Initialized
INFO - 2016-01-30 09:26:16 --> Output Class Initialized
INFO - 2016-01-30 09:26:16 --> Security Class Initialized
DEBUG - 2016-01-30 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:26:16 --> Input Class Initialized
INFO - 2016-01-30 09:26:16 --> Language Class Initialized
INFO - 2016-01-30 09:26:16 --> Loader Class Initialized
INFO - 2016-01-30 09:26:16 --> Helper loaded: url_helper
INFO - 2016-01-30 09:26:16 --> Helper loaded: file_helper
INFO - 2016-01-30 09:26:16 --> Helper loaded: date_helper
INFO - 2016-01-30 09:26:16 --> Database Driver Class Initialized
INFO - 2016-01-30 09:26:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:26:17 --> Controller Class Initialized
INFO - 2016-01-30 09:26:17 --> Model Class Initialized
INFO - 2016-01-30 09:26:17 --> Model Class Initialized
INFO - 2016-01-30 09:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:26:17 --> Pagination Class Initialized
INFO - 2016-01-30 09:26:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:26:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:26:17 --> Final output sent to browser
DEBUG - 2016-01-30 09:26:17 --> Total execution time: 1.1493
INFO - 2016-01-30 09:26:18 --> Config Class Initialized
INFO - 2016-01-30 09:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:26:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:26:18 --> Utf8 Class Initialized
INFO - 2016-01-30 09:26:18 --> URI Class Initialized
INFO - 2016-01-30 09:26:18 --> Router Class Initialized
INFO - 2016-01-30 09:26:18 --> Output Class Initialized
INFO - 2016-01-30 09:26:18 --> Security Class Initialized
DEBUG - 2016-01-30 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:26:18 --> Input Class Initialized
INFO - 2016-01-30 09:26:18 --> Language Class Initialized
INFO - 2016-01-30 09:26:18 --> Loader Class Initialized
INFO - 2016-01-30 09:26:18 --> Helper loaded: url_helper
INFO - 2016-01-30 09:26:18 --> Helper loaded: file_helper
INFO - 2016-01-30 09:26:18 --> Helper loaded: date_helper
INFO - 2016-01-30 09:26:18 --> Database Driver Class Initialized
INFO - 2016-01-30 09:26:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:26:19 --> Controller Class Initialized
INFO - 2016-01-30 09:26:19 --> Model Class Initialized
INFO - 2016-01-30 09:26:19 --> Model Class Initialized
INFO - 2016-01-30 09:26:19 --> Helper loaded: form_helper
INFO - 2016-01-30 09:26:19 --> Form Validation Class Initialized
INFO - 2016-01-30 09:26:19 --> Helper loaded: text_helper
INFO - 2016-01-30 09:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 09:26:19 --> Final output sent to browser
DEBUG - 2016-01-30 09:26:19 --> Total execution time: 1.2063
INFO - 2016-01-30 09:26:22 --> Config Class Initialized
INFO - 2016-01-30 09:26:22 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:26:22 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:26:22 --> Utf8 Class Initialized
INFO - 2016-01-30 09:26:22 --> URI Class Initialized
DEBUG - 2016-01-30 09:26:22 --> No URI present. Default controller set.
INFO - 2016-01-30 09:26:22 --> Router Class Initialized
INFO - 2016-01-30 09:26:22 --> Output Class Initialized
INFO - 2016-01-30 09:26:22 --> Security Class Initialized
DEBUG - 2016-01-30 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:26:22 --> Input Class Initialized
INFO - 2016-01-30 09:26:22 --> Language Class Initialized
INFO - 2016-01-30 09:26:22 --> Loader Class Initialized
INFO - 2016-01-30 09:26:22 --> Helper loaded: url_helper
INFO - 2016-01-30 09:26:22 --> Helper loaded: file_helper
INFO - 2016-01-30 09:26:22 --> Helper loaded: date_helper
INFO - 2016-01-30 09:26:22 --> Database Driver Class Initialized
INFO - 2016-01-30 09:26:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:26:23 --> Controller Class Initialized
INFO - 2016-01-30 09:26:23 --> Model Class Initialized
INFO - 2016-01-30 09:26:23 --> Model Class Initialized
INFO - 2016-01-30 09:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:26:23 --> Pagination Class Initialized
INFO - 2016-01-30 09:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:26:23 --> Final output sent to browser
DEBUG - 2016-01-30 09:26:23 --> Total execution time: 1.1506
INFO - 2016-01-30 09:31:30 --> Config Class Initialized
INFO - 2016-01-30 09:31:30 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:31:30 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:31:30 --> Utf8 Class Initialized
INFO - 2016-01-30 09:31:30 --> URI Class Initialized
DEBUG - 2016-01-30 09:31:30 --> No URI present. Default controller set.
INFO - 2016-01-30 09:31:30 --> Router Class Initialized
INFO - 2016-01-30 09:31:30 --> Output Class Initialized
INFO - 2016-01-30 09:31:30 --> Security Class Initialized
DEBUG - 2016-01-30 09:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:31:30 --> Input Class Initialized
INFO - 2016-01-30 09:31:30 --> Language Class Initialized
INFO - 2016-01-30 09:31:30 --> Loader Class Initialized
INFO - 2016-01-30 09:31:30 --> Helper loaded: url_helper
INFO - 2016-01-30 09:31:30 --> Helper loaded: file_helper
INFO - 2016-01-30 09:31:30 --> Helper loaded: date_helper
INFO - 2016-01-30 09:31:30 --> Database Driver Class Initialized
INFO - 2016-01-30 09:31:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:31:31 --> Controller Class Initialized
INFO - 2016-01-30 09:31:31 --> Model Class Initialized
INFO - 2016-01-30 09:31:31 --> Model Class Initialized
INFO - 2016-01-30 09:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:31:31 --> Pagination Class Initialized
INFO - 2016-01-30 09:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:31:31 --> Final output sent to browser
DEBUG - 2016-01-30 09:31:31 --> Total execution time: 1.0877
INFO - 2016-01-30 09:31:35 --> Config Class Initialized
INFO - 2016-01-30 09:31:35 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:31:35 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:31:35 --> Utf8 Class Initialized
INFO - 2016-01-30 09:31:35 --> URI Class Initialized
DEBUG - 2016-01-30 09:31:35 --> No URI present. Default controller set.
INFO - 2016-01-30 09:31:35 --> Router Class Initialized
INFO - 2016-01-30 09:31:35 --> Output Class Initialized
INFO - 2016-01-30 09:31:35 --> Security Class Initialized
DEBUG - 2016-01-30 09:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:31:35 --> Input Class Initialized
INFO - 2016-01-30 09:31:35 --> Language Class Initialized
INFO - 2016-01-30 09:31:35 --> Loader Class Initialized
INFO - 2016-01-30 09:31:35 --> Helper loaded: url_helper
INFO - 2016-01-30 09:31:35 --> Helper loaded: file_helper
INFO - 2016-01-30 09:31:35 --> Helper loaded: date_helper
INFO - 2016-01-30 09:31:35 --> Database Driver Class Initialized
INFO - 2016-01-30 09:31:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:31:36 --> Controller Class Initialized
INFO - 2016-01-30 09:31:36 --> Model Class Initialized
INFO - 2016-01-30 09:31:36 --> Model Class Initialized
INFO - 2016-01-30 09:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:31:36 --> Pagination Class Initialized
INFO - 2016-01-30 09:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:31:36 --> Final output sent to browser
DEBUG - 2016-01-30 09:31:36 --> Total execution time: 1.1149
INFO - 2016-01-30 09:31:38 --> Config Class Initialized
INFO - 2016-01-30 09:31:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:31:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:31:38 --> Utf8 Class Initialized
INFO - 2016-01-30 09:31:38 --> URI Class Initialized
INFO - 2016-01-30 09:31:38 --> Router Class Initialized
INFO - 2016-01-30 09:31:38 --> Output Class Initialized
INFO - 2016-01-30 09:31:38 --> Security Class Initialized
DEBUG - 2016-01-30 09:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:31:38 --> Input Class Initialized
INFO - 2016-01-30 09:31:38 --> Language Class Initialized
INFO - 2016-01-30 09:31:38 --> Loader Class Initialized
INFO - 2016-01-30 09:31:38 --> Helper loaded: url_helper
INFO - 2016-01-30 09:31:38 --> Helper loaded: file_helper
INFO - 2016-01-30 09:31:38 --> Helper loaded: date_helper
INFO - 2016-01-30 09:31:38 --> Database Driver Class Initialized
INFO - 2016-01-30 09:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:31:39 --> Controller Class Initialized
INFO - 2016-01-30 09:31:39 --> Model Class Initialized
INFO - 2016-01-30 09:31:39 --> Model Class Initialized
INFO - 2016-01-30 09:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:31:39 --> Pagination Class Initialized
INFO - 2016-01-30 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:31:39 --> Final output sent to browser
DEBUG - 2016-01-30 09:31:39 --> Total execution time: 1.1304
INFO - 2016-01-30 09:31:55 --> Config Class Initialized
INFO - 2016-01-30 09:31:55 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:31:55 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:31:55 --> Utf8 Class Initialized
INFO - 2016-01-30 09:31:55 --> URI Class Initialized
DEBUG - 2016-01-30 09:31:55 --> No URI present. Default controller set.
INFO - 2016-01-30 09:31:55 --> Router Class Initialized
INFO - 2016-01-30 09:31:55 --> Output Class Initialized
INFO - 2016-01-30 09:31:55 --> Security Class Initialized
DEBUG - 2016-01-30 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:31:55 --> Input Class Initialized
INFO - 2016-01-30 09:31:55 --> Language Class Initialized
INFO - 2016-01-30 09:31:55 --> Loader Class Initialized
INFO - 2016-01-30 09:31:55 --> Helper loaded: url_helper
INFO - 2016-01-30 09:31:55 --> Helper loaded: file_helper
INFO - 2016-01-30 09:31:55 --> Helper loaded: date_helper
INFO - 2016-01-30 09:31:55 --> Database Driver Class Initialized
INFO - 2016-01-30 09:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:31:56 --> Controller Class Initialized
INFO - 2016-01-30 09:31:56 --> Model Class Initialized
INFO - 2016-01-30 09:31:56 --> Model Class Initialized
INFO - 2016-01-30 09:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:31:56 --> Pagination Class Initialized
INFO - 2016-01-30 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:31:56 --> Final output sent to browser
DEBUG - 2016-01-30 09:31:56 --> Total execution time: 1.1171
INFO - 2016-01-30 09:31:59 --> Config Class Initialized
INFO - 2016-01-30 09:31:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:31:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:31:59 --> Utf8 Class Initialized
INFO - 2016-01-30 09:31:59 --> URI Class Initialized
INFO - 2016-01-30 09:31:59 --> Router Class Initialized
INFO - 2016-01-30 09:31:59 --> Output Class Initialized
INFO - 2016-01-30 09:31:59 --> Security Class Initialized
DEBUG - 2016-01-30 09:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:31:59 --> Input Class Initialized
INFO - 2016-01-30 09:31:59 --> Language Class Initialized
INFO - 2016-01-30 09:31:59 --> Loader Class Initialized
INFO - 2016-01-30 09:31:59 --> Helper loaded: url_helper
INFO - 2016-01-30 09:31:59 --> Helper loaded: file_helper
INFO - 2016-01-30 09:31:59 --> Helper loaded: date_helper
INFO - 2016-01-30 09:31:59 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:00 --> Controller Class Initialized
INFO - 2016-01-30 09:32:00 --> Model Class Initialized
INFO - 2016-01-30 09:32:00 --> Model Class Initialized
INFO - 2016-01-30 09:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:00 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:00 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:00 --> Total execution time: 1.1237
INFO - 2016-01-30 09:32:01 --> Config Class Initialized
INFO - 2016-01-30 09:32:01 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:01 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:01 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:01 --> URI Class Initialized
INFO - 2016-01-30 09:32:01 --> Router Class Initialized
INFO - 2016-01-30 09:32:01 --> Output Class Initialized
INFO - 2016-01-30 09:32:01 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:01 --> Input Class Initialized
INFO - 2016-01-30 09:32:01 --> Language Class Initialized
INFO - 2016-01-30 09:32:01 --> Loader Class Initialized
INFO - 2016-01-30 09:32:01 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:01 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:01 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:01 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:02 --> Controller Class Initialized
INFO - 2016-01-30 09:32:02 --> Model Class Initialized
INFO - 2016-01-30 09:32:02 --> Model Class Initialized
INFO - 2016-01-30 09:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:02 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:02 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:02 --> Total execution time: 1.1118
INFO - 2016-01-30 09:32:04 --> Config Class Initialized
INFO - 2016-01-30 09:32:04 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:04 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:04 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:04 --> URI Class Initialized
INFO - 2016-01-30 09:32:04 --> Router Class Initialized
INFO - 2016-01-30 09:32:04 --> Output Class Initialized
INFO - 2016-01-30 09:32:04 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:04 --> Input Class Initialized
INFO - 2016-01-30 09:32:04 --> Language Class Initialized
INFO - 2016-01-30 09:32:04 --> Loader Class Initialized
INFO - 2016-01-30 09:32:04 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:04 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:04 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:04 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:05 --> Controller Class Initialized
INFO - 2016-01-30 09:32:05 --> Model Class Initialized
INFO - 2016-01-30 09:32:05 --> Model Class Initialized
INFO - 2016-01-30 09:32:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:05 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:05 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:05 --> Total execution time: 1.1213
INFO - 2016-01-30 09:32:06 --> Config Class Initialized
INFO - 2016-01-30 09:32:06 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:06 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:06 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:06 --> URI Class Initialized
INFO - 2016-01-30 09:32:06 --> Router Class Initialized
INFO - 2016-01-30 09:32:06 --> Output Class Initialized
INFO - 2016-01-30 09:32:06 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:06 --> Input Class Initialized
INFO - 2016-01-30 09:32:06 --> Language Class Initialized
INFO - 2016-01-30 09:32:07 --> Loader Class Initialized
INFO - 2016-01-30 09:32:07 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:07 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:07 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:07 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:08 --> Controller Class Initialized
INFO - 2016-01-30 09:32:08 --> Model Class Initialized
INFO - 2016-01-30 09:32:08 --> Model Class Initialized
INFO - 2016-01-30 09:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:08 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:08 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:08 --> Total execution time: 1.1121
INFO - 2016-01-30 09:32:09 --> Config Class Initialized
INFO - 2016-01-30 09:32:09 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:09 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:09 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:09 --> URI Class Initialized
INFO - 2016-01-30 09:32:09 --> Router Class Initialized
INFO - 2016-01-30 09:32:09 --> Output Class Initialized
INFO - 2016-01-30 09:32:09 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:09 --> Input Class Initialized
INFO - 2016-01-30 09:32:09 --> Language Class Initialized
INFO - 2016-01-30 09:32:09 --> Loader Class Initialized
INFO - 2016-01-30 09:32:09 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:09 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:09 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:09 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:10 --> Controller Class Initialized
INFO - 2016-01-30 09:32:10 --> Model Class Initialized
INFO - 2016-01-30 09:32:10 --> Model Class Initialized
INFO - 2016-01-30 09:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:10 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:10 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:10 --> Total execution time: 1.1312
INFO - 2016-01-30 09:32:27 --> Config Class Initialized
INFO - 2016-01-30 09:32:27 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:27 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:27 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:27 --> URI Class Initialized
DEBUG - 2016-01-30 09:32:27 --> No URI present. Default controller set.
INFO - 2016-01-30 09:32:27 --> Router Class Initialized
INFO - 2016-01-30 09:32:27 --> Output Class Initialized
INFO - 2016-01-30 09:32:27 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:27 --> Input Class Initialized
INFO - 2016-01-30 09:32:27 --> Language Class Initialized
INFO - 2016-01-30 09:32:27 --> Loader Class Initialized
INFO - 2016-01-30 09:32:27 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:27 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:27 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:27 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:28 --> Controller Class Initialized
INFO - 2016-01-30 09:32:28 --> Model Class Initialized
INFO - 2016-01-30 09:32:28 --> Model Class Initialized
INFO - 2016-01-30 09:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:28 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:28 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:28 --> Total execution time: 1.1226
INFO - 2016-01-30 09:32:35 --> Config Class Initialized
INFO - 2016-01-30 09:32:35 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:35 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:35 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:35 --> URI Class Initialized
INFO - 2016-01-30 09:32:35 --> Router Class Initialized
INFO - 2016-01-30 09:32:35 --> Output Class Initialized
INFO - 2016-01-30 09:32:35 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:35 --> Input Class Initialized
INFO - 2016-01-30 09:32:35 --> Language Class Initialized
INFO - 2016-01-30 09:32:35 --> Loader Class Initialized
INFO - 2016-01-30 09:32:35 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:35 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:35 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:35 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:36 --> Controller Class Initialized
INFO - 2016-01-30 09:32:36 --> Model Class Initialized
INFO - 2016-01-30 09:32:36 --> Model Class Initialized
INFO - 2016-01-30 09:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:36 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:36 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:36 --> Total execution time: 1.1304
INFO - 2016-01-30 09:32:38 --> Config Class Initialized
INFO - 2016-01-30 09:32:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:38 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:38 --> URI Class Initialized
INFO - 2016-01-30 09:32:38 --> Router Class Initialized
INFO - 2016-01-30 09:32:38 --> Output Class Initialized
INFO - 2016-01-30 09:32:38 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:38 --> Input Class Initialized
INFO - 2016-01-30 09:32:38 --> Language Class Initialized
INFO - 2016-01-30 09:32:38 --> Loader Class Initialized
INFO - 2016-01-30 09:32:38 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:38 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:38 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:38 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:39 --> Controller Class Initialized
INFO - 2016-01-30 09:32:39 --> Model Class Initialized
INFO - 2016-01-30 09:32:39 --> Model Class Initialized
INFO - 2016-01-30 09:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:39 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:39 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:39 --> Total execution time: 1.1228
INFO - 2016-01-30 09:32:47 --> Config Class Initialized
INFO - 2016-01-30 09:32:47 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:47 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:47 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:47 --> URI Class Initialized
DEBUG - 2016-01-30 09:32:47 --> No URI present. Default controller set.
INFO - 2016-01-30 09:32:47 --> Router Class Initialized
INFO - 2016-01-30 09:32:47 --> Output Class Initialized
INFO - 2016-01-30 09:32:47 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:47 --> Input Class Initialized
INFO - 2016-01-30 09:32:47 --> Language Class Initialized
INFO - 2016-01-30 09:32:47 --> Loader Class Initialized
INFO - 2016-01-30 09:32:47 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:47 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:47 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:47 --> Database Driver Class Initialized
INFO - 2016-01-30 09:32:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:32:48 --> Controller Class Initialized
INFO - 2016-01-30 09:32:48 --> Model Class Initialized
INFO - 2016-01-30 09:32:48 --> Model Class Initialized
INFO - 2016-01-30 09:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:32:48 --> Pagination Class Initialized
INFO - 2016-01-30 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 09:32:48 --> Final output sent to browser
DEBUG - 2016-01-30 09:32:48 --> Total execution time: 1.1272
INFO - 2016-01-30 09:32:59 --> Config Class Initialized
INFO - 2016-01-30 09:32:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 09:32:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 09:32:59 --> Utf8 Class Initialized
INFO - 2016-01-30 09:32:59 --> URI Class Initialized
INFO - 2016-01-30 09:32:59 --> Router Class Initialized
INFO - 2016-01-30 09:32:59 --> Output Class Initialized
INFO - 2016-01-30 09:32:59 --> Security Class Initialized
DEBUG - 2016-01-30 09:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 09:32:59 --> Input Class Initialized
INFO - 2016-01-30 09:32:59 --> Language Class Initialized
INFO - 2016-01-30 09:32:59 --> Loader Class Initialized
INFO - 2016-01-30 09:32:59 --> Helper loaded: url_helper
INFO - 2016-01-30 09:32:59 --> Helper loaded: file_helper
INFO - 2016-01-30 09:32:59 --> Helper loaded: date_helper
INFO - 2016-01-30 09:32:59 --> Database Driver Class Initialized
INFO - 2016-01-30 09:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 09:33:01 --> Controller Class Initialized
INFO - 2016-01-30 09:33:01 --> Model Class Initialized
INFO - 2016-01-30 09:33:01 --> Model Class Initialized
INFO - 2016-01-30 09:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 09:33:01 --> Pagination Class Initialized
INFO - 2016-01-30 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 09:33:01 --> Helper loaded: text_helper
INFO - 2016-01-30 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 09:33:01 --> Final output sent to browser
DEBUG - 2016-01-30 09:33:01 --> Total execution time: 1.1499
INFO - 2016-01-30 10:08:53 --> Config Class Initialized
INFO - 2016-01-30 10:08:53 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:08:53 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:08:53 --> Utf8 Class Initialized
INFO - 2016-01-30 10:08:53 --> URI Class Initialized
DEBUG - 2016-01-30 10:08:53 --> No URI present. Default controller set.
INFO - 2016-01-30 10:08:53 --> Router Class Initialized
INFO - 2016-01-30 10:08:53 --> Output Class Initialized
INFO - 2016-01-30 10:08:53 --> Security Class Initialized
DEBUG - 2016-01-30 10:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:08:53 --> Input Class Initialized
INFO - 2016-01-30 10:08:53 --> Language Class Initialized
INFO - 2016-01-30 10:08:53 --> Loader Class Initialized
INFO - 2016-01-30 10:08:53 --> Helper loaded: url_helper
INFO - 2016-01-30 10:08:53 --> Helper loaded: file_helper
INFO - 2016-01-30 10:08:53 --> Helper loaded: date_helper
INFO - 2016-01-30 10:08:53 --> Database Driver Class Initialized
INFO - 2016-01-30 10:08:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:08:54 --> Controller Class Initialized
INFO - 2016-01-30 10:08:54 --> Model Class Initialized
INFO - 2016-01-30 10:08:54 --> Model Class Initialized
INFO - 2016-01-30 10:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:08:54 --> Pagination Class Initialized
INFO - 2016-01-30 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:08:54 --> Final output sent to browser
DEBUG - 2016-01-30 10:08:54 --> Total execution time: 1.1328
INFO - 2016-01-30 10:08:58 --> Config Class Initialized
INFO - 2016-01-30 10:08:58 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:08:58 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:08:58 --> Utf8 Class Initialized
INFO - 2016-01-30 10:08:58 --> URI Class Initialized
INFO - 2016-01-30 10:08:58 --> Router Class Initialized
INFO - 2016-01-30 10:08:58 --> Output Class Initialized
INFO - 2016-01-30 10:08:58 --> Security Class Initialized
DEBUG - 2016-01-30 10:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:08:58 --> Input Class Initialized
INFO - 2016-01-30 10:08:58 --> Language Class Initialized
INFO - 2016-01-30 10:08:58 --> Loader Class Initialized
INFO - 2016-01-30 10:08:58 --> Helper loaded: url_helper
INFO - 2016-01-30 10:08:58 --> Helper loaded: file_helper
INFO - 2016-01-30 10:08:58 --> Helper loaded: date_helper
INFO - 2016-01-30 10:08:58 --> Database Driver Class Initialized
INFO - 2016-01-30 10:08:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:08:59 --> Controller Class Initialized
INFO - 2016-01-30 10:08:59 --> Model Class Initialized
INFO - 2016-01-30 10:08:59 --> Model Class Initialized
INFO - 2016-01-30 10:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:08:59 --> Pagination Class Initialized
INFO - 2016-01-30 10:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:08:59 --> Helper loaded: text_helper
INFO - 2016-01-30 10:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-30 10:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
INFO - 2016-01-30 10:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:08:59 --> Final output sent to browser
DEBUG - 2016-01-30 10:08:59 --> Total execution time: 1.1951
INFO - 2016-01-30 10:12:28 --> Config Class Initialized
INFO - 2016-01-30 10:12:28 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:12:28 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:12:28 --> Utf8 Class Initialized
INFO - 2016-01-30 10:12:28 --> URI Class Initialized
INFO - 2016-01-30 10:12:28 --> Router Class Initialized
INFO - 2016-01-30 10:12:28 --> Output Class Initialized
INFO - 2016-01-30 10:12:28 --> Security Class Initialized
DEBUG - 2016-01-30 10:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:12:28 --> Input Class Initialized
INFO - 2016-01-30 10:12:28 --> Language Class Initialized
INFO - 2016-01-30 10:12:28 --> Loader Class Initialized
INFO - 2016-01-30 10:12:28 --> Helper loaded: url_helper
INFO - 2016-01-30 10:12:28 --> Helper loaded: file_helper
INFO - 2016-01-30 10:12:28 --> Helper loaded: date_helper
INFO - 2016-01-30 10:12:28 --> Database Driver Class Initialized
INFO - 2016-01-30 10:12:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:12:29 --> Controller Class Initialized
INFO - 2016-01-30 10:12:29 --> Model Class Initialized
INFO - 2016-01-30 10:12:29 --> Model Class Initialized
INFO - 2016-01-30 10:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:12:29 --> Pagination Class Initialized
INFO - 2016-01-30 10:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:12:29 --> Helper loaded: text_helper
INFO - 2016-01-30 10:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:12:29 --> Final output sent to browser
DEBUG - 2016-01-30 10:12:29 --> Total execution time: 1.1798
INFO - 2016-01-30 10:13:59 --> Config Class Initialized
INFO - 2016-01-30 10:13:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:13:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:13:59 --> Utf8 Class Initialized
INFO - 2016-01-30 10:13:59 --> URI Class Initialized
INFO - 2016-01-30 10:13:59 --> Router Class Initialized
INFO - 2016-01-30 10:13:59 --> Output Class Initialized
INFO - 2016-01-30 10:13:59 --> Security Class Initialized
DEBUG - 2016-01-30 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:13:59 --> Input Class Initialized
INFO - 2016-01-30 10:13:59 --> Language Class Initialized
INFO - 2016-01-30 10:13:59 --> Loader Class Initialized
INFO - 2016-01-30 10:13:59 --> Helper loaded: url_helper
INFO - 2016-01-30 10:13:59 --> Helper loaded: file_helper
INFO - 2016-01-30 10:13:59 --> Helper loaded: date_helper
INFO - 2016-01-30 10:13:59 --> Database Driver Class Initialized
INFO - 2016-01-30 10:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:14:00 --> Controller Class Initialized
INFO - 2016-01-30 10:14:00 --> Model Class Initialized
INFO - 2016-01-30 10:14:00 --> Model Class Initialized
INFO - 2016-01-30 10:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:14:00 --> Pagination Class Initialized
INFO - 2016-01-30 10:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:14:00 --> Helper loaded: text_helper
INFO - 2016-01-30 10:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:14:00 --> Final output sent to browser
DEBUG - 2016-01-30 10:14:00 --> Total execution time: 1.1754
INFO - 2016-01-30 10:14:03 --> Config Class Initialized
INFO - 2016-01-30 10:14:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:14:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:14:03 --> Utf8 Class Initialized
INFO - 2016-01-30 10:14:03 --> URI Class Initialized
INFO - 2016-01-30 10:14:03 --> Router Class Initialized
INFO - 2016-01-30 10:14:03 --> Output Class Initialized
INFO - 2016-01-30 10:14:03 --> Security Class Initialized
DEBUG - 2016-01-30 10:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:14:03 --> Input Class Initialized
INFO - 2016-01-30 10:14:03 --> Language Class Initialized
INFO - 2016-01-30 10:14:03 --> Loader Class Initialized
INFO - 2016-01-30 10:14:03 --> Helper loaded: url_helper
INFO - 2016-01-30 10:14:03 --> Helper loaded: file_helper
INFO - 2016-01-30 10:14:03 --> Helper loaded: date_helper
INFO - 2016-01-30 10:14:03 --> Database Driver Class Initialized
INFO - 2016-01-30 10:14:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:14:04 --> Controller Class Initialized
INFO - 2016-01-30 10:14:04 --> Model Class Initialized
INFO - 2016-01-30 10:14:04 --> Model Class Initialized
INFO - 2016-01-30 10:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:14:04 --> Pagination Class Initialized
INFO - 2016-01-30 10:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:14:04 --> Helper loaded: text_helper
INFO - 2016-01-30 10:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:14:04 --> Final output sent to browser
DEBUG - 2016-01-30 10:14:04 --> Total execution time: 1.1474
INFO - 2016-01-30 10:14:06 --> Config Class Initialized
INFO - 2016-01-30 10:14:06 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:14:06 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:14:06 --> Utf8 Class Initialized
INFO - 2016-01-30 10:14:06 --> URI Class Initialized
INFO - 2016-01-30 10:14:06 --> Router Class Initialized
INFO - 2016-01-30 10:14:06 --> Output Class Initialized
INFO - 2016-01-30 10:14:06 --> Security Class Initialized
DEBUG - 2016-01-30 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:14:06 --> Input Class Initialized
INFO - 2016-01-30 10:14:06 --> Language Class Initialized
INFO - 2016-01-30 10:14:06 --> Loader Class Initialized
INFO - 2016-01-30 10:14:06 --> Helper loaded: url_helper
INFO - 2016-01-30 10:14:06 --> Helper loaded: file_helper
INFO - 2016-01-30 10:14:06 --> Helper loaded: date_helper
INFO - 2016-01-30 10:14:06 --> Database Driver Class Initialized
INFO - 2016-01-30 10:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:14:07 --> Controller Class Initialized
INFO - 2016-01-30 10:14:07 --> Model Class Initialized
INFO - 2016-01-30 10:14:07 --> Model Class Initialized
INFO - 2016-01-30 10:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:14:07 --> Pagination Class Initialized
INFO - 2016-01-30 10:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:14:07 --> Helper loaded: text_helper
INFO - 2016-01-30 10:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:14:07 --> Final output sent to browser
DEBUG - 2016-01-30 10:14:07 --> Total execution time: 1.1415
INFO - 2016-01-30 10:19:23 --> Config Class Initialized
INFO - 2016-01-30 10:19:23 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:19:23 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:19:23 --> Utf8 Class Initialized
INFO - 2016-01-30 10:19:23 --> URI Class Initialized
DEBUG - 2016-01-30 10:19:23 --> No URI present. Default controller set.
INFO - 2016-01-30 10:19:23 --> Router Class Initialized
INFO - 2016-01-30 10:19:23 --> Output Class Initialized
INFO - 2016-01-30 10:19:23 --> Security Class Initialized
DEBUG - 2016-01-30 10:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:19:23 --> Input Class Initialized
INFO - 2016-01-30 10:19:23 --> Language Class Initialized
INFO - 2016-01-30 10:19:23 --> Loader Class Initialized
INFO - 2016-01-30 10:19:23 --> Helper loaded: url_helper
INFO - 2016-01-30 10:19:23 --> Helper loaded: file_helper
INFO - 2016-01-30 10:19:23 --> Helper loaded: date_helper
INFO - 2016-01-30 10:19:23 --> Database Driver Class Initialized
INFO - 2016-01-30 10:19:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:19:24 --> Controller Class Initialized
INFO - 2016-01-30 10:19:24 --> Model Class Initialized
INFO - 2016-01-30 10:19:24 --> Model Class Initialized
INFO - 2016-01-30 10:19:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:19:24 --> Pagination Class Initialized
INFO - 2016-01-30 10:19:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:19:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:19:24 --> Final output sent to browser
DEBUG - 2016-01-30 10:19:24 --> Total execution time: 1.1075
INFO - 2016-01-30 10:19:29 --> Config Class Initialized
INFO - 2016-01-30 10:19:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:19:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:19:29 --> Utf8 Class Initialized
INFO - 2016-01-30 10:19:29 --> URI Class Initialized
INFO - 2016-01-30 10:19:29 --> Router Class Initialized
INFO - 2016-01-30 10:19:29 --> Output Class Initialized
INFO - 2016-01-30 10:19:29 --> Security Class Initialized
DEBUG - 2016-01-30 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:19:29 --> Input Class Initialized
INFO - 2016-01-30 10:19:29 --> Language Class Initialized
INFO - 2016-01-30 10:19:29 --> Loader Class Initialized
INFO - 2016-01-30 10:19:29 --> Helper loaded: url_helper
INFO - 2016-01-30 10:19:29 --> Helper loaded: file_helper
INFO - 2016-01-30 10:19:29 --> Helper loaded: date_helper
INFO - 2016-01-30 10:19:29 --> Database Driver Class Initialized
INFO - 2016-01-30 10:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:19:30 --> Controller Class Initialized
INFO - 2016-01-30 10:19:30 --> Model Class Initialized
INFO - 2016-01-30 10:19:30 --> Model Class Initialized
INFO - 2016-01-30 10:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:19:30 --> Pagination Class Initialized
INFO - 2016-01-30 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:19:30 --> Helper loaded: text_helper
INFO - 2016-01-30 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:19:30 --> Final output sent to browser
DEBUG - 2016-01-30 10:19:30 --> Total execution time: 1.1790
INFO - 2016-01-30 10:27:03 --> Config Class Initialized
INFO - 2016-01-30 10:27:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:03 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:03 --> URI Class Initialized
DEBUG - 2016-01-30 10:27:03 --> No URI present. Default controller set.
INFO - 2016-01-30 10:27:03 --> Router Class Initialized
INFO - 2016-01-30 10:27:03 --> Output Class Initialized
INFO - 2016-01-30 10:27:03 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:03 --> Input Class Initialized
INFO - 2016-01-30 10:27:03 --> Language Class Initialized
INFO - 2016-01-30 10:27:03 --> Loader Class Initialized
INFO - 2016-01-30 10:27:03 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:03 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:03 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:03 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:04 --> Controller Class Initialized
INFO - 2016-01-30 10:27:04 --> Model Class Initialized
INFO - 2016-01-30 10:27:04 --> Model Class Initialized
INFO - 2016-01-30 10:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:04 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:27:04 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:04 --> Total execution time: 1.1211
INFO - 2016-01-30 10:27:08 --> Config Class Initialized
INFO - 2016-01-30 10:27:08 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:08 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:08 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:08 --> URI Class Initialized
INFO - 2016-01-30 10:27:08 --> Router Class Initialized
INFO - 2016-01-30 10:27:08 --> Output Class Initialized
INFO - 2016-01-30 10:27:08 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:08 --> Input Class Initialized
INFO - 2016-01-30 10:27:08 --> Language Class Initialized
INFO - 2016-01-30 10:27:08 --> Loader Class Initialized
INFO - 2016-01-30 10:27:08 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:08 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:08 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:08 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:09 --> Controller Class Initialized
INFO - 2016-01-30 10:27:09 --> Model Class Initialized
INFO - 2016-01-30 10:27:09 --> Model Class Initialized
INFO - 2016-01-30 10:27:09 --> Helper loaded: form_helper
INFO - 2016-01-30 10:27:09 --> Form Validation Class Initialized
INFO - 2016-01-30 10:27:09 --> Helper loaded: text_helper
INFO - 2016-01-30 10:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 10:27:09 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:09 --> Total execution time: 1.1140
INFO - 2016-01-30 10:27:14 --> Config Class Initialized
INFO - 2016-01-30 10:27:14 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:14 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:14 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:14 --> URI Class Initialized
INFO - 2016-01-30 10:27:14 --> Router Class Initialized
INFO - 2016-01-30 10:27:14 --> Output Class Initialized
INFO - 2016-01-30 10:27:14 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:14 --> Input Class Initialized
INFO - 2016-01-30 10:27:14 --> Language Class Initialized
INFO - 2016-01-30 10:27:14 --> Loader Class Initialized
INFO - 2016-01-30 10:27:14 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:14 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:14 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:14 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:15 --> Controller Class Initialized
INFO - 2016-01-30 10:27:15 --> Model Class Initialized
INFO - 2016-01-30 10:27:15 --> Model Class Initialized
INFO - 2016-01-30 10:27:15 --> Helper loaded: form_helper
INFO - 2016-01-30 10:27:15 --> Form Validation Class Initialized
INFO - 2016-01-30 10:27:15 --> Helper loaded: text_helper
INFO - 2016-01-30 10:27:15 --> Config Class Initialized
INFO - 2016-01-30 10:27:15 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:15 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:15 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:15 --> URI Class Initialized
INFO - 2016-01-30 10:27:15 --> Router Class Initialized
INFO - 2016-01-30 10:27:15 --> Output Class Initialized
INFO - 2016-01-30 10:27:15 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:15 --> Input Class Initialized
INFO - 2016-01-30 10:27:15 --> Language Class Initialized
INFO - 2016-01-30 10:27:15 --> Loader Class Initialized
INFO - 2016-01-30 10:27:15 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:15 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:15 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:15 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:16 --> Controller Class Initialized
INFO - 2016-01-30 10:27:16 --> Model Class Initialized
INFO - 2016-01-30 10:27:16 --> Model Class Initialized
INFO - 2016-01-30 10:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:16 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:27:16 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:16 --> Total execution time: 1.1212
INFO - 2016-01-30 10:27:19 --> Config Class Initialized
INFO - 2016-01-30 10:27:19 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:19 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:19 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:19 --> URI Class Initialized
INFO - 2016-01-30 10:27:19 --> Router Class Initialized
INFO - 2016-01-30 10:27:19 --> Output Class Initialized
INFO - 2016-01-30 10:27:19 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:19 --> Input Class Initialized
INFO - 2016-01-30 10:27:19 --> Language Class Initialized
INFO - 2016-01-30 10:27:19 --> Loader Class Initialized
INFO - 2016-01-30 10:27:19 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:19 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:19 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:19 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:20 --> Controller Class Initialized
INFO - 2016-01-30 10:27:20 --> Model Class Initialized
INFO - 2016-01-30 10:27:20 --> Model Class Initialized
INFO - 2016-01-30 10:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:20 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:20 --> Helper loaded: text_helper
INFO - 2016-01-30 10:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:27:20 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:20 --> Total execution time: 1.1748
INFO - 2016-01-30 10:27:25 --> Config Class Initialized
INFO - 2016-01-30 10:27:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:25 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:25 --> URI Class Initialized
DEBUG - 2016-01-30 10:27:25 --> No URI present. Default controller set.
INFO - 2016-01-30 10:27:25 --> Router Class Initialized
INFO - 2016-01-30 10:27:25 --> Output Class Initialized
INFO - 2016-01-30 10:27:25 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:25 --> Input Class Initialized
INFO - 2016-01-30 10:27:25 --> Language Class Initialized
INFO - 2016-01-30 10:27:25 --> Loader Class Initialized
INFO - 2016-01-30 10:27:25 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:25 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:25 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:25 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:26 --> Controller Class Initialized
INFO - 2016-01-30 10:27:26 --> Model Class Initialized
INFO - 2016-01-30 10:27:26 --> Model Class Initialized
INFO - 2016-01-30 10:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:26 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:27:26 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:26 --> Total execution time: 1.1069
INFO - 2016-01-30 10:27:28 --> Config Class Initialized
INFO - 2016-01-30 10:27:28 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:28 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:28 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:28 --> URI Class Initialized
INFO - 2016-01-30 10:27:28 --> Router Class Initialized
INFO - 2016-01-30 10:27:28 --> Output Class Initialized
INFO - 2016-01-30 10:27:28 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:28 --> Input Class Initialized
INFO - 2016-01-30 10:27:28 --> Language Class Initialized
INFO - 2016-01-30 10:27:28 --> Loader Class Initialized
INFO - 2016-01-30 10:27:28 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:28 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:28 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:28 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:29 --> Controller Class Initialized
INFO - 2016-01-30 10:27:29 --> Model Class Initialized
INFO - 2016-01-30 10:27:29 --> Model Class Initialized
INFO - 2016-01-30 10:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:29 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:29 --> Helper loaded: text_helper
INFO - 2016-01-30 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:27:29 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:29 --> Total execution time: 1.1575
INFO - 2016-01-30 10:27:37 --> Config Class Initialized
INFO - 2016-01-30 10:27:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:37 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:37 --> URI Class Initialized
DEBUG - 2016-01-30 10:27:37 --> No URI present. Default controller set.
INFO - 2016-01-30 10:27:37 --> Router Class Initialized
INFO - 2016-01-30 10:27:37 --> Output Class Initialized
INFO - 2016-01-30 10:27:37 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:37 --> Input Class Initialized
INFO - 2016-01-30 10:27:37 --> Language Class Initialized
INFO - 2016-01-30 10:27:37 --> Loader Class Initialized
INFO - 2016-01-30 10:27:37 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:37 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:37 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:37 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:38 --> Controller Class Initialized
INFO - 2016-01-30 10:27:38 --> Model Class Initialized
INFO - 2016-01-30 10:27:38 --> Model Class Initialized
INFO - 2016-01-30 10:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:38 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:27:38 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:38 --> Total execution time: 1.1424
INFO - 2016-01-30 10:27:39 --> Config Class Initialized
INFO - 2016-01-30 10:27:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:39 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:39 --> URI Class Initialized
INFO - 2016-01-30 10:27:39 --> Router Class Initialized
INFO - 2016-01-30 10:27:39 --> Output Class Initialized
INFO - 2016-01-30 10:27:39 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:39 --> Input Class Initialized
INFO - 2016-01-30 10:27:39 --> Language Class Initialized
INFO - 2016-01-30 10:27:39 --> Loader Class Initialized
INFO - 2016-01-30 10:27:39 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:39 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:39 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:39 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:40 --> Controller Class Initialized
INFO - 2016-01-30 10:27:40 --> Model Class Initialized
INFO - 2016-01-30 10:27:40 --> Model Class Initialized
INFO - 2016-01-30 10:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:40 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:40 --> Helper loaded: text_helper
INFO - 2016-01-30 10:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:27:40 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:40 --> Total execution time: 1.1388
INFO - 2016-01-30 10:27:42 --> Config Class Initialized
INFO - 2016-01-30 10:27:42 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:27:42 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:27:42 --> Utf8 Class Initialized
INFO - 2016-01-30 10:27:42 --> URI Class Initialized
DEBUG - 2016-01-30 10:27:42 --> No URI present. Default controller set.
INFO - 2016-01-30 10:27:42 --> Router Class Initialized
INFO - 2016-01-30 10:27:42 --> Output Class Initialized
INFO - 2016-01-30 10:27:42 --> Security Class Initialized
DEBUG - 2016-01-30 10:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:27:42 --> Input Class Initialized
INFO - 2016-01-30 10:27:42 --> Language Class Initialized
INFO - 2016-01-30 10:27:42 --> Loader Class Initialized
INFO - 2016-01-30 10:27:42 --> Helper loaded: url_helper
INFO - 2016-01-30 10:27:42 --> Helper loaded: file_helper
INFO - 2016-01-30 10:27:42 --> Helper loaded: date_helper
INFO - 2016-01-30 10:27:42 --> Database Driver Class Initialized
INFO - 2016-01-30 10:27:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:27:43 --> Controller Class Initialized
INFO - 2016-01-30 10:27:43 --> Model Class Initialized
INFO - 2016-01-30 10:27:43 --> Model Class Initialized
INFO - 2016-01-30 10:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:27:43 --> Pagination Class Initialized
INFO - 2016-01-30 10:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:27:43 --> Final output sent to browser
DEBUG - 2016-01-30 10:27:43 --> Total execution time: 1.1307
INFO - 2016-01-30 10:30:40 --> Config Class Initialized
INFO - 2016-01-30 10:30:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:30:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:30:40 --> Utf8 Class Initialized
INFO - 2016-01-30 10:30:40 --> URI Class Initialized
INFO - 2016-01-30 10:30:40 --> Router Class Initialized
INFO - 2016-01-30 10:30:40 --> Output Class Initialized
INFO - 2016-01-30 10:30:40 --> Security Class Initialized
DEBUG - 2016-01-30 10:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:30:40 --> Input Class Initialized
INFO - 2016-01-30 10:30:40 --> Language Class Initialized
INFO - 2016-01-30 10:30:40 --> Loader Class Initialized
INFO - 2016-01-30 10:30:40 --> Helper loaded: url_helper
INFO - 2016-01-30 10:30:40 --> Helper loaded: file_helper
INFO - 2016-01-30 10:30:40 --> Helper loaded: date_helper
INFO - 2016-01-30 10:30:40 --> Database Driver Class Initialized
INFO - 2016-01-30 10:30:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:30:41 --> Controller Class Initialized
INFO - 2016-01-30 10:30:41 --> Model Class Initialized
INFO - 2016-01-30 10:30:41 --> Model Class Initialized
INFO - 2016-01-30 10:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:30:41 --> Pagination Class Initialized
INFO - 2016-01-30 10:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:30:41 --> Helper loaded: text_helper
INFO - 2016-01-30 10:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:30:41 --> Final output sent to browser
DEBUG - 2016-01-30 10:30:41 --> Total execution time: 1.1687
INFO - 2016-01-30 10:30:45 --> Config Class Initialized
INFO - 2016-01-30 10:30:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:30:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:30:45 --> Utf8 Class Initialized
INFO - 2016-01-30 10:30:45 --> URI Class Initialized
DEBUG - 2016-01-30 10:30:45 --> No URI present. Default controller set.
INFO - 2016-01-30 10:30:45 --> Router Class Initialized
INFO - 2016-01-30 10:30:45 --> Output Class Initialized
INFO - 2016-01-30 10:30:45 --> Security Class Initialized
DEBUG - 2016-01-30 10:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:30:45 --> Input Class Initialized
INFO - 2016-01-30 10:30:45 --> Language Class Initialized
INFO - 2016-01-30 10:30:45 --> Loader Class Initialized
INFO - 2016-01-30 10:30:45 --> Helper loaded: url_helper
INFO - 2016-01-30 10:30:45 --> Helper loaded: file_helper
INFO - 2016-01-30 10:30:45 --> Helper loaded: date_helper
INFO - 2016-01-30 10:30:45 --> Database Driver Class Initialized
INFO - 2016-01-30 10:30:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:30:46 --> Controller Class Initialized
INFO - 2016-01-30 10:30:46 --> Model Class Initialized
INFO - 2016-01-30 10:30:46 --> Model Class Initialized
INFO - 2016-01-30 10:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:30:46 --> Pagination Class Initialized
INFO - 2016-01-30 10:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:30:46 --> Final output sent to browser
DEBUG - 2016-01-30 10:30:46 --> Total execution time: 1.1379
INFO - 2016-01-30 10:30:47 --> Config Class Initialized
INFO - 2016-01-30 10:30:47 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:30:47 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:30:47 --> Utf8 Class Initialized
INFO - 2016-01-30 10:30:47 --> URI Class Initialized
INFO - 2016-01-30 10:30:47 --> Router Class Initialized
INFO - 2016-01-30 10:30:47 --> Output Class Initialized
INFO - 2016-01-30 10:30:47 --> Security Class Initialized
DEBUG - 2016-01-30 10:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:30:47 --> Input Class Initialized
INFO - 2016-01-30 10:30:47 --> Language Class Initialized
INFO - 2016-01-30 10:30:47 --> Loader Class Initialized
INFO - 2016-01-30 10:30:47 --> Helper loaded: url_helper
INFO - 2016-01-30 10:30:47 --> Helper loaded: file_helper
INFO - 2016-01-30 10:30:47 --> Helper loaded: date_helper
INFO - 2016-01-30 10:30:47 --> Database Driver Class Initialized
INFO - 2016-01-30 10:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:30:48 --> Controller Class Initialized
INFO - 2016-01-30 10:30:48 --> Model Class Initialized
INFO - 2016-01-30 10:30:48 --> Model Class Initialized
INFO - 2016-01-30 10:30:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:30:48 --> Pagination Class Initialized
INFO - 2016-01-30 10:30:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:30:48 --> Helper loaded: text_helper
INFO - 2016-01-30 10:30:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:30:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:30:48 --> Final output sent to browser
DEBUG - 2016-01-30 10:30:48 --> Total execution time: 1.1778
INFO - 2016-01-30 10:30:52 --> Config Class Initialized
INFO - 2016-01-30 10:30:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:30:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:30:52 --> Utf8 Class Initialized
INFO - 2016-01-30 10:30:52 --> URI Class Initialized
DEBUG - 2016-01-30 10:30:52 --> No URI present. Default controller set.
INFO - 2016-01-30 10:30:52 --> Router Class Initialized
INFO - 2016-01-30 10:30:52 --> Output Class Initialized
INFO - 2016-01-30 10:30:52 --> Security Class Initialized
DEBUG - 2016-01-30 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:30:52 --> Input Class Initialized
INFO - 2016-01-30 10:30:52 --> Language Class Initialized
INFO - 2016-01-30 10:30:52 --> Loader Class Initialized
INFO - 2016-01-30 10:30:52 --> Helper loaded: url_helper
INFO - 2016-01-30 10:30:52 --> Helper loaded: file_helper
INFO - 2016-01-30 10:30:52 --> Helper loaded: date_helper
INFO - 2016-01-30 10:30:52 --> Database Driver Class Initialized
INFO - 2016-01-30 10:30:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:30:53 --> Controller Class Initialized
INFO - 2016-01-30 10:30:53 --> Model Class Initialized
INFO - 2016-01-30 10:30:53 --> Model Class Initialized
INFO - 2016-01-30 10:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:30:53 --> Pagination Class Initialized
INFO - 2016-01-30 10:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:30:53 --> Final output sent to browser
DEBUG - 2016-01-30 10:30:53 --> Total execution time: 1.1073
INFO - 2016-01-30 10:30:56 --> Config Class Initialized
INFO - 2016-01-30 10:30:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:30:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:30:56 --> Utf8 Class Initialized
INFO - 2016-01-30 10:30:56 --> URI Class Initialized
INFO - 2016-01-30 10:30:56 --> Router Class Initialized
INFO - 2016-01-30 10:30:56 --> Output Class Initialized
INFO - 2016-01-30 10:30:56 --> Security Class Initialized
DEBUG - 2016-01-30 10:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:30:56 --> Input Class Initialized
INFO - 2016-01-30 10:30:56 --> Language Class Initialized
INFO - 2016-01-30 10:30:56 --> Loader Class Initialized
INFO - 2016-01-30 10:30:56 --> Helper loaded: url_helper
INFO - 2016-01-30 10:30:56 --> Helper loaded: file_helper
INFO - 2016-01-30 10:30:56 --> Helper loaded: date_helper
INFO - 2016-01-30 10:30:56 --> Database Driver Class Initialized
INFO - 2016-01-30 10:30:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:30:57 --> Controller Class Initialized
INFO - 2016-01-30 10:30:57 --> Model Class Initialized
INFO - 2016-01-30 10:30:57 --> Model Class Initialized
INFO - 2016-01-30 10:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:30:57 --> Pagination Class Initialized
INFO - 2016-01-30 10:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:30:57 --> Helper loaded: text_helper
INFO - 2016-01-30 10:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:30:57 --> Final output sent to browser
DEBUG - 2016-01-30 10:30:57 --> Total execution time: 1.1633
INFO - 2016-01-30 10:31:04 --> Config Class Initialized
INFO - 2016-01-30 10:31:04 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:31:04 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:31:04 --> Utf8 Class Initialized
INFO - 2016-01-30 10:31:04 --> URI Class Initialized
INFO - 2016-01-30 10:31:04 --> Router Class Initialized
INFO - 2016-01-30 10:31:04 --> Output Class Initialized
INFO - 2016-01-30 10:31:04 --> Security Class Initialized
DEBUG - 2016-01-30 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:31:04 --> Input Class Initialized
INFO - 2016-01-30 10:31:04 --> Language Class Initialized
INFO - 2016-01-30 10:31:04 --> Loader Class Initialized
INFO - 2016-01-30 10:31:04 --> Helper loaded: url_helper
INFO - 2016-01-30 10:31:04 --> Helper loaded: file_helper
INFO - 2016-01-30 10:31:04 --> Helper loaded: date_helper
INFO - 2016-01-30 10:31:04 --> Database Driver Class Initialized
INFO - 2016-01-30 10:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:31:05 --> Controller Class Initialized
INFO - 2016-01-30 10:31:06 --> Model Class Initialized
INFO - 2016-01-30 10:31:06 --> Model Class Initialized
INFO - 2016-01-30 10:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:31:06 --> Pagination Class Initialized
INFO - 2016-01-30 10:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 10:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 10:31:06 --> Final output sent to browser
DEBUG - 2016-01-30 10:31:06 --> Total execution time: 1.1445
INFO - 2016-01-30 10:31:07 --> Config Class Initialized
INFO - 2016-01-30 10:31:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:31:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:31:07 --> Utf8 Class Initialized
INFO - 2016-01-30 10:31:07 --> URI Class Initialized
DEBUG - 2016-01-30 10:31:07 --> No URI present. Default controller set.
INFO - 2016-01-30 10:31:07 --> Router Class Initialized
INFO - 2016-01-30 10:31:07 --> Output Class Initialized
INFO - 2016-01-30 10:31:07 --> Security Class Initialized
DEBUG - 2016-01-30 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:31:07 --> Input Class Initialized
INFO - 2016-01-30 10:31:07 --> Language Class Initialized
INFO - 2016-01-30 10:31:07 --> Loader Class Initialized
INFO - 2016-01-30 10:31:07 --> Helper loaded: url_helper
INFO - 2016-01-30 10:31:07 --> Helper loaded: file_helper
INFO - 2016-01-30 10:31:07 --> Helper loaded: date_helper
INFO - 2016-01-30 10:31:07 --> Database Driver Class Initialized
INFO - 2016-01-30 10:31:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:31:08 --> Controller Class Initialized
INFO - 2016-01-30 10:31:08 --> Model Class Initialized
INFO - 2016-01-30 10:31:08 --> Model Class Initialized
INFO - 2016-01-30 10:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:31:09 --> Pagination Class Initialized
INFO - 2016-01-30 10:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:31:09 --> Final output sent to browser
DEBUG - 2016-01-30 10:31:09 --> Total execution time: 1.1205
INFO - 2016-01-30 10:45:07 --> Config Class Initialized
INFO - 2016-01-30 10:45:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:45:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:45:07 --> Utf8 Class Initialized
INFO - 2016-01-30 10:45:07 --> URI Class Initialized
DEBUG - 2016-01-30 10:45:07 --> No URI present. Default controller set.
INFO - 2016-01-30 10:45:07 --> Router Class Initialized
INFO - 2016-01-30 10:45:07 --> Output Class Initialized
INFO - 2016-01-30 10:45:07 --> Security Class Initialized
DEBUG - 2016-01-30 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:45:07 --> Input Class Initialized
INFO - 2016-01-30 10:45:07 --> Language Class Initialized
INFO - 2016-01-30 10:45:07 --> Loader Class Initialized
INFO - 2016-01-30 10:45:07 --> Helper loaded: url_helper
INFO - 2016-01-30 10:45:07 --> Helper loaded: file_helper
INFO - 2016-01-30 10:45:07 --> Helper loaded: date_helper
INFO - 2016-01-30 10:45:07 --> Database Driver Class Initialized
INFO - 2016-01-30 10:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:45:08 --> Controller Class Initialized
INFO - 2016-01-30 10:45:08 --> Model Class Initialized
INFO - 2016-01-30 10:45:08 --> Model Class Initialized
INFO - 2016-01-30 10:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:45:08 --> Pagination Class Initialized
INFO - 2016-01-30 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:45:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:45:09 --> Final output sent to browser
DEBUG - 2016-01-30 10:45:09 --> Total execution time: 1.1985
INFO - 2016-01-30 10:45:12 --> Config Class Initialized
INFO - 2016-01-30 10:45:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:45:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:45:12 --> Utf8 Class Initialized
INFO - 2016-01-30 10:45:12 --> URI Class Initialized
INFO - 2016-01-30 10:45:12 --> Router Class Initialized
INFO - 2016-01-30 10:45:12 --> Output Class Initialized
INFO - 2016-01-30 10:45:12 --> Security Class Initialized
DEBUG - 2016-01-30 10:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:45:12 --> Input Class Initialized
INFO - 2016-01-30 10:45:12 --> Language Class Initialized
INFO - 2016-01-30 10:45:12 --> Loader Class Initialized
INFO - 2016-01-30 10:45:12 --> Helper loaded: url_helper
INFO - 2016-01-30 10:45:12 --> Helper loaded: file_helper
INFO - 2016-01-30 10:45:12 --> Helper loaded: date_helper
INFO - 2016-01-30 10:45:12 --> Database Driver Class Initialized
INFO - 2016-01-30 10:45:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:45:13 --> Controller Class Initialized
INFO - 2016-01-30 10:45:13 --> Model Class Initialized
INFO - 2016-01-30 10:45:13 --> Model Class Initialized
INFO - 2016-01-30 10:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:45:13 --> Pagination Class Initialized
INFO - 2016-01-30 10:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:45:13 --> Helper loaded: text_helper
INFO - 2016-01-30 10:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:45:13 --> Final output sent to browser
DEBUG - 2016-01-30 10:45:13 --> Total execution time: 1.1773
INFO - 2016-01-30 10:45:15 --> Config Class Initialized
INFO - 2016-01-30 10:45:15 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:45:15 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:45:15 --> Utf8 Class Initialized
INFO - 2016-01-30 10:45:15 --> URI Class Initialized
DEBUG - 2016-01-30 10:45:15 --> No URI present. Default controller set.
INFO - 2016-01-30 10:45:15 --> Router Class Initialized
INFO - 2016-01-30 10:45:15 --> Output Class Initialized
INFO - 2016-01-30 10:45:15 --> Security Class Initialized
DEBUG - 2016-01-30 10:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:45:15 --> Input Class Initialized
INFO - 2016-01-30 10:45:15 --> Language Class Initialized
INFO - 2016-01-30 10:45:15 --> Loader Class Initialized
INFO - 2016-01-30 10:45:15 --> Helper loaded: url_helper
INFO - 2016-01-30 10:45:15 --> Helper loaded: file_helper
INFO - 2016-01-30 10:45:15 --> Helper loaded: date_helper
INFO - 2016-01-30 10:45:15 --> Database Driver Class Initialized
INFO - 2016-01-30 10:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:45:16 --> Controller Class Initialized
INFO - 2016-01-30 10:45:16 --> Model Class Initialized
INFO - 2016-01-30 10:45:16 --> Model Class Initialized
INFO - 2016-01-30 10:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:45:16 --> Pagination Class Initialized
INFO - 2016-01-30 10:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:45:16 --> Final output sent to browser
DEBUG - 2016-01-30 10:45:16 --> Total execution time: 1.1235
INFO - 2016-01-30 10:45:18 --> Config Class Initialized
INFO - 2016-01-30 10:45:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:45:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:45:18 --> Utf8 Class Initialized
INFO - 2016-01-30 10:45:18 --> URI Class Initialized
INFO - 2016-01-30 10:45:18 --> Router Class Initialized
INFO - 2016-01-30 10:45:18 --> Output Class Initialized
INFO - 2016-01-30 10:45:18 --> Security Class Initialized
DEBUG - 2016-01-30 10:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:45:18 --> Input Class Initialized
INFO - 2016-01-30 10:45:18 --> Language Class Initialized
INFO - 2016-01-30 10:45:18 --> Loader Class Initialized
INFO - 2016-01-30 10:45:18 --> Helper loaded: url_helper
INFO - 2016-01-30 10:45:18 --> Helper loaded: file_helper
INFO - 2016-01-30 10:45:18 --> Helper loaded: date_helper
INFO - 2016-01-30 10:45:18 --> Database Driver Class Initialized
INFO - 2016-01-30 10:45:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:45:19 --> Controller Class Initialized
INFO - 2016-01-30 10:45:19 --> Model Class Initialized
INFO - 2016-01-30 10:45:19 --> Model Class Initialized
INFO - 2016-01-30 10:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:45:19 --> Pagination Class Initialized
INFO - 2016-01-30 10:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:45:19 --> Helper loaded: text_helper
INFO - 2016-01-30 10:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:45:19 --> Final output sent to browser
DEBUG - 2016-01-30 10:45:19 --> Total execution time: 1.1483
INFO - 2016-01-30 10:45:22 --> Config Class Initialized
INFO - 2016-01-30 10:45:22 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:45:22 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:45:22 --> Utf8 Class Initialized
INFO - 2016-01-30 10:45:22 --> URI Class Initialized
DEBUG - 2016-01-30 10:45:22 --> No URI present. Default controller set.
INFO - 2016-01-30 10:45:22 --> Router Class Initialized
INFO - 2016-01-30 10:45:22 --> Output Class Initialized
INFO - 2016-01-30 10:45:22 --> Security Class Initialized
DEBUG - 2016-01-30 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:45:22 --> Input Class Initialized
INFO - 2016-01-30 10:45:22 --> Language Class Initialized
INFO - 2016-01-30 10:45:22 --> Loader Class Initialized
INFO - 2016-01-30 10:45:22 --> Helper loaded: url_helper
INFO - 2016-01-30 10:45:22 --> Helper loaded: file_helper
INFO - 2016-01-30 10:45:22 --> Helper loaded: date_helper
INFO - 2016-01-30 10:45:22 --> Database Driver Class Initialized
INFO - 2016-01-30 10:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:45:23 --> Controller Class Initialized
INFO - 2016-01-30 10:45:23 --> Model Class Initialized
INFO - 2016-01-30 10:45:23 --> Model Class Initialized
INFO - 2016-01-30 10:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:45:23 --> Pagination Class Initialized
INFO - 2016-01-30 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:45:23 --> Final output sent to browser
DEBUG - 2016-01-30 10:45:23 --> Total execution time: 1.1059
INFO - 2016-01-30 10:53:33 --> Config Class Initialized
INFO - 2016-01-30 10:53:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:53:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:53:33 --> Utf8 Class Initialized
INFO - 2016-01-30 10:53:33 --> URI Class Initialized
DEBUG - 2016-01-30 10:53:33 --> No URI present. Default controller set.
INFO - 2016-01-30 10:53:33 --> Router Class Initialized
INFO - 2016-01-30 10:53:33 --> Output Class Initialized
INFO - 2016-01-30 10:53:33 --> Security Class Initialized
DEBUG - 2016-01-30 10:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:53:33 --> Input Class Initialized
INFO - 2016-01-30 10:53:33 --> Language Class Initialized
INFO - 2016-01-30 10:53:33 --> Loader Class Initialized
INFO - 2016-01-30 10:53:33 --> Helper loaded: url_helper
INFO - 2016-01-30 10:53:33 --> Helper loaded: file_helper
INFO - 2016-01-30 10:53:33 --> Helper loaded: date_helper
INFO - 2016-01-30 10:53:33 --> Database Driver Class Initialized
INFO - 2016-01-30 10:53:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:53:34 --> Controller Class Initialized
INFO - 2016-01-30 10:53:34 --> Model Class Initialized
INFO - 2016-01-30 10:53:34 --> Model Class Initialized
INFO - 2016-01-30 10:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:53:34 --> Pagination Class Initialized
INFO - 2016-01-30 10:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:53:34 --> Final output sent to browser
DEBUG - 2016-01-30 10:53:34 --> Total execution time: 1.1340
INFO - 2016-01-30 10:53:38 --> Config Class Initialized
INFO - 2016-01-30 10:53:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:53:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:53:38 --> Utf8 Class Initialized
INFO - 2016-01-30 10:53:38 --> URI Class Initialized
INFO - 2016-01-30 10:53:38 --> Router Class Initialized
INFO - 2016-01-30 10:53:38 --> Output Class Initialized
INFO - 2016-01-30 10:53:38 --> Security Class Initialized
DEBUG - 2016-01-30 10:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:53:38 --> Input Class Initialized
INFO - 2016-01-30 10:53:38 --> Language Class Initialized
INFO - 2016-01-30 10:53:38 --> Loader Class Initialized
INFO - 2016-01-30 10:53:38 --> Helper loaded: url_helper
INFO - 2016-01-30 10:53:38 --> Helper loaded: file_helper
INFO - 2016-01-30 10:53:38 --> Helper loaded: date_helper
INFO - 2016-01-30 10:53:38 --> Database Driver Class Initialized
INFO - 2016-01-30 10:53:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:53:39 --> Controller Class Initialized
INFO - 2016-01-30 10:53:39 --> Model Class Initialized
INFO - 2016-01-30 10:53:39 --> Model Class Initialized
INFO - 2016-01-30 10:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:53:39 --> Pagination Class Initialized
INFO - 2016-01-30 10:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:53:39 --> Helper loaded: text_helper
INFO - 2016-01-30 10:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:53:39 --> Final output sent to browser
DEBUG - 2016-01-30 10:53:39 --> Total execution time: 1.1608
INFO - 2016-01-30 10:53:41 --> Config Class Initialized
INFO - 2016-01-30 10:53:41 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:53:41 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:53:41 --> Utf8 Class Initialized
INFO - 2016-01-30 10:53:41 --> URI Class Initialized
DEBUG - 2016-01-30 10:53:41 --> No URI present. Default controller set.
INFO - 2016-01-30 10:53:41 --> Router Class Initialized
INFO - 2016-01-30 10:53:41 --> Output Class Initialized
INFO - 2016-01-30 10:53:41 --> Security Class Initialized
DEBUG - 2016-01-30 10:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:53:41 --> Input Class Initialized
INFO - 2016-01-30 10:53:41 --> Language Class Initialized
INFO - 2016-01-30 10:53:41 --> Loader Class Initialized
INFO - 2016-01-30 10:53:41 --> Helper loaded: url_helper
INFO - 2016-01-30 10:53:41 --> Helper loaded: file_helper
INFO - 2016-01-30 10:53:41 --> Helper loaded: date_helper
INFO - 2016-01-30 10:53:41 --> Database Driver Class Initialized
INFO - 2016-01-30 10:53:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:53:42 --> Controller Class Initialized
INFO - 2016-01-30 10:53:42 --> Model Class Initialized
INFO - 2016-01-30 10:53:42 --> Model Class Initialized
INFO - 2016-01-30 10:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:53:42 --> Pagination Class Initialized
INFO - 2016-01-30 10:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:53:42 --> Final output sent to browser
DEBUG - 2016-01-30 10:53:42 --> Total execution time: 1.0761
INFO - 2016-01-30 10:53:43 --> Config Class Initialized
INFO - 2016-01-30 10:53:43 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:53:43 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:53:43 --> Utf8 Class Initialized
INFO - 2016-01-30 10:53:43 --> URI Class Initialized
INFO - 2016-01-30 10:53:43 --> Router Class Initialized
INFO - 2016-01-30 10:53:43 --> Output Class Initialized
INFO - 2016-01-30 10:53:43 --> Security Class Initialized
DEBUG - 2016-01-30 10:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:53:43 --> Input Class Initialized
INFO - 2016-01-30 10:53:43 --> Language Class Initialized
INFO - 2016-01-30 10:53:43 --> Loader Class Initialized
INFO - 2016-01-30 10:53:43 --> Helper loaded: url_helper
INFO - 2016-01-30 10:53:43 --> Helper loaded: file_helper
INFO - 2016-01-30 10:53:43 --> Helper loaded: date_helper
INFO - 2016-01-30 10:53:43 --> Database Driver Class Initialized
INFO - 2016-01-30 10:53:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:53:44 --> Controller Class Initialized
INFO - 2016-01-30 10:53:44 --> Model Class Initialized
INFO - 2016-01-30 10:53:44 --> Model Class Initialized
INFO - 2016-01-30 10:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:53:44 --> Pagination Class Initialized
INFO - 2016-01-30 10:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:53:44 --> Helper loaded: text_helper
INFO - 2016-01-30 10:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:53:44 --> Final output sent to browser
DEBUG - 2016-01-30 10:53:44 --> Total execution time: 1.1700
INFO - 2016-01-30 10:53:46 --> Config Class Initialized
INFO - 2016-01-30 10:53:46 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:53:46 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:53:46 --> Utf8 Class Initialized
INFO - 2016-01-30 10:53:46 --> URI Class Initialized
DEBUG - 2016-01-30 10:53:46 --> No URI present. Default controller set.
INFO - 2016-01-30 10:53:46 --> Router Class Initialized
INFO - 2016-01-30 10:53:46 --> Output Class Initialized
INFO - 2016-01-30 10:53:46 --> Security Class Initialized
DEBUG - 2016-01-30 10:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:53:46 --> Input Class Initialized
INFO - 2016-01-30 10:53:46 --> Language Class Initialized
INFO - 2016-01-30 10:53:46 --> Loader Class Initialized
INFO - 2016-01-30 10:53:46 --> Helper loaded: url_helper
INFO - 2016-01-30 10:53:47 --> Helper loaded: file_helper
INFO - 2016-01-30 10:53:47 --> Helper loaded: date_helper
INFO - 2016-01-30 10:53:47 --> Database Driver Class Initialized
INFO - 2016-01-30 10:53:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:53:48 --> Controller Class Initialized
INFO - 2016-01-30 10:53:48 --> Model Class Initialized
INFO - 2016-01-30 10:53:48 --> Model Class Initialized
INFO - 2016-01-30 10:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:53:48 --> Pagination Class Initialized
INFO - 2016-01-30 10:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:53:48 --> Final output sent to browser
DEBUG - 2016-01-30 10:53:48 --> Total execution time: 1.2418
INFO - 2016-01-30 10:54:37 --> Config Class Initialized
INFO - 2016-01-30 10:54:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:54:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:54:37 --> Utf8 Class Initialized
INFO - 2016-01-30 10:54:37 --> URI Class Initialized
DEBUG - 2016-01-30 10:54:37 --> No URI present. Default controller set.
INFO - 2016-01-30 10:54:37 --> Router Class Initialized
INFO - 2016-01-30 10:54:37 --> Output Class Initialized
INFO - 2016-01-30 10:54:37 --> Security Class Initialized
DEBUG - 2016-01-30 10:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:54:37 --> Input Class Initialized
INFO - 2016-01-30 10:54:37 --> Language Class Initialized
INFO - 2016-01-30 10:54:37 --> Loader Class Initialized
INFO - 2016-01-30 10:54:37 --> Helper loaded: url_helper
INFO - 2016-01-30 10:54:37 --> Helper loaded: file_helper
INFO - 2016-01-30 10:54:37 --> Helper loaded: date_helper
INFO - 2016-01-30 10:54:37 --> Database Driver Class Initialized
INFO - 2016-01-30 10:54:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:54:38 --> Controller Class Initialized
INFO - 2016-01-30 10:54:38 --> Model Class Initialized
INFO - 2016-01-30 10:54:38 --> Model Class Initialized
INFO - 2016-01-30 10:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:54:38 --> Pagination Class Initialized
INFO - 2016-01-30 10:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:54:38 --> Final output sent to browser
DEBUG - 2016-01-30 10:54:38 --> Total execution time: 1.1135
INFO - 2016-01-30 10:54:41 --> Config Class Initialized
INFO - 2016-01-30 10:54:41 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:54:41 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:54:41 --> Utf8 Class Initialized
INFO - 2016-01-30 10:54:41 --> URI Class Initialized
INFO - 2016-01-30 10:54:41 --> Router Class Initialized
INFO - 2016-01-30 10:54:41 --> Output Class Initialized
INFO - 2016-01-30 10:54:41 --> Security Class Initialized
DEBUG - 2016-01-30 10:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:54:41 --> Input Class Initialized
INFO - 2016-01-30 10:54:41 --> Language Class Initialized
INFO - 2016-01-30 10:54:41 --> Loader Class Initialized
INFO - 2016-01-30 10:54:41 --> Helper loaded: url_helper
INFO - 2016-01-30 10:54:41 --> Helper loaded: file_helper
INFO - 2016-01-30 10:54:41 --> Helper loaded: date_helper
INFO - 2016-01-30 10:54:41 --> Database Driver Class Initialized
INFO - 2016-01-30 10:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:54:42 --> Controller Class Initialized
INFO - 2016-01-30 10:54:42 --> Model Class Initialized
INFO - 2016-01-30 10:54:42 --> Model Class Initialized
INFO - 2016-01-30 10:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:54:42 --> Pagination Class Initialized
INFO - 2016-01-30 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:54:42 --> Helper loaded: text_helper
INFO - 2016-01-30 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:54:42 --> Final output sent to browser
DEBUG - 2016-01-30 10:54:42 --> Total execution time: 1.1494
INFO - 2016-01-30 10:54:57 --> Config Class Initialized
INFO - 2016-01-30 10:54:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:54:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:54:57 --> Utf8 Class Initialized
INFO - 2016-01-30 10:54:57 --> URI Class Initialized
DEBUG - 2016-01-30 10:54:57 --> No URI present. Default controller set.
INFO - 2016-01-30 10:54:57 --> Router Class Initialized
INFO - 2016-01-30 10:54:57 --> Output Class Initialized
INFO - 2016-01-30 10:54:57 --> Security Class Initialized
DEBUG - 2016-01-30 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:54:57 --> Input Class Initialized
INFO - 2016-01-30 10:54:57 --> Language Class Initialized
INFO - 2016-01-30 10:54:57 --> Loader Class Initialized
INFO - 2016-01-30 10:54:57 --> Helper loaded: url_helper
INFO - 2016-01-30 10:54:57 --> Helper loaded: file_helper
INFO - 2016-01-30 10:54:57 --> Helper loaded: date_helper
INFO - 2016-01-30 10:54:57 --> Database Driver Class Initialized
INFO - 2016-01-30 10:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:54:58 --> Controller Class Initialized
INFO - 2016-01-30 10:54:58 --> Model Class Initialized
INFO - 2016-01-30 10:54:58 --> Model Class Initialized
INFO - 2016-01-30 10:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:54:58 --> Pagination Class Initialized
INFO - 2016-01-30 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:54:58 --> Final output sent to browser
DEBUG - 2016-01-30 10:54:58 --> Total execution time: 1.1251
INFO - 2016-01-30 10:55:00 --> Config Class Initialized
INFO - 2016-01-30 10:55:00 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:00 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:00 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:00 --> URI Class Initialized
INFO - 2016-01-30 10:55:00 --> Router Class Initialized
INFO - 2016-01-30 10:55:00 --> Output Class Initialized
INFO - 2016-01-30 10:55:00 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:00 --> Input Class Initialized
INFO - 2016-01-30 10:55:00 --> Language Class Initialized
INFO - 2016-01-30 10:55:00 --> Loader Class Initialized
INFO - 2016-01-30 10:55:00 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:00 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:00 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:00 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:01 --> Controller Class Initialized
INFO - 2016-01-30 10:55:01 --> Model Class Initialized
INFO - 2016-01-30 10:55:01 --> Model Class Initialized
INFO - 2016-01-30 10:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:01 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:01 --> Helper loaded: text_helper
INFO - 2016-01-30 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:55:01 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:01 --> Total execution time: 1.1870
INFO - 2016-01-30 10:55:03 --> Config Class Initialized
INFO - 2016-01-30 10:55:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:03 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:03 --> URI Class Initialized
DEBUG - 2016-01-30 10:55:03 --> No URI present. Default controller set.
INFO - 2016-01-30 10:55:03 --> Router Class Initialized
INFO - 2016-01-30 10:55:03 --> Output Class Initialized
INFO - 2016-01-30 10:55:03 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:03 --> Input Class Initialized
INFO - 2016-01-30 10:55:03 --> Language Class Initialized
INFO - 2016-01-30 10:55:03 --> Loader Class Initialized
INFO - 2016-01-30 10:55:03 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:03 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:03 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:03 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:04 --> Controller Class Initialized
INFO - 2016-01-30 10:55:04 --> Model Class Initialized
INFO - 2016-01-30 10:55:04 --> Model Class Initialized
INFO - 2016-01-30 10:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:04 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:55:04 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:04 --> Total execution time: 1.1272
INFO - 2016-01-30 10:55:05 --> Config Class Initialized
INFO - 2016-01-30 10:55:05 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:05 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:05 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:05 --> URI Class Initialized
INFO - 2016-01-30 10:55:05 --> Router Class Initialized
INFO - 2016-01-30 10:55:05 --> Output Class Initialized
INFO - 2016-01-30 10:55:05 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:05 --> Input Class Initialized
INFO - 2016-01-30 10:55:05 --> Language Class Initialized
INFO - 2016-01-30 10:55:05 --> Loader Class Initialized
INFO - 2016-01-30 10:55:05 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:05 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:05 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:05 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:06 --> Controller Class Initialized
INFO - 2016-01-30 10:55:06 --> Model Class Initialized
INFO - 2016-01-30 10:55:06 --> Model Class Initialized
INFO - 2016-01-30 10:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:06 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:06 --> Helper loaded: text_helper
INFO - 2016-01-30 10:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:55:06 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:06 --> Total execution time: 1.1399
INFO - 2016-01-30 10:55:21 --> Config Class Initialized
INFO - 2016-01-30 10:55:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:21 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:21 --> URI Class Initialized
DEBUG - 2016-01-30 10:55:21 --> No URI present. Default controller set.
INFO - 2016-01-30 10:55:21 --> Router Class Initialized
INFO - 2016-01-30 10:55:21 --> Output Class Initialized
INFO - 2016-01-30 10:55:21 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:21 --> Input Class Initialized
INFO - 2016-01-30 10:55:21 --> Language Class Initialized
INFO - 2016-01-30 10:55:21 --> Loader Class Initialized
INFO - 2016-01-30 10:55:21 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:21 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:21 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:21 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:22 --> Controller Class Initialized
INFO - 2016-01-30 10:55:22 --> Model Class Initialized
INFO - 2016-01-30 10:55:22 --> Model Class Initialized
INFO - 2016-01-30 10:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:22 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:55:22 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:22 --> Total execution time: 1.1044
INFO - 2016-01-30 10:55:24 --> Config Class Initialized
INFO - 2016-01-30 10:55:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:24 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:24 --> URI Class Initialized
INFO - 2016-01-30 10:55:24 --> Router Class Initialized
INFO - 2016-01-30 10:55:24 --> Output Class Initialized
INFO - 2016-01-30 10:55:24 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:24 --> Input Class Initialized
INFO - 2016-01-30 10:55:24 --> Language Class Initialized
INFO - 2016-01-30 10:55:24 --> Loader Class Initialized
INFO - 2016-01-30 10:55:24 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:24 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:24 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:24 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:25 --> Controller Class Initialized
INFO - 2016-01-30 10:55:25 --> Model Class Initialized
INFO - 2016-01-30 10:55:25 --> Model Class Initialized
INFO - 2016-01-30 10:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:25 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:25 --> Helper loaded: text_helper
INFO - 2016-01-30 10:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:55:25 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:25 --> Total execution time: 1.1212
INFO - 2016-01-30 10:55:28 --> Config Class Initialized
INFO - 2016-01-30 10:55:28 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:55:28 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:55:28 --> Utf8 Class Initialized
INFO - 2016-01-30 10:55:28 --> URI Class Initialized
DEBUG - 2016-01-30 10:55:28 --> No URI present. Default controller set.
INFO - 2016-01-30 10:55:28 --> Router Class Initialized
INFO - 2016-01-30 10:55:28 --> Output Class Initialized
INFO - 2016-01-30 10:55:28 --> Security Class Initialized
DEBUG - 2016-01-30 10:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:55:28 --> Input Class Initialized
INFO - 2016-01-30 10:55:28 --> Language Class Initialized
INFO - 2016-01-30 10:55:28 --> Loader Class Initialized
INFO - 2016-01-30 10:55:28 --> Helper loaded: url_helper
INFO - 2016-01-30 10:55:28 --> Helper loaded: file_helper
INFO - 2016-01-30 10:55:28 --> Helper loaded: date_helper
INFO - 2016-01-30 10:55:28 --> Database Driver Class Initialized
INFO - 2016-01-30 10:55:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:55:29 --> Controller Class Initialized
INFO - 2016-01-30 10:55:29 --> Model Class Initialized
INFO - 2016-01-30 10:55:29 --> Model Class Initialized
INFO - 2016-01-30 10:55:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:55:29 --> Pagination Class Initialized
INFO - 2016-01-30 10:55:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:55:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:55:29 --> Final output sent to browser
DEBUG - 2016-01-30 10:55:29 --> Total execution time: 1.1113
INFO - 2016-01-30 10:57:33 --> Config Class Initialized
INFO - 2016-01-30 10:57:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:57:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:57:33 --> Utf8 Class Initialized
INFO - 2016-01-30 10:57:33 --> URI Class Initialized
INFO - 2016-01-30 10:57:33 --> Router Class Initialized
INFO - 2016-01-30 10:57:33 --> Output Class Initialized
INFO - 2016-01-30 10:57:33 --> Security Class Initialized
DEBUG - 2016-01-30 10:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:57:33 --> Input Class Initialized
INFO - 2016-01-30 10:57:33 --> Language Class Initialized
INFO - 2016-01-30 10:57:33 --> Loader Class Initialized
INFO - 2016-01-30 10:57:33 --> Helper loaded: url_helper
INFO - 2016-01-30 10:57:33 --> Helper loaded: file_helper
INFO - 2016-01-30 10:57:33 --> Helper loaded: date_helper
INFO - 2016-01-30 10:57:33 --> Database Driver Class Initialized
INFO - 2016-01-30 10:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:57:35 --> Controller Class Initialized
INFO - 2016-01-30 10:57:35 --> Model Class Initialized
INFO - 2016-01-30 10:57:35 --> Model Class Initialized
INFO - 2016-01-30 10:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:57:35 --> Pagination Class Initialized
INFO - 2016-01-30 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:57:35 --> Helper loaded: text_helper
INFO - 2016-01-30 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:57:35 --> Final output sent to browser
DEBUG - 2016-01-30 10:57:35 --> Total execution time: 1.1562
INFO - 2016-01-30 10:57:39 --> Config Class Initialized
INFO - 2016-01-30 10:57:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:57:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:57:39 --> Utf8 Class Initialized
INFO - 2016-01-30 10:57:39 --> URI Class Initialized
DEBUG - 2016-01-30 10:57:39 --> No URI present. Default controller set.
INFO - 2016-01-30 10:57:39 --> Router Class Initialized
INFO - 2016-01-30 10:57:39 --> Output Class Initialized
INFO - 2016-01-30 10:57:39 --> Security Class Initialized
DEBUG - 2016-01-30 10:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:57:39 --> Input Class Initialized
INFO - 2016-01-30 10:57:39 --> Language Class Initialized
INFO - 2016-01-30 10:57:39 --> Loader Class Initialized
INFO - 2016-01-30 10:57:39 --> Helper loaded: url_helper
INFO - 2016-01-30 10:57:39 --> Helper loaded: file_helper
INFO - 2016-01-30 10:57:39 --> Helper loaded: date_helper
INFO - 2016-01-30 10:57:39 --> Database Driver Class Initialized
INFO - 2016-01-30 10:57:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:57:40 --> Controller Class Initialized
INFO - 2016-01-30 10:57:40 --> Model Class Initialized
INFO - 2016-01-30 10:57:40 --> Model Class Initialized
INFO - 2016-01-30 10:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:57:40 --> Pagination Class Initialized
INFO - 2016-01-30 10:57:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:57:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:57:40 --> Final output sent to browser
DEBUG - 2016-01-30 10:57:40 --> Total execution time: 1.1150
INFO - 2016-01-30 10:57:45 --> Config Class Initialized
INFO - 2016-01-30 10:57:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:57:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:57:45 --> Utf8 Class Initialized
INFO - 2016-01-30 10:57:45 --> URI Class Initialized
INFO - 2016-01-30 10:57:45 --> Router Class Initialized
INFO - 2016-01-30 10:57:45 --> Output Class Initialized
INFO - 2016-01-30 10:57:45 --> Security Class Initialized
DEBUG - 2016-01-30 10:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:57:45 --> Input Class Initialized
INFO - 2016-01-30 10:57:45 --> Language Class Initialized
INFO - 2016-01-30 10:57:45 --> Loader Class Initialized
INFO - 2016-01-30 10:57:45 --> Helper loaded: url_helper
INFO - 2016-01-30 10:57:45 --> Helper loaded: file_helper
INFO - 2016-01-30 10:57:45 --> Helper loaded: date_helper
INFO - 2016-01-30 10:57:45 --> Database Driver Class Initialized
INFO - 2016-01-30 10:57:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:57:46 --> Controller Class Initialized
INFO - 2016-01-30 10:57:46 --> Model Class Initialized
INFO - 2016-01-30 10:57:46 --> Model Class Initialized
INFO - 2016-01-30 10:57:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:57:46 --> Pagination Class Initialized
INFO - 2016-01-30 10:57:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:57:46 --> Helper loaded: text_helper
INFO - 2016-01-30 10:57:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:57:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:57:46 --> Final output sent to browser
DEBUG - 2016-01-30 10:57:46 --> Total execution time: 1.1758
INFO - 2016-01-30 10:58:56 --> Config Class Initialized
INFO - 2016-01-30 10:58:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:58:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:58:56 --> Utf8 Class Initialized
INFO - 2016-01-30 10:58:56 --> URI Class Initialized
DEBUG - 2016-01-30 10:58:56 --> No URI present. Default controller set.
INFO - 2016-01-30 10:58:56 --> Router Class Initialized
INFO - 2016-01-30 10:58:56 --> Output Class Initialized
INFO - 2016-01-30 10:58:56 --> Security Class Initialized
DEBUG - 2016-01-30 10:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:58:56 --> Input Class Initialized
INFO - 2016-01-30 10:58:56 --> Language Class Initialized
INFO - 2016-01-30 10:58:56 --> Loader Class Initialized
INFO - 2016-01-30 10:58:56 --> Helper loaded: url_helper
INFO - 2016-01-30 10:58:56 --> Helper loaded: file_helper
INFO - 2016-01-30 10:58:56 --> Helper loaded: date_helper
INFO - 2016-01-30 10:58:56 --> Database Driver Class Initialized
INFO - 2016-01-30 10:58:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:58:57 --> Controller Class Initialized
INFO - 2016-01-30 10:58:57 --> Model Class Initialized
INFO - 2016-01-30 10:58:57 --> Model Class Initialized
INFO - 2016-01-30 10:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:58:57 --> Pagination Class Initialized
INFO - 2016-01-30 10:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:58:57 --> Final output sent to browser
DEBUG - 2016-01-30 10:58:57 --> Total execution time: 1.1093
INFO - 2016-01-30 10:58:59 --> Config Class Initialized
INFO - 2016-01-30 10:58:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:58:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:58:59 --> Utf8 Class Initialized
INFO - 2016-01-30 10:58:59 --> URI Class Initialized
INFO - 2016-01-30 10:58:59 --> Router Class Initialized
INFO - 2016-01-30 10:58:59 --> Output Class Initialized
INFO - 2016-01-30 10:58:59 --> Security Class Initialized
DEBUG - 2016-01-30 10:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:58:59 --> Input Class Initialized
INFO - 2016-01-30 10:58:59 --> Language Class Initialized
INFO - 2016-01-30 10:58:59 --> Loader Class Initialized
INFO - 2016-01-30 10:58:59 --> Helper loaded: url_helper
INFO - 2016-01-30 10:58:59 --> Helper loaded: file_helper
INFO - 2016-01-30 10:58:59 --> Helper loaded: date_helper
INFO - 2016-01-30 10:58:59 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:00 --> Controller Class Initialized
INFO - 2016-01-30 10:59:00 --> Model Class Initialized
INFO - 2016-01-30 10:59:00 --> Model Class Initialized
INFO - 2016-01-30 10:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:00 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:00 --> Helper loaded: text_helper
INFO - 2016-01-30 10:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:59:00 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:00 --> Total execution time: 1.1630
INFO - 2016-01-30 10:59:01 --> Config Class Initialized
INFO - 2016-01-30 10:59:01 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:01 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:01 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:01 --> URI Class Initialized
DEBUG - 2016-01-30 10:59:01 --> No URI present. Default controller set.
INFO - 2016-01-30 10:59:01 --> Router Class Initialized
INFO - 2016-01-30 10:59:01 --> Output Class Initialized
INFO - 2016-01-30 10:59:01 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:01 --> Input Class Initialized
INFO - 2016-01-30 10:59:01 --> Language Class Initialized
INFO - 2016-01-30 10:59:01 --> Loader Class Initialized
INFO - 2016-01-30 10:59:01 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:01 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:01 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:01 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:02 --> Controller Class Initialized
INFO - 2016-01-30 10:59:02 --> Model Class Initialized
INFO - 2016-01-30 10:59:02 --> Model Class Initialized
INFO - 2016-01-30 10:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:02 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:59:03 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:03 --> Total execution time: 1.1103
INFO - 2016-01-30 10:59:04 --> Config Class Initialized
INFO - 2016-01-30 10:59:04 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:04 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:04 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:04 --> URI Class Initialized
INFO - 2016-01-30 10:59:04 --> Router Class Initialized
INFO - 2016-01-30 10:59:04 --> Output Class Initialized
INFO - 2016-01-30 10:59:04 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:04 --> Input Class Initialized
INFO - 2016-01-30 10:59:04 --> Language Class Initialized
INFO - 2016-01-30 10:59:04 --> Loader Class Initialized
INFO - 2016-01-30 10:59:04 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:04 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:04 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:04 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:05 --> Controller Class Initialized
INFO - 2016-01-30 10:59:05 --> Model Class Initialized
INFO - 2016-01-30 10:59:05 --> Model Class Initialized
INFO - 2016-01-30 10:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:05 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:05 --> Helper loaded: text_helper
INFO - 2016-01-30 10:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:59:05 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:05 --> Total execution time: 1.1647
INFO - 2016-01-30 10:59:42 --> Config Class Initialized
INFO - 2016-01-30 10:59:42 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:42 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:42 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:42 --> URI Class Initialized
DEBUG - 2016-01-30 10:59:42 --> No URI present. Default controller set.
INFO - 2016-01-30 10:59:42 --> Router Class Initialized
INFO - 2016-01-30 10:59:42 --> Output Class Initialized
INFO - 2016-01-30 10:59:42 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:42 --> Input Class Initialized
INFO - 2016-01-30 10:59:42 --> Language Class Initialized
INFO - 2016-01-30 10:59:42 --> Loader Class Initialized
INFO - 2016-01-30 10:59:42 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:42 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:42 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:42 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:43 --> Controller Class Initialized
INFO - 2016-01-30 10:59:43 --> Model Class Initialized
INFO - 2016-01-30 10:59:43 --> Model Class Initialized
INFO - 2016-01-30 10:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:43 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:59:43 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:43 --> Total execution time: 1.1127
INFO - 2016-01-30 10:59:46 --> Config Class Initialized
INFO - 2016-01-30 10:59:46 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:46 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:46 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:46 --> URI Class Initialized
INFO - 2016-01-30 10:59:46 --> Router Class Initialized
INFO - 2016-01-30 10:59:46 --> Output Class Initialized
INFO - 2016-01-30 10:59:46 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:46 --> Input Class Initialized
INFO - 2016-01-30 10:59:46 --> Language Class Initialized
INFO - 2016-01-30 10:59:46 --> Loader Class Initialized
INFO - 2016-01-30 10:59:46 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:46 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:46 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:46 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:47 --> Controller Class Initialized
INFO - 2016-01-30 10:59:47 --> Model Class Initialized
INFO - 2016-01-30 10:59:47 --> Model Class Initialized
INFO - 2016-01-30 10:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:47 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:47 --> Helper loaded: text_helper
INFO - 2016-01-30 10:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:59:47 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:47 --> Total execution time: 1.1333
INFO - 2016-01-30 10:59:48 --> Config Class Initialized
INFO - 2016-01-30 10:59:48 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:48 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:48 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:48 --> URI Class Initialized
DEBUG - 2016-01-30 10:59:48 --> No URI present. Default controller set.
INFO - 2016-01-30 10:59:48 --> Router Class Initialized
INFO - 2016-01-30 10:59:48 --> Output Class Initialized
INFO - 2016-01-30 10:59:48 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:48 --> Input Class Initialized
INFO - 2016-01-30 10:59:48 --> Language Class Initialized
INFO - 2016-01-30 10:59:48 --> Loader Class Initialized
INFO - 2016-01-30 10:59:48 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:48 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:48 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:48 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:49 --> Controller Class Initialized
INFO - 2016-01-30 10:59:49 --> Model Class Initialized
INFO - 2016-01-30 10:59:49 --> Model Class Initialized
INFO - 2016-01-30 10:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:49 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:59:49 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:49 --> Total execution time: 1.1143
INFO - 2016-01-30 10:59:51 --> Config Class Initialized
INFO - 2016-01-30 10:59:51 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:51 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:51 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:51 --> URI Class Initialized
INFO - 2016-01-30 10:59:51 --> Router Class Initialized
INFO - 2016-01-30 10:59:51 --> Output Class Initialized
INFO - 2016-01-30 10:59:51 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:51 --> Input Class Initialized
INFO - 2016-01-30 10:59:51 --> Language Class Initialized
INFO - 2016-01-30 10:59:51 --> Loader Class Initialized
INFO - 2016-01-30 10:59:51 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:51 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:51 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:51 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:52 --> Controller Class Initialized
INFO - 2016-01-30 10:59:52 --> Model Class Initialized
INFO - 2016-01-30 10:59:52 --> Model Class Initialized
INFO - 2016-01-30 10:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:52 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:52 --> Helper loaded: text_helper
INFO - 2016-01-30 10:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 10:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 10:59:52 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:52 --> Total execution time: 1.1123
INFO - 2016-01-30 10:59:57 --> Config Class Initialized
INFO - 2016-01-30 10:59:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:57 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:57 --> URI Class Initialized
DEBUG - 2016-01-30 10:59:57 --> No URI present. Default controller set.
INFO - 2016-01-30 10:59:57 --> Router Class Initialized
INFO - 2016-01-30 10:59:57 --> Output Class Initialized
INFO - 2016-01-30 10:59:57 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:57 --> Input Class Initialized
INFO - 2016-01-30 10:59:57 --> Language Class Initialized
INFO - 2016-01-30 10:59:57 --> Loader Class Initialized
INFO - 2016-01-30 10:59:57 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:57 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:57 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:57 --> Database Driver Class Initialized
INFO - 2016-01-30 10:59:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 10:59:58 --> Controller Class Initialized
INFO - 2016-01-30 10:59:58 --> Model Class Initialized
INFO - 2016-01-30 10:59:58 --> Model Class Initialized
INFO - 2016-01-30 10:59:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 10:59:58 --> Pagination Class Initialized
INFO - 2016-01-30 10:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 10:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 10:59:58 --> Final output sent to browser
DEBUG - 2016-01-30 10:59:58 --> Total execution time: 1.0770
INFO - 2016-01-30 10:59:59 --> Config Class Initialized
INFO - 2016-01-30 10:59:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 10:59:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 10:59:59 --> Utf8 Class Initialized
INFO - 2016-01-30 10:59:59 --> URI Class Initialized
INFO - 2016-01-30 10:59:59 --> Router Class Initialized
INFO - 2016-01-30 10:59:59 --> Output Class Initialized
INFO - 2016-01-30 10:59:59 --> Security Class Initialized
DEBUG - 2016-01-30 10:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 10:59:59 --> Input Class Initialized
INFO - 2016-01-30 10:59:59 --> Language Class Initialized
INFO - 2016-01-30 10:59:59 --> Loader Class Initialized
INFO - 2016-01-30 10:59:59 --> Helper loaded: url_helper
INFO - 2016-01-30 10:59:59 --> Helper loaded: file_helper
INFO - 2016-01-30 10:59:59 --> Helper loaded: date_helper
INFO - 2016-01-30 10:59:59 --> Database Driver Class Initialized
INFO - 2016-01-30 11:00:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:00:00 --> Controller Class Initialized
INFO - 2016-01-30 11:00:00 --> Model Class Initialized
INFO - 2016-01-30 11:00:00 --> Model Class Initialized
INFO - 2016-01-30 11:00:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:00:00 --> Pagination Class Initialized
INFO - 2016-01-30 11:00:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:00:00 --> Helper loaded: text_helper
INFO - 2016-01-30 11:00:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:00:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:00:00 --> Final output sent to browser
DEBUG - 2016-01-30 11:00:00 --> Total execution time: 1.1528
INFO - 2016-01-30 11:00:50 --> Config Class Initialized
INFO - 2016-01-30 11:00:50 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:00:50 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:00:51 --> Utf8 Class Initialized
INFO - 2016-01-30 11:00:51 --> URI Class Initialized
DEBUG - 2016-01-30 11:00:51 --> No URI present. Default controller set.
INFO - 2016-01-30 11:00:51 --> Router Class Initialized
INFO - 2016-01-30 11:00:51 --> Output Class Initialized
INFO - 2016-01-30 11:00:51 --> Security Class Initialized
DEBUG - 2016-01-30 11:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:00:51 --> Input Class Initialized
INFO - 2016-01-30 11:00:51 --> Language Class Initialized
INFO - 2016-01-30 11:00:51 --> Loader Class Initialized
INFO - 2016-01-30 11:00:51 --> Helper loaded: url_helper
INFO - 2016-01-30 11:00:51 --> Helper loaded: file_helper
INFO - 2016-01-30 11:00:51 --> Helper loaded: date_helper
INFO - 2016-01-30 11:00:51 --> Database Driver Class Initialized
INFO - 2016-01-30 11:00:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:00:52 --> Controller Class Initialized
INFO - 2016-01-30 11:00:52 --> Model Class Initialized
INFO - 2016-01-30 11:00:52 --> Model Class Initialized
INFO - 2016-01-30 11:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:00:52 --> Pagination Class Initialized
INFO - 2016-01-30 11:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 11:00:52 --> Final output sent to browser
DEBUG - 2016-01-30 11:00:52 --> Total execution time: 1.1232
INFO - 2016-01-30 11:00:53 --> Config Class Initialized
INFO - 2016-01-30 11:00:53 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:00:53 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:00:53 --> Utf8 Class Initialized
INFO - 2016-01-30 11:00:53 --> URI Class Initialized
INFO - 2016-01-30 11:00:53 --> Router Class Initialized
INFO - 2016-01-30 11:00:53 --> Output Class Initialized
INFO - 2016-01-30 11:00:53 --> Security Class Initialized
DEBUG - 2016-01-30 11:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:00:53 --> Input Class Initialized
INFO - 2016-01-30 11:00:53 --> Language Class Initialized
INFO - 2016-01-30 11:00:53 --> Loader Class Initialized
INFO - 2016-01-30 11:00:53 --> Helper loaded: url_helper
INFO - 2016-01-30 11:00:53 --> Helper loaded: file_helper
INFO - 2016-01-30 11:00:53 --> Helper loaded: date_helper
INFO - 2016-01-30 11:00:53 --> Database Driver Class Initialized
INFO - 2016-01-30 11:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:00:54 --> Controller Class Initialized
INFO - 2016-01-30 11:00:54 --> Model Class Initialized
INFO - 2016-01-30 11:00:54 --> Model Class Initialized
INFO - 2016-01-30 11:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:00:54 --> Pagination Class Initialized
INFO - 2016-01-30 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:00:54 --> Helper loaded: text_helper
INFO - 2016-01-30 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:00:54 --> Final output sent to browser
DEBUG - 2016-01-30 11:00:54 --> Total execution time: 1.2003
INFO - 2016-01-30 11:00:56 --> Config Class Initialized
INFO - 2016-01-30 11:00:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:00:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:00:56 --> Utf8 Class Initialized
INFO - 2016-01-30 11:00:56 --> URI Class Initialized
DEBUG - 2016-01-30 11:00:56 --> No URI present. Default controller set.
INFO - 2016-01-30 11:00:56 --> Router Class Initialized
INFO - 2016-01-30 11:00:56 --> Output Class Initialized
INFO - 2016-01-30 11:00:56 --> Security Class Initialized
DEBUG - 2016-01-30 11:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:00:56 --> Input Class Initialized
INFO - 2016-01-30 11:00:56 --> Language Class Initialized
INFO - 2016-01-30 11:00:56 --> Loader Class Initialized
INFO - 2016-01-30 11:00:56 --> Helper loaded: url_helper
INFO - 2016-01-30 11:00:56 --> Helper loaded: file_helper
INFO - 2016-01-30 11:00:56 --> Helper loaded: date_helper
INFO - 2016-01-30 11:00:56 --> Database Driver Class Initialized
INFO - 2016-01-30 11:00:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:00:57 --> Controller Class Initialized
INFO - 2016-01-30 11:00:57 --> Model Class Initialized
INFO - 2016-01-30 11:00:57 --> Model Class Initialized
INFO - 2016-01-30 11:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:00:57 --> Pagination Class Initialized
INFO - 2016-01-30 11:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 11:00:57 --> Final output sent to browser
DEBUG - 2016-01-30 11:00:57 --> Total execution time: 1.1120
INFO - 2016-01-30 11:00:59 --> Config Class Initialized
INFO - 2016-01-30 11:00:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:00:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:00:59 --> Utf8 Class Initialized
INFO - 2016-01-30 11:00:59 --> URI Class Initialized
INFO - 2016-01-30 11:00:59 --> Router Class Initialized
INFO - 2016-01-30 11:00:59 --> Output Class Initialized
INFO - 2016-01-30 11:00:59 --> Security Class Initialized
DEBUG - 2016-01-30 11:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:00:59 --> Input Class Initialized
INFO - 2016-01-30 11:00:59 --> Language Class Initialized
INFO - 2016-01-30 11:00:59 --> Loader Class Initialized
INFO - 2016-01-30 11:00:59 --> Helper loaded: url_helper
INFO - 2016-01-30 11:00:59 --> Helper loaded: file_helper
INFO - 2016-01-30 11:00:59 --> Helper loaded: date_helper
INFO - 2016-01-30 11:00:59 --> Database Driver Class Initialized
INFO - 2016-01-30 11:01:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:01:00 --> Controller Class Initialized
INFO - 2016-01-30 11:01:00 --> Model Class Initialized
INFO - 2016-01-30 11:01:00 --> Model Class Initialized
INFO - 2016-01-30 11:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:01:00 --> Pagination Class Initialized
INFO - 2016-01-30 11:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:01:00 --> Helper loaded: text_helper
INFO - 2016-01-30 11:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:01:00 --> Final output sent to browser
DEBUG - 2016-01-30 11:01:00 --> Total execution time: 1.1527
INFO - 2016-01-30 11:02:53 --> Config Class Initialized
INFO - 2016-01-30 11:02:53 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:02:53 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:02:53 --> Utf8 Class Initialized
INFO - 2016-01-30 11:02:53 --> URI Class Initialized
DEBUG - 2016-01-30 11:02:53 --> No URI present. Default controller set.
INFO - 2016-01-30 11:02:53 --> Router Class Initialized
INFO - 2016-01-30 11:02:53 --> Output Class Initialized
INFO - 2016-01-30 11:02:53 --> Security Class Initialized
DEBUG - 2016-01-30 11:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:02:53 --> Input Class Initialized
INFO - 2016-01-30 11:02:53 --> Language Class Initialized
INFO - 2016-01-30 11:02:53 --> Loader Class Initialized
INFO - 2016-01-30 11:02:53 --> Helper loaded: url_helper
INFO - 2016-01-30 11:02:53 --> Helper loaded: file_helper
INFO - 2016-01-30 11:02:53 --> Helper loaded: date_helper
INFO - 2016-01-30 11:02:53 --> Database Driver Class Initialized
INFO - 2016-01-30 11:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:02:54 --> Controller Class Initialized
INFO - 2016-01-30 11:02:54 --> Model Class Initialized
INFO - 2016-01-30 11:02:54 --> Model Class Initialized
INFO - 2016-01-30 11:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:02:54 --> Pagination Class Initialized
INFO - 2016-01-30 11:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 11:02:54 --> Final output sent to browser
DEBUG - 2016-01-30 11:02:54 --> Total execution time: 1.1278
INFO - 2016-01-30 11:02:56 --> Config Class Initialized
INFO - 2016-01-30 11:02:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:02:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:02:56 --> Utf8 Class Initialized
INFO - 2016-01-30 11:02:56 --> URI Class Initialized
INFO - 2016-01-30 11:02:56 --> Router Class Initialized
INFO - 2016-01-30 11:02:56 --> Output Class Initialized
INFO - 2016-01-30 11:02:56 --> Security Class Initialized
DEBUG - 2016-01-30 11:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:02:56 --> Input Class Initialized
INFO - 2016-01-30 11:02:56 --> Language Class Initialized
INFO - 2016-01-30 11:02:56 --> Loader Class Initialized
INFO - 2016-01-30 11:02:56 --> Helper loaded: url_helper
INFO - 2016-01-30 11:02:56 --> Helper loaded: file_helper
INFO - 2016-01-30 11:02:56 --> Helper loaded: date_helper
INFO - 2016-01-30 11:02:56 --> Database Driver Class Initialized
INFO - 2016-01-30 11:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:02:57 --> Controller Class Initialized
INFO - 2016-01-30 11:02:57 --> Model Class Initialized
INFO - 2016-01-30 11:02:57 --> Model Class Initialized
INFO - 2016-01-30 11:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:02:57 --> Pagination Class Initialized
INFO - 2016-01-30 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:02:57 --> Helper loaded: text_helper
INFO - 2016-01-30 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:02:57 --> Final output sent to browser
DEBUG - 2016-01-30 11:02:57 --> Total execution time: 1.1697
INFO - 2016-01-30 11:03:20 --> Config Class Initialized
INFO - 2016-01-30 11:03:20 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:03:20 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:03:20 --> Utf8 Class Initialized
INFO - 2016-01-30 11:03:20 --> URI Class Initialized
DEBUG - 2016-01-30 11:03:20 --> No URI present. Default controller set.
INFO - 2016-01-30 11:03:20 --> Router Class Initialized
INFO - 2016-01-30 11:03:20 --> Output Class Initialized
INFO - 2016-01-30 11:03:20 --> Security Class Initialized
DEBUG - 2016-01-30 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:03:20 --> Input Class Initialized
INFO - 2016-01-30 11:03:20 --> Language Class Initialized
INFO - 2016-01-30 11:03:20 --> Loader Class Initialized
INFO - 2016-01-30 11:03:20 --> Helper loaded: url_helper
INFO - 2016-01-30 11:03:20 --> Helper loaded: file_helper
INFO - 2016-01-30 11:03:20 --> Helper loaded: date_helper
INFO - 2016-01-30 11:03:20 --> Database Driver Class Initialized
INFO - 2016-01-30 11:03:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:03:21 --> Controller Class Initialized
INFO - 2016-01-30 11:03:21 --> Model Class Initialized
INFO - 2016-01-30 11:03:21 --> Model Class Initialized
INFO - 2016-01-30 11:03:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:03:21 --> Pagination Class Initialized
INFO - 2016-01-30 11:03:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:03:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 11:03:21 --> Final output sent to browser
DEBUG - 2016-01-30 11:03:21 --> Total execution time: 1.1292
INFO - 2016-01-30 11:03:50 --> Config Class Initialized
INFO - 2016-01-30 11:03:50 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:03:50 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:03:50 --> Utf8 Class Initialized
INFO - 2016-01-30 11:03:50 --> URI Class Initialized
DEBUG - 2016-01-30 11:03:50 --> No URI present. Default controller set.
INFO - 2016-01-30 11:03:50 --> Router Class Initialized
INFO - 2016-01-30 11:03:50 --> Output Class Initialized
INFO - 2016-01-30 11:03:50 --> Security Class Initialized
DEBUG - 2016-01-30 11:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:03:50 --> Input Class Initialized
INFO - 2016-01-30 11:03:50 --> Language Class Initialized
INFO - 2016-01-30 11:03:50 --> Loader Class Initialized
INFO - 2016-01-30 11:03:50 --> Helper loaded: url_helper
INFO - 2016-01-30 11:03:50 --> Helper loaded: file_helper
INFO - 2016-01-30 11:03:50 --> Helper loaded: date_helper
INFO - 2016-01-30 11:03:50 --> Database Driver Class Initialized
INFO - 2016-01-30 11:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:03:51 --> Controller Class Initialized
INFO - 2016-01-30 11:03:51 --> Model Class Initialized
INFO - 2016-01-30 11:03:51 --> Model Class Initialized
INFO - 2016-01-30 11:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:03:51 --> Pagination Class Initialized
INFO - 2016-01-30 11:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 11:03:51 --> Final output sent to browser
DEBUG - 2016-01-30 11:03:51 --> Total execution time: 1.1167
INFO - 2016-01-30 11:35:25 --> Config Class Initialized
INFO - 2016-01-30 11:35:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:35:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:35:25 --> Utf8 Class Initialized
INFO - 2016-01-30 11:35:25 --> URI Class Initialized
INFO - 2016-01-30 11:35:25 --> Router Class Initialized
INFO - 2016-01-30 11:35:25 --> Output Class Initialized
INFO - 2016-01-30 11:35:25 --> Security Class Initialized
DEBUG - 2016-01-30 11:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:35:25 --> Input Class Initialized
INFO - 2016-01-30 11:35:25 --> Language Class Initialized
INFO - 2016-01-30 11:35:25 --> Loader Class Initialized
INFO - 2016-01-30 11:35:25 --> Helper loaded: url_helper
INFO - 2016-01-30 11:35:25 --> Helper loaded: file_helper
INFO - 2016-01-30 11:35:25 --> Helper loaded: date_helper
INFO - 2016-01-30 11:35:25 --> Database Driver Class Initialized
INFO - 2016-01-30 11:35:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:35:26 --> Controller Class Initialized
INFO - 2016-01-30 11:35:26 --> Model Class Initialized
INFO - 2016-01-30 11:35:26 --> Model Class Initialized
INFO - 2016-01-30 11:35:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:35:26 --> Pagination Class Initialized
INFO - 2016-01-30 11:35:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:35:26 --> Helper loaded: text_helper
INFO - 2016-01-30 11:35:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:35:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:35:26 --> Final output sent to browser
DEBUG - 2016-01-30 11:35:26 --> Total execution time: 1.1690
INFO - 2016-01-30 11:37:10 --> Config Class Initialized
INFO - 2016-01-30 11:37:10 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:37:11 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:37:11 --> Utf8 Class Initialized
INFO - 2016-01-30 11:37:11 --> URI Class Initialized
INFO - 2016-01-30 11:37:11 --> Router Class Initialized
INFO - 2016-01-30 11:37:11 --> Output Class Initialized
INFO - 2016-01-30 11:37:11 --> Security Class Initialized
DEBUG - 2016-01-30 11:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:37:11 --> Input Class Initialized
INFO - 2016-01-30 11:37:11 --> Language Class Initialized
INFO - 2016-01-30 11:37:11 --> Loader Class Initialized
INFO - 2016-01-30 11:37:11 --> Helper loaded: url_helper
INFO - 2016-01-30 11:37:11 --> Helper loaded: file_helper
INFO - 2016-01-30 11:37:11 --> Helper loaded: date_helper
INFO - 2016-01-30 11:37:11 --> Database Driver Class Initialized
INFO - 2016-01-30 11:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:37:12 --> Controller Class Initialized
INFO - 2016-01-30 11:37:12 --> Model Class Initialized
INFO - 2016-01-30 11:37:12 --> Model Class Initialized
INFO - 2016-01-30 11:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:37:12 --> Pagination Class Initialized
INFO - 2016-01-30 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:37:12 --> Helper loaded: text_helper
INFO - 2016-01-30 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:37:12 --> Final output sent to browser
DEBUG - 2016-01-30 11:37:12 --> Total execution time: 1.2321
INFO - 2016-01-30 11:38:18 --> Config Class Initialized
INFO - 2016-01-30 11:38:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:38:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:38:18 --> Utf8 Class Initialized
INFO - 2016-01-30 11:38:18 --> URI Class Initialized
INFO - 2016-01-30 11:38:18 --> Router Class Initialized
INFO - 2016-01-30 11:38:18 --> Output Class Initialized
INFO - 2016-01-30 11:38:18 --> Security Class Initialized
DEBUG - 2016-01-30 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:38:18 --> Input Class Initialized
INFO - 2016-01-30 11:38:18 --> Language Class Initialized
INFO - 2016-01-30 11:38:18 --> Loader Class Initialized
INFO - 2016-01-30 11:38:18 --> Helper loaded: url_helper
INFO - 2016-01-30 11:38:18 --> Helper loaded: file_helper
INFO - 2016-01-30 11:38:18 --> Helper loaded: date_helper
INFO - 2016-01-30 11:38:18 --> Database Driver Class Initialized
INFO - 2016-01-30 11:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:38:19 --> Controller Class Initialized
INFO - 2016-01-30 11:38:19 --> Model Class Initialized
INFO - 2016-01-30 11:38:19 --> Model Class Initialized
INFO - 2016-01-30 11:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:38:19 --> Pagination Class Initialized
INFO - 2016-01-30 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:38:19 --> Helper loaded: text_helper
INFO - 2016-01-30 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:38:19 --> Final output sent to browser
DEBUG - 2016-01-30 11:38:19 --> Total execution time: 1.1777
INFO - 2016-01-30 11:38:36 --> Config Class Initialized
INFO - 2016-01-30 11:38:36 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:38:36 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:38:36 --> Utf8 Class Initialized
INFO - 2016-01-30 11:38:36 --> URI Class Initialized
INFO - 2016-01-30 11:38:36 --> Router Class Initialized
INFO - 2016-01-30 11:38:36 --> Output Class Initialized
INFO - 2016-01-30 11:38:36 --> Security Class Initialized
DEBUG - 2016-01-30 11:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:38:36 --> Input Class Initialized
INFO - 2016-01-30 11:38:36 --> Language Class Initialized
INFO - 2016-01-30 11:38:36 --> Loader Class Initialized
INFO - 2016-01-30 11:38:36 --> Helper loaded: url_helper
INFO - 2016-01-30 11:38:36 --> Helper loaded: file_helper
INFO - 2016-01-30 11:38:36 --> Helper loaded: date_helper
INFO - 2016-01-30 11:38:36 --> Database Driver Class Initialized
INFO - 2016-01-30 11:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:38:37 --> Controller Class Initialized
INFO - 2016-01-30 11:38:37 --> Model Class Initialized
INFO - 2016-01-30 11:38:37 --> Model Class Initialized
INFO - 2016-01-30 11:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:38:37 --> Pagination Class Initialized
INFO - 2016-01-30 11:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:38:37 --> Helper loaded: text_helper
INFO - 2016-01-30 11:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:38:37 --> Final output sent to browser
DEBUG - 2016-01-30 11:38:37 --> Total execution time: 1.1911
INFO - 2016-01-30 11:39:18 --> Config Class Initialized
INFO - 2016-01-30 11:39:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:39:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:39:18 --> Utf8 Class Initialized
INFO - 2016-01-30 11:39:18 --> URI Class Initialized
INFO - 2016-01-30 11:39:18 --> Router Class Initialized
INFO - 2016-01-30 11:39:18 --> Output Class Initialized
INFO - 2016-01-30 11:39:18 --> Security Class Initialized
DEBUG - 2016-01-30 11:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:39:18 --> Input Class Initialized
INFO - 2016-01-30 11:39:18 --> Language Class Initialized
INFO - 2016-01-30 11:39:18 --> Loader Class Initialized
INFO - 2016-01-30 11:39:18 --> Helper loaded: url_helper
INFO - 2016-01-30 11:39:18 --> Helper loaded: file_helper
INFO - 2016-01-30 11:39:18 --> Helper loaded: date_helper
INFO - 2016-01-30 11:39:18 --> Database Driver Class Initialized
INFO - 2016-01-30 11:39:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:39:19 --> Controller Class Initialized
INFO - 2016-01-30 11:39:19 --> Model Class Initialized
INFO - 2016-01-30 11:39:19 --> Model Class Initialized
INFO - 2016-01-30 11:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:39:19 --> Pagination Class Initialized
INFO - 2016-01-30 11:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:39:19 --> Helper loaded: text_helper
INFO - 2016-01-30 11:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:39:19 --> Final output sent to browser
DEBUG - 2016-01-30 11:39:19 --> Total execution time: 1.2119
INFO - 2016-01-30 11:44:37 --> Config Class Initialized
INFO - 2016-01-30 11:44:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:44:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:44:37 --> Utf8 Class Initialized
INFO - 2016-01-30 11:44:37 --> URI Class Initialized
INFO - 2016-01-30 11:44:37 --> Router Class Initialized
INFO - 2016-01-30 11:44:37 --> Output Class Initialized
INFO - 2016-01-30 11:44:37 --> Security Class Initialized
DEBUG - 2016-01-30 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:44:37 --> Input Class Initialized
INFO - 2016-01-30 11:44:37 --> Language Class Initialized
INFO - 2016-01-30 11:44:37 --> Loader Class Initialized
INFO - 2016-01-30 11:44:37 --> Helper loaded: url_helper
INFO - 2016-01-30 11:44:37 --> Helper loaded: file_helper
INFO - 2016-01-30 11:44:37 --> Helper loaded: date_helper
INFO - 2016-01-30 11:44:37 --> Database Driver Class Initialized
INFO - 2016-01-30 11:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:44:38 --> Controller Class Initialized
INFO - 2016-01-30 11:44:38 --> Model Class Initialized
INFO - 2016-01-30 11:44:38 --> Model Class Initialized
INFO - 2016-01-30 11:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:44:38 --> Pagination Class Initialized
INFO - 2016-01-30 11:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:44:38 --> Helper loaded: text_helper
INFO - 2016-01-30 11:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:44:38 --> Final output sent to browser
DEBUG - 2016-01-30 11:44:38 --> Total execution time: 1.2022
INFO - 2016-01-30 11:44:49 --> Config Class Initialized
INFO - 2016-01-30 11:44:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:44:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:44:49 --> Utf8 Class Initialized
INFO - 2016-01-30 11:44:49 --> URI Class Initialized
INFO - 2016-01-30 11:44:49 --> Router Class Initialized
INFO - 2016-01-30 11:44:49 --> Output Class Initialized
INFO - 2016-01-30 11:44:49 --> Security Class Initialized
DEBUG - 2016-01-30 11:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:44:49 --> Input Class Initialized
INFO - 2016-01-30 11:44:49 --> Language Class Initialized
INFO - 2016-01-30 11:44:49 --> Loader Class Initialized
INFO - 2016-01-30 11:44:49 --> Helper loaded: url_helper
INFO - 2016-01-30 11:44:49 --> Helper loaded: file_helper
INFO - 2016-01-30 11:44:49 --> Helper loaded: date_helper
INFO - 2016-01-30 11:44:49 --> Database Driver Class Initialized
INFO - 2016-01-30 11:44:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:44:50 --> Controller Class Initialized
INFO - 2016-01-30 11:44:50 --> Model Class Initialized
INFO - 2016-01-30 11:44:50 --> Model Class Initialized
INFO - 2016-01-30 11:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:44:50 --> Pagination Class Initialized
INFO - 2016-01-30 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:44:50 --> Helper loaded: text_helper
INFO - 2016-01-30 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:44:50 --> Final output sent to browser
DEBUG - 2016-01-30 11:44:50 --> Total execution time: 1.2901
INFO - 2016-01-30 11:45:38 --> Config Class Initialized
INFO - 2016-01-30 11:45:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:45:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:45:38 --> Utf8 Class Initialized
INFO - 2016-01-30 11:45:38 --> URI Class Initialized
INFO - 2016-01-30 11:45:38 --> Router Class Initialized
INFO - 2016-01-30 11:45:38 --> Output Class Initialized
INFO - 2016-01-30 11:45:38 --> Security Class Initialized
DEBUG - 2016-01-30 11:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:45:38 --> Input Class Initialized
INFO - 2016-01-30 11:45:38 --> Language Class Initialized
INFO - 2016-01-30 11:45:38 --> Loader Class Initialized
INFO - 2016-01-30 11:45:38 --> Helper loaded: url_helper
INFO - 2016-01-30 11:45:38 --> Helper loaded: file_helper
INFO - 2016-01-30 11:45:38 --> Helper loaded: date_helper
INFO - 2016-01-30 11:45:38 --> Database Driver Class Initialized
INFO - 2016-01-30 11:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:45:39 --> Controller Class Initialized
INFO - 2016-01-30 11:45:39 --> Model Class Initialized
INFO - 2016-01-30 11:45:39 --> Model Class Initialized
INFO - 2016-01-30 11:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:45:39 --> Pagination Class Initialized
INFO - 2016-01-30 11:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:45:39 --> Helper loaded: text_helper
INFO - 2016-01-30 11:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:45:39 --> Final output sent to browser
DEBUG - 2016-01-30 11:45:39 --> Total execution time: 1.1461
INFO - 2016-01-30 11:45:52 --> Config Class Initialized
INFO - 2016-01-30 11:45:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:45:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:45:52 --> Utf8 Class Initialized
INFO - 2016-01-30 11:45:52 --> URI Class Initialized
INFO - 2016-01-30 11:45:52 --> Router Class Initialized
INFO - 2016-01-30 11:45:52 --> Output Class Initialized
INFO - 2016-01-30 11:45:52 --> Security Class Initialized
DEBUG - 2016-01-30 11:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:45:52 --> Input Class Initialized
INFO - 2016-01-30 11:45:52 --> Language Class Initialized
INFO - 2016-01-30 11:45:52 --> Loader Class Initialized
INFO - 2016-01-30 11:45:52 --> Helper loaded: url_helper
INFO - 2016-01-30 11:45:52 --> Helper loaded: file_helper
INFO - 2016-01-30 11:45:52 --> Helper loaded: date_helper
INFO - 2016-01-30 11:45:52 --> Database Driver Class Initialized
INFO - 2016-01-30 11:45:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:45:53 --> Controller Class Initialized
INFO - 2016-01-30 11:45:53 --> Model Class Initialized
INFO - 2016-01-30 11:45:53 --> Model Class Initialized
INFO - 2016-01-30 11:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:45:53 --> Pagination Class Initialized
INFO - 2016-01-30 11:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:45:53 --> Helper loaded: text_helper
INFO - 2016-01-30 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:45:54 --> Final output sent to browser
DEBUG - 2016-01-30 11:45:54 --> Total execution time: 1.1804
INFO - 2016-01-30 11:46:21 --> Config Class Initialized
INFO - 2016-01-30 11:46:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:46:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:46:21 --> Utf8 Class Initialized
INFO - 2016-01-30 11:46:21 --> URI Class Initialized
INFO - 2016-01-30 11:46:21 --> Router Class Initialized
INFO - 2016-01-30 11:46:21 --> Output Class Initialized
INFO - 2016-01-30 11:46:21 --> Security Class Initialized
DEBUG - 2016-01-30 11:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:46:21 --> Input Class Initialized
INFO - 2016-01-30 11:46:21 --> Language Class Initialized
INFO - 2016-01-30 11:46:21 --> Loader Class Initialized
INFO - 2016-01-30 11:46:21 --> Helper loaded: url_helper
INFO - 2016-01-30 11:46:21 --> Helper loaded: file_helper
INFO - 2016-01-30 11:46:21 --> Helper loaded: date_helper
INFO - 2016-01-30 11:46:21 --> Database Driver Class Initialized
INFO - 2016-01-30 11:46:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:46:22 --> Controller Class Initialized
INFO - 2016-01-30 11:46:22 --> Model Class Initialized
INFO - 2016-01-30 11:46:22 --> Model Class Initialized
INFO - 2016-01-30 11:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:46:22 --> Pagination Class Initialized
INFO - 2016-01-30 11:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:46:22 --> Helper loaded: text_helper
INFO - 2016-01-30 11:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:46:22 --> Final output sent to browser
DEBUG - 2016-01-30 11:46:22 --> Total execution time: 1.1762
INFO - 2016-01-30 11:47:24 --> Config Class Initialized
INFO - 2016-01-30 11:47:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:47:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:47:24 --> Utf8 Class Initialized
INFO - 2016-01-30 11:47:24 --> URI Class Initialized
INFO - 2016-01-30 11:47:24 --> Router Class Initialized
INFO - 2016-01-30 11:47:24 --> Output Class Initialized
INFO - 2016-01-30 11:47:24 --> Security Class Initialized
DEBUG - 2016-01-30 11:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:47:24 --> Input Class Initialized
INFO - 2016-01-30 11:47:24 --> Language Class Initialized
INFO - 2016-01-30 11:47:24 --> Loader Class Initialized
INFO - 2016-01-30 11:47:24 --> Helper loaded: url_helper
INFO - 2016-01-30 11:47:24 --> Helper loaded: file_helper
INFO - 2016-01-30 11:47:24 --> Helper loaded: date_helper
INFO - 2016-01-30 11:47:24 --> Database Driver Class Initialized
INFO - 2016-01-30 11:47:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:47:25 --> Controller Class Initialized
INFO - 2016-01-30 11:47:25 --> Model Class Initialized
INFO - 2016-01-30 11:47:25 --> Model Class Initialized
INFO - 2016-01-30 11:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:47:25 --> Pagination Class Initialized
INFO - 2016-01-30 11:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:47:25 --> Helper loaded: text_helper
INFO - 2016-01-30 11:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:47:25 --> Final output sent to browser
DEBUG - 2016-01-30 11:47:25 --> Total execution time: 1.2304
INFO - 2016-01-30 11:47:57 --> Config Class Initialized
INFO - 2016-01-30 11:47:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 11:47:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 11:47:57 --> Utf8 Class Initialized
INFO - 2016-01-30 11:47:57 --> URI Class Initialized
INFO - 2016-01-30 11:47:57 --> Router Class Initialized
INFO - 2016-01-30 11:47:57 --> Output Class Initialized
INFO - 2016-01-30 11:47:57 --> Security Class Initialized
DEBUG - 2016-01-30 11:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 11:47:57 --> Input Class Initialized
INFO - 2016-01-30 11:47:57 --> Language Class Initialized
INFO - 2016-01-30 11:47:57 --> Loader Class Initialized
INFO - 2016-01-30 11:47:57 --> Helper loaded: url_helper
INFO - 2016-01-30 11:47:57 --> Helper loaded: file_helper
INFO - 2016-01-30 11:47:57 --> Helper loaded: date_helper
INFO - 2016-01-30 11:47:57 --> Database Driver Class Initialized
INFO - 2016-01-30 11:47:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 11:47:58 --> Controller Class Initialized
INFO - 2016-01-30 11:47:58 --> Model Class Initialized
INFO - 2016-01-30 11:47:58 --> Model Class Initialized
INFO - 2016-01-30 11:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 11:47:58 --> Pagination Class Initialized
INFO - 2016-01-30 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 11:47:58 --> Helper loaded: text_helper
INFO - 2016-01-30 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 11:47:58 --> Final output sent to browser
DEBUG - 2016-01-30 11:47:58 --> Total execution time: 1.2361
INFO - 2016-01-30 12:33:59 --> Config Class Initialized
INFO - 2016-01-30 12:33:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:33:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:33:59 --> Utf8 Class Initialized
INFO - 2016-01-30 12:33:59 --> URI Class Initialized
DEBUG - 2016-01-30 12:33:59 --> No URI present. Default controller set.
INFO - 2016-01-30 12:33:59 --> Router Class Initialized
INFO - 2016-01-30 12:33:59 --> Output Class Initialized
INFO - 2016-01-30 12:33:59 --> Security Class Initialized
DEBUG - 2016-01-30 12:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:33:59 --> Input Class Initialized
INFO - 2016-01-30 12:33:59 --> Language Class Initialized
INFO - 2016-01-30 12:33:59 --> Loader Class Initialized
INFO - 2016-01-30 12:33:59 --> Helper loaded: url_helper
INFO - 2016-01-30 12:33:59 --> Helper loaded: file_helper
INFO - 2016-01-30 12:33:59 --> Helper loaded: date_helper
INFO - 2016-01-30 12:33:59 --> Database Driver Class Initialized
INFO - 2016-01-30 12:34:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:34:01 --> Controller Class Initialized
INFO - 2016-01-30 12:34:01 --> Model Class Initialized
INFO - 2016-01-30 12:34:01 --> Model Class Initialized
INFO - 2016-01-30 12:34:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:34:01 --> Pagination Class Initialized
INFO - 2016-01-30 12:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 12:34:01 --> Final output sent to browser
DEBUG - 2016-01-30 12:34:01 --> Total execution time: 1.1239
INFO - 2016-01-30 12:34:16 --> Config Class Initialized
INFO - 2016-01-30 12:34:16 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:34:16 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:34:16 --> Utf8 Class Initialized
INFO - 2016-01-30 12:34:16 --> URI Class Initialized
INFO - 2016-01-30 12:34:16 --> Router Class Initialized
INFO - 2016-01-30 12:34:16 --> Output Class Initialized
INFO - 2016-01-30 12:34:16 --> Security Class Initialized
DEBUG - 2016-01-30 12:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:34:16 --> Input Class Initialized
INFO - 2016-01-30 12:34:16 --> Language Class Initialized
INFO - 2016-01-30 12:34:16 --> Loader Class Initialized
INFO - 2016-01-30 12:34:16 --> Helper loaded: url_helper
INFO - 2016-01-30 12:34:16 --> Helper loaded: file_helper
INFO - 2016-01-30 12:34:16 --> Helper loaded: date_helper
INFO - 2016-01-30 12:34:16 --> Database Driver Class Initialized
INFO - 2016-01-30 12:34:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:34:17 --> Controller Class Initialized
INFO - 2016-01-30 12:34:17 --> Model Class Initialized
INFO - 2016-01-30 12:34:17 --> Model Class Initialized
INFO - 2016-01-30 12:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:34:17 --> Pagination Class Initialized
INFO - 2016-01-30 12:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:34:17 --> Helper loaded: text_helper
INFO - 2016-01-30 12:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 12:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 12:34:17 --> Final output sent to browser
DEBUG - 2016-01-30 12:34:17 --> Total execution time: 1.1607
INFO - 2016-01-30 12:58:18 --> Config Class Initialized
INFO - 2016-01-30 12:58:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:58:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:58:18 --> Utf8 Class Initialized
INFO - 2016-01-30 12:58:18 --> URI Class Initialized
DEBUG - 2016-01-30 12:58:18 --> No URI present. Default controller set.
INFO - 2016-01-30 12:58:18 --> Router Class Initialized
INFO - 2016-01-30 12:58:18 --> Output Class Initialized
INFO - 2016-01-30 12:58:18 --> Security Class Initialized
DEBUG - 2016-01-30 12:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:58:18 --> Input Class Initialized
INFO - 2016-01-30 12:58:18 --> Language Class Initialized
INFO - 2016-01-30 12:58:18 --> Loader Class Initialized
INFO - 2016-01-30 12:58:18 --> Helper loaded: url_helper
INFO - 2016-01-30 12:58:18 --> Helper loaded: file_helper
INFO - 2016-01-30 12:58:18 --> Helper loaded: date_helper
INFO - 2016-01-30 12:58:18 --> Database Driver Class Initialized
INFO - 2016-01-30 12:58:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:58:19 --> Controller Class Initialized
INFO - 2016-01-30 12:58:19 --> Model Class Initialized
INFO - 2016-01-30 12:58:19 --> Model Class Initialized
INFO - 2016-01-30 12:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:58:19 --> Pagination Class Initialized
INFO - 2016-01-30 12:58:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:58:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 12:58:19 --> Final output sent to browser
DEBUG - 2016-01-30 12:58:19 --> Total execution time: 1.1362
INFO - 2016-01-30 12:58:22 --> Config Class Initialized
INFO - 2016-01-30 12:58:22 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:58:22 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:58:22 --> Utf8 Class Initialized
INFO - 2016-01-30 12:58:22 --> URI Class Initialized
INFO - 2016-01-30 12:58:22 --> Router Class Initialized
INFO - 2016-01-30 12:58:22 --> Output Class Initialized
INFO - 2016-01-30 12:58:22 --> Security Class Initialized
DEBUG - 2016-01-30 12:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:58:22 --> Input Class Initialized
INFO - 2016-01-30 12:58:22 --> Language Class Initialized
INFO - 2016-01-30 12:58:22 --> Loader Class Initialized
INFO - 2016-01-30 12:58:22 --> Helper loaded: url_helper
INFO - 2016-01-30 12:58:22 --> Helper loaded: file_helper
INFO - 2016-01-30 12:58:22 --> Helper loaded: date_helper
INFO - 2016-01-30 12:58:22 --> Database Driver Class Initialized
INFO - 2016-01-30 12:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:58:23 --> Controller Class Initialized
INFO - 2016-01-30 12:58:23 --> Model Class Initialized
INFO - 2016-01-30 12:58:23 --> Model Class Initialized
INFO - 2016-01-30 12:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:58:23 --> Pagination Class Initialized
INFO - 2016-01-30 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:58:23 --> Helper loaded: text_helper
INFO - 2016-01-30 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 12:58:23 --> Final output sent to browser
DEBUG - 2016-01-30 12:58:23 --> Total execution time: 1.2335
INFO - 2016-01-30 12:58:25 --> Config Class Initialized
INFO - 2016-01-30 12:58:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:58:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:58:25 --> Utf8 Class Initialized
INFO - 2016-01-30 12:58:25 --> URI Class Initialized
INFO - 2016-01-30 12:58:25 --> Router Class Initialized
INFO - 2016-01-30 12:58:25 --> Output Class Initialized
INFO - 2016-01-30 12:58:25 --> Security Class Initialized
DEBUG - 2016-01-30 12:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:58:25 --> Input Class Initialized
INFO - 2016-01-30 12:58:25 --> Language Class Initialized
INFO - 2016-01-30 12:58:25 --> Loader Class Initialized
INFO - 2016-01-30 12:58:25 --> Helper loaded: url_helper
INFO - 2016-01-30 12:58:25 --> Helper loaded: file_helper
INFO - 2016-01-30 12:58:25 --> Helper loaded: date_helper
INFO - 2016-01-30 12:58:25 --> Database Driver Class Initialized
INFO - 2016-01-30 12:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:58:26 --> Controller Class Initialized
INFO - 2016-01-30 12:58:26 --> Model Class Initialized
INFO - 2016-01-30 12:58:26 --> Model Class Initialized
INFO - 2016-01-30 12:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:58:26 --> Pagination Class Initialized
INFO - 2016-01-30 12:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 12:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 12:58:26 --> Final output sent to browser
DEBUG - 2016-01-30 12:58:26 --> Total execution time: 1.1129
INFO - 2016-01-30 12:59:33 --> Config Class Initialized
INFO - 2016-01-30 12:59:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:59:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:59:33 --> Utf8 Class Initialized
INFO - 2016-01-30 12:59:33 --> URI Class Initialized
DEBUG - 2016-01-30 12:59:33 --> No URI present. Default controller set.
INFO - 2016-01-30 12:59:33 --> Router Class Initialized
INFO - 2016-01-30 12:59:33 --> Output Class Initialized
INFO - 2016-01-30 12:59:33 --> Security Class Initialized
DEBUG - 2016-01-30 12:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:59:33 --> Input Class Initialized
INFO - 2016-01-30 12:59:33 --> Language Class Initialized
INFO - 2016-01-30 12:59:33 --> Loader Class Initialized
INFO - 2016-01-30 12:59:33 --> Helper loaded: url_helper
INFO - 2016-01-30 12:59:33 --> Helper loaded: file_helper
INFO - 2016-01-30 12:59:33 --> Helper loaded: date_helper
INFO - 2016-01-30 12:59:33 --> Database Driver Class Initialized
INFO - 2016-01-30 12:59:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:59:34 --> Controller Class Initialized
INFO - 2016-01-30 12:59:34 --> Model Class Initialized
INFO - 2016-01-30 12:59:34 --> Model Class Initialized
INFO - 2016-01-30 12:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:59:34 --> Pagination Class Initialized
INFO - 2016-01-30 12:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 12:59:34 --> Final output sent to browser
DEBUG - 2016-01-30 12:59:34 --> Total execution time: 1.1032
INFO - 2016-01-30 12:59:43 --> Config Class Initialized
INFO - 2016-01-30 12:59:43 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:59:43 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:59:43 --> Utf8 Class Initialized
INFO - 2016-01-30 12:59:43 --> URI Class Initialized
INFO - 2016-01-30 12:59:43 --> Router Class Initialized
INFO - 2016-01-30 12:59:43 --> Output Class Initialized
INFO - 2016-01-30 12:59:43 --> Security Class Initialized
DEBUG - 2016-01-30 12:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:59:43 --> Input Class Initialized
INFO - 2016-01-30 12:59:43 --> Language Class Initialized
INFO - 2016-01-30 12:59:43 --> Loader Class Initialized
INFO - 2016-01-30 12:59:43 --> Helper loaded: url_helper
INFO - 2016-01-30 12:59:43 --> Helper loaded: file_helper
INFO - 2016-01-30 12:59:43 --> Helper loaded: date_helper
INFO - 2016-01-30 12:59:43 --> Database Driver Class Initialized
INFO - 2016-01-30 12:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:59:44 --> Controller Class Initialized
INFO - 2016-01-30 12:59:44 --> Model Class Initialized
INFO - 2016-01-30 12:59:44 --> Model Class Initialized
INFO - 2016-01-30 12:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:59:44 --> Pagination Class Initialized
INFO - 2016-01-30 12:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:59:44 --> Helper loaded: text_helper
INFO - 2016-01-30 12:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 12:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 12:59:44 --> Final output sent to browser
DEBUG - 2016-01-30 12:59:44 --> Total execution time: 1.1424
INFO - 2016-01-30 12:59:46 --> Config Class Initialized
INFO - 2016-01-30 12:59:46 --> Hooks Class Initialized
DEBUG - 2016-01-30 12:59:46 --> UTF-8 Support Enabled
INFO - 2016-01-30 12:59:46 --> Utf8 Class Initialized
INFO - 2016-01-30 12:59:46 --> URI Class Initialized
INFO - 2016-01-30 12:59:46 --> Router Class Initialized
INFO - 2016-01-30 12:59:46 --> Output Class Initialized
INFO - 2016-01-30 12:59:46 --> Security Class Initialized
DEBUG - 2016-01-30 12:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 12:59:46 --> Input Class Initialized
INFO - 2016-01-30 12:59:46 --> Language Class Initialized
INFO - 2016-01-30 12:59:46 --> Loader Class Initialized
INFO - 2016-01-30 12:59:46 --> Helper loaded: url_helper
INFO - 2016-01-30 12:59:46 --> Helper loaded: file_helper
INFO - 2016-01-30 12:59:46 --> Helper loaded: date_helper
INFO - 2016-01-30 12:59:46 --> Database Driver Class Initialized
INFO - 2016-01-30 12:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 12:59:47 --> Controller Class Initialized
INFO - 2016-01-30 12:59:47 --> Model Class Initialized
INFO - 2016-01-30 12:59:47 --> Model Class Initialized
INFO - 2016-01-30 12:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 12:59:47 --> Pagination Class Initialized
INFO - 2016-01-30 12:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 12:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 12:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 12:59:47 --> Final output sent to browser
DEBUG - 2016-01-30 12:59:47 --> Total execution time: 1.1195
INFO - 2016-01-30 13:03:40 --> Config Class Initialized
INFO - 2016-01-30 13:03:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 13:03:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 13:03:40 --> Utf8 Class Initialized
INFO - 2016-01-30 13:03:40 --> URI Class Initialized
DEBUG - 2016-01-30 13:03:40 --> No URI present. Default controller set.
INFO - 2016-01-30 13:03:40 --> Router Class Initialized
INFO - 2016-01-30 13:03:40 --> Output Class Initialized
INFO - 2016-01-30 13:03:40 --> Security Class Initialized
DEBUG - 2016-01-30 13:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 13:03:40 --> Input Class Initialized
INFO - 2016-01-30 13:03:40 --> Language Class Initialized
INFO - 2016-01-30 13:03:40 --> Loader Class Initialized
INFO - 2016-01-30 13:03:40 --> Helper loaded: url_helper
INFO - 2016-01-30 13:03:40 --> Helper loaded: file_helper
INFO - 2016-01-30 13:03:40 --> Helper loaded: date_helper
INFO - 2016-01-30 13:03:40 --> Database Driver Class Initialized
INFO - 2016-01-30 13:03:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 13:03:41 --> Controller Class Initialized
INFO - 2016-01-30 13:03:41 --> Model Class Initialized
INFO - 2016-01-30 13:03:41 --> Model Class Initialized
INFO - 2016-01-30 13:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 13:03:41 --> Pagination Class Initialized
INFO - 2016-01-30 13:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 13:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 13:03:41 --> Final output sent to browser
DEBUG - 2016-01-30 13:03:41 --> Total execution time: 1.1098
INFO - 2016-01-30 13:26:55 --> Config Class Initialized
INFO - 2016-01-30 13:26:55 --> Hooks Class Initialized
DEBUG - 2016-01-30 13:26:55 --> UTF-8 Support Enabled
INFO - 2016-01-30 13:26:55 --> Utf8 Class Initialized
INFO - 2016-01-30 13:26:55 --> URI Class Initialized
INFO - 2016-01-30 13:26:55 --> Router Class Initialized
INFO - 2016-01-30 13:26:55 --> Output Class Initialized
INFO - 2016-01-30 13:26:55 --> Security Class Initialized
DEBUG - 2016-01-30 13:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 13:26:55 --> Input Class Initialized
INFO - 2016-01-30 13:26:55 --> Language Class Initialized
INFO - 2016-01-30 13:26:55 --> Loader Class Initialized
INFO - 2016-01-30 13:26:55 --> Helper loaded: url_helper
INFO - 2016-01-30 13:26:55 --> Helper loaded: file_helper
INFO - 2016-01-30 13:26:55 --> Helper loaded: date_helper
INFO - 2016-01-30 13:26:55 --> Database Driver Class Initialized
INFO - 2016-01-30 13:26:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 13:26:57 --> Controller Class Initialized
INFO - 2016-01-30 13:26:57 --> Model Class Initialized
INFO - 2016-01-30 13:26:57 --> Model Class Initialized
INFO - 2016-01-30 13:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 13:26:57 --> Pagination Class Initialized
INFO - 2016-01-30 13:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 13:26:57 --> Helper loaded: text_helper
INFO - 2016-01-30 13:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 13:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 13:26:57 --> Final output sent to browser
DEBUG - 2016-01-30 13:26:57 --> Total execution time: 1.1683
INFO - 2016-01-30 14:19:19 --> Config Class Initialized
INFO - 2016-01-30 14:19:19 --> Hooks Class Initialized
DEBUG - 2016-01-30 14:19:19 --> UTF-8 Support Enabled
INFO - 2016-01-30 14:19:19 --> Utf8 Class Initialized
INFO - 2016-01-30 14:19:19 --> URI Class Initialized
DEBUG - 2016-01-30 14:19:19 --> No URI present. Default controller set.
INFO - 2016-01-30 14:19:19 --> Router Class Initialized
INFO - 2016-01-30 14:19:19 --> Output Class Initialized
INFO - 2016-01-30 14:19:19 --> Security Class Initialized
DEBUG - 2016-01-30 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 14:19:19 --> Input Class Initialized
INFO - 2016-01-30 14:19:19 --> Language Class Initialized
INFO - 2016-01-30 14:19:19 --> Loader Class Initialized
INFO - 2016-01-30 14:19:19 --> Helper loaded: url_helper
INFO - 2016-01-30 14:19:19 --> Helper loaded: file_helper
INFO - 2016-01-30 14:19:19 --> Helper loaded: date_helper
INFO - 2016-01-30 14:19:19 --> Database Driver Class Initialized
INFO - 2016-01-30 14:19:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 14:19:20 --> Controller Class Initialized
INFO - 2016-01-30 14:19:20 --> Model Class Initialized
INFO - 2016-01-30 14:19:20 --> Model Class Initialized
INFO - 2016-01-30 14:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 14:19:20 --> Pagination Class Initialized
INFO - 2016-01-30 14:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 14:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 14:19:20 --> Final output sent to browser
DEBUG - 2016-01-30 14:19:20 --> Total execution time: 1.1318
INFO - 2016-01-30 14:20:24 --> Config Class Initialized
INFO - 2016-01-30 14:20:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 14:20:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 14:20:24 --> Utf8 Class Initialized
INFO - 2016-01-30 14:20:24 --> URI Class Initialized
INFO - 2016-01-30 14:20:24 --> Router Class Initialized
INFO - 2016-01-30 14:20:24 --> Output Class Initialized
INFO - 2016-01-30 14:20:24 --> Security Class Initialized
DEBUG - 2016-01-30 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 14:20:24 --> Input Class Initialized
INFO - 2016-01-30 14:20:24 --> Language Class Initialized
INFO - 2016-01-30 14:20:24 --> Loader Class Initialized
INFO - 2016-01-30 14:20:24 --> Helper loaded: url_helper
INFO - 2016-01-30 14:20:24 --> Helper loaded: file_helper
INFO - 2016-01-30 14:20:24 --> Helper loaded: date_helper
INFO - 2016-01-30 14:20:24 --> Database Driver Class Initialized
INFO - 2016-01-30 14:20:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 14:20:25 --> Controller Class Initialized
INFO - 2016-01-30 14:20:25 --> Model Class Initialized
INFO - 2016-01-30 14:20:25 --> Model Class Initialized
INFO - 2016-01-30 14:20:25 --> Helper loaded: form_helper
INFO - 2016-01-30 14:20:25 --> Form Validation Class Initialized
INFO - 2016-01-30 14:20:25 --> Helper loaded: text_helper
INFO - 2016-01-30 14:20:25 --> Config Class Initialized
INFO - 2016-01-30 14:20:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 14:20:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 14:20:25 --> Utf8 Class Initialized
INFO - 2016-01-30 14:20:25 --> URI Class Initialized
INFO - 2016-01-30 14:20:25 --> Router Class Initialized
INFO - 2016-01-30 14:20:25 --> Output Class Initialized
INFO - 2016-01-30 14:20:25 --> Security Class Initialized
DEBUG - 2016-01-30 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 14:20:25 --> Input Class Initialized
INFO - 2016-01-30 14:20:25 --> Language Class Initialized
INFO - 2016-01-30 14:20:25 --> Loader Class Initialized
INFO - 2016-01-30 14:20:25 --> Helper loaded: url_helper
INFO - 2016-01-30 14:20:25 --> Helper loaded: file_helper
INFO - 2016-01-30 14:20:25 --> Helper loaded: date_helper
INFO - 2016-01-30 14:20:25 --> Database Driver Class Initialized
INFO - 2016-01-30 14:20:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 14:20:26 --> Controller Class Initialized
INFO - 2016-01-30 14:20:26 --> Model Class Initialized
INFO - 2016-01-30 14:20:26 --> Model Class Initialized
INFO - 2016-01-30 14:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 14:20:26 --> Pagination Class Initialized
INFO - 2016-01-30 14:20:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 14:20:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 14:20:26 --> Final output sent to browser
DEBUG - 2016-01-30 14:20:26 --> Total execution time: 1.1207
INFO - 2016-01-30 20:41:37 --> Config Class Initialized
INFO - 2016-01-30 20:41:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:41:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:41:38 --> Utf8 Class Initialized
INFO - 2016-01-30 20:41:38 --> URI Class Initialized
INFO - 2016-01-30 20:41:38 --> Router Class Initialized
INFO - 2016-01-30 20:41:38 --> Output Class Initialized
INFO - 2016-01-30 20:41:38 --> Security Class Initialized
DEBUG - 2016-01-30 20:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:41:38 --> Input Class Initialized
INFO - 2016-01-30 20:41:38 --> Language Class Initialized
INFO - 2016-01-30 20:41:38 --> Loader Class Initialized
INFO - 2016-01-30 20:41:38 --> Helper loaded: url_helper
INFO - 2016-01-30 20:41:38 --> Helper loaded: file_helper
INFO - 2016-01-30 20:41:38 --> Helper loaded: date_helper
INFO - 2016-01-30 20:41:38 --> Database Driver Class Initialized
INFO - 2016-01-30 20:41:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:41:39 --> Controller Class Initialized
INFO - 2016-01-30 20:41:39 --> Model Class Initialized
INFO - 2016-01-30 20:41:39 --> Model Class Initialized
INFO - 2016-01-30 20:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:41:39 --> Pagination Class Initialized
INFO - 2016-01-30 20:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:41:39 --> Helper loaded: text_helper
INFO - 2016-01-30 20:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:41:39 --> Final output sent to browser
DEBUG - 2016-01-30 20:41:39 --> Total execution time: 1.7527
INFO - 2016-01-30 20:46:52 --> Config Class Initialized
INFO - 2016-01-30 20:46:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:46:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:46:52 --> Utf8 Class Initialized
INFO - 2016-01-30 20:46:52 --> URI Class Initialized
INFO - 2016-01-30 20:46:52 --> Router Class Initialized
INFO - 2016-01-30 20:46:52 --> Output Class Initialized
INFO - 2016-01-30 20:46:52 --> Security Class Initialized
DEBUG - 2016-01-30 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:46:52 --> Input Class Initialized
INFO - 2016-01-30 20:46:52 --> Language Class Initialized
INFO - 2016-01-30 20:46:52 --> Loader Class Initialized
INFO - 2016-01-30 20:46:52 --> Helper loaded: url_helper
INFO - 2016-01-30 20:46:52 --> Helper loaded: file_helper
INFO - 2016-01-30 20:46:52 --> Helper loaded: date_helper
INFO - 2016-01-30 20:46:52 --> Database Driver Class Initialized
INFO - 2016-01-30 20:46:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:46:53 --> Controller Class Initialized
INFO - 2016-01-30 20:46:53 --> Model Class Initialized
INFO - 2016-01-30 20:46:53 --> Model Class Initialized
INFO - 2016-01-30 20:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:46:53 --> Pagination Class Initialized
INFO - 2016-01-30 20:46:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:46:54 --> Helper loaded: text_helper
INFO - 2016-01-30 20:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:46:54 --> Final output sent to browser
DEBUG - 2016-01-30 20:46:54 --> Total execution time: 1.2239
INFO - 2016-01-30 20:47:20 --> Config Class Initialized
INFO - 2016-01-30 20:47:20 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:47:20 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:47:20 --> Utf8 Class Initialized
INFO - 2016-01-30 20:47:20 --> URI Class Initialized
INFO - 2016-01-30 20:47:20 --> Router Class Initialized
INFO - 2016-01-30 20:47:20 --> Output Class Initialized
INFO - 2016-01-30 20:47:20 --> Security Class Initialized
DEBUG - 2016-01-30 20:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:47:20 --> Input Class Initialized
INFO - 2016-01-30 20:47:20 --> Language Class Initialized
INFO - 2016-01-30 20:47:20 --> Loader Class Initialized
INFO - 2016-01-30 20:47:20 --> Helper loaded: url_helper
INFO - 2016-01-30 20:47:20 --> Helper loaded: file_helper
INFO - 2016-01-30 20:47:20 --> Helper loaded: date_helper
INFO - 2016-01-30 20:47:20 --> Database Driver Class Initialized
INFO - 2016-01-30 20:47:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:47:21 --> Controller Class Initialized
INFO - 2016-01-30 20:47:21 --> Model Class Initialized
INFO - 2016-01-30 20:47:21 --> Model Class Initialized
INFO - 2016-01-30 20:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:47:21 --> Pagination Class Initialized
INFO - 2016-01-30 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:47:21 --> Helper loaded: text_helper
INFO - 2016-01-30 20:47:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:47:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:47:22 --> Final output sent to browser
DEBUG - 2016-01-30 20:47:22 --> Total execution time: 1.2325
INFO - 2016-01-30 20:48:26 --> Config Class Initialized
INFO - 2016-01-30 20:48:26 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:48:26 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:48:26 --> Utf8 Class Initialized
INFO - 2016-01-30 20:48:26 --> URI Class Initialized
INFO - 2016-01-30 20:48:26 --> Router Class Initialized
INFO - 2016-01-30 20:48:26 --> Output Class Initialized
INFO - 2016-01-30 20:48:26 --> Security Class Initialized
DEBUG - 2016-01-30 20:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:48:26 --> Input Class Initialized
INFO - 2016-01-30 20:48:26 --> Language Class Initialized
INFO - 2016-01-30 20:48:26 --> Loader Class Initialized
INFO - 2016-01-30 20:48:26 --> Helper loaded: url_helper
INFO - 2016-01-30 20:48:26 --> Helper loaded: file_helper
INFO - 2016-01-30 20:48:26 --> Helper loaded: date_helper
INFO - 2016-01-30 20:48:26 --> Database Driver Class Initialized
INFO - 2016-01-30 20:48:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:48:27 --> Controller Class Initialized
INFO - 2016-01-30 20:48:27 --> Model Class Initialized
INFO - 2016-01-30 20:48:27 --> Model Class Initialized
INFO - 2016-01-30 20:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:48:27 --> Pagination Class Initialized
INFO - 2016-01-30 20:48:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:48:27 --> Helper loaded: text_helper
INFO - 2016-01-30 20:48:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:48:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:48:27 --> Final output sent to browser
DEBUG - 2016-01-30 20:48:27 --> Total execution time: 1.1446
INFO - 2016-01-30 20:48:44 --> Config Class Initialized
INFO - 2016-01-30 20:48:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:48:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:48:44 --> Utf8 Class Initialized
INFO - 2016-01-30 20:48:44 --> URI Class Initialized
INFO - 2016-01-30 20:48:44 --> Router Class Initialized
INFO - 2016-01-30 20:48:44 --> Output Class Initialized
INFO - 2016-01-30 20:48:44 --> Security Class Initialized
DEBUG - 2016-01-30 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:48:44 --> Input Class Initialized
INFO - 2016-01-30 20:48:44 --> Language Class Initialized
INFO - 2016-01-30 20:48:44 --> Loader Class Initialized
INFO - 2016-01-30 20:48:44 --> Helper loaded: url_helper
INFO - 2016-01-30 20:48:44 --> Helper loaded: file_helper
INFO - 2016-01-30 20:48:44 --> Helper loaded: date_helper
INFO - 2016-01-30 20:48:44 --> Database Driver Class Initialized
INFO - 2016-01-30 20:48:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:48:45 --> Controller Class Initialized
INFO - 2016-01-30 20:48:45 --> Model Class Initialized
INFO - 2016-01-30 20:48:45 --> Model Class Initialized
INFO - 2016-01-30 20:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:48:45 --> Pagination Class Initialized
INFO - 2016-01-30 20:48:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:48:45 --> Helper loaded: text_helper
INFO - 2016-01-30 20:48:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:48:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:48:45 --> Final output sent to browser
DEBUG - 2016-01-30 20:48:45 --> Total execution time: 1.1595
INFO - 2016-01-30 20:49:15 --> Config Class Initialized
INFO - 2016-01-30 20:49:15 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:49:15 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:49:15 --> Utf8 Class Initialized
INFO - 2016-01-30 20:49:15 --> URI Class Initialized
INFO - 2016-01-30 20:49:15 --> Router Class Initialized
INFO - 2016-01-30 20:49:15 --> Output Class Initialized
INFO - 2016-01-30 20:49:15 --> Security Class Initialized
DEBUG - 2016-01-30 20:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:49:15 --> Input Class Initialized
INFO - 2016-01-30 20:49:15 --> Language Class Initialized
INFO - 2016-01-30 20:49:15 --> Loader Class Initialized
INFO - 2016-01-30 20:49:15 --> Helper loaded: url_helper
INFO - 2016-01-30 20:49:15 --> Helper loaded: file_helper
INFO - 2016-01-30 20:49:15 --> Helper loaded: date_helper
INFO - 2016-01-30 20:49:15 --> Database Driver Class Initialized
INFO - 2016-01-30 20:49:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:49:16 --> Controller Class Initialized
INFO - 2016-01-30 20:49:16 --> Model Class Initialized
INFO - 2016-01-30 20:49:16 --> Model Class Initialized
INFO - 2016-01-30 20:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:49:16 --> Pagination Class Initialized
INFO - 2016-01-30 20:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:49:16 --> Helper loaded: text_helper
INFO - 2016-01-30 20:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:49:16 --> Final output sent to browser
DEBUG - 2016-01-30 20:49:17 --> Total execution time: 1.1965
INFO - 2016-01-30 20:49:49 --> Config Class Initialized
INFO - 2016-01-30 20:49:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:49:50 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:49:50 --> Utf8 Class Initialized
INFO - 2016-01-30 20:49:50 --> URI Class Initialized
INFO - 2016-01-30 20:49:50 --> Router Class Initialized
INFO - 2016-01-30 20:49:50 --> Output Class Initialized
INFO - 2016-01-30 20:49:50 --> Security Class Initialized
DEBUG - 2016-01-30 20:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:49:50 --> Input Class Initialized
INFO - 2016-01-30 20:49:50 --> Language Class Initialized
INFO - 2016-01-30 20:49:50 --> Loader Class Initialized
INFO - 2016-01-30 20:49:50 --> Helper loaded: url_helper
INFO - 2016-01-30 20:49:50 --> Helper loaded: file_helper
INFO - 2016-01-30 20:49:50 --> Helper loaded: date_helper
INFO - 2016-01-30 20:49:50 --> Database Driver Class Initialized
INFO - 2016-01-30 20:49:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:49:51 --> Controller Class Initialized
INFO - 2016-01-30 20:49:51 --> Model Class Initialized
INFO - 2016-01-30 20:49:51 --> Model Class Initialized
INFO - 2016-01-30 20:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:49:51 --> Pagination Class Initialized
INFO - 2016-01-30 20:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:49:51 --> Helper loaded: text_helper
INFO - 2016-01-30 20:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:49:51 --> Final output sent to browser
DEBUG - 2016-01-30 20:49:51 --> Total execution time: 1.2581
INFO - 2016-01-30 20:51:31 --> Config Class Initialized
INFO - 2016-01-30 20:51:31 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:51:31 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:51:31 --> Utf8 Class Initialized
INFO - 2016-01-30 20:51:31 --> URI Class Initialized
INFO - 2016-01-30 20:51:31 --> Router Class Initialized
INFO - 2016-01-30 20:51:31 --> Output Class Initialized
INFO - 2016-01-30 20:51:31 --> Security Class Initialized
DEBUG - 2016-01-30 20:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:51:31 --> Input Class Initialized
INFO - 2016-01-30 20:51:31 --> Language Class Initialized
INFO - 2016-01-30 20:51:31 --> Loader Class Initialized
INFO - 2016-01-30 20:51:31 --> Helper loaded: url_helper
INFO - 2016-01-30 20:51:31 --> Helper loaded: file_helper
INFO - 2016-01-30 20:51:31 --> Helper loaded: date_helper
INFO - 2016-01-30 20:51:31 --> Database Driver Class Initialized
INFO - 2016-01-30 20:51:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:51:32 --> Controller Class Initialized
INFO - 2016-01-30 20:51:32 --> Model Class Initialized
INFO - 2016-01-30 20:51:32 --> Model Class Initialized
INFO - 2016-01-30 20:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:51:32 --> Pagination Class Initialized
INFO - 2016-01-30 20:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:51:32 --> Helper loaded: text_helper
INFO - 2016-01-30 20:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:51:32 --> Final output sent to browser
DEBUG - 2016-01-30 20:51:32 --> Total execution time: 1.2801
INFO - 2016-01-30 20:53:13 --> Config Class Initialized
INFO - 2016-01-30 20:53:13 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:53:13 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:53:13 --> Utf8 Class Initialized
INFO - 2016-01-30 20:53:13 --> URI Class Initialized
INFO - 2016-01-30 20:53:13 --> Router Class Initialized
INFO - 2016-01-30 20:53:13 --> Output Class Initialized
INFO - 2016-01-30 20:53:13 --> Security Class Initialized
DEBUG - 2016-01-30 20:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:53:13 --> Input Class Initialized
INFO - 2016-01-30 20:53:13 --> Language Class Initialized
INFO - 2016-01-30 20:53:13 --> Loader Class Initialized
INFO - 2016-01-30 20:53:13 --> Helper loaded: url_helper
INFO - 2016-01-30 20:53:13 --> Helper loaded: file_helper
INFO - 2016-01-30 20:53:13 --> Helper loaded: date_helper
INFO - 2016-01-30 20:53:13 --> Database Driver Class Initialized
INFO - 2016-01-30 20:53:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:53:14 --> Controller Class Initialized
INFO - 2016-01-30 20:53:14 --> Model Class Initialized
INFO - 2016-01-30 20:53:14 --> Model Class Initialized
INFO - 2016-01-30 20:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:53:14 --> Pagination Class Initialized
INFO - 2016-01-30 20:53:14 --> Config Class Initialized
INFO - 2016-01-30 20:53:14 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:53:14 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:53:14 --> Utf8 Class Initialized
INFO - 2016-01-30 20:53:14 --> URI Class Initialized
INFO - 2016-01-30 20:53:14 --> Router Class Initialized
INFO - 2016-01-30 20:53:14 --> Output Class Initialized
INFO - 2016-01-30 20:53:14 --> Security Class Initialized
DEBUG - 2016-01-30 20:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:53:14 --> Input Class Initialized
INFO - 2016-01-30 20:53:14 --> Language Class Initialized
INFO - 2016-01-30 20:53:14 --> Loader Class Initialized
INFO - 2016-01-30 20:53:14 --> Helper loaded: url_helper
INFO - 2016-01-30 20:53:14 --> Helper loaded: file_helper
INFO - 2016-01-30 20:53:14 --> Helper loaded: date_helper
INFO - 2016-01-30 20:53:14 --> Database Driver Class Initialized
INFO - 2016-01-30 20:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:53:15 --> Controller Class Initialized
INFO - 2016-01-30 20:53:15 --> Model Class Initialized
INFO - 2016-01-30 20:53:15 --> Model Class Initialized
INFO - 2016-01-30 20:53:15 --> Helper loaded: form_helper
INFO - 2016-01-30 20:53:15 --> Form Validation Class Initialized
INFO - 2016-01-30 20:53:15 --> Helper loaded: text_helper
INFO - 2016-01-30 20:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 20:53:15 --> Final output sent to browser
DEBUG - 2016-01-30 20:53:15 --> Total execution time: 1.4003
INFO - 2016-01-30 20:53:18 --> Config Class Initialized
INFO - 2016-01-30 20:53:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:53:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:53:18 --> Utf8 Class Initialized
INFO - 2016-01-30 20:53:18 --> URI Class Initialized
DEBUG - 2016-01-30 20:53:18 --> No URI present. Default controller set.
INFO - 2016-01-30 20:53:18 --> Router Class Initialized
INFO - 2016-01-30 20:53:18 --> Output Class Initialized
INFO - 2016-01-30 20:53:18 --> Security Class Initialized
DEBUG - 2016-01-30 20:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:53:18 --> Input Class Initialized
INFO - 2016-01-30 20:53:18 --> Language Class Initialized
INFO - 2016-01-30 20:53:18 --> Loader Class Initialized
INFO - 2016-01-30 20:53:18 --> Helper loaded: url_helper
INFO - 2016-01-30 20:53:18 --> Helper loaded: file_helper
INFO - 2016-01-30 20:53:18 --> Helper loaded: date_helper
INFO - 2016-01-30 20:53:18 --> Database Driver Class Initialized
INFO - 2016-01-30 20:53:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:53:19 --> Controller Class Initialized
INFO - 2016-01-30 20:53:19 --> Model Class Initialized
INFO - 2016-01-30 20:53:19 --> Model Class Initialized
INFO - 2016-01-30 20:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:53:19 --> Pagination Class Initialized
INFO - 2016-01-30 20:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 20:53:19 --> Final output sent to browser
DEBUG - 2016-01-30 20:53:19 --> Total execution time: 1.1239
INFO - 2016-01-30 20:53:25 --> Config Class Initialized
INFO - 2016-01-30 20:53:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:53:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:53:25 --> Utf8 Class Initialized
INFO - 2016-01-30 20:53:25 --> URI Class Initialized
INFO - 2016-01-30 20:53:25 --> Router Class Initialized
INFO - 2016-01-30 20:53:25 --> Output Class Initialized
INFO - 2016-01-30 20:53:25 --> Security Class Initialized
DEBUG - 2016-01-30 20:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:53:25 --> Input Class Initialized
INFO - 2016-01-30 20:53:25 --> Language Class Initialized
INFO - 2016-01-30 20:53:25 --> Loader Class Initialized
INFO - 2016-01-30 20:53:25 --> Helper loaded: url_helper
INFO - 2016-01-30 20:53:25 --> Helper loaded: file_helper
INFO - 2016-01-30 20:53:25 --> Helper loaded: date_helper
INFO - 2016-01-30 20:53:25 --> Database Driver Class Initialized
INFO - 2016-01-30 20:53:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:53:26 --> Controller Class Initialized
INFO - 2016-01-30 20:53:26 --> Model Class Initialized
INFO - 2016-01-30 20:53:26 --> Model Class Initialized
INFO - 2016-01-30 20:53:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:53:26 --> Pagination Class Initialized
INFO - 2016-01-30 20:53:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:53:26 --> Helper loaded: text_helper
INFO - 2016-01-30 20:53:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:53:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:53:26 --> Final output sent to browser
DEBUG - 2016-01-30 20:53:26 --> Total execution time: 1.1803
INFO - 2016-01-30 20:57:34 --> Config Class Initialized
INFO - 2016-01-30 20:57:34 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:57:34 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:57:34 --> Utf8 Class Initialized
INFO - 2016-01-30 20:57:34 --> URI Class Initialized
INFO - 2016-01-30 20:57:34 --> Router Class Initialized
INFO - 2016-01-30 20:57:34 --> Output Class Initialized
INFO - 2016-01-30 20:57:34 --> Security Class Initialized
DEBUG - 2016-01-30 20:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:57:34 --> Input Class Initialized
INFO - 2016-01-30 20:57:34 --> Language Class Initialized
INFO - 2016-01-30 20:57:34 --> Loader Class Initialized
INFO - 2016-01-30 20:57:34 --> Helper loaded: url_helper
INFO - 2016-01-30 20:57:34 --> Helper loaded: file_helper
INFO - 2016-01-30 20:57:34 --> Helper loaded: date_helper
INFO - 2016-01-30 20:57:34 --> Database Driver Class Initialized
INFO - 2016-01-30 20:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:57:35 --> Controller Class Initialized
INFO - 2016-01-30 20:57:35 --> Model Class Initialized
INFO - 2016-01-30 20:57:35 --> Model Class Initialized
INFO - 2016-01-30 20:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:57:35 --> Pagination Class Initialized
INFO - 2016-01-30 20:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:57:35 --> Helper loaded: text_helper
INFO - 2016-01-30 20:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:57:35 --> Final output sent to browser
DEBUG - 2016-01-30 20:57:35 --> Total execution time: 1.1342
INFO - 2016-01-30 20:58:19 --> Config Class Initialized
INFO - 2016-01-30 20:58:19 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:58:19 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:58:19 --> Utf8 Class Initialized
INFO - 2016-01-30 20:58:19 --> URI Class Initialized
DEBUG - 2016-01-30 20:58:19 --> No URI present. Default controller set.
INFO - 2016-01-30 20:58:19 --> Router Class Initialized
INFO - 2016-01-30 20:58:19 --> Output Class Initialized
INFO - 2016-01-30 20:58:19 --> Security Class Initialized
DEBUG - 2016-01-30 20:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:58:19 --> Input Class Initialized
INFO - 2016-01-30 20:58:19 --> Language Class Initialized
INFO - 2016-01-30 20:58:19 --> Loader Class Initialized
INFO - 2016-01-30 20:58:19 --> Helper loaded: url_helper
INFO - 2016-01-30 20:58:19 --> Helper loaded: file_helper
INFO - 2016-01-30 20:58:19 --> Helper loaded: date_helper
INFO - 2016-01-30 20:58:19 --> Database Driver Class Initialized
INFO - 2016-01-30 20:58:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:58:20 --> Controller Class Initialized
INFO - 2016-01-30 20:58:20 --> Model Class Initialized
INFO - 2016-01-30 20:58:20 --> Model Class Initialized
INFO - 2016-01-30 20:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:58:20 --> Pagination Class Initialized
INFO - 2016-01-30 20:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 20:58:20 --> Final output sent to browser
DEBUG - 2016-01-30 20:58:20 --> Total execution time: 1.1034
INFO - 2016-01-30 20:58:25 --> Config Class Initialized
INFO - 2016-01-30 20:58:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:58:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:58:25 --> Utf8 Class Initialized
INFO - 2016-01-30 20:58:25 --> URI Class Initialized
INFO - 2016-01-30 20:58:25 --> Router Class Initialized
INFO - 2016-01-30 20:58:25 --> Output Class Initialized
INFO - 2016-01-30 20:58:25 --> Security Class Initialized
DEBUG - 2016-01-30 20:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:58:25 --> Input Class Initialized
INFO - 2016-01-30 20:58:25 --> Language Class Initialized
INFO - 2016-01-30 20:58:25 --> Loader Class Initialized
INFO - 2016-01-30 20:58:25 --> Helper loaded: url_helper
INFO - 2016-01-30 20:58:25 --> Helper loaded: file_helper
INFO - 2016-01-30 20:58:25 --> Helper loaded: date_helper
INFO - 2016-01-30 20:58:25 --> Database Driver Class Initialized
INFO - 2016-01-30 20:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:58:26 --> Controller Class Initialized
INFO - 2016-01-30 20:58:26 --> Model Class Initialized
INFO - 2016-01-30 20:58:26 --> Model Class Initialized
INFO - 2016-01-30 20:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:58:26 --> Pagination Class Initialized
INFO - 2016-01-30 20:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:58:26 --> Helper loaded: text_helper
INFO - 2016-01-30 20:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:58:26 --> Final output sent to browser
DEBUG - 2016-01-30 20:58:26 --> Total execution time: 1.1469
INFO - 2016-01-30 20:58:37 --> Config Class Initialized
INFO - 2016-01-30 20:58:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 20:58:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 20:58:37 --> Utf8 Class Initialized
INFO - 2016-01-30 20:58:37 --> URI Class Initialized
INFO - 2016-01-30 20:58:37 --> Router Class Initialized
INFO - 2016-01-30 20:58:37 --> Output Class Initialized
INFO - 2016-01-30 20:58:37 --> Security Class Initialized
DEBUG - 2016-01-30 20:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 20:58:37 --> Input Class Initialized
INFO - 2016-01-30 20:58:37 --> Language Class Initialized
INFO - 2016-01-30 20:58:37 --> Loader Class Initialized
INFO - 2016-01-30 20:58:37 --> Helper loaded: url_helper
INFO - 2016-01-30 20:58:37 --> Helper loaded: file_helper
INFO - 2016-01-30 20:58:37 --> Helper loaded: date_helper
INFO - 2016-01-30 20:58:37 --> Database Driver Class Initialized
INFO - 2016-01-30 20:58:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 20:58:38 --> Controller Class Initialized
INFO - 2016-01-30 20:58:38 --> Model Class Initialized
INFO - 2016-01-30 20:58:38 --> Model Class Initialized
INFO - 2016-01-30 20:58:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 20:58:38 --> Pagination Class Initialized
INFO - 2016-01-30 20:58:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 20:58:38 --> Helper loaded: text_helper
INFO - 2016-01-30 20:58:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 20:58:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 20:58:38 --> Final output sent to browser
DEBUG - 2016-01-30 20:58:38 --> Total execution time: 1.1547
INFO - 2016-01-30 21:00:49 --> Config Class Initialized
INFO - 2016-01-30 21:00:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:00:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:00:49 --> Utf8 Class Initialized
INFO - 2016-01-30 21:00:49 --> URI Class Initialized
INFO - 2016-01-30 21:00:49 --> Router Class Initialized
INFO - 2016-01-30 21:00:49 --> Output Class Initialized
INFO - 2016-01-30 21:00:49 --> Security Class Initialized
DEBUG - 2016-01-30 21:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:00:49 --> Input Class Initialized
INFO - 2016-01-30 21:00:49 --> Language Class Initialized
INFO - 2016-01-30 21:00:49 --> Loader Class Initialized
INFO - 2016-01-30 21:00:49 --> Helper loaded: url_helper
INFO - 2016-01-30 21:00:49 --> Helper loaded: file_helper
INFO - 2016-01-30 21:00:49 --> Helper loaded: date_helper
INFO - 2016-01-30 21:00:49 --> Database Driver Class Initialized
INFO - 2016-01-30 21:00:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:00:50 --> Controller Class Initialized
INFO - 2016-01-30 21:00:50 --> Model Class Initialized
INFO - 2016-01-30 21:00:50 --> Model Class Initialized
INFO - 2016-01-30 21:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:00:50 --> Pagination Class Initialized
INFO - 2016-01-30 21:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:00:50 --> Helper loaded: text_helper
INFO - 2016-01-30 21:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:00:50 --> Final output sent to browser
DEBUG - 2016-01-30 21:00:50 --> Total execution time: 1.1876
INFO - 2016-01-30 21:04:01 --> Config Class Initialized
INFO - 2016-01-30 21:04:01 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:04:01 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:04:01 --> Utf8 Class Initialized
INFO - 2016-01-30 21:04:01 --> URI Class Initialized
INFO - 2016-01-30 21:04:01 --> Router Class Initialized
INFO - 2016-01-30 21:04:01 --> Output Class Initialized
INFO - 2016-01-30 21:04:01 --> Security Class Initialized
DEBUG - 2016-01-30 21:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:04:01 --> Input Class Initialized
INFO - 2016-01-30 21:04:01 --> Language Class Initialized
INFO - 2016-01-30 21:04:01 --> Loader Class Initialized
INFO - 2016-01-30 21:04:01 --> Helper loaded: url_helper
INFO - 2016-01-30 21:04:01 --> Helper loaded: file_helper
INFO - 2016-01-30 21:04:01 --> Helper loaded: date_helper
INFO - 2016-01-30 21:04:01 --> Database Driver Class Initialized
INFO - 2016-01-30 21:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:04:02 --> Controller Class Initialized
INFO - 2016-01-30 21:04:02 --> Model Class Initialized
INFO - 2016-01-30 21:04:02 --> Model Class Initialized
INFO - 2016-01-30 21:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:04:02 --> Pagination Class Initialized
INFO - 2016-01-30 21:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:04:02 --> Helper loaded: text_helper
INFO - 2016-01-30 21:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:04:02 --> Final output sent to browser
DEBUG - 2016-01-30 21:04:02 --> Total execution time: 1.2117
INFO - 2016-01-30 21:05:07 --> Config Class Initialized
INFO - 2016-01-30 21:05:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:05:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:05:07 --> Utf8 Class Initialized
INFO - 2016-01-30 21:05:07 --> URI Class Initialized
INFO - 2016-01-30 21:05:07 --> Router Class Initialized
INFO - 2016-01-30 21:05:07 --> Output Class Initialized
INFO - 2016-01-30 21:05:07 --> Security Class Initialized
DEBUG - 2016-01-30 21:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:05:07 --> Input Class Initialized
INFO - 2016-01-30 21:05:07 --> Language Class Initialized
INFO - 2016-01-30 21:05:07 --> Loader Class Initialized
INFO - 2016-01-30 21:05:07 --> Helper loaded: url_helper
INFO - 2016-01-30 21:05:07 --> Helper loaded: file_helper
INFO - 2016-01-30 21:05:07 --> Helper loaded: date_helper
INFO - 2016-01-30 21:05:07 --> Database Driver Class Initialized
INFO - 2016-01-30 21:05:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:05:08 --> Controller Class Initialized
INFO - 2016-01-30 21:05:08 --> Model Class Initialized
INFO - 2016-01-30 21:05:08 --> Model Class Initialized
INFO - 2016-01-30 21:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:05:08 --> Pagination Class Initialized
INFO - 2016-01-30 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:05:08 --> Helper loaded: text_helper
INFO - 2016-01-30 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:05:08 --> Final output sent to browser
DEBUG - 2016-01-30 21:05:08 --> Total execution time: 1.1769
INFO - 2016-01-30 21:06:20 --> Config Class Initialized
INFO - 2016-01-30 21:06:20 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:06:20 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:06:20 --> Utf8 Class Initialized
INFO - 2016-01-30 21:06:20 --> URI Class Initialized
INFO - 2016-01-30 21:06:20 --> Router Class Initialized
INFO - 2016-01-30 21:06:20 --> Output Class Initialized
INFO - 2016-01-30 21:06:20 --> Security Class Initialized
DEBUG - 2016-01-30 21:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:06:20 --> Input Class Initialized
INFO - 2016-01-30 21:06:20 --> Language Class Initialized
INFO - 2016-01-30 21:06:20 --> Loader Class Initialized
INFO - 2016-01-30 21:06:20 --> Helper loaded: url_helper
INFO - 2016-01-30 21:06:20 --> Helper loaded: file_helper
INFO - 2016-01-30 21:06:20 --> Helper loaded: date_helper
INFO - 2016-01-30 21:06:20 --> Database Driver Class Initialized
INFO - 2016-01-30 21:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:06:21 --> Controller Class Initialized
INFO - 2016-01-30 21:06:21 --> Model Class Initialized
INFO - 2016-01-30 21:06:21 --> Model Class Initialized
INFO - 2016-01-30 21:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:06:21 --> Pagination Class Initialized
INFO - 2016-01-30 21:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:06:21 --> Helper loaded: text_helper
INFO - 2016-01-30 21:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:06:21 --> Final output sent to browser
DEBUG - 2016-01-30 21:06:21 --> Total execution time: 1.1646
INFO - 2016-01-30 21:06:32 --> Config Class Initialized
INFO - 2016-01-30 21:06:32 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:06:32 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:06:32 --> Utf8 Class Initialized
INFO - 2016-01-30 21:06:32 --> URI Class Initialized
INFO - 2016-01-30 21:06:32 --> Router Class Initialized
INFO - 2016-01-30 21:06:32 --> Output Class Initialized
INFO - 2016-01-30 21:06:32 --> Security Class Initialized
DEBUG - 2016-01-30 21:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:06:32 --> Input Class Initialized
INFO - 2016-01-30 21:06:32 --> Language Class Initialized
INFO - 2016-01-30 21:06:32 --> Loader Class Initialized
INFO - 2016-01-30 21:06:32 --> Helper loaded: url_helper
INFO - 2016-01-30 21:06:32 --> Helper loaded: file_helper
INFO - 2016-01-30 21:06:32 --> Helper loaded: date_helper
INFO - 2016-01-30 21:06:32 --> Database Driver Class Initialized
INFO - 2016-01-30 21:06:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:06:33 --> Controller Class Initialized
INFO - 2016-01-30 21:06:33 --> Model Class Initialized
INFO - 2016-01-30 21:06:33 --> Model Class Initialized
INFO - 2016-01-30 21:06:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:06:33 --> Pagination Class Initialized
INFO - 2016-01-30 21:06:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:06:33 --> Helper loaded: text_helper
INFO - 2016-01-30 21:06:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:06:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:06:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:06:33 --> Final output sent to browser
DEBUG - 2016-01-30 21:06:33 --> Total execution time: 1.1840
INFO - 2016-01-30 21:07:52 --> Config Class Initialized
INFO - 2016-01-30 21:07:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:07:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:07:52 --> Utf8 Class Initialized
INFO - 2016-01-30 21:07:52 --> URI Class Initialized
INFO - 2016-01-30 21:07:52 --> Router Class Initialized
INFO - 2016-01-30 21:07:52 --> Output Class Initialized
INFO - 2016-01-30 21:07:52 --> Security Class Initialized
DEBUG - 2016-01-30 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:07:52 --> Input Class Initialized
INFO - 2016-01-30 21:07:52 --> Language Class Initialized
INFO - 2016-01-30 21:07:52 --> Loader Class Initialized
INFO - 2016-01-30 21:07:52 --> Helper loaded: url_helper
INFO - 2016-01-30 21:07:52 --> Helper loaded: file_helper
INFO - 2016-01-30 21:07:52 --> Helper loaded: date_helper
INFO - 2016-01-30 21:07:52 --> Database Driver Class Initialized
INFO - 2016-01-30 21:07:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:07:53 --> Controller Class Initialized
INFO - 2016-01-30 21:07:53 --> Model Class Initialized
INFO - 2016-01-30 21:07:53 --> Model Class Initialized
INFO - 2016-01-30 21:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:07:53 --> Pagination Class Initialized
INFO - 2016-01-30 21:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:07:53 --> Helper loaded: text_helper
INFO - 2016-01-30 21:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:07:53 --> Final output sent to browser
DEBUG - 2016-01-30 21:07:53 --> Total execution time: 1.2895
INFO - 2016-01-30 21:08:34 --> Config Class Initialized
INFO - 2016-01-30 21:08:34 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:08:34 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:08:34 --> Utf8 Class Initialized
INFO - 2016-01-30 21:08:34 --> URI Class Initialized
INFO - 2016-01-30 21:08:34 --> Router Class Initialized
INFO - 2016-01-30 21:08:34 --> Output Class Initialized
INFO - 2016-01-30 21:08:34 --> Security Class Initialized
DEBUG - 2016-01-30 21:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:08:34 --> Input Class Initialized
INFO - 2016-01-30 21:08:34 --> Language Class Initialized
INFO - 2016-01-30 21:08:34 --> Loader Class Initialized
INFO - 2016-01-30 21:08:34 --> Helper loaded: url_helper
INFO - 2016-01-30 21:08:34 --> Helper loaded: file_helper
INFO - 2016-01-30 21:08:34 --> Helper loaded: date_helper
INFO - 2016-01-30 21:08:34 --> Database Driver Class Initialized
INFO - 2016-01-30 21:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:08:35 --> Controller Class Initialized
INFO - 2016-01-30 21:08:35 --> Model Class Initialized
INFO - 2016-01-30 21:08:35 --> Model Class Initialized
INFO - 2016-01-30 21:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:08:35 --> Pagination Class Initialized
INFO - 2016-01-30 21:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:08:35 --> Helper loaded: text_helper
INFO - 2016-01-30 21:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:08:35 --> Final output sent to browser
DEBUG - 2016-01-30 21:08:35 --> Total execution time: 1.1845
INFO - 2016-01-30 21:19:59 --> Config Class Initialized
INFO - 2016-01-30 21:19:59 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:19:59 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:19:59 --> Utf8 Class Initialized
INFO - 2016-01-30 21:19:59 --> URI Class Initialized
INFO - 2016-01-30 21:19:59 --> Router Class Initialized
INFO - 2016-01-30 21:19:59 --> Output Class Initialized
INFO - 2016-01-30 21:19:59 --> Security Class Initialized
DEBUG - 2016-01-30 21:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:19:59 --> Input Class Initialized
INFO - 2016-01-30 21:19:59 --> Language Class Initialized
INFO - 2016-01-30 21:19:59 --> Loader Class Initialized
INFO - 2016-01-30 21:19:59 --> Helper loaded: url_helper
INFO - 2016-01-30 21:19:59 --> Helper loaded: file_helper
INFO - 2016-01-30 21:19:59 --> Helper loaded: date_helper
INFO - 2016-01-30 21:19:59 --> Database Driver Class Initialized
INFO - 2016-01-30 21:20:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:20:01 --> Controller Class Initialized
INFO - 2016-01-30 21:20:01 --> Model Class Initialized
INFO - 2016-01-30 21:20:01 --> Model Class Initialized
INFO - 2016-01-30 21:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:20:01 --> Pagination Class Initialized
INFO - 2016-01-30 21:20:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:20:01 --> Helper loaded: text_helper
INFO - 2016-01-30 21:20:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:20:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:20:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:20:01 --> Final output sent to browser
DEBUG - 2016-01-30 21:20:01 --> Total execution time: 1.1424
INFO - 2016-01-30 21:20:39 --> Config Class Initialized
INFO - 2016-01-30 21:20:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:20:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:20:39 --> Utf8 Class Initialized
INFO - 2016-01-30 21:20:39 --> URI Class Initialized
INFO - 2016-01-30 21:20:39 --> Router Class Initialized
INFO - 2016-01-30 21:20:39 --> Output Class Initialized
INFO - 2016-01-30 21:20:39 --> Security Class Initialized
DEBUG - 2016-01-30 21:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:20:39 --> Input Class Initialized
INFO - 2016-01-30 21:20:39 --> Language Class Initialized
INFO - 2016-01-30 21:20:39 --> Loader Class Initialized
INFO - 2016-01-30 21:20:39 --> Helper loaded: url_helper
INFO - 2016-01-30 21:20:39 --> Helper loaded: file_helper
INFO - 2016-01-30 21:20:39 --> Helper loaded: date_helper
INFO - 2016-01-30 21:20:39 --> Database Driver Class Initialized
INFO - 2016-01-30 21:20:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:20:40 --> Controller Class Initialized
INFO - 2016-01-30 21:20:40 --> Model Class Initialized
INFO - 2016-01-30 21:20:40 --> Model Class Initialized
INFO - 2016-01-30 21:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:20:40 --> Pagination Class Initialized
INFO - 2016-01-30 21:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:20:40 --> Helper loaded: text_helper
INFO - 2016-01-30 21:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:20:40 --> Final output sent to browser
DEBUG - 2016-01-30 21:20:40 --> Total execution time: 1.2102
INFO - 2016-01-30 21:20:49 --> Config Class Initialized
INFO - 2016-01-30 21:20:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:20:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:20:49 --> Utf8 Class Initialized
INFO - 2016-01-30 21:20:49 --> URI Class Initialized
INFO - 2016-01-30 21:20:49 --> Router Class Initialized
INFO - 2016-01-30 21:20:49 --> Output Class Initialized
INFO - 2016-01-30 21:20:49 --> Security Class Initialized
DEBUG - 2016-01-30 21:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:20:49 --> Input Class Initialized
INFO - 2016-01-30 21:20:49 --> Language Class Initialized
INFO - 2016-01-30 21:20:49 --> Loader Class Initialized
INFO - 2016-01-30 21:20:49 --> Helper loaded: url_helper
INFO - 2016-01-30 21:20:49 --> Helper loaded: file_helper
INFO - 2016-01-30 21:20:49 --> Helper loaded: date_helper
INFO - 2016-01-30 21:20:49 --> Database Driver Class Initialized
INFO - 2016-01-30 21:20:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:20:50 --> Controller Class Initialized
INFO - 2016-01-30 21:20:50 --> Model Class Initialized
INFO - 2016-01-30 21:20:50 --> Model Class Initialized
INFO - 2016-01-30 21:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:20:50 --> Pagination Class Initialized
INFO - 2016-01-30 21:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:20:50 --> Helper loaded: text_helper
INFO - 2016-01-30 21:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:20:50 --> Final output sent to browser
DEBUG - 2016-01-30 21:20:50 --> Total execution time: 1.1539
INFO - 2016-01-30 21:21:30 --> Config Class Initialized
INFO - 2016-01-30 21:21:30 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:21:31 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:21:31 --> Utf8 Class Initialized
INFO - 2016-01-30 21:21:31 --> URI Class Initialized
INFO - 2016-01-30 21:21:31 --> Router Class Initialized
INFO - 2016-01-30 21:21:31 --> Output Class Initialized
INFO - 2016-01-30 21:21:31 --> Security Class Initialized
DEBUG - 2016-01-30 21:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:21:31 --> Input Class Initialized
INFO - 2016-01-30 21:21:31 --> Language Class Initialized
INFO - 2016-01-30 21:21:31 --> Loader Class Initialized
INFO - 2016-01-30 21:21:31 --> Helper loaded: url_helper
INFO - 2016-01-30 21:21:31 --> Helper loaded: file_helper
INFO - 2016-01-30 21:21:31 --> Helper loaded: date_helper
INFO - 2016-01-30 21:21:31 --> Database Driver Class Initialized
INFO - 2016-01-30 21:21:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:21:32 --> Controller Class Initialized
INFO - 2016-01-30 21:21:32 --> Model Class Initialized
INFO - 2016-01-30 21:21:32 --> Model Class Initialized
INFO - 2016-01-30 21:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:21:32 --> Pagination Class Initialized
INFO - 2016-01-30 21:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:21:32 --> Helper loaded: text_helper
INFO - 2016-01-30 21:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:21:32 --> Final output sent to browser
DEBUG - 2016-01-30 21:21:32 --> Total execution time: 1.1646
INFO - 2016-01-30 21:21:49 --> Config Class Initialized
INFO - 2016-01-30 21:21:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:21:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:21:49 --> Utf8 Class Initialized
INFO - 2016-01-30 21:21:49 --> URI Class Initialized
INFO - 2016-01-30 21:21:49 --> Router Class Initialized
INFO - 2016-01-30 21:21:49 --> Output Class Initialized
INFO - 2016-01-30 21:21:49 --> Security Class Initialized
DEBUG - 2016-01-30 21:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:21:49 --> Input Class Initialized
INFO - 2016-01-30 21:21:49 --> Language Class Initialized
INFO - 2016-01-30 21:21:49 --> Loader Class Initialized
INFO - 2016-01-30 21:21:49 --> Helper loaded: url_helper
INFO - 2016-01-30 21:21:49 --> Helper loaded: file_helper
INFO - 2016-01-30 21:21:49 --> Helper loaded: date_helper
INFO - 2016-01-30 21:21:49 --> Database Driver Class Initialized
INFO - 2016-01-30 21:21:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:21:50 --> Controller Class Initialized
INFO - 2016-01-30 21:21:50 --> Model Class Initialized
INFO - 2016-01-30 21:21:50 --> Model Class Initialized
INFO - 2016-01-30 21:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:21:50 --> Pagination Class Initialized
INFO - 2016-01-30 21:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:21:50 --> Helper loaded: text_helper
INFO - 2016-01-30 21:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:21:50 --> Final output sent to browser
DEBUG - 2016-01-30 21:21:50 --> Total execution time: 1.1601
INFO - 2016-01-30 21:22:10 --> Config Class Initialized
INFO - 2016-01-30 21:22:10 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:22:10 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:22:10 --> Utf8 Class Initialized
INFO - 2016-01-30 21:22:10 --> URI Class Initialized
INFO - 2016-01-30 21:22:10 --> Router Class Initialized
INFO - 2016-01-30 21:22:10 --> Output Class Initialized
INFO - 2016-01-30 21:22:10 --> Security Class Initialized
DEBUG - 2016-01-30 21:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:22:10 --> Input Class Initialized
INFO - 2016-01-30 21:22:10 --> Language Class Initialized
INFO - 2016-01-30 21:22:10 --> Loader Class Initialized
INFO - 2016-01-30 21:22:10 --> Helper loaded: url_helper
INFO - 2016-01-30 21:22:10 --> Helper loaded: file_helper
INFO - 2016-01-30 21:22:10 --> Helper loaded: date_helper
INFO - 2016-01-30 21:22:10 --> Database Driver Class Initialized
INFO - 2016-01-30 21:22:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:22:11 --> Controller Class Initialized
INFO - 2016-01-30 21:22:11 --> Model Class Initialized
INFO - 2016-01-30 21:22:11 --> Model Class Initialized
INFO - 2016-01-30 21:22:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:22:11 --> Pagination Class Initialized
INFO - 2016-01-30 21:22:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:22:11 --> Helper loaded: text_helper
INFO - 2016-01-30 21:22:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:22:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:22:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:22:11 --> Final output sent to browser
DEBUG - 2016-01-30 21:22:11 --> Total execution time: 1.1976
INFO - 2016-01-30 21:22:29 --> Config Class Initialized
INFO - 2016-01-30 21:22:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:22:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:22:30 --> Utf8 Class Initialized
INFO - 2016-01-30 21:22:30 --> URI Class Initialized
INFO - 2016-01-30 21:22:30 --> Router Class Initialized
INFO - 2016-01-30 21:22:30 --> Output Class Initialized
INFO - 2016-01-30 21:22:30 --> Security Class Initialized
DEBUG - 2016-01-30 21:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:22:30 --> Input Class Initialized
INFO - 2016-01-30 21:22:30 --> Language Class Initialized
INFO - 2016-01-30 21:22:30 --> Loader Class Initialized
INFO - 2016-01-30 21:22:30 --> Helper loaded: url_helper
INFO - 2016-01-30 21:22:30 --> Helper loaded: file_helper
INFO - 2016-01-30 21:22:30 --> Helper loaded: date_helper
INFO - 2016-01-30 21:22:30 --> Database Driver Class Initialized
INFO - 2016-01-30 21:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:22:31 --> Controller Class Initialized
INFO - 2016-01-30 21:22:31 --> Model Class Initialized
INFO - 2016-01-30 21:22:31 --> Model Class Initialized
INFO - 2016-01-30 21:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:22:31 --> Pagination Class Initialized
INFO - 2016-01-30 21:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:22:31 --> Helper loaded: text_helper
INFO - 2016-01-30 21:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:22:31 --> Final output sent to browser
DEBUG - 2016-01-30 21:22:31 --> Total execution time: 1.2081
INFO - 2016-01-30 21:22:45 --> Config Class Initialized
INFO - 2016-01-30 21:22:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:22:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:22:45 --> Utf8 Class Initialized
INFO - 2016-01-30 21:22:45 --> URI Class Initialized
INFO - 2016-01-30 21:22:45 --> Router Class Initialized
INFO - 2016-01-30 21:22:45 --> Output Class Initialized
INFO - 2016-01-30 21:22:45 --> Security Class Initialized
DEBUG - 2016-01-30 21:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:22:45 --> Input Class Initialized
INFO - 2016-01-30 21:22:45 --> Language Class Initialized
INFO - 2016-01-30 21:22:45 --> Loader Class Initialized
INFO - 2016-01-30 21:22:45 --> Helper loaded: url_helper
INFO - 2016-01-30 21:22:45 --> Helper loaded: file_helper
INFO - 2016-01-30 21:22:45 --> Helper loaded: date_helper
INFO - 2016-01-30 21:22:45 --> Database Driver Class Initialized
INFO - 2016-01-30 21:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:22:46 --> Controller Class Initialized
INFO - 2016-01-30 21:22:46 --> Model Class Initialized
INFO - 2016-01-30 21:22:46 --> Model Class Initialized
INFO - 2016-01-30 21:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:22:46 --> Pagination Class Initialized
INFO - 2016-01-30 21:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:22:46 --> Helper loaded: text_helper
INFO - 2016-01-30 21:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:22:46 --> Final output sent to browser
DEBUG - 2016-01-30 21:22:46 --> Total execution time: 1.2060
INFO - 2016-01-30 21:23:30 --> Config Class Initialized
INFO - 2016-01-30 21:23:30 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:23:30 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:23:30 --> Utf8 Class Initialized
INFO - 2016-01-30 21:23:30 --> URI Class Initialized
INFO - 2016-01-30 21:23:30 --> Router Class Initialized
INFO - 2016-01-30 21:23:30 --> Output Class Initialized
INFO - 2016-01-30 21:23:30 --> Security Class Initialized
DEBUG - 2016-01-30 21:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:23:30 --> Input Class Initialized
INFO - 2016-01-30 21:23:30 --> Language Class Initialized
INFO - 2016-01-30 21:23:30 --> Loader Class Initialized
INFO - 2016-01-30 21:23:30 --> Helper loaded: url_helper
INFO - 2016-01-30 21:23:30 --> Helper loaded: file_helper
INFO - 2016-01-30 21:23:30 --> Helper loaded: date_helper
INFO - 2016-01-30 21:23:30 --> Database Driver Class Initialized
INFO - 2016-01-30 21:23:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:23:31 --> Controller Class Initialized
INFO - 2016-01-30 21:23:31 --> Model Class Initialized
INFO - 2016-01-30 21:23:31 --> Model Class Initialized
INFO - 2016-01-30 21:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:23:31 --> Pagination Class Initialized
INFO - 2016-01-30 21:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:23:31 --> Helper loaded: text_helper
INFO - 2016-01-30 21:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:23:31 --> Final output sent to browser
DEBUG - 2016-01-30 21:23:31 --> Total execution time: 1.2039
INFO - 2016-01-30 21:23:57 --> Config Class Initialized
INFO - 2016-01-30 21:23:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:23:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:23:57 --> Utf8 Class Initialized
INFO - 2016-01-30 21:23:57 --> URI Class Initialized
INFO - 2016-01-30 21:23:57 --> Router Class Initialized
INFO - 2016-01-30 21:23:57 --> Output Class Initialized
INFO - 2016-01-30 21:23:57 --> Security Class Initialized
DEBUG - 2016-01-30 21:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:23:57 --> Input Class Initialized
INFO - 2016-01-30 21:23:57 --> Language Class Initialized
INFO - 2016-01-30 21:23:57 --> Loader Class Initialized
INFO - 2016-01-30 21:23:57 --> Helper loaded: url_helper
INFO - 2016-01-30 21:23:57 --> Helper loaded: file_helper
INFO - 2016-01-30 21:23:57 --> Helper loaded: date_helper
INFO - 2016-01-30 21:23:57 --> Database Driver Class Initialized
INFO - 2016-01-30 21:23:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:23:58 --> Controller Class Initialized
INFO - 2016-01-30 21:23:58 --> Model Class Initialized
INFO - 2016-01-30 21:23:58 --> Model Class Initialized
INFO - 2016-01-30 21:23:58 --> Helper loaded: form_helper
INFO - 2016-01-30 21:23:58 --> Form Validation Class Initialized
INFO - 2016-01-30 21:23:58 --> Helper loaded: text_helper
INFO - 2016-01-30 21:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 21:23:58 --> Final output sent to browser
DEBUG - 2016-01-30 21:23:58 --> Total execution time: 1.1509
INFO - 2016-01-30 21:24:03 --> Config Class Initialized
INFO - 2016-01-30 21:24:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:03 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:03 --> URI Class Initialized
INFO - 2016-01-30 21:24:03 --> Router Class Initialized
INFO - 2016-01-30 21:24:03 --> Output Class Initialized
INFO - 2016-01-30 21:24:03 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:03 --> Input Class Initialized
INFO - 2016-01-30 21:24:03 --> Language Class Initialized
INFO - 2016-01-30 21:24:03 --> Loader Class Initialized
INFO - 2016-01-30 21:24:03 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:03 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:03 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:03 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:04 --> Controller Class Initialized
INFO - 2016-01-30 21:24:04 --> Model Class Initialized
INFO - 2016-01-30 21:24:04 --> Model Class Initialized
INFO - 2016-01-30 21:24:04 --> Helper loaded: form_helper
INFO - 2016-01-30 21:24:04 --> Form Validation Class Initialized
INFO - 2016-01-30 21:24:04 --> Helper loaded: text_helper
INFO - 2016-01-30 21:24:04 --> Config Class Initialized
INFO - 2016-01-30 21:24:04 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:04 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:04 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:04 --> URI Class Initialized
INFO - 2016-01-30 21:24:04 --> Router Class Initialized
INFO - 2016-01-30 21:24:04 --> Output Class Initialized
INFO - 2016-01-30 21:24:04 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:04 --> Input Class Initialized
INFO - 2016-01-30 21:24:04 --> Language Class Initialized
INFO - 2016-01-30 21:24:04 --> Loader Class Initialized
INFO - 2016-01-30 21:24:04 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:04 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:04 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:04 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:05 --> Controller Class Initialized
INFO - 2016-01-30 21:24:05 --> Model Class Initialized
INFO - 2016-01-30 21:24:05 --> Model Class Initialized
INFO - 2016-01-30 21:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:24:05 --> Pagination Class Initialized
INFO - 2016-01-30 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:24:05 --> Final output sent to browser
DEBUG - 2016-01-30 21:24:05 --> Total execution time: 1.1171
INFO - 2016-01-30 21:24:17 --> Config Class Initialized
INFO - 2016-01-30 21:24:17 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:17 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:17 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:17 --> URI Class Initialized
DEBUG - 2016-01-30 21:24:17 --> No URI present. Default controller set.
INFO - 2016-01-30 21:24:17 --> Router Class Initialized
INFO - 2016-01-30 21:24:17 --> Output Class Initialized
INFO - 2016-01-30 21:24:17 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:17 --> Input Class Initialized
INFO - 2016-01-30 21:24:17 --> Language Class Initialized
INFO - 2016-01-30 21:24:17 --> Loader Class Initialized
INFO - 2016-01-30 21:24:17 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:17 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:17 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:17 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:18 --> Controller Class Initialized
INFO - 2016-01-30 21:24:18 --> Model Class Initialized
INFO - 2016-01-30 21:24:18 --> Model Class Initialized
INFO - 2016-01-30 21:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:24:18 --> Pagination Class Initialized
INFO - 2016-01-30 21:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:24:18 --> Final output sent to browser
DEBUG - 2016-01-30 21:24:18 --> Total execution time: 1.1135
INFO - 2016-01-30 21:24:21 --> Config Class Initialized
INFO - 2016-01-30 21:24:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:21 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:21 --> URI Class Initialized
INFO - 2016-01-30 21:24:21 --> Router Class Initialized
INFO - 2016-01-30 21:24:21 --> Output Class Initialized
INFO - 2016-01-30 21:24:21 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:21 --> Input Class Initialized
INFO - 2016-01-30 21:24:21 --> Language Class Initialized
INFO - 2016-01-30 21:24:21 --> Loader Class Initialized
INFO - 2016-01-30 21:24:21 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:21 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:21 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:21 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:22 --> Controller Class Initialized
INFO - 2016-01-30 21:24:22 --> Model Class Initialized
INFO - 2016-01-30 21:24:22 --> Model Class Initialized
INFO - 2016-01-30 21:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:24:22 --> Pagination Class Initialized
INFO - 2016-01-30 21:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:24:22 --> Helper loaded: text_helper
INFO - 2016-01-30 21:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:24:22 --> Final output sent to browser
DEBUG - 2016-01-30 21:24:22 --> Total execution time: 1.1216
INFO - 2016-01-30 21:24:26 --> Config Class Initialized
INFO - 2016-01-30 21:24:26 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:26 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:26 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:26 --> URI Class Initialized
INFO - 2016-01-30 21:24:26 --> Router Class Initialized
INFO - 2016-01-30 21:24:26 --> Output Class Initialized
INFO - 2016-01-30 21:24:26 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:26 --> Input Class Initialized
INFO - 2016-01-30 21:24:26 --> Language Class Initialized
INFO - 2016-01-30 21:24:26 --> Loader Class Initialized
INFO - 2016-01-30 21:24:26 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:26 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:26 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:26 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:27 --> Controller Class Initialized
INFO - 2016-01-30 21:24:27 --> Model Class Initialized
INFO - 2016-01-30 21:24:27 --> Model Class Initialized
INFO - 2016-01-30 21:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:24:27 --> Pagination Class Initialized
INFO - 2016-01-30 21:24:27 --> Helper loaded: form_helper
INFO - 2016-01-30 21:24:27 --> Form Validation Class Initialized
INFO - 2016-01-30 21:24:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-01-30 21:24:27 --> Model Class Initialized
INFO - 2016-01-30 21:24:27 --> Config Class Initialized
INFO - 2016-01-30 21:24:27 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:24:27 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:24:27 --> Utf8 Class Initialized
INFO - 2016-01-30 21:24:27 --> URI Class Initialized
INFO - 2016-01-30 21:24:27 --> Router Class Initialized
INFO - 2016-01-30 21:24:27 --> Output Class Initialized
INFO - 2016-01-30 21:24:27 --> Security Class Initialized
DEBUG - 2016-01-30 21:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:24:27 --> Input Class Initialized
INFO - 2016-01-30 21:24:27 --> Language Class Initialized
INFO - 2016-01-30 21:24:27 --> Loader Class Initialized
INFO - 2016-01-30 21:24:27 --> Helper loaded: url_helper
INFO - 2016-01-30 21:24:27 --> Helper loaded: file_helper
INFO - 2016-01-30 21:24:27 --> Helper loaded: date_helper
INFO - 2016-01-30 21:24:27 --> Database Driver Class Initialized
INFO - 2016-01-30 21:24:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:24:28 --> Controller Class Initialized
INFO - 2016-01-30 21:24:28 --> Model Class Initialized
INFO - 2016-01-30 21:24:28 --> Model Class Initialized
INFO - 2016-01-30 21:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:24:28 --> Pagination Class Initialized
INFO - 2016-01-30 21:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:24:29 --> Helper loaded: text_helper
INFO - 2016-01-30 21:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:24:29 --> Final output sent to browser
DEBUG - 2016-01-30 21:24:29 --> Total execution time: 1.1720
INFO - 2016-01-30 21:28:25 --> Config Class Initialized
INFO - 2016-01-30 21:28:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:28:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:28:25 --> Utf8 Class Initialized
INFO - 2016-01-30 21:28:25 --> URI Class Initialized
DEBUG - 2016-01-30 21:28:25 --> No URI present. Default controller set.
INFO - 2016-01-30 21:28:25 --> Router Class Initialized
INFO - 2016-01-30 21:28:25 --> Output Class Initialized
INFO - 2016-01-30 21:28:25 --> Security Class Initialized
DEBUG - 2016-01-30 21:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:28:25 --> Input Class Initialized
INFO - 2016-01-30 21:28:25 --> Language Class Initialized
INFO - 2016-01-30 21:28:25 --> Loader Class Initialized
INFO - 2016-01-30 21:28:25 --> Helper loaded: url_helper
INFO - 2016-01-30 21:28:25 --> Helper loaded: file_helper
INFO - 2016-01-30 21:28:25 --> Helper loaded: date_helper
INFO - 2016-01-30 21:28:25 --> Database Driver Class Initialized
INFO - 2016-01-30 21:28:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:28:26 --> Controller Class Initialized
INFO - 2016-01-30 21:28:26 --> Model Class Initialized
INFO - 2016-01-30 21:28:26 --> Model Class Initialized
INFO - 2016-01-30 21:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:28:26 --> Pagination Class Initialized
INFO - 2016-01-30 21:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:28:26 --> Final output sent to browser
DEBUG - 2016-01-30 21:28:26 --> Total execution time: 1.1331
INFO - 2016-01-30 21:28:29 --> Config Class Initialized
INFO - 2016-01-30 21:28:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:28:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:28:29 --> Utf8 Class Initialized
INFO - 2016-01-30 21:28:29 --> URI Class Initialized
INFO - 2016-01-30 21:28:29 --> Router Class Initialized
INFO - 2016-01-30 21:28:29 --> Output Class Initialized
INFO - 2016-01-30 21:28:29 --> Security Class Initialized
DEBUG - 2016-01-30 21:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:28:29 --> Input Class Initialized
INFO - 2016-01-30 21:28:29 --> Language Class Initialized
INFO - 2016-01-30 21:28:29 --> Loader Class Initialized
INFO - 2016-01-30 21:28:29 --> Helper loaded: url_helper
INFO - 2016-01-30 21:28:29 --> Helper loaded: file_helper
INFO - 2016-01-30 21:28:29 --> Helper loaded: date_helper
INFO - 2016-01-30 21:28:29 --> Database Driver Class Initialized
INFO - 2016-01-30 21:28:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:28:30 --> Controller Class Initialized
INFO - 2016-01-30 21:28:30 --> Model Class Initialized
INFO - 2016-01-30 21:28:30 --> Model Class Initialized
INFO - 2016-01-30 21:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:28:30 --> Pagination Class Initialized
INFO - 2016-01-30 21:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:28:30 --> Helper loaded: text_helper
INFO - 2016-01-30 21:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:28:30 --> Final output sent to browser
DEBUG - 2016-01-30 21:28:30 --> Total execution time: 1.1536
INFO - 2016-01-30 21:28:33 --> Config Class Initialized
INFO - 2016-01-30 21:28:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:28:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:28:33 --> Utf8 Class Initialized
INFO - 2016-01-30 21:28:33 --> URI Class Initialized
INFO - 2016-01-30 21:28:33 --> Router Class Initialized
INFO - 2016-01-30 21:28:33 --> Output Class Initialized
INFO - 2016-01-30 21:28:33 --> Security Class Initialized
DEBUG - 2016-01-30 21:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:28:33 --> Input Class Initialized
INFO - 2016-01-30 21:28:33 --> Language Class Initialized
INFO - 2016-01-30 21:28:33 --> Loader Class Initialized
INFO - 2016-01-30 21:28:33 --> Helper loaded: url_helper
INFO - 2016-01-30 21:28:33 --> Helper loaded: file_helper
INFO - 2016-01-30 21:28:33 --> Helper loaded: date_helper
INFO - 2016-01-30 21:28:33 --> Database Driver Class Initialized
INFO - 2016-01-30 21:28:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:28:34 --> Controller Class Initialized
INFO - 2016-01-30 21:28:34 --> Model Class Initialized
INFO - 2016-01-30 21:28:34 --> Model Class Initialized
INFO - 2016-01-30 21:28:34 --> Helper loaded: form_helper
INFO - 2016-01-30 21:28:34 --> Form Validation Class Initialized
INFO - 2016-01-30 21:28:34 --> Helper loaded: text_helper
INFO - 2016-01-30 21:28:34 --> Config Class Initialized
INFO - 2016-01-30 21:28:34 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:28:34 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:28:34 --> Utf8 Class Initialized
INFO - 2016-01-30 21:28:34 --> URI Class Initialized
INFO - 2016-01-30 21:28:34 --> Router Class Initialized
INFO - 2016-01-30 21:28:34 --> Output Class Initialized
INFO - 2016-01-30 21:28:34 --> Security Class Initialized
DEBUG - 2016-01-30 21:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:28:34 --> Input Class Initialized
INFO - 2016-01-30 21:28:34 --> Language Class Initialized
INFO - 2016-01-30 21:28:34 --> Loader Class Initialized
INFO - 2016-01-30 21:28:34 --> Helper loaded: url_helper
INFO - 2016-01-30 21:28:34 --> Helper loaded: file_helper
INFO - 2016-01-30 21:28:34 --> Helper loaded: date_helper
INFO - 2016-01-30 21:28:34 --> Database Driver Class Initialized
INFO - 2016-01-30 21:28:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:28:35 --> Controller Class Initialized
INFO - 2016-01-30 21:28:35 --> Model Class Initialized
INFO - 2016-01-30 21:28:35 --> Model Class Initialized
INFO - 2016-01-30 21:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:28:35 --> Pagination Class Initialized
INFO - 2016-01-30 21:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:28:35 --> Final output sent to browser
DEBUG - 2016-01-30 21:28:35 --> Total execution time: 1.1269
INFO - 2016-01-30 21:28:38 --> Config Class Initialized
INFO - 2016-01-30 21:28:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:28:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:28:38 --> Utf8 Class Initialized
INFO - 2016-01-30 21:28:38 --> URI Class Initialized
INFO - 2016-01-30 21:28:38 --> Router Class Initialized
INFO - 2016-01-30 21:28:38 --> Output Class Initialized
INFO - 2016-01-30 21:28:38 --> Security Class Initialized
DEBUG - 2016-01-30 21:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:28:38 --> Input Class Initialized
INFO - 2016-01-30 21:28:38 --> Language Class Initialized
INFO - 2016-01-30 21:28:38 --> Loader Class Initialized
INFO - 2016-01-30 21:28:38 --> Helper loaded: url_helper
INFO - 2016-01-30 21:28:38 --> Helper loaded: file_helper
INFO - 2016-01-30 21:28:38 --> Helper loaded: date_helper
INFO - 2016-01-30 21:28:38 --> Database Driver Class Initialized
INFO - 2016-01-30 21:28:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:28:39 --> Controller Class Initialized
INFO - 2016-01-30 21:28:39 --> Model Class Initialized
INFO - 2016-01-30 21:28:39 --> Model Class Initialized
INFO - 2016-01-30 21:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:28:39 --> Pagination Class Initialized
INFO - 2016-01-30 21:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:28:39 --> Helper loaded: text_helper
INFO - 2016-01-30 21:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:28:39 --> Final output sent to browser
DEBUG - 2016-01-30 21:28:39 --> Total execution time: 1.1482
INFO - 2016-01-30 21:29:30 --> Config Class Initialized
INFO - 2016-01-30 21:29:30 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:29:30 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:29:30 --> Utf8 Class Initialized
INFO - 2016-01-30 21:29:30 --> URI Class Initialized
DEBUG - 2016-01-30 21:29:30 --> No URI present. Default controller set.
INFO - 2016-01-30 21:29:30 --> Router Class Initialized
INFO - 2016-01-30 21:29:30 --> Output Class Initialized
INFO - 2016-01-30 21:29:30 --> Security Class Initialized
DEBUG - 2016-01-30 21:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:29:30 --> Input Class Initialized
INFO - 2016-01-30 21:29:30 --> Language Class Initialized
INFO - 2016-01-30 21:29:30 --> Loader Class Initialized
INFO - 2016-01-30 21:29:30 --> Helper loaded: url_helper
INFO - 2016-01-30 21:29:30 --> Helper loaded: file_helper
INFO - 2016-01-30 21:29:30 --> Helper loaded: date_helper
INFO - 2016-01-30 21:29:30 --> Database Driver Class Initialized
INFO - 2016-01-30 21:29:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:29:31 --> Controller Class Initialized
INFO - 2016-01-30 21:29:31 --> Model Class Initialized
INFO - 2016-01-30 21:29:31 --> Model Class Initialized
INFO - 2016-01-30 21:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:29:31 --> Pagination Class Initialized
INFO - 2016-01-30 21:29:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:29:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:29:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:29:31 --> Final output sent to browser
DEBUG - 2016-01-30 21:29:31 --> Total execution time: 1.1259
INFO - 2016-01-30 21:29:33 --> Config Class Initialized
INFO - 2016-01-30 21:29:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:29:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:29:33 --> Utf8 Class Initialized
INFO - 2016-01-30 21:29:33 --> URI Class Initialized
INFO - 2016-01-30 21:29:33 --> Router Class Initialized
INFO - 2016-01-30 21:29:33 --> Output Class Initialized
INFO - 2016-01-30 21:29:33 --> Security Class Initialized
DEBUG - 2016-01-30 21:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:29:33 --> Input Class Initialized
INFO - 2016-01-30 21:29:33 --> Language Class Initialized
INFO - 2016-01-30 21:29:33 --> Loader Class Initialized
INFO - 2016-01-30 21:29:33 --> Helper loaded: url_helper
INFO - 2016-01-30 21:29:33 --> Helper loaded: file_helper
INFO - 2016-01-30 21:29:33 --> Helper loaded: date_helper
INFO - 2016-01-30 21:29:33 --> Database Driver Class Initialized
INFO - 2016-01-30 21:29:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:29:34 --> Controller Class Initialized
INFO - 2016-01-30 21:29:34 --> Model Class Initialized
INFO - 2016-01-30 21:29:34 --> Model Class Initialized
INFO - 2016-01-30 21:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:29:34 --> Pagination Class Initialized
INFO - 2016-01-30 21:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:29:34 --> Helper loaded: text_helper
INFO - 2016-01-30 21:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:29:34 --> Final output sent to browser
DEBUG - 2016-01-30 21:29:34 --> Total execution time: 1.1519
INFO - 2016-01-30 21:30:13 --> Config Class Initialized
INFO - 2016-01-30 21:30:13 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:30:13 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:30:13 --> Utf8 Class Initialized
INFO - 2016-01-30 21:30:13 --> URI Class Initialized
INFO - 2016-01-30 21:30:13 --> Router Class Initialized
INFO - 2016-01-30 21:30:13 --> Output Class Initialized
INFO - 2016-01-30 21:30:13 --> Security Class Initialized
DEBUG - 2016-01-30 21:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:30:13 --> Input Class Initialized
INFO - 2016-01-30 21:30:13 --> Language Class Initialized
INFO - 2016-01-30 21:30:13 --> Loader Class Initialized
INFO - 2016-01-30 21:30:13 --> Helper loaded: url_helper
INFO - 2016-01-30 21:30:13 --> Helper loaded: file_helper
INFO - 2016-01-30 21:30:13 --> Helper loaded: date_helper
INFO - 2016-01-30 21:30:13 --> Database Driver Class Initialized
INFO - 2016-01-30 21:30:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:30:14 --> Controller Class Initialized
INFO - 2016-01-30 21:30:14 --> Model Class Initialized
INFO - 2016-01-30 21:30:14 --> Model Class Initialized
INFO - 2016-01-30 21:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:30:14 --> Pagination Class Initialized
INFO - 2016-01-30 21:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:30:14 --> Helper loaded: text_helper
INFO - 2016-01-30 21:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:30:14 --> Final output sent to browser
DEBUG - 2016-01-30 21:30:14 --> Total execution time: 1.2092
INFO - 2016-01-30 21:31:41 --> Config Class Initialized
INFO - 2016-01-30 21:31:41 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:31:41 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:31:41 --> Utf8 Class Initialized
INFO - 2016-01-30 21:31:41 --> URI Class Initialized
INFO - 2016-01-30 21:31:41 --> Router Class Initialized
INFO - 2016-01-30 21:31:41 --> Output Class Initialized
INFO - 2016-01-30 21:31:41 --> Security Class Initialized
DEBUG - 2016-01-30 21:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:31:41 --> Input Class Initialized
INFO - 2016-01-30 21:31:41 --> Language Class Initialized
INFO - 2016-01-30 21:31:41 --> Loader Class Initialized
INFO - 2016-01-30 21:31:41 --> Helper loaded: url_helper
INFO - 2016-01-30 21:31:41 --> Helper loaded: file_helper
INFO - 2016-01-30 21:31:41 --> Helper loaded: date_helper
INFO - 2016-01-30 21:31:41 --> Database Driver Class Initialized
INFO - 2016-01-30 21:31:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:31:42 --> Controller Class Initialized
INFO - 2016-01-30 21:31:42 --> Model Class Initialized
INFO - 2016-01-30 21:31:42 --> Model Class Initialized
INFO - 2016-01-30 21:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:31:42 --> Pagination Class Initialized
INFO - 2016-01-30 21:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:31:42 --> Helper loaded: text_helper
INFO - 2016-01-30 21:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:31:42 --> Final output sent to browser
DEBUG - 2016-01-30 21:31:42 --> Total execution time: 1.2161
INFO - 2016-01-30 21:31:47 --> Config Class Initialized
INFO - 2016-01-30 21:31:47 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:31:47 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:31:47 --> Utf8 Class Initialized
INFO - 2016-01-30 21:31:47 --> URI Class Initialized
DEBUG - 2016-01-30 21:31:47 --> No URI present. Default controller set.
INFO - 2016-01-30 21:31:47 --> Router Class Initialized
INFO - 2016-01-30 21:31:47 --> Output Class Initialized
INFO - 2016-01-30 21:31:47 --> Security Class Initialized
DEBUG - 2016-01-30 21:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:31:47 --> Input Class Initialized
INFO - 2016-01-30 21:31:47 --> Language Class Initialized
INFO - 2016-01-30 21:31:47 --> Loader Class Initialized
INFO - 2016-01-30 21:31:47 --> Helper loaded: url_helper
INFO - 2016-01-30 21:31:47 --> Helper loaded: file_helper
INFO - 2016-01-30 21:31:47 --> Helper loaded: date_helper
INFO - 2016-01-30 21:31:47 --> Database Driver Class Initialized
INFO - 2016-01-30 21:31:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:31:48 --> Controller Class Initialized
INFO - 2016-01-30 21:31:48 --> Model Class Initialized
INFO - 2016-01-30 21:31:48 --> Model Class Initialized
INFO - 2016-01-30 21:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:31:48 --> Pagination Class Initialized
INFO - 2016-01-30 21:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:31:48 --> Final output sent to browser
DEBUG - 2016-01-30 21:31:48 --> Total execution time: 1.1011
INFO - 2016-01-30 21:31:50 --> Config Class Initialized
INFO - 2016-01-30 21:31:50 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:31:50 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:31:50 --> Utf8 Class Initialized
INFO - 2016-01-30 21:31:50 --> URI Class Initialized
INFO - 2016-01-30 21:31:50 --> Router Class Initialized
INFO - 2016-01-30 21:31:50 --> Output Class Initialized
INFO - 2016-01-30 21:31:50 --> Security Class Initialized
DEBUG - 2016-01-30 21:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:31:50 --> Input Class Initialized
INFO - 2016-01-30 21:31:50 --> Language Class Initialized
INFO - 2016-01-30 21:31:50 --> Loader Class Initialized
INFO - 2016-01-30 21:31:50 --> Helper loaded: url_helper
INFO - 2016-01-30 21:31:50 --> Helper loaded: file_helper
INFO - 2016-01-30 21:31:50 --> Helper loaded: date_helper
INFO - 2016-01-30 21:31:50 --> Database Driver Class Initialized
INFO - 2016-01-30 21:31:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:31:51 --> Controller Class Initialized
INFO - 2016-01-30 21:31:51 --> Model Class Initialized
INFO - 2016-01-30 21:31:51 --> Model Class Initialized
INFO - 2016-01-30 21:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:31:51 --> Pagination Class Initialized
INFO - 2016-01-30 21:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:31:51 --> Helper loaded: text_helper
INFO - 2016-01-30 21:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:31:51 --> Final output sent to browser
DEBUG - 2016-01-30 21:31:51 --> Total execution time: 1.1490
INFO - 2016-01-30 21:33:07 --> Config Class Initialized
INFO - 2016-01-30 21:33:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:07 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:07 --> URI Class Initialized
DEBUG - 2016-01-30 21:33:07 --> No URI present. Default controller set.
INFO - 2016-01-30 21:33:07 --> Router Class Initialized
INFO - 2016-01-30 21:33:07 --> Output Class Initialized
INFO - 2016-01-30 21:33:07 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:07 --> Input Class Initialized
INFO - 2016-01-30 21:33:07 --> Language Class Initialized
INFO - 2016-01-30 21:33:07 --> Loader Class Initialized
INFO - 2016-01-30 21:33:07 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:07 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:07 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:07 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:08 --> Controller Class Initialized
INFO - 2016-01-30 21:33:08 --> Model Class Initialized
INFO - 2016-01-30 21:33:08 --> Model Class Initialized
INFO - 2016-01-30 21:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:08 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:08 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:08 --> Total execution time: 1.1090
INFO - 2016-01-30 21:33:12 --> Config Class Initialized
INFO - 2016-01-30 21:33:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:12 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:12 --> URI Class Initialized
INFO - 2016-01-30 21:33:12 --> Router Class Initialized
INFO - 2016-01-30 21:33:12 --> Output Class Initialized
INFO - 2016-01-30 21:33:12 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:12 --> Input Class Initialized
INFO - 2016-01-30 21:33:12 --> Language Class Initialized
INFO - 2016-01-30 21:33:12 --> Loader Class Initialized
INFO - 2016-01-30 21:33:12 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:12 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:12 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:12 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:13 --> Controller Class Initialized
INFO - 2016-01-30 21:33:13 --> Model Class Initialized
INFO - 2016-01-30 21:33:13 --> Model Class Initialized
INFO - 2016-01-30 21:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:13 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:13 --> Helper loaded: text_helper
INFO - 2016-01-30 21:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:13 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:13 --> Total execution time: 1.2723
INFO - 2016-01-30 21:33:16 --> Config Class Initialized
INFO - 2016-01-30 21:33:16 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:16 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:16 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:16 --> URI Class Initialized
DEBUG - 2016-01-30 21:33:16 --> No URI present. Default controller set.
INFO - 2016-01-30 21:33:16 --> Router Class Initialized
INFO - 2016-01-30 21:33:16 --> Output Class Initialized
INFO - 2016-01-30 21:33:16 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:16 --> Input Class Initialized
INFO - 2016-01-30 21:33:16 --> Language Class Initialized
INFO - 2016-01-30 21:33:16 --> Loader Class Initialized
INFO - 2016-01-30 21:33:16 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:16 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:16 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:16 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:17 --> Controller Class Initialized
INFO - 2016-01-30 21:33:17 --> Model Class Initialized
INFO - 2016-01-30 21:33:17 --> Model Class Initialized
INFO - 2016-01-30 21:33:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:17 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:17 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:17 --> Total execution time: 1.0942
INFO - 2016-01-30 21:33:19 --> Config Class Initialized
INFO - 2016-01-30 21:33:19 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:19 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:19 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:19 --> URI Class Initialized
INFO - 2016-01-30 21:33:19 --> Router Class Initialized
INFO - 2016-01-30 21:33:19 --> Output Class Initialized
INFO - 2016-01-30 21:33:19 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:19 --> Input Class Initialized
INFO - 2016-01-30 21:33:19 --> Language Class Initialized
INFO - 2016-01-30 21:33:19 --> Loader Class Initialized
INFO - 2016-01-30 21:33:19 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:19 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:19 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:19 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:20 --> Controller Class Initialized
INFO - 2016-01-30 21:33:20 --> Model Class Initialized
INFO - 2016-01-30 21:33:20 --> Model Class Initialized
INFO - 2016-01-30 21:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:20 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:20 --> Helper loaded: text_helper
INFO - 2016-01-30 21:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:20 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:20 --> Total execution time: 1.1652
INFO - 2016-01-30 21:33:22 --> Config Class Initialized
INFO - 2016-01-30 21:33:22 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:22 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:22 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:22 --> URI Class Initialized
DEBUG - 2016-01-30 21:33:22 --> No URI present. Default controller set.
INFO - 2016-01-30 21:33:22 --> Router Class Initialized
INFO - 2016-01-30 21:33:22 --> Output Class Initialized
INFO - 2016-01-30 21:33:22 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:22 --> Input Class Initialized
INFO - 2016-01-30 21:33:22 --> Language Class Initialized
INFO - 2016-01-30 21:33:22 --> Loader Class Initialized
INFO - 2016-01-30 21:33:22 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:22 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:22 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:23 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:24 --> Controller Class Initialized
INFO - 2016-01-30 21:33:24 --> Model Class Initialized
INFO - 2016-01-30 21:33:24 --> Model Class Initialized
INFO - 2016-01-30 21:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:24 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:24 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:24 --> Total execution time: 1.0821
INFO - 2016-01-30 21:33:25 --> Config Class Initialized
INFO - 2016-01-30 21:33:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:25 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:25 --> URI Class Initialized
INFO - 2016-01-30 21:33:25 --> Router Class Initialized
INFO - 2016-01-30 21:33:25 --> Output Class Initialized
INFO - 2016-01-30 21:33:25 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:25 --> Input Class Initialized
INFO - 2016-01-30 21:33:25 --> Language Class Initialized
INFO - 2016-01-30 21:33:25 --> Loader Class Initialized
INFO - 2016-01-30 21:33:25 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:25 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:25 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:25 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:26 --> Controller Class Initialized
INFO - 2016-01-30 21:33:26 --> Model Class Initialized
INFO - 2016-01-30 21:33:26 --> Model Class Initialized
INFO - 2016-01-30 21:33:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:26 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:26 --> Helper loaded: text_helper
INFO - 2016-01-30 21:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:26 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:26 --> Total execution time: 1.1558
INFO - 2016-01-30 21:33:29 --> Config Class Initialized
INFO - 2016-01-30 21:33:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:29 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:29 --> URI Class Initialized
DEBUG - 2016-01-30 21:33:29 --> No URI present. Default controller set.
INFO - 2016-01-30 21:33:29 --> Router Class Initialized
INFO - 2016-01-30 21:33:29 --> Output Class Initialized
INFO - 2016-01-30 21:33:29 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:29 --> Input Class Initialized
INFO - 2016-01-30 21:33:29 --> Language Class Initialized
INFO - 2016-01-30 21:33:29 --> Loader Class Initialized
INFO - 2016-01-30 21:33:29 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:29 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:29 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:29 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:30 --> Controller Class Initialized
INFO - 2016-01-30 21:33:30 --> Model Class Initialized
INFO - 2016-01-30 21:33:30 --> Model Class Initialized
INFO - 2016-01-30 21:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:30 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:30 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:30 --> Total execution time: 1.0872
INFO - 2016-01-30 21:33:32 --> Config Class Initialized
INFO - 2016-01-30 21:33:32 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:32 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:32 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:32 --> URI Class Initialized
INFO - 2016-01-30 21:33:32 --> Router Class Initialized
INFO - 2016-01-30 21:33:32 --> Output Class Initialized
INFO - 2016-01-30 21:33:32 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:32 --> Input Class Initialized
INFO - 2016-01-30 21:33:32 --> Language Class Initialized
INFO - 2016-01-30 21:33:32 --> Loader Class Initialized
INFO - 2016-01-30 21:33:32 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:32 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:32 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:32 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:33 --> Controller Class Initialized
INFO - 2016-01-30 21:33:33 --> Model Class Initialized
INFO - 2016-01-30 21:33:33 --> Model Class Initialized
INFO - 2016-01-30 21:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:33 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:33 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:33 --> Total execution time: 1.1164
INFO - 2016-01-30 21:33:37 --> Config Class Initialized
INFO - 2016-01-30 21:33:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:37 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:37 --> URI Class Initialized
INFO - 2016-01-30 21:33:37 --> Router Class Initialized
INFO - 2016-01-30 21:33:37 --> Output Class Initialized
INFO - 2016-01-30 21:33:37 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:37 --> Input Class Initialized
INFO - 2016-01-30 21:33:37 --> Language Class Initialized
INFO - 2016-01-30 21:33:37 --> Loader Class Initialized
INFO - 2016-01-30 21:33:37 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:37 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:37 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:37 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:38 --> Controller Class Initialized
INFO - 2016-01-30 21:33:38 --> Model Class Initialized
INFO - 2016-01-30 21:33:38 --> Model Class Initialized
INFO - 2016-01-30 21:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:38 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:38 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:38 --> Total execution time: 1.1192
INFO - 2016-01-30 21:33:41 --> Config Class Initialized
INFO - 2016-01-30 21:33:41 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:41 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:41 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:41 --> URI Class Initialized
INFO - 2016-01-30 21:33:41 --> Router Class Initialized
INFO - 2016-01-30 21:33:41 --> Output Class Initialized
INFO - 2016-01-30 21:33:41 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:41 --> Input Class Initialized
INFO - 2016-01-30 21:33:41 --> Language Class Initialized
INFO - 2016-01-30 21:33:41 --> Loader Class Initialized
INFO - 2016-01-30 21:33:41 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:41 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:41 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:41 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:42 --> Controller Class Initialized
INFO - 2016-01-30 21:33:42 --> Model Class Initialized
INFO - 2016-01-30 21:33:42 --> Model Class Initialized
INFO - 2016-01-30 21:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:42 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:42 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:42 --> Total execution time: 1.1072
INFO - 2016-01-30 21:33:52 --> Config Class Initialized
INFO - 2016-01-30 21:33:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:52 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:52 --> URI Class Initialized
INFO - 2016-01-30 21:33:52 --> Router Class Initialized
INFO - 2016-01-30 21:33:52 --> Output Class Initialized
INFO - 2016-01-30 21:33:52 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:52 --> Input Class Initialized
INFO - 2016-01-30 21:33:52 --> Language Class Initialized
INFO - 2016-01-30 21:33:52 --> Loader Class Initialized
INFO - 2016-01-30 21:33:52 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:52 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:52 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:52 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:53 --> Controller Class Initialized
INFO - 2016-01-30 21:33:53 --> Model Class Initialized
INFO - 2016-01-30 21:33:53 --> Model Class Initialized
INFO - 2016-01-30 21:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:53 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:53 --> Helper loaded: text_helper
INFO - 2016-01-30 21:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:53 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:53 --> Total execution time: 1.2523
INFO - 2016-01-30 21:33:57 --> Config Class Initialized
INFO - 2016-01-30 21:33:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:33:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:33:57 --> Utf8 Class Initialized
INFO - 2016-01-30 21:33:57 --> URI Class Initialized
INFO - 2016-01-30 21:33:57 --> Router Class Initialized
INFO - 2016-01-30 21:33:57 --> Output Class Initialized
INFO - 2016-01-30 21:33:57 --> Security Class Initialized
DEBUG - 2016-01-30 21:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:33:57 --> Input Class Initialized
INFO - 2016-01-30 21:33:57 --> Language Class Initialized
INFO - 2016-01-30 21:33:57 --> Loader Class Initialized
INFO - 2016-01-30 21:33:57 --> Helper loaded: url_helper
INFO - 2016-01-30 21:33:57 --> Helper loaded: file_helper
INFO - 2016-01-30 21:33:57 --> Helper loaded: date_helper
INFO - 2016-01-30 21:33:57 --> Database Driver Class Initialized
INFO - 2016-01-30 21:33:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:33:58 --> Controller Class Initialized
INFO - 2016-01-30 21:33:58 --> Model Class Initialized
INFO - 2016-01-30 21:33:58 --> Model Class Initialized
INFO - 2016-01-30 21:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:33:58 --> Pagination Class Initialized
INFO - 2016-01-30 21:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:33:58 --> Final output sent to browser
DEBUG - 2016-01-30 21:33:58 --> Total execution time: 1.1367
INFO - 2016-01-30 21:35:04 --> Config Class Initialized
INFO - 2016-01-30 21:35:04 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:04 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:04 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:04 --> URI Class Initialized
INFO - 2016-01-30 21:35:04 --> Router Class Initialized
INFO - 2016-01-30 21:35:04 --> Output Class Initialized
INFO - 2016-01-30 21:35:04 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:04 --> Input Class Initialized
INFO - 2016-01-30 21:35:04 --> Language Class Initialized
INFO - 2016-01-30 21:35:04 --> Loader Class Initialized
INFO - 2016-01-30 21:35:04 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:04 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:04 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:04 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:05 --> Controller Class Initialized
INFO - 2016-01-30 21:35:05 --> Model Class Initialized
INFO - 2016-01-30 21:35:05 --> Model Class Initialized
INFO - 2016-01-30 21:35:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:05 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:05 --> Helper loaded: text_helper
INFO - 2016-01-30 21:35:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:35:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:35:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:35:05 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:05 --> Total execution time: 1.1440
INFO - 2016-01-30 21:35:07 --> Config Class Initialized
INFO - 2016-01-30 21:35:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:07 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:07 --> URI Class Initialized
INFO - 2016-01-30 21:35:07 --> Router Class Initialized
INFO - 2016-01-30 21:35:07 --> Output Class Initialized
INFO - 2016-01-30 21:35:08 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:08 --> Input Class Initialized
INFO - 2016-01-30 21:35:08 --> Language Class Initialized
INFO - 2016-01-30 21:35:08 --> Loader Class Initialized
INFO - 2016-01-30 21:35:08 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:08 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:08 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:08 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:09 --> Controller Class Initialized
INFO - 2016-01-30 21:35:09 --> Model Class Initialized
INFO - 2016-01-30 21:35:09 --> Model Class Initialized
INFO - 2016-01-30 21:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:09 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:35:09 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:09 --> Total execution time: 1.1494
INFO - 2016-01-30 21:35:11 --> Config Class Initialized
INFO - 2016-01-30 21:35:11 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:11 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:11 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:11 --> URI Class Initialized
INFO - 2016-01-30 21:35:11 --> Router Class Initialized
INFO - 2016-01-30 21:35:11 --> Output Class Initialized
INFO - 2016-01-30 21:35:11 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:11 --> Input Class Initialized
INFO - 2016-01-30 21:35:11 --> Language Class Initialized
INFO - 2016-01-30 21:35:11 --> Loader Class Initialized
INFO - 2016-01-30 21:35:11 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:11 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:11 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:11 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:12 --> Controller Class Initialized
INFO - 2016-01-30 21:35:12 --> Model Class Initialized
INFO - 2016-01-30 21:35:12 --> Model Class Initialized
INFO - 2016-01-30 21:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:12 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:12 --> Helper loaded: text_helper
INFO - 2016-01-30 21:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:35:12 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:12 --> Total execution time: 1.1384
INFO - 2016-01-30 21:35:24 --> Config Class Initialized
INFO - 2016-01-30 21:35:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:24 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:24 --> URI Class Initialized
INFO - 2016-01-30 21:35:24 --> Router Class Initialized
INFO - 2016-01-30 21:35:24 --> Output Class Initialized
INFO - 2016-01-30 21:35:24 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:24 --> Input Class Initialized
INFO - 2016-01-30 21:35:24 --> Language Class Initialized
INFO - 2016-01-30 21:35:24 --> Loader Class Initialized
INFO - 2016-01-30 21:35:24 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:24 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:24 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:24 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:25 --> Controller Class Initialized
INFO - 2016-01-30 21:35:25 --> Model Class Initialized
INFO - 2016-01-30 21:35:25 --> Model Class Initialized
INFO - 2016-01-30 21:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:25 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:26 --> Config Class Initialized
INFO - 2016-01-30 21:35:26 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:26 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:26 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:26 --> URI Class Initialized
INFO - 2016-01-30 21:35:26 --> Router Class Initialized
INFO - 2016-01-30 21:35:26 --> Output Class Initialized
INFO - 2016-01-30 21:35:26 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:26 --> Input Class Initialized
INFO - 2016-01-30 21:35:26 --> Language Class Initialized
INFO - 2016-01-30 21:35:26 --> Loader Class Initialized
INFO - 2016-01-30 21:35:26 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:26 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:26 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:26 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:27 --> Controller Class Initialized
INFO - 2016-01-30 21:35:27 --> Model Class Initialized
INFO - 2016-01-30 21:35:27 --> Model Class Initialized
INFO - 2016-01-30 21:35:27 --> Helper loaded: form_helper
INFO - 2016-01-30 21:35:27 --> Form Validation Class Initialized
INFO - 2016-01-30 21:35:27 --> Helper loaded: text_helper
INFO - 2016-01-30 21:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 21:35:27 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:27 --> Total execution time: 1.0845
INFO - 2016-01-30 21:35:29 --> Config Class Initialized
INFO - 2016-01-30 21:35:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:29 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:29 --> URI Class Initialized
DEBUG - 2016-01-30 21:35:29 --> No URI present. Default controller set.
INFO - 2016-01-30 21:35:29 --> Router Class Initialized
INFO - 2016-01-30 21:35:29 --> Output Class Initialized
INFO - 2016-01-30 21:35:29 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:29 --> Input Class Initialized
INFO - 2016-01-30 21:35:29 --> Language Class Initialized
INFO - 2016-01-30 21:35:29 --> Loader Class Initialized
INFO - 2016-01-30 21:35:29 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:29 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:29 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:29 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:30 --> Controller Class Initialized
INFO - 2016-01-30 21:35:30 --> Model Class Initialized
INFO - 2016-01-30 21:35:30 --> Model Class Initialized
INFO - 2016-01-30 21:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:30 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:35:30 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:30 --> Total execution time: 1.1312
INFO - 2016-01-30 21:35:38 --> Config Class Initialized
INFO - 2016-01-30 21:35:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:35:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:35:38 --> Utf8 Class Initialized
INFO - 2016-01-30 21:35:38 --> URI Class Initialized
INFO - 2016-01-30 21:35:38 --> Router Class Initialized
INFO - 2016-01-30 21:35:38 --> Output Class Initialized
INFO - 2016-01-30 21:35:38 --> Security Class Initialized
DEBUG - 2016-01-30 21:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:35:38 --> Input Class Initialized
INFO - 2016-01-30 21:35:38 --> Language Class Initialized
INFO - 2016-01-30 21:35:38 --> Loader Class Initialized
INFO - 2016-01-30 21:35:38 --> Helper loaded: url_helper
INFO - 2016-01-30 21:35:38 --> Helper loaded: file_helper
INFO - 2016-01-30 21:35:38 --> Helper loaded: date_helper
INFO - 2016-01-30 21:35:38 --> Database Driver Class Initialized
INFO - 2016-01-30 21:35:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:35:39 --> Controller Class Initialized
INFO - 2016-01-30 21:35:39 --> Model Class Initialized
INFO - 2016-01-30 21:35:39 --> Model Class Initialized
INFO - 2016-01-30 21:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:35:39 --> Pagination Class Initialized
INFO - 2016-01-30 21:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:35:39 --> Helper loaded: text_helper
INFO - 2016-01-30 21:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:35:39 --> Final output sent to browser
DEBUG - 2016-01-30 21:35:39 --> Total execution time: 1.1517
INFO - 2016-01-30 21:36:12 --> Config Class Initialized
INFO - 2016-01-30 21:36:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:12 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:12 --> URI Class Initialized
INFO - 2016-01-30 21:36:12 --> Router Class Initialized
INFO - 2016-01-30 21:36:12 --> Output Class Initialized
INFO - 2016-01-30 21:36:12 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:12 --> Input Class Initialized
INFO - 2016-01-30 21:36:12 --> Language Class Initialized
INFO - 2016-01-30 21:36:12 --> Loader Class Initialized
INFO - 2016-01-30 21:36:12 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:12 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:12 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:12 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:13 --> Controller Class Initialized
INFO - 2016-01-30 21:36:13 --> Model Class Initialized
INFO - 2016-01-30 21:36:13 --> Model Class Initialized
INFO - 2016-01-30 21:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:13 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:13 --> Helper loaded: text_helper
INFO - 2016-01-30 21:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:13 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:13 --> Total execution time: 1.2196
INFO - 2016-01-30 21:36:15 --> Config Class Initialized
INFO - 2016-01-30 21:36:15 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:15 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:15 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:15 --> URI Class Initialized
DEBUG - 2016-01-30 21:36:15 --> No URI present. Default controller set.
INFO - 2016-01-30 21:36:15 --> Router Class Initialized
INFO - 2016-01-30 21:36:15 --> Output Class Initialized
INFO - 2016-01-30 21:36:15 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:15 --> Input Class Initialized
INFO - 2016-01-30 21:36:15 --> Language Class Initialized
INFO - 2016-01-30 21:36:15 --> Loader Class Initialized
INFO - 2016-01-30 21:36:15 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:15 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:15 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:15 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:16 --> Controller Class Initialized
INFO - 2016-01-30 21:36:16 --> Model Class Initialized
INFO - 2016-01-30 21:36:16 --> Model Class Initialized
INFO - 2016-01-30 21:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:16 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:16 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:16 --> Total execution time: 1.1237
INFO - 2016-01-30 21:36:18 --> Config Class Initialized
INFO - 2016-01-30 21:36:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:18 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:18 --> URI Class Initialized
INFO - 2016-01-30 21:36:18 --> Router Class Initialized
INFO - 2016-01-30 21:36:18 --> Output Class Initialized
INFO - 2016-01-30 21:36:18 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:18 --> Input Class Initialized
INFO - 2016-01-30 21:36:18 --> Language Class Initialized
INFO - 2016-01-30 21:36:18 --> Loader Class Initialized
INFO - 2016-01-30 21:36:18 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:18 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:18 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:18 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:19 --> Controller Class Initialized
INFO - 2016-01-30 21:36:19 --> Model Class Initialized
INFO - 2016-01-30 21:36:19 --> Model Class Initialized
INFO - 2016-01-30 21:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:19 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:19 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:19 --> Total execution time: 1.0918
INFO - 2016-01-30 21:36:21 --> Config Class Initialized
INFO - 2016-01-30 21:36:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:21 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:21 --> URI Class Initialized
INFO - 2016-01-30 21:36:21 --> Router Class Initialized
INFO - 2016-01-30 21:36:21 --> Output Class Initialized
INFO - 2016-01-30 21:36:21 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:21 --> Input Class Initialized
INFO - 2016-01-30 21:36:21 --> Language Class Initialized
INFO - 2016-01-30 21:36:21 --> Loader Class Initialized
INFO - 2016-01-30 21:36:21 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:21 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:21 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:21 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:22 --> Controller Class Initialized
INFO - 2016-01-30 21:36:22 --> Model Class Initialized
INFO - 2016-01-30 21:36:22 --> Model Class Initialized
INFO - 2016-01-30 21:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:22 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:22 --> Helper loaded: text_helper
INFO - 2016-01-30 21:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:22 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:22 --> Total execution time: 1.1647
INFO - 2016-01-30 21:36:25 --> Config Class Initialized
INFO - 2016-01-30 21:36:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:25 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:25 --> URI Class Initialized
DEBUG - 2016-01-30 21:36:25 --> No URI present. Default controller set.
INFO - 2016-01-30 21:36:25 --> Router Class Initialized
INFO - 2016-01-30 21:36:25 --> Output Class Initialized
INFO - 2016-01-30 21:36:25 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:25 --> Input Class Initialized
INFO - 2016-01-30 21:36:25 --> Language Class Initialized
INFO - 2016-01-30 21:36:25 --> Loader Class Initialized
INFO - 2016-01-30 21:36:25 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:25 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:25 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:25 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:27 --> Controller Class Initialized
INFO - 2016-01-30 21:36:27 --> Model Class Initialized
INFO - 2016-01-30 21:36:27 --> Model Class Initialized
INFO - 2016-01-30 21:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:27 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:27 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:27 --> Total execution time: 1.1254
INFO - 2016-01-30 21:36:28 --> Config Class Initialized
INFO - 2016-01-30 21:36:28 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:28 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:28 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:28 --> URI Class Initialized
INFO - 2016-01-30 21:36:28 --> Router Class Initialized
INFO - 2016-01-30 21:36:28 --> Output Class Initialized
INFO - 2016-01-30 21:36:28 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:28 --> Input Class Initialized
INFO - 2016-01-30 21:36:28 --> Language Class Initialized
INFO - 2016-01-30 21:36:28 --> Loader Class Initialized
INFO - 2016-01-30 21:36:28 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:28 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:28 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:28 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:29 --> Controller Class Initialized
INFO - 2016-01-30 21:36:29 --> Model Class Initialized
INFO - 2016-01-30 21:36:29 --> Model Class Initialized
INFO - 2016-01-30 21:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:29 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:29 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:29 --> Total execution time: 1.0881
INFO - 2016-01-30 21:36:31 --> Config Class Initialized
INFO - 2016-01-30 21:36:31 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:31 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:31 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:31 --> URI Class Initialized
INFO - 2016-01-30 21:36:31 --> Router Class Initialized
INFO - 2016-01-30 21:36:31 --> Output Class Initialized
INFO - 2016-01-30 21:36:31 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:31 --> Input Class Initialized
INFO - 2016-01-30 21:36:31 --> Language Class Initialized
INFO - 2016-01-30 21:36:31 --> Loader Class Initialized
INFO - 2016-01-30 21:36:31 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:31 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:31 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:31 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:32 --> Controller Class Initialized
INFO - 2016-01-30 21:36:32 --> Model Class Initialized
INFO - 2016-01-30 21:36:32 --> Model Class Initialized
INFO - 2016-01-30 21:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:32 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:32 --> Helper loaded: text_helper
INFO - 2016-01-30 21:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:32 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:32 --> Total execution time: 1.1195
INFO - 2016-01-30 21:36:35 --> Config Class Initialized
INFO - 2016-01-30 21:36:35 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:35 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:35 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:35 --> URI Class Initialized
INFO - 2016-01-30 21:36:35 --> Router Class Initialized
INFO - 2016-01-30 21:36:35 --> Output Class Initialized
INFO - 2016-01-30 21:36:35 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:35 --> Input Class Initialized
INFO - 2016-01-30 21:36:35 --> Language Class Initialized
INFO - 2016-01-30 21:36:35 --> Loader Class Initialized
INFO - 2016-01-30 21:36:35 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:35 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:35 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:35 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:36 --> Controller Class Initialized
INFO - 2016-01-30 21:36:36 --> Model Class Initialized
INFO - 2016-01-30 21:36:36 --> Model Class Initialized
INFO - 2016-01-30 21:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:36 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:36 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:36 --> Total execution time: 1.1193
INFO - 2016-01-30 21:36:38 --> Config Class Initialized
INFO - 2016-01-30 21:36:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:36:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:36:38 --> Utf8 Class Initialized
INFO - 2016-01-30 21:36:38 --> URI Class Initialized
INFO - 2016-01-30 21:36:38 --> Router Class Initialized
INFO - 2016-01-30 21:36:38 --> Output Class Initialized
INFO - 2016-01-30 21:36:38 --> Security Class Initialized
DEBUG - 2016-01-30 21:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:36:38 --> Input Class Initialized
INFO - 2016-01-30 21:36:38 --> Language Class Initialized
INFO - 2016-01-30 21:36:38 --> Loader Class Initialized
INFO - 2016-01-30 21:36:38 --> Helper loaded: url_helper
INFO - 2016-01-30 21:36:38 --> Helper loaded: file_helper
INFO - 2016-01-30 21:36:38 --> Helper loaded: date_helper
INFO - 2016-01-30 21:36:38 --> Database Driver Class Initialized
INFO - 2016-01-30 21:36:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:36:39 --> Controller Class Initialized
INFO - 2016-01-30 21:36:39 --> Model Class Initialized
INFO - 2016-01-30 21:36:39 --> Model Class Initialized
INFO - 2016-01-30 21:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:36:39 --> Pagination Class Initialized
INFO - 2016-01-30 21:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:36:39 --> Helper loaded: text_helper
INFO - 2016-01-30 21:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:36:39 --> Final output sent to browser
DEBUG - 2016-01-30 21:36:39 --> Total execution time: 1.2331
INFO - 2016-01-30 21:38:03 --> Config Class Initialized
INFO - 2016-01-30 21:38:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:38:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:38:03 --> Utf8 Class Initialized
INFO - 2016-01-30 21:38:03 --> URI Class Initialized
DEBUG - 2016-01-30 21:38:03 --> No URI present. Default controller set.
INFO - 2016-01-30 21:38:03 --> Router Class Initialized
INFO - 2016-01-30 21:38:03 --> Output Class Initialized
INFO - 2016-01-30 21:38:03 --> Security Class Initialized
DEBUG - 2016-01-30 21:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:38:03 --> Input Class Initialized
INFO - 2016-01-30 21:38:03 --> Language Class Initialized
INFO - 2016-01-30 21:38:03 --> Loader Class Initialized
INFO - 2016-01-30 21:38:03 --> Helper loaded: url_helper
INFO - 2016-01-30 21:38:03 --> Helper loaded: file_helper
INFO - 2016-01-30 21:38:03 --> Helper loaded: date_helper
INFO - 2016-01-30 21:38:03 --> Database Driver Class Initialized
INFO - 2016-01-30 21:38:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:38:04 --> Controller Class Initialized
INFO - 2016-01-30 21:38:04 --> Model Class Initialized
INFO - 2016-01-30 21:38:04 --> Model Class Initialized
INFO - 2016-01-30 21:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:38:04 --> Pagination Class Initialized
INFO - 2016-01-30 21:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:38:04 --> Final output sent to browser
DEBUG - 2016-01-30 21:38:04 --> Total execution time: 1.1249
INFO - 2016-01-30 21:38:09 --> Config Class Initialized
INFO - 2016-01-30 21:38:09 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:38:09 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:38:09 --> Utf8 Class Initialized
INFO - 2016-01-30 21:38:09 --> URI Class Initialized
INFO - 2016-01-30 21:38:09 --> Router Class Initialized
INFO - 2016-01-30 21:38:09 --> Output Class Initialized
INFO - 2016-01-30 21:38:09 --> Security Class Initialized
DEBUG - 2016-01-30 21:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:38:09 --> Input Class Initialized
INFO - 2016-01-30 21:38:09 --> Language Class Initialized
INFO - 2016-01-30 21:38:09 --> Loader Class Initialized
INFO - 2016-01-30 21:38:09 --> Helper loaded: url_helper
INFO - 2016-01-30 21:38:09 --> Helper loaded: file_helper
INFO - 2016-01-30 21:38:09 --> Helper loaded: date_helper
INFO - 2016-01-30 21:38:09 --> Database Driver Class Initialized
INFO - 2016-01-30 21:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:38:10 --> Controller Class Initialized
INFO - 2016-01-30 21:38:10 --> Model Class Initialized
INFO - 2016-01-30 21:38:10 --> Model Class Initialized
INFO - 2016-01-30 21:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:38:10 --> Pagination Class Initialized
INFO - 2016-01-30 21:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:38:10 --> Helper loaded: text_helper
INFO - 2016-01-30 21:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:38:10 --> Final output sent to browser
DEBUG - 2016-01-30 21:38:10 --> Total execution time: 1.2734
INFO - 2016-01-30 21:38:12 --> Config Class Initialized
INFO - 2016-01-30 21:38:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:38:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:38:12 --> Utf8 Class Initialized
INFO - 2016-01-30 21:38:12 --> URI Class Initialized
INFO - 2016-01-30 21:38:12 --> Router Class Initialized
INFO - 2016-01-30 21:38:12 --> Output Class Initialized
INFO - 2016-01-30 21:38:12 --> Security Class Initialized
DEBUG - 2016-01-30 21:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:38:12 --> Input Class Initialized
INFO - 2016-01-30 21:38:12 --> Language Class Initialized
INFO - 2016-01-30 21:38:12 --> Loader Class Initialized
INFO - 2016-01-30 21:38:12 --> Helper loaded: url_helper
INFO - 2016-01-30 21:38:12 --> Helper loaded: file_helper
INFO - 2016-01-30 21:38:12 --> Helper loaded: date_helper
INFO - 2016-01-30 21:38:12 --> Database Driver Class Initialized
INFO - 2016-01-30 21:38:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:38:13 --> Controller Class Initialized
INFO - 2016-01-30 21:38:13 --> Model Class Initialized
INFO - 2016-01-30 21:38:13 --> Model Class Initialized
INFO - 2016-01-30 21:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:38:13 --> Pagination Class Initialized
INFO - 2016-01-30 21:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:38:13 --> Final output sent to browser
DEBUG - 2016-01-30 21:38:13 --> Total execution time: 1.1334
INFO - 2016-01-30 21:38:16 --> Config Class Initialized
INFO - 2016-01-30 21:38:16 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:38:16 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:38:16 --> Utf8 Class Initialized
INFO - 2016-01-30 21:38:16 --> URI Class Initialized
DEBUG - 2016-01-30 21:38:16 --> No URI present. Default controller set.
INFO - 2016-01-30 21:38:16 --> Router Class Initialized
INFO - 2016-01-30 21:38:16 --> Output Class Initialized
INFO - 2016-01-30 21:38:16 --> Security Class Initialized
DEBUG - 2016-01-30 21:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:38:16 --> Input Class Initialized
INFO - 2016-01-30 21:38:16 --> Language Class Initialized
INFO - 2016-01-30 21:38:16 --> Loader Class Initialized
INFO - 2016-01-30 21:38:16 --> Helper loaded: url_helper
INFO - 2016-01-30 21:38:16 --> Helper loaded: file_helper
INFO - 2016-01-30 21:38:16 --> Helper loaded: date_helper
INFO - 2016-01-30 21:38:16 --> Database Driver Class Initialized
INFO - 2016-01-30 21:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:38:17 --> Controller Class Initialized
INFO - 2016-01-30 21:38:17 --> Model Class Initialized
INFO - 2016-01-30 21:38:17 --> Model Class Initialized
INFO - 2016-01-30 21:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:38:17 --> Pagination Class Initialized
INFO - 2016-01-30 21:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:38:17 --> Final output sent to browser
DEBUG - 2016-01-30 21:38:17 --> Total execution time: 1.1103
INFO - 2016-01-30 21:40:21 --> Config Class Initialized
INFO - 2016-01-30 21:40:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:40:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:40:21 --> Utf8 Class Initialized
INFO - 2016-01-30 21:40:21 --> URI Class Initialized
INFO - 2016-01-30 21:40:21 --> Router Class Initialized
INFO - 2016-01-30 21:40:21 --> Output Class Initialized
INFO - 2016-01-30 21:40:21 --> Security Class Initialized
DEBUG - 2016-01-30 21:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:40:21 --> Input Class Initialized
INFO - 2016-01-30 21:40:21 --> Language Class Initialized
INFO - 2016-01-30 21:40:21 --> Loader Class Initialized
INFO - 2016-01-30 21:40:21 --> Helper loaded: url_helper
INFO - 2016-01-30 21:40:21 --> Helper loaded: file_helper
INFO - 2016-01-30 21:40:21 --> Helper loaded: date_helper
INFO - 2016-01-30 21:40:21 --> Database Driver Class Initialized
INFO - 2016-01-30 21:40:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:40:22 --> Controller Class Initialized
INFO - 2016-01-30 21:40:22 --> Model Class Initialized
INFO - 2016-01-30 21:40:22 --> Model Class Initialized
INFO - 2016-01-30 21:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:40:22 --> Pagination Class Initialized
INFO - 2016-01-30 21:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:40:22 --> Helper loaded: text_helper
INFO - 2016-01-30 21:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:40:22 --> Final output sent to browser
DEBUG - 2016-01-30 21:40:22 --> Total execution time: 1.2698
INFO - 2016-01-30 21:40:24 --> Config Class Initialized
INFO - 2016-01-30 21:40:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:40:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:40:24 --> Utf8 Class Initialized
INFO - 2016-01-30 21:40:24 --> URI Class Initialized
INFO - 2016-01-30 21:40:24 --> Router Class Initialized
INFO - 2016-01-30 21:40:24 --> Output Class Initialized
INFO - 2016-01-30 21:40:24 --> Security Class Initialized
DEBUG - 2016-01-30 21:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:40:24 --> Input Class Initialized
INFO - 2016-01-30 21:40:24 --> Language Class Initialized
INFO - 2016-01-30 21:40:24 --> Loader Class Initialized
INFO - 2016-01-30 21:40:24 --> Helper loaded: url_helper
INFO - 2016-01-30 21:40:24 --> Helper loaded: file_helper
INFO - 2016-01-30 21:40:24 --> Helper loaded: date_helper
INFO - 2016-01-30 21:40:24 --> Database Driver Class Initialized
INFO - 2016-01-30 21:40:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:40:25 --> Controller Class Initialized
INFO - 2016-01-30 21:40:25 --> Model Class Initialized
INFO - 2016-01-30 21:40:25 --> Model Class Initialized
INFO - 2016-01-30 21:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:40:26 --> Pagination Class Initialized
INFO - 2016-01-30 21:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:40:26 --> Final output sent to browser
DEBUG - 2016-01-30 21:40:26 --> Total execution time: 1.1030
INFO - 2016-01-30 21:40:44 --> Config Class Initialized
INFO - 2016-01-30 21:40:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:40:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:40:44 --> Utf8 Class Initialized
INFO - 2016-01-30 21:40:44 --> URI Class Initialized
DEBUG - 2016-01-30 21:40:44 --> No URI present. Default controller set.
INFO - 2016-01-30 21:40:44 --> Router Class Initialized
INFO - 2016-01-30 21:40:44 --> Output Class Initialized
INFO - 2016-01-30 21:40:44 --> Security Class Initialized
DEBUG - 2016-01-30 21:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:40:44 --> Input Class Initialized
INFO - 2016-01-30 21:40:44 --> Language Class Initialized
INFO - 2016-01-30 21:40:44 --> Loader Class Initialized
INFO - 2016-01-30 21:40:44 --> Helper loaded: url_helper
INFO - 2016-01-30 21:40:44 --> Helper loaded: file_helper
INFO - 2016-01-30 21:40:44 --> Helper loaded: date_helper
INFO - 2016-01-30 21:40:44 --> Database Driver Class Initialized
INFO - 2016-01-30 21:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:40:45 --> Controller Class Initialized
INFO - 2016-01-30 21:40:45 --> Model Class Initialized
INFO - 2016-01-30 21:40:45 --> Model Class Initialized
INFO - 2016-01-30 21:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:40:45 --> Pagination Class Initialized
INFO - 2016-01-30 21:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:40:45 --> Final output sent to browser
DEBUG - 2016-01-30 21:40:45 --> Total execution time: 1.1488
INFO - 2016-01-30 21:45:25 --> Config Class Initialized
INFO - 2016-01-30 21:45:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:45:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:45:25 --> Utf8 Class Initialized
INFO - 2016-01-30 21:45:25 --> URI Class Initialized
INFO - 2016-01-30 21:45:25 --> Router Class Initialized
INFO - 2016-01-30 21:45:25 --> Output Class Initialized
INFO - 2016-01-30 21:45:25 --> Security Class Initialized
DEBUG - 2016-01-30 21:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:45:25 --> Input Class Initialized
INFO - 2016-01-30 21:45:25 --> Language Class Initialized
INFO - 2016-01-30 21:45:25 --> Loader Class Initialized
INFO - 2016-01-30 21:45:25 --> Helper loaded: url_helper
INFO - 2016-01-30 21:45:25 --> Helper loaded: file_helper
INFO - 2016-01-30 21:45:25 --> Helper loaded: date_helper
INFO - 2016-01-30 21:45:25 --> Database Driver Class Initialized
INFO - 2016-01-30 21:45:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:45:26 --> Controller Class Initialized
INFO - 2016-01-30 21:45:26 --> Model Class Initialized
INFO - 2016-01-30 21:45:26 --> Model Class Initialized
INFO - 2016-01-30 21:45:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:45:26 --> Pagination Class Initialized
INFO - 2016-01-30 21:45:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:45:26 --> Helper loaded: text_helper
INFO - 2016-01-30 21:45:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:45:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:45:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:45:26 --> Final output sent to browser
DEBUG - 2016-01-30 21:45:26 --> Total execution time: 1.1991
INFO - 2016-01-30 21:45:28 --> Config Class Initialized
INFO - 2016-01-30 21:45:28 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:45:28 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:45:28 --> Utf8 Class Initialized
INFO - 2016-01-30 21:45:28 --> URI Class Initialized
INFO - 2016-01-30 21:45:28 --> Router Class Initialized
INFO - 2016-01-30 21:45:28 --> Output Class Initialized
INFO - 2016-01-30 21:45:28 --> Security Class Initialized
DEBUG - 2016-01-30 21:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:45:28 --> Input Class Initialized
INFO - 2016-01-30 21:45:28 --> Language Class Initialized
INFO - 2016-01-30 21:45:28 --> Loader Class Initialized
INFO - 2016-01-30 21:45:28 --> Helper loaded: url_helper
INFO - 2016-01-30 21:45:28 --> Helper loaded: file_helper
INFO - 2016-01-30 21:45:28 --> Helper loaded: date_helper
INFO - 2016-01-30 21:45:28 --> Database Driver Class Initialized
INFO - 2016-01-30 21:45:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:45:29 --> Controller Class Initialized
INFO - 2016-01-30 21:45:29 --> Model Class Initialized
INFO - 2016-01-30 21:45:29 --> Model Class Initialized
INFO - 2016-01-30 21:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:45:29 --> Pagination Class Initialized
INFO - 2016-01-30 21:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:45:29 --> Final output sent to browser
DEBUG - 2016-01-30 21:45:29 --> Total execution time: 1.1397
INFO - 2016-01-30 21:45:48 --> Config Class Initialized
INFO - 2016-01-30 21:45:48 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:45:48 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:45:48 --> Utf8 Class Initialized
INFO - 2016-01-30 21:45:48 --> URI Class Initialized
DEBUG - 2016-01-30 21:45:48 --> No URI present. Default controller set.
INFO - 2016-01-30 21:45:48 --> Router Class Initialized
INFO - 2016-01-30 21:45:48 --> Output Class Initialized
INFO - 2016-01-30 21:45:48 --> Security Class Initialized
DEBUG - 2016-01-30 21:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:45:48 --> Input Class Initialized
INFO - 2016-01-30 21:45:48 --> Language Class Initialized
INFO - 2016-01-30 21:45:48 --> Loader Class Initialized
INFO - 2016-01-30 21:45:48 --> Helper loaded: url_helper
INFO - 2016-01-30 21:45:48 --> Helper loaded: file_helper
INFO - 2016-01-30 21:45:48 --> Helper loaded: date_helper
INFO - 2016-01-30 21:45:48 --> Database Driver Class Initialized
INFO - 2016-01-30 21:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:45:49 --> Controller Class Initialized
INFO - 2016-01-30 21:45:49 --> Model Class Initialized
INFO - 2016-01-30 21:45:49 --> Model Class Initialized
INFO - 2016-01-30 21:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:45:49 --> Pagination Class Initialized
INFO - 2016-01-30 21:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:45:49 --> Final output sent to browser
DEBUG - 2016-01-30 21:45:49 --> Total execution time: 1.1351
INFO - 2016-01-30 21:45:51 --> Config Class Initialized
INFO - 2016-01-30 21:45:51 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:45:51 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:45:51 --> Utf8 Class Initialized
INFO - 2016-01-30 21:45:51 --> URI Class Initialized
INFO - 2016-01-30 21:45:51 --> Router Class Initialized
INFO - 2016-01-30 21:45:51 --> Output Class Initialized
INFO - 2016-01-30 21:45:51 --> Security Class Initialized
DEBUG - 2016-01-30 21:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:45:51 --> Input Class Initialized
INFO - 2016-01-30 21:45:51 --> Language Class Initialized
INFO - 2016-01-30 21:45:51 --> Loader Class Initialized
INFO - 2016-01-30 21:45:51 --> Helper loaded: url_helper
INFO - 2016-01-30 21:45:51 --> Helper loaded: file_helper
INFO - 2016-01-30 21:45:51 --> Helper loaded: date_helper
INFO - 2016-01-30 21:45:51 --> Database Driver Class Initialized
INFO - 2016-01-30 21:45:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:45:52 --> Controller Class Initialized
INFO - 2016-01-30 21:45:52 --> Model Class Initialized
INFO - 2016-01-30 21:45:52 --> Model Class Initialized
INFO - 2016-01-30 21:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:45:52 --> Pagination Class Initialized
INFO - 2016-01-30 21:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:45:52 --> Helper loaded: text_helper
INFO - 2016-01-30 21:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:45:52 --> Final output sent to browser
DEBUG - 2016-01-30 21:45:52 --> Total execution time: 1.1720
INFO - 2016-01-30 21:45:53 --> Config Class Initialized
INFO - 2016-01-30 21:45:53 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:45:53 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:45:53 --> Utf8 Class Initialized
INFO - 2016-01-30 21:45:53 --> URI Class Initialized
INFO - 2016-01-30 21:45:53 --> Router Class Initialized
INFO - 2016-01-30 21:45:53 --> Output Class Initialized
INFO - 2016-01-30 21:45:53 --> Security Class Initialized
DEBUG - 2016-01-30 21:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:45:53 --> Input Class Initialized
INFO - 2016-01-30 21:45:53 --> Language Class Initialized
INFO - 2016-01-30 21:45:53 --> Loader Class Initialized
INFO - 2016-01-30 21:45:53 --> Helper loaded: url_helper
INFO - 2016-01-30 21:45:53 --> Helper loaded: file_helper
INFO - 2016-01-30 21:45:53 --> Helper loaded: date_helper
INFO - 2016-01-30 21:45:53 --> Database Driver Class Initialized
INFO - 2016-01-30 21:45:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:45:54 --> Controller Class Initialized
INFO - 2016-01-30 21:45:54 --> Model Class Initialized
INFO - 2016-01-30 21:45:54 --> Model Class Initialized
INFO - 2016-01-30 21:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:45:54 --> Pagination Class Initialized
INFO - 2016-01-30 21:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:45:54 --> Final output sent to browser
DEBUG - 2016-01-30 21:45:54 --> Total execution time: 1.1100
INFO - 2016-01-30 21:57:20 --> Config Class Initialized
INFO - 2016-01-30 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:57:20 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:57:20 --> Utf8 Class Initialized
INFO - 2016-01-30 21:57:20 --> URI Class Initialized
DEBUG - 2016-01-30 21:57:20 --> No URI present. Default controller set.
INFO - 2016-01-30 21:57:20 --> Router Class Initialized
INFO - 2016-01-30 21:57:20 --> Output Class Initialized
INFO - 2016-01-30 21:57:20 --> Security Class Initialized
DEBUG - 2016-01-30 21:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:57:20 --> Input Class Initialized
INFO - 2016-01-30 21:57:20 --> Language Class Initialized
INFO - 2016-01-30 21:57:20 --> Loader Class Initialized
INFO - 2016-01-30 21:57:20 --> Helper loaded: url_helper
INFO - 2016-01-30 21:57:20 --> Helper loaded: file_helper
INFO - 2016-01-30 21:57:20 --> Helper loaded: date_helper
INFO - 2016-01-30 21:57:20 --> Database Driver Class Initialized
INFO - 2016-01-30 21:57:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:57:21 --> Controller Class Initialized
INFO - 2016-01-30 21:57:21 --> Model Class Initialized
INFO - 2016-01-30 21:57:21 --> Model Class Initialized
INFO - 2016-01-30 21:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:57:21 --> Pagination Class Initialized
INFO - 2016-01-30 21:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 21:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:57:21 --> Final output sent to browser
DEBUG - 2016-01-30 21:57:21 --> Total execution time: 1.1405
INFO - 2016-01-30 21:57:24 --> Config Class Initialized
INFO - 2016-01-30 21:57:24 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:57:24 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:57:24 --> Utf8 Class Initialized
INFO - 2016-01-30 21:57:24 --> URI Class Initialized
INFO - 2016-01-30 21:57:24 --> Router Class Initialized
INFO - 2016-01-30 21:57:24 --> Output Class Initialized
INFO - 2016-01-30 21:57:24 --> Security Class Initialized
DEBUG - 2016-01-30 21:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:57:24 --> Input Class Initialized
INFO - 2016-01-30 21:57:24 --> Language Class Initialized
INFO - 2016-01-30 21:57:24 --> Loader Class Initialized
INFO - 2016-01-30 21:57:24 --> Helper loaded: url_helper
INFO - 2016-01-30 21:57:24 --> Helper loaded: file_helper
INFO - 2016-01-30 21:57:24 --> Helper loaded: date_helper
INFO - 2016-01-30 21:57:24 --> Database Driver Class Initialized
INFO - 2016-01-30 21:57:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:57:25 --> Controller Class Initialized
INFO - 2016-01-30 21:57:25 --> Model Class Initialized
INFO - 2016-01-30 21:57:25 --> Model Class Initialized
INFO - 2016-01-30 21:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:57:25 --> Pagination Class Initialized
INFO - 2016-01-30 21:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:57:25 --> Helper loaded: text_helper
INFO - 2016-01-30 21:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:57:25 --> Final output sent to browser
DEBUG - 2016-01-30 21:57:25 --> Total execution time: 1.1639
INFO - 2016-01-30 21:57:29 --> Config Class Initialized
INFO - 2016-01-30 21:57:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:57:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:57:29 --> Utf8 Class Initialized
INFO - 2016-01-30 21:57:29 --> URI Class Initialized
INFO - 2016-01-30 21:57:29 --> Router Class Initialized
INFO - 2016-01-30 21:57:29 --> Output Class Initialized
INFO - 2016-01-30 21:57:29 --> Security Class Initialized
DEBUG - 2016-01-30 21:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:57:29 --> Input Class Initialized
INFO - 2016-01-30 21:57:29 --> Language Class Initialized
INFO - 2016-01-30 21:57:29 --> Loader Class Initialized
INFO - 2016-01-30 21:57:29 --> Helper loaded: url_helper
INFO - 2016-01-30 21:57:29 --> Helper loaded: file_helper
INFO - 2016-01-30 21:57:29 --> Helper loaded: date_helper
INFO - 2016-01-30 21:57:29 --> Database Driver Class Initialized
INFO - 2016-01-30 21:57:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:57:30 --> Controller Class Initialized
INFO - 2016-01-30 21:57:30 --> Model Class Initialized
INFO - 2016-01-30 21:57:30 --> Model Class Initialized
INFO - 2016-01-30 21:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:57:30 --> Pagination Class Initialized
ERROR - 2016-01-30 21:57:30 --> Severity: Notice --> Undefined variable: load C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 200
ERROR - 2016-01-30 21:57:30 --> Severity: Error --> Cannot access empty property C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 200
INFO - 2016-01-30 21:58:09 --> Config Class Initialized
INFO - 2016-01-30 21:58:09 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:58:09 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:58:09 --> Utf8 Class Initialized
INFO - 2016-01-30 21:58:09 --> URI Class Initialized
INFO - 2016-01-30 21:58:09 --> Router Class Initialized
INFO - 2016-01-30 21:58:09 --> Output Class Initialized
INFO - 2016-01-30 21:58:09 --> Security Class Initialized
DEBUG - 2016-01-30 21:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:58:09 --> Input Class Initialized
INFO - 2016-01-30 21:58:09 --> Language Class Initialized
INFO - 2016-01-30 21:58:09 --> Loader Class Initialized
INFO - 2016-01-30 21:58:09 --> Helper loaded: url_helper
INFO - 2016-01-30 21:58:09 --> Helper loaded: file_helper
INFO - 2016-01-30 21:58:09 --> Helper loaded: date_helper
INFO - 2016-01-30 21:58:09 --> Database Driver Class Initialized
INFO - 2016-01-30 21:58:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:58:10 --> Controller Class Initialized
INFO - 2016-01-30 21:58:10 --> Model Class Initialized
INFO - 2016-01-30 21:58:10 --> Model Class Initialized
INFO - 2016-01-30 21:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:58:10 --> Pagination Class Initialized
INFO - 2016-01-30 21:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:58:10 --> Helper loaded: text_helper
INFO - 2016-01-30 21:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:58:10 --> Final output sent to browser
DEBUG - 2016-01-30 21:58:10 --> Total execution time: 1.1707
INFO - 2016-01-30 21:58:12 --> Config Class Initialized
INFO - 2016-01-30 21:58:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:58:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:58:12 --> Utf8 Class Initialized
INFO - 2016-01-30 21:58:12 --> URI Class Initialized
INFO - 2016-01-30 21:58:12 --> Router Class Initialized
INFO - 2016-01-30 21:58:12 --> Output Class Initialized
INFO - 2016-01-30 21:58:12 --> Security Class Initialized
DEBUG - 2016-01-30 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:58:12 --> Input Class Initialized
INFO - 2016-01-30 21:58:12 --> Language Class Initialized
INFO - 2016-01-30 21:58:12 --> Loader Class Initialized
INFO - 2016-01-30 21:58:12 --> Helper loaded: url_helper
INFO - 2016-01-30 21:58:12 --> Helper loaded: file_helper
INFO - 2016-01-30 21:58:12 --> Helper loaded: date_helper
INFO - 2016-01-30 21:58:12 --> Database Driver Class Initialized
INFO - 2016-01-30 21:58:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:58:13 --> Controller Class Initialized
INFO - 2016-01-30 21:58:13 --> Model Class Initialized
INFO - 2016-01-30 21:58:13 --> Model Class Initialized
INFO - 2016-01-30 21:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:58:13 --> Pagination Class Initialized
INFO - 2016-01-30 21:58:13 --> Helper loaded: text_helper
INFO - 2016-01-30 21:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:58:13 --> Final output sent to browser
DEBUG - 2016-01-30 21:58:13 --> Total execution time: 1.1287
INFO - 2016-01-30 21:58:49 --> Config Class Initialized
INFO - 2016-01-30 21:58:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:58:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:58:49 --> Utf8 Class Initialized
INFO - 2016-01-30 21:58:49 --> URI Class Initialized
INFO - 2016-01-30 21:58:49 --> Router Class Initialized
INFO - 2016-01-30 21:58:49 --> Output Class Initialized
INFO - 2016-01-30 21:58:49 --> Security Class Initialized
DEBUG - 2016-01-30 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:58:49 --> Input Class Initialized
INFO - 2016-01-30 21:58:49 --> Language Class Initialized
INFO - 2016-01-30 21:58:49 --> Loader Class Initialized
INFO - 2016-01-30 21:58:49 --> Helper loaded: url_helper
INFO - 2016-01-30 21:58:49 --> Helper loaded: file_helper
INFO - 2016-01-30 21:58:49 --> Helper loaded: date_helper
INFO - 2016-01-30 21:58:49 --> Database Driver Class Initialized
INFO - 2016-01-30 21:58:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:58:50 --> Controller Class Initialized
INFO - 2016-01-30 21:58:50 --> Model Class Initialized
INFO - 2016-01-30 21:58:50 --> Model Class Initialized
INFO - 2016-01-30 21:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:58:50 --> Pagination Class Initialized
INFO - 2016-01-30 21:58:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:58:50 --> Helper loaded: text_helper
INFO - 2016-01-30 21:58:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 21:58:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:58:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:58:50 --> Final output sent to browser
DEBUG - 2016-01-30 21:58:50 --> Total execution time: 1.1467
INFO - 2016-01-30 21:58:52 --> Config Class Initialized
INFO - 2016-01-30 21:58:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 21:58:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 21:58:52 --> Utf8 Class Initialized
INFO - 2016-01-30 21:58:52 --> URI Class Initialized
INFO - 2016-01-30 21:58:52 --> Router Class Initialized
INFO - 2016-01-30 21:58:52 --> Output Class Initialized
INFO - 2016-01-30 21:58:52 --> Security Class Initialized
DEBUG - 2016-01-30 21:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 21:58:52 --> Input Class Initialized
INFO - 2016-01-30 21:58:52 --> Language Class Initialized
INFO - 2016-01-30 21:58:52 --> Loader Class Initialized
INFO - 2016-01-30 21:58:52 --> Helper loaded: url_helper
INFO - 2016-01-30 21:58:52 --> Helper loaded: file_helper
INFO - 2016-01-30 21:58:52 --> Helper loaded: date_helper
INFO - 2016-01-30 21:58:52 --> Database Driver Class Initialized
INFO - 2016-01-30 21:58:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 21:58:53 --> Controller Class Initialized
INFO - 2016-01-30 21:58:53 --> Model Class Initialized
INFO - 2016-01-30 21:58:53 --> Model Class Initialized
INFO - 2016-01-30 21:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 21:58:53 --> Pagination Class Initialized
INFO - 2016-01-30 21:58:53 --> Helper loaded: text_helper
INFO - 2016-01-30 21:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 21:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 21:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 21:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 21:58:53 --> Final output sent to browser
DEBUG - 2016-01-30 21:58:53 --> Total execution time: 1.1237
INFO - 2016-01-30 22:04:07 --> Config Class Initialized
INFO - 2016-01-30 22:04:07 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:04:07 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:04:07 --> Utf8 Class Initialized
INFO - 2016-01-30 22:04:07 --> URI Class Initialized
DEBUG - 2016-01-30 22:04:07 --> No URI present. Default controller set.
INFO - 2016-01-30 22:04:07 --> Router Class Initialized
INFO - 2016-01-30 22:04:07 --> Output Class Initialized
INFO - 2016-01-30 22:04:07 --> Security Class Initialized
DEBUG - 2016-01-30 22:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:04:07 --> Input Class Initialized
INFO - 2016-01-30 22:04:07 --> Language Class Initialized
INFO - 2016-01-30 22:04:07 --> Loader Class Initialized
INFO - 2016-01-30 22:04:07 --> Helper loaded: url_helper
INFO - 2016-01-30 22:04:07 --> Helper loaded: file_helper
INFO - 2016-01-30 22:04:07 --> Helper loaded: date_helper
INFO - 2016-01-30 22:04:07 --> Database Driver Class Initialized
INFO - 2016-01-30 22:04:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:04:08 --> Controller Class Initialized
INFO - 2016-01-30 22:04:08 --> Model Class Initialized
INFO - 2016-01-30 22:04:08 --> Model Class Initialized
INFO - 2016-01-30 22:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:04:08 --> Pagination Class Initialized
INFO - 2016-01-30 22:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:04:08 --> Final output sent to browser
DEBUG - 2016-01-30 22:04:08 --> Total execution time: 1.1034
INFO - 2016-01-30 22:04:10 --> Config Class Initialized
INFO - 2016-01-30 22:04:10 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:04:10 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:04:10 --> Utf8 Class Initialized
INFO - 2016-01-30 22:04:10 --> URI Class Initialized
INFO - 2016-01-30 22:04:10 --> Router Class Initialized
INFO - 2016-01-30 22:04:10 --> Output Class Initialized
INFO - 2016-01-30 22:04:10 --> Security Class Initialized
DEBUG - 2016-01-30 22:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:04:10 --> Input Class Initialized
INFO - 2016-01-30 22:04:10 --> Language Class Initialized
INFO - 2016-01-30 22:04:10 --> Loader Class Initialized
INFO - 2016-01-30 22:04:10 --> Helper loaded: url_helper
INFO - 2016-01-30 22:04:10 --> Helper loaded: file_helper
INFO - 2016-01-30 22:04:10 --> Helper loaded: date_helper
INFO - 2016-01-30 22:04:10 --> Database Driver Class Initialized
INFO - 2016-01-30 22:04:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:04:11 --> Controller Class Initialized
INFO - 2016-01-30 22:04:11 --> Model Class Initialized
INFO - 2016-01-30 22:04:11 --> Model Class Initialized
INFO - 2016-01-30 22:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:04:11 --> Pagination Class Initialized
INFO - 2016-01-30 22:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:04:11 --> Helper loaded: text_helper
INFO - 2016-01-30 22:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:04:11 --> Final output sent to browser
DEBUG - 2016-01-30 22:04:11 --> Total execution time: 1.1557
INFO - 2016-01-30 22:04:13 --> Config Class Initialized
INFO - 2016-01-30 22:04:13 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:04:13 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:04:13 --> Utf8 Class Initialized
INFO - 2016-01-30 22:04:13 --> URI Class Initialized
INFO - 2016-01-30 22:04:13 --> Router Class Initialized
INFO - 2016-01-30 22:04:13 --> Output Class Initialized
INFO - 2016-01-30 22:04:13 --> Security Class Initialized
DEBUG - 2016-01-30 22:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:04:13 --> Input Class Initialized
INFO - 2016-01-30 22:04:13 --> Language Class Initialized
INFO - 2016-01-30 22:04:13 --> Loader Class Initialized
INFO - 2016-01-30 22:04:13 --> Helper loaded: url_helper
INFO - 2016-01-30 22:04:13 --> Helper loaded: file_helper
INFO - 2016-01-30 22:04:13 --> Helper loaded: date_helper
INFO - 2016-01-30 22:04:13 --> Database Driver Class Initialized
INFO - 2016-01-30 22:04:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:04:14 --> Controller Class Initialized
INFO - 2016-01-30 22:04:14 --> Model Class Initialized
INFO - 2016-01-30 22:04:14 --> Model Class Initialized
INFO - 2016-01-30 22:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:04:14 --> Pagination Class Initialized
INFO - 2016-01-30 22:04:14 --> Helper loaded: text_helper
INFO - 2016-01-30 22:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 22:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:04:14 --> Final output sent to browser
DEBUG - 2016-01-30 22:04:14 --> Total execution time: 1.1457
INFO - 2016-01-30 22:06:23 --> Config Class Initialized
INFO - 2016-01-30 22:06:23 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:23 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:23 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:23 --> URI Class Initialized
DEBUG - 2016-01-30 22:06:23 --> No URI present. Default controller set.
INFO - 2016-01-30 22:06:23 --> Router Class Initialized
INFO - 2016-01-30 22:06:23 --> Output Class Initialized
INFO - 2016-01-30 22:06:23 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:23 --> Input Class Initialized
INFO - 2016-01-30 22:06:23 --> Language Class Initialized
INFO - 2016-01-30 22:06:23 --> Loader Class Initialized
INFO - 2016-01-30 22:06:23 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:23 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:23 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:23 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:24 --> Controller Class Initialized
INFO - 2016-01-30 22:06:24 --> Model Class Initialized
INFO - 2016-01-30 22:06:24 --> Model Class Initialized
INFO - 2016-01-30 22:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:24 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:24 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:24 --> Total execution time: 1.1154
INFO - 2016-01-30 22:06:26 --> Config Class Initialized
INFO - 2016-01-30 22:06:26 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:26 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:26 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:26 --> URI Class Initialized
INFO - 2016-01-30 22:06:26 --> Router Class Initialized
INFO - 2016-01-30 22:06:26 --> Output Class Initialized
INFO - 2016-01-30 22:06:26 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:26 --> Input Class Initialized
INFO - 2016-01-30 22:06:26 --> Language Class Initialized
INFO - 2016-01-30 22:06:26 --> Loader Class Initialized
INFO - 2016-01-30 22:06:26 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:26 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:26 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:26 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:27 --> Controller Class Initialized
INFO - 2016-01-30 22:06:27 --> Model Class Initialized
INFO - 2016-01-30 22:06:27 --> Model Class Initialized
INFO - 2016-01-30 22:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:27 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:28 --> Helper loaded: text_helper
INFO - 2016-01-30 22:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:28 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:28 --> Total execution time: 1.1956
INFO - 2016-01-30 22:06:29 --> Config Class Initialized
INFO - 2016-01-30 22:06:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:29 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:29 --> URI Class Initialized
INFO - 2016-01-30 22:06:29 --> Router Class Initialized
INFO - 2016-01-30 22:06:29 --> Output Class Initialized
INFO - 2016-01-30 22:06:29 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:29 --> Input Class Initialized
INFO - 2016-01-30 22:06:29 --> Language Class Initialized
INFO - 2016-01-30 22:06:29 --> Loader Class Initialized
INFO - 2016-01-30 22:06:29 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:29 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:29 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:29 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:30 --> Controller Class Initialized
INFO - 2016-01-30 22:06:30 --> Model Class Initialized
INFO - 2016-01-30 22:06:30 --> Model Class Initialized
INFO - 2016-01-30 22:06:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:30 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:30 --> Helper loaded: text_helper
INFO - 2016-01-30 22:06:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 22:06:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:06:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:30 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:30 --> Total execution time: 1.0895
INFO - 2016-01-30 22:06:39 --> Config Class Initialized
INFO - 2016-01-30 22:06:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:39 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:39 --> URI Class Initialized
DEBUG - 2016-01-30 22:06:39 --> No URI present. Default controller set.
INFO - 2016-01-30 22:06:39 --> Router Class Initialized
INFO - 2016-01-30 22:06:39 --> Output Class Initialized
INFO - 2016-01-30 22:06:39 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:39 --> Input Class Initialized
INFO - 2016-01-30 22:06:39 --> Language Class Initialized
INFO - 2016-01-30 22:06:39 --> Loader Class Initialized
INFO - 2016-01-30 22:06:39 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:39 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:39 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:39 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:40 --> Controller Class Initialized
INFO - 2016-01-30 22:06:40 --> Model Class Initialized
INFO - 2016-01-30 22:06:40 --> Model Class Initialized
INFO - 2016-01-30 22:06:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:40 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:06:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:40 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:40 --> Total execution time: 1.1324
INFO - 2016-01-30 22:06:42 --> Config Class Initialized
INFO - 2016-01-30 22:06:42 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:42 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:42 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:42 --> URI Class Initialized
INFO - 2016-01-30 22:06:42 --> Router Class Initialized
INFO - 2016-01-30 22:06:42 --> Output Class Initialized
INFO - 2016-01-30 22:06:42 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:42 --> Input Class Initialized
INFO - 2016-01-30 22:06:42 --> Language Class Initialized
INFO - 2016-01-30 22:06:42 --> Loader Class Initialized
INFO - 2016-01-30 22:06:42 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:42 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:42 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:42 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:43 --> Controller Class Initialized
INFO - 2016-01-30 22:06:43 --> Model Class Initialized
INFO - 2016-01-30 22:06:43 --> Model Class Initialized
INFO - 2016-01-30 22:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:44 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:44 --> Helper loaded: text_helper
INFO - 2016-01-30 22:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:44 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:44 --> Total execution time: 1.1634
INFO - 2016-01-30 22:06:45 --> Config Class Initialized
INFO - 2016-01-30 22:06:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:45 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:45 --> URI Class Initialized
INFO - 2016-01-30 22:06:45 --> Router Class Initialized
INFO - 2016-01-30 22:06:45 --> Output Class Initialized
INFO - 2016-01-30 22:06:45 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:45 --> Input Class Initialized
INFO - 2016-01-30 22:06:45 --> Language Class Initialized
INFO - 2016-01-30 22:06:45 --> Loader Class Initialized
INFO - 2016-01-30 22:06:45 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:45 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:45 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:45 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:46 --> Controller Class Initialized
INFO - 2016-01-30 22:06:46 --> Model Class Initialized
INFO - 2016-01-30 22:06:46 --> Model Class Initialized
INFO - 2016-01-30 22:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:46 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:46 --> Helper loaded: text_helper
INFO - 2016-01-30 22:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-30 22:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:46 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:46 --> Total execution time: 1.0871
INFO - 2016-01-30 22:06:49 --> Config Class Initialized
INFO - 2016-01-30 22:06:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:06:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:06:49 --> Utf8 Class Initialized
INFO - 2016-01-30 22:06:49 --> URI Class Initialized
DEBUG - 2016-01-30 22:06:49 --> No URI present. Default controller set.
INFO - 2016-01-30 22:06:49 --> Router Class Initialized
INFO - 2016-01-30 22:06:49 --> Output Class Initialized
INFO - 2016-01-30 22:06:49 --> Security Class Initialized
DEBUG - 2016-01-30 22:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:06:49 --> Input Class Initialized
INFO - 2016-01-30 22:06:49 --> Language Class Initialized
INFO - 2016-01-30 22:06:49 --> Loader Class Initialized
INFO - 2016-01-30 22:06:49 --> Helper loaded: url_helper
INFO - 2016-01-30 22:06:49 --> Helper loaded: file_helper
INFO - 2016-01-30 22:06:49 --> Helper loaded: date_helper
INFO - 2016-01-30 22:06:49 --> Database Driver Class Initialized
INFO - 2016-01-30 22:06:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:06:50 --> Controller Class Initialized
INFO - 2016-01-30 22:06:50 --> Model Class Initialized
INFO - 2016-01-30 22:06:50 --> Model Class Initialized
INFO - 2016-01-30 22:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:06:50 --> Pagination Class Initialized
INFO - 2016-01-30 22:06:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:06:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:06:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:06:50 --> Final output sent to browser
DEBUG - 2016-01-30 22:06:50 --> Total execution time: 1.0991
INFO - 2016-01-30 22:07:05 --> Config Class Initialized
INFO - 2016-01-30 22:07:05 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:07:05 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:07:05 --> Utf8 Class Initialized
INFO - 2016-01-30 22:07:05 --> URI Class Initialized
INFO - 2016-01-30 22:07:05 --> Router Class Initialized
INFO - 2016-01-30 22:07:05 --> Output Class Initialized
INFO - 2016-01-30 22:07:05 --> Security Class Initialized
DEBUG - 2016-01-30 22:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:07:05 --> Input Class Initialized
INFO - 2016-01-30 22:07:05 --> Language Class Initialized
INFO - 2016-01-30 22:07:05 --> Loader Class Initialized
INFO - 2016-01-30 22:07:05 --> Helper loaded: url_helper
INFO - 2016-01-30 22:07:05 --> Helper loaded: file_helper
INFO - 2016-01-30 22:07:05 --> Helper loaded: date_helper
INFO - 2016-01-30 22:07:05 --> Database Driver Class Initialized
INFO - 2016-01-30 22:07:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:07:06 --> Controller Class Initialized
INFO - 2016-01-30 22:07:06 --> Model Class Initialized
INFO - 2016-01-30 22:07:06 --> Model Class Initialized
INFO - 2016-01-30 22:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:07:06 --> Pagination Class Initialized
INFO - 2016-01-30 22:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:07:06 --> Final output sent to browser
DEBUG - 2016-01-30 22:07:06 --> Total execution time: 1.1218
INFO - 2016-01-30 22:07:08 --> Config Class Initialized
INFO - 2016-01-30 22:07:08 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:07:08 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:07:08 --> Utf8 Class Initialized
INFO - 2016-01-30 22:07:08 --> URI Class Initialized
INFO - 2016-01-30 22:07:08 --> Router Class Initialized
INFO - 2016-01-30 22:07:08 --> Output Class Initialized
INFO - 2016-01-30 22:07:08 --> Security Class Initialized
DEBUG - 2016-01-30 22:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:07:08 --> Input Class Initialized
INFO - 2016-01-30 22:07:08 --> Language Class Initialized
INFO - 2016-01-30 22:07:08 --> Loader Class Initialized
INFO - 2016-01-30 22:07:08 --> Helper loaded: url_helper
INFO - 2016-01-30 22:07:08 --> Helper loaded: file_helper
INFO - 2016-01-30 22:07:08 --> Helper loaded: date_helper
INFO - 2016-01-30 22:07:08 --> Database Driver Class Initialized
INFO - 2016-01-30 22:07:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:07:09 --> Controller Class Initialized
INFO - 2016-01-30 22:07:09 --> Model Class Initialized
INFO - 2016-01-30 22:07:09 --> Model Class Initialized
INFO - 2016-01-30 22:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:07:09 --> Pagination Class Initialized
INFO - 2016-01-30 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:07:09 --> Helper loaded: text_helper
INFO - 2016-01-30 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:07:09 --> Final output sent to browser
DEBUG - 2016-01-30 22:07:09 --> Total execution time: 1.2352
INFO - 2016-01-30 22:07:12 --> Config Class Initialized
INFO - 2016-01-30 22:07:12 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:07:12 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:07:12 --> Utf8 Class Initialized
INFO - 2016-01-30 22:07:12 --> URI Class Initialized
DEBUG - 2016-01-30 22:07:12 --> No URI present. Default controller set.
INFO - 2016-01-30 22:07:12 --> Router Class Initialized
INFO - 2016-01-30 22:07:13 --> Output Class Initialized
INFO - 2016-01-30 22:07:13 --> Security Class Initialized
DEBUG - 2016-01-30 22:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:07:13 --> Input Class Initialized
INFO - 2016-01-30 22:07:13 --> Language Class Initialized
INFO - 2016-01-30 22:07:13 --> Loader Class Initialized
INFO - 2016-01-30 22:07:13 --> Helper loaded: url_helper
INFO - 2016-01-30 22:07:13 --> Helper loaded: file_helper
INFO - 2016-01-30 22:07:13 --> Helper loaded: date_helper
INFO - 2016-01-30 22:07:13 --> Database Driver Class Initialized
INFO - 2016-01-30 22:07:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:07:14 --> Controller Class Initialized
INFO - 2016-01-30 22:07:14 --> Model Class Initialized
INFO - 2016-01-30 22:07:14 --> Model Class Initialized
INFO - 2016-01-30 22:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:07:14 --> Pagination Class Initialized
INFO - 2016-01-30 22:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:07:14 --> Final output sent to browser
DEBUG - 2016-01-30 22:07:14 --> Total execution time: 1.0767
INFO - 2016-01-30 22:08:35 --> Config Class Initialized
INFO - 2016-01-30 22:08:35 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:08:35 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:08:35 --> Utf8 Class Initialized
INFO - 2016-01-30 22:08:35 --> URI Class Initialized
INFO - 2016-01-30 22:08:35 --> Router Class Initialized
INFO - 2016-01-30 22:08:35 --> Output Class Initialized
INFO - 2016-01-30 22:08:35 --> Security Class Initialized
DEBUG - 2016-01-30 22:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:08:35 --> Input Class Initialized
INFO - 2016-01-30 22:08:35 --> Language Class Initialized
INFO - 2016-01-30 22:08:35 --> Loader Class Initialized
INFO - 2016-01-30 22:08:35 --> Helper loaded: url_helper
INFO - 2016-01-30 22:08:35 --> Helper loaded: file_helper
INFO - 2016-01-30 22:08:35 --> Helper loaded: date_helper
INFO - 2016-01-30 22:08:35 --> Database Driver Class Initialized
INFO - 2016-01-30 22:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:08:36 --> Controller Class Initialized
INFO - 2016-01-30 22:08:36 --> Model Class Initialized
INFO - 2016-01-30 22:08:36 --> Model Class Initialized
INFO - 2016-01-30 22:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:08:36 --> Pagination Class Initialized
INFO - 2016-01-30 22:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:08:36 --> Final output sent to browser
DEBUG - 2016-01-30 22:08:36 --> Total execution time: 1.1424
INFO - 2016-01-30 22:08:37 --> Config Class Initialized
INFO - 2016-01-30 22:08:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:08:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:08:37 --> Utf8 Class Initialized
INFO - 2016-01-30 22:08:37 --> URI Class Initialized
INFO - 2016-01-30 22:08:37 --> Router Class Initialized
INFO - 2016-01-30 22:08:37 --> Output Class Initialized
INFO - 2016-01-30 22:08:37 --> Security Class Initialized
DEBUG - 2016-01-30 22:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:08:37 --> Input Class Initialized
INFO - 2016-01-30 22:08:37 --> Language Class Initialized
INFO - 2016-01-30 22:08:37 --> Loader Class Initialized
INFO - 2016-01-30 22:08:37 --> Helper loaded: url_helper
INFO - 2016-01-30 22:08:37 --> Helper loaded: file_helper
INFO - 2016-01-30 22:08:37 --> Helper loaded: date_helper
INFO - 2016-01-30 22:08:37 --> Database Driver Class Initialized
INFO - 2016-01-30 22:08:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:08:38 --> Controller Class Initialized
INFO - 2016-01-30 22:08:38 --> Model Class Initialized
INFO - 2016-01-30 22:08:38 --> Model Class Initialized
INFO - 2016-01-30 22:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:08:38 --> Pagination Class Initialized
INFO - 2016-01-30 22:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:08:38 --> Helper loaded: text_helper
INFO - 2016-01-30 22:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:08:38 --> Final output sent to browser
DEBUG - 2016-01-30 22:08:38 --> Total execution time: 1.1337
INFO - 2016-01-30 22:09:10 --> Config Class Initialized
INFO - 2016-01-30 22:09:10 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:10 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:10 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:10 --> URI Class Initialized
DEBUG - 2016-01-30 22:09:10 --> No URI present. Default controller set.
INFO - 2016-01-30 22:09:10 --> Router Class Initialized
INFO - 2016-01-30 22:09:10 --> Output Class Initialized
INFO - 2016-01-30 22:09:10 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:10 --> Input Class Initialized
INFO - 2016-01-30 22:09:10 --> Language Class Initialized
INFO - 2016-01-30 22:09:10 --> Loader Class Initialized
INFO - 2016-01-30 22:09:10 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:10 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:10 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:10 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:11 --> Controller Class Initialized
INFO - 2016-01-30 22:09:11 --> Model Class Initialized
INFO - 2016-01-30 22:09:11 --> Model Class Initialized
INFO - 2016-01-30 22:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:11 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:11 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:11 --> Total execution time: 1.1000
INFO - 2016-01-30 22:09:18 --> Config Class Initialized
INFO - 2016-01-30 22:09:18 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:18 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:18 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:18 --> URI Class Initialized
DEBUG - 2016-01-30 22:09:18 --> No URI present. Default controller set.
INFO - 2016-01-30 22:09:18 --> Router Class Initialized
INFO - 2016-01-30 22:09:18 --> Output Class Initialized
INFO - 2016-01-30 22:09:18 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:18 --> Input Class Initialized
INFO - 2016-01-30 22:09:18 --> Language Class Initialized
INFO - 2016-01-30 22:09:18 --> Loader Class Initialized
INFO - 2016-01-30 22:09:18 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:18 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:18 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:18 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:19 --> Controller Class Initialized
INFO - 2016-01-30 22:09:19 --> Model Class Initialized
INFO - 2016-01-30 22:09:19 --> Model Class Initialized
INFO - 2016-01-30 22:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:19 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:19 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:19 --> Total execution time: 1.1086
INFO - 2016-01-30 22:09:21 --> Config Class Initialized
INFO - 2016-01-30 22:09:21 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:21 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:21 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:21 --> URI Class Initialized
INFO - 2016-01-30 22:09:21 --> Router Class Initialized
INFO - 2016-01-30 22:09:21 --> Output Class Initialized
INFO - 2016-01-30 22:09:21 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:21 --> Input Class Initialized
INFO - 2016-01-30 22:09:21 --> Language Class Initialized
INFO - 2016-01-30 22:09:21 --> Loader Class Initialized
INFO - 2016-01-30 22:09:21 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:21 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:21 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:21 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:22 --> Controller Class Initialized
INFO - 2016-01-30 22:09:22 --> Model Class Initialized
INFO - 2016-01-30 22:09:22 --> Model Class Initialized
INFO - 2016-01-30 22:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:22 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:22 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:22 --> Total execution time: 1.1258
INFO - 2016-01-30 22:09:23 --> Config Class Initialized
INFO - 2016-01-30 22:09:23 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:23 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:23 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:23 --> URI Class Initialized
INFO - 2016-01-30 22:09:23 --> Router Class Initialized
INFO - 2016-01-30 22:09:23 --> Output Class Initialized
INFO - 2016-01-30 22:09:23 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:23 --> Input Class Initialized
INFO - 2016-01-30 22:09:23 --> Language Class Initialized
INFO - 2016-01-30 22:09:23 --> Loader Class Initialized
INFO - 2016-01-30 22:09:23 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:23 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:23 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:23 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:24 --> Controller Class Initialized
INFO - 2016-01-30 22:09:24 --> Model Class Initialized
INFO - 2016-01-30 22:09:24 --> Model Class Initialized
INFO - 2016-01-30 22:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:24 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:24 --> Helper loaded: text_helper
INFO - 2016-01-30 22:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:24 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:24 --> Total execution time: 1.1394
INFO - 2016-01-30 22:09:41 --> Config Class Initialized
INFO - 2016-01-30 22:09:41 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:41 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:41 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:41 --> URI Class Initialized
DEBUG - 2016-01-30 22:09:41 --> No URI present. Default controller set.
INFO - 2016-01-30 22:09:41 --> Router Class Initialized
INFO - 2016-01-30 22:09:41 --> Output Class Initialized
INFO - 2016-01-30 22:09:41 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:41 --> Input Class Initialized
INFO - 2016-01-30 22:09:41 --> Language Class Initialized
INFO - 2016-01-30 22:09:41 --> Loader Class Initialized
INFO - 2016-01-30 22:09:42 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:42 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:42 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:42 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:43 --> Controller Class Initialized
INFO - 2016-01-30 22:09:43 --> Model Class Initialized
INFO - 2016-01-30 22:09:43 --> Model Class Initialized
INFO - 2016-01-30 22:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:43 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:43 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:43 --> Total execution time: 1.0993
INFO - 2016-01-30 22:09:43 --> Config Class Initialized
INFO - 2016-01-30 22:09:43 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:43 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:43 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:43 --> URI Class Initialized
DEBUG - 2016-01-30 22:09:43 --> No URI present. Default controller set.
INFO - 2016-01-30 22:09:43 --> Router Class Initialized
INFO - 2016-01-30 22:09:43 --> Output Class Initialized
INFO - 2016-01-30 22:09:43 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:43 --> Input Class Initialized
INFO - 2016-01-30 22:09:43 --> Language Class Initialized
INFO - 2016-01-30 22:09:43 --> Loader Class Initialized
INFO - 2016-01-30 22:09:43 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:43 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:43 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:43 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:44 --> Controller Class Initialized
INFO - 2016-01-30 22:09:44 --> Model Class Initialized
INFO - 2016-01-30 22:09:44 --> Model Class Initialized
INFO - 2016-01-30 22:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:44 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:44 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:44 --> Total execution time: 1.1270
INFO - 2016-01-30 22:09:44 --> Config Class Initialized
INFO - 2016-01-30 22:09:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:44 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:44 --> URI Class Initialized
INFO - 2016-01-30 22:09:44 --> Router Class Initialized
INFO - 2016-01-30 22:09:44 --> Output Class Initialized
INFO - 2016-01-30 22:09:44 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:44 --> Input Class Initialized
INFO - 2016-01-30 22:09:44 --> Language Class Initialized
INFO - 2016-01-30 22:09:44 --> Loader Class Initialized
INFO - 2016-01-30 22:09:44 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:44 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:44 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:44 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:45 --> Controller Class Initialized
INFO - 2016-01-30 22:09:45 --> Model Class Initialized
INFO - 2016-01-30 22:09:45 --> Model Class Initialized
INFO - 2016-01-30 22:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:45 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:45 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:45 --> Total execution time: 1.1356
INFO - 2016-01-30 22:09:47 --> Config Class Initialized
INFO - 2016-01-30 22:09:47 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:09:47 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:09:47 --> Utf8 Class Initialized
INFO - 2016-01-30 22:09:47 --> URI Class Initialized
INFO - 2016-01-30 22:09:47 --> Router Class Initialized
INFO - 2016-01-30 22:09:47 --> Output Class Initialized
INFO - 2016-01-30 22:09:47 --> Security Class Initialized
DEBUG - 2016-01-30 22:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:09:47 --> Input Class Initialized
INFO - 2016-01-30 22:09:47 --> Language Class Initialized
INFO - 2016-01-30 22:09:47 --> Loader Class Initialized
INFO - 2016-01-30 22:09:47 --> Helper loaded: url_helper
INFO - 2016-01-30 22:09:47 --> Helper loaded: file_helper
INFO - 2016-01-30 22:09:47 --> Helper loaded: date_helper
INFO - 2016-01-30 22:09:47 --> Database Driver Class Initialized
INFO - 2016-01-30 22:09:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:09:48 --> Controller Class Initialized
INFO - 2016-01-30 22:09:48 --> Model Class Initialized
INFO - 2016-01-30 22:09:48 --> Model Class Initialized
INFO - 2016-01-30 22:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:09:48 --> Pagination Class Initialized
INFO - 2016-01-30 22:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:09:48 --> Helper loaded: text_helper
INFO - 2016-01-30 22:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:09:48 --> Final output sent to browser
DEBUG - 2016-01-30 22:09:48 --> Total execution time: 1.1661
INFO - 2016-01-30 22:10:29 --> Config Class Initialized
INFO - 2016-01-30 22:10:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:10:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:10:29 --> Utf8 Class Initialized
INFO - 2016-01-30 22:10:29 --> URI Class Initialized
INFO - 2016-01-30 22:10:29 --> Router Class Initialized
INFO - 2016-01-30 22:10:29 --> Output Class Initialized
INFO - 2016-01-30 22:10:29 --> Security Class Initialized
DEBUG - 2016-01-30 22:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:10:29 --> Input Class Initialized
INFO - 2016-01-30 22:10:29 --> Language Class Initialized
INFO - 2016-01-30 22:10:29 --> Loader Class Initialized
INFO - 2016-01-30 22:10:29 --> Helper loaded: url_helper
INFO - 2016-01-30 22:10:29 --> Helper loaded: file_helper
INFO - 2016-01-30 22:10:29 --> Helper loaded: date_helper
INFO - 2016-01-30 22:10:29 --> Database Driver Class Initialized
INFO - 2016-01-30 22:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:10:30 --> Controller Class Initialized
INFO - 2016-01-30 22:10:30 --> Model Class Initialized
INFO - 2016-01-30 22:10:30 --> Model Class Initialized
INFO - 2016-01-30 22:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:10:30 --> Pagination Class Initialized
INFO - 2016-01-30 22:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:10:30 --> Helper loaded: text_helper
INFO - 2016-01-30 22:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:10:30 --> Final output sent to browser
DEBUG - 2016-01-30 22:10:30 --> Total execution time: 1.2357
INFO - 2016-01-30 22:10:54 --> Config Class Initialized
INFO - 2016-01-30 22:10:54 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:10:54 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:10:54 --> Utf8 Class Initialized
INFO - 2016-01-30 22:10:54 --> URI Class Initialized
DEBUG - 2016-01-30 22:10:54 --> No URI present. Default controller set.
INFO - 2016-01-30 22:10:54 --> Router Class Initialized
INFO - 2016-01-30 22:10:54 --> Output Class Initialized
INFO - 2016-01-30 22:10:54 --> Security Class Initialized
DEBUG - 2016-01-30 22:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:10:54 --> Input Class Initialized
INFO - 2016-01-30 22:10:54 --> Language Class Initialized
INFO - 2016-01-30 22:10:54 --> Loader Class Initialized
INFO - 2016-01-30 22:10:54 --> Helper loaded: url_helper
INFO - 2016-01-30 22:10:54 --> Helper loaded: file_helper
INFO - 2016-01-30 22:10:54 --> Helper loaded: date_helper
INFO - 2016-01-30 22:10:54 --> Database Driver Class Initialized
INFO - 2016-01-30 22:10:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:10:55 --> Controller Class Initialized
INFO - 2016-01-30 22:10:55 --> Model Class Initialized
INFO - 2016-01-30 22:10:55 --> Model Class Initialized
INFO - 2016-01-30 22:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:10:55 --> Pagination Class Initialized
INFO - 2016-01-30 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:10:55 --> Final output sent to browser
DEBUG - 2016-01-30 22:10:55 --> Total execution time: 1.1131
INFO - 2016-01-30 22:10:57 --> Config Class Initialized
INFO - 2016-01-30 22:10:57 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:10:57 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:10:57 --> Utf8 Class Initialized
INFO - 2016-01-30 22:10:57 --> URI Class Initialized
INFO - 2016-01-30 22:10:57 --> Router Class Initialized
INFO - 2016-01-30 22:10:57 --> Output Class Initialized
INFO - 2016-01-30 22:10:57 --> Security Class Initialized
DEBUG - 2016-01-30 22:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:10:57 --> Input Class Initialized
INFO - 2016-01-30 22:10:57 --> Language Class Initialized
INFO - 2016-01-30 22:10:57 --> Loader Class Initialized
INFO - 2016-01-30 22:10:57 --> Helper loaded: url_helper
INFO - 2016-01-30 22:10:57 --> Helper loaded: file_helper
INFO - 2016-01-30 22:10:57 --> Helper loaded: date_helper
INFO - 2016-01-30 22:10:57 --> Database Driver Class Initialized
INFO - 2016-01-30 22:10:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:10:58 --> Controller Class Initialized
INFO - 2016-01-30 22:10:58 --> Model Class Initialized
INFO - 2016-01-30 22:10:58 --> Model Class Initialized
INFO - 2016-01-30 22:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:10:58 --> Pagination Class Initialized
INFO - 2016-01-30 22:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:10:58 --> Helper loaded: text_helper
INFO - 2016-01-30 22:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:10:58 --> Final output sent to browser
DEBUG - 2016-01-30 22:10:58 --> Total execution time: 1.1829
INFO - 2016-01-30 22:11:39 --> Config Class Initialized
INFO - 2016-01-30 22:11:39 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:11:39 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:11:39 --> Utf8 Class Initialized
INFO - 2016-01-30 22:11:39 --> URI Class Initialized
INFO - 2016-01-30 22:11:39 --> Router Class Initialized
INFO - 2016-01-30 22:11:39 --> Output Class Initialized
INFO - 2016-01-30 22:11:39 --> Security Class Initialized
DEBUG - 2016-01-30 22:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:11:39 --> Input Class Initialized
INFO - 2016-01-30 22:11:39 --> Language Class Initialized
INFO - 2016-01-30 22:11:39 --> Loader Class Initialized
INFO - 2016-01-30 22:11:39 --> Helper loaded: url_helper
INFO - 2016-01-30 22:11:39 --> Helper loaded: file_helper
INFO - 2016-01-30 22:11:39 --> Helper loaded: date_helper
INFO - 2016-01-30 22:11:39 --> Database Driver Class Initialized
INFO - 2016-01-30 22:11:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:11:40 --> Controller Class Initialized
INFO - 2016-01-30 22:11:40 --> Model Class Initialized
INFO - 2016-01-30 22:11:40 --> Model Class Initialized
INFO - 2016-01-30 22:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:11:40 --> Pagination Class Initialized
INFO - 2016-01-30 22:11:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:11:40 --> Helper loaded: text_helper
INFO - 2016-01-30 22:11:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:11:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:11:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:11:40 --> Final output sent to browser
DEBUG - 2016-01-30 22:11:40 --> Total execution time: 1.1187
INFO - 2016-01-30 22:12:14 --> Config Class Initialized
INFO - 2016-01-30 22:12:14 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:14 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:14 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:14 --> URI Class Initialized
DEBUG - 2016-01-30 22:12:14 --> No URI present. Default controller set.
INFO - 2016-01-30 22:12:14 --> Router Class Initialized
INFO - 2016-01-30 22:12:14 --> Output Class Initialized
INFO - 2016-01-30 22:12:14 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:14 --> Input Class Initialized
INFO - 2016-01-30 22:12:14 --> Language Class Initialized
INFO - 2016-01-30 22:12:14 --> Loader Class Initialized
INFO - 2016-01-30 22:12:14 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:14 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:14 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:14 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:15 --> Controller Class Initialized
INFO - 2016-01-30 22:12:15 --> Model Class Initialized
INFO - 2016-01-30 22:12:15 --> Model Class Initialized
INFO - 2016-01-30 22:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:15 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:15 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:15 --> Total execution time: 1.1425
INFO - 2016-01-30 22:12:17 --> Config Class Initialized
INFO - 2016-01-30 22:12:17 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:17 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:17 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:17 --> URI Class Initialized
INFO - 2016-01-30 22:12:17 --> Router Class Initialized
INFO - 2016-01-30 22:12:17 --> Output Class Initialized
INFO - 2016-01-30 22:12:17 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:17 --> Input Class Initialized
INFO - 2016-01-30 22:12:17 --> Language Class Initialized
INFO - 2016-01-30 22:12:17 --> Loader Class Initialized
INFO - 2016-01-30 22:12:17 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:17 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:17 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:17 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:18 --> Controller Class Initialized
INFO - 2016-01-30 22:12:18 --> Model Class Initialized
INFO - 2016-01-30 22:12:18 --> Model Class Initialized
INFO - 2016-01-30 22:12:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:18 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:18 --> Helper loaded: text_helper
INFO - 2016-01-30 22:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:18 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:18 --> Total execution time: 1.2038
INFO - 2016-01-30 22:12:22 --> Config Class Initialized
INFO - 2016-01-30 22:12:22 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:22 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:22 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:22 --> URI Class Initialized
DEBUG - 2016-01-30 22:12:22 --> No URI present. Default controller set.
INFO - 2016-01-30 22:12:22 --> Router Class Initialized
INFO - 2016-01-30 22:12:22 --> Output Class Initialized
INFO - 2016-01-30 22:12:22 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:22 --> Input Class Initialized
INFO - 2016-01-30 22:12:22 --> Language Class Initialized
INFO - 2016-01-30 22:12:22 --> Loader Class Initialized
INFO - 2016-01-30 22:12:22 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:22 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:22 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:22 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:23 --> Controller Class Initialized
INFO - 2016-01-30 22:12:23 --> Model Class Initialized
INFO - 2016-01-30 22:12:23 --> Model Class Initialized
INFO - 2016-01-30 22:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:23 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:23 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:23 --> Total execution time: 1.1614
INFO - 2016-01-30 22:12:25 --> Config Class Initialized
INFO - 2016-01-30 22:12:25 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:25 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:25 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:25 --> URI Class Initialized
INFO - 2016-01-30 22:12:25 --> Router Class Initialized
INFO - 2016-01-30 22:12:25 --> Output Class Initialized
INFO - 2016-01-30 22:12:25 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:25 --> Input Class Initialized
INFO - 2016-01-30 22:12:25 --> Language Class Initialized
INFO - 2016-01-30 22:12:25 --> Loader Class Initialized
INFO - 2016-01-30 22:12:25 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:25 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:25 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:25 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:26 --> Controller Class Initialized
INFO - 2016-01-30 22:12:26 --> Model Class Initialized
INFO - 2016-01-30 22:12:26 --> Model Class Initialized
INFO - 2016-01-30 22:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:26 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:26 --> Helper loaded: text_helper
INFO - 2016-01-30 22:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:26 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:26 --> Total execution time: 1.2149
INFO - 2016-01-30 22:12:32 --> Config Class Initialized
INFO - 2016-01-30 22:12:33 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:33 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:33 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:33 --> URI Class Initialized
DEBUG - 2016-01-30 22:12:33 --> No URI present. Default controller set.
INFO - 2016-01-30 22:12:33 --> Router Class Initialized
INFO - 2016-01-30 22:12:33 --> Output Class Initialized
INFO - 2016-01-30 22:12:33 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:33 --> Input Class Initialized
INFO - 2016-01-30 22:12:33 --> Language Class Initialized
INFO - 2016-01-30 22:12:33 --> Loader Class Initialized
INFO - 2016-01-30 22:12:33 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:33 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:33 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:33 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:34 --> Controller Class Initialized
INFO - 2016-01-30 22:12:34 --> Model Class Initialized
INFO - 2016-01-30 22:12:34 --> Model Class Initialized
INFO - 2016-01-30 22:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:34 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:34 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:34 --> Total execution time: 1.1524
INFO - 2016-01-30 22:12:36 --> Config Class Initialized
INFO - 2016-01-30 22:12:36 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:12:36 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:12:36 --> Utf8 Class Initialized
INFO - 2016-01-30 22:12:36 --> URI Class Initialized
INFO - 2016-01-30 22:12:36 --> Router Class Initialized
INFO - 2016-01-30 22:12:36 --> Output Class Initialized
INFO - 2016-01-30 22:12:36 --> Security Class Initialized
DEBUG - 2016-01-30 22:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:12:36 --> Input Class Initialized
INFO - 2016-01-30 22:12:36 --> Language Class Initialized
INFO - 2016-01-30 22:12:36 --> Loader Class Initialized
INFO - 2016-01-30 22:12:36 --> Helper loaded: url_helper
INFO - 2016-01-30 22:12:36 --> Helper loaded: file_helper
INFO - 2016-01-30 22:12:36 --> Helper loaded: date_helper
INFO - 2016-01-30 22:12:36 --> Database Driver Class Initialized
INFO - 2016-01-30 22:12:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:12:37 --> Controller Class Initialized
INFO - 2016-01-30 22:12:37 --> Model Class Initialized
INFO - 2016-01-30 22:12:37 --> Model Class Initialized
INFO - 2016-01-30 22:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:12:37 --> Pagination Class Initialized
INFO - 2016-01-30 22:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:12:37 --> Helper loaded: text_helper
INFO - 2016-01-30 22:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:12:37 --> Final output sent to browser
DEBUG - 2016-01-30 22:12:37 --> Total execution time: 1.1676
INFO - 2016-01-30 22:13:34 --> Config Class Initialized
INFO - 2016-01-30 22:13:34 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:13:34 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:13:34 --> Utf8 Class Initialized
INFO - 2016-01-30 22:13:34 --> URI Class Initialized
DEBUG - 2016-01-30 22:13:34 --> No URI present. Default controller set.
INFO - 2016-01-30 22:13:34 --> Router Class Initialized
INFO - 2016-01-30 22:13:34 --> Output Class Initialized
INFO - 2016-01-30 22:13:34 --> Security Class Initialized
DEBUG - 2016-01-30 22:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:13:34 --> Input Class Initialized
INFO - 2016-01-30 22:13:34 --> Language Class Initialized
INFO - 2016-01-30 22:13:34 --> Loader Class Initialized
INFO - 2016-01-30 22:13:34 --> Helper loaded: url_helper
INFO - 2016-01-30 22:13:34 --> Helper loaded: file_helper
INFO - 2016-01-30 22:13:34 --> Helper loaded: date_helper
INFO - 2016-01-30 22:13:34 --> Database Driver Class Initialized
INFO - 2016-01-30 22:13:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:13:35 --> Controller Class Initialized
INFO - 2016-01-30 22:13:35 --> Model Class Initialized
INFO - 2016-01-30 22:13:35 --> Model Class Initialized
INFO - 2016-01-30 22:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:13:35 --> Pagination Class Initialized
INFO - 2016-01-30 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:13:36 --> Final output sent to browser
DEBUG - 2016-01-30 22:13:36 --> Total execution time: 1.1344
INFO - 2016-01-30 22:13:37 --> Config Class Initialized
INFO - 2016-01-30 22:13:37 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:13:37 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:13:37 --> Utf8 Class Initialized
INFO - 2016-01-30 22:13:37 --> URI Class Initialized
INFO - 2016-01-30 22:13:37 --> Router Class Initialized
INFO - 2016-01-30 22:13:37 --> Output Class Initialized
INFO - 2016-01-30 22:13:37 --> Security Class Initialized
DEBUG - 2016-01-30 22:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:13:37 --> Input Class Initialized
INFO - 2016-01-30 22:13:37 --> Language Class Initialized
INFO - 2016-01-30 22:13:37 --> Loader Class Initialized
INFO - 2016-01-30 22:13:37 --> Helper loaded: url_helper
INFO - 2016-01-30 22:13:37 --> Helper loaded: file_helper
INFO - 2016-01-30 22:13:37 --> Helper loaded: date_helper
INFO - 2016-01-30 22:13:37 --> Database Driver Class Initialized
INFO - 2016-01-30 22:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:13:38 --> Controller Class Initialized
INFO - 2016-01-30 22:13:38 --> Model Class Initialized
INFO - 2016-01-30 22:13:38 --> Model Class Initialized
INFO - 2016-01-30 22:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:13:38 --> Pagination Class Initialized
INFO - 2016-01-30 22:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:13:38 --> Helper loaded: text_helper
INFO - 2016-01-30 22:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:13:38 --> Final output sent to browser
DEBUG - 2016-01-30 22:13:38 --> Total execution time: 1.2253
INFO - 2016-01-30 22:13:44 --> Config Class Initialized
INFO - 2016-01-30 22:13:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:13:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:13:44 --> Utf8 Class Initialized
INFO - 2016-01-30 22:13:44 --> URI Class Initialized
DEBUG - 2016-01-30 22:13:44 --> No URI present. Default controller set.
INFO - 2016-01-30 22:13:44 --> Router Class Initialized
INFO - 2016-01-30 22:13:44 --> Output Class Initialized
INFO - 2016-01-30 22:13:44 --> Security Class Initialized
DEBUG - 2016-01-30 22:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:13:44 --> Input Class Initialized
INFO - 2016-01-30 22:13:44 --> Language Class Initialized
INFO - 2016-01-30 22:13:44 --> Loader Class Initialized
INFO - 2016-01-30 22:13:44 --> Helper loaded: url_helper
INFO - 2016-01-30 22:13:44 --> Helper loaded: file_helper
INFO - 2016-01-30 22:13:44 --> Helper loaded: date_helper
INFO - 2016-01-30 22:13:44 --> Database Driver Class Initialized
INFO - 2016-01-30 22:13:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:13:45 --> Controller Class Initialized
INFO - 2016-01-30 22:13:45 --> Model Class Initialized
INFO - 2016-01-30 22:13:45 --> Model Class Initialized
INFO - 2016-01-30 22:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:13:45 --> Pagination Class Initialized
INFO - 2016-01-30 22:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:13:45 --> Final output sent to browser
DEBUG - 2016-01-30 22:13:45 --> Total execution time: 1.1359
INFO - 2016-01-30 22:13:50 --> Config Class Initialized
INFO - 2016-01-30 22:13:50 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:13:50 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:13:50 --> Utf8 Class Initialized
INFO - 2016-01-30 22:13:50 --> URI Class Initialized
INFO - 2016-01-30 22:13:50 --> Router Class Initialized
INFO - 2016-01-30 22:13:50 --> Output Class Initialized
INFO - 2016-01-30 22:13:50 --> Security Class Initialized
DEBUG - 2016-01-30 22:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:13:50 --> Input Class Initialized
INFO - 2016-01-30 22:13:50 --> Language Class Initialized
INFO - 2016-01-30 22:13:50 --> Loader Class Initialized
INFO - 2016-01-30 22:13:50 --> Helper loaded: url_helper
INFO - 2016-01-30 22:13:50 --> Helper loaded: file_helper
INFO - 2016-01-30 22:13:50 --> Helper loaded: date_helper
INFO - 2016-01-30 22:13:50 --> Database Driver Class Initialized
INFO - 2016-01-30 22:13:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:13:51 --> Controller Class Initialized
INFO - 2016-01-30 22:13:51 --> Model Class Initialized
INFO - 2016-01-30 22:13:51 --> Model Class Initialized
INFO - 2016-01-30 22:13:51 --> Helper loaded: form_helper
INFO - 2016-01-30 22:13:51 --> Form Validation Class Initialized
INFO - 2016-01-30 22:13:51 --> Helper loaded: text_helper
INFO - 2016-01-30 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 22:13:51 --> Final output sent to browser
DEBUG - 2016-01-30 22:13:51 --> Total execution time: 1.1600
INFO - 2016-01-30 22:14:02 --> Config Class Initialized
INFO - 2016-01-30 22:14:02 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:14:02 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:14:02 --> Utf8 Class Initialized
INFO - 2016-01-30 22:14:02 --> URI Class Initialized
INFO - 2016-01-30 22:14:02 --> Router Class Initialized
INFO - 2016-01-30 22:14:02 --> Output Class Initialized
INFO - 2016-01-30 22:14:02 --> Security Class Initialized
DEBUG - 2016-01-30 22:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:14:02 --> Input Class Initialized
INFO - 2016-01-30 22:14:02 --> Language Class Initialized
INFO - 2016-01-30 22:14:02 --> Loader Class Initialized
INFO - 2016-01-30 22:14:02 --> Helper loaded: url_helper
INFO - 2016-01-30 22:14:02 --> Helper loaded: file_helper
INFO - 2016-01-30 22:14:02 --> Helper loaded: date_helper
INFO - 2016-01-30 22:14:02 --> Database Driver Class Initialized
INFO - 2016-01-30 22:14:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:14:03 --> Controller Class Initialized
INFO - 2016-01-30 22:14:03 --> Model Class Initialized
INFO - 2016-01-30 22:14:03 --> Model Class Initialized
INFO - 2016-01-30 22:14:03 --> Helper loaded: form_helper
INFO - 2016-01-30 22:14:03 --> Form Validation Class Initialized
INFO - 2016-01-30 22:14:03 --> Helper loaded: text_helper
INFO - 2016-01-30 22:14:03 --> Config Class Initialized
INFO - 2016-01-30 22:14:03 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:14:03 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:14:03 --> Utf8 Class Initialized
INFO - 2016-01-30 22:14:03 --> URI Class Initialized
INFO - 2016-01-30 22:14:03 --> Router Class Initialized
INFO - 2016-01-30 22:14:03 --> Output Class Initialized
INFO - 2016-01-30 22:14:03 --> Security Class Initialized
DEBUG - 2016-01-30 22:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:14:03 --> Input Class Initialized
INFO - 2016-01-30 22:14:03 --> Language Class Initialized
INFO - 2016-01-30 22:14:03 --> Loader Class Initialized
INFO - 2016-01-30 22:14:03 --> Helper loaded: url_helper
INFO - 2016-01-30 22:14:03 --> Helper loaded: file_helper
INFO - 2016-01-30 22:14:03 --> Helper loaded: date_helper
INFO - 2016-01-30 22:14:03 --> Database Driver Class Initialized
INFO - 2016-01-30 22:14:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:14:04 --> Controller Class Initialized
INFO - 2016-01-30 22:14:04 --> Model Class Initialized
INFO - 2016-01-30 22:14:04 --> Model Class Initialized
INFO - 2016-01-30 22:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:14:04 --> Pagination Class Initialized
INFO - 2016-01-30 22:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:14:04 --> Final output sent to browser
DEBUG - 2016-01-30 22:14:04 --> Total execution time: 1.1696
INFO - 2016-01-30 22:14:08 --> Config Class Initialized
INFO - 2016-01-30 22:14:08 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:14:08 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:14:08 --> Utf8 Class Initialized
INFO - 2016-01-30 22:14:08 --> URI Class Initialized
INFO - 2016-01-30 22:14:08 --> Router Class Initialized
INFO - 2016-01-30 22:14:08 --> Output Class Initialized
INFO - 2016-01-30 22:14:08 --> Security Class Initialized
DEBUG - 2016-01-30 22:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:14:08 --> Input Class Initialized
INFO - 2016-01-30 22:14:08 --> Language Class Initialized
INFO - 2016-01-30 22:14:08 --> Loader Class Initialized
INFO - 2016-01-30 22:14:08 --> Helper loaded: url_helper
INFO - 2016-01-30 22:14:08 --> Helper loaded: file_helper
INFO - 2016-01-30 22:14:08 --> Helper loaded: date_helper
INFO - 2016-01-30 22:14:08 --> Database Driver Class Initialized
INFO - 2016-01-30 22:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:14:09 --> Controller Class Initialized
INFO - 2016-01-30 22:14:09 --> Model Class Initialized
INFO - 2016-01-30 22:14:09 --> Model Class Initialized
INFO - 2016-01-30 22:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:14:09 --> Pagination Class Initialized
INFO - 2016-01-30 22:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:14:09 --> Helper loaded: text_helper
INFO - 2016-01-30 22:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:14:09 --> Final output sent to browser
DEBUG - 2016-01-30 22:14:09 --> Total execution time: 1.1549
INFO - 2016-01-30 22:15:29 --> Config Class Initialized
INFO - 2016-01-30 22:15:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:29 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:29 --> URI Class Initialized
DEBUG - 2016-01-30 22:15:29 --> No URI present. Default controller set.
INFO - 2016-01-30 22:15:29 --> Router Class Initialized
INFO - 2016-01-30 22:15:29 --> Output Class Initialized
INFO - 2016-01-30 22:15:29 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:29 --> Input Class Initialized
INFO - 2016-01-30 22:15:29 --> Language Class Initialized
INFO - 2016-01-30 22:15:29 --> Loader Class Initialized
INFO - 2016-01-30 22:15:29 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:29 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:29 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:29 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:30 --> Controller Class Initialized
INFO - 2016-01-30 22:15:30 --> Model Class Initialized
INFO - 2016-01-30 22:15:30 --> Model Class Initialized
INFO - 2016-01-30 22:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:30 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:30 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:30 --> Total execution time: 1.1246
INFO - 2016-01-30 22:15:34 --> Config Class Initialized
INFO - 2016-01-30 22:15:34 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:34 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:34 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:34 --> URI Class Initialized
INFO - 2016-01-30 22:15:34 --> Router Class Initialized
INFO - 2016-01-30 22:15:34 --> Output Class Initialized
INFO - 2016-01-30 22:15:34 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:34 --> Input Class Initialized
INFO - 2016-01-30 22:15:34 --> Language Class Initialized
INFO - 2016-01-30 22:15:34 --> Loader Class Initialized
INFO - 2016-01-30 22:15:34 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:34 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:34 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:34 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:35 --> Controller Class Initialized
INFO - 2016-01-30 22:15:35 --> Model Class Initialized
INFO - 2016-01-30 22:15:35 --> Model Class Initialized
INFO - 2016-01-30 22:15:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:35 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:35 --> Helper loaded: text_helper
INFO - 2016-01-30 22:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:35 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:35 --> Total execution time: 1.1957
INFO - 2016-01-30 22:15:38 --> Config Class Initialized
INFO - 2016-01-30 22:15:38 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:38 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:38 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:38 --> URI Class Initialized
DEBUG - 2016-01-30 22:15:38 --> No URI present. Default controller set.
INFO - 2016-01-30 22:15:38 --> Router Class Initialized
INFO - 2016-01-30 22:15:38 --> Output Class Initialized
INFO - 2016-01-30 22:15:38 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:38 --> Input Class Initialized
INFO - 2016-01-30 22:15:38 --> Language Class Initialized
INFO - 2016-01-30 22:15:38 --> Loader Class Initialized
INFO - 2016-01-30 22:15:38 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:38 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:38 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:38 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:39 --> Controller Class Initialized
INFO - 2016-01-30 22:15:39 --> Model Class Initialized
INFO - 2016-01-30 22:15:39 --> Model Class Initialized
INFO - 2016-01-30 22:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:39 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:39 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:39 --> Total execution time: 1.1343
INFO - 2016-01-30 22:15:40 --> Config Class Initialized
INFO - 2016-01-30 22:15:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:40 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:41 --> URI Class Initialized
INFO - 2016-01-30 22:15:41 --> Router Class Initialized
INFO - 2016-01-30 22:15:41 --> Output Class Initialized
INFO - 2016-01-30 22:15:41 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:41 --> Input Class Initialized
INFO - 2016-01-30 22:15:41 --> Language Class Initialized
INFO - 2016-01-30 22:15:41 --> Loader Class Initialized
INFO - 2016-01-30 22:15:41 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:41 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:41 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:41 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:42 --> Controller Class Initialized
INFO - 2016-01-30 22:15:42 --> Model Class Initialized
INFO - 2016-01-30 22:15:42 --> Model Class Initialized
INFO - 2016-01-30 22:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:42 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:42 --> Helper loaded: text_helper
INFO - 2016-01-30 22:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:42 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:42 --> Total execution time: 1.1825
INFO - 2016-01-30 22:15:51 --> Config Class Initialized
INFO - 2016-01-30 22:15:51 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:51 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:51 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:51 --> URI Class Initialized
INFO - 2016-01-30 22:15:51 --> Router Class Initialized
INFO - 2016-01-30 22:15:51 --> Output Class Initialized
INFO - 2016-01-30 22:15:51 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:51 --> Input Class Initialized
INFO - 2016-01-30 22:15:51 --> Language Class Initialized
INFO - 2016-01-30 22:15:51 --> Loader Class Initialized
INFO - 2016-01-30 22:15:51 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:51 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:51 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:51 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:52 --> Controller Class Initialized
INFO - 2016-01-30 22:15:52 --> Model Class Initialized
INFO - 2016-01-30 22:15:52 --> Model Class Initialized
INFO - 2016-01-30 22:15:52 --> Helper loaded: form_helper
INFO - 2016-01-30 22:15:52 --> Form Validation Class Initialized
INFO - 2016-01-30 22:15:52 --> Helper loaded: text_helper
INFO - 2016-01-30 22:15:52 --> Config Class Initialized
INFO - 2016-01-30 22:15:52 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:52 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:52 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:52 --> URI Class Initialized
INFO - 2016-01-30 22:15:52 --> Router Class Initialized
INFO - 2016-01-30 22:15:52 --> Output Class Initialized
INFO - 2016-01-30 22:15:52 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:52 --> Input Class Initialized
INFO - 2016-01-30 22:15:52 --> Language Class Initialized
INFO - 2016-01-30 22:15:52 --> Loader Class Initialized
INFO - 2016-01-30 22:15:52 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:52 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:52 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:52 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:53 --> Controller Class Initialized
INFO - 2016-01-30 22:15:53 --> Model Class Initialized
INFO - 2016-01-30 22:15:53 --> Model Class Initialized
INFO - 2016-01-30 22:15:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:53 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:53 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:53 --> Total execution time: 1.0933
INFO - 2016-01-30 22:15:56 --> Config Class Initialized
INFO - 2016-01-30 22:15:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:15:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:15:56 --> Utf8 Class Initialized
INFO - 2016-01-30 22:15:56 --> URI Class Initialized
INFO - 2016-01-30 22:15:56 --> Router Class Initialized
INFO - 2016-01-30 22:15:56 --> Output Class Initialized
INFO - 2016-01-30 22:15:56 --> Security Class Initialized
DEBUG - 2016-01-30 22:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:15:56 --> Input Class Initialized
INFO - 2016-01-30 22:15:56 --> Language Class Initialized
INFO - 2016-01-30 22:15:56 --> Loader Class Initialized
INFO - 2016-01-30 22:15:56 --> Helper loaded: url_helper
INFO - 2016-01-30 22:15:56 --> Helper loaded: file_helper
INFO - 2016-01-30 22:15:56 --> Helper loaded: date_helper
INFO - 2016-01-30 22:15:56 --> Database Driver Class Initialized
INFO - 2016-01-30 22:15:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:15:57 --> Controller Class Initialized
INFO - 2016-01-30 22:15:57 --> Model Class Initialized
INFO - 2016-01-30 22:15:57 --> Model Class Initialized
INFO - 2016-01-30 22:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:15:57 --> Pagination Class Initialized
INFO - 2016-01-30 22:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:15:57 --> Helper loaded: text_helper
INFO - 2016-01-30 22:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:15:57 --> Final output sent to browser
DEBUG - 2016-01-30 22:15:57 --> Total execution time: 1.1786
INFO - 2016-01-30 22:17:29 --> Config Class Initialized
INFO - 2016-01-30 22:17:29 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:17:29 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:17:29 --> Utf8 Class Initialized
INFO - 2016-01-30 22:17:29 --> URI Class Initialized
DEBUG - 2016-01-30 22:17:29 --> No URI present. Default controller set.
INFO - 2016-01-30 22:17:29 --> Router Class Initialized
INFO - 2016-01-30 22:17:29 --> Output Class Initialized
INFO - 2016-01-30 22:17:29 --> Security Class Initialized
DEBUG - 2016-01-30 22:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:17:29 --> Input Class Initialized
INFO - 2016-01-30 22:17:29 --> Language Class Initialized
INFO - 2016-01-30 22:17:29 --> Loader Class Initialized
INFO - 2016-01-30 22:17:29 --> Helper loaded: url_helper
INFO - 2016-01-30 22:17:29 --> Helper loaded: file_helper
INFO - 2016-01-30 22:17:29 --> Helper loaded: date_helper
INFO - 2016-01-30 22:17:29 --> Database Driver Class Initialized
INFO - 2016-01-30 22:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:17:30 --> Controller Class Initialized
INFO - 2016-01-30 22:17:30 --> Model Class Initialized
INFO - 2016-01-30 22:17:30 --> Model Class Initialized
INFO - 2016-01-30 22:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:17:30 --> Pagination Class Initialized
INFO - 2016-01-30 22:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:17:30 --> Final output sent to browser
DEBUG - 2016-01-30 22:17:30 --> Total execution time: 1.1500
INFO - 2016-01-30 22:17:32 --> Config Class Initialized
INFO - 2016-01-30 22:17:32 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:17:32 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:17:32 --> Utf8 Class Initialized
INFO - 2016-01-30 22:17:32 --> URI Class Initialized
INFO - 2016-01-30 22:17:32 --> Router Class Initialized
INFO - 2016-01-30 22:17:32 --> Output Class Initialized
INFO - 2016-01-30 22:17:32 --> Security Class Initialized
DEBUG - 2016-01-30 22:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:17:32 --> Input Class Initialized
INFO - 2016-01-30 22:17:32 --> Language Class Initialized
INFO - 2016-01-30 22:17:32 --> Loader Class Initialized
INFO - 2016-01-30 22:17:32 --> Helper loaded: url_helper
INFO - 2016-01-30 22:17:32 --> Helper loaded: file_helper
INFO - 2016-01-30 22:17:32 --> Helper loaded: date_helper
INFO - 2016-01-30 22:17:32 --> Database Driver Class Initialized
INFO - 2016-01-30 22:17:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:17:33 --> Controller Class Initialized
INFO - 2016-01-30 22:17:33 --> Model Class Initialized
INFO - 2016-01-30 22:17:33 --> Model Class Initialized
INFO - 2016-01-30 22:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:17:33 --> Pagination Class Initialized
INFO - 2016-01-30 22:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:17:33 --> Helper loaded: text_helper
ERROR - 2016-01-30 22:17:34 --> Severity: Notice --> Undefined variable: session C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-01-30 22:17:34 --> Severity: Error --> Cannot access empty property C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
INFO - 2016-01-30 22:20:16 --> Config Class Initialized
INFO - 2016-01-30 22:20:16 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:20:16 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:20:16 --> Utf8 Class Initialized
INFO - 2016-01-30 22:20:16 --> URI Class Initialized
DEBUG - 2016-01-30 22:20:16 --> No URI present. Default controller set.
INFO - 2016-01-30 22:20:16 --> Router Class Initialized
INFO - 2016-01-30 22:20:16 --> Output Class Initialized
INFO - 2016-01-30 22:20:16 --> Security Class Initialized
DEBUG - 2016-01-30 22:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:20:16 --> Input Class Initialized
INFO - 2016-01-30 22:20:16 --> Language Class Initialized
INFO - 2016-01-30 22:20:16 --> Loader Class Initialized
INFO - 2016-01-30 22:20:16 --> Helper loaded: url_helper
INFO - 2016-01-30 22:20:16 --> Helper loaded: file_helper
INFO - 2016-01-30 22:20:16 --> Helper loaded: date_helper
INFO - 2016-01-30 22:20:16 --> Database Driver Class Initialized
INFO - 2016-01-30 22:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:20:17 --> Controller Class Initialized
INFO - 2016-01-30 22:20:17 --> Model Class Initialized
INFO - 2016-01-30 22:20:17 --> Model Class Initialized
INFO - 2016-01-30 22:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:20:17 --> Pagination Class Initialized
INFO - 2016-01-30 22:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:20:17 --> Final output sent to browser
DEBUG - 2016-01-30 22:20:17 --> Total execution time: 1.1444
INFO - 2016-01-30 22:20:19 --> Config Class Initialized
INFO - 2016-01-30 22:20:19 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:20:19 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:20:19 --> Utf8 Class Initialized
INFO - 2016-01-30 22:20:19 --> URI Class Initialized
INFO - 2016-01-30 22:20:19 --> Router Class Initialized
INFO - 2016-01-30 22:20:19 --> Output Class Initialized
INFO - 2016-01-30 22:20:19 --> Security Class Initialized
DEBUG - 2016-01-30 22:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:20:19 --> Input Class Initialized
INFO - 2016-01-30 22:20:19 --> Language Class Initialized
INFO - 2016-01-30 22:20:19 --> Loader Class Initialized
INFO - 2016-01-30 22:20:19 --> Helper loaded: url_helper
INFO - 2016-01-30 22:20:19 --> Helper loaded: file_helper
INFO - 2016-01-30 22:20:19 --> Helper loaded: date_helper
INFO - 2016-01-30 22:20:19 --> Database Driver Class Initialized
INFO - 2016-01-30 22:20:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:20:20 --> Controller Class Initialized
INFO - 2016-01-30 22:20:20 --> Model Class Initialized
INFO - 2016-01-30 22:20:20 --> Model Class Initialized
INFO - 2016-01-30 22:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:20:20 --> Pagination Class Initialized
INFO - 2016-01-30 22:20:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:20:20 --> Helper loaded: text_helper
ERROR - 2016-01-30 22:20:20 --> Severity: Notice --> Undefined variable: session C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-01-30 22:20:20 --> Severity: Error --> Cannot access empty property C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
INFO - 2016-01-30 22:22:26 --> Config Class Initialized
INFO - 2016-01-30 22:22:26 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:22:26 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:22:26 --> Utf8 Class Initialized
INFO - 2016-01-30 22:22:26 --> URI Class Initialized
DEBUG - 2016-01-30 22:22:26 --> No URI present. Default controller set.
INFO - 2016-01-30 22:22:26 --> Router Class Initialized
INFO - 2016-01-30 22:22:26 --> Output Class Initialized
INFO - 2016-01-30 22:22:26 --> Security Class Initialized
DEBUG - 2016-01-30 22:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:22:26 --> Input Class Initialized
INFO - 2016-01-30 22:22:26 --> Language Class Initialized
INFO - 2016-01-30 22:22:26 --> Loader Class Initialized
INFO - 2016-01-30 22:22:26 --> Helper loaded: url_helper
INFO - 2016-01-30 22:22:26 --> Helper loaded: file_helper
INFO - 2016-01-30 22:22:26 --> Helper loaded: date_helper
INFO - 2016-01-30 22:22:26 --> Database Driver Class Initialized
INFO - 2016-01-30 22:22:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:22:27 --> Controller Class Initialized
INFO - 2016-01-30 22:22:27 --> Model Class Initialized
INFO - 2016-01-30 22:22:27 --> Model Class Initialized
INFO - 2016-01-30 22:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:22:27 --> Pagination Class Initialized
INFO - 2016-01-30 22:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:22:27 --> Final output sent to browser
DEBUG - 2016-01-30 22:22:27 --> Total execution time: 1.1236
INFO - 2016-01-30 22:22:30 --> Config Class Initialized
INFO - 2016-01-30 22:22:30 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:22:30 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:22:30 --> Utf8 Class Initialized
INFO - 2016-01-30 22:22:30 --> URI Class Initialized
INFO - 2016-01-30 22:22:30 --> Router Class Initialized
INFO - 2016-01-30 22:22:30 --> Output Class Initialized
INFO - 2016-01-30 22:22:30 --> Security Class Initialized
DEBUG - 2016-01-30 22:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:22:30 --> Input Class Initialized
INFO - 2016-01-30 22:22:30 --> Language Class Initialized
INFO - 2016-01-30 22:22:30 --> Loader Class Initialized
INFO - 2016-01-30 22:22:30 --> Helper loaded: url_helper
INFO - 2016-01-30 22:22:30 --> Helper loaded: file_helper
INFO - 2016-01-30 22:22:30 --> Helper loaded: date_helper
INFO - 2016-01-30 22:22:30 --> Database Driver Class Initialized
INFO - 2016-01-30 22:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:22:31 --> Controller Class Initialized
INFO - 2016-01-30 22:22:31 --> Model Class Initialized
INFO - 2016-01-30 22:22:31 --> Model Class Initialized
INFO - 2016-01-30 22:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:22:31 --> Pagination Class Initialized
INFO - 2016-01-30 22:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:22:31 --> Helper loaded: text_helper
INFO - 2016-01-30 22:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:22:31 --> Final output sent to browser
DEBUG - 2016-01-30 22:22:31 --> Total execution time: 1.1761
INFO - 2016-01-30 22:22:45 --> Config Class Initialized
INFO - 2016-01-30 22:22:45 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:22:45 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:22:45 --> Utf8 Class Initialized
INFO - 2016-01-30 22:22:45 --> URI Class Initialized
INFO - 2016-01-30 22:22:45 --> Router Class Initialized
INFO - 2016-01-30 22:22:45 --> Output Class Initialized
INFO - 2016-01-30 22:22:45 --> Security Class Initialized
DEBUG - 2016-01-30 22:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:22:45 --> Input Class Initialized
INFO - 2016-01-30 22:22:45 --> Language Class Initialized
INFO - 2016-01-30 22:22:45 --> Loader Class Initialized
INFO - 2016-01-30 22:22:45 --> Helper loaded: url_helper
INFO - 2016-01-30 22:22:45 --> Helper loaded: file_helper
INFO - 2016-01-30 22:22:45 --> Helper loaded: date_helper
INFO - 2016-01-30 22:22:45 --> Database Driver Class Initialized
INFO - 2016-01-30 22:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:22:46 --> Controller Class Initialized
INFO - 2016-01-30 22:22:46 --> Model Class Initialized
INFO - 2016-01-30 22:22:46 --> Model Class Initialized
INFO - 2016-01-30 22:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:22:46 --> Pagination Class Initialized
INFO - 2016-01-30 22:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:22:46 --> Helper loaded: text_helper
INFO - 2016-01-30 22:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:22:46 --> Final output sent to browser
DEBUG - 2016-01-30 22:22:46 --> Total execution time: 1.2265
INFO - 2016-01-30 22:23:32 --> Config Class Initialized
INFO - 2016-01-30 22:23:32 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:23:32 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:23:32 --> Utf8 Class Initialized
INFO - 2016-01-30 22:23:32 --> URI Class Initialized
DEBUG - 2016-01-30 22:23:32 --> No URI present. Default controller set.
INFO - 2016-01-30 22:23:32 --> Router Class Initialized
INFO - 2016-01-30 22:23:32 --> Output Class Initialized
INFO - 2016-01-30 22:23:32 --> Security Class Initialized
DEBUG - 2016-01-30 22:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:23:32 --> Input Class Initialized
INFO - 2016-01-30 22:23:32 --> Language Class Initialized
INFO - 2016-01-30 22:23:32 --> Loader Class Initialized
INFO - 2016-01-30 22:23:32 --> Helper loaded: url_helper
INFO - 2016-01-30 22:23:32 --> Helper loaded: file_helper
INFO - 2016-01-30 22:23:32 --> Helper loaded: date_helper
INFO - 2016-01-30 22:23:32 --> Database Driver Class Initialized
INFO - 2016-01-30 22:23:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:23:33 --> Controller Class Initialized
INFO - 2016-01-30 22:23:33 --> Model Class Initialized
INFO - 2016-01-30 22:23:33 --> Model Class Initialized
INFO - 2016-01-30 22:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:23:33 --> Pagination Class Initialized
INFO - 2016-01-30 22:23:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:23:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:23:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:23:33 --> Final output sent to browser
DEBUG - 2016-01-30 22:23:33 --> Total execution time: 1.1190
INFO - 2016-01-30 22:23:35 --> Config Class Initialized
INFO - 2016-01-30 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:23:35 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:23:35 --> Utf8 Class Initialized
INFO - 2016-01-30 22:23:35 --> URI Class Initialized
INFO - 2016-01-30 22:23:35 --> Router Class Initialized
INFO - 2016-01-30 22:23:35 --> Output Class Initialized
INFO - 2016-01-30 22:23:35 --> Security Class Initialized
DEBUG - 2016-01-30 22:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:23:35 --> Input Class Initialized
INFO - 2016-01-30 22:23:35 --> Language Class Initialized
INFO - 2016-01-30 22:23:35 --> Loader Class Initialized
INFO - 2016-01-30 22:23:35 --> Helper loaded: url_helper
INFO - 2016-01-30 22:23:35 --> Helper loaded: file_helper
INFO - 2016-01-30 22:23:35 --> Helper loaded: date_helper
INFO - 2016-01-30 22:23:35 --> Database Driver Class Initialized
INFO - 2016-01-30 22:23:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:23:36 --> Controller Class Initialized
INFO - 2016-01-30 22:23:36 --> Model Class Initialized
INFO - 2016-01-30 22:23:36 --> Model Class Initialized
INFO - 2016-01-30 22:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:23:36 --> Pagination Class Initialized
INFO - 2016-01-30 22:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:23:36 --> Helper loaded: text_helper
INFO - 2016-01-30 22:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:23:36 --> Final output sent to browser
DEBUG - 2016-01-30 22:23:36 --> Total execution time: 1.1889
INFO - 2016-01-30 22:23:42 --> Config Class Initialized
INFO - 2016-01-30 22:23:42 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:23:42 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:23:42 --> Utf8 Class Initialized
INFO - 2016-01-30 22:23:42 --> URI Class Initialized
DEBUG - 2016-01-30 22:23:42 --> No URI present. Default controller set.
INFO - 2016-01-30 22:23:42 --> Router Class Initialized
INFO - 2016-01-30 22:23:42 --> Output Class Initialized
INFO - 2016-01-30 22:23:42 --> Security Class Initialized
DEBUG - 2016-01-30 22:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:23:42 --> Input Class Initialized
INFO - 2016-01-30 22:23:42 --> Language Class Initialized
INFO - 2016-01-30 22:23:42 --> Loader Class Initialized
INFO - 2016-01-30 22:23:42 --> Helper loaded: url_helper
INFO - 2016-01-30 22:23:42 --> Helper loaded: file_helper
INFO - 2016-01-30 22:23:42 --> Helper loaded: date_helper
INFO - 2016-01-30 22:23:42 --> Database Driver Class Initialized
INFO - 2016-01-30 22:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:23:43 --> Controller Class Initialized
INFO - 2016-01-30 22:23:43 --> Model Class Initialized
INFO - 2016-01-30 22:23:43 --> Model Class Initialized
INFO - 2016-01-30 22:23:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:23:43 --> Pagination Class Initialized
INFO - 2016-01-30 22:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:23:43 --> Final output sent to browser
DEBUG - 2016-01-30 22:23:43 --> Total execution time: 1.1256
INFO - 2016-01-30 22:25:44 --> Config Class Initialized
INFO - 2016-01-30 22:25:44 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:25:44 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:25:44 --> Utf8 Class Initialized
INFO - 2016-01-30 22:25:44 --> URI Class Initialized
DEBUG - 2016-01-30 22:25:44 --> No URI present. Default controller set.
INFO - 2016-01-30 22:25:44 --> Router Class Initialized
INFO - 2016-01-30 22:25:44 --> Output Class Initialized
INFO - 2016-01-30 22:25:44 --> Security Class Initialized
DEBUG - 2016-01-30 22:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:25:44 --> Input Class Initialized
INFO - 2016-01-30 22:25:44 --> Language Class Initialized
INFO - 2016-01-30 22:25:44 --> Loader Class Initialized
INFO - 2016-01-30 22:25:44 --> Helper loaded: url_helper
INFO - 2016-01-30 22:25:44 --> Helper loaded: file_helper
INFO - 2016-01-30 22:25:44 --> Helper loaded: date_helper
INFO - 2016-01-30 22:25:44 --> Database Driver Class Initialized
INFO - 2016-01-30 22:25:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:25:46 --> Controller Class Initialized
INFO - 2016-01-30 22:25:46 --> Model Class Initialized
INFO - 2016-01-30 22:25:46 --> Model Class Initialized
INFO - 2016-01-30 22:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:25:46 --> Pagination Class Initialized
INFO - 2016-01-30 22:25:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:25:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:25:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:25:46 --> Final output sent to browser
DEBUG - 2016-01-30 22:25:46 --> Total execution time: 1.1674
INFO - 2016-01-30 22:25:48 --> Config Class Initialized
INFO - 2016-01-30 22:25:48 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:25:48 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:25:48 --> Utf8 Class Initialized
INFO - 2016-01-30 22:25:48 --> URI Class Initialized
INFO - 2016-01-30 22:25:48 --> Router Class Initialized
INFO - 2016-01-30 22:25:48 --> Output Class Initialized
INFO - 2016-01-30 22:25:48 --> Security Class Initialized
DEBUG - 2016-01-30 22:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:25:48 --> Input Class Initialized
INFO - 2016-01-30 22:25:48 --> Language Class Initialized
INFO - 2016-01-30 22:25:48 --> Loader Class Initialized
INFO - 2016-01-30 22:25:48 --> Helper loaded: url_helper
INFO - 2016-01-30 22:25:48 --> Helper loaded: file_helper
INFO - 2016-01-30 22:25:48 --> Helper loaded: date_helper
INFO - 2016-01-30 22:25:48 --> Database Driver Class Initialized
INFO - 2016-01-30 22:25:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:25:49 --> Controller Class Initialized
INFO - 2016-01-30 22:25:49 --> Model Class Initialized
INFO - 2016-01-30 22:25:49 --> Model Class Initialized
INFO - 2016-01-30 22:25:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:25:49 --> Pagination Class Initialized
INFO - 2016-01-30 22:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:25:49 --> Helper loaded: text_helper
INFO - 2016-01-30 22:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:25:49 --> Final output sent to browser
DEBUG - 2016-01-30 22:25:49 --> Total execution time: 1.1761
INFO - 2016-01-30 22:25:56 --> Config Class Initialized
INFO - 2016-01-30 22:25:56 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:25:56 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:25:56 --> Utf8 Class Initialized
INFO - 2016-01-30 22:25:56 --> URI Class Initialized
DEBUG - 2016-01-30 22:25:56 --> No URI present. Default controller set.
INFO - 2016-01-30 22:25:56 --> Router Class Initialized
INFO - 2016-01-30 22:25:56 --> Output Class Initialized
INFO - 2016-01-30 22:25:56 --> Security Class Initialized
DEBUG - 2016-01-30 22:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:25:56 --> Input Class Initialized
INFO - 2016-01-30 22:25:56 --> Language Class Initialized
INFO - 2016-01-30 22:25:56 --> Loader Class Initialized
INFO - 2016-01-30 22:25:56 --> Helper loaded: url_helper
INFO - 2016-01-30 22:25:56 --> Helper loaded: file_helper
INFO - 2016-01-30 22:25:56 --> Helper loaded: date_helper
INFO - 2016-01-30 22:25:56 --> Database Driver Class Initialized
INFO - 2016-01-30 22:25:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:25:57 --> Controller Class Initialized
INFO - 2016-01-30 22:25:57 --> Model Class Initialized
INFO - 2016-01-30 22:25:57 --> Model Class Initialized
INFO - 2016-01-30 22:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:25:57 --> Pagination Class Initialized
INFO - 2016-01-30 22:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:25:57 --> Final output sent to browser
DEBUG - 2016-01-30 22:25:57 --> Total execution time: 1.1376
INFO - 2016-01-30 22:27:36 --> Config Class Initialized
INFO - 2016-01-30 22:27:36 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:27:36 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:27:36 --> Utf8 Class Initialized
INFO - 2016-01-30 22:27:36 --> URI Class Initialized
INFO - 2016-01-30 22:27:36 --> Router Class Initialized
INFO - 2016-01-30 22:27:36 --> Output Class Initialized
INFO - 2016-01-30 22:27:36 --> Security Class Initialized
DEBUG - 2016-01-30 22:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:27:36 --> Input Class Initialized
INFO - 2016-01-30 22:27:36 --> Language Class Initialized
INFO - 2016-01-30 22:27:36 --> Loader Class Initialized
INFO - 2016-01-30 22:27:36 --> Helper loaded: url_helper
INFO - 2016-01-30 22:27:36 --> Helper loaded: file_helper
INFO - 2016-01-30 22:27:36 --> Helper loaded: date_helper
INFO - 2016-01-30 22:27:36 --> Database Driver Class Initialized
INFO - 2016-01-30 22:27:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:27:37 --> Controller Class Initialized
INFO - 2016-01-30 22:27:37 --> Model Class Initialized
INFO - 2016-01-30 22:27:37 --> Model Class Initialized
INFO - 2016-01-30 22:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:27:37 --> Pagination Class Initialized
INFO - 2016-01-30 22:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:27:37 --> Helper loaded: text_helper
INFO - 2016-01-30 22:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:27:37 --> Final output sent to browser
DEBUG - 2016-01-30 22:27:37 --> Total execution time: 1.1581
INFO - 2016-01-30 22:27:40 --> Config Class Initialized
INFO - 2016-01-30 22:27:40 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:27:40 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:27:40 --> Utf8 Class Initialized
INFO - 2016-01-30 22:27:40 --> URI Class Initialized
INFO - 2016-01-30 22:27:40 --> Router Class Initialized
INFO - 2016-01-30 22:27:40 --> Output Class Initialized
INFO - 2016-01-30 22:27:40 --> Security Class Initialized
DEBUG - 2016-01-30 22:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:27:40 --> Input Class Initialized
INFO - 2016-01-30 22:27:40 --> Language Class Initialized
INFO - 2016-01-30 22:27:40 --> Loader Class Initialized
INFO - 2016-01-30 22:27:40 --> Helper loaded: url_helper
INFO - 2016-01-30 22:27:40 --> Helper loaded: file_helper
INFO - 2016-01-30 22:27:40 --> Helper loaded: date_helper
INFO - 2016-01-30 22:27:40 --> Database Driver Class Initialized
INFO - 2016-01-30 22:27:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:27:41 --> Controller Class Initialized
INFO - 2016-01-30 22:27:41 --> Model Class Initialized
INFO - 2016-01-30 22:27:41 --> Model Class Initialized
INFO - 2016-01-30 22:27:41 --> Helper loaded: form_helper
INFO - 2016-01-30 22:27:41 --> Form Validation Class Initialized
INFO - 2016-01-30 22:27:41 --> Helper loaded: text_helper
INFO - 2016-01-30 22:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-30 22:27:41 --> Final output sent to browser
DEBUG - 2016-01-30 22:27:41 --> Total execution time: 1.1134
INFO - 2016-01-30 22:27:49 --> Config Class Initialized
INFO - 2016-01-30 22:27:49 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:27:49 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:27:49 --> Utf8 Class Initialized
INFO - 2016-01-30 22:27:49 --> URI Class Initialized
INFO - 2016-01-30 22:27:49 --> Router Class Initialized
INFO - 2016-01-30 22:27:49 --> Output Class Initialized
INFO - 2016-01-30 22:27:49 --> Security Class Initialized
DEBUG - 2016-01-30 22:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:27:49 --> Input Class Initialized
INFO - 2016-01-30 22:27:49 --> Language Class Initialized
INFO - 2016-01-30 22:27:49 --> Loader Class Initialized
INFO - 2016-01-30 22:27:49 --> Helper loaded: url_helper
INFO - 2016-01-30 22:27:49 --> Helper loaded: file_helper
INFO - 2016-01-30 22:27:49 --> Helper loaded: date_helper
INFO - 2016-01-30 22:27:49 --> Database Driver Class Initialized
INFO - 2016-01-30 22:27:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:27:50 --> Controller Class Initialized
INFO - 2016-01-30 22:27:50 --> Model Class Initialized
INFO - 2016-01-30 22:27:50 --> Model Class Initialized
INFO - 2016-01-30 22:27:50 --> Helper loaded: form_helper
INFO - 2016-01-30 22:27:50 --> Form Validation Class Initialized
INFO - 2016-01-30 22:27:50 --> Helper loaded: text_helper
INFO - 2016-01-30 22:27:51 --> Config Class Initialized
INFO - 2016-01-30 22:27:51 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:27:51 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:27:51 --> Utf8 Class Initialized
INFO - 2016-01-30 22:27:51 --> URI Class Initialized
INFO - 2016-01-30 22:27:51 --> Router Class Initialized
INFO - 2016-01-30 22:27:51 --> Output Class Initialized
INFO - 2016-01-30 22:27:51 --> Security Class Initialized
DEBUG - 2016-01-30 22:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:27:51 --> Input Class Initialized
INFO - 2016-01-30 22:27:51 --> Language Class Initialized
INFO - 2016-01-30 22:27:51 --> Loader Class Initialized
INFO - 2016-01-30 22:27:51 --> Helper loaded: url_helper
INFO - 2016-01-30 22:27:51 --> Helper loaded: file_helper
INFO - 2016-01-30 22:27:51 --> Helper loaded: date_helper
INFO - 2016-01-30 22:27:51 --> Database Driver Class Initialized
INFO - 2016-01-30 22:27:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:27:52 --> Controller Class Initialized
INFO - 2016-01-30 22:27:52 --> Model Class Initialized
INFO - 2016-01-30 22:27:52 --> Model Class Initialized
INFO - 2016-01-30 22:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:27:52 --> Pagination Class Initialized
INFO - 2016-01-30 22:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-30 22:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:27:52 --> Final output sent to browser
DEBUG - 2016-01-30 22:27:52 --> Total execution time: 1.1141
INFO - 2016-01-30 22:27:55 --> Config Class Initialized
INFO - 2016-01-30 22:27:55 --> Hooks Class Initialized
DEBUG - 2016-01-30 22:27:55 --> UTF-8 Support Enabled
INFO - 2016-01-30 22:27:55 --> Utf8 Class Initialized
INFO - 2016-01-30 22:27:55 --> URI Class Initialized
INFO - 2016-01-30 22:27:55 --> Router Class Initialized
INFO - 2016-01-30 22:27:55 --> Output Class Initialized
INFO - 2016-01-30 22:27:55 --> Security Class Initialized
DEBUG - 2016-01-30 22:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-30 22:27:55 --> Input Class Initialized
INFO - 2016-01-30 22:27:55 --> Language Class Initialized
INFO - 2016-01-30 22:27:55 --> Loader Class Initialized
INFO - 2016-01-30 22:27:55 --> Helper loaded: url_helper
INFO - 2016-01-30 22:27:55 --> Helper loaded: file_helper
INFO - 2016-01-30 22:27:55 --> Helper loaded: date_helper
INFO - 2016-01-30 22:27:55 --> Database Driver Class Initialized
INFO - 2016-01-30 22:27:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-30 22:27:56 --> Controller Class Initialized
INFO - 2016-01-30 22:27:56 --> Model Class Initialized
INFO - 2016-01-30 22:27:56 --> Model Class Initialized
INFO - 2016-01-30 22:27:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-30 22:27:56 --> Pagination Class Initialized
INFO - 2016-01-30 22:27:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-30 22:27:56 --> Helper loaded: text_helper
INFO - 2016-01-30 22:27:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-30 22:27:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-30 22:27:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-30 22:27:56 --> Final output sent to browser
DEBUG - 2016-01-30 22:27:56 --> Total execution time: 1.1705
