<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-10 05:26:14 --> Config Class Initialized
INFO - 2016-03-10 05:26:14 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:26:14 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:26:14 --> Utf8 Class Initialized
INFO - 2016-03-10 05:26:14 --> URI Class Initialized
DEBUG - 2016-03-10 05:26:14 --> No URI present. Default controller set.
INFO - 2016-03-10 05:26:14 --> Router Class Initialized
INFO - 2016-03-10 05:26:14 --> Output Class Initialized
INFO - 2016-03-10 05:26:14 --> Security Class Initialized
DEBUG - 2016-03-10 05:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:26:15 --> Input Class Initialized
INFO - 2016-03-10 05:26:15 --> Language Class Initialized
INFO - 2016-03-10 05:26:15 --> Loader Class Initialized
INFO - 2016-03-10 05:26:15 --> Helper loaded: url_helper
INFO - 2016-03-10 05:26:15 --> Helper loaded: file_helper
INFO - 2016-03-10 05:26:15 --> Helper loaded: date_helper
INFO - 2016-03-10 05:26:15 --> Helper loaded: form_helper
INFO - 2016-03-10 05:26:15 --> Database Driver Class Initialized
INFO - 2016-03-10 05:26:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:26:16 --> Controller Class Initialized
INFO - 2016-03-10 05:26:16 --> Model Class Initialized
INFO - 2016-03-10 05:26:16 --> Model Class Initialized
INFO - 2016-03-10 05:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:26:16 --> Pagination Class Initialized
INFO - 2016-03-10 05:26:16 --> Helper loaded: text_helper
INFO - 2016-03-10 05:26:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:26:16 --> Final output sent to browser
DEBUG - 2016-03-10 08:26:16 --> Total execution time: 2.1365
INFO - 2016-03-10 05:26:36 --> Config Class Initialized
INFO - 2016-03-10 05:26:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:26:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:26:36 --> Utf8 Class Initialized
INFO - 2016-03-10 05:26:36 --> URI Class Initialized
INFO - 2016-03-10 05:26:36 --> Router Class Initialized
INFO - 2016-03-10 05:26:36 --> Output Class Initialized
INFO - 2016-03-10 05:26:36 --> Security Class Initialized
DEBUG - 2016-03-10 05:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:26:36 --> Input Class Initialized
INFO - 2016-03-10 05:26:36 --> Language Class Initialized
INFO - 2016-03-10 05:26:36 --> Loader Class Initialized
INFO - 2016-03-10 05:26:36 --> Helper loaded: url_helper
INFO - 2016-03-10 05:26:36 --> Helper loaded: file_helper
INFO - 2016-03-10 05:26:36 --> Helper loaded: date_helper
INFO - 2016-03-10 05:26:36 --> Helper loaded: form_helper
INFO - 2016-03-10 05:26:36 --> Database Driver Class Initialized
INFO - 2016-03-10 05:26:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:26:37 --> Controller Class Initialized
INFO - 2016-03-10 05:26:37 --> Model Class Initialized
INFO - 2016-03-10 05:26:37 --> Model Class Initialized
INFO - 2016-03-10 05:26:37 --> Form Validation Class Initialized
INFO - 2016-03-10 05:26:37 --> Helper loaded: text_helper
INFO - 2016-03-10 05:26:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-10 05:26:37 --> Severity: Warning --> Illegal string offset 'email' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\user_model.php 71
INFO - 2016-03-10 05:26:38 --> Final output sent to browser
DEBUG - 2016-03-10 05:26:38 --> Total execution time: 1.3795
INFO - 2016-03-10 05:32:30 --> Config Class Initialized
INFO - 2016-03-10 05:32:30 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:32:30 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:32:30 --> Utf8 Class Initialized
INFO - 2016-03-10 05:32:30 --> URI Class Initialized
DEBUG - 2016-03-10 05:32:30 --> No URI present. Default controller set.
INFO - 2016-03-10 05:32:30 --> Router Class Initialized
INFO - 2016-03-10 05:32:30 --> Output Class Initialized
INFO - 2016-03-10 05:32:30 --> Security Class Initialized
DEBUG - 2016-03-10 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:32:30 --> Input Class Initialized
INFO - 2016-03-10 05:32:30 --> Language Class Initialized
INFO - 2016-03-10 05:32:30 --> Loader Class Initialized
INFO - 2016-03-10 05:32:30 --> Helper loaded: url_helper
INFO - 2016-03-10 05:32:30 --> Helper loaded: file_helper
INFO - 2016-03-10 05:32:30 --> Helper loaded: date_helper
INFO - 2016-03-10 05:32:30 --> Helper loaded: form_helper
INFO - 2016-03-10 05:32:30 --> Database Driver Class Initialized
INFO - 2016-03-10 05:32:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:32:31 --> Controller Class Initialized
INFO - 2016-03-10 05:32:31 --> Model Class Initialized
INFO - 2016-03-10 05:32:31 --> Model Class Initialized
INFO - 2016-03-10 05:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:32:31 --> Pagination Class Initialized
INFO - 2016-03-10 05:32:31 --> Helper loaded: text_helper
INFO - 2016-03-10 05:32:31 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:32:31 --> Final output sent to browser
DEBUG - 2016-03-10 08:32:31 --> Total execution time: 1.1283
INFO - 2016-03-10 05:32:55 --> Config Class Initialized
INFO - 2016-03-10 05:32:55 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:32:55 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:32:55 --> Utf8 Class Initialized
INFO - 2016-03-10 05:32:55 --> URI Class Initialized
INFO - 2016-03-10 05:32:55 --> Router Class Initialized
INFO - 2016-03-10 05:32:55 --> Output Class Initialized
INFO - 2016-03-10 05:32:55 --> Security Class Initialized
DEBUG - 2016-03-10 05:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:32:55 --> Input Class Initialized
INFO - 2016-03-10 05:32:55 --> Language Class Initialized
INFO - 2016-03-10 05:32:55 --> Loader Class Initialized
INFO - 2016-03-10 05:32:55 --> Helper loaded: url_helper
INFO - 2016-03-10 05:32:55 --> Helper loaded: file_helper
INFO - 2016-03-10 05:32:55 --> Helper loaded: date_helper
INFO - 2016-03-10 05:32:55 --> Helper loaded: form_helper
INFO - 2016-03-10 05:32:55 --> Database Driver Class Initialized
INFO - 2016-03-10 05:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:32:56 --> Controller Class Initialized
INFO - 2016-03-10 05:32:56 --> Model Class Initialized
INFO - 2016-03-10 05:32:56 --> Model Class Initialized
INFO - 2016-03-10 05:32:56 --> Form Validation Class Initialized
INFO - 2016-03-10 05:32:56 --> Helper loaded: text_helper
INFO - 2016-03-10 05:32:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-10 05:32:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::num_results() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 48
INFO - 2016-03-10 05:34:24 --> Config Class Initialized
INFO - 2016-03-10 05:34:24 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:34:24 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:34:24 --> Utf8 Class Initialized
INFO - 2016-03-10 05:34:24 --> URI Class Initialized
DEBUG - 2016-03-10 05:34:24 --> No URI present. Default controller set.
INFO - 2016-03-10 05:34:24 --> Router Class Initialized
INFO - 2016-03-10 05:34:24 --> Output Class Initialized
INFO - 2016-03-10 05:34:24 --> Security Class Initialized
DEBUG - 2016-03-10 05:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:34:24 --> Input Class Initialized
INFO - 2016-03-10 05:34:24 --> Language Class Initialized
INFO - 2016-03-10 05:34:24 --> Loader Class Initialized
INFO - 2016-03-10 05:34:24 --> Helper loaded: url_helper
INFO - 2016-03-10 05:34:24 --> Helper loaded: file_helper
INFO - 2016-03-10 05:34:24 --> Helper loaded: date_helper
INFO - 2016-03-10 05:34:24 --> Helper loaded: form_helper
INFO - 2016-03-10 05:34:24 --> Database Driver Class Initialized
INFO - 2016-03-10 05:34:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:34:25 --> Controller Class Initialized
INFO - 2016-03-10 05:34:25 --> Model Class Initialized
INFO - 2016-03-10 05:34:25 --> Model Class Initialized
INFO - 2016-03-10 05:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:34:25 --> Pagination Class Initialized
INFO - 2016-03-10 05:34:25 --> Helper loaded: text_helper
INFO - 2016-03-10 05:34:25 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:34:25 --> Final output sent to browser
DEBUG - 2016-03-10 08:34:25 --> Total execution time: 1.1358
INFO - 2016-03-10 05:34:42 --> Config Class Initialized
INFO - 2016-03-10 05:34:42 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:34:42 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:34:42 --> Utf8 Class Initialized
INFO - 2016-03-10 05:34:42 --> URI Class Initialized
INFO - 2016-03-10 05:34:42 --> Router Class Initialized
INFO - 2016-03-10 05:34:42 --> Output Class Initialized
INFO - 2016-03-10 05:34:42 --> Security Class Initialized
DEBUG - 2016-03-10 05:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:34:42 --> Input Class Initialized
INFO - 2016-03-10 05:34:42 --> Language Class Initialized
INFO - 2016-03-10 05:34:42 --> Loader Class Initialized
INFO - 2016-03-10 05:34:42 --> Helper loaded: url_helper
INFO - 2016-03-10 05:34:42 --> Helper loaded: file_helper
INFO - 2016-03-10 05:34:42 --> Helper loaded: date_helper
INFO - 2016-03-10 05:34:42 --> Helper loaded: form_helper
INFO - 2016-03-10 05:34:42 --> Database Driver Class Initialized
INFO - 2016-03-10 05:34:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:34:43 --> Controller Class Initialized
INFO - 2016-03-10 05:34:43 --> Model Class Initialized
INFO - 2016-03-10 05:34:43 --> Model Class Initialized
INFO - 2016-03-10 05:34:43 --> Form Validation Class Initialized
INFO - 2016-03-10 05:34:43 --> Helper loaded: text_helper
INFO - 2016-03-10 05:34:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-10 05:34:43 --> Could not find the language line "form_validation_emailcheck"
INFO - 2016-03-10 05:34:43 --> Final output sent to browser
DEBUG - 2016-03-10 05:34:43 --> Total execution time: 1.1083
INFO - 2016-03-10 05:35:31 --> Config Class Initialized
INFO - 2016-03-10 05:35:31 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:35:31 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:35:31 --> Utf8 Class Initialized
INFO - 2016-03-10 05:35:31 --> URI Class Initialized
DEBUG - 2016-03-10 05:35:31 --> No URI present. Default controller set.
INFO - 2016-03-10 05:35:31 --> Router Class Initialized
INFO - 2016-03-10 05:35:31 --> Output Class Initialized
INFO - 2016-03-10 05:35:31 --> Security Class Initialized
DEBUG - 2016-03-10 05:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:35:31 --> Input Class Initialized
INFO - 2016-03-10 05:35:31 --> Language Class Initialized
INFO - 2016-03-10 05:35:31 --> Loader Class Initialized
INFO - 2016-03-10 05:35:31 --> Helper loaded: url_helper
INFO - 2016-03-10 05:35:31 --> Helper loaded: file_helper
INFO - 2016-03-10 05:35:31 --> Helper loaded: date_helper
INFO - 2016-03-10 05:35:31 --> Helper loaded: form_helper
INFO - 2016-03-10 05:35:31 --> Database Driver Class Initialized
INFO - 2016-03-10 05:35:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:35:32 --> Controller Class Initialized
INFO - 2016-03-10 05:35:32 --> Model Class Initialized
INFO - 2016-03-10 05:35:32 --> Model Class Initialized
INFO - 2016-03-10 05:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:35:32 --> Pagination Class Initialized
INFO - 2016-03-10 05:35:32 --> Helper loaded: text_helper
INFO - 2016-03-10 05:35:32 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:35:32 --> Final output sent to browser
DEBUG - 2016-03-10 08:35:32 --> Total execution time: 1.1360
INFO - 2016-03-10 05:35:48 --> Config Class Initialized
INFO - 2016-03-10 05:35:48 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:35:48 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:35:48 --> Utf8 Class Initialized
INFO - 2016-03-10 05:35:48 --> URI Class Initialized
INFO - 2016-03-10 05:35:48 --> Router Class Initialized
INFO - 2016-03-10 05:35:48 --> Output Class Initialized
INFO - 2016-03-10 05:35:48 --> Security Class Initialized
DEBUG - 2016-03-10 05:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:35:48 --> Input Class Initialized
INFO - 2016-03-10 05:35:48 --> Language Class Initialized
INFO - 2016-03-10 05:35:48 --> Loader Class Initialized
INFO - 2016-03-10 05:35:48 --> Helper loaded: url_helper
INFO - 2016-03-10 05:35:48 --> Helper loaded: file_helper
INFO - 2016-03-10 05:35:48 --> Helper loaded: date_helper
INFO - 2016-03-10 05:35:48 --> Helper loaded: form_helper
INFO - 2016-03-10 05:35:48 --> Database Driver Class Initialized
INFO - 2016-03-10 05:35:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:35:50 --> Controller Class Initialized
INFO - 2016-03-10 05:35:50 --> Model Class Initialized
INFO - 2016-03-10 05:35:50 --> Model Class Initialized
INFO - 2016-03-10 05:35:50 --> Form Validation Class Initialized
INFO - 2016-03-10 05:35:50 --> Helper loaded: text_helper
INFO - 2016-03-10 05:35:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 05:35:50 --> Final output sent to browser
DEBUG - 2016-03-10 05:35:50 --> Total execution time: 1.1122
INFO - 2016-03-10 05:37:07 --> Config Class Initialized
INFO - 2016-03-10 05:37:07 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:37:07 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:37:07 --> Utf8 Class Initialized
INFO - 2016-03-10 05:37:07 --> URI Class Initialized
DEBUG - 2016-03-10 05:37:07 --> No URI present. Default controller set.
INFO - 2016-03-10 05:37:07 --> Router Class Initialized
INFO - 2016-03-10 05:37:07 --> Output Class Initialized
INFO - 2016-03-10 05:37:07 --> Security Class Initialized
DEBUG - 2016-03-10 05:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:37:07 --> Input Class Initialized
INFO - 2016-03-10 05:37:07 --> Language Class Initialized
INFO - 2016-03-10 05:37:07 --> Loader Class Initialized
INFO - 2016-03-10 05:37:07 --> Helper loaded: url_helper
INFO - 2016-03-10 05:37:07 --> Helper loaded: file_helper
INFO - 2016-03-10 05:37:07 --> Helper loaded: date_helper
INFO - 2016-03-10 05:37:07 --> Helper loaded: form_helper
INFO - 2016-03-10 05:37:07 --> Database Driver Class Initialized
INFO - 2016-03-10 05:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:37:08 --> Controller Class Initialized
INFO - 2016-03-10 05:37:08 --> Model Class Initialized
INFO - 2016-03-10 05:37:08 --> Model Class Initialized
INFO - 2016-03-10 05:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:37:08 --> Pagination Class Initialized
INFO - 2016-03-10 05:37:08 --> Helper loaded: text_helper
INFO - 2016-03-10 05:37:08 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:37:08 --> Final output sent to browser
DEBUG - 2016-03-10 08:37:08 --> Total execution time: 1.1887
INFO - 2016-03-10 05:37:32 --> Config Class Initialized
INFO - 2016-03-10 05:37:32 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:37:32 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:37:32 --> Utf8 Class Initialized
INFO - 2016-03-10 05:37:32 --> URI Class Initialized
INFO - 2016-03-10 05:37:32 --> Router Class Initialized
INFO - 2016-03-10 05:37:32 --> Output Class Initialized
INFO - 2016-03-10 05:37:32 --> Security Class Initialized
DEBUG - 2016-03-10 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:37:32 --> Input Class Initialized
INFO - 2016-03-10 05:37:32 --> Language Class Initialized
INFO - 2016-03-10 05:37:32 --> Loader Class Initialized
INFO - 2016-03-10 05:37:32 --> Helper loaded: url_helper
INFO - 2016-03-10 05:37:32 --> Helper loaded: file_helper
INFO - 2016-03-10 05:37:32 --> Helper loaded: date_helper
INFO - 2016-03-10 05:37:32 --> Helper loaded: form_helper
INFO - 2016-03-10 05:37:32 --> Database Driver Class Initialized
INFO - 2016-03-10 05:37:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:37:33 --> Controller Class Initialized
INFO - 2016-03-10 05:37:33 --> Model Class Initialized
INFO - 2016-03-10 05:37:33 --> Model Class Initialized
INFO - 2016-03-10 05:37:33 --> Form Validation Class Initialized
INFO - 2016-03-10 05:37:33 --> Helper loaded: text_helper
INFO - 2016-03-10 05:37:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 05:37:33 --> Final output sent to browser
DEBUG - 2016-03-10 05:37:33 --> Total execution time: 1.2321
INFO - 2016-03-10 05:37:34 --> Config Class Initialized
INFO - 2016-03-10 05:37:34 --> Hooks Class Initialized
DEBUG - 2016-03-10 05:37:34 --> UTF-8 Support Enabled
INFO - 2016-03-10 05:37:34 --> Utf8 Class Initialized
INFO - 2016-03-10 05:37:34 --> URI Class Initialized
DEBUG - 2016-03-10 05:37:34 --> No URI present. Default controller set.
INFO - 2016-03-10 05:37:34 --> Router Class Initialized
INFO - 2016-03-10 05:37:34 --> Output Class Initialized
INFO - 2016-03-10 05:37:34 --> Security Class Initialized
DEBUG - 2016-03-10 05:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 05:37:34 --> Input Class Initialized
INFO - 2016-03-10 05:37:34 --> Language Class Initialized
INFO - 2016-03-10 05:37:34 --> Loader Class Initialized
INFO - 2016-03-10 05:37:34 --> Helper loaded: url_helper
INFO - 2016-03-10 05:37:34 --> Helper loaded: file_helper
INFO - 2016-03-10 05:37:34 --> Helper loaded: date_helper
INFO - 2016-03-10 05:37:34 --> Helper loaded: form_helper
INFO - 2016-03-10 05:37:34 --> Database Driver Class Initialized
INFO - 2016-03-10 05:37:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 05:37:35 --> Controller Class Initialized
INFO - 2016-03-10 05:37:35 --> Model Class Initialized
INFO - 2016-03-10 05:37:35 --> Model Class Initialized
INFO - 2016-03-10 05:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 05:37:35 --> Pagination Class Initialized
INFO - 2016-03-10 05:37:35 --> Helper loaded: text_helper
INFO - 2016-03-10 05:37:35 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 08:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 08:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 08:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 08:37:35 --> Final output sent to browser
DEBUG - 2016-03-10 08:37:35 --> Total execution time: 1.1494
INFO - 2016-03-10 08:48:37 --> Config Class Initialized
INFO - 2016-03-10 08:48:37 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:48:37 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:48:37 --> Utf8 Class Initialized
INFO - 2016-03-10 08:48:37 --> URI Class Initialized
DEBUG - 2016-03-10 08:48:37 --> No URI present. Default controller set.
INFO - 2016-03-10 08:48:37 --> Router Class Initialized
INFO - 2016-03-10 08:48:37 --> Output Class Initialized
INFO - 2016-03-10 08:48:37 --> Security Class Initialized
DEBUG - 2016-03-10 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:48:37 --> Input Class Initialized
INFO - 2016-03-10 08:48:37 --> Language Class Initialized
INFO - 2016-03-10 08:48:37 --> Loader Class Initialized
INFO - 2016-03-10 08:48:37 --> Helper loaded: url_helper
INFO - 2016-03-10 08:48:37 --> Helper loaded: file_helper
INFO - 2016-03-10 08:48:37 --> Helper loaded: date_helper
INFO - 2016-03-10 08:48:37 --> Helper loaded: form_helper
INFO - 2016-03-10 08:48:37 --> Database Driver Class Initialized
INFO - 2016-03-10 08:48:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:48:38 --> Controller Class Initialized
INFO - 2016-03-10 08:48:39 --> Model Class Initialized
INFO - 2016-03-10 08:48:39 --> Model Class Initialized
INFO - 2016-03-10 08:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:48:39 --> Pagination Class Initialized
INFO - 2016-03-10 08:48:39 --> Helper loaded: text_helper
INFO - 2016-03-10 08:48:39 --> Helper loaded: cookie_helper
INFO - 2016-03-10 11:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 11:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 11:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 11:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 11:48:39 --> Final output sent to browser
DEBUG - 2016-03-10 11:48:39 --> Total execution time: 1.1521
INFO - 2016-03-10 08:48:56 --> Config Class Initialized
INFO - 2016-03-10 08:48:56 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:48:56 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:48:56 --> Utf8 Class Initialized
INFO - 2016-03-10 08:48:56 --> URI Class Initialized
INFO - 2016-03-10 08:48:56 --> Router Class Initialized
INFO - 2016-03-10 08:48:56 --> Output Class Initialized
INFO - 2016-03-10 08:48:56 --> Security Class Initialized
DEBUG - 2016-03-10 08:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:48:56 --> Input Class Initialized
INFO - 2016-03-10 08:48:56 --> Language Class Initialized
INFO - 2016-03-10 08:48:56 --> Loader Class Initialized
INFO - 2016-03-10 08:48:56 --> Helper loaded: url_helper
INFO - 2016-03-10 08:48:56 --> Helper loaded: file_helper
INFO - 2016-03-10 08:48:56 --> Helper loaded: date_helper
INFO - 2016-03-10 08:48:56 --> Helper loaded: form_helper
INFO - 2016-03-10 08:48:56 --> Database Driver Class Initialized
INFO - 2016-03-10 08:48:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:48:57 --> Controller Class Initialized
INFO - 2016-03-10 08:48:57 --> Model Class Initialized
INFO - 2016-03-10 08:48:57 --> Model Class Initialized
INFO - 2016-03-10 08:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:48:57 --> Pagination Class Initialized
INFO - 2016-03-10 08:48:57 --> Helper loaded: text_helper
INFO - 2016-03-10 08:48:57 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:48:57 --> Form Validation Class Initialized
INFO - 2016-03-10 11:48:58 --> Email Class Initialized
INFO - 2016-03-10 11:48:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-10 11:48:58 --> Email class already loaded. Second attempt ignored.
INFO - 2016-03-10 11:48:58 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-10 11:48:59 --> Final output sent to browser
DEBUG - 2016-03-10 11:48:59 --> Total execution time: 2.4576
INFO - 2016-03-10 08:50:14 --> Config Class Initialized
INFO - 2016-03-10 08:50:14 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:50:14 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:50:14 --> Utf8 Class Initialized
INFO - 2016-03-10 08:50:14 --> URI Class Initialized
DEBUG - 2016-03-10 08:50:14 --> No URI present. Default controller set.
INFO - 2016-03-10 08:50:14 --> Router Class Initialized
INFO - 2016-03-10 08:50:14 --> Output Class Initialized
INFO - 2016-03-10 08:50:14 --> Security Class Initialized
DEBUG - 2016-03-10 08:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:50:14 --> Input Class Initialized
INFO - 2016-03-10 08:50:14 --> Language Class Initialized
INFO - 2016-03-10 08:50:14 --> Loader Class Initialized
INFO - 2016-03-10 08:50:14 --> Helper loaded: url_helper
INFO - 2016-03-10 08:50:14 --> Helper loaded: file_helper
INFO - 2016-03-10 08:50:14 --> Helper loaded: date_helper
INFO - 2016-03-10 08:50:14 --> Helper loaded: form_helper
INFO - 2016-03-10 08:50:14 --> Database Driver Class Initialized
INFO - 2016-03-10 08:50:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:50:15 --> Controller Class Initialized
INFO - 2016-03-10 08:50:15 --> Model Class Initialized
INFO - 2016-03-10 08:50:15 --> Model Class Initialized
INFO - 2016-03-10 08:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:50:15 --> Pagination Class Initialized
INFO - 2016-03-10 08:50:15 --> Helper loaded: text_helper
INFO - 2016-03-10 08:50:15 --> Helper loaded: cookie_helper
INFO - 2016-03-10 11:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 11:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 11:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 11:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 11:50:16 --> Final output sent to browser
DEBUG - 2016-03-10 11:50:16 --> Total execution time: 1.1041
INFO - 2016-03-10 08:50:30 --> Config Class Initialized
INFO - 2016-03-10 08:50:30 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:50:30 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:50:30 --> Utf8 Class Initialized
INFO - 2016-03-10 08:50:30 --> URI Class Initialized
INFO - 2016-03-10 08:50:30 --> Router Class Initialized
INFO - 2016-03-10 08:50:30 --> Output Class Initialized
INFO - 2016-03-10 08:50:30 --> Security Class Initialized
DEBUG - 2016-03-10 08:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:50:30 --> Input Class Initialized
INFO - 2016-03-10 08:50:30 --> Language Class Initialized
INFO - 2016-03-10 08:50:30 --> Loader Class Initialized
INFO - 2016-03-10 08:50:30 --> Helper loaded: url_helper
INFO - 2016-03-10 08:50:30 --> Helper loaded: file_helper
INFO - 2016-03-10 08:50:30 --> Helper loaded: date_helper
INFO - 2016-03-10 08:50:30 --> Helper loaded: form_helper
INFO - 2016-03-10 08:50:30 --> Database Driver Class Initialized
INFO - 2016-03-10 08:50:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:50:31 --> Controller Class Initialized
INFO - 2016-03-10 08:50:31 --> Model Class Initialized
INFO - 2016-03-10 08:50:31 --> Model Class Initialized
INFO - 2016-03-10 08:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:50:31 --> Pagination Class Initialized
INFO - 2016-03-10 08:50:31 --> Helper loaded: text_helper
INFO - 2016-03-10 08:50:31 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:50:31 --> Form Validation Class Initialized
INFO - 2016-03-10 11:50:31 --> Email Class Initialized
INFO - 2016-03-10 11:50:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 11:50:31 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-10 11:50:31 --> Final output sent to browser
DEBUG - 2016-03-10 11:50:31 --> Total execution time: 1.7263
INFO - 2016-03-10 08:51:57 --> Config Class Initialized
INFO - 2016-03-10 08:51:57 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:51:57 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:51:57 --> Utf8 Class Initialized
INFO - 2016-03-10 08:51:57 --> URI Class Initialized
DEBUG - 2016-03-10 08:51:57 --> No URI present. Default controller set.
INFO - 2016-03-10 08:51:57 --> Router Class Initialized
INFO - 2016-03-10 08:51:57 --> Output Class Initialized
INFO - 2016-03-10 08:51:57 --> Security Class Initialized
DEBUG - 2016-03-10 08:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:51:57 --> Input Class Initialized
INFO - 2016-03-10 08:51:57 --> Language Class Initialized
INFO - 2016-03-10 08:51:57 --> Loader Class Initialized
INFO - 2016-03-10 08:51:57 --> Helper loaded: url_helper
INFO - 2016-03-10 08:51:57 --> Helper loaded: file_helper
INFO - 2016-03-10 08:51:57 --> Helper loaded: date_helper
INFO - 2016-03-10 08:51:57 --> Helper loaded: form_helper
INFO - 2016-03-10 08:51:57 --> Database Driver Class Initialized
INFO - 2016-03-10 08:51:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:51:58 --> Controller Class Initialized
INFO - 2016-03-10 08:51:58 --> Model Class Initialized
INFO - 2016-03-10 08:51:58 --> Model Class Initialized
INFO - 2016-03-10 08:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:51:58 --> Pagination Class Initialized
INFO - 2016-03-10 08:51:58 --> Helper loaded: text_helper
INFO - 2016-03-10 08:51:58 --> Helper loaded: cookie_helper
INFO - 2016-03-10 11:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 11:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 11:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 11:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 11:51:58 --> Final output sent to browser
DEBUG - 2016-03-10 11:51:58 --> Total execution time: 1.1619
INFO - 2016-03-10 08:52:11 --> Config Class Initialized
INFO - 2016-03-10 08:52:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 08:52:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 08:52:11 --> Utf8 Class Initialized
INFO - 2016-03-10 08:52:11 --> URI Class Initialized
INFO - 2016-03-10 08:52:11 --> Router Class Initialized
INFO - 2016-03-10 08:52:11 --> Output Class Initialized
INFO - 2016-03-10 08:52:11 --> Security Class Initialized
DEBUG - 2016-03-10 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 08:52:11 --> Input Class Initialized
INFO - 2016-03-10 08:52:11 --> Language Class Initialized
INFO - 2016-03-10 08:52:11 --> Loader Class Initialized
INFO - 2016-03-10 08:52:11 --> Helper loaded: url_helper
INFO - 2016-03-10 08:52:11 --> Helper loaded: file_helper
INFO - 2016-03-10 08:52:11 --> Helper loaded: date_helper
INFO - 2016-03-10 08:52:11 --> Helper loaded: form_helper
INFO - 2016-03-10 08:52:11 --> Database Driver Class Initialized
INFO - 2016-03-10 08:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 08:52:12 --> Controller Class Initialized
INFO - 2016-03-10 08:52:12 --> Model Class Initialized
INFO - 2016-03-10 08:52:12 --> Model Class Initialized
INFO - 2016-03-10 08:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 08:52:12 --> Pagination Class Initialized
INFO - 2016-03-10 08:52:12 --> Helper loaded: text_helper
INFO - 2016-03-10 08:52:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 08:52:12 --> Form Validation Class Initialized
INFO - 2016-03-10 11:52:12 --> Email Class Initialized
INFO - 2016-03-10 11:52:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 11:52:12 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-10 11:52:13 --> Final output sent to browser
DEBUG - 2016-03-10 11:52:13 --> Total execution time: 2.6929
INFO - 2016-03-10 13:21:19 --> Config Class Initialized
INFO - 2016-03-10 13:21:19 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:21:19 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:21:19 --> Utf8 Class Initialized
INFO - 2016-03-10 13:21:19 --> URI Class Initialized
DEBUG - 2016-03-10 13:21:19 --> No URI present. Default controller set.
INFO - 2016-03-10 13:21:19 --> Router Class Initialized
INFO - 2016-03-10 13:21:19 --> Output Class Initialized
INFO - 2016-03-10 13:21:19 --> Security Class Initialized
DEBUG - 2016-03-10 13:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:21:19 --> Input Class Initialized
INFO - 2016-03-10 13:21:19 --> Language Class Initialized
INFO - 2016-03-10 13:21:19 --> Loader Class Initialized
INFO - 2016-03-10 13:21:19 --> Helper loaded: url_helper
INFO - 2016-03-10 13:21:19 --> Helper loaded: file_helper
INFO - 2016-03-10 13:21:19 --> Helper loaded: date_helper
INFO - 2016-03-10 13:21:19 --> Helper loaded: form_helper
INFO - 2016-03-10 13:21:19 --> Database Driver Class Initialized
INFO - 2016-03-10 13:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:21:20 --> Controller Class Initialized
INFO - 2016-03-10 13:21:20 --> Model Class Initialized
INFO - 2016-03-10 13:21:20 --> Model Class Initialized
INFO - 2016-03-10 13:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:21:20 --> Pagination Class Initialized
INFO - 2016-03-10 13:21:20 --> Helper loaded: text_helper
INFO - 2016-03-10 13:21:20 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 16:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:21:20 --> Final output sent to browser
DEBUG - 2016-03-10 16:21:20 --> Total execution time: 1.2019
INFO - 2016-03-10 13:21:24 --> Config Class Initialized
INFO - 2016-03-10 13:21:24 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:21:24 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:21:24 --> Utf8 Class Initialized
INFO - 2016-03-10 13:21:24 --> URI Class Initialized
INFO - 2016-03-10 13:21:24 --> Router Class Initialized
INFO - 2016-03-10 13:21:24 --> Output Class Initialized
INFO - 2016-03-10 13:21:24 --> Security Class Initialized
DEBUG - 2016-03-10 13:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:21:24 --> Input Class Initialized
INFO - 2016-03-10 13:21:24 --> Language Class Initialized
INFO - 2016-03-10 13:21:24 --> Loader Class Initialized
INFO - 2016-03-10 13:21:24 --> Helper loaded: url_helper
INFO - 2016-03-10 13:21:24 --> Helper loaded: file_helper
INFO - 2016-03-10 13:21:24 --> Helper loaded: date_helper
INFO - 2016-03-10 13:21:24 --> Helper loaded: form_helper
INFO - 2016-03-10 13:21:24 --> Database Driver Class Initialized
INFO - 2016-03-10 13:21:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:21:25 --> Controller Class Initialized
INFO - 2016-03-10 13:21:25 --> Model Class Initialized
INFO - 2016-03-10 13:21:25 --> Model Class Initialized
INFO - 2016-03-10 13:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:21:25 --> Pagination Class Initialized
INFO - 2016-03-10 13:21:25 --> Helper loaded: text_helper
INFO - 2016-03-10 13:21:25 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:21:25 --> Final output sent to browser
DEBUG - 2016-03-10 16:21:25 --> Total execution time: 1.2718
INFO - 2016-03-10 13:21:26 --> Config Class Initialized
INFO - 2016-03-10 13:21:26 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:21:26 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:21:26 --> Utf8 Class Initialized
INFO - 2016-03-10 13:21:26 --> URI Class Initialized
INFO - 2016-03-10 13:21:26 --> Router Class Initialized
INFO - 2016-03-10 13:21:26 --> Output Class Initialized
INFO - 2016-03-10 13:21:26 --> Security Class Initialized
DEBUG - 2016-03-10 13:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:21:26 --> Input Class Initialized
INFO - 2016-03-10 13:21:26 --> Language Class Initialized
INFO - 2016-03-10 13:21:26 --> Loader Class Initialized
INFO - 2016-03-10 13:21:26 --> Helper loaded: url_helper
INFO - 2016-03-10 13:21:26 --> Helper loaded: file_helper
INFO - 2016-03-10 13:21:26 --> Helper loaded: date_helper
INFO - 2016-03-10 13:21:26 --> Helper loaded: form_helper
INFO - 2016-03-10 13:21:26 --> Database Driver Class Initialized
INFO - 2016-03-10 13:21:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:21:27 --> Controller Class Initialized
INFO - 2016-03-10 13:21:27 --> Model Class Initialized
INFO - 2016-03-10 13:21:27 --> Model Class Initialized
INFO - 2016-03-10 13:21:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:21:27 --> Pagination Class Initialized
INFO - 2016-03-10 13:21:27 --> Helper loaded: text_helper
INFO - 2016-03-10 13:21:27 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:21:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:21:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:21:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:21:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:21:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:21:28 --> Final output sent to browser
DEBUG - 2016-03-10 16:21:28 --> Total execution time: 1.1694
INFO - 2016-03-10 13:21:29 --> Config Class Initialized
INFO - 2016-03-10 13:21:29 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:21:29 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:21:29 --> Utf8 Class Initialized
INFO - 2016-03-10 13:21:29 --> URI Class Initialized
INFO - 2016-03-10 13:21:29 --> Router Class Initialized
INFO - 2016-03-10 13:21:29 --> Output Class Initialized
INFO - 2016-03-10 13:21:29 --> Security Class Initialized
DEBUG - 2016-03-10 13:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:21:29 --> Input Class Initialized
INFO - 2016-03-10 13:21:29 --> Language Class Initialized
INFO - 2016-03-10 13:21:29 --> Loader Class Initialized
INFO - 2016-03-10 13:21:29 --> Helper loaded: url_helper
INFO - 2016-03-10 13:21:29 --> Helper loaded: file_helper
INFO - 2016-03-10 13:21:29 --> Helper loaded: date_helper
INFO - 2016-03-10 13:21:29 --> Helper loaded: form_helper
INFO - 2016-03-10 13:21:29 --> Database Driver Class Initialized
INFO - 2016-03-10 13:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:21:30 --> Controller Class Initialized
INFO - 2016-03-10 13:21:30 --> Model Class Initialized
INFO - 2016-03-10 13:21:30 --> Model Class Initialized
INFO - 2016-03-10 13:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:21:30 --> Pagination Class Initialized
INFO - 2016-03-10 13:21:30 --> Helper loaded: text_helper
INFO - 2016-03-10 13:21:30 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:21:30 --> Final output sent to browser
DEBUG - 2016-03-10 16:21:30 --> Total execution time: 1.1065
INFO - 2016-03-10 13:22:04 --> Config Class Initialized
INFO - 2016-03-10 13:22:04 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:22:04 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:22:04 --> Utf8 Class Initialized
INFO - 2016-03-10 13:22:04 --> URI Class Initialized
INFO - 2016-03-10 13:22:04 --> Router Class Initialized
INFO - 2016-03-10 13:22:04 --> Output Class Initialized
INFO - 2016-03-10 13:22:04 --> Security Class Initialized
DEBUG - 2016-03-10 13:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:22:04 --> Input Class Initialized
INFO - 2016-03-10 13:22:04 --> Language Class Initialized
INFO - 2016-03-10 13:22:04 --> Loader Class Initialized
INFO - 2016-03-10 13:22:04 --> Helper loaded: url_helper
INFO - 2016-03-10 13:22:04 --> Helper loaded: file_helper
INFO - 2016-03-10 13:22:04 --> Helper loaded: date_helper
INFO - 2016-03-10 13:22:04 --> Helper loaded: form_helper
INFO - 2016-03-10 13:22:04 --> Database Driver Class Initialized
INFO - 2016-03-10 13:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:22:05 --> Controller Class Initialized
INFO - 2016-03-10 13:22:05 --> Model Class Initialized
INFO - 2016-03-10 13:22:05 --> Model Class Initialized
INFO - 2016-03-10 13:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:22:05 --> Pagination Class Initialized
INFO - 2016-03-10 13:22:05 --> Helper loaded: text_helper
INFO - 2016-03-10 13:22:05 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:22:05 --> Final output sent to browser
DEBUG - 2016-03-10 16:22:05 --> Total execution time: 1.2535
INFO - 2016-03-10 13:22:11 --> Config Class Initialized
INFO - 2016-03-10 13:22:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:22:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:22:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:22:11 --> URI Class Initialized
INFO - 2016-03-10 13:22:11 --> Router Class Initialized
INFO - 2016-03-10 13:22:11 --> Output Class Initialized
INFO - 2016-03-10 13:22:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:22:11 --> Input Class Initialized
INFO - 2016-03-10 13:22:11 --> Language Class Initialized
INFO - 2016-03-10 13:22:11 --> Loader Class Initialized
INFO - 2016-03-10 13:22:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:22:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:22:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:22:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:22:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:22:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:22:12 --> Controller Class Initialized
INFO - 2016-03-10 13:22:12 --> Model Class Initialized
INFO - 2016-03-10 13:22:12 --> Model Class Initialized
INFO - 2016-03-10 13:22:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:22:12 --> Pagination Class Initialized
INFO - 2016-03-10 13:22:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:22:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:22:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:22:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:22:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:22:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:22:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:22:12 --> Final output sent to browser
DEBUG - 2016-03-10 16:22:13 --> Total execution time: 1.1397
INFO - 2016-03-10 13:22:38 --> Config Class Initialized
INFO - 2016-03-10 13:22:38 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:22:38 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:22:38 --> Utf8 Class Initialized
INFO - 2016-03-10 13:22:38 --> URI Class Initialized
INFO - 2016-03-10 13:22:38 --> Router Class Initialized
INFO - 2016-03-10 13:22:38 --> Output Class Initialized
INFO - 2016-03-10 13:22:38 --> Security Class Initialized
DEBUG - 2016-03-10 13:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:22:38 --> Input Class Initialized
INFO - 2016-03-10 13:22:38 --> Language Class Initialized
INFO - 2016-03-10 13:22:39 --> Loader Class Initialized
INFO - 2016-03-10 13:22:39 --> Helper loaded: url_helper
INFO - 2016-03-10 13:22:39 --> Helper loaded: file_helper
INFO - 2016-03-10 13:22:39 --> Helper loaded: date_helper
INFO - 2016-03-10 13:22:39 --> Helper loaded: form_helper
INFO - 2016-03-10 13:22:39 --> Database Driver Class Initialized
INFO - 2016-03-10 13:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:22:40 --> Controller Class Initialized
INFO - 2016-03-10 13:22:40 --> Model Class Initialized
INFO - 2016-03-10 13:22:40 --> Model Class Initialized
INFO - 2016-03-10 13:22:40 --> Form Validation Class Initialized
INFO - 2016-03-10 13:22:40 --> Helper loaded: text_helper
INFO - 2016-03-10 13:22:40 --> Final output sent to browser
DEBUG - 2016-03-10 13:22:40 --> Total execution time: 1.2010
INFO - 2016-03-10 13:22:49 --> Config Class Initialized
INFO - 2016-03-10 13:22:49 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:22:49 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:22:49 --> Utf8 Class Initialized
INFO - 2016-03-10 13:22:49 --> URI Class Initialized
INFO - 2016-03-10 13:22:49 --> Router Class Initialized
INFO - 2016-03-10 13:22:49 --> Output Class Initialized
INFO - 2016-03-10 13:22:49 --> Security Class Initialized
DEBUG - 2016-03-10 13:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:22:49 --> Input Class Initialized
INFO - 2016-03-10 13:22:49 --> Language Class Initialized
INFO - 2016-03-10 13:22:49 --> Loader Class Initialized
INFO - 2016-03-10 13:22:49 --> Helper loaded: url_helper
INFO - 2016-03-10 13:22:49 --> Helper loaded: file_helper
INFO - 2016-03-10 13:22:49 --> Helper loaded: date_helper
INFO - 2016-03-10 13:22:49 --> Helper loaded: form_helper
INFO - 2016-03-10 13:22:49 --> Database Driver Class Initialized
INFO - 2016-03-10 13:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:22:50 --> Controller Class Initialized
INFO - 2016-03-10 13:22:50 --> Model Class Initialized
INFO - 2016-03-10 13:22:50 --> Model Class Initialized
INFO - 2016-03-10 13:22:50 --> Form Validation Class Initialized
INFO - 2016-03-10 13:22:50 --> Helper loaded: text_helper
INFO - 2016-03-10 13:22:50 --> Final output sent to browser
DEBUG - 2016-03-10 13:22:50 --> Total execution time: 1.0989
INFO - 2016-03-10 13:23:00 --> Config Class Initialized
INFO - 2016-03-10 13:23:00 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:23:00 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:23:00 --> Utf8 Class Initialized
INFO - 2016-03-10 13:23:00 --> URI Class Initialized
INFO - 2016-03-10 13:23:00 --> Router Class Initialized
INFO - 2016-03-10 13:23:00 --> Output Class Initialized
INFO - 2016-03-10 13:23:00 --> Security Class Initialized
DEBUG - 2016-03-10 13:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:23:00 --> Input Class Initialized
INFO - 2016-03-10 13:23:00 --> Language Class Initialized
INFO - 2016-03-10 13:23:00 --> Loader Class Initialized
INFO - 2016-03-10 13:23:00 --> Helper loaded: url_helper
INFO - 2016-03-10 13:23:00 --> Helper loaded: file_helper
INFO - 2016-03-10 13:23:00 --> Helper loaded: date_helper
INFO - 2016-03-10 13:23:00 --> Helper loaded: form_helper
INFO - 2016-03-10 13:23:00 --> Database Driver Class Initialized
INFO - 2016-03-10 13:23:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:23:01 --> Controller Class Initialized
INFO - 2016-03-10 13:23:01 --> Model Class Initialized
INFO - 2016-03-10 13:23:01 --> Model Class Initialized
INFO - 2016-03-10 13:23:01 --> Form Validation Class Initialized
INFO - 2016-03-10 13:23:01 --> Helper loaded: text_helper
INFO - 2016-03-10 13:23:01 --> Final output sent to browser
DEBUG - 2016-03-10 13:23:01 --> Total execution time: 1.1082
INFO - 2016-03-10 13:23:12 --> Config Class Initialized
INFO - 2016-03-10 13:23:12 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:23:12 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:23:12 --> Utf8 Class Initialized
INFO - 2016-03-10 13:23:12 --> URI Class Initialized
INFO - 2016-03-10 13:23:12 --> Router Class Initialized
INFO - 2016-03-10 13:23:12 --> Output Class Initialized
INFO - 2016-03-10 13:23:12 --> Security Class Initialized
DEBUG - 2016-03-10 13:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:23:12 --> Input Class Initialized
INFO - 2016-03-10 13:23:12 --> Language Class Initialized
INFO - 2016-03-10 13:23:12 --> Loader Class Initialized
INFO - 2016-03-10 13:23:12 --> Helper loaded: url_helper
INFO - 2016-03-10 13:23:12 --> Helper loaded: file_helper
INFO - 2016-03-10 13:23:12 --> Helper loaded: date_helper
INFO - 2016-03-10 13:23:12 --> Helper loaded: form_helper
INFO - 2016-03-10 13:23:12 --> Database Driver Class Initialized
INFO - 2016-03-10 13:23:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:23:13 --> Controller Class Initialized
INFO - 2016-03-10 13:23:13 --> Model Class Initialized
INFO - 2016-03-10 13:23:13 --> Model Class Initialized
INFO - 2016-03-10 13:23:13 --> Form Validation Class Initialized
INFO - 2016-03-10 13:23:13 --> Helper loaded: text_helper
INFO - 2016-03-10 13:23:13 --> Final output sent to browser
DEBUG - 2016-03-10 13:23:13 --> Total execution time: 1.1088
INFO - 2016-03-10 13:23:34 --> Config Class Initialized
INFO - 2016-03-10 13:23:34 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:23:34 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:23:34 --> Utf8 Class Initialized
INFO - 2016-03-10 13:23:34 --> URI Class Initialized
INFO - 2016-03-10 13:23:34 --> Router Class Initialized
INFO - 2016-03-10 13:23:34 --> Output Class Initialized
INFO - 2016-03-10 13:23:34 --> Security Class Initialized
DEBUG - 2016-03-10 13:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:23:34 --> Input Class Initialized
INFO - 2016-03-10 13:23:34 --> Language Class Initialized
INFO - 2016-03-10 13:23:34 --> Loader Class Initialized
INFO - 2016-03-10 13:23:34 --> Helper loaded: url_helper
INFO - 2016-03-10 13:23:35 --> Helper loaded: file_helper
INFO - 2016-03-10 13:23:35 --> Helper loaded: date_helper
INFO - 2016-03-10 13:23:35 --> Helper loaded: form_helper
INFO - 2016-03-10 13:23:35 --> Database Driver Class Initialized
INFO - 2016-03-10 13:23:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:23:36 --> Controller Class Initialized
INFO - 2016-03-10 13:23:36 --> Model Class Initialized
INFO - 2016-03-10 13:23:36 --> Model Class Initialized
INFO - 2016-03-10 13:23:36 --> Form Validation Class Initialized
INFO - 2016-03-10 13:23:36 --> Helper loaded: text_helper
INFO - 2016-03-10 13:23:36 --> Final output sent to browser
DEBUG - 2016-03-10 13:23:36 --> Total execution time: 1.1118
INFO - 2016-03-10 13:24:03 --> Config Class Initialized
INFO - 2016-03-10 13:24:03 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:03 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:03 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:03 --> URI Class Initialized
INFO - 2016-03-10 13:24:03 --> Router Class Initialized
INFO - 2016-03-10 13:24:03 --> Output Class Initialized
INFO - 2016-03-10 13:24:03 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:03 --> Input Class Initialized
INFO - 2016-03-10 13:24:03 --> Language Class Initialized
INFO - 2016-03-10 13:24:03 --> Loader Class Initialized
INFO - 2016-03-10 13:24:03 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:03 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:03 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:03 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:03 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:04 --> Controller Class Initialized
INFO - 2016-03-10 13:24:04 --> Model Class Initialized
INFO - 2016-03-10 13:24:04 --> Model Class Initialized
INFO - 2016-03-10 13:24:04 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:04 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:04 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:04 --> Total execution time: 1.1946
INFO - 2016-03-10 13:24:11 --> Config Class Initialized
INFO - 2016-03-10 13:24:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:11 --> URI Class Initialized
INFO - 2016-03-10 13:24:11 --> Router Class Initialized
INFO - 2016-03-10 13:24:11 --> Output Class Initialized
INFO - 2016-03-10 13:24:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:11 --> Input Class Initialized
INFO - 2016-03-10 13:24:11 --> Language Class Initialized
INFO - 2016-03-10 13:24:11 --> Loader Class Initialized
INFO - 2016-03-10 13:24:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:12 --> Controller Class Initialized
INFO - 2016-03-10 13:24:12 --> Model Class Initialized
INFO - 2016-03-10 13:24:12 --> Model Class Initialized
INFO - 2016-03-10 13:24:12 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:12 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:12 --> Total execution time: 1.0809
INFO - 2016-03-10 13:24:18 --> Config Class Initialized
INFO - 2016-03-10 13:24:18 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:18 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:18 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:18 --> URI Class Initialized
INFO - 2016-03-10 13:24:18 --> Router Class Initialized
INFO - 2016-03-10 13:24:18 --> Output Class Initialized
INFO - 2016-03-10 13:24:19 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:19 --> Input Class Initialized
INFO - 2016-03-10 13:24:19 --> Language Class Initialized
INFO - 2016-03-10 13:24:19 --> Loader Class Initialized
INFO - 2016-03-10 13:24:19 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:19 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:19 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:19 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:19 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:20 --> Controller Class Initialized
INFO - 2016-03-10 13:24:20 --> Model Class Initialized
INFO - 2016-03-10 13:24:20 --> Model Class Initialized
INFO - 2016-03-10 13:24:20 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:20 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:20 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:20 --> Total execution time: 1.0976
INFO - 2016-03-10 13:24:26 --> Config Class Initialized
INFO - 2016-03-10 13:24:26 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:26 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:26 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:26 --> URI Class Initialized
INFO - 2016-03-10 13:24:26 --> Router Class Initialized
INFO - 2016-03-10 13:24:26 --> Output Class Initialized
INFO - 2016-03-10 13:24:26 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:26 --> Input Class Initialized
INFO - 2016-03-10 13:24:26 --> Language Class Initialized
INFO - 2016-03-10 13:24:26 --> Loader Class Initialized
INFO - 2016-03-10 13:24:26 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:26 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:26 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:26 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:26 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:27 --> Controller Class Initialized
INFO - 2016-03-10 13:24:27 --> Model Class Initialized
INFO - 2016-03-10 13:24:27 --> Model Class Initialized
INFO - 2016-03-10 13:24:27 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:27 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:27 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:27 --> Total execution time: 1.0997
INFO - 2016-03-10 13:24:39 --> Config Class Initialized
INFO - 2016-03-10 13:24:39 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:39 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:39 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:39 --> URI Class Initialized
INFO - 2016-03-10 13:24:39 --> Router Class Initialized
INFO - 2016-03-10 13:24:39 --> Output Class Initialized
INFO - 2016-03-10 13:24:39 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:39 --> Input Class Initialized
INFO - 2016-03-10 13:24:39 --> Language Class Initialized
INFO - 2016-03-10 13:24:39 --> Loader Class Initialized
INFO - 2016-03-10 13:24:39 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:39 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:39 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:39 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:39 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:40 --> Controller Class Initialized
INFO - 2016-03-10 13:24:40 --> Model Class Initialized
INFO - 2016-03-10 13:24:40 --> Model Class Initialized
INFO - 2016-03-10 13:24:40 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:40 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:40 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:40 --> Total execution time: 1.2613
INFO - 2016-03-10 13:24:46 --> Config Class Initialized
INFO - 2016-03-10 13:24:46 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:46 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:46 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:46 --> URI Class Initialized
INFO - 2016-03-10 13:24:46 --> Router Class Initialized
INFO - 2016-03-10 13:24:46 --> Output Class Initialized
INFO - 2016-03-10 13:24:46 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:46 --> Input Class Initialized
INFO - 2016-03-10 13:24:46 --> Language Class Initialized
INFO - 2016-03-10 13:24:46 --> Loader Class Initialized
INFO - 2016-03-10 13:24:46 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:46 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:46 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:46 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:46 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:47 --> Controller Class Initialized
INFO - 2016-03-10 13:24:47 --> Model Class Initialized
INFO - 2016-03-10 13:24:47 --> Model Class Initialized
INFO - 2016-03-10 13:24:47 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:47 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:47 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:47 --> Total execution time: 1.1067
INFO - 2016-03-10 13:24:52 --> Config Class Initialized
INFO - 2016-03-10 13:24:52 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:24:52 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:24:52 --> Utf8 Class Initialized
INFO - 2016-03-10 13:24:52 --> URI Class Initialized
INFO - 2016-03-10 13:24:52 --> Router Class Initialized
INFO - 2016-03-10 13:24:52 --> Output Class Initialized
INFO - 2016-03-10 13:24:52 --> Security Class Initialized
DEBUG - 2016-03-10 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:24:52 --> Input Class Initialized
INFO - 2016-03-10 13:24:52 --> Language Class Initialized
INFO - 2016-03-10 13:24:52 --> Loader Class Initialized
INFO - 2016-03-10 13:24:52 --> Helper loaded: url_helper
INFO - 2016-03-10 13:24:52 --> Helper loaded: file_helper
INFO - 2016-03-10 13:24:52 --> Helper loaded: date_helper
INFO - 2016-03-10 13:24:52 --> Helper loaded: form_helper
INFO - 2016-03-10 13:24:52 --> Database Driver Class Initialized
INFO - 2016-03-10 13:24:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:24:53 --> Controller Class Initialized
INFO - 2016-03-10 13:24:53 --> Model Class Initialized
INFO - 2016-03-10 13:24:53 --> Model Class Initialized
INFO - 2016-03-10 13:24:53 --> Form Validation Class Initialized
INFO - 2016-03-10 13:24:53 --> Helper loaded: text_helper
INFO - 2016-03-10 13:24:53 --> Final output sent to browser
DEBUG - 2016-03-10 13:24:53 --> Total execution time: 1.1120
INFO - 2016-03-10 13:25:02 --> Config Class Initialized
INFO - 2016-03-10 13:25:02 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:25:02 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:25:02 --> Utf8 Class Initialized
INFO - 2016-03-10 13:25:02 --> URI Class Initialized
INFO - 2016-03-10 13:25:02 --> Router Class Initialized
INFO - 2016-03-10 13:25:02 --> Output Class Initialized
INFO - 2016-03-10 13:25:02 --> Security Class Initialized
DEBUG - 2016-03-10 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:25:02 --> Input Class Initialized
INFO - 2016-03-10 13:25:02 --> Language Class Initialized
INFO - 2016-03-10 13:25:02 --> Loader Class Initialized
INFO - 2016-03-10 13:25:02 --> Helper loaded: url_helper
INFO - 2016-03-10 13:25:02 --> Helper loaded: file_helper
INFO - 2016-03-10 13:25:02 --> Helper loaded: date_helper
INFO - 2016-03-10 13:25:02 --> Helper loaded: form_helper
INFO - 2016-03-10 13:25:02 --> Database Driver Class Initialized
INFO - 2016-03-10 13:25:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:25:03 --> Controller Class Initialized
INFO - 2016-03-10 13:25:03 --> Model Class Initialized
INFO - 2016-03-10 13:25:03 --> Model Class Initialized
INFO - 2016-03-10 13:25:03 --> Form Validation Class Initialized
INFO - 2016-03-10 13:25:03 --> Helper loaded: text_helper
INFO - 2016-03-10 13:25:03 --> Final output sent to browser
DEBUG - 2016-03-10 13:25:03 --> Total execution time: 1.0879
INFO - 2016-03-10 13:25:22 --> Config Class Initialized
INFO - 2016-03-10 13:25:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:25:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:25:22 --> Utf8 Class Initialized
INFO - 2016-03-10 13:25:22 --> URI Class Initialized
INFO - 2016-03-10 13:25:22 --> Router Class Initialized
INFO - 2016-03-10 13:25:22 --> Output Class Initialized
INFO - 2016-03-10 13:25:22 --> Security Class Initialized
DEBUG - 2016-03-10 13:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:25:22 --> Input Class Initialized
INFO - 2016-03-10 13:25:22 --> Language Class Initialized
INFO - 2016-03-10 13:25:22 --> Loader Class Initialized
INFO - 2016-03-10 13:25:22 --> Helper loaded: url_helper
INFO - 2016-03-10 13:25:22 --> Helper loaded: file_helper
INFO - 2016-03-10 13:25:22 --> Helper loaded: date_helper
INFO - 2016-03-10 13:25:22 --> Helper loaded: form_helper
INFO - 2016-03-10 13:25:22 --> Database Driver Class Initialized
INFO - 2016-03-10 13:25:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:25:23 --> Controller Class Initialized
INFO - 2016-03-10 13:25:23 --> Model Class Initialized
INFO - 2016-03-10 13:25:23 --> Model Class Initialized
INFO - 2016-03-10 13:25:23 --> Form Validation Class Initialized
INFO - 2016-03-10 13:25:23 --> Helper loaded: text_helper
INFO - 2016-03-10 13:25:23 --> Final output sent to browser
DEBUG - 2016-03-10 13:25:23 --> Total execution time: 1.0804
INFO - 2016-03-10 13:25:35 --> Config Class Initialized
INFO - 2016-03-10 13:25:35 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:25:35 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:25:35 --> Utf8 Class Initialized
INFO - 2016-03-10 13:25:35 --> URI Class Initialized
INFO - 2016-03-10 13:25:35 --> Router Class Initialized
INFO - 2016-03-10 13:25:35 --> Output Class Initialized
INFO - 2016-03-10 13:25:35 --> Security Class Initialized
DEBUG - 2016-03-10 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:25:35 --> Input Class Initialized
INFO - 2016-03-10 13:25:35 --> Language Class Initialized
INFO - 2016-03-10 13:25:35 --> Loader Class Initialized
INFO - 2016-03-10 13:25:35 --> Helper loaded: url_helper
INFO - 2016-03-10 13:25:35 --> Helper loaded: file_helper
INFO - 2016-03-10 13:25:35 --> Helper loaded: date_helper
INFO - 2016-03-10 13:25:35 --> Helper loaded: form_helper
INFO - 2016-03-10 13:25:35 --> Database Driver Class Initialized
INFO - 2016-03-10 13:25:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:25:36 --> Controller Class Initialized
INFO - 2016-03-10 13:25:36 --> Model Class Initialized
INFO - 2016-03-10 13:25:36 --> Model Class Initialized
INFO - 2016-03-10 13:25:36 --> Form Validation Class Initialized
INFO - 2016-03-10 13:25:36 --> Helper loaded: text_helper
INFO - 2016-03-10 13:25:36 --> Final output sent to browser
DEBUG - 2016-03-10 13:25:36 --> Total execution time: 1.2026
INFO - 2016-03-10 13:25:36 --> Config Class Initialized
INFO - 2016-03-10 13:25:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:25:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:25:36 --> Utf8 Class Initialized
INFO - 2016-03-10 13:25:36 --> URI Class Initialized
INFO - 2016-03-10 13:25:36 --> Router Class Initialized
INFO - 2016-03-10 13:25:36 --> Output Class Initialized
INFO - 2016-03-10 13:25:36 --> Security Class Initialized
DEBUG - 2016-03-10 13:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:25:36 --> Input Class Initialized
INFO - 2016-03-10 13:25:36 --> Language Class Initialized
INFO - 2016-03-10 13:25:36 --> Loader Class Initialized
INFO - 2016-03-10 13:25:36 --> Helper loaded: url_helper
INFO - 2016-03-10 13:25:36 --> Helper loaded: file_helper
INFO - 2016-03-10 13:25:36 --> Helper loaded: date_helper
INFO - 2016-03-10 13:25:36 --> Helper loaded: form_helper
INFO - 2016-03-10 13:25:36 --> Database Driver Class Initialized
INFO - 2016-03-10 13:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:25:37 --> Controller Class Initialized
INFO - 2016-03-10 13:25:37 --> Model Class Initialized
INFO - 2016-03-10 13:25:37 --> Model Class Initialized
INFO - 2016-03-10 13:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:25:37 --> Pagination Class Initialized
INFO - 2016-03-10 13:25:37 --> Helper loaded: text_helper
INFO - 2016-03-10 13:25:37 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:25:37 --> Final output sent to browser
DEBUG - 2016-03-10 16:25:37 --> Total execution time: 1.1101
INFO - 2016-03-10 13:26:22 --> Config Class Initialized
INFO - 2016-03-10 13:26:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:22 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:22 --> URI Class Initialized
INFO - 2016-03-10 13:26:22 --> Router Class Initialized
INFO - 2016-03-10 13:26:22 --> Output Class Initialized
INFO - 2016-03-10 13:26:22 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:22 --> Input Class Initialized
INFO - 2016-03-10 13:26:22 --> Language Class Initialized
INFO - 2016-03-10 13:26:22 --> Loader Class Initialized
INFO - 2016-03-10 13:26:22 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:22 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:22 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:22 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:22 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:23 --> Controller Class Initialized
INFO - 2016-03-10 13:26:23 --> Model Class Initialized
INFO - 2016-03-10 13:26:23 --> Model Class Initialized
INFO - 2016-03-10 13:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:23 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:23 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:26:23 --> Final output sent to browser
DEBUG - 2016-03-10 16:26:23 --> Total execution time: 1.1522
INFO - 2016-03-10 13:26:36 --> Config Class Initialized
INFO - 2016-03-10 13:26:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:36 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:36 --> URI Class Initialized
INFO - 2016-03-10 13:26:36 --> Router Class Initialized
INFO - 2016-03-10 13:26:36 --> Output Class Initialized
INFO - 2016-03-10 13:26:36 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:36 --> Input Class Initialized
INFO - 2016-03-10 13:26:36 --> Language Class Initialized
INFO - 2016-03-10 13:26:36 --> Loader Class Initialized
INFO - 2016-03-10 13:26:36 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:36 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:36 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:36 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:36 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:37 --> Controller Class Initialized
INFO - 2016-03-10 13:26:37 --> Model Class Initialized
INFO - 2016-03-10 13:26:37 --> Model Class Initialized
INFO - 2016-03-10 13:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:37 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:37 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:37 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:26:37 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:37 --> Form Validation Class Initialized
INFO - 2016-03-10 16:26:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:26:38 --> Config Class Initialized
INFO - 2016-03-10 13:26:38 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:38 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:38 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:38 --> URI Class Initialized
INFO - 2016-03-10 13:26:38 --> Router Class Initialized
INFO - 2016-03-10 13:26:38 --> Output Class Initialized
INFO - 2016-03-10 13:26:38 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:38 --> Input Class Initialized
INFO - 2016-03-10 13:26:38 --> Language Class Initialized
INFO - 2016-03-10 13:26:38 --> Loader Class Initialized
INFO - 2016-03-10 13:26:38 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:38 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:38 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:38 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:38 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:39 --> Controller Class Initialized
INFO - 2016-03-10 13:26:39 --> Model Class Initialized
INFO - 2016-03-10 13:26:39 --> Model Class Initialized
INFO - 2016-03-10 13:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:39 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:39 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:39 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:26:39 --> Final output sent to browser
DEBUG - 2016-03-10 16:26:39 --> Total execution time: 1.2604
INFO - 2016-03-10 13:26:43 --> Config Class Initialized
INFO - 2016-03-10 13:26:43 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:43 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:43 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:43 --> URI Class Initialized
INFO - 2016-03-10 13:26:43 --> Router Class Initialized
INFO - 2016-03-10 13:26:43 --> Output Class Initialized
INFO - 2016-03-10 13:26:43 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:43 --> Input Class Initialized
INFO - 2016-03-10 13:26:43 --> Language Class Initialized
INFO - 2016-03-10 13:26:43 --> Loader Class Initialized
INFO - 2016-03-10 13:26:43 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:43 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:43 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:43 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:43 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:44 --> Controller Class Initialized
INFO - 2016-03-10 13:26:44 --> Model Class Initialized
INFO - 2016-03-10 13:26:44 --> Model Class Initialized
INFO - 2016-03-10 13:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:44 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:44 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:44 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:26:45 --> Final output sent to browser
DEBUG - 2016-03-10 16:26:45 --> Total execution time: 1.0868
INFO - 2016-03-10 13:26:54 --> Config Class Initialized
INFO - 2016-03-10 13:26:54 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:54 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:54 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:54 --> URI Class Initialized
INFO - 2016-03-10 13:26:54 --> Router Class Initialized
INFO - 2016-03-10 13:26:54 --> Output Class Initialized
INFO - 2016-03-10 13:26:54 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:54 --> Input Class Initialized
INFO - 2016-03-10 13:26:54 --> Language Class Initialized
INFO - 2016-03-10 13:26:54 --> Loader Class Initialized
INFO - 2016-03-10 13:26:54 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:54 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:54 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:54 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:54 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:55 --> Controller Class Initialized
INFO - 2016-03-10 13:26:55 --> Model Class Initialized
INFO - 2016-03-10 13:26:55 --> Model Class Initialized
INFO - 2016-03-10 13:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:55 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:55 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:55 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:26:55 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:55 --> Form Validation Class Initialized
INFO - 2016-03-10 16:26:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:26:56 --> Config Class Initialized
INFO - 2016-03-10 13:26:56 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:26:56 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:26:56 --> Utf8 Class Initialized
INFO - 2016-03-10 13:26:56 --> URI Class Initialized
INFO - 2016-03-10 13:26:56 --> Router Class Initialized
INFO - 2016-03-10 13:26:56 --> Output Class Initialized
INFO - 2016-03-10 13:26:56 --> Security Class Initialized
DEBUG - 2016-03-10 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:26:56 --> Input Class Initialized
INFO - 2016-03-10 13:26:56 --> Language Class Initialized
INFO - 2016-03-10 13:26:56 --> Loader Class Initialized
INFO - 2016-03-10 13:26:56 --> Helper loaded: url_helper
INFO - 2016-03-10 13:26:56 --> Helper loaded: file_helper
INFO - 2016-03-10 13:26:56 --> Helper loaded: date_helper
INFO - 2016-03-10 13:26:56 --> Helper loaded: form_helper
INFO - 2016-03-10 13:26:56 --> Database Driver Class Initialized
INFO - 2016-03-10 13:26:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:26:57 --> Controller Class Initialized
INFO - 2016-03-10 13:26:57 --> Model Class Initialized
INFO - 2016-03-10 13:26:57 --> Model Class Initialized
INFO - 2016-03-10 13:26:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:26:57 --> Pagination Class Initialized
INFO - 2016-03-10 13:26:57 --> Helper loaded: text_helper
INFO - 2016-03-10 13:26:57 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:26:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:26:57 --> Final output sent to browser
DEBUG - 2016-03-10 16:26:57 --> Total execution time: 1.1688
INFO - 2016-03-10 13:27:01 --> Config Class Initialized
INFO - 2016-03-10 13:27:01 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:27:01 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:27:01 --> Utf8 Class Initialized
INFO - 2016-03-10 13:27:01 --> URI Class Initialized
INFO - 2016-03-10 13:27:01 --> Router Class Initialized
INFO - 2016-03-10 13:27:01 --> Output Class Initialized
INFO - 2016-03-10 13:27:01 --> Security Class Initialized
DEBUG - 2016-03-10 13:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:27:01 --> Input Class Initialized
INFO - 2016-03-10 13:27:01 --> Language Class Initialized
INFO - 2016-03-10 13:27:01 --> Loader Class Initialized
INFO - 2016-03-10 13:27:01 --> Helper loaded: url_helper
INFO - 2016-03-10 13:27:01 --> Helper loaded: file_helper
INFO - 2016-03-10 13:27:01 --> Helper loaded: date_helper
INFO - 2016-03-10 13:27:01 --> Helper loaded: form_helper
INFO - 2016-03-10 13:27:01 --> Database Driver Class Initialized
INFO - 2016-03-10 13:27:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:27:02 --> Controller Class Initialized
INFO - 2016-03-10 13:27:02 --> Model Class Initialized
INFO - 2016-03-10 13:27:02 --> Model Class Initialized
INFO - 2016-03-10 13:27:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:27:02 --> Pagination Class Initialized
INFO - 2016-03-10 13:27:02 --> Helper loaded: text_helper
INFO - 2016-03-10 13:27:02 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:27:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:27:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:27:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:27:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:27:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:27:02 --> Final output sent to browser
DEBUG - 2016-03-10 16:27:02 --> Total execution time: 1.1434
INFO - 2016-03-10 13:27:08 --> Config Class Initialized
INFO - 2016-03-10 13:27:08 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:27:08 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:27:08 --> Utf8 Class Initialized
INFO - 2016-03-10 13:27:08 --> URI Class Initialized
INFO - 2016-03-10 13:27:08 --> Router Class Initialized
INFO - 2016-03-10 13:27:08 --> Output Class Initialized
INFO - 2016-03-10 13:27:08 --> Security Class Initialized
DEBUG - 2016-03-10 13:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:27:08 --> Input Class Initialized
INFO - 2016-03-10 13:27:08 --> Language Class Initialized
INFO - 2016-03-10 13:27:08 --> Loader Class Initialized
INFO - 2016-03-10 13:27:08 --> Helper loaded: url_helper
INFO - 2016-03-10 13:27:08 --> Helper loaded: file_helper
INFO - 2016-03-10 13:27:08 --> Helper loaded: date_helper
INFO - 2016-03-10 13:27:08 --> Helper loaded: form_helper
INFO - 2016-03-10 13:27:08 --> Database Driver Class Initialized
INFO - 2016-03-10 13:27:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:27:09 --> Controller Class Initialized
INFO - 2016-03-10 13:27:09 --> Model Class Initialized
INFO - 2016-03-10 13:27:09 --> Model Class Initialized
INFO - 2016-03-10 13:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:27:09 --> Pagination Class Initialized
INFO - 2016-03-10 13:27:09 --> Helper loaded: text_helper
INFO - 2016-03-10 13:27:09 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:27:09 --> Final output sent to browser
DEBUG - 2016-03-10 16:27:09 --> Total execution time: 1.1246
INFO - 2016-03-10 13:27:15 --> Config Class Initialized
INFO - 2016-03-10 13:27:15 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:27:15 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:27:15 --> Utf8 Class Initialized
INFO - 2016-03-10 13:27:15 --> URI Class Initialized
INFO - 2016-03-10 13:27:15 --> Router Class Initialized
INFO - 2016-03-10 13:27:15 --> Output Class Initialized
INFO - 2016-03-10 13:27:15 --> Security Class Initialized
DEBUG - 2016-03-10 13:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:27:15 --> Input Class Initialized
INFO - 2016-03-10 13:27:15 --> Language Class Initialized
INFO - 2016-03-10 13:27:15 --> Loader Class Initialized
INFO - 2016-03-10 13:27:15 --> Helper loaded: url_helper
INFO - 2016-03-10 13:27:15 --> Helper loaded: file_helper
INFO - 2016-03-10 13:27:15 --> Helper loaded: date_helper
INFO - 2016-03-10 13:27:15 --> Helper loaded: form_helper
INFO - 2016-03-10 13:27:15 --> Database Driver Class Initialized
INFO - 2016-03-10 13:27:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:27:16 --> Controller Class Initialized
INFO - 2016-03-10 13:27:16 --> Model Class Initialized
INFO - 2016-03-10 13:27:16 --> Model Class Initialized
INFO - 2016-03-10 13:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:27:16 --> Pagination Class Initialized
INFO - 2016-03-10 13:27:16 --> Helper loaded: text_helper
INFO - 2016-03-10 13:27:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:27:16 --> Final output sent to browser
DEBUG - 2016-03-10 16:27:16 --> Total execution time: 1.1464
INFO - 2016-03-10 13:27:22 --> Config Class Initialized
INFO - 2016-03-10 13:27:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:27:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:27:22 --> Utf8 Class Initialized
INFO - 2016-03-10 13:27:22 --> URI Class Initialized
INFO - 2016-03-10 13:27:22 --> Router Class Initialized
INFO - 2016-03-10 13:27:22 --> Output Class Initialized
INFO - 2016-03-10 13:27:22 --> Security Class Initialized
DEBUG - 2016-03-10 13:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:27:22 --> Input Class Initialized
INFO - 2016-03-10 13:27:22 --> Language Class Initialized
INFO - 2016-03-10 13:27:22 --> Loader Class Initialized
INFO - 2016-03-10 13:27:22 --> Helper loaded: url_helper
INFO - 2016-03-10 13:27:22 --> Helper loaded: file_helper
INFO - 2016-03-10 13:27:22 --> Helper loaded: date_helper
INFO - 2016-03-10 13:27:22 --> Helper loaded: form_helper
INFO - 2016-03-10 13:27:22 --> Database Driver Class Initialized
INFO - 2016-03-10 13:27:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:27:23 --> Controller Class Initialized
INFO - 2016-03-10 13:27:23 --> Model Class Initialized
INFO - 2016-03-10 13:27:23 --> Model Class Initialized
INFO - 2016-03-10 13:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:27:23 --> Pagination Class Initialized
INFO - 2016-03-10 13:27:23 --> Helper loaded: text_helper
INFO - 2016-03-10 13:27:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:27:23 --> Final output sent to browser
DEBUG - 2016-03-10 16:27:23 --> Total execution time: 1.0879
INFO - 2016-03-10 13:28:07 --> Config Class Initialized
INFO - 2016-03-10 13:28:07 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:07 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:07 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:07 --> URI Class Initialized
INFO - 2016-03-10 13:28:07 --> Router Class Initialized
INFO - 2016-03-10 13:28:07 --> Output Class Initialized
INFO - 2016-03-10 13:28:07 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:07 --> Input Class Initialized
INFO - 2016-03-10 13:28:07 --> Language Class Initialized
INFO - 2016-03-10 13:28:07 --> Loader Class Initialized
INFO - 2016-03-10 13:28:07 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:07 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:07 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:07 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:07 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:08 --> Controller Class Initialized
INFO - 2016-03-10 13:28:08 --> Model Class Initialized
INFO - 2016-03-10 13:28:08 --> Model Class Initialized
INFO - 2016-03-10 13:28:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:08 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:08 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:08 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:08 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:08 --> Total execution time: 1.1378
INFO - 2016-03-10 13:28:10 --> Config Class Initialized
INFO - 2016-03-10 13:28:10 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:10 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:10 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:10 --> URI Class Initialized
INFO - 2016-03-10 13:28:10 --> Router Class Initialized
INFO - 2016-03-10 13:28:10 --> Output Class Initialized
INFO - 2016-03-10 13:28:10 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:10 --> Input Class Initialized
INFO - 2016-03-10 13:28:10 --> Language Class Initialized
INFO - 2016-03-10 13:28:10 --> Loader Class Initialized
INFO - 2016-03-10 13:28:10 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:10 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:10 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:10 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:10 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:11 --> Controller Class Initialized
INFO - 2016-03-10 13:28:11 --> Model Class Initialized
INFO - 2016-03-10 13:28:11 --> Model Class Initialized
INFO - 2016-03-10 13:28:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:11 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:11 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:11 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:11 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:11 --> Total execution time: 1.1319
INFO - 2016-03-10 13:28:21 --> Config Class Initialized
INFO - 2016-03-10 13:28:21 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:21 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:21 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:21 --> URI Class Initialized
INFO - 2016-03-10 13:28:21 --> Router Class Initialized
INFO - 2016-03-10 13:28:21 --> Output Class Initialized
INFO - 2016-03-10 13:28:21 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:21 --> Input Class Initialized
INFO - 2016-03-10 13:28:21 --> Language Class Initialized
INFO - 2016-03-10 13:28:21 --> Loader Class Initialized
INFO - 2016-03-10 13:28:21 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:21 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:21 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:21 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:21 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:22 --> Controller Class Initialized
INFO - 2016-03-10 13:28:22 --> Model Class Initialized
INFO - 2016-03-10 13:28:22 --> Model Class Initialized
INFO - 2016-03-10 13:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:22 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:22 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:22 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:22 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:22 --> Total execution time: 1.1705
INFO - 2016-03-10 13:28:24 --> Config Class Initialized
INFO - 2016-03-10 13:28:24 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:24 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:24 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:24 --> URI Class Initialized
INFO - 2016-03-10 13:28:24 --> Router Class Initialized
INFO - 2016-03-10 13:28:24 --> Output Class Initialized
INFO - 2016-03-10 13:28:24 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:24 --> Input Class Initialized
INFO - 2016-03-10 13:28:24 --> Language Class Initialized
INFO - 2016-03-10 13:28:24 --> Loader Class Initialized
INFO - 2016-03-10 13:28:24 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:24 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:24 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:24 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:24 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:25 --> Controller Class Initialized
INFO - 2016-03-10 13:28:25 --> Model Class Initialized
INFO - 2016-03-10 13:28:25 --> Model Class Initialized
INFO - 2016-03-10 13:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:25 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:25 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:25 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:25 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:25 --> Total execution time: 1.1458
INFO - 2016-03-10 13:28:38 --> Config Class Initialized
INFO - 2016-03-10 13:28:38 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:38 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:38 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:38 --> URI Class Initialized
INFO - 2016-03-10 13:28:38 --> Router Class Initialized
INFO - 2016-03-10 13:28:38 --> Output Class Initialized
INFO - 2016-03-10 13:28:38 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:38 --> Input Class Initialized
INFO - 2016-03-10 13:28:38 --> Language Class Initialized
INFO - 2016-03-10 13:28:38 --> Loader Class Initialized
INFO - 2016-03-10 13:28:38 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:38 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:38 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:38 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:38 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:39 --> Controller Class Initialized
INFO - 2016-03-10 13:28:39 --> Model Class Initialized
INFO - 2016-03-10 13:28:39 --> Model Class Initialized
INFO - 2016-03-10 13:28:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:39 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:39 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:39 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:39 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:39 --> Total execution time: 1.1475
INFO - 2016-03-10 13:28:43 --> Config Class Initialized
INFO - 2016-03-10 13:28:43 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:43 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:43 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:43 --> URI Class Initialized
INFO - 2016-03-10 13:28:43 --> Router Class Initialized
INFO - 2016-03-10 13:28:43 --> Output Class Initialized
INFO - 2016-03-10 13:28:43 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:43 --> Input Class Initialized
INFO - 2016-03-10 13:28:43 --> Language Class Initialized
INFO - 2016-03-10 13:28:43 --> Loader Class Initialized
INFO - 2016-03-10 13:28:43 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:43 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:43 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:43 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:43 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:45 --> Controller Class Initialized
INFO - 2016-03-10 13:28:45 --> Model Class Initialized
INFO - 2016-03-10 13:28:45 --> Model Class Initialized
INFO - 2016-03-10 13:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:45 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:45 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:45 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:45 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:45 --> Total execution time: 1.1377
INFO - 2016-03-10 13:28:51 --> Config Class Initialized
INFO - 2016-03-10 13:28:51 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:51 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:51 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:51 --> URI Class Initialized
INFO - 2016-03-10 13:28:51 --> Router Class Initialized
INFO - 2016-03-10 13:28:51 --> Output Class Initialized
INFO - 2016-03-10 13:28:51 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:51 --> Input Class Initialized
INFO - 2016-03-10 13:28:51 --> Language Class Initialized
INFO - 2016-03-10 13:28:51 --> Loader Class Initialized
INFO - 2016-03-10 13:28:51 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:51 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:51 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:51 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:51 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:52 --> Controller Class Initialized
INFO - 2016-03-10 13:28:52 --> Model Class Initialized
INFO - 2016-03-10 13:28:52 --> Model Class Initialized
INFO - 2016-03-10 13:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:52 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:52 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:52 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:52 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:52 --> Total execution time: 1.1036
INFO - 2016-03-10 13:28:58 --> Config Class Initialized
INFO - 2016-03-10 13:28:58 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:28:58 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:28:58 --> Utf8 Class Initialized
INFO - 2016-03-10 13:28:58 --> URI Class Initialized
INFO - 2016-03-10 13:28:58 --> Router Class Initialized
INFO - 2016-03-10 13:28:58 --> Output Class Initialized
INFO - 2016-03-10 13:28:58 --> Security Class Initialized
DEBUG - 2016-03-10 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:28:58 --> Input Class Initialized
INFO - 2016-03-10 13:28:58 --> Language Class Initialized
INFO - 2016-03-10 13:28:58 --> Loader Class Initialized
INFO - 2016-03-10 13:28:58 --> Helper loaded: url_helper
INFO - 2016-03-10 13:28:58 --> Helper loaded: file_helper
INFO - 2016-03-10 13:28:58 --> Helper loaded: date_helper
INFO - 2016-03-10 13:28:58 --> Helper loaded: form_helper
INFO - 2016-03-10 13:28:58 --> Database Driver Class Initialized
INFO - 2016-03-10 13:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:28:59 --> Controller Class Initialized
INFO - 2016-03-10 13:28:59 --> Model Class Initialized
INFO - 2016-03-10 13:28:59 --> Model Class Initialized
INFO - 2016-03-10 13:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:28:59 --> Pagination Class Initialized
INFO - 2016-03-10 13:28:59 --> Helper loaded: text_helper
INFO - 2016-03-10 13:28:59 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:28:59 --> Final output sent to browser
DEBUG - 2016-03-10 16:28:59 --> Total execution time: 1.1849
INFO - 2016-03-10 13:29:02 --> Config Class Initialized
INFO - 2016-03-10 13:29:02 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:02 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:02 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:02 --> URI Class Initialized
INFO - 2016-03-10 13:29:02 --> Router Class Initialized
INFO - 2016-03-10 13:29:02 --> Output Class Initialized
INFO - 2016-03-10 13:29:02 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:02 --> Input Class Initialized
INFO - 2016-03-10 13:29:02 --> Language Class Initialized
INFO - 2016-03-10 13:29:02 --> Loader Class Initialized
INFO - 2016-03-10 13:29:02 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:02 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:02 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:02 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:02 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:03 --> Controller Class Initialized
INFO - 2016-03-10 13:29:03 --> Model Class Initialized
INFO - 2016-03-10 13:29:03 --> Model Class Initialized
INFO - 2016-03-10 13:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:03 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:03 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:03 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:03 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:03 --> Total execution time: 1.1376
INFO - 2016-03-10 13:29:04 --> Config Class Initialized
INFO - 2016-03-10 13:29:04 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:04 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:04 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:04 --> URI Class Initialized
INFO - 2016-03-10 13:29:04 --> Router Class Initialized
INFO - 2016-03-10 13:29:04 --> Output Class Initialized
INFO - 2016-03-10 13:29:04 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:04 --> Input Class Initialized
INFO - 2016-03-10 13:29:04 --> Language Class Initialized
INFO - 2016-03-10 13:29:04 --> Loader Class Initialized
INFO - 2016-03-10 13:29:04 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:04 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:04 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:04 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:04 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:05 --> Controller Class Initialized
INFO - 2016-03-10 13:29:05 --> Model Class Initialized
INFO - 2016-03-10 13:29:05 --> Model Class Initialized
INFO - 2016-03-10 13:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:06 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:06 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:06 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:06 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:06 --> Total execution time: 1.1377
INFO - 2016-03-10 13:29:06 --> Config Class Initialized
INFO - 2016-03-10 13:29:06 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:06 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:06 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:06 --> URI Class Initialized
INFO - 2016-03-10 13:29:06 --> Router Class Initialized
INFO - 2016-03-10 13:29:06 --> Output Class Initialized
INFO - 2016-03-10 13:29:06 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:06 --> Input Class Initialized
INFO - 2016-03-10 13:29:06 --> Language Class Initialized
INFO - 2016-03-10 13:29:06 --> Loader Class Initialized
INFO - 2016-03-10 13:29:06 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:06 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:06 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:06 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:06 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:07 --> Controller Class Initialized
INFO - 2016-03-10 13:29:07 --> Model Class Initialized
INFO - 2016-03-10 13:29:07 --> Model Class Initialized
INFO - 2016-03-10 13:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:07 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:07 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:07 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:07 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:07 --> Total execution time: 1.1449
INFO - 2016-03-10 13:29:13 --> Config Class Initialized
INFO - 2016-03-10 13:29:13 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:13 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:13 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:13 --> URI Class Initialized
INFO - 2016-03-10 13:29:13 --> Router Class Initialized
INFO - 2016-03-10 13:29:13 --> Output Class Initialized
INFO - 2016-03-10 13:29:13 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:13 --> Input Class Initialized
INFO - 2016-03-10 13:29:13 --> Language Class Initialized
INFO - 2016-03-10 13:29:13 --> Loader Class Initialized
INFO - 2016-03-10 13:29:13 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:13 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:13 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:13 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:13 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:14 --> Controller Class Initialized
INFO - 2016-03-10 13:29:14 --> Model Class Initialized
INFO - 2016-03-10 13:29:14 --> Model Class Initialized
INFO - 2016-03-10 13:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:14 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:14 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:14 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:14 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:14 --> Total execution time: 1.1078
INFO - 2016-03-10 13:29:25 --> Config Class Initialized
INFO - 2016-03-10 13:29:25 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:25 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:25 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:25 --> URI Class Initialized
INFO - 2016-03-10 13:29:25 --> Router Class Initialized
INFO - 2016-03-10 13:29:25 --> Output Class Initialized
INFO - 2016-03-10 13:29:25 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:25 --> Input Class Initialized
INFO - 2016-03-10 13:29:25 --> Language Class Initialized
INFO - 2016-03-10 13:29:25 --> Loader Class Initialized
INFO - 2016-03-10 13:29:25 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:25 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:25 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:25 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:25 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:26 --> Controller Class Initialized
INFO - 2016-03-10 13:29:26 --> Model Class Initialized
INFO - 2016-03-10 13:29:26 --> Model Class Initialized
INFO - 2016-03-10 13:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:26 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:26 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:26 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:29:26 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:29:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:26 --> Form Validation Class Initialized
INFO - 2016-03-10 16:29:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:29:26 --> Config Class Initialized
INFO - 2016-03-10 13:29:26 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:26 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:26 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:26 --> URI Class Initialized
INFO - 2016-03-10 13:29:26 --> Router Class Initialized
INFO - 2016-03-10 13:29:26 --> Output Class Initialized
INFO - 2016-03-10 13:29:26 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:26 --> Input Class Initialized
INFO - 2016-03-10 13:29:26 --> Language Class Initialized
INFO - 2016-03-10 13:29:26 --> Loader Class Initialized
INFO - 2016-03-10 13:29:26 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:26 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:26 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:26 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:26 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:27 --> Controller Class Initialized
INFO - 2016-03-10 13:29:27 --> Model Class Initialized
INFO - 2016-03-10 13:29:27 --> Model Class Initialized
INFO - 2016-03-10 13:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:27 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:27 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:27 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:27 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:27 --> Total execution time: 1.1685
INFO - 2016-03-10 13:29:29 --> Config Class Initialized
INFO - 2016-03-10 13:29:29 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:29 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:29 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:29 --> URI Class Initialized
INFO - 2016-03-10 13:29:29 --> Router Class Initialized
INFO - 2016-03-10 13:29:29 --> Output Class Initialized
INFO - 2016-03-10 13:29:29 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:29 --> Input Class Initialized
INFO - 2016-03-10 13:29:29 --> Language Class Initialized
INFO - 2016-03-10 13:29:29 --> Loader Class Initialized
INFO - 2016-03-10 13:29:29 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:29 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:29 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:29 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:29 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:30 --> Controller Class Initialized
INFO - 2016-03-10 13:29:30 --> Model Class Initialized
INFO - 2016-03-10 13:29:30 --> Model Class Initialized
INFO - 2016-03-10 13:29:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:30 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:30 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:30 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:29:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:29:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:30 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:30 --> Total execution time: 1.1609
INFO - 2016-03-10 13:29:47 --> Config Class Initialized
INFO - 2016-03-10 13:29:47 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:47 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:47 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:47 --> URI Class Initialized
INFO - 2016-03-10 13:29:47 --> Router Class Initialized
INFO - 2016-03-10 13:29:47 --> Output Class Initialized
INFO - 2016-03-10 13:29:47 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:47 --> Input Class Initialized
INFO - 2016-03-10 13:29:47 --> Language Class Initialized
INFO - 2016-03-10 13:29:47 --> Loader Class Initialized
INFO - 2016-03-10 13:29:47 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:47 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:47 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:47 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:47 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:48 --> Controller Class Initialized
INFO - 2016-03-10 13:29:48 --> Model Class Initialized
INFO - 2016-03-10 13:29:48 --> Model Class Initialized
INFO - 2016-03-10 13:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:48 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:48 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:48 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:29:48 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:48 --> Form Validation Class Initialized
INFO - 2016-03-10 16:29:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:29:49 --> Config Class Initialized
INFO - 2016-03-10 13:29:49 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:49 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:49 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:49 --> URI Class Initialized
INFO - 2016-03-10 13:29:49 --> Router Class Initialized
INFO - 2016-03-10 13:29:49 --> Output Class Initialized
INFO - 2016-03-10 13:29:49 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:49 --> Input Class Initialized
INFO - 2016-03-10 13:29:49 --> Language Class Initialized
INFO - 2016-03-10 13:29:49 --> Loader Class Initialized
INFO - 2016-03-10 13:29:49 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:49 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:49 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:49 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:49 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:50 --> Controller Class Initialized
INFO - 2016-03-10 13:29:50 --> Model Class Initialized
INFO - 2016-03-10 13:29:50 --> Model Class Initialized
INFO - 2016-03-10 13:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:50 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:50 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:50 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:50 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:50 --> Total execution time: 1.1794
INFO - 2016-03-10 13:29:51 --> Config Class Initialized
INFO - 2016-03-10 13:29:51 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:29:51 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:29:51 --> Utf8 Class Initialized
INFO - 2016-03-10 13:29:51 --> URI Class Initialized
INFO - 2016-03-10 13:29:51 --> Router Class Initialized
INFO - 2016-03-10 13:29:51 --> Output Class Initialized
INFO - 2016-03-10 13:29:51 --> Security Class Initialized
DEBUG - 2016-03-10 13:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:29:51 --> Input Class Initialized
INFO - 2016-03-10 13:29:51 --> Language Class Initialized
INFO - 2016-03-10 13:29:51 --> Loader Class Initialized
INFO - 2016-03-10 13:29:51 --> Helper loaded: url_helper
INFO - 2016-03-10 13:29:51 --> Helper loaded: file_helper
INFO - 2016-03-10 13:29:51 --> Helper loaded: date_helper
INFO - 2016-03-10 13:29:51 --> Helper loaded: form_helper
INFO - 2016-03-10 13:29:51 --> Database Driver Class Initialized
INFO - 2016-03-10 13:29:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:29:52 --> Controller Class Initialized
INFO - 2016-03-10 13:29:52 --> Model Class Initialized
INFO - 2016-03-10 13:29:52 --> Model Class Initialized
INFO - 2016-03-10 13:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:29:52 --> Pagination Class Initialized
INFO - 2016-03-10 13:29:52 --> Helper loaded: text_helper
INFO - 2016-03-10 13:29:52 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:29:52 --> Final output sent to browser
DEBUG - 2016-03-10 16:29:52 --> Total execution time: 1.1501
INFO - 2016-03-10 13:30:15 --> Config Class Initialized
INFO - 2016-03-10 13:30:15 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:15 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:15 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:15 --> URI Class Initialized
INFO - 2016-03-10 13:30:15 --> Router Class Initialized
INFO - 2016-03-10 13:30:15 --> Output Class Initialized
INFO - 2016-03-10 13:30:15 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:15 --> Input Class Initialized
INFO - 2016-03-10 13:30:15 --> Language Class Initialized
INFO - 2016-03-10 13:30:15 --> Loader Class Initialized
INFO - 2016-03-10 13:30:15 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:15 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:15 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:15 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:15 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:16 --> Controller Class Initialized
INFO - 2016-03-10 13:30:16 --> Model Class Initialized
INFO - 2016-03-10 13:30:16 --> Model Class Initialized
INFO - 2016-03-10 13:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:16 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:16 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:16 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:30:16 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:16 --> Form Validation Class Initialized
INFO - 2016-03-10 16:30:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:30:16 --> Config Class Initialized
INFO - 2016-03-10 13:30:16 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:16 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:16 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:16 --> URI Class Initialized
INFO - 2016-03-10 13:30:16 --> Router Class Initialized
INFO - 2016-03-10 13:30:16 --> Output Class Initialized
INFO - 2016-03-10 13:30:16 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:16 --> Input Class Initialized
INFO - 2016-03-10 13:30:16 --> Language Class Initialized
INFO - 2016-03-10 13:30:16 --> Loader Class Initialized
INFO - 2016-03-10 13:30:16 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:16 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:16 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:16 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:16 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:17 --> Controller Class Initialized
INFO - 2016-03-10 13:30:17 --> Model Class Initialized
INFO - 2016-03-10 13:30:17 --> Model Class Initialized
INFO - 2016-03-10 13:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:17 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:17 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:17 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:17 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:17 --> Total execution time: 1.1690
INFO - 2016-03-10 13:30:22 --> Config Class Initialized
INFO - 2016-03-10 13:30:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:22 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:22 --> URI Class Initialized
INFO - 2016-03-10 13:30:22 --> Router Class Initialized
INFO - 2016-03-10 13:30:22 --> Output Class Initialized
INFO - 2016-03-10 13:30:22 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:22 --> Input Class Initialized
INFO - 2016-03-10 13:30:22 --> Language Class Initialized
INFO - 2016-03-10 13:30:22 --> Loader Class Initialized
INFO - 2016-03-10 13:30:22 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:22 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:22 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:22 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:22 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:23 --> Controller Class Initialized
INFO - 2016-03-10 13:30:23 --> Model Class Initialized
INFO - 2016-03-10 13:30:23 --> Model Class Initialized
INFO - 2016-03-10 13:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:23 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:23 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-10 16:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:23 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:23 --> Total execution time: 1.1162
INFO - 2016-03-10 13:30:32 --> Config Class Initialized
INFO - 2016-03-10 13:30:32 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:32 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:32 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:32 --> URI Class Initialized
INFO - 2016-03-10 13:30:32 --> Router Class Initialized
INFO - 2016-03-10 13:30:32 --> Output Class Initialized
INFO - 2016-03-10 13:30:32 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:32 --> Input Class Initialized
INFO - 2016-03-10 13:30:32 --> Language Class Initialized
INFO - 2016-03-10 13:30:32 --> Loader Class Initialized
INFO - 2016-03-10 13:30:32 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:32 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:32 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:32 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:32 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:33 --> Controller Class Initialized
INFO - 2016-03-10 13:30:33 --> Model Class Initialized
INFO - 2016-03-10 13:30:33 --> Model Class Initialized
INFO - 2016-03-10 13:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:33 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:33 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:33 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:30:33 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 327
INFO - 2016-03-10 16:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:33 --> Form Validation Class Initialized
INFO - 2016-03-10 16:30:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-10 13:30:33 --> Config Class Initialized
INFO - 2016-03-10 13:30:33 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:33 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:33 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:33 --> URI Class Initialized
INFO - 2016-03-10 13:30:33 --> Router Class Initialized
INFO - 2016-03-10 13:30:33 --> Output Class Initialized
INFO - 2016-03-10 13:30:33 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:33 --> Input Class Initialized
INFO - 2016-03-10 13:30:33 --> Language Class Initialized
INFO - 2016-03-10 13:30:33 --> Loader Class Initialized
INFO - 2016-03-10 13:30:33 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:33 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:33 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:33 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:33 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:34 --> Controller Class Initialized
INFO - 2016-03-10 13:30:34 --> Model Class Initialized
INFO - 2016-03-10 13:30:34 --> Model Class Initialized
INFO - 2016-03-10 13:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:35 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:35 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:35 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:35 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:35 --> Total execution time: 1.1628
INFO - 2016-03-10 13:30:37 --> Config Class Initialized
INFO - 2016-03-10 13:30:37 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:37 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:37 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:37 --> URI Class Initialized
INFO - 2016-03-10 13:30:37 --> Router Class Initialized
INFO - 2016-03-10 13:30:37 --> Output Class Initialized
INFO - 2016-03-10 13:30:37 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:37 --> Input Class Initialized
INFO - 2016-03-10 13:30:37 --> Language Class Initialized
INFO - 2016-03-10 13:30:37 --> Loader Class Initialized
INFO - 2016-03-10 13:30:37 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:37 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:37 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:37 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:37 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:38 --> Controller Class Initialized
INFO - 2016-03-10 13:30:38 --> Model Class Initialized
INFO - 2016-03-10 13:30:38 --> Model Class Initialized
INFO - 2016-03-10 13:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:38 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:38 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:38 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:39 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:39 --> Total execution time: 1.0844
INFO - 2016-03-10 13:30:43 --> Config Class Initialized
INFO - 2016-03-10 13:30:43 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:43 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:43 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:43 --> URI Class Initialized
INFO - 2016-03-10 13:30:43 --> Router Class Initialized
INFO - 2016-03-10 13:30:43 --> Output Class Initialized
INFO - 2016-03-10 13:30:43 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:43 --> Input Class Initialized
INFO - 2016-03-10 13:30:43 --> Language Class Initialized
INFO - 2016-03-10 13:30:43 --> Loader Class Initialized
INFO - 2016-03-10 13:30:43 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:43 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:43 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:43 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:43 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:44 --> Controller Class Initialized
INFO - 2016-03-10 13:30:44 --> Model Class Initialized
INFO - 2016-03-10 13:30:44 --> Model Class Initialized
INFO - 2016-03-10 13:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:44 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:44 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:44 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:44 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:44 --> Total execution time: 1.1280
INFO - 2016-03-10 13:30:53 --> Config Class Initialized
INFO - 2016-03-10 13:30:53 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:53 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:53 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:53 --> URI Class Initialized
INFO - 2016-03-10 13:30:53 --> Router Class Initialized
INFO - 2016-03-10 13:30:53 --> Output Class Initialized
INFO - 2016-03-10 13:30:53 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:53 --> Input Class Initialized
INFO - 2016-03-10 13:30:53 --> Language Class Initialized
INFO - 2016-03-10 13:30:53 --> Loader Class Initialized
INFO - 2016-03-10 13:30:53 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:53 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:53 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:53 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:53 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:54 --> Controller Class Initialized
INFO - 2016-03-10 13:30:54 --> Model Class Initialized
INFO - 2016-03-10 13:30:54 --> Model Class Initialized
INFO - 2016-03-10 13:30:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:54 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:54 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:54 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:30:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:30:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:54 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:54 --> Total execution time: 1.1352
INFO - 2016-03-10 13:30:57 --> Config Class Initialized
INFO - 2016-03-10 13:30:57 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:30:57 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:30:57 --> Utf8 Class Initialized
INFO - 2016-03-10 13:30:57 --> URI Class Initialized
INFO - 2016-03-10 13:30:57 --> Router Class Initialized
INFO - 2016-03-10 13:30:57 --> Output Class Initialized
INFO - 2016-03-10 13:30:57 --> Security Class Initialized
DEBUG - 2016-03-10 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:30:57 --> Input Class Initialized
INFO - 2016-03-10 13:30:57 --> Language Class Initialized
INFO - 2016-03-10 13:30:58 --> Loader Class Initialized
INFO - 2016-03-10 13:30:58 --> Helper loaded: url_helper
INFO - 2016-03-10 13:30:58 --> Helper loaded: file_helper
INFO - 2016-03-10 13:30:58 --> Helper loaded: date_helper
INFO - 2016-03-10 13:30:58 --> Helper loaded: form_helper
INFO - 2016-03-10 13:30:58 --> Database Driver Class Initialized
INFO - 2016-03-10 13:30:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:30:59 --> Controller Class Initialized
INFO - 2016-03-10 13:30:59 --> Model Class Initialized
INFO - 2016-03-10 13:30:59 --> Model Class Initialized
INFO - 2016-03-10 13:30:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:30:59 --> Pagination Class Initialized
INFO - 2016-03-10 13:30:59 --> Helper loaded: text_helper
INFO - 2016-03-10 13:30:59 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:30:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:30:59 --> Final output sent to browser
DEBUG - 2016-03-10 16:30:59 --> Total execution time: 1.1844
INFO - 2016-03-10 13:37:11 --> Config Class Initialized
INFO - 2016-03-10 13:37:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:37:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:37:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:37:11 --> URI Class Initialized
INFO - 2016-03-10 13:37:11 --> Router Class Initialized
INFO - 2016-03-10 13:37:11 --> Output Class Initialized
INFO - 2016-03-10 13:37:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:37:11 --> Input Class Initialized
INFO - 2016-03-10 13:37:11 --> Language Class Initialized
INFO - 2016-03-10 13:37:11 --> Loader Class Initialized
INFO - 2016-03-10 13:37:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:37:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:37:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:37:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:37:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:37:12 --> Controller Class Initialized
INFO - 2016-03-10 13:37:12 --> Model Class Initialized
INFO - 2016-03-10 13:37:12 --> Model Class Initialized
INFO - 2016-03-10 13:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:37:12 --> Pagination Class Initialized
INFO - 2016-03-10 13:37:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:37:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:37:12 --> Final output sent to browser
DEBUG - 2016-03-10 16:37:12 --> Total execution time: 1.1516
INFO - 2016-03-10 13:46:40 --> Config Class Initialized
INFO - 2016-03-10 13:46:40 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:46:40 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:46:40 --> Utf8 Class Initialized
INFO - 2016-03-10 13:46:40 --> URI Class Initialized
INFO - 2016-03-10 13:46:40 --> Router Class Initialized
INFO - 2016-03-10 13:46:40 --> Output Class Initialized
INFO - 2016-03-10 13:46:40 --> Security Class Initialized
DEBUG - 2016-03-10 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:46:40 --> Input Class Initialized
INFO - 2016-03-10 13:46:40 --> Language Class Initialized
INFO - 2016-03-10 13:46:40 --> Loader Class Initialized
INFO - 2016-03-10 13:46:40 --> Helper loaded: url_helper
INFO - 2016-03-10 13:46:40 --> Helper loaded: file_helper
INFO - 2016-03-10 13:46:40 --> Helper loaded: date_helper
INFO - 2016-03-10 13:46:40 --> Helper loaded: form_helper
INFO - 2016-03-10 13:46:40 --> Database Driver Class Initialized
INFO - 2016-03-10 13:46:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:46:41 --> Controller Class Initialized
INFO - 2016-03-10 13:46:41 --> Model Class Initialized
INFO - 2016-03-10 13:46:41 --> Model Class Initialized
INFO - 2016-03-10 13:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:46:41 --> Pagination Class Initialized
INFO - 2016-03-10 13:46:41 --> Helper loaded: text_helper
INFO - 2016-03-10 13:46:41 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:46:41 --> Final output sent to browser
DEBUG - 2016-03-10 16:46:41 --> Total execution time: 1.1110
INFO - 2016-03-10 13:47:09 --> Config Class Initialized
INFO - 2016-03-10 13:47:09 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:47:09 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:47:09 --> Utf8 Class Initialized
INFO - 2016-03-10 13:47:09 --> URI Class Initialized
INFO - 2016-03-10 13:47:09 --> Router Class Initialized
INFO - 2016-03-10 13:47:09 --> Output Class Initialized
INFO - 2016-03-10 13:47:09 --> Security Class Initialized
DEBUG - 2016-03-10 13:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:47:09 --> Input Class Initialized
INFO - 2016-03-10 13:47:09 --> Language Class Initialized
INFO - 2016-03-10 13:47:09 --> Loader Class Initialized
INFO - 2016-03-10 13:47:09 --> Helper loaded: url_helper
INFO - 2016-03-10 13:47:09 --> Helper loaded: file_helper
INFO - 2016-03-10 13:47:09 --> Helper loaded: date_helper
INFO - 2016-03-10 13:47:09 --> Helper loaded: form_helper
INFO - 2016-03-10 13:47:09 --> Database Driver Class Initialized
INFO - 2016-03-10 13:47:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:47:10 --> Controller Class Initialized
INFO - 2016-03-10 13:47:10 --> Model Class Initialized
INFO - 2016-03-10 13:47:10 --> Model Class Initialized
INFO - 2016-03-10 13:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:47:10 --> Pagination Class Initialized
INFO - 2016-03-10 13:47:10 --> Helper loaded: text_helper
INFO - 2016-03-10 13:47:10 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:47:10 --> Final output sent to browser
DEBUG - 2016-03-10 16:47:10 --> Total execution time: 1.1094
INFO - 2016-03-10 13:47:11 --> Config Class Initialized
INFO - 2016-03-10 13:47:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:47:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:47:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:47:11 --> URI Class Initialized
INFO - 2016-03-10 13:47:11 --> Router Class Initialized
INFO - 2016-03-10 13:47:11 --> Output Class Initialized
INFO - 2016-03-10 13:47:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:47:11 --> Input Class Initialized
INFO - 2016-03-10 13:47:11 --> Language Class Initialized
INFO - 2016-03-10 13:47:11 --> Loader Class Initialized
INFO - 2016-03-10 13:47:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:47:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:47:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:47:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:47:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:47:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:47:12 --> Controller Class Initialized
INFO - 2016-03-10 13:47:12 --> Model Class Initialized
INFO - 2016-03-10 13:47:12 --> Model Class Initialized
INFO - 2016-03-10 13:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:47:12 --> Pagination Class Initialized
INFO - 2016-03-10 13:47:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:47:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:47:12 --> Final output sent to browser
DEBUG - 2016-03-10 16:47:12 --> Total execution time: 1.1283
INFO - 2016-03-10 13:47:53 --> Config Class Initialized
INFO - 2016-03-10 13:47:53 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:47:53 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:47:53 --> Utf8 Class Initialized
INFO - 2016-03-10 13:47:53 --> URI Class Initialized
INFO - 2016-03-10 13:47:53 --> Router Class Initialized
INFO - 2016-03-10 13:47:53 --> Output Class Initialized
INFO - 2016-03-10 13:47:53 --> Security Class Initialized
DEBUG - 2016-03-10 13:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:47:53 --> Input Class Initialized
INFO - 2016-03-10 13:47:53 --> Language Class Initialized
INFO - 2016-03-10 13:47:53 --> Loader Class Initialized
INFO - 2016-03-10 13:47:53 --> Helper loaded: url_helper
INFO - 2016-03-10 13:47:53 --> Helper loaded: file_helper
INFO - 2016-03-10 13:47:53 --> Helper loaded: date_helper
INFO - 2016-03-10 13:47:53 --> Helper loaded: form_helper
INFO - 2016-03-10 13:47:53 --> Database Driver Class Initialized
INFO - 2016-03-10 13:47:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:47:54 --> Controller Class Initialized
INFO - 2016-03-10 13:47:54 --> Model Class Initialized
INFO - 2016-03-10 13:47:54 --> Model Class Initialized
INFO - 2016-03-10 13:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:47:54 --> Pagination Class Initialized
INFO - 2016-03-10 13:47:54 --> Helper loaded: text_helper
INFO - 2016-03-10 13:47:54 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:47:54 --> Final output sent to browser
DEBUG - 2016-03-10 16:47:54 --> Total execution time: 1.1255
INFO - 2016-03-10 13:48:05 --> Config Class Initialized
INFO - 2016-03-10 13:48:05 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:48:05 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:48:05 --> Utf8 Class Initialized
INFO - 2016-03-10 13:48:05 --> URI Class Initialized
INFO - 2016-03-10 13:48:05 --> Router Class Initialized
INFO - 2016-03-10 13:48:05 --> Output Class Initialized
INFO - 2016-03-10 13:48:05 --> Security Class Initialized
DEBUG - 2016-03-10 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:48:05 --> Input Class Initialized
INFO - 2016-03-10 13:48:05 --> Language Class Initialized
INFO - 2016-03-10 13:48:05 --> Loader Class Initialized
INFO - 2016-03-10 13:48:05 --> Helper loaded: url_helper
INFO - 2016-03-10 13:48:05 --> Helper loaded: file_helper
INFO - 2016-03-10 13:48:05 --> Helper loaded: date_helper
INFO - 2016-03-10 13:48:05 --> Helper loaded: form_helper
INFO - 2016-03-10 13:48:05 --> Database Driver Class Initialized
INFO - 2016-03-10 13:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:48:06 --> Controller Class Initialized
INFO - 2016-03-10 13:48:06 --> Model Class Initialized
INFO - 2016-03-10 13:48:06 --> Model Class Initialized
INFO - 2016-03-10 13:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:48:06 --> Pagination Class Initialized
INFO - 2016-03-10 13:48:06 --> Helper loaded: text_helper
INFO - 2016-03-10 13:48:06 --> Helper loaded: cookie_helper
ERROR - 2016-03-10 16:48:06 --> Severity: Warning --> Missing argument 1 for Wall::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 117
INFO - 2016-03-10 16:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:48:06 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 212
ERROR - 2016-03-10 16:48:06 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 220
ERROR - 2016-03-10 16:48:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIMIT 1' at line 4 - Invalid query: SELECT *
FROM `wall`
WHERE `id` >
 LIMIT 1
INFO - 2016-03-10 16:48:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-03-10 16:48:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `id` = 'c8e86cc50ac1d970aaa814228debd402f138965c' LIMIT 1' at line 3 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1457646486
WHERE `id` >
AND `id` = 'c8e86cc50ac1d970aaa814228debd402f138965c' LIMIT 1
INFO - 2016-03-10 13:48:10 --> Config Class Initialized
INFO - 2016-03-10 13:48:10 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:48:10 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:48:10 --> Utf8 Class Initialized
INFO - 2016-03-10 13:48:10 --> URI Class Initialized
INFO - 2016-03-10 13:48:10 --> Router Class Initialized
INFO - 2016-03-10 13:48:10 --> Output Class Initialized
INFO - 2016-03-10 13:48:10 --> Security Class Initialized
DEBUG - 2016-03-10 13:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:48:10 --> Input Class Initialized
INFO - 2016-03-10 13:48:10 --> Language Class Initialized
INFO - 2016-03-10 13:48:10 --> Loader Class Initialized
INFO - 2016-03-10 13:48:10 --> Helper loaded: url_helper
INFO - 2016-03-10 13:48:10 --> Helper loaded: file_helper
INFO - 2016-03-10 13:48:10 --> Helper loaded: date_helper
INFO - 2016-03-10 13:48:10 --> Helper loaded: form_helper
INFO - 2016-03-10 13:48:10 --> Database Driver Class Initialized
INFO - 2016-03-10 13:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:48:11 --> Controller Class Initialized
INFO - 2016-03-10 13:48:11 --> Model Class Initialized
INFO - 2016-03-10 13:48:11 --> Model Class Initialized
INFO - 2016-03-10 13:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:48:11 --> Pagination Class Initialized
INFO - 2016-03-10 13:48:11 --> Helper loaded: text_helper
INFO - 2016-03-10 13:48:11 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:48:11 --> Final output sent to browser
DEBUG - 2016-03-10 16:48:11 --> Total execution time: 1.1064
INFO - 2016-03-10 13:49:03 --> Config Class Initialized
INFO - 2016-03-10 13:49:03 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:49:03 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:49:03 --> Utf8 Class Initialized
INFO - 2016-03-10 13:49:03 --> URI Class Initialized
INFO - 2016-03-10 13:49:03 --> Router Class Initialized
INFO - 2016-03-10 13:49:03 --> Output Class Initialized
INFO - 2016-03-10 13:49:03 --> Security Class Initialized
DEBUG - 2016-03-10 13:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:49:03 --> Input Class Initialized
INFO - 2016-03-10 13:49:03 --> Language Class Initialized
INFO - 2016-03-10 13:49:03 --> Loader Class Initialized
INFO - 2016-03-10 13:49:03 --> Helper loaded: url_helper
INFO - 2016-03-10 13:49:03 --> Helper loaded: file_helper
INFO - 2016-03-10 13:49:03 --> Helper loaded: date_helper
INFO - 2016-03-10 13:49:03 --> Helper loaded: form_helper
INFO - 2016-03-10 13:49:03 --> Database Driver Class Initialized
INFO - 2016-03-10 13:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:49:04 --> Controller Class Initialized
INFO - 2016-03-10 13:49:04 --> Model Class Initialized
INFO - 2016-03-10 13:49:04 --> Model Class Initialized
INFO - 2016-03-10 13:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:49:04 --> Pagination Class Initialized
INFO - 2016-03-10 13:49:04 --> Helper loaded: text_helper
INFO - 2016-03-10 13:49:04 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:49:04 --> Final output sent to browser
DEBUG - 2016-03-10 16:49:04 --> Total execution time: 1.1970
INFO - 2016-03-10 13:49:22 --> Config Class Initialized
INFO - 2016-03-10 13:49:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:49:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:49:22 --> Utf8 Class Initialized
INFO - 2016-03-10 13:49:22 --> URI Class Initialized
INFO - 2016-03-10 13:49:22 --> Router Class Initialized
INFO - 2016-03-10 13:49:22 --> Output Class Initialized
INFO - 2016-03-10 13:49:22 --> Security Class Initialized
DEBUG - 2016-03-10 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:49:22 --> Input Class Initialized
INFO - 2016-03-10 13:49:22 --> Language Class Initialized
INFO - 2016-03-10 13:49:22 --> Loader Class Initialized
INFO - 2016-03-10 13:49:22 --> Helper loaded: url_helper
INFO - 2016-03-10 13:49:22 --> Helper loaded: file_helper
INFO - 2016-03-10 13:49:22 --> Helper loaded: date_helper
INFO - 2016-03-10 13:49:22 --> Helper loaded: form_helper
INFO - 2016-03-10 13:49:22 --> Database Driver Class Initialized
INFO - 2016-03-10 13:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:49:23 --> Controller Class Initialized
INFO - 2016-03-10 13:49:23 --> Model Class Initialized
INFO - 2016-03-10 13:49:23 --> Model Class Initialized
INFO - 2016-03-10 13:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:49:23 --> Pagination Class Initialized
INFO - 2016-03-10 13:49:23 --> Helper loaded: text_helper
INFO - 2016-03-10 13:49:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:49:23 --> Final output sent to browser
DEBUG - 2016-03-10 16:49:23 --> Total execution time: 1.1746
INFO - 2016-03-10 13:50:00 --> Config Class Initialized
INFO - 2016-03-10 13:50:00 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:50:00 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:50:00 --> Utf8 Class Initialized
INFO - 2016-03-10 13:50:00 --> URI Class Initialized
DEBUG - 2016-03-10 13:50:00 --> No URI present. Default controller set.
INFO - 2016-03-10 13:50:00 --> Router Class Initialized
INFO - 2016-03-10 13:50:00 --> Output Class Initialized
INFO - 2016-03-10 13:50:00 --> Security Class Initialized
DEBUG - 2016-03-10 13:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:50:00 --> Input Class Initialized
INFO - 2016-03-10 13:50:00 --> Language Class Initialized
INFO - 2016-03-10 13:50:00 --> Loader Class Initialized
INFO - 2016-03-10 13:50:00 --> Helper loaded: url_helper
INFO - 2016-03-10 13:50:00 --> Helper loaded: file_helper
INFO - 2016-03-10 13:50:00 --> Helper loaded: date_helper
INFO - 2016-03-10 13:50:00 --> Helper loaded: form_helper
INFO - 2016-03-10 13:50:00 --> Database Driver Class Initialized
INFO - 2016-03-10 13:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:50:01 --> Controller Class Initialized
INFO - 2016-03-10 13:50:01 --> Model Class Initialized
INFO - 2016-03-10 13:50:02 --> Model Class Initialized
INFO - 2016-03-10 13:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:50:02 --> Pagination Class Initialized
INFO - 2016-03-10 13:50:02 --> Helper loaded: text_helper
INFO - 2016-03-10 13:50:02 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-10 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:50:02 --> Final output sent to browser
DEBUG - 2016-03-10 16:50:02 --> Total execution time: 1.2143
INFO - 2016-03-10 13:51:51 --> Config Class Initialized
INFO - 2016-03-10 13:51:51 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:51:51 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:51:51 --> Utf8 Class Initialized
INFO - 2016-03-10 13:51:51 --> URI Class Initialized
INFO - 2016-03-10 13:51:51 --> Router Class Initialized
INFO - 2016-03-10 13:51:51 --> Output Class Initialized
INFO - 2016-03-10 13:51:51 --> Security Class Initialized
DEBUG - 2016-03-10 13:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:51:51 --> Input Class Initialized
INFO - 2016-03-10 13:51:51 --> Language Class Initialized
INFO - 2016-03-10 13:51:51 --> Loader Class Initialized
INFO - 2016-03-10 13:51:51 --> Helper loaded: url_helper
INFO - 2016-03-10 13:51:51 --> Helper loaded: file_helper
INFO - 2016-03-10 13:51:51 --> Helper loaded: date_helper
INFO - 2016-03-10 13:51:51 --> Helper loaded: form_helper
INFO - 2016-03-10 13:51:51 --> Database Driver Class Initialized
INFO - 2016-03-10 13:51:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:51:53 --> Controller Class Initialized
INFO - 2016-03-10 13:51:53 --> Model Class Initialized
INFO - 2016-03-10 13:51:53 --> Model Class Initialized
INFO - 2016-03-10 13:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:51:53 --> Pagination Class Initialized
INFO - 2016-03-10 13:51:53 --> Helper loaded: text_helper
INFO - 2016-03-10 13:51:53 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:51:53 --> Final output sent to browser
DEBUG - 2016-03-10 16:51:53 --> Total execution time: 1.1880
INFO - 2016-03-10 13:51:56 --> Config Class Initialized
INFO - 2016-03-10 13:51:56 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:51:56 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:51:56 --> Utf8 Class Initialized
INFO - 2016-03-10 13:51:56 --> URI Class Initialized
INFO - 2016-03-10 13:51:56 --> Router Class Initialized
INFO - 2016-03-10 13:51:56 --> Output Class Initialized
INFO - 2016-03-10 13:51:56 --> Security Class Initialized
DEBUG - 2016-03-10 13:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:51:56 --> Input Class Initialized
INFO - 2016-03-10 13:51:56 --> Language Class Initialized
INFO - 2016-03-10 13:51:56 --> Loader Class Initialized
INFO - 2016-03-10 13:51:56 --> Helper loaded: url_helper
INFO - 2016-03-10 13:51:56 --> Helper loaded: file_helper
INFO - 2016-03-10 13:51:56 --> Helper loaded: date_helper
INFO - 2016-03-10 13:51:56 --> Helper loaded: form_helper
INFO - 2016-03-10 13:51:56 --> Database Driver Class Initialized
INFO - 2016-03-10 13:51:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:51:57 --> Controller Class Initialized
INFO - 2016-03-10 13:51:57 --> Model Class Initialized
INFO - 2016-03-10 13:51:57 --> Model Class Initialized
INFO - 2016-03-10 13:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:51:57 --> Pagination Class Initialized
INFO - 2016-03-10 13:51:57 --> Helper loaded: text_helper
INFO - 2016-03-10 13:51:57 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:51:57 --> Severity: Notice --> Undefined variable: nini C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 142
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:51:57 --> Final output sent to browser
DEBUG - 2016-03-10 16:51:57 --> Total execution time: 1.2011
INFO - 2016-03-10 13:52:16 --> Config Class Initialized
INFO - 2016-03-10 13:52:16 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:52:16 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:52:16 --> Utf8 Class Initialized
INFO - 2016-03-10 13:52:16 --> URI Class Initialized
INFO - 2016-03-10 13:52:16 --> Router Class Initialized
INFO - 2016-03-10 13:52:16 --> Output Class Initialized
INFO - 2016-03-10 13:52:16 --> Security Class Initialized
DEBUG - 2016-03-10 13:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:52:16 --> Input Class Initialized
INFO - 2016-03-10 13:52:16 --> Language Class Initialized
INFO - 2016-03-10 13:52:16 --> Loader Class Initialized
INFO - 2016-03-10 13:52:16 --> Helper loaded: url_helper
INFO - 2016-03-10 13:52:16 --> Helper loaded: file_helper
INFO - 2016-03-10 13:52:16 --> Helper loaded: date_helper
INFO - 2016-03-10 13:52:16 --> Helper loaded: form_helper
INFO - 2016-03-10 13:52:16 --> Database Driver Class Initialized
INFO - 2016-03-10 13:52:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:52:17 --> Controller Class Initialized
INFO - 2016-03-10 13:52:18 --> Model Class Initialized
INFO - 2016-03-10 13:52:18 --> Model Class Initialized
INFO - 2016-03-10 13:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:52:18 --> Pagination Class Initialized
INFO - 2016-03-10 13:52:18 --> Helper loaded: text_helper
INFO - 2016-03-10 13:52:18 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:52:18 --> Final output sent to browser
DEBUG - 2016-03-10 16:52:18 --> Total execution time: 1.4042
INFO - 2016-03-10 13:52:50 --> Config Class Initialized
INFO - 2016-03-10 13:52:50 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:52:50 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:52:50 --> Utf8 Class Initialized
INFO - 2016-03-10 13:52:50 --> URI Class Initialized
INFO - 2016-03-10 13:52:50 --> Router Class Initialized
INFO - 2016-03-10 13:52:50 --> Output Class Initialized
INFO - 2016-03-10 13:52:50 --> Security Class Initialized
DEBUG - 2016-03-10 13:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:52:50 --> Input Class Initialized
INFO - 2016-03-10 13:52:50 --> Language Class Initialized
INFO - 2016-03-10 13:52:50 --> Loader Class Initialized
INFO - 2016-03-10 13:52:50 --> Helper loaded: url_helper
INFO - 2016-03-10 13:52:50 --> Helper loaded: file_helper
INFO - 2016-03-10 13:52:50 --> Helper loaded: date_helper
INFO - 2016-03-10 13:52:50 --> Helper loaded: form_helper
INFO - 2016-03-10 13:52:50 --> Database Driver Class Initialized
INFO - 2016-03-10 13:52:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:52:52 --> Controller Class Initialized
INFO - 2016-03-10 13:52:52 --> Model Class Initialized
INFO - 2016-03-10 13:52:52 --> Model Class Initialized
INFO - 2016-03-10 13:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:52:52 --> Pagination Class Initialized
INFO - 2016-03-10 13:52:52 --> Helper loaded: text_helper
INFO - 2016-03-10 13:52:52 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined variable: page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 135
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:52:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:52:52 --> Final output sent to browser
DEBUG - 2016-03-10 16:52:52 --> Total execution time: 1.4823
INFO - 2016-03-10 13:53:03 --> Config Class Initialized
INFO - 2016-03-10 13:53:03 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:53:03 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:53:03 --> Utf8 Class Initialized
INFO - 2016-03-10 13:53:03 --> URI Class Initialized
INFO - 2016-03-10 13:53:03 --> Router Class Initialized
INFO - 2016-03-10 13:53:03 --> Output Class Initialized
INFO - 2016-03-10 13:53:03 --> Security Class Initialized
DEBUG - 2016-03-10 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:53:03 --> Input Class Initialized
INFO - 2016-03-10 13:53:03 --> Language Class Initialized
INFO - 2016-03-10 13:53:03 --> Loader Class Initialized
INFO - 2016-03-10 13:53:03 --> Helper loaded: url_helper
INFO - 2016-03-10 13:53:03 --> Helper loaded: file_helper
INFO - 2016-03-10 13:53:03 --> Helper loaded: date_helper
INFO - 2016-03-10 13:53:03 --> Helper loaded: form_helper
INFO - 2016-03-10 13:53:03 --> Database Driver Class Initialized
INFO - 2016-03-10 13:53:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:53:04 --> Controller Class Initialized
INFO - 2016-03-10 13:53:04 --> Model Class Initialized
INFO - 2016-03-10 13:53:04 --> Model Class Initialized
INFO - 2016-03-10 13:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:53:04 --> Pagination Class Initialized
INFO - 2016-03-10 13:53:04 --> Helper loaded: text_helper
INFO - 2016-03-10 13:53:04 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:53:04 --> Final output sent to browser
DEBUG - 2016-03-10 16:53:04 --> Total execution time: 1.1640
INFO - 2016-03-10 13:53:06 --> Config Class Initialized
INFO - 2016-03-10 13:53:06 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:53:06 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:53:06 --> Utf8 Class Initialized
INFO - 2016-03-10 13:53:06 --> URI Class Initialized
INFO - 2016-03-10 13:53:06 --> Router Class Initialized
INFO - 2016-03-10 13:53:06 --> Output Class Initialized
INFO - 2016-03-10 13:53:06 --> Security Class Initialized
DEBUG - 2016-03-10 13:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:53:06 --> Input Class Initialized
INFO - 2016-03-10 13:53:06 --> Language Class Initialized
INFO - 2016-03-10 13:53:06 --> Loader Class Initialized
INFO - 2016-03-10 13:53:06 --> Helper loaded: url_helper
INFO - 2016-03-10 13:53:06 --> Helper loaded: file_helper
INFO - 2016-03-10 13:53:06 --> Helper loaded: date_helper
INFO - 2016-03-10 13:53:06 --> Helper loaded: form_helper
INFO - 2016-03-10 13:53:06 --> Database Driver Class Initialized
INFO - 2016-03-10 13:53:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:53:07 --> Controller Class Initialized
INFO - 2016-03-10 13:53:07 --> Model Class Initialized
INFO - 2016-03-10 13:53:07 --> Model Class Initialized
INFO - 2016-03-10 13:53:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:53:07 --> Pagination Class Initialized
INFO - 2016-03-10 13:53:07 --> Helper loaded: text_helper
INFO - 2016-03-10 13:53:07 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined variable: page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 135
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:53:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:53:07 --> Final output sent to browser
DEBUG - 2016-03-10 16:53:07 --> Total execution time: 1.4019
INFO - 2016-03-10 13:53:08 --> Config Class Initialized
INFO - 2016-03-10 13:53:08 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:53:08 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:53:08 --> Utf8 Class Initialized
INFO - 2016-03-10 13:53:08 --> URI Class Initialized
INFO - 2016-03-10 13:53:08 --> Router Class Initialized
INFO - 2016-03-10 13:53:08 --> Output Class Initialized
INFO - 2016-03-10 13:53:08 --> Security Class Initialized
DEBUG - 2016-03-10 13:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:53:08 --> Input Class Initialized
INFO - 2016-03-10 13:53:08 --> Language Class Initialized
INFO - 2016-03-10 13:53:08 --> Loader Class Initialized
INFO - 2016-03-10 13:53:08 --> Helper loaded: url_helper
INFO - 2016-03-10 13:53:08 --> Helper loaded: file_helper
INFO - 2016-03-10 13:53:08 --> Helper loaded: date_helper
INFO - 2016-03-10 13:53:08 --> Helper loaded: form_helper
INFO - 2016-03-10 13:53:08 --> Database Driver Class Initialized
INFO - 2016-03-10 13:53:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:53:09 --> Controller Class Initialized
INFO - 2016-03-10 13:53:09 --> Model Class Initialized
INFO - 2016-03-10 13:53:09 --> Model Class Initialized
INFO - 2016-03-10 13:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:53:09 --> Pagination Class Initialized
INFO - 2016-03-10 13:53:09 --> Helper loaded: text_helper
INFO - 2016-03-10 13:53:09 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:53:10 --> Final output sent to browser
DEBUG - 2016-03-10 16:53:10 --> Total execution time: 1.1491
INFO - 2016-03-10 13:53:11 --> Config Class Initialized
INFO - 2016-03-10 13:53:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:53:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:53:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:53:11 --> URI Class Initialized
INFO - 2016-03-10 13:53:11 --> Router Class Initialized
INFO - 2016-03-10 13:53:11 --> Output Class Initialized
INFO - 2016-03-10 13:53:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:53:11 --> Input Class Initialized
INFO - 2016-03-10 13:53:11 --> Language Class Initialized
INFO - 2016-03-10 13:53:11 --> Loader Class Initialized
INFO - 2016-03-10 13:53:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:53:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:53:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:53:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:53:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:53:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:53:12 --> Controller Class Initialized
INFO - 2016-03-10 13:53:12 --> Model Class Initialized
INFO - 2016-03-10 13:53:12 --> Model Class Initialized
INFO - 2016-03-10 13:53:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:53:12 --> Pagination Class Initialized
INFO - 2016-03-10 13:53:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:53:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:53:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:53:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:53:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:53:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:53:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:53:12 --> Final output sent to browser
DEBUG - 2016-03-10 16:53:12 --> Total execution time: 1.1582
INFO - 2016-03-10 13:53:14 --> Config Class Initialized
INFO - 2016-03-10 13:53:14 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:53:14 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:53:14 --> Utf8 Class Initialized
INFO - 2016-03-10 13:53:14 --> URI Class Initialized
INFO - 2016-03-10 13:53:14 --> Router Class Initialized
INFO - 2016-03-10 13:53:14 --> Output Class Initialized
INFO - 2016-03-10 13:53:14 --> Security Class Initialized
DEBUG - 2016-03-10 13:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:53:14 --> Input Class Initialized
INFO - 2016-03-10 13:53:14 --> Language Class Initialized
INFO - 2016-03-10 13:53:14 --> Loader Class Initialized
INFO - 2016-03-10 13:53:14 --> Helper loaded: url_helper
INFO - 2016-03-10 13:53:14 --> Helper loaded: file_helper
INFO - 2016-03-10 13:53:14 --> Helper loaded: date_helper
INFO - 2016-03-10 13:53:14 --> Helper loaded: form_helper
INFO - 2016-03-10 13:53:14 --> Database Driver Class Initialized
INFO - 2016-03-10 13:53:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:53:16 --> Controller Class Initialized
INFO - 2016-03-10 13:53:16 --> Model Class Initialized
INFO - 2016-03-10 13:53:16 --> Model Class Initialized
INFO - 2016-03-10 13:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:53:16 --> Pagination Class Initialized
INFO - 2016-03-10 13:53:16 --> Helper loaded: text_helper
INFO - 2016-03-10 13:53:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined variable: page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 135
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:53:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:53:16 --> Final output sent to browser
DEBUG - 2016-03-10 16:53:16 --> Total execution time: 1.4049
INFO - 2016-03-10 13:54:12 --> Config Class Initialized
INFO - 2016-03-10 13:54:12 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:54:12 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:54:12 --> Utf8 Class Initialized
INFO - 2016-03-10 13:54:12 --> URI Class Initialized
INFO - 2016-03-10 13:54:12 --> Router Class Initialized
INFO - 2016-03-10 13:54:12 --> Output Class Initialized
INFO - 2016-03-10 13:54:12 --> Security Class Initialized
DEBUG - 2016-03-10 13:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:54:12 --> Input Class Initialized
INFO - 2016-03-10 13:54:12 --> Language Class Initialized
INFO - 2016-03-10 13:54:12 --> Loader Class Initialized
INFO - 2016-03-10 13:54:12 --> Helper loaded: url_helper
INFO - 2016-03-10 13:54:12 --> Helper loaded: file_helper
INFO - 2016-03-10 13:54:12 --> Helper loaded: date_helper
INFO - 2016-03-10 13:54:12 --> Helper loaded: form_helper
INFO - 2016-03-10 13:54:12 --> Database Driver Class Initialized
INFO - 2016-03-10 13:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:54:13 --> Controller Class Initialized
INFO - 2016-03-10 13:54:13 --> Model Class Initialized
INFO - 2016-03-10 13:54:13 --> Model Class Initialized
INFO - 2016-03-10 13:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:54:13 --> Pagination Class Initialized
INFO - 2016-03-10 13:54:13 --> Helper loaded: text_helper
INFO - 2016-03-10 13:54:13 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:54:13 --> Final output sent to browser
DEBUG - 2016-03-10 16:54:13 --> Total execution time: 1.4009
INFO - 2016-03-10 13:54:37 --> Config Class Initialized
INFO - 2016-03-10 13:54:37 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:54:37 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:54:37 --> Utf8 Class Initialized
INFO - 2016-03-10 13:54:37 --> URI Class Initialized
INFO - 2016-03-10 13:54:37 --> Router Class Initialized
INFO - 2016-03-10 13:54:37 --> Output Class Initialized
INFO - 2016-03-10 13:54:37 --> Security Class Initialized
DEBUG - 2016-03-10 13:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:54:37 --> Input Class Initialized
INFO - 2016-03-10 13:54:37 --> Language Class Initialized
INFO - 2016-03-10 13:54:37 --> Loader Class Initialized
INFO - 2016-03-10 13:54:37 --> Helper loaded: url_helper
INFO - 2016-03-10 13:54:37 --> Helper loaded: file_helper
INFO - 2016-03-10 13:54:37 --> Helper loaded: date_helper
INFO - 2016-03-10 13:54:37 --> Helper loaded: form_helper
INFO - 2016-03-10 13:54:37 --> Database Driver Class Initialized
INFO - 2016-03-10 13:54:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:54:38 --> Controller Class Initialized
INFO - 2016-03-10 13:54:38 --> Model Class Initialized
INFO - 2016-03-10 13:54:38 --> Model Class Initialized
INFO - 2016-03-10 13:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:54:38 --> Pagination Class Initialized
INFO - 2016-03-10 13:54:38 --> Helper loaded: text_helper
INFO - 2016-03-10 13:54:38 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:54:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:54:38 --> Final output sent to browser
DEBUG - 2016-03-10 16:54:38 --> Total execution time: 1.3783
INFO - 2016-03-10 13:55:46 --> Config Class Initialized
INFO - 2016-03-10 13:55:46 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:55:46 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:55:46 --> Utf8 Class Initialized
INFO - 2016-03-10 13:55:46 --> URI Class Initialized
INFO - 2016-03-10 13:55:46 --> Router Class Initialized
INFO - 2016-03-10 13:55:46 --> Output Class Initialized
INFO - 2016-03-10 13:55:46 --> Security Class Initialized
DEBUG - 2016-03-10 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:55:46 --> Input Class Initialized
INFO - 2016-03-10 13:55:46 --> Language Class Initialized
INFO - 2016-03-10 13:55:46 --> Loader Class Initialized
INFO - 2016-03-10 13:55:46 --> Helper loaded: url_helper
INFO - 2016-03-10 13:55:46 --> Helper loaded: file_helper
INFO - 2016-03-10 13:55:46 --> Helper loaded: date_helper
INFO - 2016-03-10 13:55:46 --> Helper loaded: form_helper
INFO - 2016-03-10 13:55:46 --> Database Driver Class Initialized
INFO - 2016-03-10 13:55:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:55:47 --> Controller Class Initialized
INFO - 2016-03-10 13:55:47 --> Model Class Initialized
INFO - 2016-03-10 13:55:47 --> Model Class Initialized
INFO - 2016-03-10 13:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:55:47 --> Pagination Class Initialized
INFO - 2016-03-10 13:55:47 --> Helper loaded: text_helper
INFO - 2016-03-10 13:55:47 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 16:55:47 --> Severity: Error --> Call to undefined method CI_URI::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 135
INFO - 2016-03-10 13:56:01 --> Config Class Initialized
INFO - 2016-03-10 13:56:01 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:01 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:01 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:01 --> URI Class Initialized
INFO - 2016-03-10 13:56:01 --> Router Class Initialized
INFO - 2016-03-10 13:56:01 --> Output Class Initialized
INFO - 2016-03-10 13:56:01 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:01 --> Input Class Initialized
INFO - 2016-03-10 13:56:01 --> Language Class Initialized
INFO - 2016-03-10 13:56:01 --> Loader Class Initialized
INFO - 2016-03-10 13:56:01 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:01 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:01 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:01 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:01 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:03 --> Controller Class Initialized
INFO - 2016-03-10 13:56:03 --> Model Class Initialized
INFO - 2016-03-10 13:56:03 --> Model Class Initialized
INFO - 2016-03-10 13:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:03 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:03 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:03 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:03 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:03 --> Total execution time: 1.3607
INFO - 2016-03-10 13:56:11 --> Config Class Initialized
INFO - 2016-03-10 13:56:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:11 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:11 --> URI Class Initialized
INFO - 2016-03-10 13:56:11 --> Router Class Initialized
INFO - 2016-03-10 13:56:11 --> Output Class Initialized
INFO - 2016-03-10 13:56:11 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:11 --> Input Class Initialized
INFO - 2016-03-10 13:56:11 --> Language Class Initialized
INFO - 2016-03-10 13:56:11 --> Loader Class Initialized
INFO - 2016-03-10 13:56:11 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:11 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:11 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:11 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:11 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:12 --> Controller Class Initialized
INFO - 2016-03-10 13:56:12 --> Model Class Initialized
INFO - 2016-03-10 13:56:12 --> Model Class Initialized
INFO - 2016-03-10 13:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:12 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:12 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:12 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:12 --> Total execution time: 1.1251
INFO - 2016-03-10 13:56:15 --> Config Class Initialized
INFO - 2016-03-10 13:56:15 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:15 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:15 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:15 --> URI Class Initialized
INFO - 2016-03-10 13:56:15 --> Router Class Initialized
INFO - 2016-03-10 13:56:15 --> Output Class Initialized
INFO - 2016-03-10 13:56:15 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:15 --> Input Class Initialized
INFO - 2016-03-10 13:56:15 --> Language Class Initialized
INFO - 2016-03-10 13:56:15 --> Loader Class Initialized
INFO - 2016-03-10 13:56:15 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:15 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:15 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:15 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:15 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:16 --> Controller Class Initialized
INFO - 2016-03-10 13:56:16 --> Model Class Initialized
INFO - 2016-03-10 13:56:16 --> Model Class Initialized
INFO - 2016-03-10 13:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:16 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:16 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:16 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:16 --> Total execution time: 1.1229
INFO - 2016-03-10 13:56:20 --> Config Class Initialized
INFO - 2016-03-10 13:56:20 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:20 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:20 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:20 --> URI Class Initialized
INFO - 2016-03-10 13:56:20 --> Router Class Initialized
INFO - 2016-03-10 13:56:20 --> Output Class Initialized
INFO - 2016-03-10 13:56:20 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:20 --> Input Class Initialized
INFO - 2016-03-10 13:56:20 --> Language Class Initialized
INFO - 2016-03-10 13:56:20 --> Loader Class Initialized
INFO - 2016-03-10 13:56:20 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:20 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:20 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:20 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:20 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:21 --> Controller Class Initialized
INFO - 2016-03-10 13:56:21 --> Model Class Initialized
INFO - 2016-03-10 13:56:21 --> Model Class Initialized
INFO - 2016-03-10 13:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:21 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:21 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:21 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:21 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:21 --> Total execution time: 1.3578
INFO - 2016-03-10 13:56:26 --> Config Class Initialized
INFO - 2016-03-10 13:56:26 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:26 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:26 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:26 --> URI Class Initialized
INFO - 2016-03-10 13:56:26 --> Router Class Initialized
INFO - 2016-03-10 13:56:26 --> Output Class Initialized
INFO - 2016-03-10 13:56:26 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:26 --> Input Class Initialized
INFO - 2016-03-10 13:56:26 --> Language Class Initialized
INFO - 2016-03-10 13:56:26 --> Loader Class Initialized
INFO - 2016-03-10 13:56:26 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:26 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:26 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:26 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:26 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:27 --> Controller Class Initialized
INFO - 2016-03-10 13:56:27 --> Model Class Initialized
INFO - 2016-03-10 13:56:27 --> Model Class Initialized
INFO - 2016-03-10 13:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:27 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:27 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:27 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 16:56:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 16:56:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:27 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:27 --> Total execution time: 1.2273
INFO - 2016-03-10 13:56:30 --> Config Class Initialized
INFO - 2016-03-10 13:56:30 --> Hooks Class Initialized
DEBUG - 2016-03-10 13:56:30 --> UTF-8 Support Enabled
INFO - 2016-03-10 13:56:30 --> Utf8 Class Initialized
INFO - 2016-03-10 13:56:30 --> URI Class Initialized
INFO - 2016-03-10 13:56:30 --> Router Class Initialized
INFO - 2016-03-10 13:56:30 --> Output Class Initialized
INFO - 2016-03-10 13:56:30 --> Security Class Initialized
DEBUG - 2016-03-10 13:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 13:56:30 --> Input Class Initialized
INFO - 2016-03-10 13:56:30 --> Language Class Initialized
INFO - 2016-03-10 13:56:30 --> Loader Class Initialized
INFO - 2016-03-10 13:56:30 --> Helper loaded: url_helper
INFO - 2016-03-10 13:56:30 --> Helper loaded: file_helper
INFO - 2016-03-10 13:56:30 --> Helper loaded: date_helper
INFO - 2016-03-10 13:56:30 --> Helper loaded: form_helper
INFO - 2016-03-10 13:56:30 --> Database Driver Class Initialized
INFO - 2016-03-10 13:56:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 13:56:31 --> Controller Class Initialized
INFO - 2016-03-10 13:56:31 --> Model Class Initialized
INFO - 2016-03-10 13:56:31 --> Model Class Initialized
INFO - 2016-03-10 13:56:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 13:56:31 --> Pagination Class Initialized
INFO - 2016-03-10 13:56:31 --> Helper loaded: text_helper
INFO - 2016-03-10 13:56:31 --> Helper loaded: cookie_helper
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-10 16:56:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 16:56:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 16:56:31 --> Final output sent to browser
DEBUG - 2016-03-10 16:56:31 --> Total execution time: 1.3094
INFO - 2016-03-10 14:00:39 --> Config Class Initialized
INFO - 2016-03-10 14:00:39 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:00:39 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:00:39 --> Utf8 Class Initialized
INFO - 2016-03-10 14:00:39 --> URI Class Initialized
INFO - 2016-03-10 14:00:39 --> Router Class Initialized
INFO - 2016-03-10 14:00:39 --> Output Class Initialized
INFO - 2016-03-10 14:00:39 --> Security Class Initialized
DEBUG - 2016-03-10 14:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:00:39 --> Input Class Initialized
INFO - 2016-03-10 14:00:39 --> Language Class Initialized
INFO - 2016-03-10 14:00:39 --> Loader Class Initialized
INFO - 2016-03-10 14:00:39 --> Helper loaded: url_helper
INFO - 2016-03-10 14:00:39 --> Helper loaded: file_helper
INFO - 2016-03-10 14:00:39 --> Helper loaded: date_helper
INFO - 2016-03-10 14:00:39 --> Helper loaded: form_helper
INFO - 2016-03-10 14:00:39 --> Database Driver Class Initialized
INFO - 2016-03-10 14:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:00:40 --> Controller Class Initialized
INFO - 2016-03-10 14:00:40 --> Model Class Initialized
INFO - 2016-03-10 14:00:40 --> Model Class Initialized
INFO - 2016-03-10 14:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:00:40 --> Pagination Class Initialized
INFO - 2016-03-10 14:00:40 --> Helper loaded: text_helper
INFO - 2016-03-10 14:00:40 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:00:40 --> Final output sent to browser
DEBUG - 2016-03-10 17:00:40 --> Total execution time: 1.1723
INFO - 2016-03-10 14:00:42 --> Config Class Initialized
INFO - 2016-03-10 14:00:42 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:00:42 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:00:42 --> Utf8 Class Initialized
INFO - 2016-03-10 14:00:42 --> URI Class Initialized
INFO - 2016-03-10 14:00:42 --> Router Class Initialized
INFO - 2016-03-10 14:00:42 --> Output Class Initialized
INFO - 2016-03-10 14:00:42 --> Security Class Initialized
DEBUG - 2016-03-10 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:00:42 --> Input Class Initialized
INFO - 2016-03-10 14:00:42 --> Language Class Initialized
INFO - 2016-03-10 14:00:42 --> Loader Class Initialized
INFO - 2016-03-10 14:00:42 --> Helper loaded: url_helper
INFO - 2016-03-10 14:00:42 --> Helper loaded: file_helper
INFO - 2016-03-10 14:00:42 --> Helper loaded: date_helper
INFO - 2016-03-10 14:00:42 --> Helper loaded: form_helper
INFO - 2016-03-10 14:00:42 --> Database Driver Class Initialized
INFO - 2016-03-10 14:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:00:43 --> Controller Class Initialized
INFO - 2016-03-10 14:00:43 --> Model Class Initialized
INFO - 2016-03-10 14:00:43 --> Model Class Initialized
INFO - 2016-03-10 14:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:00:43 --> Pagination Class Initialized
INFO - 2016-03-10 14:00:43 --> Helper loaded: text_helper
INFO - 2016-03-10 14:00:43 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:00:43 --> Final output sent to browser
DEBUG - 2016-03-10 17:00:43 --> Total execution time: 1.1535
INFO - 2016-03-10 14:00:45 --> Config Class Initialized
INFO - 2016-03-10 14:00:45 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:00:45 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:00:45 --> Utf8 Class Initialized
INFO - 2016-03-10 14:00:45 --> URI Class Initialized
INFO - 2016-03-10 14:00:45 --> Router Class Initialized
INFO - 2016-03-10 14:00:45 --> Output Class Initialized
INFO - 2016-03-10 14:00:45 --> Security Class Initialized
DEBUG - 2016-03-10 14:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:00:45 --> Input Class Initialized
INFO - 2016-03-10 14:00:45 --> Language Class Initialized
INFO - 2016-03-10 14:00:45 --> Loader Class Initialized
INFO - 2016-03-10 14:00:45 --> Helper loaded: url_helper
INFO - 2016-03-10 14:00:45 --> Helper loaded: file_helper
INFO - 2016-03-10 14:00:45 --> Helper loaded: date_helper
INFO - 2016-03-10 14:00:45 --> Helper loaded: form_helper
INFO - 2016-03-10 14:00:45 --> Database Driver Class Initialized
INFO - 2016-03-10 14:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:00:46 --> Controller Class Initialized
INFO - 2016-03-10 14:00:46 --> Model Class Initialized
INFO - 2016-03-10 14:00:46 --> Model Class Initialized
INFO - 2016-03-10 14:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:00:46 --> Pagination Class Initialized
INFO - 2016-03-10 14:00:46 --> Helper loaded: text_helper
INFO - 2016-03-10 14:00:46 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:00:46 --> Final output sent to browser
DEBUG - 2016-03-10 17:00:46 --> Total execution time: 1.1797
INFO - 2016-03-10 14:01:02 --> Config Class Initialized
INFO - 2016-03-10 14:01:02 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:01:02 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:01:02 --> Utf8 Class Initialized
INFO - 2016-03-10 14:01:02 --> URI Class Initialized
INFO - 2016-03-10 14:01:02 --> Router Class Initialized
INFO - 2016-03-10 14:01:02 --> Output Class Initialized
INFO - 2016-03-10 14:01:02 --> Security Class Initialized
DEBUG - 2016-03-10 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:01:02 --> Input Class Initialized
INFO - 2016-03-10 14:01:02 --> Language Class Initialized
INFO - 2016-03-10 14:01:02 --> Loader Class Initialized
INFO - 2016-03-10 14:01:02 --> Helper loaded: url_helper
INFO - 2016-03-10 14:01:02 --> Helper loaded: file_helper
INFO - 2016-03-10 14:01:02 --> Helper loaded: date_helper
INFO - 2016-03-10 14:01:02 --> Helper loaded: form_helper
INFO - 2016-03-10 14:01:02 --> Database Driver Class Initialized
INFO - 2016-03-10 14:01:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:01:03 --> Controller Class Initialized
INFO - 2016-03-10 14:01:03 --> Model Class Initialized
INFO - 2016-03-10 14:01:03 --> Model Class Initialized
INFO - 2016-03-10 14:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:01:04 --> Pagination Class Initialized
INFO - 2016-03-10 14:01:04 --> Helper loaded: text_helper
INFO - 2016-03-10 14:01:04 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:01:04 --> Final output sent to browser
DEBUG - 2016-03-10 17:01:04 --> Total execution time: 1.1431
INFO - 2016-03-10 14:01:08 --> Config Class Initialized
INFO - 2016-03-10 14:01:08 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:01:08 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:01:08 --> Utf8 Class Initialized
INFO - 2016-03-10 14:01:08 --> URI Class Initialized
INFO - 2016-03-10 14:01:08 --> Router Class Initialized
INFO - 2016-03-10 14:01:08 --> Output Class Initialized
INFO - 2016-03-10 14:01:08 --> Security Class Initialized
DEBUG - 2016-03-10 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:01:08 --> Input Class Initialized
INFO - 2016-03-10 14:01:08 --> Language Class Initialized
INFO - 2016-03-10 14:01:08 --> Loader Class Initialized
INFO - 2016-03-10 14:01:08 --> Helper loaded: url_helper
INFO - 2016-03-10 14:01:08 --> Helper loaded: file_helper
INFO - 2016-03-10 14:01:08 --> Helper loaded: date_helper
INFO - 2016-03-10 14:01:08 --> Helper loaded: form_helper
INFO - 2016-03-10 14:01:08 --> Database Driver Class Initialized
INFO - 2016-03-10 14:01:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:01:09 --> Controller Class Initialized
INFO - 2016-03-10 14:01:09 --> Model Class Initialized
INFO - 2016-03-10 14:01:09 --> Model Class Initialized
INFO - 2016-03-10 14:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:01:09 --> Pagination Class Initialized
INFO - 2016-03-10 14:01:09 --> Helper loaded: text_helper
INFO - 2016-03-10 14:01:09 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:01:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:01:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:01:10 --> Final output sent to browser
DEBUG - 2016-03-10 17:01:10 --> Total execution time: 1.1589
INFO - 2016-03-10 14:01:12 --> Config Class Initialized
INFO - 2016-03-10 14:01:12 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:01:12 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:01:12 --> Utf8 Class Initialized
INFO - 2016-03-10 14:01:12 --> URI Class Initialized
INFO - 2016-03-10 14:01:12 --> Router Class Initialized
INFO - 2016-03-10 14:01:12 --> Output Class Initialized
INFO - 2016-03-10 14:01:12 --> Security Class Initialized
DEBUG - 2016-03-10 14:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:01:12 --> Input Class Initialized
INFO - 2016-03-10 14:01:12 --> Language Class Initialized
INFO - 2016-03-10 14:01:12 --> Loader Class Initialized
INFO - 2016-03-10 14:01:12 --> Helper loaded: url_helper
INFO - 2016-03-10 14:01:12 --> Helper loaded: file_helper
INFO - 2016-03-10 14:01:12 --> Helper loaded: date_helper
INFO - 2016-03-10 14:01:12 --> Helper loaded: form_helper
INFO - 2016-03-10 14:01:12 --> Database Driver Class Initialized
INFO - 2016-03-10 14:01:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:01:13 --> Controller Class Initialized
INFO - 2016-03-10 14:01:13 --> Model Class Initialized
INFO - 2016-03-10 14:01:13 --> Model Class Initialized
INFO - 2016-03-10 14:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:01:13 --> Pagination Class Initialized
INFO - 2016-03-10 14:01:14 --> Helper loaded: text_helper
INFO - 2016-03-10 14:01:14 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:01:14 --> Final output sent to browser
DEBUG - 2016-03-10 17:01:14 --> Total execution time: 1.1969
INFO - 2016-03-10 14:11:35 --> Config Class Initialized
INFO - 2016-03-10 14:11:35 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:11:35 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:11:35 --> Utf8 Class Initialized
INFO - 2016-03-10 14:11:35 --> URI Class Initialized
INFO - 2016-03-10 14:11:35 --> Router Class Initialized
INFO - 2016-03-10 14:11:35 --> Output Class Initialized
INFO - 2016-03-10 14:11:35 --> Security Class Initialized
DEBUG - 2016-03-10 14:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:11:35 --> Input Class Initialized
INFO - 2016-03-10 14:11:35 --> Language Class Initialized
INFO - 2016-03-10 14:11:35 --> Loader Class Initialized
INFO - 2016-03-10 14:11:35 --> Helper loaded: url_helper
INFO - 2016-03-10 14:11:35 --> Helper loaded: file_helper
INFO - 2016-03-10 14:11:35 --> Helper loaded: date_helper
INFO - 2016-03-10 14:11:35 --> Helper loaded: form_helper
INFO - 2016-03-10 14:11:35 --> Database Driver Class Initialized
INFO - 2016-03-10 14:11:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:11:36 --> Controller Class Initialized
INFO - 2016-03-10 14:11:36 --> Model Class Initialized
INFO - 2016-03-10 14:11:36 --> Model Class Initialized
INFO - 2016-03-10 14:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:11:36 --> Pagination Class Initialized
INFO - 2016-03-10 14:11:36 --> Helper loaded: text_helper
INFO - 2016-03-10 14:11:36 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:11:36 --> Final output sent to browser
DEBUG - 2016-03-10 17:11:36 --> Total execution time: 1.1464
INFO - 2016-03-10 14:11:38 --> Config Class Initialized
INFO - 2016-03-10 14:11:38 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:11:38 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:11:38 --> Utf8 Class Initialized
INFO - 2016-03-10 14:11:38 --> URI Class Initialized
INFO - 2016-03-10 14:11:38 --> Router Class Initialized
INFO - 2016-03-10 14:11:38 --> Output Class Initialized
INFO - 2016-03-10 14:11:38 --> Security Class Initialized
DEBUG - 2016-03-10 14:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:11:38 --> Input Class Initialized
INFO - 2016-03-10 14:11:38 --> Language Class Initialized
INFO - 2016-03-10 14:11:38 --> Loader Class Initialized
INFO - 2016-03-10 14:11:38 --> Helper loaded: url_helper
INFO - 2016-03-10 14:11:38 --> Helper loaded: file_helper
INFO - 2016-03-10 14:11:38 --> Helper loaded: date_helper
INFO - 2016-03-10 14:11:38 --> Helper loaded: form_helper
INFO - 2016-03-10 14:11:38 --> Database Driver Class Initialized
INFO - 2016-03-10 14:11:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:11:39 --> Controller Class Initialized
INFO - 2016-03-10 14:11:39 --> Model Class Initialized
INFO - 2016-03-10 14:11:39 --> Model Class Initialized
INFO - 2016-03-10 14:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:11:39 --> Pagination Class Initialized
INFO - 2016-03-10 14:11:39 --> Helper loaded: text_helper
INFO - 2016-03-10 14:11:39 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:11:39 --> Final output sent to browser
DEBUG - 2016-03-10 17:11:39 --> Total execution time: 1.1622
INFO - 2016-03-10 14:11:41 --> Config Class Initialized
INFO - 2016-03-10 14:11:41 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:11:41 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:11:41 --> Utf8 Class Initialized
INFO - 2016-03-10 14:11:41 --> URI Class Initialized
INFO - 2016-03-10 14:11:41 --> Router Class Initialized
INFO - 2016-03-10 14:11:41 --> Output Class Initialized
INFO - 2016-03-10 14:11:41 --> Security Class Initialized
DEBUG - 2016-03-10 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:11:41 --> Input Class Initialized
INFO - 2016-03-10 14:11:41 --> Language Class Initialized
INFO - 2016-03-10 14:11:41 --> Loader Class Initialized
INFO - 2016-03-10 14:11:41 --> Helper loaded: url_helper
INFO - 2016-03-10 14:11:41 --> Helper loaded: file_helper
INFO - 2016-03-10 14:11:41 --> Helper loaded: date_helper
INFO - 2016-03-10 14:11:41 --> Helper loaded: form_helper
INFO - 2016-03-10 14:11:41 --> Database Driver Class Initialized
INFO - 2016-03-10 14:11:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:11:42 --> Controller Class Initialized
INFO - 2016-03-10 14:11:42 --> Model Class Initialized
INFO - 2016-03-10 14:11:42 --> Model Class Initialized
INFO - 2016-03-10 14:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:11:42 --> Pagination Class Initialized
INFO - 2016-03-10 14:11:42 --> Helper loaded: text_helper
INFO - 2016-03-10 14:11:42 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:11:42 --> Final output sent to browser
DEBUG - 2016-03-10 17:11:42 --> Total execution time: 1.1987
INFO - 2016-03-10 14:12:12 --> Config Class Initialized
INFO - 2016-03-10 14:12:12 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:12:12 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:12:12 --> Utf8 Class Initialized
INFO - 2016-03-10 14:12:12 --> URI Class Initialized
INFO - 2016-03-10 14:12:12 --> Router Class Initialized
INFO - 2016-03-10 14:12:12 --> Output Class Initialized
INFO - 2016-03-10 14:12:12 --> Security Class Initialized
DEBUG - 2016-03-10 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:12:12 --> Input Class Initialized
INFO - 2016-03-10 14:12:12 --> Language Class Initialized
INFO - 2016-03-10 14:12:12 --> Loader Class Initialized
INFO - 2016-03-10 14:12:12 --> Helper loaded: url_helper
INFO - 2016-03-10 14:12:12 --> Helper loaded: file_helper
INFO - 2016-03-10 14:12:12 --> Helper loaded: date_helper
INFO - 2016-03-10 14:12:12 --> Helper loaded: form_helper
INFO - 2016-03-10 14:12:12 --> Database Driver Class Initialized
INFO - 2016-03-10 14:12:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:12:13 --> Controller Class Initialized
INFO - 2016-03-10 14:12:13 --> Model Class Initialized
INFO - 2016-03-10 14:12:13 --> Model Class Initialized
INFO - 2016-03-10 14:12:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:12:13 --> Pagination Class Initialized
INFO - 2016-03-10 14:12:13 --> Helper loaded: text_helper
INFO - 2016-03-10 14:12:13 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:12:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:12:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:12:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:12:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:12:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:12:13 --> Final output sent to browser
DEBUG - 2016-03-10 17:12:13 --> Total execution time: 1.1521
INFO - 2016-03-10 14:12:14 --> Config Class Initialized
INFO - 2016-03-10 14:12:15 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:12:15 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:12:15 --> Utf8 Class Initialized
INFO - 2016-03-10 14:12:15 --> URI Class Initialized
INFO - 2016-03-10 14:12:15 --> Router Class Initialized
INFO - 2016-03-10 14:12:15 --> Output Class Initialized
INFO - 2016-03-10 14:12:15 --> Security Class Initialized
DEBUG - 2016-03-10 14:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:12:15 --> Input Class Initialized
INFO - 2016-03-10 14:12:15 --> Language Class Initialized
INFO - 2016-03-10 14:12:15 --> Loader Class Initialized
INFO - 2016-03-10 14:12:15 --> Helper loaded: url_helper
INFO - 2016-03-10 14:12:15 --> Helper loaded: file_helper
INFO - 2016-03-10 14:12:15 --> Helper loaded: date_helper
INFO - 2016-03-10 14:12:15 --> Helper loaded: form_helper
INFO - 2016-03-10 14:12:15 --> Database Driver Class Initialized
INFO - 2016-03-10 14:12:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:12:16 --> Controller Class Initialized
INFO - 2016-03-10 14:12:16 --> Model Class Initialized
INFO - 2016-03-10 14:12:16 --> Model Class Initialized
INFO - 2016-03-10 14:12:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:12:16 --> Pagination Class Initialized
INFO - 2016-03-10 14:12:16 --> Helper loaded: text_helper
INFO - 2016-03-10 14:12:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:12:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:12:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:12:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:12:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:12:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:12:16 --> Final output sent to browser
DEBUG - 2016-03-10 17:12:16 --> Total execution time: 1.3661
INFO - 2016-03-10 14:12:20 --> Config Class Initialized
INFO - 2016-03-10 14:12:20 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:12:20 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:12:20 --> Utf8 Class Initialized
INFO - 2016-03-10 14:12:20 --> URI Class Initialized
INFO - 2016-03-10 14:12:20 --> Router Class Initialized
INFO - 2016-03-10 14:12:20 --> Output Class Initialized
INFO - 2016-03-10 14:12:20 --> Security Class Initialized
DEBUG - 2016-03-10 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:12:20 --> Input Class Initialized
INFO - 2016-03-10 14:12:20 --> Language Class Initialized
INFO - 2016-03-10 14:12:20 --> Loader Class Initialized
INFO - 2016-03-10 14:12:20 --> Helper loaded: url_helper
INFO - 2016-03-10 14:12:20 --> Helper loaded: file_helper
INFO - 2016-03-10 14:12:20 --> Helper loaded: date_helper
INFO - 2016-03-10 14:12:20 --> Helper loaded: form_helper
INFO - 2016-03-10 14:12:20 --> Database Driver Class Initialized
INFO - 2016-03-10 14:12:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:12:21 --> Controller Class Initialized
INFO - 2016-03-10 14:12:21 --> Model Class Initialized
INFO - 2016-03-10 14:12:21 --> Model Class Initialized
INFO - 2016-03-10 14:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:12:21 --> Pagination Class Initialized
INFO - 2016-03-10 14:12:21 --> Helper loaded: text_helper
INFO - 2016-03-10 14:12:21 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:12:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:12:21 --> Final output sent to browser
DEBUG - 2016-03-10 17:12:21 --> Total execution time: 1.2424
INFO - 2016-03-10 14:12:41 --> Config Class Initialized
INFO - 2016-03-10 14:12:41 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:12:41 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:12:41 --> Utf8 Class Initialized
INFO - 2016-03-10 14:12:41 --> URI Class Initialized
INFO - 2016-03-10 14:12:41 --> Router Class Initialized
INFO - 2016-03-10 14:12:41 --> Output Class Initialized
INFO - 2016-03-10 14:12:41 --> Security Class Initialized
DEBUG - 2016-03-10 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:12:41 --> Input Class Initialized
INFO - 2016-03-10 14:12:41 --> Language Class Initialized
INFO - 2016-03-10 14:12:41 --> Loader Class Initialized
INFO - 2016-03-10 14:12:41 --> Helper loaded: url_helper
INFO - 2016-03-10 14:12:41 --> Helper loaded: file_helper
INFO - 2016-03-10 14:12:41 --> Helper loaded: date_helper
INFO - 2016-03-10 14:12:41 --> Helper loaded: form_helper
INFO - 2016-03-10 14:12:41 --> Database Driver Class Initialized
INFO - 2016-03-10 14:12:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:12:42 --> Controller Class Initialized
INFO - 2016-03-10 14:12:42 --> Model Class Initialized
INFO - 2016-03-10 14:12:42 --> Model Class Initialized
INFO - 2016-03-10 14:12:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:12:42 --> Pagination Class Initialized
INFO - 2016-03-10 14:12:42 --> Helper loaded: text_helper
INFO - 2016-03-10 14:12:42 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:12:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:12:42 --> Final output sent to browser
DEBUG - 2016-03-10 17:12:42 --> Total execution time: 1.2542
INFO - 2016-03-10 14:13:02 --> Config Class Initialized
INFO - 2016-03-10 14:13:02 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:02 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:02 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:02 --> URI Class Initialized
INFO - 2016-03-10 14:13:02 --> Router Class Initialized
INFO - 2016-03-10 14:13:02 --> Output Class Initialized
INFO - 2016-03-10 14:13:02 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:02 --> Input Class Initialized
INFO - 2016-03-10 14:13:02 --> Language Class Initialized
INFO - 2016-03-10 14:13:02 --> Loader Class Initialized
INFO - 2016-03-10 14:13:02 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:02 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:02 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:02 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:02 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:04 --> Controller Class Initialized
INFO - 2016-03-10 14:13:04 --> Model Class Initialized
INFO - 2016-03-10 14:13:04 --> Model Class Initialized
INFO - 2016-03-10 14:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:04 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:04 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:04 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:04 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:04 --> Total execution time: 1.2288
INFO - 2016-03-10 14:13:08 --> Config Class Initialized
INFO - 2016-03-10 14:13:08 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:08 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:08 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:08 --> URI Class Initialized
INFO - 2016-03-10 14:13:08 --> Router Class Initialized
INFO - 2016-03-10 14:13:08 --> Output Class Initialized
INFO - 2016-03-10 14:13:08 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:08 --> Input Class Initialized
INFO - 2016-03-10 14:13:08 --> Language Class Initialized
INFO - 2016-03-10 14:13:08 --> Loader Class Initialized
INFO - 2016-03-10 14:13:08 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:08 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:08 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:08 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:08 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:09 --> Controller Class Initialized
INFO - 2016-03-10 14:13:09 --> Model Class Initialized
INFO - 2016-03-10 14:13:09 --> Model Class Initialized
INFO - 2016-03-10 14:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:09 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:09 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:09 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:09 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:09 --> Total execution time: 1.1534
INFO - 2016-03-10 14:13:11 --> Config Class Initialized
INFO - 2016-03-10 14:13:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:11 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:11 --> URI Class Initialized
INFO - 2016-03-10 14:13:11 --> Router Class Initialized
INFO - 2016-03-10 14:13:11 --> Output Class Initialized
INFO - 2016-03-10 14:13:11 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:11 --> Input Class Initialized
INFO - 2016-03-10 14:13:11 --> Language Class Initialized
INFO - 2016-03-10 14:13:11 --> Loader Class Initialized
INFO - 2016-03-10 14:13:11 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:11 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:11 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:11 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:11 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:12 --> Controller Class Initialized
INFO - 2016-03-10 14:13:12 --> Model Class Initialized
INFO - 2016-03-10 14:13:12 --> Model Class Initialized
INFO - 2016-03-10 14:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:12 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:12 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:12 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:12 --> Total execution time: 1.2941
INFO - 2016-03-10 14:13:13 --> Config Class Initialized
INFO - 2016-03-10 14:13:13 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:13 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:13 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:13 --> URI Class Initialized
INFO - 2016-03-10 14:13:13 --> Router Class Initialized
INFO - 2016-03-10 14:13:13 --> Output Class Initialized
INFO - 2016-03-10 14:13:13 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:13 --> Input Class Initialized
INFO - 2016-03-10 14:13:13 --> Language Class Initialized
INFO - 2016-03-10 14:13:13 --> Loader Class Initialized
INFO - 2016-03-10 14:13:13 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:13 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:13 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:13 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:13 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:14 --> Controller Class Initialized
INFO - 2016-03-10 14:13:14 --> Model Class Initialized
INFO - 2016-03-10 14:13:14 --> Model Class Initialized
INFO - 2016-03-10 14:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:14 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:14 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:14 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:14 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:14 --> Total execution time: 1.1526
INFO - 2016-03-10 14:13:30 --> Config Class Initialized
INFO - 2016-03-10 14:13:30 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:30 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:30 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:30 --> URI Class Initialized
INFO - 2016-03-10 14:13:30 --> Router Class Initialized
INFO - 2016-03-10 14:13:30 --> Output Class Initialized
INFO - 2016-03-10 14:13:30 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:30 --> Input Class Initialized
INFO - 2016-03-10 14:13:30 --> Language Class Initialized
INFO - 2016-03-10 14:13:30 --> Loader Class Initialized
INFO - 2016-03-10 14:13:30 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:30 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:30 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:30 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:30 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:31 --> Controller Class Initialized
INFO - 2016-03-10 14:13:31 --> Model Class Initialized
INFO - 2016-03-10 14:13:31 --> Model Class Initialized
INFO - 2016-03-10 14:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:31 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:31 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:31 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:31 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:31 --> Total execution time: 1.2200
INFO - 2016-03-10 14:13:35 --> Config Class Initialized
INFO - 2016-03-10 14:13:35 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:35 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:35 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:35 --> URI Class Initialized
INFO - 2016-03-10 14:13:35 --> Router Class Initialized
INFO - 2016-03-10 14:13:35 --> Output Class Initialized
INFO - 2016-03-10 14:13:35 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:35 --> Input Class Initialized
INFO - 2016-03-10 14:13:35 --> Language Class Initialized
INFO - 2016-03-10 14:13:35 --> Loader Class Initialized
INFO - 2016-03-10 14:13:35 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:35 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:35 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:35 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:35 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:36 --> Controller Class Initialized
INFO - 2016-03-10 14:13:36 --> Model Class Initialized
INFO - 2016-03-10 14:13:36 --> Model Class Initialized
INFO - 2016-03-10 14:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:36 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:36 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:36 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:36 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:36 --> Total execution time: 1.1422
INFO - 2016-03-10 14:13:38 --> Config Class Initialized
INFO - 2016-03-10 14:13:38 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:38 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:38 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:38 --> URI Class Initialized
INFO - 2016-03-10 14:13:38 --> Router Class Initialized
INFO - 2016-03-10 14:13:38 --> Output Class Initialized
INFO - 2016-03-10 14:13:38 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:38 --> Input Class Initialized
INFO - 2016-03-10 14:13:38 --> Language Class Initialized
INFO - 2016-03-10 14:13:38 --> Loader Class Initialized
INFO - 2016-03-10 14:13:38 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:38 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:38 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:38 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:38 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:39 --> Controller Class Initialized
INFO - 2016-03-10 14:13:39 --> Model Class Initialized
INFO - 2016-03-10 14:13:39 --> Model Class Initialized
INFO - 2016-03-10 14:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:39 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:39 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:39 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:39 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:39 --> Total execution time: 1.1419
INFO - 2016-03-10 14:13:40 --> Config Class Initialized
INFO - 2016-03-10 14:13:40 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:40 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:40 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:40 --> URI Class Initialized
INFO - 2016-03-10 14:13:40 --> Router Class Initialized
INFO - 2016-03-10 14:13:40 --> Output Class Initialized
INFO - 2016-03-10 14:13:40 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:40 --> Input Class Initialized
INFO - 2016-03-10 14:13:40 --> Language Class Initialized
INFO - 2016-03-10 14:13:40 --> Loader Class Initialized
INFO - 2016-03-10 14:13:40 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:40 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:40 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:40 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:40 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:41 --> Controller Class Initialized
INFO - 2016-03-10 14:13:41 --> Model Class Initialized
INFO - 2016-03-10 14:13:41 --> Model Class Initialized
INFO - 2016-03-10 14:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:41 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:41 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:41 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:41 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:41 --> Total execution time: 1.1432
INFO - 2016-03-10 14:13:43 --> Config Class Initialized
INFO - 2016-03-10 14:13:43 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:13:43 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:13:43 --> Utf8 Class Initialized
INFO - 2016-03-10 14:13:43 --> URI Class Initialized
INFO - 2016-03-10 14:13:43 --> Router Class Initialized
INFO - 2016-03-10 14:13:43 --> Output Class Initialized
INFO - 2016-03-10 14:13:43 --> Security Class Initialized
DEBUG - 2016-03-10 14:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:13:43 --> Input Class Initialized
INFO - 2016-03-10 14:13:43 --> Language Class Initialized
INFO - 2016-03-10 14:13:43 --> Loader Class Initialized
INFO - 2016-03-10 14:13:43 --> Helper loaded: url_helper
INFO - 2016-03-10 14:13:43 --> Helper loaded: file_helper
INFO - 2016-03-10 14:13:43 --> Helper loaded: date_helper
INFO - 2016-03-10 14:13:43 --> Helper loaded: form_helper
INFO - 2016-03-10 14:13:43 --> Database Driver Class Initialized
INFO - 2016-03-10 14:13:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:13:44 --> Controller Class Initialized
INFO - 2016-03-10 14:13:44 --> Model Class Initialized
INFO - 2016-03-10 14:13:44 --> Model Class Initialized
INFO - 2016-03-10 14:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:13:44 --> Pagination Class Initialized
INFO - 2016-03-10 14:13:44 --> Helper loaded: text_helper
INFO - 2016-03-10 14:13:44 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:13:44 --> Final output sent to browser
DEBUG - 2016-03-10 17:13:44 --> Total execution time: 1.2667
INFO - 2016-03-10 14:14:04 --> Config Class Initialized
INFO - 2016-03-10 14:14:04 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:14:04 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:14:04 --> Utf8 Class Initialized
INFO - 2016-03-10 14:14:04 --> URI Class Initialized
INFO - 2016-03-10 14:14:04 --> Router Class Initialized
INFO - 2016-03-10 14:14:04 --> Output Class Initialized
INFO - 2016-03-10 14:14:04 --> Security Class Initialized
DEBUG - 2016-03-10 14:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:14:04 --> Input Class Initialized
INFO - 2016-03-10 14:14:04 --> Language Class Initialized
INFO - 2016-03-10 14:14:04 --> Loader Class Initialized
INFO - 2016-03-10 14:14:04 --> Helper loaded: url_helper
INFO - 2016-03-10 14:14:04 --> Helper loaded: file_helper
INFO - 2016-03-10 14:14:04 --> Helper loaded: date_helper
INFO - 2016-03-10 14:14:04 --> Helper loaded: form_helper
INFO - 2016-03-10 14:14:04 --> Database Driver Class Initialized
INFO - 2016-03-10 14:14:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:14:05 --> Controller Class Initialized
INFO - 2016-03-10 14:14:05 --> Model Class Initialized
INFO - 2016-03-10 14:14:05 --> Model Class Initialized
INFO - 2016-03-10 14:14:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:14:05 --> Pagination Class Initialized
INFO - 2016-03-10 14:14:05 --> Helper loaded: text_helper
INFO - 2016-03-10 14:14:05 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:14:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:14:05 --> Final output sent to browser
DEBUG - 2016-03-10 17:14:05 --> Total execution time: 1.2239
INFO - 2016-03-10 14:14:09 --> Config Class Initialized
INFO - 2016-03-10 14:14:09 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:14:09 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:14:09 --> Utf8 Class Initialized
INFO - 2016-03-10 14:14:09 --> URI Class Initialized
INFO - 2016-03-10 14:14:09 --> Router Class Initialized
INFO - 2016-03-10 14:14:09 --> Output Class Initialized
INFO - 2016-03-10 14:14:09 --> Security Class Initialized
DEBUG - 2016-03-10 14:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:14:09 --> Input Class Initialized
INFO - 2016-03-10 14:14:09 --> Language Class Initialized
INFO - 2016-03-10 14:14:09 --> Loader Class Initialized
INFO - 2016-03-10 14:14:09 --> Helper loaded: url_helper
INFO - 2016-03-10 14:14:09 --> Helper loaded: file_helper
INFO - 2016-03-10 14:14:09 --> Helper loaded: date_helper
INFO - 2016-03-10 14:14:09 --> Helper loaded: form_helper
INFO - 2016-03-10 14:14:09 --> Database Driver Class Initialized
INFO - 2016-03-10 14:14:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:14:10 --> Controller Class Initialized
INFO - 2016-03-10 14:14:10 --> Model Class Initialized
INFO - 2016-03-10 14:14:10 --> Model Class Initialized
INFO - 2016-03-10 14:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:14:10 --> Pagination Class Initialized
INFO - 2016-03-10 14:14:10 --> Helper loaded: text_helper
INFO - 2016-03-10 14:14:10 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:14:10 --> Final output sent to browser
DEBUG - 2016-03-10 17:14:10 --> Total execution time: 1.1812
INFO - 2016-03-10 14:14:12 --> Config Class Initialized
INFO - 2016-03-10 14:14:12 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:14:12 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:14:12 --> Utf8 Class Initialized
INFO - 2016-03-10 14:14:12 --> URI Class Initialized
INFO - 2016-03-10 14:14:12 --> Router Class Initialized
INFO - 2016-03-10 14:14:12 --> Output Class Initialized
INFO - 2016-03-10 14:14:12 --> Security Class Initialized
DEBUG - 2016-03-10 14:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:14:12 --> Input Class Initialized
INFO - 2016-03-10 14:14:12 --> Language Class Initialized
INFO - 2016-03-10 14:14:12 --> Loader Class Initialized
INFO - 2016-03-10 14:14:12 --> Helper loaded: url_helper
INFO - 2016-03-10 14:14:12 --> Helper loaded: file_helper
INFO - 2016-03-10 14:14:12 --> Helper loaded: date_helper
INFO - 2016-03-10 14:14:12 --> Helper loaded: form_helper
INFO - 2016-03-10 14:14:12 --> Database Driver Class Initialized
INFO - 2016-03-10 14:14:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:14:13 --> Controller Class Initialized
INFO - 2016-03-10 14:14:13 --> Model Class Initialized
INFO - 2016-03-10 14:14:13 --> Model Class Initialized
INFO - 2016-03-10 14:14:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:14:13 --> Pagination Class Initialized
INFO - 2016-03-10 14:14:13 --> Helper loaded: text_helper
INFO - 2016-03-10 14:14:13 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:14:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:14:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:14:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:14:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:14:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:14:13 --> Final output sent to browser
DEBUG - 2016-03-10 17:14:13 --> Total execution time: 1.1337
INFO - 2016-03-10 14:14:15 --> Config Class Initialized
INFO - 2016-03-10 14:14:15 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:14:15 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:14:15 --> Utf8 Class Initialized
INFO - 2016-03-10 14:14:15 --> URI Class Initialized
INFO - 2016-03-10 14:14:15 --> Router Class Initialized
INFO - 2016-03-10 14:14:15 --> Output Class Initialized
INFO - 2016-03-10 14:14:15 --> Security Class Initialized
DEBUG - 2016-03-10 14:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:14:15 --> Input Class Initialized
INFO - 2016-03-10 14:14:15 --> Language Class Initialized
INFO - 2016-03-10 14:14:15 --> Loader Class Initialized
INFO - 2016-03-10 14:14:15 --> Helper loaded: url_helper
INFO - 2016-03-10 14:14:15 --> Helper loaded: file_helper
INFO - 2016-03-10 14:14:15 --> Helper loaded: date_helper
INFO - 2016-03-10 14:14:15 --> Helper loaded: form_helper
INFO - 2016-03-10 14:14:15 --> Database Driver Class Initialized
INFO - 2016-03-10 14:14:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:14:16 --> Controller Class Initialized
INFO - 2016-03-10 14:14:16 --> Model Class Initialized
INFO - 2016-03-10 14:14:16 --> Model Class Initialized
INFO - 2016-03-10 14:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:14:16 --> Pagination Class Initialized
INFO - 2016-03-10 14:14:16 --> Helper loaded: text_helper
INFO - 2016-03-10 14:14:16 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:14:16 --> Final output sent to browser
DEBUG - 2016-03-10 17:14:16 --> Total execution time: 1.1998
INFO - 2016-03-10 14:15:10 --> Config Class Initialized
INFO - 2016-03-10 14:15:10 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:15:10 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:15:10 --> Utf8 Class Initialized
INFO - 2016-03-10 14:15:10 --> URI Class Initialized
INFO - 2016-03-10 14:15:10 --> Router Class Initialized
INFO - 2016-03-10 14:15:10 --> Output Class Initialized
INFO - 2016-03-10 14:15:10 --> Security Class Initialized
DEBUG - 2016-03-10 14:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:15:10 --> Input Class Initialized
INFO - 2016-03-10 14:15:10 --> Language Class Initialized
ERROR - 2016-03-10 14:15:10 --> Severity: Parsing Error --> syntax error, unexpected ''/'' (T_CONSTANT_ENCAPSED_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 140
INFO - 2016-03-10 14:15:19 --> Config Class Initialized
INFO - 2016-03-10 14:15:19 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:15:19 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:15:19 --> Utf8 Class Initialized
INFO - 2016-03-10 14:15:19 --> URI Class Initialized
INFO - 2016-03-10 14:15:19 --> Router Class Initialized
INFO - 2016-03-10 14:15:19 --> Output Class Initialized
INFO - 2016-03-10 14:15:19 --> Security Class Initialized
DEBUG - 2016-03-10 14:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:15:19 --> Input Class Initialized
INFO - 2016-03-10 14:15:19 --> Language Class Initialized
INFO - 2016-03-10 14:15:19 --> Loader Class Initialized
INFO - 2016-03-10 14:15:19 --> Helper loaded: url_helper
INFO - 2016-03-10 14:15:19 --> Helper loaded: file_helper
INFO - 2016-03-10 14:15:19 --> Helper loaded: date_helper
INFO - 2016-03-10 14:15:19 --> Helper loaded: form_helper
INFO - 2016-03-10 14:15:19 --> Database Driver Class Initialized
INFO - 2016-03-10 14:15:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:15:20 --> Controller Class Initialized
INFO - 2016-03-10 14:15:20 --> Model Class Initialized
INFO - 2016-03-10 14:15:20 --> Model Class Initialized
INFO - 2016-03-10 14:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:15:20 --> Pagination Class Initialized
INFO - 2016-03-10 14:15:20 --> Helper loaded: text_helper
INFO - 2016-03-10 14:15:20 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:15:20 --> Final output sent to browser
DEBUG - 2016-03-10 17:15:20 --> Total execution time: 1.1714
INFO - 2016-03-10 14:15:22 --> Config Class Initialized
INFO - 2016-03-10 14:15:22 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:15:22 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:15:22 --> Utf8 Class Initialized
INFO - 2016-03-10 14:15:22 --> URI Class Initialized
INFO - 2016-03-10 14:15:22 --> Router Class Initialized
INFO - 2016-03-10 14:15:22 --> Output Class Initialized
INFO - 2016-03-10 14:15:22 --> Security Class Initialized
DEBUG - 2016-03-10 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:15:22 --> Input Class Initialized
INFO - 2016-03-10 14:15:22 --> Language Class Initialized
INFO - 2016-03-10 14:15:22 --> Loader Class Initialized
INFO - 2016-03-10 14:15:22 --> Helper loaded: url_helper
INFO - 2016-03-10 14:15:22 --> Helper loaded: file_helper
INFO - 2016-03-10 14:15:22 --> Helper loaded: date_helper
INFO - 2016-03-10 14:15:22 --> Helper loaded: form_helper
INFO - 2016-03-10 14:15:22 --> Database Driver Class Initialized
INFO - 2016-03-10 14:15:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:15:23 --> Controller Class Initialized
INFO - 2016-03-10 14:15:23 --> Model Class Initialized
INFO - 2016-03-10 14:15:23 --> Model Class Initialized
INFO - 2016-03-10 14:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:15:23 --> Pagination Class Initialized
INFO - 2016-03-10 14:15:23 --> Helper loaded: text_helper
INFO - 2016-03-10 14:15:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:15:23 --> Final output sent to browser
DEBUG - 2016-03-10 17:15:23 --> Total execution time: 1.1608
INFO - 2016-03-10 14:15:25 --> Config Class Initialized
INFO - 2016-03-10 14:15:25 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:15:25 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:15:25 --> Utf8 Class Initialized
INFO - 2016-03-10 14:15:25 --> URI Class Initialized
INFO - 2016-03-10 14:15:25 --> Router Class Initialized
INFO - 2016-03-10 14:15:25 --> Output Class Initialized
INFO - 2016-03-10 14:15:25 --> Security Class Initialized
DEBUG - 2016-03-10 14:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:15:25 --> Input Class Initialized
INFO - 2016-03-10 14:15:25 --> Language Class Initialized
INFO - 2016-03-10 14:15:25 --> Loader Class Initialized
INFO - 2016-03-10 14:15:25 --> Helper loaded: url_helper
INFO - 2016-03-10 14:15:25 --> Helper loaded: file_helper
INFO - 2016-03-10 14:15:25 --> Helper loaded: date_helper
INFO - 2016-03-10 14:15:25 --> Helper loaded: form_helper
INFO - 2016-03-10 14:15:25 --> Database Driver Class Initialized
INFO - 2016-03-10 14:15:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:15:26 --> Controller Class Initialized
INFO - 2016-03-10 14:15:26 --> Model Class Initialized
INFO - 2016-03-10 14:15:26 --> Model Class Initialized
INFO - 2016-03-10 14:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:15:26 --> Pagination Class Initialized
INFO - 2016-03-10 14:15:26 --> Helper loaded: text_helper
INFO - 2016-03-10 14:15:26 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:15:26 --> Final output sent to browser
DEBUG - 2016-03-10 17:15:26 --> Total execution time: 1.2000
INFO - 2016-03-10 14:34:21 --> Config Class Initialized
INFO - 2016-03-10 14:34:21 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:34:21 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:34:21 --> Utf8 Class Initialized
INFO - 2016-03-10 14:34:21 --> URI Class Initialized
INFO - 2016-03-10 14:34:21 --> Router Class Initialized
INFO - 2016-03-10 14:34:21 --> Output Class Initialized
INFO - 2016-03-10 14:34:21 --> Security Class Initialized
DEBUG - 2016-03-10 14:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:34:21 --> Input Class Initialized
INFO - 2016-03-10 14:34:21 --> Language Class Initialized
INFO - 2016-03-10 14:34:22 --> Loader Class Initialized
INFO - 2016-03-10 14:34:22 --> Helper loaded: url_helper
INFO - 2016-03-10 14:34:22 --> Helper loaded: file_helper
INFO - 2016-03-10 14:34:22 --> Helper loaded: date_helper
INFO - 2016-03-10 14:34:22 --> Helper loaded: form_helper
INFO - 2016-03-10 14:34:22 --> Database Driver Class Initialized
INFO - 2016-03-10 14:34:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:34:23 --> Controller Class Initialized
INFO - 2016-03-10 14:34:23 --> Model Class Initialized
INFO - 2016-03-10 14:34:23 --> Model Class Initialized
INFO - 2016-03-10 14:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:34:23 --> Pagination Class Initialized
INFO - 2016-03-10 14:34:23 --> Helper loaded: text_helper
INFO - 2016-03-10 14:34:23 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-10 17:34:23 --> Severity: Error --> Call to undefined method CI_Pagination::current_place() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-03-10 14:34:40 --> Config Class Initialized
INFO - 2016-03-10 14:34:40 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:34:40 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:34:40 --> Utf8 Class Initialized
INFO - 2016-03-10 14:34:40 --> URI Class Initialized
INFO - 2016-03-10 14:34:40 --> Router Class Initialized
INFO - 2016-03-10 14:34:40 --> Output Class Initialized
INFO - 2016-03-10 14:34:40 --> Security Class Initialized
DEBUG - 2016-03-10 14:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:34:40 --> Input Class Initialized
INFO - 2016-03-10 14:34:40 --> Language Class Initialized
INFO - 2016-03-10 14:34:40 --> Loader Class Initialized
INFO - 2016-03-10 14:34:40 --> Helper loaded: url_helper
INFO - 2016-03-10 14:34:40 --> Helper loaded: file_helper
INFO - 2016-03-10 14:34:40 --> Helper loaded: date_helper
INFO - 2016-03-10 14:34:40 --> Helper loaded: form_helper
INFO - 2016-03-10 14:34:40 --> Database Driver Class Initialized
INFO - 2016-03-10 14:34:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:34:42 --> Controller Class Initialized
INFO - 2016-03-10 14:34:42 --> Model Class Initialized
INFO - 2016-03-10 14:34:42 --> Model Class Initialized
INFO - 2016-03-10 14:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:34:42 --> Pagination Class Initialized
INFO - 2016-03-10 14:34:42 --> Helper loaded: text_helper
INFO - 2016-03-10 14:34:42 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:34:42 --> Final output sent to browser
DEBUG - 2016-03-10 17:34:42 --> Total execution time: 1.2022
INFO - 2016-03-10 14:36:36 --> Config Class Initialized
INFO - 2016-03-10 14:36:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:36:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:36:36 --> Utf8 Class Initialized
INFO - 2016-03-10 14:36:36 --> URI Class Initialized
INFO - 2016-03-10 14:36:36 --> Router Class Initialized
INFO - 2016-03-10 14:36:36 --> Output Class Initialized
INFO - 2016-03-10 14:36:36 --> Security Class Initialized
DEBUG - 2016-03-10 14:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:36:36 --> Input Class Initialized
INFO - 2016-03-10 14:36:36 --> Language Class Initialized
INFO - 2016-03-10 14:36:36 --> Loader Class Initialized
INFO - 2016-03-10 14:36:36 --> Helper loaded: url_helper
INFO - 2016-03-10 14:36:36 --> Helper loaded: file_helper
INFO - 2016-03-10 14:36:36 --> Helper loaded: date_helper
INFO - 2016-03-10 14:36:36 --> Helper loaded: form_helper
INFO - 2016-03-10 14:36:36 --> Database Driver Class Initialized
INFO - 2016-03-10 14:36:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:36:37 --> Controller Class Initialized
INFO - 2016-03-10 14:36:37 --> Model Class Initialized
INFO - 2016-03-10 14:36:37 --> Model Class Initialized
INFO - 2016-03-10 14:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:36:37 --> Pagination Class Initialized
INFO - 2016-03-10 14:36:37 --> Helper loaded: text_helper
INFO - 2016-03-10 14:36:37 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:36:37 --> Final output sent to browser
DEBUG - 2016-03-10 17:36:37 --> Total execution time: 1.1278
INFO - 2016-03-10 14:37:06 --> Config Class Initialized
INFO - 2016-03-10 14:37:06 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:37:06 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:37:06 --> Utf8 Class Initialized
INFO - 2016-03-10 14:37:06 --> URI Class Initialized
INFO - 2016-03-10 14:37:06 --> Router Class Initialized
INFO - 2016-03-10 14:37:06 --> Output Class Initialized
INFO - 2016-03-10 14:37:06 --> Security Class Initialized
DEBUG - 2016-03-10 14:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:37:06 --> Input Class Initialized
INFO - 2016-03-10 14:37:06 --> Language Class Initialized
INFO - 2016-03-10 14:37:06 --> Loader Class Initialized
INFO - 2016-03-10 14:37:06 --> Helper loaded: url_helper
INFO - 2016-03-10 14:37:06 --> Helper loaded: file_helper
INFO - 2016-03-10 14:37:06 --> Helper loaded: date_helper
INFO - 2016-03-10 14:37:06 --> Helper loaded: form_helper
INFO - 2016-03-10 14:37:06 --> Database Driver Class Initialized
INFO - 2016-03-10 14:37:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:37:07 --> Controller Class Initialized
INFO - 2016-03-10 14:37:07 --> Model Class Initialized
INFO - 2016-03-10 14:37:07 --> Model Class Initialized
INFO - 2016-03-10 14:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:37:07 --> Pagination Class Initialized
INFO - 2016-03-10 14:37:07 --> Helper loaded: text_helper
INFO - 2016-03-10 14:37:07 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:37:07 --> Final output sent to browser
DEBUG - 2016-03-10 17:37:07 --> Total execution time: 1.1341
INFO - 2016-03-10 14:37:36 --> Config Class Initialized
INFO - 2016-03-10 14:37:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:37:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:37:36 --> Utf8 Class Initialized
INFO - 2016-03-10 14:37:36 --> URI Class Initialized
INFO - 2016-03-10 14:37:36 --> Router Class Initialized
INFO - 2016-03-10 14:37:36 --> Output Class Initialized
INFO - 2016-03-10 14:37:36 --> Security Class Initialized
DEBUG - 2016-03-10 14:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:37:36 --> Input Class Initialized
INFO - 2016-03-10 14:37:36 --> Language Class Initialized
ERROR - 2016-03-10 14:37:36 --> Severity: Parsing Error --> syntax error, unexpected '3' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 140
INFO - 2016-03-10 14:38:01 --> Config Class Initialized
INFO - 2016-03-10 14:38:01 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:38:02 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:38:02 --> Utf8 Class Initialized
INFO - 2016-03-10 14:38:02 --> URI Class Initialized
INFO - 2016-03-10 14:38:02 --> Router Class Initialized
INFO - 2016-03-10 14:38:02 --> Output Class Initialized
INFO - 2016-03-10 14:38:02 --> Security Class Initialized
DEBUG - 2016-03-10 14:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:38:02 --> Input Class Initialized
INFO - 2016-03-10 14:38:02 --> Language Class Initialized
INFO - 2016-03-10 14:38:02 --> Loader Class Initialized
INFO - 2016-03-10 14:38:02 --> Helper loaded: url_helper
INFO - 2016-03-10 14:38:02 --> Helper loaded: file_helper
INFO - 2016-03-10 14:38:02 --> Helper loaded: date_helper
INFO - 2016-03-10 14:38:02 --> Helper loaded: form_helper
INFO - 2016-03-10 14:38:02 --> Database Driver Class Initialized
INFO - 2016-03-10 14:38:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:38:03 --> Controller Class Initialized
INFO - 2016-03-10 14:38:03 --> Model Class Initialized
INFO - 2016-03-10 14:38:03 --> Model Class Initialized
INFO - 2016-03-10 14:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:38:03 --> Pagination Class Initialized
INFO - 2016-03-10 14:38:03 --> Helper loaded: text_helper
INFO - 2016-03-10 14:38:03 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:38:03 --> Final output sent to browser
DEBUG - 2016-03-10 17:38:03 --> Total execution time: 1.2034
INFO - 2016-03-10 14:38:04 --> Config Class Initialized
INFO - 2016-03-10 14:38:04 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:38:04 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:38:04 --> Utf8 Class Initialized
INFO - 2016-03-10 14:38:04 --> URI Class Initialized
INFO - 2016-03-10 14:38:04 --> Router Class Initialized
INFO - 2016-03-10 14:38:04 --> Output Class Initialized
INFO - 2016-03-10 14:38:04 --> Security Class Initialized
DEBUG - 2016-03-10 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:38:04 --> Input Class Initialized
INFO - 2016-03-10 14:38:04 --> Language Class Initialized
INFO - 2016-03-10 14:38:04 --> Loader Class Initialized
INFO - 2016-03-10 14:38:04 --> Helper loaded: url_helper
INFO - 2016-03-10 14:38:04 --> Helper loaded: file_helper
INFO - 2016-03-10 14:38:04 --> Helper loaded: date_helper
INFO - 2016-03-10 14:38:04 --> Helper loaded: form_helper
INFO - 2016-03-10 14:38:04 --> Database Driver Class Initialized
INFO - 2016-03-10 14:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:38:05 --> Controller Class Initialized
INFO - 2016-03-10 14:38:05 --> Model Class Initialized
INFO - 2016-03-10 14:38:06 --> Model Class Initialized
INFO - 2016-03-10 14:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:38:06 --> Pagination Class Initialized
INFO - 2016-03-10 14:38:06 --> Helper loaded: text_helper
INFO - 2016-03-10 14:38:06 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:38:06 --> Final output sent to browser
DEBUG - 2016-03-10 17:38:06 --> Total execution time: 1.1345
INFO - 2016-03-10 14:38:07 --> Config Class Initialized
INFO - 2016-03-10 14:38:07 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:38:07 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:38:07 --> Utf8 Class Initialized
INFO - 2016-03-10 14:38:07 --> URI Class Initialized
INFO - 2016-03-10 14:38:07 --> Router Class Initialized
INFO - 2016-03-10 14:38:07 --> Output Class Initialized
INFO - 2016-03-10 14:38:07 --> Security Class Initialized
DEBUG - 2016-03-10 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:38:07 --> Input Class Initialized
INFO - 2016-03-10 14:38:07 --> Language Class Initialized
INFO - 2016-03-10 14:38:07 --> Loader Class Initialized
INFO - 2016-03-10 14:38:07 --> Helper loaded: url_helper
INFO - 2016-03-10 14:38:07 --> Helper loaded: file_helper
INFO - 2016-03-10 14:38:07 --> Helper loaded: date_helper
INFO - 2016-03-10 14:38:07 --> Helper loaded: form_helper
INFO - 2016-03-10 14:38:07 --> Database Driver Class Initialized
INFO - 2016-03-10 14:38:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:38:09 --> Controller Class Initialized
INFO - 2016-03-10 14:38:09 --> Model Class Initialized
INFO - 2016-03-10 14:38:09 --> Model Class Initialized
INFO - 2016-03-10 14:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:38:09 --> Pagination Class Initialized
INFO - 2016-03-10 14:38:09 --> Helper loaded: text_helper
INFO - 2016-03-10 14:38:09 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:38:09 --> Final output sent to browser
DEBUG - 2016-03-10 17:38:09 --> Total execution time: 1.1960
INFO - 2016-03-10 14:47:05 --> Config Class Initialized
INFO - 2016-03-10 14:47:05 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:47:05 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:47:05 --> Utf8 Class Initialized
INFO - 2016-03-10 14:47:05 --> URI Class Initialized
INFO - 2016-03-10 14:47:05 --> Router Class Initialized
INFO - 2016-03-10 14:47:05 --> Output Class Initialized
INFO - 2016-03-10 14:47:05 --> Security Class Initialized
DEBUG - 2016-03-10 14:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:47:05 --> Input Class Initialized
INFO - 2016-03-10 14:47:05 --> Language Class Initialized
INFO - 2016-03-10 14:47:05 --> Loader Class Initialized
INFO - 2016-03-10 14:47:06 --> Helper loaded: url_helper
INFO - 2016-03-10 14:47:06 --> Helper loaded: file_helper
INFO - 2016-03-10 14:47:06 --> Helper loaded: date_helper
INFO - 2016-03-10 14:47:06 --> Helper loaded: form_helper
INFO - 2016-03-10 14:47:06 --> Database Driver Class Initialized
INFO - 2016-03-10 14:47:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:47:07 --> Controller Class Initialized
INFO - 2016-03-10 14:47:07 --> Model Class Initialized
INFO - 2016-03-10 14:47:07 --> Model Class Initialized
INFO - 2016-03-10 14:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:47:07 --> Pagination Class Initialized
INFO - 2016-03-10 14:47:07 --> Helper loaded: text_helper
INFO - 2016-03-10 14:47:07 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:47:07 --> Final output sent to browser
DEBUG - 2016-03-10 17:47:07 --> Total execution time: 1.2488
INFO - 2016-03-10 14:47:11 --> Config Class Initialized
INFO - 2016-03-10 14:47:11 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:47:11 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:47:11 --> Utf8 Class Initialized
INFO - 2016-03-10 14:47:11 --> URI Class Initialized
INFO - 2016-03-10 14:47:11 --> Router Class Initialized
INFO - 2016-03-10 14:47:11 --> Output Class Initialized
INFO - 2016-03-10 14:47:11 --> Security Class Initialized
DEBUG - 2016-03-10 14:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:47:11 --> Input Class Initialized
INFO - 2016-03-10 14:47:11 --> Language Class Initialized
INFO - 2016-03-10 14:47:11 --> Loader Class Initialized
INFO - 2016-03-10 14:47:11 --> Helper loaded: url_helper
INFO - 2016-03-10 14:47:11 --> Helper loaded: file_helper
INFO - 2016-03-10 14:47:11 --> Helper loaded: date_helper
INFO - 2016-03-10 14:47:11 --> Helper loaded: form_helper
INFO - 2016-03-10 14:47:11 --> Database Driver Class Initialized
INFO - 2016-03-10 14:47:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:47:12 --> Controller Class Initialized
INFO - 2016-03-10 14:47:12 --> Model Class Initialized
INFO - 2016-03-10 14:47:12 --> Model Class Initialized
INFO - 2016-03-10 14:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:47:12 --> Pagination Class Initialized
INFO - 2016-03-10 14:47:12 --> Helper loaded: text_helper
INFO - 2016-03-10 14:47:12 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:47:12 --> Final output sent to browser
DEBUG - 2016-03-10 17:47:12 --> Total execution time: 1.0963
INFO - 2016-03-10 14:47:14 --> Config Class Initialized
INFO - 2016-03-10 14:47:14 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:47:14 --> Utf8 Class Initialized
INFO - 2016-03-10 14:47:14 --> URI Class Initialized
INFO - 2016-03-10 14:47:14 --> Router Class Initialized
INFO - 2016-03-10 14:47:14 --> Output Class Initialized
INFO - 2016-03-10 14:47:14 --> Security Class Initialized
DEBUG - 2016-03-10 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:47:14 --> Input Class Initialized
INFO - 2016-03-10 14:47:14 --> Language Class Initialized
INFO - 2016-03-10 14:47:14 --> Loader Class Initialized
INFO - 2016-03-10 14:47:14 --> Helper loaded: url_helper
INFO - 2016-03-10 14:47:14 --> Helper loaded: file_helper
INFO - 2016-03-10 14:47:14 --> Helper loaded: date_helper
INFO - 2016-03-10 14:47:14 --> Helper loaded: form_helper
INFO - 2016-03-10 14:47:14 --> Database Driver Class Initialized
INFO - 2016-03-10 14:47:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:47:15 --> Controller Class Initialized
INFO - 2016-03-10 14:47:15 --> Model Class Initialized
INFO - 2016-03-10 14:47:15 --> Model Class Initialized
INFO - 2016-03-10 14:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:47:15 --> Pagination Class Initialized
INFO - 2016-03-10 14:47:15 --> Helper loaded: text_helper
INFO - 2016-03-10 14:47:15 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:47:15 --> Final output sent to browser
DEBUG - 2016-03-10 17:47:15 --> Total execution time: 1.1276
INFO - 2016-03-10 14:47:16 --> Config Class Initialized
INFO - 2016-03-10 14:47:16 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:47:16 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:47:16 --> Utf8 Class Initialized
INFO - 2016-03-10 14:47:16 --> URI Class Initialized
INFO - 2016-03-10 14:47:16 --> Router Class Initialized
INFO - 2016-03-10 14:47:16 --> Output Class Initialized
INFO - 2016-03-10 14:47:16 --> Security Class Initialized
DEBUG - 2016-03-10 14:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:47:16 --> Input Class Initialized
INFO - 2016-03-10 14:47:16 --> Language Class Initialized
INFO - 2016-03-10 14:47:16 --> Loader Class Initialized
INFO - 2016-03-10 14:47:16 --> Helper loaded: url_helper
INFO - 2016-03-10 14:47:16 --> Helper loaded: file_helper
INFO - 2016-03-10 14:47:16 --> Helper loaded: date_helper
INFO - 2016-03-10 14:47:16 --> Helper loaded: form_helper
INFO - 2016-03-10 14:47:16 --> Database Driver Class Initialized
INFO - 2016-03-10 14:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:47:17 --> Controller Class Initialized
INFO - 2016-03-10 14:47:17 --> Model Class Initialized
INFO - 2016-03-10 14:47:17 --> Model Class Initialized
INFO - 2016-03-10 14:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:47:17 --> Pagination Class Initialized
INFO - 2016-03-10 14:47:17 --> Helper loaded: text_helper
INFO - 2016-03-10 14:47:17 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:47:17 --> Final output sent to browser
DEBUG - 2016-03-10 17:47:17 --> Total execution time: 1.1024
INFO - 2016-03-10 14:47:18 --> Config Class Initialized
INFO - 2016-03-10 14:47:18 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:47:18 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:47:18 --> Utf8 Class Initialized
INFO - 2016-03-10 14:47:18 --> URI Class Initialized
INFO - 2016-03-10 14:47:18 --> Router Class Initialized
INFO - 2016-03-10 14:47:18 --> Output Class Initialized
INFO - 2016-03-10 14:47:18 --> Security Class Initialized
DEBUG - 2016-03-10 14:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:47:18 --> Input Class Initialized
INFO - 2016-03-10 14:47:18 --> Language Class Initialized
INFO - 2016-03-10 14:47:18 --> Loader Class Initialized
INFO - 2016-03-10 14:47:18 --> Helper loaded: url_helper
INFO - 2016-03-10 14:47:18 --> Helper loaded: file_helper
INFO - 2016-03-10 14:47:18 --> Helper loaded: date_helper
INFO - 2016-03-10 14:47:18 --> Helper loaded: form_helper
INFO - 2016-03-10 14:47:18 --> Database Driver Class Initialized
INFO - 2016-03-10 14:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:47:19 --> Controller Class Initialized
INFO - 2016-03-10 14:47:19 --> Model Class Initialized
INFO - 2016-03-10 14:47:19 --> Model Class Initialized
INFO - 2016-03-10 14:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:47:19 --> Pagination Class Initialized
INFO - 2016-03-10 14:47:19 --> Helper loaded: text_helper
INFO - 2016-03-10 14:47:19 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:47:19 --> Final output sent to browser
DEBUG - 2016-03-10 17:47:19 --> Total execution time: 1.1986
INFO - 2016-03-10 14:48:29 --> Config Class Initialized
INFO - 2016-03-10 14:48:29 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:48:29 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:48:29 --> Utf8 Class Initialized
INFO - 2016-03-10 14:48:29 --> URI Class Initialized
INFO - 2016-03-10 14:48:29 --> Router Class Initialized
INFO - 2016-03-10 14:48:29 --> Output Class Initialized
INFO - 2016-03-10 14:48:29 --> Security Class Initialized
DEBUG - 2016-03-10 14:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:48:29 --> Input Class Initialized
INFO - 2016-03-10 14:48:29 --> Language Class Initialized
INFO - 2016-03-10 14:48:29 --> Loader Class Initialized
INFO - 2016-03-10 14:48:29 --> Helper loaded: url_helper
INFO - 2016-03-10 14:48:29 --> Helper loaded: file_helper
INFO - 2016-03-10 14:48:29 --> Helper loaded: date_helper
INFO - 2016-03-10 14:48:29 --> Helper loaded: form_helper
INFO - 2016-03-10 14:48:29 --> Database Driver Class Initialized
INFO - 2016-03-10 14:48:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:48:30 --> Controller Class Initialized
INFO - 2016-03-10 14:48:30 --> Model Class Initialized
INFO - 2016-03-10 14:48:30 --> Model Class Initialized
INFO - 2016-03-10 14:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:48:30 --> Pagination Class Initialized
INFO - 2016-03-10 14:48:30 --> Helper loaded: text_helper
INFO - 2016-03-10 14:48:30 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:48:30 --> Final output sent to browser
DEBUG - 2016-03-10 17:48:30 --> Total execution time: 1.1452
INFO - 2016-03-10 14:48:33 --> Config Class Initialized
INFO - 2016-03-10 14:48:33 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:48:33 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:48:33 --> Utf8 Class Initialized
INFO - 2016-03-10 14:48:33 --> URI Class Initialized
INFO - 2016-03-10 14:48:33 --> Router Class Initialized
INFO - 2016-03-10 14:48:33 --> Output Class Initialized
INFO - 2016-03-10 14:48:33 --> Security Class Initialized
DEBUG - 2016-03-10 14:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:48:33 --> Input Class Initialized
INFO - 2016-03-10 14:48:33 --> Language Class Initialized
INFO - 2016-03-10 14:48:33 --> Loader Class Initialized
INFO - 2016-03-10 14:48:33 --> Helper loaded: url_helper
INFO - 2016-03-10 14:48:33 --> Helper loaded: file_helper
INFO - 2016-03-10 14:48:33 --> Helper loaded: date_helper
INFO - 2016-03-10 14:48:33 --> Helper loaded: form_helper
INFO - 2016-03-10 14:48:33 --> Database Driver Class Initialized
INFO - 2016-03-10 14:48:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:48:34 --> Controller Class Initialized
INFO - 2016-03-10 14:48:34 --> Model Class Initialized
INFO - 2016-03-10 14:48:34 --> Model Class Initialized
INFO - 2016-03-10 14:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:48:34 --> Pagination Class Initialized
INFO - 2016-03-10 14:48:34 --> Helper loaded: text_helper
INFO - 2016-03-10 14:48:34 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:48:34 --> Final output sent to browser
DEBUG - 2016-03-10 17:48:34 --> Total execution time: 1.1252
INFO - 2016-03-10 14:48:36 --> Config Class Initialized
INFO - 2016-03-10 14:48:36 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:48:36 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:48:36 --> Utf8 Class Initialized
INFO - 2016-03-10 14:48:36 --> URI Class Initialized
INFO - 2016-03-10 14:48:36 --> Router Class Initialized
INFO - 2016-03-10 14:48:36 --> Output Class Initialized
INFO - 2016-03-10 14:48:36 --> Security Class Initialized
DEBUG - 2016-03-10 14:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:48:36 --> Input Class Initialized
INFO - 2016-03-10 14:48:36 --> Language Class Initialized
INFO - 2016-03-10 14:48:36 --> Loader Class Initialized
INFO - 2016-03-10 14:48:36 --> Helper loaded: url_helper
INFO - 2016-03-10 14:48:36 --> Helper loaded: file_helper
INFO - 2016-03-10 14:48:36 --> Helper loaded: date_helper
INFO - 2016-03-10 14:48:36 --> Helper loaded: form_helper
INFO - 2016-03-10 14:48:36 --> Database Driver Class Initialized
INFO - 2016-03-10 14:48:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:48:37 --> Controller Class Initialized
INFO - 2016-03-10 14:48:37 --> Model Class Initialized
INFO - 2016-03-10 14:48:37 --> Model Class Initialized
INFO - 2016-03-10 14:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:48:37 --> Pagination Class Initialized
INFO - 2016-03-10 14:48:37 --> Helper loaded: text_helper
INFO - 2016-03-10 14:48:37 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-10 17:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-10 17:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:48:37 --> Final output sent to browser
DEBUG - 2016-03-10 17:48:37 --> Total execution time: 1.1153
INFO - 2016-03-10 14:48:39 --> Config Class Initialized
INFO - 2016-03-10 14:48:39 --> Hooks Class Initialized
DEBUG - 2016-03-10 14:48:39 --> UTF-8 Support Enabled
INFO - 2016-03-10 14:48:39 --> Utf8 Class Initialized
INFO - 2016-03-10 14:48:39 --> URI Class Initialized
INFO - 2016-03-10 14:48:39 --> Router Class Initialized
INFO - 2016-03-10 14:48:39 --> Output Class Initialized
INFO - 2016-03-10 14:48:39 --> Security Class Initialized
DEBUG - 2016-03-10 14:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-10 14:48:39 --> Input Class Initialized
INFO - 2016-03-10 14:48:39 --> Language Class Initialized
INFO - 2016-03-10 14:48:39 --> Loader Class Initialized
INFO - 2016-03-10 14:48:39 --> Helper loaded: url_helper
INFO - 2016-03-10 14:48:39 --> Helper loaded: file_helper
INFO - 2016-03-10 14:48:39 --> Helper loaded: date_helper
INFO - 2016-03-10 14:48:39 --> Helper loaded: form_helper
INFO - 2016-03-10 14:48:39 --> Database Driver Class Initialized
INFO - 2016-03-10 14:48:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-10 14:48:40 --> Controller Class Initialized
INFO - 2016-03-10 14:48:40 --> Model Class Initialized
INFO - 2016-03-10 14:48:40 --> Model Class Initialized
INFO - 2016-03-10 14:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-10 14:48:40 --> Pagination Class Initialized
INFO - 2016-03-10 14:48:40 --> Helper loaded: text_helper
INFO - 2016-03-10 14:48:40 --> Helper loaded: cookie_helper
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-10 17:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-10 17:48:40 --> Final output sent to browser
DEBUG - 2016-03-10 17:48:40 --> Total execution time: 1.1700
