<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-28 00:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:01:32 --> Final output sent to browser
DEBUG - 2016-02-28 00:01:32 --> Total execution time: 1.1173
INFO - 2016-02-28 00:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:02:15 --> Final output sent to browser
DEBUG - 2016-02-28 00:02:15 --> Total execution time: 1.1057
INFO - 2016-02-28 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:02:46 --> Final output sent to browser
DEBUG - 2016-02-28 00:02:46 --> Total execution time: 1.1172
INFO - 2016-02-28 00:06:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:06:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:06:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:06:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:06:57 --> Final output sent to browser
DEBUG - 2016-02-28 00:06:57 --> Total execution time: 1.1208
INFO - 2016-02-28 00:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:08:10 --> Final output sent to browser
DEBUG - 2016-02-28 00:08:10 --> Total execution time: 1.1413
INFO - 2016-02-28 00:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:08:31 --> Final output sent to browser
DEBUG - 2016-02-28 00:08:31 --> Total execution time: 1.1232
INFO - 2016-02-28 00:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:10:01 --> Final output sent to browser
DEBUG - 2016-02-28 00:10:01 --> Total execution time: 1.1016
INFO - 2016-02-28 00:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:10:20 --> Final output sent to browser
DEBUG - 2016-02-28 00:10:20 --> Total execution time: 1.1444
INFO - 2016-02-28 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:10:23 --> Final output sent to browser
DEBUG - 2016-02-28 00:10:23 --> Total execution time: 1.1224
INFO - 2016-02-28 00:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:10:25 --> Final output sent to browser
DEBUG - 2016-02-28 00:10:25 --> Total execution time: 1.1165
INFO - 2016-02-28 00:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:14:56 --> Final output sent to browser
DEBUG - 2016-02-28 00:14:56 --> Total execution time: 1.1891
INFO - 2016-02-28 00:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:21:43 --> Final output sent to browser
DEBUG - 2016-02-28 00:21:43 --> Total execution time: 1.2853
INFO - 2016-02-28 00:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:22:15 --> Final output sent to browser
DEBUG - 2016-02-28 00:22:15 --> Total execution time: 1.1772
INFO - 2016-02-28 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:22:28 --> Final output sent to browser
DEBUG - 2016-02-28 00:22:28 --> Total execution time: 1.1352
INFO - 2016-02-28 00:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:22:31 --> Final output sent to browser
DEBUG - 2016-02-28 00:22:31 --> Total execution time: 1.0912
INFO - 2016-02-28 00:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:22:33 --> Final output sent to browser
DEBUG - 2016-02-28 00:22:33 --> Total execution time: 1.1526
INFO - 2016-02-28 00:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:23:41 --> Final output sent to browser
DEBUG - 2016-02-28 00:23:41 --> Total execution time: 1.2524
INFO - 2016-02-28 00:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 00:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:23:52 --> Final output sent to browser
DEBUG - 2016-02-28 00:23:52 --> Total execution time: 1.1430
INFO - 2016-02-28 00:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:23:55 --> Final output sent to browser
DEBUG - 2016-02-28 00:23:55 --> Total execution time: 1.1127
INFO - 2016-02-28 00:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:23:59 --> Final output sent to browser
DEBUG - 2016-02-28 00:23:59 --> Total execution time: 1.1434
INFO - 2016-02-28 00:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:24:03 --> Final output sent to browser
DEBUG - 2016-02-28 00:24:03 --> Total execution time: 1.1474
INFO - 2016-02-28 00:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:24:07 --> Final output sent to browser
DEBUG - 2016-02-28 00:24:07 --> Total execution time: 1.1094
INFO - 2016-02-28 00:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:24:10 --> Final output sent to browser
DEBUG - 2016-02-28 00:24:10 --> Total execution time: 1.1520
INFO - 2016-02-28 00:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:24:15 --> Final output sent to browser
DEBUG - 2016-02-28 00:24:15 --> Total execution time: 1.1235
INFO - 2016-02-28 00:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:06 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:06 --> Total execution time: 1.1519
INFO - 2016-02-28 00:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 00:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:12 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:12 --> Total execution time: 1.0982
INFO - 2016-02-28 00:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-28 00:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:17 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:17 --> Total execution time: 1.1430
INFO - 2016-02-28 00:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:22 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:22 --> Total execution time: 1.1471
INFO - 2016-02-28 00:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:48 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:48 --> Total execution time: 1.1211
INFO - 2016-02-28 00:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:52 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:52 --> Total execution time: 1.1096
INFO - 2016-02-28 00:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:25:56 --> Final output sent to browser
DEBUG - 2016-02-28 00:25:56 --> Total execution time: 1.1647
INFO - 2016-02-28 00:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:01 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:01 --> Total execution time: 1.1197
INFO - 2016-02-28 00:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:08 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:08 --> Total execution time: 1.1937
INFO - 2016-02-28 00:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:11 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:11 --> Total execution time: 1.1565
INFO - 2016-02-28 00:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:21 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:21 --> Total execution time: 1.1336
INFO - 2016-02-28 00:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:24 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:24 --> Total execution time: 1.1277
INFO - 2016-02-28 00:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:26:27 --> Final output sent to browser
DEBUG - 2016-02-28 00:26:27 --> Total execution time: 1.1644
INFO - 2016-02-28 00:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:27:09 --> Final output sent to browser
DEBUG - 2016-02-28 00:27:09 --> Total execution time: 1.1206
INFO - 2016-02-28 00:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:27:12 --> Final output sent to browser
DEBUG - 2016-02-28 00:27:12 --> Total execution time: 1.0902
INFO - 2016-02-28 00:27:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:27:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:27:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:27:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:27:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:27:17 --> Final output sent to browser
DEBUG - 2016-02-28 00:27:17 --> Total execution time: 1.1650
INFO - 2016-02-28 00:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:34:16 --> Final output sent to browser
DEBUG - 2016-02-28 00:34:16 --> Total execution time: 1.1718
INFO - 2016-02-28 00:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:34:23 --> Final output sent to browser
DEBUG - 2016-02-28 00:34:23 --> Total execution time: 1.1479
INFO - 2016-02-28 00:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:34:55 --> Final output sent to browser
DEBUG - 2016-02-28 00:34:55 --> Total execution time: 1.1650
INFO - 2016-02-28 00:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:36:48 --> Final output sent to browser
DEBUG - 2016-02-28 00:36:48 --> Total execution time: 1.1746
INFO - 2016-02-28 00:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:38:41 --> Final output sent to browser
DEBUG - 2016-02-28 00:38:42 --> Total execution time: 1.1500
INFO - 2016-02-28 00:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:42:28 --> Final output sent to browser
DEBUG - 2016-02-28 00:42:28 --> Total execution time: 1.2031
INFO - 2016-02-28 00:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:45:06 --> Final output sent to browser
DEBUG - 2016-02-28 00:45:06 --> Total execution time: 1.1770
INFO - 2016-02-28 00:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:46:08 --> Final output sent to browser
DEBUG - 2016-02-28 00:46:08 --> Total execution time: 1.1866
INFO - 2016-02-28 00:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:49:51 --> Final output sent to browser
DEBUG - 2016-02-28 00:49:51 --> Total execution time: 1.1708
INFO - 2016-02-28 00:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:52:56 --> Final output sent to browser
DEBUG - 2016-02-28 00:52:56 --> Total execution time: 1.1457
INFO - 2016-02-28 00:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:52:59 --> Final output sent to browser
DEBUG - 2016-02-28 00:52:59 --> Total execution time: 1.1225
INFO - 2016-02-28 00:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:53:02 --> Final output sent to browser
DEBUG - 2016-02-28 00:53:02 --> Total execution time: 1.1663
INFO - 2016-02-28 00:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:53:32 --> Final output sent to browser
DEBUG - 2016-02-28 00:53:32 --> Total execution time: 1.1624
INFO - 2016-02-28 00:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:53:38 --> Final output sent to browser
DEBUG - 2016-02-28 00:53:38 --> Total execution time: 1.1478
INFO - 2016-02-28 00:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:54:07 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:07 --> Total execution time: 1.1086
INFO - 2016-02-28 00:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 00:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:54:12 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:12 --> Total execution time: 1.1157
INFO - 2016-02-28 00:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-28 00:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:54:14 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:14 --> Total execution time: 1.1573
INFO - 2016-02-28 00:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 00:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:54:42 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:42 --> Total execution time: 1.1199
INFO - 2016-02-28 00:54:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 00:54:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 00:54:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 00:54:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 00:54:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 00:54:43 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:43 --> Total execution time: 1.1403
INFO - 2016-02-28 00:54:52 --> Upload Class Initialized
INFO - 2016-02-28 00:54:52 --> Image Lib Class Initialized
DEBUG - 2016-02-28 00:54:52 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 00:54:52 --> Final output sent to browser
DEBUG - 2016-02-28 00:54:52 --> Total execution time: 1.2994
INFO - 2016-02-28 00:55:30 --> Upload Class Initialized
INFO - 2016-02-28 00:55:30 --> Image Lib Class Initialized
DEBUG - 2016-02-28 00:55:30 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 00:55:30 --> Final output sent to browser
DEBUG - 2016-02-28 00:55:30 --> Total execution time: 1.3403
INFO - 2016-02-28 01:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 01:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:00:43 --> Final output sent to browser
DEBUG - 2016-02-28 01:00:43 --> Total execution time: 1.1006
INFO - 2016-02-28 01:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:00:48 --> Final output sent to browser
DEBUG - 2016-02-28 01:00:48 --> Total execution time: 1.1326
INFO - 2016-02-28 01:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:00:49 --> Final output sent to browser
DEBUG - 2016-02-28 01:00:49 --> Total execution time: 1.1244
INFO - 2016-02-28 01:00:57 --> Upload Class Initialized
INFO - 2016-02-28 01:00:57 --> Image Lib Class Initialized
DEBUG - 2016-02-28 01:00:57 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 01:00:58 --> Final output sent to browser
DEBUG - 2016-02-28 01:00:58 --> Total execution time: 1.3307
INFO - 2016-02-28 01:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 01:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:18 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:18 --> Total execution time: 1.1191
INFO - 2016-02-28 01:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:21 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:21 --> Total execution time: 1.1180
INFO - 2016-02-28 01:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:22 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:22 --> Total execution time: 1.1469
INFO - 2016-02-28 01:02:28 --> Upload Class Initialized
INFO - 2016-02-28 01:02:28 --> Image Lib Class Initialized
DEBUG - 2016-02-28 01:02:28 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 01:02:28 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:28 --> Total execution time: 1.3368
INFO - 2016-02-28 01:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 01:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:54 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:54 --> Total execution time: 1.0983
INFO - 2016-02-28 01:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:56 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:56 --> Total execution time: 1.1103
INFO - 2016-02-28 01:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:02:58 --> Final output sent to browser
DEBUG - 2016-02-28 01:02:58 --> Total execution time: 1.1616
INFO - 2016-02-28 01:03:05 --> Upload Class Initialized
INFO - 2016-02-28 01:03:05 --> Image Lib Class Initialized
DEBUG - 2016-02-28 01:03:05 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 01:03:05 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:05 --> Total execution time: 1.3155
INFO - 2016-02-28 01:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:41 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:41 --> Total execution time: 1.1536
INFO - 2016-02-28 01:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:42 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:42 --> Total execution time: 1.1654
INFO - 2016-02-28 01:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:44 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:44 --> Total execution time: 1.1410
INFO - 2016-02-28 01:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:46 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:46 --> Total execution time: 1.1642
INFO - 2016-02-28 01:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 01:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:48 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:48 --> Total execution time: 1.1118
INFO - 2016-02-28 01:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:51 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:51 --> Total execution time: 1.1361
INFO - 2016-02-28 01:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:03:52 --> Final output sent to browser
DEBUG - 2016-02-28 01:03:52 --> Total execution time: 1.1319
INFO - 2016-02-28 01:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:04:10 --> Final output sent to browser
DEBUG - 2016-02-28 01:04:10 --> Total execution time: 1.1505
INFO - 2016-02-28 01:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:04:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:04:11 --> Final output sent to browser
DEBUG - 2016-02-28 01:04:11 --> Total execution time: 1.1415
INFO - 2016-02-28 01:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:04:20 --> Final output sent to browser
DEBUG - 2016-02-28 01:04:20 --> Total execution time: 1.1284
INFO - 2016-02-28 01:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:04:21 --> Final output sent to browser
DEBUG - 2016-02-28 01:04:21 --> Total execution time: 1.1418
INFO - 2016-02-28 01:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:09:03 --> Final output sent to browser
DEBUG - 2016-02-28 01:09:03 --> Total execution time: 1.1225
INFO - 2016-02-28 01:09:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 01:09:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 01:09:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-28 01:09:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-28 01:09:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 01:09:04 --> Final output sent to browser
DEBUG - 2016-02-28 01:09:04 --> Total execution time: 1.1207
INFO - 2016-02-28 01:09:20 --> Upload Class Initialized
INFO - 2016-02-28 01:09:20 --> Image Lib Class Initialized
DEBUG - 2016-02-28 01:09:20 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-28 01:09:21 --> Final output sent to browser
DEBUG - 2016-02-28 01:09:21 --> Total execution time: 1.3123
INFO - 2016-02-28 08:43:50 --> Config Class Initialized
INFO - 2016-02-28 08:43:50 --> Hooks Class Initialized
DEBUG - 2016-02-28 08:43:50 --> UTF-8 Support Enabled
INFO - 2016-02-28 08:43:50 --> Utf8 Class Initialized
INFO - 2016-02-28 08:43:50 --> URI Class Initialized
DEBUG - 2016-02-28 08:43:50 --> No URI present. Default controller set.
INFO - 2016-02-28 08:43:50 --> Router Class Initialized
INFO - 2016-02-28 08:43:50 --> Output Class Initialized
INFO - 2016-02-28 08:43:50 --> Security Class Initialized
DEBUG - 2016-02-28 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 08:43:50 --> Input Class Initialized
INFO - 2016-02-28 08:43:50 --> Language Class Initialized
INFO - 2016-02-28 08:43:50 --> Loader Class Initialized
INFO - 2016-02-28 08:43:50 --> Helper loaded: url_helper
INFO - 2016-02-28 08:43:50 --> Helper loaded: file_helper
INFO - 2016-02-28 08:43:50 --> Helper loaded: date_helper
INFO - 2016-02-28 08:43:50 --> Helper loaded: form_helper
INFO - 2016-02-28 08:43:50 --> Database Driver Class Initialized
INFO - 2016-02-28 08:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 08:43:51 --> Controller Class Initialized
INFO - 2016-02-28 08:43:51 --> Model Class Initialized
INFO - 2016-02-28 08:43:51 --> Model Class Initialized
INFO - 2016-02-28 08:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 08:43:51 --> Pagination Class Initialized
INFO - 2016-02-28 08:43:51 --> Helper loaded: text_helper
INFO - 2016-02-28 08:43:51 --> Helper loaded: cookie_helper
INFO - 2016-02-28 11:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 11:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 11:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 11:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 11:43:51 --> Final output sent to browser
DEBUG - 2016-02-28 11:43:51 --> Total execution time: 1.2322
INFO - 2016-02-28 08:46:07 --> Config Class Initialized
INFO - 2016-02-28 08:46:07 --> Hooks Class Initialized
DEBUG - 2016-02-28 08:46:07 --> UTF-8 Support Enabled
INFO - 2016-02-28 08:46:07 --> Utf8 Class Initialized
INFO - 2016-02-28 08:46:07 --> URI Class Initialized
INFO - 2016-02-28 08:46:07 --> Router Class Initialized
INFO - 2016-02-28 08:46:07 --> Output Class Initialized
INFO - 2016-02-28 08:46:07 --> Security Class Initialized
DEBUG - 2016-02-28 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 08:46:08 --> Input Class Initialized
INFO - 2016-02-28 08:46:08 --> Language Class Initialized
INFO - 2016-02-28 08:46:08 --> Loader Class Initialized
INFO - 2016-02-28 08:46:08 --> Helper loaded: url_helper
INFO - 2016-02-28 08:46:08 --> Helper loaded: file_helper
INFO - 2016-02-28 08:46:08 --> Helper loaded: date_helper
INFO - 2016-02-28 08:46:08 --> Helper loaded: form_helper
INFO - 2016-02-28 08:46:08 --> Database Driver Class Initialized
INFO - 2016-02-28 08:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 08:46:09 --> Controller Class Initialized
INFO - 2016-02-28 08:46:09 --> Model Class Initialized
INFO - 2016-02-28 08:46:09 --> Model Class Initialized
INFO - 2016-02-28 08:46:09 --> Form Validation Class Initialized
INFO - 2016-02-28 08:46:09 --> Helper loaded: text_helper
INFO - 2016-02-28 08:46:09 --> Config Class Initialized
INFO - 2016-02-28 08:46:09 --> Hooks Class Initialized
DEBUG - 2016-02-28 08:46:09 --> UTF-8 Support Enabled
INFO - 2016-02-28 08:46:09 --> Utf8 Class Initialized
INFO - 2016-02-28 08:46:09 --> URI Class Initialized
INFO - 2016-02-28 08:46:09 --> Router Class Initialized
INFO - 2016-02-28 08:46:09 --> Output Class Initialized
INFO - 2016-02-28 08:46:09 --> Security Class Initialized
DEBUG - 2016-02-28 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 08:46:09 --> Input Class Initialized
INFO - 2016-02-28 08:46:09 --> Language Class Initialized
INFO - 2016-02-28 08:46:09 --> Loader Class Initialized
INFO - 2016-02-28 08:46:09 --> Helper loaded: url_helper
INFO - 2016-02-28 08:46:09 --> Helper loaded: file_helper
INFO - 2016-02-28 08:46:09 --> Helper loaded: date_helper
INFO - 2016-02-28 08:46:09 --> Helper loaded: form_helper
INFO - 2016-02-28 08:46:09 --> Database Driver Class Initialized
INFO - 2016-02-28 08:46:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 08:46:10 --> Controller Class Initialized
INFO - 2016-02-28 08:46:10 --> Model Class Initialized
INFO - 2016-02-28 08:46:10 --> Model Class Initialized
INFO - 2016-02-28 08:46:10 --> Form Validation Class Initialized
INFO - 2016-02-28 08:46:10 --> Helper loaded: text_helper
INFO - 2016-02-28 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-28 08:46:10 --> Final output sent to browser
DEBUG - 2016-02-28 08:46:10 --> Total execution time: 1.1855
INFO - 2016-02-28 08:51:07 --> Config Class Initialized
INFO - 2016-02-28 08:51:07 --> Hooks Class Initialized
DEBUG - 2016-02-28 08:51:07 --> UTF-8 Support Enabled
INFO - 2016-02-28 08:51:07 --> Utf8 Class Initialized
INFO - 2016-02-28 08:51:07 --> URI Class Initialized
INFO - 2016-02-28 08:51:07 --> Router Class Initialized
INFO - 2016-02-28 08:51:07 --> Output Class Initialized
INFO - 2016-02-28 08:51:07 --> Security Class Initialized
DEBUG - 2016-02-28 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 08:51:07 --> Input Class Initialized
INFO - 2016-02-28 08:51:07 --> Language Class Initialized
INFO - 2016-02-28 08:51:07 --> Loader Class Initialized
INFO - 2016-02-28 08:51:07 --> Helper loaded: url_helper
INFO - 2016-02-28 08:51:07 --> Helper loaded: file_helper
INFO - 2016-02-28 08:51:07 --> Helper loaded: date_helper
INFO - 2016-02-28 08:51:07 --> Helper loaded: form_helper
INFO - 2016-02-28 08:51:07 --> Database Driver Class Initialized
INFO - 2016-02-28 08:51:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 08:51:08 --> Controller Class Initialized
INFO - 2016-02-28 08:51:08 --> Model Class Initialized
INFO - 2016-02-28 08:51:08 --> Model Class Initialized
INFO - 2016-02-28 08:51:08 --> Form Validation Class Initialized
INFO - 2016-02-28 08:51:08 --> Helper loaded: text_helper
INFO - 2016-02-28 08:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 08:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-28 08:51:08 --> Final output sent to browser
DEBUG - 2016-02-28 08:51:08 --> Total execution time: 1.1168
INFO - 2016-02-28 08:51:10 --> Config Class Initialized
INFO - 2016-02-28 08:51:10 --> Hooks Class Initialized
DEBUG - 2016-02-28 08:51:10 --> UTF-8 Support Enabled
INFO - 2016-02-28 08:51:10 --> Utf8 Class Initialized
INFO - 2016-02-28 08:51:10 --> URI Class Initialized
DEBUG - 2016-02-28 08:51:10 --> No URI present. Default controller set.
INFO - 2016-02-28 08:51:10 --> Router Class Initialized
INFO - 2016-02-28 08:51:10 --> Output Class Initialized
INFO - 2016-02-28 08:51:10 --> Security Class Initialized
DEBUG - 2016-02-28 08:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 08:51:10 --> Input Class Initialized
INFO - 2016-02-28 08:51:10 --> Language Class Initialized
INFO - 2016-02-28 08:51:10 --> Loader Class Initialized
INFO - 2016-02-28 08:51:10 --> Helper loaded: url_helper
INFO - 2016-02-28 08:51:10 --> Helper loaded: file_helper
INFO - 2016-02-28 08:51:10 --> Helper loaded: date_helper
INFO - 2016-02-28 08:51:10 --> Helper loaded: form_helper
INFO - 2016-02-28 08:51:10 --> Database Driver Class Initialized
INFO - 2016-02-28 08:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 08:51:11 --> Controller Class Initialized
INFO - 2016-02-28 08:51:11 --> Model Class Initialized
INFO - 2016-02-28 08:51:11 --> Model Class Initialized
INFO - 2016-02-28 08:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 08:51:11 --> Pagination Class Initialized
INFO - 2016-02-28 08:51:11 --> Helper loaded: text_helper
INFO - 2016-02-28 08:51:11 --> Helper loaded: cookie_helper
INFO - 2016-02-28 11:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 11:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 11:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 11:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 11:51:11 --> Final output sent to browser
DEBUG - 2016-02-28 11:51:11 --> Total execution time: 1.1378
INFO - 2016-02-28 09:03:13 --> Config Class Initialized
INFO - 2016-02-28 09:03:13 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:03:13 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:03:13 --> Utf8 Class Initialized
INFO - 2016-02-28 09:03:13 --> URI Class Initialized
DEBUG - 2016-02-28 09:03:13 --> No URI present. Default controller set.
INFO - 2016-02-28 09:03:13 --> Router Class Initialized
INFO - 2016-02-28 09:03:13 --> Output Class Initialized
INFO - 2016-02-28 09:03:13 --> Security Class Initialized
DEBUG - 2016-02-28 09:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:03:13 --> Input Class Initialized
INFO - 2016-02-28 09:03:13 --> Language Class Initialized
INFO - 2016-02-28 09:03:13 --> Loader Class Initialized
INFO - 2016-02-28 09:03:13 --> Helper loaded: url_helper
INFO - 2016-02-28 09:03:13 --> Helper loaded: file_helper
INFO - 2016-02-28 09:03:13 --> Helper loaded: date_helper
INFO - 2016-02-28 09:03:13 --> Helper loaded: form_helper
INFO - 2016-02-28 09:03:13 --> Database Driver Class Initialized
INFO - 2016-02-28 09:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:03:14 --> Controller Class Initialized
INFO - 2016-02-28 09:03:14 --> Model Class Initialized
INFO - 2016-02-28 09:03:14 --> Model Class Initialized
INFO - 2016-02-28 09:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:03:14 --> Pagination Class Initialized
INFO - 2016-02-28 09:03:14 --> Helper loaded: text_helper
INFO - 2016-02-28 09:03:14 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:03:14 --> Final output sent to browser
DEBUG - 2016-02-28 12:03:14 --> Total execution time: 1.1555
INFO - 2016-02-28 09:03:43 --> Config Class Initialized
INFO - 2016-02-28 09:03:43 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:03:43 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:03:43 --> Utf8 Class Initialized
INFO - 2016-02-28 09:03:43 --> URI Class Initialized
DEBUG - 2016-02-28 09:03:43 --> No URI present. Default controller set.
INFO - 2016-02-28 09:03:43 --> Router Class Initialized
INFO - 2016-02-28 09:03:43 --> Output Class Initialized
INFO - 2016-02-28 09:03:43 --> Security Class Initialized
DEBUG - 2016-02-28 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:03:43 --> Input Class Initialized
INFO - 2016-02-28 09:03:43 --> Language Class Initialized
INFO - 2016-02-28 09:03:43 --> Loader Class Initialized
INFO - 2016-02-28 09:03:43 --> Helper loaded: url_helper
INFO - 2016-02-28 09:03:43 --> Helper loaded: file_helper
INFO - 2016-02-28 09:03:43 --> Helper loaded: date_helper
INFO - 2016-02-28 09:03:43 --> Helper loaded: form_helper
INFO - 2016-02-28 09:03:43 --> Database Driver Class Initialized
INFO - 2016-02-28 09:03:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:03:44 --> Controller Class Initialized
INFO - 2016-02-28 09:03:44 --> Model Class Initialized
INFO - 2016-02-28 09:03:44 --> Model Class Initialized
INFO - 2016-02-28 09:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:03:44 --> Pagination Class Initialized
INFO - 2016-02-28 09:03:44 --> Helper loaded: text_helper
INFO - 2016-02-28 09:03:44 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:03:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:03:44 --> Final output sent to browser
DEBUG - 2016-02-28 12:03:44 --> Total execution time: 1.1296
INFO - 2016-02-28 09:04:34 --> Config Class Initialized
INFO - 2016-02-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:04:34 --> Utf8 Class Initialized
INFO - 2016-02-28 09:04:34 --> URI Class Initialized
DEBUG - 2016-02-28 09:04:34 --> No URI present. Default controller set.
INFO - 2016-02-28 09:04:34 --> Router Class Initialized
INFO - 2016-02-28 09:04:34 --> Output Class Initialized
INFO - 2016-02-28 09:04:34 --> Security Class Initialized
DEBUG - 2016-02-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:04:34 --> Input Class Initialized
INFO - 2016-02-28 09:04:34 --> Language Class Initialized
INFO - 2016-02-28 09:04:34 --> Loader Class Initialized
INFO - 2016-02-28 09:04:34 --> Helper loaded: url_helper
INFO - 2016-02-28 09:04:34 --> Helper loaded: file_helper
INFO - 2016-02-28 09:04:34 --> Helper loaded: date_helper
INFO - 2016-02-28 09:04:34 --> Helper loaded: form_helper
INFO - 2016-02-28 09:04:34 --> Database Driver Class Initialized
INFO - 2016-02-28 09:04:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:04:35 --> Controller Class Initialized
INFO - 2016-02-28 09:04:35 --> Model Class Initialized
INFO - 2016-02-28 09:04:35 --> Model Class Initialized
INFO - 2016-02-28 09:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:04:35 --> Pagination Class Initialized
INFO - 2016-02-28 09:04:36 --> Helper loaded: text_helper
INFO - 2016-02-28 09:04:36 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:04:36 --> Final output sent to browser
DEBUG - 2016-02-28 12:04:36 --> Total execution time: 1.1349
INFO - 2016-02-28 09:19:19 --> Config Class Initialized
INFO - 2016-02-28 09:19:19 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:19:19 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:19:19 --> Utf8 Class Initialized
INFO - 2016-02-28 09:19:19 --> URI Class Initialized
DEBUG - 2016-02-28 09:19:19 --> No URI present. Default controller set.
INFO - 2016-02-28 09:19:19 --> Router Class Initialized
INFO - 2016-02-28 09:19:19 --> Output Class Initialized
INFO - 2016-02-28 09:19:19 --> Security Class Initialized
DEBUG - 2016-02-28 09:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:19:19 --> Input Class Initialized
INFO - 2016-02-28 09:19:19 --> Language Class Initialized
INFO - 2016-02-28 09:19:19 --> Loader Class Initialized
INFO - 2016-02-28 09:19:19 --> Helper loaded: url_helper
INFO - 2016-02-28 09:19:19 --> Helper loaded: file_helper
INFO - 2016-02-28 09:19:19 --> Helper loaded: date_helper
INFO - 2016-02-28 09:19:19 --> Helper loaded: form_helper
INFO - 2016-02-28 09:19:19 --> Database Driver Class Initialized
INFO - 2016-02-28 09:19:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:19:20 --> Controller Class Initialized
INFO - 2016-02-28 09:19:20 --> Model Class Initialized
INFO - 2016-02-28 09:19:20 --> Model Class Initialized
INFO - 2016-02-28 09:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:19:20 --> Pagination Class Initialized
INFO - 2016-02-28 09:19:20 --> Helper loaded: text_helper
INFO - 2016-02-28 09:19:20 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:19:20 --> Final output sent to browser
DEBUG - 2016-02-28 12:19:20 --> Total execution time: 1.1269
INFO - 2016-02-28 09:19:23 --> Config Class Initialized
INFO - 2016-02-28 09:19:23 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:19:23 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:19:23 --> Utf8 Class Initialized
INFO - 2016-02-28 09:19:23 --> URI Class Initialized
INFO - 2016-02-28 09:19:23 --> Router Class Initialized
INFO - 2016-02-28 09:19:23 --> Output Class Initialized
INFO - 2016-02-28 09:19:23 --> Security Class Initialized
DEBUG - 2016-02-28 09:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:19:23 --> Input Class Initialized
INFO - 2016-02-28 09:19:23 --> Language Class Initialized
INFO - 2016-02-28 09:19:23 --> Loader Class Initialized
INFO - 2016-02-28 09:19:23 --> Helper loaded: url_helper
INFO - 2016-02-28 09:19:23 --> Helper loaded: file_helper
INFO - 2016-02-28 09:19:23 --> Helper loaded: date_helper
INFO - 2016-02-28 09:19:23 --> Helper loaded: form_helper
INFO - 2016-02-28 09:19:23 --> Database Driver Class Initialized
INFO - 2016-02-28 09:19:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:19:24 --> Controller Class Initialized
INFO - 2016-02-28 09:19:24 --> Model Class Initialized
INFO - 2016-02-28 09:19:24 --> Model Class Initialized
INFO - 2016-02-28 09:19:24 --> Form Validation Class Initialized
INFO - 2016-02-28 09:19:24 --> Helper loaded: text_helper
ERROR - 2016-02-28 09:19:24 --> Severity: Error --> Call to undefined function validation_error() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 110
INFO - 2016-02-28 09:21:51 --> Config Class Initialized
INFO - 2016-02-28 09:21:51 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:21:51 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:21:51 --> Utf8 Class Initialized
INFO - 2016-02-28 09:21:51 --> URI Class Initialized
DEBUG - 2016-02-28 09:21:51 --> No URI present. Default controller set.
INFO - 2016-02-28 09:21:51 --> Router Class Initialized
INFO - 2016-02-28 09:21:51 --> Output Class Initialized
INFO - 2016-02-28 09:21:51 --> Security Class Initialized
DEBUG - 2016-02-28 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:21:51 --> Input Class Initialized
INFO - 2016-02-28 09:21:51 --> Language Class Initialized
INFO - 2016-02-28 09:21:51 --> Loader Class Initialized
INFO - 2016-02-28 09:21:51 --> Helper loaded: url_helper
INFO - 2016-02-28 09:21:51 --> Helper loaded: file_helper
INFO - 2016-02-28 09:21:51 --> Helper loaded: date_helper
INFO - 2016-02-28 09:21:51 --> Helper loaded: form_helper
INFO - 2016-02-28 09:21:51 --> Database Driver Class Initialized
INFO - 2016-02-28 09:21:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:21:52 --> Controller Class Initialized
INFO - 2016-02-28 09:21:52 --> Model Class Initialized
INFO - 2016-02-28 09:21:52 --> Model Class Initialized
INFO - 2016-02-28 09:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:21:52 --> Pagination Class Initialized
INFO - 2016-02-28 09:21:52 --> Helper loaded: text_helper
INFO - 2016-02-28 09:21:52 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:21:52 --> Final output sent to browser
DEBUG - 2016-02-28 12:21:52 --> Total execution time: 1.1281
INFO - 2016-02-28 09:21:55 --> Config Class Initialized
INFO - 2016-02-28 09:21:55 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:21:55 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:21:55 --> Utf8 Class Initialized
INFO - 2016-02-28 09:21:55 --> URI Class Initialized
INFO - 2016-02-28 09:21:55 --> Router Class Initialized
INFO - 2016-02-28 09:21:55 --> Output Class Initialized
INFO - 2016-02-28 09:21:55 --> Security Class Initialized
DEBUG - 2016-02-28 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:21:55 --> Input Class Initialized
INFO - 2016-02-28 09:21:55 --> Language Class Initialized
INFO - 2016-02-28 09:21:55 --> Loader Class Initialized
INFO - 2016-02-28 09:21:55 --> Helper loaded: url_helper
INFO - 2016-02-28 09:21:55 --> Helper loaded: file_helper
INFO - 2016-02-28 09:21:55 --> Helper loaded: date_helper
INFO - 2016-02-28 09:21:55 --> Helper loaded: form_helper
INFO - 2016-02-28 09:21:55 --> Database Driver Class Initialized
INFO - 2016-02-28 09:21:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:21:56 --> Controller Class Initialized
INFO - 2016-02-28 09:21:56 --> Model Class Initialized
INFO - 2016-02-28 09:21:56 --> Model Class Initialized
INFO - 2016-02-28 09:21:56 --> Form Validation Class Initialized
INFO - 2016-02-28 09:21:56 --> Helper loaded: text_helper
INFO - 2016-02-28 09:21:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-28 09:21:56 --> Unable to find validation rule: xss_clean
ERROR - 2016-02-28 09:21:56 --> Could not find the language line "form_validation_xss_clean"
DEBUG - 2016-02-28 09:21:56 --> Unable to find validation rule: xss_clean
ERROR - 2016-02-28 09:21:56 --> Could not find the language line "form_validation_xss_clean"
ERROR - 2016-02-28 09:21:56 --> Severity: Error --> Call to undefined function validation_error() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 93
INFO - 2016-02-28 09:22:16 --> Config Class Initialized
INFO - 2016-02-28 09:22:16 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:22:16 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:22:16 --> Utf8 Class Initialized
INFO - 2016-02-28 09:22:16 --> URI Class Initialized
DEBUG - 2016-02-28 09:22:16 --> No URI present. Default controller set.
INFO - 2016-02-28 09:22:16 --> Router Class Initialized
INFO - 2016-02-28 09:22:16 --> Output Class Initialized
INFO - 2016-02-28 09:22:16 --> Security Class Initialized
DEBUG - 2016-02-28 09:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:22:16 --> Input Class Initialized
INFO - 2016-02-28 09:22:16 --> Language Class Initialized
INFO - 2016-02-28 09:22:16 --> Loader Class Initialized
INFO - 2016-02-28 09:22:16 --> Helper loaded: url_helper
INFO - 2016-02-28 09:22:16 --> Helper loaded: file_helper
INFO - 2016-02-28 09:22:16 --> Helper loaded: date_helper
INFO - 2016-02-28 09:22:16 --> Helper loaded: form_helper
INFO - 2016-02-28 09:22:16 --> Database Driver Class Initialized
INFO - 2016-02-28 09:22:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:22:17 --> Controller Class Initialized
INFO - 2016-02-28 09:22:17 --> Model Class Initialized
INFO - 2016-02-28 09:22:17 --> Model Class Initialized
INFO - 2016-02-28 09:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:22:17 --> Pagination Class Initialized
INFO - 2016-02-28 09:22:17 --> Helper loaded: text_helper
INFO - 2016-02-28 09:22:17 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:22:17 --> Final output sent to browser
DEBUG - 2016-02-28 12:22:17 --> Total execution time: 1.1392
INFO - 2016-02-28 09:22:19 --> Config Class Initialized
INFO - 2016-02-28 09:22:19 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:22:19 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:22:19 --> Utf8 Class Initialized
INFO - 2016-02-28 09:22:19 --> URI Class Initialized
INFO - 2016-02-28 09:22:19 --> Router Class Initialized
INFO - 2016-02-28 09:22:19 --> Output Class Initialized
INFO - 2016-02-28 09:22:19 --> Security Class Initialized
DEBUG - 2016-02-28 09:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:22:19 --> Input Class Initialized
INFO - 2016-02-28 09:22:19 --> Language Class Initialized
INFO - 2016-02-28 09:22:19 --> Loader Class Initialized
INFO - 2016-02-28 09:22:19 --> Helper loaded: url_helper
INFO - 2016-02-28 09:22:19 --> Helper loaded: file_helper
INFO - 2016-02-28 09:22:19 --> Helper loaded: date_helper
INFO - 2016-02-28 09:22:19 --> Helper loaded: form_helper
INFO - 2016-02-28 09:22:19 --> Database Driver Class Initialized
INFO - 2016-02-28 09:22:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:22:20 --> Controller Class Initialized
INFO - 2016-02-28 09:22:20 --> Model Class Initialized
INFO - 2016-02-28 09:22:20 --> Model Class Initialized
INFO - 2016-02-28 09:22:20 --> Form Validation Class Initialized
INFO - 2016-02-28 09:22:20 --> Helper loaded: text_helper
INFO - 2016-02-28 09:22:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-28 09:22:20 --> Unable to find validation rule: xss_clean
ERROR - 2016-02-28 09:22:20 --> Could not find the language line "form_validation_xss_clean"
DEBUG - 2016-02-28 09:22:20 --> Unable to find validation rule: xss_clean
ERROR - 2016-02-28 09:22:20 --> Could not find the language line "form_validation_xss_clean"
INFO - 2016-02-28 09:22:20 --> Final output sent to browser
DEBUG - 2016-02-28 09:22:20 --> Total execution time: 1.1085
INFO - 2016-02-28 09:22:44 --> Config Class Initialized
INFO - 2016-02-28 09:22:44 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:22:44 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:22:44 --> Utf8 Class Initialized
INFO - 2016-02-28 09:22:44 --> URI Class Initialized
DEBUG - 2016-02-28 09:22:44 --> No URI present. Default controller set.
INFO - 2016-02-28 09:22:44 --> Router Class Initialized
INFO - 2016-02-28 09:22:44 --> Output Class Initialized
INFO - 2016-02-28 09:22:44 --> Security Class Initialized
DEBUG - 2016-02-28 09:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:22:44 --> Input Class Initialized
INFO - 2016-02-28 09:22:44 --> Language Class Initialized
INFO - 2016-02-28 09:22:44 --> Loader Class Initialized
INFO - 2016-02-28 09:22:44 --> Helper loaded: url_helper
INFO - 2016-02-28 09:22:44 --> Helper loaded: file_helper
INFO - 2016-02-28 09:22:44 --> Helper loaded: date_helper
INFO - 2016-02-28 09:22:44 --> Helper loaded: form_helper
INFO - 2016-02-28 09:22:44 --> Database Driver Class Initialized
INFO - 2016-02-28 09:22:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:22:45 --> Controller Class Initialized
INFO - 2016-02-28 09:22:45 --> Model Class Initialized
INFO - 2016-02-28 09:22:45 --> Model Class Initialized
INFO - 2016-02-28 09:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:22:45 --> Pagination Class Initialized
INFO - 2016-02-28 09:22:45 --> Helper loaded: text_helper
INFO - 2016-02-28 09:22:45 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:22:45 --> Final output sent to browser
DEBUG - 2016-02-28 12:22:45 --> Total execution time: 1.1156
INFO - 2016-02-28 09:22:48 --> Config Class Initialized
INFO - 2016-02-28 09:22:48 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:22:48 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:22:48 --> Utf8 Class Initialized
INFO - 2016-02-28 09:22:48 --> URI Class Initialized
INFO - 2016-02-28 09:22:48 --> Router Class Initialized
INFO - 2016-02-28 09:22:48 --> Output Class Initialized
INFO - 2016-02-28 09:22:48 --> Security Class Initialized
DEBUG - 2016-02-28 09:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:22:48 --> Input Class Initialized
INFO - 2016-02-28 09:22:48 --> Language Class Initialized
INFO - 2016-02-28 09:22:48 --> Loader Class Initialized
INFO - 2016-02-28 09:22:48 --> Helper loaded: url_helper
INFO - 2016-02-28 09:22:48 --> Helper loaded: file_helper
INFO - 2016-02-28 09:22:48 --> Helper loaded: date_helper
INFO - 2016-02-28 09:22:48 --> Helper loaded: form_helper
INFO - 2016-02-28 09:22:48 --> Database Driver Class Initialized
INFO - 2016-02-28 09:22:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:22:49 --> Controller Class Initialized
INFO - 2016-02-28 09:22:49 --> Model Class Initialized
INFO - 2016-02-28 09:22:49 --> Model Class Initialized
INFO - 2016-02-28 09:22:49 --> Form Validation Class Initialized
INFO - 2016-02-28 09:22:49 --> Helper loaded: text_helper
INFO - 2016-02-28 09:22:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-28 09:22:49 --> Final output sent to browser
DEBUG - 2016-02-28 09:22:49 --> Total execution time: 1.0975
INFO - 2016-02-28 09:24:03 --> Config Class Initialized
INFO - 2016-02-28 09:24:03 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:24:03 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:24:03 --> Utf8 Class Initialized
INFO - 2016-02-28 09:24:03 --> URI Class Initialized
DEBUG - 2016-02-28 09:24:03 --> No URI present. Default controller set.
INFO - 2016-02-28 09:24:03 --> Router Class Initialized
INFO - 2016-02-28 09:24:03 --> Output Class Initialized
INFO - 2016-02-28 09:24:03 --> Security Class Initialized
DEBUG - 2016-02-28 09:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:24:03 --> Input Class Initialized
INFO - 2016-02-28 09:24:03 --> Language Class Initialized
INFO - 2016-02-28 09:24:03 --> Loader Class Initialized
INFO - 2016-02-28 09:24:03 --> Helper loaded: url_helper
INFO - 2016-02-28 09:24:03 --> Helper loaded: file_helper
INFO - 2016-02-28 09:24:03 --> Helper loaded: date_helper
INFO - 2016-02-28 09:24:03 --> Helper loaded: form_helper
INFO - 2016-02-28 09:24:03 --> Database Driver Class Initialized
INFO - 2016-02-28 09:24:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:24:04 --> Controller Class Initialized
INFO - 2016-02-28 09:24:04 --> Model Class Initialized
INFO - 2016-02-28 09:24:04 --> Model Class Initialized
INFO - 2016-02-28 09:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:24:04 --> Pagination Class Initialized
INFO - 2016-02-28 09:24:04 --> Helper loaded: text_helper
INFO - 2016-02-28 09:24:04 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:24:04 --> Final output sent to browser
DEBUG - 2016-02-28 12:24:04 --> Total execution time: 1.1390
INFO - 2016-02-28 09:24:12 --> Config Class Initialized
INFO - 2016-02-28 09:24:12 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:24:12 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:24:12 --> Utf8 Class Initialized
INFO - 2016-02-28 09:24:12 --> URI Class Initialized
INFO - 2016-02-28 09:24:12 --> Router Class Initialized
INFO - 2016-02-28 09:24:12 --> Output Class Initialized
INFO - 2016-02-28 09:24:12 --> Security Class Initialized
DEBUG - 2016-02-28 09:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:24:12 --> Input Class Initialized
INFO - 2016-02-28 09:24:12 --> Language Class Initialized
INFO - 2016-02-28 09:24:12 --> Loader Class Initialized
INFO - 2016-02-28 09:24:12 --> Helper loaded: url_helper
INFO - 2016-02-28 09:24:12 --> Helper loaded: file_helper
INFO - 2016-02-28 09:24:12 --> Helper loaded: date_helper
INFO - 2016-02-28 09:24:12 --> Helper loaded: form_helper
INFO - 2016-02-28 09:24:12 --> Database Driver Class Initialized
INFO - 2016-02-28 09:24:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:24:13 --> Controller Class Initialized
INFO - 2016-02-28 09:24:13 --> Model Class Initialized
INFO - 2016-02-28 09:24:13 --> Model Class Initialized
INFO - 2016-02-28 09:24:13 --> Form Validation Class Initialized
INFO - 2016-02-28 09:24:14 --> Helper loaded: text_helper
INFO - 2016-02-28 09:24:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-28 09:24:14 --> Final output sent to browser
DEBUG - 2016-02-28 09:24:14 --> Total execution time: 1.1490
INFO - 2016-02-28 09:54:01 --> Config Class Initialized
INFO - 2016-02-28 09:54:01 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:01 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:01 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:01 --> URI Class Initialized
DEBUG - 2016-02-28 09:54:01 --> No URI present. Default controller set.
INFO - 2016-02-28 09:54:01 --> Router Class Initialized
INFO - 2016-02-28 09:54:01 --> Output Class Initialized
INFO - 2016-02-28 09:54:01 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:01 --> Input Class Initialized
INFO - 2016-02-28 09:54:01 --> Language Class Initialized
INFO - 2016-02-28 09:54:01 --> Loader Class Initialized
INFO - 2016-02-28 09:54:01 --> Helper loaded: url_helper
INFO - 2016-02-28 09:54:01 --> Helper loaded: file_helper
INFO - 2016-02-28 09:54:01 --> Helper loaded: date_helper
INFO - 2016-02-28 09:54:01 --> Helper loaded: form_helper
INFO - 2016-02-28 09:54:01 --> Database Driver Class Initialized
INFO - 2016-02-28 09:54:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:54:02 --> Controller Class Initialized
INFO - 2016-02-28 09:54:02 --> Model Class Initialized
INFO - 2016-02-28 09:54:02 --> Model Class Initialized
INFO - 2016-02-28 09:54:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:54:02 --> Pagination Class Initialized
INFO - 2016-02-28 09:54:02 --> Helper loaded: text_helper
INFO - 2016-02-28 09:54:02 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:54:02 --> Final output sent to browser
DEBUG - 2016-02-28 12:54:02 --> Total execution time: 1.1284
INFO - 2016-02-28 09:54:04 --> Config Class Initialized
INFO - 2016-02-28 09:54:04 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:04 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:04 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:04 --> URI Class Initialized
INFO - 2016-02-28 09:54:04 --> Router Class Initialized
INFO - 2016-02-28 09:54:04 --> Output Class Initialized
INFO - 2016-02-28 09:54:04 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:04 --> Input Class Initialized
INFO - 2016-02-28 09:54:04 --> Language Class Initialized
ERROR - 2016-02-28 09:54:04 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:06 --> Config Class Initialized
INFO - 2016-02-28 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:06 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:06 --> URI Class Initialized
INFO - 2016-02-28 09:54:06 --> Router Class Initialized
INFO - 2016-02-28 09:54:06 --> Output Class Initialized
INFO - 2016-02-28 09:54:06 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:06 --> Input Class Initialized
INFO - 2016-02-28 09:54:06 --> Language Class Initialized
ERROR - 2016-02-28 09:54:06 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:06 --> Config Class Initialized
INFO - 2016-02-28 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:06 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:06 --> URI Class Initialized
INFO - 2016-02-28 09:54:06 --> Router Class Initialized
INFO - 2016-02-28 09:54:06 --> Output Class Initialized
INFO - 2016-02-28 09:54:06 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:06 --> Input Class Initialized
INFO - 2016-02-28 09:54:06 --> Language Class Initialized
ERROR - 2016-02-28 09:54:06 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:06 --> Config Class Initialized
INFO - 2016-02-28 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:06 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:06 --> URI Class Initialized
INFO - 2016-02-28 09:54:06 --> Router Class Initialized
INFO - 2016-02-28 09:54:06 --> Output Class Initialized
INFO - 2016-02-28 09:54:06 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:06 --> Input Class Initialized
INFO - 2016-02-28 09:54:06 --> Language Class Initialized
ERROR - 2016-02-28 09:54:06 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:06 --> Config Class Initialized
INFO - 2016-02-28 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:06 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:06 --> URI Class Initialized
INFO - 2016-02-28 09:54:06 --> Router Class Initialized
INFO - 2016-02-28 09:54:06 --> Output Class Initialized
INFO - 2016-02-28 09:54:06 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:06 --> Input Class Initialized
INFO - 2016-02-28 09:54:06 --> Language Class Initialized
ERROR - 2016-02-28 09:54:06 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:07 --> Config Class Initialized
INFO - 2016-02-28 09:54:07 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:07 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:07 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:07 --> URI Class Initialized
INFO - 2016-02-28 09:54:07 --> Router Class Initialized
INFO - 2016-02-28 09:54:07 --> Output Class Initialized
INFO - 2016-02-28 09:54:07 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:07 --> Input Class Initialized
INFO - 2016-02-28 09:54:07 --> Language Class Initialized
ERROR - 2016-02-28 09:54:07 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:08 --> Config Class Initialized
INFO - 2016-02-28 09:54:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:08 --> URI Class Initialized
INFO - 2016-02-28 09:54:08 --> Router Class Initialized
INFO - 2016-02-28 09:54:08 --> Output Class Initialized
INFO - 2016-02-28 09:54:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:08 --> Input Class Initialized
INFO - 2016-02-28 09:54:08 --> Language Class Initialized
ERROR - 2016-02-28 09:54:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:08 --> Config Class Initialized
INFO - 2016-02-28 09:54:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:08 --> URI Class Initialized
INFO - 2016-02-28 09:54:08 --> Router Class Initialized
INFO - 2016-02-28 09:54:08 --> Output Class Initialized
INFO - 2016-02-28 09:54:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:08 --> Input Class Initialized
INFO - 2016-02-28 09:54:08 --> Language Class Initialized
ERROR - 2016-02-28 09:54:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:54:08 --> Config Class Initialized
INFO - 2016-02-28 09:54:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:54:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:54:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:54:08 --> URI Class Initialized
INFO - 2016-02-28 09:54:08 --> Router Class Initialized
INFO - 2016-02-28 09:54:08 --> Output Class Initialized
INFO - 2016-02-28 09:54:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:54:08 --> Input Class Initialized
INFO - 2016-02-28 09:54:08 --> Language Class Initialized
ERROR - 2016-02-28 09:54:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:08 --> Config Class Initialized
INFO - 2016-02-28 09:55:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:08 --> URI Class Initialized
INFO - 2016-02-28 09:55:08 --> Router Class Initialized
INFO - 2016-02-28 09:55:08 --> Output Class Initialized
INFO - 2016-02-28 09:55:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:08 --> Input Class Initialized
INFO - 2016-02-28 09:55:08 --> Language Class Initialized
ERROR - 2016-02-28 09:55:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:08 --> Config Class Initialized
INFO - 2016-02-28 09:55:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:08 --> URI Class Initialized
INFO - 2016-02-28 09:55:08 --> Router Class Initialized
INFO - 2016-02-28 09:55:08 --> Output Class Initialized
INFO - 2016-02-28 09:55:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:08 --> Input Class Initialized
INFO - 2016-02-28 09:55:08 --> Language Class Initialized
ERROR - 2016-02-28 09:55:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:08 --> Config Class Initialized
INFO - 2016-02-28 09:55:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:08 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:08 --> URI Class Initialized
INFO - 2016-02-28 09:55:08 --> Router Class Initialized
INFO - 2016-02-28 09:55:08 --> Output Class Initialized
INFO - 2016-02-28 09:55:08 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:08 --> Input Class Initialized
INFO - 2016-02-28 09:55:08 --> Language Class Initialized
ERROR - 2016-02-28 09:55:08 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:09 --> Config Class Initialized
INFO - 2016-02-28 09:55:09 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:09 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:09 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:09 --> URI Class Initialized
INFO - 2016-02-28 09:55:09 --> Router Class Initialized
INFO - 2016-02-28 09:55:09 --> Output Class Initialized
INFO - 2016-02-28 09:55:09 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:09 --> Input Class Initialized
INFO - 2016-02-28 09:55:09 --> Language Class Initialized
ERROR - 2016-02-28 09:55:09 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:10 --> Config Class Initialized
INFO - 2016-02-28 09:55:10 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:10 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:10 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:10 --> URI Class Initialized
INFO - 2016-02-28 09:55:10 --> Router Class Initialized
INFO - 2016-02-28 09:55:10 --> Output Class Initialized
INFO - 2016-02-28 09:55:10 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:10 --> Input Class Initialized
INFO - 2016-02-28 09:55:10 --> Language Class Initialized
ERROR - 2016-02-28 09:55:10 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:55:11 --> Config Class Initialized
INFO - 2016-02-28 09:55:11 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:55:11 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:55:11 --> Utf8 Class Initialized
INFO - 2016-02-28 09:55:11 --> URI Class Initialized
INFO - 2016-02-28 09:55:11 --> Router Class Initialized
INFO - 2016-02-28 09:55:11 --> Output Class Initialized
INFO - 2016-02-28 09:55:11 --> Security Class Initialized
DEBUG - 2016-02-28 09:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:55:11 --> Input Class Initialized
INFO - 2016-02-28 09:55:11 --> Language Class Initialized
ERROR - 2016-02-28 09:55:11 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:56:45 --> Config Class Initialized
INFO - 2016-02-28 09:56:45 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:56:45 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:56:45 --> Utf8 Class Initialized
INFO - 2016-02-28 09:56:45 --> URI Class Initialized
INFO - 2016-02-28 09:56:45 --> Router Class Initialized
INFO - 2016-02-28 09:56:45 --> Output Class Initialized
INFO - 2016-02-28 09:56:45 --> Security Class Initialized
DEBUG - 2016-02-28 09:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:56:45 --> Input Class Initialized
INFO - 2016-02-28 09:56:45 --> Language Class Initialized
ERROR - 2016-02-28 09:56:45 --> 404 Page Not Found: Insert_comment/index
INFO - 2016-02-28 09:58:22 --> Config Class Initialized
INFO - 2016-02-28 09:58:22 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:58:22 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:58:22 --> Utf8 Class Initialized
INFO - 2016-02-28 09:58:22 --> URI Class Initialized
DEBUG - 2016-02-28 09:58:22 --> No URI present. Default controller set.
INFO - 2016-02-28 09:58:22 --> Router Class Initialized
INFO - 2016-02-28 09:58:22 --> Output Class Initialized
INFO - 2016-02-28 09:58:22 --> Security Class Initialized
DEBUG - 2016-02-28 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:58:22 --> Input Class Initialized
INFO - 2016-02-28 09:58:22 --> Language Class Initialized
INFO - 2016-02-28 09:58:22 --> Loader Class Initialized
INFO - 2016-02-28 09:58:22 --> Helper loaded: url_helper
INFO - 2016-02-28 09:58:22 --> Helper loaded: file_helper
INFO - 2016-02-28 09:58:22 --> Helper loaded: date_helper
INFO - 2016-02-28 09:58:22 --> Helper loaded: form_helper
INFO - 2016-02-28 09:58:22 --> Database Driver Class Initialized
INFO - 2016-02-28 09:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:58:23 --> Controller Class Initialized
INFO - 2016-02-28 09:58:23 --> Model Class Initialized
INFO - 2016-02-28 09:58:23 --> Model Class Initialized
INFO - 2016-02-28 09:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:58:23 --> Pagination Class Initialized
INFO - 2016-02-28 09:58:23 --> Helper loaded: text_helper
INFO - 2016-02-28 09:58:23 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:58:23 --> Final output sent to browser
DEBUG - 2016-02-28 12:58:23 --> Total execution time: 1.1639
INFO - 2016-02-28 09:58:26 --> Config Class Initialized
INFO - 2016-02-28 09:58:26 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:58:26 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:58:26 --> Utf8 Class Initialized
INFO - 2016-02-28 09:58:26 --> URI Class Initialized
INFO - 2016-02-28 09:58:26 --> Router Class Initialized
INFO - 2016-02-28 09:58:26 --> Output Class Initialized
INFO - 2016-02-28 09:58:26 --> Security Class Initialized
DEBUG - 2016-02-28 09:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:58:26 --> Input Class Initialized
INFO - 2016-02-28 09:58:26 --> Language Class Initialized
INFO - 2016-02-28 09:58:26 --> Loader Class Initialized
INFO - 2016-02-28 09:58:26 --> Helper loaded: url_helper
INFO - 2016-02-28 09:58:26 --> Helper loaded: file_helper
INFO - 2016-02-28 09:58:26 --> Helper loaded: date_helper
INFO - 2016-02-28 09:58:26 --> Helper loaded: form_helper
INFO - 2016-02-28 09:58:26 --> Database Driver Class Initialized
INFO - 2016-02-28 09:58:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:58:27 --> Controller Class Initialized
INFO - 2016-02-28 09:58:27 --> Model Class Initialized
INFO - 2016-02-28 09:58:27 --> Model Class Initialized
INFO - 2016-02-28 09:58:27 --> Form Validation Class Initialized
INFO - 2016-02-28 09:58:27 --> Helper loaded: text_helper
INFO - 2016-02-28 09:58:27 --> Final output sent to browser
DEBUG - 2016-02-28 09:58:27 --> Total execution time: 1.1342
INFO - 2016-02-28 09:59:17 --> Config Class Initialized
INFO - 2016-02-28 09:59:17 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:59:17 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:59:17 --> Utf8 Class Initialized
INFO - 2016-02-28 09:59:17 --> URI Class Initialized
INFO - 2016-02-28 09:59:17 --> Router Class Initialized
INFO - 2016-02-28 09:59:17 --> Output Class Initialized
INFO - 2016-02-28 09:59:17 --> Security Class Initialized
DEBUG - 2016-02-28 09:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:59:17 --> Input Class Initialized
INFO - 2016-02-28 09:59:17 --> Language Class Initialized
INFO - 2016-02-28 09:59:17 --> Loader Class Initialized
INFO - 2016-02-28 09:59:17 --> Helper loaded: url_helper
INFO - 2016-02-28 09:59:17 --> Helper loaded: file_helper
INFO - 2016-02-28 09:59:17 --> Helper loaded: date_helper
INFO - 2016-02-28 09:59:17 --> Helper loaded: form_helper
INFO - 2016-02-28 09:59:17 --> Database Driver Class Initialized
INFO - 2016-02-28 09:59:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:59:18 --> Controller Class Initialized
INFO - 2016-02-28 09:59:18 --> Model Class Initialized
INFO - 2016-02-28 09:59:18 --> Model Class Initialized
INFO - 2016-02-28 09:59:18 --> Form Validation Class Initialized
INFO - 2016-02-28 09:59:18 --> Helper loaded: text_helper
INFO - 2016-02-28 09:59:18 --> Config Class Initialized
INFO - 2016-02-28 09:59:18 --> Hooks Class Initialized
DEBUG - 2016-02-28 09:59:18 --> UTF-8 Support Enabled
INFO - 2016-02-28 09:59:18 --> Utf8 Class Initialized
INFO - 2016-02-28 09:59:18 --> URI Class Initialized
DEBUG - 2016-02-28 09:59:18 --> No URI present. Default controller set.
INFO - 2016-02-28 09:59:18 --> Router Class Initialized
INFO - 2016-02-28 09:59:18 --> Output Class Initialized
INFO - 2016-02-28 09:59:18 --> Security Class Initialized
DEBUG - 2016-02-28 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 09:59:18 --> Input Class Initialized
INFO - 2016-02-28 09:59:18 --> Language Class Initialized
INFO - 2016-02-28 09:59:18 --> Loader Class Initialized
INFO - 2016-02-28 09:59:18 --> Helper loaded: url_helper
INFO - 2016-02-28 09:59:18 --> Helper loaded: file_helper
INFO - 2016-02-28 09:59:18 --> Helper loaded: date_helper
INFO - 2016-02-28 09:59:18 --> Helper loaded: form_helper
INFO - 2016-02-28 09:59:18 --> Database Driver Class Initialized
INFO - 2016-02-28 09:59:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 09:59:19 --> Controller Class Initialized
INFO - 2016-02-28 09:59:19 --> Model Class Initialized
INFO - 2016-02-28 09:59:19 --> Model Class Initialized
INFO - 2016-02-28 09:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 09:59:19 --> Pagination Class Initialized
INFO - 2016-02-28 09:59:19 --> Helper loaded: text_helper
INFO - 2016-02-28 09:59:19 --> Helper loaded: cookie_helper
INFO - 2016-02-28 12:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 12:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 12:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 12:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 12:59:19 --> Final output sent to browser
DEBUG - 2016-02-28 12:59:19 --> Total execution time: 1.1426
INFO - 2016-02-28 10:00:00 --> Config Class Initialized
INFO - 2016-02-28 10:00:00 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:00 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:00 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:00 --> URI Class Initialized
INFO - 2016-02-28 10:00:00 --> Router Class Initialized
INFO - 2016-02-28 10:00:00 --> Output Class Initialized
INFO - 2016-02-28 10:00:00 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:00 --> Input Class Initialized
INFO - 2016-02-28 10:00:00 --> Language Class Initialized
INFO - 2016-02-28 10:00:00 --> Loader Class Initialized
INFO - 2016-02-28 10:00:00 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:00 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:00 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:00 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:00 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:01 --> Controller Class Initialized
INFO - 2016-02-28 10:00:01 --> Model Class Initialized
INFO - 2016-02-28 10:00:01 --> Model Class Initialized
INFO - 2016-02-28 10:00:01 --> Form Validation Class Initialized
INFO - 2016-02-28 10:00:01 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:01 --> Config Class Initialized
INFO - 2016-02-28 10:00:01 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:01 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:01 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:01 --> URI Class Initialized
DEBUG - 2016-02-28 10:00:01 --> No URI present. Default controller set.
INFO - 2016-02-28 10:00:01 --> Router Class Initialized
INFO - 2016-02-28 10:00:01 --> Output Class Initialized
INFO - 2016-02-28 10:00:01 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:01 --> Input Class Initialized
INFO - 2016-02-28 10:00:01 --> Language Class Initialized
INFO - 2016-02-28 10:00:01 --> Loader Class Initialized
INFO - 2016-02-28 10:00:01 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:01 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:01 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:01 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:01 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:03 --> Controller Class Initialized
INFO - 2016-02-28 10:00:03 --> Model Class Initialized
INFO - 2016-02-28 10:00:03 --> Model Class Initialized
INFO - 2016-02-28 10:00:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:03 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:03 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:03 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 13:00:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:03 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:03 --> Total execution time: 1.1283
INFO - 2016-02-28 10:00:26 --> Config Class Initialized
INFO - 2016-02-28 10:00:26 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:26 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:26 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:26 --> URI Class Initialized
DEBUG - 2016-02-28 10:00:26 --> No URI present. Default controller set.
INFO - 2016-02-28 10:00:26 --> Router Class Initialized
INFO - 2016-02-28 10:00:26 --> Output Class Initialized
INFO - 2016-02-28 10:00:26 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:26 --> Input Class Initialized
INFO - 2016-02-28 10:00:26 --> Language Class Initialized
INFO - 2016-02-28 10:00:26 --> Loader Class Initialized
INFO - 2016-02-28 10:00:26 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:26 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:26 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:26 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:26 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:27 --> Controller Class Initialized
INFO - 2016-02-28 10:00:27 --> Model Class Initialized
INFO - 2016-02-28 10:00:27 --> Model Class Initialized
INFO - 2016-02-28 10:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:27 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:27 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:27 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:27 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:27 --> Total execution time: 1.1978
INFO - 2016-02-28 10:00:28 --> Config Class Initialized
INFO - 2016-02-28 10:00:28 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:28 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:28 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:28 --> URI Class Initialized
INFO - 2016-02-28 10:00:28 --> Router Class Initialized
INFO - 2016-02-28 10:00:28 --> Output Class Initialized
INFO - 2016-02-28 10:00:28 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:28 --> Input Class Initialized
INFO - 2016-02-28 10:00:28 --> Language Class Initialized
INFO - 2016-02-28 10:00:28 --> Loader Class Initialized
INFO - 2016-02-28 10:00:28 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:28 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:28 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:28 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:28 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:29 --> Controller Class Initialized
INFO - 2016-02-28 10:00:29 --> Model Class Initialized
INFO - 2016-02-28 10:00:29 --> Model Class Initialized
INFO - 2016-02-28 10:00:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:29 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:29 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:29 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 13:00:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:30 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:30 --> Total execution time: 1.2000
INFO - 2016-02-28 10:00:34 --> Config Class Initialized
INFO - 2016-02-28 10:00:34 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:34 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:34 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:34 --> URI Class Initialized
DEBUG - 2016-02-28 10:00:34 --> No URI present. Default controller set.
INFO - 2016-02-28 10:00:34 --> Router Class Initialized
INFO - 2016-02-28 10:00:34 --> Output Class Initialized
INFO - 2016-02-28 10:00:34 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:34 --> Input Class Initialized
INFO - 2016-02-28 10:00:34 --> Language Class Initialized
INFO - 2016-02-28 10:00:34 --> Loader Class Initialized
INFO - 2016-02-28 10:00:34 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:34 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:34 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:34 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:34 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:35 --> Controller Class Initialized
INFO - 2016-02-28 10:00:35 --> Model Class Initialized
INFO - 2016-02-28 10:00:35 --> Model Class Initialized
INFO - 2016-02-28 10:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:35 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:35 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:35 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 13:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:35 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:35 --> Total execution time: 1.1641
INFO - 2016-02-28 10:00:35 --> Config Class Initialized
INFO - 2016-02-28 10:00:35 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:35 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:35 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:35 --> URI Class Initialized
INFO - 2016-02-28 10:00:35 --> Router Class Initialized
INFO - 2016-02-28 10:00:35 --> Output Class Initialized
INFO - 2016-02-28 10:00:35 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:35 --> Input Class Initialized
INFO - 2016-02-28 10:00:35 --> Language Class Initialized
INFO - 2016-02-28 10:00:35 --> Loader Class Initialized
INFO - 2016-02-28 10:00:35 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:35 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:35 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:35 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:35 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:36 --> Controller Class Initialized
INFO - 2016-02-28 10:00:36 --> Model Class Initialized
INFO - 2016-02-28 10:00:37 --> Model Class Initialized
INFO - 2016-02-28 10:00:37 --> Form Validation Class Initialized
INFO - 2016-02-28 10:00:37 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:37 --> Config Class Initialized
INFO - 2016-02-28 10:00:37 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:37 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:37 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:37 --> URI Class Initialized
DEBUG - 2016-02-28 10:00:37 --> No URI present. Default controller set.
INFO - 2016-02-28 10:00:37 --> Router Class Initialized
INFO - 2016-02-28 10:00:37 --> Output Class Initialized
INFO - 2016-02-28 10:00:37 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:37 --> Input Class Initialized
INFO - 2016-02-28 10:00:37 --> Language Class Initialized
INFO - 2016-02-28 10:00:37 --> Loader Class Initialized
INFO - 2016-02-28 10:00:37 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:37 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:37 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:37 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:37 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:38 --> Controller Class Initialized
INFO - 2016-02-28 10:00:38 --> Model Class Initialized
INFO - 2016-02-28 10:00:38 --> Model Class Initialized
INFO - 2016-02-28 10:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:38 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:38 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:38 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 13:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:38 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:38 --> Total execution time: 1.1635
INFO - 2016-02-28 10:00:47 --> Config Class Initialized
INFO - 2016-02-28 10:00:47 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:47 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:47 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:47 --> URI Class Initialized
INFO - 2016-02-28 10:00:47 --> Router Class Initialized
INFO - 2016-02-28 10:00:47 --> Output Class Initialized
INFO - 2016-02-28 10:00:47 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:47 --> Input Class Initialized
INFO - 2016-02-28 10:00:47 --> Language Class Initialized
INFO - 2016-02-28 10:00:47 --> Loader Class Initialized
INFO - 2016-02-28 10:00:47 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:47 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:47 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:47 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:47 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:48 --> Controller Class Initialized
INFO - 2016-02-28 10:00:48 --> Model Class Initialized
INFO - 2016-02-28 10:00:48 --> Model Class Initialized
INFO - 2016-02-28 10:00:48 --> Form Validation Class Initialized
INFO - 2016-02-28 10:00:48 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:48 --> Config Class Initialized
INFO - 2016-02-28 10:00:48 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:48 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:48 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:48 --> URI Class Initialized
DEBUG - 2016-02-28 10:00:48 --> No URI present. Default controller set.
INFO - 2016-02-28 10:00:48 --> Router Class Initialized
INFO - 2016-02-28 10:00:48 --> Output Class Initialized
INFO - 2016-02-28 10:00:48 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:48 --> Input Class Initialized
INFO - 2016-02-28 10:00:48 --> Language Class Initialized
INFO - 2016-02-28 10:00:48 --> Loader Class Initialized
INFO - 2016-02-28 10:00:48 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:48 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:48 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:48 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:48 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:49 --> Controller Class Initialized
INFO - 2016-02-28 10:00:49 --> Model Class Initialized
INFO - 2016-02-28 10:00:49 --> Model Class Initialized
INFO - 2016-02-28 10:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:50 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:50 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:50 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-28 13:00:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:50 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:50 --> Total execution time: 1.1418
INFO - 2016-02-28 10:00:53 --> Config Class Initialized
INFO - 2016-02-28 10:00:53 --> Hooks Class Initialized
DEBUG - 2016-02-28 10:00:53 --> UTF-8 Support Enabled
INFO - 2016-02-28 10:00:53 --> Utf8 Class Initialized
INFO - 2016-02-28 10:00:53 --> URI Class Initialized
INFO - 2016-02-28 10:00:53 --> Router Class Initialized
INFO - 2016-02-28 10:00:53 --> Output Class Initialized
INFO - 2016-02-28 10:00:53 --> Security Class Initialized
DEBUG - 2016-02-28 10:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 10:00:53 --> Input Class Initialized
INFO - 2016-02-28 10:00:53 --> Language Class Initialized
INFO - 2016-02-28 10:00:53 --> Loader Class Initialized
INFO - 2016-02-28 10:00:53 --> Helper loaded: url_helper
INFO - 2016-02-28 10:00:53 --> Helper loaded: file_helper
INFO - 2016-02-28 10:00:53 --> Helper loaded: date_helper
INFO - 2016-02-28 10:00:53 --> Helper loaded: form_helper
INFO - 2016-02-28 10:00:53 --> Database Driver Class Initialized
INFO - 2016-02-28 10:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 10:00:54 --> Controller Class Initialized
INFO - 2016-02-28 10:00:54 --> Model Class Initialized
INFO - 2016-02-28 10:00:54 --> Model Class Initialized
INFO - 2016-02-28 10:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 10:00:54 --> Pagination Class Initialized
INFO - 2016-02-28 10:00:54 --> Helper loaded: text_helper
INFO - 2016-02-28 10:00:54 --> Helper loaded: cookie_helper
INFO - 2016-02-28 13:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-28 13:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-28 13:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-28 13:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-28 13:00:54 --> Final output sent to browser
DEBUG - 2016-02-28 13:00:54 --> Total execution time: 1.1373
INFO - 2016-02-28 21:10:22 --> Config Class Initialized
INFO - 2016-02-28 21:10:22 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:10:22 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:10:22 --> Utf8 Class Initialized
INFO - 2016-02-28 21:10:22 --> URI Class Initialized
DEBUG - 2016-02-28 21:10:22 --> No URI present. Default controller set.
INFO - 2016-02-28 21:10:22 --> Router Class Initialized
INFO - 2016-02-28 21:10:22 --> Output Class Initialized
INFO - 2016-02-28 21:10:22 --> Security Class Initialized
DEBUG - 2016-02-28 21:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:10:22 --> Input Class Initialized
INFO - 2016-02-28 21:10:22 --> Language Class Initialized
INFO - 2016-02-28 21:10:22 --> Loader Class Initialized
INFO - 2016-02-28 21:10:22 --> Helper loaded: url_helper
INFO - 2016-02-28 21:10:22 --> Helper loaded: file_helper
INFO - 2016-02-28 21:10:22 --> Helper loaded: date_helper
INFO - 2016-02-28 21:10:22 --> Helper loaded: form_helper
INFO - 2016-02-28 21:10:22 --> Database Driver Class Initialized
INFO - 2016-02-28 21:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:10:23 --> Controller Class Initialized
INFO - 2016-02-28 21:10:23 --> Model Class Initialized
INFO - 2016-02-28 21:10:23 --> Model Class Initialized
INFO - 2016-02-28 21:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:10:23 --> Pagination Class Initialized
INFO - 2016-02-28 21:10:23 --> Helper loaded: text_helper
INFO - 2016-02-28 21:10:23 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:10:28 --> Config Class Initialized
INFO - 2016-02-28 21:10:28 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:10:28 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:10:28 --> Utf8 Class Initialized
INFO - 2016-02-28 21:10:28 --> URI Class Initialized
INFO - 2016-02-28 21:10:28 --> Router Class Initialized
INFO - 2016-02-28 21:10:28 --> Output Class Initialized
INFO - 2016-02-28 21:10:28 --> Security Class Initialized
DEBUG - 2016-02-28 21:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:10:28 --> Input Class Initialized
INFO - 2016-02-28 21:10:28 --> Language Class Initialized
INFO - 2016-02-28 21:10:28 --> Loader Class Initialized
INFO - 2016-02-28 21:10:28 --> Helper loaded: url_helper
INFO - 2016-02-28 21:10:28 --> Helper loaded: file_helper
INFO - 2016-02-28 21:10:28 --> Helper loaded: date_helper
INFO - 2016-02-28 21:10:28 --> Helper loaded: form_helper
INFO - 2016-02-28 21:10:28 --> Database Driver Class Initialized
INFO - 2016-02-28 21:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:10:29 --> Controller Class Initialized
INFO - 2016-02-28 21:10:29 --> Model Class Initialized
INFO - 2016-02-28 21:10:29 --> Model Class Initialized
INFO - 2016-02-28 21:10:29 --> Form Validation Class Initialized
INFO - 2016-02-28 21:10:29 --> Helper loaded: text_helper
INFO - 2016-02-28 21:10:29 --> Final output sent to browser
DEBUG - 2016-02-28 21:10:29 --> Total execution time: 1.3515
INFO - 2016-02-28 21:15:28 --> Config Class Initialized
INFO - 2016-02-28 21:15:28 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:15:28 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:15:28 --> Utf8 Class Initialized
INFO - 2016-02-28 21:15:28 --> URI Class Initialized
INFO - 2016-02-28 21:15:28 --> Router Class Initialized
INFO - 2016-02-28 21:15:28 --> Output Class Initialized
INFO - 2016-02-28 21:15:28 --> Security Class Initialized
DEBUG - 2016-02-28 21:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:15:28 --> Input Class Initialized
INFO - 2016-02-28 21:15:28 --> Language Class Initialized
INFO - 2016-02-28 21:15:28 --> Loader Class Initialized
INFO - 2016-02-28 21:15:28 --> Helper loaded: url_helper
INFO - 2016-02-28 21:15:28 --> Helper loaded: file_helper
INFO - 2016-02-28 21:15:28 --> Helper loaded: date_helper
INFO - 2016-02-28 21:15:28 --> Helper loaded: form_helper
INFO - 2016-02-28 21:15:28 --> Database Driver Class Initialized
INFO - 2016-02-28 21:15:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:15:29 --> Controller Class Initialized
INFO - 2016-02-28 21:15:29 --> Model Class Initialized
INFO - 2016-02-28 21:15:29 --> Model Class Initialized
INFO - 2016-02-28 21:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:15:29 --> Pagination Class Initialized
INFO - 2016-02-28 21:15:29 --> Helper loaded: text_helper
INFO - 2016-02-28 21:15:29 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:20:56 --> Config Class Initialized
INFO - 2016-02-28 21:20:56 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:20:56 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:20:56 --> Utf8 Class Initialized
INFO - 2016-02-28 21:20:56 --> URI Class Initialized
INFO - 2016-02-28 21:20:56 --> Router Class Initialized
INFO - 2016-02-28 21:20:56 --> Output Class Initialized
INFO - 2016-02-28 21:20:56 --> Security Class Initialized
DEBUG - 2016-02-28 21:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:20:56 --> Input Class Initialized
INFO - 2016-02-28 21:20:56 --> Language Class Initialized
INFO - 2016-02-28 21:20:56 --> Loader Class Initialized
INFO - 2016-02-28 21:20:56 --> Helper loaded: url_helper
INFO - 2016-02-28 21:20:56 --> Helper loaded: file_helper
INFO - 2016-02-28 21:20:56 --> Helper loaded: date_helper
INFO - 2016-02-28 21:20:56 --> Helper loaded: form_helper
INFO - 2016-02-28 21:20:56 --> Database Driver Class Initialized
INFO - 2016-02-28 21:20:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:20:57 --> Controller Class Initialized
INFO - 2016-02-28 21:20:57 --> Model Class Initialized
INFO - 2016-02-28 21:20:57 --> Model Class Initialized
INFO - 2016-02-28 21:20:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:20:57 --> Pagination Class Initialized
INFO - 2016-02-28 21:20:57 --> Helper loaded: text_helper
INFO - 2016-02-28 21:20:57 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:21:08 --> Config Class Initialized
INFO - 2016-02-28 21:21:08 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:08 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:08 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:08 --> URI Class Initialized
INFO - 2016-02-28 21:21:08 --> Router Class Initialized
INFO - 2016-02-28 21:21:08 --> Output Class Initialized
INFO - 2016-02-28 21:21:08 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:08 --> Input Class Initialized
INFO - 2016-02-28 21:21:08 --> Language Class Initialized
INFO - 2016-02-28 21:21:08 --> Loader Class Initialized
INFO - 2016-02-28 21:21:08 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:08 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:08 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:08 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:08 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:09 --> Controller Class Initialized
INFO - 2016-02-28 21:21:09 --> Model Class Initialized
INFO - 2016-02-28 21:21:09 --> Model Class Initialized
INFO - 2016-02-28 21:21:09 --> Form Validation Class Initialized
INFO - 2016-02-28 21:21:09 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:09 --> Config Class Initialized
INFO - 2016-02-28 21:21:09 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:09 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:09 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:09 --> URI Class Initialized
INFO - 2016-02-28 21:21:09 --> Router Class Initialized
INFO - 2016-02-28 21:21:09 --> Output Class Initialized
INFO - 2016-02-28 21:21:09 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:09 --> Input Class Initialized
INFO - 2016-02-28 21:21:09 --> Language Class Initialized
INFO - 2016-02-28 21:21:09 --> Loader Class Initialized
INFO - 2016-02-28 21:21:09 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:09 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:09 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:09 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:09 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:10 --> Controller Class Initialized
INFO - 2016-02-28 21:21:10 --> Model Class Initialized
INFO - 2016-02-28 21:21:10 --> Model Class Initialized
INFO - 2016-02-28 21:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:21:10 --> Pagination Class Initialized
INFO - 2016-02-28 21:21:10 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:10 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:21:14 --> Config Class Initialized
INFO - 2016-02-28 21:21:14 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:14 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:14 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:14 --> URI Class Initialized
INFO - 2016-02-28 21:21:14 --> Router Class Initialized
INFO - 2016-02-28 21:21:14 --> Output Class Initialized
INFO - 2016-02-28 21:21:14 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:14 --> Input Class Initialized
INFO - 2016-02-28 21:21:14 --> Language Class Initialized
INFO - 2016-02-28 21:21:14 --> Loader Class Initialized
INFO - 2016-02-28 21:21:14 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:14 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:14 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:14 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:14 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:15 --> Controller Class Initialized
INFO - 2016-02-28 21:21:15 --> Model Class Initialized
INFO - 2016-02-28 21:21:15 --> Model Class Initialized
INFO - 2016-02-28 21:21:15 --> Form Validation Class Initialized
INFO - 2016-02-28 21:21:15 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:15 --> Config Class Initialized
INFO - 2016-02-28 21:21:15 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:15 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:15 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:15 --> URI Class Initialized
INFO - 2016-02-28 21:21:15 --> Router Class Initialized
INFO - 2016-02-28 21:21:15 --> Output Class Initialized
INFO - 2016-02-28 21:21:15 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:15 --> Input Class Initialized
INFO - 2016-02-28 21:21:15 --> Language Class Initialized
INFO - 2016-02-28 21:21:15 --> Loader Class Initialized
INFO - 2016-02-28 21:21:15 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:15 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:15 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:15 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:15 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:16 --> Controller Class Initialized
INFO - 2016-02-28 21:21:16 --> Model Class Initialized
INFO - 2016-02-28 21:21:16 --> Model Class Initialized
INFO - 2016-02-28 21:21:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:21:16 --> Pagination Class Initialized
INFO - 2016-02-28 21:21:16 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:16 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:21:31 --> Config Class Initialized
INFO - 2016-02-28 21:21:31 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:31 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:31 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:31 --> URI Class Initialized
INFO - 2016-02-28 21:21:31 --> Router Class Initialized
INFO - 2016-02-28 21:21:31 --> Output Class Initialized
INFO - 2016-02-28 21:21:31 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:31 --> Input Class Initialized
INFO - 2016-02-28 21:21:31 --> Language Class Initialized
INFO - 2016-02-28 21:21:31 --> Loader Class Initialized
INFO - 2016-02-28 21:21:31 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:31 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:31 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:31 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:31 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:32 --> Controller Class Initialized
INFO - 2016-02-28 21:21:32 --> Model Class Initialized
INFO - 2016-02-28 21:21:32 --> Model Class Initialized
INFO - 2016-02-28 21:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:21:32 --> Pagination Class Initialized
INFO - 2016-02-28 21:21:32 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:32 --> Helper loaded: cookie_helper
INFO - 2016-02-28 21:21:34 --> Config Class Initialized
INFO - 2016-02-28 21:21:34 --> Hooks Class Initialized
DEBUG - 2016-02-28 21:21:34 --> UTF-8 Support Enabled
INFO - 2016-02-28 21:21:34 --> Utf8 Class Initialized
INFO - 2016-02-28 21:21:34 --> URI Class Initialized
INFO - 2016-02-28 21:21:34 --> Router Class Initialized
INFO - 2016-02-28 21:21:34 --> Output Class Initialized
INFO - 2016-02-28 21:21:34 --> Security Class Initialized
DEBUG - 2016-02-28 21:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-28 21:21:34 --> Input Class Initialized
INFO - 2016-02-28 21:21:34 --> Language Class Initialized
INFO - 2016-02-28 21:21:34 --> Loader Class Initialized
INFO - 2016-02-28 21:21:34 --> Helper loaded: url_helper
INFO - 2016-02-28 21:21:34 --> Helper loaded: file_helper
INFO - 2016-02-28 21:21:34 --> Helper loaded: date_helper
INFO - 2016-02-28 21:21:34 --> Helper loaded: form_helper
INFO - 2016-02-28 21:21:34 --> Database Driver Class Initialized
INFO - 2016-02-28 21:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-28 21:21:35 --> Controller Class Initialized
INFO - 2016-02-28 21:21:35 --> Model Class Initialized
INFO - 2016-02-28 21:21:35 --> Model Class Initialized
INFO - 2016-02-28 21:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-28 21:21:35 --> Pagination Class Initialized
INFO - 2016-02-28 21:21:35 --> Helper loaded: text_helper
INFO - 2016-02-28 21:21:35 --> Helper loaded: cookie_helper
