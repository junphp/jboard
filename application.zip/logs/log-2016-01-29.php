<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-29 05:31:16 --> Config Class Initialized
INFO - 2016-01-29 05:31:16 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:31:16 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:31:16 --> Utf8 Class Initialized
INFO - 2016-01-29 05:31:16 --> URI Class Initialized
DEBUG - 2016-01-29 05:31:16 --> No URI present. Default controller set.
INFO - 2016-01-29 05:31:16 --> Router Class Initialized
INFO - 2016-01-29 05:31:16 --> Output Class Initialized
INFO - 2016-01-29 05:31:16 --> Security Class Initialized
DEBUG - 2016-01-29 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:31:16 --> Input Class Initialized
INFO - 2016-01-29 05:31:16 --> Language Class Initialized
INFO - 2016-01-29 05:31:16 --> Loader Class Initialized
INFO - 2016-01-29 05:31:16 --> Helper loaded: url_helper
INFO - 2016-01-29 05:31:16 --> Helper loaded: file_helper
INFO - 2016-01-29 05:31:16 --> Helper loaded: date_helper
INFO - 2016-01-29 05:31:16 --> Database Driver Class Initialized
INFO - 2016-01-29 05:31:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:31:17 --> Controller Class Initialized
INFO - 2016-01-29 05:31:17 --> Model Class Initialized
INFO - 2016-01-29 05:31:17 --> Model Class Initialized
INFO - 2016-01-29 05:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:31:17 --> Pagination Class Initialized
INFO - 2016-01-29 05:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:31:17 --> Final output sent to browser
DEBUG - 2016-01-29 05:31:17 --> Total execution time: 1.1467
INFO - 2016-01-29 05:31:32 --> Config Class Initialized
INFO - 2016-01-29 05:31:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:31:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:31:32 --> Utf8 Class Initialized
INFO - 2016-01-29 05:31:32 --> URI Class Initialized
INFO - 2016-01-29 05:31:32 --> Router Class Initialized
INFO - 2016-01-29 05:31:32 --> Output Class Initialized
INFO - 2016-01-29 05:31:32 --> Security Class Initialized
DEBUG - 2016-01-29 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:31:32 --> Input Class Initialized
INFO - 2016-01-29 05:31:32 --> Language Class Initialized
INFO - 2016-01-29 05:31:32 --> Loader Class Initialized
INFO - 2016-01-29 05:31:32 --> Helper loaded: url_helper
INFO - 2016-01-29 05:31:32 --> Helper loaded: file_helper
INFO - 2016-01-29 05:31:32 --> Helper loaded: date_helper
INFO - 2016-01-29 05:31:32 --> Database Driver Class Initialized
INFO - 2016-01-29 05:31:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:31:33 --> Controller Class Initialized
INFO - 2016-01-29 05:31:33 --> Model Class Initialized
INFO - 2016-01-29 05:31:33 --> Model Class Initialized
INFO - 2016-01-29 05:31:33 --> Helper loaded: form_helper
INFO - 2016-01-29 05:31:33 --> Form Validation Class Initialized
INFO - 2016-01-29 05:31:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:31:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
ERROR - 2016-01-29 05:31:33 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 7
ERROR - 2016-01-29 05:31:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 7
INFO - 2016-01-29 05:31:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:31:33 --> Final output sent to browser
DEBUG - 2016-01-29 05:31:33 --> Total execution time: 1.1407
INFO - 2016-01-29 05:31:36 --> Config Class Initialized
INFO - 2016-01-29 05:31:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:31:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:31:36 --> Utf8 Class Initialized
INFO - 2016-01-29 05:31:36 --> URI Class Initialized
DEBUG - 2016-01-29 05:31:36 --> No URI present. Default controller set.
INFO - 2016-01-29 05:31:36 --> Router Class Initialized
INFO - 2016-01-29 05:31:36 --> Output Class Initialized
INFO - 2016-01-29 05:31:36 --> Security Class Initialized
DEBUG - 2016-01-29 05:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:31:36 --> Input Class Initialized
INFO - 2016-01-29 05:31:36 --> Language Class Initialized
INFO - 2016-01-29 05:31:36 --> Loader Class Initialized
INFO - 2016-01-29 05:31:36 --> Helper loaded: url_helper
INFO - 2016-01-29 05:31:36 --> Helper loaded: file_helper
INFO - 2016-01-29 05:31:36 --> Helper loaded: date_helper
INFO - 2016-01-29 05:31:36 --> Database Driver Class Initialized
INFO - 2016-01-29 05:31:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:31:37 --> Controller Class Initialized
INFO - 2016-01-29 05:31:37 --> Model Class Initialized
INFO - 2016-01-29 05:31:37 --> Model Class Initialized
INFO - 2016-01-29 05:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:31:37 --> Pagination Class Initialized
INFO - 2016-01-29 05:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:31:37 --> Final output sent to browser
DEBUG - 2016-01-29 05:31:37 --> Total execution time: 1.1247
INFO - 2016-01-29 05:31:43 --> Config Class Initialized
INFO - 2016-01-29 05:31:43 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:31:43 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:31:43 --> Utf8 Class Initialized
INFO - 2016-01-29 05:31:43 --> URI Class Initialized
INFO - 2016-01-29 05:31:43 --> Router Class Initialized
INFO - 2016-01-29 05:31:43 --> Output Class Initialized
INFO - 2016-01-29 05:31:43 --> Security Class Initialized
DEBUG - 2016-01-29 05:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:31:43 --> Input Class Initialized
INFO - 2016-01-29 05:31:43 --> Language Class Initialized
INFO - 2016-01-29 05:31:43 --> Loader Class Initialized
INFO - 2016-01-29 05:31:43 --> Helper loaded: url_helper
INFO - 2016-01-29 05:31:43 --> Helper loaded: file_helper
INFO - 2016-01-29 05:31:43 --> Helper loaded: date_helper
INFO - 2016-01-29 05:31:43 --> Database Driver Class Initialized
INFO - 2016-01-29 05:31:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:31:44 --> Controller Class Initialized
INFO - 2016-01-29 05:31:44 --> Model Class Initialized
INFO - 2016-01-29 05:31:44 --> Model Class Initialized
INFO - 2016-01-29 05:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:31:44 --> Pagination Class Initialized
INFO - 2016-01-29 05:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:31:44 --> Helper loaded: text_helper
INFO - 2016-01-29 05:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 05:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:31:44 --> Final output sent to browser
DEBUG - 2016-01-29 05:31:44 --> Total execution time: 1.1952
INFO - 2016-01-29 05:34:10 --> Config Class Initialized
INFO - 2016-01-29 05:34:10 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:34:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:34:10 --> Utf8 Class Initialized
INFO - 2016-01-29 05:34:10 --> URI Class Initialized
INFO - 2016-01-29 05:34:10 --> Router Class Initialized
INFO - 2016-01-29 05:34:10 --> Output Class Initialized
INFO - 2016-01-29 05:34:10 --> Security Class Initialized
DEBUG - 2016-01-29 05:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:34:10 --> Input Class Initialized
INFO - 2016-01-29 05:34:10 --> Language Class Initialized
INFO - 2016-01-29 05:34:10 --> Loader Class Initialized
INFO - 2016-01-29 05:34:10 --> Helper loaded: url_helper
INFO - 2016-01-29 05:34:10 --> Helper loaded: file_helper
INFO - 2016-01-29 05:34:10 --> Helper loaded: date_helper
INFO - 2016-01-29 05:34:10 --> Database Driver Class Initialized
INFO - 2016-01-29 05:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:34:11 --> Controller Class Initialized
INFO - 2016-01-29 05:34:11 --> Model Class Initialized
INFO - 2016-01-29 05:34:11 --> Model Class Initialized
INFO - 2016-01-29 05:34:11 --> Helper loaded: form_helper
INFO - 2016-01-29 05:34:11 --> Form Validation Class Initialized
INFO - 2016-01-29 05:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
ERROR - 2016-01-29 05:34:11 --> Severity: Notice --> Undefined property: Auth::$Jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 35
ERROR - 2016-01-29 05:34:11 --> Severity: Error --> Call to a member function get_latest() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 35
INFO - 2016-01-29 05:36:29 --> Config Class Initialized
INFO - 2016-01-29 05:36:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:36:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:36:29 --> Utf8 Class Initialized
INFO - 2016-01-29 05:36:29 --> URI Class Initialized
INFO - 2016-01-29 05:36:29 --> Router Class Initialized
INFO - 2016-01-29 05:36:29 --> Output Class Initialized
INFO - 2016-01-29 05:36:29 --> Security Class Initialized
DEBUG - 2016-01-29 05:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:36:29 --> Input Class Initialized
INFO - 2016-01-29 05:36:29 --> Language Class Initialized
INFO - 2016-01-29 05:36:29 --> Loader Class Initialized
INFO - 2016-01-29 05:36:29 --> Helper loaded: url_helper
INFO - 2016-01-29 05:36:29 --> Helper loaded: file_helper
INFO - 2016-01-29 05:36:29 --> Helper loaded: date_helper
INFO - 2016-01-29 05:36:29 --> Database Driver Class Initialized
INFO - 2016-01-29 05:36:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:36:30 --> Controller Class Initialized
INFO - 2016-01-29 05:36:30 --> Model Class Initialized
INFO - 2016-01-29 05:36:30 --> Model Class Initialized
INFO - 2016-01-29 05:36:30 --> Helper loaded: form_helper
INFO - 2016-01-29 05:36:30 --> Form Validation Class Initialized
INFO - 2016-01-29 05:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
ERROR - 2016-01-29 05:36:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Jboard C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Loader.php 314
INFO - 2016-01-29 05:36:57 --> Config Class Initialized
INFO - 2016-01-29 05:36:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:36:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:36:57 --> Utf8 Class Initialized
INFO - 2016-01-29 05:36:57 --> URI Class Initialized
INFO - 2016-01-29 05:36:57 --> Router Class Initialized
INFO - 2016-01-29 05:36:57 --> Output Class Initialized
INFO - 2016-01-29 05:36:57 --> Security Class Initialized
DEBUG - 2016-01-29 05:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:36:57 --> Input Class Initialized
INFO - 2016-01-29 05:36:57 --> Language Class Initialized
INFO - 2016-01-29 05:36:57 --> Loader Class Initialized
INFO - 2016-01-29 05:36:57 --> Helper loaded: url_helper
INFO - 2016-01-29 05:36:57 --> Helper loaded: file_helper
INFO - 2016-01-29 05:36:57 --> Helper loaded: date_helper
INFO - 2016-01-29 05:36:57 --> Database Driver Class Initialized
INFO - 2016-01-29 05:36:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:36:58 --> Controller Class Initialized
INFO - 2016-01-29 05:36:58 --> Model Class Initialized
INFO - 2016-01-29 05:36:58 --> Model Class Initialized
INFO - 2016-01-29 05:36:58 --> Helper loaded: form_helper
INFO - 2016-01-29 05:36:58 --> Form Validation Class Initialized
INFO - 2016-01-29 05:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:36:58 --> Model Class Initialized
INFO - 2016-01-29 05:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:36:58 --> Final output sent to browser
DEBUG - 2016-01-29 05:36:58 --> Total execution time: 1.1501
INFO - 2016-01-29 05:38:01 --> Config Class Initialized
INFO - 2016-01-29 05:38:01 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:38:01 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:38:01 --> Utf8 Class Initialized
INFO - 2016-01-29 05:38:01 --> URI Class Initialized
INFO - 2016-01-29 05:38:01 --> Router Class Initialized
INFO - 2016-01-29 05:38:01 --> Output Class Initialized
INFO - 2016-01-29 05:38:01 --> Security Class Initialized
DEBUG - 2016-01-29 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:38:01 --> Input Class Initialized
INFO - 2016-01-29 05:38:01 --> Language Class Initialized
INFO - 2016-01-29 05:38:01 --> Loader Class Initialized
INFO - 2016-01-29 05:38:01 --> Helper loaded: url_helper
INFO - 2016-01-29 05:38:01 --> Helper loaded: file_helper
INFO - 2016-01-29 05:38:01 --> Helper loaded: date_helper
INFO - 2016-01-29 05:38:01 --> Database Driver Class Initialized
INFO - 2016-01-29 05:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:38:02 --> Controller Class Initialized
INFO - 2016-01-29 05:38:02 --> Model Class Initialized
INFO - 2016-01-29 05:38:02 --> Model Class Initialized
INFO - 2016-01-29 05:38:02 --> Helper loaded: form_helper
INFO - 2016-01-29 05:38:02 --> Form Validation Class Initialized
INFO - 2016-01-29 05:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:38:02 --> Model Class Initialized
INFO - 2016-01-29 05:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:38:02 --> Final output sent to browser
DEBUG - 2016-01-29 05:38:02 --> Total execution time: 1.1578
INFO - 2016-01-29 05:40:44 --> Config Class Initialized
INFO - 2016-01-29 05:40:44 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:40:44 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:40:44 --> Utf8 Class Initialized
INFO - 2016-01-29 05:40:44 --> URI Class Initialized
INFO - 2016-01-29 05:40:44 --> Router Class Initialized
INFO - 2016-01-29 05:40:44 --> Output Class Initialized
INFO - 2016-01-29 05:40:44 --> Security Class Initialized
DEBUG - 2016-01-29 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:40:44 --> Input Class Initialized
INFO - 2016-01-29 05:40:44 --> Language Class Initialized
INFO - 2016-01-29 05:40:44 --> Loader Class Initialized
INFO - 2016-01-29 05:40:44 --> Helper loaded: url_helper
INFO - 2016-01-29 05:40:44 --> Helper loaded: file_helper
INFO - 2016-01-29 05:40:44 --> Helper loaded: date_helper
INFO - 2016-01-29 05:40:44 --> Database Driver Class Initialized
INFO - 2016-01-29 05:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:40:45 --> Controller Class Initialized
INFO - 2016-01-29 05:40:45 --> Model Class Initialized
INFO - 2016-01-29 05:40:45 --> Model Class Initialized
INFO - 2016-01-29 05:40:45 --> Helper loaded: form_helper
INFO - 2016-01-29 05:40:45 --> Form Validation Class Initialized
INFO - 2016-01-29 05:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:40:45 --> Model Class Initialized
INFO - 2016-01-29 05:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:40:45 --> Final output sent to browser
DEBUG - 2016-01-29 05:40:45 --> Total execution time: 1.2209
INFO - 2016-01-29 05:41:50 --> Config Class Initialized
INFO - 2016-01-29 05:41:50 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:41:50 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:41:50 --> Utf8 Class Initialized
INFO - 2016-01-29 05:41:50 --> URI Class Initialized
INFO - 2016-01-29 05:41:50 --> Router Class Initialized
INFO - 2016-01-29 05:41:50 --> Output Class Initialized
INFO - 2016-01-29 05:41:50 --> Security Class Initialized
DEBUG - 2016-01-29 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:41:50 --> Input Class Initialized
INFO - 2016-01-29 05:41:50 --> Language Class Initialized
INFO - 2016-01-29 05:41:50 --> Loader Class Initialized
INFO - 2016-01-29 05:41:50 --> Helper loaded: url_helper
INFO - 2016-01-29 05:41:50 --> Helper loaded: file_helper
INFO - 2016-01-29 05:41:50 --> Helper loaded: date_helper
INFO - 2016-01-29 05:41:50 --> Database Driver Class Initialized
INFO - 2016-01-29 05:41:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:41:51 --> Controller Class Initialized
INFO - 2016-01-29 05:41:51 --> Model Class Initialized
INFO - 2016-01-29 05:41:51 --> Model Class Initialized
INFO - 2016-01-29 05:41:51 --> Helper loaded: form_helper
INFO - 2016-01-29 05:41:51 --> Form Validation Class Initialized
INFO - 2016-01-29 05:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:41:51 --> Model Class Initialized
INFO - 2016-01-29 05:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:41:51 --> Final output sent to browser
DEBUG - 2016-01-29 05:41:51 --> Total execution time: 1.1325
INFO - 2016-01-29 05:45:48 --> Config Class Initialized
INFO - 2016-01-29 05:45:48 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:45:48 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:45:48 --> Utf8 Class Initialized
INFO - 2016-01-29 05:45:48 --> URI Class Initialized
INFO - 2016-01-29 05:45:48 --> Router Class Initialized
INFO - 2016-01-29 05:45:48 --> Output Class Initialized
INFO - 2016-01-29 05:45:48 --> Security Class Initialized
DEBUG - 2016-01-29 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:45:48 --> Input Class Initialized
INFO - 2016-01-29 05:45:48 --> Language Class Initialized
INFO - 2016-01-29 05:45:48 --> Loader Class Initialized
INFO - 2016-01-29 05:45:48 --> Helper loaded: url_helper
INFO - 2016-01-29 05:45:48 --> Helper loaded: file_helper
INFO - 2016-01-29 05:45:48 --> Helper loaded: date_helper
INFO - 2016-01-29 05:45:48 --> Database Driver Class Initialized
INFO - 2016-01-29 05:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:45:49 --> Controller Class Initialized
INFO - 2016-01-29 05:45:49 --> Model Class Initialized
INFO - 2016-01-29 05:45:49 --> Model Class Initialized
INFO - 2016-01-29 05:45:49 --> Helper loaded: form_helper
INFO - 2016-01-29 05:45:49 --> Form Validation Class Initialized
INFO - 2016-01-29 05:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:45:49 --> Model Class Initialized
INFO - 2016-01-29 05:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:45:49 --> Final output sent to browser
DEBUG - 2016-01-29 05:45:49 --> Total execution time: 1.1629
INFO - 2016-01-29 05:47:31 --> Config Class Initialized
INFO - 2016-01-29 05:47:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:31 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:31 --> URI Class Initialized
DEBUG - 2016-01-29 05:47:31 --> No URI present. Default controller set.
INFO - 2016-01-29 05:47:31 --> Router Class Initialized
INFO - 2016-01-29 05:47:31 --> Output Class Initialized
INFO - 2016-01-29 05:47:31 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:31 --> Input Class Initialized
INFO - 2016-01-29 05:47:31 --> Language Class Initialized
INFO - 2016-01-29 05:47:31 --> Loader Class Initialized
INFO - 2016-01-29 05:47:31 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:31 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:31 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:31 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:32 --> Controller Class Initialized
INFO - 2016-01-29 05:47:32 --> Model Class Initialized
INFO - 2016-01-29 05:47:32 --> Model Class Initialized
INFO - 2016-01-29 05:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:47:32 --> Pagination Class Initialized
INFO - 2016-01-29 05:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:47:32 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:32 --> Total execution time: 1.0935
INFO - 2016-01-29 05:47:34 --> Config Class Initialized
INFO - 2016-01-29 05:47:34 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:34 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:34 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:34 --> URI Class Initialized
INFO - 2016-01-29 05:47:34 --> Router Class Initialized
INFO - 2016-01-29 05:47:34 --> Output Class Initialized
INFO - 2016-01-29 05:47:34 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:34 --> Input Class Initialized
INFO - 2016-01-29 05:47:34 --> Language Class Initialized
INFO - 2016-01-29 05:47:34 --> Loader Class Initialized
INFO - 2016-01-29 05:47:34 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:34 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:34 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:34 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:35 --> Controller Class Initialized
INFO - 2016-01-29 05:47:35 --> Model Class Initialized
INFO - 2016-01-29 05:47:35 --> Model Class Initialized
INFO - 2016-01-29 05:47:35 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:35 --> Form Validation Class Initialized
INFO - 2016-01-29 05:47:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:47:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 05:47:35 --> Model Class Initialized
INFO - 2016-01-29 05:47:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:47:35 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:35 --> Total execution time: 1.0999
INFO - 2016-01-29 05:47:36 --> Config Class Initialized
INFO - 2016-01-29 05:47:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:36 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:36 --> URI Class Initialized
DEBUG - 2016-01-29 05:47:36 --> No URI present. Default controller set.
INFO - 2016-01-29 05:47:36 --> Router Class Initialized
INFO - 2016-01-29 05:47:36 --> Output Class Initialized
INFO - 2016-01-29 05:47:36 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:36 --> Input Class Initialized
INFO - 2016-01-29 05:47:36 --> Language Class Initialized
INFO - 2016-01-29 05:47:36 --> Loader Class Initialized
INFO - 2016-01-29 05:47:36 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:36 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:36 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:36 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:38 --> Controller Class Initialized
INFO - 2016-01-29 05:47:38 --> Model Class Initialized
INFO - 2016-01-29 05:47:38 --> Model Class Initialized
INFO - 2016-01-29 05:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:47:38 --> Pagination Class Initialized
INFO - 2016-01-29 05:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:47:38 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:38 --> Total execution time: 1.0830
INFO - 2016-01-29 05:47:40 --> Config Class Initialized
INFO - 2016-01-29 05:47:40 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:40 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:40 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:40 --> URI Class Initialized
INFO - 2016-01-29 05:47:40 --> Router Class Initialized
INFO - 2016-01-29 05:47:40 --> Output Class Initialized
INFO - 2016-01-29 05:47:40 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:40 --> Input Class Initialized
INFO - 2016-01-29 05:47:40 --> Language Class Initialized
INFO - 2016-01-29 05:47:40 --> Loader Class Initialized
INFO - 2016-01-29 05:47:40 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:40 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:40 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:40 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:41 --> Controller Class Initialized
INFO - 2016-01-29 05:47:41 --> Model Class Initialized
INFO - 2016-01-29 05:47:41 --> Model Class Initialized
INFO - 2016-01-29 05:47:41 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:41 --> Form Validation Class Initialized
INFO - 2016-01-29 05:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 05:47:41 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:41 --> Total execution time: 1.1028
INFO - 2016-01-29 05:47:46 --> Config Class Initialized
INFO - 2016-01-29 05:47:46 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:46 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:46 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:46 --> URI Class Initialized
INFO - 2016-01-29 05:47:46 --> Router Class Initialized
INFO - 2016-01-29 05:47:46 --> Output Class Initialized
INFO - 2016-01-29 05:47:46 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:46 --> Input Class Initialized
INFO - 2016-01-29 05:47:46 --> Language Class Initialized
INFO - 2016-01-29 05:47:46 --> Loader Class Initialized
INFO - 2016-01-29 05:47:46 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:46 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:46 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:46 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:47 --> Controller Class Initialized
INFO - 2016-01-29 05:47:47 --> Model Class Initialized
INFO - 2016-01-29 05:47:47 --> Model Class Initialized
INFO - 2016-01-29 05:47:47 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:47 --> Form Validation Class Initialized
INFO - 2016-01-29 05:47:47 --> Config Class Initialized
INFO - 2016-01-29 05:47:47 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:47 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:47 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:47 --> URI Class Initialized
INFO - 2016-01-29 05:47:47 --> Router Class Initialized
INFO - 2016-01-29 05:47:47 --> Output Class Initialized
INFO - 2016-01-29 05:47:47 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:47 --> Input Class Initialized
INFO - 2016-01-29 05:47:47 --> Language Class Initialized
INFO - 2016-01-29 05:47:47 --> Loader Class Initialized
INFO - 2016-01-29 05:47:47 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:47 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:47 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:47 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:48 --> Controller Class Initialized
INFO - 2016-01-29 05:47:48 --> Model Class Initialized
INFO - 2016-01-29 05:47:48 --> Model Class Initialized
INFO - 2016-01-29 05:47:48 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:48 --> Form Validation Class Initialized
INFO - 2016-01-29 05:47:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-29 05:47:48 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:48 --> Total execution time: 1.1249
INFO - 2016-01-29 05:47:54 --> Config Class Initialized
INFO - 2016-01-29 05:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:54 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:54 --> URI Class Initialized
INFO - 2016-01-29 05:47:54 --> Router Class Initialized
INFO - 2016-01-29 05:47:54 --> Output Class Initialized
INFO - 2016-01-29 05:47:54 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:54 --> Input Class Initialized
INFO - 2016-01-29 05:47:54 --> Language Class Initialized
INFO - 2016-01-29 05:47:54 --> Loader Class Initialized
INFO - 2016-01-29 05:47:54 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:54 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:54 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:54 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:55 --> Controller Class Initialized
INFO - 2016-01-29 05:47:55 --> Model Class Initialized
INFO - 2016-01-29 05:47:55 --> Model Class Initialized
INFO - 2016-01-29 05:47:55 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:55 --> Form Validation Class Initialized
ERROR - 2016-01-29 05:47:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 84
ERROR - 2016-01-29 05:47:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 84
INFO - 2016-01-29 05:47:55 --> Config Class Initialized
INFO - 2016-01-29 05:47:55 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:47:55 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:47:55 --> Utf8 Class Initialized
INFO - 2016-01-29 05:47:55 --> URI Class Initialized
INFO - 2016-01-29 05:47:55 --> Router Class Initialized
INFO - 2016-01-29 05:47:55 --> Output Class Initialized
INFO - 2016-01-29 05:47:55 --> Security Class Initialized
DEBUG - 2016-01-29 05:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:47:55 --> Input Class Initialized
INFO - 2016-01-29 05:47:55 --> Language Class Initialized
INFO - 2016-01-29 05:47:55 --> Loader Class Initialized
INFO - 2016-01-29 05:47:55 --> Helper loaded: url_helper
INFO - 2016-01-29 05:47:55 --> Helper loaded: file_helper
INFO - 2016-01-29 05:47:55 --> Helper loaded: date_helper
INFO - 2016-01-29 05:47:56 --> Database Driver Class Initialized
INFO - 2016-01-29 05:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:47:57 --> Controller Class Initialized
INFO - 2016-01-29 05:47:57 --> Model Class Initialized
INFO - 2016-01-29 05:47:57 --> Model Class Initialized
INFO - 2016-01-29 05:47:57 --> Helper loaded: form_helper
INFO - 2016-01-29 05:47:57 --> Form Validation Class Initialized
INFO - 2016-01-29 05:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-29 05:47:57 --> Final output sent to browser
DEBUG - 2016-01-29 05:47:57 --> Total execution time: 1.1292
INFO - 2016-01-29 05:51:35 --> Config Class Initialized
INFO - 2016-01-29 05:51:35 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:35 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:35 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:35 --> URI Class Initialized
INFO - 2016-01-29 05:51:35 --> Router Class Initialized
INFO - 2016-01-29 05:51:35 --> Output Class Initialized
INFO - 2016-01-29 05:51:36 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:36 --> Input Class Initialized
INFO - 2016-01-29 05:51:36 --> Language Class Initialized
INFO - 2016-01-29 05:51:36 --> Loader Class Initialized
INFO - 2016-01-29 05:51:36 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:36 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:36 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:36 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:37 --> Controller Class Initialized
INFO - 2016-01-29 05:51:37 --> Model Class Initialized
INFO - 2016-01-29 05:51:37 --> Model Class Initialized
INFO - 2016-01-29 05:51:37 --> Helper loaded: form_helper
INFO - 2016-01-29 05:51:37 --> Form Validation Class Initialized
ERROR - 2016-01-29 05:51:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 84
ERROR - 2016-01-29 05:51:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 84
INFO - 2016-01-29 05:51:37 --> Config Class Initialized
INFO - 2016-01-29 05:51:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:37 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:37 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:37 --> URI Class Initialized
INFO - 2016-01-29 05:51:37 --> Router Class Initialized
INFO - 2016-01-29 05:51:37 --> Output Class Initialized
INFO - 2016-01-29 05:51:37 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:37 --> Input Class Initialized
INFO - 2016-01-29 05:51:37 --> Language Class Initialized
INFO - 2016-01-29 05:51:37 --> Loader Class Initialized
INFO - 2016-01-29 05:51:37 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:37 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:37 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:37 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:38 --> Controller Class Initialized
INFO - 2016-01-29 05:51:38 --> Model Class Initialized
INFO - 2016-01-29 05:51:38 --> Model Class Initialized
INFO - 2016-01-29 05:51:38 --> Helper loaded: form_helper
INFO - 2016-01-29 05:51:38 --> Form Validation Class Initialized
INFO - 2016-01-29 05:51:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-29 05:51:38 --> Final output sent to browser
DEBUG - 2016-01-29 05:51:38 --> Total execution time: 1.1422
INFO - 2016-01-29 05:51:45 --> Config Class Initialized
INFO - 2016-01-29 05:51:45 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:45 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:45 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:45 --> URI Class Initialized
DEBUG - 2016-01-29 05:51:45 --> No URI present. Default controller set.
INFO - 2016-01-29 05:51:45 --> Router Class Initialized
INFO - 2016-01-29 05:51:45 --> Output Class Initialized
INFO - 2016-01-29 05:51:45 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:45 --> Input Class Initialized
INFO - 2016-01-29 05:51:45 --> Language Class Initialized
INFO - 2016-01-29 05:51:45 --> Loader Class Initialized
INFO - 2016-01-29 05:51:45 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:45 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:45 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:45 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:46 --> Controller Class Initialized
INFO - 2016-01-29 05:51:46 --> Model Class Initialized
INFO - 2016-01-29 05:51:46 --> Model Class Initialized
INFO - 2016-01-29 05:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:51:46 --> Pagination Class Initialized
INFO - 2016-01-29 05:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:51:46 --> Final output sent to browser
DEBUG - 2016-01-29 05:51:46 --> Total execution time: 1.1049
INFO - 2016-01-29 05:51:50 --> Config Class Initialized
INFO - 2016-01-29 05:51:50 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:50 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:50 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:50 --> URI Class Initialized
INFO - 2016-01-29 05:51:50 --> Router Class Initialized
INFO - 2016-01-29 05:51:50 --> Output Class Initialized
INFO - 2016-01-29 05:51:50 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:50 --> Input Class Initialized
INFO - 2016-01-29 05:51:50 --> Language Class Initialized
INFO - 2016-01-29 05:51:50 --> Loader Class Initialized
INFO - 2016-01-29 05:51:50 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:50 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:50 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:50 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:51 --> Controller Class Initialized
INFO - 2016-01-29 05:51:51 --> Model Class Initialized
INFO - 2016-01-29 05:51:51 --> Model Class Initialized
INFO - 2016-01-29 05:51:51 --> Helper loaded: form_helper
INFO - 2016-01-29 05:51:51 --> Form Validation Class Initialized
INFO - 2016-01-29 05:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 05:51:51 --> Final output sent to browser
DEBUG - 2016-01-29 05:51:51 --> Total execution time: 1.1270
INFO - 2016-01-29 05:51:56 --> Config Class Initialized
INFO - 2016-01-29 05:51:56 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:56 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:56 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:56 --> URI Class Initialized
INFO - 2016-01-29 05:51:56 --> Router Class Initialized
INFO - 2016-01-29 05:51:56 --> Output Class Initialized
INFO - 2016-01-29 05:51:56 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:56 --> Input Class Initialized
INFO - 2016-01-29 05:51:56 --> Language Class Initialized
INFO - 2016-01-29 05:51:56 --> Loader Class Initialized
INFO - 2016-01-29 05:51:56 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:56 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:56 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:56 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:57 --> Controller Class Initialized
INFO - 2016-01-29 05:51:57 --> Model Class Initialized
INFO - 2016-01-29 05:51:57 --> Model Class Initialized
INFO - 2016-01-29 05:51:57 --> Helper loaded: form_helper
INFO - 2016-01-29 05:51:57 --> Form Validation Class Initialized
INFO - 2016-01-29 05:51:57 --> Config Class Initialized
INFO - 2016-01-29 05:51:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:51:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:51:57 --> Utf8 Class Initialized
INFO - 2016-01-29 05:51:57 --> URI Class Initialized
INFO - 2016-01-29 05:51:57 --> Router Class Initialized
INFO - 2016-01-29 05:51:57 --> Output Class Initialized
INFO - 2016-01-29 05:51:57 --> Security Class Initialized
DEBUG - 2016-01-29 05:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:51:57 --> Input Class Initialized
INFO - 2016-01-29 05:51:57 --> Language Class Initialized
INFO - 2016-01-29 05:51:57 --> Loader Class Initialized
INFO - 2016-01-29 05:51:57 --> Helper loaded: url_helper
INFO - 2016-01-29 05:51:57 --> Helper loaded: file_helper
INFO - 2016-01-29 05:51:57 --> Helper loaded: date_helper
INFO - 2016-01-29 05:51:57 --> Database Driver Class Initialized
INFO - 2016-01-29 05:51:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:51:58 --> Controller Class Initialized
INFO - 2016-01-29 05:51:58 --> Model Class Initialized
INFO - 2016-01-29 05:51:58 --> Model Class Initialized
INFO - 2016-01-29 05:51:58 --> Helper loaded: form_helper
INFO - 2016-01-29 05:51:58 --> Form Validation Class Initialized
INFO - 2016-01-29 05:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-29 05:51:58 --> Final output sent to browser
DEBUG - 2016-01-29 05:51:58 --> Total execution time: 1.1191
INFO - 2016-01-29 05:54:31 --> Config Class Initialized
INFO - 2016-01-29 05:54:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:54:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:54:31 --> Utf8 Class Initialized
INFO - 2016-01-29 05:54:31 --> URI Class Initialized
DEBUG - 2016-01-29 05:54:31 --> No URI present. Default controller set.
INFO - 2016-01-29 05:54:31 --> Router Class Initialized
INFO - 2016-01-29 05:54:31 --> Output Class Initialized
INFO - 2016-01-29 05:54:31 --> Security Class Initialized
DEBUG - 2016-01-29 05:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:54:31 --> Input Class Initialized
INFO - 2016-01-29 05:54:31 --> Language Class Initialized
INFO - 2016-01-29 05:54:31 --> Loader Class Initialized
INFO - 2016-01-29 05:54:31 --> Helper loaded: url_helper
INFO - 2016-01-29 05:54:31 --> Helper loaded: file_helper
INFO - 2016-01-29 05:54:31 --> Helper loaded: date_helper
INFO - 2016-01-29 05:54:31 --> Database Driver Class Initialized
INFO - 2016-01-29 05:54:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:54:32 --> Controller Class Initialized
INFO - 2016-01-29 05:54:32 --> Model Class Initialized
INFO - 2016-01-29 05:54:32 --> Model Class Initialized
INFO - 2016-01-29 05:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:54:32 --> Pagination Class Initialized
INFO - 2016-01-29 05:54:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:54:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:54:32 --> Final output sent to browser
DEBUG - 2016-01-29 05:54:32 --> Total execution time: 1.1432
INFO - 2016-01-29 05:54:34 --> Config Class Initialized
INFO - 2016-01-29 05:54:34 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:54:34 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:54:34 --> Utf8 Class Initialized
INFO - 2016-01-29 05:54:34 --> URI Class Initialized
INFO - 2016-01-29 05:54:34 --> Router Class Initialized
INFO - 2016-01-29 05:54:34 --> Output Class Initialized
INFO - 2016-01-29 05:54:34 --> Security Class Initialized
DEBUG - 2016-01-29 05:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:54:34 --> Input Class Initialized
INFO - 2016-01-29 05:54:34 --> Language Class Initialized
INFO - 2016-01-29 05:54:34 --> Loader Class Initialized
INFO - 2016-01-29 05:54:34 --> Helper loaded: url_helper
INFO - 2016-01-29 05:54:34 --> Helper loaded: file_helper
INFO - 2016-01-29 05:54:34 --> Helper loaded: date_helper
INFO - 2016-01-29 05:54:34 --> Database Driver Class Initialized
INFO - 2016-01-29 05:54:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:54:35 --> Controller Class Initialized
INFO - 2016-01-29 05:54:35 --> Model Class Initialized
INFO - 2016-01-29 05:54:35 --> Model Class Initialized
INFO - 2016-01-29 05:54:35 --> Helper loaded: form_helper
INFO - 2016-01-29 05:54:35 --> Form Validation Class Initialized
INFO - 2016-01-29 05:54:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:54:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 05:54:35 --> Final output sent to browser
DEBUG - 2016-01-29 05:54:35 --> Total execution time: 1.1172
INFO - 2016-01-29 05:54:38 --> Config Class Initialized
INFO - 2016-01-29 05:54:38 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:54:38 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:54:38 --> Utf8 Class Initialized
INFO - 2016-01-29 05:54:38 --> URI Class Initialized
DEBUG - 2016-01-29 05:54:38 --> No URI present. Default controller set.
INFO - 2016-01-29 05:54:38 --> Router Class Initialized
INFO - 2016-01-29 05:54:38 --> Output Class Initialized
INFO - 2016-01-29 05:54:38 --> Security Class Initialized
DEBUG - 2016-01-29 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:54:38 --> Input Class Initialized
INFO - 2016-01-29 05:54:38 --> Language Class Initialized
INFO - 2016-01-29 05:54:38 --> Loader Class Initialized
INFO - 2016-01-29 05:54:38 --> Helper loaded: url_helper
INFO - 2016-01-29 05:54:38 --> Helper loaded: file_helper
INFO - 2016-01-29 05:54:38 --> Helper loaded: date_helper
INFO - 2016-01-29 05:54:38 --> Database Driver Class Initialized
INFO - 2016-01-29 05:54:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:54:39 --> Controller Class Initialized
INFO - 2016-01-29 05:54:39 --> Model Class Initialized
INFO - 2016-01-29 05:54:39 --> Model Class Initialized
INFO - 2016-01-29 05:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:54:39 --> Pagination Class Initialized
INFO - 2016-01-29 05:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:54:39 --> Final output sent to browser
DEBUG - 2016-01-29 05:54:39 --> Total execution time: 1.1228
INFO - 2016-01-29 05:54:40 --> Config Class Initialized
INFO - 2016-01-29 05:54:40 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:54:40 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:54:40 --> Utf8 Class Initialized
INFO - 2016-01-29 05:54:40 --> URI Class Initialized
INFO - 2016-01-29 05:54:40 --> Router Class Initialized
INFO - 2016-01-29 05:54:40 --> Output Class Initialized
INFO - 2016-01-29 05:54:40 --> Security Class Initialized
DEBUG - 2016-01-29 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:54:40 --> Input Class Initialized
INFO - 2016-01-29 05:54:40 --> Language Class Initialized
INFO - 2016-01-29 05:54:40 --> Loader Class Initialized
INFO - 2016-01-29 05:54:40 --> Helper loaded: url_helper
INFO - 2016-01-29 05:54:40 --> Helper loaded: file_helper
INFO - 2016-01-29 05:54:40 --> Helper loaded: date_helper
INFO - 2016-01-29 05:54:40 --> Database Driver Class Initialized
INFO - 2016-01-29 05:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:54:42 --> Controller Class Initialized
INFO - 2016-01-29 05:54:42 --> Model Class Initialized
INFO - 2016-01-29 05:54:42 --> Model Class Initialized
INFO - 2016-01-29 05:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:54:42 --> Pagination Class Initialized
INFO - 2016-01-29 05:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:54:42 --> Helper loaded: text_helper
INFO - 2016-01-29 05:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 05:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 05:54:42 --> Final output sent to browser
DEBUG - 2016-01-29 05:54:42 --> Total execution time: 1.1760
INFO - 2016-01-29 05:54:58 --> Config Class Initialized
INFO - 2016-01-29 05:54:58 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:54:58 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:54:58 --> Utf8 Class Initialized
INFO - 2016-01-29 05:54:58 --> URI Class Initialized
INFO - 2016-01-29 05:54:58 --> Router Class Initialized
INFO - 2016-01-29 05:54:58 --> Output Class Initialized
INFO - 2016-01-29 05:54:58 --> Security Class Initialized
DEBUG - 2016-01-29 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:54:58 --> Input Class Initialized
INFO - 2016-01-29 05:54:58 --> Language Class Initialized
INFO - 2016-01-29 05:54:58 --> Loader Class Initialized
INFO - 2016-01-29 05:54:58 --> Helper loaded: url_helper
INFO - 2016-01-29 05:54:58 --> Helper loaded: file_helper
INFO - 2016-01-29 05:54:58 --> Helper loaded: date_helper
INFO - 2016-01-29 05:54:58 --> Database Driver Class Initialized
INFO - 2016-01-29 05:54:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:54:59 --> Controller Class Initialized
INFO - 2016-01-29 05:54:59 --> Model Class Initialized
INFO - 2016-01-29 05:54:59 --> Model Class Initialized
INFO - 2016-01-29 05:54:59 --> Helper loaded: form_helper
INFO - 2016-01-29 05:54:59 --> Form Validation Class Initialized
INFO - 2016-01-29 05:54:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:54:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 05:54:59 --> Final output sent to browser
DEBUG - 2016-01-29 05:54:59 --> Total execution time: 1.1107
INFO - 2016-01-29 05:55:04 --> Config Class Initialized
INFO - 2016-01-29 05:55:04 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:55:04 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:55:04 --> Utf8 Class Initialized
INFO - 2016-01-29 05:55:04 --> URI Class Initialized
INFO - 2016-01-29 05:55:04 --> Router Class Initialized
INFO - 2016-01-29 05:55:04 --> Output Class Initialized
INFO - 2016-01-29 05:55:04 --> Security Class Initialized
DEBUG - 2016-01-29 05:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:55:04 --> Input Class Initialized
INFO - 2016-01-29 05:55:04 --> Language Class Initialized
INFO - 2016-01-29 05:55:04 --> Loader Class Initialized
INFO - 2016-01-29 05:55:04 --> Helper loaded: url_helper
INFO - 2016-01-29 05:55:04 --> Helper loaded: file_helper
INFO - 2016-01-29 05:55:04 --> Helper loaded: date_helper
INFO - 2016-01-29 05:55:04 --> Database Driver Class Initialized
INFO - 2016-01-29 05:55:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:55:05 --> Controller Class Initialized
INFO - 2016-01-29 05:55:05 --> Model Class Initialized
INFO - 2016-01-29 05:55:05 --> Model Class Initialized
INFO - 2016-01-29 05:55:05 --> Helper loaded: form_helper
INFO - 2016-01-29 05:55:05 --> Form Validation Class Initialized
INFO - 2016-01-29 05:55:05 --> Config Class Initialized
INFO - 2016-01-29 05:55:05 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:55:05 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:55:05 --> Utf8 Class Initialized
INFO - 2016-01-29 05:55:05 --> URI Class Initialized
INFO - 2016-01-29 05:55:05 --> Router Class Initialized
INFO - 2016-01-29 05:55:05 --> Output Class Initialized
INFO - 2016-01-29 05:55:05 --> Security Class Initialized
DEBUG - 2016-01-29 05:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:55:05 --> Input Class Initialized
INFO - 2016-01-29 05:55:05 --> Language Class Initialized
INFO - 2016-01-29 05:55:05 --> Loader Class Initialized
INFO - 2016-01-29 05:55:05 --> Helper loaded: url_helper
INFO - 2016-01-29 05:55:05 --> Helper loaded: file_helper
INFO - 2016-01-29 05:55:05 --> Helper loaded: date_helper
INFO - 2016-01-29 05:55:05 --> Database Driver Class Initialized
INFO - 2016-01-29 05:55:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:55:06 --> Controller Class Initialized
INFO - 2016-01-29 05:55:06 --> Model Class Initialized
INFO - 2016-01-29 05:55:06 --> Model Class Initialized
INFO - 2016-01-29 05:55:06 --> Helper loaded: form_helper
INFO - 2016-01-29 05:55:06 --> Form Validation Class Initialized
INFO - 2016-01-29 05:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-29 05:55:06 --> Final output sent to browser
DEBUG - 2016-01-29 05:55:06 --> Total execution time: 1.1138
INFO - 2016-01-29 05:55:11 --> Config Class Initialized
INFO - 2016-01-29 05:55:11 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:55:11 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:55:11 --> Utf8 Class Initialized
INFO - 2016-01-29 05:55:11 --> URI Class Initialized
INFO - 2016-01-29 05:55:11 --> Router Class Initialized
INFO - 2016-01-29 05:55:11 --> Output Class Initialized
INFO - 2016-01-29 05:55:11 --> Security Class Initialized
DEBUG - 2016-01-29 05:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:55:11 --> Input Class Initialized
INFO - 2016-01-29 05:55:11 --> Language Class Initialized
INFO - 2016-01-29 05:55:11 --> Loader Class Initialized
INFO - 2016-01-29 05:55:11 --> Helper loaded: url_helper
INFO - 2016-01-29 05:55:11 --> Helper loaded: file_helper
INFO - 2016-01-29 05:55:11 --> Helper loaded: date_helper
INFO - 2016-01-29 05:55:11 --> Database Driver Class Initialized
INFO - 2016-01-29 05:55:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:55:12 --> Controller Class Initialized
INFO - 2016-01-29 05:55:12 --> Model Class Initialized
INFO - 2016-01-29 05:55:12 --> Model Class Initialized
INFO - 2016-01-29 05:55:12 --> Helper loaded: form_helper
INFO - 2016-01-29 05:55:12 --> Form Validation Class Initialized
INFO - 2016-01-29 05:55:12 --> Config Class Initialized
INFO - 2016-01-29 05:55:12 --> Hooks Class Initialized
DEBUG - 2016-01-29 05:55:12 --> UTF-8 Support Enabled
INFO - 2016-01-29 05:55:12 --> Utf8 Class Initialized
INFO - 2016-01-29 05:55:12 --> URI Class Initialized
INFO - 2016-01-29 05:55:12 --> Router Class Initialized
INFO - 2016-01-29 05:55:12 --> Output Class Initialized
INFO - 2016-01-29 05:55:12 --> Security Class Initialized
DEBUG - 2016-01-29 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 05:55:12 --> Input Class Initialized
INFO - 2016-01-29 05:55:12 --> Language Class Initialized
INFO - 2016-01-29 05:55:12 --> Loader Class Initialized
INFO - 2016-01-29 05:55:12 --> Helper loaded: url_helper
INFO - 2016-01-29 05:55:12 --> Helper loaded: file_helper
INFO - 2016-01-29 05:55:12 --> Helper loaded: date_helper
INFO - 2016-01-29 05:55:12 --> Database Driver Class Initialized
INFO - 2016-01-29 05:55:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 05:55:13 --> Controller Class Initialized
INFO - 2016-01-29 05:55:13 --> Model Class Initialized
INFO - 2016-01-29 05:55:13 --> Model Class Initialized
INFO - 2016-01-29 05:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 05:55:13 --> Pagination Class Initialized
INFO - 2016-01-29 05:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 05:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 05:55:13 --> Final output sent to browser
DEBUG - 2016-01-29 05:55:13 --> Total execution time: 1.1523
INFO - 2016-01-29 06:02:12 --> Config Class Initialized
INFO - 2016-01-29 06:02:12 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:12 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:12 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:12 --> URI Class Initialized
INFO - 2016-01-29 06:02:12 --> Router Class Initialized
INFO - 2016-01-29 06:02:12 --> Output Class Initialized
INFO - 2016-01-29 06:02:12 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:12 --> Input Class Initialized
INFO - 2016-01-29 06:02:12 --> Language Class Initialized
INFO - 2016-01-29 06:02:12 --> Loader Class Initialized
INFO - 2016-01-29 06:02:12 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:12 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:12 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:12 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:13 --> Controller Class Initialized
INFO - 2016-01-29 06:02:13 --> Model Class Initialized
INFO - 2016-01-29 06:02:13 --> Model Class Initialized
INFO - 2016-01-29 06:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:13 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:13 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:13 --> Total execution time: 1.1459
INFO - 2016-01-29 06:02:15 --> Config Class Initialized
INFO - 2016-01-29 06:02:15 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:15 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:15 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:15 --> URI Class Initialized
INFO - 2016-01-29 06:02:15 --> Router Class Initialized
INFO - 2016-01-29 06:02:15 --> Output Class Initialized
INFO - 2016-01-29 06:02:15 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:15 --> Input Class Initialized
INFO - 2016-01-29 06:02:15 --> Language Class Initialized
INFO - 2016-01-29 06:02:15 --> Loader Class Initialized
INFO - 2016-01-29 06:02:15 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:15 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:15 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:15 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:16 --> Controller Class Initialized
INFO - 2016-01-29 06:02:16 --> Model Class Initialized
INFO - 2016-01-29 06:02:16 --> Model Class Initialized
INFO - 2016-01-29 06:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:16 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:16 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:16 --> Total execution time: 1.1177
INFO - 2016-01-29 06:02:18 --> Config Class Initialized
INFO - 2016-01-29 06:02:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:18 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:18 --> URI Class Initialized
INFO - 2016-01-29 06:02:18 --> Router Class Initialized
INFO - 2016-01-29 06:02:18 --> Output Class Initialized
INFO - 2016-01-29 06:02:18 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:18 --> Input Class Initialized
INFO - 2016-01-29 06:02:18 --> Language Class Initialized
INFO - 2016-01-29 06:02:18 --> Loader Class Initialized
INFO - 2016-01-29 06:02:18 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:18 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:18 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:18 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:19 --> Controller Class Initialized
INFO - 2016-01-29 06:02:19 --> Model Class Initialized
INFO - 2016-01-29 06:02:19 --> Model Class Initialized
INFO - 2016-01-29 06:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:19 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:19 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:19 --> Total execution time: 1.1100
INFO - 2016-01-29 06:02:36 --> Config Class Initialized
INFO - 2016-01-29 06:02:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:36 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:36 --> URI Class Initialized
INFO - 2016-01-29 06:02:36 --> Router Class Initialized
INFO - 2016-01-29 06:02:36 --> Output Class Initialized
INFO - 2016-01-29 06:02:36 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:36 --> Input Class Initialized
INFO - 2016-01-29 06:02:36 --> Language Class Initialized
INFO - 2016-01-29 06:02:36 --> Loader Class Initialized
INFO - 2016-01-29 06:02:36 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:36 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:36 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:36 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:37 --> Controller Class Initialized
INFO - 2016-01-29 06:02:37 --> Model Class Initialized
INFO - 2016-01-29 06:02:38 --> Model Class Initialized
INFO - 2016-01-29 06:02:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:38 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:38 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:38 --> Total execution time: 1.1580
INFO - 2016-01-29 06:02:40 --> Config Class Initialized
INFO - 2016-01-29 06:02:40 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:40 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:40 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:40 --> URI Class Initialized
INFO - 2016-01-29 06:02:40 --> Router Class Initialized
INFO - 2016-01-29 06:02:40 --> Output Class Initialized
INFO - 2016-01-29 06:02:40 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:40 --> Input Class Initialized
INFO - 2016-01-29 06:02:40 --> Language Class Initialized
INFO - 2016-01-29 06:02:40 --> Loader Class Initialized
INFO - 2016-01-29 06:02:40 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:40 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:40 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:40 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:41 --> Controller Class Initialized
INFO - 2016-01-29 06:02:41 --> Model Class Initialized
INFO - 2016-01-29 06:02:41 --> Model Class Initialized
INFO - 2016-01-29 06:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:42 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:42 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:42 --> Total execution time: 1.1290
INFO - 2016-01-29 06:02:43 --> Config Class Initialized
INFO - 2016-01-29 06:02:43 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:43 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:43 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:43 --> URI Class Initialized
INFO - 2016-01-29 06:02:43 --> Router Class Initialized
INFO - 2016-01-29 06:02:43 --> Output Class Initialized
INFO - 2016-01-29 06:02:43 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:43 --> Input Class Initialized
INFO - 2016-01-29 06:02:43 --> Language Class Initialized
INFO - 2016-01-29 06:02:43 --> Loader Class Initialized
INFO - 2016-01-29 06:02:43 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:43 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:43 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:43 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:44 --> Controller Class Initialized
INFO - 2016-01-29 06:02:44 --> Model Class Initialized
INFO - 2016-01-29 06:02:44 --> Model Class Initialized
INFO - 2016-01-29 06:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:44 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:44 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:44 --> Total execution time: 1.1425
INFO - 2016-01-29 06:02:46 --> Config Class Initialized
INFO - 2016-01-29 06:02:46 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:46 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:46 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:46 --> URI Class Initialized
INFO - 2016-01-29 06:02:46 --> Router Class Initialized
INFO - 2016-01-29 06:02:46 --> Output Class Initialized
INFO - 2016-01-29 06:02:46 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:46 --> Input Class Initialized
INFO - 2016-01-29 06:02:46 --> Language Class Initialized
INFO - 2016-01-29 06:02:46 --> Loader Class Initialized
INFO - 2016-01-29 06:02:46 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:46 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:46 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:46 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:47 --> Controller Class Initialized
INFO - 2016-01-29 06:02:47 --> Model Class Initialized
INFO - 2016-01-29 06:02:47 --> Model Class Initialized
INFO - 2016-01-29 06:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:48 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:48 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:48 --> Total execution time: 1.1403
INFO - 2016-01-29 06:02:54 --> Config Class Initialized
INFO - 2016-01-29 06:02:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:54 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:54 --> URI Class Initialized
INFO - 2016-01-29 06:02:54 --> Router Class Initialized
INFO - 2016-01-29 06:02:54 --> Output Class Initialized
INFO - 2016-01-29 06:02:54 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:54 --> Input Class Initialized
INFO - 2016-01-29 06:02:54 --> Language Class Initialized
INFO - 2016-01-29 06:02:54 --> Loader Class Initialized
INFO - 2016-01-29 06:02:54 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:54 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:54 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:54 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:55 --> Controller Class Initialized
INFO - 2016-01-29 06:02:55 --> Model Class Initialized
INFO - 2016-01-29 06:02:55 --> Model Class Initialized
INFO - 2016-01-29 06:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:55 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:55 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:55 --> Total execution time: 1.1476
INFO - 2016-01-29 06:02:58 --> Config Class Initialized
INFO - 2016-01-29 06:02:58 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:02:58 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:02:58 --> Utf8 Class Initialized
INFO - 2016-01-29 06:02:58 --> URI Class Initialized
INFO - 2016-01-29 06:02:58 --> Router Class Initialized
INFO - 2016-01-29 06:02:58 --> Output Class Initialized
INFO - 2016-01-29 06:02:58 --> Security Class Initialized
DEBUG - 2016-01-29 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:02:58 --> Input Class Initialized
INFO - 2016-01-29 06:02:58 --> Language Class Initialized
INFO - 2016-01-29 06:02:58 --> Loader Class Initialized
INFO - 2016-01-29 06:02:58 --> Helper loaded: url_helper
INFO - 2016-01-29 06:02:58 --> Helper loaded: file_helper
INFO - 2016-01-29 06:02:58 --> Helper loaded: date_helper
INFO - 2016-01-29 06:02:58 --> Database Driver Class Initialized
INFO - 2016-01-29 06:02:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:02:59 --> Controller Class Initialized
INFO - 2016-01-29 06:02:59 --> Model Class Initialized
INFO - 2016-01-29 06:02:59 --> Model Class Initialized
INFO - 2016-01-29 06:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:02:59 --> Pagination Class Initialized
INFO - 2016-01-29 06:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:02:59 --> Final output sent to browser
DEBUG - 2016-01-29 06:02:59 --> Total execution time: 1.1488
INFO - 2016-01-29 06:03:02 --> Config Class Initialized
INFO - 2016-01-29 06:03:02 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:03:02 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:03:02 --> Utf8 Class Initialized
INFO - 2016-01-29 06:03:02 --> URI Class Initialized
INFO - 2016-01-29 06:03:02 --> Router Class Initialized
INFO - 2016-01-29 06:03:02 --> Output Class Initialized
INFO - 2016-01-29 06:03:02 --> Security Class Initialized
DEBUG - 2016-01-29 06:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:03:02 --> Input Class Initialized
INFO - 2016-01-29 06:03:02 --> Language Class Initialized
INFO - 2016-01-29 06:03:02 --> Loader Class Initialized
INFO - 2016-01-29 06:03:02 --> Helper loaded: url_helper
INFO - 2016-01-29 06:03:02 --> Helper loaded: file_helper
INFO - 2016-01-29 06:03:02 --> Helper loaded: date_helper
INFO - 2016-01-29 06:03:02 --> Database Driver Class Initialized
INFO - 2016-01-29 06:03:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:03:03 --> Controller Class Initialized
INFO - 2016-01-29 06:03:03 --> Model Class Initialized
INFO - 2016-01-29 06:03:03 --> Model Class Initialized
INFO - 2016-01-29 06:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:03:03 --> Pagination Class Initialized
INFO - 2016-01-29 06:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:03:03 --> Final output sent to browser
DEBUG - 2016-01-29 06:03:03 --> Total execution time: 1.1133
INFO - 2016-01-29 06:03:04 --> Config Class Initialized
INFO - 2016-01-29 06:03:04 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:03:04 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:03:04 --> Utf8 Class Initialized
INFO - 2016-01-29 06:03:04 --> URI Class Initialized
INFO - 2016-01-29 06:03:04 --> Router Class Initialized
INFO - 2016-01-29 06:03:04 --> Output Class Initialized
INFO - 2016-01-29 06:03:04 --> Security Class Initialized
DEBUG - 2016-01-29 06:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:03:04 --> Input Class Initialized
INFO - 2016-01-29 06:03:04 --> Language Class Initialized
INFO - 2016-01-29 06:03:04 --> Loader Class Initialized
INFO - 2016-01-29 06:03:04 --> Helper loaded: url_helper
INFO - 2016-01-29 06:03:04 --> Helper loaded: file_helper
INFO - 2016-01-29 06:03:04 --> Helper loaded: date_helper
INFO - 2016-01-29 06:03:04 --> Database Driver Class Initialized
INFO - 2016-01-29 06:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:03:05 --> Controller Class Initialized
INFO - 2016-01-29 06:03:05 --> Model Class Initialized
INFO - 2016-01-29 06:03:06 --> Model Class Initialized
INFO - 2016-01-29 06:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:03:06 --> Pagination Class Initialized
INFO - 2016-01-29 06:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:03:06 --> Final output sent to browser
DEBUG - 2016-01-29 06:03:06 --> Total execution time: 1.1121
INFO - 2016-01-29 06:03:17 --> Config Class Initialized
INFO - 2016-01-29 06:03:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:03:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:03:17 --> Utf8 Class Initialized
INFO - 2016-01-29 06:03:17 --> URI Class Initialized
INFO - 2016-01-29 06:03:17 --> Router Class Initialized
INFO - 2016-01-29 06:03:17 --> Output Class Initialized
INFO - 2016-01-29 06:03:18 --> Security Class Initialized
DEBUG - 2016-01-29 06:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:03:18 --> Input Class Initialized
INFO - 2016-01-29 06:03:18 --> Language Class Initialized
INFO - 2016-01-29 06:03:18 --> Loader Class Initialized
INFO - 2016-01-29 06:03:18 --> Helper loaded: url_helper
INFO - 2016-01-29 06:03:18 --> Helper loaded: file_helper
INFO - 2016-01-29 06:03:18 --> Helper loaded: date_helper
INFO - 2016-01-29 06:03:18 --> Database Driver Class Initialized
INFO - 2016-01-29 06:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:03:19 --> Controller Class Initialized
INFO - 2016-01-29 06:03:19 --> Model Class Initialized
INFO - 2016-01-29 06:03:19 --> Model Class Initialized
INFO - 2016-01-29 06:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:03:19 --> Pagination Class Initialized
INFO - 2016-01-29 06:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:03:19 --> Final output sent to browser
DEBUG - 2016-01-29 06:03:19 --> Total execution time: 1.1637
INFO - 2016-01-29 06:03:29 --> Config Class Initialized
INFO - 2016-01-29 06:03:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:03:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:03:29 --> Utf8 Class Initialized
INFO - 2016-01-29 06:03:29 --> URI Class Initialized
INFO - 2016-01-29 06:03:29 --> Router Class Initialized
INFO - 2016-01-29 06:03:29 --> Output Class Initialized
INFO - 2016-01-29 06:03:29 --> Security Class Initialized
DEBUG - 2016-01-29 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:03:29 --> Input Class Initialized
INFO - 2016-01-29 06:03:29 --> Language Class Initialized
INFO - 2016-01-29 06:03:29 --> Loader Class Initialized
INFO - 2016-01-29 06:03:29 --> Helper loaded: url_helper
INFO - 2016-01-29 06:03:29 --> Helper loaded: file_helper
INFO - 2016-01-29 06:03:29 --> Helper loaded: date_helper
INFO - 2016-01-29 06:03:29 --> Database Driver Class Initialized
INFO - 2016-01-29 06:03:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:03:30 --> Controller Class Initialized
INFO - 2016-01-29 06:03:30 --> Model Class Initialized
INFO - 2016-01-29 06:03:30 --> Model Class Initialized
INFO - 2016-01-29 06:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:03:30 --> Pagination Class Initialized
INFO - 2016-01-29 06:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:03:30 --> Helper loaded: text_helper
INFO - 2016-01-29 06:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 06:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 06:03:30 --> Final output sent to browser
DEBUG - 2016-01-29 06:03:30 --> Total execution time: 1.1728
INFO - 2016-01-29 06:03:41 --> Config Class Initialized
INFO - 2016-01-29 06:03:41 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:03:41 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:03:41 --> Utf8 Class Initialized
INFO - 2016-01-29 06:03:41 --> URI Class Initialized
DEBUG - 2016-01-29 06:03:41 --> No URI present. Default controller set.
INFO - 2016-01-29 06:03:41 --> Router Class Initialized
INFO - 2016-01-29 06:03:41 --> Output Class Initialized
INFO - 2016-01-29 06:03:41 --> Security Class Initialized
DEBUG - 2016-01-29 06:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:03:41 --> Input Class Initialized
INFO - 2016-01-29 06:03:41 --> Language Class Initialized
INFO - 2016-01-29 06:03:41 --> Loader Class Initialized
INFO - 2016-01-29 06:03:41 --> Helper loaded: url_helper
INFO - 2016-01-29 06:03:41 --> Helper loaded: file_helper
INFO - 2016-01-29 06:03:41 --> Helper loaded: date_helper
INFO - 2016-01-29 06:03:41 --> Database Driver Class Initialized
INFO - 2016-01-29 06:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:03:42 --> Controller Class Initialized
INFO - 2016-01-29 06:03:42 --> Model Class Initialized
INFO - 2016-01-29 06:03:42 --> Model Class Initialized
INFO - 2016-01-29 06:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:03:42 --> Pagination Class Initialized
INFO - 2016-01-29 06:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:03:42 --> Final output sent to browser
DEBUG - 2016-01-29 06:03:42 --> Total execution time: 1.0927
INFO - 2016-01-29 06:04:02 --> Config Class Initialized
INFO - 2016-01-29 06:04:02 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:04:02 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:04:02 --> Utf8 Class Initialized
INFO - 2016-01-29 06:04:02 --> URI Class Initialized
INFO - 2016-01-29 06:04:02 --> Router Class Initialized
INFO - 2016-01-29 06:04:02 --> Output Class Initialized
INFO - 2016-01-29 06:04:02 --> Security Class Initialized
DEBUG - 2016-01-29 06:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:04:02 --> Input Class Initialized
INFO - 2016-01-29 06:04:02 --> Language Class Initialized
INFO - 2016-01-29 06:04:02 --> Loader Class Initialized
INFO - 2016-01-29 06:04:02 --> Helper loaded: url_helper
INFO - 2016-01-29 06:04:02 --> Helper loaded: file_helper
INFO - 2016-01-29 06:04:02 --> Helper loaded: date_helper
INFO - 2016-01-29 06:04:02 --> Database Driver Class Initialized
INFO - 2016-01-29 06:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:04:03 --> Controller Class Initialized
INFO - 2016-01-29 06:04:03 --> Model Class Initialized
INFO - 2016-01-29 06:04:03 --> Model Class Initialized
INFO - 2016-01-29 06:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:04:03 --> Pagination Class Initialized
INFO - 2016-01-29 06:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:04:03 --> Helper loaded: text_helper
INFO - 2016-01-29 06:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 06:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 06:04:04 --> Final output sent to browser
DEBUG - 2016-01-29 06:04:04 --> Total execution time: 1.1658
INFO - 2016-01-29 06:04:12 --> Config Class Initialized
INFO - 2016-01-29 06:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:04:12 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:04:12 --> Utf8 Class Initialized
INFO - 2016-01-29 06:04:12 --> URI Class Initialized
DEBUG - 2016-01-29 06:04:12 --> No URI present. Default controller set.
INFO - 2016-01-29 06:04:12 --> Router Class Initialized
INFO - 2016-01-29 06:04:12 --> Output Class Initialized
INFO - 2016-01-29 06:04:12 --> Security Class Initialized
DEBUG - 2016-01-29 06:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:04:12 --> Input Class Initialized
INFO - 2016-01-29 06:04:12 --> Language Class Initialized
INFO - 2016-01-29 06:04:12 --> Loader Class Initialized
INFO - 2016-01-29 06:04:12 --> Helper loaded: url_helper
INFO - 2016-01-29 06:04:12 --> Helper loaded: file_helper
INFO - 2016-01-29 06:04:12 --> Helper loaded: date_helper
INFO - 2016-01-29 06:04:12 --> Database Driver Class Initialized
INFO - 2016-01-29 06:04:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:04:13 --> Controller Class Initialized
INFO - 2016-01-29 06:04:13 --> Model Class Initialized
INFO - 2016-01-29 06:04:13 --> Model Class Initialized
INFO - 2016-01-29 06:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:04:13 --> Pagination Class Initialized
INFO - 2016-01-29 06:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:04:13 --> Final output sent to browser
DEBUG - 2016-01-29 06:04:13 --> Total execution time: 1.1073
INFO - 2016-01-29 06:21:09 --> Config Class Initialized
INFO - 2016-01-29 06:21:09 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:21:09 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:21:09 --> Utf8 Class Initialized
INFO - 2016-01-29 06:21:09 --> URI Class Initialized
INFO - 2016-01-29 06:21:09 --> Router Class Initialized
INFO - 2016-01-29 06:21:09 --> Output Class Initialized
INFO - 2016-01-29 06:21:09 --> Security Class Initialized
DEBUG - 2016-01-29 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:21:09 --> Input Class Initialized
INFO - 2016-01-29 06:21:09 --> Language Class Initialized
INFO - 2016-01-29 06:21:09 --> Loader Class Initialized
INFO - 2016-01-29 06:21:09 --> Helper loaded: url_helper
INFO - 2016-01-29 06:21:09 --> Helper loaded: file_helper
INFO - 2016-01-29 06:21:09 --> Helper loaded: date_helper
INFO - 2016-01-29 06:21:09 --> Database Driver Class Initialized
INFO - 2016-01-29 06:21:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:21:10 --> Controller Class Initialized
INFO - 2016-01-29 06:21:10 --> Model Class Initialized
INFO - 2016-01-29 06:21:10 --> Model Class Initialized
INFO - 2016-01-29 06:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:21:10 --> Pagination Class Initialized
INFO - 2016-01-29 06:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:21:10 --> Final output sent to browser
DEBUG - 2016-01-29 06:21:10 --> Total execution time: 1.1150
INFO - 2016-01-29 06:21:24 --> Config Class Initialized
INFO - 2016-01-29 06:21:24 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:21:24 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:21:24 --> Utf8 Class Initialized
INFO - 2016-01-29 06:21:24 --> URI Class Initialized
DEBUG - 2016-01-29 06:21:24 --> No URI present. Default controller set.
INFO - 2016-01-29 06:21:24 --> Router Class Initialized
INFO - 2016-01-29 06:21:24 --> Output Class Initialized
INFO - 2016-01-29 06:21:24 --> Security Class Initialized
DEBUG - 2016-01-29 06:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:21:24 --> Input Class Initialized
INFO - 2016-01-29 06:21:24 --> Language Class Initialized
INFO - 2016-01-29 06:21:24 --> Loader Class Initialized
INFO - 2016-01-29 06:21:24 --> Helper loaded: url_helper
INFO - 2016-01-29 06:21:24 --> Helper loaded: file_helper
INFO - 2016-01-29 06:21:24 --> Helper loaded: date_helper
INFO - 2016-01-29 06:21:24 --> Database Driver Class Initialized
INFO - 2016-01-29 06:21:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:21:25 --> Controller Class Initialized
INFO - 2016-01-29 06:21:25 --> Model Class Initialized
INFO - 2016-01-29 06:21:25 --> Model Class Initialized
INFO - 2016-01-29 06:21:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:21:25 --> Pagination Class Initialized
INFO - 2016-01-29 06:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:21:25 --> Final output sent to browser
DEBUG - 2016-01-29 06:21:25 --> Total execution time: 1.1281
INFO - 2016-01-29 06:21:36 --> Config Class Initialized
INFO - 2016-01-29 06:21:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:21:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:21:36 --> Utf8 Class Initialized
INFO - 2016-01-29 06:21:36 --> URI Class Initialized
DEBUG - 2016-01-29 06:21:36 --> No URI present. Default controller set.
INFO - 2016-01-29 06:21:36 --> Router Class Initialized
INFO - 2016-01-29 06:21:36 --> Output Class Initialized
INFO - 2016-01-29 06:21:36 --> Security Class Initialized
DEBUG - 2016-01-29 06:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:21:36 --> Input Class Initialized
INFO - 2016-01-29 06:21:36 --> Language Class Initialized
INFO - 2016-01-29 06:21:36 --> Loader Class Initialized
INFO - 2016-01-29 06:21:36 --> Helper loaded: url_helper
INFO - 2016-01-29 06:21:36 --> Helper loaded: file_helper
INFO - 2016-01-29 06:21:36 --> Helper loaded: date_helper
INFO - 2016-01-29 06:21:36 --> Database Driver Class Initialized
INFO - 2016-01-29 06:21:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:21:37 --> Controller Class Initialized
INFO - 2016-01-29 06:21:37 --> Model Class Initialized
INFO - 2016-01-29 06:21:37 --> Model Class Initialized
INFO - 2016-01-29 06:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:21:37 --> Pagination Class Initialized
INFO - 2016-01-29 06:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:21:37 --> Final output sent to browser
DEBUG - 2016-01-29 06:21:37 --> Total execution time: 1.1569
INFO - 2016-01-29 06:21:39 --> Config Class Initialized
INFO - 2016-01-29 06:21:39 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:21:39 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:21:39 --> Utf8 Class Initialized
INFO - 2016-01-29 06:21:39 --> URI Class Initialized
INFO - 2016-01-29 06:21:39 --> Router Class Initialized
INFO - 2016-01-29 06:21:39 --> Output Class Initialized
INFO - 2016-01-29 06:21:39 --> Security Class Initialized
DEBUG - 2016-01-29 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:21:39 --> Input Class Initialized
INFO - 2016-01-29 06:21:39 --> Language Class Initialized
INFO - 2016-01-29 06:21:39 --> Loader Class Initialized
INFO - 2016-01-29 06:21:39 --> Helper loaded: url_helper
INFO - 2016-01-29 06:21:39 --> Helper loaded: file_helper
INFO - 2016-01-29 06:21:39 --> Helper loaded: date_helper
INFO - 2016-01-29 06:21:39 --> Database Driver Class Initialized
INFO - 2016-01-29 06:21:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:21:40 --> Controller Class Initialized
INFO - 2016-01-29 06:21:40 --> Model Class Initialized
INFO - 2016-01-29 06:21:40 --> Model Class Initialized
INFO - 2016-01-29 06:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:21:40 --> Pagination Class Initialized
INFO - 2016-01-29 06:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:21:40 --> Final output sent to browser
DEBUG - 2016-01-29 06:21:40 --> Total execution time: 1.1210
INFO - 2016-01-29 06:21:42 --> Config Class Initialized
INFO - 2016-01-29 06:21:42 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:21:42 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:21:42 --> Utf8 Class Initialized
INFO - 2016-01-29 06:21:42 --> URI Class Initialized
INFO - 2016-01-29 06:21:42 --> Router Class Initialized
INFO - 2016-01-29 06:21:42 --> Output Class Initialized
INFO - 2016-01-29 06:21:42 --> Security Class Initialized
DEBUG - 2016-01-29 06:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:21:42 --> Input Class Initialized
INFO - 2016-01-29 06:21:42 --> Language Class Initialized
INFO - 2016-01-29 06:21:42 --> Loader Class Initialized
INFO - 2016-01-29 06:21:42 --> Helper loaded: url_helper
INFO - 2016-01-29 06:21:42 --> Helper loaded: file_helper
INFO - 2016-01-29 06:21:42 --> Helper loaded: date_helper
INFO - 2016-01-29 06:21:42 --> Database Driver Class Initialized
INFO - 2016-01-29 06:21:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:21:43 --> Controller Class Initialized
INFO - 2016-01-29 06:21:43 --> Model Class Initialized
INFO - 2016-01-29 06:21:43 --> Model Class Initialized
INFO - 2016-01-29 06:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:21:43 --> Pagination Class Initialized
INFO - 2016-01-29 06:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:21:43 --> Final output sent to browser
DEBUG - 2016-01-29 06:21:43 --> Total execution time: 1.1221
INFO - 2016-01-29 06:42:25 --> Config Class Initialized
INFO - 2016-01-29 06:42:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:42:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:42:25 --> Utf8 Class Initialized
INFO - 2016-01-29 06:42:25 --> URI Class Initialized
INFO - 2016-01-29 06:42:25 --> Router Class Initialized
INFO - 2016-01-29 06:42:25 --> Output Class Initialized
INFO - 2016-01-29 06:42:25 --> Security Class Initialized
DEBUG - 2016-01-29 06:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:42:25 --> Input Class Initialized
INFO - 2016-01-29 06:42:25 --> Language Class Initialized
INFO - 2016-01-29 06:42:25 --> Loader Class Initialized
INFO - 2016-01-29 06:42:25 --> Helper loaded: url_helper
INFO - 2016-01-29 06:42:25 --> Helper loaded: file_helper
INFO - 2016-01-29 06:42:25 --> Helper loaded: date_helper
INFO - 2016-01-29 06:42:25 --> Database Driver Class Initialized
INFO - 2016-01-29 06:42:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:42:27 --> Controller Class Initialized
INFO - 2016-01-29 06:42:27 --> Model Class Initialized
INFO - 2016-01-29 06:42:27 --> Model Class Initialized
INFO - 2016-01-29 06:42:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:42:27 --> Pagination Class Initialized
INFO - 2016-01-29 06:42:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:42:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:42:27 --> Final output sent to browser
DEBUG - 2016-01-29 06:42:27 --> Total execution time: 1.1218
INFO - 2016-01-29 06:42:36 --> Config Class Initialized
INFO - 2016-01-29 06:42:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:42:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:42:36 --> Utf8 Class Initialized
INFO - 2016-01-29 06:42:36 --> URI Class Initialized
INFO - 2016-01-29 06:42:36 --> Router Class Initialized
INFO - 2016-01-29 06:42:36 --> Output Class Initialized
INFO - 2016-01-29 06:42:36 --> Security Class Initialized
DEBUG - 2016-01-29 06:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:42:36 --> Input Class Initialized
INFO - 2016-01-29 06:42:36 --> Language Class Initialized
INFO - 2016-01-29 06:42:36 --> Loader Class Initialized
INFO - 2016-01-29 06:42:36 --> Helper loaded: url_helper
INFO - 2016-01-29 06:42:36 --> Helper loaded: file_helper
INFO - 2016-01-29 06:42:36 --> Helper loaded: date_helper
INFO - 2016-01-29 06:42:36 --> Database Driver Class Initialized
INFO - 2016-01-29 06:42:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:42:37 --> Controller Class Initialized
INFO - 2016-01-29 06:42:37 --> Model Class Initialized
INFO - 2016-01-29 06:42:37 --> Model Class Initialized
INFO - 2016-01-29 06:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:42:37 --> Pagination Class Initialized
INFO - 2016-01-29 06:42:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:42:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:42:37 --> Final output sent to browser
DEBUG - 2016-01-29 06:42:37 --> Total execution time: 1.1035
INFO - 2016-01-29 06:46:50 --> Config Class Initialized
INFO - 2016-01-29 06:46:50 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:46:50 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:46:50 --> Utf8 Class Initialized
INFO - 2016-01-29 06:46:50 --> URI Class Initialized
DEBUG - 2016-01-29 06:46:50 --> No URI present. Default controller set.
INFO - 2016-01-29 06:46:50 --> Router Class Initialized
INFO - 2016-01-29 06:46:50 --> Output Class Initialized
INFO - 2016-01-29 06:46:50 --> Security Class Initialized
DEBUG - 2016-01-29 06:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:46:50 --> Input Class Initialized
INFO - 2016-01-29 06:46:50 --> Language Class Initialized
INFO - 2016-01-29 06:46:50 --> Loader Class Initialized
INFO - 2016-01-29 06:46:50 --> Helper loaded: url_helper
INFO - 2016-01-29 06:46:50 --> Helper loaded: file_helper
INFO - 2016-01-29 06:46:50 --> Helper loaded: date_helper
INFO - 2016-01-29 06:46:50 --> Database Driver Class Initialized
INFO - 2016-01-29 06:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:46:51 --> Controller Class Initialized
INFO - 2016-01-29 06:46:51 --> Model Class Initialized
INFO - 2016-01-29 06:46:51 --> Model Class Initialized
INFO - 2016-01-29 06:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:46:51 --> Pagination Class Initialized
INFO - 2016-01-29 06:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:46:51 --> Final output sent to browser
DEBUG - 2016-01-29 06:46:51 --> Total execution time: 1.0848
INFO - 2016-01-29 06:46:55 --> Config Class Initialized
INFO - 2016-01-29 06:46:55 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:46:55 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:46:55 --> Utf8 Class Initialized
INFO - 2016-01-29 06:46:55 --> URI Class Initialized
INFO - 2016-01-29 06:46:55 --> Router Class Initialized
INFO - 2016-01-29 06:46:55 --> Output Class Initialized
INFO - 2016-01-29 06:46:55 --> Security Class Initialized
DEBUG - 2016-01-29 06:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:46:55 --> Input Class Initialized
INFO - 2016-01-29 06:46:55 --> Language Class Initialized
INFO - 2016-01-29 06:46:55 --> Loader Class Initialized
INFO - 2016-01-29 06:46:55 --> Helper loaded: url_helper
INFO - 2016-01-29 06:46:55 --> Helper loaded: file_helper
INFO - 2016-01-29 06:46:55 --> Helper loaded: date_helper
INFO - 2016-01-29 06:46:55 --> Database Driver Class Initialized
INFO - 2016-01-29 06:46:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:46:56 --> Controller Class Initialized
INFO - 2016-01-29 06:46:56 --> Model Class Initialized
INFO - 2016-01-29 06:46:56 --> Model Class Initialized
INFO - 2016-01-29 06:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:46:56 --> Pagination Class Initialized
ERROR - 2016-01-29 06:46:56 --> Query error: Unknown column 'bookname' in 'where clause' - Invalid query: SELECT *
FROM `jdmain`
WHERE `bookname` LIKE '%test%' ESCAPE '!'
OR  `author` LIKE '%test%' ESCAPE '!'
OR  `description` LIKE '%test%' ESCAPE '!'
INFO - 2016-01-29 06:46:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-01-29 06:46:56 --> Query error: Unknown column 'bookname' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1454078816
WHERE `bookname` LIKE '%test%' ESCAPE '!'
OR  `author` LIKE '%test%' ESCAPE '!'
OR  `description` LIKE '%test%' ESCAPE '!'
AND `id` = '350a865eab461f9686f9969ae33914274d1b5c8d'
INFO - 2016-01-29 06:48:21 --> Config Class Initialized
INFO - 2016-01-29 06:48:21 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:48:21 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:48:21 --> Utf8 Class Initialized
INFO - 2016-01-29 06:48:21 --> URI Class Initialized
DEBUG - 2016-01-29 06:48:21 --> No URI present. Default controller set.
INFO - 2016-01-29 06:48:21 --> Router Class Initialized
INFO - 2016-01-29 06:48:21 --> Output Class Initialized
INFO - 2016-01-29 06:48:21 --> Security Class Initialized
DEBUG - 2016-01-29 06:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:48:21 --> Input Class Initialized
INFO - 2016-01-29 06:48:21 --> Language Class Initialized
INFO - 2016-01-29 06:48:21 --> Loader Class Initialized
INFO - 2016-01-29 06:48:21 --> Helper loaded: url_helper
INFO - 2016-01-29 06:48:21 --> Helper loaded: file_helper
INFO - 2016-01-29 06:48:21 --> Helper loaded: date_helper
INFO - 2016-01-29 06:48:21 --> Database Driver Class Initialized
INFO - 2016-01-29 06:48:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:48:22 --> Controller Class Initialized
INFO - 2016-01-29 06:48:22 --> Model Class Initialized
INFO - 2016-01-29 06:48:22 --> Model Class Initialized
INFO - 2016-01-29 06:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:48:22 --> Pagination Class Initialized
INFO - 2016-01-29 06:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:48:22 --> Final output sent to browser
DEBUG - 2016-01-29 06:48:22 --> Total execution time: 1.1290
INFO - 2016-01-29 06:48:25 --> Config Class Initialized
INFO - 2016-01-29 06:48:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:48:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:48:25 --> Utf8 Class Initialized
INFO - 2016-01-29 06:48:25 --> URI Class Initialized
INFO - 2016-01-29 06:48:25 --> Router Class Initialized
INFO - 2016-01-29 06:48:25 --> Output Class Initialized
INFO - 2016-01-29 06:48:25 --> Security Class Initialized
DEBUG - 2016-01-29 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:48:25 --> Input Class Initialized
INFO - 2016-01-29 06:48:25 --> Language Class Initialized
INFO - 2016-01-29 06:48:25 --> Loader Class Initialized
INFO - 2016-01-29 06:48:25 --> Helper loaded: url_helper
INFO - 2016-01-29 06:48:25 --> Helper loaded: file_helper
INFO - 2016-01-29 06:48:25 --> Helper loaded: date_helper
INFO - 2016-01-29 06:48:25 --> Database Driver Class Initialized
INFO - 2016-01-29 06:48:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:48:26 --> Controller Class Initialized
INFO - 2016-01-29 06:48:26 --> Model Class Initialized
INFO - 2016-01-29 06:48:27 --> Model Class Initialized
INFO - 2016-01-29 06:48:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:48:27 --> Pagination Class Initialized
ERROR - 2016-01-29 06:48:27 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 30
INFO - 2016-01-29 06:48:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:48:27 --> Final output sent to browser
DEBUG - 2016-01-29 06:48:27 --> Total execution time: 1.1374
INFO - 2016-01-29 06:50:37 --> Config Class Initialized
INFO - 2016-01-29 06:50:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:50:37 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:50:37 --> Utf8 Class Initialized
INFO - 2016-01-29 06:50:37 --> URI Class Initialized
DEBUG - 2016-01-29 06:50:37 --> No URI present. Default controller set.
INFO - 2016-01-29 06:50:37 --> Router Class Initialized
INFO - 2016-01-29 06:50:37 --> Output Class Initialized
INFO - 2016-01-29 06:50:37 --> Security Class Initialized
DEBUG - 2016-01-29 06:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:50:37 --> Input Class Initialized
INFO - 2016-01-29 06:50:37 --> Language Class Initialized
INFO - 2016-01-29 06:50:37 --> Loader Class Initialized
INFO - 2016-01-29 06:50:37 --> Helper loaded: url_helper
INFO - 2016-01-29 06:50:37 --> Helper loaded: file_helper
INFO - 2016-01-29 06:50:37 --> Helper loaded: date_helper
INFO - 2016-01-29 06:50:37 --> Database Driver Class Initialized
INFO - 2016-01-29 06:50:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:50:38 --> Controller Class Initialized
INFO - 2016-01-29 06:50:38 --> Model Class Initialized
INFO - 2016-01-29 06:50:38 --> Model Class Initialized
INFO - 2016-01-29 06:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:50:38 --> Pagination Class Initialized
INFO - 2016-01-29 06:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:50:38 --> Final output sent to browser
DEBUG - 2016-01-29 06:50:38 --> Total execution time: 1.1094
INFO - 2016-01-29 06:50:55 --> Config Class Initialized
INFO - 2016-01-29 06:50:55 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:50:55 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:50:55 --> Utf8 Class Initialized
INFO - 2016-01-29 06:50:55 --> URI Class Initialized
INFO - 2016-01-29 06:50:55 --> Router Class Initialized
INFO - 2016-01-29 06:50:55 --> Output Class Initialized
INFO - 2016-01-29 06:50:55 --> Security Class Initialized
DEBUG - 2016-01-29 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:50:55 --> Input Class Initialized
INFO - 2016-01-29 06:50:55 --> Language Class Initialized
INFO - 2016-01-29 06:50:55 --> Loader Class Initialized
INFO - 2016-01-29 06:50:55 --> Helper loaded: url_helper
INFO - 2016-01-29 06:50:55 --> Helper loaded: file_helper
INFO - 2016-01-29 06:50:55 --> Helper loaded: date_helper
INFO - 2016-01-29 06:50:55 --> Database Driver Class Initialized
INFO - 2016-01-29 06:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:50:56 --> Controller Class Initialized
INFO - 2016-01-29 06:50:56 --> Model Class Initialized
INFO - 2016-01-29 06:50:56 --> Model Class Initialized
INFO - 2016-01-29 06:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:50:56 --> Pagination Class Initialized
ERROR - 2016-01-29 06:50:56 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 30
INFO - 2016-01-29 06:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 06:50:56 --> Final output sent to browser
DEBUG - 2016-01-29 06:50:56 --> Total execution time: 1.0969
INFO - 2016-01-29 06:51:39 --> Config Class Initialized
INFO - 2016-01-29 06:51:39 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:51:39 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:51:39 --> Utf8 Class Initialized
INFO - 2016-01-29 06:51:39 --> URI Class Initialized
DEBUG - 2016-01-29 06:51:39 --> No URI present. Default controller set.
INFO - 2016-01-29 06:51:39 --> Router Class Initialized
INFO - 2016-01-29 06:51:39 --> Output Class Initialized
INFO - 2016-01-29 06:51:39 --> Security Class Initialized
DEBUG - 2016-01-29 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:51:39 --> Input Class Initialized
INFO - 2016-01-29 06:51:39 --> Language Class Initialized
INFO - 2016-01-29 06:51:39 --> Loader Class Initialized
INFO - 2016-01-29 06:51:40 --> Helper loaded: url_helper
INFO - 2016-01-29 06:51:40 --> Helper loaded: file_helper
INFO - 2016-01-29 06:51:40 --> Helper loaded: date_helper
INFO - 2016-01-29 06:51:40 --> Database Driver Class Initialized
INFO - 2016-01-29 06:51:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:51:41 --> Controller Class Initialized
INFO - 2016-01-29 06:51:41 --> Model Class Initialized
INFO - 2016-01-29 06:51:41 --> Model Class Initialized
INFO - 2016-01-29 06:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:51:41 --> Pagination Class Initialized
INFO - 2016-01-29 06:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:51:41 --> Final output sent to browser
DEBUG - 2016-01-29 06:51:41 --> Total execution time: 1.1284
INFO - 2016-01-29 06:51:43 --> Config Class Initialized
INFO - 2016-01-29 06:51:43 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:51:43 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:51:43 --> Utf8 Class Initialized
INFO - 2016-01-29 06:51:43 --> URI Class Initialized
INFO - 2016-01-29 06:51:43 --> Router Class Initialized
INFO - 2016-01-29 06:51:43 --> Output Class Initialized
INFO - 2016-01-29 06:51:43 --> Security Class Initialized
DEBUG - 2016-01-29 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:51:43 --> Input Class Initialized
INFO - 2016-01-29 06:51:43 --> Language Class Initialized
INFO - 2016-01-29 06:51:43 --> Loader Class Initialized
INFO - 2016-01-29 06:51:43 --> Helper loaded: url_helper
INFO - 2016-01-29 06:51:43 --> Helper loaded: file_helper
INFO - 2016-01-29 06:51:43 --> Helper loaded: date_helper
INFO - 2016-01-29 06:51:43 --> Database Driver Class Initialized
INFO - 2016-01-29 06:51:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:51:44 --> Controller Class Initialized
INFO - 2016-01-29 06:51:44 --> Model Class Initialized
INFO - 2016-01-29 06:51:44 --> Model Class Initialized
INFO - 2016-01-29 06:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:51:44 --> Pagination Class Initialized
INFO - 2016-01-29 06:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 06:51:44 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 30
INFO - 2016-01-29 06:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 06:51:44 --> Final output sent to browser
DEBUG - 2016-01-29 06:51:44 --> Total execution time: 1.1191
INFO - 2016-01-29 06:52:08 --> Config Class Initialized
INFO - 2016-01-29 06:52:08 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:52:08 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:52:08 --> Utf8 Class Initialized
INFO - 2016-01-29 06:52:08 --> URI Class Initialized
DEBUG - 2016-01-29 06:52:08 --> No URI present. Default controller set.
INFO - 2016-01-29 06:52:08 --> Router Class Initialized
INFO - 2016-01-29 06:52:08 --> Output Class Initialized
INFO - 2016-01-29 06:52:08 --> Security Class Initialized
DEBUG - 2016-01-29 06:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:52:08 --> Input Class Initialized
INFO - 2016-01-29 06:52:08 --> Language Class Initialized
INFO - 2016-01-29 06:52:08 --> Loader Class Initialized
INFO - 2016-01-29 06:52:08 --> Helper loaded: url_helper
INFO - 2016-01-29 06:52:08 --> Helper loaded: file_helper
INFO - 2016-01-29 06:52:08 --> Helper loaded: date_helper
INFO - 2016-01-29 06:52:08 --> Database Driver Class Initialized
INFO - 2016-01-29 06:52:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:52:09 --> Controller Class Initialized
INFO - 2016-01-29 06:52:10 --> Model Class Initialized
INFO - 2016-01-29 06:52:10 --> Model Class Initialized
INFO - 2016-01-29 06:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:52:10 --> Pagination Class Initialized
INFO - 2016-01-29 06:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:52:10 --> Final output sent to browser
DEBUG - 2016-01-29 06:52:10 --> Total execution time: 1.1002
INFO - 2016-01-29 06:52:10 --> Config Class Initialized
INFO - 2016-01-29 06:52:10 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:52:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:52:10 --> Utf8 Class Initialized
INFO - 2016-01-29 06:52:10 --> URI Class Initialized
DEBUG - 2016-01-29 06:52:10 --> No URI present. Default controller set.
INFO - 2016-01-29 06:52:10 --> Router Class Initialized
INFO - 2016-01-29 06:52:10 --> Output Class Initialized
INFO - 2016-01-29 06:52:10 --> Security Class Initialized
DEBUG - 2016-01-29 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:52:10 --> Input Class Initialized
INFO - 2016-01-29 06:52:10 --> Language Class Initialized
INFO - 2016-01-29 06:52:10 --> Loader Class Initialized
INFO - 2016-01-29 06:52:10 --> Helper loaded: url_helper
INFO - 2016-01-29 06:52:10 --> Helper loaded: file_helper
INFO - 2016-01-29 06:52:10 --> Helper loaded: date_helper
INFO - 2016-01-29 06:52:10 --> Database Driver Class Initialized
INFO - 2016-01-29 06:52:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:52:11 --> Controller Class Initialized
INFO - 2016-01-29 06:52:11 --> Model Class Initialized
INFO - 2016-01-29 06:52:11 --> Model Class Initialized
INFO - 2016-01-29 06:52:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:52:11 --> Pagination Class Initialized
INFO - 2016-01-29 06:52:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:52:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 06:52:11 --> Final output sent to browser
DEBUG - 2016-01-29 06:52:11 --> Total execution time: 1.0786
INFO - 2016-01-29 06:52:20 --> Config Class Initialized
INFO - 2016-01-29 06:52:20 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:52:20 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:52:20 --> Utf8 Class Initialized
INFO - 2016-01-29 06:52:20 --> URI Class Initialized
INFO - 2016-01-29 06:52:20 --> Router Class Initialized
INFO - 2016-01-29 06:52:20 --> Output Class Initialized
INFO - 2016-01-29 06:52:20 --> Security Class Initialized
DEBUG - 2016-01-29 06:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:52:20 --> Input Class Initialized
INFO - 2016-01-29 06:52:20 --> Language Class Initialized
INFO - 2016-01-29 06:52:20 --> Loader Class Initialized
INFO - 2016-01-29 06:52:20 --> Helper loaded: url_helper
INFO - 2016-01-29 06:52:20 --> Helper loaded: file_helper
INFO - 2016-01-29 06:52:20 --> Helper loaded: date_helper
INFO - 2016-01-29 06:52:20 --> Database Driver Class Initialized
INFO - 2016-01-29 06:52:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:52:21 --> Controller Class Initialized
INFO - 2016-01-29 06:52:21 --> Model Class Initialized
INFO - 2016-01-29 06:52:21 --> Model Class Initialized
INFO - 2016-01-29 06:52:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:52:21 --> Pagination Class Initialized
INFO - 2016-01-29 06:52:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 06:52:21 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 30
INFO - 2016-01-29 06:52:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:52:21 --> Final output sent to browser
DEBUG - 2016-01-29 06:52:21 --> Total execution time: 1.1082
INFO - 2016-01-29 06:54:09 --> Config Class Initialized
INFO - 2016-01-29 06:54:09 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:54:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:54:10 --> Utf8 Class Initialized
INFO - 2016-01-29 06:54:10 --> URI Class Initialized
INFO - 2016-01-29 06:54:10 --> Router Class Initialized
INFO - 2016-01-29 06:54:10 --> Output Class Initialized
INFO - 2016-01-29 06:54:10 --> Security Class Initialized
DEBUG - 2016-01-29 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:54:10 --> Input Class Initialized
INFO - 2016-01-29 06:54:10 --> Language Class Initialized
INFO - 2016-01-29 06:54:10 --> Loader Class Initialized
INFO - 2016-01-29 06:54:10 --> Helper loaded: url_helper
INFO - 2016-01-29 06:54:10 --> Helper loaded: file_helper
INFO - 2016-01-29 06:54:10 --> Helper loaded: date_helper
INFO - 2016-01-29 06:54:10 --> Database Driver Class Initialized
INFO - 2016-01-29 06:54:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:54:11 --> Controller Class Initialized
INFO - 2016-01-29 06:54:11 --> Model Class Initialized
INFO - 2016-01-29 06:54:11 --> Model Class Initialized
INFO - 2016-01-29 06:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:54:11 --> Pagination Class Initialized
ERROR - 2016-01-29 06:54:11 --> Severity: Notice --> Undefined index: total C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 246
INFO - 2016-01-29 06:54:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:54:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:54:11 --> Final output sent to browser
DEBUG - 2016-01-29 06:54:11 --> Total execution time: 1.1157
INFO - 2016-01-29 06:56:40 --> Config Class Initialized
INFO - 2016-01-29 06:56:40 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:56:40 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:56:40 --> Utf8 Class Initialized
INFO - 2016-01-29 06:56:40 --> URI Class Initialized
INFO - 2016-01-29 06:56:40 --> Router Class Initialized
INFO - 2016-01-29 06:56:40 --> Output Class Initialized
INFO - 2016-01-29 06:56:40 --> Security Class Initialized
DEBUG - 2016-01-29 06:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:56:40 --> Input Class Initialized
INFO - 2016-01-29 06:56:40 --> Language Class Initialized
INFO - 2016-01-29 06:56:40 --> Loader Class Initialized
INFO - 2016-01-29 06:56:40 --> Helper loaded: url_helper
INFO - 2016-01-29 06:56:40 --> Helper loaded: file_helper
INFO - 2016-01-29 06:56:40 --> Helper loaded: date_helper
INFO - 2016-01-29 06:56:40 --> Database Driver Class Initialized
INFO - 2016-01-29 06:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:56:41 --> Controller Class Initialized
INFO - 2016-01-29 06:56:41 --> Model Class Initialized
INFO - 2016-01-29 06:56:41 --> Model Class Initialized
INFO - 2016-01-29 06:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:56:41 --> Pagination Class Initialized
INFO - 2016-01-29 06:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:56:41 --> Final output sent to browser
DEBUG - 2016-01-29 06:56:41 --> Total execution time: 1.1099
INFO - 2016-01-29 06:57:29 --> Config Class Initialized
INFO - 2016-01-29 06:57:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 06:57:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 06:57:29 --> Utf8 Class Initialized
INFO - 2016-01-29 06:57:29 --> URI Class Initialized
INFO - 2016-01-29 06:57:29 --> Router Class Initialized
INFO - 2016-01-29 06:57:29 --> Output Class Initialized
INFO - 2016-01-29 06:57:29 --> Security Class Initialized
DEBUG - 2016-01-29 06:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 06:57:29 --> Input Class Initialized
INFO - 2016-01-29 06:57:29 --> Language Class Initialized
INFO - 2016-01-29 06:57:29 --> Loader Class Initialized
INFO - 2016-01-29 06:57:29 --> Helper loaded: url_helper
INFO - 2016-01-29 06:57:29 --> Helper loaded: file_helper
INFO - 2016-01-29 06:57:29 --> Helper loaded: date_helper
INFO - 2016-01-29 06:57:29 --> Database Driver Class Initialized
INFO - 2016-01-29 06:57:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 06:57:30 --> Controller Class Initialized
INFO - 2016-01-29 06:57:30 --> Model Class Initialized
INFO - 2016-01-29 06:57:30 --> Model Class Initialized
INFO - 2016-01-29 06:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 06:57:30 --> Pagination Class Initialized
INFO - 2016-01-29 06:57:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 06:57:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 06:57:30 --> Final output sent to browser
DEBUG - 2016-01-29 06:57:30 --> Total execution time: 1.1098
INFO - 2016-01-29 07:02:49 --> Config Class Initialized
INFO - 2016-01-29 07:02:49 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:02:49 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:02:49 --> Utf8 Class Initialized
INFO - 2016-01-29 07:02:49 --> URI Class Initialized
DEBUG - 2016-01-29 07:02:49 --> No URI present. Default controller set.
INFO - 2016-01-29 07:02:49 --> Router Class Initialized
INFO - 2016-01-29 07:02:49 --> Output Class Initialized
INFO - 2016-01-29 07:02:49 --> Security Class Initialized
DEBUG - 2016-01-29 07:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:02:49 --> Input Class Initialized
INFO - 2016-01-29 07:02:49 --> Language Class Initialized
INFO - 2016-01-29 07:02:49 --> Loader Class Initialized
INFO - 2016-01-29 07:02:49 --> Helper loaded: url_helper
INFO - 2016-01-29 07:02:49 --> Helper loaded: file_helper
INFO - 2016-01-29 07:02:49 --> Helper loaded: date_helper
INFO - 2016-01-29 07:02:49 --> Database Driver Class Initialized
INFO - 2016-01-29 07:02:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:02:50 --> Controller Class Initialized
INFO - 2016-01-29 07:02:50 --> Model Class Initialized
INFO - 2016-01-29 07:02:50 --> Model Class Initialized
INFO - 2016-01-29 07:02:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:02:50 --> Pagination Class Initialized
INFO - 2016-01-29 07:02:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:02:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:02:50 --> Final output sent to browser
DEBUG - 2016-01-29 07:02:50 --> Total execution time: 1.0920
INFO - 2016-01-29 07:02:54 --> Config Class Initialized
INFO - 2016-01-29 07:02:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:02:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:02:54 --> Utf8 Class Initialized
INFO - 2016-01-29 07:02:54 --> URI Class Initialized
INFO - 2016-01-29 07:02:54 --> Router Class Initialized
INFO - 2016-01-29 07:02:54 --> Output Class Initialized
INFO - 2016-01-29 07:02:54 --> Security Class Initialized
DEBUG - 2016-01-29 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:02:54 --> Input Class Initialized
INFO - 2016-01-29 07:02:54 --> Language Class Initialized
INFO - 2016-01-29 07:02:54 --> Loader Class Initialized
INFO - 2016-01-29 07:02:54 --> Helper loaded: url_helper
INFO - 2016-01-29 07:02:54 --> Helper loaded: file_helper
INFO - 2016-01-29 07:02:54 --> Helper loaded: date_helper
INFO - 2016-01-29 07:02:54 --> Database Driver Class Initialized
INFO - 2016-01-29 07:02:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:02:55 --> Controller Class Initialized
INFO - 2016-01-29 07:02:55 --> Model Class Initialized
INFO - 2016-01-29 07:02:55 --> Model Class Initialized
INFO - 2016-01-29 07:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:02:55 --> Pagination Class Initialized
INFO - 2016-01-29 07:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:02:55 --> Final output sent to browser
DEBUG - 2016-01-29 07:02:55 --> Total execution time: 1.0982
INFO - 2016-01-29 07:02:57 --> Config Class Initialized
INFO - 2016-01-29 07:02:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:02:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:02:57 --> Utf8 Class Initialized
INFO - 2016-01-29 07:02:57 --> URI Class Initialized
INFO - 2016-01-29 07:02:57 --> Router Class Initialized
INFO - 2016-01-29 07:02:57 --> Output Class Initialized
INFO - 2016-01-29 07:02:57 --> Security Class Initialized
DEBUG - 2016-01-29 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:02:57 --> Input Class Initialized
INFO - 2016-01-29 07:02:57 --> Language Class Initialized
INFO - 2016-01-29 07:02:57 --> Loader Class Initialized
INFO - 2016-01-29 07:02:57 --> Helper loaded: url_helper
INFO - 2016-01-29 07:02:57 --> Helper loaded: file_helper
INFO - 2016-01-29 07:02:57 --> Helper loaded: date_helper
INFO - 2016-01-29 07:02:57 --> Database Driver Class Initialized
INFO - 2016-01-29 07:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:02:58 --> Controller Class Initialized
INFO - 2016-01-29 07:02:58 --> Model Class Initialized
INFO - 2016-01-29 07:02:58 --> Model Class Initialized
INFO - 2016-01-29 07:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:02:58 --> Pagination Class Initialized
INFO - 2016-01-29 07:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:02:58 --> Final output sent to browser
DEBUG - 2016-01-29 07:02:58 --> Total execution time: 1.0877
INFO - 2016-01-29 07:03:25 --> Config Class Initialized
INFO - 2016-01-29 07:03:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:25 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:25 --> URI Class Initialized
DEBUG - 2016-01-29 07:03:25 --> No URI present. Default controller set.
INFO - 2016-01-29 07:03:25 --> Router Class Initialized
INFO - 2016-01-29 07:03:25 --> Output Class Initialized
INFO - 2016-01-29 07:03:25 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:25 --> Input Class Initialized
INFO - 2016-01-29 07:03:25 --> Language Class Initialized
INFO - 2016-01-29 07:03:25 --> Loader Class Initialized
INFO - 2016-01-29 07:03:25 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:25 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:25 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:25 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:26 --> Controller Class Initialized
INFO - 2016-01-29 07:03:26 --> Model Class Initialized
INFO - 2016-01-29 07:03:26 --> Model Class Initialized
INFO - 2016-01-29 07:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:26 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:03:26 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:26 --> Total execution time: 1.1192
INFO - 2016-01-29 07:03:29 --> Config Class Initialized
INFO - 2016-01-29 07:03:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:29 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:29 --> URI Class Initialized
INFO - 2016-01-29 07:03:29 --> Router Class Initialized
INFO - 2016-01-29 07:03:29 --> Output Class Initialized
INFO - 2016-01-29 07:03:29 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:29 --> Input Class Initialized
INFO - 2016-01-29 07:03:29 --> Language Class Initialized
INFO - 2016-01-29 07:03:29 --> Loader Class Initialized
INFO - 2016-01-29 07:03:29 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:29 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:29 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:29 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:30 --> Controller Class Initialized
INFO - 2016-01-29 07:03:30 --> Model Class Initialized
INFO - 2016-01-29 07:03:30 --> Model Class Initialized
INFO - 2016-01-29 07:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:30 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:30 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:30 --> Total execution time: 1.1178
INFO - 2016-01-29 07:03:32 --> Config Class Initialized
INFO - 2016-01-29 07:03:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:32 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:32 --> URI Class Initialized
INFO - 2016-01-29 07:03:32 --> Router Class Initialized
INFO - 2016-01-29 07:03:32 --> Output Class Initialized
INFO - 2016-01-29 07:03:32 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:32 --> Input Class Initialized
INFO - 2016-01-29 07:03:32 --> Language Class Initialized
INFO - 2016-01-29 07:03:32 --> Loader Class Initialized
INFO - 2016-01-29 07:03:32 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:32 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:32 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:32 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:33 --> Controller Class Initialized
INFO - 2016-01-29 07:03:33 --> Model Class Initialized
INFO - 2016-01-29 07:03:33 --> Model Class Initialized
INFO - 2016-01-29 07:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:33 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:33 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:33 --> Total execution time: 1.1127
INFO - 2016-01-29 07:03:36 --> Config Class Initialized
INFO - 2016-01-29 07:03:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:36 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:36 --> URI Class Initialized
INFO - 2016-01-29 07:03:36 --> Router Class Initialized
INFO - 2016-01-29 07:03:36 --> Output Class Initialized
INFO - 2016-01-29 07:03:36 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:36 --> Input Class Initialized
INFO - 2016-01-29 07:03:36 --> Language Class Initialized
INFO - 2016-01-29 07:03:36 --> Loader Class Initialized
INFO - 2016-01-29 07:03:36 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:36 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:36 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:36 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:37 --> Controller Class Initialized
INFO - 2016-01-29 07:03:37 --> Model Class Initialized
INFO - 2016-01-29 07:03:37 --> Model Class Initialized
INFO - 2016-01-29 07:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:37 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:37 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:37 --> Total execution time: 1.1065
INFO - 2016-01-29 07:03:39 --> Config Class Initialized
INFO - 2016-01-29 07:03:39 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:39 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:39 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:39 --> URI Class Initialized
INFO - 2016-01-29 07:03:39 --> Router Class Initialized
INFO - 2016-01-29 07:03:39 --> Output Class Initialized
INFO - 2016-01-29 07:03:39 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:39 --> Input Class Initialized
INFO - 2016-01-29 07:03:39 --> Language Class Initialized
INFO - 2016-01-29 07:03:39 --> Loader Class Initialized
INFO - 2016-01-29 07:03:39 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:39 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:39 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:39 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:40 --> Controller Class Initialized
INFO - 2016-01-29 07:03:40 --> Model Class Initialized
INFO - 2016-01-29 07:03:40 --> Model Class Initialized
INFO - 2016-01-29 07:03:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:40 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:40 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:40 --> Total execution time: 1.0995
INFO - 2016-01-29 07:03:41 --> Config Class Initialized
INFO - 2016-01-29 07:03:41 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:41 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:41 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:41 --> URI Class Initialized
INFO - 2016-01-29 07:03:41 --> Router Class Initialized
INFO - 2016-01-29 07:03:41 --> Output Class Initialized
INFO - 2016-01-29 07:03:41 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:41 --> Input Class Initialized
INFO - 2016-01-29 07:03:41 --> Language Class Initialized
INFO - 2016-01-29 07:03:41 --> Loader Class Initialized
INFO - 2016-01-29 07:03:41 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:41 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:41 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:41 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:42 --> Controller Class Initialized
INFO - 2016-01-29 07:03:42 --> Model Class Initialized
INFO - 2016-01-29 07:03:42 --> Model Class Initialized
INFO - 2016-01-29 07:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:42 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:42 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:42 --> Total execution time: 1.1056
INFO - 2016-01-29 07:03:44 --> Config Class Initialized
INFO - 2016-01-29 07:03:44 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:44 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:44 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:44 --> URI Class Initialized
INFO - 2016-01-29 07:03:44 --> Router Class Initialized
INFO - 2016-01-29 07:03:44 --> Output Class Initialized
INFO - 2016-01-29 07:03:44 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:44 --> Input Class Initialized
INFO - 2016-01-29 07:03:44 --> Language Class Initialized
INFO - 2016-01-29 07:03:44 --> Loader Class Initialized
INFO - 2016-01-29 07:03:44 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:44 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:44 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:44 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:45 --> Controller Class Initialized
INFO - 2016-01-29 07:03:45 --> Model Class Initialized
INFO - 2016-01-29 07:03:45 --> Model Class Initialized
INFO - 2016-01-29 07:03:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:45 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:45 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:45 --> Total execution time: 1.1169
INFO - 2016-01-29 07:03:47 --> Config Class Initialized
INFO - 2016-01-29 07:03:47 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:47 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:47 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:47 --> URI Class Initialized
INFO - 2016-01-29 07:03:47 --> Router Class Initialized
INFO - 2016-01-29 07:03:47 --> Output Class Initialized
INFO - 2016-01-29 07:03:47 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:47 --> Input Class Initialized
INFO - 2016-01-29 07:03:47 --> Language Class Initialized
INFO - 2016-01-29 07:03:47 --> Loader Class Initialized
INFO - 2016-01-29 07:03:47 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:47 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:47 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:47 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:48 --> Controller Class Initialized
INFO - 2016-01-29 07:03:48 --> Model Class Initialized
INFO - 2016-01-29 07:03:48 --> Model Class Initialized
INFO - 2016-01-29 07:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:48 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:48 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:48 --> Total execution time: 1.0707
INFO - 2016-01-29 07:03:49 --> Config Class Initialized
INFO - 2016-01-29 07:03:49 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:49 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:49 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:49 --> URI Class Initialized
INFO - 2016-01-29 07:03:49 --> Router Class Initialized
INFO - 2016-01-29 07:03:49 --> Output Class Initialized
INFO - 2016-01-29 07:03:49 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:49 --> Input Class Initialized
INFO - 2016-01-29 07:03:49 --> Language Class Initialized
INFO - 2016-01-29 07:03:49 --> Loader Class Initialized
INFO - 2016-01-29 07:03:49 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:49 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:49 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:49 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:50 --> Controller Class Initialized
INFO - 2016-01-29 07:03:50 --> Model Class Initialized
INFO - 2016-01-29 07:03:50 --> Model Class Initialized
INFO - 2016-01-29 07:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:50 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:50 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:50 --> Total execution time: 1.1318
INFO - 2016-01-29 07:03:52 --> Config Class Initialized
INFO - 2016-01-29 07:03:52 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:03:52 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:03:52 --> Utf8 Class Initialized
INFO - 2016-01-29 07:03:52 --> URI Class Initialized
INFO - 2016-01-29 07:03:52 --> Router Class Initialized
INFO - 2016-01-29 07:03:52 --> Output Class Initialized
INFO - 2016-01-29 07:03:52 --> Security Class Initialized
DEBUG - 2016-01-29 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:03:52 --> Input Class Initialized
INFO - 2016-01-29 07:03:52 --> Language Class Initialized
INFO - 2016-01-29 07:03:52 --> Loader Class Initialized
INFO - 2016-01-29 07:03:52 --> Helper loaded: url_helper
INFO - 2016-01-29 07:03:52 --> Helper loaded: file_helper
INFO - 2016-01-29 07:03:52 --> Helper loaded: date_helper
INFO - 2016-01-29 07:03:52 --> Database Driver Class Initialized
INFO - 2016-01-29 07:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:03:53 --> Controller Class Initialized
INFO - 2016-01-29 07:03:53 --> Model Class Initialized
INFO - 2016-01-29 07:03:53 --> Model Class Initialized
INFO - 2016-01-29 07:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:03:53 --> Pagination Class Initialized
INFO - 2016-01-29 07:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:03:53 --> Final output sent to browser
DEBUG - 2016-01-29 07:03:53 --> Total execution time: 1.0879
INFO - 2016-01-29 07:04:18 --> Config Class Initialized
INFO - 2016-01-29 07:04:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:18 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:18 --> URI Class Initialized
DEBUG - 2016-01-29 07:04:18 --> No URI present. Default controller set.
INFO - 2016-01-29 07:04:18 --> Router Class Initialized
INFO - 2016-01-29 07:04:18 --> Output Class Initialized
INFO - 2016-01-29 07:04:18 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:18 --> Input Class Initialized
INFO - 2016-01-29 07:04:18 --> Language Class Initialized
INFO - 2016-01-29 07:04:18 --> Loader Class Initialized
INFO - 2016-01-29 07:04:18 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:18 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:18 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:18 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:19 --> Controller Class Initialized
INFO - 2016-01-29 07:04:19 --> Model Class Initialized
INFO - 2016-01-29 07:04:19 --> Model Class Initialized
INFO - 2016-01-29 07:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:19 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:04:19 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:19 --> Total execution time: 1.1109
INFO - 2016-01-29 07:04:23 --> Config Class Initialized
INFO - 2016-01-29 07:04:23 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:23 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:23 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:23 --> URI Class Initialized
INFO - 2016-01-29 07:04:23 --> Router Class Initialized
INFO - 2016-01-29 07:04:23 --> Output Class Initialized
INFO - 2016-01-29 07:04:23 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:23 --> Input Class Initialized
INFO - 2016-01-29 07:04:23 --> Language Class Initialized
INFO - 2016-01-29 07:04:23 --> Loader Class Initialized
INFO - 2016-01-29 07:04:23 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:23 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:23 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:23 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:24 --> Controller Class Initialized
INFO - 2016-01-29 07:04:24 --> Model Class Initialized
INFO - 2016-01-29 07:04:24 --> Model Class Initialized
INFO - 2016-01-29 07:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:24 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:24 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:24 --> Total execution time: 1.1146
INFO - 2016-01-29 07:04:33 --> Config Class Initialized
INFO - 2016-01-29 07:04:33 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:33 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:33 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:33 --> URI Class Initialized
INFO - 2016-01-29 07:04:33 --> Router Class Initialized
INFO - 2016-01-29 07:04:33 --> Output Class Initialized
INFO - 2016-01-29 07:04:33 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:33 --> Input Class Initialized
INFO - 2016-01-29 07:04:33 --> Language Class Initialized
INFO - 2016-01-29 07:04:33 --> Loader Class Initialized
INFO - 2016-01-29 07:04:33 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:33 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:33 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:33 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:34 --> Controller Class Initialized
INFO - 2016-01-29 07:04:34 --> Model Class Initialized
INFO - 2016-01-29 07:04:34 --> Model Class Initialized
INFO - 2016-01-29 07:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:34 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:34 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:34 --> Total execution time: 1.1053
INFO - 2016-01-29 07:04:36 --> Config Class Initialized
INFO - 2016-01-29 07:04:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:36 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:36 --> URI Class Initialized
INFO - 2016-01-29 07:04:36 --> Router Class Initialized
INFO - 2016-01-29 07:04:36 --> Output Class Initialized
INFO - 2016-01-29 07:04:36 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:36 --> Input Class Initialized
INFO - 2016-01-29 07:04:36 --> Language Class Initialized
INFO - 2016-01-29 07:04:36 --> Loader Class Initialized
INFO - 2016-01-29 07:04:36 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:36 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:36 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:36 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:37 --> Controller Class Initialized
INFO - 2016-01-29 07:04:37 --> Model Class Initialized
INFO - 2016-01-29 07:04:37 --> Model Class Initialized
INFO - 2016-01-29 07:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:37 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:37 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:37 --> Total execution time: 1.1162
INFO - 2016-01-29 07:04:38 --> Config Class Initialized
INFO - 2016-01-29 07:04:38 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:38 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:38 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:38 --> URI Class Initialized
INFO - 2016-01-29 07:04:38 --> Router Class Initialized
INFO - 2016-01-29 07:04:38 --> Output Class Initialized
INFO - 2016-01-29 07:04:38 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:38 --> Input Class Initialized
INFO - 2016-01-29 07:04:38 --> Language Class Initialized
INFO - 2016-01-29 07:04:38 --> Loader Class Initialized
INFO - 2016-01-29 07:04:38 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:38 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:38 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:38 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:39 --> Controller Class Initialized
INFO - 2016-01-29 07:04:39 --> Model Class Initialized
INFO - 2016-01-29 07:04:39 --> Model Class Initialized
INFO - 2016-01-29 07:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:39 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:40 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:40 --> Total execution time: 1.1229
INFO - 2016-01-29 07:04:41 --> Config Class Initialized
INFO - 2016-01-29 07:04:41 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:41 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:41 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:41 --> URI Class Initialized
INFO - 2016-01-29 07:04:41 --> Router Class Initialized
INFO - 2016-01-29 07:04:41 --> Output Class Initialized
INFO - 2016-01-29 07:04:41 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:41 --> Input Class Initialized
INFO - 2016-01-29 07:04:41 --> Language Class Initialized
INFO - 2016-01-29 07:04:41 --> Loader Class Initialized
INFO - 2016-01-29 07:04:41 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:41 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:41 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:41 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:42 --> Controller Class Initialized
INFO - 2016-01-29 07:04:42 --> Model Class Initialized
INFO - 2016-01-29 07:04:42 --> Model Class Initialized
INFO - 2016-01-29 07:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:42 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:42 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:42 --> Total execution time: 1.1145
INFO - 2016-01-29 07:04:43 --> Config Class Initialized
INFO - 2016-01-29 07:04:43 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:43 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:43 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:43 --> URI Class Initialized
INFO - 2016-01-29 07:04:43 --> Router Class Initialized
INFO - 2016-01-29 07:04:43 --> Output Class Initialized
INFO - 2016-01-29 07:04:43 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:43 --> Input Class Initialized
INFO - 2016-01-29 07:04:43 --> Language Class Initialized
INFO - 2016-01-29 07:04:43 --> Loader Class Initialized
INFO - 2016-01-29 07:04:43 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:43 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:43 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:43 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:44 --> Controller Class Initialized
INFO - 2016-01-29 07:04:44 --> Model Class Initialized
INFO - 2016-01-29 07:04:44 --> Model Class Initialized
INFO - 2016-01-29 07:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:44 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:44 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:44 --> Total execution time: 1.1283
INFO - 2016-01-29 07:04:46 --> Config Class Initialized
INFO - 2016-01-29 07:04:46 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:04:46 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:04:46 --> Utf8 Class Initialized
INFO - 2016-01-29 07:04:46 --> URI Class Initialized
INFO - 2016-01-29 07:04:46 --> Router Class Initialized
INFO - 2016-01-29 07:04:46 --> Output Class Initialized
INFO - 2016-01-29 07:04:46 --> Security Class Initialized
DEBUG - 2016-01-29 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:04:46 --> Input Class Initialized
INFO - 2016-01-29 07:04:46 --> Language Class Initialized
INFO - 2016-01-29 07:04:46 --> Loader Class Initialized
INFO - 2016-01-29 07:04:46 --> Helper loaded: url_helper
INFO - 2016-01-29 07:04:46 --> Helper loaded: file_helper
INFO - 2016-01-29 07:04:46 --> Helper loaded: date_helper
INFO - 2016-01-29 07:04:46 --> Database Driver Class Initialized
INFO - 2016-01-29 07:04:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:04:47 --> Controller Class Initialized
INFO - 2016-01-29 07:04:47 --> Model Class Initialized
INFO - 2016-01-29 07:04:47 --> Model Class Initialized
INFO - 2016-01-29 07:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:04:47 --> Pagination Class Initialized
INFO - 2016-01-29 07:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:04:47 --> Final output sent to browser
DEBUG - 2016-01-29 07:04:47 --> Total execution time: 1.1383
INFO - 2016-01-29 07:06:11 --> Config Class Initialized
INFO - 2016-01-29 07:06:11 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:11 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:11 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:11 --> URI Class Initialized
DEBUG - 2016-01-29 07:06:11 --> No URI present. Default controller set.
INFO - 2016-01-29 07:06:11 --> Router Class Initialized
INFO - 2016-01-29 07:06:11 --> Output Class Initialized
INFO - 2016-01-29 07:06:11 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:11 --> Input Class Initialized
INFO - 2016-01-29 07:06:11 --> Language Class Initialized
INFO - 2016-01-29 07:06:11 --> Loader Class Initialized
INFO - 2016-01-29 07:06:11 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:11 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:11 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:11 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:12 --> Controller Class Initialized
INFO - 2016-01-29 07:06:12 --> Model Class Initialized
INFO - 2016-01-29 07:06:12 --> Model Class Initialized
INFO - 2016-01-29 07:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:12 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:06:12 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:12 --> Total execution time: 1.1129
INFO - 2016-01-29 07:06:15 --> Config Class Initialized
INFO - 2016-01-29 07:06:15 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:15 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:15 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:15 --> URI Class Initialized
INFO - 2016-01-29 07:06:15 --> Router Class Initialized
INFO - 2016-01-29 07:06:15 --> Output Class Initialized
INFO - 2016-01-29 07:06:15 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:15 --> Input Class Initialized
INFO - 2016-01-29 07:06:15 --> Language Class Initialized
INFO - 2016-01-29 07:06:15 --> Loader Class Initialized
INFO - 2016-01-29 07:06:15 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:15 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:15 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:15 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:16 --> Controller Class Initialized
INFO - 2016-01-29 07:06:16 --> Model Class Initialized
INFO - 2016-01-29 07:06:16 --> Model Class Initialized
INFO - 2016-01-29 07:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:16 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:16 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:16 --> Total execution time: 1.0896
INFO - 2016-01-29 07:06:18 --> Config Class Initialized
INFO - 2016-01-29 07:06:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:18 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:18 --> URI Class Initialized
INFO - 2016-01-29 07:06:18 --> Router Class Initialized
INFO - 2016-01-29 07:06:18 --> Output Class Initialized
INFO - 2016-01-29 07:06:18 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:18 --> Input Class Initialized
INFO - 2016-01-29 07:06:18 --> Language Class Initialized
INFO - 2016-01-29 07:06:18 --> Loader Class Initialized
INFO - 2016-01-29 07:06:18 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:18 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:18 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:18 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:19 --> Controller Class Initialized
INFO - 2016-01-29 07:06:19 --> Model Class Initialized
INFO - 2016-01-29 07:06:19 --> Model Class Initialized
INFO - 2016-01-29 07:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:19 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:19 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:19 --> Total execution time: 1.1072
INFO - 2016-01-29 07:06:20 --> Config Class Initialized
INFO - 2016-01-29 07:06:20 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:20 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:20 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:20 --> URI Class Initialized
INFO - 2016-01-29 07:06:20 --> Router Class Initialized
INFO - 2016-01-29 07:06:20 --> Output Class Initialized
INFO - 2016-01-29 07:06:20 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:20 --> Input Class Initialized
INFO - 2016-01-29 07:06:20 --> Language Class Initialized
INFO - 2016-01-29 07:06:20 --> Loader Class Initialized
INFO - 2016-01-29 07:06:20 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:21 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:21 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:21 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:22 --> Controller Class Initialized
INFO - 2016-01-29 07:06:22 --> Model Class Initialized
INFO - 2016-01-29 07:06:22 --> Model Class Initialized
INFO - 2016-01-29 07:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:22 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:22 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:22 --> Total execution time: 1.1078
INFO - 2016-01-29 07:06:23 --> Config Class Initialized
INFO - 2016-01-29 07:06:23 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:23 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:23 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:23 --> URI Class Initialized
INFO - 2016-01-29 07:06:23 --> Router Class Initialized
INFO - 2016-01-29 07:06:23 --> Output Class Initialized
INFO - 2016-01-29 07:06:23 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:23 --> Input Class Initialized
INFO - 2016-01-29 07:06:23 --> Language Class Initialized
INFO - 2016-01-29 07:06:23 --> Loader Class Initialized
INFO - 2016-01-29 07:06:23 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:23 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:23 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:23 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:24 --> Controller Class Initialized
INFO - 2016-01-29 07:06:24 --> Model Class Initialized
INFO - 2016-01-29 07:06:24 --> Model Class Initialized
INFO - 2016-01-29 07:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:24 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:24 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:24 --> Total execution time: 1.1007
INFO - 2016-01-29 07:06:25 --> Config Class Initialized
INFO - 2016-01-29 07:06:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:25 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:25 --> URI Class Initialized
INFO - 2016-01-29 07:06:25 --> Router Class Initialized
INFO - 2016-01-29 07:06:25 --> Output Class Initialized
INFO - 2016-01-29 07:06:25 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:25 --> Input Class Initialized
INFO - 2016-01-29 07:06:25 --> Language Class Initialized
INFO - 2016-01-29 07:06:25 --> Loader Class Initialized
INFO - 2016-01-29 07:06:25 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:25 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:25 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:25 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:26 --> Controller Class Initialized
INFO - 2016-01-29 07:06:26 --> Model Class Initialized
INFO - 2016-01-29 07:06:26 --> Model Class Initialized
INFO - 2016-01-29 07:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:26 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:26 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:26 --> Total execution time: 1.1156
INFO - 2016-01-29 07:06:28 --> Config Class Initialized
INFO - 2016-01-29 07:06:28 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:28 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:28 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:28 --> URI Class Initialized
INFO - 2016-01-29 07:06:28 --> Router Class Initialized
INFO - 2016-01-29 07:06:28 --> Output Class Initialized
INFO - 2016-01-29 07:06:28 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:28 --> Input Class Initialized
INFO - 2016-01-29 07:06:28 --> Language Class Initialized
INFO - 2016-01-29 07:06:28 --> Loader Class Initialized
INFO - 2016-01-29 07:06:28 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:28 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:28 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:28 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:29 --> Controller Class Initialized
INFO - 2016-01-29 07:06:29 --> Model Class Initialized
INFO - 2016-01-29 07:06:29 --> Model Class Initialized
INFO - 2016-01-29 07:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:29 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:29 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:29 --> Total execution time: 1.0753
INFO - 2016-01-29 07:06:31 --> Config Class Initialized
INFO - 2016-01-29 07:06:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:31 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:31 --> URI Class Initialized
INFO - 2016-01-29 07:06:31 --> Router Class Initialized
INFO - 2016-01-29 07:06:31 --> Output Class Initialized
INFO - 2016-01-29 07:06:31 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:31 --> Input Class Initialized
INFO - 2016-01-29 07:06:31 --> Language Class Initialized
INFO - 2016-01-29 07:06:31 --> Loader Class Initialized
INFO - 2016-01-29 07:06:31 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:31 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:31 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:31 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:32 --> Controller Class Initialized
INFO - 2016-01-29 07:06:32 --> Model Class Initialized
INFO - 2016-01-29 07:06:32 --> Model Class Initialized
INFO - 2016-01-29 07:06:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:32 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:32 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:32 --> Total execution time: 1.1131
INFO - 2016-01-29 07:06:53 --> Config Class Initialized
INFO - 2016-01-29 07:06:53 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:53 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:53 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:53 --> URI Class Initialized
DEBUG - 2016-01-29 07:06:53 --> No URI present. Default controller set.
INFO - 2016-01-29 07:06:53 --> Router Class Initialized
INFO - 2016-01-29 07:06:53 --> Output Class Initialized
INFO - 2016-01-29 07:06:53 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:53 --> Input Class Initialized
INFO - 2016-01-29 07:06:53 --> Language Class Initialized
INFO - 2016-01-29 07:06:53 --> Loader Class Initialized
INFO - 2016-01-29 07:06:53 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:53 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:53 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:53 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:54 --> Controller Class Initialized
INFO - 2016-01-29 07:06:54 --> Model Class Initialized
INFO - 2016-01-29 07:06:54 --> Model Class Initialized
INFO - 2016-01-29 07:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:54 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:06:54 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:54 --> Total execution time: 1.0800
INFO - 2016-01-29 07:06:57 --> Config Class Initialized
INFO - 2016-01-29 07:06:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:57 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:57 --> URI Class Initialized
INFO - 2016-01-29 07:06:57 --> Router Class Initialized
INFO - 2016-01-29 07:06:57 --> Output Class Initialized
INFO - 2016-01-29 07:06:57 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:57 --> Input Class Initialized
INFO - 2016-01-29 07:06:57 --> Language Class Initialized
INFO - 2016-01-29 07:06:57 --> Loader Class Initialized
INFO - 2016-01-29 07:06:57 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:57 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:57 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:57 --> Database Driver Class Initialized
INFO - 2016-01-29 07:06:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:06:58 --> Controller Class Initialized
INFO - 2016-01-29 07:06:58 --> Model Class Initialized
INFO - 2016-01-29 07:06:58 --> Model Class Initialized
INFO - 2016-01-29 07:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:06:58 --> Pagination Class Initialized
INFO - 2016-01-29 07:06:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:06:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:06:58 --> Final output sent to browser
DEBUG - 2016-01-29 07:06:58 --> Total execution time: 1.0808
INFO - 2016-01-29 07:06:59 --> Config Class Initialized
INFO - 2016-01-29 07:06:59 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:06:59 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:06:59 --> Utf8 Class Initialized
INFO - 2016-01-29 07:06:59 --> URI Class Initialized
INFO - 2016-01-29 07:06:59 --> Router Class Initialized
INFO - 2016-01-29 07:06:59 --> Output Class Initialized
INFO - 2016-01-29 07:06:59 --> Security Class Initialized
DEBUG - 2016-01-29 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:06:59 --> Input Class Initialized
INFO - 2016-01-29 07:06:59 --> Language Class Initialized
INFO - 2016-01-29 07:06:59 --> Loader Class Initialized
INFO - 2016-01-29 07:06:59 --> Helper loaded: url_helper
INFO - 2016-01-29 07:06:59 --> Helper loaded: file_helper
INFO - 2016-01-29 07:06:59 --> Helper loaded: date_helper
INFO - 2016-01-29 07:06:59 --> Database Driver Class Initialized
INFO - 2016-01-29 07:07:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:07:00 --> Controller Class Initialized
INFO - 2016-01-29 07:07:00 --> Model Class Initialized
INFO - 2016-01-29 07:07:00 --> Model Class Initialized
INFO - 2016-01-29 07:07:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:07:00 --> Pagination Class Initialized
INFO - 2016-01-29 07:07:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:07:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:07:00 --> Final output sent to browser
DEBUG - 2016-01-29 07:07:00 --> Total execution time: 1.1106
INFO - 2016-01-29 07:07:01 --> Config Class Initialized
INFO - 2016-01-29 07:07:01 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:07:01 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:07:01 --> Utf8 Class Initialized
INFO - 2016-01-29 07:07:01 --> URI Class Initialized
INFO - 2016-01-29 07:07:01 --> Router Class Initialized
INFO - 2016-01-29 07:07:01 --> Output Class Initialized
INFO - 2016-01-29 07:07:01 --> Security Class Initialized
DEBUG - 2016-01-29 07:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:07:01 --> Input Class Initialized
INFO - 2016-01-29 07:07:01 --> Language Class Initialized
INFO - 2016-01-29 07:07:01 --> Loader Class Initialized
INFO - 2016-01-29 07:07:01 --> Helper loaded: url_helper
INFO - 2016-01-29 07:07:01 --> Helper loaded: file_helper
INFO - 2016-01-29 07:07:01 --> Helper loaded: date_helper
INFO - 2016-01-29 07:07:01 --> Database Driver Class Initialized
INFO - 2016-01-29 07:07:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:07:02 --> Controller Class Initialized
INFO - 2016-01-29 07:07:02 --> Model Class Initialized
INFO - 2016-01-29 07:07:02 --> Model Class Initialized
INFO - 2016-01-29 07:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:07:02 --> Pagination Class Initialized
INFO - 2016-01-29 07:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:07:02 --> Final output sent to browser
DEBUG - 2016-01-29 07:07:02 --> Total execution time: 1.1304
INFO - 2016-01-29 07:08:49 --> Config Class Initialized
INFO - 2016-01-29 07:08:49 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:08:49 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:08:49 --> Utf8 Class Initialized
INFO - 2016-01-29 07:08:49 --> URI Class Initialized
INFO - 2016-01-29 07:08:49 --> Router Class Initialized
INFO - 2016-01-29 07:08:49 --> Output Class Initialized
INFO - 2016-01-29 07:08:49 --> Security Class Initialized
DEBUG - 2016-01-29 07:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:08:49 --> Input Class Initialized
INFO - 2016-01-29 07:08:49 --> Language Class Initialized
INFO - 2016-01-29 07:08:49 --> Loader Class Initialized
INFO - 2016-01-29 07:08:49 --> Helper loaded: url_helper
INFO - 2016-01-29 07:08:49 --> Helper loaded: file_helper
INFO - 2016-01-29 07:08:49 --> Helper loaded: date_helper
INFO - 2016-01-29 07:08:49 --> Database Driver Class Initialized
INFO - 2016-01-29 07:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:08:50 --> Controller Class Initialized
INFO - 2016-01-29 07:08:50 --> Model Class Initialized
INFO - 2016-01-29 07:08:50 --> Model Class Initialized
INFO - 2016-01-29 07:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:08:50 --> Pagination Class Initialized
INFO - 2016-01-29 07:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:08:50 --> Final output sent to browser
DEBUG - 2016-01-29 07:08:50 --> Total execution time: 1.1055
INFO - 2016-01-29 07:08:51 --> Config Class Initialized
INFO - 2016-01-29 07:08:51 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:08:51 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:08:51 --> Utf8 Class Initialized
INFO - 2016-01-29 07:08:51 --> URI Class Initialized
DEBUG - 2016-01-29 07:08:51 --> No URI present. Default controller set.
INFO - 2016-01-29 07:08:51 --> Router Class Initialized
INFO - 2016-01-29 07:08:51 --> Output Class Initialized
INFO - 2016-01-29 07:08:51 --> Security Class Initialized
DEBUG - 2016-01-29 07:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:08:51 --> Input Class Initialized
INFO - 2016-01-29 07:08:51 --> Language Class Initialized
INFO - 2016-01-29 07:08:51 --> Loader Class Initialized
INFO - 2016-01-29 07:08:51 --> Helper loaded: url_helper
INFO - 2016-01-29 07:08:51 --> Helper loaded: file_helper
INFO - 2016-01-29 07:08:51 --> Helper loaded: date_helper
INFO - 2016-01-29 07:08:51 --> Database Driver Class Initialized
INFO - 2016-01-29 07:08:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:08:52 --> Controller Class Initialized
INFO - 2016-01-29 07:08:52 --> Model Class Initialized
INFO - 2016-01-29 07:08:52 --> Model Class Initialized
INFO - 2016-01-29 07:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:08:52 --> Pagination Class Initialized
INFO - 2016-01-29 07:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:08:52 --> Final output sent to browser
DEBUG - 2016-01-29 07:08:52 --> Total execution time: 1.0724
INFO - 2016-01-29 07:08:54 --> Config Class Initialized
INFO - 2016-01-29 07:08:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:08:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:08:54 --> Utf8 Class Initialized
INFO - 2016-01-29 07:08:54 --> URI Class Initialized
INFO - 2016-01-29 07:08:54 --> Router Class Initialized
INFO - 2016-01-29 07:08:54 --> Output Class Initialized
INFO - 2016-01-29 07:08:54 --> Security Class Initialized
DEBUG - 2016-01-29 07:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:08:54 --> Input Class Initialized
INFO - 2016-01-29 07:08:54 --> Language Class Initialized
INFO - 2016-01-29 07:08:54 --> Loader Class Initialized
INFO - 2016-01-29 07:08:54 --> Helper loaded: url_helper
INFO - 2016-01-29 07:08:54 --> Helper loaded: file_helper
INFO - 2016-01-29 07:08:54 --> Helper loaded: date_helper
INFO - 2016-01-29 07:08:54 --> Database Driver Class Initialized
INFO - 2016-01-29 07:08:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:08:55 --> Controller Class Initialized
INFO - 2016-01-29 07:08:55 --> Model Class Initialized
INFO - 2016-01-29 07:08:55 --> Model Class Initialized
INFO - 2016-01-29 07:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:08:55 --> Pagination Class Initialized
INFO - 2016-01-29 07:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:08:55 --> Final output sent to browser
DEBUG - 2016-01-29 07:08:55 --> Total execution time: 1.1180
INFO - 2016-01-29 07:08:57 --> Config Class Initialized
INFO - 2016-01-29 07:08:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:08:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:08:57 --> Utf8 Class Initialized
INFO - 2016-01-29 07:08:57 --> URI Class Initialized
INFO - 2016-01-29 07:08:57 --> Router Class Initialized
INFO - 2016-01-29 07:08:57 --> Output Class Initialized
INFO - 2016-01-29 07:08:57 --> Security Class Initialized
DEBUG - 2016-01-29 07:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:08:57 --> Input Class Initialized
INFO - 2016-01-29 07:08:57 --> Language Class Initialized
INFO - 2016-01-29 07:08:57 --> Loader Class Initialized
INFO - 2016-01-29 07:08:57 --> Helper loaded: url_helper
INFO - 2016-01-29 07:08:57 --> Helper loaded: file_helper
INFO - 2016-01-29 07:08:57 --> Helper loaded: date_helper
INFO - 2016-01-29 07:08:57 --> Database Driver Class Initialized
INFO - 2016-01-29 07:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:08:58 --> Controller Class Initialized
INFO - 2016-01-29 07:08:58 --> Model Class Initialized
INFO - 2016-01-29 07:08:58 --> Model Class Initialized
INFO - 2016-01-29 07:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:08:58 --> Pagination Class Initialized
INFO - 2016-01-29 07:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:08:58 --> Final output sent to browser
DEBUG - 2016-01-29 07:08:58 --> Total execution time: 1.0737
INFO - 2016-01-29 07:09:00 --> Config Class Initialized
INFO - 2016-01-29 07:09:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:09:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:09:00 --> Utf8 Class Initialized
INFO - 2016-01-29 07:09:00 --> URI Class Initialized
INFO - 2016-01-29 07:09:00 --> Router Class Initialized
INFO - 2016-01-29 07:09:00 --> Output Class Initialized
INFO - 2016-01-29 07:09:00 --> Security Class Initialized
DEBUG - 2016-01-29 07:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:09:00 --> Input Class Initialized
INFO - 2016-01-29 07:09:00 --> Language Class Initialized
INFO - 2016-01-29 07:09:00 --> Loader Class Initialized
INFO - 2016-01-29 07:09:00 --> Helper loaded: url_helper
INFO - 2016-01-29 07:09:00 --> Helper loaded: file_helper
INFO - 2016-01-29 07:09:00 --> Helper loaded: date_helper
INFO - 2016-01-29 07:09:00 --> Database Driver Class Initialized
INFO - 2016-01-29 07:09:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:09:01 --> Controller Class Initialized
INFO - 2016-01-29 07:09:01 --> Model Class Initialized
INFO - 2016-01-29 07:09:01 --> Model Class Initialized
INFO - 2016-01-29 07:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:09:01 --> Pagination Class Initialized
INFO - 2016-01-29 07:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:09:01 --> Final output sent to browser
DEBUG - 2016-01-29 07:09:01 --> Total execution time: 1.1043
INFO - 2016-01-29 07:09:09 --> Config Class Initialized
INFO - 2016-01-29 07:09:09 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:09:09 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:09:09 --> Utf8 Class Initialized
INFO - 2016-01-29 07:09:09 --> URI Class Initialized
INFO - 2016-01-29 07:09:09 --> Router Class Initialized
INFO - 2016-01-29 07:09:09 --> Output Class Initialized
INFO - 2016-01-29 07:09:09 --> Security Class Initialized
DEBUG - 2016-01-29 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:09:09 --> Input Class Initialized
INFO - 2016-01-29 07:09:09 --> Language Class Initialized
INFO - 2016-01-29 07:09:09 --> Loader Class Initialized
INFO - 2016-01-29 07:09:09 --> Helper loaded: url_helper
INFO - 2016-01-29 07:09:09 --> Helper loaded: file_helper
INFO - 2016-01-29 07:09:09 --> Helper loaded: date_helper
INFO - 2016-01-29 07:09:09 --> Database Driver Class Initialized
INFO - 2016-01-29 07:09:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:09:10 --> Controller Class Initialized
INFO - 2016-01-29 07:09:10 --> Model Class Initialized
INFO - 2016-01-29 07:09:10 --> Model Class Initialized
INFO - 2016-01-29 07:09:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:09:10 --> Pagination Class Initialized
INFO - 2016-01-29 07:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:09:10 --> Final output sent to browser
DEBUG - 2016-01-29 07:09:10 --> Total execution time: 1.1016
INFO - 2016-01-29 07:09:12 --> Config Class Initialized
INFO - 2016-01-29 07:09:12 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:09:12 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:09:12 --> Utf8 Class Initialized
INFO - 2016-01-29 07:09:12 --> URI Class Initialized
INFO - 2016-01-29 07:09:12 --> Router Class Initialized
INFO - 2016-01-29 07:09:12 --> Output Class Initialized
INFO - 2016-01-29 07:09:12 --> Security Class Initialized
DEBUG - 2016-01-29 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:09:12 --> Input Class Initialized
INFO - 2016-01-29 07:09:12 --> Language Class Initialized
INFO - 2016-01-29 07:09:12 --> Loader Class Initialized
INFO - 2016-01-29 07:09:12 --> Helper loaded: url_helper
INFO - 2016-01-29 07:09:12 --> Helper loaded: file_helper
INFO - 2016-01-29 07:09:12 --> Helper loaded: date_helper
INFO - 2016-01-29 07:09:12 --> Database Driver Class Initialized
INFO - 2016-01-29 07:09:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:09:13 --> Controller Class Initialized
INFO - 2016-01-29 07:09:13 --> Model Class Initialized
INFO - 2016-01-29 07:09:13 --> Model Class Initialized
INFO - 2016-01-29 07:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:09:13 --> Pagination Class Initialized
INFO - 2016-01-29 07:09:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:09:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:09:13 --> Final output sent to browser
DEBUG - 2016-01-29 07:09:13 --> Total execution time: 1.1276
INFO - 2016-01-29 07:12:59 --> Config Class Initialized
INFO - 2016-01-29 07:12:59 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:12:59 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:12:59 --> Utf8 Class Initialized
INFO - 2016-01-29 07:12:59 --> URI Class Initialized
DEBUG - 2016-01-29 07:12:59 --> No URI present. Default controller set.
INFO - 2016-01-29 07:12:59 --> Router Class Initialized
INFO - 2016-01-29 07:12:59 --> Output Class Initialized
INFO - 2016-01-29 07:12:59 --> Security Class Initialized
DEBUG - 2016-01-29 07:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:12:59 --> Input Class Initialized
INFO - 2016-01-29 07:12:59 --> Language Class Initialized
INFO - 2016-01-29 07:12:59 --> Loader Class Initialized
INFO - 2016-01-29 07:12:59 --> Helper loaded: url_helper
INFO - 2016-01-29 07:12:59 --> Helper loaded: file_helper
INFO - 2016-01-29 07:12:59 --> Helper loaded: date_helper
INFO - 2016-01-29 07:12:59 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:00 --> Controller Class Initialized
INFO - 2016-01-29 07:13:01 --> Model Class Initialized
INFO - 2016-01-29 07:13:01 --> Model Class Initialized
INFO - 2016-01-29 07:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:01 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:13:01 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:01 --> Total execution time: 1.1070
INFO - 2016-01-29 07:13:04 --> Config Class Initialized
INFO - 2016-01-29 07:13:04 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:04 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:04 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:04 --> URI Class Initialized
INFO - 2016-01-29 07:13:04 --> Router Class Initialized
INFO - 2016-01-29 07:13:04 --> Output Class Initialized
INFO - 2016-01-29 07:13:05 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:05 --> Input Class Initialized
INFO - 2016-01-29 07:13:05 --> Language Class Initialized
INFO - 2016-01-29 07:13:05 --> Loader Class Initialized
INFO - 2016-01-29 07:13:05 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:05 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:05 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:05 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:06 --> Controller Class Initialized
INFO - 2016-01-29 07:13:06 --> Model Class Initialized
INFO - 2016-01-29 07:13:06 --> Model Class Initialized
INFO - 2016-01-29 07:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:06 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 07:13:06 --> Severity: Notice --> Undefined variable: limit C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 131
ERROR - 2016-01-29 07:13:06 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 131
INFO - 2016-01-29 07:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:13:06 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:06 --> Total execution time: 1.1223
INFO - 2016-01-29 07:13:29 --> Config Class Initialized
INFO - 2016-01-29 07:13:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:29 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:29 --> URI Class Initialized
DEBUG - 2016-01-29 07:13:29 --> No URI present. Default controller set.
INFO - 2016-01-29 07:13:29 --> Router Class Initialized
INFO - 2016-01-29 07:13:29 --> Output Class Initialized
INFO - 2016-01-29 07:13:29 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:29 --> Input Class Initialized
INFO - 2016-01-29 07:13:29 --> Language Class Initialized
INFO - 2016-01-29 07:13:29 --> Loader Class Initialized
INFO - 2016-01-29 07:13:29 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:29 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:29 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:29 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:30 --> Controller Class Initialized
INFO - 2016-01-29 07:13:30 --> Model Class Initialized
INFO - 2016-01-29 07:13:30 --> Model Class Initialized
INFO - 2016-01-29 07:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:30 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 07:13:30 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:30 --> Total execution time: 1.1377
INFO - 2016-01-29 07:13:32 --> Config Class Initialized
INFO - 2016-01-29 07:13:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:32 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:32 --> URI Class Initialized
INFO - 2016-01-29 07:13:32 --> Router Class Initialized
INFO - 2016-01-29 07:13:32 --> Output Class Initialized
INFO - 2016-01-29 07:13:32 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:32 --> Input Class Initialized
INFO - 2016-01-29 07:13:32 --> Language Class Initialized
INFO - 2016-01-29 07:13:32 --> Loader Class Initialized
INFO - 2016-01-29 07:13:32 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:32 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:32 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:32 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:33 --> Controller Class Initialized
INFO - 2016-01-29 07:13:33 --> Model Class Initialized
INFO - 2016-01-29 07:13:33 --> Model Class Initialized
INFO - 2016-01-29 07:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:33 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:13:33 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:33 --> Total execution time: 1.1266
INFO - 2016-01-29 07:13:35 --> Config Class Initialized
INFO - 2016-01-29 07:13:35 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:35 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:35 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:35 --> URI Class Initialized
INFO - 2016-01-29 07:13:35 --> Router Class Initialized
INFO - 2016-01-29 07:13:35 --> Output Class Initialized
INFO - 2016-01-29 07:13:35 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:35 --> Input Class Initialized
INFO - 2016-01-29 07:13:35 --> Language Class Initialized
INFO - 2016-01-29 07:13:35 --> Loader Class Initialized
INFO - 2016-01-29 07:13:35 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:35 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:35 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:35 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:36 --> Controller Class Initialized
INFO - 2016-01-29 07:13:36 --> Model Class Initialized
INFO - 2016-01-29 07:13:36 --> Model Class Initialized
INFO - 2016-01-29 07:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:36 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:13:36 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:36 --> Total execution time: 1.1317
INFO - 2016-01-29 07:13:38 --> Config Class Initialized
INFO - 2016-01-29 07:13:38 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:38 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:38 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:38 --> URI Class Initialized
INFO - 2016-01-29 07:13:38 --> Router Class Initialized
INFO - 2016-01-29 07:13:38 --> Output Class Initialized
INFO - 2016-01-29 07:13:38 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:38 --> Input Class Initialized
INFO - 2016-01-29 07:13:38 --> Language Class Initialized
INFO - 2016-01-29 07:13:38 --> Loader Class Initialized
INFO - 2016-01-29 07:13:38 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:38 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:38 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:38 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:39 --> Controller Class Initialized
INFO - 2016-01-29 07:13:39 --> Model Class Initialized
INFO - 2016-01-29 07:13:39 --> Model Class Initialized
INFO - 2016-01-29 07:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:39 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:13:39 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:39 --> Total execution time: 1.1316
INFO - 2016-01-29 07:13:44 --> Config Class Initialized
INFO - 2016-01-29 07:13:44 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:44 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:44 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:44 --> URI Class Initialized
INFO - 2016-01-29 07:13:44 --> Router Class Initialized
INFO - 2016-01-29 07:13:44 --> Output Class Initialized
INFO - 2016-01-29 07:13:44 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:44 --> Input Class Initialized
INFO - 2016-01-29 07:13:44 --> Language Class Initialized
INFO - 2016-01-29 07:13:44 --> Loader Class Initialized
INFO - 2016-01-29 07:13:44 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:44 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:44 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:44 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:45 --> Controller Class Initialized
INFO - 2016-01-29 07:13:45 --> Model Class Initialized
INFO - 2016-01-29 07:13:45 --> Model Class Initialized
INFO - 2016-01-29 07:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:45 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:45 --> Helper loaded: text_helper
INFO - 2016-01-29 07:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 07:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 07:13:45 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:45 --> Total execution time: 1.2048
INFO - 2016-01-29 07:13:57 --> Config Class Initialized
INFO - 2016-01-29 07:13:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:13:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:13:57 --> Utf8 Class Initialized
INFO - 2016-01-29 07:13:57 --> URI Class Initialized
INFO - 2016-01-29 07:13:57 --> Router Class Initialized
INFO - 2016-01-29 07:13:57 --> Output Class Initialized
INFO - 2016-01-29 07:13:57 --> Security Class Initialized
DEBUG - 2016-01-29 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:13:57 --> Input Class Initialized
INFO - 2016-01-29 07:13:57 --> Language Class Initialized
INFO - 2016-01-29 07:13:57 --> Loader Class Initialized
INFO - 2016-01-29 07:13:57 --> Helper loaded: url_helper
INFO - 2016-01-29 07:13:57 --> Helper loaded: file_helper
INFO - 2016-01-29 07:13:57 --> Helper loaded: date_helper
INFO - 2016-01-29 07:13:57 --> Database Driver Class Initialized
INFO - 2016-01-29 07:13:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:13:59 --> Controller Class Initialized
INFO - 2016-01-29 07:13:59 --> Model Class Initialized
INFO - 2016-01-29 07:13:59 --> Model Class Initialized
INFO - 2016-01-29 07:13:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:13:59 --> Pagination Class Initialized
INFO - 2016-01-29 07:13:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:13:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:13:59 --> Final output sent to browser
DEBUG - 2016-01-29 07:13:59 --> Total execution time: 1.1337
INFO - 2016-01-29 07:14:00 --> Config Class Initialized
INFO - 2016-01-29 07:14:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:00 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:00 --> URI Class Initialized
INFO - 2016-01-29 07:14:00 --> Router Class Initialized
INFO - 2016-01-29 07:14:00 --> Output Class Initialized
INFO - 2016-01-29 07:14:00 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:00 --> Input Class Initialized
INFO - 2016-01-29 07:14:00 --> Language Class Initialized
INFO - 2016-01-29 07:14:00 --> Loader Class Initialized
INFO - 2016-01-29 07:14:00 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:00 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:00 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:00 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:01 --> Controller Class Initialized
INFO - 2016-01-29 07:14:01 --> Model Class Initialized
INFO - 2016-01-29 07:14:01 --> Model Class Initialized
INFO - 2016-01-29 07:14:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:01 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:01 --> Helper loaded: text_helper
INFO - 2016-01-29 07:14:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 07:14:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 07:14:01 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:01 --> Total execution time: 1.1777
INFO - 2016-01-29 07:14:03 --> Config Class Initialized
INFO - 2016-01-29 07:14:03 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:03 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:03 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:03 --> URI Class Initialized
INFO - 2016-01-29 07:14:03 --> Router Class Initialized
INFO - 2016-01-29 07:14:03 --> Output Class Initialized
INFO - 2016-01-29 07:14:03 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:03 --> Input Class Initialized
INFO - 2016-01-29 07:14:03 --> Language Class Initialized
INFO - 2016-01-29 07:14:03 --> Loader Class Initialized
INFO - 2016-01-29 07:14:03 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:03 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:03 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:03 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:04 --> Controller Class Initialized
INFO - 2016-01-29 07:14:04 --> Model Class Initialized
INFO - 2016-01-29 07:14:04 --> Model Class Initialized
INFO - 2016-01-29 07:14:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:04 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:04 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:04 --> Total execution time: 1.1315
INFO - 2016-01-29 07:14:07 --> Config Class Initialized
INFO - 2016-01-29 07:14:07 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:07 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:07 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:07 --> URI Class Initialized
INFO - 2016-01-29 07:14:07 --> Router Class Initialized
INFO - 2016-01-29 07:14:07 --> Output Class Initialized
INFO - 2016-01-29 07:14:07 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:07 --> Input Class Initialized
INFO - 2016-01-29 07:14:07 --> Language Class Initialized
INFO - 2016-01-29 07:14:07 --> Loader Class Initialized
INFO - 2016-01-29 07:14:07 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:07 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:07 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:07 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:08 --> Controller Class Initialized
INFO - 2016-01-29 07:14:08 --> Model Class Initialized
INFO - 2016-01-29 07:14:08 --> Model Class Initialized
INFO - 2016-01-29 07:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:08 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:08 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:08 --> Total execution time: 1.1525
INFO - 2016-01-29 07:14:10 --> Config Class Initialized
INFO - 2016-01-29 07:14:10 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:10 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:10 --> URI Class Initialized
INFO - 2016-01-29 07:14:10 --> Router Class Initialized
INFO - 2016-01-29 07:14:10 --> Output Class Initialized
INFO - 2016-01-29 07:14:10 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:10 --> Input Class Initialized
INFO - 2016-01-29 07:14:10 --> Language Class Initialized
INFO - 2016-01-29 07:14:10 --> Loader Class Initialized
INFO - 2016-01-29 07:14:10 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:10 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:10 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:10 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:11 --> Controller Class Initialized
INFO - 2016-01-29 07:14:11 --> Model Class Initialized
INFO - 2016-01-29 07:14:11 --> Model Class Initialized
INFO - 2016-01-29 07:14:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:11 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:11 --> Helper loaded: text_helper
INFO - 2016-01-29 07:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 07:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 07:14:11 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:11 --> Total execution time: 1.2086
INFO - 2016-01-29 07:14:15 --> Config Class Initialized
INFO - 2016-01-29 07:14:15 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:15 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:15 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:15 --> URI Class Initialized
INFO - 2016-01-29 07:14:15 --> Router Class Initialized
INFO - 2016-01-29 07:14:15 --> Output Class Initialized
INFO - 2016-01-29 07:14:15 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:15 --> Input Class Initialized
INFO - 2016-01-29 07:14:15 --> Language Class Initialized
INFO - 2016-01-29 07:14:15 --> Loader Class Initialized
INFO - 2016-01-29 07:14:15 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:15 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:15 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:15 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:16 --> Controller Class Initialized
INFO - 2016-01-29 07:14:16 --> Model Class Initialized
INFO - 2016-01-29 07:14:16 --> Model Class Initialized
INFO - 2016-01-29 07:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:16 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:16 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:16 --> Total execution time: 1.1337
INFO - 2016-01-29 07:14:21 --> Config Class Initialized
INFO - 2016-01-29 07:14:21 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:21 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:21 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:21 --> URI Class Initialized
INFO - 2016-01-29 07:14:21 --> Router Class Initialized
INFO - 2016-01-29 07:14:21 --> Output Class Initialized
INFO - 2016-01-29 07:14:21 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:21 --> Input Class Initialized
INFO - 2016-01-29 07:14:21 --> Language Class Initialized
INFO - 2016-01-29 07:14:21 --> Loader Class Initialized
INFO - 2016-01-29 07:14:21 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:21 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:21 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:21 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:23 --> Controller Class Initialized
INFO - 2016-01-29 07:14:23 --> Model Class Initialized
INFO - 2016-01-29 07:14:23 --> Model Class Initialized
INFO - 2016-01-29 07:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:23 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:23 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:23 --> Total execution time: 1.1395
INFO - 2016-01-29 07:14:26 --> Config Class Initialized
INFO - 2016-01-29 07:14:26 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:26 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:26 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:26 --> URI Class Initialized
INFO - 2016-01-29 07:14:26 --> Router Class Initialized
INFO - 2016-01-29 07:14:26 --> Output Class Initialized
INFO - 2016-01-29 07:14:26 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:26 --> Input Class Initialized
INFO - 2016-01-29 07:14:26 --> Language Class Initialized
INFO - 2016-01-29 07:14:26 --> Loader Class Initialized
INFO - 2016-01-29 07:14:26 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:26 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:26 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:26 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:27 --> Controller Class Initialized
INFO - 2016-01-29 07:14:27 --> Model Class Initialized
INFO - 2016-01-29 07:14:27 --> Model Class Initialized
INFO - 2016-01-29 07:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:27 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:27 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:27 --> Total execution time: 1.1423
INFO - 2016-01-29 07:14:30 --> Config Class Initialized
INFO - 2016-01-29 07:14:30 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:30 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:30 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:30 --> URI Class Initialized
INFO - 2016-01-29 07:14:30 --> Router Class Initialized
INFO - 2016-01-29 07:14:30 --> Output Class Initialized
INFO - 2016-01-29 07:14:30 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:30 --> Input Class Initialized
INFO - 2016-01-29 07:14:30 --> Language Class Initialized
INFO - 2016-01-29 07:14:30 --> Loader Class Initialized
INFO - 2016-01-29 07:14:30 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:30 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:30 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:30 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:31 --> Controller Class Initialized
INFO - 2016-01-29 07:14:31 --> Model Class Initialized
INFO - 2016-01-29 07:14:31 --> Model Class Initialized
INFO - 2016-01-29 07:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:31 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:31 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:31 --> Total execution time: 1.1102
INFO - 2016-01-29 07:14:33 --> Config Class Initialized
INFO - 2016-01-29 07:14:33 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:33 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:33 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:33 --> URI Class Initialized
INFO - 2016-01-29 07:14:33 --> Router Class Initialized
INFO - 2016-01-29 07:14:33 --> Output Class Initialized
INFO - 2016-01-29 07:14:33 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:33 --> Input Class Initialized
INFO - 2016-01-29 07:14:33 --> Language Class Initialized
INFO - 2016-01-29 07:14:33 --> Loader Class Initialized
INFO - 2016-01-29 07:14:33 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:33 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:33 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:33 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:34 --> Controller Class Initialized
INFO - 2016-01-29 07:14:34 --> Model Class Initialized
INFO - 2016-01-29 07:14:34 --> Model Class Initialized
INFO - 2016-01-29 07:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:34 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:34 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:34 --> Total execution time: 1.1536
INFO - 2016-01-29 07:14:36 --> Config Class Initialized
INFO - 2016-01-29 07:14:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 07:14:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 07:14:36 --> Utf8 Class Initialized
INFO - 2016-01-29 07:14:36 --> URI Class Initialized
INFO - 2016-01-29 07:14:36 --> Router Class Initialized
INFO - 2016-01-29 07:14:36 --> Output Class Initialized
INFO - 2016-01-29 07:14:36 --> Security Class Initialized
DEBUG - 2016-01-29 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 07:14:36 --> Input Class Initialized
INFO - 2016-01-29 07:14:36 --> Language Class Initialized
INFO - 2016-01-29 07:14:36 --> Loader Class Initialized
INFO - 2016-01-29 07:14:36 --> Helper loaded: url_helper
INFO - 2016-01-29 07:14:36 --> Helper loaded: file_helper
INFO - 2016-01-29 07:14:36 --> Helper loaded: date_helper
INFO - 2016-01-29 07:14:36 --> Database Driver Class Initialized
INFO - 2016-01-29 07:14:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 07:14:37 --> Controller Class Initialized
INFO - 2016-01-29 07:14:37 --> Model Class Initialized
INFO - 2016-01-29 07:14:37 --> Model Class Initialized
INFO - 2016-01-29 07:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 07:14:37 --> Pagination Class Initialized
INFO - 2016-01-29 07:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 07:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-01-29 07:14:37 --> Final output sent to browser
DEBUG - 2016-01-29 07:14:37 --> Total execution time: 1.1152
INFO - 2016-01-29 08:55:57 --> Config Class Initialized
INFO - 2016-01-29 08:55:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 08:55:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 08:55:57 --> Utf8 Class Initialized
INFO - 2016-01-29 08:55:57 --> URI Class Initialized
DEBUG - 2016-01-29 08:55:57 --> No URI present. Default controller set.
INFO - 2016-01-29 08:55:57 --> Router Class Initialized
INFO - 2016-01-29 08:55:57 --> Output Class Initialized
INFO - 2016-01-29 08:55:57 --> Security Class Initialized
DEBUG - 2016-01-29 08:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 08:55:57 --> Input Class Initialized
INFO - 2016-01-29 08:55:57 --> Language Class Initialized
INFO - 2016-01-29 08:55:57 --> Loader Class Initialized
INFO - 2016-01-29 08:55:57 --> Helper loaded: url_helper
INFO - 2016-01-29 08:55:57 --> Helper loaded: file_helper
INFO - 2016-01-29 08:55:57 --> Helper loaded: date_helper
INFO - 2016-01-29 08:55:57 --> Database Driver Class Initialized
INFO - 2016-01-29 08:55:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 08:55:58 --> Controller Class Initialized
INFO - 2016-01-29 08:55:58 --> Model Class Initialized
INFO - 2016-01-29 08:55:58 --> Model Class Initialized
INFO - 2016-01-29 08:55:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 08:55:58 --> Pagination Class Initialized
INFO - 2016-01-29 08:55:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 08:55:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 08:55:58 --> Final output sent to browser
DEBUG - 2016-01-29 08:55:58 --> Total execution time: 1.1432
INFO - 2016-01-29 09:00:25 --> Config Class Initialized
INFO - 2016-01-29 09:00:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:00:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:00:25 --> Utf8 Class Initialized
INFO - 2016-01-29 09:00:25 --> URI Class Initialized
INFO - 2016-01-29 09:00:25 --> Router Class Initialized
INFO - 2016-01-29 09:00:25 --> Output Class Initialized
INFO - 2016-01-29 09:00:25 --> Security Class Initialized
DEBUG - 2016-01-29 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:00:25 --> Input Class Initialized
INFO - 2016-01-29 09:00:25 --> Language Class Initialized
INFO - 2016-01-29 09:00:25 --> Loader Class Initialized
INFO - 2016-01-29 09:00:25 --> Helper loaded: url_helper
INFO - 2016-01-29 09:00:25 --> Helper loaded: file_helper
INFO - 2016-01-29 09:00:25 --> Helper loaded: date_helper
INFO - 2016-01-29 09:00:25 --> Database Driver Class Initialized
INFO - 2016-01-29 09:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:00:26 --> Controller Class Initialized
INFO - 2016-01-29 09:00:26 --> Model Class Initialized
INFO - 2016-01-29 09:00:26 --> Model Class Initialized
INFO - 2016-01-29 09:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:00:26 --> Pagination Class Initialized
INFO - 2016-01-29 09:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:00:26 --> Helper loaded: text_helper
INFO - 2016-01-29 09:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:00:26 --> Final output sent to browser
DEBUG - 2016-01-29 09:00:26 --> Total execution time: 1.1534
INFO - 2016-01-29 09:01:32 --> Config Class Initialized
INFO - 2016-01-29 09:01:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:01:32 --> Utf8 Class Initialized
INFO - 2016-01-29 09:01:32 --> URI Class Initialized
INFO - 2016-01-29 09:01:32 --> Router Class Initialized
INFO - 2016-01-29 09:01:32 --> Output Class Initialized
INFO - 2016-01-29 09:01:32 --> Security Class Initialized
DEBUG - 2016-01-29 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:01:32 --> Input Class Initialized
INFO - 2016-01-29 09:01:32 --> Language Class Initialized
INFO - 2016-01-29 09:01:32 --> Loader Class Initialized
INFO - 2016-01-29 09:01:32 --> Helper loaded: url_helper
INFO - 2016-01-29 09:01:32 --> Helper loaded: file_helper
INFO - 2016-01-29 09:01:32 --> Helper loaded: date_helper
INFO - 2016-01-29 09:01:32 --> Database Driver Class Initialized
INFO - 2016-01-29 09:01:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:01:33 --> Controller Class Initialized
INFO - 2016-01-29 09:01:33 --> Model Class Initialized
INFO - 2016-01-29 09:01:33 --> Model Class Initialized
INFO - 2016-01-29 09:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:01:33 --> Pagination Class Initialized
INFO - 2016-01-29 09:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:01:33 --> Helper loaded: text_helper
INFO - 2016-01-29 09:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:01:33 --> Final output sent to browser
DEBUG - 2016-01-29 09:01:33 --> Total execution time: 1.2320
INFO - 2016-01-29 09:02:58 --> Config Class Initialized
INFO - 2016-01-29 09:02:58 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:02:58 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:02:58 --> Utf8 Class Initialized
INFO - 2016-01-29 09:02:58 --> URI Class Initialized
INFO - 2016-01-29 09:02:58 --> Router Class Initialized
INFO - 2016-01-29 09:02:58 --> Output Class Initialized
INFO - 2016-01-29 09:02:58 --> Security Class Initialized
DEBUG - 2016-01-29 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:02:58 --> Input Class Initialized
INFO - 2016-01-29 09:02:58 --> Language Class Initialized
INFO - 2016-01-29 09:02:58 --> Loader Class Initialized
INFO - 2016-01-29 09:02:58 --> Helper loaded: url_helper
INFO - 2016-01-29 09:02:58 --> Helper loaded: file_helper
INFO - 2016-01-29 09:02:58 --> Helper loaded: date_helper
INFO - 2016-01-29 09:02:58 --> Database Driver Class Initialized
INFO - 2016-01-29 09:02:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:02:59 --> Controller Class Initialized
INFO - 2016-01-29 09:02:59 --> Model Class Initialized
INFO - 2016-01-29 09:02:59 --> Model Class Initialized
INFO - 2016-01-29 09:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:02:59 --> Pagination Class Initialized
INFO - 2016-01-29 09:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:02:59 --> Helper loaded: text_helper
INFO - 2016-01-29 09:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:02:59 --> Final output sent to browser
DEBUG - 2016-01-29 09:02:59 --> Total execution time: 1.2213
INFO - 2016-01-29 09:03:18 --> Config Class Initialized
INFO - 2016-01-29 09:03:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:18 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:18 --> URI Class Initialized
INFO - 2016-01-29 09:03:18 --> Router Class Initialized
INFO - 2016-01-29 09:03:18 --> Output Class Initialized
INFO - 2016-01-29 09:03:18 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:18 --> Input Class Initialized
INFO - 2016-01-29 09:03:18 --> Language Class Initialized
INFO - 2016-01-29 09:03:18 --> Loader Class Initialized
INFO - 2016-01-29 09:03:18 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:18 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:18 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:18 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:19 --> Controller Class Initialized
INFO - 2016-01-29 09:03:19 --> Model Class Initialized
INFO - 2016-01-29 09:03:19 --> Model Class Initialized
INFO - 2016-01-29 09:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:03:19 --> Pagination Class Initialized
INFO - 2016-01-29 09:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:03:19 --> Helper loaded: text_helper
INFO - 2016-01-29 09:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:03:19 --> Final output sent to browser
DEBUG - 2016-01-29 09:03:19 --> Total execution time: 1.2049
INFO - 2016-01-29 09:03:30 --> Config Class Initialized
INFO - 2016-01-29 09:03:30 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:30 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:30 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:30 --> URI Class Initialized
INFO - 2016-01-29 09:03:30 --> Router Class Initialized
INFO - 2016-01-29 09:03:30 --> Output Class Initialized
INFO - 2016-01-29 09:03:30 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:30 --> Input Class Initialized
INFO - 2016-01-29 09:03:30 --> Language Class Initialized
INFO - 2016-01-29 09:03:30 --> Loader Class Initialized
INFO - 2016-01-29 09:03:30 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:30 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:30 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:30 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:31 --> Controller Class Initialized
INFO - 2016-01-29 09:03:31 --> Model Class Initialized
INFO - 2016-01-29 09:03:31 --> Model Class Initialized
INFO - 2016-01-29 09:03:31 --> Helper loaded: form_helper
INFO - 2016-01-29 09:03:31 --> Form Validation Class Initialized
INFO - 2016-01-29 09:03:31 --> Config Class Initialized
INFO - 2016-01-29 09:03:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:31 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:31 --> URI Class Initialized
INFO - 2016-01-29 09:03:31 --> Router Class Initialized
INFO - 2016-01-29 09:03:31 --> Output Class Initialized
INFO - 2016-01-29 09:03:31 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:31 --> Input Class Initialized
INFO - 2016-01-29 09:03:31 --> Language Class Initialized
INFO - 2016-01-29 09:03:31 --> Loader Class Initialized
INFO - 2016-01-29 09:03:31 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:31 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:31 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:31 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:32 --> Controller Class Initialized
INFO - 2016-01-29 09:03:32 --> Model Class Initialized
INFO - 2016-01-29 09:03:32 --> Model Class Initialized
INFO - 2016-01-29 09:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:03:32 --> Pagination Class Initialized
INFO - 2016-01-29 09:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:03:32 --> Final output sent to browser
DEBUG - 2016-01-29 09:03:32 --> Total execution time: 1.1295
INFO - 2016-01-29 09:03:36 --> Config Class Initialized
INFO - 2016-01-29 09:03:36 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:36 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:36 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:36 --> URI Class Initialized
INFO - 2016-01-29 09:03:36 --> Router Class Initialized
INFO - 2016-01-29 09:03:36 --> Output Class Initialized
INFO - 2016-01-29 09:03:36 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:36 --> Input Class Initialized
INFO - 2016-01-29 09:03:36 --> Language Class Initialized
INFO - 2016-01-29 09:03:36 --> Loader Class Initialized
INFO - 2016-01-29 09:03:36 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:36 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:36 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:36 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:37 --> Controller Class Initialized
INFO - 2016-01-29 09:03:37 --> Model Class Initialized
INFO - 2016-01-29 09:03:37 --> Model Class Initialized
INFO - 2016-01-29 09:03:37 --> Helper loaded: form_helper
INFO - 2016-01-29 09:03:37 --> Form Validation Class Initialized
INFO - 2016-01-29 09:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 09:03:37 --> Model Class Initialized
INFO - 2016-01-29 09:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:03:37 --> Final output sent to browser
DEBUG - 2016-01-29 09:03:37 --> Total execution time: 1.1648
INFO - 2016-01-29 09:03:49 --> Config Class Initialized
INFO - 2016-01-29 09:03:49 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:49 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:49 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:49 --> URI Class Initialized
DEBUG - 2016-01-29 09:03:49 --> No URI present. Default controller set.
INFO - 2016-01-29 09:03:49 --> Router Class Initialized
INFO - 2016-01-29 09:03:49 --> Output Class Initialized
INFO - 2016-01-29 09:03:49 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:49 --> Input Class Initialized
INFO - 2016-01-29 09:03:49 --> Language Class Initialized
INFO - 2016-01-29 09:03:49 --> Loader Class Initialized
INFO - 2016-01-29 09:03:49 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:49 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:49 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:49 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:50 --> Controller Class Initialized
INFO - 2016-01-29 09:03:50 --> Model Class Initialized
INFO - 2016-01-29 09:03:50 --> Model Class Initialized
INFO - 2016-01-29 09:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:03:50 --> Pagination Class Initialized
INFO - 2016-01-29 09:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:03:50 --> Final output sent to browser
DEBUG - 2016-01-29 09:03:50 --> Total execution time: 1.1364
INFO - 2016-01-29 09:03:54 --> Config Class Initialized
INFO - 2016-01-29 09:03:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:03:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:03:54 --> Utf8 Class Initialized
INFO - 2016-01-29 09:03:54 --> URI Class Initialized
INFO - 2016-01-29 09:03:54 --> Router Class Initialized
INFO - 2016-01-29 09:03:54 --> Output Class Initialized
INFO - 2016-01-29 09:03:54 --> Security Class Initialized
DEBUG - 2016-01-29 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:03:54 --> Input Class Initialized
INFO - 2016-01-29 09:03:54 --> Language Class Initialized
INFO - 2016-01-29 09:03:54 --> Loader Class Initialized
INFO - 2016-01-29 09:03:54 --> Helper loaded: url_helper
INFO - 2016-01-29 09:03:54 --> Helper loaded: file_helper
INFO - 2016-01-29 09:03:54 --> Helper loaded: date_helper
INFO - 2016-01-29 09:03:54 --> Database Driver Class Initialized
INFO - 2016-01-29 09:03:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:03:55 --> Controller Class Initialized
INFO - 2016-01-29 09:03:55 --> Model Class Initialized
INFO - 2016-01-29 09:03:55 --> Model Class Initialized
INFO - 2016-01-29 09:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:03:55 --> Pagination Class Initialized
INFO - 2016-01-29 09:03:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:03:55 --> Helper loaded: text_helper
INFO - 2016-01-29 09:03:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:03:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:03:55 --> Final output sent to browser
DEBUG - 2016-01-29 09:03:55 --> Total execution time: 1.1604
INFO - 2016-01-29 09:04:24 --> Config Class Initialized
INFO - 2016-01-29 09:04:24 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:04:24 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:04:24 --> Utf8 Class Initialized
INFO - 2016-01-29 09:04:24 --> URI Class Initialized
INFO - 2016-01-29 09:04:24 --> Router Class Initialized
INFO - 2016-01-29 09:04:24 --> Output Class Initialized
INFO - 2016-01-29 09:04:24 --> Security Class Initialized
DEBUG - 2016-01-29 09:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:04:24 --> Input Class Initialized
INFO - 2016-01-29 09:04:24 --> Language Class Initialized
INFO - 2016-01-29 09:04:24 --> Loader Class Initialized
INFO - 2016-01-29 09:04:24 --> Helper loaded: url_helper
INFO - 2016-01-29 09:04:24 --> Helper loaded: file_helper
INFO - 2016-01-29 09:04:24 --> Helper loaded: date_helper
INFO - 2016-01-29 09:04:24 --> Database Driver Class Initialized
INFO - 2016-01-29 09:04:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:04:25 --> Controller Class Initialized
INFO - 2016-01-29 09:04:25 --> Model Class Initialized
INFO - 2016-01-29 09:04:25 --> Model Class Initialized
INFO - 2016-01-29 09:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:04:25 --> Pagination Class Initialized
INFO - 2016-01-29 09:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:04:25 --> Helper loaded: text_helper
INFO - 2016-01-29 09:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:04:25 --> Final output sent to browser
DEBUG - 2016-01-29 09:04:25 --> Total execution time: 1.2122
INFO - 2016-01-29 09:05:06 --> Config Class Initialized
INFO - 2016-01-29 09:05:06 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:05:06 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:05:06 --> Utf8 Class Initialized
INFO - 2016-01-29 09:05:06 --> URI Class Initialized
INFO - 2016-01-29 09:05:06 --> Router Class Initialized
INFO - 2016-01-29 09:05:06 --> Output Class Initialized
INFO - 2016-01-29 09:05:06 --> Security Class Initialized
DEBUG - 2016-01-29 09:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:05:06 --> Input Class Initialized
INFO - 2016-01-29 09:05:06 --> Language Class Initialized
INFO - 2016-01-29 09:05:06 --> Loader Class Initialized
INFO - 2016-01-29 09:05:06 --> Helper loaded: url_helper
INFO - 2016-01-29 09:05:06 --> Helper loaded: file_helper
INFO - 2016-01-29 09:05:06 --> Helper loaded: date_helper
INFO - 2016-01-29 09:05:06 --> Database Driver Class Initialized
INFO - 2016-01-29 09:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:05:07 --> Controller Class Initialized
INFO - 2016-01-29 09:05:08 --> Model Class Initialized
INFO - 2016-01-29 09:05:08 --> Model Class Initialized
INFO - 2016-01-29 09:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:05:08 --> Pagination Class Initialized
INFO - 2016-01-29 09:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:05:08 --> Helper loaded: text_helper
INFO - 2016-01-29 09:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:05:08 --> Final output sent to browser
DEBUG - 2016-01-29 09:05:08 --> Total execution time: 1.1667
INFO - 2016-01-29 09:06:00 --> Config Class Initialized
INFO - 2016-01-29 09:06:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:06:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:06:00 --> Utf8 Class Initialized
INFO - 2016-01-29 09:06:00 --> URI Class Initialized
INFO - 2016-01-29 09:06:00 --> Router Class Initialized
INFO - 2016-01-29 09:06:00 --> Output Class Initialized
INFO - 2016-01-29 09:06:00 --> Security Class Initialized
DEBUG - 2016-01-29 09:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:06:00 --> Input Class Initialized
INFO - 2016-01-29 09:06:00 --> Language Class Initialized
INFO - 2016-01-29 09:06:00 --> Loader Class Initialized
INFO - 2016-01-29 09:06:00 --> Helper loaded: url_helper
INFO - 2016-01-29 09:06:00 --> Helper loaded: file_helper
INFO - 2016-01-29 09:06:00 --> Helper loaded: date_helper
INFO - 2016-01-29 09:06:00 --> Database Driver Class Initialized
INFO - 2016-01-29 09:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:06:01 --> Controller Class Initialized
INFO - 2016-01-29 09:06:01 --> Model Class Initialized
INFO - 2016-01-29 09:06:01 --> Model Class Initialized
INFO - 2016-01-29 09:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:06:01 --> Pagination Class Initialized
INFO - 2016-01-29 09:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:06:01 --> Helper loaded: text_helper
INFO - 2016-01-29 09:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:06:01 --> Final output sent to browser
DEBUG - 2016-01-29 09:06:01 --> Total execution time: 1.1829
INFO - 2016-01-29 09:06:52 --> Config Class Initialized
INFO - 2016-01-29 09:06:52 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:06:52 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:06:52 --> Utf8 Class Initialized
INFO - 2016-01-29 09:06:52 --> URI Class Initialized
INFO - 2016-01-29 09:06:52 --> Router Class Initialized
INFO - 2016-01-29 09:06:52 --> Output Class Initialized
INFO - 2016-01-29 09:06:52 --> Security Class Initialized
DEBUG - 2016-01-29 09:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:06:52 --> Input Class Initialized
INFO - 2016-01-29 09:06:52 --> Language Class Initialized
INFO - 2016-01-29 09:06:52 --> Loader Class Initialized
INFO - 2016-01-29 09:06:52 --> Helper loaded: url_helper
INFO - 2016-01-29 09:06:52 --> Helper loaded: file_helper
INFO - 2016-01-29 09:06:52 --> Helper loaded: date_helper
INFO - 2016-01-29 09:06:52 --> Database Driver Class Initialized
INFO - 2016-01-29 09:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:06:53 --> Controller Class Initialized
INFO - 2016-01-29 09:06:53 --> Model Class Initialized
INFO - 2016-01-29 09:06:53 --> Model Class Initialized
INFO - 2016-01-29 09:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:06:53 --> Pagination Class Initialized
INFO - 2016-01-29 09:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:06:53 --> Helper loaded: text_helper
INFO - 2016-01-29 09:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:06:53 --> Final output sent to browser
DEBUG - 2016-01-29 09:06:53 --> Total execution time: 1.1479
INFO - 2016-01-29 09:07:05 --> Config Class Initialized
INFO - 2016-01-29 09:07:05 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:07:05 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:07:05 --> Utf8 Class Initialized
INFO - 2016-01-29 09:07:05 --> URI Class Initialized
INFO - 2016-01-29 09:07:05 --> Router Class Initialized
INFO - 2016-01-29 09:07:05 --> Output Class Initialized
INFO - 2016-01-29 09:07:05 --> Security Class Initialized
DEBUG - 2016-01-29 09:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:07:05 --> Input Class Initialized
INFO - 2016-01-29 09:07:05 --> Language Class Initialized
INFO - 2016-01-29 09:07:05 --> Loader Class Initialized
INFO - 2016-01-29 09:07:05 --> Helper loaded: url_helper
INFO - 2016-01-29 09:07:05 --> Helper loaded: file_helper
INFO - 2016-01-29 09:07:05 --> Helper loaded: date_helper
INFO - 2016-01-29 09:07:05 --> Database Driver Class Initialized
INFO - 2016-01-29 09:07:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:07:07 --> Controller Class Initialized
INFO - 2016-01-29 09:07:07 --> Model Class Initialized
INFO - 2016-01-29 09:07:07 --> Model Class Initialized
INFO - 2016-01-29 09:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:07:07 --> Pagination Class Initialized
INFO - 2016-01-29 09:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:07:07 --> Helper loaded: text_helper
INFO - 2016-01-29 09:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:07:07 --> Final output sent to browser
DEBUG - 2016-01-29 09:07:07 --> Total execution time: 1.2397
INFO - 2016-01-29 09:07:32 --> Config Class Initialized
INFO - 2016-01-29 09:07:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:07:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:07:32 --> Utf8 Class Initialized
INFO - 2016-01-29 09:07:32 --> URI Class Initialized
INFO - 2016-01-29 09:07:32 --> Router Class Initialized
INFO - 2016-01-29 09:07:32 --> Output Class Initialized
INFO - 2016-01-29 09:07:32 --> Security Class Initialized
DEBUG - 2016-01-29 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:07:32 --> Input Class Initialized
INFO - 2016-01-29 09:07:32 --> Language Class Initialized
INFO - 2016-01-29 09:07:32 --> Loader Class Initialized
INFO - 2016-01-29 09:07:32 --> Helper loaded: url_helper
INFO - 2016-01-29 09:07:32 --> Helper loaded: file_helper
INFO - 2016-01-29 09:07:32 --> Helper loaded: date_helper
INFO - 2016-01-29 09:07:32 --> Database Driver Class Initialized
INFO - 2016-01-29 09:07:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:07:33 --> Controller Class Initialized
INFO - 2016-01-29 09:07:33 --> Model Class Initialized
INFO - 2016-01-29 09:07:33 --> Model Class Initialized
INFO - 2016-01-29 09:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:07:33 --> Pagination Class Initialized
INFO - 2016-01-29 09:07:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:07:33 --> Helper loaded: text_helper
INFO - 2016-01-29 09:07:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:07:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:07:33 --> Final output sent to browser
DEBUG - 2016-01-29 09:07:33 --> Total execution time: 1.2209
INFO - 2016-01-29 09:12:09 --> Config Class Initialized
INFO - 2016-01-29 09:12:09 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:12:09 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:12:09 --> Utf8 Class Initialized
INFO - 2016-01-29 09:12:09 --> URI Class Initialized
INFO - 2016-01-29 09:12:09 --> Router Class Initialized
INFO - 2016-01-29 09:12:09 --> Output Class Initialized
INFO - 2016-01-29 09:12:09 --> Security Class Initialized
DEBUG - 2016-01-29 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:12:09 --> Input Class Initialized
INFO - 2016-01-29 09:12:09 --> Language Class Initialized
INFO - 2016-01-29 09:12:09 --> Loader Class Initialized
INFO - 2016-01-29 09:12:09 --> Helper loaded: url_helper
INFO - 2016-01-29 09:12:09 --> Helper loaded: file_helper
INFO - 2016-01-29 09:12:09 --> Helper loaded: date_helper
INFO - 2016-01-29 09:12:09 --> Database Driver Class Initialized
INFO - 2016-01-29 09:12:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:12:10 --> Controller Class Initialized
INFO - 2016-01-29 09:12:10 --> Model Class Initialized
INFO - 2016-01-29 09:12:10 --> Model Class Initialized
INFO - 2016-01-29 09:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:12:10 --> Pagination Class Initialized
INFO - 2016-01-29 09:12:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:12:10 --> Helper loaded: text_helper
INFO - 2016-01-29 09:12:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:12:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:12:10 --> Final output sent to browser
DEBUG - 2016-01-29 09:12:10 --> Total execution time: 1.1873
INFO - 2016-01-29 09:12:46 --> Config Class Initialized
INFO - 2016-01-29 09:12:46 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:12:46 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:12:46 --> Utf8 Class Initialized
INFO - 2016-01-29 09:12:46 --> URI Class Initialized
INFO - 2016-01-29 09:12:46 --> Router Class Initialized
INFO - 2016-01-29 09:12:46 --> Output Class Initialized
INFO - 2016-01-29 09:12:46 --> Security Class Initialized
DEBUG - 2016-01-29 09:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:12:46 --> Input Class Initialized
INFO - 2016-01-29 09:12:46 --> Language Class Initialized
INFO - 2016-01-29 09:12:46 --> Loader Class Initialized
INFO - 2016-01-29 09:12:46 --> Helper loaded: url_helper
INFO - 2016-01-29 09:12:46 --> Helper loaded: file_helper
INFO - 2016-01-29 09:12:46 --> Helper loaded: date_helper
INFO - 2016-01-29 09:12:46 --> Database Driver Class Initialized
INFO - 2016-01-29 09:12:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:12:47 --> Controller Class Initialized
INFO - 2016-01-29 09:12:47 --> Model Class Initialized
INFO - 2016-01-29 09:12:47 --> Model Class Initialized
INFO - 2016-01-29 09:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:12:47 --> Pagination Class Initialized
INFO - 2016-01-29 09:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:12:47 --> Helper loaded: text_helper
INFO - 2016-01-29 09:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:12:47 --> Final output sent to browser
DEBUG - 2016-01-29 09:12:47 --> Total execution time: 1.2363
INFO - 2016-01-29 09:13:29 --> Config Class Initialized
INFO - 2016-01-29 09:13:29 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:13:29 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:13:29 --> Utf8 Class Initialized
INFO - 2016-01-29 09:13:29 --> URI Class Initialized
INFO - 2016-01-29 09:13:29 --> Router Class Initialized
INFO - 2016-01-29 09:13:29 --> Output Class Initialized
INFO - 2016-01-29 09:13:29 --> Security Class Initialized
DEBUG - 2016-01-29 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:13:29 --> Input Class Initialized
INFO - 2016-01-29 09:13:29 --> Language Class Initialized
INFO - 2016-01-29 09:13:29 --> Loader Class Initialized
INFO - 2016-01-29 09:13:29 --> Helper loaded: url_helper
INFO - 2016-01-29 09:13:29 --> Helper loaded: file_helper
INFO - 2016-01-29 09:13:29 --> Helper loaded: date_helper
INFO - 2016-01-29 09:13:29 --> Database Driver Class Initialized
INFO - 2016-01-29 09:13:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:13:30 --> Controller Class Initialized
INFO - 2016-01-29 09:13:30 --> Model Class Initialized
INFO - 2016-01-29 09:13:30 --> Model Class Initialized
INFO - 2016-01-29 09:13:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:13:30 --> Pagination Class Initialized
INFO - 2016-01-29 09:13:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:13:30 --> Helper loaded: text_helper
INFO - 2016-01-29 09:13:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:13:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:13:30 --> Final output sent to browser
DEBUG - 2016-01-29 09:13:30 --> Total execution time: 1.2061
INFO - 2016-01-29 09:13:54 --> Config Class Initialized
INFO - 2016-01-29 09:13:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:13:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:13:54 --> Utf8 Class Initialized
INFO - 2016-01-29 09:13:54 --> URI Class Initialized
INFO - 2016-01-29 09:13:54 --> Router Class Initialized
INFO - 2016-01-29 09:13:54 --> Output Class Initialized
INFO - 2016-01-29 09:13:54 --> Security Class Initialized
DEBUG - 2016-01-29 09:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:13:54 --> Input Class Initialized
INFO - 2016-01-29 09:13:54 --> Language Class Initialized
INFO - 2016-01-29 09:13:54 --> Loader Class Initialized
INFO - 2016-01-29 09:13:54 --> Helper loaded: url_helper
INFO - 2016-01-29 09:13:54 --> Helper loaded: file_helper
INFO - 2016-01-29 09:13:54 --> Helper loaded: date_helper
INFO - 2016-01-29 09:13:54 --> Database Driver Class Initialized
INFO - 2016-01-29 09:13:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:13:55 --> Controller Class Initialized
INFO - 2016-01-29 09:13:55 --> Model Class Initialized
INFO - 2016-01-29 09:13:55 --> Model Class Initialized
INFO - 2016-01-29 09:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:13:55 --> Pagination Class Initialized
INFO - 2016-01-29 09:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:13:55 --> Helper loaded: text_helper
INFO - 2016-01-29 09:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:13:55 --> Final output sent to browser
DEBUG - 2016-01-29 09:13:55 --> Total execution time: 1.1389
INFO - 2016-01-29 09:16:56 --> Config Class Initialized
INFO - 2016-01-29 09:16:56 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:16:56 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:16:56 --> Utf8 Class Initialized
INFO - 2016-01-29 09:16:56 --> URI Class Initialized
INFO - 2016-01-29 09:16:56 --> Router Class Initialized
INFO - 2016-01-29 09:16:56 --> Output Class Initialized
INFO - 2016-01-29 09:16:56 --> Security Class Initialized
DEBUG - 2016-01-29 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:16:56 --> Input Class Initialized
INFO - 2016-01-29 09:16:56 --> Language Class Initialized
INFO - 2016-01-29 09:16:56 --> Loader Class Initialized
INFO - 2016-01-29 09:16:56 --> Helper loaded: url_helper
INFO - 2016-01-29 09:16:56 --> Helper loaded: file_helper
INFO - 2016-01-29 09:16:56 --> Helper loaded: date_helper
INFO - 2016-01-29 09:16:56 --> Database Driver Class Initialized
INFO - 2016-01-29 09:16:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:16:57 --> Controller Class Initialized
INFO - 2016-01-29 09:16:57 --> Model Class Initialized
INFO - 2016-01-29 09:16:57 --> Model Class Initialized
INFO - 2016-01-29 09:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:16:57 --> Pagination Class Initialized
INFO - 2016-01-29 09:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:16:57 --> Helper loaded: text_helper
INFO - 2016-01-29 09:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:16:57 --> Final output sent to browser
DEBUG - 2016-01-29 09:16:57 --> Total execution time: 1.1550
INFO - 2016-01-29 09:19:41 --> Config Class Initialized
INFO - 2016-01-29 09:19:41 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:19:41 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:19:41 --> Utf8 Class Initialized
INFO - 2016-01-29 09:19:41 --> URI Class Initialized
INFO - 2016-01-29 09:19:41 --> Router Class Initialized
INFO - 2016-01-29 09:19:41 --> Output Class Initialized
INFO - 2016-01-29 09:19:41 --> Security Class Initialized
DEBUG - 2016-01-29 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:19:41 --> Input Class Initialized
INFO - 2016-01-29 09:19:41 --> Language Class Initialized
INFO - 2016-01-29 09:19:41 --> Loader Class Initialized
INFO - 2016-01-29 09:19:41 --> Helper loaded: url_helper
INFO - 2016-01-29 09:19:41 --> Helper loaded: file_helper
INFO - 2016-01-29 09:19:41 --> Helper loaded: date_helper
INFO - 2016-01-29 09:19:41 --> Database Driver Class Initialized
INFO - 2016-01-29 09:19:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:19:42 --> Controller Class Initialized
INFO - 2016-01-29 09:19:42 --> Model Class Initialized
INFO - 2016-01-29 09:19:42 --> Model Class Initialized
INFO - 2016-01-29 09:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:19:42 --> Pagination Class Initialized
INFO - 2016-01-29 09:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:19:42 --> Helper loaded: text_helper
INFO - 2016-01-29 09:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:19:42 --> Final output sent to browser
DEBUG - 2016-01-29 09:19:42 --> Total execution time: 1.2056
INFO - 2016-01-29 09:20:16 --> Config Class Initialized
INFO - 2016-01-29 09:20:16 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:20:16 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:20:16 --> Utf8 Class Initialized
INFO - 2016-01-29 09:20:16 --> URI Class Initialized
INFO - 2016-01-29 09:20:16 --> Router Class Initialized
INFO - 2016-01-29 09:20:16 --> Output Class Initialized
INFO - 2016-01-29 09:20:16 --> Security Class Initialized
DEBUG - 2016-01-29 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:20:16 --> Input Class Initialized
INFO - 2016-01-29 09:20:16 --> Language Class Initialized
INFO - 2016-01-29 09:20:16 --> Loader Class Initialized
INFO - 2016-01-29 09:20:16 --> Helper loaded: url_helper
INFO - 2016-01-29 09:20:16 --> Helper loaded: file_helper
INFO - 2016-01-29 09:20:16 --> Helper loaded: date_helper
INFO - 2016-01-29 09:20:16 --> Database Driver Class Initialized
INFO - 2016-01-29 09:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:20:17 --> Controller Class Initialized
INFO - 2016-01-29 09:20:17 --> Model Class Initialized
INFO - 2016-01-29 09:20:17 --> Model Class Initialized
INFO - 2016-01-29 09:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:20:17 --> Pagination Class Initialized
INFO - 2016-01-29 09:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:20:17 --> Helper loaded: text_helper
ERROR - 2016-01-29 09:20:17 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
INFO - 2016-01-29 09:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:20:17 --> Final output sent to browser
DEBUG - 2016-01-29 09:20:17 --> Total execution time: 1.1950
INFO - 2016-01-29 09:21:58 --> Config Class Initialized
INFO - 2016-01-29 09:21:58 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:21:58 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:21:58 --> Utf8 Class Initialized
INFO - 2016-01-29 09:21:58 --> URI Class Initialized
INFO - 2016-01-29 09:21:58 --> Router Class Initialized
INFO - 2016-01-29 09:21:58 --> Output Class Initialized
INFO - 2016-01-29 09:21:58 --> Security Class Initialized
DEBUG - 2016-01-29 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:21:58 --> Input Class Initialized
INFO - 2016-01-29 09:21:58 --> Language Class Initialized
INFO - 2016-01-29 09:21:58 --> Loader Class Initialized
INFO - 2016-01-29 09:21:58 --> Helper loaded: url_helper
INFO - 2016-01-29 09:21:58 --> Helper loaded: file_helper
INFO - 2016-01-29 09:21:58 --> Helper loaded: date_helper
INFO - 2016-01-29 09:21:58 --> Database Driver Class Initialized
INFO - 2016-01-29 09:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:21:59 --> Controller Class Initialized
INFO - 2016-01-29 09:21:59 --> Model Class Initialized
INFO - 2016-01-29 09:21:59 --> Model Class Initialized
INFO - 2016-01-29 09:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:21:59 --> Pagination Class Initialized
INFO - 2016-01-29 09:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:21:59 --> Helper loaded: text_helper
INFO - 2016-01-29 09:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:21:59 --> Final output sent to browser
DEBUG - 2016-01-29 09:21:59 --> Total execution time: 1.2089
INFO - 2016-01-29 09:22:32 --> Config Class Initialized
INFO - 2016-01-29 09:22:32 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:22:32 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:22:32 --> Utf8 Class Initialized
INFO - 2016-01-29 09:22:32 --> URI Class Initialized
INFO - 2016-01-29 09:22:32 --> Router Class Initialized
INFO - 2016-01-29 09:22:32 --> Output Class Initialized
INFO - 2016-01-29 09:22:32 --> Security Class Initialized
DEBUG - 2016-01-29 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:22:32 --> Input Class Initialized
INFO - 2016-01-29 09:22:32 --> Language Class Initialized
INFO - 2016-01-29 09:22:32 --> Loader Class Initialized
INFO - 2016-01-29 09:22:32 --> Helper loaded: url_helper
INFO - 2016-01-29 09:22:32 --> Helper loaded: file_helper
INFO - 2016-01-29 09:22:32 --> Helper loaded: date_helper
INFO - 2016-01-29 09:22:32 --> Database Driver Class Initialized
INFO - 2016-01-29 09:22:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:22:33 --> Controller Class Initialized
INFO - 2016-01-29 09:22:33 --> Model Class Initialized
INFO - 2016-01-29 09:22:33 --> Model Class Initialized
INFO - 2016-01-29 09:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:22:33 --> Pagination Class Initialized
INFO - 2016-01-29 09:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:22:33 --> Helper loaded: text_helper
INFO - 2016-01-29 09:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:22:33 --> Final output sent to browser
DEBUG - 2016-01-29 09:22:33 --> Total execution time: 1.2209
INFO - 2016-01-29 09:23:06 --> Config Class Initialized
INFO - 2016-01-29 09:23:06 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:23:06 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:23:06 --> Utf8 Class Initialized
INFO - 2016-01-29 09:23:06 --> URI Class Initialized
INFO - 2016-01-29 09:23:06 --> Router Class Initialized
INFO - 2016-01-29 09:23:06 --> Output Class Initialized
INFO - 2016-01-29 09:23:06 --> Security Class Initialized
DEBUG - 2016-01-29 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:23:06 --> Input Class Initialized
INFO - 2016-01-29 09:23:06 --> Language Class Initialized
INFO - 2016-01-29 09:23:06 --> Loader Class Initialized
INFO - 2016-01-29 09:23:06 --> Helper loaded: url_helper
INFO - 2016-01-29 09:23:06 --> Helper loaded: file_helper
INFO - 2016-01-29 09:23:06 --> Helper loaded: date_helper
INFO - 2016-01-29 09:23:06 --> Database Driver Class Initialized
INFO - 2016-01-29 09:23:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:23:07 --> Controller Class Initialized
INFO - 2016-01-29 09:23:07 --> Model Class Initialized
INFO - 2016-01-29 09:23:07 --> Model Class Initialized
INFO - 2016-01-29 09:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:23:07 --> Pagination Class Initialized
INFO - 2016-01-29 09:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:23:07 --> Helper loaded: text_helper
INFO - 2016-01-29 09:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:23:07 --> Final output sent to browser
DEBUG - 2016-01-29 09:23:07 --> Total execution time: 1.2155
INFO - 2016-01-29 09:23:17 --> Config Class Initialized
INFO - 2016-01-29 09:23:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:23:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:23:17 --> Utf8 Class Initialized
INFO - 2016-01-29 09:23:17 --> URI Class Initialized
INFO - 2016-01-29 09:23:17 --> Router Class Initialized
INFO - 2016-01-29 09:23:17 --> Output Class Initialized
INFO - 2016-01-29 09:23:17 --> Security Class Initialized
DEBUG - 2016-01-29 09:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:23:17 --> Input Class Initialized
INFO - 2016-01-29 09:23:17 --> Language Class Initialized
INFO - 2016-01-29 09:23:17 --> Loader Class Initialized
INFO - 2016-01-29 09:23:17 --> Helper loaded: url_helper
INFO - 2016-01-29 09:23:17 --> Helper loaded: file_helper
INFO - 2016-01-29 09:23:17 --> Helper loaded: date_helper
INFO - 2016-01-29 09:23:17 --> Database Driver Class Initialized
INFO - 2016-01-29 09:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:23:18 --> Controller Class Initialized
INFO - 2016-01-29 09:23:18 --> Model Class Initialized
INFO - 2016-01-29 09:23:18 --> Model Class Initialized
INFO - 2016-01-29 09:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:23:18 --> Pagination Class Initialized
INFO - 2016-01-29 09:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:23:18 --> Helper loaded: text_helper
INFO - 2016-01-29 09:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:23:18 --> Final output sent to browser
DEBUG - 2016-01-29 09:23:18 --> Total execution time: 1.1544
INFO - 2016-01-29 09:24:31 --> Config Class Initialized
INFO - 2016-01-29 09:24:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:24:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:24:31 --> Utf8 Class Initialized
INFO - 2016-01-29 09:24:31 --> URI Class Initialized
INFO - 2016-01-29 09:24:31 --> Router Class Initialized
INFO - 2016-01-29 09:24:31 --> Output Class Initialized
INFO - 2016-01-29 09:24:31 --> Security Class Initialized
DEBUG - 2016-01-29 09:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:24:31 --> Input Class Initialized
INFO - 2016-01-29 09:24:31 --> Language Class Initialized
INFO - 2016-01-29 09:24:31 --> Loader Class Initialized
INFO - 2016-01-29 09:24:31 --> Helper loaded: url_helper
INFO - 2016-01-29 09:24:31 --> Helper loaded: file_helper
INFO - 2016-01-29 09:24:31 --> Helper loaded: date_helper
INFO - 2016-01-29 09:24:31 --> Database Driver Class Initialized
INFO - 2016-01-29 09:24:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:24:32 --> Controller Class Initialized
INFO - 2016-01-29 09:24:32 --> Model Class Initialized
INFO - 2016-01-29 09:24:32 --> Model Class Initialized
INFO - 2016-01-29 09:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:24:32 --> Pagination Class Initialized
INFO - 2016-01-29 09:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:24:32 --> Helper loaded: text_helper
INFO - 2016-01-29 09:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:24:33 --> Final output sent to browser
DEBUG - 2016-01-29 09:24:33 --> Total execution time: 1.1907
INFO - 2016-01-29 09:30:20 --> Config Class Initialized
INFO - 2016-01-29 09:30:20 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:30:20 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:30:20 --> Utf8 Class Initialized
INFO - 2016-01-29 09:30:20 --> URI Class Initialized
DEBUG - 2016-01-29 09:30:20 --> No URI present. Default controller set.
INFO - 2016-01-29 09:30:20 --> Router Class Initialized
INFO - 2016-01-29 09:30:20 --> Output Class Initialized
INFO - 2016-01-29 09:30:20 --> Security Class Initialized
DEBUG - 2016-01-29 09:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:30:20 --> Input Class Initialized
INFO - 2016-01-29 09:30:20 --> Language Class Initialized
INFO - 2016-01-29 09:30:20 --> Loader Class Initialized
INFO - 2016-01-29 09:30:20 --> Helper loaded: url_helper
INFO - 2016-01-29 09:30:20 --> Helper loaded: file_helper
INFO - 2016-01-29 09:30:20 --> Helper loaded: date_helper
INFO - 2016-01-29 09:30:20 --> Database Driver Class Initialized
INFO - 2016-01-29 09:30:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:30:21 --> Controller Class Initialized
INFO - 2016-01-29 09:30:21 --> Model Class Initialized
INFO - 2016-01-29 09:30:21 --> Model Class Initialized
INFO - 2016-01-29 09:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:30:21 --> Pagination Class Initialized
INFO - 2016-01-29 09:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:30:21 --> Final output sent to browser
DEBUG - 2016-01-29 09:30:21 --> Total execution time: 1.1025
INFO - 2016-01-29 09:31:00 --> Config Class Initialized
INFO - 2016-01-29 09:31:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:31:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:31:00 --> Utf8 Class Initialized
INFO - 2016-01-29 09:31:00 --> URI Class Initialized
INFO - 2016-01-29 09:31:00 --> Router Class Initialized
INFO - 2016-01-29 09:31:00 --> Output Class Initialized
INFO - 2016-01-29 09:31:00 --> Security Class Initialized
DEBUG - 2016-01-29 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:31:00 --> Input Class Initialized
INFO - 2016-01-29 09:31:00 --> Language Class Initialized
INFO - 2016-01-29 09:31:00 --> Loader Class Initialized
INFO - 2016-01-29 09:31:00 --> Helper loaded: url_helper
INFO - 2016-01-29 09:31:00 --> Helper loaded: file_helper
INFO - 2016-01-29 09:31:00 --> Helper loaded: date_helper
INFO - 2016-01-29 09:31:00 --> Database Driver Class Initialized
INFO - 2016-01-29 09:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:31:01 --> Controller Class Initialized
INFO - 2016-01-29 09:31:01 --> Model Class Initialized
INFO - 2016-01-29 09:31:01 --> Model Class Initialized
INFO - 2016-01-29 09:31:01 --> Helper loaded: form_helper
INFO - 2016-01-29 09:31:01 --> Form Validation Class Initialized
INFO - 2016-01-29 09:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 09:31:01 --> Final output sent to browser
DEBUG - 2016-01-29 09:31:01 --> Total execution time: 1.1354
INFO - 2016-01-29 09:31:17 --> Config Class Initialized
INFO - 2016-01-29 09:31:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:31:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:31:17 --> Utf8 Class Initialized
INFO - 2016-01-29 09:31:17 --> URI Class Initialized
INFO - 2016-01-29 09:31:17 --> Router Class Initialized
INFO - 2016-01-29 09:31:17 --> Output Class Initialized
INFO - 2016-01-29 09:31:17 --> Security Class Initialized
DEBUG - 2016-01-29 09:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:31:17 --> Input Class Initialized
INFO - 2016-01-29 09:31:17 --> Language Class Initialized
INFO - 2016-01-29 09:31:17 --> Loader Class Initialized
INFO - 2016-01-29 09:31:17 --> Helper loaded: url_helper
INFO - 2016-01-29 09:31:17 --> Helper loaded: file_helper
INFO - 2016-01-29 09:31:17 --> Helper loaded: date_helper
INFO - 2016-01-29 09:31:17 --> Database Driver Class Initialized
INFO - 2016-01-29 09:31:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:31:18 --> Controller Class Initialized
INFO - 2016-01-29 09:31:18 --> Model Class Initialized
INFO - 2016-01-29 09:31:18 --> Model Class Initialized
INFO - 2016-01-29 09:31:18 --> Helper loaded: form_helper
INFO - 2016-01-29 09:31:18 --> Form Validation Class Initialized
INFO - 2016-01-29 09:31:18 --> Config Class Initialized
INFO - 2016-01-29 09:31:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:31:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:31:18 --> Utf8 Class Initialized
INFO - 2016-01-29 09:31:18 --> URI Class Initialized
INFO - 2016-01-29 09:31:18 --> Router Class Initialized
INFO - 2016-01-29 09:31:18 --> Output Class Initialized
INFO - 2016-01-29 09:31:18 --> Security Class Initialized
DEBUG - 2016-01-29 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:31:18 --> Input Class Initialized
INFO - 2016-01-29 09:31:18 --> Language Class Initialized
INFO - 2016-01-29 09:31:18 --> Loader Class Initialized
INFO - 2016-01-29 09:31:18 --> Helper loaded: url_helper
INFO - 2016-01-29 09:31:18 --> Helper loaded: file_helper
INFO - 2016-01-29 09:31:18 --> Helper loaded: date_helper
INFO - 2016-01-29 09:31:18 --> Database Driver Class Initialized
INFO - 2016-01-29 09:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:31:19 --> Controller Class Initialized
INFO - 2016-01-29 09:31:19 --> Model Class Initialized
INFO - 2016-01-29 09:31:19 --> Model Class Initialized
INFO - 2016-01-29 09:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:31:19 --> Pagination Class Initialized
INFO - 2016-01-29 09:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:31:19 --> Final output sent to browser
DEBUG - 2016-01-29 09:31:19 --> Total execution time: 1.1275
INFO - 2016-01-29 09:31:22 --> Config Class Initialized
INFO - 2016-01-29 09:31:22 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:31:22 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:31:22 --> Utf8 Class Initialized
INFO - 2016-01-29 09:31:22 --> URI Class Initialized
INFO - 2016-01-29 09:31:22 --> Router Class Initialized
INFO - 2016-01-29 09:31:22 --> Output Class Initialized
INFO - 2016-01-29 09:31:22 --> Security Class Initialized
DEBUG - 2016-01-29 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:31:22 --> Input Class Initialized
INFO - 2016-01-29 09:31:22 --> Language Class Initialized
INFO - 2016-01-29 09:31:22 --> Loader Class Initialized
INFO - 2016-01-29 09:31:22 --> Helper loaded: url_helper
INFO - 2016-01-29 09:31:22 --> Helper loaded: file_helper
INFO - 2016-01-29 09:31:22 --> Helper loaded: date_helper
INFO - 2016-01-29 09:31:22 --> Database Driver Class Initialized
INFO - 2016-01-29 09:31:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:31:23 --> Controller Class Initialized
INFO - 2016-01-29 09:31:23 --> Model Class Initialized
INFO - 2016-01-29 09:31:23 --> Model Class Initialized
INFO - 2016-01-29 09:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:31:23 --> Pagination Class Initialized
INFO - 2016-01-29 09:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:31:23 --> Helper loaded: form_helper
INFO - 2016-01-29 09:31:23 --> Form Validation Class Initialized
INFO - 2016-01-29 09:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-01-29 09:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-29 09:31:23 --> Final output sent to browser
DEBUG - 2016-01-29 09:31:23 --> Total execution time: 1.1267
INFO - 2016-01-29 09:32:02 --> Config Class Initialized
INFO - 2016-01-29 09:32:02 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:32:02 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:32:02 --> Utf8 Class Initialized
INFO - 2016-01-29 09:32:02 --> URI Class Initialized
INFO - 2016-01-29 09:32:02 --> Router Class Initialized
INFO - 2016-01-29 09:32:02 --> Output Class Initialized
INFO - 2016-01-29 09:32:02 --> Security Class Initialized
DEBUG - 2016-01-29 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:32:02 --> Input Class Initialized
INFO - 2016-01-29 09:32:02 --> Language Class Initialized
INFO - 2016-01-29 09:32:02 --> Loader Class Initialized
INFO - 2016-01-29 09:32:02 --> Helper loaded: url_helper
INFO - 2016-01-29 09:32:02 --> Helper loaded: file_helper
INFO - 2016-01-29 09:32:02 --> Helper loaded: date_helper
INFO - 2016-01-29 09:32:02 --> Database Driver Class Initialized
INFO - 2016-01-29 09:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:32:03 --> Controller Class Initialized
INFO - 2016-01-29 09:32:03 --> Model Class Initialized
INFO - 2016-01-29 09:32:03 --> Model Class Initialized
INFO - 2016-01-29 09:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:32:03 --> Pagination Class Initialized
INFO - 2016-01-29 09:32:03 --> Upload Class Initialized
INFO - 2016-01-29 09:32:04 --> Final output sent to browser
DEBUG - 2016-01-29 09:32:04 --> Total execution time: 1.1734
INFO - 2016-01-29 09:33:09 --> Config Class Initialized
INFO - 2016-01-29 09:33:09 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:33:09 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:33:09 --> Utf8 Class Initialized
INFO - 2016-01-29 09:33:09 --> URI Class Initialized
INFO - 2016-01-29 09:33:09 --> Router Class Initialized
INFO - 2016-01-29 09:33:09 --> Output Class Initialized
INFO - 2016-01-29 09:33:09 --> Security Class Initialized
DEBUG - 2016-01-29 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:33:09 --> Input Class Initialized
INFO - 2016-01-29 09:33:09 --> Language Class Initialized
INFO - 2016-01-29 09:33:09 --> Loader Class Initialized
INFO - 2016-01-29 09:33:09 --> Helper loaded: url_helper
INFO - 2016-01-29 09:33:09 --> Helper loaded: file_helper
INFO - 2016-01-29 09:33:09 --> Helper loaded: date_helper
INFO - 2016-01-29 09:33:09 --> Database Driver Class Initialized
INFO - 2016-01-29 09:33:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:33:10 --> Controller Class Initialized
INFO - 2016-01-29 09:33:10 --> Model Class Initialized
INFO - 2016-01-29 09:33:10 --> Model Class Initialized
INFO - 2016-01-29 09:33:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:33:10 --> Pagination Class Initialized
INFO - 2016-01-29 09:33:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:33:10 --> Helper loaded: form_helper
INFO - 2016-01-29 09:33:10 --> Form Validation Class Initialized
INFO - 2016-01-29 09:33:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-01-29 09:33:10 --> Config Class Initialized
INFO - 2016-01-29 09:33:10 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:33:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:33:10 --> Utf8 Class Initialized
INFO - 2016-01-29 09:33:10 --> URI Class Initialized
INFO - 2016-01-29 09:33:10 --> Router Class Initialized
INFO - 2016-01-29 09:33:10 --> Output Class Initialized
INFO - 2016-01-29 09:33:10 --> Security Class Initialized
DEBUG - 2016-01-29 09:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:33:10 --> Input Class Initialized
INFO - 2016-01-29 09:33:10 --> Language Class Initialized
INFO - 2016-01-29 09:33:10 --> Loader Class Initialized
INFO - 2016-01-29 09:33:10 --> Helper loaded: url_helper
INFO - 2016-01-29 09:33:10 --> Helper loaded: file_helper
INFO - 2016-01-29 09:33:10 --> Helper loaded: date_helper
INFO - 2016-01-29 09:33:10 --> Database Driver Class Initialized
INFO - 2016-01-29 09:33:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:33:11 --> Controller Class Initialized
INFO - 2016-01-29 09:33:11 --> Model Class Initialized
INFO - 2016-01-29 09:33:11 --> Model Class Initialized
INFO - 2016-01-29 09:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:33:11 --> Pagination Class Initialized
INFO - 2016-01-29 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:33:11 --> Helper loaded: text_helper
INFO - 2016-01-29 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:33:11 --> Final output sent to browser
DEBUG - 2016-01-29 09:33:11 --> Total execution time: 1.1567
INFO - 2016-01-29 09:33:19 --> Config Class Initialized
INFO - 2016-01-29 09:33:19 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:33:19 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:33:19 --> Utf8 Class Initialized
INFO - 2016-01-29 09:33:19 --> URI Class Initialized
INFO - 2016-01-29 09:33:19 --> Router Class Initialized
INFO - 2016-01-29 09:33:19 --> Output Class Initialized
INFO - 2016-01-29 09:33:19 --> Security Class Initialized
DEBUG - 2016-01-29 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:33:19 --> Input Class Initialized
INFO - 2016-01-29 09:33:19 --> Language Class Initialized
INFO - 2016-01-29 09:33:19 --> Loader Class Initialized
INFO - 2016-01-29 09:33:19 --> Helper loaded: url_helper
INFO - 2016-01-29 09:33:19 --> Helper loaded: file_helper
INFO - 2016-01-29 09:33:19 --> Helper loaded: date_helper
INFO - 2016-01-29 09:33:19 --> Database Driver Class Initialized
INFO - 2016-01-29 09:33:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:33:20 --> Controller Class Initialized
INFO - 2016-01-29 09:33:20 --> Model Class Initialized
INFO - 2016-01-29 09:33:20 --> Model Class Initialized
INFO - 2016-01-29 09:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:33:20 --> Pagination Class Initialized
INFO - 2016-01-29 09:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-01-29 09:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-29 09:33:20 --> Final output sent to browser
DEBUG - 2016-01-29 09:33:20 --> Total execution time: 1.1636
INFO - 2016-01-29 09:34:01 --> Config Class Initialized
INFO - 2016-01-29 09:34:01 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:34:01 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:34:01 --> Utf8 Class Initialized
INFO - 2016-01-29 09:34:01 --> URI Class Initialized
INFO - 2016-01-29 09:34:01 --> Router Class Initialized
INFO - 2016-01-29 09:34:01 --> Output Class Initialized
INFO - 2016-01-29 09:34:01 --> Security Class Initialized
DEBUG - 2016-01-29 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:34:01 --> Input Class Initialized
INFO - 2016-01-29 09:34:01 --> Language Class Initialized
INFO - 2016-01-29 09:34:01 --> Loader Class Initialized
INFO - 2016-01-29 09:34:01 --> Helper loaded: url_helper
INFO - 2016-01-29 09:34:01 --> Helper loaded: file_helper
INFO - 2016-01-29 09:34:01 --> Helper loaded: date_helper
INFO - 2016-01-29 09:34:01 --> Database Driver Class Initialized
INFO - 2016-01-29 09:34:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:34:02 --> Controller Class Initialized
INFO - 2016-01-29 09:34:02 --> Model Class Initialized
INFO - 2016-01-29 09:34:02 --> Model Class Initialized
INFO - 2016-01-29 09:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:34:02 --> Pagination Class Initialized
INFO - 2016-01-29 09:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:34:03 --> Config Class Initialized
INFO - 2016-01-29 09:34:03 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:34:03 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:34:03 --> Utf8 Class Initialized
INFO - 2016-01-29 09:34:03 --> URI Class Initialized
INFO - 2016-01-29 09:34:03 --> Router Class Initialized
INFO - 2016-01-29 09:34:03 --> Output Class Initialized
INFO - 2016-01-29 09:34:03 --> Security Class Initialized
DEBUG - 2016-01-29 09:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:34:03 --> Input Class Initialized
INFO - 2016-01-29 09:34:03 --> Language Class Initialized
INFO - 2016-01-29 09:34:03 --> Loader Class Initialized
INFO - 2016-01-29 09:34:03 --> Helper loaded: url_helper
INFO - 2016-01-29 09:34:03 --> Helper loaded: file_helper
INFO - 2016-01-29 09:34:03 --> Helper loaded: date_helper
INFO - 2016-01-29 09:34:03 --> Database Driver Class Initialized
INFO - 2016-01-29 09:34:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:34:04 --> Controller Class Initialized
INFO - 2016-01-29 09:34:04 --> Model Class Initialized
INFO - 2016-01-29 09:34:04 --> Model Class Initialized
INFO - 2016-01-29 09:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:34:04 --> Pagination Class Initialized
INFO - 2016-01-29 09:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:34:04 --> Helper loaded: text_helper
INFO - 2016-01-29 09:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:34:04 --> Final output sent to browser
DEBUG - 2016-01-29 09:34:04 --> Total execution time: 1.2093
INFO - 2016-01-29 09:40:25 --> Config Class Initialized
INFO - 2016-01-29 09:40:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:40:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:40:25 --> Utf8 Class Initialized
INFO - 2016-01-29 09:40:25 --> URI Class Initialized
INFO - 2016-01-29 09:40:25 --> Router Class Initialized
INFO - 2016-01-29 09:40:25 --> Output Class Initialized
INFO - 2016-01-29 09:40:25 --> Security Class Initialized
DEBUG - 2016-01-29 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:40:25 --> Input Class Initialized
INFO - 2016-01-29 09:40:25 --> Language Class Initialized
INFO - 2016-01-29 09:40:25 --> Loader Class Initialized
INFO - 2016-01-29 09:40:25 --> Helper loaded: url_helper
INFO - 2016-01-29 09:40:25 --> Helper loaded: file_helper
INFO - 2016-01-29 09:40:25 --> Helper loaded: date_helper
INFO - 2016-01-29 09:40:25 --> Database Driver Class Initialized
INFO - 2016-01-29 09:40:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:40:26 --> Controller Class Initialized
INFO - 2016-01-29 09:40:26 --> Model Class Initialized
INFO - 2016-01-29 09:40:26 --> Model Class Initialized
INFO - 2016-01-29 09:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:40:26 --> Pagination Class Initialized
INFO - 2016-01-29 09:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:40:26 --> Helper loaded: text_helper
INFO - 2016-01-29 09:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:40:27 --> Final output sent to browser
DEBUG - 2016-01-29 09:40:27 --> Total execution time: 1.1684
INFO - 2016-01-29 09:41:21 --> Config Class Initialized
INFO - 2016-01-29 09:41:21 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:41:21 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:41:21 --> Utf8 Class Initialized
INFO - 2016-01-29 09:41:21 --> URI Class Initialized
DEBUG - 2016-01-29 09:41:21 --> No URI present. Default controller set.
INFO - 2016-01-29 09:41:21 --> Router Class Initialized
INFO - 2016-01-29 09:41:21 --> Output Class Initialized
INFO - 2016-01-29 09:41:21 --> Security Class Initialized
DEBUG - 2016-01-29 09:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:41:21 --> Input Class Initialized
INFO - 2016-01-29 09:41:21 --> Language Class Initialized
INFO - 2016-01-29 09:41:21 --> Loader Class Initialized
INFO - 2016-01-29 09:41:21 --> Helper loaded: url_helper
INFO - 2016-01-29 09:41:21 --> Helper loaded: file_helper
INFO - 2016-01-29 09:41:21 --> Helper loaded: date_helper
INFO - 2016-01-29 09:41:21 --> Database Driver Class Initialized
INFO - 2016-01-29 09:41:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:41:22 --> Controller Class Initialized
INFO - 2016-01-29 09:41:22 --> Model Class Initialized
INFO - 2016-01-29 09:41:22 --> Model Class Initialized
INFO - 2016-01-29 09:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:41:22 --> Pagination Class Initialized
INFO - 2016-01-29 09:41:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 09:41:22 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
INFO - 2016-01-29 09:42:17 --> Config Class Initialized
INFO - 2016-01-29 09:42:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:42:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:42:17 --> Utf8 Class Initialized
INFO - 2016-01-29 09:42:17 --> URI Class Initialized
DEBUG - 2016-01-29 09:42:17 --> No URI present. Default controller set.
INFO - 2016-01-29 09:42:17 --> Router Class Initialized
INFO - 2016-01-29 09:42:17 --> Output Class Initialized
INFO - 2016-01-29 09:42:17 --> Security Class Initialized
DEBUG - 2016-01-29 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:42:17 --> Input Class Initialized
INFO - 2016-01-29 09:42:17 --> Language Class Initialized
INFO - 2016-01-29 09:42:17 --> Loader Class Initialized
INFO - 2016-01-29 09:42:17 --> Helper loaded: url_helper
INFO - 2016-01-29 09:42:17 --> Helper loaded: file_helper
INFO - 2016-01-29 09:42:17 --> Helper loaded: date_helper
INFO - 2016-01-29 09:42:17 --> Database Driver Class Initialized
INFO - 2016-01-29 09:42:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:42:18 --> Controller Class Initialized
INFO - 2016-01-29 09:42:18 --> Model Class Initialized
INFO - 2016-01-29 09:42:18 --> Model Class Initialized
INFO - 2016-01-29 09:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:42:18 --> Pagination Class Initialized
INFO - 2016-01-29 09:42:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 09:42:18 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
INFO - 2016-01-29 09:42:37 --> Config Class Initialized
INFO - 2016-01-29 09:42:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:42:37 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:42:37 --> Utf8 Class Initialized
INFO - 2016-01-29 09:42:37 --> URI Class Initialized
DEBUG - 2016-01-29 09:42:37 --> No URI present. Default controller set.
INFO - 2016-01-29 09:42:37 --> Router Class Initialized
INFO - 2016-01-29 09:42:37 --> Output Class Initialized
INFO - 2016-01-29 09:42:37 --> Security Class Initialized
DEBUG - 2016-01-29 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:42:37 --> Input Class Initialized
INFO - 2016-01-29 09:42:37 --> Language Class Initialized
INFO - 2016-01-29 09:42:37 --> Loader Class Initialized
INFO - 2016-01-29 09:42:37 --> Helper loaded: url_helper
INFO - 2016-01-29 09:42:37 --> Helper loaded: file_helper
INFO - 2016-01-29 09:42:37 --> Helper loaded: date_helper
INFO - 2016-01-29 09:42:37 --> Database Driver Class Initialized
INFO - 2016-01-29 09:42:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:42:38 --> Controller Class Initialized
INFO - 2016-01-29 09:42:38 --> Model Class Initialized
INFO - 2016-01-29 09:42:38 --> Model Class Initialized
INFO - 2016-01-29 09:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:42:38 --> Pagination Class Initialized
INFO - 2016-01-29 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-29 09:42:38 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
INFO - 2016-01-29 09:43:37 --> Config Class Initialized
INFO - 2016-01-29 09:43:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:43:37 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:43:37 --> Utf8 Class Initialized
INFO - 2016-01-29 09:43:37 --> URI Class Initialized
DEBUG - 2016-01-29 09:43:37 --> No URI present. Default controller set.
INFO - 2016-01-29 09:43:37 --> Router Class Initialized
INFO - 2016-01-29 09:43:37 --> Output Class Initialized
INFO - 2016-01-29 09:43:37 --> Security Class Initialized
DEBUG - 2016-01-29 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:43:37 --> Input Class Initialized
INFO - 2016-01-29 09:43:37 --> Language Class Initialized
INFO - 2016-01-29 09:43:37 --> Loader Class Initialized
INFO - 2016-01-29 09:43:37 --> Helper loaded: url_helper
INFO - 2016-01-29 09:43:37 --> Helper loaded: file_helper
INFO - 2016-01-29 09:43:37 --> Helper loaded: date_helper
INFO - 2016-01-29 09:43:37 --> Database Driver Class Initialized
INFO - 2016-01-29 09:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:43:38 --> Controller Class Initialized
INFO - 2016-01-29 09:43:38 --> Model Class Initialized
INFO - 2016-01-29 09:43:38 --> Model Class Initialized
INFO - 2016-01-29 09:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:43:38 --> Pagination Class Initialized
INFO - 2016-01-29 09:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:43:38 --> Final output sent to browser
DEBUG - 2016-01-29 09:43:38 --> Total execution time: 1.0995
INFO - 2016-01-29 09:44:31 --> Config Class Initialized
INFO - 2016-01-29 09:44:31 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:44:31 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:44:31 --> Utf8 Class Initialized
INFO - 2016-01-29 09:44:31 --> URI Class Initialized
DEBUG - 2016-01-29 09:44:31 --> No URI present. Default controller set.
INFO - 2016-01-29 09:44:31 --> Router Class Initialized
INFO - 2016-01-29 09:44:31 --> Output Class Initialized
INFO - 2016-01-29 09:44:31 --> Security Class Initialized
DEBUG - 2016-01-29 09:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:44:31 --> Input Class Initialized
INFO - 2016-01-29 09:44:31 --> Language Class Initialized
INFO - 2016-01-29 09:44:31 --> Loader Class Initialized
INFO - 2016-01-29 09:44:31 --> Helper loaded: url_helper
INFO - 2016-01-29 09:44:31 --> Helper loaded: file_helper
INFO - 2016-01-29 09:44:31 --> Helper loaded: date_helper
INFO - 2016-01-29 09:44:31 --> Database Driver Class Initialized
INFO - 2016-01-29 09:44:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:44:32 --> Controller Class Initialized
INFO - 2016-01-29 09:44:32 --> Model Class Initialized
INFO - 2016-01-29 09:44:32 --> Model Class Initialized
INFO - 2016-01-29 09:44:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:44:32 --> Pagination Class Initialized
INFO - 2016-01-29 09:44:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:44:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:44:32 --> Final output sent to browser
DEBUG - 2016-01-29 09:44:32 --> Total execution time: 1.1354
INFO - 2016-01-29 09:44:37 --> Config Class Initialized
INFO - 2016-01-29 09:44:37 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:44:37 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:44:37 --> Utf8 Class Initialized
INFO - 2016-01-29 09:44:37 --> URI Class Initialized
DEBUG - 2016-01-29 09:44:37 --> No URI present. Default controller set.
INFO - 2016-01-29 09:44:37 --> Router Class Initialized
INFO - 2016-01-29 09:44:37 --> Output Class Initialized
INFO - 2016-01-29 09:44:37 --> Security Class Initialized
DEBUG - 2016-01-29 09:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:44:37 --> Input Class Initialized
INFO - 2016-01-29 09:44:37 --> Language Class Initialized
INFO - 2016-01-29 09:44:37 --> Loader Class Initialized
INFO - 2016-01-29 09:44:37 --> Helper loaded: url_helper
INFO - 2016-01-29 09:44:37 --> Helper loaded: file_helper
INFO - 2016-01-29 09:44:37 --> Helper loaded: date_helper
INFO - 2016-01-29 09:44:37 --> Database Driver Class Initialized
INFO - 2016-01-29 09:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:44:38 --> Controller Class Initialized
INFO - 2016-01-29 09:44:38 --> Model Class Initialized
INFO - 2016-01-29 09:44:38 --> Model Class Initialized
INFO - 2016-01-29 09:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:44:38 --> Pagination Class Initialized
INFO - 2016-01-29 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 09:44:38 --> Final output sent to browser
DEBUG - 2016-01-29 09:44:38 --> Total execution time: 1.1083
INFO - 2016-01-29 09:44:42 --> Config Class Initialized
INFO - 2016-01-29 09:44:42 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:44:42 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:44:42 --> Utf8 Class Initialized
INFO - 2016-01-29 09:44:42 --> URI Class Initialized
INFO - 2016-01-29 09:44:42 --> Router Class Initialized
INFO - 2016-01-29 09:44:42 --> Output Class Initialized
INFO - 2016-01-29 09:44:42 --> Security Class Initialized
DEBUG - 2016-01-29 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:44:42 --> Input Class Initialized
INFO - 2016-01-29 09:44:42 --> Language Class Initialized
INFO - 2016-01-29 09:44:42 --> Loader Class Initialized
INFO - 2016-01-29 09:44:42 --> Helper loaded: url_helper
INFO - 2016-01-29 09:44:42 --> Helper loaded: file_helper
INFO - 2016-01-29 09:44:42 --> Helper loaded: date_helper
INFO - 2016-01-29 09:44:42 --> Database Driver Class Initialized
INFO - 2016-01-29 09:44:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:44:43 --> Controller Class Initialized
INFO - 2016-01-29 09:44:43 --> Model Class Initialized
INFO - 2016-01-29 09:44:43 --> Model Class Initialized
INFO - 2016-01-29 09:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:44:43 --> Pagination Class Initialized
INFO - 2016-01-29 09:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:44:43 --> Helper loaded: text_helper
INFO - 2016-01-29 09:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:44:43 --> Final output sent to browser
DEBUG - 2016-01-29 09:44:43 --> Total execution time: 1.1472
INFO - 2016-01-29 09:45:03 --> Config Class Initialized
INFO - 2016-01-29 09:45:03 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:45:03 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:45:03 --> Utf8 Class Initialized
INFO - 2016-01-29 09:45:03 --> URI Class Initialized
INFO - 2016-01-29 09:45:03 --> Router Class Initialized
INFO - 2016-01-29 09:45:03 --> Output Class Initialized
INFO - 2016-01-29 09:45:03 --> Security Class Initialized
DEBUG - 2016-01-29 09:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:45:03 --> Input Class Initialized
INFO - 2016-01-29 09:45:03 --> Language Class Initialized
INFO - 2016-01-29 09:45:03 --> Loader Class Initialized
INFO - 2016-01-29 09:45:03 --> Helper loaded: url_helper
INFO - 2016-01-29 09:45:03 --> Helper loaded: file_helper
INFO - 2016-01-29 09:45:03 --> Helper loaded: date_helper
INFO - 2016-01-29 09:45:03 --> Database Driver Class Initialized
INFO - 2016-01-29 09:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:45:04 --> Controller Class Initialized
INFO - 2016-01-29 09:45:04 --> Model Class Initialized
INFO - 2016-01-29 09:45:04 --> Model Class Initialized
INFO - 2016-01-29 09:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:45:04 --> Pagination Class Initialized
INFO - 2016-01-29 09:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:45:04 --> Helper loaded: text_helper
INFO - 2016-01-29 09:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:45:04 --> Final output sent to browser
DEBUG - 2016-01-29 09:45:04 --> Total execution time: 1.1797
INFO - 2016-01-29 09:45:10 --> Config Class Initialized
INFO - 2016-01-29 09:45:10 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:45:10 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:45:10 --> Utf8 Class Initialized
INFO - 2016-01-29 09:45:10 --> URI Class Initialized
INFO - 2016-01-29 09:45:10 --> Router Class Initialized
INFO - 2016-01-29 09:45:10 --> Output Class Initialized
INFO - 2016-01-29 09:45:10 --> Security Class Initialized
DEBUG - 2016-01-29 09:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:45:10 --> Input Class Initialized
INFO - 2016-01-29 09:45:10 --> Language Class Initialized
INFO - 2016-01-29 09:45:10 --> Loader Class Initialized
INFO - 2016-01-29 09:45:10 --> Helper loaded: url_helper
INFO - 2016-01-29 09:45:10 --> Helper loaded: file_helper
INFO - 2016-01-29 09:45:10 --> Helper loaded: date_helper
INFO - 2016-01-29 09:45:10 --> Database Driver Class Initialized
INFO - 2016-01-29 09:45:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:45:11 --> Controller Class Initialized
INFO - 2016-01-29 09:45:11 --> Model Class Initialized
INFO - 2016-01-29 09:45:11 --> Model Class Initialized
INFO - 2016-01-29 09:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:45:11 --> Pagination Class Initialized
INFO - 2016-01-29 09:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:45:11 --> Helper loaded: text_helper
INFO - 2016-01-29 09:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:45:11 --> Final output sent to browser
DEBUG - 2016-01-29 09:45:11 --> Total execution time: 1.2664
INFO - 2016-01-29 09:45:17 --> Config Class Initialized
INFO - 2016-01-29 09:45:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 09:45:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 09:45:17 --> Utf8 Class Initialized
INFO - 2016-01-29 09:45:17 --> URI Class Initialized
INFO - 2016-01-29 09:45:17 --> Router Class Initialized
INFO - 2016-01-29 09:45:17 --> Output Class Initialized
INFO - 2016-01-29 09:45:17 --> Security Class Initialized
DEBUG - 2016-01-29 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 09:45:17 --> Input Class Initialized
INFO - 2016-01-29 09:45:17 --> Language Class Initialized
INFO - 2016-01-29 09:45:17 --> Loader Class Initialized
INFO - 2016-01-29 09:45:17 --> Helper loaded: url_helper
INFO - 2016-01-29 09:45:17 --> Helper loaded: file_helper
INFO - 2016-01-29 09:45:17 --> Helper loaded: date_helper
INFO - 2016-01-29 09:45:17 --> Database Driver Class Initialized
INFO - 2016-01-29 09:45:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 09:45:18 --> Controller Class Initialized
INFO - 2016-01-29 09:45:18 --> Model Class Initialized
INFO - 2016-01-29 09:45:18 --> Model Class Initialized
INFO - 2016-01-29 09:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 09:45:18 --> Pagination Class Initialized
INFO - 2016-01-29 09:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 09:45:18 --> Helper loaded: text_helper
INFO - 2016-01-29 09:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 09:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 09:45:19 --> Final output sent to browser
DEBUG - 2016-01-29 09:45:19 --> Total execution time: 1.1148
INFO - 2016-01-29 12:44:26 --> Config Class Initialized
INFO - 2016-01-29 12:44:26 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:44:26 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:44:26 --> Utf8 Class Initialized
INFO - 2016-01-29 12:44:26 --> URI Class Initialized
DEBUG - 2016-01-29 12:44:26 --> No URI present. Default controller set.
INFO - 2016-01-29 12:44:26 --> Router Class Initialized
INFO - 2016-01-29 12:44:26 --> Output Class Initialized
INFO - 2016-01-29 12:44:26 --> Security Class Initialized
DEBUG - 2016-01-29 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:44:26 --> Input Class Initialized
INFO - 2016-01-29 12:44:26 --> Language Class Initialized
INFO - 2016-01-29 12:44:26 --> Loader Class Initialized
INFO - 2016-01-29 12:44:26 --> Helper loaded: url_helper
INFO - 2016-01-29 12:44:26 --> Helper loaded: file_helper
INFO - 2016-01-29 12:44:26 --> Helper loaded: date_helper
INFO - 2016-01-29 12:44:26 --> Database Driver Class Initialized
INFO - 2016-01-29 12:44:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:44:27 --> Controller Class Initialized
INFO - 2016-01-29 12:44:27 --> Model Class Initialized
INFO - 2016-01-29 12:44:27 --> Model Class Initialized
INFO - 2016-01-29 12:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:44:27 --> Pagination Class Initialized
INFO - 2016-01-29 12:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:44:27 --> Final output sent to browser
DEBUG - 2016-01-29 12:44:27 --> Total execution time: 1.1408
INFO - 2016-01-29 12:44:44 --> Config Class Initialized
INFO - 2016-01-29 12:44:44 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:44:44 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:44:44 --> Utf8 Class Initialized
INFO - 2016-01-29 12:44:44 --> URI Class Initialized
INFO - 2016-01-29 12:44:44 --> Router Class Initialized
INFO - 2016-01-29 12:44:44 --> Output Class Initialized
INFO - 2016-01-29 12:44:44 --> Security Class Initialized
DEBUG - 2016-01-29 12:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:44:44 --> Input Class Initialized
INFO - 2016-01-29 12:44:44 --> Language Class Initialized
INFO - 2016-01-29 12:44:44 --> Loader Class Initialized
INFO - 2016-01-29 12:44:44 --> Helper loaded: url_helper
INFO - 2016-01-29 12:44:44 --> Helper loaded: file_helper
INFO - 2016-01-29 12:44:44 --> Helper loaded: date_helper
INFO - 2016-01-29 12:44:44 --> Database Driver Class Initialized
INFO - 2016-01-29 12:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:44:45 --> Controller Class Initialized
INFO - 2016-01-29 12:44:45 --> Model Class Initialized
INFO - 2016-01-29 12:44:45 --> Model Class Initialized
INFO - 2016-01-29 12:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:44:45 --> Pagination Class Initialized
INFO - 2016-01-29 12:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:44:45 --> Final output sent to browser
DEBUG - 2016-01-29 12:44:45 --> Total execution time: 1.1527
INFO - 2016-01-29 12:44:47 --> Config Class Initialized
INFO - 2016-01-29 12:44:47 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:44:47 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:44:47 --> Utf8 Class Initialized
INFO - 2016-01-29 12:44:47 --> URI Class Initialized
DEBUG - 2016-01-29 12:44:47 --> No URI present. Default controller set.
INFO - 2016-01-29 12:44:47 --> Router Class Initialized
INFO - 2016-01-29 12:44:47 --> Output Class Initialized
INFO - 2016-01-29 12:44:47 --> Security Class Initialized
DEBUG - 2016-01-29 12:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:44:47 --> Input Class Initialized
INFO - 2016-01-29 12:44:47 --> Language Class Initialized
INFO - 2016-01-29 12:44:47 --> Loader Class Initialized
INFO - 2016-01-29 12:44:47 --> Helper loaded: url_helper
INFO - 2016-01-29 12:44:47 --> Helper loaded: file_helper
INFO - 2016-01-29 12:44:47 --> Helper loaded: date_helper
INFO - 2016-01-29 12:44:47 --> Database Driver Class Initialized
INFO - 2016-01-29 12:44:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:44:48 --> Controller Class Initialized
INFO - 2016-01-29 12:44:48 --> Model Class Initialized
INFO - 2016-01-29 12:44:48 --> Model Class Initialized
INFO - 2016-01-29 12:44:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:44:48 --> Pagination Class Initialized
INFO - 2016-01-29 12:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:44:48 --> Final output sent to browser
DEBUG - 2016-01-29 12:44:48 --> Total execution time: 1.1427
INFO - 2016-01-29 12:44:57 --> Config Class Initialized
INFO - 2016-01-29 12:44:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:44:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:44:57 --> Utf8 Class Initialized
INFO - 2016-01-29 12:44:57 --> URI Class Initialized
INFO - 2016-01-29 12:44:57 --> Router Class Initialized
INFO - 2016-01-29 12:44:57 --> Output Class Initialized
INFO - 2016-01-29 12:44:57 --> Security Class Initialized
DEBUG - 2016-01-29 12:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:44:57 --> Input Class Initialized
INFO - 2016-01-29 12:44:57 --> Language Class Initialized
INFO - 2016-01-29 12:44:57 --> Loader Class Initialized
INFO - 2016-01-29 12:44:57 --> Helper loaded: url_helper
INFO - 2016-01-29 12:44:57 --> Helper loaded: file_helper
INFO - 2016-01-29 12:44:57 --> Helper loaded: date_helper
INFO - 2016-01-29 12:44:57 --> Database Driver Class Initialized
INFO - 2016-01-29 12:44:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:44:58 --> Controller Class Initialized
INFO - 2016-01-29 12:44:58 --> Model Class Initialized
INFO - 2016-01-29 12:44:58 --> Model Class Initialized
INFO - 2016-01-29 12:44:58 --> Helper loaded: form_helper
INFO - 2016-01-29 12:44:58 --> Form Validation Class Initialized
INFO - 2016-01-29 12:44:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:44:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 12:44:58 --> Model Class Initialized
ERROR - 2016-01-29 12:44:58 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 9
INFO - 2016-01-29 12:45:17 --> Config Class Initialized
INFO - 2016-01-29 12:45:17 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:45:17 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:45:17 --> Utf8 Class Initialized
INFO - 2016-01-29 12:45:17 --> URI Class Initialized
INFO - 2016-01-29 12:45:17 --> Router Class Initialized
INFO - 2016-01-29 12:45:17 --> Output Class Initialized
INFO - 2016-01-29 12:45:17 --> Security Class Initialized
DEBUG - 2016-01-29 12:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:45:17 --> Input Class Initialized
INFO - 2016-01-29 12:45:17 --> Language Class Initialized
INFO - 2016-01-29 12:45:17 --> Loader Class Initialized
INFO - 2016-01-29 12:45:17 --> Helper loaded: url_helper
INFO - 2016-01-29 12:45:17 --> Helper loaded: file_helper
INFO - 2016-01-29 12:45:17 --> Helper loaded: date_helper
INFO - 2016-01-29 12:45:17 --> Database Driver Class Initialized
INFO - 2016-01-29 12:45:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:45:18 --> Controller Class Initialized
INFO - 2016-01-29 12:45:18 --> Model Class Initialized
INFO - 2016-01-29 12:45:18 --> Model Class Initialized
INFO - 2016-01-29 12:45:18 --> Helper loaded: form_helper
INFO - 2016-01-29 12:45:18 --> Form Validation Class Initialized
INFO - 2016-01-29 12:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 12:45:18 --> Model Class Initialized
ERROR - 2016-01-29 12:45:18 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 9
INFO - 2016-01-29 12:45:57 --> Config Class Initialized
INFO - 2016-01-29 12:45:57 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:45:57 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:45:57 --> Utf8 Class Initialized
INFO - 2016-01-29 12:45:57 --> URI Class Initialized
DEBUG - 2016-01-29 12:45:57 --> No URI present. Default controller set.
INFO - 2016-01-29 12:45:57 --> Router Class Initialized
INFO - 2016-01-29 12:45:57 --> Output Class Initialized
INFO - 2016-01-29 12:45:57 --> Security Class Initialized
DEBUG - 2016-01-29 12:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:45:57 --> Input Class Initialized
INFO - 2016-01-29 12:45:57 --> Language Class Initialized
INFO - 2016-01-29 12:45:57 --> Loader Class Initialized
INFO - 2016-01-29 12:45:57 --> Helper loaded: url_helper
INFO - 2016-01-29 12:45:57 --> Helper loaded: file_helper
INFO - 2016-01-29 12:45:57 --> Helper loaded: date_helper
INFO - 2016-01-29 12:45:57 --> Database Driver Class Initialized
INFO - 2016-01-29 12:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:45:58 --> Controller Class Initialized
INFO - 2016-01-29 12:45:58 --> Model Class Initialized
INFO - 2016-01-29 12:45:58 --> Model Class Initialized
INFO - 2016-01-29 12:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:45:58 --> Pagination Class Initialized
INFO - 2016-01-29 12:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:45:58 --> Final output sent to browser
DEBUG - 2016-01-29 12:45:58 --> Total execution time: 1.1259
INFO - 2016-01-29 12:46:00 --> Config Class Initialized
INFO - 2016-01-29 12:46:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:46:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:46:00 --> Utf8 Class Initialized
INFO - 2016-01-29 12:46:00 --> URI Class Initialized
INFO - 2016-01-29 12:46:00 --> Router Class Initialized
INFO - 2016-01-29 12:46:00 --> Output Class Initialized
INFO - 2016-01-29 12:46:00 --> Security Class Initialized
DEBUG - 2016-01-29 12:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:46:00 --> Input Class Initialized
INFO - 2016-01-29 12:46:00 --> Language Class Initialized
INFO - 2016-01-29 12:46:00 --> Loader Class Initialized
INFO - 2016-01-29 12:46:00 --> Helper loaded: url_helper
INFO - 2016-01-29 12:46:00 --> Helper loaded: file_helper
INFO - 2016-01-29 12:46:00 --> Helper loaded: date_helper
INFO - 2016-01-29 12:46:00 --> Database Driver Class Initialized
INFO - 2016-01-29 12:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:46:01 --> Controller Class Initialized
INFO - 2016-01-29 12:46:01 --> Model Class Initialized
INFO - 2016-01-29 12:46:01 --> Model Class Initialized
INFO - 2016-01-29 12:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:46:01 --> Pagination Class Initialized
INFO - 2016-01-29 12:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:46:01 --> Helper loaded: text_helper
INFO - 2016-01-29 12:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 12:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:46:01 --> Final output sent to browser
DEBUG - 2016-01-29 12:46:01 --> Total execution time: 1.1492
INFO - 2016-01-29 12:46:55 --> Config Class Initialized
INFO - 2016-01-29 12:46:55 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:46:55 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:46:55 --> Utf8 Class Initialized
INFO - 2016-01-29 12:46:55 --> URI Class Initialized
INFO - 2016-01-29 12:46:55 --> Router Class Initialized
INFO - 2016-01-29 12:46:55 --> Output Class Initialized
INFO - 2016-01-29 12:46:56 --> Security Class Initialized
DEBUG - 2016-01-29 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:46:56 --> Input Class Initialized
INFO - 2016-01-29 12:46:56 --> Language Class Initialized
INFO - 2016-01-29 12:46:56 --> Loader Class Initialized
INFO - 2016-01-29 12:46:56 --> Helper loaded: url_helper
INFO - 2016-01-29 12:46:56 --> Helper loaded: file_helper
INFO - 2016-01-29 12:46:56 --> Helper loaded: date_helper
INFO - 2016-01-29 12:46:56 --> Database Driver Class Initialized
INFO - 2016-01-29 12:46:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:46:57 --> Controller Class Initialized
INFO - 2016-01-29 12:46:57 --> Model Class Initialized
INFO - 2016-01-29 12:46:57 --> Model Class Initialized
INFO - 2016-01-29 12:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:46:57 --> Pagination Class Initialized
INFO - 2016-01-29 12:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:46:57 --> Helper loaded: text_helper
INFO - 2016-01-29 12:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 12:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:46:57 --> Final output sent to browser
DEBUG - 2016-01-29 12:46:57 --> Total execution time: 1.2265
INFO - 2016-01-29 12:46:58 --> Config Class Initialized
INFO - 2016-01-29 12:46:58 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:46:58 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:46:58 --> Utf8 Class Initialized
INFO - 2016-01-29 12:46:58 --> URI Class Initialized
INFO - 2016-01-29 12:46:58 --> Router Class Initialized
INFO - 2016-01-29 12:46:58 --> Output Class Initialized
INFO - 2016-01-29 12:46:58 --> Security Class Initialized
DEBUG - 2016-01-29 12:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:46:58 --> Input Class Initialized
INFO - 2016-01-29 12:46:58 --> Language Class Initialized
INFO - 2016-01-29 12:46:58 --> Loader Class Initialized
INFO - 2016-01-29 12:46:58 --> Helper loaded: url_helper
INFO - 2016-01-29 12:46:58 --> Helper loaded: file_helper
INFO - 2016-01-29 12:46:58 --> Helper loaded: date_helper
INFO - 2016-01-29 12:46:58 --> Database Driver Class Initialized
INFO - 2016-01-29 12:46:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:46:59 --> Controller Class Initialized
INFO - 2016-01-29 12:46:59 --> Model Class Initialized
INFO - 2016-01-29 12:46:59 --> Model Class Initialized
INFO - 2016-01-29 12:46:59 --> Helper loaded: form_helper
INFO - 2016-01-29 12:46:59 --> Form Validation Class Initialized
INFO - 2016-01-29 12:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 12:46:59 --> Model Class Initialized
ERROR - 2016-01-29 12:46:59 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 9
INFO - 2016-01-29 12:47:15 --> Config Class Initialized
INFO - 2016-01-29 12:47:15 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:47:15 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:47:15 --> Utf8 Class Initialized
INFO - 2016-01-29 12:47:15 --> URI Class Initialized
INFO - 2016-01-29 12:47:15 --> Router Class Initialized
INFO - 2016-01-29 12:47:15 --> Output Class Initialized
INFO - 2016-01-29 12:47:15 --> Security Class Initialized
DEBUG - 2016-01-29 12:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:47:15 --> Input Class Initialized
INFO - 2016-01-29 12:47:15 --> Language Class Initialized
INFO - 2016-01-29 12:47:15 --> Loader Class Initialized
INFO - 2016-01-29 12:47:15 --> Helper loaded: url_helper
INFO - 2016-01-29 12:47:15 --> Helper loaded: file_helper
INFO - 2016-01-29 12:47:15 --> Helper loaded: date_helper
INFO - 2016-01-29 12:47:15 --> Database Driver Class Initialized
INFO - 2016-01-29 12:47:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:47:16 --> Controller Class Initialized
INFO - 2016-01-29 12:47:16 --> Model Class Initialized
INFO - 2016-01-29 12:47:16 --> Model Class Initialized
INFO - 2016-01-29 12:47:16 --> Helper loaded: form_helper
INFO - 2016-01-29 12:47:16 --> Form Validation Class Initialized
INFO - 2016-01-29 12:47:16 --> Helper loaded: text_helper
INFO - 2016-01-29 12:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 12:47:16 --> Model Class Initialized
INFO - 2016-01-29 12:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:47:16 --> Final output sent to browser
DEBUG - 2016-01-29 12:47:16 --> Total execution time: 1.1558
INFO - 2016-01-29 12:47:25 --> Config Class Initialized
INFO - 2016-01-29 12:47:25 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:47:25 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:47:25 --> Utf8 Class Initialized
INFO - 2016-01-29 12:47:25 --> URI Class Initialized
INFO - 2016-01-29 12:47:25 --> Router Class Initialized
INFO - 2016-01-29 12:47:25 --> Output Class Initialized
INFO - 2016-01-29 12:47:25 --> Security Class Initialized
DEBUG - 2016-01-29 12:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:47:25 --> Input Class Initialized
INFO - 2016-01-29 12:47:25 --> Language Class Initialized
INFO - 2016-01-29 12:47:25 --> Loader Class Initialized
INFO - 2016-01-29 12:47:25 --> Helper loaded: url_helper
INFO - 2016-01-29 12:47:25 --> Helper loaded: file_helper
INFO - 2016-01-29 12:47:25 --> Helper loaded: date_helper
INFO - 2016-01-29 12:47:25 --> Database Driver Class Initialized
INFO - 2016-01-29 12:47:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:47:26 --> Controller Class Initialized
INFO - 2016-01-29 12:47:26 --> Model Class Initialized
INFO - 2016-01-29 12:47:26 --> Model Class Initialized
INFO - 2016-01-29 12:47:26 --> Helper loaded: form_helper
INFO - 2016-01-29 12:47:27 --> Form Validation Class Initialized
INFO - 2016-01-29 12:47:27 --> Helper loaded: text_helper
INFO - 2016-01-29 12:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 12:47:27 --> Model Class Initialized
INFO - 2016-01-29 12:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:47:27 --> Final output sent to browser
DEBUG - 2016-01-29 12:47:27 --> Total execution time: 1.1556
INFO - 2016-01-29 12:47:43 --> Config Class Initialized
INFO - 2016-01-29 12:47:43 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:47:43 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:47:43 --> Utf8 Class Initialized
INFO - 2016-01-29 12:47:43 --> URI Class Initialized
DEBUG - 2016-01-29 12:47:43 --> No URI present. Default controller set.
INFO - 2016-01-29 12:47:43 --> Router Class Initialized
INFO - 2016-01-29 12:47:43 --> Output Class Initialized
INFO - 2016-01-29 12:47:43 --> Security Class Initialized
DEBUG - 2016-01-29 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:47:43 --> Input Class Initialized
INFO - 2016-01-29 12:47:43 --> Language Class Initialized
INFO - 2016-01-29 12:47:43 --> Loader Class Initialized
INFO - 2016-01-29 12:47:43 --> Helper loaded: url_helper
INFO - 2016-01-29 12:47:43 --> Helper loaded: file_helper
INFO - 2016-01-29 12:47:43 --> Helper loaded: date_helper
INFO - 2016-01-29 12:47:43 --> Database Driver Class Initialized
INFO - 2016-01-29 12:47:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:47:44 --> Controller Class Initialized
INFO - 2016-01-29 12:47:44 --> Model Class Initialized
INFO - 2016-01-29 12:47:44 --> Model Class Initialized
INFO - 2016-01-29 12:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:47:44 --> Pagination Class Initialized
INFO - 2016-01-29 12:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:47:44 --> Final output sent to browser
DEBUG - 2016-01-29 12:47:44 --> Total execution time: 1.1120
INFO - 2016-01-29 12:47:56 --> Config Class Initialized
INFO - 2016-01-29 12:47:56 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:47:56 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:47:56 --> Utf8 Class Initialized
INFO - 2016-01-29 12:47:56 --> URI Class Initialized
DEBUG - 2016-01-29 12:47:56 --> No URI present. Default controller set.
INFO - 2016-01-29 12:47:56 --> Router Class Initialized
INFO - 2016-01-29 12:47:56 --> Output Class Initialized
INFO - 2016-01-29 12:47:56 --> Security Class Initialized
DEBUG - 2016-01-29 12:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:47:56 --> Input Class Initialized
INFO - 2016-01-29 12:47:56 --> Language Class Initialized
INFO - 2016-01-29 12:47:56 --> Loader Class Initialized
INFO - 2016-01-29 12:47:56 --> Helper loaded: url_helper
INFO - 2016-01-29 12:47:56 --> Helper loaded: file_helper
INFO - 2016-01-29 12:47:56 --> Helper loaded: date_helper
INFO - 2016-01-29 12:47:56 --> Database Driver Class Initialized
INFO - 2016-01-29 12:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:47:57 --> Controller Class Initialized
INFO - 2016-01-29 12:47:57 --> Model Class Initialized
INFO - 2016-01-29 12:47:57 --> Model Class Initialized
INFO - 2016-01-29 12:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:47:57 --> Pagination Class Initialized
INFO - 2016-01-29 12:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:47:57 --> Final output sent to browser
DEBUG - 2016-01-29 12:47:57 --> Total execution time: 1.1250
INFO - 2016-01-29 12:49:33 --> Config Class Initialized
INFO - 2016-01-29 12:49:33 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:49:33 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:49:33 --> Utf8 Class Initialized
INFO - 2016-01-29 12:49:33 --> URI Class Initialized
INFO - 2016-01-29 12:49:33 --> Router Class Initialized
INFO - 2016-01-29 12:49:33 --> Output Class Initialized
INFO - 2016-01-29 12:49:33 --> Security Class Initialized
DEBUG - 2016-01-29 12:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:49:33 --> Input Class Initialized
INFO - 2016-01-29 12:49:33 --> Language Class Initialized
INFO - 2016-01-29 12:49:33 --> Loader Class Initialized
INFO - 2016-01-29 12:49:33 --> Helper loaded: url_helper
INFO - 2016-01-29 12:49:33 --> Helper loaded: file_helper
INFO - 2016-01-29 12:49:33 --> Helper loaded: date_helper
INFO - 2016-01-29 12:49:33 --> Database Driver Class Initialized
INFO - 2016-01-29 12:49:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:49:34 --> Controller Class Initialized
INFO - 2016-01-29 12:49:34 --> Model Class Initialized
INFO - 2016-01-29 12:49:34 --> Model Class Initialized
INFO - 2016-01-29 12:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:49:34 --> Pagination Class Initialized
INFO - 2016-01-29 12:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:49:34 --> Helper loaded: text_helper
INFO - 2016-01-29 12:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 12:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:49:34 --> Final output sent to browser
DEBUG - 2016-01-29 12:49:34 --> Total execution time: 1.1751
INFO - 2016-01-29 12:50:05 --> Config Class Initialized
INFO - 2016-01-29 12:50:05 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:50:05 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:50:05 --> Utf8 Class Initialized
INFO - 2016-01-29 12:50:05 --> URI Class Initialized
DEBUG - 2016-01-29 12:50:05 --> No URI present. Default controller set.
INFO - 2016-01-29 12:50:05 --> Router Class Initialized
INFO - 2016-01-29 12:50:05 --> Output Class Initialized
INFO - 2016-01-29 12:50:05 --> Security Class Initialized
DEBUG - 2016-01-29 12:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:50:05 --> Input Class Initialized
INFO - 2016-01-29 12:50:05 --> Language Class Initialized
INFO - 2016-01-29 12:50:05 --> Loader Class Initialized
INFO - 2016-01-29 12:50:05 --> Helper loaded: url_helper
INFO - 2016-01-29 12:50:05 --> Helper loaded: file_helper
INFO - 2016-01-29 12:50:05 --> Helper loaded: date_helper
INFO - 2016-01-29 12:50:05 --> Database Driver Class Initialized
INFO - 2016-01-29 12:50:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:50:06 --> Controller Class Initialized
INFO - 2016-01-29 12:50:06 --> Model Class Initialized
INFO - 2016-01-29 12:50:06 --> Model Class Initialized
INFO - 2016-01-29 12:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:50:06 --> Pagination Class Initialized
INFO - 2016-01-29 12:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:50:06 --> Final output sent to browser
DEBUG - 2016-01-29 12:50:06 --> Total execution time: 1.1167
INFO - 2016-01-29 12:50:59 --> Config Class Initialized
INFO - 2016-01-29 12:50:59 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:50:59 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:50:59 --> Utf8 Class Initialized
INFO - 2016-01-29 12:50:59 --> URI Class Initialized
INFO - 2016-01-29 12:50:59 --> Router Class Initialized
INFO - 2016-01-29 12:50:59 --> Output Class Initialized
INFO - 2016-01-29 12:50:59 --> Security Class Initialized
DEBUG - 2016-01-29 12:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:50:59 --> Input Class Initialized
INFO - 2016-01-29 12:50:59 --> Language Class Initialized
INFO - 2016-01-29 12:50:59 --> Loader Class Initialized
INFO - 2016-01-29 12:50:59 --> Helper loaded: url_helper
INFO - 2016-01-29 12:50:59 --> Helper loaded: file_helper
INFO - 2016-01-29 12:50:59 --> Helper loaded: date_helper
INFO - 2016-01-29 12:50:59 --> Database Driver Class Initialized
INFO - 2016-01-29 12:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:51:00 --> Controller Class Initialized
INFO - 2016-01-29 12:51:00 --> Model Class Initialized
INFO - 2016-01-29 12:51:00 --> Model Class Initialized
INFO - 2016-01-29 12:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:51:00 --> Pagination Class Initialized
INFO - 2016-01-29 12:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:51:00 --> Helper loaded: text_helper
INFO - 2016-01-29 12:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 12:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:51:00 --> Final output sent to browser
DEBUG - 2016-01-29 12:51:00 --> Total execution time: 1.1618
INFO - 2016-01-29 12:59:41 --> Config Class Initialized
INFO - 2016-01-29 12:59:41 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:59:41 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:59:41 --> Utf8 Class Initialized
INFO - 2016-01-29 12:59:41 --> URI Class Initialized
DEBUG - 2016-01-29 12:59:41 --> No URI present. Default controller set.
INFO - 2016-01-29 12:59:41 --> Router Class Initialized
INFO - 2016-01-29 12:59:41 --> Output Class Initialized
INFO - 2016-01-29 12:59:41 --> Security Class Initialized
DEBUG - 2016-01-29 12:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:59:41 --> Input Class Initialized
INFO - 2016-01-29 12:59:41 --> Language Class Initialized
INFO - 2016-01-29 12:59:41 --> Loader Class Initialized
INFO - 2016-01-29 12:59:41 --> Helper loaded: url_helper
INFO - 2016-01-29 12:59:41 --> Helper loaded: file_helper
INFO - 2016-01-29 12:59:41 --> Helper loaded: date_helper
INFO - 2016-01-29 12:59:41 --> Database Driver Class Initialized
INFO - 2016-01-29 12:59:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:59:42 --> Controller Class Initialized
INFO - 2016-01-29 12:59:42 --> Model Class Initialized
INFO - 2016-01-29 12:59:42 --> Model Class Initialized
INFO - 2016-01-29 12:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:59:42 --> Pagination Class Initialized
INFO - 2016-01-29 12:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 12:59:42 --> Final output sent to browser
DEBUG - 2016-01-29 12:59:42 --> Total execution time: 1.1106
INFO - 2016-01-29 12:59:47 --> Config Class Initialized
INFO - 2016-01-29 12:59:47 --> Hooks Class Initialized
DEBUG - 2016-01-29 12:59:47 --> UTF-8 Support Enabled
INFO - 2016-01-29 12:59:47 --> Utf8 Class Initialized
INFO - 2016-01-29 12:59:47 --> URI Class Initialized
INFO - 2016-01-29 12:59:47 --> Router Class Initialized
INFO - 2016-01-29 12:59:47 --> Output Class Initialized
INFO - 2016-01-29 12:59:47 --> Security Class Initialized
DEBUG - 2016-01-29 12:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 12:59:47 --> Input Class Initialized
INFO - 2016-01-29 12:59:47 --> Language Class Initialized
INFO - 2016-01-29 12:59:47 --> Loader Class Initialized
INFO - 2016-01-29 12:59:47 --> Helper loaded: url_helper
INFO - 2016-01-29 12:59:47 --> Helper loaded: file_helper
INFO - 2016-01-29 12:59:47 --> Helper loaded: date_helper
INFO - 2016-01-29 12:59:47 --> Database Driver Class Initialized
INFO - 2016-01-29 12:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 12:59:48 --> Controller Class Initialized
INFO - 2016-01-29 12:59:48 --> Model Class Initialized
INFO - 2016-01-29 12:59:48 --> Model Class Initialized
INFO - 2016-01-29 12:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 12:59:48 --> Pagination Class Initialized
INFO - 2016-01-29 12:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 12:59:48 --> Helper loaded: text_helper
INFO - 2016-01-29 12:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 12:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 12:59:48 --> Final output sent to browser
DEBUG - 2016-01-29 12:59:48 --> Total execution time: 1.1661
INFO - 2016-01-29 13:05:47 --> Config Class Initialized
INFO - 2016-01-29 13:05:47 --> Hooks Class Initialized
DEBUG - 2016-01-29 13:05:47 --> UTF-8 Support Enabled
INFO - 2016-01-29 13:05:47 --> Utf8 Class Initialized
INFO - 2016-01-29 13:05:47 --> URI Class Initialized
INFO - 2016-01-29 13:05:47 --> Router Class Initialized
INFO - 2016-01-29 13:05:47 --> Output Class Initialized
INFO - 2016-01-29 13:05:47 --> Security Class Initialized
DEBUG - 2016-01-29 13:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 13:05:47 --> Input Class Initialized
INFO - 2016-01-29 13:05:47 --> Language Class Initialized
INFO - 2016-01-29 13:05:47 --> Loader Class Initialized
INFO - 2016-01-29 13:05:47 --> Helper loaded: url_helper
INFO - 2016-01-29 13:05:47 --> Helper loaded: file_helper
INFO - 2016-01-29 13:05:47 --> Helper loaded: date_helper
INFO - 2016-01-29 13:05:47 --> Database Driver Class Initialized
INFO - 2016-01-29 13:05:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 13:05:48 --> Controller Class Initialized
INFO - 2016-01-29 13:05:48 --> Model Class Initialized
INFO - 2016-01-29 13:05:48 --> Model Class Initialized
INFO - 2016-01-29 13:05:48 --> Helper loaded: form_helper
INFO - 2016-01-29 13:05:48 --> Form Validation Class Initialized
INFO - 2016-01-29 13:05:48 --> Helper loaded: text_helper
INFO - 2016-01-29 13:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 13:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 13:05:48 --> Final output sent to browser
DEBUG - 2016-01-29 13:05:48 --> Total execution time: 1.1296
INFO - 2016-01-29 13:05:51 --> Config Class Initialized
INFO - 2016-01-29 13:05:51 --> Hooks Class Initialized
DEBUG - 2016-01-29 13:05:51 --> UTF-8 Support Enabled
INFO - 2016-01-29 13:05:51 --> Utf8 Class Initialized
INFO - 2016-01-29 13:05:51 --> URI Class Initialized
DEBUG - 2016-01-29 13:05:51 --> No URI present. Default controller set.
INFO - 2016-01-29 13:05:51 --> Router Class Initialized
INFO - 2016-01-29 13:05:51 --> Output Class Initialized
INFO - 2016-01-29 13:05:51 --> Security Class Initialized
DEBUG - 2016-01-29 13:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 13:05:51 --> Input Class Initialized
INFO - 2016-01-29 13:05:51 --> Language Class Initialized
INFO - 2016-01-29 13:05:51 --> Loader Class Initialized
INFO - 2016-01-29 13:05:51 --> Helper loaded: url_helper
INFO - 2016-01-29 13:05:51 --> Helper loaded: file_helper
INFO - 2016-01-29 13:05:51 --> Helper loaded: date_helper
INFO - 2016-01-29 13:05:51 --> Database Driver Class Initialized
INFO - 2016-01-29 13:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 13:05:52 --> Controller Class Initialized
INFO - 2016-01-29 13:05:52 --> Model Class Initialized
INFO - 2016-01-29 13:05:52 --> Model Class Initialized
INFO - 2016-01-29 13:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 13:05:52 --> Pagination Class Initialized
INFO - 2016-01-29 13:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 13:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 13:05:52 --> Final output sent to browser
DEBUG - 2016-01-29 13:05:52 --> Total execution time: 1.1173
INFO - 2016-01-29 13:05:54 --> Config Class Initialized
INFO - 2016-01-29 13:05:54 --> Hooks Class Initialized
DEBUG - 2016-01-29 13:05:54 --> UTF-8 Support Enabled
INFO - 2016-01-29 13:05:54 --> Utf8 Class Initialized
INFO - 2016-01-29 13:05:54 --> URI Class Initialized
DEBUG - 2016-01-29 13:05:54 --> No URI present. Default controller set.
INFO - 2016-01-29 13:05:54 --> Router Class Initialized
INFO - 2016-01-29 13:05:54 --> Output Class Initialized
INFO - 2016-01-29 13:05:54 --> Security Class Initialized
DEBUG - 2016-01-29 13:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 13:05:54 --> Input Class Initialized
INFO - 2016-01-29 13:05:54 --> Language Class Initialized
INFO - 2016-01-29 13:05:54 --> Loader Class Initialized
INFO - 2016-01-29 13:05:54 --> Helper loaded: url_helper
INFO - 2016-01-29 13:05:54 --> Helper loaded: file_helper
INFO - 2016-01-29 13:05:54 --> Helper loaded: date_helper
INFO - 2016-01-29 13:05:54 --> Database Driver Class Initialized
INFO - 2016-01-29 13:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 13:05:55 --> Controller Class Initialized
INFO - 2016-01-29 13:05:55 --> Model Class Initialized
INFO - 2016-01-29 13:05:55 --> Model Class Initialized
INFO - 2016-01-29 13:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 13:05:55 --> Pagination Class Initialized
INFO - 2016-01-29 13:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 13:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 13:05:55 --> Final output sent to browser
DEBUG - 2016-01-29 13:05:55 --> Total execution time: 1.1346
INFO - 2016-01-29 22:45:49 --> Config Class Initialized
INFO - 2016-01-29 22:45:49 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:45:49 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:45:49 --> Utf8 Class Initialized
INFO - 2016-01-29 22:45:49 --> URI Class Initialized
DEBUG - 2016-01-29 22:45:49 --> No URI present. Default controller set.
INFO - 2016-01-29 22:45:49 --> Router Class Initialized
INFO - 2016-01-29 22:45:49 --> Output Class Initialized
INFO - 2016-01-29 22:45:49 --> Security Class Initialized
DEBUG - 2016-01-29 22:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:45:49 --> Input Class Initialized
INFO - 2016-01-29 22:45:49 --> Language Class Initialized
INFO - 2016-01-29 22:45:49 --> Loader Class Initialized
INFO - 2016-01-29 22:45:49 --> Helper loaded: url_helper
INFO - 2016-01-29 22:45:49 --> Helper loaded: file_helper
INFO - 2016-01-29 22:45:49 --> Helper loaded: date_helper
INFO - 2016-01-29 22:45:49 --> Database Driver Class Initialized
INFO - 2016-01-29 22:45:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:45:50 --> Controller Class Initialized
INFO - 2016-01-29 22:45:50 --> Model Class Initialized
INFO - 2016-01-29 22:45:50 --> Model Class Initialized
INFO - 2016-01-29 22:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:45:50 --> Pagination Class Initialized
INFO - 2016-01-29 22:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 22:45:50 --> Final output sent to browser
DEBUG - 2016-01-29 22:45:50 --> Total execution time: 1.1719
INFO - 2016-01-29 22:46:13 --> Config Class Initialized
INFO - 2016-01-29 22:46:13 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:13 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:13 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:13 --> URI Class Initialized
INFO - 2016-01-29 22:46:13 --> Router Class Initialized
INFO - 2016-01-29 22:46:13 --> Output Class Initialized
INFO - 2016-01-29 22:46:13 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:13 --> Input Class Initialized
INFO - 2016-01-29 22:46:13 --> Language Class Initialized
INFO - 2016-01-29 22:46:13 --> Loader Class Initialized
INFO - 2016-01-29 22:46:13 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:13 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:13 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:13 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:14 --> Controller Class Initialized
INFO - 2016-01-29 22:46:14 --> Model Class Initialized
INFO - 2016-01-29 22:46:14 --> Model Class Initialized
INFO - 2016-01-29 22:46:14 --> Helper loaded: form_helper
INFO - 2016-01-29 22:46:14 --> Form Validation Class Initialized
INFO - 2016-01-29 22:46:14 --> Helper loaded: text_helper
INFO - 2016-01-29 22:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-01-29 22:46:14 --> Model Class Initialized
INFO - 2016-01-29 22:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 22:46:14 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:14 --> Total execution time: 1.1392
INFO - 2016-01-29 22:46:18 --> Config Class Initialized
INFO - 2016-01-29 22:46:18 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:18 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:18 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:18 --> URI Class Initialized
INFO - 2016-01-29 22:46:18 --> Router Class Initialized
INFO - 2016-01-29 22:46:18 --> Output Class Initialized
INFO - 2016-01-29 22:46:18 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:18 --> Input Class Initialized
INFO - 2016-01-29 22:46:18 --> Language Class Initialized
INFO - 2016-01-29 22:46:18 --> Loader Class Initialized
INFO - 2016-01-29 22:46:18 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:18 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:18 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:18 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:19 --> Controller Class Initialized
INFO - 2016-01-29 22:46:19 --> Model Class Initialized
INFO - 2016-01-29 22:46:19 --> Model Class Initialized
INFO - 2016-01-29 22:46:19 --> Helper loaded: form_helper
INFO - 2016-01-29 22:46:19 --> Form Validation Class Initialized
INFO - 2016-01-29 22:46:19 --> Helper loaded: text_helper
INFO - 2016-01-29 22:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-29 22:46:19 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:19 --> Total execution time: 1.1295
INFO - 2016-01-29 22:46:21 --> Config Class Initialized
INFO - 2016-01-29 22:46:21 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:21 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:21 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:21 --> URI Class Initialized
DEBUG - 2016-01-29 22:46:21 --> No URI present. Default controller set.
INFO - 2016-01-29 22:46:21 --> Router Class Initialized
INFO - 2016-01-29 22:46:21 --> Output Class Initialized
INFO - 2016-01-29 22:46:21 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:21 --> Input Class Initialized
INFO - 2016-01-29 22:46:21 --> Language Class Initialized
INFO - 2016-01-29 22:46:21 --> Loader Class Initialized
INFO - 2016-01-29 22:46:21 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:21 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:21 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:21 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:22 --> Controller Class Initialized
INFO - 2016-01-29 22:46:22 --> Model Class Initialized
INFO - 2016-01-29 22:46:22 --> Model Class Initialized
INFO - 2016-01-29 22:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:46:22 --> Pagination Class Initialized
INFO - 2016-01-29 22:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 22:46:22 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:22 --> Total execution time: 1.1193
INFO - 2016-01-29 22:46:42 --> Config Class Initialized
INFO - 2016-01-29 22:46:42 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:42 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:42 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:42 --> URI Class Initialized
INFO - 2016-01-29 22:46:42 --> Router Class Initialized
INFO - 2016-01-29 22:46:42 --> Output Class Initialized
INFO - 2016-01-29 22:46:42 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:42 --> Input Class Initialized
INFO - 2016-01-29 22:46:42 --> Language Class Initialized
INFO - 2016-01-29 22:46:42 --> Loader Class Initialized
INFO - 2016-01-29 22:46:42 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:42 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:42 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:42 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:43 --> Controller Class Initialized
INFO - 2016-01-29 22:46:43 --> Model Class Initialized
INFO - 2016-01-29 22:46:43 --> Model Class Initialized
INFO - 2016-01-29 22:46:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:46:43 --> Pagination Class Initialized
INFO - 2016-01-29 22:46:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 22:46:43 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:43 --> Total execution time: 1.1089
INFO - 2016-01-29 22:46:46 --> Config Class Initialized
INFO - 2016-01-29 22:46:46 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:46 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:46 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:46 --> URI Class Initialized
INFO - 2016-01-29 22:46:46 --> Router Class Initialized
INFO - 2016-01-29 22:46:46 --> Output Class Initialized
INFO - 2016-01-29 22:46:46 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:46 --> Input Class Initialized
INFO - 2016-01-29 22:46:46 --> Language Class Initialized
INFO - 2016-01-29 22:46:46 --> Loader Class Initialized
INFO - 2016-01-29 22:46:46 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:46 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:46 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:46 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:47 --> Controller Class Initialized
INFO - 2016-01-29 22:46:47 --> Model Class Initialized
INFO - 2016-01-29 22:46:47 --> Model Class Initialized
INFO - 2016-01-29 22:46:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:46:47 --> Pagination Class Initialized
INFO - 2016-01-29 22:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 22:46:47 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:47 --> Total execution time: 1.1332
INFO - 2016-01-29 22:46:50 --> Config Class Initialized
INFO - 2016-01-29 22:46:50 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:50 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:50 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:50 --> URI Class Initialized
DEBUG - 2016-01-29 22:46:50 --> No URI present. Default controller set.
INFO - 2016-01-29 22:46:50 --> Router Class Initialized
INFO - 2016-01-29 22:46:50 --> Output Class Initialized
INFO - 2016-01-29 22:46:50 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:50 --> Input Class Initialized
INFO - 2016-01-29 22:46:50 --> Language Class Initialized
INFO - 2016-01-29 22:46:50 --> Loader Class Initialized
INFO - 2016-01-29 22:46:50 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:50 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:50 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:50 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:51 --> Controller Class Initialized
INFO - 2016-01-29 22:46:51 --> Model Class Initialized
INFO - 2016-01-29 22:46:51 --> Model Class Initialized
INFO - 2016-01-29 22:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:46:51 --> Pagination Class Initialized
INFO - 2016-01-29 22:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 22:46:51 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:51 --> Total execution time: 1.1221
INFO - 2016-01-29 22:46:53 --> Config Class Initialized
INFO - 2016-01-29 22:46:53 --> Hooks Class Initialized
DEBUG - 2016-01-29 22:46:53 --> UTF-8 Support Enabled
INFO - 2016-01-29 22:46:53 --> Utf8 Class Initialized
INFO - 2016-01-29 22:46:53 --> URI Class Initialized
INFO - 2016-01-29 22:46:53 --> Router Class Initialized
INFO - 2016-01-29 22:46:53 --> Output Class Initialized
INFO - 2016-01-29 22:46:53 --> Security Class Initialized
DEBUG - 2016-01-29 22:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 22:46:53 --> Input Class Initialized
INFO - 2016-01-29 22:46:53 --> Language Class Initialized
INFO - 2016-01-29 22:46:53 --> Loader Class Initialized
INFO - 2016-01-29 22:46:53 --> Helper loaded: url_helper
INFO - 2016-01-29 22:46:53 --> Helper loaded: file_helper
INFO - 2016-01-29 22:46:53 --> Helper loaded: date_helper
INFO - 2016-01-29 22:46:53 --> Database Driver Class Initialized
INFO - 2016-01-29 22:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 22:46:54 --> Controller Class Initialized
INFO - 2016-01-29 22:46:54 --> Model Class Initialized
INFO - 2016-01-29 22:46:54 --> Model Class Initialized
INFO - 2016-01-29 22:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 22:46:54 --> Pagination Class Initialized
INFO - 2016-01-29 22:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 22:46:54 --> Helper loaded: text_helper
INFO - 2016-01-29 22:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-29 22:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-29 22:46:54 --> Final output sent to browser
DEBUG - 2016-01-29 22:46:54 --> Total execution time: 1.1459
INFO - 2016-01-29 23:57:00 --> Config Class Initialized
INFO - 2016-01-29 23:57:00 --> Hooks Class Initialized
DEBUG - 2016-01-29 23:57:00 --> UTF-8 Support Enabled
INFO - 2016-01-29 23:57:00 --> Utf8 Class Initialized
INFO - 2016-01-29 23:57:00 --> URI Class Initialized
DEBUG - 2016-01-29 23:57:00 --> No URI present. Default controller set.
INFO - 2016-01-29 23:57:00 --> Router Class Initialized
INFO - 2016-01-29 23:57:00 --> Output Class Initialized
INFO - 2016-01-29 23:57:00 --> Security Class Initialized
DEBUG - 2016-01-29 23:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 23:57:00 --> Input Class Initialized
INFO - 2016-01-29 23:57:00 --> Language Class Initialized
INFO - 2016-01-29 23:57:00 --> Loader Class Initialized
INFO - 2016-01-29 23:57:00 --> Helper loaded: url_helper
INFO - 2016-01-29 23:57:00 --> Helper loaded: file_helper
INFO - 2016-01-29 23:57:00 --> Helper loaded: date_helper
INFO - 2016-01-29 23:57:00 --> Database Driver Class Initialized
INFO - 2016-01-29 23:57:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 23:57:01 --> Controller Class Initialized
INFO - 2016-01-29 23:57:01 --> Model Class Initialized
INFO - 2016-01-29 23:57:01 --> Model Class Initialized
INFO - 2016-01-29 23:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 23:57:01 --> Pagination Class Initialized
INFO - 2016-01-29 23:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 23:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 23:57:01 --> Final output sent to browser
DEBUG - 2016-01-29 23:57:01 --> Total execution time: 1.1281
INFO - 2016-01-29 23:57:05 --> Config Class Initialized
INFO - 2016-01-29 23:57:05 --> Hooks Class Initialized
DEBUG - 2016-01-29 23:57:05 --> UTF-8 Support Enabled
INFO - 2016-01-29 23:57:05 --> Utf8 Class Initialized
INFO - 2016-01-29 23:57:05 --> URI Class Initialized
INFO - 2016-01-29 23:57:05 --> Router Class Initialized
INFO - 2016-01-29 23:57:05 --> Output Class Initialized
INFO - 2016-01-29 23:57:05 --> Security Class Initialized
DEBUG - 2016-01-29 23:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 23:57:05 --> Input Class Initialized
INFO - 2016-01-29 23:57:05 --> Language Class Initialized
INFO - 2016-01-29 23:57:05 --> Loader Class Initialized
INFO - 2016-01-29 23:57:05 --> Helper loaded: url_helper
INFO - 2016-01-29 23:57:05 --> Helper loaded: file_helper
INFO - 2016-01-29 23:57:05 --> Helper loaded: date_helper
INFO - 2016-01-29 23:57:05 --> Database Driver Class Initialized
INFO - 2016-01-29 23:57:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 23:57:06 --> Controller Class Initialized
INFO - 2016-01-29 23:57:06 --> Model Class Initialized
INFO - 2016-01-29 23:57:06 --> Model Class Initialized
INFO - 2016-01-29 23:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 23:57:06 --> Pagination Class Initialized
INFO - 2016-01-29 23:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 23:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 23:57:06 --> Final output sent to browser
DEBUG - 2016-01-29 23:57:06 --> Total execution time: 1.2032
INFO - 2016-01-29 23:57:08 --> Config Class Initialized
INFO - 2016-01-29 23:57:08 --> Hooks Class Initialized
DEBUG - 2016-01-29 23:57:08 --> UTF-8 Support Enabled
INFO - 2016-01-29 23:57:08 --> Utf8 Class Initialized
INFO - 2016-01-29 23:57:08 --> URI Class Initialized
INFO - 2016-01-29 23:57:08 --> Router Class Initialized
INFO - 2016-01-29 23:57:08 --> Output Class Initialized
INFO - 2016-01-29 23:57:08 --> Security Class Initialized
DEBUG - 2016-01-29 23:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 23:57:08 --> Input Class Initialized
INFO - 2016-01-29 23:57:08 --> Language Class Initialized
INFO - 2016-01-29 23:57:08 --> Loader Class Initialized
INFO - 2016-01-29 23:57:08 --> Helper loaded: url_helper
INFO - 2016-01-29 23:57:08 --> Helper loaded: file_helper
INFO - 2016-01-29 23:57:08 --> Helper loaded: date_helper
INFO - 2016-01-29 23:57:08 --> Database Driver Class Initialized
INFO - 2016-01-29 23:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 23:57:09 --> Controller Class Initialized
INFO - 2016-01-29 23:57:09 --> Model Class Initialized
INFO - 2016-01-29 23:57:09 --> Model Class Initialized
INFO - 2016-01-29 23:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 23:57:09 --> Pagination Class Initialized
INFO - 2016-01-29 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 23:57:09 --> Final output sent to browser
DEBUG - 2016-01-29 23:57:09 --> Total execution time: 1.1052
INFO - 2016-01-29 23:58:08 --> Config Class Initialized
INFO - 2016-01-29 23:58:08 --> Hooks Class Initialized
DEBUG - 2016-01-29 23:58:08 --> UTF-8 Support Enabled
INFO - 2016-01-29 23:58:08 --> Utf8 Class Initialized
INFO - 2016-01-29 23:58:08 --> URI Class Initialized
DEBUG - 2016-01-29 23:58:08 --> No URI present. Default controller set.
INFO - 2016-01-29 23:58:08 --> Router Class Initialized
INFO - 2016-01-29 23:58:08 --> Output Class Initialized
INFO - 2016-01-29 23:58:08 --> Security Class Initialized
DEBUG - 2016-01-29 23:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-29 23:58:08 --> Input Class Initialized
INFO - 2016-01-29 23:58:08 --> Language Class Initialized
INFO - 2016-01-29 23:58:08 --> Loader Class Initialized
INFO - 2016-01-29 23:58:08 --> Helper loaded: url_helper
INFO - 2016-01-29 23:58:08 --> Helper loaded: file_helper
INFO - 2016-01-29 23:58:08 --> Helper loaded: date_helper
INFO - 2016-01-29 23:58:08 --> Database Driver Class Initialized
INFO - 2016-01-29 23:58:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-29 23:58:09 --> Controller Class Initialized
INFO - 2016-01-29 23:58:09 --> Model Class Initialized
INFO - 2016-01-29 23:58:09 --> Model Class Initialized
INFO - 2016-01-29 23:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-29 23:58:09 --> Pagination Class Initialized
INFO - 2016-01-29 23:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-29 23:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-29 23:58:09 --> Final output sent to browser
DEBUG - 2016-01-29 23:58:09 --> Total execution time: 1.0999
