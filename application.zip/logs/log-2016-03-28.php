<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-28 10:34:26 --> Config Class Initialized
INFO - 2016-03-28 10:34:26 --> Hooks Class Initialized
DEBUG - 2016-03-28 10:34:27 --> UTF-8 Support Enabled
INFO - 2016-03-28 10:34:27 --> Utf8 Class Initialized
INFO - 2016-03-28 10:34:27 --> URI Class Initialized
DEBUG - 2016-03-28 10:34:27 --> No URI present. Default controller set.
INFO - 2016-03-28 10:34:27 --> Router Class Initialized
INFO - 2016-03-28 10:34:27 --> Output Class Initialized
INFO - 2016-03-28 10:34:27 --> Security Class Initialized
DEBUG - 2016-03-28 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-28 10:34:27 --> Input Class Initialized
INFO - 2016-03-28 10:34:27 --> Language Class Initialized
INFO - 2016-03-28 10:34:27 --> Loader Class Initialized
INFO - 2016-03-28 10:34:27 --> Helper loaded: url_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: file_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: date_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: form_helper
INFO - 2016-03-28 10:34:27 --> Database Driver Class Initialized
INFO - 2016-03-28 10:34:27 --> Config Class Initialized
INFO - 2016-03-28 10:34:27 --> Hooks Class Initialized
DEBUG - 2016-03-28 10:34:27 --> UTF-8 Support Enabled
INFO - 2016-03-28 10:34:27 --> Utf8 Class Initialized
INFO - 2016-03-28 10:34:27 --> URI Class Initialized
DEBUG - 2016-03-28 10:34:27 --> No URI present. Default controller set.
INFO - 2016-03-28 10:34:27 --> Router Class Initialized
INFO - 2016-03-28 10:34:27 --> Output Class Initialized
INFO - 2016-03-28 10:34:27 --> Security Class Initialized
DEBUG - 2016-03-28 10:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-28 10:34:27 --> Input Class Initialized
INFO - 2016-03-28 10:34:27 --> Language Class Initialized
INFO - 2016-03-28 10:34:27 --> Loader Class Initialized
INFO - 2016-03-28 10:34:27 --> Helper loaded: url_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: file_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: date_helper
INFO - 2016-03-28 10:34:27 --> Helper loaded: form_helper
INFO - 2016-03-28 10:34:27 --> Database Driver Class Initialized
INFO - 2016-03-28 10:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-28 10:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-28 10:34:28 --> Controller Class Initialized
INFO - 2016-03-28 10:34:28 --> Controller Class Initialized
INFO - 2016-03-28 10:34:28 --> Model Class Initialized
INFO - 2016-03-28 10:34:28 --> Model Class Initialized
INFO - 2016-03-28 10:34:28 --> Model Class Initialized
INFO - 2016-03-28 10:34:28 --> Model Class Initialized
INFO - 2016-03-28 10:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-28 10:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-28 10:34:28 --> Pagination Class Initialized
INFO - 2016-03-28 10:34:28 --> Pagination Class Initialized
INFO - 2016-03-28 10:34:28 --> Helper loaded: text_helper
INFO - 2016-03-28 10:34:28 --> Helper loaded: text_helper
INFO - 2016-03-28 10:34:28 --> Helper loaded: cookie_helper
INFO - 2016-03-28 10:34:28 --> Helper loaded: cookie_helper
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-28 13:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-28 13:34:28 --> Final output sent to browser
INFO - 2016-03-28 13:34:28 --> Final output sent to browser
DEBUG - 2016-03-28 13:34:28 --> Total execution time: 1.7288
DEBUG - 2016-03-28 13:34:28 --> Total execution time: 1.3922
