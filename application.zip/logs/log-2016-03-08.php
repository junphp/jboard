<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-08 07:14:45 --> Config Class Initialized
INFO - 2016-03-08 07:14:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:14:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:14:45 --> Utf8 Class Initialized
INFO - 2016-03-08 07:14:45 --> URI Class Initialized
DEBUG - 2016-03-08 07:14:45 --> No URI present. Default controller set.
INFO - 2016-03-08 07:14:45 --> Router Class Initialized
INFO - 2016-03-08 07:14:45 --> Output Class Initialized
INFO - 2016-03-08 07:14:45 --> Security Class Initialized
DEBUG - 2016-03-08 07:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:14:45 --> Input Class Initialized
INFO - 2016-03-08 07:14:45 --> Language Class Initialized
INFO - 2016-03-08 07:14:45 --> Loader Class Initialized
INFO - 2016-03-08 07:14:45 --> Helper loaded: url_helper
INFO - 2016-03-08 07:14:45 --> Helper loaded: file_helper
INFO - 2016-03-08 07:14:45 --> Helper loaded: date_helper
INFO - 2016-03-08 07:14:45 --> Helper loaded: form_helper
INFO - 2016-03-08 07:14:45 --> Database Driver Class Initialized
INFO - 2016-03-08 07:14:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:14:46 --> Controller Class Initialized
INFO - 2016-03-08 07:14:46 --> Model Class Initialized
INFO - 2016-03-08 07:14:46 --> Model Class Initialized
INFO - 2016-03-08 07:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:14:46 --> Pagination Class Initialized
INFO - 2016-03-08 07:14:46 --> Helper loaded: text_helper
INFO - 2016-03-08 07:14:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 10:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:14:46 --> Final output sent to browser
DEBUG - 2016-03-08 10:14:46 --> Total execution time: 1.1465
INFO - 2016-03-08 07:16:45 --> Config Class Initialized
INFO - 2016-03-08 07:16:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:16:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:16:45 --> Utf8 Class Initialized
INFO - 2016-03-08 07:16:45 --> URI Class Initialized
INFO - 2016-03-08 07:16:45 --> Router Class Initialized
INFO - 2016-03-08 07:16:45 --> Output Class Initialized
INFO - 2016-03-08 07:16:45 --> Security Class Initialized
DEBUG - 2016-03-08 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:16:45 --> Input Class Initialized
INFO - 2016-03-08 07:16:45 --> Language Class Initialized
INFO - 2016-03-08 07:16:45 --> Loader Class Initialized
INFO - 2016-03-08 07:16:45 --> Helper loaded: url_helper
INFO - 2016-03-08 07:16:45 --> Helper loaded: file_helper
INFO - 2016-03-08 07:16:45 --> Helper loaded: date_helper
INFO - 2016-03-08 07:16:45 --> Helper loaded: form_helper
INFO - 2016-03-08 07:16:45 --> Database Driver Class Initialized
INFO - 2016-03-08 07:16:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:16:47 --> Controller Class Initialized
INFO - 2016-03-08 07:16:47 --> Model Class Initialized
INFO - 2016-03-08 07:16:47 --> Model Class Initialized
INFO - 2016-03-08 07:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:16:47 --> Pagination Class Initialized
INFO - 2016-03-08 07:16:47 --> Helper loaded: text_helper
INFO - 2016-03-08 07:16:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:16:47 --> Final output sent to browser
DEBUG - 2016-03-08 10:16:47 --> Total execution time: 1.1438
INFO - 2016-03-08 07:20:55 --> Config Class Initialized
INFO - 2016-03-08 07:20:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:20:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:20:55 --> Utf8 Class Initialized
INFO - 2016-03-08 07:20:55 --> URI Class Initialized
INFO - 2016-03-08 07:20:55 --> Router Class Initialized
INFO - 2016-03-08 07:20:55 --> Output Class Initialized
INFO - 2016-03-08 07:20:55 --> Security Class Initialized
DEBUG - 2016-03-08 07:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:20:55 --> Input Class Initialized
INFO - 2016-03-08 07:20:55 --> Language Class Initialized
INFO - 2016-03-08 07:20:55 --> Loader Class Initialized
INFO - 2016-03-08 07:20:55 --> Helper loaded: url_helper
INFO - 2016-03-08 07:20:55 --> Helper loaded: file_helper
INFO - 2016-03-08 07:20:55 --> Helper loaded: date_helper
INFO - 2016-03-08 07:20:55 --> Helper loaded: form_helper
INFO - 2016-03-08 07:20:55 --> Database Driver Class Initialized
INFO - 2016-03-08 07:20:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:20:56 --> Controller Class Initialized
INFO - 2016-03-08 07:20:56 --> Model Class Initialized
INFO - 2016-03-08 07:20:56 --> Model Class Initialized
INFO - 2016-03-08 07:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:20:56 --> Pagination Class Initialized
INFO - 2016-03-08 07:20:56 --> Helper loaded: text_helper
INFO - 2016-03-08 07:20:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:20:56 --> Final output sent to browser
DEBUG - 2016-03-08 10:20:56 --> Total execution time: 1.1006
INFO - 2016-03-08 07:22:14 --> Config Class Initialized
INFO - 2016-03-08 07:22:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:22:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:22:14 --> Utf8 Class Initialized
INFO - 2016-03-08 07:22:14 --> URI Class Initialized
INFO - 2016-03-08 07:22:14 --> Router Class Initialized
INFO - 2016-03-08 07:22:14 --> Output Class Initialized
INFO - 2016-03-08 07:22:14 --> Security Class Initialized
DEBUG - 2016-03-08 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:22:14 --> Input Class Initialized
INFO - 2016-03-08 07:22:14 --> Language Class Initialized
INFO - 2016-03-08 07:22:14 --> Loader Class Initialized
INFO - 2016-03-08 07:22:14 --> Helper loaded: url_helper
INFO - 2016-03-08 07:22:14 --> Helper loaded: file_helper
INFO - 2016-03-08 07:22:14 --> Helper loaded: date_helper
INFO - 2016-03-08 07:22:14 --> Helper loaded: form_helper
INFO - 2016-03-08 07:22:14 --> Database Driver Class Initialized
INFO - 2016-03-08 07:22:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:22:15 --> Controller Class Initialized
INFO - 2016-03-08 07:22:15 --> Model Class Initialized
INFO - 2016-03-08 07:22:15 --> Model Class Initialized
INFO - 2016-03-08 07:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:22:15 --> Pagination Class Initialized
INFO - 2016-03-08 07:22:15 --> Helper loaded: text_helper
INFO - 2016-03-08 07:22:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:22:15 --> Final output sent to browser
DEBUG - 2016-03-08 10:22:15 --> Total execution time: 1.1354
INFO - 2016-03-08 07:23:05 --> Config Class Initialized
INFO - 2016-03-08 07:23:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:23:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:23:05 --> Utf8 Class Initialized
INFO - 2016-03-08 07:23:05 --> URI Class Initialized
INFO - 2016-03-08 07:23:05 --> Router Class Initialized
INFO - 2016-03-08 07:23:05 --> Output Class Initialized
INFO - 2016-03-08 07:23:05 --> Security Class Initialized
DEBUG - 2016-03-08 07:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:23:05 --> Input Class Initialized
INFO - 2016-03-08 07:23:05 --> Language Class Initialized
INFO - 2016-03-08 07:23:05 --> Loader Class Initialized
INFO - 2016-03-08 07:23:05 --> Helper loaded: url_helper
INFO - 2016-03-08 07:23:05 --> Helper loaded: file_helper
INFO - 2016-03-08 07:23:05 --> Helper loaded: date_helper
INFO - 2016-03-08 07:23:05 --> Helper loaded: form_helper
INFO - 2016-03-08 07:23:05 --> Database Driver Class Initialized
INFO - 2016-03-08 07:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:23:06 --> Controller Class Initialized
INFO - 2016-03-08 07:23:06 --> Model Class Initialized
INFO - 2016-03-08 07:23:06 --> Model Class Initialized
INFO - 2016-03-08 07:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:23:06 --> Pagination Class Initialized
INFO - 2016-03-08 07:23:06 --> Helper loaded: text_helper
INFO - 2016-03-08 07:23:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:23:06 --> Final output sent to browser
DEBUG - 2016-03-08 10:23:06 --> Total execution time: 1.1010
INFO - 2016-03-08 07:23:45 --> Config Class Initialized
INFO - 2016-03-08 07:23:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:23:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:23:45 --> Utf8 Class Initialized
INFO - 2016-03-08 07:23:45 --> URI Class Initialized
INFO - 2016-03-08 07:23:45 --> Router Class Initialized
INFO - 2016-03-08 07:23:45 --> Output Class Initialized
INFO - 2016-03-08 07:23:45 --> Security Class Initialized
DEBUG - 2016-03-08 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:23:45 --> Input Class Initialized
INFO - 2016-03-08 07:23:45 --> Language Class Initialized
INFO - 2016-03-08 07:23:45 --> Loader Class Initialized
INFO - 2016-03-08 07:23:45 --> Helper loaded: url_helper
INFO - 2016-03-08 07:23:45 --> Helper loaded: file_helper
INFO - 2016-03-08 07:23:45 --> Helper loaded: date_helper
INFO - 2016-03-08 07:23:45 --> Helper loaded: form_helper
INFO - 2016-03-08 07:23:45 --> Database Driver Class Initialized
INFO - 2016-03-08 07:23:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:23:46 --> Controller Class Initialized
INFO - 2016-03-08 07:23:46 --> Model Class Initialized
INFO - 2016-03-08 07:23:46 --> Model Class Initialized
INFO - 2016-03-08 07:23:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:23:46 --> Pagination Class Initialized
INFO - 2016-03-08 07:23:46 --> Helper loaded: text_helper
INFO - 2016-03-08 07:23:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:23:46 --> Final output sent to browser
DEBUG - 2016-03-08 10:23:46 --> Total execution time: 1.1936
INFO - 2016-03-08 07:28:53 --> Config Class Initialized
INFO - 2016-03-08 07:28:53 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:28:53 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:28:53 --> Utf8 Class Initialized
INFO - 2016-03-08 07:28:53 --> URI Class Initialized
INFO - 2016-03-08 07:28:53 --> Router Class Initialized
INFO - 2016-03-08 07:28:53 --> Output Class Initialized
INFO - 2016-03-08 07:28:53 --> Security Class Initialized
DEBUG - 2016-03-08 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:28:53 --> Input Class Initialized
INFO - 2016-03-08 07:28:53 --> Language Class Initialized
INFO - 2016-03-08 07:28:53 --> Loader Class Initialized
INFO - 2016-03-08 07:28:53 --> Helper loaded: url_helper
INFO - 2016-03-08 07:28:53 --> Helper loaded: file_helper
INFO - 2016-03-08 07:28:53 --> Helper loaded: date_helper
INFO - 2016-03-08 07:28:53 --> Helper loaded: form_helper
INFO - 2016-03-08 07:28:53 --> Database Driver Class Initialized
INFO - 2016-03-08 07:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:28:54 --> Controller Class Initialized
INFO - 2016-03-08 07:28:54 --> Model Class Initialized
INFO - 2016-03-08 07:28:54 --> Model Class Initialized
INFO - 2016-03-08 07:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:28:54 --> Pagination Class Initialized
INFO - 2016-03-08 07:28:54 --> Helper loaded: text_helper
INFO - 2016-03-08 07:28:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:28:54 --> Final output sent to browser
DEBUG - 2016-03-08 10:28:54 --> Total execution time: 1.1749
INFO - 2016-03-08 07:30:29 --> Config Class Initialized
INFO - 2016-03-08 07:30:29 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:30:29 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:30:29 --> Utf8 Class Initialized
INFO - 2016-03-08 07:30:29 --> URI Class Initialized
INFO - 2016-03-08 07:30:29 --> Router Class Initialized
INFO - 2016-03-08 07:30:29 --> Output Class Initialized
INFO - 2016-03-08 07:30:29 --> Security Class Initialized
DEBUG - 2016-03-08 07:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:30:29 --> Input Class Initialized
INFO - 2016-03-08 07:30:29 --> Language Class Initialized
INFO - 2016-03-08 07:30:29 --> Loader Class Initialized
INFO - 2016-03-08 07:30:29 --> Helper loaded: url_helper
INFO - 2016-03-08 07:30:29 --> Helper loaded: file_helper
INFO - 2016-03-08 07:30:29 --> Helper loaded: date_helper
INFO - 2016-03-08 07:30:29 --> Helper loaded: form_helper
INFO - 2016-03-08 07:30:29 --> Database Driver Class Initialized
INFO - 2016-03-08 07:30:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:30:30 --> Controller Class Initialized
INFO - 2016-03-08 07:30:30 --> Model Class Initialized
INFO - 2016-03-08 07:30:30 --> Model Class Initialized
INFO - 2016-03-08 07:30:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:30:30 --> Pagination Class Initialized
INFO - 2016-03-08 07:30:30 --> Helper loaded: text_helper
INFO - 2016-03-08 07:30:30 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:30:30 --> Final output sent to browser
DEBUG - 2016-03-08 10:30:30 --> Total execution time: 1.0969
INFO - 2016-03-08 07:31:41 --> Config Class Initialized
INFO - 2016-03-08 07:31:41 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:31:41 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:31:41 --> Utf8 Class Initialized
INFO - 2016-03-08 07:31:41 --> URI Class Initialized
DEBUG - 2016-03-08 07:31:41 --> No URI present. Default controller set.
INFO - 2016-03-08 07:31:41 --> Router Class Initialized
INFO - 2016-03-08 07:31:41 --> Output Class Initialized
INFO - 2016-03-08 07:31:41 --> Security Class Initialized
DEBUG - 2016-03-08 07:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:31:41 --> Input Class Initialized
INFO - 2016-03-08 07:31:41 --> Language Class Initialized
INFO - 2016-03-08 07:31:41 --> Loader Class Initialized
INFO - 2016-03-08 07:31:41 --> Helper loaded: url_helper
INFO - 2016-03-08 07:31:41 --> Helper loaded: file_helper
INFO - 2016-03-08 07:31:41 --> Helper loaded: date_helper
INFO - 2016-03-08 07:31:41 --> Helper loaded: form_helper
INFO - 2016-03-08 07:31:41 --> Database Driver Class Initialized
INFO - 2016-03-08 07:31:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:31:42 --> Controller Class Initialized
INFO - 2016-03-08 07:31:42 --> Model Class Initialized
INFO - 2016-03-08 07:31:42 --> Model Class Initialized
INFO - 2016-03-08 07:31:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:31:42 --> Pagination Class Initialized
INFO - 2016-03-08 07:31:42 --> Helper loaded: text_helper
INFO - 2016-03-08 07:31:42 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 10:31:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:31:42 --> Final output sent to browser
DEBUG - 2016-03-08 10:31:42 --> Total execution time: 1.0883
INFO - 2016-03-08 07:33:41 --> Config Class Initialized
INFO - 2016-03-08 07:33:41 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:33:41 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:33:41 --> Utf8 Class Initialized
INFO - 2016-03-08 07:33:41 --> URI Class Initialized
INFO - 2016-03-08 07:33:41 --> Router Class Initialized
INFO - 2016-03-08 07:33:41 --> Output Class Initialized
INFO - 2016-03-08 07:33:41 --> Security Class Initialized
DEBUG - 2016-03-08 07:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:33:41 --> Input Class Initialized
INFO - 2016-03-08 07:33:41 --> Language Class Initialized
INFO - 2016-03-08 07:33:41 --> Loader Class Initialized
INFO - 2016-03-08 07:33:41 --> Helper loaded: url_helper
INFO - 2016-03-08 07:33:41 --> Helper loaded: file_helper
INFO - 2016-03-08 07:33:41 --> Helper loaded: date_helper
INFO - 2016-03-08 07:33:41 --> Helper loaded: form_helper
INFO - 2016-03-08 07:33:41 --> Database Driver Class Initialized
INFO - 2016-03-08 07:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:33:42 --> Controller Class Initialized
INFO - 2016-03-08 07:33:42 --> Model Class Initialized
INFO - 2016-03-08 07:33:42 --> Model Class Initialized
INFO - 2016-03-08 07:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:33:42 --> Pagination Class Initialized
INFO - 2016-03-08 07:33:42 --> Helper loaded: text_helper
INFO - 2016-03-08 07:33:42 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:33:42 --> Final output sent to browser
DEBUG - 2016-03-08 10:33:42 --> Total execution time: 1.1355
INFO - 2016-03-08 07:34:22 --> Config Class Initialized
INFO - 2016-03-08 07:34:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:34:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:34:22 --> Utf8 Class Initialized
INFO - 2016-03-08 07:34:22 --> URI Class Initialized
INFO - 2016-03-08 07:34:22 --> Router Class Initialized
INFO - 2016-03-08 07:34:22 --> Output Class Initialized
INFO - 2016-03-08 07:34:22 --> Security Class Initialized
DEBUG - 2016-03-08 07:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:34:22 --> Input Class Initialized
INFO - 2016-03-08 07:34:22 --> Language Class Initialized
INFO - 2016-03-08 07:34:22 --> Loader Class Initialized
INFO - 2016-03-08 07:34:22 --> Helper loaded: url_helper
INFO - 2016-03-08 07:34:22 --> Helper loaded: file_helper
INFO - 2016-03-08 07:34:22 --> Helper loaded: date_helper
INFO - 2016-03-08 07:34:22 --> Helper loaded: form_helper
INFO - 2016-03-08 07:34:22 --> Database Driver Class Initialized
INFO - 2016-03-08 07:34:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:34:23 --> Controller Class Initialized
INFO - 2016-03-08 07:34:23 --> Model Class Initialized
INFO - 2016-03-08 07:34:23 --> Model Class Initialized
INFO - 2016-03-08 07:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:34:23 --> Pagination Class Initialized
INFO - 2016-03-08 07:34:23 --> Helper loaded: text_helper
INFO - 2016-03-08 07:34:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:34:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:34:23 --> Final output sent to browser
DEBUG - 2016-03-08 10:34:23 --> Total execution time: 1.1024
INFO - 2016-03-08 07:34:37 --> Config Class Initialized
INFO - 2016-03-08 07:34:37 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:34:37 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:34:37 --> Utf8 Class Initialized
INFO - 2016-03-08 07:34:37 --> URI Class Initialized
INFO - 2016-03-08 07:34:37 --> Router Class Initialized
INFO - 2016-03-08 07:34:37 --> Output Class Initialized
INFO - 2016-03-08 07:34:37 --> Security Class Initialized
DEBUG - 2016-03-08 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:34:37 --> Input Class Initialized
INFO - 2016-03-08 07:34:37 --> Language Class Initialized
INFO - 2016-03-08 07:34:37 --> Loader Class Initialized
INFO - 2016-03-08 07:34:37 --> Helper loaded: url_helper
INFO - 2016-03-08 07:34:37 --> Helper loaded: file_helper
INFO - 2016-03-08 07:34:37 --> Helper loaded: date_helper
INFO - 2016-03-08 07:34:37 --> Helper loaded: form_helper
INFO - 2016-03-08 07:34:37 --> Database Driver Class Initialized
INFO - 2016-03-08 07:34:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:34:38 --> Controller Class Initialized
INFO - 2016-03-08 07:34:38 --> Model Class Initialized
INFO - 2016-03-08 07:34:38 --> Model Class Initialized
INFO - 2016-03-08 07:34:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:34:38 --> Pagination Class Initialized
INFO - 2016-03-08 07:34:38 --> Helper loaded: text_helper
INFO - 2016-03-08 07:34:38 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:34:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:34:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:34:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:34:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:34:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:34:38 --> Final output sent to browser
DEBUG - 2016-03-08 10:34:38 --> Total execution time: 1.1330
INFO - 2016-03-08 07:35:11 --> Config Class Initialized
INFO - 2016-03-08 07:35:11 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:35:11 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:35:11 --> Utf8 Class Initialized
INFO - 2016-03-08 07:35:11 --> URI Class Initialized
INFO - 2016-03-08 07:35:11 --> Router Class Initialized
INFO - 2016-03-08 07:35:11 --> Output Class Initialized
INFO - 2016-03-08 07:35:11 --> Security Class Initialized
DEBUG - 2016-03-08 07:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:35:11 --> Input Class Initialized
INFO - 2016-03-08 07:35:11 --> Language Class Initialized
INFO - 2016-03-08 07:35:11 --> Loader Class Initialized
INFO - 2016-03-08 07:35:11 --> Helper loaded: url_helper
INFO - 2016-03-08 07:35:11 --> Helper loaded: file_helper
INFO - 2016-03-08 07:35:11 --> Helper loaded: date_helper
INFO - 2016-03-08 07:35:11 --> Helper loaded: form_helper
INFO - 2016-03-08 07:35:11 --> Database Driver Class Initialized
INFO - 2016-03-08 07:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:35:12 --> Controller Class Initialized
INFO - 2016-03-08 07:35:12 --> Model Class Initialized
INFO - 2016-03-08 07:35:12 --> Model Class Initialized
INFO - 2016-03-08 07:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:35:12 --> Pagination Class Initialized
INFO - 2016-03-08 07:35:12 --> Helper loaded: text_helper
INFO - 2016-03-08 07:35:12 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:35:12 --> Final output sent to browser
DEBUG - 2016-03-08 10:35:12 --> Total execution time: 1.1276
INFO - 2016-03-08 07:40:08 --> Config Class Initialized
INFO - 2016-03-08 07:40:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:40:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:40:08 --> Utf8 Class Initialized
INFO - 2016-03-08 07:40:08 --> URI Class Initialized
INFO - 2016-03-08 07:40:08 --> Router Class Initialized
INFO - 2016-03-08 07:40:08 --> Output Class Initialized
INFO - 2016-03-08 07:40:08 --> Security Class Initialized
DEBUG - 2016-03-08 07:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:40:08 --> Input Class Initialized
INFO - 2016-03-08 07:40:08 --> Language Class Initialized
INFO - 2016-03-08 07:40:08 --> Loader Class Initialized
INFO - 2016-03-08 07:40:08 --> Helper loaded: url_helper
INFO - 2016-03-08 07:40:08 --> Helper loaded: file_helper
INFO - 2016-03-08 07:40:08 --> Helper loaded: date_helper
INFO - 2016-03-08 07:40:08 --> Helper loaded: form_helper
INFO - 2016-03-08 07:40:08 --> Database Driver Class Initialized
INFO - 2016-03-08 07:40:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:40:09 --> Controller Class Initialized
INFO - 2016-03-08 07:40:09 --> Model Class Initialized
INFO - 2016-03-08 07:40:09 --> Model Class Initialized
INFO - 2016-03-08 07:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:40:09 --> Pagination Class Initialized
INFO - 2016-03-08 07:40:09 --> Helper loaded: text_helper
INFO - 2016-03-08 07:40:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:40:09 --> Final output sent to browser
DEBUG - 2016-03-08 10:40:09 --> Total execution time: 1.1483
INFO - 2016-03-08 07:40:47 --> Config Class Initialized
INFO - 2016-03-08 07:40:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:40:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:40:47 --> Utf8 Class Initialized
INFO - 2016-03-08 07:40:47 --> URI Class Initialized
INFO - 2016-03-08 07:40:47 --> Router Class Initialized
INFO - 2016-03-08 07:40:47 --> Output Class Initialized
INFO - 2016-03-08 07:40:47 --> Security Class Initialized
DEBUG - 2016-03-08 07:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:40:47 --> Input Class Initialized
INFO - 2016-03-08 07:40:47 --> Language Class Initialized
INFO - 2016-03-08 07:40:47 --> Loader Class Initialized
INFO - 2016-03-08 07:40:47 --> Helper loaded: url_helper
INFO - 2016-03-08 07:40:47 --> Helper loaded: file_helper
INFO - 2016-03-08 07:40:47 --> Helper loaded: date_helper
INFO - 2016-03-08 07:40:47 --> Helper loaded: form_helper
INFO - 2016-03-08 07:40:47 --> Database Driver Class Initialized
INFO - 2016-03-08 07:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:40:48 --> Controller Class Initialized
INFO - 2016-03-08 07:40:48 --> Model Class Initialized
INFO - 2016-03-08 07:40:48 --> Model Class Initialized
INFO - 2016-03-08 07:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:40:48 --> Pagination Class Initialized
INFO - 2016-03-08 07:40:48 --> Helper loaded: text_helper
INFO - 2016-03-08 07:40:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:40:48 --> Final output sent to browser
DEBUG - 2016-03-08 10:40:48 --> Total execution time: 1.1089
INFO - 2016-03-08 07:43:24 --> Config Class Initialized
INFO - 2016-03-08 07:43:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:43:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:43:24 --> Utf8 Class Initialized
INFO - 2016-03-08 07:43:24 --> URI Class Initialized
INFO - 2016-03-08 07:43:24 --> Router Class Initialized
INFO - 2016-03-08 07:43:24 --> Output Class Initialized
INFO - 2016-03-08 07:43:24 --> Security Class Initialized
DEBUG - 2016-03-08 07:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:43:24 --> Input Class Initialized
INFO - 2016-03-08 07:43:24 --> Language Class Initialized
INFO - 2016-03-08 07:43:24 --> Loader Class Initialized
INFO - 2016-03-08 07:43:24 --> Helper loaded: url_helper
INFO - 2016-03-08 07:43:24 --> Helper loaded: file_helper
INFO - 2016-03-08 07:43:24 --> Helper loaded: date_helper
INFO - 2016-03-08 07:43:24 --> Helper loaded: form_helper
INFO - 2016-03-08 07:43:24 --> Database Driver Class Initialized
INFO - 2016-03-08 07:43:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:43:25 --> Controller Class Initialized
INFO - 2016-03-08 07:43:25 --> Model Class Initialized
INFO - 2016-03-08 07:43:25 --> Model Class Initialized
INFO - 2016-03-08 07:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:43:25 --> Pagination Class Initialized
INFO - 2016-03-08 07:43:25 --> Helper loaded: text_helper
INFO - 2016-03-08 07:43:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:43:25 --> Final output sent to browser
DEBUG - 2016-03-08 10:43:25 --> Total execution time: 1.1709
INFO - 2016-03-08 07:44:48 --> Config Class Initialized
INFO - 2016-03-08 07:44:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:44:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:44:48 --> Utf8 Class Initialized
INFO - 2016-03-08 07:44:48 --> URI Class Initialized
INFO - 2016-03-08 07:44:48 --> Router Class Initialized
INFO - 2016-03-08 07:44:48 --> Output Class Initialized
INFO - 2016-03-08 07:44:48 --> Security Class Initialized
DEBUG - 2016-03-08 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:44:48 --> Input Class Initialized
INFO - 2016-03-08 07:44:48 --> Language Class Initialized
INFO - 2016-03-08 07:44:48 --> Loader Class Initialized
INFO - 2016-03-08 07:44:48 --> Helper loaded: url_helper
INFO - 2016-03-08 07:44:48 --> Helper loaded: file_helper
INFO - 2016-03-08 07:44:48 --> Helper loaded: date_helper
INFO - 2016-03-08 07:44:48 --> Helper loaded: form_helper
INFO - 2016-03-08 07:44:48 --> Database Driver Class Initialized
INFO - 2016-03-08 07:44:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:44:49 --> Controller Class Initialized
INFO - 2016-03-08 07:44:49 --> Model Class Initialized
INFO - 2016-03-08 07:44:49 --> Model Class Initialized
INFO - 2016-03-08 07:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:44:49 --> Pagination Class Initialized
INFO - 2016-03-08 07:44:49 --> Helper loaded: text_helper
INFO - 2016-03-08 07:44:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:44:49 --> Final output sent to browser
DEBUG - 2016-03-08 10:44:49 --> Total execution time: 1.1702
INFO - 2016-03-08 07:45:27 --> Config Class Initialized
INFO - 2016-03-08 07:45:27 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:45:27 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:45:27 --> Utf8 Class Initialized
INFO - 2016-03-08 07:45:27 --> URI Class Initialized
INFO - 2016-03-08 07:45:27 --> Router Class Initialized
INFO - 2016-03-08 07:45:27 --> Output Class Initialized
INFO - 2016-03-08 07:45:27 --> Security Class Initialized
DEBUG - 2016-03-08 07:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:45:27 --> Input Class Initialized
INFO - 2016-03-08 07:45:27 --> Language Class Initialized
INFO - 2016-03-08 07:45:27 --> Loader Class Initialized
INFO - 2016-03-08 07:45:27 --> Helper loaded: url_helper
INFO - 2016-03-08 07:45:27 --> Helper loaded: file_helper
INFO - 2016-03-08 07:45:27 --> Helper loaded: date_helper
INFO - 2016-03-08 07:45:27 --> Helper loaded: form_helper
INFO - 2016-03-08 07:45:27 --> Database Driver Class Initialized
INFO - 2016-03-08 07:45:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:45:28 --> Controller Class Initialized
INFO - 2016-03-08 07:45:28 --> Model Class Initialized
INFO - 2016-03-08 07:45:28 --> Model Class Initialized
INFO - 2016-03-08 07:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:45:28 --> Pagination Class Initialized
INFO - 2016-03-08 07:45:28 --> Helper loaded: text_helper
INFO - 2016-03-08 07:45:28 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:45:28 --> Final output sent to browser
DEBUG - 2016-03-08 10:45:28 --> Total execution time: 1.1721
INFO - 2016-03-08 07:46:34 --> Config Class Initialized
INFO - 2016-03-08 07:46:34 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:46:34 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:46:34 --> Utf8 Class Initialized
INFO - 2016-03-08 07:46:34 --> URI Class Initialized
INFO - 2016-03-08 07:46:34 --> Router Class Initialized
INFO - 2016-03-08 07:46:34 --> Output Class Initialized
INFO - 2016-03-08 07:46:34 --> Security Class Initialized
DEBUG - 2016-03-08 07:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:46:34 --> Input Class Initialized
INFO - 2016-03-08 07:46:34 --> Language Class Initialized
INFO - 2016-03-08 07:46:34 --> Loader Class Initialized
INFO - 2016-03-08 07:46:34 --> Helper loaded: url_helper
INFO - 2016-03-08 07:46:34 --> Helper loaded: file_helper
INFO - 2016-03-08 07:46:34 --> Helper loaded: date_helper
INFO - 2016-03-08 07:46:34 --> Helper loaded: form_helper
INFO - 2016-03-08 07:46:34 --> Database Driver Class Initialized
INFO - 2016-03-08 07:46:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:46:36 --> Controller Class Initialized
INFO - 2016-03-08 07:46:36 --> Model Class Initialized
INFO - 2016-03-08 07:46:36 --> Model Class Initialized
INFO - 2016-03-08 07:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:46:36 --> Pagination Class Initialized
INFO - 2016-03-08 07:46:36 --> Helper loaded: text_helper
INFO - 2016-03-08 07:46:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:46:36 --> Final output sent to browser
DEBUG - 2016-03-08 10:46:36 --> Total execution time: 1.1528
INFO - 2016-03-08 07:47:27 --> Config Class Initialized
INFO - 2016-03-08 07:47:27 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:47:27 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:47:27 --> Utf8 Class Initialized
INFO - 2016-03-08 07:47:27 --> URI Class Initialized
INFO - 2016-03-08 07:47:27 --> Router Class Initialized
INFO - 2016-03-08 07:47:27 --> Output Class Initialized
INFO - 2016-03-08 07:47:27 --> Security Class Initialized
DEBUG - 2016-03-08 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:47:27 --> Input Class Initialized
INFO - 2016-03-08 07:47:27 --> Language Class Initialized
INFO - 2016-03-08 07:47:27 --> Loader Class Initialized
INFO - 2016-03-08 07:47:27 --> Helper loaded: url_helper
INFO - 2016-03-08 07:47:27 --> Helper loaded: file_helper
INFO - 2016-03-08 07:47:27 --> Helper loaded: date_helper
INFO - 2016-03-08 07:47:27 --> Helper loaded: form_helper
INFO - 2016-03-08 07:47:27 --> Database Driver Class Initialized
INFO - 2016-03-08 07:47:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:47:28 --> Controller Class Initialized
INFO - 2016-03-08 07:47:28 --> Model Class Initialized
INFO - 2016-03-08 07:47:28 --> Model Class Initialized
INFO - 2016-03-08 07:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:47:28 --> Pagination Class Initialized
INFO - 2016-03-08 07:47:28 --> Helper loaded: text_helper
INFO - 2016-03-08 07:47:28 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:47:28 --> Final output sent to browser
DEBUG - 2016-03-08 10:47:28 --> Total execution time: 1.1923
INFO - 2016-03-08 07:47:56 --> Config Class Initialized
INFO - 2016-03-08 07:47:56 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:47:56 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:47:56 --> Utf8 Class Initialized
INFO - 2016-03-08 07:47:56 --> URI Class Initialized
INFO - 2016-03-08 07:47:56 --> Router Class Initialized
INFO - 2016-03-08 07:47:56 --> Output Class Initialized
INFO - 2016-03-08 07:47:56 --> Security Class Initialized
DEBUG - 2016-03-08 07:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:47:56 --> Input Class Initialized
INFO - 2016-03-08 07:47:56 --> Language Class Initialized
INFO - 2016-03-08 07:47:56 --> Loader Class Initialized
INFO - 2016-03-08 07:47:56 --> Helper loaded: url_helper
INFO - 2016-03-08 07:47:56 --> Helper loaded: file_helper
INFO - 2016-03-08 07:47:56 --> Helper loaded: date_helper
INFO - 2016-03-08 07:47:56 --> Helper loaded: form_helper
INFO - 2016-03-08 07:47:56 --> Database Driver Class Initialized
INFO - 2016-03-08 07:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:47:57 --> Controller Class Initialized
INFO - 2016-03-08 07:47:57 --> Model Class Initialized
INFO - 2016-03-08 07:47:57 --> Model Class Initialized
INFO - 2016-03-08 07:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:47:57 --> Pagination Class Initialized
INFO - 2016-03-08 07:47:57 --> Helper loaded: text_helper
INFO - 2016-03-08 07:47:57 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:47:57 --> Final output sent to browser
DEBUG - 2016-03-08 10:47:57 --> Total execution time: 1.1381
INFO - 2016-03-08 07:48:32 --> Config Class Initialized
INFO - 2016-03-08 07:48:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:48:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:48:32 --> Utf8 Class Initialized
INFO - 2016-03-08 07:48:32 --> URI Class Initialized
INFO - 2016-03-08 07:48:32 --> Router Class Initialized
INFO - 2016-03-08 07:48:32 --> Output Class Initialized
INFO - 2016-03-08 07:48:32 --> Security Class Initialized
DEBUG - 2016-03-08 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:48:32 --> Input Class Initialized
INFO - 2016-03-08 07:48:32 --> Language Class Initialized
INFO - 2016-03-08 07:48:32 --> Loader Class Initialized
INFO - 2016-03-08 07:48:32 --> Helper loaded: url_helper
INFO - 2016-03-08 07:48:32 --> Helper loaded: file_helper
INFO - 2016-03-08 07:48:32 --> Helper loaded: date_helper
INFO - 2016-03-08 07:48:32 --> Helper loaded: form_helper
INFO - 2016-03-08 07:48:32 --> Database Driver Class Initialized
INFO - 2016-03-08 07:48:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:48:33 --> Controller Class Initialized
INFO - 2016-03-08 07:48:33 --> Model Class Initialized
INFO - 2016-03-08 07:48:33 --> Model Class Initialized
INFO - 2016-03-08 07:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:48:33 --> Pagination Class Initialized
INFO - 2016-03-08 07:48:33 --> Helper loaded: text_helper
INFO - 2016-03-08 07:48:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:48:33 --> Final output sent to browser
DEBUG - 2016-03-08 10:48:33 --> Total execution time: 1.2203
INFO - 2016-03-08 07:54:16 --> Config Class Initialized
INFO - 2016-03-08 07:54:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:54:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:54:16 --> Utf8 Class Initialized
INFO - 2016-03-08 07:54:16 --> URI Class Initialized
INFO - 2016-03-08 07:54:16 --> Router Class Initialized
INFO - 2016-03-08 07:54:16 --> Output Class Initialized
INFO - 2016-03-08 07:54:16 --> Security Class Initialized
DEBUG - 2016-03-08 07:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:54:16 --> Input Class Initialized
INFO - 2016-03-08 07:54:16 --> Language Class Initialized
INFO - 2016-03-08 07:54:16 --> Loader Class Initialized
INFO - 2016-03-08 07:54:16 --> Helper loaded: url_helper
INFO - 2016-03-08 07:54:16 --> Helper loaded: file_helper
INFO - 2016-03-08 07:54:16 --> Helper loaded: date_helper
INFO - 2016-03-08 07:54:16 --> Helper loaded: form_helper
INFO - 2016-03-08 07:54:16 --> Database Driver Class Initialized
INFO - 2016-03-08 07:54:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:54:17 --> Controller Class Initialized
INFO - 2016-03-08 07:54:17 --> Model Class Initialized
INFO - 2016-03-08 07:54:17 --> Model Class Initialized
INFO - 2016-03-08 07:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:54:17 --> Pagination Class Initialized
INFO - 2016-03-08 07:54:17 --> Helper loaded: text_helper
INFO - 2016-03-08 07:54:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:54:17 --> Final output sent to browser
DEBUG - 2016-03-08 10:54:17 --> Total execution time: 1.1355
INFO - 2016-03-08 07:54:54 --> Config Class Initialized
INFO - 2016-03-08 07:54:54 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:54:54 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:54:54 --> Utf8 Class Initialized
INFO - 2016-03-08 07:54:54 --> URI Class Initialized
INFO - 2016-03-08 07:54:54 --> Router Class Initialized
INFO - 2016-03-08 07:54:54 --> Output Class Initialized
INFO - 2016-03-08 07:54:54 --> Security Class Initialized
DEBUG - 2016-03-08 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:54:54 --> Input Class Initialized
INFO - 2016-03-08 07:54:54 --> Language Class Initialized
INFO - 2016-03-08 07:54:54 --> Loader Class Initialized
INFO - 2016-03-08 07:54:54 --> Helper loaded: url_helper
INFO - 2016-03-08 07:54:54 --> Helper loaded: file_helper
INFO - 2016-03-08 07:54:54 --> Helper loaded: date_helper
INFO - 2016-03-08 07:54:54 --> Helper loaded: form_helper
INFO - 2016-03-08 07:54:54 --> Database Driver Class Initialized
INFO - 2016-03-08 07:54:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:54:55 --> Controller Class Initialized
INFO - 2016-03-08 07:54:55 --> Model Class Initialized
INFO - 2016-03-08 07:54:55 --> Model Class Initialized
INFO - 2016-03-08 07:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:54:55 --> Pagination Class Initialized
INFO - 2016-03-08 07:54:55 --> Helper loaded: text_helper
INFO - 2016-03-08 07:54:55 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:54:55 --> Final output sent to browser
DEBUG - 2016-03-08 10:54:55 --> Total execution time: 1.1349
INFO - 2016-03-08 07:56:38 --> Config Class Initialized
INFO - 2016-03-08 07:56:38 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:56:38 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:56:38 --> Utf8 Class Initialized
INFO - 2016-03-08 07:56:38 --> URI Class Initialized
INFO - 2016-03-08 07:56:38 --> Router Class Initialized
INFO - 2016-03-08 07:56:38 --> Output Class Initialized
INFO - 2016-03-08 07:56:38 --> Security Class Initialized
DEBUG - 2016-03-08 07:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:56:38 --> Input Class Initialized
INFO - 2016-03-08 07:56:38 --> Language Class Initialized
INFO - 2016-03-08 07:56:38 --> Loader Class Initialized
INFO - 2016-03-08 07:56:38 --> Helper loaded: url_helper
INFO - 2016-03-08 07:56:38 --> Helper loaded: file_helper
INFO - 2016-03-08 07:56:38 --> Helper loaded: date_helper
INFO - 2016-03-08 07:56:38 --> Helper loaded: form_helper
INFO - 2016-03-08 07:56:38 --> Database Driver Class Initialized
INFO - 2016-03-08 07:56:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:56:39 --> Controller Class Initialized
INFO - 2016-03-08 07:56:39 --> Model Class Initialized
INFO - 2016-03-08 07:56:39 --> Model Class Initialized
INFO - 2016-03-08 07:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:56:39 --> Pagination Class Initialized
INFO - 2016-03-08 07:56:39 --> Helper loaded: text_helper
INFO - 2016-03-08 07:56:39 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:56:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:56:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:56:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:56:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:56:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:56:39 --> Final output sent to browser
DEBUG - 2016-03-08 10:56:39 --> Total execution time: 1.2015
INFO - 2016-03-08 07:57:16 --> Config Class Initialized
INFO - 2016-03-08 07:57:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:57:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:57:16 --> Utf8 Class Initialized
INFO - 2016-03-08 07:57:16 --> URI Class Initialized
INFO - 2016-03-08 07:57:16 --> Router Class Initialized
INFO - 2016-03-08 07:57:17 --> Output Class Initialized
INFO - 2016-03-08 07:57:17 --> Security Class Initialized
DEBUG - 2016-03-08 07:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:57:17 --> Input Class Initialized
INFO - 2016-03-08 07:57:17 --> Language Class Initialized
INFO - 2016-03-08 07:57:17 --> Loader Class Initialized
INFO - 2016-03-08 07:57:17 --> Helper loaded: url_helper
INFO - 2016-03-08 07:57:17 --> Helper loaded: file_helper
INFO - 2016-03-08 07:57:17 --> Helper loaded: date_helper
INFO - 2016-03-08 07:57:17 --> Helper loaded: form_helper
INFO - 2016-03-08 07:57:17 --> Database Driver Class Initialized
INFO - 2016-03-08 07:57:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:57:18 --> Controller Class Initialized
INFO - 2016-03-08 07:57:18 --> Model Class Initialized
INFO - 2016-03-08 07:57:18 --> Model Class Initialized
INFO - 2016-03-08 07:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:57:18 --> Pagination Class Initialized
INFO - 2016-03-08 07:57:18 --> Helper loaded: text_helper
INFO - 2016-03-08 07:57:18 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:57:18 --> Final output sent to browser
DEBUG - 2016-03-08 10:57:18 --> Total execution time: 1.1753
INFO - 2016-03-08 07:58:24 --> Config Class Initialized
INFO - 2016-03-08 07:58:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:58:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:58:24 --> Utf8 Class Initialized
INFO - 2016-03-08 07:58:24 --> URI Class Initialized
INFO - 2016-03-08 07:58:24 --> Router Class Initialized
INFO - 2016-03-08 07:58:24 --> Output Class Initialized
INFO - 2016-03-08 07:58:24 --> Security Class Initialized
DEBUG - 2016-03-08 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:58:24 --> Input Class Initialized
INFO - 2016-03-08 07:58:24 --> Language Class Initialized
INFO - 2016-03-08 07:58:24 --> Loader Class Initialized
INFO - 2016-03-08 07:58:24 --> Helper loaded: url_helper
INFO - 2016-03-08 07:58:24 --> Helper loaded: file_helper
INFO - 2016-03-08 07:58:24 --> Helper loaded: date_helper
INFO - 2016-03-08 07:58:24 --> Helper loaded: form_helper
INFO - 2016-03-08 07:58:24 --> Database Driver Class Initialized
INFO - 2016-03-08 07:58:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:58:25 --> Controller Class Initialized
INFO - 2016-03-08 07:58:25 --> Model Class Initialized
INFO - 2016-03-08 07:58:25 --> Model Class Initialized
INFO - 2016-03-08 07:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:58:25 --> Pagination Class Initialized
INFO - 2016-03-08 07:58:25 --> Helper loaded: text_helper
INFO - 2016-03-08 07:58:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:58:25 --> Final output sent to browser
DEBUG - 2016-03-08 10:58:25 --> Total execution time: 1.1551
INFO - 2016-03-08 07:59:43 --> Config Class Initialized
INFO - 2016-03-08 07:59:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 07:59:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 07:59:43 --> Utf8 Class Initialized
INFO - 2016-03-08 07:59:43 --> URI Class Initialized
INFO - 2016-03-08 07:59:43 --> Router Class Initialized
INFO - 2016-03-08 07:59:43 --> Output Class Initialized
INFO - 2016-03-08 07:59:43 --> Security Class Initialized
DEBUG - 2016-03-08 07:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 07:59:43 --> Input Class Initialized
INFO - 2016-03-08 07:59:43 --> Language Class Initialized
INFO - 2016-03-08 07:59:43 --> Loader Class Initialized
INFO - 2016-03-08 07:59:43 --> Helper loaded: url_helper
INFO - 2016-03-08 07:59:43 --> Helper loaded: file_helper
INFO - 2016-03-08 07:59:43 --> Helper loaded: date_helper
INFO - 2016-03-08 07:59:43 --> Helper loaded: form_helper
INFO - 2016-03-08 07:59:43 --> Database Driver Class Initialized
INFO - 2016-03-08 07:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 07:59:44 --> Controller Class Initialized
INFO - 2016-03-08 07:59:44 --> Model Class Initialized
INFO - 2016-03-08 07:59:44 --> Model Class Initialized
INFO - 2016-03-08 07:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 07:59:44 --> Pagination Class Initialized
INFO - 2016-03-08 07:59:44 --> Helper loaded: text_helper
INFO - 2016-03-08 07:59:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 10:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 10:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 10:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 10:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 10:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 10:59:44 --> Final output sent to browser
DEBUG - 2016-03-08 10:59:44 --> Total execution time: 1.1459
INFO - 2016-03-08 08:00:40 --> Config Class Initialized
INFO - 2016-03-08 08:00:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:00:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:00:40 --> Utf8 Class Initialized
INFO - 2016-03-08 08:00:40 --> URI Class Initialized
INFO - 2016-03-08 08:00:40 --> Router Class Initialized
INFO - 2016-03-08 08:00:40 --> Output Class Initialized
INFO - 2016-03-08 08:00:40 --> Security Class Initialized
DEBUG - 2016-03-08 08:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:00:40 --> Input Class Initialized
INFO - 2016-03-08 08:00:40 --> Language Class Initialized
INFO - 2016-03-08 08:00:40 --> Loader Class Initialized
INFO - 2016-03-08 08:00:40 --> Helper loaded: url_helper
INFO - 2016-03-08 08:00:40 --> Helper loaded: file_helper
INFO - 2016-03-08 08:00:40 --> Helper loaded: date_helper
INFO - 2016-03-08 08:00:40 --> Helper loaded: form_helper
INFO - 2016-03-08 08:00:40 --> Database Driver Class Initialized
INFO - 2016-03-08 08:00:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:00:41 --> Controller Class Initialized
INFO - 2016-03-08 08:00:41 --> Model Class Initialized
INFO - 2016-03-08 08:00:41 --> Model Class Initialized
INFO - 2016-03-08 08:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:00:41 --> Pagination Class Initialized
INFO - 2016-03-08 08:00:41 --> Helper loaded: text_helper
INFO - 2016-03-08 08:00:41 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:00:41 --> Final output sent to browser
DEBUG - 2016-03-08 11:00:41 --> Total execution time: 1.1507
INFO - 2016-03-08 08:01:42 --> Config Class Initialized
INFO - 2016-03-08 08:01:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:01:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:01:42 --> Utf8 Class Initialized
INFO - 2016-03-08 08:01:42 --> URI Class Initialized
INFO - 2016-03-08 08:01:42 --> Router Class Initialized
INFO - 2016-03-08 08:01:42 --> Output Class Initialized
INFO - 2016-03-08 08:01:42 --> Security Class Initialized
DEBUG - 2016-03-08 08:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:01:42 --> Input Class Initialized
INFO - 2016-03-08 08:01:42 --> Language Class Initialized
INFO - 2016-03-08 08:01:42 --> Loader Class Initialized
INFO - 2016-03-08 08:01:42 --> Helper loaded: url_helper
INFO - 2016-03-08 08:01:42 --> Helper loaded: file_helper
INFO - 2016-03-08 08:01:42 --> Helper loaded: date_helper
INFO - 2016-03-08 08:01:42 --> Helper loaded: form_helper
INFO - 2016-03-08 08:01:42 --> Database Driver Class Initialized
INFO - 2016-03-08 08:01:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:01:43 --> Controller Class Initialized
INFO - 2016-03-08 08:01:43 --> Model Class Initialized
INFO - 2016-03-08 08:01:43 --> Model Class Initialized
INFO - 2016-03-08 08:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:01:43 --> Pagination Class Initialized
INFO - 2016-03-08 08:01:43 --> Helper loaded: text_helper
INFO - 2016-03-08 08:01:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:01:43 --> Final output sent to browser
DEBUG - 2016-03-08 11:01:43 --> Total execution time: 1.1798
INFO - 2016-03-08 08:02:07 --> Config Class Initialized
INFO - 2016-03-08 08:02:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:02:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:02:08 --> Utf8 Class Initialized
INFO - 2016-03-08 08:02:08 --> URI Class Initialized
INFO - 2016-03-08 08:02:08 --> Router Class Initialized
INFO - 2016-03-08 08:02:08 --> Output Class Initialized
INFO - 2016-03-08 08:02:08 --> Security Class Initialized
DEBUG - 2016-03-08 08:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:02:08 --> Input Class Initialized
INFO - 2016-03-08 08:02:08 --> Language Class Initialized
INFO - 2016-03-08 08:02:08 --> Loader Class Initialized
INFO - 2016-03-08 08:02:08 --> Helper loaded: url_helper
INFO - 2016-03-08 08:02:08 --> Helper loaded: file_helper
INFO - 2016-03-08 08:02:08 --> Helper loaded: date_helper
INFO - 2016-03-08 08:02:08 --> Helper loaded: form_helper
INFO - 2016-03-08 08:02:08 --> Database Driver Class Initialized
INFO - 2016-03-08 08:02:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:02:09 --> Controller Class Initialized
INFO - 2016-03-08 08:02:09 --> Model Class Initialized
INFO - 2016-03-08 08:02:09 --> Model Class Initialized
INFO - 2016-03-08 08:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:02:09 --> Pagination Class Initialized
INFO - 2016-03-08 08:02:09 --> Helper loaded: text_helper
INFO - 2016-03-08 08:02:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:02:09 --> Final output sent to browser
DEBUG - 2016-03-08 11:02:09 --> Total execution time: 1.2296
INFO - 2016-03-08 08:02:40 --> Config Class Initialized
INFO - 2016-03-08 08:02:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:02:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:02:40 --> Utf8 Class Initialized
INFO - 2016-03-08 08:02:40 --> URI Class Initialized
INFO - 2016-03-08 08:02:40 --> Router Class Initialized
INFO - 2016-03-08 08:02:40 --> Output Class Initialized
INFO - 2016-03-08 08:02:40 --> Security Class Initialized
DEBUG - 2016-03-08 08:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:02:40 --> Input Class Initialized
INFO - 2016-03-08 08:02:40 --> Language Class Initialized
INFO - 2016-03-08 08:02:40 --> Loader Class Initialized
INFO - 2016-03-08 08:02:40 --> Helper loaded: url_helper
INFO - 2016-03-08 08:02:40 --> Helper loaded: file_helper
INFO - 2016-03-08 08:02:40 --> Helper loaded: date_helper
INFO - 2016-03-08 08:02:40 --> Helper loaded: form_helper
INFO - 2016-03-08 08:02:40 --> Database Driver Class Initialized
INFO - 2016-03-08 08:02:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:02:41 --> Controller Class Initialized
INFO - 2016-03-08 08:02:41 --> Model Class Initialized
INFO - 2016-03-08 08:02:41 --> Model Class Initialized
INFO - 2016-03-08 08:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:02:41 --> Pagination Class Initialized
INFO - 2016-03-08 08:02:41 --> Helper loaded: text_helper
INFO - 2016-03-08 08:02:41 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:02:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:02:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:02:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:02:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:02:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:02:41 --> Final output sent to browser
DEBUG - 2016-03-08 11:02:41 --> Total execution time: 1.1649
INFO - 2016-03-08 08:03:27 --> Config Class Initialized
INFO - 2016-03-08 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:03:27 --> Utf8 Class Initialized
INFO - 2016-03-08 08:03:27 --> URI Class Initialized
INFO - 2016-03-08 08:03:28 --> Router Class Initialized
INFO - 2016-03-08 08:03:28 --> Output Class Initialized
INFO - 2016-03-08 08:03:28 --> Security Class Initialized
DEBUG - 2016-03-08 08:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:03:28 --> Input Class Initialized
INFO - 2016-03-08 08:03:28 --> Language Class Initialized
INFO - 2016-03-08 08:03:28 --> Loader Class Initialized
INFO - 2016-03-08 08:03:28 --> Helper loaded: url_helper
INFO - 2016-03-08 08:03:28 --> Helper loaded: file_helper
INFO - 2016-03-08 08:03:28 --> Helper loaded: date_helper
INFO - 2016-03-08 08:03:28 --> Helper loaded: form_helper
INFO - 2016-03-08 08:03:28 --> Database Driver Class Initialized
INFO - 2016-03-08 08:03:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:03:29 --> Controller Class Initialized
INFO - 2016-03-08 08:03:29 --> Model Class Initialized
INFO - 2016-03-08 08:03:29 --> Model Class Initialized
INFO - 2016-03-08 08:03:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:03:29 --> Pagination Class Initialized
INFO - 2016-03-08 08:03:29 --> Helper loaded: text_helper
INFO - 2016-03-08 08:03:29 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:03:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:03:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:03:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:03:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:03:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:03:29 --> Final output sent to browser
DEBUG - 2016-03-08 11:03:29 --> Total execution time: 1.1794
INFO - 2016-03-08 08:03:49 --> Config Class Initialized
INFO - 2016-03-08 08:03:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:03:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:03:49 --> Utf8 Class Initialized
INFO - 2016-03-08 08:03:49 --> URI Class Initialized
INFO - 2016-03-08 08:03:49 --> Router Class Initialized
INFO - 2016-03-08 08:03:49 --> Output Class Initialized
INFO - 2016-03-08 08:03:49 --> Security Class Initialized
DEBUG - 2016-03-08 08:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:03:49 --> Input Class Initialized
INFO - 2016-03-08 08:03:49 --> Language Class Initialized
INFO - 2016-03-08 08:03:49 --> Loader Class Initialized
INFO - 2016-03-08 08:03:49 --> Helper loaded: url_helper
INFO - 2016-03-08 08:03:49 --> Helper loaded: file_helper
INFO - 2016-03-08 08:03:49 --> Helper loaded: date_helper
INFO - 2016-03-08 08:03:49 --> Helper loaded: form_helper
INFO - 2016-03-08 08:03:49 --> Database Driver Class Initialized
INFO - 2016-03-08 08:03:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:03:50 --> Controller Class Initialized
INFO - 2016-03-08 08:03:50 --> Model Class Initialized
INFO - 2016-03-08 08:03:50 --> Model Class Initialized
INFO - 2016-03-08 08:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:03:50 --> Pagination Class Initialized
INFO - 2016-03-08 08:03:50 --> Helper loaded: text_helper
INFO - 2016-03-08 08:03:50 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:03:50 --> Final output sent to browser
DEBUG - 2016-03-08 11:03:50 --> Total execution time: 1.2001
INFO - 2016-03-08 08:04:55 --> Config Class Initialized
INFO - 2016-03-08 08:04:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:04:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:04:55 --> Utf8 Class Initialized
INFO - 2016-03-08 08:04:55 --> URI Class Initialized
INFO - 2016-03-08 08:04:55 --> Router Class Initialized
INFO - 2016-03-08 08:04:55 --> Output Class Initialized
INFO - 2016-03-08 08:04:55 --> Security Class Initialized
DEBUG - 2016-03-08 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:04:55 --> Input Class Initialized
INFO - 2016-03-08 08:04:55 --> Language Class Initialized
INFO - 2016-03-08 08:04:55 --> Loader Class Initialized
INFO - 2016-03-08 08:04:55 --> Helper loaded: url_helper
INFO - 2016-03-08 08:04:55 --> Helper loaded: file_helper
INFO - 2016-03-08 08:04:55 --> Helper loaded: date_helper
INFO - 2016-03-08 08:04:55 --> Helper loaded: form_helper
INFO - 2016-03-08 08:04:55 --> Database Driver Class Initialized
INFO - 2016-03-08 08:04:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:04:56 --> Controller Class Initialized
INFO - 2016-03-08 08:04:56 --> Model Class Initialized
INFO - 2016-03-08 08:04:56 --> Model Class Initialized
INFO - 2016-03-08 08:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:04:56 --> Pagination Class Initialized
INFO - 2016-03-08 08:04:56 --> Helper loaded: text_helper
INFO - 2016-03-08 08:04:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:04:56 --> Final output sent to browser
DEBUG - 2016-03-08 11:04:56 --> Total execution time: 1.2248
INFO - 2016-03-08 08:05:42 --> Config Class Initialized
INFO - 2016-03-08 08:05:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:05:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:05:42 --> Utf8 Class Initialized
INFO - 2016-03-08 08:05:42 --> URI Class Initialized
INFO - 2016-03-08 08:05:42 --> Router Class Initialized
INFO - 2016-03-08 08:05:42 --> Output Class Initialized
INFO - 2016-03-08 08:05:42 --> Security Class Initialized
DEBUG - 2016-03-08 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:05:42 --> Input Class Initialized
INFO - 2016-03-08 08:05:42 --> Language Class Initialized
INFO - 2016-03-08 08:05:42 --> Loader Class Initialized
INFO - 2016-03-08 08:05:42 --> Helper loaded: url_helper
INFO - 2016-03-08 08:05:42 --> Helper loaded: file_helper
INFO - 2016-03-08 08:05:42 --> Helper loaded: date_helper
INFO - 2016-03-08 08:05:42 --> Helper loaded: form_helper
INFO - 2016-03-08 08:05:42 --> Database Driver Class Initialized
INFO - 2016-03-08 08:05:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:05:43 --> Controller Class Initialized
INFO - 2016-03-08 08:05:43 --> Model Class Initialized
INFO - 2016-03-08 08:05:43 --> Model Class Initialized
INFO - 2016-03-08 08:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:05:43 --> Pagination Class Initialized
INFO - 2016-03-08 08:05:43 --> Helper loaded: text_helper
INFO - 2016-03-08 08:05:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:05:43 --> Final output sent to browser
DEBUG - 2016-03-08 11:05:43 --> Total execution time: 1.1802
INFO - 2016-03-08 08:06:01 --> Config Class Initialized
INFO - 2016-03-08 08:06:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:06:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:06:01 --> Utf8 Class Initialized
INFO - 2016-03-08 08:06:01 --> URI Class Initialized
INFO - 2016-03-08 08:06:01 --> Router Class Initialized
INFO - 2016-03-08 08:06:01 --> Output Class Initialized
INFO - 2016-03-08 08:06:01 --> Security Class Initialized
DEBUG - 2016-03-08 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:06:01 --> Input Class Initialized
INFO - 2016-03-08 08:06:01 --> Language Class Initialized
INFO - 2016-03-08 08:06:01 --> Loader Class Initialized
INFO - 2016-03-08 08:06:01 --> Helper loaded: url_helper
INFO - 2016-03-08 08:06:01 --> Helper loaded: file_helper
INFO - 2016-03-08 08:06:01 --> Helper loaded: date_helper
INFO - 2016-03-08 08:06:01 --> Helper loaded: form_helper
INFO - 2016-03-08 08:06:01 --> Database Driver Class Initialized
INFO - 2016-03-08 08:06:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:06:02 --> Controller Class Initialized
INFO - 2016-03-08 08:06:02 --> Model Class Initialized
INFO - 2016-03-08 08:06:02 --> Model Class Initialized
INFO - 2016-03-08 08:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:06:02 --> Pagination Class Initialized
INFO - 2016-03-08 08:06:02 --> Helper loaded: text_helper
INFO - 2016-03-08 08:06:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:06:02 --> Final output sent to browser
DEBUG - 2016-03-08 11:06:02 --> Total execution time: 1.1163
INFO - 2016-03-08 08:06:19 --> Config Class Initialized
INFO - 2016-03-08 08:06:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:06:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:06:19 --> Utf8 Class Initialized
INFO - 2016-03-08 08:06:19 --> URI Class Initialized
INFO - 2016-03-08 08:06:19 --> Router Class Initialized
INFO - 2016-03-08 08:06:19 --> Output Class Initialized
INFO - 2016-03-08 08:06:19 --> Security Class Initialized
DEBUG - 2016-03-08 08:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:06:19 --> Input Class Initialized
INFO - 2016-03-08 08:06:19 --> Language Class Initialized
INFO - 2016-03-08 08:06:19 --> Loader Class Initialized
INFO - 2016-03-08 08:06:19 --> Helper loaded: url_helper
INFO - 2016-03-08 08:06:19 --> Helper loaded: file_helper
INFO - 2016-03-08 08:06:19 --> Helper loaded: date_helper
INFO - 2016-03-08 08:06:19 --> Helper loaded: form_helper
INFO - 2016-03-08 08:06:19 --> Database Driver Class Initialized
INFO - 2016-03-08 08:06:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:06:20 --> Controller Class Initialized
INFO - 2016-03-08 08:06:20 --> Model Class Initialized
INFO - 2016-03-08 08:06:20 --> Model Class Initialized
INFO - 2016-03-08 08:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:06:20 --> Pagination Class Initialized
INFO - 2016-03-08 08:06:20 --> Helper loaded: text_helper
INFO - 2016-03-08 08:06:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:06:20 --> Final output sent to browser
DEBUG - 2016-03-08 11:06:20 --> Total execution time: 1.1647
INFO - 2016-03-08 08:06:36 --> Config Class Initialized
INFO - 2016-03-08 08:06:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:06:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:06:36 --> Utf8 Class Initialized
INFO - 2016-03-08 08:06:36 --> URI Class Initialized
INFO - 2016-03-08 08:06:36 --> Router Class Initialized
INFO - 2016-03-08 08:06:36 --> Output Class Initialized
INFO - 2016-03-08 08:06:36 --> Security Class Initialized
DEBUG - 2016-03-08 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:06:36 --> Input Class Initialized
INFO - 2016-03-08 08:06:36 --> Language Class Initialized
INFO - 2016-03-08 08:06:36 --> Loader Class Initialized
INFO - 2016-03-08 08:06:36 --> Helper loaded: url_helper
INFO - 2016-03-08 08:06:36 --> Helper loaded: file_helper
INFO - 2016-03-08 08:06:36 --> Helper loaded: date_helper
INFO - 2016-03-08 08:06:36 --> Helper loaded: form_helper
INFO - 2016-03-08 08:06:36 --> Database Driver Class Initialized
INFO - 2016-03-08 08:06:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:06:37 --> Controller Class Initialized
INFO - 2016-03-08 08:06:37 --> Model Class Initialized
INFO - 2016-03-08 08:06:37 --> Model Class Initialized
INFO - 2016-03-08 08:06:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:06:37 --> Pagination Class Initialized
INFO - 2016-03-08 08:06:37 --> Helper loaded: text_helper
INFO - 2016-03-08 08:06:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:06:37 --> Final output sent to browser
DEBUG - 2016-03-08 11:06:37 --> Total execution time: 1.1916
INFO - 2016-03-08 08:06:49 --> Config Class Initialized
INFO - 2016-03-08 08:06:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:06:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:06:49 --> Utf8 Class Initialized
INFO - 2016-03-08 08:06:49 --> URI Class Initialized
INFO - 2016-03-08 08:06:49 --> Router Class Initialized
INFO - 2016-03-08 08:06:49 --> Output Class Initialized
INFO - 2016-03-08 08:06:49 --> Security Class Initialized
DEBUG - 2016-03-08 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:06:49 --> Input Class Initialized
INFO - 2016-03-08 08:06:49 --> Language Class Initialized
INFO - 2016-03-08 08:06:49 --> Loader Class Initialized
INFO - 2016-03-08 08:06:49 --> Helper loaded: url_helper
INFO - 2016-03-08 08:06:49 --> Helper loaded: file_helper
INFO - 2016-03-08 08:06:49 --> Helper loaded: date_helper
INFO - 2016-03-08 08:06:49 --> Helper loaded: form_helper
INFO - 2016-03-08 08:06:49 --> Database Driver Class Initialized
INFO - 2016-03-08 08:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:06:51 --> Controller Class Initialized
INFO - 2016-03-08 08:06:51 --> Model Class Initialized
INFO - 2016-03-08 08:06:51 --> Model Class Initialized
INFO - 2016-03-08 08:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:06:51 --> Pagination Class Initialized
INFO - 2016-03-08 08:06:51 --> Helper loaded: text_helper
INFO - 2016-03-08 08:06:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:06:51 --> Final output sent to browser
DEBUG - 2016-03-08 11:06:51 --> Total execution time: 1.1648
INFO - 2016-03-08 08:07:14 --> Config Class Initialized
INFO - 2016-03-08 08:07:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:07:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:07:14 --> Utf8 Class Initialized
INFO - 2016-03-08 08:07:14 --> URI Class Initialized
INFO - 2016-03-08 08:07:14 --> Router Class Initialized
INFO - 2016-03-08 08:07:14 --> Output Class Initialized
INFO - 2016-03-08 08:07:14 --> Security Class Initialized
DEBUG - 2016-03-08 08:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:07:14 --> Input Class Initialized
INFO - 2016-03-08 08:07:14 --> Language Class Initialized
INFO - 2016-03-08 08:07:14 --> Loader Class Initialized
INFO - 2016-03-08 08:07:14 --> Helper loaded: url_helper
INFO - 2016-03-08 08:07:14 --> Helper loaded: file_helper
INFO - 2016-03-08 08:07:14 --> Helper loaded: date_helper
INFO - 2016-03-08 08:07:14 --> Helper loaded: form_helper
INFO - 2016-03-08 08:07:14 --> Database Driver Class Initialized
INFO - 2016-03-08 08:07:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:07:15 --> Controller Class Initialized
INFO - 2016-03-08 08:07:15 --> Model Class Initialized
INFO - 2016-03-08 08:07:15 --> Model Class Initialized
INFO - 2016-03-08 08:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:07:15 --> Pagination Class Initialized
INFO - 2016-03-08 08:07:15 --> Helper loaded: text_helper
INFO - 2016-03-08 08:07:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:07:15 --> Final output sent to browser
DEBUG - 2016-03-08 11:07:15 --> Total execution time: 1.1877
INFO - 2016-03-08 08:09:21 --> Config Class Initialized
INFO - 2016-03-08 08:09:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:09:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:09:21 --> Utf8 Class Initialized
INFO - 2016-03-08 08:09:21 --> URI Class Initialized
INFO - 2016-03-08 08:09:21 --> Router Class Initialized
INFO - 2016-03-08 08:09:21 --> Output Class Initialized
INFO - 2016-03-08 08:09:21 --> Security Class Initialized
DEBUG - 2016-03-08 08:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:09:21 --> Input Class Initialized
INFO - 2016-03-08 08:09:21 --> Language Class Initialized
INFO - 2016-03-08 08:09:21 --> Loader Class Initialized
INFO - 2016-03-08 08:09:21 --> Helper loaded: url_helper
INFO - 2016-03-08 08:09:21 --> Helper loaded: file_helper
INFO - 2016-03-08 08:09:21 --> Helper loaded: date_helper
INFO - 2016-03-08 08:09:21 --> Helper loaded: form_helper
INFO - 2016-03-08 08:09:21 --> Database Driver Class Initialized
INFO - 2016-03-08 08:09:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:09:22 --> Controller Class Initialized
INFO - 2016-03-08 08:09:22 --> Model Class Initialized
INFO - 2016-03-08 08:09:22 --> Model Class Initialized
INFO - 2016-03-08 08:09:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:09:22 --> Pagination Class Initialized
INFO - 2016-03-08 08:09:22 --> Helper loaded: text_helper
INFO - 2016-03-08 08:09:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:09:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:09:22 --> Final output sent to browser
DEBUG - 2016-03-08 11:09:22 --> Total execution time: 1.1760
INFO - 2016-03-08 08:09:50 --> Config Class Initialized
INFO - 2016-03-08 08:09:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:09:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:09:50 --> Utf8 Class Initialized
INFO - 2016-03-08 08:09:50 --> URI Class Initialized
INFO - 2016-03-08 08:09:50 --> Router Class Initialized
INFO - 2016-03-08 08:09:50 --> Output Class Initialized
INFO - 2016-03-08 08:09:50 --> Security Class Initialized
DEBUG - 2016-03-08 08:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:09:50 --> Input Class Initialized
INFO - 2016-03-08 08:09:50 --> Language Class Initialized
INFO - 2016-03-08 08:09:50 --> Loader Class Initialized
INFO - 2016-03-08 08:09:50 --> Helper loaded: url_helper
INFO - 2016-03-08 08:09:50 --> Helper loaded: file_helper
INFO - 2016-03-08 08:09:50 --> Helper loaded: date_helper
INFO - 2016-03-08 08:09:50 --> Helper loaded: form_helper
INFO - 2016-03-08 08:09:50 --> Database Driver Class Initialized
INFO - 2016-03-08 08:09:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:09:51 --> Controller Class Initialized
INFO - 2016-03-08 08:09:51 --> Model Class Initialized
INFO - 2016-03-08 08:09:51 --> Model Class Initialized
INFO - 2016-03-08 08:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:09:51 --> Pagination Class Initialized
INFO - 2016-03-08 08:09:51 --> Helper loaded: text_helper
INFO - 2016-03-08 08:09:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:09:51 --> Final output sent to browser
DEBUG - 2016-03-08 11:09:51 --> Total execution time: 1.1714
INFO - 2016-03-08 08:10:16 --> Config Class Initialized
INFO - 2016-03-08 08:10:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:10:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:10:16 --> Utf8 Class Initialized
INFO - 2016-03-08 08:10:16 --> URI Class Initialized
INFO - 2016-03-08 08:10:16 --> Router Class Initialized
INFO - 2016-03-08 08:10:16 --> Output Class Initialized
INFO - 2016-03-08 08:10:16 --> Security Class Initialized
DEBUG - 2016-03-08 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:10:16 --> Input Class Initialized
INFO - 2016-03-08 08:10:16 --> Language Class Initialized
INFO - 2016-03-08 08:10:16 --> Loader Class Initialized
INFO - 2016-03-08 08:10:16 --> Helper loaded: url_helper
INFO - 2016-03-08 08:10:16 --> Helper loaded: file_helper
INFO - 2016-03-08 08:10:16 --> Helper loaded: date_helper
INFO - 2016-03-08 08:10:16 --> Helper loaded: form_helper
INFO - 2016-03-08 08:10:16 --> Database Driver Class Initialized
INFO - 2016-03-08 08:10:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:10:17 --> Controller Class Initialized
INFO - 2016-03-08 08:10:17 --> Model Class Initialized
INFO - 2016-03-08 08:10:17 --> Model Class Initialized
INFO - 2016-03-08 08:10:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:10:17 --> Pagination Class Initialized
INFO - 2016-03-08 08:10:17 --> Helper loaded: text_helper
INFO - 2016-03-08 08:10:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:10:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:10:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:10:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:10:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:10:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:10:17 --> Final output sent to browser
DEBUG - 2016-03-08 11:10:17 --> Total execution time: 1.2097
INFO - 2016-03-08 08:10:36 --> Config Class Initialized
INFO - 2016-03-08 08:10:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:10:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:10:36 --> Utf8 Class Initialized
INFO - 2016-03-08 08:10:36 --> URI Class Initialized
INFO - 2016-03-08 08:10:37 --> Router Class Initialized
INFO - 2016-03-08 08:10:37 --> Output Class Initialized
INFO - 2016-03-08 08:10:37 --> Security Class Initialized
DEBUG - 2016-03-08 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:10:37 --> Input Class Initialized
INFO - 2016-03-08 08:10:37 --> Language Class Initialized
INFO - 2016-03-08 08:10:37 --> Loader Class Initialized
INFO - 2016-03-08 08:10:37 --> Helper loaded: url_helper
INFO - 2016-03-08 08:10:37 --> Helper loaded: file_helper
INFO - 2016-03-08 08:10:37 --> Helper loaded: date_helper
INFO - 2016-03-08 08:10:37 --> Helper loaded: form_helper
INFO - 2016-03-08 08:10:37 --> Database Driver Class Initialized
INFO - 2016-03-08 08:10:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:10:38 --> Controller Class Initialized
INFO - 2016-03-08 08:10:38 --> Model Class Initialized
INFO - 2016-03-08 08:10:38 --> Model Class Initialized
INFO - 2016-03-08 08:10:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:10:38 --> Pagination Class Initialized
INFO - 2016-03-08 08:10:38 --> Helper loaded: text_helper
INFO - 2016-03-08 08:10:38 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:10:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:10:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:10:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:10:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:10:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:10:38 --> Final output sent to browser
DEBUG - 2016-03-08 11:10:38 --> Total execution time: 1.1651
INFO - 2016-03-08 08:10:46 --> Config Class Initialized
INFO - 2016-03-08 08:10:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:10:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:10:46 --> Utf8 Class Initialized
INFO - 2016-03-08 08:10:46 --> URI Class Initialized
INFO - 2016-03-08 08:10:46 --> Router Class Initialized
INFO - 2016-03-08 08:10:46 --> Output Class Initialized
INFO - 2016-03-08 08:10:46 --> Security Class Initialized
DEBUG - 2016-03-08 08:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:10:46 --> Input Class Initialized
INFO - 2016-03-08 08:10:46 --> Language Class Initialized
INFO - 2016-03-08 08:10:46 --> Loader Class Initialized
INFO - 2016-03-08 08:10:46 --> Helper loaded: url_helper
INFO - 2016-03-08 08:10:46 --> Helper loaded: file_helper
INFO - 2016-03-08 08:10:46 --> Helper loaded: date_helper
INFO - 2016-03-08 08:10:46 --> Helper loaded: form_helper
INFO - 2016-03-08 08:10:46 --> Database Driver Class Initialized
INFO - 2016-03-08 08:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:10:47 --> Controller Class Initialized
INFO - 2016-03-08 08:10:47 --> Model Class Initialized
INFO - 2016-03-08 08:10:47 --> Model Class Initialized
INFO - 2016-03-08 08:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:10:47 --> Pagination Class Initialized
INFO - 2016-03-08 08:10:47 --> Helper loaded: text_helper
INFO - 2016-03-08 08:10:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:10:47 --> Final output sent to browser
DEBUG - 2016-03-08 11:10:47 --> Total execution time: 1.1175
INFO - 2016-03-08 08:25:57 --> Config Class Initialized
INFO - 2016-03-08 08:25:57 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:25:57 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:25:57 --> Utf8 Class Initialized
INFO - 2016-03-08 08:25:57 --> URI Class Initialized
INFO - 2016-03-08 08:25:57 --> Router Class Initialized
INFO - 2016-03-08 08:25:57 --> Output Class Initialized
INFO - 2016-03-08 08:25:57 --> Security Class Initialized
DEBUG - 2016-03-08 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:25:57 --> Input Class Initialized
INFO - 2016-03-08 08:25:57 --> Language Class Initialized
INFO - 2016-03-08 08:25:58 --> Loader Class Initialized
INFO - 2016-03-08 08:25:58 --> Helper loaded: url_helper
INFO - 2016-03-08 08:25:58 --> Helper loaded: file_helper
INFO - 2016-03-08 08:25:58 --> Helper loaded: date_helper
INFO - 2016-03-08 08:25:58 --> Helper loaded: form_helper
INFO - 2016-03-08 08:25:58 --> Database Driver Class Initialized
INFO - 2016-03-08 08:25:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:25:59 --> Controller Class Initialized
INFO - 2016-03-08 08:25:59 --> Model Class Initialized
INFO - 2016-03-08 08:25:59 --> Model Class Initialized
INFO - 2016-03-08 08:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:25:59 --> Pagination Class Initialized
INFO - 2016-03-08 08:25:59 --> Helper loaded: text_helper
INFO - 2016-03-08 08:25:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:25:59 --> Final output sent to browser
DEBUG - 2016-03-08 11:25:59 --> Total execution time: 1.2261
INFO - 2016-03-08 08:26:06 --> Config Class Initialized
INFO - 2016-03-08 08:26:06 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:26:06 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:26:06 --> Utf8 Class Initialized
INFO - 2016-03-08 08:26:06 --> URI Class Initialized
DEBUG - 2016-03-08 08:26:06 --> No URI present. Default controller set.
INFO - 2016-03-08 08:26:06 --> Router Class Initialized
INFO - 2016-03-08 08:26:06 --> Output Class Initialized
INFO - 2016-03-08 08:26:06 --> Security Class Initialized
DEBUG - 2016-03-08 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:26:06 --> Input Class Initialized
INFO - 2016-03-08 08:26:06 --> Language Class Initialized
INFO - 2016-03-08 08:26:06 --> Loader Class Initialized
INFO - 2016-03-08 08:26:06 --> Helper loaded: url_helper
INFO - 2016-03-08 08:26:06 --> Helper loaded: file_helper
INFO - 2016-03-08 08:26:06 --> Helper loaded: date_helper
INFO - 2016-03-08 08:26:06 --> Helper loaded: form_helper
INFO - 2016-03-08 08:26:06 --> Database Driver Class Initialized
INFO - 2016-03-08 08:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:26:07 --> Controller Class Initialized
INFO - 2016-03-08 08:26:07 --> Model Class Initialized
INFO - 2016-03-08 08:26:07 --> Model Class Initialized
INFO - 2016-03-08 08:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:26:07 --> Pagination Class Initialized
INFO - 2016-03-08 08:26:07 --> Helper loaded: text_helper
INFO - 2016-03-08 08:26:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 11:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:26:07 --> Final output sent to browser
DEBUG - 2016-03-08 11:26:07 --> Total execution time: 1.2451
INFO - 2016-03-08 08:33:07 --> Config Class Initialized
INFO - 2016-03-08 08:33:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:33:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:33:07 --> Utf8 Class Initialized
INFO - 2016-03-08 08:33:07 --> URI Class Initialized
DEBUG - 2016-03-08 08:33:07 --> No URI present. Default controller set.
INFO - 2016-03-08 08:33:07 --> Router Class Initialized
INFO - 2016-03-08 08:33:07 --> Output Class Initialized
INFO - 2016-03-08 08:33:07 --> Security Class Initialized
DEBUG - 2016-03-08 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:33:07 --> Input Class Initialized
INFO - 2016-03-08 08:33:07 --> Language Class Initialized
INFO - 2016-03-08 08:33:07 --> Loader Class Initialized
INFO - 2016-03-08 08:33:07 --> Helper loaded: url_helper
INFO - 2016-03-08 08:33:07 --> Helper loaded: file_helper
INFO - 2016-03-08 08:33:07 --> Helper loaded: date_helper
INFO - 2016-03-08 08:33:07 --> Helper loaded: form_helper
INFO - 2016-03-08 08:33:07 --> Database Driver Class Initialized
INFO - 2016-03-08 08:33:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:33:08 --> Controller Class Initialized
INFO - 2016-03-08 08:33:08 --> Model Class Initialized
INFO - 2016-03-08 08:33:08 --> Model Class Initialized
INFO - 2016-03-08 08:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:33:08 --> Pagination Class Initialized
INFO - 2016-03-08 08:33:08 --> Helper loaded: text_helper
INFO - 2016-03-08 08:33:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 11:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:33:08 --> Final output sent to browser
DEBUG - 2016-03-08 11:33:08 --> Total execution time: 1.1946
INFO - 2016-03-08 08:33:11 --> Config Class Initialized
INFO - 2016-03-08 08:33:11 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:33:11 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:33:11 --> Utf8 Class Initialized
INFO - 2016-03-08 08:33:11 --> URI Class Initialized
INFO - 2016-03-08 08:33:11 --> Router Class Initialized
INFO - 2016-03-08 08:33:11 --> Output Class Initialized
INFO - 2016-03-08 08:33:11 --> Security Class Initialized
DEBUG - 2016-03-08 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:33:11 --> Input Class Initialized
INFO - 2016-03-08 08:33:11 --> Language Class Initialized
INFO - 2016-03-08 08:33:11 --> Loader Class Initialized
INFO - 2016-03-08 08:33:11 --> Helper loaded: url_helper
INFO - 2016-03-08 08:33:11 --> Helper loaded: file_helper
INFO - 2016-03-08 08:33:11 --> Helper loaded: date_helper
INFO - 2016-03-08 08:33:11 --> Helper loaded: form_helper
INFO - 2016-03-08 08:33:11 --> Database Driver Class Initialized
INFO - 2016-03-08 08:33:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:33:12 --> Controller Class Initialized
INFO - 2016-03-08 08:33:12 --> User Agent Class Initialized
INFO - 2016-03-08 08:33:12 --> Final output sent to browser
DEBUG - 2016-03-08 08:33:12 --> Total execution time: 1.1178
INFO - 2016-03-08 08:33:33 --> Config Class Initialized
INFO - 2016-03-08 08:33:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:33:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:33:33 --> Utf8 Class Initialized
INFO - 2016-03-08 08:33:33 --> URI Class Initialized
DEBUG - 2016-03-08 08:33:33 --> No URI present. Default controller set.
INFO - 2016-03-08 08:33:33 --> Router Class Initialized
INFO - 2016-03-08 08:33:33 --> Output Class Initialized
INFO - 2016-03-08 08:33:33 --> Security Class Initialized
DEBUG - 2016-03-08 08:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:33:33 --> Input Class Initialized
INFO - 2016-03-08 08:33:33 --> Language Class Initialized
INFO - 2016-03-08 08:33:33 --> Loader Class Initialized
INFO - 2016-03-08 08:33:33 --> Helper loaded: url_helper
INFO - 2016-03-08 08:33:33 --> Helper loaded: file_helper
INFO - 2016-03-08 08:33:33 --> Helper loaded: date_helper
INFO - 2016-03-08 08:33:33 --> Helper loaded: form_helper
INFO - 2016-03-08 08:33:33 --> Database Driver Class Initialized
INFO - 2016-03-08 08:33:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:33:34 --> Controller Class Initialized
INFO - 2016-03-08 08:33:34 --> Model Class Initialized
INFO - 2016-03-08 08:33:34 --> Model Class Initialized
INFO - 2016-03-08 08:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:33:34 --> Pagination Class Initialized
INFO - 2016-03-08 08:33:34 --> Helper loaded: text_helper
INFO - 2016-03-08 08:33:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:33:34 --> Final output sent to browser
DEBUG - 2016-03-08 11:33:34 --> Total execution time: 1.1388
INFO - 2016-03-08 08:33:36 --> Config Class Initialized
INFO - 2016-03-08 08:33:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:33:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:33:36 --> Utf8 Class Initialized
INFO - 2016-03-08 08:33:36 --> URI Class Initialized
INFO - 2016-03-08 08:33:36 --> Router Class Initialized
INFO - 2016-03-08 08:33:36 --> Output Class Initialized
INFO - 2016-03-08 08:33:36 --> Security Class Initialized
DEBUG - 2016-03-08 08:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:33:36 --> Input Class Initialized
INFO - 2016-03-08 08:33:36 --> Language Class Initialized
INFO - 2016-03-08 08:33:36 --> Loader Class Initialized
INFO - 2016-03-08 08:33:36 --> Helper loaded: url_helper
INFO - 2016-03-08 08:33:36 --> Helper loaded: file_helper
INFO - 2016-03-08 08:33:36 --> Helper loaded: date_helper
INFO - 2016-03-08 08:33:36 --> Helper loaded: form_helper
INFO - 2016-03-08 08:33:36 --> Database Driver Class Initialized
INFO - 2016-03-08 08:33:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:33:37 --> Controller Class Initialized
INFO - 2016-03-08 08:33:37 --> Model Class Initialized
INFO - 2016-03-08 08:33:37 --> Model Class Initialized
INFO - 2016-03-08 08:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:33:37 --> Pagination Class Initialized
INFO - 2016-03-08 08:33:37 --> Helper loaded: text_helper
INFO - 2016-03-08 08:33:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:33:37 --> Final output sent to browser
DEBUG - 2016-03-08 11:33:37 --> Total execution time: 1.1528
INFO - 2016-03-08 08:33:44 --> Config Class Initialized
INFO - 2016-03-08 08:33:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:33:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:33:44 --> Utf8 Class Initialized
INFO - 2016-03-08 08:33:44 --> URI Class Initialized
INFO - 2016-03-08 08:33:44 --> Router Class Initialized
INFO - 2016-03-08 08:33:44 --> Output Class Initialized
INFO - 2016-03-08 08:33:44 --> Security Class Initialized
DEBUG - 2016-03-08 08:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:33:44 --> Input Class Initialized
INFO - 2016-03-08 08:33:44 --> Language Class Initialized
INFO - 2016-03-08 08:33:44 --> Loader Class Initialized
INFO - 2016-03-08 08:33:44 --> Helper loaded: url_helper
INFO - 2016-03-08 08:33:44 --> Helper loaded: file_helper
INFO - 2016-03-08 08:33:44 --> Helper loaded: date_helper
INFO - 2016-03-08 08:33:44 --> Helper loaded: form_helper
INFO - 2016-03-08 08:33:44 --> Database Driver Class Initialized
INFO - 2016-03-08 08:33:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:33:45 --> Controller Class Initialized
INFO - 2016-03-08 08:33:45 --> Model Class Initialized
INFO - 2016-03-08 08:33:45 --> Model Class Initialized
INFO - 2016-03-08 08:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:33:45 --> Pagination Class Initialized
INFO - 2016-03-08 08:33:45 --> Helper loaded: text_helper
INFO - 2016-03-08 08:33:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:33:45 --> Final output sent to browser
DEBUG - 2016-03-08 11:33:45 --> Total execution time: 1.2122
INFO - 2016-03-08 08:34:03 --> Config Class Initialized
INFO - 2016-03-08 08:34:03 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:34:03 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:34:03 --> Utf8 Class Initialized
INFO - 2016-03-08 08:34:03 --> URI Class Initialized
INFO - 2016-03-08 08:34:03 --> Router Class Initialized
INFO - 2016-03-08 08:34:03 --> Output Class Initialized
INFO - 2016-03-08 08:34:03 --> Security Class Initialized
DEBUG - 2016-03-08 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:34:03 --> Input Class Initialized
INFO - 2016-03-08 08:34:03 --> Language Class Initialized
INFO - 2016-03-08 08:34:03 --> Loader Class Initialized
INFO - 2016-03-08 08:34:03 --> Helper loaded: url_helper
INFO - 2016-03-08 08:34:03 --> Helper loaded: file_helper
INFO - 2016-03-08 08:34:03 --> Helper loaded: date_helper
INFO - 2016-03-08 08:34:03 --> Helper loaded: form_helper
INFO - 2016-03-08 08:34:03 --> Database Driver Class Initialized
INFO - 2016-03-08 08:34:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:34:04 --> Controller Class Initialized
INFO - 2016-03-08 08:34:04 --> Model Class Initialized
INFO - 2016-03-08 08:34:04 --> Model Class Initialized
INFO - 2016-03-08 08:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:34:04 --> Pagination Class Initialized
INFO - 2016-03-08 08:34:04 --> Helper loaded: text_helper
INFO - 2016-03-08 08:34:04 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:34:04 --> Final output sent to browser
DEBUG - 2016-03-08 11:34:04 --> Total execution time: 1.1781
INFO - 2016-03-08 08:34:06 --> Config Class Initialized
INFO - 2016-03-08 08:34:06 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:34:06 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:34:06 --> Utf8 Class Initialized
INFO - 2016-03-08 08:34:06 --> URI Class Initialized
INFO - 2016-03-08 08:34:06 --> Router Class Initialized
INFO - 2016-03-08 08:34:06 --> Output Class Initialized
INFO - 2016-03-08 08:34:06 --> Security Class Initialized
DEBUG - 2016-03-08 08:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:34:06 --> Input Class Initialized
INFO - 2016-03-08 08:34:06 --> Language Class Initialized
INFO - 2016-03-08 08:34:06 --> Loader Class Initialized
INFO - 2016-03-08 08:34:06 --> Helper loaded: url_helper
INFO - 2016-03-08 08:34:06 --> Helper loaded: file_helper
INFO - 2016-03-08 08:34:06 --> Helper loaded: date_helper
INFO - 2016-03-08 08:34:06 --> Helper loaded: form_helper
INFO - 2016-03-08 08:34:06 --> Database Driver Class Initialized
INFO - 2016-03-08 08:34:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:34:07 --> Controller Class Initialized
INFO - 2016-03-08 08:34:07 --> Model Class Initialized
INFO - 2016-03-08 08:34:07 --> Model Class Initialized
INFO - 2016-03-08 08:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:34:07 --> Pagination Class Initialized
INFO - 2016-03-08 08:34:07 --> Helper loaded: text_helper
INFO - 2016-03-08 08:34:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:34:07 --> Final output sent to browser
DEBUG - 2016-03-08 11:34:07 --> Total execution time: 1.1901
INFO - 2016-03-08 08:34:10 --> Config Class Initialized
INFO - 2016-03-08 08:34:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:34:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:34:10 --> Utf8 Class Initialized
INFO - 2016-03-08 08:34:10 --> URI Class Initialized
INFO - 2016-03-08 08:34:10 --> Router Class Initialized
INFO - 2016-03-08 08:34:10 --> Output Class Initialized
INFO - 2016-03-08 08:34:10 --> Security Class Initialized
DEBUG - 2016-03-08 08:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:34:10 --> Input Class Initialized
INFO - 2016-03-08 08:34:10 --> Language Class Initialized
INFO - 2016-03-08 08:34:10 --> Loader Class Initialized
INFO - 2016-03-08 08:34:10 --> Helper loaded: url_helper
INFO - 2016-03-08 08:34:10 --> Helper loaded: file_helper
INFO - 2016-03-08 08:34:10 --> Helper loaded: date_helper
INFO - 2016-03-08 08:34:10 --> Helper loaded: form_helper
INFO - 2016-03-08 08:34:10 --> Database Driver Class Initialized
INFO - 2016-03-08 08:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:34:11 --> Controller Class Initialized
INFO - 2016-03-08 08:34:11 --> Model Class Initialized
INFO - 2016-03-08 08:34:11 --> Model Class Initialized
INFO - 2016-03-08 08:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:34:11 --> Pagination Class Initialized
INFO - 2016-03-08 08:34:11 --> Helper loaded: text_helper
INFO - 2016-03-08 08:34:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:34:11 --> Final output sent to browser
DEBUG - 2016-03-08 11:34:11 --> Total execution time: 1.1343
INFO - 2016-03-08 08:34:17 --> Config Class Initialized
INFO - 2016-03-08 08:34:17 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:34:17 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:34:17 --> Utf8 Class Initialized
INFO - 2016-03-08 08:34:17 --> URI Class Initialized
INFO - 2016-03-08 08:34:17 --> Router Class Initialized
INFO - 2016-03-08 08:34:17 --> Output Class Initialized
INFO - 2016-03-08 08:34:17 --> Security Class Initialized
DEBUG - 2016-03-08 08:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:34:17 --> Input Class Initialized
INFO - 2016-03-08 08:34:17 --> Language Class Initialized
INFO - 2016-03-08 08:34:17 --> Loader Class Initialized
INFO - 2016-03-08 08:34:17 --> Helper loaded: url_helper
INFO - 2016-03-08 08:34:17 --> Helper loaded: file_helper
INFO - 2016-03-08 08:34:17 --> Helper loaded: date_helper
INFO - 2016-03-08 08:34:17 --> Helper loaded: form_helper
INFO - 2016-03-08 08:34:17 --> Database Driver Class Initialized
INFO - 2016-03-08 08:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:34:18 --> Controller Class Initialized
INFO - 2016-03-08 08:34:18 --> Model Class Initialized
INFO - 2016-03-08 08:34:18 --> Model Class Initialized
INFO - 2016-03-08 08:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:34:18 --> Pagination Class Initialized
INFO - 2016-03-08 08:34:18 --> Helper loaded: text_helper
INFO - 2016-03-08 08:34:18 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:34:18 --> Final output sent to browser
DEBUG - 2016-03-08 11:34:18 --> Total execution time: 1.1471
INFO - 2016-03-08 08:34:26 --> Config Class Initialized
INFO - 2016-03-08 08:34:26 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:34:26 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:34:26 --> Utf8 Class Initialized
INFO - 2016-03-08 08:34:26 --> URI Class Initialized
INFO - 2016-03-08 08:34:26 --> Router Class Initialized
INFO - 2016-03-08 08:34:26 --> Output Class Initialized
INFO - 2016-03-08 08:34:26 --> Security Class Initialized
DEBUG - 2016-03-08 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:34:26 --> Input Class Initialized
INFO - 2016-03-08 08:34:26 --> Language Class Initialized
INFO - 2016-03-08 08:34:26 --> Loader Class Initialized
INFO - 2016-03-08 08:34:26 --> Helper loaded: url_helper
INFO - 2016-03-08 08:34:26 --> Helper loaded: file_helper
INFO - 2016-03-08 08:34:26 --> Helper loaded: date_helper
INFO - 2016-03-08 08:34:26 --> Helper loaded: form_helper
INFO - 2016-03-08 08:34:26 --> Database Driver Class Initialized
INFO - 2016-03-08 08:34:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:34:27 --> Controller Class Initialized
INFO - 2016-03-08 08:34:27 --> Model Class Initialized
INFO - 2016-03-08 08:34:27 --> Model Class Initialized
INFO - 2016-03-08 08:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:34:27 --> Pagination Class Initialized
INFO - 2016-03-08 08:34:27 --> Helper loaded: text_helper
INFO - 2016-03-08 08:34:27 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:34:27 --> Final output sent to browser
DEBUG - 2016-03-08 11:34:27 --> Total execution time: 1.1467
INFO - 2016-03-08 08:35:06 --> Config Class Initialized
INFO - 2016-03-08 08:35:06 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:35:06 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:35:06 --> Utf8 Class Initialized
INFO - 2016-03-08 08:35:06 --> URI Class Initialized
INFO - 2016-03-08 08:35:06 --> Router Class Initialized
INFO - 2016-03-08 08:35:06 --> Output Class Initialized
INFO - 2016-03-08 08:35:06 --> Security Class Initialized
DEBUG - 2016-03-08 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:35:06 --> Input Class Initialized
INFO - 2016-03-08 08:35:06 --> Language Class Initialized
INFO - 2016-03-08 08:35:06 --> Loader Class Initialized
INFO - 2016-03-08 08:35:06 --> Helper loaded: url_helper
INFO - 2016-03-08 08:35:06 --> Helper loaded: file_helper
INFO - 2016-03-08 08:35:06 --> Helper loaded: date_helper
INFO - 2016-03-08 08:35:06 --> Helper loaded: form_helper
INFO - 2016-03-08 08:35:06 --> Database Driver Class Initialized
INFO - 2016-03-08 08:35:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:35:07 --> Controller Class Initialized
INFO - 2016-03-08 08:35:07 --> Model Class Initialized
INFO - 2016-03-08 08:35:07 --> Model Class Initialized
INFO - 2016-03-08 08:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:35:07 --> Pagination Class Initialized
INFO - 2016-03-08 08:35:07 --> Helper loaded: text_helper
INFO - 2016-03-08 08:35:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:35:07 --> Final output sent to browser
DEBUG - 2016-03-08 11:35:07 --> Total execution time: 1.1654
INFO - 2016-03-08 08:35:14 --> Config Class Initialized
INFO - 2016-03-08 08:35:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:35:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:35:14 --> Utf8 Class Initialized
INFO - 2016-03-08 08:35:14 --> URI Class Initialized
INFO - 2016-03-08 08:35:14 --> Router Class Initialized
INFO - 2016-03-08 08:35:14 --> Output Class Initialized
INFO - 2016-03-08 08:35:14 --> Security Class Initialized
DEBUG - 2016-03-08 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:35:14 --> Input Class Initialized
INFO - 2016-03-08 08:35:14 --> Language Class Initialized
INFO - 2016-03-08 08:35:14 --> Loader Class Initialized
INFO - 2016-03-08 08:35:14 --> Helper loaded: url_helper
INFO - 2016-03-08 08:35:14 --> Helper loaded: file_helper
INFO - 2016-03-08 08:35:14 --> Helper loaded: date_helper
INFO - 2016-03-08 08:35:14 --> Helper loaded: form_helper
INFO - 2016-03-08 08:35:14 --> Database Driver Class Initialized
INFO - 2016-03-08 08:35:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:35:15 --> Controller Class Initialized
INFO - 2016-03-08 08:35:15 --> Model Class Initialized
INFO - 2016-03-08 08:35:15 --> Model Class Initialized
INFO - 2016-03-08 08:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:35:15 --> Pagination Class Initialized
INFO - 2016-03-08 08:35:15 --> Helper loaded: text_helper
INFO - 2016-03-08 08:35:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:35:15 --> Final output sent to browser
DEBUG - 2016-03-08 11:35:15 --> Total execution time: 1.1437
INFO - 2016-03-08 08:35:18 --> Config Class Initialized
INFO - 2016-03-08 08:35:18 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:35:18 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:35:18 --> Utf8 Class Initialized
INFO - 2016-03-08 08:35:18 --> URI Class Initialized
INFO - 2016-03-08 08:35:18 --> Router Class Initialized
INFO - 2016-03-08 08:35:18 --> Output Class Initialized
INFO - 2016-03-08 08:35:18 --> Security Class Initialized
DEBUG - 2016-03-08 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:35:18 --> Input Class Initialized
INFO - 2016-03-08 08:35:18 --> Language Class Initialized
INFO - 2016-03-08 08:35:18 --> Loader Class Initialized
INFO - 2016-03-08 08:35:18 --> Helper loaded: url_helper
INFO - 2016-03-08 08:35:18 --> Helper loaded: file_helper
INFO - 2016-03-08 08:35:18 --> Helper loaded: date_helper
INFO - 2016-03-08 08:35:18 --> Helper loaded: form_helper
INFO - 2016-03-08 08:35:18 --> Database Driver Class Initialized
INFO - 2016-03-08 08:35:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:35:19 --> Controller Class Initialized
INFO - 2016-03-08 08:35:19 --> Model Class Initialized
INFO - 2016-03-08 08:35:19 --> Model Class Initialized
INFO - 2016-03-08 08:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:35:19 --> Pagination Class Initialized
INFO - 2016-03-08 08:35:19 --> Helper loaded: text_helper
INFO - 2016-03-08 08:35:19 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:35:19 --> Final output sent to browser
DEBUG - 2016-03-08 11:35:19 --> Total execution time: 1.2230
INFO - 2016-03-08 08:46:29 --> Config Class Initialized
INFO - 2016-03-08 08:46:29 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:46:29 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:46:29 --> Utf8 Class Initialized
INFO - 2016-03-08 08:46:29 --> URI Class Initialized
INFO - 2016-03-08 08:46:29 --> Router Class Initialized
INFO - 2016-03-08 08:46:29 --> Output Class Initialized
INFO - 2016-03-08 08:46:29 --> Security Class Initialized
DEBUG - 2016-03-08 08:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:46:29 --> Input Class Initialized
INFO - 2016-03-08 08:46:29 --> Language Class Initialized
INFO - 2016-03-08 08:46:29 --> Loader Class Initialized
INFO - 2016-03-08 08:46:29 --> Helper loaded: url_helper
INFO - 2016-03-08 08:46:29 --> Helper loaded: file_helper
INFO - 2016-03-08 08:46:29 --> Helper loaded: date_helper
INFO - 2016-03-08 08:46:29 --> Helper loaded: form_helper
INFO - 2016-03-08 08:46:29 --> Database Driver Class Initialized
INFO - 2016-03-08 08:46:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:46:30 --> Controller Class Initialized
INFO - 2016-03-08 08:46:30 --> Model Class Initialized
INFO - 2016-03-08 08:46:30 --> Model Class Initialized
INFO - 2016-03-08 08:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:46:30 --> Pagination Class Initialized
INFO - 2016-03-08 08:46:30 --> Helper loaded: text_helper
INFO - 2016-03-08 08:46:30 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:46:30 --> Final output sent to browser
DEBUG - 2016-03-08 11:46:30 --> Total execution time: 1.1483
INFO - 2016-03-08 08:46:32 --> Config Class Initialized
INFO - 2016-03-08 08:46:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:46:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:46:32 --> Utf8 Class Initialized
INFO - 2016-03-08 08:46:32 --> URI Class Initialized
INFO - 2016-03-08 08:46:32 --> Router Class Initialized
INFO - 2016-03-08 08:46:32 --> Output Class Initialized
INFO - 2016-03-08 08:46:32 --> Security Class Initialized
DEBUG - 2016-03-08 08:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:46:32 --> Input Class Initialized
INFO - 2016-03-08 08:46:32 --> Language Class Initialized
INFO - 2016-03-08 08:46:32 --> Loader Class Initialized
INFO - 2016-03-08 08:46:32 --> Helper loaded: url_helper
INFO - 2016-03-08 08:46:32 --> Helper loaded: file_helper
INFO - 2016-03-08 08:46:32 --> Helper loaded: date_helper
INFO - 2016-03-08 08:46:32 --> Helper loaded: form_helper
INFO - 2016-03-08 08:46:32 --> Database Driver Class Initialized
INFO - 2016-03-08 08:46:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:46:33 --> Controller Class Initialized
INFO - 2016-03-08 08:46:33 --> Model Class Initialized
INFO - 2016-03-08 08:46:33 --> Model Class Initialized
INFO - 2016-03-08 08:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:46:33 --> Pagination Class Initialized
INFO - 2016-03-08 08:46:33 --> Helper loaded: text_helper
INFO - 2016-03-08 08:46:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:46:33 --> Final output sent to browser
DEBUG - 2016-03-08 11:46:33 --> Total execution time: 1.1556
INFO - 2016-03-08 08:47:01 --> Config Class Initialized
INFO - 2016-03-08 08:47:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:47:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:47:01 --> Utf8 Class Initialized
INFO - 2016-03-08 08:47:01 --> URI Class Initialized
INFO - 2016-03-08 08:47:01 --> Router Class Initialized
INFO - 2016-03-08 08:47:01 --> Output Class Initialized
INFO - 2016-03-08 08:47:01 --> Security Class Initialized
DEBUG - 2016-03-08 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:47:01 --> Input Class Initialized
INFO - 2016-03-08 08:47:01 --> Language Class Initialized
INFO - 2016-03-08 08:47:01 --> Loader Class Initialized
INFO - 2016-03-08 08:47:01 --> Helper loaded: url_helper
INFO - 2016-03-08 08:47:01 --> Helper loaded: file_helper
INFO - 2016-03-08 08:47:01 --> Helper loaded: date_helper
INFO - 2016-03-08 08:47:01 --> Helper loaded: form_helper
INFO - 2016-03-08 08:47:01 --> Database Driver Class Initialized
INFO - 2016-03-08 08:47:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:47:02 --> Controller Class Initialized
INFO - 2016-03-08 08:47:02 --> Model Class Initialized
INFO - 2016-03-08 08:47:02 --> Model Class Initialized
INFO - 2016-03-08 08:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:47:02 --> Pagination Class Initialized
INFO - 2016-03-08 08:47:02 --> Helper loaded: text_helper
INFO - 2016-03-08 08:47:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:47:02 --> Final output sent to browser
DEBUG - 2016-03-08 11:47:02 --> Total execution time: 1.1577
INFO - 2016-03-08 08:47:04 --> Config Class Initialized
INFO - 2016-03-08 08:47:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:47:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:47:04 --> Utf8 Class Initialized
INFO - 2016-03-08 08:47:04 --> URI Class Initialized
INFO - 2016-03-08 08:47:04 --> Router Class Initialized
INFO - 2016-03-08 08:47:04 --> Output Class Initialized
INFO - 2016-03-08 08:47:04 --> Security Class Initialized
DEBUG - 2016-03-08 08:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:47:04 --> Input Class Initialized
INFO - 2016-03-08 08:47:04 --> Language Class Initialized
INFO - 2016-03-08 08:47:04 --> Loader Class Initialized
INFO - 2016-03-08 08:47:04 --> Helper loaded: url_helper
INFO - 2016-03-08 08:47:04 --> Helper loaded: file_helper
INFO - 2016-03-08 08:47:04 --> Helper loaded: date_helper
INFO - 2016-03-08 08:47:04 --> Helper loaded: form_helper
INFO - 2016-03-08 08:47:04 --> Database Driver Class Initialized
INFO - 2016-03-08 08:47:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:47:05 --> Controller Class Initialized
INFO - 2016-03-08 08:47:05 --> Model Class Initialized
INFO - 2016-03-08 08:47:05 --> Model Class Initialized
INFO - 2016-03-08 08:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:47:05 --> Pagination Class Initialized
INFO - 2016-03-08 08:47:05 --> Helper loaded: text_helper
INFO - 2016-03-08 08:47:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:47:05 --> Final output sent to browser
DEBUG - 2016-03-08 11:47:05 --> Total execution time: 1.1428
INFO - 2016-03-08 08:47:15 --> Config Class Initialized
INFO - 2016-03-08 08:47:15 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:47:15 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:47:15 --> Utf8 Class Initialized
INFO - 2016-03-08 08:47:15 --> URI Class Initialized
INFO - 2016-03-08 08:47:15 --> Router Class Initialized
INFO - 2016-03-08 08:47:15 --> Output Class Initialized
INFO - 2016-03-08 08:47:15 --> Security Class Initialized
DEBUG - 2016-03-08 08:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:47:15 --> Input Class Initialized
INFO - 2016-03-08 08:47:15 --> Language Class Initialized
INFO - 2016-03-08 08:47:15 --> Loader Class Initialized
INFO - 2016-03-08 08:47:15 --> Helper loaded: url_helper
INFO - 2016-03-08 08:47:15 --> Helper loaded: file_helper
INFO - 2016-03-08 08:47:15 --> Helper loaded: date_helper
INFO - 2016-03-08 08:47:15 --> Helper loaded: form_helper
INFO - 2016-03-08 08:47:15 --> Database Driver Class Initialized
INFO - 2016-03-08 08:47:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:47:16 --> Controller Class Initialized
INFO - 2016-03-08 08:47:16 --> Model Class Initialized
INFO - 2016-03-08 08:47:16 --> Model Class Initialized
INFO - 2016-03-08 08:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:47:16 --> Pagination Class Initialized
INFO - 2016-03-08 08:47:16 --> Helper loaded: text_helper
INFO - 2016-03-08 08:47:16 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:47:16 --> Final output sent to browser
DEBUG - 2016-03-08 11:47:16 --> Total execution time: 1.1808
INFO - 2016-03-08 08:48:17 --> Config Class Initialized
INFO - 2016-03-08 08:48:17 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:48:17 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:48:17 --> Utf8 Class Initialized
INFO - 2016-03-08 08:48:17 --> URI Class Initialized
INFO - 2016-03-08 08:48:17 --> Router Class Initialized
INFO - 2016-03-08 08:48:17 --> Output Class Initialized
INFO - 2016-03-08 08:48:17 --> Security Class Initialized
DEBUG - 2016-03-08 08:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:48:17 --> Input Class Initialized
INFO - 2016-03-08 08:48:17 --> Language Class Initialized
INFO - 2016-03-08 08:48:17 --> Loader Class Initialized
INFO - 2016-03-08 08:48:17 --> Helper loaded: url_helper
INFO - 2016-03-08 08:48:17 --> Helper loaded: file_helper
INFO - 2016-03-08 08:48:17 --> Helper loaded: date_helper
INFO - 2016-03-08 08:48:17 --> Helper loaded: form_helper
INFO - 2016-03-08 08:48:17 --> Database Driver Class Initialized
INFO - 2016-03-08 08:48:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:48:18 --> Controller Class Initialized
INFO - 2016-03-08 08:48:18 --> Model Class Initialized
INFO - 2016-03-08 08:48:18 --> Model Class Initialized
INFO - 2016-03-08 08:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:48:18 --> Pagination Class Initialized
INFO - 2016-03-08 08:48:18 --> Helper loaded: text_helper
INFO - 2016-03-08 08:48:18 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:48:18 --> Final output sent to browser
DEBUG - 2016-03-08 11:48:18 --> Total execution time: 1.2189
INFO - 2016-03-08 08:48:23 --> Config Class Initialized
INFO - 2016-03-08 08:48:23 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:48:23 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:48:23 --> Utf8 Class Initialized
INFO - 2016-03-08 08:48:23 --> URI Class Initialized
INFO - 2016-03-08 08:48:23 --> Router Class Initialized
INFO - 2016-03-08 08:48:23 --> Output Class Initialized
INFO - 2016-03-08 08:48:23 --> Security Class Initialized
DEBUG - 2016-03-08 08:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:48:23 --> Input Class Initialized
INFO - 2016-03-08 08:48:23 --> Language Class Initialized
INFO - 2016-03-08 08:48:23 --> Loader Class Initialized
INFO - 2016-03-08 08:48:23 --> Helper loaded: url_helper
INFO - 2016-03-08 08:48:23 --> Helper loaded: file_helper
INFO - 2016-03-08 08:48:23 --> Helper loaded: date_helper
INFO - 2016-03-08 08:48:23 --> Helper loaded: form_helper
INFO - 2016-03-08 08:48:23 --> Database Driver Class Initialized
INFO - 2016-03-08 08:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:48:24 --> Controller Class Initialized
INFO - 2016-03-08 08:48:24 --> Model Class Initialized
INFO - 2016-03-08 08:48:24 --> Model Class Initialized
INFO - 2016-03-08 08:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:48:24 --> Pagination Class Initialized
INFO - 2016-03-08 08:48:24 --> Helper loaded: text_helper
INFO - 2016-03-08 08:48:24 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:48:24 --> Final output sent to browser
DEBUG - 2016-03-08 11:48:24 --> Total execution time: 1.1836
INFO - 2016-03-08 08:49:19 --> Config Class Initialized
INFO - 2016-03-08 08:49:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:49:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:49:19 --> Utf8 Class Initialized
INFO - 2016-03-08 08:49:19 --> URI Class Initialized
INFO - 2016-03-08 08:49:19 --> Router Class Initialized
INFO - 2016-03-08 08:49:19 --> Output Class Initialized
INFO - 2016-03-08 08:49:19 --> Security Class Initialized
DEBUG - 2016-03-08 08:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:49:19 --> Input Class Initialized
INFO - 2016-03-08 08:49:19 --> Language Class Initialized
INFO - 2016-03-08 08:49:19 --> Loader Class Initialized
INFO - 2016-03-08 08:49:19 --> Helper loaded: url_helper
INFO - 2016-03-08 08:49:19 --> Helper loaded: file_helper
INFO - 2016-03-08 08:49:19 --> Helper loaded: date_helper
INFO - 2016-03-08 08:49:19 --> Helper loaded: form_helper
INFO - 2016-03-08 08:49:19 --> Database Driver Class Initialized
INFO - 2016-03-08 08:49:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:49:20 --> Controller Class Initialized
INFO - 2016-03-08 08:49:20 --> Model Class Initialized
INFO - 2016-03-08 08:49:20 --> Model Class Initialized
INFO - 2016-03-08 08:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:49:20 --> Pagination Class Initialized
INFO - 2016-03-08 08:49:20 --> Helper loaded: text_helper
INFO - 2016-03-08 08:49:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:49:20 --> Final output sent to browser
DEBUG - 2016-03-08 11:49:20 --> Total execution time: 1.1229
INFO - 2016-03-08 08:49:22 --> Config Class Initialized
INFO - 2016-03-08 08:49:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:49:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:49:22 --> Utf8 Class Initialized
INFO - 2016-03-08 08:49:22 --> URI Class Initialized
INFO - 2016-03-08 08:49:22 --> Router Class Initialized
INFO - 2016-03-08 08:49:22 --> Output Class Initialized
INFO - 2016-03-08 08:49:22 --> Security Class Initialized
DEBUG - 2016-03-08 08:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:49:22 --> Input Class Initialized
INFO - 2016-03-08 08:49:22 --> Language Class Initialized
INFO - 2016-03-08 08:49:22 --> Loader Class Initialized
INFO - 2016-03-08 08:49:22 --> Helper loaded: url_helper
INFO - 2016-03-08 08:49:22 --> Helper loaded: file_helper
INFO - 2016-03-08 08:49:22 --> Helper loaded: date_helper
INFO - 2016-03-08 08:49:22 --> Helper loaded: form_helper
INFO - 2016-03-08 08:49:22 --> Database Driver Class Initialized
INFO - 2016-03-08 08:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:49:23 --> Controller Class Initialized
INFO - 2016-03-08 08:49:23 --> Model Class Initialized
INFO - 2016-03-08 08:49:23 --> Model Class Initialized
INFO - 2016-03-08 08:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:49:24 --> Pagination Class Initialized
INFO - 2016-03-08 08:49:24 --> Helper loaded: text_helper
INFO - 2016-03-08 08:49:24 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:49:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:49:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:49:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:49:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:49:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:49:24 --> Final output sent to browser
DEBUG - 2016-03-08 11:49:24 --> Total execution time: 1.1678
INFO - 2016-03-08 08:49:25 --> Config Class Initialized
INFO - 2016-03-08 08:49:25 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:49:25 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:49:25 --> Utf8 Class Initialized
INFO - 2016-03-08 08:49:25 --> URI Class Initialized
INFO - 2016-03-08 08:49:25 --> Router Class Initialized
INFO - 2016-03-08 08:49:25 --> Output Class Initialized
INFO - 2016-03-08 08:49:25 --> Security Class Initialized
DEBUG - 2016-03-08 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:49:25 --> Input Class Initialized
INFO - 2016-03-08 08:49:25 --> Language Class Initialized
INFO - 2016-03-08 08:49:25 --> Loader Class Initialized
INFO - 2016-03-08 08:49:25 --> Helper loaded: url_helper
INFO - 2016-03-08 08:49:25 --> Helper loaded: file_helper
INFO - 2016-03-08 08:49:25 --> Helper loaded: date_helper
INFO - 2016-03-08 08:49:25 --> Helper loaded: form_helper
INFO - 2016-03-08 08:49:25 --> Database Driver Class Initialized
INFO - 2016-03-08 08:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:49:26 --> Controller Class Initialized
INFO - 2016-03-08 08:49:26 --> Model Class Initialized
INFO - 2016-03-08 08:49:26 --> Model Class Initialized
INFO - 2016-03-08 08:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:49:26 --> Pagination Class Initialized
INFO - 2016-03-08 08:49:26 --> Helper loaded: text_helper
INFO - 2016-03-08 08:49:26 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:49:26 --> Final output sent to browser
DEBUG - 2016-03-08 11:49:26 --> Total execution time: 1.1032
INFO - 2016-03-08 08:49:28 --> Config Class Initialized
INFO - 2016-03-08 08:49:28 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:49:28 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:49:28 --> Utf8 Class Initialized
INFO - 2016-03-08 08:49:28 --> URI Class Initialized
INFO - 2016-03-08 08:49:28 --> Router Class Initialized
INFO - 2016-03-08 08:49:28 --> Output Class Initialized
INFO - 2016-03-08 08:49:28 --> Security Class Initialized
DEBUG - 2016-03-08 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:49:28 --> Input Class Initialized
INFO - 2016-03-08 08:49:28 --> Language Class Initialized
INFO - 2016-03-08 08:49:28 --> Loader Class Initialized
INFO - 2016-03-08 08:49:28 --> Helper loaded: url_helper
INFO - 2016-03-08 08:49:28 --> Helper loaded: file_helper
INFO - 2016-03-08 08:49:28 --> Helper loaded: date_helper
INFO - 2016-03-08 08:49:28 --> Helper loaded: form_helper
INFO - 2016-03-08 08:49:28 --> Database Driver Class Initialized
INFO - 2016-03-08 08:49:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:49:29 --> Controller Class Initialized
INFO - 2016-03-08 08:49:29 --> Model Class Initialized
INFO - 2016-03-08 08:49:29 --> Model Class Initialized
INFO - 2016-03-08 08:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:49:29 --> Pagination Class Initialized
INFO - 2016-03-08 08:49:29 --> Helper loaded: text_helper
INFO - 2016-03-08 08:49:29 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:49:29 --> Final output sent to browser
DEBUG - 2016-03-08 11:49:29 --> Total execution time: 1.0947
INFO - 2016-03-08 08:49:52 --> Config Class Initialized
INFO - 2016-03-08 08:49:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:49:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:49:52 --> Utf8 Class Initialized
INFO - 2016-03-08 08:49:52 --> URI Class Initialized
INFO - 2016-03-08 08:49:52 --> Router Class Initialized
INFO - 2016-03-08 08:49:52 --> Output Class Initialized
INFO - 2016-03-08 08:49:52 --> Security Class Initialized
DEBUG - 2016-03-08 08:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:49:52 --> Input Class Initialized
INFO - 2016-03-08 08:49:52 --> Language Class Initialized
ERROR - 2016-03-08 08:49:52 --> Severity: Parsing Error --> syntax error, unexpected 'list' (T_LIST), expecting identifier (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 26
INFO - 2016-03-08 08:51:45 --> Config Class Initialized
INFO - 2016-03-08 08:51:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:51:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:51:45 --> Utf8 Class Initialized
INFO - 2016-03-08 08:51:45 --> URI Class Initialized
INFO - 2016-03-08 08:51:45 --> Router Class Initialized
INFO - 2016-03-08 08:51:45 --> Output Class Initialized
INFO - 2016-03-08 08:51:45 --> Security Class Initialized
DEBUG - 2016-03-08 08:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:51:45 --> Input Class Initialized
INFO - 2016-03-08 08:51:45 --> Language Class Initialized
INFO - 2016-03-08 08:51:45 --> Loader Class Initialized
INFO - 2016-03-08 08:51:45 --> Helper loaded: url_helper
INFO - 2016-03-08 08:51:45 --> Helper loaded: file_helper
INFO - 2016-03-08 08:51:45 --> Helper loaded: date_helper
INFO - 2016-03-08 08:51:45 --> Helper loaded: form_helper
INFO - 2016-03-08 08:51:45 --> Database Driver Class Initialized
INFO - 2016-03-08 08:51:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:51:46 --> Controller Class Initialized
INFO - 2016-03-08 08:51:46 --> Model Class Initialized
INFO - 2016-03-08 08:51:47 --> Model Class Initialized
INFO - 2016-03-08 08:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:51:47 --> Pagination Class Initialized
INFO - 2016-03-08 08:51:47 --> Helper loaded: text_helper
INFO - 2016-03-08 08:51:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:51:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:51:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:51:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:51:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:51:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:51:47 --> Final output sent to browser
DEBUG - 2016-03-08 11:51:47 --> Total execution time: 1.1483
INFO - 2016-03-08 08:51:49 --> Config Class Initialized
INFO - 2016-03-08 08:51:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:51:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:51:49 --> Utf8 Class Initialized
INFO - 2016-03-08 08:51:49 --> URI Class Initialized
INFO - 2016-03-08 08:51:49 --> Router Class Initialized
INFO - 2016-03-08 08:51:49 --> Output Class Initialized
INFO - 2016-03-08 08:51:49 --> Security Class Initialized
DEBUG - 2016-03-08 08:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:51:49 --> Input Class Initialized
INFO - 2016-03-08 08:51:49 --> Language Class Initialized
INFO - 2016-03-08 08:51:49 --> Loader Class Initialized
INFO - 2016-03-08 08:51:49 --> Helper loaded: url_helper
INFO - 2016-03-08 08:51:49 --> Helper loaded: file_helper
INFO - 2016-03-08 08:51:49 --> Helper loaded: date_helper
INFO - 2016-03-08 08:51:49 --> Helper loaded: form_helper
INFO - 2016-03-08 08:51:49 --> Database Driver Class Initialized
INFO - 2016-03-08 08:51:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:51:50 --> Controller Class Initialized
INFO - 2016-03-08 08:51:50 --> Model Class Initialized
INFO - 2016-03-08 08:51:50 --> Model Class Initialized
INFO - 2016-03-08 08:51:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:51:50 --> Pagination Class Initialized
INFO - 2016-03-08 08:51:50 --> Helper loaded: text_helper
INFO - 2016-03-08 08:51:50 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:51:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:51:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:51:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:51:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:51:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:51:50 --> Final output sent to browser
DEBUG - 2016-03-08 11:51:50 --> Total execution time: 1.1797
INFO - 2016-03-08 08:51:52 --> Config Class Initialized
INFO - 2016-03-08 08:51:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:51:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:51:52 --> Utf8 Class Initialized
INFO - 2016-03-08 08:51:52 --> URI Class Initialized
INFO - 2016-03-08 08:51:52 --> Router Class Initialized
INFO - 2016-03-08 08:51:52 --> Output Class Initialized
INFO - 2016-03-08 08:51:52 --> Security Class Initialized
DEBUG - 2016-03-08 08:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:51:52 --> Input Class Initialized
INFO - 2016-03-08 08:51:52 --> Language Class Initialized
INFO - 2016-03-08 08:51:52 --> Loader Class Initialized
INFO - 2016-03-08 08:51:52 --> Helper loaded: url_helper
INFO - 2016-03-08 08:51:52 --> Helper loaded: file_helper
INFO - 2016-03-08 08:51:52 --> Helper loaded: date_helper
INFO - 2016-03-08 08:51:52 --> Helper loaded: form_helper
INFO - 2016-03-08 08:51:52 --> Database Driver Class Initialized
INFO - 2016-03-08 08:51:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:51:53 --> Controller Class Initialized
INFO - 2016-03-08 08:51:53 --> Model Class Initialized
INFO - 2016-03-08 08:51:53 --> Model Class Initialized
INFO - 2016-03-08 08:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:51:53 --> Pagination Class Initialized
INFO - 2016-03-08 08:51:53 --> Helper loaded: text_helper
INFO - 2016-03-08 08:51:53 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 11:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 11:51:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:51:53 --> Final output sent to browser
DEBUG - 2016-03-08 11:51:53 --> Total execution time: 1.1226
INFO - 2016-03-08 08:53:14 --> Config Class Initialized
INFO - 2016-03-08 08:53:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:53:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:53:14 --> Utf8 Class Initialized
INFO - 2016-03-08 08:53:14 --> URI Class Initialized
INFO - 2016-03-08 08:53:14 --> Router Class Initialized
INFO - 2016-03-08 08:53:14 --> Output Class Initialized
INFO - 2016-03-08 08:53:14 --> Security Class Initialized
DEBUG - 2016-03-08 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:53:14 --> Input Class Initialized
INFO - 2016-03-08 08:53:14 --> Language Class Initialized
INFO - 2016-03-08 08:53:14 --> Loader Class Initialized
INFO - 2016-03-08 08:53:14 --> Helper loaded: url_helper
INFO - 2016-03-08 08:53:14 --> Helper loaded: file_helper
INFO - 2016-03-08 08:53:14 --> Helper loaded: date_helper
INFO - 2016-03-08 08:53:14 --> Helper loaded: form_helper
INFO - 2016-03-08 08:53:14 --> Database Driver Class Initialized
INFO - 2016-03-08 08:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:53:15 --> Controller Class Initialized
INFO - 2016-03-08 08:53:15 --> Model Class Initialized
INFO - 2016-03-08 08:53:15 --> Model Class Initialized
INFO - 2016-03-08 08:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:53:15 --> Pagination Class Initialized
INFO - 2016-03-08 08:53:15 --> Helper loaded: text_helper
INFO - 2016-03-08 08:53:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 11:53:15 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:53:15 --> Final output sent to browser
DEBUG - 2016-03-08 11:53:15 --> Total execution time: 1.2468
INFO - 2016-03-08 08:53:35 --> Config Class Initialized
INFO - 2016-03-08 08:53:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:53:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:53:35 --> Utf8 Class Initialized
INFO - 2016-03-08 08:53:35 --> URI Class Initialized
INFO - 2016-03-08 08:53:35 --> Router Class Initialized
INFO - 2016-03-08 08:53:35 --> Output Class Initialized
INFO - 2016-03-08 08:53:35 --> Security Class Initialized
DEBUG - 2016-03-08 08:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:53:35 --> Input Class Initialized
INFO - 2016-03-08 08:53:35 --> Language Class Initialized
INFO - 2016-03-08 08:53:35 --> Loader Class Initialized
INFO - 2016-03-08 08:53:35 --> Helper loaded: url_helper
INFO - 2016-03-08 08:53:35 --> Helper loaded: file_helper
INFO - 2016-03-08 08:53:35 --> Helper loaded: date_helper
INFO - 2016-03-08 08:53:35 --> Helper loaded: form_helper
INFO - 2016-03-08 08:53:35 --> Database Driver Class Initialized
INFO - 2016-03-08 08:53:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:53:36 --> Controller Class Initialized
INFO - 2016-03-08 08:53:36 --> Model Class Initialized
INFO - 2016-03-08 08:53:36 --> Model Class Initialized
INFO - 2016-03-08 08:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:53:36 --> Pagination Class Initialized
INFO - 2016-03-08 08:53:36 --> Helper loaded: text_helper
INFO - 2016-03-08 08:53:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:53:36 --> Final output sent to browser
DEBUG - 2016-03-08 11:53:36 --> Total execution time: 1.2385
INFO - 2016-03-08 08:57:01 --> Config Class Initialized
INFO - 2016-03-08 08:57:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:57:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:57:01 --> Utf8 Class Initialized
INFO - 2016-03-08 08:57:01 --> URI Class Initialized
INFO - 2016-03-08 08:57:01 --> Router Class Initialized
INFO - 2016-03-08 08:57:01 --> Output Class Initialized
INFO - 2016-03-08 08:57:01 --> Security Class Initialized
DEBUG - 2016-03-08 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:57:01 --> Input Class Initialized
INFO - 2016-03-08 08:57:01 --> Language Class Initialized
INFO - 2016-03-08 08:57:01 --> Loader Class Initialized
INFO - 2016-03-08 08:57:01 --> Helper loaded: url_helper
INFO - 2016-03-08 08:57:01 --> Helper loaded: file_helper
INFO - 2016-03-08 08:57:01 --> Helper loaded: date_helper
INFO - 2016-03-08 08:57:01 --> Helper loaded: form_helper
INFO - 2016-03-08 08:57:01 --> Database Driver Class Initialized
INFO - 2016-03-08 08:57:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:57:02 --> Controller Class Initialized
INFO - 2016-03-08 08:57:02 --> Model Class Initialized
INFO - 2016-03-08 08:57:02 --> Model Class Initialized
INFO - 2016-03-08 08:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:57:02 --> Pagination Class Initialized
INFO - 2016-03-08 08:57:02 --> Helper loaded: text_helper
INFO - 2016-03-08 08:57:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 11:57:02 --> Severity: Notice --> Use of undefined constant wall - assumed 'wall' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 139
ERROR - 2016-03-08 11:57:02 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 139
ERROR - 2016-03-08 11:57:02 --> Severity: Notice --> Use of undefined constant index - assumed 'index' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 139
ERROR - 2016-03-08 11:57:02 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 139
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 11:57:02 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:57:02 --> Final output sent to browser
DEBUG - 2016-03-08 11:57:02 --> Total execution time: 1.2035
INFO - 2016-03-08 08:57:32 --> Config Class Initialized
INFO - 2016-03-08 08:57:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:57:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:57:32 --> Utf8 Class Initialized
INFO - 2016-03-08 08:57:32 --> URI Class Initialized
INFO - 2016-03-08 08:57:32 --> Router Class Initialized
INFO - 2016-03-08 08:57:32 --> Output Class Initialized
INFO - 2016-03-08 08:57:32 --> Security Class Initialized
DEBUG - 2016-03-08 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:57:32 --> Input Class Initialized
INFO - 2016-03-08 08:57:32 --> Language Class Initialized
INFO - 2016-03-08 08:57:32 --> Loader Class Initialized
INFO - 2016-03-08 08:57:32 --> Helper loaded: url_helper
INFO - 2016-03-08 08:57:32 --> Helper loaded: file_helper
INFO - 2016-03-08 08:57:32 --> Helper loaded: date_helper
INFO - 2016-03-08 08:57:32 --> Helper loaded: form_helper
INFO - 2016-03-08 08:57:32 --> Database Driver Class Initialized
INFO - 2016-03-08 08:57:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:57:33 --> Controller Class Initialized
INFO - 2016-03-08 08:57:33 --> Model Class Initialized
INFO - 2016-03-08 08:57:33 --> Model Class Initialized
INFO - 2016-03-08 08:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:57:33 --> Pagination Class Initialized
INFO - 2016-03-08 08:57:33 --> Helper loaded: text_helper
INFO - 2016-03-08 08:57:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 11:57:33 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:57:33 --> Final output sent to browser
DEBUG - 2016-03-08 11:57:33 --> Total execution time: 1.2434
INFO - 2016-03-08 08:58:19 --> Config Class Initialized
INFO - 2016-03-08 08:58:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:58:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:58:19 --> Utf8 Class Initialized
INFO - 2016-03-08 08:58:19 --> URI Class Initialized
INFO - 2016-03-08 08:58:19 --> Router Class Initialized
INFO - 2016-03-08 08:58:19 --> Output Class Initialized
INFO - 2016-03-08 08:58:19 --> Security Class Initialized
DEBUG - 2016-03-08 08:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:58:19 --> Input Class Initialized
INFO - 2016-03-08 08:58:19 --> Language Class Initialized
INFO - 2016-03-08 08:58:19 --> Loader Class Initialized
INFO - 2016-03-08 08:58:19 --> Helper loaded: url_helper
INFO - 2016-03-08 08:58:19 --> Helper loaded: file_helper
INFO - 2016-03-08 08:58:19 --> Helper loaded: date_helper
INFO - 2016-03-08 08:58:19 --> Helper loaded: form_helper
INFO - 2016-03-08 08:58:19 --> Database Driver Class Initialized
INFO - 2016-03-08 08:58:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:58:20 --> Controller Class Initialized
INFO - 2016-03-08 08:58:20 --> Model Class Initialized
INFO - 2016-03-08 08:58:20 --> Model Class Initialized
INFO - 2016-03-08 08:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:58:20 --> Pagination Class Initialized
INFO - 2016-03-08 08:58:20 --> Helper loaded: text_helper
INFO - 2016-03-08 08:58:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 11:58:20 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:58:20 --> Final output sent to browser
DEBUG - 2016-03-08 11:58:20 --> Total execution time: 1.2829
INFO - 2016-03-08 08:59:24 --> Config Class Initialized
INFO - 2016-03-08 08:59:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 08:59:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 08:59:24 --> Utf8 Class Initialized
INFO - 2016-03-08 08:59:24 --> URI Class Initialized
INFO - 2016-03-08 08:59:24 --> Router Class Initialized
INFO - 2016-03-08 08:59:24 --> Output Class Initialized
INFO - 2016-03-08 08:59:24 --> Security Class Initialized
DEBUG - 2016-03-08 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 08:59:24 --> Input Class Initialized
INFO - 2016-03-08 08:59:24 --> Language Class Initialized
INFO - 2016-03-08 08:59:24 --> Loader Class Initialized
INFO - 2016-03-08 08:59:24 --> Helper loaded: url_helper
INFO - 2016-03-08 08:59:24 --> Helper loaded: file_helper
INFO - 2016-03-08 08:59:24 --> Helper loaded: date_helper
INFO - 2016-03-08 08:59:24 --> Helper loaded: form_helper
INFO - 2016-03-08 08:59:24 --> Database Driver Class Initialized
INFO - 2016-03-08 08:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 08:59:25 --> Controller Class Initialized
INFO - 2016-03-08 08:59:25 --> Model Class Initialized
INFO - 2016-03-08 08:59:25 --> Model Class Initialized
INFO - 2016-03-08 08:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 08:59:25 --> Pagination Class Initialized
INFO - 2016-03-08 08:59:25 --> Helper loaded: text_helper
INFO - 2016-03-08 08:59:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 11:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 11:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 11:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 11:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 11:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 11:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 11:59:26 --> Final output sent to browser
DEBUG - 2016-03-08 11:59:26 --> Total execution time: 1.2023
INFO - 2016-03-08 09:01:07 --> Config Class Initialized
INFO - 2016-03-08 09:01:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:01:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:01:07 --> Utf8 Class Initialized
INFO - 2016-03-08 09:01:07 --> URI Class Initialized
INFO - 2016-03-08 09:01:07 --> Router Class Initialized
INFO - 2016-03-08 09:01:07 --> Output Class Initialized
INFO - 2016-03-08 09:01:07 --> Security Class Initialized
DEBUG - 2016-03-08 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:01:07 --> Input Class Initialized
INFO - 2016-03-08 09:01:07 --> Language Class Initialized
INFO - 2016-03-08 09:01:07 --> Loader Class Initialized
INFO - 2016-03-08 09:01:07 --> Helper loaded: url_helper
INFO - 2016-03-08 09:01:07 --> Helper loaded: file_helper
INFO - 2016-03-08 09:01:07 --> Helper loaded: date_helper
INFO - 2016-03-08 09:01:07 --> Helper loaded: form_helper
INFO - 2016-03-08 09:01:07 --> Database Driver Class Initialized
INFO - 2016-03-08 09:01:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:01:08 --> Controller Class Initialized
INFO - 2016-03-08 09:01:08 --> Model Class Initialized
INFO - 2016-03-08 09:01:08 --> Model Class Initialized
INFO - 2016-03-08 09:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:01:08 --> Pagination Class Initialized
INFO - 2016-03-08 09:01:08 --> Helper loaded: text_helper
INFO - 2016-03-08 09:01:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:01:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:01:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:01:09 --> Final output sent to browser
DEBUG - 2016-03-08 12:01:09 --> Total execution time: 1.2736
INFO - 2016-03-08 09:02:30 --> Config Class Initialized
INFO - 2016-03-08 09:02:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:02:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:02:31 --> Utf8 Class Initialized
INFO - 2016-03-08 09:02:31 --> URI Class Initialized
INFO - 2016-03-08 09:02:31 --> Router Class Initialized
INFO - 2016-03-08 09:02:31 --> Output Class Initialized
INFO - 2016-03-08 09:02:31 --> Security Class Initialized
DEBUG - 2016-03-08 09:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:02:31 --> Input Class Initialized
INFO - 2016-03-08 09:02:31 --> Language Class Initialized
INFO - 2016-03-08 09:02:31 --> Loader Class Initialized
INFO - 2016-03-08 09:02:31 --> Helper loaded: url_helper
INFO - 2016-03-08 09:02:31 --> Helper loaded: file_helper
INFO - 2016-03-08 09:02:31 --> Helper loaded: date_helper
INFO - 2016-03-08 09:02:31 --> Helper loaded: form_helper
INFO - 2016-03-08 09:02:31 --> Database Driver Class Initialized
INFO - 2016-03-08 09:02:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:02:32 --> Controller Class Initialized
INFO - 2016-03-08 09:02:32 --> Model Class Initialized
INFO - 2016-03-08 09:02:32 --> Model Class Initialized
INFO - 2016-03-08 09:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:02:32 --> Pagination Class Initialized
INFO - 2016-03-08 09:02:32 --> Helper loaded: text_helper
INFO - 2016-03-08 09:02:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:02:32 --> Final output sent to browser
DEBUG - 2016-03-08 12:02:32 --> Total execution time: 1.1816
INFO - 2016-03-08 09:04:01 --> Config Class Initialized
INFO - 2016-03-08 09:04:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:04:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:04:01 --> Utf8 Class Initialized
INFO - 2016-03-08 09:04:01 --> URI Class Initialized
INFO - 2016-03-08 09:04:01 --> Router Class Initialized
INFO - 2016-03-08 09:04:01 --> Output Class Initialized
INFO - 2016-03-08 09:04:01 --> Security Class Initialized
DEBUG - 2016-03-08 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:04:01 --> Input Class Initialized
INFO - 2016-03-08 09:04:01 --> Language Class Initialized
INFO - 2016-03-08 09:04:01 --> Loader Class Initialized
INFO - 2016-03-08 09:04:01 --> Helper loaded: url_helper
INFO - 2016-03-08 09:04:01 --> Helper loaded: file_helper
INFO - 2016-03-08 09:04:01 --> Helper loaded: date_helper
INFO - 2016-03-08 09:04:01 --> Helper loaded: form_helper
INFO - 2016-03-08 09:04:01 --> Database Driver Class Initialized
INFO - 2016-03-08 09:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:04:02 --> Controller Class Initialized
INFO - 2016-03-08 09:04:02 --> Model Class Initialized
INFO - 2016-03-08 09:04:02 --> Model Class Initialized
INFO - 2016-03-08 09:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:04:02 --> Pagination Class Initialized
INFO - 2016-03-08 09:04:02 --> Helper loaded: text_helper
INFO - 2016-03-08 09:04:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:04:03 --> Final output sent to browser
DEBUG - 2016-03-08 12:04:03 --> Total execution time: 1.1676
INFO - 2016-03-08 09:05:36 --> Config Class Initialized
INFO - 2016-03-08 09:05:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:05:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:05:36 --> Utf8 Class Initialized
INFO - 2016-03-08 09:05:36 --> URI Class Initialized
INFO - 2016-03-08 09:05:36 --> Router Class Initialized
INFO - 2016-03-08 09:05:36 --> Output Class Initialized
INFO - 2016-03-08 09:05:36 --> Security Class Initialized
DEBUG - 2016-03-08 09:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:05:36 --> Input Class Initialized
INFO - 2016-03-08 09:05:36 --> Language Class Initialized
INFO - 2016-03-08 09:05:36 --> Loader Class Initialized
INFO - 2016-03-08 09:05:36 --> Helper loaded: url_helper
INFO - 2016-03-08 09:05:36 --> Helper loaded: file_helper
INFO - 2016-03-08 09:05:36 --> Helper loaded: date_helper
INFO - 2016-03-08 09:05:36 --> Helper loaded: form_helper
INFO - 2016-03-08 09:05:36 --> Database Driver Class Initialized
INFO - 2016-03-08 09:05:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:05:37 --> Controller Class Initialized
INFO - 2016-03-08 09:05:37 --> Model Class Initialized
INFO - 2016-03-08 09:05:37 --> Model Class Initialized
INFO - 2016-03-08 09:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:05:37 --> Pagination Class Initialized
INFO - 2016-03-08 09:05:37 --> Helper loaded: text_helper
INFO - 2016-03-08 09:05:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:05:37 --> Final output sent to browser
DEBUG - 2016-03-08 12:05:37 --> Total execution time: 1.2435
INFO - 2016-03-08 09:05:48 --> Config Class Initialized
INFO - 2016-03-08 09:05:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:05:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:05:48 --> Utf8 Class Initialized
INFO - 2016-03-08 09:05:48 --> URI Class Initialized
INFO - 2016-03-08 09:05:48 --> Router Class Initialized
INFO - 2016-03-08 09:05:48 --> Output Class Initialized
INFO - 2016-03-08 09:05:48 --> Security Class Initialized
DEBUG - 2016-03-08 09:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:05:48 --> Input Class Initialized
INFO - 2016-03-08 09:05:48 --> Language Class Initialized
INFO - 2016-03-08 09:05:48 --> Loader Class Initialized
INFO - 2016-03-08 09:05:48 --> Helper loaded: url_helper
INFO - 2016-03-08 09:05:48 --> Helper loaded: file_helper
INFO - 2016-03-08 09:05:48 --> Helper loaded: date_helper
INFO - 2016-03-08 09:05:48 --> Helper loaded: form_helper
INFO - 2016-03-08 09:05:48 --> Database Driver Class Initialized
INFO - 2016-03-08 09:05:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:05:49 --> Controller Class Initialized
INFO - 2016-03-08 09:05:49 --> Model Class Initialized
INFO - 2016-03-08 09:05:49 --> Model Class Initialized
INFO - 2016-03-08 09:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:05:49 --> Pagination Class Initialized
INFO - 2016-03-08 09:05:49 --> Helper loaded: text_helper
INFO - 2016-03-08 09:05:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:05:49 --> Final output sent to browser
DEBUG - 2016-03-08 12:05:49 --> Total execution time: 1.1428
INFO - 2016-03-08 09:05:51 --> Config Class Initialized
INFO - 2016-03-08 09:05:51 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:05:51 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:05:51 --> Utf8 Class Initialized
INFO - 2016-03-08 09:05:51 --> URI Class Initialized
INFO - 2016-03-08 09:05:51 --> Router Class Initialized
INFO - 2016-03-08 09:05:51 --> Output Class Initialized
INFO - 2016-03-08 09:05:51 --> Security Class Initialized
DEBUG - 2016-03-08 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:05:51 --> Input Class Initialized
INFO - 2016-03-08 09:05:51 --> Language Class Initialized
INFO - 2016-03-08 09:05:51 --> Loader Class Initialized
INFO - 2016-03-08 09:05:51 --> Helper loaded: url_helper
INFO - 2016-03-08 09:05:51 --> Helper loaded: file_helper
INFO - 2016-03-08 09:05:51 --> Helper loaded: date_helper
INFO - 2016-03-08 09:05:51 --> Helper loaded: form_helper
INFO - 2016-03-08 09:05:51 --> Database Driver Class Initialized
INFO - 2016-03-08 09:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:05:52 --> Controller Class Initialized
INFO - 2016-03-08 09:05:52 --> Model Class Initialized
INFO - 2016-03-08 09:05:52 --> Model Class Initialized
INFO - 2016-03-08 09:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:05:52 --> Pagination Class Initialized
INFO - 2016-03-08 09:05:52 --> Helper loaded: text_helper
INFO - 2016-03-08 09:05:52 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:05:52 --> Final output sent to browser
DEBUG - 2016-03-08 12:05:52 --> Total execution time: 1.1657
INFO - 2016-03-08 09:05:55 --> Config Class Initialized
INFO - 2016-03-08 09:05:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:05:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:05:55 --> Utf8 Class Initialized
INFO - 2016-03-08 09:05:55 --> URI Class Initialized
INFO - 2016-03-08 09:05:55 --> Router Class Initialized
INFO - 2016-03-08 09:05:55 --> Output Class Initialized
INFO - 2016-03-08 09:05:55 --> Security Class Initialized
DEBUG - 2016-03-08 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:05:55 --> Input Class Initialized
INFO - 2016-03-08 09:05:55 --> Language Class Initialized
INFO - 2016-03-08 09:05:55 --> Loader Class Initialized
INFO - 2016-03-08 09:05:55 --> Helper loaded: url_helper
INFO - 2016-03-08 09:05:55 --> Helper loaded: file_helper
INFO - 2016-03-08 09:05:55 --> Helper loaded: date_helper
INFO - 2016-03-08 09:05:55 --> Helper loaded: form_helper
INFO - 2016-03-08 09:05:55 --> Database Driver Class Initialized
INFO - 2016-03-08 09:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:05:56 --> Controller Class Initialized
INFO - 2016-03-08 09:05:56 --> Model Class Initialized
INFO - 2016-03-08 09:05:56 --> Model Class Initialized
INFO - 2016-03-08 09:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:05:56 --> Pagination Class Initialized
INFO - 2016-03-08 09:05:56 --> Helper loaded: text_helper
INFO - 2016-03-08 09:05:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:05:56 --> Final output sent to browser
DEBUG - 2016-03-08 12:05:56 --> Total execution time: 1.2240
INFO - 2016-03-08 09:06:15 --> Config Class Initialized
INFO - 2016-03-08 09:06:15 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:06:15 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:06:15 --> Utf8 Class Initialized
INFO - 2016-03-08 09:06:15 --> URI Class Initialized
INFO - 2016-03-08 09:06:15 --> Router Class Initialized
INFO - 2016-03-08 09:06:15 --> Output Class Initialized
INFO - 2016-03-08 09:06:15 --> Security Class Initialized
DEBUG - 2016-03-08 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:06:15 --> Input Class Initialized
INFO - 2016-03-08 09:06:15 --> Language Class Initialized
INFO - 2016-03-08 09:06:15 --> Loader Class Initialized
INFO - 2016-03-08 09:06:15 --> Helper loaded: url_helper
INFO - 2016-03-08 09:06:15 --> Helper loaded: file_helper
INFO - 2016-03-08 09:06:15 --> Helper loaded: date_helper
INFO - 2016-03-08 09:06:15 --> Helper loaded: form_helper
INFO - 2016-03-08 09:06:15 --> Database Driver Class Initialized
INFO - 2016-03-08 09:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:06:16 --> Controller Class Initialized
INFO - 2016-03-08 09:06:16 --> Model Class Initialized
INFO - 2016-03-08 09:06:16 --> Model Class Initialized
INFO - 2016-03-08 09:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:06:16 --> Pagination Class Initialized
INFO - 2016-03-08 09:06:16 --> Helper loaded: text_helper
INFO - 2016-03-08 09:06:16 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:06:16 --> Final output sent to browser
DEBUG - 2016-03-08 12:06:16 --> Total execution time: 1.2997
INFO - 2016-03-08 09:06:41 --> Config Class Initialized
INFO - 2016-03-08 09:06:41 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:06:41 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:06:41 --> Utf8 Class Initialized
INFO - 2016-03-08 09:06:41 --> URI Class Initialized
INFO - 2016-03-08 09:06:41 --> Router Class Initialized
INFO - 2016-03-08 09:06:41 --> Output Class Initialized
INFO - 2016-03-08 09:06:41 --> Security Class Initialized
DEBUG - 2016-03-08 09:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:06:41 --> Input Class Initialized
INFO - 2016-03-08 09:06:41 --> Language Class Initialized
INFO - 2016-03-08 09:06:41 --> Loader Class Initialized
INFO - 2016-03-08 09:06:41 --> Helper loaded: url_helper
INFO - 2016-03-08 09:06:41 --> Helper loaded: file_helper
INFO - 2016-03-08 09:06:41 --> Helper loaded: date_helper
INFO - 2016-03-08 09:06:41 --> Helper loaded: form_helper
INFO - 2016-03-08 09:06:41 --> Database Driver Class Initialized
INFO - 2016-03-08 09:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:06:42 --> Controller Class Initialized
INFO - 2016-03-08 09:06:42 --> Model Class Initialized
INFO - 2016-03-08 09:06:42 --> Model Class Initialized
INFO - 2016-03-08 09:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:06:42 --> Pagination Class Initialized
INFO - 2016-03-08 09:06:42 --> Helper loaded: text_helper
INFO - 2016-03-08 09:06:42 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:06:43 --> Final output sent to browser
DEBUG - 2016-03-08 12:06:43 --> Total execution time: 1.2318
INFO - 2016-03-08 09:07:01 --> Config Class Initialized
INFO - 2016-03-08 09:07:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:07:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:07:01 --> Utf8 Class Initialized
INFO - 2016-03-08 09:07:01 --> URI Class Initialized
INFO - 2016-03-08 09:07:01 --> Router Class Initialized
INFO - 2016-03-08 09:07:01 --> Output Class Initialized
INFO - 2016-03-08 09:07:01 --> Security Class Initialized
DEBUG - 2016-03-08 09:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:07:01 --> Input Class Initialized
INFO - 2016-03-08 09:07:01 --> Language Class Initialized
INFO - 2016-03-08 09:07:01 --> Loader Class Initialized
INFO - 2016-03-08 09:07:01 --> Helper loaded: url_helper
INFO - 2016-03-08 09:07:01 --> Helper loaded: file_helper
INFO - 2016-03-08 09:07:01 --> Helper loaded: date_helper
INFO - 2016-03-08 09:07:01 --> Helper loaded: form_helper
INFO - 2016-03-08 09:07:01 --> Database Driver Class Initialized
INFO - 2016-03-08 09:07:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:07:02 --> Controller Class Initialized
INFO - 2016-03-08 09:07:02 --> Model Class Initialized
INFO - 2016-03-08 09:07:02 --> Model Class Initialized
INFO - 2016-03-08 09:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:07:02 --> Pagination Class Initialized
INFO - 2016-03-08 09:07:02 --> Helper loaded: text_helper
INFO - 2016-03-08 09:07:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:07:02 --> Final output sent to browser
DEBUG - 2016-03-08 12:07:02 --> Total execution time: 1.1714
INFO - 2016-03-08 09:24:55 --> Config Class Initialized
INFO - 2016-03-08 09:24:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:24:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:24:55 --> Utf8 Class Initialized
INFO - 2016-03-08 09:24:55 --> URI Class Initialized
INFO - 2016-03-08 09:24:55 --> Router Class Initialized
INFO - 2016-03-08 09:24:55 --> Output Class Initialized
INFO - 2016-03-08 09:24:55 --> Security Class Initialized
DEBUG - 2016-03-08 09:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:24:55 --> Input Class Initialized
INFO - 2016-03-08 09:24:55 --> Language Class Initialized
INFO - 2016-03-08 09:24:55 --> Loader Class Initialized
INFO - 2016-03-08 09:24:55 --> Helper loaded: url_helper
INFO - 2016-03-08 09:24:55 --> Helper loaded: file_helper
INFO - 2016-03-08 09:24:55 --> Helper loaded: date_helper
INFO - 2016-03-08 09:24:55 --> Helper loaded: form_helper
INFO - 2016-03-08 09:24:55 --> Database Driver Class Initialized
INFO - 2016-03-08 09:24:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:24:56 --> Controller Class Initialized
INFO - 2016-03-08 09:24:56 --> Model Class Initialized
INFO - 2016-03-08 09:24:56 --> Model Class Initialized
INFO - 2016-03-08 09:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:24:56 --> Pagination Class Initialized
INFO - 2016-03-08 09:24:56 --> Helper loaded: text_helper
INFO - 2016-03-08 09:24:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:24:56 --> Final output sent to browser
DEBUG - 2016-03-08 12:24:56 --> Total execution time: 1.2008
INFO - 2016-03-08 09:25:30 --> Config Class Initialized
INFO - 2016-03-08 09:25:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:25:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:25:30 --> Utf8 Class Initialized
INFO - 2016-03-08 09:25:30 --> URI Class Initialized
INFO - 2016-03-08 09:25:30 --> Router Class Initialized
INFO - 2016-03-08 09:25:30 --> Output Class Initialized
INFO - 2016-03-08 09:25:30 --> Security Class Initialized
DEBUG - 2016-03-08 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:25:30 --> Input Class Initialized
INFO - 2016-03-08 09:25:30 --> Language Class Initialized
INFO - 2016-03-08 09:25:30 --> Loader Class Initialized
INFO - 2016-03-08 09:25:30 --> Helper loaded: url_helper
INFO - 2016-03-08 09:25:30 --> Helper loaded: file_helper
INFO - 2016-03-08 09:25:30 --> Helper loaded: date_helper
INFO - 2016-03-08 09:25:31 --> Helper loaded: form_helper
INFO - 2016-03-08 09:25:31 --> Database Driver Class Initialized
INFO - 2016-03-08 09:25:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:25:32 --> Controller Class Initialized
INFO - 2016-03-08 09:25:32 --> Model Class Initialized
INFO - 2016-03-08 09:25:32 --> Model Class Initialized
INFO - 2016-03-08 09:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:25:32 --> Pagination Class Initialized
INFO - 2016-03-08 09:25:32 --> Helper loaded: text_helper
INFO - 2016-03-08 09:25:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:25:32 --> Final output sent to browser
DEBUG - 2016-03-08 12:25:32 --> Total execution time: 1.1140
INFO - 2016-03-08 09:26:06 --> Config Class Initialized
INFO - 2016-03-08 09:26:06 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:26:06 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:26:06 --> Utf8 Class Initialized
INFO - 2016-03-08 09:26:06 --> URI Class Initialized
INFO - 2016-03-08 09:26:06 --> Router Class Initialized
INFO - 2016-03-08 09:26:06 --> Output Class Initialized
INFO - 2016-03-08 09:26:06 --> Security Class Initialized
DEBUG - 2016-03-08 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:26:06 --> Input Class Initialized
INFO - 2016-03-08 09:26:06 --> Language Class Initialized
INFO - 2016-03-08 09:26:06 --> Loader Class Initialized
INFO - 2016-03-08 09:26:06 --> Helper loaded: url_helper
INFO - 2016-03-08 09:26:06 --> Helper loaded: file_helper
INFO - 2016-03-08 09:26:06 --> Helper loaded: date_helper
INFO - 2016-03-08 09:26:06 --> Helper loaded: form_helper
INFO - 2016-03-08 09:26:06 --> Database Driver Class Initialized
INFO - 2016-03-08 09:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:26:07 --> Controller Class Initialized
INFO - 2016-03-08 09:26:07 --> Model Class Initialized
INFO - 2016-03-08 09:26:07 --> Model Class Initialized
INFO - 2016-03-08 09:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:26:07 --> Pagination Class Initialized
INFO - 2016-03-08 09:26:07 --> Helper loaded: text_helper
INFO - 2016-03-08 09:26:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:26:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:26:07 --> Final output sent to browser
DEBUG - 2016-03-08 12:26:07 --> Total execution time: 1.2988
INFO - 2016-03-08 09:27:44 --> Config Class Initialized
INFO - 2016-03-08 09:27:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:27:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:27:44 --> Utf8 Class Initialized
INFO - 2016-03-08 09:27:44 --> URI Class Initialized
INFO - 2016-03-08 09:27:44 --> Router Class Initialized
INFO - 2016-03-08 09:27:44 --> Output Class Initialized
INFO - 2016-03-08 09:27:44 --> Security Class Initialized
DEBUG - 2016-03-08 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:27:44 --> Input Class Initialized
INFO - 2016-03-08 09:27:44 --> Language Class Initialized
INFO - 2016-03-08 09:27:44 --> Loader Class Initialized
INFO - 2016-03-08 09:27:44 --> Helper loaded: url_helper
INFO - 2016-03-08 09:27:44 --> Helper loaded: file_helper
INFO - 2016-03-08 09:27:44 --> Helper loaded: date_helper
INFO - 2016-03-08 09:27:44 --> Helper loaded: form_helper
INFO - 2016-03-08 09:27:44 --> Database Driver Class Initialized
INFO - 2016-03-08 09:27:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:27:45 --> Controller Class Initialized
INFO - 2016-03-08 09:27:45 --> Model Class Initialized
INFO - 2016-03-08 09:27:45 --> Model Class Initialized
INFO - 2016-03-08 09:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:27:45 --> Pagination Class Initialized
INFO - 2016-03-08 09:27:45 --> Helper loaded: text_helper
INFO - 2016-03-08 09:27:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:27:45 --> Final output sent to browser
DEBUG - 2016-03-08 12:27:45 --> Total execution time: 1.1513
INFO - 2016-03-08 09:27:47 --> Config Class Initialized
INFO - 2016-03-08 09:27:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:27:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:27:47 --> Utf8 Class Initialized
INFO - 2016-03-08 09:27:47 --> URI Class Initialized
INFO - 2016-03-08 09:27:47 --> Router Class Initialized
INFO - 2016-03-08 09:27:47 --> Output Class Initialized
INFO - 2016-03-08 09:27:47 --> Security Class Initialized
DEBUG - 2016-03-08 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:27:47 --> Input Class Initialized
INFO - 2016-03-08 09:27:47 --> Language Class Initialized
INFO - 2016-03-08 09:27:48 --> Loader Class Initialized
INFO - 2016-03-08 09:27:48 --> Helper loaded: url_helper
INFO - 2016-03-08 09:27:48 --> Helper loaded: file_helper
INFO - 2016-03-08 09:27:48 --> Helper loaded: date_helper
INFO - 2016-03-08 09:27:48 --> Helper loaded: form_helper
INFO - 2016-03-08 09:27:48 --> Database Driver Class Initialized
INFO - 2016-03-08 09:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:27:49 --> Controller Class Initialized
INFO - 2016-03-08 09:27:49 --> Model Class Initialized
INFO - 2016-03-08 09:27:49 --> Model Class Initialized
INFO - 2016-03-08 09:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:27:49 --> Pagination Class Initialized
INFO - 2016-03-08 09:27:49 --> Helper loaded: text_helper
INFO - 2016-03-08 09:27:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:27:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:27:49 --> Final output sent to browser
DEBUG - 2016-03-08 12:27:49 --> Total execution time: 1.1982
INFO - 2016-03-08 09:28:05 --> Config Class Initialized
INFO - 2016-03-08 09:28:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:28:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:28:05 --> Utf8 Class Initialized
INFO - 2016-03-08 09:28:05 --> URI Class Initialized
INFO - 2016-03-08 09:28:05 --> Router Class Initialized
INFO - 2016-03-08 09:28:05 --> Output Class Initialized
INFO - 2016-03-08 09:28:05 --> Security Class Initialized
DEBUG - 2016-03-08 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:28:05 --> Input Class Initialized
INFO - 2016-03-08 09:28:05 --> Language Class Initialized
INFO - 2016-03-08 09:28:05 --> Loader Class Initialized
INFO - 2016-03-08 09:28:05 --> Helper loaded: url_helper
INFO - 2016-03-08 09:28:05 --> Helper loaded: file_helper
INFO - 2016-03-08 09:28:05 --> Helper loaded: date_helper
INFO - 2016-03-08 09:28:05 --> Helper loaded: form_helper
INFO - 2016-03-08 09:28:05 --> Database Driver Class Initialized
INFO - 2016-03-08 09:28:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:28:06 --> Controller Class Initialized
INFO - 2016-03-08 09:28:06 --> Model Class Initialized
INFO - 2016-03-08 09:28:06 --> Model Class Initialized
INFO - 2016-03-08 09:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:28:06 --> Pagination Class Initialized
INFO - 2016-03-08 09:28:06 --> Helper loaded: text_helper
INFO - 2016-03-08 09:28:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:28:06 --> Final output sent to browser
DEBUG - 2016-03-08 12:28:06 --> Total execution time: 1.1650
INFO - 2016-03-08 09:31:04 --> Config Class Initialized
INFO - 2016-03-08 09:31:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:31:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:31:04 --> Utf8 Class Initialized
INFO - 2016-03-08 09:31:04 --> URI Class Initialized
INFO - 2016-03-08 09:31:04 --> Router Class Initialized
INFO - 2016-03-08 09:31:04 --> Output Class Initialized
INFO - 2016-03-08 09:31:04 --> Security Class Initialized
DEBUG - 2016-03-08 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:31:04 --> Input Class Initialized
INFO - 2016-03-08 09:31:04 --> Language Class Initialized
INFO - 2016-03-08 09:31:04 --> Loader Class Initialized
INFO - 2016-03-08 09:31:04 --> Helper loaded: url_helper
INFO - 2016-03-08 09:31:04 --> Helper loaded: file_helper
INFO - 2016-03-08 09:31:04 --> Helper loaded: date_helper
INFO - 2016-03-08 09:31:04 --> Helper loaded: form_helper
INFO - 2016-03-08 09:31:04 --> Database Driver Class Initialized
INFO - 2016-03-08 09:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:31:05 --> Controller Class Initialized
INFO - 2016-03-08 09:31:05 --> Model Class Initialized
INFO - 2016-03-08 09:31:05 --> Model Class Initialized
INFO - 2016-03-08 09:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:31:05 --> Pagination Class Initialized
INFO - 2016-03-08 09:31:05 --> Helper loaded: text_helper
INFO - 2016-03-08 09:31:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:31:05 --> Final output sent to browser
DEBUG - 2016-03-08 12:31:05 --> Total execution time: 1.2650
INFO - 2016-03-08 09:31:33 --> Config Class Initialized
INFO - 2016-03-08 09:31:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:31:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:31:33 --> Utf8 Class Initialized
INFO - 2016-03-08 09:31:33 --> URI Class Initialized
INFO - 2016-03-08 09:31:33 --> Router Class Initialized
INFO - 2016-03-08 09:31:33 --> Output Class Initialized
INFO - 2016-03-08 09:31:33 --> Security Class Initialized
DEBUG - 2016-03-08 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:31:33 --> Input Class Initialized
INFO - 2016-03-08 09:31:33 --> Language Class Initialized
INFO - 2016-03-08 09:31:33 --> Loader Class Initialized
INFO - 2016-03-08 09:31:33 --> Helper loaded: url_helper
INFO - 2016-03-08 09:31:33 --> Helper loaded: file_helper
INFO - 2016-03-08 09:31:33 --> Helper loaded: date_helper
INFO - 2016-03-08 09:31:33 --> Helper loaded: form_helper
INFO - 2016-03-08 09:31:33 --> Database Driver Class Initialized
INFO - 2016-03-08 09:31:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:31:34 --> Controller Class Initialized
INFO - 2016-03-08 09:31:34 --> Model Class Initialized
INFO - 2016-03-08 09:31:34 --> Model Class Initialized
INFO - 2016-03-08 09:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:31:34 --> Pagination Class Initialized
INFO - 2016-03-08 09:31:34 --> Helper loaded: text_helper
INFO - 2016-03-08 09:31:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:31:34 --> Final output sent to browser
DEBUG - 2016-03-08 12:31:34 --> Total execution time: 1.1619
INFO - 2016-03-08 09:31:49 --> Config Class Initialized
INFO - 2016-03-08 09:31:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:31:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:31:49 --> Utf8 Class Initialized
INFO - 2016-03-08 09:31:49 --> URI Class Initialized
INFO - 2016-03-08 09:31:49 --> Router Class Initialized
INFO - 2016-03-08 09:31:49 --> Output Class Initialized
INFO - 2016-03-08 09:31:49 --> Security Class Initialized
DEBUG - 2016-03-08 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:31:49 --> Input Class Initialized
INFO - 2016-03-08 09:31:49 --> Language Class Initialized
INFO - 2016-03-08 09:31:49 --> Loader Class Initialized
INFO - 2016-03-08 09:31:49 --> Helper loaded: url_helper
INFO - 2016-03-08 09:31:49 --> Helper loaded: file_helper
INFO - 2016-03-08 09:31:49 --> Helper loaded: date_helper
INFO - 2016-03-08 09:31:49 --> Helper loaded: form_helper
INFO - 2016-03-08 09:31:49 --> Database Driver Class Initialized
INFO - 2016-03-08 09:31:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:31:50 --> Controller Class Initialized
INFO - 2016-03-08 09:31:50 --> Model Class Initialized
INFO - 2016-03-08 09:31:50 --> Model Class Initialized
INFO - 2016-03-08 09:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:31:50 --> Pagination Class Initialized
INFO - 2016-03-08 09:31:50 --> Helper loaded: text_helper
INFO - 2016-03-08 09:31:50 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:31:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:31:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:31:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:31:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:31:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:31:50 --> Final output sent to browser
DEBUG - 2016-03-08 12:31:50 --> Total execution time: 1.1037
INFO - 2016-03-08 09:31:53 --> Config Class Initialized
INFO - 2016-03-08 09:31:53 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:31:53 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:31:53 --> Utf8 Class Initialized
INFO - 2016-03-08 09:31:53 --> URI Class Initialized
INFO - 2016-03-08 09:31:53 --> Router Class Initialized
INFO - 2016-03-08 09:31:53 --> Output Class Initialized
INFO - 2016-03-08 09:31:53 --> Security Class Initialized
DEBUG - 2016-03-08 09:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:31:53 --> Input Class Initialized
INFO - 2016-03-08 09:31:53 --> Language Class Initialized
INFO - 2016-03-08 09:31:53 --> Loader Class Initialized
INFO - 2016-03-08 09:31:53 --> Helper loaded: url_helper
INFO - 2016-03-08 09:31:53 --> Helper loaded: file_helper
INFO - 2016-03-08 09:31:53 --> Helper loaded: date_helper
INFO - 2016-03-08 09:31:53 --> Helper loaded: form_helper
INFO - 2016-03-08 09:31:53 --> Database Driver Class Initialized
INFO - 2016-03-08 09:31:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:31:54 --> Controller Class Initialized
INFO - 2016-03-08 09:31:54 --> Model Class Initialized
INFO - 2016-03-08 09:31:54 --> Model Class Initialized
INFO - 2016-03-08 09:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:31:54 --> Pagination Class Initialized
INFO - 2016-03-08 09:31:54 --> Helper loaded: text_helper
INFO - 2016-03-08 09:31:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:31:54 --> Final output sent to browser
DEBUG - 2016-03-08 12:31:54 --> Total execution time: 1.2199
INFO - 2016-03-08 09:33:58 --> Config Class Initialized
INFO - 2016-03-08 09:33:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:33:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:33:58 --> Utf8 Class Initialized
INFO - 2016-03-08 09:33:58 --> URI Class Initialized
INFO - 2016-03-08 09:33:58 --> Router Class Initialized
INFO - 2016-03-08 09:33:58 --> Output Class Initialized
INFO - 2016-03-08 09:33:58 --> Security Class Initialized
DEBUG - 2016-03-08 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:33:58 --> Input Class Initialized
INFO - 2016-03-08 09:33:58 --> Language Class Initialized
INFO - 2016-03-08 09:33:58 --> Loader Class Initialized
INFO - 2016-03-08 09:33:58 --> Helper loaded: url_helper
INFO - 2016-03-08 09:33:58 --> Helper loaded: file_helper
INFO - 2016-03-08 09:33:58 --> Helper loaded: date_helper
INFO - 2016-03-08 09:33:58 --> Helper loaded: form_helper
INFO - 2016-03-08 09:33:58 --> Database Driver Class Initialized
INFO - 2016-03-08 09:33:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:33:59 --> Controller Class Initialized
INFO - 2016-03-08 09:33:59 --> Model Class Initialized
INFO - 2016-03-08 09:33:59 --> Model Class Initialized
INFO - 2016-03-08 09:33:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:33:59 --> Pagination Class Initialized
INFO - 2016-03-08 09:33:59 --> Helper loaded: text_helper
INFO - 2016-03-08 09:33:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:33:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:33:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:33:59 --> Final output sent to browser
DEBUG - 2016-03-08 12:33:59 --> Total execution time: 1.1989
INFO - 2016-03-08 09:34:09 --> Config Class Initialized
INFO - 2016-03-08 09:34:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:34:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:34:09 --> Utf8 Class Initialized
INFO - 2016-03-08 09:34:09 --> URI Class Initialized
INFO - 2016-03-08 09:34:10 --> Router Class Initialized
INFO - 2016-03-08 09:34:10 --> Output Class Initialized
INFO - 2016-03-08 09:34:10 --> Security Class Initialized
DEBUG - 2016-03-08 09:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:34:10 --> Input Class Initialized
INFO - 2016-03-08 09:34:10 --> Language Class Initialized
INFO - 2016-03-08 09:34:10 --> Loader Class Initialized
INFO - 2016-03-08 09:34:10 --> Helper loaded: url_helper
INFO - 2016-03-08 09:34:10 --> Helper loaded: file_helper
INFO - 2016-03-08 09:34:10 --> Helper loaded: date_helper
INFO - 2016-03-08 09:34:10 --> Helper loaded: form_helper
INFO - 2016-03-08 09:34:10 --> Database Driver Class Initialized
INFO - 2016-03-08 09:34:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:34:11 --> Controller Class Initialized
INFO - 2016-03-08 09:34:11 --> Model Class Initialized
INFO - 2016-03-08 09:34:11 --> Model Class Initialized
INFO - 2016-03-08 09:34:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:34:11 --> Pagination Class Initialized
INFO - 2016-03-08 09:34:11 --> Helper loaded: text_helper
INFO - 2016-03-08 09:34:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:34:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:34:11 --> Final output sent to browser
DEBUG - 2016-03-08 12:34:11 --> Total execution time: 1.1450
INFO - 2016-03-08 09:34:14 --> Config Class Initialized
INFO - 2016-03-08 09:34:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:34:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:34:14 --> Utf8 Class Initialized
INFO - 2016-03-08 09:34:14 --> URI Class Initialized
INFO - 2016-03-08 09:34:14 --> Router Class Initialized
INFO - 2016-03-08 09:34:14 --> Output Class Initialized
INFO - 2016-03-08 09:34:14 --> Security Class Initialized
DEBUG - 2016-03-08 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:34:14 --> Input Class Initialized
INFO - 2016-03-08 09:34:14 --> Language Class Initialized
INFO - 2016-03-08 09:34:14 --> Loader Class Initialized
INFO - 2016-03-08 09:34:14 --> Helper loaded: url_helper
INFO - 2016-03-08 09:34:14 --> Helper loaded: file_helper
INFO - 2016-03-08 09:34:14 --> Helper loaded: date_helper
INFO - 2016-03-08 09:34:14 --> Helper loaded: form_helper
INFO - 2016-03-08 09:34:14 --> Database Driver Class Initialized
INFO - 2016-03-08 09:34:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:34:15 --> Controller Class Initialized
INFO - 2016-03-08 09:34:15 --> Model Class Initialized
INFO - 2016-03-08 09:34:15 --> Model Class Initialized
INFO - 2016-03-08 09:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:34:15 --> Pagination Class Initialized
INFO - 2016-03-08 09:34:15 --> Helper loaded: text_helper
INFO - 2016-03-08 09:34:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 12:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 12:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:34:15 --> Final output sent to browser
DEBUG - 2016-03-08 12:34:15 --> Total execution time: 1.1690
INFO - 2016-03-08 09:34:35 --> Config Class Initialized
INFO - 2016-03-08 09:34:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:34:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:34:35 --> Utf8 Class Initialized
INFO - 2016-03-08 09:34:35 --> URI Class Initialized
INFO - 2016-03-08 09:34:35 --> Router Class Initialized
INFO - 2016-03-08 09:34:35 --> Output Class Initialized
INFO - 2016-03-08 09:34:35 --> Security Class Initialized
DEBUG - 2016-03-08 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:34:35 --> Input Class Initialized
INFO - 2016-03-08 09:34:35 --> Language Class Initialized
INFO - 2016-03-08 09:34:35 --> Loader Class Initialized
INFO - 2016-03-08 09:34:35 --> Helper loaded: url_helper
INFO - 2016-03-08 09:34:35 --> Helper loaded: file_helper
INFO - 2016-03-08 09:34:35 --> Helper loaded: date_helper
INFO - 2016-03-08 09:34:35 --> Helper loaded: form_helper
INFO - 2016-03-08 09:34:35 --> Database Driver Class Initialized
INFO - 2016-03-08 09:34:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:34:36 --> Controller Class Initialized
INFO - 2016-03-08 09:34:36 --> Model Class Initialized
INFO - 2016-03-08 09:34:36 --> Model Class Initialized
INFO - 2016-03-08 09:34:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:34:36 --> Pagination Class Initialized
INFO - 2016-03-08 09:34:36 --> Helper loaded: text_helper
INFO - 2016-03-08 09:34:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:34:36 --> Final output sent to browser
DEBUG - 2016-03-08 12:34:36 --> Total execution time: 1.1553
INFO - 2016-03-08 09:48:31 --> Config Class Initialized
INFO - 2016-03-08 09:48:31 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:48:31 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:48:31 --> Utf8 Class Initialized
INFO - 2016-03-08 09:48:31 --> URI Class Initialized
INFO - 2016-03-08 09:48:31 --> Router Class Initialized
INFO - 2016-03-08 09:48:31 --> Output Class Initialized
INFO - 2016-03-08 09:48:31 --> Security Class Initialized
DEBUG - 2016-03-08 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:48:31 --> Input Class Initialized
INFO - 2016-03-08 09:48:31 --> Language Class Initialized
INFO - 2016-03-08 09:48:31 --> Loader Class Initialized
INFO - 2016-03-08 09:48:31 --> Helper loaded: url_helper
INFO - 2016-03-08 09:48:31 --> Helper loaded: file_helper
INFO - 2016-03-08 09:48:31 --> Helper loaded: date_helper
INFO - 2016-03-08 09:48:31 --> Helper loaded: form_helper
INFO - 2016-03-08 09:48:31 --> Database Driver Class Initialized
INFO - 2016-03-08 09:48:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:48:32 --> Controller Class Initialized
INFO - 2016-03-08 09:48:32 --> Model Class Initialized
INFO - 2016-03-08 09:48:32 --> Model Class Initialized
INFO - 2016-03-08 09:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:48:32 --> Pagination Class Initialized
INFO - 2016-03-08 09:48:32 --> Helper loaded: text_helper
INFO - 2016-03-08 09:48:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 12:48:32 --> Final output sent to browser
DEBUG - 2016-03-08 12:48:32 --> Total execution time: 1.1675
INFO - 2016-03-08 09:48:43 --> Config Class Initialized
INFO - 2016-03-08 09:48:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:48:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:48:43 --> Utf8 Class Initialized
INFO - 2016-03-08 09:48:43 --> URI Class Initialized
INFO - 2016-03-08 09:48:43 --> Router Class Initialized
INFO - 2016-03-08 09:48:43 --> Output Class Initialized
INFO - 2016-03-08 09:48:43 --> Security Class Initialized
DEBUG - 2016-03-08 09:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:48:43 --> Input Class Initialized
INFO - 2016-03-08 09:48:43 --> Language Class Initialized
INFO - 2016-03-08 09:48:43 --> Loader Class Initialized
INFO - 2016-03-08 09:48:43 --> Helper loaded: url_helper
INFO - 2016-03-08 09:48:43 --> Helper loaded: file_helper
INFO - 2016-03-08 09:48:43 --> Helper loaded: date_helper
INFO - 2016-03-08 09:48:43 --> Helper loaded: form_helper
INFO - 2016-03-08 09:48:43 --> Database Driver Class Initialized
INFO - 2016-03-08 09:48:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:48:44 --> Controller Class Initialized
INFO - 2016-03-08 09:48:44 --> Model Class Initialized
INFO - 2016-03-08 09:48:44 --> Model Class Initialized
INFO - 2016-03-08 09:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:48:44 --> Pagination Class Initialized
INFO - 2016-03-08 09:48:44 --> Helper loaded: text_helper
INFO - 2016-03-08 09:48:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 12:48:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROMwall' at line 1 - Invalid query: SELECT * FROMwall
INFO - 2016-03-08 12:48:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 09:49:51 --> Config Class Initialized
INFO - 2016-03-08 09:49:51 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:49:51 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:49:51 --> Utf8 Class Initialized
INFO - 2016-03-08 09:49:51 --> URI Class Initialized
INFO - 2016-03-08 09:49:51 --> Router Class Initialized
INFO - 2016-03-08 09:49:51 --> Output Class Initialized
INFO - 2016-03-08 09:49:51 --> Security Class Initialized
DEBUG - 2016-03-08 09:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:49:51 --> Input Class Initialized
INFO - 2016-03-08 09:49:51 --> Language Class Initialized
INFO - 2016-03-08 09:49:51 --> Loader Class Initialized
INFO - 2016-03-08 09:49:51 --> Helper loaded: url_helper
INFO - 2016-03-08 09:49:51 --> Helper loaded: file_helper
INFO - 2016-03-08 09:49:51 --> Helper loaded: date_helper
INFO - 2016-03-08 09:49:51 --> Helper loaded: form_helper
INFO - 2016-03-08 09:49:51 --> Database Driver Class Initialized
INFO - 2016-03-08 09:49:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:49:52 --> Controller Class Initialized
INFO - 2016-03-08 09:49:52 --> Model Class Initialized
INFO - 2016-03-08 09:49:52 --> Model Class Initialized
INFO - 2016-03-08 09:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:49:52 --> Pagination Class Initialized
INFO - 2016-03-08 09:49:52 --> Helper loaded: text_helper
INFO - 2016-03-08 09:49:52 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 12:49:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROMwall' at line 1 - Invalid query: SELECT * FROMwall
INFO - 2016-03-08 12:49:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 09:50:21 --> Config Class Initialized
INFO - 2016-03-08 09:50:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:50:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:50:21 --> Utf8 Class Initialized
INFO - 2016-03-08 09:50:21 --> URI Class Initialized
INFO - 2016-03-08 09:50:21 --> Router Class Initialized
INFO - 2016-03-08 09:50:21 --> Output Class Initialized
INFO - 2016-03-08 09:50:21 --> Security Class Initialized
DEBUG - 2016-03-08 09:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:50:21 --> Input Class Initialized
INFO - 2016-03-08 09:50:21 --> Language Class Initialized
INFO - 2016-03-08 09:50:21 --> Loader Class Initialized
INFO - 2016-03-08 09:50:21 --> Helper loaded: url_helper
INFO - 2016-03-08 09:50:21 --> Helper loaded: file_helper
INFO - 2016-03-08 09:50:21 --> Helper loaded: date_helper
INFO - 2016-03-08 09:50:21 --> Helper loaded: form_helper
INFO - 2016-03-08 09:50:21 --> Database Driver Class Initialized
INFO - 2016-03-08 09:50:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:50:22 --> Controller Class Initialized
INFO - 2016-03-08 09:50:22 --> Model Class Initialized
INFO - 2016-03-08 09:50:22 --> Model Class Initialized
INFO - 2016-03-08 09:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:50:22 --> Pagination Class Initialized
INFO - 2016-03-08 09:50:22 --> Helper loaded: text_helper
INFO - 2016-03-08 09:50:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 12:50:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM.$table_name' at line 1 - Invalid query: SELECT * FROM.$table_name
INFO - 2016-03-08 12:50:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 09:51:16 --> Config Class Initialized
INFO - 2016-03-08 09:51:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:51:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:51:16 --> Utf8 Class Initialized
INFO - 2016-03-08 09:51:16 --> URI Class Initialized
INFO - 2016-03-08 09:51:16 --> Router Class Initialized
INFO - 2016-03-08 09:51:16 --> Output Class Initialized
INFO - 2016-03-08 09:51:16 --> Security Class Initialized
DEBUG - 2016-03-08 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:51:16 --> Input Class Initialized
INFO - 2016-03-08 09:51:16 --> Language Class Initialized
INFO - 2016-03-08 09:51:16 --> Loader Class Initialized
INFO - 2016-03-08 09:51:16 --> Helper loaded: url_helper
INFO - 2016-03-08 09:51:16 --> Helper loaded: file_helper
INFO - 2016-03-08 09:51:16 --> Helper loaded: date_helper
INFO - 2016-03-08 09:51:16 --> Helper loaded: form_helper
INFO - 2016-03-08 09:51:16 --> Database Driver Class Initialized
INFO - 2016-03-08 09:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:51:17 --> Controller Class Initialized
INFO - 2016-03-08 09:51:17 --> Model Class Initialized
INFO - 2016-03-08 09:51:17 --> Model Class Initialized
INFO - 2016-03-08 09:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:51:17 --> Pagination Class Initialized
INFO - 2016-03-08 09:51:17 --> Helper loaded: text_helper
INFO - 2016-03-08 09:51:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 12:51:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROMwall' at line 1 - Invalid query: SELECT * FROMwall
INFO - 2016-03-08 12:51:17 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 09:51:30 --> Config Class Initialized
INFO - 2016-03-08 09:51:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 09:51:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 09:51:30 --> Utf8 Class Initialized
INFO - 2016-03-08 09:51:30 --> URI Class Initialized
INFO - 2016-03-08 09:51:30 --> Router Class Initialized
INFO - 2016-03-08 09:51:30 --> Output Class Initialized
INFO - 2016-03-08 09:51:30 --> Security Class Initialized
DEBUG - 2016-03-08 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 09:51:30 --> Input Class Initialized
INFO - 2016-03-08 09:51:30 --> Language Class Initialized
INFO - 2016-03-08 09:51:30 --> Loader Class Initialized
INFO - 2016-03-08 09:51:30 --> Helper loaded: url_helper
INFO - 2016-03-08 09:51:30 --> Helper loaded: file_helper
INFO - 2016-03-08 09:51:30 --> Helper loaded: date_helper
INFO - 2016-03-08 09:51:30 --> Helper loaded: form_helper
INFO - 2016-03-08 09:51:30 --> Database Driver Class Initialized
INFO - 2016-03-08 09:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 09:51:31 --> Controller Class Initialized
INFO - 2016-03-08 09:51:31 --> Model Class Initialized
INFO - 2016-03-08 09:51:31 --> Model Class Initialized
INFO - 2016-03-08 09:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 09:51:31 --> Pagination Class Initialized
INFO - 2016-03-08 09:51:31 --> Helper loaded: text_helper
INFO - 2016-03-08 09:51:31 --> Helper loaded: cookie_helper
INFO - 2016-03-08 12:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 12:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 12:51:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROMwall' at line 1 - Invalid query: SELECT * FROMwall
INFO - 2016-03-08 12:51:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 10:26:44 --> Config Class Initialized
INFO - 2016-03-08 10:26:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:26:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:26:44 --> Utf8 Class Initialized
INFO - 2016-03-08 10:26:44 --> URI Class Initialized
INFO - 2016-03-08 10:26:44 --> Router Class Initialized
INFO - 2016-03-08 10:26:44 --> Output Class Initialized
INFO - 2016-03-08 10:26:44 --> Security Class Initialized
DEBUG - 2016-03-08 10:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:26:44 --> Input Class Initialized
INFO - 2016-03-08 10:26:44 --> Language Class Initialized
INFO - 2016-03-08 10:26:44 --> Loader Class Initialized
INFO - 2016-03-08 10:26:44 --> Helper loaded: url_helper
INFO - 2016-03-08 10:26:44 --> Helper loaded: file_helper
INFO - 2016-03-08 10:26:44 --> Helper loaded: date_helper
INFO - 2016-03-08 10:26:44 --> Helper loaded: form_helper
INFO - 2016-03-08 10:26:44 --> Database Driver Class Initialized
INFO - 2016-03-08 10:26:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:26:45 --> Controller Class Initialized
INFO - 2016-03-08 10:26:45 --> Model Class Initialized
INFO - 2016-03-08 10:26:45 --> Model Class Initialized
INFO - 2016-03-08 10:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:26:45 --> Pagination Class Initialized
INFO - 2016-03-08 10:26:45 --> Helper loaded: text_helper
INFO - 2016-03-08 10:26:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 13:26:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 159
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:26:45 --> Final output sent to browser
DEBUG - 2016-03-08 13:26:45 --> Total execution time: 1.2294
INFO - 2016-03-08 10:27:38 --> Config Class Initialized
INFO - 2016-03-08 10:27:38 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:27:38 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:27:38 --> Utf8 Class Initialized
INFO - 2016-03-08 10:27:38 --> URI Class Initialized
INFO - 2016-03-08 10:27:38 --> Router Class Initialized
INFO - 2016-03-08 10:27:38 --> Output Class Initialized
INFO - 2016-03-08 10:27:38 --> Security Class Initialized
DEBUG - 2016-03-08 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:27:38 --> Input Class Initialized
INFO - 2016-03-08 10:27:38 --> Language Class Initialized
INFO - 2016-03-08 10:27:38 --> Loader Class Initialized
INFO - 2016-03-08 10:27:38 --> Helper loaded: url_helper
INFO - 2016-03-08 10:27:38 --> Helper loaded: file_helper
INFO - 2016-03-08 10:27:38 --> Helper loaded: date_helper
INFO - 2016-03-08 10:27:38 --> Helper loaded: form_helper
INFO - 2016-03-08 10:27:38 --> Database Driver Class Initialized
INFO - 2016-03-08 10:27:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:27:39 --> Controller Class Initialized
INFO - 2016-03-08 10:27:39 --> Model Class Initialized
INFO - 2016-03-08 10:27:39 --> Model Class Initialized
INFO - 2016-03-08 10:27:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:27:39 --> Pagination Class Initialized
INFO - 2016-03-08 10:27:39 --> Helper loaded: text_helper
INFO - 2016-03-08 10:27:39 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 13:27:39 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 159
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:27:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:27:39 --> Final output sent to browser
DEBUG - 2016-03-08 13:27:39 --> Total execution time: 1.2475
INFO - 2016-03-08 10:28:46 --> Config Class Initialized
INFO - 2016-03-08 10:28:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:28:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:28:46 --> Utf8 Class Initialized
INFO - 2016-03-08 10:28:46 --> URI Class Initialized
INFO - 2016-03-08 10:28:46 --> Router Class Initialized
INFO - 2016-03-08 10:28:46 --> Output Class Initialized
INFO - 2016-03-08 10:28:46 --> Security Class Initialized
DEBUG - 2016-03-08 10:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:28:46 --> Input Class Initialized
INFO - 2016-03-08 10:28:46 --> Language Class Initialized
INFO - 2016-03-08 10:28:46 --> Loader Class Initialized
INFO - 2016-03-08 10:28:46 --> Helper loaded: url_helper
INFO - 2016-03-08 10:28:46 --> Helper loaded: file_helper
INFO - 2016-03-08 10:28:46 --> Helper loaded: date_helper
INFO - 2016-03-08 10:28:46 --> Helper loaded: form_helper
INFO - 2016-03-08 10:28:46 --> Database Driver Class Initialized
INFO - 2016-03-08 10:28:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:28:47 --> Controller Class Initialized
INFO - 2016-03-08 10:28:47 --> Model Class Initialized
INFO - 2016-03-08 10:28:47 --> Model Class Initialized
INFO - 2016-03-08 10:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:28:47 --> Pagination Class Initialized
INFO - 2016-03-08 10:28:47 --> Helper loaded: text_helper
INFO - 2016-03-08 10:28:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:28:47 --> Final output sent to browser
DEBUG - 2016-03-08 13:28:47 --> Total execution time: 1.2537
INFO - 2016-03-08 10:29:05 --> Config Class Initialized
INFO - 2016-03-08 10:29:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:29:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:29:05 --> Utf8 Class Initialized
INFO - 2016-03-08 10:29:05 --> URI Class Initialized
INFO - 2016-03-08 10:29:05 --> Router Class Initialized
INFO - 2016-03-08 10:29:05 --> Output Class Initialized
INFO - 2016-03-08 10:29:05 --> Security Class Initialized
DEBUG - 2016-03-08 10:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:29:05 --> Input Class Initialized
INFO - 2016-03-08 10:29:05 --> Language Class Initialized
INFO - 2016-03-08 10:29:05 --> Loader Class Initialized
INFO - 2016-03-08 10:29:05 --> Helper loaded: url_helper
INFO - 2016-03-08 10:29:05 --> Helper loaded: file_helper
INFO - 2016-03-08 10:29:05 --> Helper loaded: date_helper
INFO - 2016-03-08 10:29:05 --> Helper loaded: form_helper
INFO - 2016-03-08 10:29:05 --> Database Driver Class Initialized
INFO - 2016-03-08 10:29:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:29:06 --> Controller Class Initialized
INFO - 2016-03-08 10:29:06 --> Model Class Initialized
INFO - 2016-03-08 10:29:06 --> Model Class Initialized
INFO - 2016-03-08 10:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:29:06 --> Pagination Class Initialized
INFO - 2016-03-08 10:29:06 --> Helper loaded: text_helper
INFO - 2016-03-08 10:29:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:29:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:29:07 --> Final output sent to browser
DEBUG - 2016-03-08 13:29:07 --> Total execution time: 1.2850
INFO - 2016-03-08 10:29:26 --> Config Class Initialized
INFO - 2016-03-08 10:29:26 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:29:26 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:29:26 --> Utf8 Class Initialized
INFO - 2016-03-08 10:29:26 --> URI Class Initialized
INFO - 2016-03-08 10:29:26 --> Router Class Initialized
INFO - 2016-03-08 10:29:26 --> Output Class Initialized
INFO - 2016-03-08 10:29:26 --> Security Class Initialized
DEBUG - 2016-03-08 10:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:29:26 --> Input Class Initialized
INFO - 2016-03-08 10:29:26 --> Language Class Initialized
INFO - 2016-03-08 10:29:27 --> Loader Class Initialized
INFO - 2016-03-08 10:29:27 --> Helper loaded: url_helper
INFO - 2016-03-08 10:29:27 --> Helper loaded: file_helper
INFO - 2016-03-08 10:29:27 --> Helper loaded: date_helper
INFO - 2016-03-08 10:29:27 --> Helper loaded: form_helper
INFO - 2016-03-08 10:29:27 --> Database Driver Class Initialized
INFO - 2016-03-08 10:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:29:28 --> Controller Class Initialized
INFO - 2016-03-08 10:29:28 --> Model Class Initialized
INFO - 2016-03-08 10:29:28 --> Model Class Initialized
INFO - 2016-03-08 10:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:29:28 --> Pagination Class Initialized
INFO - 2016-03-08 10:29:28 --> Helper loaded: text_helper
INFO - 2016-03-08 10:29:28 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 13:29:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 159
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:29:28 --> Final output sent to browser
DEBUG - 2016-03-08 13:29:28 --> Total execution time: 1.2042
INFO - 2016-03-08 10:48:19 --> Config Class Initialized
INFO - 2016-03-08 10:48:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:48:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:48:19 --> Utf8 Class Initialized
INFO - 2016-03-08 10:48:19 --> URI Class Initialized
INFO - 2016-03-08 10:48:19 --> Router Class Initialized
INFO - 2016-03-08 10:48:19 --> Output Class Initialized
INFO - 2016-03-08 10:48:19 --> Security Class Initialized
DEBUG - 2016-03-08 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:48:19 --> Input Class Initialized
INFO - 2016-03-08 10:48:19 --> Language Class Initialized
INFO - 2016-03-08 10:48:19 --> Loader Class Initialized
INFO - 2016-03-08 10:48:19 --> Helper loaded: url_helper
INFO - 2016-03-08 10:48:19 --> Helper loaded: file_helper
INFO - 2016-03-08 10:48:19 --> Helper loaded: date_helper
INFO - 2016-03-08 10:48:19 --> Helper loaded: form_helper
INFO - 2016-03-08 10:48:19 --> Database Driver Class Initialized
INFO - 2016-03-08 10:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:48:20 --> Controller Class Initialized
INFO - 2016-03-08 10:48:20 --> Model Class Initialized
INFO - 2016-03-08 10:48:20 --> Model Class Initialized
INFO - 2016-03-08 10:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:48:20 --> Pagination Class Initialized
INFO - 2016-03-08 10:48:20 --> Helper loaded: text_helper
INFO - 2016-03-08 10:48:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:48:20 --> Final output sent to browser
DEBUG - 2016-03-08 13:48:20 --> Total execution time: 1.2211
INFO - 2016-03-08 10:49:10 --> Config Class Initialized
INFO - 2016-03-08 10:49:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:49:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:49:10 --> Utf8 Class Initialized
INFO - 2016-03-08 10:49:10 --> URI Class Initialized
INFO - 2016-03-08 10:49:10 --> Router Class Initialized
INFO - 2016-03-08 10:49:10 --> Output Class Initialized
INFO - 2016-03-08 10:49:10 --> Security Class Initialized
DEBUG - 2016-03-08 10:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:49:10 --> Input Class Initialized
INFO - 2016-03-08 10:49:10 --> Language Class Initialized
INFO - 2016-03-08 10:49:10 --> Loader Class Initialized
INFO - 2016-03-08 10:49:10 --> Helper loaded: url_helper
INFO - 2016-03-08 10:49:10 --> Helper loaded: file_helper
INFO - 2016-03-08 10:49:10 --> Helper loaded: date_helper
INFO - 2016-03-08 10:49:10 --> Helper loaded: form_helper
INFO - 2016-03-08 10:49:10 --> Database Driver Class Initialized
INFO - 2016-03-08 10:49:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:49:11 --> Controller Class Initialized
INFO - 2016-03-08 10:49:11 --> Model Class Initialized
INFO - 2016-03-08 10:49:11 --> Model Class Initialized
INFO - 2016-03-08 10:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:49:11 --> Pagination Class Initialized
INFO - 2016-03-08 10:49:11 --> Helper loaded: text_helper
INFO - 2016-03-08 10:49:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:49:11 --> Final output sent to browser
DEBUG - 2016-03-08 13:49:11 --> Total execution time: 1.1802
INFO - 2016-03-08 10:49:13 --> Config Class Initialized
INFO - 2016-03-08 10:49:13 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:49:13 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:49:13 --> Utf8 Class Initialized
INFO - 2016-03-08 10:49:13 --> URI Class Initialized
INFO - 2016-03-08 10:49:13 --> Router Class Initialized
INFO - 2016-03-08 10:49:13 --> Output Class Initialized
INFO - 2016-03-08 10:49:13 --> Security Class Initialized
DEBUG - 2016-03-08 10:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:49:13 --> Input Class Initialized
INFO - 2016-03-08 10:49:13 --> Language Class Initialized
INFO - 2016-03-08 10:49:13 --> Loader Class Initialized
INFO - 2016-03-08 10:49:13 --> Helper loaded: url_helper
INFO - 2016-03-08 10:49:13 --> Helper loaded: file_helper
INFO - 2016-03-08 10:49:13 --> Helper loaded: date_helper
INFO - 2016-03-08 10:49:13 --> Helper loaded: form_helper
INFO - 2016-03-08 10:49:13 --> Database Driver Class Initialized
INFO - 2016-03-08 10:49:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:49:14 --> Controller Class Initialized
INFO - 2016-03-08 10:49:14 --> Model Class Initialized
INFO - 2016-03-08 10:49:14 --> Model Class Initialized
INFO - 2016-03-08 10:49:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:49:14 --> Pagination Class Initialized
INFO - 2016-03-08 10:49:14 --> Helper loaded: text_helper
INFO - 2016-03-08 10:49:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:49:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:49:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:49:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:49:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 13:49:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:49:14 --> Final output sent to browser
DEBUG - 2016-03-08 13:49:14 --> Total execution time: 1.1976
INFO - 2016-03-08 10:49:18 --> Config Class Initialized
INFO - 2016-03-08 10:49:18 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:49:18 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:49:18 --> Utf8 Class Initialized
INFO - 2016-03-08 10:49:18 --> URI Class Initialized
INFO - 2016-03-08 10:49:18 --> Router Class Initialized
INFO - 2016-03-08 10:49:18 --> Output Class Initialized
INFO - 2016-03-08 10:49:18 --> Security Class Initialized
DEBUG - 2016-03-08 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:49:18 --> Input Class Initialized
INFO - 2016-03-08 10:49:18 --> Language Class Initialized
INFO - 2016-03-08 10:49:18 --> Loader Class Initialized
INFO - 2016-03-08 10:49:18 --> Helper loaded: url_helper
INFO - 2016-03-08 10:49:18 --> Helper loaded: file_helper
INFO - 2016-03-08 10:49:18 --> Helper loaded: date_helper
INFO - 2016-03-08 10:49:18 --> Helper loaded: form_helper
INFO - 2016-03-08 10:49:18 --> Database Driver Class Initialized
INFO - 2016-03-08 10:49:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:49:19 --> Controller Class Initialized
INFO - 2016-03-08 10:49:19 --> Model Class Initialized
INFO - 2016-03-08 10:49:19 --> Model Class Initialized
INFO - 2016-03-08 10:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:49:19 --> Pagination Class Initialized
INFO - 2016-03-08 10:49:19 --> Helper loaded: text_helper
INFO - 2016-03-08 10:49:19 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:49:19 --> Final output sent to browser
DEBUG - 2016-03-08 13:49:19 --> Total execution time: 1.1313
INFO - 2016-03-08 10:49:22 --> Config Class Initialized
INFO - 2016-03-08 10:49:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:49:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:49:22 --> Utf8 Class Initialized
INFO - 2016-03-08 10:49:22 --> URI Class Initialized
INFO - 2016-03-08 10:49:22 --> Router Class Initialized
INFO - 2016-03-08 10:49:22 --> Output Class Initialized
INFO - 2016-03-08 10:49:22 --> Security Class Initialized
DEBUG - 2016-03-08 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:49:22 --> Input Class Initialized
INFO - 2016-03-08 10:49:22 --> Language Class Initialized
INFO - 2016-03-08 10:49:22 --> Loader Class Initialized
INFO - 2016-03-08 10:49:22 --> Helper loaded: url_helper
INFO - 2016-03-08 10:49:22 --> Helper loaded: file_helper
INFO - 2016-03-08 10:49:22 --> Helper loaded: date_helper
INFO - 2016-03-08 10:49:22 --> Helper loaded: form_helper
INFO - 2016-03-08 10:49:22 --> Database Driver Class Initialized
INFO - 2016-03-08 10:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:49:23 --> Controller Class Initialized
INFO - 2016-03-08 10:49:23 --> Model Class Initialized
INFO - 2016-03-08 10:49:23 --> Model Class Initialized
INFO - 2016-03-08 10:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:49:23 --> Pagination Class Initialized
INFO - 2016-03-08 10:49:23 --> Helper loaded: text_helper
INFO - 2016-03-08 10:49:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:49:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:49:23 --> Final output sent to browser
DEBUG - 2016-03-08 13:49:23 --> Total execution time: 1.1792
INFO - 2016-03-08 10:50:36 --> Config Class Initialized
INFO - 2016-03-08 10:50:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:50:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:50:36 --> Utf8 Class Initialized
INFO - 2016-03-08 10:50:36 --> URI Class Initialized
INFO - 2016-03-08 10:50:36 --> Router Class Initialized
INFO - 2016-03-08 10:50:36 --> Output Class Initialized
INFO - 2016-03-08 10:50:36 --> Security Class Initialized
DEBUG - 2016-03-08 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:50:36 --> Input Class Initialized
INFO - 2016-03-08 10:50:36 --> Language Class Initialized
INFO - 2016-03-08 10:50:36 --> Loader Class Initialized
INFO - 2016-03-08 10:50:36 --> Helper loaded: url_helper
INFO - 2016-03-08 10:50:36 --> Helper loaded: file_helper
INFO - 2016-03-08 10:50:36 --> Helper loaded: date_helper
INFO - 2016-03-08 10:50:36 --> Helper loaded: form_helper
INFO - 2016-03-08 10:50:36 --> Database Driver Class Initialized
INFO - 2016-03-08 10:50:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:50:37 --> Controller Class Initialized
INFO - 2016-03-08 10:50:37 --> Model Class Initialized
INFO - 2016-03-08 10:50:37 --> Model Class Initialized
INFO - 2016-03-08 10:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:50:37 --> Pagination Class Initialized
INFO - 2016-03-08 10:50:37 --> Helper loaded: text_helper
INFO - 2016-03-08 10:50:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:50:37 --> Final output sent to browser
DEBUG - 2016-03-08 13:50:37 --> Total execution time: 1.1625
INFO - 2016-03-08 10:50:47 --> Config Class Initialized
INFO - 2016-03-08 10:50:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:50:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:50:47 --> Utf8 Class Initialized
INFO - 2016-03-08 10:50:47 --> URI Class Initialized
INFO - 2016-03-08 10:50:47 --> Router Class Initialized
INFO - 2016-03-08 10:50:47 --> Output Class Initialized
INFO - 2016-03-08 10:50:47 --> Security Class Initialized
DEBUG - 2016-03-08 10:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:50:47 --> Input Class Initialized
INFO - 2016-03-08 10:50:47 --> Language Class Initialized
INFO - 2016-03-08 10:50:47 --> Loader Class Initialized
INFO - 2016-03-08 10:50:47 --> Helper loaded: url_helper
INFO - 2016-03-08 10:50:47 --> Helper loaded: file_helper
INFO - 2016-03-08 10:50:47 --> Helper loaded: date_helper
INFO - 2016-03-08 10:50:47 --> Helper loaded: form_helper
INFO - 2016-03-08 10:50:47 --> Database Driver Class Initialized
INFO - 2016-03-08 10:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:50:48 --> Controller Class Initialized
INFO - 2016-03-08 10:50:48 --> Model Class Initialized
INFO - 2016-03-08 10:50:48 --> Model Class Initialized
INFO - 2016-03-08 10:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:50:48 --> Pagination Class Initialized
INFO - 2016-03-08 10:50:48 --> Helper loaded: text_helper
INFO - 2016-03-08 10:50:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:50:48 --> Final output sent to browser
DEBUG - 2016-03-08 13:50:48 --> Total execution time: 1.1096
INFO - 2016-03-08 10:50:49 --> Config Class Initialized
INFO - 2016-03-08 10:50:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:50:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:50:49 --> Utf8 Class Initialized
INFO - 2016-03-08 10:50:49 --> URI Class Initialized
INFO - 2016-03-08 10:50:49 --> Router Class Initialized
INFO - 2016-03-08 10:50:49 --> Output Class Initialized
INFO - 2016-03-08 10:50:49 --> Security Class Initialized
DEBUG - 2016-03-08 10:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:50:49 --> Input Class Initialized
INFO - 2016-03-08 10:50:49 --> Language Class Initialized
INFO - 2016-03-08 10:50:49 --> Loader Class Initialized
INFO - 2016-03-08 10:50:49 --> Helper loaded: url_helper
INFO - 2016-03-08 10:50:49 --> Helper loaded: file_helper
INFO - 2016-03-08 10:50:50 --> Helper loaded: date_helper
INFO - 2016-03-08 10:50:50 --> Helper loaded: form_helper
INFO - 2016-03-08 10:50:50 --> Database Driver Class Initialized
INFO - 2016-03-08 10:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:50:51 --> Controller Class Initialized
INFO - 2016-03-08 10:50:51 --> Model Class Initialized
INFO - 2016-03-08 10:50:51 --> Model Class Initialized
INFO - 2016-03-08 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:50:51 --> Pagination Class Initialized
INFO - 2016-03-08 10:50:51 --> Helper loaded: text_helper
INFO - 2016-03-08 10:50:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:50:51 --> Final output sent to browser
DEBUG - 2016-03-08 13:50:51 --> Total execution time: 1.2083
INFO - 2016-03-08 10:56:16 --> Config Class Initialized
INFO - 2016-03-08 10:56:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:16 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:16 --> URI Class Initialized
INFO - 2016-03-08 10:56:16 --> Router Class Initialized
INFO - 2016-03-08 10:56:16 --> Output Class Initialized
INFO - 2016-03-08 10:56:16 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:16 --> Input Class Initialized
INFO - 2016-03-08 10:56:16 --> Language Class Initialized
INFO - 2016-03-08 10:56:16 --> Loader Class Initialized
INFO - 2016-03-08 10:56:16 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:16 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:16 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:16 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:16 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:17 --> Controller Class Initialized
INFO - 2016-03-08 10:56:17 --> Model Class Initialized
INFO - 2016-03-08 10:56:17 --> Model Class Initialized
INFO - 2016-03-08 10:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:17 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:17 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:17 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:17 --> Total execution time: 1.1431
INFO - 2016-03-08 10:56:25 --> Config Class Initialized
INFO - 2016-03-08 10:56:25 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:25 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:25 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:25 --> URI Class Initialized
INFO - 2016-03-08 10:56:25 --> Router Class Initialized
INFO - 2016-03-08 10:56:25 --> Output Class Initialized
INFO - 2016-03-08 10:56:25 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:25 --> Input Class Initialized
INFO - 2016-03-08 10:56:25 --> Language Class Initialized
INFO - 2016-03-08 10:56:25 --> Loader Class Initialized
INFO - 2016-03-08 10:56:25 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:25 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:25 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:25 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:25 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:26 --> Controller Class Initialized
INFO - 2016-03-08 10:56:26 --> Model Class Initialized
INFO - 2016-03-08 10:56:26 --> Model Class Initialized
INFO - 2016-03-08 10:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:26 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:26 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:26 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:26 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:26 --> Total execution time: 1.2182
INFO - 2016-03-08 10:56:33 --> Config Class Initialized
INFO - 2016-03-08 10:56:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:33 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:33 --> URI Class Initialized
INFO - 2016-03-08 10:56:33 --> Router Class Initialized
INFO - 2016-03-08 10:56:33 --> Output Class Initialized
INFO - 2016-03-08 10:56:33 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:33 --> Input Class Initialized
INFO - 2016-03-08 10:56:33 --> Language Class Initialized
INFO - 2016-03-08 10:56:33 --> Loader Class Initialized
INFO - 2016-03-08 10:56:33 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:33 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:33 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:33 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:33 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:34 --> Controller Class Initialized
INFO - 2016-03-08 10:56:34 --> Model Class Initialized
INFO - 2016-03-08 10:56:34 --> Model Class Initialized
INFO - 2016-03-08 10:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:34 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:34 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:34 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:34 --> Total execution time: 1.1488
INFO - 2016-03-08 10:56:37 --> Config Class Initialized
INFO - 2016-03-08 10:56:37 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:37 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:37 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:37 --> URI Class Initialized
INFO - 2016-03-08 10:56:37 --> Router Class Initialized
INFO - 2016-03-08 10:56:37 --> Output Class Initialized
INFO - 2016-03-08 10:56:37 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:37 --> Input Class Initialized
INFO - 2016-03-08 10:56:37 --> Language Class Initialized
INFO - 2016-03-08 10:56:37 --> Loader Class Initialized
INFO - 2016-03-08 10:56:37 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:37 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:37 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:37 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:37 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:38 --> Controller Class Initialized
INFO - 2016-03-08 10:56:38 --> Model Class Initialized
INFO - 2016-03-08 10:56:38 --> Model Class Initialized
INFO - 2016-03-08 10:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:38 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:38 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:38 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:56:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:56:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:38 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:38 --> Total execution time: 1.2068
INFO - 2016-03-08 10:56:39 --> Config Class Initialized
INFO - 2016-03-08 10:56:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:39 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:39 --> URI Class Initialized
INFO - 2016-03-08 10:56:39 --> Router Class Initialized
INFO - 2016-03-08 10:56:39 --> Output Class Initialized
INFO - 2016-03-08 10:56:39 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:39 --> Input Class Initialized
INFO - 2016-03-08 10:56:39 --> Language Class Initialized
INFO - 2016-03-08 10:56:39 --> Loader Class Initialized
INFO - 2016-03-08 10:56:39 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:39 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:39 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:40 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:40 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:41 --> Controller Class Initialized
INFO - 2016-03-08 10:56:41 --> Model Class Initialized
INFO - 2016-03-08 10:56:41 --> Model Class Initialized
INFO - 2016-03-08 10:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:41 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:41 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:41 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:56:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:41 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:41 --> Total execution time: 1.1687
INFO - 2016-03-08 10:56:42 --> Config Class Initialized
INFO - 2016-03-08 10:56:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:42 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:42 --> URI Class Initialized
INFO - 2016-03-08 10:56:42 --> Router Class Initialized
INFO - 2016-03-08 10:56:42 --> Output Class Initialized
INFO - 2016-03-08 10:56:42 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:42 --> Input Class Initialized
INFO - 2016-03-08 10:56:42 --> Language Class Initialized
INFO - 2016-03-08 10:56:42 --> Loader Class Initialized
INFO - 2016-03-08 10:56:42 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:42 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:42 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:42 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:42 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:43 --> Controller Class Initialized
INFO - 2016-03-08 10:56:43 --> Model Class Initialized
INFO - 2016-03-08 10:56:43 --> Model Class Initialized
INFO - 2016-03-08 10:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:43 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:43 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:43 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:43 --> Total execution time: 1.2178
INFO - 2016-03-08 10:56:55 --> Config Class Initialized
INFO - 2016-03-08 10:56:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:55 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:55 --> URI Class Initialized
INFO - 2016-03-08 10:56:55 --> Router Class Initialized
INFO - 2016-03-08 10:56:55 --> Output Class Initialized
INFO - 2016-03-08 10:56:55 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:55 --> Input Class Initialized
INFO - 2016-03-08 10:56:55 --> Language Class Initialized
INFO - 2016-03-08 10:56:55 --> Loader Class Initialized
INFO - 2016-03-08 10:56:55 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:55 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:55 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:55 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:55 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:56 --> Controller Class Initialized
INFO - 2016-03-08 10:56:56 --> Model Class Initialized
INFO - 2016-03-08 10:56:56 --> Model Class Initialized
INFO - 2016-03-08 10:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:56 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:56 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:56 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:56 --> Total execution time: 1.1689
INFO - 2016-03-08 10:56:58 --> Config Class Initialized
INFO - 2016-03-08 10:56:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:56:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:56:58 --> Utf8 Class Initialized
INFO - 2016-03-08 10:56:58 --> URI Class Initialized
INFO - 2016-03-08 10:56:58 --> Router Class Initialized
INFO - 2016-03-08 10:56:58 --> Output Class Initialized
INFO - 2016-03-08 10:56:58 --> Security Class Initialized
DEBUG - 2016-03-08 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:56:58 --> Input Class Initialized
INFO - 2016-03-08 10:56:58 --> Language Class Initialized
INFO - 2016-03-08 10:56:58 --> Loader Class Initialized
INFO - 2016-03-08 10:56:58 --> Helper loaded: url_helper
INFO - 2016-03-08 10:56:58 --> Helper loaded: file_helper
INFO - 2016-03-08 10:56:58 --> Helper loaded: date_helper
INFO - 2016-03-08 10:56:58 --> Helper loaded: form_helper
INFO - 2016-03-08 10:56:58 --> Database Driver Class Initialized
INFO - 2016-03-08 10:56:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:56:59 --> Controller Class Initialized
INFO - 2016-03-08 10:56:59 --> Model Class Initialized
INFO - 2016-03-08 10:56:59 --> Model Class Initialized
INFO - 2016-03-08 10:56:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:56:59 --> Pagination Class Initialized
INFO - 2016-03-08 10:56:59 --> Helper loaded: text_helper
INFO - 2016-03-08 10:56:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:56:59 --> Final output sent to browser
DEBUG - 2016-03-08 13:56:59 --> Total execution time: 1.2171
INFO - 2016-03-08 10:57:50 --> Config Class Initialized
INFO - 2016-03-08 10:57:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:57:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:57:50 --> Utf8 Class Initialized
INFO - 2016-03-08 10:57:50 --> URI Class Initialized
INFO - 2016-03-08 10:57:50 --> Router Class Initialized
INFO - 2016-03-08 10:57:50 --> Output Class Initialized
INFO - 2016-03-08 10:57:50 --> Security Class Initialized
DEBUG - 2016-03-08 10:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:57:50 --> Input Class Initialized
INFO - 2016-03-08 10:57:50 --> Language Class Initialized
INFO - 2016-03-08 10:57:50 --> Loader Class Initialized
INFO - 2016-03-08 10:57:50 --> Helper loaded: url_helper
INFO - 2016-03-08 10:57:50 --> Helper loaded: file_helper
INFO - 2016-03-08 10:57:50 --> Helper loaded: date_helper
INFO - 2016-03-08 10:57:50 --> Helper loaded: form_helper
INFO - 2016-03-08 10:57:50 --> Database Driver Class Initialized
INFO - 2016-03-08 10:57:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:57:51 --> Controller Class Initialized
INFO - 2016-03-08 10:57:51 --> Model Class Initialized
INFO - 2016-03-08 10:57:51 --> Model Class Initialized
INFO - 2016-03-08 10:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:57:51 --> Pagination Class Initialized
INFO - 2016-03-08 10:57:51 --> Helper loaded: text_helper
INFO - 2016-03-08 10:57:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:57:51 --> Final output sent to browser
DEBUG - 2016-03-08 13:57:51 --> Total execution time: 1.1231
INFO - 2016-03-08 10:57:53 --> Config Class Initialized
INFO - 2016-03-08 10:57:53 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:57:53 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:57:53 --> Utf8 Class Initialized
INFO - 2016-03-08 10:57:53 --> URI Class Initialized
INFO - 2016-03-08 10:57:53 --> Router Class Initialized
INFO - 2016-03-08 10:57:53 --> Output Class Initialized
INFO - 2016-03-08 10:57:53 --> Security Class Initialized
DEBUG - 2016-03-08 10:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:57:53 --> Input Class Initialized
INFO - 2016-03-08 10:57:53 --> Language Class Initialized
INFO - 2016-03-08 10:57:53 --> Loader Class Initialized
INFO - 2016-03-08 10:57:53 --> Helper loaded: url_helper
INFO - 2016-03-08 10:57:53 --> Helper loaded: file_helper
INFO - 2016-03-08 10:57:53 --> Helper loaded: date_helper
INFO - 2016-03-08 10:57:53 --> Helper loaded: form_helper
INFO - 2016-03-08 10:57:53 --> Database Driver Class Initialized
INFO - 2016-03-08 10:57:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:57:54 --> Controller Class Initialized
INFO - 2016-03-08 10:57:54 --> Model Class Initialized
INFO - 2016-03-08 10:57:54 --> Model Class Initialized
INFO - 2016-03-08 10:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:57:54 --> Pagination Class Initialized
INFO - 2016-03-08 10:57:54 --> Helper loaded: text_helper
INFO - 2016-03-08 10:57:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:57:54 --> Final output sent to browser
DEBUG - 2016-03-08 13:57:54 --> Total execution time: 1.1448
INFO - 2016-03-08 10:58:02 --> Config Class Initialized
INFO - 2016-03-08 10:58:02 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:58:02 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:58:02 --> Utf8 Class Initialized
INFO - 2016-03-08 10:58:02 --> URI Class Initialized
INFO - 2016-03-08 10:58:02 --> Router Class Initialized
INFO - 2016-03-08 10:58:02 --> Output Class Initialized
INFO - 2016-03-08 10:58:02 --> Security Class Initialized
DEBUG - 2016-03-08 10:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:58:02 --> Input Class Initialized
INFO - 2016-03-08 10:58:02 --> Language Class Initialized
INFO - 2016-03-08 10:58:02 --> Loader Class Initialized
INFO - 2016-03-08 10:58:02 --> Helper loaded: url_helper
INFO - 2016-03-08 10:58:02 --> Helper loaded: file_helper
INFO - 2016-03-08 10:58:02 --> Helper loaded: date_helper
INFO - 2016-03-08 10:58:02 --> Helper loaded: form_helper
INFO - 2016-03-08 10:58:02 --> Database Driver Class Initialized
INFO - 2016-03-08 10:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:58:03 --> Controller Class Initialized
INFO - 2016-03-08 10:58:03 --> Model Class Initialized
INFO - 2016-03-08 10:58:03 --> Model Class Initialized
INFO - 2016-03-08 10:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:58:03 --> Pagination Class Initialized
INFO - 2016-03-08 10:58:03 --> Helper loaded: text_helper
INFO - 2016-03-08 10:58:03 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:58:03 --> Final output sent to browser
DEBUG - 2016-03-08 13:58:03 --> Total execution time: 1.1354
INFO - 2016-03-08 10:58:05 --> Config Class Initialized
INFO - 2016-03-08 10:58:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:58:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:58:05 --> Utf8 Class Initialized
INFO - 2016-03-08 10:58:05 --> URI Class Initialized
INFO - 2016-03-08 10:58:05 --> Router Class Initialized
INFO - 2016-03-08 10:58:05 --> Output Class Initialized
INFO - 2016-03-08 10:58:05 --> Security Class Initialized
DEBUG - 2016-03-08 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:58:05 --> Input Class Initialized
INFO - 2016-03-08 10:58:05 --> Language Class Initialized
INFO - 2016-03-08 10:58:05 --> Loader Class Initialized
INFO - 2016-03-08 10:58:05 --> Helper loaded: url_helper
INFO - 2016-03-08 10:58:05 --> Helper loaded: file_helper
INFO - 2016-03-08 10:58:05 --> Helper loaded: date_helper
INFO - 2016-03-08 10:58:05 --> Helper loaded: form_helper
INFO - 2016-03-08 10:58:05 --> Database Driver Class Initialized
INFO - 2016-03-08 10:58:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:58:06 --> Controller Class Initialized
INFO - 2016-03-08 10:58:06 --> Model Class Initialized
INFO - 2016-03-08 10:58:06 --> Model Class Initialized
INFO - 2016-03-08 10:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:58:06 --> Pagination Class Initialized
INFO - 2016-03-08 10:58:06 --> Helper loaded: text_helper
INFO - 2016-03-08 10:58:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:58:06 --> Final output sent to browser
DEBUG - 2016-03-08 13:58:06 --> Total execution time: 1.1474
INFO - 2016-03-08 10:58:07 --> Config Class Initialized
INFO - 2016-03-08 10:58:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:58:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:58:07 --> Utf8 Class Initialized
INFO - 2016-03-08 10:58:07 --> URI Class Initialized
INFO - 2016-03-08 10:58:07 --> Router Class Initialized
INFO - 2016-03-08 10:58:07 --> Output Class Initialized
INFO - 2016-03-08 10:58:07 --> Security Class Initialized
DEBUG - 2016-03-08 10:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:58:07 --> Input Class Initialized
INFO - 2016-03-08 10:58:07 --> Language Class Initialized
INFO - 2016-03-08 10:58:07 --> Loader Class Initialized
INFO - 2016-03-08 10:58:07 --> Helper loaded: url_helper
INFO - 2016-03-08 10:58:07 --> Helper loaded: file_helper
INFO - 2016-03-08 10:58:07 --> Helper loaded: date_helper
INFO - 2016-03-08 10:58:07 --> Helper loaded: form_helper
INFO - 2016-03-08 10:58:07 --> Database Driver Class Initialized
INFO - 2016-03-08 10:58:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:58:08 --> Controller Class Initialized
INFO - 2016-03-08 10:58:08 --> Model Class Initialized
INFO - 2016-03-08 10:58:08 --> Model Class Initialized
INFO - 2016-03-08 10:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:58:08 --> Pagination Class Initialized
INFO - 2016-03-08 10:58:08 --> Helper loaded: text_helper
INFO - 2016-03-08 10:58:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:58:08 --> Final output sent to browser
DEBUG - 2016-03-08 13:58:08 --> Total execution time: 1.2087
INFO - 2016-03-08 10:59:46 --> Config Class Initialized
INFO - 2016-03-08 10:59:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:59:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:59:46 --> Utf8 Class Initialized
INFO - 2016-03-08 10:59:46 --> URI Class Initialized
INFO - 2016-03-08 10:59:46 --> Router Class Initialized
INFO - 2016-03-08 10:59:46 --> Output Class Initialized
INFO - 2016-03-08 10:59:46 --> Security Class Initialized
DEBUG - 2016-03-08 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:59:46 --> Input Class Initialized
INFO - 2016-03-08 10:59:46 --> Language Class Initialized
INFO - 2016-03-08 10:59:46 --> Loader Class Initialized
INFO - 2016-03-08 10:59:46 --> Helper loaded: url_helper
INFO - 2016-03-08 10:59:46 --> Helper loaded: file_helper
INFO - 2016-03-08 10:59:46 --> Helper loaded: date_helper
INFO - 2016-03-08 10:59:46 --> Helper loaded: form_helper
INFO - 2016-03-08 10:59:46 --> Database Driver Class Initialized
INFO - 2016-03-08 10:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:59:47 --> Controller Class Initialized
INFO - 2016-03-08 10:59:47 --> Model Class Initialized
INFO - 2016-03-08 10:59:47 --> Model Class Initialized
INFO - 2016-03-08 10:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:59:47 --> Pagination Class Initialized
INFO - 2016-03-08 10:59:47 --> Helper loaded: text_helper
INFO - 2016-03-08 10:59:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 13:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 13:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:59:47 --> Final output sent to browser
DEBUG - 2016-03-08 13:59:47 --> Total execution time: 1.1500
INFO - 2016-03-08 10:59:50 --> Config Class Initialized
INFO - 2016-03-08 10:59:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 10:59:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 10:59:50 --> Utf8 Class Initialized
INFO - 2016-03-08 10:59:50 --> URI Class Initialized
INFO - 2016-03-08 10:59:50 --> Router Class Initialized
INFO - 2016-03-08 10:59:50 --> Output Class Initialized
INFO - 2016-03-08 10:59:50 --> Security Class Initialized
DEBUG - 2016-03-08 10:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 10:59:50 --> Input Class Initialized
INFO - 2016-03-08 10:59:50 --> Language Class Initialized
INFO - 2016-03-08 10:59:50 --> Loader Class Initialized
INFO - 2016-03-08 10:59:50 --> Helper loaded: url_helper
INFO - 2016-03-08 10:59:50 --> Helper loaded: file_helper
INFO - 2016-03-08 10:59:50 --> Helper loaded: date_helper
INFO - 2016-03-08 10:59:50 --> Helper loaded: form_helper
INFO - 2016-03-08 10:59:50 --> Database Driver Class Initialized
INFO - 2016-03-08 10:59:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 10:59:51 --> Controller Class Initialized
INFO - 2016-03-08 10:59:51 --> Model Class Initialized
INFO - 2016-03-08 10:59:51 --> Model Class Initialized
INFO - 2016-03-08 10:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 10:59:51 --> Pagination Class Initialized
INFO - 2016-03-08 10:59:51 --> Helper loaded: text_helper
INFO - 2016-03-08 10:59:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 13:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 13:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 13:59:51 --> Final output sent to browser
DEBUG - 2016-03-08 13:59:51 --> Total execution time: 1.1556
INFO - 2016-03-08 11:00:05 --> Config Class Initialized
INFO - 2016-03-08 11:00:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:05 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:05 --> URI Class Initialized
INFO - 2016-03-08 11:00:05 --> Router Class Initialized
INFO - 2016-03-08 11:00:05 --> Output Class Initialized
INFO - 2016-03-08 11:00:05 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:05 --> Input Class Initialized
INFO - 2016-03-08 11:00:05 --> Language Class Initialized
INFO - 2016-03-08 11:00:05 --> Loader Class Initialized
INFO - 2016-03-08 11:00:05 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:05 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:05 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:05 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:05 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:06 --> Controller Class Initialized
INFO - 2016-03-08 11:00:06 --> Model Class Initialized
INFO - 2016-03-08 11:00:06 --> Model Class Initialized
INFO - 2016-03-08 11:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:06 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:06 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:06 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:06 --> Total execution time: 1.1471
INFO - 2016-03-08 11:00:09 --> Config Class Initialized
INFO - 2016-03-08 11:00:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:09 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:09 --> URI Class Initialized
INFO - 2016-03-08 11:00:09 --> Router Class Initialized
INFO - 2016-03-08 11:00:09 --> Output Class Initialized
INFO - 2016-03-08 11:00:09 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:09 --> Input Class Initialized
INFO - 2016-03-08 11:00:09 --> Language Class Initialized
INFO - 2016-03-08 11:00:09 --> Loader Class Initialized
INFO - 2016-03-08 11:00:09 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:09 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:09 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:09 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:09 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:10 --> Controller Class Initialized
INFO - 2016-03-08 11:00:10 --> Model Class Initialized
INFO - 2016-03-08 11:00:10 --> Model Class Initialized
INFO - 2016-03-08 11:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:10 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:10 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:10 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:10 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:10 --> Total execution time: 1.1148
INFO - 2016-03-08 11:00:12 --> Config Class Initialized
INFO - 2016-03-08 11:00:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:12 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:12 --> URI Class Initialized
INFO - 2016-03-08 11:00:12 --> Router Class Initialized
INFO - 2016-03-08 11:00:12 --> Output Class Initialized
INFO - 2016-03-08 11:00:13 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:13 --> Input Class Initialized
INFO - 2016-03-08 11:00:13 --> Language Class Initialized
INFO - 2016-03-08 11:00:13 --> Loader Class Initialized
INFO - 2016-03-08 11:00:13 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:13 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:13 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:13 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:13 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:14 --> Controller Class Initialized
INFO - 2016-03-08 11:00:14 --> Model Class Initialized
INFO - 2016-03-08 11:00:14 --> Model Class Initialized
INFO - 2016-03-08 11:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:14 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:14 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:14 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:14 --> Total execution time: 1.1757
INFO - 2016-03-08 11:00:32 --> Config Class Initialized
INFO - 2016-03-08 11:00:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:32 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:32 --> URI Class Initialized
INFO - 2016-03-08 11:00:32 --> Router Class Initialized
INFO - 2016-03-08 11:00:32 --> Output Class Initialized
INFO - 2016-03-08 11:00:32 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:32 --> Input Class Initialized
INFO - 2016-03-08 11:00:32 --> Language Class Initialized
INFO - 2016-03-08 11:00:32 --> Loader Class Initialized
INFO - 2016-03-08 11:00:32 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:32 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:32 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:32 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:32 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:33 --> Controller Class Initialized
INFO - 2016-03-08 11:00:33 --> Model Class Initialized
INFO - 2016-03-08 11:00:33 --> Model Class Initialized
INFO - 2016-03-08 11:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:33 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:33 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:00:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:00:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:33 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:33 --> Total execution time: 1.1894
INFO - 2016-03-08 11:00:36 --> Config Class Initialized
INFO - 2016-03-08 11:00:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:36 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:36 --> URI Class Initialized
INFO - 2016-03-08 11:00:36 --> Router Class Initialized
INFO - 2016-03-08 11:00:36 --> Output Class Initialized
INFO - 2016-03-08 11:00:36 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:36 --> Input Class Initialized
INFO - 2016-03-08 11:00:36 --> Language Class Initialized
INFO - 2016-03-08 11:00:36 --> Loader Class Initialized
INFO - 2016-03-08 11:00:36 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:36 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:36 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:36 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:36 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:37 --> Controller Class Initialized
INFO - 2016-03-08 11:00:37 --> Model Class Initialized
INFO - 2016-03-08 11:00:37 --> Model Class Initialized
INFO - 2016-03-08 11:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:37 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:37 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:37 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:37 --> Total execution time: 1.1462
INFO - 2016-03-08 11:00:40 --> Config Class Initialized
INFO - 2016-03-08 11:00:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:40 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:40 --> URI Class Initialized
INFO - 2016-03-08 11:00:40 --> Router Class Initialized
INFO - 2016-03-08 11:00:40 --> Output Class Initialized
INFO - 2016-03-08 11:00:40 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:40 --> Input Class Initialized
INFO - 2016-03-08 11:00:40 --> Language Class Initialized
INFO - 2016-03-08 11:00:40 --> Loader Class Initialized
INFO - 2016-03-08 11:00:40 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:40 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:40 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:40 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:40 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:41 --> Controller Class Initialized
INFO - 2016-03-08 11:00:41 --> Model Class Initialized
INFO - 2016-03-08 11:00:41 --> Model Class Initialized
INFO - 2016-03-08 11:00:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:41 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:41 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:41 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 14:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:00:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:41 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:41 --> Total execution time: 1.1808
INFO - 2016-03-08 11:00:47 --> Config Class Initialized
INFO - 2016-03-08 11:00:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:00:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:00:47 --> Utf8 Class Initialized
INFO - 2016-03-08 11:00:47 --> URI Class Initialized
INFO - 2016-03-08 11:00:47 --> Router Class Initialized
INFO - 2016-03-08 11:00:47 --> Output Class Initialized
INFO - 2016-03-08 11:00:47 --> Security Class Initialized
DEBUG - 2016-03-08 11:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:00:47 --> Input Class Initialized
INFO - 2016-03-08 11:00:47 --> Language Class Initialized
INFO - 2016-03-08 11:00:47 --> Loader Class Initialized
INFO - 2016-03-08 11:00:47 --> Helper loaded: url_helper
INFO - 2016-03-08 11:00:47 --> Helper loaded: file_helper
INFO - 2016-03-08 11:00:47 --> Helper loaded: date_helper
INFO - 2016-03-08 11:00:47 --> Helper loaded: form_helper
INFO - 2016-03-08 11:00:47 --> Database Driver Class Initialized
INFO - 2016-03-08 11:00:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:00:48 --> Controller Class Initialized
INFO - 2016-03-08 11:00:48 --> Model Class Initialized
INFO - 2016-03-08 11:00:48 --> Model Class Initialized
INFO - 2016-03-08 11:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:00:48 --> Pagination Class Initialized
INFO - 2016-03-08 11:00:48 --> Helper loaded: text_helper
INFO - 2016-03-08 11:00:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:00:48 --> Final output sent to browser
DEBUG - 2016-03-08 14:00:48 --> Total execution time: 1.1662
INFO - 2016-03-08 11:18:52 --> Config Class Initialized
INFO - 2016-03-08 11:18:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:18:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:18:52 --> Utf8 Class Initialized
INFO - 2016-03-08 11:18:52 --> URI Class Initialized
INFO - 2016-03-08 11:18:52 --> Router Class Initialized
INFO - 2016-03-08 11:18:52 --> Output Class Initialized
INFO - 2016-03-08 11:18:52 --> Security Class Initialized
DEBUG - 2016-03-08 11:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:18:52 --> Input Class Initialized
INFO - 2016-03-08 11:18:52 --> Language Class Initialized
INFO - 2016-03-08 11:18:52 --> Loader Class Initialized
INFO - 2016-03-08 11:18:52 --> Helper loaded: url_helper
INFO - 2016-03-08 11:18:52 --> Helper loaded: file_helper
INFO - 2016-03-08 11:18:52 --> Helper loaded: date_helper
INFO - 2016-03-08 11:18:52 --> Helper loaded: form_helper
INFO - 2016-03-08 11:18:52 --> Database Driver Class Initialized
INFO - 2016-03-08 11:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:18:53 --> Controller Class Initialized
INFO - 2016-03-08 11:18:53 --> Model Class Initialized
INFO - 2016-03-08 11:18:53 --> Model Class Initialized
INFO - 2016-03-08 11:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:18:53 --> Pagination Class Initialized
INFO - 2016-03-08 11:18:53 --> Helper loaded: text_helper
INFO - 2016-03-08 11:18:53 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 14:18:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:18:53 --> Final output sent to browser
DEBUG - 2016-03-08 14:18:53 --> Total execution time: 1.2085
INFO - 2016-03-08 11:25:46 --> Config Class Initialized
INFO - 2016-03-08 11:25:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:25:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:25:46 --> Utf8 Class Initialized
INFO - 2016-03-08 11:25:46 --> URI Class Initialized
INFO - 2016-03-08 11:25:46 --> Router Class Initialized
INFO - 2016-03-08 11:25:46 --> Output Class Initialized
INFO - 2016-03-08 11:25:46 --> Security Class Initialized
DEBUG - 2016-03-08 11:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:25:46 --> Input Class Initialized
INFO - 2016-03-08 11:25:46 --> Language Class Initialized
INFO - 2016-03-08 11:25:46 --> Loader Class Initialized
INFO - 2016-03-08 11:25:46 --> Helper loaded: url_helper
INFO - 2016-03-08 11:25:46 --> Helper loaded: file_helper
INFO - 2016-03-08 11:25:46 --> Helper loaded: date_helper
INFO - 2016-03-08 11:25:46 --> Helper loaded: form_helper
INFO - 2016-03-08 11:25:46 --> Database Driver Class Initialized
INFO - 2016-03-08 11:25:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:25:47 --> Controller Class Initialized
INFO - 2016-03-08 11:25:47 --> Model Class Initialized
INFO - 2016-03-08 11:25:47 --> Model Class Initialized
INFO - 2016-03-08 11:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:25:47 --> Pagination Class Initialized
INFO - 2016-03-08 11:25:47 --> Helper loaded: text_helper
INFO - 2016-03-08 11:25:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:25:47 --> Final output sent to browser
DEBUG - 2016-03-08 14:25:47 --> Total execution time: 1.1477
INFO - 2016-03-08 11:25:52 --> Config Class Initialized
INFO - 2016-03-08 11:25:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:25:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:25:52 --> Utf8 Class Initialized
INFO - 2016-03-08 11:25:52 --> URI Class Initialized
INFO - 2016-03-08 11:25:52 --> Router Class Initialized
INFO - 2016-03-08 11:25:52 --> Output Class Initialized
INFO - 2016-03-08 11:25:52 --> Security Class Initialized
DEBUG - 2016-03-08 11:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:25:52 --> Input Class Initialized
INFO - 2016-03-08 11:25:52 --> Language Class Initialized
INFO - 2016-03-08 11:25:52 --> Loader Class Initialized
INFO - 2016-03-08 11:25:52 --> Helper loaded: url_helper
INFO - 2016-03-08 11:25:52 --> Helper loaded: file_helper
INFO - 2016-03-08 11:25:52 --> Helper loaded: date_helper
INFO - 2016-03-08 11:25:52 --> Helper loaded: form_helper
INFO - 2016-03-08 11:25:52 --> Database Driver Class Initialized
INFO - 2016-03-08 11:25:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:25:53 --> Controller Class Initialized
INFO - 2016-03-08 11:25:53 --> Model Class Initialized
INFO - 2016-03-08 11:25:53 --> Model Class Initialized
INFO - 2016-03-08 11:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:25:53 --> Pagination Class Initialized
INFO - 2016-03-08 11:25:53 --> Helper loaded: text_helper
INFO - 2016-03-08 11:25:53 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:25:53 --> Final output sent to browser
DEBUG - 2016-03-08 14:25:53 --> Total execution time: 1.1457
INFO - 2016-03-08 11:25:56 --> Config Class Initialized
INFO - 2016-03-08 11:25:56 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:25:56 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:25:56 --> Utf8 Class Initialized
INFO - 2016-03-08 11:25:56 --> URI Class Initialized
INFO - 2016-03-08 11:25:56 --> Router Class Initialized
INFO - 2016-03-08 11:25:56 --> Output Class Initialized
INFO - 2016-03-08 11:25:56 --> Security Class Initialized
DEBUG - 2016-03-08 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:25:56 --> Input Class Initialized
INFO - 2016-03-08 11:25:56 --> Language Class Initialized
INFO - 2016-03-08 11:25:56 --> Loader Class Initialized
INFO - 2016-03-08 11:25:56 --> Helper loaded: url_helper
INFO - 2016-03-08 11:25:56 --> Helper loaded: file_helper
INFO - 2016-03-08 11:25:56 --> Helper loaded: date_helper
INFO - 2016-03-08 11:25:56 --> Helper loaded: form_helper
INFO - 2016-03-08 11:25:56 --> Database Driver Class Initialized
INFO - 2016-03-08 11:25:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:25:57 --> Controller Class Initialized
INFO - 2016-03-08 11:25:57 --> Model Class Initialized
INFO - 2016-03-08 11:25:57 --> Model Class Initialized
INFO - 2016-03-08 11:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:25:57 --> Pagination Class Initialized
INFO - 2016-03-08 11:25:57 --> Helper loaded: text_helper
INFO - 2016-03-08 11:25:57 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:25:57 --> Final output sent to browser
DEBUG - 2016-03-08 14:25:57 --> Total execution time: 1.1650
INFO - 2016-03-08 11:27:27 --> Config Class Initialized
INFO - 2016-03-08 11:27:27 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:27:27 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:27:27 --> Utf8 Class Initialized
INFO - 2016-03-08 11:27:27 --> URI Class Initialized
INFO - 2016-03-08 11:27:27 --> Router Class Initialized
INFO - 2016-03-08 11:27:27 --> Output Class Initialized
INFO - 2016-03-08 11:27:27 --> Security Class Initialized
DEBUG - 2016-03-08 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:27:27 --> Input Class Initialized
INFO - 2016-03-08 11:27:27 --> Language Class Initialized
INFO - 2016-03-08 11:27:27 --> Loader Class Initialized
INFO - 2016-03-08 11:27:27 --> Helper loaded: url_helper
INFO - 2016-03-08 11:27:27 --> Helper loaded: file_helper
INFO - 2016-03-08 11:27:27 --> Helper loaded: date_helper
INFO - 2016-03-08 11:27:27 --> Helper loaded: form_helper
INFO - 2016-03-08 11:27:27 --> Database Driver Class Initialized
INFO - 2016-03-08 11:27:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:27:28 --> Controller Class Initialized
INFO - 2016-03-08 11:27:28 --> Model Class Initialized
INFO - 2016-03-08 11:27:28 --> Model Class Initialized
INFO - 2016-03-08 11:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:27:28 --> Pagination Class Initialized
INFO - 2016-03-08 11:27:28 --> Helper loaded: text_helper
INFO - 2016-03-08 11:27:28 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:27:28 --> Final output sent to browser
DEBUG - 2016-03-08 14:27:28 --> Total execution time: 1.0961
INFO - 2016-03-08 11:27:31 --> Config Class Initialized
INFO - 2016-03-08 11:27:31 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:27:31 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:27:31 --> Utf8 Class Initialized
INFO - 2016-03-08 11:27:32 --> URI Class Initialized
INFO - 2016-03-08 11:27:32 --> Router Class Initialized
INFO - 2016-03-08 11:27:32 --> Output Class Initialized
INFO - 2016-03-08 11:27:32 --> Security Class Initialized
DEBUG - 2016-03-08 11:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:27:32 --> Input Class Initialized
INFO - 2016-03-08 11:27:32 --> Language Class Initialized
INFO - 2016-03-08 11:27:32 --> Loader Class Initialized
INFO - 2016-03-08 11:27:32 --> Helper loaded: url_helper
INFO - 2016-03-08 11:27:32 --> Helper loaded: file_helper
INFO - 2016-03-08 11:27:32 --> Helper loaded: date_helper
INFO - 2016-03-08 11:27:32 --> Helper loaded: form_helper
INFO - 2016-03-08 11:27:32 --> Database Driver Class Initialized
INFO - 2016-03-08 11:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:27:33 --> Controller Class Initialized
INFO - 2016-03-08 11:27:33 --> Model Class Initialized
INFO - 2016-03-08 11:27:33 --> Model Class Initialized
INFO - 2016-03-08 11:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:27:33 --> Pagination Class Initialized
INFO - 2016-03-08 11:27:33 --> Helper loaded: text_helper
INFO - 2016-03-08 11:27:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:27:33 --> Final output sent to browser
DEBUG - 2016-03-08 14:27:33 --> Total execution time: 1.1322
INFO - 2016-03-08 11:27:39 --> Config Class Initialized
INFO - 2016-03-08 11:27:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:27:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:27:39 --> Utf8 Class Initialized
INFO - 2016-03-08 11:27:39 --> URI Class Initialized
INFO - 2016-03-08 11:27:39 --> Router Class Initialized
INFO - 2016-03-08 11:27:39 --> Output Class Initialized
INFO - 2016-03-08 11:27:39 --> Security Class Initialized
DEBUG - 2016-03-08 11:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:27:39 --> Input Class Initialized
INFO - 2016-03-08 11:27:39 --> Language Class Initialized
INFO - 2016-03-08 11:27:39 --> Loader Class Initialized
INFO - 2016-03-08 11:27:39 --> Helper loaded: url_helper
INFO - 2016-03-08 11:27:39 --> Helper loaded: file_helper
INFO - 2016-03-08 11:27:39 --> Helper loaded: date_helper
INFO - 2016-03-08 11:27:39 --> Helper loaded: form_helper
INFO - 2016-03-08 11:27:39 --> Database Driver Class Initialized
INFO - 2016-03-08 11:27:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:27:40 --> Controller Class Initialized
INFO - 2016-03-08 11:27:40 --> Model Class Initialized
INFO - 2016-03-08 11:27:40 --> Model Class Initialized
INFO - 2016-03-08 11:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:27:40 --> Pagination Class Initialized
INFO - 2016-03-08 11:27:40 --> Helper loaded: text_helper
INFO - 2016-03-08 11:27:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:27:40 --> Final output sent to browser
DEBUG - 2016-03-08 14:27:40 --> Total execution time: 1.1535
INFO - 2016-03-08 11:29:43 --> Config Class Initialized
INFO - 2016-03-08 11:29:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:29:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:29:43 --> Utf8 Class Initialized
INFO - 2016-03-08 11:29:43 --> URI Class Initialized
INFO - 2016-03-08 11:29:43 --> Router Class Initialized
INFO - 2016-03-08 11:29:43 --> Output Class Initialized
INFO - 2016-03-08 11:29:43 --> Security Class Initialized
DEBUG - 2016-03-08 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:29:43 --> Input Class Initialized
INFO - 2016-03-08 11:29:43 --> Language Class Initialized
INFO - 2016-03-08 11:29:43 --> Loader Class Initialized
INFO - 2016-03-08 11:29:43 --> Helper loaded: url_helper
INFO - 2016-03-08 11:29:43 --> Helper loaded: file_helper
INFO - 2016-03-08 11:29:43 --> Helper loaded: date_helper
INFO - 2016-03-08 11:29:43 --> Helper loaded: form_helper
INFO - 2016-03-08 11:29:43 --> Database Driver Class Initialized
INFO - 2016-03-08 11:29:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:29:44 --> Controller Class Initialized
INFO - 2016-03-08 11:29:44 --> Model Class Initialized
INFO - 2016-03-08 11:29:44 --> Model Class Initialized
INFO - 2016-03-08 11:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:29:44 --> Pagination Class Initialized
INFO - 2016-03-08 11:29:44 --> Helper loaded: text_helper
INFO - 2016-03-08 11:29:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:29:44 --> Final output sent to browser
DEBUG - 2016-03-08 14:29:44 --> Total execution time: 1.1347
INFO - 2016-03-08 11:29:47 --> Config Class Initialized
INFO - 2016-03-08 11:29:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:29:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:29:47 --> Utf8 Class Initialized
INFO - 2016-03-08 11:29:47 --> URI Class Initialized
INFO - 2016-03-08 11:29:47 --> Router Class Initialized
INFO - 2016-03-08 11:29:47 --> Output Class Initialized
INFO - 2016-03-08 11:29:47 --> Security Class Initialized
DEBUG - 2016-03-08 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:29:47 --> Input Class Initialized
INFO - 2016-03-08 11:29:47 --> Language Class Initialized
INFO - 2016-03-08 11:29:47 --> Loader Class Initialized
INFO - 2016-03-08 11:29:47 --> Helper loaded: url_helper
INFO - 2016-03-08 11:29:47 --> Helper loaded: file_helper
INFO - 2016-03-08 11:29:47 --> Helper loaded: date_helper
INFO - 2016-03-08 11:29:47 --> Helper loaded: form_helper
INFO - 2016-03-08 11:29:47 --> Database Driver Class Initialized
INFO - 2016-03-08 11:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:29:48 --> Controller Class Initialized
INFO - 2016-03-08 11:29:48 --> Model Class Initialized
INFO - 2016-03-08 11:29:48 --> Model Class Initialized
INFO - 2016-03-08 11:29:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:29:48 --> Pagination Class Initialized
INFO - 2016-03-08 11:29:48 --> Helper loaded: text_helper
INFO - 2016-03-08 11:29:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:29:48 --> Final output sent to browser
DEBUG - 2016-03-08 14:29:48 --> Total execution time: 1.2146
INFO - 2016-03-08 11:30:22 --> Config Class Initialized
INFO - 2016-03-08 11:30:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:30:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:30:22 --> Utf8 Class Initialized
INFO - 2016-03-08 11:30:22 --> URI Class Initialized
INFO - 2016-03-08 11:30:22 --> Router Class Initialized
INFO - 2016-03-08 11:30:22 --> Output Class Initialized
INFO - 2016-03-08 11:30:22 --> Security Class Initialized
DEBUG - 2016-03-08 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:30:22 --> Input Class Initialized
INFO - 2016-03-08 11:30:22 --> Language Class Initialized
INFO - 2016-03-08 11:30:22 --> Loader Class Initialized
INFO - 2016-03-08 11:30:22 --> Helper loaded: url_helper
INFO - 2016-03-08 11:30:22 --> Helper loaded: file_helper
INFO - 2016-03-08 11:30:22 --> Helper loaded: date_helper
INFO - 2016-03-08 11:30:22 --> Helper loaded: form_helper
INFO - 2016-03-08 11:30:22 --> Database Driver Class Initialized
INFO - 2016-03-08 11:30:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:30:23 --> Controller Class Initialized
INFO - 2016-03-08 11:30:23 --> Model Class Initialized
INFO - 2016-03-08 11:30:23 --> Model Class Initialized
INFO - 2016-03-08 11:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:30:23 --> Pagination Class Initialized
INFO - 2016-03-08 11:30:23 --> Helper loaded: text_helper
INFO - 2016-03-08 11:30:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:30:23 --> Final output sent to browser
DEBUG - 2016-03-08 14:30:23 --> Total execution time: 1.1079
INFO - 2016-03-08 11:30:26 --> Config Class Initialized
INFO - 2016-03-08 11:30:26 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:30:26 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:30:26 --> Utf8 Class Initialized
INFO - 2016-03-08 11:30:26 --> URI Class Initialized
INFO - 2016-03-08 11:30:26 --> Router Class Initialized
INFO - 2016-03-08 11:30:26 --> Output Class Initialized
INFO - 2016-03-08 11:30:26 --> Security Class Initialized
DEBUG - 2016-03-08 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:30:26 --> Input Class Initialized
INFO - 2016-03-08 11:30:26 --> Language Class Initialized
INFO - 2016-03-08 11:30:26 --> Loader Class Initialized
INFO - 2016-03-08 11:30:26 --> Helper loaded: url_helper
INFO - 2016-03-08 11:30:26 --> Helper loaded: file_helper
INFO - 2016-03-08 11:30:26 --> Helper loaded: date_helper
INFO - 2016-03-08 11:30:26 --> Helper loaded: form_helper
INFO - 2016-03-08 11:30:26 --> Database Driver Class Initialized
INFO - 2016-03-08 11:30:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:30:27 --> Controller Class Initialized
INFO - 2016-03-08 11:30:27 --> Model Class Initialized
INFO - 2016-03-08 11:30:27 --> Model Class Initialized
INFO - 2016-03-08 11:30:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:30:27 --> Pagination Class Initialized
INFO - 2016-03-08 11:30:27 --> Helper loaded: text_helper
INFO - 2016-03-08 11:30:27 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:30:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:30:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:30:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:30:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:30:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:30:27 --> Final output sent to browser
DEBUG - 2016-03-08 14:30:27 --> Total execution time: 1.1728
INFO - 2016-03-08 11:30:30 --> Config Class Initialized
INFO - 2016-03-08 11:30:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:30:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:30:30 --> Utf8 Class Initialized
INFO - 2016-03-08 11:30:30 --> URI Class Initialized
INFO - 2016-03-08 11:30:30 --> Router Class Initialized
INFO - 2016-03-08 11:30:30 --> Output Class Initialized
INFO - 2016-03-08 11:30:30 --> Security Class Initialized
DEBUG - 2016-03-08 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:30:30 --> Input Class Initialized
INFO - 2016-03-08 11:30:30 --> Language Class Initialized
INFO - 2016-03-08 11:30:30 --> Loader Class Initialized
INFO - 2016-03-08 11:30:30 --> Helper loaded: url_helper
INFO - 2016-03-08 11:30:30 --> Helper loaded: file_helper
INFO - 2016-03-08 11:30:30 --> Helper loaded: date_helper
INFO - 2016-03-08 11:30:30 --> Helper loaded: form_helper
INFO - 2016-03-08 11:30:30 --> Database Driver Class Initialized
INFO - 2016-03-08 11:30:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:30:31 --> Controller Class Initialized
INFO - 2016-03-08 11:30:31 --> Model Class Initialized
INFO - 2016-03-08 11:30:31 --> Model Class Initialized
INFO - 2016-03-08 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:30:31 --> Pagination Class Initialized
INFO - 2016-03-08 11:30:31 --> Helper loaded: text_helper
INFO - 2016-03-08 11:30:31 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:30:31 --> Final output sent to browser
DEBUG - 2016-03-08 14:30:31 --> Total execution time: 1.2457
INFO - 2016-03-08 11:31:11 --> Config Class Initialized
INFO - 2016-03-08 11:31:11 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:31:11 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:31:11 --> Utf8 Class Initialized
INFO - 2016-03-08 11:31:11 --> URI Class Initialized
INFO - 2016-03-08 11:31:11 --> Router Class Initialized
INFO - 2016-03-08 11:31:11 --> Output Class Initialized
INFO - 2016-03-08 11:31:11 --> Security Class Initialized
DEBUG - 2016-03-08 11:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:31:11 --> Input Class Initialized
INFO - 2016-03-08 11:31:11 --> Language Class Initialized
INFO - 2016-03-08 11:31:11 --> Loader Class Initialized
INFO - 2016-03-08 11:31:11 --> Helper loaded: url_helper
INFO - 2016-03-08 11:31:11 --> Helper loaded: file_helper
INFO - 2016-03-08 11:31:11 --> Helper loaded: date_helper
INFO - 2016-03-08 11:31:11 --> Helper loaded: form_helper
INFO - 2016-03-08 11:31:11 --> Database Driver Class Initialized
INFO - 2016-03-08 11:31:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:31:12 --> Controller Class Initialized
INFO - 2016-03-08 11:31:12 --> Model Class Initialized
INFO - 2016-03-08 11:31:12 --> Model Class Initialized
INFO - 2016-03-08 11:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:31:12 --> Pagination Class Initialized
INFO - 2016-03-08 11:31:12 --> Helper loaded: text_helper
INFO - 2016-03-08 11:31:12 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:31:12 --> Final output sent to browser
DEBUG - 2016-03-08 14:31:12 --> Total execution time: 1.1466
INFO - 2016-03-08 11:31:14 --> Config Class Initialized
INFO - 2016-03-08 11:31:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:31:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:31:14 --> Utf8 Class Initialized
INFO - 2016-03-08 11:31:14 --> URI Class Initialized
INFO - 2016-03-08 11:31:14 --> Router Class Initialized
INFO - 2016-03-08 11:31:14 --> Output Class Initialized
INFO - 2016-03-08 11:31:14 --> Security Class Initialized
DEBUG - 2016-03-08 11:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:31:14 --> Input Class Initialized
INFO - 2016-03-08 11:31:14 --> Language Class Initialized
INFO - 2016-03-08 11:31:14 --> Loader Class Initialized
INFO - 2016-03-08 11:31:14 --> Helper loaded: url_helper
INFO - 2016-03-08 11:31:14 --> Helper loaded: file_helper
INFO - 2016-03-08 11:31:14 --> Helper loaded: date_helper
INFO - 2016-03-08 11:31:14 --> Helper loaded: form_helper
INFO - 2016-03-08 11:31:14 --> Database Driver Class Initialized
INFO - 2016-03-08 11:31:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:31:15 --> Controller Class Initialized
INFO - 2016-03-08 11:31:15 --> Model Class Initialized
INFO - 2016-03-08 11:31:15 --> Model Class Initialized
INFO - 2016-03-08 11:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:31:15 --> Pagination Class Initialized
INFO - 2016-03-08 11:31:15 --> Helper loaded: text_helper
INFO - 2016-03-08 11:31:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:31:15 --> Final output sent to browser
DEBUG - 2016-03-08 14:31:15 --> Total execution time: 1.1751
INFO - 2016-03-08 11:31:18 --> Config Class Initialized
INFO - 2016-03-08 11:31:18 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:31:18 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:31:18 --> Utf8 Class Initialized
INFO - 2016-03-08 11:31:18 --> URI Class Initialized
INFO - 2016-03-08 11:31:18 --> Router Class Initialized
INFO - 2016-03-08 11:31:18 --> Output Class Initialized
INFO - 2016-03-08 11:31:18 --> Security Class Initialized
DEBUG - 2016-03-08 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:31:18 --> Input Class Initialized
INFO - 2016-03-08 11:31:18 --> Language Class Initialized
INFO - 2016-03-08 11:31:18 --> Loader Class Initialized
INFO - 2016-03-08 11:31:18 --> Helper loaded: url_helper
INFO - 2016-03-08 11:31:18 --> Helper loaded: file_helper
INFO - 2016-03-08 11:31:18 --> Helper loaded: date_helper
INFO - 2016-03-08 11:31:18 --> Helper loaded: form_helper
INFO - 2016-03-08 11:31:18 --> Database Driver Class Initialized
INFO - 2016-03-08 11:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:31:19 --> Controller Class Initialized
INFO - 2016-03-08 11:31:19 --> Model Class Initialized
INFO - 2016-03-08 11:31:19 --> Model Class Initialized
INFO - 2016-03-08 11:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:31:19 --> Pagination Class Initialized
INFO - 2016-03-08 11:31:19 --> Helper loaded: text_helper
INFO - 2016-03-08 11:31:19 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:31:19 --> Final output sent to browser
DEBUG - 2016-03-08 14:31:19 --> Total execution time: 1.1836
INFO - 2016-03-08 11:31:35 --> Config Class Initialized
INFO - 2016-03-08 11:31:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:31:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:31:35 --> Utf8 Class Initialized
INFO - 2016-03-08 11:31:35 --> URI Class Initialized
INFO - 2016-03-08 11:31:35 --> Router Class Initialized
INFO - 2016-03-08 11:31:35 --> Output Class Initialized
INFO - 2016-03-08 11:31:35 --> Security Class Initialized
DEBUG - 2016-03-08 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:31:35 --> Input Class Initialized
INFO - 2016-03-08 11:31:35 --> Language Class Initialized
INFO - 2016-03-08 11:31:35 --> Loader Class Initialized
INFO - 2016-03-08 11:31:35 --> Helper loaded: url_helper
INFO - 2016-03-08 11:31:35 --> Helper loaded: file_helper
INFO - 2016-03-08 11:31:35 --> Helper loaded: date_helper
INFO - 2016-03-08 11:31:35 --> Helper loaded: form_helper
INFO - 2016-03-08 11:31:35 --> Database Driver Class Initialized
INFO - 2016-03-08 11:31:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:31:36 --> Controller Class Initialized
INFO - 2016-03-08 11:31:36 --> Model Class Initialized
INFO - 2016-03-08 11:31:36 --> Model Class Initialized
INFO - 2016-03-08 11:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:31:36 --> Pagination Class Initialized
INFO - 2016-03-08 11:31:36 --> Helper loaded: text_helper
INFO - 2016-03-08 11:31:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:31:36 --> Final output sent to browser
DEBUG - 2016-03-08 14:31:36 --> Total execution time: 1.1984
INFO - 2016-03-08 11:31:46 --> Config Class Initialized
INFO - 2016-03-08 11:31:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:31:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:31:46 --> Utf8 Class Initialized
INFO - 2016-03-08 11:31:46 --> URI Class Initialized
INFO - 2016-03-08 11:31:46 --> Router Class Initialized
INFO - 2016-03-08 11:31:46 --> Output Class Initialized
INFO - 2016-03-08 11:31:46 --> Security Class Initialized
DEBUG - 2016-03-08 11:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:31:46 --> Input Class Initialized
INFO - 2016-03-08 11:31:46 --> Language Class Initialized
INFO - 2016-03-08 11:31:46 --> Loader Class Initialized
INFO - 2016-03-08 11:31:46 --> Helper loaded: url_helper
INFO - 2016-03-08 11:31:46 --> Helper loaded: file_helper
INFO - 2016-03-08 11:31:46 --> Helper loaded: date_helper
INFO - 2016-03-08 11:31:46 --> Helper loaded: form_helper
INFO - 2016-03-08 11:31:46 --> Database Driver Class Initialized
INFO - 2016-03-08 11:31:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:31:47 --> Controller Class Initialized
INFO - 2016-03-08 11:31:47 --> Model Class Initialized
INFO - 2016-03-08 11:31:47 --> Model Class Initialized
INFO - 2016-03-08 11:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:31:47 --> Pagination Class Initialized
INFO - 2016-03-08 11:31:47 --> Helper loaded: text_helper
INFO - 2016-03-08 11:31:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:31:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:31:47 --> Final output sent to browser
DEBUG - 2016-03-08 14:31:47 --> Total execution time: 1.1963
INFO - 2016-03-08 11:32:47 --> Config Class Initialized
INFO - 2016-03-08 11:32:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:32:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:32:47 --> Utf8 Class Initialized
INFO - 2016-03-08 11:32:47 --> URI Class Initialized
INFO - 2016-03-08 11:32:47 --> Router Class Initialized
INFO - 2016-03-08 11:32:47 --> Output Class Initialized
INFO - 2016-03-08 11:32:47 --> Security Class Initialized
DEBUG - 2016-03-08 11:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:32:47 --> Input Class Initialized
INFO - 2016-03-08 11:32:47 --> Language Class Initialized
INFO - 2016-03-08 11:32:47 --> Loader Class Initialized
INFO - 2016-03-08 11:32:47 --> Helper loaded: url_helper
INFO - 2016-03-08 11:32:47 --> Helper loaded: file_helper
INFO - 2016-03-08 11:32:47 --> Helper loaded: date_helper
INFO - 2016-03-08 11:32:47 --> Helper loaded: form_helper
INFO - 2016-03-08 11:32:47 --> Database Driver Class Initialized
INFO - 2016-03-08 11:32:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:32:48 --> Controller Class Initialized
INFO - 2016-03-08 11:32:48 --> Model Class Initialized
INFO - 2016-03-08 11:32:48 --> Model Class Initialized
INFO - 2016-03-08 11:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:32:48 --> Pagination Class Initialized
INFO - 2016-03-08 11:32:48 --> Helper loaded: text_helper
INFO - 2016-03-08 11:32:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:32:49 --> Final output sent to browser
DEBUG - 2016-03-08 14:32:49 --> Total execution time: 1.2202
INFO - 2016-03-08 11:32:58 --> Config Class Initialized
INFO - 2016-03-08 11:32:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:32:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:32:58 --> Utf8 Class Initialized
INFO - 2016-03-08 11:32:58 --> URI Class Initialized
INFO - 2016-03-08 11:32:58 --> Router Class Initialized
INFO - 2016-03-08 11:32:58 --> Output Class Initialized
INFO - 2016-03-08 11:32:58 --> Security Class Initialized
DEBUG - 2016-03-08 11:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:32:58 --> Input Class Initialized
INFO - 2016-03-08 11:32:58 --> Language Class Initialized
INFO - 2016-03-08 11:32:58 --> Loader Class Initialized
INFO - 2016-03-08 11:32:58 --> Helper loaded: url_helper
INFO - 2016-03-08 11:32:58 --> Helper loaded: file_helper
INFO - 2016-03-08 11:32:58 --> Helper loaded: date_helper
INFO - 2016-03-08 11:32:58 --> Helper loaded: form_helper
INFO - 2016-03-08 11:32:58 --> Database Driver Class Initialized
INFO - 2016-03-08 11:32:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:32:59 --> Controller Class Initialized
INFO - 2016-03-08 11:32:59 --> Model Class Initialized
INFO - 2016-03-08 11:32:59 --> Model Class Initialized
INFO - 2016-03-08 11:32:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:32:59 --> Pagination Class Initialized
INFO - 2016-03-08 11:32:59 --> Helper loaded: text_helper
INFO - 2016-03-08 11:32:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:32:59 --> Final output sent to browser
DEBUG - 2016-03-08 14:32:59 --> Total execution time: 1.1851
INFO - 2016-03-08 11:33:01 --> Config Class Initialized
INFO - 2016-03-08 11:33:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:33:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:33:01 --> Utf8 Class Initialized
INFO - 2016-03-08 11:33:01 --> URI Class Initialized
INFO - 2016-03-08 11:33:01 --> Router Class Initialized
INFO - 2016-03-08 11:33:01 --> Output Class Initialized
INFO - 2016-03-08 11:33:01 --> Security Class Initialized
DEBUG - 2016-03-08 11:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:33:01 --> Input Class Initialized
INFO - 2016-03-08 11:33:01 --> Language Class Initialized
INFO - 2016-03-08 11:33:01 --> Loader Class Initialized
INFO - 2016-03-08 11:33:01 --> Helper loaded: url_helper
INFO - 2016-03-08 11:33:01 --> Helper loaded: file_helper
INFO - 2016-03-08 11:33:01 --> Helper loaded: date_helper
INFO - 2016-03-08 11:33:01 --> Helper loaded: form_helper
INFO - 2016-03-08 11:33:01 --> Database Driver Class Initialized
INFO - 2016-03-08 11:33:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:33:02 --> Controller Class Initialized
INFO - 2016-03-08 11:33:02 --> Model Class Initialized
INFO - 2016-03-08 11:33:02 --> Model Class Initialized
INFO - 2016-03-08 11:33:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:33:02 --> Pagination Class Initialized
INFO - 2016-03-08 11:33:02 --> Helper loaded: text_helper
INFO - 2016-03-08 11:33:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:33:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:33:02 --> Final output sent to browser
DEBUG - 2016-03-08 14:33:02 --> Total execution time: 1.2006
INFO - 2016-03-08 11:35:43 --> Config Class Initialized
INFO - 2016-03-08 11:35:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:35:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:35:43 --> Utf8 Class Initialized
INFO - 2016-03-08 11:35:43 --> URI Class Initialized
INFO - 2016-03-08 11:35:43 --> Router Class Initialized
INFO - 2016-03-08 11:35:43 --> Output Class Initialized
INFO - 2016-03-08 11:35:43 --> Security Class Initialized
DEBUG - 2016-03-08 11:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:35:43 --> Input Class Initialized
INFO - 2016-03-08 11:35:43 --> Language Class Initialized
INFO - 2016-03-08 11:35:43 --> Loader Class Initialized
INFO - 2016-03-08 11:35:43 --> Helper loaded: url_helper
INFO - 2016-03-08 11:35:43 --> Helper loaded: file_helper
INFO - 2016-03-08 11:35:43 --> Helper loaded: date_helper
INFO - 2016-03-08 11:35:43 --> Helper loaded: form_helper
INFO - 2016-03-08 11:35:43 --> Database Driver Class Initialized
INFO - 2016-03-08 11:35:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:35:44 --> Controller Class Initialized
INFO - 2016-03-08 11:35:44 --> Model Class Initialized
INFO - 2016-03-08 11:35:44 --> Model Class Initialized
INFO - 2016-03-08 11:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:35:44 --> Pagination Class Initialized
INFO - 2016-03-08 11:35:44 --> Helper loaded: text_helper
INFO - 2016-03-08 11:35:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 14:35:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-60, 20' at line 4 - Invalid query: SELECT *
FROM `wall`
ORDER BY `id` DESC
 LIMIT -60, 20
INFO - 2016-03-08 14:35:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-08 11:38:12 --> Config Class Initialized
INFO - 2016-03-08 11:38:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:38:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:38:12 --> Utf8 Class Initialized
INFO - 2016-03-08 11:38:12 --> URI Class Initialized
INFO - 2016-03-08 11:38:12 --> Router Class Initialized
INFO - 2016-03-08 11:38:12 --> Output Class Initialized
INFO - 2016-03-08 11:38:12 --> Security Class Initialized
DEBUG - 2016-03-08 11:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:38:12 --> Input Class Initialized
INFO - 2016-03-08 11:38:12 --> Language Class Initialized
INFO - 2016-03-08 11:38:12 --> Loader Class Initialized
INFO - 2016-03-08 11:38:12 --> Helper loaded: url_helper
INFO - 2016-03-08 11:38:12 --> Helper loaded: file_helper
INFO - 2016-03-08 11:38:12 --> Helper loaded: date_helper
INFO - 2016-03-08 11:38:12 --> Helper loaded: form_helper
INFO - 2016-03-08 11:38:12 --> Database Driver Class Initialized
INFO - 2016-03-08 11:38:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:38:13 --> Controller Class Initialized
INFO - 2016-03-08 11:38:13 --> Model Class Initialized
INFO - 2016-03-08 11:38:13 --> Model Class Initialized
INFO - 2016-03-08 11:38:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:38:13 --> Pagination Class Initialized
INFO - 2016-03-08 11:38:13 --> Helper loaded: text_helper
INFO - 2016-03-08 11:38:13 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:38:13 --> Final output sent to browser
DEBUG - 2016-03-08 14:38:13 --> Total execution time: 1.1222
INFO - 2016-03-08 11:38:17 --> Config Class Initialized
INFO - 2016-03-08 11:38:17 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:38:17 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:38:17 --> Utf8 Class Initialized
INFO - 2016-03-08 11:38:17 --> URI Class Initialized
INFO - 2016-03-08 11:38:17 --> Router Class Initialized
INFO - 2016-03-08 11:38:17 --> Output Class Initialized
INFO - 2016-03-08 11:38:17 --> Security Class Initialized
DEBUG - 2016-03-08 11:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:38:17 --> Input Class Initialized
INFO - 2016-03-08 11:38:17 --> Language Class Initialized
INFO - 2016-03-08 11:38:17 --> Loader Class Initialized
INFO - 2016-03-08 11:38:17 --> Helper loaded: url_helper
INFO - 2016-03-08 11:38:17 --> Helper loaded: file_helper
INFO - 2016-03-08 11:38:17 --> Helper loaded: date_helper
INFO - 2016-03-08 11:38:17 --> Helper loaded: form_helper
INFO - 2016-03-08 11:38:17 --> Database Driver Class Initialized
INFO - 2016-03-08 11:38:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:38:19 --> Controller Class Initialized
INFO - 2016-03-08 11:38:19 --> Model Class Initialized
INFO - 2016-03-08 11:38:19 --> Model Class Initialized
INFO - 2016-03-08 11:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:38:19 --> Pagination Class Initialized
INFO - 2016-03-08 11:38:19 --> Helper loaded: text_helper
INFO - 2016-03-08 11:38:19 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:38:19 --> Final output sent to browser
DEBUG - 2016-03-08 14:38:19 --> Total execution time: 1.1301
INFO - 2016-03-08 11:38:22 --> Config Class Initialized
INFO - 2016-03-08 11:38:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:38:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:38:22 --> Utf8 Class Initialized
INFO - 2016-03-08 11:38:22 --> URI Class Initialized
INFO - 2016-03-08 11:38:22 --> Router Class Initialized
INFO - 2016-03-08 11:38:22 --> Output Class Initialized
INFO - 2016-03-08 11:38:22 --> Security Class Initialized
DEBUG - 2016-03-08 11:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:38:22 --> Input Class Initialized
INFO - 2016-03-08 11:38:22 --> Language Class Initialized
INFO - 2016-03-08 11:38:22 --> Loader Class Initialized
INFO - 2016-03-08 11:38:22 --> Helper loaded: url_helper
INFO - 2016-03-08 11:38:22 --> Helper loaded: file_helper
INFO - 2016-03-08 11:38:22 --> Helper loaded: date_helper
INFO - 2016-03-08 11:38:22 --> Helper loaded: form_helper
INFO - 2016-03-08 11:38:22 --> Database Driver Class Initialized
INFO - 2016-03-08 11:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:38:23 --> Controller Class Initialized
INFO - 2016-03-08 11:38:23 --> Model Class Initialized
INFO - 2016-03-08 11:38:23 --> Model Class Initialized
INFO - 2016-03-08 11:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:38:23 --> Pagination Class Initialized
INFO - 2016-03-08 11:38:23 --> Helper loaded: text_helper
INFO - 2016-03-08 11:38:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:38:23 --> Final output sent to browser
DEBUG - 2016-03-08 14:38:23 --> Total execution time: 1.1415
INFO - 2016-03-08 11:38:46 --> Config Class Initialized
INFO - 2016-03-08 11:38:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:38:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:38:46 --> Utf8 Class Initialized
INFO - 2016-03-08 11:38:46 --> URI Class Initialized
INFO - 2016-03-08 11:38:46 --> Router Class Initialized
INFO - 2016-03-08 11:38:46 --> Output Class Initialized
INFO - 2016-03-08 11:38:46 --> Security Class Initialized
DEBUG - 2016-03-08 11:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:38:46 --> Input Class Initialized
INFO - 2016-03-08 11:38:46 --> Language Class Initialized
INFO - 2016-03-08 11:38:46 --> Loader Class Initialized
INFO - 2016-03-08 11:38:46 --> Helper loaded: url_helper
INFO - 2016-03-08 11:38:46 --> Helper loaded: file_helper
INFO - 2016-03-08 11:38:46 --> Helper loaded: date_helper
INFO - 2016-03-08 11:38:46 --> Helper loaded: form_helper
INFO - 2016-03-08 11:38:46 --> Database Driver Class Initialized
INFO - 2016-03-08 11:38:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:38:47 --> Controller Class Initialized
INFO - 2016-03-08 11:38:47 --> Model Class Initialized
INFO - 2016-03-08 11:38:47 --> Model Class Initialized
INFO - 2016-03-08 11:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:38:47 --> Pagination Class Initialized
INFO - 2016-03-08 11:38:47 --> Helper loaded: text_helper
INFO - 2016-03-08 11:38:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:38:47 --> Final output sent to browser
DEBUG - 2016-03-08 14:38:47 --> Total execution time: 1.1212
INFO - 2016-03-08 11:38:52 --> Config Class Initialized
INFO - 2016-03-08 11:38:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:38:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:38:52 --> Utf8 Class Initialized
INFO - 2016-03-08 11:38:52 --> URI Class Initialized
INFO - 2016-03-08 11:38:52 --> Router Class Initialized
INFO - 2016-03-08 11:38:52 --> Output Class Initialized
INFO - 2016-03-08 11:38:52 --> Security Class Initialized
DEBUG - 2016-03-08 11:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:38:52 --> Input Class Initialized
INFO - 2016-03-08 11:38:52 --> Language Class Initialized
INFO - 2016-03-08 11:38:52 --> Loader Class Initialized
INFO - 2016-03-08 11:38:52 --> Helper loaded: url_helper
INFO - 2016-03-08 11:38:52 --> Helper loaded: file_helper
INFO - 2016-03-08 11:38:52 --> Helper loaded: date_helper
INFO - 2016-03-08 11:38:52 --> Helper loaded: form_helper
INFO - 2016-03-08 11:38:52 --> Database Driver Class Initialized
INFO - 2016-03-08 11:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:38:53 --> Controller Class Initialized
INFO - 2016-03-08 11:38:53 --> Model Class Initialized
INFO - 2016-03-08 11:38:53 --> Model Class Initialized
INFO - 2016-03-08 11:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:38:53 --> Pagination Class Initialized
INFO - 2016-03-08 11:38:53 --> Helper loaded: text_helper
INFO - 2016-03-08 11:38:53 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:38:53 --> Final output sent to browser
DEBUG - 2016-03-08 14:38:53 --> Total execution time: 1.1934
INFO - 2016-03-08 11:39:04 --> Config Class Initialized
INFO - 2016-03-08 11:39:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:04 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:04 --> URI Class Initialized
INFO - 2016-03-08 11:39:04 --> Router Class Initialized
INFO - 2016-03-08 11:39:04 --> Output Class Initialized
INFO - 2016-03-08 11:39:04 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:04 --> Input Class Initialized
INFO - 2016-03-08 11:39:04 --> Language Class Initialized
INFO - 2016-03-08 11:39:04 --> Loader Class Initialized
INFO - 2016-03-08 11:39:04 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:04 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:04 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:04 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:04 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:06 --> Controller Class Initialized
INFO - 2016-03-08 11:39:06 --> Model Class Initialized
INFO - 2016-03-08 11:39:06 --> Model Class Initialized
INFO - 2016-03-08 11:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:06 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:06 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:06 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:06 --> Total execution time: 1.1991
INFO - 2016-03-08 11:39:09 --> Config Class Initialized
INFO - 2016-03-08 11:39:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:09 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:09 --> URI Class Initialized
INFO - 2016-03-08 11:39:09 --> Router Class Initialized
INFO - 2016-03-08 11:39:09 --> Output Class Initialized
INFO - 2016-03-08 11:39:09 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:09 --> Input Class Initialized
INFO - 2016-03-08 11:39:09 --> Language Class Initialized
INFO - 2016-03-08 11:39:09 --> Loader Class Initialized
INFO - 2016-03-08 11:39:09 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:09 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:09 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:09 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:09 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:10 --> Controller Class Initialized
INFO - 2016-03-08 11:39:10 --> Model Class Initialized
INFO - 2016-03-08 11:39:10 --> Model Class Initialized
INFO - 2016-03-08 11:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:10 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:10 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:10 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:10 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:10 --> Total execution time: 1.1899
INFO - 2016-03-08 11:39:19 --> Config Class Initialized
INFO - 2016-03-08 11:39:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:19 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:19 --> URI Class Initialized
INFO - 2016-03-08 11:39:19 --> Router Class Initialized
INFO - 2016-03-08 11:39:19 --> Output Class Initialized
INFO - 2016-03-08 11:39:19 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:19 --> Input Class Initialized
INFO - 2016-03-08 11:39:19 --> Language Class Initialized
INFO - 2016-03-08 11:39:19 --> Loader Class Initialized
INFO - 2016-03-08 11:39:19 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:19 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:19 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:19 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:19 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:20 --> Controller Class Initialized
INFO - 2016-03-08 11:39:20 --> Model Class Initialized
INFO - 2016-03-08 11:39:20 --> Model Class Initialized
INFO - 2016-03-08 11:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:20 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:20 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:39:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:39:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:20 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:21 --> Total execution time: 1.1898
INFO - 2016-03-08 11:39:23 --> Config Class Initialized
INFO - 2016-03-08 11:39:23 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:23 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:23 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:23 --> URI Class Initialized
INFO - 2016-03-08 11:39:23 --> Router Class Initialized
INFO - 2016-03-08 11:39:23 --> Output Class Initialized
INFO - 2016-03-08 11:39:23 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:23 --> Input Class Initialized
INFO - 2016-03-08 11:39:23 --> Language Class Initialized
INFO - 2016-03-08 11:39:23 --> Loader Class Initialized
INFO - 2016-03-08 11:39:23 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:23 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:23 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:23 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:23 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:24 --> Controller Class Initialized
INFO - 2016-03-08 11:39:24 --> Model Class Initialized
INFO - 2016-03-08 11:39:24 --> Model Class Initialized
INFO - 2016-03-08 11:39:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:24 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:24 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:24 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:39:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:39:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:24 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:24 --> Total execution time: 1.1959
INFO - 2016-03-08 11:39:26 --> Config Class Initialized
INFO - 2016-03-08 11:39:26 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:26 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:26 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:26 --> URI Class Initialized
INFO - 2016-03-08 11:39:26 --> Router Class Initialized
INFO - 2016-03-08 11:39:26 --> Output Class Initialized
INFO - 2016-03-08 11:39:26 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:26 --> Input Class Initialized
INFO - 2016-03-08 11:39:26 --> Language Class Initialized
INFO - 2016-03-08 11:39:26 --> Loader Class Initialized
INFO - 2016-03-08 11:39:26 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:26 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:26 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:26 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:26 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:27 --> Controller Class Initialized
INFO - 2016-03-08 11:39:27 --> Model Class Initialized
INFO - 2016-03-08 11:39:27 --> Model Class Initialized
INFO - 2016-03-08 11:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:27 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:27 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:27 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:27 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:27 --> Total execution time: 1.2372
INFO - 2016-03-08 11:39:33 --> Config Class Initialized
INFO - 2016-03-08 11:39:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:33 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:33 --> URI Class Initialized
INFO - 2016-03-08 11:39:33 --> Router Class Initialized
INFO - 2016-03-08 11:39:33 --> Output Class Initialized
INFO - 2016-03-08 11:39:33 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:33 --> Input Class Initialized
INFO - 2016-03-08 11:39:33 --> Language Class Initialized
INFO - 2016-03-08 11:39:33 --> Loader Class Initialized
INFO - 2016-03-08 11:39:33 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:33 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:33 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:33 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:33 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:34 --> Controller Class Initialized
INFO - 2016-03-08 11:39:34 --> Model Class Initialized
INFO - 2016-03-08 11:39:34 --> Model Class Initialized
INFO - 2016-03-08 11:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:34 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:34 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:34 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:34 --> Total execution time: 1.1292
INFO - 2016-03-08 11:39:36 --> Config Class Initialized
INFO - 2016-03-08 11:39:36 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:36 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:36 --> URI Class Initialized
INFO - 2016-03-08 11:39:36 --> Router Class Initialized
INFO - 2016-03-08 11:39:36 --> Output Class Initialized
INFO - 2016-03-08 11:39:36 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:36 --> Input Class Initialized
INFO - 2016-03-08 11:39:36 --> Language Class Initialized
INFO - 2016-03-08 11:39:36 --> Loader Class Initialized
INFO - 2016-03-08 11:39:36 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:36 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:36 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:36 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:36 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:37 --> Controller Class Initialized
INFO - 2016-03-08 11:39:37 --> Model Class Initialized
INFO - 2016-03-08 11:39:37 --> Model Class Initialized
INFO - 2016-03-08 11:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:37 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:37 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:37 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:37 --> Total execution time: 1.1153
INFO - 2016-03-08 11:39:39 --> Config Class Initialized
INFO - 2016-03-08 11:39:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:39:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:39:39 --> Utf8 Class Initialized
INFO - 2016-03-08 11:39:39 --> URI Class Initialized
INFO - 2016-03-08 11:39:39 --> Router Class Initialized
INFO - 2016-03-08 11:39:39 --> Output Class Initialized
INFO - 2016-03-08 11:39:39 --> Security Class Initialized
DEBUG - 2016-03-08 11:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:39:39 --> Input Class Initialized
INFO - 2016-03-08 11:39:39 --> Language Class Initialized
INFO - 2016-03-08 11:39:39 --> Loader Class Initialized
INFO - 2016-03-08 11:39:39 --> Helper loaded: url_helper
INFO - 2016-03-08 11:39:39 --> Helper loaded: file_helper
INFO - 2016-03-08 11:39:39 --> Helper loaded: date_helper
INFO - 2016-03-08 11:39:39 --> Helper loaded: form_helper
INFO - 2016-03-08 11:39:39 --> Database Driver Class Initialized
INFO - 2016-03-08 11:39:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:39:40 --> Controller Class Initialized
INFO - 2016-03-08 11:39:40 --> Model Class Initialized
INFO - 2016-03-08 11:39:40 --> Model Class Initialized
INFO - 2016-03-08 11:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:39:40 --> Pagination Class Initialized
INFO - 2016-03-08 11:39:40 --> Helper loaded: text_helper
INFO - 2016-03-08 11:39:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:39:40 --> Final output sent to browser
DEBUG - 2016-03-08 14:39:40 --> Total execution time: 1.2623
INFO - 2016-03-08 11:43:00 --> Config Class Initialized
INFO - 2016-03-08 11:43:00 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:43:00 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:43:00 --> Utf8 Class Initialized
INFO - 2016-03-08 11:43:00 --> URI Class Initialized
INFO - 2016-03-08 11:43:00 --> Router Class Initialized
INFO - 2016-03-08 11:43:00 --> Output Class Initialized
INFO - 2016-03-08 11:43:00 --> Security Class Initialized
DEBUG - 2016-03-08 11:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:43:00 --> Input Class Initialized
INFO - 2016-03-08 11:43:00 --> Language Class Initialized
INFO - 2016-03-08 11:43:00 --> Loader Class Initialized
INFO - 2016-03-08 11:43:00 --> Helper loaded: url_helper
INFO - 2016-03-08 11:43:00 --> Helper loaded: file_helper
INFO - 2016-03-08 11:43:00 --> Helper loaded: date_helper
INFO - 2016-03-08 11:43:00 --> Helper loaded: form_helper
INFO - 2016-03-08 11:43:00 --> Database Driver Class Initialized
INFO - 2016-03-08 11:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:43:01 --> Controller Class Initialized
INFO - 2016-03-08 11:43:01 --> Model Class Initialized
INFO - 2016-03-08 11:43:01 --> Model Class Initialized
INFO - 2016-03-08 11:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:43:01 --> Pagination Class Initialized
INFO - 2016-03-08 11:43:01 --> Helper loaded: text_helper
INFO - 2016-03-08 11:43:01 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:43:01 --> Final output sent to browser
DEBUG - 2016-03-08 14:43:01 --> Total execution time: 1.1478
INFO - 2016-03-08 11:43:04 --> Config Class Initialized
INFO - 2016-03-08 11:43:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:43:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:43:04 --> Utf8 Class Initialized
INFO - 2016-03-08 11:43:04 --> URI Class Initialized
INFO - 2016-03-08 11:43:04 --> Router Class Initialized
INFO - 2016-03-08 11:43:04 --> Output Class Initialized
INFO - 2016-03-08 11:43:04 --> Security Class Initialized
DEBUG - 2016-03-08 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:43:04 --> Input Class Initialized
INFO - 2016-03-08 11:43:04 --> Language Class Initialized
INFO - 2016-03-08 11:43:04 --> Loader Class Initialized
INFO - 2016-03-08 11:43:04 --> Helper loaded: url_helper
INFO - 2016-03-08 11:43:04 --> Helper loaded: file_helper
INFO - 2016-03-08 11:43:04 --> Helper loaded: date_helper
INFO - 2016-03-08 11:43:04 --> Helper loaded: form_helper
INFO - 2016-03-08 11:43:04 --> Database Driver Class Initialized
INFO - 2016-03-08 11:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:43:05 --> Controller Class Initialized
INFO - 2016-03-08 11:43:05 --> Model Class Initialized
INFO - 2016-03-08 11:43:05 --> Model Class Initialized
INFO - 2016-03-08 11:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:43:05 --> Pagination Class Initialized
INFO - 2016-03-08 11:43:05 --> Helper loaded: text_helper
INFO - 2016-03-08 11:43:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:43:05 --> Final output sent to browser
DEBUG - 2016-03-08 14:43:05 --> Total execution time: 1.1281
INFO - 2016-03-08 11:43:07 --> Config Class Initialized
INFO - 2016-03-08 11:43:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:43:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:43:07 --> Utf8 Class Initialized
INFO - 2016-03-08 11:43:07 --> URI Class Initialized
INFO - 2016-03-08 11:43:07 --> Router Class Initialized
INFO - 2016-03-08 11:43:07 --> Output Class Initialized
INFO - 2016-03-08 11:43:07 --> Security Class Initialized
DEBUG - 2016-03-08 11:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:43:07 --> Input Class Initialized
INFO - 2016-03-08 11:43:07 --> Language Class Initialized
INFO - 2016-03-08 11:43:07 --> Loader Class Initialized
INFO - 2016-03-08 11:43:07 --> Helper loaded: url_helper
INFO - 2016-03-08 11:43:07 --> Helper loaded: file_helper
INFO - 2016-03-08 11:43:07 --> Helper loaded: date_helper
INFO - 2016-03-08 11:43:07 --> Helper loaded: form_helper
INFO - 2016-03-08 11:43:07 --> Database Driver Class Initialized
INFO - 2016-03-08 11:43:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:43:08 --> Controller Class Initialized
INFO - 2016-03-08 11:43:08 --> Model Class Initialized
INFO - 2016-03-08 11:43:08 --> Model Class Initialized
INFO - 2016-03-08 11:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:43:08 --> Pagination Class Initialized
INFO - 2016-03-08 11:43:08 --> Helper loaded: text_helper
INFO - 2016-03-08 11:43:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:43:08 --> Final output sent to browser
DEBUG - 2016-03-08 14:43:08 --> Total execution time: 1.1909
INFO - 2016-03-08 11:43:20 --> Config Class Initialized
INFO - 2016-03-08 11:43:20 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:43:20 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:43:20 --> Utf8 Class Initialized
INFO - 2016-03-08 11:43:20 --> URI Class Initialized
INFO - 2016-03-08 11:43:20 --> Router Class Initialized
INFO - 2016-03-08 11:43:20 --> Output Class Initialized
INFO - 2016-03-08 11:43:20 --> Security Class Initialized
DEBUG - 2016-03-08 11:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:43:20 --> Input Class Initialized
INFO - 2016-03-08 11:43:20 --> Language Class Initialized
INFO - 2016-03-08 11:43:20 --> Loader Class Initialized
INFO - 2016-03-08 11:43:20 --> Helper loaded: url_helper
INFO - 2016-03-08 11:43:20 --> Helper loaded: file_helper
INFO - 2016-03-08 11:43:20 --> Helper loaded: date_helper
INFO - 2016-03-08 11:43:20 --> Helper loaded: form_helper
INFO - 2016-03-08 11:43:20 --> Database Driver Class Initialized
INFO - 2016-03-08 11:43:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:43:21 --> Controller Class Initialized
INFO - 2016-03-08 11:43:21 --> Model Class Initialized
INFO - 2016-03-08 11:43:21 --> Model Class Initialized
INFO - 2016-03-08 11:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:43:21 --> Pagination Class Initialized
INFO - 2016-03-08 11:43:21 --> Helper loaded: text_helper
INFO - 2016-03-08 11:43:21 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:43:21 --> Final output sent to browser
DEBUG - 2016-03-08 14:43:21 --> Total execution time: 1.1240
INFO - 2016-03-08 11:44:58 --> Config Class Initialized
INFO - 2016-03-08 11:44:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:44:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:44:58 --> Utf8 Class Initialized
INFO - 2016-03-08 11:44:58 --> URI Class Initialized
INFO - 2016-03-08 11:44:58 --> Router Class Initialized
INFO - 2016-03-08 11:44:58 --> Output Class Initialized
INFO - 2016-03-08 11:44:58 --> Security Class Initialized
DEBUG - 2016-03-08 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:44:58 --> Input Class Initialized
INFO - 2016-03-08 11:44:58 --> Language Class Initialized
INFO - 2016-03-08 11:44:58 --> Loader Class Initialized
INFO - 2016-03-08 11:44:58 --> Helper loaded: url_helper
INFO - 2016-03-08 11:44:58 --> Helper loaded: file_helper
INFO - 2016-03-08 11:44:58 --> Helper loaded: date_helper
INFO - 2016-03-08 11:44:58 --> Helper loaded: form_helper
INFO - 2016-03-08 11:44:58 --> Database Driver Class Initialized
INFO - 2016-03-08 11:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:44:59 --> Controller Class Initialized
INFO - 2016-03-08 11:44:59 --> Model Class Initialized
INFO - 2016-03-08 11:44:59 --> Model Class Initialized
INFO - 2016-03-08 11:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:44:59 --> Pagination Class Initialized
INFO - 2016-03-08 11:44:59 --> Helper loaded: text_helper
INFO - 2016-03-08 11:44:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:44:59 --> Final output sent to browser
DEBUG - 2016-03-08 14:44:59 --> Total execution time: 1.1258
INFO - 2016-03-08 11:45:01 --> Config Class Initialized
INFO - 2016-03-08 11:45:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:45:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:45:01 --> Utf8 Class Initialized
INFO - 2016-03-08 11:45:01 --> URI Class Initialized
INFO - 2016-03-08 11:45:01 --> Router Class Initialized
INFO - 2016-03-08 11:45:01 --> Output Class Initialized
INFO - 2016-03-08 11:45:01 --> Security Class Initialized
DEBUG - 2016-03-08 11:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:45:01 --> Input Class Initialized
INFO - 2016-03-08 11:45:01 --> Language Class Initialized
INFO - 2016-03-08 11:45:01 --> Loader Class Initialized
INFO - 2016-03-08 11:45:01 --> Helper loaded: url_helper
INFO - 2016-03-08 11:45:01 --> Helper loaded: file_helper
INFO - 2016-03-08 11:45:01 --> Helper loaded: date_helper
INFO - 2016-03-08 11:45:01 --> Helper loaded: form_helper
INFO - 2016-03-08 11:45:01 --> Database Driver Class Initialized
INFO - 2016-03-08 11:45:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:45:02 --> Controller Class Initialized
INFO - 2016-03-08 11:45:02 --> Model Class Initialized
INFO - 2016-03-08 11:45:02 --> Model Class Initialized
INFO - 2016-03-08 11:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:45:02 --> Pagination Class Initialized
INFO - 2016-03-08 11:45:02 --> Helper loaded: text_helper
INFO - 2016-03-08 11:45:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:45:02 --> Final output sent to browser
DEBUG - 2016-03-08 14:45:02 --> Total execution time: 1.1358
INFO - 2016-03-08 11:45:05 --> Config Class Initialized
INFO - 2016-03-08 11:45:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:45:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:45:05 --> Utf8 Class Initialized
INFO - 2016-03-08 11:45:05 --> URI Class Initialized
INFO - 2016-03-08 11:45:05 --> Router Class Initialized
INFO - 2016-03-08 11:45:05 --> Output Class Initialized
INFO - 2016-03-08 11:45:05 --> Security Class Initialized
DEBUG - 2016-03-08 11:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:45:05 --> Input Class Initialized
INFO - 2016-03-08 11:45:05 --> Language Class Initialized
INFO - 2016-03-08 11:45:05 --> Loader Class Initialized
INFO - 2016-03-08 11:45:05 --> Helper loaded: url_helper
INFO - 2016-03-08 11:45:05 --> Helper loaded: file_helper
INFO - 2016-03-08 11:45:05 --> Helper loaded: date_helper
INFO - 2016-03-08 11:45:05 --> Helper loaded: form_helper
INFO - 2016-03-08 11:45:05 --> Database Driver Class Initialized
INFO - 2016-03-08 11:45:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:45:06 --> Controller Class Initialized
INFO - 2016-03-08 11:45:06 --> Model Class Initialized
INFO - 2016-03-08 11:45:06 --> Model Class Initialized
INFO - 2016-03-08 11:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:45:06 --> Pagination Class Initialized
INFO - 2016-03-08 11:45:06 --> Helper loaded: text_helper
INFO - 2016-03-08 11:45:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:45:06 --> Final output sent to browser
DEBUG - 2016-03-08 14:45:06 --> Total execution time: 1.1641
INFO - 2016-03-08 11:45:35 --> Config Class Initialized
INFO - 2016-03-08 11:45:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:45:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:45:35 --> Utf8 Class Initialized
INFO - 2016-03-08 11:45:35 --> URI Class Initialized
INFO - 2016-03-08 11:45:35 --> Router Class Initialized
INFO - 2016-03-08 11:45:35 --> Output Class Initialized
INFO - 2016-03-08 11:45:35 --> Security Class Initialized
DEBUG - 2016-03-08 11:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:45:35 --> Input Class Initialized
INFO - 2016-03-08 11:45:35 --> Language Class Initialized
INFO - 2016-03-08 11:45:35 --> Loader Class Initialized
INFO - 2016-03-08 11:45:35 --> Helper loaded: url_helper
INFO - 2016-03-08 11:45:35 --> Helper loaded: file_helper
INFO - 2016-03-08 11:45:35 --> Helper loaded: date_helper
INFO - 2016-03-08 11:45:35 --> Helper loaded: form_helper
INFO - 2016-03-08 11:45:35 --> Database Driver Class Initialized
INFO - 2016-03-08 11:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:45:36 --> Controller Class Initialized
INFO - 2016-03-08 11:45:36 --> Model Class Initialized
INFO - 2016-03-08 11:45:36 --> Model Class Initialized
INFO - 2016-03-08 11:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:45:36 --> Pagination Class Initialized
INFO - 2016-03-08 11:45:36 --> Helper loaded: text_helper
INFO - 2016-03-08 11:45:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:45:36 --> Final output sent to browser
DEBUG - 2016-03-08 14:45:36 --> Total execution time: 1.1251
INFO - 2016-03-08 11:45:42 --> Config Class Initialized
INFO - 2016-03-08 11:45:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:45:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:45:42 --> Utf8 Class Initialized
INFO - 2016-03-08 11:45:42 --> URI Class Initialized
INFO - 2016-03-08 11:45:42 --> Router Class Initialized
INFO - 2016-03-08 11:45:42 --> Output Class Initialized
INFO - 2016-03-08 11:45:42 --> Security Class Initialized
DEBUG - 2016-03-08 11:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:45:42 --> Input Class Initialized
INFO - 2016-03-08 11:45:42 --> Language Class Initialized
INFO - 2016-03-08 11:45:42 --> Loader Class Initialized
INFO - 2016-03-08 11:45:42 --> Helper loaded: url_helper
INFO - 2016-03-08 11:45:42 --> Helper loaded: file_helper
INFO - 2016-03-08 11:45:42 --> Helper loaded: date_helper
INFO - 2016-03-08 11:45:42 --> Helper loaded: form_helper
INFO - 2016-03-08 11:45:42 --> Database Driver Class Initialized
INFO - 2016-03-08 11:45:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:45:43 --> Controller Class Initialized
INFO - 2016-03-08 11:45:43 --> Model Class Initialized
INFO - 2016-03-08 11:45:43 --> Model Class Initialized
INFO - 2016-03-08 11:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:45:43 --> Pagination Class Initialized
INFO - 2016-03-08 11:45:43 --> Helper loaded: text_helper
INFO - 2016-03-08 11:45:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:45:43 --> Final output sent to browser
DEBUG - 2016-03-08 14:45:43 --> Total execution time: 1.1173
INFO - 2016-03-08 11:45:57 --> Config Class Initialized
INFO - 2016-03-08 11:45:57 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:45:57 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:45:57 --> Utf8 Class Initialized
INFO - 2016-03-08 11:45:57 --> URI Class Initialized
INFO - 2016-03-08 11:45:57 --> Router Class Initialized
INFO - 2016-03-08 11:45:57 --> Output Class Initialized
INFO - 2016-03-08 11:45:57 --> Security Class Initialized
DEBUG - 2016-03-08 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:45:57 --> Input Class Initialized
INFO - 2016-03-08 11:45:57 --> Language Class Initialized
INFO - 2016-03-08 11:45:57 --> Loader Class Initialized
INFO - 2016-03-08 11:45:57 --> Helper loaded: url_helper
INFO - 2016-03-08 11:45:57 --> Helper loaded: file_helper
INFO - 2016-03-08 11:45:57 --> Helper loaded: date_helper
INFO - 2016-03-08 11:45:57 --> Helper loaded: form_helper
INFO - 2016-03-08 11:45:57 --> Database Driver Class Initialized
INFO - 2016-03-08 11:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:45:58 --> Controller Class Initialized
INFO - 2016-03-08 11:45:58 --> Model Class Initialized
INFO - 2016-03-08 11:45:58 --> Model Class Initialized
INFO - 2016-03-08 11:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:45:58 --> Pagination Class Initialized
INFO - 2016-03-08 11:45:58 --> Helper loaded: text_helper
INFO - 2016-03-08 11:45:58 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:45:58 --> Final output sent to browser
DEBUG - 2016-03-08 14:45:58 --> Total execution time: 1.1924
INFO - 2016-03-08 11:46:14 --> Config Class Initialized
INFO - 2016-03-08 11:46:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:46:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:46:14 --> Utf8 Class Initialized
INFO - 2016-03-08 11:46:14 --> URI Class Initialized
INFO - 2016-03-08 11:46:14 --> Router Class Initialized
INFO - 2016-03-08 11:46:14 --> Output Class Initialized
INFO - 2016-03-08 11:46:14 --> Security Class Initialized
DEBUG - 2016-03-08 11:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:46:14 --> Input Class Initialized
INFO - 2016-03-08 11:46:14 --> Language Class Initialized
INFO - 2016-03-08 11:46:14 --> Loader Class Initialized
INFO - 2016-03-08 11:46:14 --> Helper loaded: url_helper
INFO - 2016-03-08 11:46:14 --> Helper loaded: file_helper
INFO - 2016-03-08 11:46:14 --> Helper loaded: date_helper
INFO - 2016-03-08 11:46:14 --> Helper loaded: form_helper
INFO - 2016-03-08 11:46:14 --> Database Driver Class Initialized
INFO - 2016-03-08 11:46:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:46:15 --> Controller Class Initialized
INFO - 2016-03-08 11:46:15 --> Model Class Initialized
INFO - 2016-03-08 11:46:15 --> Model Class Initialized
INFO - 2016-03-08 11:46:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:46:15 --> Pagination Class Initialized
INFO - 2016-03-08 11:46:15 --> Helper loaded: text_helper
INFO - 2016-03-08 11:46:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:46:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:46:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:46:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:46:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:46:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:46:15 --> Final output sent to browser
DEBUG - 2016-03-08 14:46:15 --> Total execution time: 1.1769
INFO - 2016-03-08 11:46:17 --> Config Class Initialized
INFO - 2016-03-08 11:46:17 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:46:17 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:46:17 --> Utf8 Class Initialized
INFO - 2016-03-08 11:46:17 --> URI Class Initialized
INFO - 2016-03-08 11:46:17 --> Router Class Initialized
INFO - 2016-03-08 11:46:17 --> Output Class Initialized
INFO - 2016-03-08 11:46:17 --> Security Class Initialized
DEBUG - 2016-03-08 11:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:46:17 --> Input Class Initialized
INFO - 2016-03-08 11:46:17 --> Language Class Initialized
INFO - 2016-03-08 11:46:17 --> Loader Class Initialized
INFO - 2016-03-08 11:46:17 --> Helper loaded: url_helper
INFO - 2016-03-08 11:46:17 --> Helper loaded: file_helper
INFO - 2016-03-08 11:46:17 --> Helper loaded: date_helper
INFO - 2016-03-08 11:46:17 --> Helper loaded: form_helper
INFO - 2016-03-08 11:46:17 --> Database Driver Class Initialized
INFO - 2016-03-08 11:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:46:18 --> Controller Class Initialized
INFO - 2016-03-08 11:46:18 --> Model Class Initialized
INFO - 2016-03-08 11:46:18 --> Model Class Initialized
INFO - 2016-03-08 11:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:46:18 --> Pagination Class Initialized
INFO - 2016-03-08 11:46:18 --> Helper loaded: text_helper
INFO - 2016-03-08 11:46:18 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:46:18 --> Final output sent to browser
DEBUG - 2016-03-08 14:46:18 --> Total execution time: 1.1104
INFO - 2016-03-08 11:47:04 --> Config Class Initialized
INFO - 2016-03-08 11:47:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:47:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:47:04 --> Utf8 Class Initialized
INFO - 2016-03-08 11:47:04 --> URI Class Initialized
INFO - 2016-03-08 11:47:04 --> Router Class Initialized
INFO - 2016-03-08 11:47:04 --> Output Class Initialized
INFO - 2016-03-08 11:47:04 --> Security Class Initialized
DEBUG - 2016-03-08 11:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:47:04 --> Input Class Initialized
INFO - 2016-03-08 11:47:04 --> Language Class Initialized
INFO - 2016-03-08 11:47:04 --> Loader Class Initialized
INFO - 2016-03-08 11:47:04 --> Helper loaded: url_helper
INFO - 2016-03-08 11:47:04 --> Helper loaded: file_helper
INFO - 2016-03-08 11:47:04 --> Helper loaded: date_helper
INFO - 2016-03-08 11:47:04 --> Helper loaded: form_helper
INFO - 2016-03-08 11:47:04 --> Database Driver Class Initialized
INFO - 2016-03-08 11:47:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:47:05 --> Controller Class Initialized
INFO - 2016-03-08 11:47:05 --> Model Class Initialized
INFO - 2016-03-08 11:47:05 --> Model Class Initialized
INFO - 2016-03-08 11:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:47:05 --> Pagination Class Initialized
INFO - 2016-03-08 11:47:05 --> Helper loaded: text_helper
INFO - 2016-03-08 11:47:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:47:05 --> Final output sent to browser
DEBUG - 2016-03-08 14:47:05 --> Total execution time: 1.1131
INFO - 2016-03-08 11:47:08 --> Config Class Initialized
INFO - 2016-03-08 11:47:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:47:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:47:08 --> Utf8 Class Initialized
INFO - 2016-03-08 11:47:08 --> URI Class Initialized
INFO - 2016-03-08 11:47:08 --> Router Class Initialized
INFO - 2016-03-08 11:47:08 --> Output Class Initialized
INFO - 2016-03-08 11:47:08 --> Security Class Initialized
DEBUG - 2016-03-08 11:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:47:08 --> Input Class Initialized
INFO - 2016-03-08 11:47:08 --> Language Class Initialized
INFO - 2016-03-08 11:47:08 --> Loader Class Initialized
INFO - 2016-03-08 11:47:08 --> Helper loaded: url_helper
INFO - 2016-03-08 11:47:08 --> Helper loaded: file_helper
INFO - 2016-03-08 11:47:08 --> Helper loaded: date_helper
INFO - 2016-03-08 11:47:08 --> Helper loaded: form_helper
INFO - 2016-03-08 11:47:08 --> Database Driver Class Initialized
INFO - 2016-03-08 11:47:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:47:09 --> Controller Class Initialized
INFO - 2016-03-08 11:47:09 --> Model Class Initialized
INFO - 2016-03-08 11:47:09 --> Model Class Initialized
INFO - 2016-03-08 11:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:47:09 --> Pagination Class Initialized
INFO - 2016-03-08 11:47:09 --> Helper loaded: text_helper
INFO - 2016-03-08 11:47:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:47:10 --> Final output sent to browser
DEBUG - 2016-03-08 14:47:10 --> Total execution time: 1.2250
INFO - 2016-03-08 11:49:25 --> Config Class Initialized
INFO - 2016-03-08 11:49:25 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:49:25 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:49:25 --> Utf8 Class Initialized
INFO - 2016-03-08 11:49:25 --> URI Class Initialized
INFO - 2016-03-08 11:49:25 --> Router Class Initialized
INFO - 2016-03-08 11:49:25 --> Output Class Initialized
INFO - 2016-03-08 11:49:25 --> Security Class Initialized
DEBUG - 2016-03-08 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:49:25 --> Input Class Initialized
INFO - 2016-03-08 11:49:25 --> Language Class Initialized
INFO - 2016-03-08 11:49:25 --> Loader Class Initialized
INFO - 2016-03-08 11:49:25 --> Helper loaded: url_helper
INFO - 2016-03-08 11:49:25 --> Helper loaded: file_helper
INFO - 2016-03-08 11:49:25 --> Helper loaded: date_helper
INFO - 2016-03-08 11:49:25 --> Helper loaded: form_helper
INFO - 2016-03-08 11:49:25 --> Database Driver Class Initialized
INFO - 2016-03-08 11:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:49:26 --> Controller Class Initialized
INFO - 2016-03-08 11:49:26 --> Model Class Initialized
INFO - 2016-03-08 11:49:26 --> Model Class Initialized
INFO - 2016-03-08 11:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:49:26 --> Pagination Class Initialized
INFO - 2016-03-08 11:49:26 --> Helper loaded: text_helper
INFO - 2016-03-08 11:49:26 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:49:26 --> Final output sent to browser
DEBUG - 2016-03-08 14:49:26 --> Total execution time: 1.1281
INFO - 2016-03-08 11:49:29 --> Config Class Initialized
INFO - 2016-03-08 11:49:29 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:49:29 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:49:29 --> Utf8 Class Initialized
INFO - 2016-03-08 11:49:29 --> URI Class Initialized
INFO - 2016-03-08 11:49:29 --> Router Class Initialized
INFO - 2016-03-08 11:49:29 --> Output Class Initialized
INFO - 2016-03-08 11:49:29 --> Security Class Initialized
DEBUG - 2016-03-08 11:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:49:29 --> Input Class Initialized
INFO - 2016-03-08 11:49:29 --> Language Class Initialized
INFO - 2016-03-08 11:49:29 --> Loader Class Initialized
INFO - 2016-03-08 11:49:29 --> Helper loaded: url_helper
INFO - 2016-03-08 11:49:29 --> Helper loaded: file_helper
INFO - 2016-03-08 11:49:29 --> Helper loaded: date_helper
INFO - 2016-03-08 11:49:29 --> Helper loaded: form_helper
INFO - 2016-03-08 11:49:29 --> Database Driver Class Initialized
INFO - 2016-03-08 11:49:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:49:30 --> Controller Class Initialized
INFO - 2016-03-08 11:49:30 --> Model Class Initialized
INFO - 2016-03-08 11:49:30 --> Model Class Initialized
INFO - 2016-03-08 11:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:49:30 --> Pagination Class Initialized
INFO - 2016-03-08 11:49:30 --> Helper loaded: text_helper
INFO - 2016-03-08 11:49:30 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:49:30 --> Final output sent to browser
DEBUG - 2016-03-08 14:49:30 --> Total execution time: 1.1535
INFO - 2016-03-08 11:49:31 --> Config Class Initialized
INFO - 2016-03-08 11:49:31 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:49:31 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:49:31 --> Utf8 Class Initialized
INFO - 2016-03-08 11:49:31 --> URI Class Initialized
INFO - 2016-03-08 11:49:31 --> Router Class Initialized
INFO - 2016-03-08 11:49:31 --> Output Class Initialized
INFO - 2016-03-08 11:49:31 --> Security Class Initialized
DEBUG - 2016-03-08 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:49:31 --> Input Class Initialized
INFO - 2016-03-08 11:49:31 --> Language Class Initialized
INFO - 2016-03-08 11:49:31 --> Loader Class Initialized
INFO - 2016-03-08 11:49:31 --> Helper loaded: url_helper
INFO - 2016-03-08 11:49:31 --> Helper loaded: file_helper
INFO - 2016-03-08 11:49:31 --> Helper loaded: date_helper
INFO - 2016-03-08 11:49:31 --> Helper loaded: form_helper
INFO - 2016-03-08 11:49:31 --> Database Driver Class Initialized
INFO - 2016-03-08 11:49:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:49:32 --> Controller Class Initialized
INFO - 2016-03-08 11:49:32 --> Model Class Initialized
INFO - 2016-03-08 11:49:32 --> Model Class Initialized
INFO - 2016-03-08 11:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:49:32 --> Pagination Class Initialized
INFO - 2016-03-08 11:49:32 --> Helper loaded: text_helper
INFO - 2016-03-08 11:49:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:49:33 --> Final output sent to browser
DEBUG - 2016-03-08 14:49:33 --> Total execution time: 1.2087
INFO - 2016-03-08 11:50:12 --> Config Class Initialized
INFO - 2016-03-08 11:50:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:50:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:50:12 --> Utf8 Class Initialized
INFO - 2016-03-08 11:50:12 --> URI Class Initialized
INFO - 2016-03-08 11:50:12 --> Router Class Initialized
INFO - 2016-03-08 11:50:12 --> Output Class Initialized
INFO - 2016-03-08 11:50:12 --> Security Class Initialized
DEBUG - 2016-03-08 11:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:50:12 --> Input Class Initialized
INFO - 2016-03-08 11:50:12 --> Language Class Initialized
INFO - 2016-03-08 11:50:12 --> Loader Class Initialized
INFO - 2016-03-08 11:50:12 --> Helper loaded: url_helper
INFO - 2016-03-08 11:50:12 --> Helper loaded: file_helper
INFO - 2016-03-08 11:50:12 --> Helper loaded: date_helper
INFO - 2016-03-08 11:50:12 --> Helper loaded: form_helper
INFO - 2016-03-08 11:50:12 --> Database Driver Class Initialized
INFO - 2016-03-08 11:50:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:50:13 --> Controller Class Initialized
INFO - 2016-03-08 11:50:13 --> Model Class Initialized
INFO - 2016-03-08 11:50:13 --> Model Class Initialized
INFO - 2016-03-08 11:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:50:13 --> Pagination Class Initialized
INFO - 2016-03-08 11:50:13 --> Helper loaded: text_helper
INFO - 2016-03-08 11:50:13 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:50:13 --> Final output sent to browser
DEBUG - 2016-03-08 14:50:13 --> Total execution time: 1.1039
INFO - 2016-03-08 11:50:21 --> Config Class Initialized
INFO - 2016-03-08 11:50:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:50:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:50:21 --> Utf8 Class Initialized
INFO - 2016-03-08 11:50:21 --> URI Class Initialized
INFO - 2016-03-08 11:50:21 --> Router Class Initialized
INFO - 2016-03-08 11:50:21 --> Output Class Initialized
INFO - 2016-03-08 11:50:21 --> Security Class Initialized
DEBUG - 2016-03-08 11:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:50:21 --> Input Class Initialized
INFO - 2016-03-08 11:50:21 --> Language Class Initialized
INFO - 2016-03-08 11:50:21 --> Loader Class Initialized
INFO - 2016-03-08 11:50:21 --> Helper loaded: url_helper
INFO - 2016-03-08 11:50:21 --> Helper loaded: file_helper
INFO - 2016-03-08 11:50:21 --> Helper loaded: date_helper
INFO - 2016-03-08 11:50:21 --> Helper loaded: form_helper
INFO - 2016-03-08 11:50:21 --> Database Driver Class Initialized
INFO - 2016-03-08 11:50:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:50:22 --> Controller Class Initialized
INFO - 2016-03-08 11:50:22 --> Model Class Initialized
INFO - 2016-03-08 11:50:22 --> Model Class Initialized
INFO - 2016-03-08 11:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:50:22 --> Pagination Class Initialized
INFO - 2016-03-08 11:50:22 --> Helper loaded: text_helper
INFO - 2016-03-08 11:50:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:50:22 --> Final output sent to browser
DEBUG - 2016-03-08 14:50:22 --> Total execution time: 1.1907
INFO - 2016-03-08 11:53:05 --> Config Class Initialized
INFO - 2016-03-08 11:53:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:05 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:05 --> URI Class Initialized
INFO - 2016-03-08 11:53:05 --> Router Class Initialized
INFO - 2016-03-08 11:53:05 --> Output Class Initialized
INFO - 2016-03-08 11:53:05 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:05 --> Input Class Initialized
INFO - 2016-03-08 11:53:05 --> Language Class Initialized
INFO - 2016-03-08 11:53:05 --> Loader Class Initialized
INFO - 2016-03-08 11:53:05 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:05 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:05 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:05 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:05 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:06 --> Controller Class Initialized
INFO - 2016-03-08 11:53:06 --> Model Class Initialized
INFO - 2016-03-08 11:53:06 --> Model Class Initialized
INFO - 2016-03-08 11:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:06 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:06 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:06 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:06 --> Total execution time: 1.2234
INFO - 2016-03-08 11:53:14 --> Config Class Initialized
INFO - 2016-03-08 11:53:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:14 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:14 --> URI Class Initialized
INFO - 2016-03-08 11:53:14 --> Router Class Initialized
INFO - 2016-03-08 11:53:14 --> Output Class Initialized
INFO - 2016-03-08 11:53:14 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:14 --> Input Class Initialized
INFO - 2016-03-08 11:53:14 --> Language Class Initialized
INFO - 2016-03-08 11:53:14 --> Loader Class Initialized
INFO - 2016-03-08 11:53:14 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:14 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:14 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:14 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:14 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:16 --> Controller Class Initialized
INFO - 2016-03-08 11:53:16 --> Model Class Initialized
INFO - 2016-03-08 11:53:16 --> Model Class Initialized
INFO - 2016-03-08 11:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:16 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:16 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:16 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:53:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:16 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:16 --> Total execution time: 1.1439
INFO - 2016-03-08 11:53:18 --> Config Class Initialized
INFO - 2016-03-08 11:53:18 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:18 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:18 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:18 --> URI Class Initialized
INFO - 2016-03-08 11:53:18 --> Router Class Initialized
INFO - 2016-03-08 11:53:18 --> Output Class Initialized
INFO - 2016-03-08 11:53:18 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:18 --> Input Class Initialized
INFO - 2016-03-08 11:53:18 --> Language Class Initialized
INFO - 2016-03-08 11:53:18 --> Loader Class Initialized
INFO - 2016-03-08 11:53:18 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:18 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:18 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:18 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:18 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:19 --> Controller Class Initialized
INFO - 2016-03-08 11:53:19 --> Model Class Initialized
INFO - 2016-03-08 11:53:19 --> Model Class Initialized
INFO - 2016-03-08 11:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:19 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:19 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:19 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:19 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:19 --> Total execution time: 1.1416
INFO - 2016-03-08 11:53:21 --> Config Class Initialized
INFO - 2016-03-08 11:53:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:21 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:21 --> URI Class Initialized
INFO - 2016-03-08 11:53:21 --> Router Class Initialized
INFO - 2016-03-08 11:53:21 --> Output Class Initialized
INFO - 2016-03-08 11:53:21 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:21 --> Input Class Initialized
INFO - 2016-03-08 11:53:21 --> Language Class Initialized
INFO - 2016-03-08 11:53:21 --> Loader Class Initialized
INFO - 2016-03-08 11:53:21 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:21 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:21 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:21 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:21 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:22 --> Controller Class Initialized
INFO - 2016-03-08 11:53:22 --> Model Class Initialized
INFO - 2016-03-08 11:53:22 --> Model Class Initialized
INFO - 2016-03-08 11:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:22 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:22 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:22 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:22 --> Total execution time: 1.1582
INFO - 2016-03-08 11:53:39 --> Config Class Initialized
INFO - 2016-03-08 11:53:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:39 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:39 --> URI Class Initialized
INFO - 2016-03-08 11:53:39 --> Router Class Initialized
INFO - 2016-03-08 11:53:39 --> Output Class Initialized
INFO - 2016-03-08 11:53:39 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:39 --> Input Class Initialized
INFO - 2016-03-08 11:53:39 --> Language Class Initialized
INFO - 2016-03-08 11:53:39 --> Loader Class Initialized
INFO - 2016-03-08 11:53:39 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:39 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:39 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:39 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:39 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:40 --> Controller Class Initialized
INFO - 2016-03-08 11:53:40 --> Model Class Initialized
INFO - 2016-03-08 11:53:40 --> Model Class Initialized
INFO - 2016-03-08 11:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:40 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:40 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:40 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:40 --> Total execution time: 1.1722
INFO - 2016-03-08 11:53:56 --> Config Class Initialized
INFO - 2016-03-08 11:53:56 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:53:56 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:53:56 --> Utf8 Class Initialized
INFO - 2016-03-08 11:53:56 --> URI Class Initialized
INFO - 2016-03-08 11:53:56 --> Router Class Initialized
INFO - 2016-03-08 11:53:56 --> Output Class Initialized
INFO - 2016-03-08 11:53:56 --> Security Class Initialized
DEBUG - 2016-03-08 11:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:53:56 --> Input Class Initialized
INFO - 2016-03-08 11:53:56 --> Language Class Initialized
INFO - 2016-03-08 11:53:56 --> Loader Class Initialized
INFO - 2016-03-08 11:53:56 --> Helper loaded: url_helper
INFO - 2016-03-08 11:53:56 --> Helper loaded: file_helper
INFO - 2016-03-08 11:53:56 --> Helper loaded: date_helper
INFO - 2016-03-08 11:53:56 --> Helper loaded: form_helper
INFO - 2016-03-08 11:53:56 --> Database Driver Class Initialized
INFO - 2016-03-08 11:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:53:57 --> Controller Class Initialized
INFO - 2016-03-08 11:53:57 --> Model Class Initialized
INFO - 2016-03-08 11:53:57 --> Model Class Initialized
INFO - 2016-03-08 11:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:53:57 --> Pagination Class Initialized
INFO - 2016-03-08 11:53:57 --> Helper loaded: text_helper
INFO - 2016-03-08 11:53:57 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:53:57 --> Final output sent to browser
DEBUG - 2016-03-08 14:53:57 --> Total execution time: 1.2340
INFO - 2016-03-08 11:54:05 --> Config Class Initialized
INFO - 2016-03-08 11:54:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:54:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:54:05 --> Utf8 Class Initialized
INFO - 2016-03-08 11:54:05 --> URI Class Initialized
INFO - 2016-03-08 11:54:05 --> Router Class Initialized
INFO - 2016-03-08 11:54:05 --> Output Class Initialized
INFO - 2016-03-08 11:54:05 --> Security Class Initialized
DEBUG - 2016-03-08 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:54:05 --> Input Class Initialized
INFO - 2016-03-08 11:54:05 --> Language Class Initialized
INFO - 2016-03-08 11:54:05 --> Loader Class Initialized
INFO - 2016-03-08 11:54:05 --> Helper loaded: url_helper
INFO - 2016-03-08 11:54:05 --> Helper loaded: file_helper
INFO - 2016-03-08 11:54:05 --> Helper loaded: date_helper
INFO - 2016-03-08 11:54:06 --> Helper loaded: form_helper
INFO - 2016-03-08 11:54:06 --> Database Driver Class Initialized
INFO - 2016-03-08 11:54:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:54:07 --> Controller Class Initialized
INFO - 2016-03-08 11:54:07 --> Model Class Initialized
INFO - 2016-03-08 11:54:07 --> Model Class Initialized
INFO - 2016-03-08 11:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:54:07 --> Pagination Class Initialized
INFO - 2016-03-08 11:54:07 --> Helper loaded: text_helper
INFO - 2016-03-08 11:54:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 14:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-08 14:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:54:07 --> Final output sent to browser
DEBUG - 2016-03-08 14:54:07 --> Total execution time: 1.1614
INFO - 2016-03-08 11:54:35 --> Config Class Initialized
INFO - 2016-03-08 11:54:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:54:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:54:35 --> Utf8 Class Initialized
INFO - 2016-03-08 11:54:35 --> URI Class Initialized
INFO - 2016-03-08 11:54:35 --> Router Class Initialized
INFO - 2016-03-08 11:54:35 --> Output Class Initialized
INFO - 2016-03-08 11:54:35 --> Security Class Initialized
DEBUG - 2016-03-08 11:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:54:35 --> Input Class Initialized
INFO - 2016-03-08 11:54:35 --> Language Class Initialized
INFO - 2016-03-08 11:54:35 --> Loader Class Initialized
INFO - 2016-03-08 11:54:35 --> Helper loaded: url_helper
INFO - 2016-03-08 11:54:35 --> Helper loaded: file_helper
INFO - 2016-03-08 11:54:35 --> Helper loaded: date_helper
INFO - 2016-03-08 11:54:35 --> Helper loaded: form_helper
INFO - 2016-03-08 11:54:35 --> Database Driver Class Initialized
INFO - 2016-03-08 11:54:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:54:36 --> Controller Class Initialized
INFO - 2016-03-08 11:54:36 --> Model Class Initialized
INFO - 2016-03-08 11:54:36 --> Model Class Initialized
INFO - 2016-03-08 11:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:54:36 --> Pagination Class Initialized
INFO - 2016-03-08 11:54:36 --> Helper loaded: text_helper
INFO - 2016-03-08 11:54:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:54:36 --> Final output sent to browser
DEBUG - 2016-03-08 14:54:36 --> Total execution time: 1.1886
INFO - 2016-03-08 11:56:50 --> Config Class Initialized
INFO - 2016-03-08 11:56:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:56:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:56:50 --> Utf8 Class Initialized
INFO - 2016-03-08 11:56:50 --> URI Class Initialized
INFO - 2016-03-08 11:56:50 --> Router Class Initialized
INFO - 2016-03-08 11:56:50 --> Output Class Initialized
INFO - 2016-03-08 11:56:50 --> Security Class Initialized
DEBUG - 2016-03-08 11:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:56:50 --> Input Class Initialized
INFO - 2016-03-08 11:56:50 --> Language Class Initialized
INFO - 2016-03-08 11:56:50 --> Loader Class Initialized
INFO - 2016-03-08 11:56:50 --> Helper loaded: url_helper
INFO - 2016-03-08 11:56:50 --> Helper loaded: file_helper
INFO - 2016-03-08 11:56:50 --> Helper loaded: date_helper
INFO - 2016-03-08 11:56:50 --> Helper loaded: form_helper
INFO - 2016-03-08 11:56:50 --> Database Driver Class Initialized
INFO - 2016-03-08 11:56:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:56:51 --> Controller Class Initialized
INFO - 2016-03-08 11:56:51 --> Model Class Initialized
INFO - 2016-03-08 11:56:51 --> Model Class Initialized
INFO - 2016-03-08 11:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:56:51 --> Pagination Class Initialized
INFO - 2016-03-08 11:56:51 --> Helper loaded: text_helper
INFO - 2016-03-08 11:56:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:56:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:56:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:56:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:56:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:56:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:56:51 --> Final output sent to browser
DEBUG - 2016-03-08 14:56:51 --> Total execution time: 1.1462
INFO - 2016-03-08 11:57:00 --> Config Class Initialized
INFO - 2016-03-08 11:57:00 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:57:00 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:57:00 --> Utf8 Class Initialized
INFO - 2016-03-08 11:57:00 --> URI Class Initialized
INFO - 2016-03-08 11:57:00 --> Router Class Initialized
INFO - 2016-03-08 11:57:00 --> Output Class Initialized
INFO - 2016-03-08 11:57:00 --> Security Class Initialized
DEBUG - 2016-03-08 11:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:57:00 --> Input Class Initialized
INFO - 2016-03-08 11:57:00 --> Language Class Initialized
INFO - 2016-03-08 11:57:00 --> Loader Class Initialized
INFO - 2016-03-08 11:57:00 --> Helper loaded: url_helper
INFO - 2016-03-08 11:57:00 --> Helper loaded: file_helper
INFO - 2016-03-08 11:57:00 --> Helper loaded: date_helper
INFO - 2016-03-08 11:57:00 --> Helper loaded: form_helper
INFO - 2016-03-08 11:57:00 --> Database Driver Class Initialized
INFO - 2016-03-08 11:57:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:57:01 --> Controller Class Initialized
INFO - 2016-03-08 11:57:01 --> Model Class Initialized
INFO - 2016-03-08 11:57:01 --> Model Class Initialized
INFO - 2016-03-08 11:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:57:01 --> Pagination Class Initialized
INFO - 2016-03-08 11:57:01 --> Helper loaded: text_helper
INFO - 2016-03-08 11:57:01 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:57:01 --> Final output sent to browser
DEBUG - 2016-03-08 14:57:01 --> Total execution time: 1.2501
INFO - 2016-03-08 11:57:12 --> Config Class Initialized
INFO - 2016-03-08 11:57:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:57:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:57:12 --> Utf8 Class Initialized
INFO - 2016-03-08 11:57:12 --> URI Class Initialized
INFO - 2016-03-08 11:57:12 --> Router Class Initialized
INFO - 2016-03-08 11:57:12 --> Output Class Initialized
INFO - 2016-03-08 11:57:12 --> Security Class Initialized
DEBUG - 2016-03-08 11:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:57:12 --> Input Class Initialized
INFO - 2016-03-08 11:57:12 --> Language Class Initialized
INFO - 2016-03-08 11:57:12 --> Loader Class Initialized
INFO - 2016-03-08 11:57:12 --> Helper loaded: url_helper
INFO - 2016-03-08 11:57:12 --> Helper loaded: file_helper
INFO - 2016-03-08 11:57:12 --> Helper loaded: date_helper
INFO - 2016-03-08 11:57:12 --> Helper loaded: form_helper
INFO - 2016-03-08 11:57:12 --> Database Driver Class Initialized
INFO - 2016-03-08 11:57:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:57:13 --> Controller Class Initialized
INFO - 2016-03-08 11:57:13 --> Model Class Initialized
INFO - 2016-03-08 11:57:13 --> Model Class Initialized
INFO - 2016-03-08 11:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:57:13 --> Pagination Class Initialized
INFO - 2016-03-08 11:57:13 --> Helper loaded: text_helper
INFO - 2016-03-08 11:57:13 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:57:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:57:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 14:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-08 14:57:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:57:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:57:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:57:13 --> Final output sent to browser
DEBUG - 2016-03-08 14:57:13 --> Total execution time: 1.1749
INFO - 2016-03-08 11:57:14 --> Config Class Initialized
INFO - 2016-03-08 11:57:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:57:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:57:14 --> Utf8 Class Initialized
INFO - 2016-03-08 11:57:14 --> URI Class Initialized
INFO - 2016-03-08 11:57:14 --> Router Class Initialized
INFO - 2016-03-08 11:57:14 --> Output Class Initialized
INFO - 2016-03-08 11:57:14 --> Security Class Initialized
DEBUG - 2016-03-08 11:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:57:14 --> Input Class Initialized
INFO - 2016-03-08 11:57:14 --> Language Class Initialized
INFO - 2016-03-08 11:57:14 --> Loader Class Initialized
INFO - 2016-03-08 11:57:14 --> Helper loaded: url_helper
INFO - 2016-03-08 11:57:14 --> Helper loaded: file_helper
INFO - 2016-03-08 11:57:14 --> Helper loaded: date_helper
INFO - 2016-03-08 11:57:14 --> Helper loaded: form_helper
INFO - 2016-03-08 11:57:14 --> Database Driver Class Initialized
INFO - 2016-03-08 11:57:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:57:15 --> Controller Class Initialized
INFO - 2016-03-08 11:57:15 --> Model Class Initialized
INFO - 2016-03-08 11:57:15 --> Model Class Initialized
INFO - 2016-03-08 11:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:57:15 --> Pagination Class Initialized
INFO - 2016-03-08 11:57:15 --> Helper loaded: text_helper
INFO - 2016-03-08 11:57:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:57:15 --> Final output sent to browser
DEBUG - 2016-03-08 14:57:15 --> Total execution time: 1.1649
INFO - 2016-03-08 11:57:46 --> Config Class Initialized
INFO - 2016-03-08 11:57:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:57:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:57:46 --> Utf8 Class Initialized
INFO - 2016-03-08 11:57:46 --> URI Class Initialized
INFO - 2016-03-08 11:57:46 --> Router Class Initialized
INFO - 2016-03-08 11:57:46 --> Output Class Initialized
INFO - 2016-03-08 11:57:46 --> Security Class Initialized
DEBUG - 2016-03-08 11:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:57:46 --> Input Class Initialized
INFO - 2016-03-08 11:57:46 --> Language Class Initialized
INFO - 2016-03-08 11:57:46 --> Loader Class Initialized
INFO - 2016-03-08 11:57:46 --> Helper loaded: url_helper
INFO - 2016-03-08 11:57:46 --> Helper loaded: file_helper
INFO - 2016-03-08 11:57:46 --> Helper loaded: date_helper
INFO - 2016-03-08 11:57:46 --> Helper loaded: form_helper
INFO - 2016-03-08 11:57:46 --> Database Driver Class Initialized
INFO - 2016-03-08 11:57:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:57:47 --> Controller Class Initialized
INFO - 2016-03-08 11:57:47 --> Model Class Initialized
INFO - 2016-03-08 11:57:47 --> Model Class Initialized
INFO - 2016-03-08 11:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:57:47 --> Pagination Class Initialized
INFO - 2016-03-08 11:57:47 --> Helper loaded: text_helper
INFO - 2016-03-08 11:57:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:57:47 --> Final output sent to browser
DEBUG - 2016-03-08 14:57:47 --> Total execution time: 1.1408
INFO - 2016-03-08 11:58:06 --> Config Class Initialized
INFO - 2016-03-08 11:58:06 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:58:06 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:58:06 --> Utf8 Class Initialized
INFO - 2016-03-08 11:58:06 --> URI Class Initialized
INFO - 2016-03-08 11:58:06 --> Router Class Initialized
INFO - 2016-03-08 11:58:06 --> Output Class Initialized
INFO - 2016-03-08 11:58:06 --> Security Class Initialized
DEBUG - 2016-03-08 11:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:58:06 --> Input Class Initialized
INFO - 2016-03-08 11:58:06 --> Language Class Initialized
INFO - 2016-03-08 11:58:06 --> Loader Class Initialized
INFO - 2016-03-08 11:58:06 --> Helper loaded: url_helper
INFO - 2016-03-08 11:58:06 --> Helper loaded: file_helper
INFO - 2016-03-08 11:58:06 --> Helper loaded: date_helper
INFO - 2016-03-08 11:58:06 --> Helper loaded: form_helper
INFO - 2016-03-08 11:58:06 --> Database Driver Class Initialized
INFO - 2016-03-08 11:58:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:58:07 --> Controller Class Initialized
INFO - 2016-03-08 11:58:07 --> Model Class Initialized
INFO - 2016-03-08 11:58:07 --> Model Class Initialized
INFO - 2016-03-08 11:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:58:07 --> Pagination Class Initialized
INFO - 2016-03-08 11:58:07 --> Helper loaded: text_helper
INFO - 2016-03-08 11:58:07 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:58:07 --> Final output sent to browser
DEBUG - 2016-03-08 14:58:07 --> Total execution time: 1.1014
INFO - 2016-03-08 11:58:10 --> Config Class Initialized
INFO - 2016-03-08 11:58:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:58:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:58:10 --> Utf8 Class Initialized
INFO - 2016-03-08 11:58:10 --> URI Class Initialized
INFO - 2016-03-08 11:58:10 --> Router Class Initialized
INFO - 2016-03-08 11:58:10 --> Output Class Initialized
INFO - 2016-03-08 11:58:10 --> Security Class Initialized
DEBUG - 2016-03-08 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:58:10 --> Input Class Initialized
INFO - 2016-03-08 11:58:10 --> Language Class Initialized
INFO - 2016-03-08 11:58:10 --> Loader Class Initialized
INFO - 2016-03-08 11:58:10 --> Helper loaded: url_helper
INFO - 2016-03-08 11:58:10 --> Helper loaded: file_helper
INFO - 2016-03-08 11:58:10 --> Helper loaded: date_helper
INFO - 2016-03-08 11:58:10 --> Helper loaded: form_helper
INFO - 2016-03-08 11:58:10 --> Database Driver Class Initialized
INFO - 2016-03-08 11:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:58:11 --> Controller Class Initialized
INFO - 2016-03-08 11:58:11 --> Model Class Initialized
INFO - 2016-03-08 11:58:11 --> Model Class Initialized
INFO - 2016-03-08 11:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:58:11 --> Pagination Class Initialized
INFO - 2016-03-08 11:58:11 --> Helper loaded: text_helper
INFO - 2016-03-08 11:58:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:58:11 --> Final output sent to browser
DEBUG - 2016-03-08 14:58:11 --> Total execution time: 1.2111
INFO - 2016-03-08 11:58:24 --> Config Class Initialized
INFO - 2016-03-08 11:58:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:58:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:58:24 --> Utf8 Class Initialized
INFO - 2016-03-08 11:58:24 --> URI Class Initialized
INFO - 2016-03-08 11:58:24 --> Router Class Initialized
INFO - 2016-03-08 11:58:24 --> Output Class Initialized
INFO - 2016-03-08 11:58:24 --> Security Class Initialized
DEBUG - 2016-03-08 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:58:24 --> Input Class Initialized
INFO - 2016-03-08 11:58:24 --> Language Class Initialized
INFO - 2016-03-08 11:58:24 --> Loader Class Initialized
INFO - 2016-03-08 11:58:24 --> Helper loaded: url_helper
INFO - 2016-03-08 11:58:24 --> Helper loaded: file_helper
INFO - 2016-03-08 11:58:24 --> Helper loaded: date_helper
INFO - 2016-03-08 11:58:24 --> Helper loaded: form_helper
INFO - 2016-03-08 11:58:24 --> Database Driver Class Initialized
INFO - 2016-03-08 11:58:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:58:25 --> Controller Class Initialized
INFO - 2016-03-08 11:58:25 --> Model Class Initialized
INFO - 2016-03-08 11:58:25 --> Model Class Initialized
INFO - 2016-03-08 11:58:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:58:25 --> Pagination Class Initialized
INFO - 2016-03-08 11:58:25 --> Helper loaded: text_helper
INFO - 2016-03-08 11:58:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 14:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-08 14:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:58:25 --> Final output sent to browser
DEBUG - 2016-03-08 14:58:25 --> Total execution time: 1.1484
INFO - 2016-03-08 11:58:34 --> Config Class Initialized
INFO - 2016-03-08 11:58:34 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:58:34 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:58:34 --> Utf8 Class Initialized
INFO - 2016-03-08 11:58:34 --> URI Class Initialized
INFO - 2016-03-08 11:58:34 --> Router Class Initialized
INFO - 2016-03-08 11:58:34 --> Output Class Initialized
INFO - 2016-03-08 11:58:34 --> Security Class Initialized
DEBUG - 2016-03-08 11:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:58:34 --> Input Class Initialized
INFO - 2016-03-08 11:58:34 --> Language Class Initialized
INFO - 2016-03-08 11:58:34 --> Loader Class Initialized
INFO - 2016-03-08 11:58:34 --> Helper loaded: url_helper
INFO - 2016-03-08 11:58:34 --> Helper loaded: file_helper
INFO - 2016-03-08 11:58:34 --> Helper loaded: date_helper
INFO - 2016-03-08 11:58:34 --> Helper loaded: form_helper
INFO - 2016-03-08 11:58:34 --> Database Driver Class Initialized
INFO - 2016-03-08 11:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:58:35 --> Controller Class Initialized
INFO - 2016-03-08 11:58:35 --> Model Class Initialized
INFO - 2016-03-08 11:58:35 --> Model Class Initialized
INFO - 2016-03-08 11:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:58:35 --> Pagination Class Initialized
INFO - 2016-03-08 11:58:35 --> Helper loaded: text_helper
INFO - 2016-03-08 11:58:35 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:58:35 --> Final output sent to browser
DEBUG - 2016-03-08 14:58:35 --> Total execution time: 1.1666
INFO - 2016-03-08 11:58:59 --> Config Class Initialized
INFO - 2016-03-08 11:58:59 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:58:59 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:58:59 --> Utf8 Class Initialized
INFO - 2016-03-08 11:58:59 --> URI Class Initialized
INFO - 2016-03-08 11:58:59 --> Router Class Initialized
INFO - 2016-03-08 11:58:59 --> Output Class Initialized
INFO - 2016-03-08 11:58:59 --> Security Class Initialized
DEBUG - 2016-03-08 11:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:58:59 --> Input Class Initialized
INFO - 2016-03-08 11:58:59 --> Language Class Initialized
INFO - 2016-03-08 11:58:59 --> Loader Class Initialized
INFO - 2016-03-08 11:58:59 --> Helper loaded: url_helper
INFO - 2016-03-08 11:58:59 --> Helper loaded: file_helper
INFO - 2016-03-08 11:58:59 --> Helper loaded: date_helper
INFO - 2016-03-08 11:58:59 --> Helper loaded: form_helper
INFO - 2016-03-08 11:58:59 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:00 --> Controller Class Initialized
INFO - 2016-03-08 11:59:00 --> Model Class Initialized
INFO - 2016-03-08 11:59:00 --> Model Class Initialized
INFO - 2016-03-08 11:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:00 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:00 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:00 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:00 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:00 --> Total execution time: 1.1364
INFO - 2016-03-08 11:59:02 --> Config Class Initialized
INFO - 2016-03-08 11:59:02 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:02 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:02 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:02 --> URI Class Initialized
INFO - 2016-03-08 11:59:02 --> Router Class Initialized
INFO - 2016-03-08 11:59:02 --> Output Class Initialized
INFO - 2016-03-08 11:59:02 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:02 --> Input Class Initialized
INFO - 2016-03-08 11:59:02 --> Language Class Initialized
INFO - 2016-03-08 11:59:02 --> Loader Class Initialized
INFO - 2016-03-08 11:59:02 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:02 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:02 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:02 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:02 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:03 --> Controller Class Initialized
INFO - 2016-03-08 11:59:03 --> Model Class Initialized
INFO - 2016-03-08 11:59:03 --> Model Class Initialized
INFO - 2016-03-08 11:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:03 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:03 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:03 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:03 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:03 --> Total execution time: 1.1889
INFO - 2016-03-08 11:59:05 --> Config Class Initialized
INFO - 2016-03-08 11:59:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:05 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:05 --> URI Class Initialized
INFO - 2016-03-08 11:59:05 --> Router Class Initialized
INFO - 2016-03-08 11:59:05 --> Output Class Initialized
INFO - 2016-03-08 11:59:05 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:05 --> Input Class Initialized
INFO - 2016-03-08 11:59:05 --> Language Class Initialized
INFO - 2016-03-08 11:59:05 --> Loader Class Initialized
INFO - 2016-03-08 11:59:05 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:05 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:05 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:05 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:05 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:06 --> Controller Class Initialized
INFO - 2016-03-08 11:59:06 --> Model Class Initialized
INFO - 2016-03-08 11:59:06 --> Model Class Initialized
INFO - 2016-03-08 11:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:06 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:06 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:07 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:07 --> Total execution time: 1.1800
INFO - 2016-03-08 11:59:14 --> Config Class Initialized
INFO - 2016-03-08 11:59:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:14 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:14 --> URI Class Initialized
INFO - 2016-03-08 11:59:14 --> Router Class Initialized
INFO - 2016-03-08 11:59:14 --> Output Class Initialized
INFO - 2016-03-08 11:59:14 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:14 --> Input Class Initialized
INFO - 2016-03-08 11:59:14 --> Language Class Initialized
INFO - 2016-03-08 11:59:14 --> Loader Class Initialized
INFO - 2016-03-08 11:59:14 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:14 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:14 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:14 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:14 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:15 --> Controller Class Initialized
INFO - 2016-03-08 11:59:15 --> Model Class Initialized
INFO - 2016-03-08 11:59:15 --> Model Class Initialized
INFO - 2016-03-08 11:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:15 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:15 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:15 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:15 --> Total execution time: 1.1648
INFO - 2016-03-08 11:59:17 --> Config Class Initialized
INFO - 2016-03-08 11:59:17 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:17 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:17 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:17 --> URI Class Initialized
INFO - 2016-03-08 11:59:17 --> Router Class Initialized
INFO - 2016-03-08 11:59:17 --> Output Class Initialized
INFO - 2016-03-08 11:59:17 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:17 --> Input Class Initialized
INFO - 2016-03-08 11:59:17 --> Language Class Initialized
INFO - 2016-03-08 11:59:17 --> Loader Class Initialized
INFO - 2016-03-08 11:59:17 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:17 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:17 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:17 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:17 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:18 --> Controller Class Initialized
INFO - 2016-03-08 11:59:18 --> Model Class Initialized
INFO - 2016-03-08 11:59:18 --> Model Class Initialized
INFO - 2016-03-08 11:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:18 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:18 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:18 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:18 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:18 --> Total execution time: 1.1003
INFO - 2016-03-08 11:59:19 --> Config Class Initialized
INFO - 2016-03-08 11:59:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:19 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:19 --> URI Class Initialized
INFO - 2016-03-08 11:59:19 --> Router Class Initialized
INFO - 2016-03-08 11:59:19 --> Output Class Initialized
INFO - 2016-03-08 11:59:19 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:19 --> Input Class Initialized
INFO - 2016-03-08 11:59:19 --> Language Class Initialized
INFO - 2016-03-08 11:59:19 --> Loader Class Initialized
INFO - 2016-03-08 11:59:19 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:19 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:19 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:19 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:19 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:20 --> Controller Class Initialized
INFO - 2016-03-08 11:59:20 --> Model Class Initialized
INFO - 2016-03-08 11:59:20 --> Model Class Initialized
INFO - 2016-03-08 11:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:20 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:20 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:21 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:21 --> Total execution time: 1.2277
INFO - 2016-03-08 11:59:37 --> Config Class Initialized
INFO - 2016-03-08 11:59:37 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:37 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:37 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:37 --> URI Class Initialized
INFO - 2016-03-08 11:59:37 --> Router Class Initialized
INFO - 2016-03-08 11:59:37 --> Output Class Initialized
INFO - 2016-03-08 11:59:37 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:37 --> Input Class Initialized
INFO - 2016-03-08 11:59:37 --> Language Class Initialized
INFO - 2016-03-08 11:59:37 --> Loader Class Initialized
INFO - 2016-03-08 11:59:37 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:37 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:37 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:37 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:37 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:38 --> Controller Class Initialized
INFO - 2016-03-08 11:59:38 --> Model Class Initialized
INFO - 2016-03-08 11:59:38 --> Model Class Initialized
INFO - 2016-03-08 11:59:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:38 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:38 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:38 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:38 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:38 --> Total execution time: 1.1335
INFO - 2016-03-08 11:59:45 --> Config Class Initialized
INFO - 2016-03-08 11:59:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:45 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:45 --> URI Class Initialized
INFO - 2016-03-08 11:59:45 --> Router Class Initialized
INFO - 2016-03-08 11:59:45 --> Output Class Initialized
INFO - 2016-03-08 11:59:45 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:45 --> Input Class Initialized
INFO - 2016-03-08 11:59:45 --> Language Class Initialized
INFO - 2016-03-08 11:59:45 --> Loader Class Initialized
INFO - 2016-03-08 11:59:45 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:45 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:45 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:45 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:45 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:46 --> Controller Class Initialized
INFO - 2016-03-08 11:59:46 --> Model Class Initialized
INFO - 2016-03-08 11:59:46 --> Model Class Initialized
INFO - 2016-03-08 11:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:46 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:46 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:46 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:46 --> Total execution time: 1.1383
INFO - 2016-03-08 11:59:47 --> Config Class Initialized
INFO - 2016-03-08 11:59:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 11:59:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 11:59:47 --> Utf8 Class Initialized
INFO - 2016-03-08 11:59:47 --> URI Class Initialized
INFO - 2016-03-08 11:59:47 --> Router Class Initialized
INFO - 2016-03-08 11:59:47 --> Output Class Initialized
INFO - 2016-03-08 11:59:47 --> Security Class Initialized
DEBUG - 2016-03-08 11:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 11:59:47 --> Input Class Initialized
INFO - 2016-03-08 11:59:47 --> Language Class Initialized
INFO - 2016-03-08 11:59:47 --> Loader Class Initialized
INFO - 2016-03-08 11:59:47 --> Helper loaded: url_helper
INFO - 2016-03-08 11:59:47 --> Helper loaded: file_helper
INFO - 2016-03-08 11:59:47 --> Helper loaded: date_helper
INFO - 2016-03-08 11:59:47 --> Helper loaded: form_helper
INFO - 2016-03-08 11:59:47 --> Database Driver Class Initialized
INFO - 2016-03-08 11:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 11:59:48 --> Controller Class Initialized
INFO - 2016-03-08 11:59:48 --> Model Class Initialized
INFO - 2016-03-08 11:59:48 --> Model Class Initialized
INFO - 2016-03-08 11:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 11:59:48 --> Pagination Class Initialized
INFO - 2016-03-08 11:59:48 --> Helper loaded: text_helper
INFO - 2016-03-08 11:59:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 14:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 14:59:48 --> Final output sent to browser
DEBUG - 2016-03-08 14:59:48 --> Total execution time: 1.1673
INFO - 2016-03-08 12:00:16 --> Config Class Initialized
INFO - 2016-03-08 12:00:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:00:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:00:16 --> Utf8 Class Initialized
INFO - 2016-03-08 12:00:16 --> URI Class Initialized
INFO - 2016-03-08 12:00:16 --> Router Class Initialized
INFO - 2016-03-08 12:00:16 --> Output Class Initialized
INFO - 2016-03-08 12:00:16 --> Security Class Initialized
DEBUG - 2016-03-08 12:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:00:16 --> Input Class Initialized
INFO - 2016-03-08 12:00:16 --> Language Class Initialized
INFO - 2016-03-08 12:00:16 --> Loader Class Initialized
INFO - 2016-03-08 12:00:16 --> Helper loaded: url_helper
INFO - 2016-03-08 12:00:16 --> Helper loaded: file_helper
INFO - 2016-03-08 12:00:16 --> Helper loaded: date_helper
INFO - 2016-03-08 12:00:16 --> Helper loaded: form_helper
INFO - 2016-03-08 12:00:16 --> Database Driver Class Initialized
INFO - 2016-03-08 12:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:00:17 --> Controller Class Initialized
INFO - 2016-03-08 12:00:17 --> Model Class Initialized
INFO - 2016-03-08 12:00:17 --> Model Class Initialized
INFO - 2016-03-08 12:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:00:17 --> Pagination Class Initialized
INFO - 2016-03-08 12:00:17 --> Helper loaded: text_helper
INFO - 2016-03-08 12:00:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:00:17 --> Final output sent to browser
DEBUG - 2016-03-08 15:00:17 --> Total execution time: 1.1711
INFO - 2016-03-08 12:00:20 --> Config Class Initialized
INFO - 2016-03-08 12:00:20 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:00:20 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:00:20 --> Utf8 Class Initialized
INFO - 2016-03-08 12:00:20 --> URI Class Initialized
INFO - 2016-03-08 12:00:20 --> Router Class Initialized
INFO - 2016-03-08 12:00:20 --> Output Class Initialized
INFO - 2016-03-08 12:00:20 --> Security Class Initialized
DEBUG - 2016-03-08 12:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:00:20 --> Input Class Initialized
INFO - 2016-03-08 12:00:20 --> Language Class Initialized
INFO - 2016-03-08 12:00:20 --> Loader Class Initialized
INFO - 2016-03-08 12:00:20 --> Helper loaded: url_helper
INFO - 2016-03-08 12:00:20 --> Helper loaded: file_helper
INFO - 2016-03-08 12:00:20 --> Helper loaded: date_helper
INFO - 2016-03-08 12:00:20 --> Helper loaded: form_helper
INFO - 2016-03-08 12:00:20 --> Database Driver Class Initialized
INFO - 2016-03-08 12:00:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:00:21 --> Controller Class Initialized
INFO - 2016-03-08 12:00:21 --> Model Class Initialized
INFO - 2016-03-08 12:00:21 --> Model Class Initialized
INFO - 2016-03-08 12:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:00:21 --> Pagination Class Initialized
INFO - 2016-03-08 12:00:21 --> Helper loaded: text_helper
INFO - 2016-03-08 12:00:21 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:00:21 --> Final output sent to browser
DEBUG - 2016-03-08 15:00:21 --> Total execution time: 1.2008
INFO - 2016-03-08 12:00:45 --> Config Class Initialized
INFO - 2016-03-08 12:00:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:00:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:00:45 --> Utf8 Class Initialized
INFO - 2016-03-08 12:00:45 --> URI Class Initialized
INFO - 2016-03-08 12:00:45 --> Router Class Initialized
INFO - 2016-03-08 12:00:45 --> Output Class Initialized
INFO - 2016-03-08 12:00:45 --> Security Class Initialized
DEBUG - 2016-03-08 12:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:00:45 --> Input Class Initialized
INFO - 2016-03-08 12:00:45 --> Language Class Initialized
INFO - 2016-03-08 12:00:45 --> Loader Class Initialized
INFO - 2016-03-08 12:00:45 --> Helper loaded: url_helper
INFO - 2016-03-08 12:00:45 --> Helper loaded: file_helper
INFO - 2016-03-08 12:00:45 --> Helper loaded: date_helper
INFO - 2016-03-08 12:00:45 --> Helper loaded: form_helper
INFO - 2016-03-08 12:00:45 --> Database Driver Class Initialized
INFO - 2016-03-08 12:00:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:00:46 --> Controller Class Initialized
INFO - 2016-03-08 12:00:46 --> Model Class Initialized
INFO - 2016-03-08 12:00:46 --> Model Class Initialized
INFO - 2016-03-08 12:00:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:00:46 --> Pagination Class Initialized
INFO - 2016-03-08 12:00:46 --> Helper loaded: text_helper
INFO - 2016-03-08 12:00:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:00:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:00:46 --> Final output sent to browser
DEBUG - 2016-03-08 15:00:46 --> Total execution time: 1.1215
INFO - 2016-03-08 12:00:48 --> Config Class Initialized
INFO - 2016-03-08 12:00:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:00:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:00:48 --> Utf8 Class Initialized
INFO - 2016-03-08 12:00:48 --> URI Class Initialized
INFO - 2016-03-08 12:00:48 --> Router Class Initialized
INFO - 2016-03-08 12:00:48 --> Output Class Initialized
INFO - 2016-03-08 12:00:48 --> Security Class Initialized
DEBUG - 2016-03-08 12:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:00:48 --> Input Class Initialized
INFO - 2016-03-08 12:00:48 --> Language Class Initialized
INFO - 2016-03-08 12:00:48 --> Loader Class Initialized
INFO - 2016-03-08 12:00:48 --> Helper loaded: url_helper
INFO - 2016-03-08 12:00:48 --> Helper loaded: file_helper
INFO - 2016-03-08 12:00:48 --> Helper loaded: date_helper
INFO - 2016-03-08 12:00:48 --> Helper loaded: form_helper
INFO - 2016-03-08 12:00:48 --> Database Driver Class Initialized
INFO - 2016-03-08 12:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:00:49 --> Controller Class Initialized
INFO - 2016-03-08 12:00:49 --> Model Class Initialized
INFO - 2016-03-08 12:00:49 --> Model Class Initialized
INFO - 2016-03-08 12:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:00:49 --> Pagination Class Initialized
INFO - 2016-03-08 12:00:49 --> Helper loaded: text_helper
INFO - 2016-03-08 12:00:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:00:49 --> Final output sent to browser
DEBUG - 2016-03-08 15:00:49 --> Total execution time: 1.2329
INFO - 2016-03-08 12:01:05 --> Config Class Initialized
INFO - 2016-03-08 12:01:05 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:05 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:05 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:05 --> URI Class Initialized
INFO - 2016-03-08 12:01:05 --> Router Class Initialized
INFO - 2016-03-08 12:01:05 --> Output Class Initialized
INFO - 2016-03-08 12:01:05 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:05 --> Input Class Initialized
INFO - 2016-03-08 12:01:05 --> Language Class Initialized
INFO - 2016-03-08 12:01:05 --> Loader Class Initialized
INFO - 2016-03-08 12:01:05 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:05 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:05 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:05 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:05 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:06 --> Controller Class Initialized
INFO - 2016-03-08 12:01:06 --> Model Class Initialized
INFO - 2016-03-08 12:01:06 --> Model Class Initialized
INFO - 2016-03-08 12:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:06 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:06 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:06 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 15:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-08 15:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:06 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:06 --> Total execution time: 1.1839
INFO - 2016-03-08 12:01:10 --> Config Class Initialized
INFO - 2016-03-08 12:01:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:10 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:10 --> URI Class Initialized
INFO - 2016-03-08 12:01:10 --> Router Class Initialized
INFO - 2016-03-08 12:01:10 --> Output Class Initialized
INFO - 2016-03-08 12:01:10 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:10 --> Input Class Initialized
INFO - 2016-03-08 12:01:10 --> Language Class Initialized
INFO - 2016-03-08 12:01:10 --> Loader Class Initialized
INFO - 2016-03-08 12:01:10 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:10 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:10 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:10 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:10 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:11 --> Controller Class Initialized
INFO - 2016-03-08 12:01:11 --> Model Class Initialized
INFO - 2016-03-08 12:01:11 --> Model Class Initialized
INFO - 2016-03-08 12:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:11 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:11 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:11 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:11 --> Total execution time: 1.1682
INFO - 2016-03-08 12:01:20 --> Config Class Initialized
INFO - 2016-03-08 12:01:20 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:20 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:20 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:20 --> URI Class Initialized
INFO - 2016-03-08 12:01:20 --> Router Class Initialized
INFO - 2016-03-08 12:01:20 --> Output Class Initialized
INFO - 2016-03-08 12:01:20 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:20 --> Input Class Initialized
INFO - 2016-03-08 12:01:20 --> Language Class Initialized
INFO - 2016-03-08 12:01:20 --> Loader Class Initialized
INFO - 2016-03-08 12:01:20 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:20 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:20 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:20 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:20 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:21 --> Controller Class Initialized
INFO - 2016-03-08 12:01:21 --> Model Class Initialized
INFO - 2016-03-08 12:01:21 --> Model Class Initialized
INFO - 2016-03-08 12:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:21 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:21 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:21 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:01:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:21 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:21 --> Total execution time: 1.2460
INFO - 2016-03-08 12:01:23 --> Config Class Initialized
INFO - 2016-03-08 12:01:23 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:23 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:23 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:23 --> URI Class Initialized
INFO - 2016-03-08 12:01:23 --> Router Class Initialized
INFO - 2016-03-08 12:01:23 --> Output Class Initialized
INFO - 2016-03-08 12:01:23 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:23 --> Input Class Initialized
INFO - 2016-03-08 12:01:23 --> Language Class Initialized
INFO - 2016-03-08 12:01:24 --> Loader Class Initialized
INFO - 2016-03-08 12:01:24 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:24 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:24 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:24 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:24 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:25 --> Controller Class Initialized
INFO - 2016-03-08 12:01:25 --> Model Class Initialized
INFO - 2016-03-08 12:01:25 --> Model Class Initialized
INFO - 2016-03-08 12:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:25 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:25 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:25 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:25 --> Total execution time: 1.1402
INFO - 2016-03-08 12:01:33 --> Config Class Initialized
INFO - 2016-03-08 12:01:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:33 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:33 --> URI Class Initialized
INFO - 2016-03-08 12:01:33 --> Router Class Initialized
INFO - 2016-03-08 12:01:33 --> Output Class Initialized
INFO - 2016-03-08 12:01:33 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:33 --> Input Class Initialized
INFO - 2016-03-08 12:01:33 --> Language Class Initialized
INFO - 2016-03-08 12:01:33 --> Loader Class Initialized
INFO - 2016-03-08 12:01:33 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:33 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:33 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:33 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:33 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:34 --> Controller Class Initialized
INFO - 2016-03-08 12:01:34 --> Model Class Initialized
INFO - 2016-03-08 12:01:34 --> Model Class Initialized
INFO - 2016-03-08 12:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:34 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:34 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:34 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:34 --> Total execution time: 1.1843
INFO - 2016-03-08 12:01:48 --> Config Class Initialized
INFO - 2016-03-08 12:01:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:48 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:48 --> URI Class Initialized
INFO - 2016-03-08 12:01:48 --> Router Class Initialized
INFO - 2016-03-08 12:01:48 --> Output Class Initialized
INFO - 2016-03-08 12:01:48 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:48 --> Input Class Initialized
INFO - 2016-03-08 12:01:48 --> Language Class Initialized
INFO - 2016-03-08 12:01:48 --> Loader Class Initialized
INFO - 2016-03-08 12:01:48 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:48 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:48 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:48 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:48 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:49 --> Controller Class Initialized
INFO - 2016-03-08 12:01:49 --> Model Class Initialized
INFO - 2016-03-08 12:01:49 --> Model Class Initialized
INFO - 2016-03-08 12:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:49 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:49 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:49 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:49 --> Total execution time: 1.2242
INFO - 2016-03-08 12:01:58 --> Config Class Initialized
INFO - 2016-03-08 12:01:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:01:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:01:58 --> Utf8 Class Initialized
INFO - 2016-03-08 12:01:58 --> URI Class Initialized
INFO - 2016-03-08 12:01:58 --> Router Class Initialized
INFO - 2016-03-08 12:01:58 --> Output Class Initialized
INFO - 2016-03-08 12:01:58 --> Security Class Initialized
DEBUG - 2016-03-08 12:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:01:58 --> Input Class Initialized
INFO - 2016-03-08 12:01:58 --> Language Class Initialized
INFO - 2016-03-08 12:01:58 --> Loader Class Initialized
INFO - 2016-03-08 12:01:58 --> Helper loaded: url_helper
INFO - 2016-03-08 12:01:58 --> Helper loaded: file_helper
INFO - 2016-03-08 12:01:58 --> Helper loaded: date_helper
INFO - 2016-03-08 12:01:58 --> Helper loaded: form_helper
INFO - 2016-03-08 12:01:58 --> Database Driver Class Initialized
INFO - 2016-03-08 12:01:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:01:59 --> Controller Class Initialized
INFO - 2016-03-08 12:01:59 --> Model Class Initialized
INFO - 2016-03-08 12:01:59 --> Model Class Initialized
INFO - 2016-03-08 12:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:01:59 --> Pagination Class Initialized
INFO - 2016-03-08 12:01:59 --> Helper loaded: text_helper
INFO - 2016-03-08 12:01:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:01:59 --> Final output sent to browser
DEBUG - 2016-03-08 15:01:59 --> Total execution time: 1.1934
INFO - 2016-03-08 12:02:10 --> Config Class Initialized
INFO - 2016-03-08 12:02:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:02:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:02:10 --> Utf8 Class Initialized
INFO - 2016-03-08 12:02:10 --> URI Class Initialized
INFO - 2016-03-08 12:02:10 --> Router Class Initialized
INFO - 2016-03-08 12:02:10 --> Output Class Initialized
INFO - 2016-03-08 12:02:10 --> Security Class Initialized
DEBUG - 2016-03-08 12:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:02:10 --> Input Class Initialized
INFO - 2016-03-08 12:02:10 --> Language Class Initialized
INFO - 2016-03-08 12:02:10 --> Loader Class Initialized
INFO - 2016-03-08 12:02:10 --> Helper loaded: url_helper
INFO - 2016-03-08 12:02:10 --> Helper loaded: file_helper
INFO - 2016-03-08 12:02:10 --> Helper loaded: date_helper
INFO - 2016-03-08 12:02:10 --> Helper loaded: form_helper
INFO - 2016-03-08 12:02:10 --> Database Driver Class Initialized
INFO - 2016-03-08 12:02:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:02:11 --> Controller Class Initialized
INFO - 2016-03-08 12:02:11 --> Model Class Initialized
INFO - 2016-03-08 12:02:11 --> Model Class Initialized
INFO - 2016-03-08 12:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:02:11 --> Pagination Class Initialized
INFO - 2016-03-08 12:02:11 --> Helper loaded: text_helper
INFO - 2016-03-08 12:02:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:02:11 --> Final output sent to browser
DEBUG - 2016-03-08 15:02:11 --> Total execution time: 1.1634
INFO - 2016-03-08 12:02:14 --> Config Class Initialized
INFO - 2016-03-08 12:02:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:02:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:02:14 --> Utf8 Class Initialized
INFO - 2016-03-08 12:02:14 --> URI Class Initialized
INFO - 2016-03-08 12:02:14 --> Router Class Initialized
INFO - 2016-03-08 12:02:14 --> Output Class Initialized
INFO - 2016-03-08 12:02:14 --> Security Class Initialized
DEBUG - 2016-03-08 12:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:02:14 --> Input Class Initialized
INFO - 2016-03-08 12:02:14 --> Language Class Initialized
INFO - 2016-03-08 12:02:14 --> Loader Class Initialized
INFO - 2016-03-08 12:02:14 --> Helper loaded: url_helper
INFO - 2016-03-08 12:02:14 --> Helper loaded: file_helper
INFO - 2016-03-08 12:02:14 --> Helper loaded: date_helper
INFO - 2016-03-08 12:02:14 --> Helper loaded: form_helper
INFO - 2016-03-08 12:02:14 --> Database Driver Class Initialized
INFO - 2016-03-08 12:02:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:02:15 --> Controller Class Initialized
INFO - 2016-03-08 12:02:15 --> Model Class Initialized
INFO - 2016-03-08 12:02:15 --> Model Class Initialized
INFO - 2016-03-08 12:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:02:15 --> Pagination Class Initialized
INFO - 2016-03-08 12:02:15 --> Helper loaded: text_helper
INFO - 2016-03-08 12:02:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 15:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:02:15 --> Final output sent to browser
DEBUG - 2016-03-08 15:02:15 --> Total execution time: 1.2293
INFO - 2016-03-08 12:02:32 --> Config Class Initialized
INFO - 2016-03-08 12:02:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:02:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:02:32 --> Utf8 Class Initialized
INFO - 2016-03-08 12:02:32 --> URI Class Initialized
INFO - 2016-03-08 12:02:32 --> Router Class Initialized
INFO - 2016-03-08 12:02:32 --> Output Class Initialized
INFO - 2016-03-08 12:02:32 --> Security Class Initialized
DEBUG - 2016-03-08 12:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:02:32 --> Input Class Initialized
INFO - 2016-03-08 12:02:32 --> Language Class Initialized
INFO - 2016-03-08 12:02:32 --> Loader Class Initialized
INFO - 2016-03-08 12:02:32 --> Helper loaded: url_helper
INFO - 2016-03-08 12:02:32 --> Helper loaded: file_helper
INFO - 2016-03-08 12:02:32 --> Helper loaded: date_helper
INFO - 2016-03-08 12:02:32 --> Helper loaded: form_helper
INFO - 2016-03-08 12:02:32 --> Database Driver Class Initialized
INFO - 2016-03-08 12:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:02:33 --> Controller Class Initialized
INFO - 2016-03-08 12:02:33 --> Model Class Initialized
INFO - 2016-03-08 12:02:33 --> Model Class Initialized
INFO - 2016-03-08 12:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:02:33 --> Pagination Class Initialized
INFO - 2016-03-08 12:02:33 --> Helper loaded: text_helper
INFO - 2016-03-08 12:02:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:02:33 --> Final output sent to browser
DEBUG - 2016-03-08 15:02:33 --> Total execution time: 1.1683
INFO - 2016-03-08 12:02:42 --> Config Class Initialized
INFO - 2016-03-08 12:02:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:02:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:02:42 --> Utf8 Class Initialized
INFO - 2016-03-08 12:02:42 --> URI Class Initialized
INFO - 2016-03-08 12:02:42 --> Router Class Initialized
INFO - 2016-03-08 12:02:42 --> Output Class Initialized
INFO - 2016-03-08 12:02:42 --> Security Class Initialized
DEBUG - 2016-03-08 12:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:02:42 --> Input Class Initialized
INFO - 2016-03-08 12:02:42 --> Language Class Initialized
INFO - 2016-03-08 12:02:42 --> Loader Class Initialized
INFO - 2016-03-08 12:02:42 --> Helper loaded: url_helper
INFO - 2016-03-08 12:02:42 --> Helper loaded: file_helper
INFO - 2016-03-08 12:02:42 --> Helper loaded: date_helper
INFO - 2016-03-08 12:02:42 --> Helper loaded: form_helper
INFO - 2016-03-08 12:02:42 --> Database Driver Class Initialized
INFO - 2016-03-08 12:02:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:02:43 --> Controller Class Initialized
INFO - 2016-03-08 12:02:43 --> Model Class Initialized
INFO - 2016-03-08 12:02:43 --> Model Class Initialized
INFO - 2016-03-08 12:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:02:43 --> Pagination Class Initialized
INFO - 2016-03-08 12:02:43 --> Helper loaded: text_helper
INFO - 2016-03-08 12:02:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:02:43 --> Final output sent to browser
DEBUG - 2016-03-08 15:02:43 --> Total execution time: 1.1218
INFO - 2016-03-08 12:02:45 --> Config Class Initialized
INFO - 2016-03-08 12:02:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:02:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:02:45 --> Utf8 Class Initialized
INFO - 2016-03-08 12:02:45 --> URI Class Initialized
INFO - 2016-03-08 12:02:45 --> Router Class Initialized
INFO - 2016-03-08 12:02:45 --> Output Class Initialized
INFO - 2016-03-08 12:02:45 --> Security Class Initialized
DEBUG - 2016-03-08 12:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:02:45 --> Input Class Initialized
INFO - 2016-03-08 12:02:45 --> Language Class Initialized
INFO - 2016-03-08 12:02:45 --> Loader Class Initialized
INFO - 2016-03-08 12:02:45 --> Helper loaded: url_helper
INFO - 2016-03-08 12:02:45 --> Helper loaded: file_helper
INFO - 2016-03-08 12:02:45 --> Helper loaded: date_helper
INFO - 2016-03-08 12:02:45 --> Helper loaded: form_helper
INFO - 2016-03-08 12:02:45 --> Database Driver Class Initialized
INFO - 2016-03-08 12:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:02:46 --> Controller Class Initialized
INFO - 2016-03-08 12:02:46 --> Model Class Initialized
INFO - 2016-03-08 12:02:46 --> Model Class Initialized
INFO - 2016-03-08 12:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:02:46 --> Pagination Class Initialized
INFO - 2016-03-08 12:02:46 --> Helper loaded: text_helper
INFO - 2016-03-08 12:02:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:02:46 --> Final output sent to browser
DEBUG - 2016-03-08 15:02:46 --> Total execution time: 1.1453
INFO - 2016-03-08 12:07:21 --> Config Class Initialized
INFO - 2016-03-08 12:07:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:07:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:07:21 --> Utf8 Class Initialized
INFO - 2016-03-08 12:07:21 --> URI Class Initialized
DEBUG - 2016-03-08 12:07:21 --> No URI present. Default controller set.
INFO - 2016-03-08 12:07:21 --> Router Class Initialized
INFO - 2016-03-08 12:07:21 --> Output Class Initialized
INFO - 2016-03-08 12:07:21 --> Security Class Initialized
DEBUG - 2016-03-08 12:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:07:21 --> Input Class Initialized
INFO - 2016-03-08 12:07:21 --> Language Class Initialized
INFO - 2016-03-08 12:07:21 --> Loader Class Initialized
INFO - 2016-03-08 12:07:21 --> Helper loaded: url_helper
INFO - 2016-03-08 12:07:21 --> Helper loaded: file_helper
INFO - 2016-03-08 12:07:21 --> Helper loaded: date_helper
INFO - 2016-03-08 12:07:21 --> Helper loaded: form_helper
INFO - 2016-03-08 12:07:21 --> Database Driver Class Initialized
INFO - 2016-03-08 12:07:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:07:22 --> Controller Class Initialized
INFO - 2016-03-08 12:07:22 --> Model Class Initialized
INFO - 2016-03-08 12:07:22 --> Model Class Initialized
INFO - 2016-03-08 12:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:07:22 --> Pagination Class Initialized
INFO - 2016-03-08 12:07:22 --> Helper loaded: text_helper
INFO - 2016-03-08 12:07:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 15:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:07:22 --> Final output sent to browser
DEBUG - 2016-03-08 15:07:22 --> Total execution time: 1.1055
INFO - 2016-03-08 12:08:47 --> Config Class Initialized
INFO - 2016-03-08 12:08:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:08:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:08:47 --> Utf8 Class Initialized
INFO - 2016-03-08 12:08:47 --> URI Class Initialized
INFO - 2016-03-08 12:08:47 --> Router Class Initialized
INFO - 2016-03-08 12:08:47 --> Output Class Initialized
INFO - 2016-03-08 12:08:47 --> Security Class Initialized
DEBUG - 2016-03-08 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:08:47 --> Input Class Initialized
INFO - 2016-03-08 12:08:47 --> Language Class Initialized
INFO - 2016-03-08 12:08:47 --> Loader Class Initialized
INFO - 2016-03-08 12:08:47 --> Helper loaded: url_helper
INFO - 2016-03-08 12:08:47 --> Helper loaded: file_helper
INFO - 2016-03-08 12:08:47 --> Helper loaded: date_helper
INFO - 2016-03-08 12:08:47 --> Helper loaded: form_helper
INFO - 2016-03-08 12:08:47 --> Database Driver Class Initialized
INFO - 2016-03-08 12:08:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:08:49 --> Controller Class Initialized
INFO - 2016-03-08 12:08:49 --> Model Class Initialized
INFO - 2016-03-08 12:08:49 --> Model Class Initialized
INFO - 2016-03-08 12:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:08:49 --> Pagination Class Initialized
INFO - 2016-03-08 12:08:49 --> Helper loaded: text_helper
INFO - 2016-03-08 12:08:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:08:49 --> Final output sent to browser
DEBUG - 2016-03-08 15:08:49 --> Total execution time: 1.2150
INFO - 2016-03-08 12:08:58 --> Config Class Initialized
INFO - 2016-03-08 12:08:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:08:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:08:58 --> Utf8 Class Initialized
INFO - 2016-03-08 12:08:58 --> URI Class Initialized
INFO - 2016-03-08 12:08:58 --> Router Class Initialized
INFO - 2016-03-08 12:08:58 --> Output Class Initialized
INFO - 2016-03-08 12:08:58 --> Security Class Initialized
DEBUG - 2016-03-08 12:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:08:58 --> Input Class Initialized
INFO - 2016-03-08 12:08:58 --> Language Class Initialized
INFO - 2016-03-08 12:08:58 --> Loader Class Initialized
INFO - 2016-03-08 12:08:58 --> Helper loaded: url_helper
INFO - 2016-03-08 12:08:58 --> Helper loaded: file_helper
INFO - 2016-03-08 12:08:58 --> Helper loaded: date_helper
INFO - 2016-03-08 12:08:58 --> Helper loaded: form_helper
INFO - 2016-03-08 12:08:58 --> Database Driver Class Initialized
INFO - 2016-03-08 12:08:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:08:59 --> Controller Class Initialized
INFO - 2016-03-08 12:08:59 --> Model Class Initialized
INFO - 2016-03-08 12:08:59 --> Model Class Initialized
INFO - 2016-03-08 12:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:08:59 --> Pagination Class Initialized
INFO - 2016-03-08 12:08:59 --> Helper loaded: text_helper
INFO - 2016-03-08 12:08:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:08:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:08:59 --> Final output sent to browser
DEBUG - 2016-03-08 15:08:59 --> Total execution time: 1.1563
INFO - 2016-03-08 12:09:00 --> Config Class Initialized
INFO - 2016-03-08 12:09:00 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:09:00 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:09:00 --> Utf8 Class Initialized
INFO - 2016-03-08 12:09:00 --> URI Class Initialized
INFO - 2016-03-08 12:09:00 --> Router Class Initialized
INFO - 2016-03-08 12:09:00 --> Output Class Initialized
INFO - 2016-03-08 12:09:00 --> Security Class Initialized
DEBUG - 2016-03-08 12:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:09:00 --> Input Class Initialized
INFO - 2016-03-08 12:09:00 --> Language Class Initialized
INFO - 2016-03-08 12:09:00 --> Loader Class Initialized
INFO - 2016-03-08 12:09:00 --> Helper loaded: url_helper
INFO - 2016-03-08 12:09:00 --> Helper loaded: file_helper
INFO - 2016-03-08 12:09:00 --> Helper loaded: date_helper
INFO - 2016-03-08 12:09:00 --> Helper loaded: form_helper
INFO - 2016-03-08 12:09:00 --> Database Driver Class Initialized
INFO - 2016-03-08 12:09:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:09:01 --> Controller Class Initialized
INFO - 2016-03-08 12:09:01 --> Model Class Initialized
INFO - 2016-03-08 12:09:01 --> Model Class Initialized
INFO - 2016-03-08 12:09:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:09:01 --> Pagination Class Initialized
INFO - 2016-03-08 12:09:01 --> Helper loaded: text_helper
INFO - 2016-03-08 12:09:01 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 15:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 15:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:09:01 --> Final output sent to browser
DEBUG - 2016-03-08 15:09:01 --> Total execution time: 1.3065
INFO - 2016-03-08 12:09:02 --> Config Class Initialized
INFO - 2016-03-08 12:09:02 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:09:02 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:09:02 --> Utf8 Class Initialized
INFO - 2016-03-08 12:09:02 --> URI Class Initialized
INFO - 2016-03-08 12:09:02 --> Router Class Initialized
INFO - 2016-03-08 12:09:02 --> Output Class Initialized
INFO - 2016-03-08 12:09:02 --> Security Class Initialized
DEBUG - 2016-03-08 12:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:09:02 --> Input Class Initialized
INFO - 2016-03-08 12:09:02 --> Language Class Initialized
INFO - 2016-03-08 12:09:02 --> Loader Class Initialized
INFO - 2016-03-08 12:09:02 --> Helper loaded: url_helper
INFO - 2016-03-08 12:09:02 --> Helper loaded: file_helper
INFO - 2016-03-08 12:09:02 --> Helper loaded: date_helper
INFO - 2016-03-08 12:09:02 --> Helper loaded: form_helper
INFO - 2016-03-08 12:09:02 --> Database Driver Class Initialized
INFO - 2016-03-08 12:09:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:09:03 --> Controller Class Initialized
INFO - 2016-03-08 12:09:03 --> User Agent Class Initialized
INFO - 2016-03-08 12:09:03 --> Final output sent to browser
DEBUG - 2016-03-08 12:09:03 --> Total execution time: 1.1106
INFO - 2016-03-08 12:09:08 --> Config Class Initialized
INFO - 2016-03-08 12:09:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:09:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:09:08 --> Utf8 Class Initialized
INFO - 2016-03-08 12:09:08 --> URI Class Initialized
DEBUG - 2016-03-08 12:09:08 --> No URI present. Default controller set.
INFO - 2016-03-08 12:09:08 --> Router Class Initialized
INFO - 2016-03-08 12:09:08 --> Output Class Initialized
INFO - 2016-03-08 12:09:08 --> Security Class Initialized
DEBUG - 2016-03-08 12:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:09:08 --> Input Class Initialized
INFO - 2016-03-08 12:09:08 --> Language Class Initialized
INFO - 2016-03-08 12:09:08 --> Loader Class Initialized
INFO - 2016-03-08 12:09:08 --> Helper loaded: url_helper
INFO - 2016-03-08 12:09:08 --> Helper loaded: file_helper
INFO - 2016-03-08 12:09:08 --> Helper loaded: date_helper
INFO - 2016-03-08 12:09:08 --> Helper loaded: form_helper
INFO - 2016-03-08 12:09:08 --> Database Driver Class Initialized
INFO - 2016-03-08 12:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:09:09 --> Controller Class Initialized
INFO - 2016-03-08 12:09:09 --> Model Class Initialized
INFO - 2016-03-08 12:09:09 --> Model Class Initialized
INFO - 2016-03-08 12:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:09:09 --> Pagination Class Initialized
INFO - 2016-03-08 12:09:09 --> Helper loaded: text_helper
INFO - 2016-03-08 12:09:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 15:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:09:09 --> Final output sent to browser
DEBUG - 2016-03-08 15:09:09 --> Total execution time: 1.1365
INFO - 2016-03-08 12:11:09 --> Config Class Initialized
INFO - 2016-03-08 12:11:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:11:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:11:09 --> Utf8 Class Initialized
INFO - 2016-03-08 12:11:09 --> URI Class Initialized
DEBUG - 2016-03-08 12:11:09 --> No URI present. Default controller set.
INFO - 2016-03-08 12:11:09 --> Router Class Initialized
INFO - 2016-03-08 12:11:09 --> Output Class Initialized
INFO - 2016-03-08 12:11:09 --> Security Class Initialized
DEBUG - 2016-03-08 12:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:11:09 --> Input Class Initialized
INFO - 2016-03-08 12:11:09 --> Language Class Initialized
INFO - 2016-03-08 12:11:09 --> Loader Class Initialized
INFO - 2016-03-08 12:11:09 --> Helper loaded: url_helper
INFO - 2016-03-08 12:11:09 --> Helper loaded: file_helper
INFO - 2016-03-08 12:11:09 --> Helper loaded: date_helper
INFO - 2016-03-08 12:11:09 --> Helper loaded: form_helper
INFO - 2016-03-08 12:11:09 --> Database Driver Class Initialized
INFO - 2016-03-08 12:11:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:11:10 --> Controller Class Initialized
INFO - 2016-03-08 12:11:10 --> Model Class Initialized
INFO - 2016-03-08 12:11:10 --> Model Class Initialized
INFO - 2016-03-08 12:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:11:10 --> Pagination Class Initialized
INFO - 2016-03-08 12:11:10 --> Helper loaded: text_helper
INFO - 2016-03-08 12:11:10 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 15:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:11:10 --> Final output sent to browser
DEBUG - 2016-03-08 15:11:10 --> Total execution time: 1.1357
INFO - 2016-03-08 12:11:12 --> Config Class Initialized
INFO - 2016-03-08 12:11:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 12:11:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 12:11:12 --> Utf8 Class Initialized
INFO - 2016-03-08 12:11:12 --> URI Class Initialized
INFO - 2016-03-08 12:11:12 --> Router Class Initialized
INFO - 2016-03-08 12:11:12 --> Output Class Initialized
INFO - 2016-03-08 12:11:12 --> Security Class Initialized
DEBUG - 2016-03-08 12:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 12:11:12 --> Input Class Initialized
INFO - 2016-03-08 12:11:12 --> Language Class Initialized
INFO - 2016-03-08 12:11:12 --> Loader Class Initialized
INFO - 2016-03-08 12:11:12 --> Helper loaded: url_helper
INFO - 2016-03-08 12:11:12 --> Helper loaded: file_helper
INFO - 2016-03-08 12:11:12 --> Helper loaded: date_helper
INFO - 2016-03-08 12:11:12 --> Helper loaded: form_helper
INFO - 2016-03-08 12:11:12 --> Database Driver Class Initialized
INFO - 2016-03-08 12:11:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 12:11:13 --> Controller Class Initialized
INFO - 2016-03-08 12:11:14 --> Model Class Initialized
INFO - 2016-03-08 12:11:14 --> Model Class Initialized
INFO - 2016-03-08 12:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 12:11:14 --> Pagination Class Initialized
INFO - 2016-03-08 12:11:14 --> Helper loaded: text_helper
INFO - 2016-03-08 12:11:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 15:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 15:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 15:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 15:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 15:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 15:11:14 --> Final output sent to browser
DEBUG - 2016-03-08 15:11:14 --> Total execution time: 1.1355
INFO - 2016-03-08 14:14:55 --> Config Class Initialized
INFO - 2016-03-08 14:14:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 14:14:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 14:14:55 --> Utf8 Class Initialized
INFO - 2016-03-08 14:14:55 --> URI Class Initialized
DEBUG - 2016-03-08 14:14:55 --> No URI present. Default controller set.
INFO - 2016-03-08 14:14:55 --> Router Class Initialized
INFO - 2016-03-08 14:14:55 --> Output Class Initialized
INFO - 2016-03-08 14:14:55 --> Security Class Initialized
DEBUG - 2016-03-08 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 14:14:55 --> Input Class Initialized
INFO - 2016-03-08 14:14:55 --> Language Class Initialized
INFO - 2016-03-08 14:14:55 --> Loader Class Initialized
INFO - 2016-03-08 14:14:55 --> Helper loaded: url_helper
INFO - 2016-03-08 14:14:55 --> Helper loaded: file_helper
INFO - 2016-03-08 14:14:55 --> Helper loaded: date_helper
INFO - 2016-03-08 14:14:55 --> Helper loaded: form_helper
INFO - 2016-03-08 14:14:55 --> Database Driver Class Initialized
INFO - 2016-03-08 14:14:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 14:14:56 --> Controller Class Initialized
INFO - 2016-03-08 14:14:56 --> Model Class Initialized
INFO - 2016-03-08 14:14:56 --> Model Class Initialized
INFO - 2016-03-08 14:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 14:14:56 --> Pagination Class Initialized
INFO - 2016-03-08 14:14:56 --> Helper loaded: text_helper
INFO - 2016-03-08 14:14:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 17:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 17:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 17:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 17:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 17:14:56 --> Final output sent to browser
DEBUG - 2016-03-08 17:14:56 --> Total execution time: 1.2049
INFO - 2016-03-08 14:15:22 --> Config Class Initialized
INFO - 2016-03-08 14:15:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 14:15:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 14:15:22 --> Utf8 Class Initialized
INFO - 2016-03-08 14:15:22 --> URI Class Initialized
DEBUG - 2016-03-08 14:15:22 --> No URI present. Default controller set.
INFO - 2016-03-08 14:15:22 --> Router Class Initialized
INFO - 2016-03-08 14:15:22 --> Output Class Initialized
INFO - 2016-03-08 14:15:22 --> Security Class Initialized
DEBUG - 2016-03-08 14:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 14:15:22 --> Input Class Initialized
INFO - 2016-03-08 14:15:22 --> Language Class Initialized
INFO - 2016-03-08 14:15:22 --> Loader Class Initialized
INFO - 2016-03-08 14:15:22 --> Helper loaded: url_helper
INFO - 2016-03-08 14:15:22 --> Helper loaded: file_helper
INFO - 2016-03-08 14:15:22 --> Helper loaded: date_helper
INFO - 2016-03-08 14:15:22 --> Helper loaded: form_helper
INFO - 2016-03-08 14:15:22 --> Database Driver Class Initialized
INFO - 2016-03-08 14:15:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 14:15:23 --> Controller Class Initialized
INFO - 2016-03-08 14:15:23 --> Model Class Initialized
INFO - 2016-03-08 14:15:23 --> Model Class Initialized
INFO - 2016-03-08 14:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 14:15:23 --> Pagination Class Initialized
INFO - 2016-03-08 14:15:23 --> Helper loaded: text_helper
INFO - 2016-03-08 14:15:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 17:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 17:15:23 --> Final output sent to browser
DEBUG - 2016-03-08 17:15:23 --> Total execution time: 1.1461
INFO - 2016-03-08 14:17:44 --> Config Class Initialized
INFO - 2016-03-08 14:17:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 14:17:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 14:17:44 --> Utf8 Class Initialized
INFO - 2016-03-08 14:17:44 --> URI Class Initialized
DEBUG - 2016-03-08 14:17:44 --> No URI present. Default controller set.
INFO - 2016-03-08 14:17:44 --> Router Class Initialized
INFO - 2016-03-08 14:17:44 --> Output Class Initialized
INFO - 2016-03-08 14:17:44 --> Security Class Initialized
DEBUG - 2016-03-08 14:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 14:17:44 --> Input Class Initialized
INFO - 2016-03-08 14:17:44 --> Language Class Initialized
INFO - 2016-03-08 14:17:44 --> Loader Class Initialized
INFO - 2016-03-08 14:17:44 --> Helper loaded: url_helper
INFO - 2016-03-08 14:17:44 --> Helper loaded: file_helper
INFO - 2016-03-08 14:17:44 --> Helper loaded: date_helper
INFO - 2016-03-08 14:17:44 --> Helper loaded: form_helper
INFO - 2016-03-08 14:17:44 --> Database Driver Class Initialized
INFO - 2016-03-08 14:17:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 14:17:45 --> Controller Class Initialized
INFO - 2016-03-08 14:17:45 --> Model Class Initialized
INFO - 2016-03-08 14:17:45 --> Model Class Initialized
INFO - 2016-03-08 14:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 14:17:45 --> Pagination Class Initialized
INFO - 2016-03-08 14:17:45 --> Helper loaded: text_helper
INFO - 2016-03-08 14:17:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 17:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 17:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 17:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 17:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 17:17:45 --> Final output sent to browser
DEBUG - 2016-03-08 17:17:45 --> Total execution time: 1.1587
INFO - 2016-03-08 17:58:50 --> Config Class Initialized
INFO - 2016-03-08 17:58:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:58:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:58:50 --> Utf8 Class Initialized
INFO - 2016-03-08 17:58:50 --> URI Class Initialized
DEBUG - 2016-03-08 17:58:50 --> No URI present. Default controller set.
INFO - 2016-03-08 17:58:50 --> Router Class Initialized
INFO - 2016-03-08 17:58:50 --> Output Class Initialized
INFO - 2016-03-08 17:58:50 --> Security Class Initialized
DEBUG - 2016-03-08 17:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:58:50 --> Input Class Initialized
INFO - 2016-03-08 17:58:50 --> Language Class Initialized
INFO - 2016-03-08 17:58:50 --> Loader Class Initialized
INFO - 2016-03-08 17:58:50 --> Helper loaded: url_helper
INFO - 2016-03-08 17:58:50 --> Helper loaded: file_helper
INFO - 2016-03-08 17:58:50 --> Helper loaded: date_helper
INFO - 2016-03-08 17:58:50 --> Helper loaded: form_helper
INFO - 2016-03-08 17:58:50 --> Database Driver Class Initialized
INFO - 2016-03-08 17:58:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:58:51 --> Controller Class Initialized
INFO - 2016-03-08 17:58:51 --> Model Class Initialized
INFO - 2016-03-08 17:58:51 --> Model Class Initialized
INFO - 2016-03-08 17:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:58:51 --> Pagination Class Initialized
INFO - 2016-03-08 17:58:51 --> Helper loaded: text_helper
INFO - 2016-03-08 17:58:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-08 20:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:58:51 --> Final output sent to browser
DEBUG - 2016-03-08 20:58:51 --> Total execution time: 1.1539
INFO - 2016-03-08 17:58:54 --> Config Class Initialized
INFO - 2016-03-08 17:58:54 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:58:54 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:58:55 --> Utf8 Class Initialized
INFO - 2016-03-08 17:58:55 --> URI Class Initialized
INFO - 2016-03-08 17:58:55 --> Router Class Initialized
INFO - 2016-03-08 17:58:55 --> Output Class Initialized
INFO - 2016-03-08 17:58:55 --> Security Class Initialized
DEBUG - 2016-03-08 17:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:58:55 --> Input Class Initialized
INFO - 2016-03-08 17:58:55 --> Language Class Initialized
INFO - 2016-03-08 17:58:55 --> Loader Class Initialized
INFO - 2016-03-08 17:58:55 --> Helper loaded: url_helper
INFO - 2016-03-08 17:58:55 --> Helper loaded: file_helper
INFO - 2016-03-08 17:58:55 --> Helper loaded: date_helper
INFO - 2016-03-08 17:58:55 --> Helper loaded: form_helper
INFO - 2016-03-08 17:58:55 --> Database Driver Class Initialized
INFO - 2016-03-08 17:58:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:58:56 --> Controller Class Initialized
INFO - 2016-03-08 17:58:56 --> Model Class Initialized
INFO - 2016-03-08 17:58:56 --> Model Class Initialized
INFO - 2016-03-08 17:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:58:56 --> Pagination Class Initialized
INFO - 2016-03-08 17:58:56 --> Helper loaded: text_helper
INFO - 2016-03-08 17:58:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 20:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 20:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:58:56 --> Final output sent to browser
DEBUG - 2016-03-08 20:58:56 --> Total execution time: 1.1511
INFO - 2016-03-08 17:59:02 --> Config Class Initialized
INFO - 2016-03-08 17:59:02 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:02 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:02 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:02 --> URI Class Initialized
INFO - 2016-03-08 17:59:02 --> Router Class Initialized
INFO - 2016-03-08 17:59:02 --> Output Class Initialized
INFO - 2016-03-08 17:59:02 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:02 --> Input Class Initialized
INFO - 2016-03-08 17:59:02 --> Language Class Initialized
INFO - 2016-03-08 17:59:02 --> Loader Class Initialized
INFO - 2016-03-08 17:59:02 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:02 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:02 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:02 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:02 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:03 --> Controller Class Initialized
INFO - 2016-03-08 17:59:03 --> Model Class Initialized
INFO - 2016-03-08 17:59:03 --> Model Class Initialized
INFO - 2016-03-08 17:59:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:59:03 --> Pagination Class Initialized
INFO - 2016-03-08 17:59:03 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:03 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 20:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 20:59:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:59:03 --> Final output sent to browser
DEBUG - 2016-03-08 20:59:03 --> Total execution time: 1.1072
INFO - 2016-03-08 17:59:28 --> Config Class Initialized
INFO - 2016-03-08 17:59:28 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:28 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:28 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:28 --> URI Class Initialized
INFO - 2016-03-08 17:59:28 --> Router Class Initialized
INFO - 2016-03-08 17:59:28 --> Output Class Initialized
INFO - 2016-03-08 17:59:28 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:28 --> Input Class Initialized
INFO - 2016-03-08 17:59:28 --> Language Class Initialized
INFO - 2016-03-08 17:59:28 --> Loader Class Initialized
INFO - 2016-03-08 17:59:28 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:28 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:28 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:28 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:28 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:30 --> Controller Class Initialized
INFO - 2016-03-08 17:59:30 --> Model Class Initialized
INFO - 2016-03-08 17:59:30 --> Model Class Initialized
INFO - 2016-03-08 17:59:30 --> Form Validation Class Initialized
INFO - 2016-03-08 17:59:30 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:30 --> Final output sent to browser
DEBUG - 2016-03-08 17:59:30 --> Total execution time: 1.2629
INFO - 2016-03-08 17:59:37 --> Config Class Initialized
INFO - 2016-03-08 17:59:37 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:37 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:37 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:37 --> URI Class Initialized
INFO - 2016-03-08 17:59:37 --> Router Class Initialized
INFO - 2016-03-08 17:59:37 --> Output Class Initialized
INFO - 2016-03-08 17:59:37 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:37 --> Input Class Initialized
INFO - 2016-03-08 17:59:37 --> Language Class Initialized
INFO - 2016-03-08 17:59:37 --> Loader Class Initialized
INFO - 2016-03-08 17:59:37 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:37 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:37 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:37 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:37 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:38 --> Controller Class Initialized
INFO - 2016-03-08 17:59:38 --> Model Class Initialized
INFO - 2016-03-08 17:59:38 --> Model Class Initialized
INFO - 2016-03-08 17:59:38 --> Form Validation Class Initialized
INFO - 2016-03-08 17:59:38 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:38 --> Final output sent to browser
DEBUG - 2016-03-08 17:59:38 --> Total execution time: 1.2904
INFO - 2016-03-08 17:59:38 --> Config Class Initialized
INFO - 2016-03-08 17:59:38 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:38 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:38 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:38 --> URI Class Initialized
INFO - 2016-03-08 17:59:38 --> Router Class Initialized
INFO - 2016-03-08 17:59:38 --> Output Class Initialized
INFO - 2016-03-08 17:59:38 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:38 --> Input Class Initialized
INFO - 2016-03-08 17:59:38 --> Language Class Initialized
INFO - 2016-03-08 17:59:38 --> Loader Class Initialized
INFO - 2016-03-08 17:59:38 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:38 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:38 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:38 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:38 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:39 --> Controller Class Initialized
INFO - 2016-03-08 17:59:39 --> Model Class Initialized
INFO - 2016-03-08 17:59:39 --> Model Class Initialized
INFO - 2016-03-08 17:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:59:39 --> Pagination Class Initialized
INFO - 2016-03-08 17:59:39 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:39 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 20:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 20:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:59:39 --> Final output sent to browser
DEBUG - 2016-03-08 20:59:39 --> Total execution time: 1.1681
INFO - 2016-03-08 17:59:43 --> Config Class Initialized
INFO - 2016-03-08 17:59:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:43 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:43 --> URI Class Initialized
INFO - 2016-03-08 17:59:43 --> Router Class Initialized
INFO - 2016-03-08 17:59:43 --> Output Class Initialized
INFO - 2016-03-08 17:59:43 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:43 --> Input Class Initialized
INFO - 2016-03-08 17:59:43 --> Language Class Initialized
INFO - 2016-03-08 17:59:43 --> Loader Class Initialized
INFO - 2016-03-08 17:59:43 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:43 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:43 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:43 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:43 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:44 --> Controller Class Initialized
INFO - 2016-03-08 17:59:44 --> Model Class Initialized
INFO - 2016-03-08 17:59:44 --> Model Class Initialized
INFO - 2016-03-08 17:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:59:45 --> Pagination Class Initialized
INFO - 2016-03-08 17:59:45 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-08 20:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 20:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:59:45 --> Final output sent to browser
DEBUG - 2016-03-08 20:59:45 --> Total execution time: 1.1467
INFO - 2016-03-08 17:59:56 --> Config Class Initialized
INFO - 2016-03-08 17:59:56 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:56 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:56 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:56 --> URI Class Initialized
INFO - 2016-03-08 17:59:56 --> Router Class Initialized
INFO - 2016-03-08 17:59:56 --> Output Class Initialized
INFO - 2016-03-08 17:59:56 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:56 --> Input Class Initialized
INFO - 2016-03-08 17:59:56 --> Language Class Initialized
INFO - 2016-03-08 17:59:56 --> Loader Class Initialized
INFO - 2016-03-08 17:59:56 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:56 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:56 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:56 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:56 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:57 --> Controller Class Initialized
INFO - 2016-03-08 17:59:57 --> Model Class Initialized
INFO - 2016-03-08 17:59:57 --> Model Class Initialized
INFO - 2016-03-08 17:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:59:57 --> Pagination Class Initialized
INFO - 2016-03-08 17:59:57 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:57 --> Helper loaded: cookie_helper
ERROR - 2016-03-08 20:59:58 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 225
INFO - 2016-03-08 20:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 20:59:58 --> Form Validation Class Initialized
INFO - 2016-03-08 20:59:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-08 17:59:58 --> Config Class Initialized
INFO - 2016-03-08 17:59:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 17:59:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 17:59:58 --> Utf8 Class Initialized
INFO - 2016-03-08 17:59:58 --> URI Class Initialized
INFO - 2016-03-08 17:59:58 --> Router Class Initialized
INFO - 2016-03-08 17:59:58 --> Output Class Initialized
INFO - 2016-03-08 17:59:58 --> Security Class Initialized
DEBUG - 2016-03-08 17:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 17:59:58 --> Input Class Initialized
INFO - 2016-03-08 17:59:58 --> Language Class Initialized
INFO - 2016-03-08 17:59:58 --> Loader Class Initialized
INFO - 2016-03-08 17:59:58 --> Helper loaded: url_helper
INFO - 2016-03-08 17:59:58 --> Helper loaded: file_helper
INFO - 2016-03-08 17:59:58 --> Helper loaded: date_helper
INFO - 2016-03-08 17:59:58 --> Helper loaded: form_helper
INFO - 2016-03-08 17:59:58 --> Database Driver Class Initialized
INFO - 2016-03-08 17:59:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 17:59:59 --> Controller Class Initialized
INFO - 2016-03-08 17:59:59 --> Model Class Initialized
INFO - 2016-03-08 17:59:59 --> Model Class Initialized
INFO - 2016-03-08 17:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 17:59:59 --> Pagination Class Initialized
INFO - 2016-03-08 17:59:59 --> Helper loaded: text_helper
INFO - 2016-03-08 17:59:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 20:59:59 --> Severity: Notice --> Undefined index: per_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 197
ERROR - 2016-03-08 20:59:59 --> Severity: Notice --> Undefined variable: pageoffset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 197
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 20:59:59 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 20:59:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 20:59:59 --> Final output sent to browser
DEBUG - 2016-03-08 20:59:59 --> Total execution time: 1.2826
INFO - 2016-03-08 18:00:07 --> Config Class Initialized
INFO - 2016-03-08 18:00:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:00:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:00:07 --> Utf8 Class Initialized
INFO - 2016-03-08 18:00:07 --> URI Class Initialized
INFO - 2016-03-08 18:00:07 --> Router Class Initialized
INFO - 2016-03-08 18:00:07 --> Output Class Initialized
INFO - 2016-03-08 18:00:07 --> Security Class Initialized
DEBUG - 2016-03-08 18:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:00:07 --> Input Class Initialized
INFO - 2016-03-08 18:00:07 --> Language Class Initialized
INFO - 2016-03-08 18:00:07 --> Loader Class Initialized
INFO - 2016-03-08 18:00:07 --> Helper loaded: url_helper
INFO - 2016-03-08 18:00:07 --> Helper loaded: file_helper
INFO - 2016-03-08 18:00:07 --> Helper loaded: date_helper
INFO - 2016-03-08 18:00:07 --> Helper loaded: form_helper
INFO - 2016-03-08 18:00:07 --> Database Driver Class Initialized
INFO - 2016-03-08 18:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:00:08 --> Controller Class Initialized
INFO - 2016-03-08 18:00:08 --> Model Class Initialized
INFO - 2016-03-08 18:00:08 --> Model Class Initialized
INFO - 2016-03-08 18:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:00:08 --> Pagination Class Initialized
INFO - 2016-03-08 18:00:08 --> Helper loaded: text_helper
INFO - 2016-03-08 18:00:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:00:08 --> Final output sent to browser
DEBUG - 2016-03-08 21:00:08 --> Total execution time: 1.0996
INFO - 2016-03-08 18:01:01 --> Config Class Initialized
INFO - 2016-03-08 18:01:01 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:01:01 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:01:01 --> Utf8 Class Initialized
INFO - 2016-03-08 18:01:01 --> URI Class Initialized
INFO - 2016-03-08 18:01:01 --> Router Class Initialized
INFO - 2016-03-08 18:01:01 --> Output Class Initialized
INFO - 2016-03-08 18:01:01 --> Security Class Initialized
DEBUG - 2016-03-08 18:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:01:01 --> Input Class Initialized
INFO - 2016-03-08 18:01:01 --> Language Class Initialized
INFO - 2016-03-08 18:01:01 --> Loader Class Initialized
INFO - 2016-03-08 18:01:01 --> Helper loaded: url_helper
INFO - 2016-03-08 18:01:01 --> Helper loaded: file_helper
INFO - 2016-03-08 18:01:01 --> Helper loaded: date_helper
INFO - 2016-03-08 18:01:01 --> Helper loaded: form_helper
INFO - 2016-03-08 18:01:01 --> Database Driver Class Initialized
INFO - 2016-03-08 18:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:01:02 --> Controller Class Initialized
INFO - 2016-03-08 18:01:02 --> Model Class Initialized
INFO - 2016-03-08 18:01:02 --> Model Class Initialized
INFO - 2016-03-08 18:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:01:02 --> Pagination Class Initialized
INFO - 2016-03-08 18:01:02 --> Helper loaded: text_helper
INFO - 2016-03-08 18:01:02 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-08 21:01:03 --> Severity: Notice --> Undefined index: per_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 197
ERROR - 2016-03-08 21:01:03 --> Severity: Notice --> Undefined variable: pageoffset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 197
INFO - 2016-03-08 21:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 21:01:03 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 21:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 21:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:01:03 --> Final output sent to browser
DEBUG - 2016-03-08 21:01:03 --> Total execution time: 1.2370
INFO - 2016-03-08 18:07:52 --> Config Class Initialized
INFO - 2016-03-08 18:07:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:07:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:07:52 --> Utf8 Class Initialized
INFO - 2016-03-08 18:07:52 --> URI Class Initialized
INFO - 2016-03-08 18:07:52 --> Router Class Initialized
INFO - 2016-03-08 18:07:52 --> Output Class Initialized
INFO - 2016-03-08 18:07:52 --> Security Class Initialized
DEBUG - 2016-03-08 18:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:07:52 --> Input Class Initialized
INFO - 2016-03-08 18:07:52 --> Language Class Initialized
INFO - 2016-03-08 18:07:52 --> Loader Class Initialized
INFO - 2016-03-08 18:07:52 --> Helper loaded: url_helper
INFO - 2016-03-08 18:07:52 --> Helper loaded: file_helper
INFO - 2016-03-08 18:07:52 --> Helper loaded: date_helper
INFO - 2016-03-08 18:07:53 --> Helper loaded: form_helper
INFO - 2016-03-08 18:07:53 --> Database Driver Class Initialized
INFO - 2016-03-08 18:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:07:54 --> Controller Class Initialized
INFO - 2016-03-08 18:07:54 --> Model Class Initialized
INFO - 2016-03-08 18:07:54 --> Model Class Initialized
INFO - 2016-03-08 18:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:07:54 --> Pagination Class Initialized
INFO - 2016-03-08 18:07:54 --> Helper loaded: text_helper
INFO - 2016-03-08 18:07:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 21:07:54 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
ERROR - 2016-03-08 21:07:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
ERROR - 2016-03-08 21:07:54 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 21:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:07:54 --> Final output sent to browser
DEBUG - 2016-03-08 21:07:54 --> Total execution time: 1.3393
INFO - 2016-03-08 18:08:12 --> Config Class Initialized
INFO - 2016-03-08 18:08:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:08:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:08:12 --> Utf8 Class Initialized
INFO - 2016-03-08 18:08:12 --> URI Class Initialized
INFO - 2016-03-08 18:08:13 --> Router Class Initialized
INFO - 2016-03-08 18:08:13 --> Output Class Initialized
INFO - 2016-03-08 18:08:13 --> Security Class Initialized
DEBUG - 2016-03-08 18:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:08:13 --> Input Class Initialized
INFO - 2016-03-08 18:08:13 --> Language Class Initialized
INFO - 2016-03-08 18:08:13 --> Loader Class Initialized
INFO - 2016-03-08 18:08:13 --> Helper loaded: url_helper
INFO - 2016-03-08 18:08:13 --> Helper loaded: file_helper
INFO - 2016-03-08 18:08:13 --> Helper loaded: date_helper
INFO - 2016-03-08 18:08:13 --> Helper loaded: form_helper
INFO - 2016-03-08 18:08:13 --> Database Driver Class Initialized
INFO - 2016-03-08 18:08:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:08:14 --> Controller Class Initialized
INFO - 2016-03-08 18:08:14 --> Model Class Initialized
INFO - 2016-03-08 18:08:14 --> Model Class Initialized
INFO - 2016-03-08 18:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:08:14 --> Pagination Class Initialized
INFO - 2016-03-08 18:08:14 --> Helper loaded: text_helper
INFO - 2016-03-08 18:08:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:08:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:08:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:08:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:08:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:08:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:08:14 --> Final output sent to browser
DEBUG - 2016-03-08 21:08:14 --> Total execution time: 1.2690
INFO - 2016-03-08 18:08:55 --> Config Class Initialized
INFO - 2016-03-08 18:08:55 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:08:55 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:08:55 --> Utf8 Class Initialized
INFO - 2016-03-08 18:08:55 --> URI Class Initialized
INFO - 2016-03-08 18:08:55 --> Router Class Initialized
INFO - 2016-03-08 18:08:55 --> Output Class Initialized
INFO - 2016-03-08 18:08:55 --> Security Class Initialized
DEBUG - 2016-03-08 18:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:08:55 --> Input Class Initialized
INFO - 2016-03-08 18:08:55 --> Language Class Initialized
INFO - 2016-03-08 18:08:55 --> Loader Class Initialized
INFO - 2016-03-08 18:08:55 --> Helper loaded: url_helper
INFO - 2016-03-08 18:08:55 --> Helper loaded: file_helper
INFO - 2016-03-08 18:08:55 --> Helper loaded: date_helper
INFO - 2016-03-08 18:08:55 --> Helper loaded: form_helper
INFO - 2016-03-08 18:08:55 --> Database Driver Class Initialized
INFO - 2016-03-08 18:08:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:08:56 --> Controller Class Initialized
INFO - 2016-03-08 18:08:56 --> Model Class Initialized
INFO - 2016-03-08 18:08:56 --> Model Class Initialized
INFO - 2016-03-08 18:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:08:56 --> Pagination Class Initialized
INFO - 2016-03-08 18:08:56 --> Helper loaded: text_helper
INFO - 2016-03-08 18:08:56 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:08:56 --> Final output sent to browser
DEBUG - 2016-03-08 21:08:56 --> Total execution time: 1.2117
INFO - 2016-03-08 18:10:35 --> Config Class Initialized
INFO - 2016-03-08 18:10:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:10:36 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:10:36 --> Utf8 Class Initialized
INFO - 2016-03-08 18:10:36 --> URI Class Initialized
INFO - 2016-03-08 18:10:36 --> Router Class Initialized
INFO - 2016-03-08 18:10:36 --> Output Class Initialized
INFO - 2016-03-08 18:10:36 --> Security Class Initialized
DEBUG - 2016-03-08 18:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:10:36 --> Input Class Initialized
INFO - 2016-03-08 18:10:36 --> Language Class Initialized
INFO - 2016-03-08 18:10:36 --> Loader Class Initialized
INFO - 2016-03-08 18:10:36 --> Helper loaded: url_helper
INFO - 2016-03-08 18:10:36 --> Helper loaded: file_helper
INFO - 2016-03-08 18:10:36 --> Helper loaded: date_helper
INFO - 2016-03-08 18:10:36 --> Helper loaded: form_helper
INFO - 2016-03-08 18:10:36 --> Database Driver Class Initialized
INFO - 2016-03-08 18:10:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:10:37 --> Controller Class Initialized
INFO - 2016-03-08 18:10:37 --> Model Class Initialized
INFO - 2016-03-08 18:10:37 --> Model Class Initialized
INFO - 2016-03-08 18:10:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:10:37 --> Pagination Class Initialized
INFO - 2016-03-08 18:10:37 --> Helper loaded: text_helper
INFO - 2016-03-08 18:10:37 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:10:37 --> Final output sent to browser
DEBUG - 2016-03-08 21:10:37 --> Total execution time: 1.1522
INFO - 2016-03-08 18:11:13 --> Config Class Initialized
INFO - 2016-03-08 18:11:13 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:11:13 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:11:13 --> Utf8 Class Initialized
INFO - 2016-03-08 18:11:13 --> URI Class Initialized
INFO - 2016-03-08 18:11:13 --> Router Class Initialized
INFO - 2016-03-08 18:11:13 --> Output Class Initialized
INFO - 2016-03-08 18:11:13 --> Security Class Initialized
DEBUG - 2016-03-08 18:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:11:13 --> Input Class Initialized
INFO - 2016-03-08 18:11:13 --> Language Class Initialized
INFO - 2016-03-08 18:11:13 --> Loader Class Initialized
INFO - 2016-03-08 18:11:13 --> Helper loaded: url_helper
INFO - 2016-03-08 18:11:13 --> Helper loaded: file_helper
INFO - 2016-03-08 18:11:13 --> Helper loaded: date_helper
INFO - 2016-03-08 18:11:13 --> Helper loaded: form_helper
INFO - 2016-03-08 18:11:13 --> Database Driver Class Initialized
INFO - 2016-03-08 18:11:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:11:14 --> Controller Class Initialized
INFO - 2016-03-08 18:11:14 --> Model Class Initialized
INFO - 2016-03-08 18:11:14 --> Model Class Initialized
INFO - 2016-03-08 18:11:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:11:14 --> Pagination Class Initialized
INFO - 2016-03-08 18:11:14 --> Helper loaded: text_helper
INFO - 2016-03-08 18:11:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:11:14 --> Final output sent to browser
DEBUG - 2016-03-08 21:11:14 --> Total execution time: 1.1541
INFO - 2016-03-08 18:11:15 --> Config Class Initialized
INFO - 2016-03-08 18:11:15 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:11:15 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:11:15 --> Utf8 Class Initialized
INFO - 2016-03-08 18:11:15 --> URI Class Initialized
INFO - 2016-03-08 18:11:15 --> Router Class Initialized
INFO - 2016-03-08 18:11:15 --> Output Class Initialized
INFO - 2016-03-08 18:11:15 --> Security Class Initialized
DEBUG - 2016-03-08 18:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:11:15 --> Input Class Initialized
INFO - 2016-03-08 18:11:15 --> Language Class Initialized
INFO - 2016-03-08 18:11:15 --> Loader Class Initialized
INFO - 2016-03-08 18:11:15 --> Helper loaded: url_helper
INFO - 2016-03-08 18:11:15 --> Helper loaded: file_helper
INFO - 2016-03-08 18:11:15 --> Helper loaded: date_helper
INFO - 2016-03-08 18:11:15 --> Helper loaded: form_helper
INFO - 2016-03-08 18:11:15 --> Database Driver Class Initialized
INFO - 2016-03-08 18:11:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:11:16 --> Controller Class Initialized
INFO - 2016-03-08 18:11:16 --> Model Class Initialized
INFO - 2016-03-08 18:11:16 --> Model Class Initialized
INFO - 2016-03-08 18:11:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:11:16 --> Pagination Class Initialized
INFO - 2016-03-08 18:11:16 --> Helper loaded: text_helper
INFO - 2016-03-08 18:11:16 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:11:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:11:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:11:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:11:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:11:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:11:17 --> Final output sent to browser
DEBUG - 2016-03-08 21:11:17 --> Total execution time: 1.2633
INFO - 2016-03-08 18:12:38 --> Config Class Initialized
INFO - 2016-03-08 18:12:38 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:12:38 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:12:38 --> Utf8 Class Initialized
INFO - 2016-03-08 18:12:38 --> URI Class Initialized
INFO - 2016-03-08 18:12:38 --> Router Class Initialized
INFO - 2016-03-08 18:12:38 --> Output Class Initialized
INFO - 2016-03-08 18:12:38 --> Security Class Initialized
DEBUG - 2016-03-08 18:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:12:38 --> Input Class Initialized
INFO - 2016-03-08 18:12:38 --> Language Class Initialized
INFO - 2016-03-08 18:12:38 --> Loader Class Initialized
INFO - 2016-03-08 18:12:38 --> Helper loaded: url_helper
INFO - 2016-03-08 18:12:38 --> Helper loaded: file_helper
INFO - 2016-03-08 18:12:38 --> Helper loaded: date_helper
INFO - 2016-03-08 18:12:38 --> Helper loaded: form_helper
INFO - 2016-03-08 18:12:38 --> Database Driver Class Initialized
INFO - 2016-03-08 18:12:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:12:39 --> Controller Class Initialized
INFO - 2016-03-08 18:12:39 --> Model Class Initialized
INFO - 2016-03-08 18:12:39 --> Model Class Initialized
INFO - 2016-03-08 18:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:12:39 --> Pagination Class Initialized
INFO - 2016-03-08 18:12:39 --> Helper loaded: text_helper
INFO - 2016-03-08 18:12:39 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:12:39 --> Final output sent to browser
DEBUG - 2016-03-08 21:12:39 --> Total execution time: 1.2585
INFO - 2016-03-08 18:13:46 --> Config Class Initialized
INFO - 2016-03-08 18:13:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:13:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:13:46 --> Utf8 Class Initialized
INFO - 2016-03-08 18:13:46 --> URI Class Initialized
INFO - 2016-03-08 18:13:46 --> Router Class Initialized
INFO - 2016-03-08 18:13:46 --> Output Class Initialized
INFO - 2016-03-08 18:13:46 --> Security Class Initialized
DEBUG - 2016-03-08 18:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:13:46 --> Input Class Initialized
INFO - 2016-03-08 18:13:46 --> Language Class Initialized
INFO - 2016-03-08 18:13:46 --> Loader Class Initialized
INFO - 2016-03-08 18:13:46 --> Helper loaded: url_helper
INFO - 2016-03-08 18:13:46 --> Helper loaded: file_helper
INFO - 2016-03-08 18:13:46 --> Helper loaded: date_helper
INFO - 2016-03-08 18:13:46 --> Helper loaded: form_helper
INFO - 2016-03-08 18:13:46 --> Database Driver Class Initialized
INFO - 2016-03-08 18:13:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:13:47 --> Controller Class Initialized
INFO - 2016-03-08 18:13:47 --> Model Class Initialized
INFO - 2016-03-08 18:13:47 --> Model Class Initialized
INFO - 2016-03-08 18:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:13:47 --> Pagination Class Initialized
INFO - 2016-03-08 18:13:47 --> Helper loaded: text_helper
INFO - 2016-03-08 18:13:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:13:47 --> Final output sent to browser
DEBUG - 2016-03-08 21:13:47 --> Total execution time: 1.1532
INFO - 2016-03-08 18:14:13 --> Config Class Initialized
INFO - 2016-03-08 18:14:13 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:14:13 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:14:13 --> Utf8 Class Initialized
INFO - 2016-03-08 18:14:13 --> URI Class Initialized
INFO - 2016-03-08 18:14:13 --> Router Class Initialized
INFO - 2016-03-08 18:14:13 --> Output Class Initialized
INFO - 2016-03-08 18:14:13 --> Security Class Initialized
DEBUG - 2016-03-08 18:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:14:14 --> Input Class Initialized
INFO - 2016-03-08 18:14:14 --> Language Class Initialized
INFO - 2016-03-08 18:14:14 --> Loader Class Initialized
INFO - 2016-03-08 18:14:14 --> Helper loaded: url_helper
INFO - 2016-03-08 18:14:14 --> Helper loaded: file_helper
INFO - 2016-03-08 18:14:14 --> Helper loaded: date_helper
INFO - 2016-03-08 18:14:14 --> Helper loaded: form_helper
INFO - 2016-03-08 18:14:14 --> Database Driver Class Initialized
INFO - 2016-03-08 18:14:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:14:15 --> Controller Class Initialized
INFO - 2016-03-08 18:14:15 --> Model Class Initialized
INFO - 2016-03-08 18:14:15 --> Model Class Initialized
INFO - 2016-03-08 18:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:14:15 --> Pagination Class Initialized
INFO - 2016-03-08 18:14:15 --> Helper loaded: text_helper
INFO - 2016-03-08 18:14:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:14:15 --> Final output sent to browser
DEBUG - 2016-03-08 21:14:15 --> Total execution time: 1.2725
INFO - 2016-03-08 18:14:58 --> Config Class Initialized
INFO - 2016-03-08 18:14:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:14:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:14:58 --> Utf8 Class Initialized
INFO - 2016-03-08 18:14:58 --> URI Class Initialized
INFO - 2016-03-08 18:14:58 --> Router Class Initialized
INFO - 2016-03-08 18:14:58 --> Output Class Initialized
INFO - 2016-03-08 18:14:58 --> Security Class Initialized
DEBUG - 2016-03-08 18:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:14:58 --> Input Class Initialized
INFO - 2016-03-08 18:14:58 --> Language Class Initialized
INFO - 2016-03-08 18:14:58 --> Loader Class Initialized
INFO - 2016-03-08 18:14:58 --> Helper loaded: url_helper
INFO - 2016-03-08 18:14:58 --> Helper loaded: file_helper
INFO - 2016-03-08 18:14:58 --> Helper loaded: date_helper
INFO - 2016-03-08 18:14:58 --> Helper loaded: form_helper
INFO - 2016-03-08 18:14:58 --> Database Driver Class Initialized
INFO - 2016-03-08 18:15:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:15:00 --> Controller Class Initialized
INFO - 2016-03-08 18:15:00 --> Model Class Initialized
INFO - 2016-03-08 18:15:00 --> Model Class Initialized
INFO - 2016-03-08 18:15:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:15:00 --> Pagination Class Initialized
INFO - 2016-03-08 18:15:00 --> Helper loaded: text_helper
INFO - 2016-03-08 18:15:00 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:15:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:15:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:15:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:15:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:15:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:15:00 --> Final output sent to browser
DEBUG - 2016-03-08 21:15:00 --> Total execution time: 1.2061
INFO - 2016-03-08 18:15:07 --> Config Class Initialized
INFO - 2016-03-08 18:15:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:15:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:15:07 --> Utf8 Class Initialized
INFO - 2016-03-08 18:15:07 --> URI Class Initialized
INFO - 2016-03-08 18:15:07 --> Router Class Initialized
INFO - 2016-03-08 18:15:07 --> Output Class Initialized
INFO - 2016-03-08 18:15:07 --> Security Class Initialized
DEBUG - 2016-03-08 18:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:15:07 --> Input Class Initialized
INFO - 2016-03-08 18:15:07 --> Language Class Initialized
INFO - 2016-03-08 18:15:07 --> Loader Class Initialized
INFO - 2016-03-08 18:15:07 --> Helper loaded: url_helper
INFO - 2016-03-08 18:15:07 --> Helper loaded: file_helper
INFO - 2016-03-08 18:15:07 --> Helper loaded: date_helper
INFO - 2016-03-08 18:15:07 --> Helper loaded: form_helper
INFO - 2016-03-08 18:15:07 --> Database Driver Class Initialized
INFO - 2016-03-08 18:15:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:15:08 --> Controller Class Initialized
INFO - 2016-03-08 18:15:08 --> Model Class Initialized
INFO - 2016-03-08 18:15:08 --> Model Class Initialized
INFO - 2016-03-08 18:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:15:08 --> Pagination Class Initialized
INFO - 2016-03-08 18:15:08 --> Helper loaded: text_helper
INFO - 2016-03-08 18:15:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:15:08 --> Final output sent to browser
DEBUG - 2016-03-08 21:15:08 --> Total execution time: 1.0937
INFO - 2016-03-08 18:16:08 --> Config Class Initialized
INFO - 2016-03-08 18:16:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:16:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:16:08 --> Utf8 Class Initialized
INFO - 2016-03-08 18:16:08 --> URI Class Initialized
INFO - 2016-03-08 18:16:08 --> Router Class Initialized
INFO - 2016-03-08 18:16:08 --> Output Class Initialized
INFO - 2016-03-08 18:16:08 --> Security Class Initialized
DEBUG - 2016-03-08 18:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:16:08 --> Input Class Initialized
INFO - 2016-03-08 18:16:08 --> Language Class Initialized
INFO - 2016-03-08 18:16:08 --> Loader Class Initialized
INFO - 2016-03-08 18:16:08 --> Helper loaded: url_helper
INFO - 2016-03-08 18:16:08 --> Helper loaded: file_helper
INFO - 2016-03-08 18:16:08 --> Helper loaded: date_helper
INFO - 2016-03-08 18:16:08 --> Helper loaded: form_helper
INFO - 2016-03-08 18:16:08 --> Database Driver Class Initialized
INFO - 2016-03-08 18:16:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:16:09 --> Controller Class Initialized
INFO - 2016-03-08 18:16:09 --> Model Class Initialized
INFO - 2016-03-08 18:16:09 --> Model Class Initialized
INFO - 2016-03-08 18:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:16:09 --> Pagination Class Initialized
INFO - 2016-03-08 18:16:09 --> Helper loaded: text_helper
INFO - 2016-03-08 18:16:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:16:09 --> Final output sent to browser
DEBUG - 2016-03-08 21:16:09 --> Total execution time: 1.1448
INFO - 2016-03-08 18:23:33 --> Config Class Initialized
INFO - 2016-03-08 18:23:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:23:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:23:33 --> Utf8 Class Initialized
INFO - 2016-03-08 18:23:33 --> URI Class Initialized
INFO - 2016-03-08 18:23:33 --> Router Class Initialized
INFO - 2016-03-08 18:23:33 --> Output Class Initialized
INFO - 2016-03-08 18:23:33 --> Security Class Initialized
DEBUG - 2016-03-08 18:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:23:33 --> Input Class Initialized
INFO - 2016-03-08 18:23:33 --> Language Class Initialized
INFO - 2016-03-08 18:23:33 --> Loader Class Initialized
INFO - 2016-03-08 18:23:34 --> Helper loaded: url_helper
INFO - 2016-03-08 18:23:34 --> Helper loaded: file_helper
INFO - 2016-03-08 18:23:34 --> Helper loaded: date_helper
INFO - 2016-03-08 18:23:34 --> Helper loaded: form_helper
INFO - 2016-03-08 18:23:34 --> Database Driver Class Initialized
INFO - 2016-03-08 18:23:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:23:35 --> Controller Class Initialized
INFO - 2016-03-08 18:23:35 --> Model Class Initialized
INFO - 2016-03-08 18:23:35 --> Model Class Initialized
INFO - 2016-03-08 18:23:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:23:35 --> Pagination Class Initialized
INFO - 2016-03-08 18:23:35 --> Helper loaded: text_helper
INFO - 2016-03-08 18:23:35 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:23:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:23:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:23:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:23:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:23:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:23:35 --> Final output sent to browser
DEBUG - 2016-03-08 21:23:35 --> Total execution time: 1.1739
INFO - 2016-03-08 18:23:37 --> Config Class Initialized
INFO - 2016-03-08 18:23:37 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:23:37 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:23:37 --> Utf8 Class Initialized
INFO - 2016-03-08 18:23:37 --> URI Class Initialized
INFO - 2016-03-08 18:23:37 --> Router Class Initialized
INFO - 2016-03-08 18:23:37 --> Output Class Initialized
INFO - 2016-03-08 18:23:37 --> Security Class Initialized
DEBUG - 2016-03-08 18:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:23:37 --> Input Class Initialized
INFO - 2016-03-08 18:23:37 --> Language Class Initialized
INFO - 2016-03-08 18:23:37 --> Loader Class Initialized
INFO - 2016-03-08 18:23:37 --> Helper loaded: url_helper
INFO - 2016-03-08 18:23:37 --> Helper loaded: file_helper
INFO - 2016-03-08 18:23:37 --> Helper loaded: date_helper
INFO - 2016-03-08 18:23:37 --> Helper loaded: form_helper
INFO - 2016-03-08 18:23:37 --> Database Driver Class Initialized
INFO - 2016-03-08 18:23:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:23:38 --> Controller Class Initialized
INFO - 2016-03-08 18:23:38 --> Model Class Initialized
INFO - 2016-03-08 18:23:38 --> Model Class Initialized
INFO - 2016-03-08 18:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:23:38 --> Pagination Class Initialized
INFO - 2016-03-08 18:23:38 --> Helper loaded: text_helper
INFO - 2016-03-08 18:23:38 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:23:38 --> Final output sent to browser
DEBUG - 2016-03-08 21:23:38 --> Total execution time: 1.1245
INFO - 2016-03-08 18:23:46 --> Config Class Initialized
INFO - 2016-03-08 18:23:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:23:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:23:46 --> Utf8 Class Initialized
INFO - 2016-03-08 18:23:46 --> URI Class Initialized
INFO - 2016-03-08 18:23:46 --> Router Class Initialized
INFO - 2016-03-08 18:23:46 --> Output Class Initialized
INFO - 2016-03-08 18:23:46 --> Security Class Initialized
DEBUG - 2016-03-08 18:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:23:46 --> Input Class Initialized
INFO - 2016-03-08 18:23:46 --> Language Class Initialized
INFO - 2016-03-08 18:23:46 --> Loader Class Initialized
INFO - 2016-03-08 18:23:46 --> Helper loaded: url_helper
INFO - 2016-03-08 18:23:46 --> Helper loaded: file_helper
INFO - 2016-03-08 18:23:46 --> Helper loaded: date_helper
INFO - 2016-03-08 18:23:46 --> Helper loaded: form_helper
INFO - 2016-03-08 18:23:46 --> Database Driver Class Initialized
INFO - 2016-03-08 18:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:23:48 --> Controller Class Initialized
INFO - 2016-03-08 18:23:48 --> Model Class Initialized
INFO - 2016-03-08 18:23:48 --> Model Class Initialized
INFO - 2016-03-08 18:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:23:48 --> Pagination Class Initialized
INFO - 2016-03-08 18:23:48 --> Helper loaded: text_helper
INFO - 2016-03-08 18:23:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:23:48 --> Final output sent to browser
DEBUG - 2016-03-08 21:23:48 --> Total execution time: 1.1535
INFO - 2016-03-08 18:24:04 --> Config Class Initialized
INFO - 2016-03-08 18:24:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:04 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:04 --> URI Class Initialized
INFO - 2016-03-08 18:24:04 --> Router Class Initialized
INFO - 2016-03-08 18:24:04 --> Output Class Initialized
INFO - 2016-03-08 18:24:04 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:04 --> Input Class Initialized
INFO - 2016-03-08 18:24:04 --> Language Class Initialized
INFO - 2016-03-08 18:24:04 --> Loader Class Initialized
INFO - 2016-03-08 18:24:04 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:04 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:04 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:04 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:04 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:05 --> Controller Class Initialized
INFO - 2016-03-08 18:24:05 --> Model Class Initialized
INFO - 2016-03-08 18:24:05 --> Model Class Initialized
INFO - 2016-03-08 18:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:05 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:05 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:05 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:05 --> Total execution time: 1.1288
INFO - 2016-03-08 18:24:08 --> Config Class Initialized
INFO - 2016-03-08 18:24:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:08 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:08 --> URI Class Initialized
INFO - 2016-03-08 18:24:08 --> Router Class Initialized
INFO - 2016-03-08 18:24:08 --> Output Class Initialized
INFO - 2016-03-08 18:24:08 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:08 --> Input Class Initialized
INFO - 2016-03-08 18:24:08 --> Language Class Initialized
INFO - 2016-03-08 18:24:08 --> Loader Class Initialized
INFO - 2016-03-08 18:24:08 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:08 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:08 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:08 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:08 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:09 --> Controller Class Initialized
INFO - 2016-03-08 18:24:09 --> Model Class Initialized
INFO - 2016-03-08 18:24:09 --> Model Class Initialized
INFO - 2016-03-08 18:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:09 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:09 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:09 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:09 --> Total execution time: 1.1155
INFO - 2016-03-08 18:24:32 --> Config Class Initialized
INFO - 2016-03-08 18:24:32 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:32 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:32 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:32 --> URI Class Initialized
INFO - 2016-03-08 18:24:32 --> Router Class Initialized
INFO - 2016-03-08 18:24:32 --> Output Class Initialized
INFO - 2016-03-08 18:24:32 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:32 --> Input Class Initialized
INFO - 2016-03-08 18:24:32 --> Language Class Initialized
INFO - 2016-03-08 18:24:32 --> Loader Class Initialized
INFO - 2016-03-08 18:24:32 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:32 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:32 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:32 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:32 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:33 --> Controller Class Initialized
INFO - 2016-03-08 18:24:33 --> Model Class Initialized
INFO - 2016-03-08 18:24:33 --> Model Class Initialized
INFO - 2016-03-08 18:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:33 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:33 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:33 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:33 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:33 --> Total execution time: 1.1455
INFO - 2016-03-08 18:24:38 --> Config Class Initialized
INFO - 2016-03-08 18:24:38 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:38 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:38 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:38 --> URI Class Initialized
INFO - 2016-03-08 18:24:38 --> Router Class Initialized
INFO - 2016-03-08 18:24:38 --> Output Class Initialized
INFO - 2016-03-08 18:24:38 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:38 --> Input Class Initialized
INFO - 2016-03-08 18:24:38 --> Language Class Initialized
INFO - 2016-03-08 18:24:38 --> Loader Class Initialized
INFO - 2016-03-08 18:24:38 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:38 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:38 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:38 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:38 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:39 --> Controller Class Initialized
INFO - 2016-03-08 18:24:39 --> Model Class Initialized
INFO - 2016-03-08 18:24:39 --> Model Class Initialized
INFO - 2016-03-08 18:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:39 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:39 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:39 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:39 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:39 --> Total execution time: 1.2877
INFO - 2016-03-08 18:24:42 --> Config Class Initialized
INFO - 2016-03-08 18:24:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:42 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:42 --> URI Class Initialized
INFO - 2016-03-08 18:24:42 --> Router Class Initialized
INFO - 2016-03-08 18:24:42 --> Output Class Initialized
INFO - 2016-03-08 18:24:42 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:42 --> Input Class Initialized
INFO - 2016-03-08 18:24:42 --> Language Class Initialized
INFO - 2016-03-08 18:24:42 --> Loader Class Initialized
INFO - 2016-03-08 18:24:42 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:42 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:42 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:42 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:42 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:43 --> Controller Class Initialized
INFO - 2016-03-08 18:24:43 --> Model Class Initialized
INFO - 2016-03-08 18:24:43 --> Model Class Initialized
INFO - 2016-03-08 18:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:43 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:43 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:43 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:43 --> Total execution time: 1.1188
INFO - 2016-03-08 18:24:45 --> Config Class Initialized
INFO - 2016-03-08 18:24:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:45 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:45 --> URI Class Initialized
INFO - 2016-03-08 18:24:45 --> Router Class Initialized
INFO - 2016-03-08 18:24:45 --> Output Class Initialized
INFO - 2016-03-08 18:24:45 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:45 --> Input Class Initialized
INFO - 2016-03-08 18:24:45 --> Language Class Initialized
INFO - 2016-03-08 18:24:45 --> Loader Class Initialized
INFO - 2016-03-08 18:24:45 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:45 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:45 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:45 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:45 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:46 --> Controller Class Initialized
INFO - 2016-03-08 18:24:46 --> Model Class Initialized
INFO - 2016-03-08 18:24:46 --> Model Class Initialized
INFO - 2016-03-08 18:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:46 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:46 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:46 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:46 --> Total execution time: 1.1318
INFO - 2016-03-08 18:24:48 --> Config Class Initialized
INFO - 2016-03-08 18:24:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:24:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:24:48 --> Utf8 Class Initialized
INFO - 2016-03-08 18:24:48 --> URI Class Initialized
INFO - 2016-03-08 18:24:48 --> Router Class Initialized
INFO - 2016-03-08 18:24:48 --> Output Class Initialized
INFO - 2016-03-08 18:24:48 --> Security Class Initialized
DEBUG - 2016-03-08 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:24:48 --> Input Class Initialized
INFO - 2016-03-08 18:24:48 --> Language Class Initialized
INFO - 2016-03-08 18:24:48 --> Loader Class Initialized
INFO - 2016-03-08 18:24:48 --> Helper loaded: url_helper
INFO - 2016-03-08 18:24:48 --> Helper loaded: file_helper
INFO - 2016-03-08 18:24:48 --> Helper loaded: date_helper
INFO - 2016-03-08 18:24:48 --> Helper loaded: form_helper
INFO - 2016-03-08 18:24:48 --> Database Driver Class Initialized
INFO - 2016-03-08 18:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:24:49 --> Controller Class Initialized
INFO - 2016-03-08 18:24:49 --> Model Class Initialized
INFO - 2016-03-08 18:24:49 --> Model Class Initialized
INFO - 2016-03-08 18:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:24:49 --> Pagination Class Initialized
INFO - 2016-03-08 18:24:49 --> Helper loaded: text_helper
INFO - 2016-03-08 18:24:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:24:49 --> Final output sent to browser
DEBUG - 2016-03-08 21:24:49 --> Total execution time: 1.1696
INFO - 2016-03-08 18:25:16 --> Config Class Initialized
INFO - 2016-03-08 18:25:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:25:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:25:16 --> Utf8 Class Initialized
INFO - 2016-03-08 18:25:16 --> URI Class Initialized
INFO - 2016-03-08 18:25:16 --> Router Class Initialized
INFO - 2016-03-08 18:25:16 --> Output Class Initialized
INFO - 2016-03-08 18:25:16 --> Security Class Initialized
DEBUG - 2016-03-08 18:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:25:16 --> Input Class Initialized
INFO - 2016-03-08 18:25:16 --> Language Class Initialized
INFO - 2016-03-08 18:25:16 --> Loader Class Initialized
INFO - 2016-03-08 18:25:16 --> Helper loaded: url_helper
INFO - 2016-03-08 18:25:16 --> Helper loaded: file_helper
INFO - 2016-03-08 18:25:16 --> Helper loaded: date_helper
INFO - 2016-03-08 18:25:16 --> Helper loaded: form_helper
INFO - 2016-03-08 18:25:16 --> Database Driver Class Initialized
INFO - 2016-03-08 18:25:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:25:17 --> Controller Class Initialized
INFO - 2016-03-08 18:25:17 --> Model Class Initialized
INFO - 2016-03-08 18:25:17 --> Model Class Initialized
INFO - 2016-03-08 18:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:25:17 --> Pagination Class Initialized
INFO - 2016-03-08 18:25:17 --> Helper loaded: text_helper
INFO - 2016-03-08 18:25:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:25:17 --> Final output sent to browser
DEBUG - 2016-03-08 21:25:17 --> Total execution time: 1.1578
INFO - 2016-03-08 18:25:24 --> Config Class Initialized
INFO - 2016-03-08 18:25:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:25:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:25:24 --> Utf8 Class Initialized
INFO - 2016-03-08 18:25:24 --> URI Class Initialized
INFO - 2016-03-08 18:25:24 --> Router Class Initialized
INFO - 2016-03-08 18:25:24 --> Output Class Initialized
INFO - 2016-03-08 18:25:24 --> Security Class Initialized
DEBUG - 2016-03-08 18:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:25:24 --> Input Class Initialized
INFO - 2016-03-08 18:25:24 --> Language Class Initialized
INFO - 2016-03-08 18:25:24 --> Loader Class Initialized
INFO - 2016-03-08 18:25:24 --> Helper loaded: url_helper
INFO - 2016-03-08 18:25:24 --> Helper loaded: file_helper
INFO - 2016-03-08 18:25:24 --> Helper loaded: date_helper
INFO - 2016-03-08 18:25:24 --> Helper loaded: form_helper
INFO - 2016-03-08 18:25:24 --> Database Driver Class Initialized
INFO - 2016-03-08 18:25:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:25:25 --> Controller Class Initialized
INFO - 2016-03-08 18:25:25 --> Model Class Initialized
INFO - 2016-03-08 18:25:25 --> Model Class Initialized
INFO - 2016-03-08 18:25:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:25:25 --> Pagination Class Initialized
INFO - 2016-03-08 18:25:25 --> Helper loaded: text_helper
INFO - 2016-03-08 18:25:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:25:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:25:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:25:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:25:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:25:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:25:25 --> Final output sent to browser
DEBUG - 2016-03-08 21:25:25 --> Total execution time: 1.1372
INFO - 2016-03-08 18:25:27 --> Config Class Initialized
INFO - 2016-03-08 18:25:27 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:25:27 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:25:27 --> Utf8 Class Initialized
INFO - 2016-03-08 18:25:27 --> URI Class Initialized
INFO - 2016-03-08 18:25:27 --> Router Class Initialized
INFO - 2016-03-08 18:25:27 --> Output Class Initialized
INFO - 2016-03-08 18:25:27 --> Security Class Initialized
DEBUG - 2016-03-08 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:25:27 --> Input Class Initialized
INFO - 2016-03-08 18:25:27 --> Language Class Initialized
INFO - 2016-03-08 18:25:27 --> Loader Class Initialized
INFO - 2016-03-08 18:25:27 --> Helper loaded: url_helper
INFO - 2016-03-08 18:25:27 --> Helper loaded: file_helper
INFO - 2016-03-08 18:25:27 --> Helper loaded: date_helper
INFO - 2016-03-08 18:25:27 --> Helper loaded: form_helper
INFO - 2016-03-08 18:25:27 --> Database Driver Class Initialized
INFO - 2016-03-08 18:25:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:25:28 --> Controller Class Initialized
INFO - 2016-03-08 18:25:28 --> Model Class Initialized
INFO - 2016-03-08 18:25:28 --> Model Class Initialized
INFO - 2016-03-08 18:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:25:28 --> Pagination Class Initialized
INFO - 2016-03-08 18:25:28 --> Helper loaded: text_helper
INFO - 2016-03-08 18:25:28 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:25:28 --> Final output sent to browser
DEBUG - 2016-03-08 21:25:28 --> Total execution time: 1.1292
INFO - 2016-03-08 18:25:30 --> Config Class Initialized
INFO - 2016-03-08 18:25:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:25:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:25:30 --> Utf8 Class Initialized
INFO - 2016-03-08 18:25:30 --> URI Class Initialized
INFO - 2016-03-08 18:25:30 --> Router Class Initialized
INFO - 2016-03-08 18:25:30 --> Output Class Initialized
INFO - 2016-03-08 18:25:30 --> Security Class Initialized
DEBUG - 2016-03-08 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:25:30 --> Input Class Initialized
INFO - 2016-03-08 18:25:30 --> Language Class Initialized
INFO - 2016-03-08 18:25:30 --> Loader Class Initialized
INFO - 2016-03-08 18:25:30 --> Helper loaded: url_helper
INFO - 2016-03-08 18:25:30 --> Helper loaded: file_helper
INFO - 2016-03-08 18:25:30 --> Helper loaded: date_helper
INFO - 2016-03-08 18:25:30 --> Helper loaded: form_helper
INFO - 2016-03-08 18:25:30 --> Database Driver Class Initialized
INFO - 2016-03-08 18:25:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:25:31 --> Controller Class Initialized
INFO - 2016-03-08 18:25:31 --> Model Class Initialized
INFO - 2016-03-08 18:25:31 --> Model Class Initialized
INFO - 2016-03-08 18:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:25:31 --> Pagination Class Initialized
INFO - 2016-03-08 18:25:31 --> Helper loaded: text_helper
INFO - 2016-03-08 18:25:31 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:25:31 --> Final output sent to browser
DEBUG - 2016-03-08 21:25:31 --> Total execution time: 1.1239
INFO - 2016-03-08 18:25:41 --> Config Class Initialized
INFO - 2016-03-08 18:25:41 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:25:41 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:25:41 --> Utf8 Class Initialized
INFO - 2016-03-08 18:25:41 --> URI Class Initialized
INFO - 2016-03-08 18:25:41 --> Router Class Initialized
INFO - 2016-03-08 18:25:41 --> Output Class Initialized
INFO - 2016-03-08 18:25:41 --> Security Class Initialized
DEBUG - 2016-03-08 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:25:41 --> Input Class Initialized
INFO - 2016-03-08 18:25:41 --> Language Class Initialized
INFO - 2016-03-08 18:25:41 --> Loader Class Initialized
INFO - 2016-03-08 18:25:41 --> Helper loaded: url_helper
INFO - 2016-03-08 18:25:41 --> Helper loaded: file_helper
INFO - 2016-03-08 18:25:41 --> Helper loaded: date_helper
INFO - 2016-03-08 18:25:41 --> Helper loaded: form_helper
INFO - 2016-03-08 18:25:41 --> Database Driver Class Initialized
INFO - 2016-03-08 18:25:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:25:42 --> Controller Class Initialized
INFO - 2016-03-08 18:25:42 --> Model Class Initialized
INFO - 2016-03-08 18:25:42 --> Model Class Initialized
INFO - 2016-03-08 18:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:25:42 --> Pagination Class Initialized
INFO - 2016-03-08 18:25:42 --> Helper loaded: text_helper
INFO - 2016-03-08 18:25:42 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:25:42 --> Final output sent to browser
DEBUG - 2016-03-08 21:25:42 --> Total execution time: 1.2197
INFO - 2016-03-08 18:30:22 --> Config Class Initialized
INFO - 2016-03-08 18:30:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:30:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:30:22 --> Utf8 Class Initialized
INFO - 2016-03-08 18:30:22 --> URI Class Initialized
INFO - 2016-03-08 18:30:22 --> Router Class Initialized
INFO - 2016-03-08 18:30:22 --> Output Class Initialized
INFO - 2016-03-08 18:30:22 --> Security Class Initialized
DEBUG - 2016-03-08 18:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:30:22 --> Input Class Initialized
INFO - 2016-03-08 18:30:22 --> Language Class Initialized
INFO - 2016-03-08 18:30:22 --> Loader Class Initialized
INFO - 2016-03-08 18:30:22 --> Helper loaded: url_helper
INFO - 2016-03-08 18:30:22 --> Helper loaded: file_helper
INFO - 2016-03-08 18:30:22 --> Helper loaded: date_helper
INFO - 2016-03-08 18:30:22 --> Helper loaded: form_helper
INFO - 2016-03-08 18:30:22 --> Database Driver Class Initialized
INFO - 2016-03-08 18:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:30:24 --> Controller Class Initialized
INFO - 2016-03-08 18:30:24 --> Model Class Initialized
INFO - 2016-03-08 18:30:24 --> Model Class Initialized
INFO - 2016-03-08 18:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:30:24 --> Pagination Class Initialized
INFO - 2016-03-08 18:30:24 --> Helper loaded: text_helper
INFO - 2016-03-08 18:30:24 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:30:24 --> Final output sent to browser
DEBUG - 2016-03-08 21:30:24 --> Total execution time: 1.1431
INFO - 2016-03-08 18:35:22 --> Config Class Initialized
INFO - 2016-03-08 18:35:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:35:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:35:22 --> Utf8 Class Initialized
INFO - 2016-03-08 18:35:22 --> URI Class Initialized
INFO - 2016-03-08 18:35:22 --> Router Class Initialized
INFO - 2016-03-08 18:35:22 --> Output Class Initialized
INFO - 2016-03-08 18:35:22 --> Security Class Initialized
DEBUG - 2016-03-08 18:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:35:22 --> Input Class Initialized
INFO - 2016-03-08 18:35:22 --> Language Class Initialized
INFO - 2016-03-08 18:35:22 --> Loader Class Initialized
INFO - 2016-03-08 18:35:22 --> Helper loaded: url_helper
INFO - 2016-03-08 18:35:22 --> Helper loaded: file_helper
INFO - 2016-03-08 18:35:22 --> Helper loaded: date_helper
INFO - 2016-03-08 18:35:22 --> Helper loaded: form_helper
INFO - 2016-03-08 18:35:22 --> Database Driver Class Initialized
INFO - 2016-03-08 18:35:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:35:23 --> Controller Class Initialized
INFO - 2016-03-08 18:35:23 --> Model Class Initialized
INFO - 2016-03-08 18:35:24 --> Model Class Initialized
INFO - 2016-03-08 18:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:35:24 --> Pagination Class Initialized
INFO - 2016-03-08 18:35:24 --> Helper loaded: text_helper
INFO - 2016-03-08 18:35:24 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:35:24 --> Final output sent to browser
DEBUG - 2016-03-08 21:35:24 --> Total execution time: 1.1398
INFO - 2016-03-08 18:35:31 --> Config Class Initialized
INFO - 2016-03-08 18:35:31 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:35:31 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:35:31 --> Utf8 Class Initialized
INFO - 2016-03-08 18:35:31 --> URI Class Initialized
INFO - 2016-03-08 18:35:31 --> Router Class Initialized
INFO - 2016-03-08 18:35:31 --> Output Class Initialized
INFO - 2016-03-08 18:35:31 --> Security Class Initialized
DEBUG - 2016-03-08 18:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:35:31 --> Input Class Initialized
INFO - 2016-03-08 18:35:31 --> Language Class Initialized
INFO - 2016-03-08 18:35:31 --> Loader Class Initialized
INFO - 2016-03-08 18:35:31 --> Helper loaded: url_helper
INFO - 2016-03-08 18:35:31 --> Helper loaded: file_helper
INFO - 2016-03-08 18:35:31 --> Helper loaded: date_helper
INFO - 2016-03-08 18:35:31 --> Helper loaded: form_helper
INFO - 2016-03-08 18:35:31 --> Database Driver Class Initialized
INFO - 2016-03-08 18:35:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:35:32 --> Controller Class Initialized
INFO - 2016-03-08 18:35:32 --> Model Class Initialized
INFO - 2016-03-08 18:35:32 --> Model Class Initialized
INFO - 2016-03-08 18:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:35:32 --> Pagination Class Initialized
INFO - 2016-03-08 18:35:32 --> Helper loaded: text_helper
INFO - 2016-03-08 18:35:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:35:32 --> Final output sent to browser
DEBUG - 2016-03-08 21:35:32 --> Total execution time: 1.1027
INFO - 2016-03-08 18:35:39 --> Config Class Initialized
INFO - 2016-03-08 18:35:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:35:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:35:39 --> Utf8 Class Initialized
INFO - 2016-03-08 18:35:39 --> URI Class Initialized
INFO - 2016-03-08 18:35:39 --> Router Class Initialized
INFO - 2016-03-08 18:35:39 --> Output Class Initialized
INFO - 2016-03-08 18:35:39 --> Security Class Initialized
DEBUG - 2016-03-08 18:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:35:39 --> Input Class Initialized
INFO - 2016-03-08 18:35:39 --> Language Class Initialized
INFO - 2016-03-08 18:35:39 --> Loader Class Initialized
INFO - 2016-03-08 18:35:39 --> Helper loaded: url_helper
INFO - 2016-03-08 18:35:39 --> Helper loaded: file_helper
INFO - 2016-03-08 18:35:39 --> Helper loaded: date_helper
INFO - 2016-03-08 18:35:39 --> Helper loaded: form_helper
INFO - 2016-03-08 18:35:39 --> Database Driver Class Initialized
INFO - 2016-03-08 18:35:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:35:40 --> Controller Class Initialized
INFO - 2016-03-08 18:35:40 --> Model Class Initialized
INFO - 2016-03-08 18:35:40 --> Model Class Initialized
INFO - 2016-03-08 18:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:35:40 --> Pagination Class Initialized
INFO - 2016-03-08 18:35:40 --> Helper loaded: text_helper
INFO - 2016-03-08 18:35:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:35:40 --> Final output sent to browser
DEBUG - 2016-03-08 21:35:40 --> Total execution time: 1.1440
INFO - 2016-03-08 18:36:30 --> Config Class Initialized
INFO - 2016-03-08 18:36:30 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:36:30 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:36:30 --> Utf8 Class Initialized
INFO - 2016-03-08 18:36:30 --> URI Class Initialized
INFO - 2016-03-08 18:36:30 --> Router Class Initialized
INFO - 2016-03-08 18:36:30 --> Output Class Initialized
INFO - 2016-03-08 18:36:30 --> Security Class Initialized
DEBUG - 2016-03-08 18:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:36:30 --> Input Class Initialized
INFO - 2016-03-08 18:36:30 --> Language Class Initialized
INFO - 2016-03-08 18:36:30 --> Loader Class Initialized
INFO - 2016-03-08 18:36:30 --> Helper loaded: url_helper
INFO - 2016-03-08 18:36:30 --> Helper loaded: file_helper
INFO - 2016-03-08 18:36:30 --> Helper loaded: date_helper
INFO - 2016-03-08 18:36:30 --> Helper loaded: form_helper
INFO - 2016-03-08 18:36:30 --> Database Driver Class Initialized
INFO - 2016-03-08 18:36:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:36:31 --> Controller Class Initialized
INFO - 2016-03-08 18:36:31 --> Model Class Initialized
INFO - 2016-03-08 18:36:31 --> Model Class Initialized
INFO - 2016-03-08 18:36:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:36:31 --> Pagination Class Initialized
INFO - 2016-03-08 18:36:31 --> Helper loaded: text_helper
INFO - 2016-03-08 18:36:31 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:36:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:36:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:36:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:36:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:36:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:36:31 --> Final output sent to browser
DEBUG - 2016-03-08 21:36:31 --> Total execution time: 1.1147
INFO - 2016-03-08 18:45:50 --> Config Class Initialized
INFO - 2016-03-08 18:45:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:45:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:45:50 --> Utf8 Class Initialized
INFO - 2016-03-08 18:45:50 --> URI Class Initialized
INFO - 2016-03-08 18:45:50 --> Router Class Initialized
INFO - 2016-03-08 18:45:50 --> Output Class Initialized
INFO - 2016-03-08 18:45:50 --> Security Class Initialized
DEBUG - 2016-03-08 18:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:45:50 --> Input Class Initialized
INFO - 2016-03-08 18:45:50 --> Language Class Initialized
INFO - 2016-03-08 18:45:50 --> Loader Class Initialized
INFO - 2016-03-08 18:45:50 --> Helper loaded: url_helper
INFO - 2016-03-08 18:45:50 --> Helper loaded: file_helper
INFO - 2016-03-08 18:45:50 --> Helper loaded: date_helper
INFO - 2016-03-08 18:45:50 --> Helper loaded: form_helper
INFO - 2016-03-08 18:45:50 --> Database Driver Class Initialized
INFO - 2016-03-08 18:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:45:51 --> Controller Class Initialized
INFO - 2016-03-08 18:45:51 --> Model Class Initialized
INFO - 2016-03-08 18:45:51 --> Model Class Initialized
INFO - 2016-03-08 18:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:45:51 --> Pagination Class Initialized
INFO - 2016-03-08 18:45:51 --> Helper loaded: text_helper
INFO - 2016-03-08 18:45:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:45:51 --> Final output sent to browser
DEBUG - 2016-03-08 21:45:51 --> Total execution time: 1.1390
INFO - 2016-03-08 18:45:58 --> Config Class Initialized
INFO - 2016-03-08 18:45:58 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:45:58 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:45:58 --> Utf8 Class Initialized
INFO - 2016-03-08 18:45:58 --> URI Class Initialized
INFO - 2016-03-08 18:45:58 --> Router Class Initialized
INFO - 2016-03-08 18:45:58 --> Output Class Initialized
INFO - 2016-03-08 18:45:58 --> Security Class Initialized
DEBUG - 2016-03-08 18:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:45:58 --> Input Class Initialized
INFO - 2016-03-08 18:45:58 --> Language Class Initialized
INFO - 2016-03-08 18:45:58 --> Loader Class Initialized
INFO - 2016-03-08 18:45:58 --> Helper loaded: url_helper
INFO - 2016-03-08 18:45:58 --> Helper loaded: file_helper
INFO - 2016-03-08 18:45:58 --> Helper loaded: date_helper
INFO - 2016-03-08 18:45:58 --> Helper loaded: form_helper
INFO - 2016-03-08 18:45:58 --> Database Driver Class Initialized
INFO - 2016-03-08 18:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:45:59 --> Controller Class Initialized
INFO - 2016-03-08 18:45:59 --> Model Class Initialized
INFO - 2016-03-08 18:45:59 --> Model Class Initialized
INFO - 2016-03-08 18:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:45:59 --> Pagination Class Initialized
INFO - 2016-03-08 18:45:59 --> Helper loaded: text_helper
INFO - 2016-03-08 18:45:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:45:59 --> Final output sent to browser
DEBUG - 2016-03-08 21:45:59 --> Total execution time: 1.1161
INFO - 2016-03-08 18:46:12 --> Config Class Initialized
INFO - 2016-03-08 18:46:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:46:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:46:12 --> Utf8 Class Initialized
INFO - 2016-03-08 18:46:12 --> URI Class Initialized
INFO - 2016-03-08 18:46:12 --> Router Class Initialized
INFO - 2016-03-08 18:46:12 --> Output Class Initialized
INFO - 2016-03-08 18:46:12 --> Security Class Initialized
DEBUG - 2016-03-08 18:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:46:12 --> Input Class Initialized
INFO - 2016-03-08 18:46:12 --> Language Class Initialized
INFO - 2016-03-08 18:46:12 --> Loader Class Initialized
INFO - 2016-03-08 18:46:12 --> Helper loaded: url_helper
INFO - 2016-03-08 18:46:12 --> Helper loaded: file_helper
INFO - 2016-03-08 18:46:12 --> Helper loaded: date_helper
INFO - 2016-03-08 18:46:12 --> Helper loaded: form_helper
INFO - 2016-03-08 18:46:12 --> Database Driver Class Initialized
INFO - 2016-03-08 18:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:46:13 --> Controller Class Initialized
INFO - 2016-03-08 18:46:13 --> Model Class Initialized
INFO - 2016-03-08 18:46:13 --> Model Class Initialized
INFO - 2016-03-08 18:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:46:13 --> Pagination Class Initialized
INFO - 2016-03-08 18:46:13 --> Helper loaded: text_helper
INFO - 2016-03-08 18:46:13 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:46:13 --> Final output sent to browser
DEBUG - 2016-03-08 21:46:13 --> Total execution time: 1.0906
INFO - 2016-03-08 18:46:50 --> Config Class Initialized
INFO - 2016-03-08 18:46:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:46:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:46:50 --> Utf8 Class Initialized
INFO - 2016-03-08 18:46:50 --> URI Class Initialized
INFO - 2016-03-08 18:46:50 --> Router Class Initialized
INFO - 2016-03-08 18:46:50 --> Output Class Initialized
INFO - 2016-03-08 18:46:50 --> Security Class Initialized
DEBUG - 2016-03-08 18:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:46:50 --> Input Class Initialized
INFO - 2016-03-08 18:46:50 --> Language Class Initialized
INFO - 2016-03-08 18:46:50 --> Loader Class Initialized
INFO - 2016-03-08 18:46:50 --> Helper loaded: url_helper
INFO - 2016-03-08 18:46:50 --> Helper loaded: file_helper
INFO - 2016-03-08 18:46:50 --> Helper loaded: date_helper
INFO - 2016-03-08 18:46:50 --> Helper loaded: form_helper
INFO - 2016-03-08 18:46:50 --> Database Driver Class Initialized
INFO - 2016-03-08 18:46:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:46:51 --> Controller Class Initialized
INFO - 2016-03-08 18:46:51 --> Model Class Initialized
INFO - 2016-03-08 18:46:51 --> Model Class Initialized
INFO - 2016-03-08 18:46:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:46:51 --> Pagination Class Initialized
INFO - 2016-03-08 18:46:51 --> Helper loaded: text_helper
INFO - 2016-03-08 18:46:51 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:46:51 --> Final output sent to browser
DEBUG - 2016-03-08 21:46:51 --> Total execution time: 1.1033
INFO - 2016-03-08 18:46:53 --> Config Class Initialized
INFO - 2016-03-08 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:46:53 --> Utf8 Class Initialized
INFO - 2016-03-08 18:46:53 --> URI Class Initialized
INFO - 2016-03-08 18:46:53 --> Router Class Initialized
INFO - 2016-03-08 18:46:53 --> Output Class Initialized
INFO - 2016-03-08 18:46:53 --> Security Class Initialized
DEBUG - 2016-03-08 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:46:53 --> Input Class Initialized
INFO - 2016-03-08 18:46:53 --> Language Class Initialized
INFO - 2016-03-08 18:46:53 --> Loader Class Initialized
INFO - 2016-03-08 18:46:53 --> Helper loaded: url_helper
INFO - 2016-03-08 18:46:53 --> Helper loaded: file_helper
INFO - 2016-03-08 18:46:53 --> Helper loaded: date_helper
INFO - 2016-03-08 18:46:53 --> Helper loaded: form_helper
INFO - 2016-03-08 18:46:53 --> Database Driver Class Initialized
INFO - 2016-03-08 18:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:46:54 --> Controller Class Initialized
INFO - 2016-03-08 18:46:54 --> Model Class Initialized
INFO - 2016-03-08 18:46:54 --> Model Class Initialized
INFO - 2016-03-08 18:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:46:54 --> Pagination Class Initialized
INFO - 2016-03-08 18:46:54 --> Helper loaded: text_helper
INFO - 2016-03-08 18:46:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:46:54 --> Final output sent to browser
DEBUG - 2016-03-08 21:46:54 --> Total execution time: 1.1447
INFO - 2016-03-08 18:47:12 --> Config Class Initialized
INFO - 2016-03-08 18:47:12 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:47:12 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:47:12 --> Utf8 Class Initialized
INFO - 2016-03-08 18:47:12 --> URI Class Initialized
INFO - 2016-03-08 18:47:12 --> Router Class Initialized
INFO - 2016-03-08 18:47:12 --> Output Class Initialized
INFO - 2016-03-08 18:47:12 --> Security Class Initialized
DEBUG - 2016-03-08 18:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:47:12 --> Input Class Initialized
INFO - 2016-03-08 18:47:12 --> Language Class Initialized
INFO - 2016-03-08 18:47:12 --> Loader Class Initialized
INFO - 2016-03-08 18:47:12 --> Helper loaded: url_helper
INFO - 2016-03-08 18:47:12 --> Helper loaded: file_helper
INFO - 2016-03-08 18:47:12 --> Helper loaded: date_helper
INFO - 2016-03-08 18:47:12 --> Helper loaded: form_helper
INFO - 2016-03-08 18:47:12 --> Database Driver Class Initialized
INFO - 2016-03-08 18:47:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:47:13 --> Controller Class Initialized
INFO - 2016-03-08 18:47:13 --> Model Class Initialized
INFO - 2016-03-08 18:47:13 --> Model Class Initialized
INFO - 2016-03-08 18:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:47:13 --> Pagination Class Initialized
INFO - 2016-03-08 18:47:13 --> Helper loaded: text_helper
INFO - 2016-03-08 18:47:13 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:47:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:47:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:47:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:47:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:47:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:47:13 --> Final output sent to browser
DEBUG - 2016-03-08 21:47:13 --> Total execution time: 1.1907
INFO - 2016-03-08 18:47:31 --> Config Class Initialized
INFO - 2016-03-08 18:47:31 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:47:31 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:47:31 --> Utf8 Class Initialized
INFO - 2016-03-08 18:47:31 --> URI Class Initialized
INFO - 2016-03-08 18:47:31 --> Router Class Initialized
INFO - 2016-03-08 18:47:31 --> Output Class Initialized
INFO - 2016-03-08 18:47:31 --> Security Class Initialized
DEBUG - 2016-03-08 18:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:47:31 --> Input Class Initialized
INFO - 2016-03-08 18:47:31 --> Language Class Initialized
INFO - 2016-03-08 18:47:31 --> Loader Class Initialized
INFO - 2016-03-08 18:47:31 --> Helper loaded: url_helper
INFO - 2016-03-08 18:47:31 --> Helper loaded: file_helper
INFO - 2016-03-08 18:47:31 --> Helper loaded: date_helper
INFO - 2016-03-08 18:47:31 --> Helper loaded: form_helper
INFO - 2016-03-08 18:47:31 --> Database Driver Class Initialized
INFO - 2016-03-08 18:47:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:47:32 --> Controller Class Initialized
INFO - 2016-03-08 18:47:32 --> Model Class Initialized
INFO - 2016-03-08 18:47:32 --> Model Class Initialized
INFO - 2016-03-08 18:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:47:32 --> Pagination Class Initialized
INFO - 2016-03-08 18:47:32 --> Helper loaded: text_helper
INFO - 2016-03-08 18:47:32 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:47:32 --> Final output sent to browser
DEBUG - 2016-03-08 21:47:32 --> Total execution time: 1.1346
INFO - 2016-03-08 18:47:40 --> Config Class Initialized
INFO - 2016-03-08 18:47:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:47:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:47:40 --> Utf8 Class Initialized
INFO - 2016-03-08 18:47:40 --> URI Class Initialized
INFO - 2016-03-08 18:47:40 --> Router Class Initialized
INFO - 2016-03-08 18:47:40 --> Output Class Initialized
INFO - 2016-03-08 18:47:40 --> Security Class Initialized
DEBUG - 2016-03-08 18:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:47:40 --> Input Class Initialized
INFO - 2016-03-08 18:47:40 --> Language Class Initialized
INFO - 2016-03-08 18:47:40 --> Loader Class Initialized
INFO - 2016-03-08 18:47:40 --> Helper loaded: url_helper
INFO - 2016-03-08 18:47:40 --> Helper loaded: file_helper
INFO - 2016-03-08 18:47:40 --> Helper loaded: date_helper
INFO - 2016-03-08 18:47:40 --> Helper loaded: form_helper
INFO - 2016-03-08 18:47:40 --> Database Driver Class Initialized
INFO - 2016-03-08 18:47:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:47:41 --> Controller Class Initialized
INFO - 2016-03-08 18:47:41 --> Model Class Initialized
INFO - 2016-03-08 18:47:41 --> Model Class Initialized
INFO - 2016-03-08 18:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:47:41 --> Pagination Class Initialized
INFO - 2016-03-08 18:47:41 --> Helper loaded: text_helper
INFO - 2016-03-08 18:47:41 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:47:41 --> Final output sent to browser
DEBUG - 2016-03-08 21:47:41 --> Total execution time: 1.1268
INFO - 2016-03-08 18:48:10 --> Config Class Initialized
INFO - 2016-03-08 18:48:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:10 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:10 --> URI Class Initialized
INFO - 2016-03-08 18:48:10 --> Router Class Initialized
INFO - 2016-03-08 18:48:10 --> Output Class Initialized
INFO - 2016-03-08 18:48:10 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:10 --> Input Class Initialized
INFO - 2016-03-08 18:48:10 --> Language Class Initialized
INFO - 2016-03-08 18:48:10 --> Loader Class Initialized
INFO - 2016-03-08 18:48:10 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:10 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:10 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:10 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:10 --> Database Driver Class Initialized
INFO - 2016-03-08 18:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:48:11 --> Controller Class Initialized
INFO - 2016-03-08 18:48:11 --> Model Class Initialized
INFO - 2016-03-08 18:48:11 --> Model Class Initialized
INFO - 2016-03-08 18:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:48:11 --> Pagination Class Initialized
INFO - 2016-03-08 18:48:11 --> Helper loaded: text_helper
INFO - 2016-03-08 18:48:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:48:11 --> Final output sent to browser
DEBUG - 2016-03-08 21:48:11 --> Total execution time: 1.0991
INFO - 2016-03-08 18:48:39 --> Config Class Initialized
INFO - 2016-03-08 18:48:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:39 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:39 --> URI Class Initialized
INFO - 2016-03-08 18:48:39 --> Router Class Initialized
INFO - 2016-03-08 18:48:39 --> Output Class Initialized
INFO - 2016-03-08 18:48:39 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:39 --> Input Class Initialized
INFO - 2016-03-08 18:48:39 --> Language Class Initialized
INFO - 2016-03-08 18:48:39 --> Loader Class Initialized
INFO - 2016-03-08 18:48:39 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:39 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:39 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:39 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:39 --> Database Driver Class Initialized
INFO - 2016-03-08 18:48:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:48:40 --> Controller Class Initialized
INFO - 2016-03-08 18:48:40 --> Model Class Initialized
INFO - 2016-03-08 18:48:40 --> Model Class Initialized
INFO - 2016-03-08 18:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:48:40 --> Pagination Class Initialized
INFO - 2016-03-08 18:48:40 --> Helper loaded: text_helper
INFO - 2016-03-08 18:48:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:48:40 --> Final output sent to browser
DEBUG - 2016-03-08 21:48:40 --> Total execution time: 1.0879
INFO - 2016-03-08 18:48:42 --> Config Class Initialized
INFO - 2016-03-08 18:48:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:42 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:42 --> URI Class Initialized
INFO - 2016-03-08 18:48:42 --> Router Class Initialized
INFO - 2016-03-08 18:48:42 --> Output Class Initialized
INFO - 2016-03-08 18:48:42 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:42 --> Input Class Initialized
INFO - 2016-03-08 18:48:42 --> Language Class Initialized
INFO - 2016-03-08 18:48:42 --> Loader Class Initialized
INFO - 2016-03-08 18:48:42 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:42 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:42 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:42 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:42 --> Database Driver Class Initialized
INFO - 2016-03-08 18:48:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:48:43 --> Controller Class Initialized
INFO - 2016-03-08 18:48:43 --> Model Class Initialized
INFO - 2016-03-08 18:48:43 --> Model Class Initialized
INFO - 2016-03-08 18:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:48:43 --> Pagination Class Initialized
INFO - 2016-03-08 18:48:43 --> Helper loaded: text_helper
INFO - 2016-03-08 18:48:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:48:43 --> Final output sent to browser
DEBUG - 2016-03-08 21:48:43 --> Total execution time: 1.1117
INFO - 2016-03-08 18:48:45 --> Config Class Initialized
INFO - 2016-03-08 18:48:45 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:45 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:45 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:45 --> URI Class Initialized
INFO - 2016-03-08 18:48:45 --> Router Class Initialized
INFO - 2016-03-08 18:48:45 --> Output Class Initialized
INFO - 2016-03-08 18:48:45 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:45 --> Input Class Initialized
INFO - 2016-03-08 18:48:45 --> Language Class Initialized
INFO - 2016-03-08 18:48:45 --> Loader Class Initialized
INFO - 2016-03-08 18:48:45 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:45 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:45 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:45 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:45 --> Database Driver Class Initialized
INFO - 2016-03-08 18:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:48:46 --> Controller Class Initialized
INFO - 2016-03-08 18:48:46 --> Model Class Initialized
INFO - 2016-03-08 18:48:46 --> Model Class Initialized
INFO - 2016-03-08 18:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:48:46 --> Pagination Class Initialized
INFO - 2016-03-08 18:48:46 --> Helper loaded: text_helper
INFO - 2016-03-08 18:48:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:48:46 --> Final output sent to browser
DEBUG - 2016-03-08 21:48:46 --> Total execution time: 1.1412
INFO - 2016-03-08 18:48:48 --> Config Class Initialized
INFO - 2016-03-08 18:48:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:48 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:48 --> URI Class Initialized
INFO - 2016-03-08 18:48:48 --> Router Class Initialized
INFO - 2016-03-08 18:48:48 --> Output Class Initialized
INFO - 2016-03-08 18:48:48 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:48 --> Input Class Initialized
INFO - 2016-03-08 18:48:48 --> Language Class Initialized
INFO - 2016-03-08 18:48:48 --> Loader Class Initialized
INFO - 2016-03-08 18:48:48 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:48 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:48 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:48 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:48 --> Database Driver Class Initialized
INFO - 2016-03-08 18:48:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:48:49 --> Controller Class Initialized
INFO - 2016-03-08 18:48:49 --> Model Class Initialized
INFO - 2016-03-08 18:48:49 --> Model Class Initialized
INFO - 2016-03-08 18:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:48:49 --> Pagination Class Initialized
INFO - 2016-03-08 18:48:49 --> Helper loaded: text_helper
INFO - 2016-03-08 18:48:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:48:49 --> Final output sent to browser
DEBUG - 2016-03-08 21:48:49 --> Total execution time: 1.1375
INFO - 2016-03-08 18:48:59 --> Config Class Initialized
INFO - 2016-03-08 18:48:59 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:48:59 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:48:59 --> Utf8 Class Initialized
INFO - 2016-03-08 18:48:59 --> URI Class Initialized
INFO - 2016-03-08 18:48:59 --> Router Class Initialized
INFO - 2016-03-08 18:48:59 --> Output Class Initialized
INFO - 2016-03-08 18:48:59 --> Security Class Initialized
DEBUG - 2016-03-08 18:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:48:59 --> Input Class Initialized
INFO - 2016-03-08 18:48:59 --> Language Class Initialized
INFO - 2016-03-08 18:48:59 --> Loader Class Initialized
INFO - 2016-03-08 18:48:59 --> Helper loaded: url_helper
INFO - 2016-03-08 18:48:59 --> Helper loaded: file_helper
INFO - 2016-03-08 18:48:59 --> Helper loaded: date_helper
INFO - 2016-03-08 18:48:59 --> Helper loaded: form_helper
INFO - 2016-03-08 18:48:59 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:00 --> Controller Class Initialized
INFO - 2016-03-08 18:49:00 --> Model Class Initialized
INFO - 2016-03-08 18:49:00 --> Model Class Initialized
INFO - 2016-03-08 18:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:00 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:00 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:00 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:00 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:00 --> Total execution time: 1.1399
INFO - 2016-03-08 18:49:09 --> Config Class Initialized
INFO - 2016-03-08 18:49:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:09 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:09 --> URI Class Initialized
INFO - 2016-03-08 18:49:09 --> Router Class Initialized
INFO - 2016-03-08 18:49:09 --> Output Class Initialized
INFO - 2016-03-08 18:49:09 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:09 --> Input Class Initialized
INFO - 2016-03-08 18:49:09 --> Language Class Initialized
INFO - 2016-03-08 18:49:09 --> Loader Class Initialized
INFO - 2016-03-08 18:49:09 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:09 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:09 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:09 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:09 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:11 --> Controller Class Initialized
INFO - 2016-03-08 18:49:11 --> Model Class Initialized
INFO - 2016-03-08 18:49:11 --> Model Class Initialized
INFO - 2016-03-08 18:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:11 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:11 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:11 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:11 --> Total execution time: 1.1485
INFO - 2016-03-08 18:49:16 --> Config Class Initialized
INFO - 2016-03-08 18:49:16 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:16 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:16 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:16 --> URI Class Initialized
INFO - 2016-03-08 18:49:16 --> Router Class Initialized
INFO - 2016-03-08 18:49:16 --> Output Class Initialized
INFO - 2016-03-08 18:49:16 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:16 --> Input Class Initialized
INFO - 2016-03-08 18:49:16 --> Language Class Initialized
INFO - 2016-03-08 18:49:16 --> Loader Class Initialized
INFO - 2016-03-08 18:49:16 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:16 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:16 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:16 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:16 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:17 --> Controller Class Initialized
INFO - 2016-03-08 18:49:17 --> Model Class Initialized
INFO - 2016-03-08 18:49:17 --> Model Class Initialized
INFO - 2016-03-08 18:49:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:17 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:17 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:17 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:17 --> Total execution time: 1.1596
INFO - 2016-03-08 18:49:25 --> Config Class Initialized
INFO - 2016-03-08 18:49:25 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:25 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:25 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:25 --> URI Class Initialized
INFO - 2016-03-08 18:49:25 --> Router Class Initialized
INFO - 2016-03-08 18:49:25 --> Output Class Initialized
INFO - 2016-03-08 18:49:25 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:25 --> Input Class Initialized
INFO - 2016-03-08 18:49:25 --> Language Class Initialized
INFO - 2016-03-08 18:49:25 --> Loader Class Initialized
INFO - 2016-03-08 18:49:25 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:25 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:25 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:25 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:25 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:26 --> Controller Class Initialized
INFO - 2016-03-08 18:49:26 --> Model Class Initialized
INFO - 2016-03-08 18:49:26 --> Model Class Initialized
INFO - 2016-03-08 18:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:26 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:26 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:26 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:26 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:26 --> Total execution time: 1.1298
INFO - 2016-03-08 18:49:29 --> Config Class Initialized
INFO - 2016-03-08 18:49:29 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:29 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:29 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:29 --> URI Class Initialized
INFO - 2016-03-08 18:49:29 --> Router Class Initialized
INFO - 2016-03-08 18:49:29 --> Output Class Initialized
INFO - 2016-03-08 18:49:29 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:29 --> Input Class Initialized
INFO - 2016-03-08 18:49:29 --> Language Class Initialized
INFO - 2016-03-08 18:49:29 --> Loader Class Initialized
INFO - 2016-03-08 18:49:29 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:29 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:29 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:29 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:29 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:30 --> Controller Class Initialized
INFO - 2016-03-08 18:49:30 --> Model Class Initialized
INFO - 2016-03-08 18:49:30 --> Model Class Initialized
INFO - 2016-03-08 18:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:31 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:31 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:31 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:31 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:31 --> Total execution time: 1.1053
INFO - 2016-03-08 18:49:33 --> Config Class Initialized
INFO - 2016-03-08 18:49:33 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:33 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:33 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:33 --> URI Class Initialized
INFO - 2016-03-08 18:49:33 --> Router Class Initialized
INFO - 2016-03-08 18:49:33 --> Output Class Initialized
INFO - 2016-03-08 18:49:33 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:33 --> Input Class Initialized
INFO - 2016-03-08 18:49:33 --> Language Class Initialized
INFO - 2016-03-08 18:49:33 --> Loader Class Initialized
INFO - 2016-03-08 18:49:33 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:33 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:33 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:33 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:33 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:34 --> Controller Class Initialized
INFO - 2016-03-08 18:49:34 --> Model Class Initialized
INFO - 2016-03-08 18:49:34 --> Model Class Initialized
INFO - 2016-03-08 18:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:34 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:34 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:34 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:34 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:34 --> Total execution time: 1.1472
INFO - 2016-03-08 18:49:42 --> Config Class Initialized
INFO - 2016-03-08 18:49:42 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:49:42 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:49:42 --> Utf8 Class Initialized
INFO - 2016-03-08 18:49:42 --> URI Class Initialized
INFO - 2016-03-08 18:49:42 --> Router Class Initialized
INFO - 2016-03-08 18:49:42 --> Output Class Initialized
INFO - 2016-03-08 18:49:42 --> Security Class Initialized
DEBUG - 2016-03-08 18:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:49:42 --> Input Class Initialized
INFO - 2016-03-08 18:49:42 --> Language Class Initialized
INFO - 2016-03-08 18:49:42 --> Loader Class Initialized
INFO - 2016-03-08 18:49:42 --> Helper loaded: url_helper
INFO - 2016-03-08 18:49:42 --> Helper loaded: file_helper
INFO - 2016-03-08 18:49:42 --> Helper loaded: date_helper
INFO - 2016-03-08 18:49:42 --> Helper loaded: form_helper
INFO - 2016-03-08 18:49:42 --> Database Driver Class Initialized
INFO - 2016-03-08 18:49:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:49:43 --> Controller Class Initialized
INFO - 2016-03-08 18:49:43 --> Model Class Initialized
INFO - 2016-03-08 18:49:43 --> Model Class Initialized
INFO - 2016-03-08 18:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:49:43 --> Pagination Class Initialized
INFO - 2016-03-08 18:49:43 --> Helper loaded: text_helper
INFO - 2016-03-08 18:49:43 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:49:43 --> Final output sent to browser
DEBUG - 2016-03-08 21:49:43 --> Total execution time: 1.1809
INFO - 2016-03-08 18:50:35 --> Config Class Initialized
INFO - 2016-03-08 18:50:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:50:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:50:35 --> Utf8 Class Initialized
INFO - 2016-03-08 18:50:35 --> URI Class Initialized
INFO - 2016-03-08 18:50:35 --> Router Class Initialized
INFO - 2016-03-08 18:50:35 --> Output Class Initialized
INFO - 2016-03-08 18:50:35 --> Security Class Initialized
DEBUG - 2016-03-08 18:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:50:35 --> Input Class Initialized
INFO - 2016-03-08 18:50:35 --> Language Class Initialized
INFO - 2016-03-08 18:50:35 --> Loader Class Initialized
INFO - 2016-03-08 18:50:35 --> Helper loaded: url_helper
INFO - 2016-03-08 18:50:35 --> Helper loaded: file_helper
INFO - 2016-03-08 18:50:35 --> Helper loaded: date_helper
INFO - 2016-03-08 18:50:35 --> Helper loaded: form_helper
INFO - 2016-03-08 18:50:35 --> Database Driver Class Initialized
INFO - 2016-03-08 18:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:50:36 --> Controller Class Initialized
INFO - 2016-03-08 18:50:36 --> Model Class Initialized
INFO - 2016-03-08 18:50:36 --> Model Class Initialized
INFO - 2016-03-08 18:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:50:36 --> Pagination Class Initialized
INFO - 2016-03-08 18:50:36 --> Helper loaded: text_helper
INFO - 2016-03-08 18:50:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:50:37 --> Final output sent to browser
DEBUG - 2016-03-08 21:50:37 --> Total execution time: 1.1196
INFO - 2016-03-08 18:50:41 --> Config Class Initialized
INFO - 2016-03-08 18:50:41 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:50:41 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:50:41 --> Utf8 Class Initialized
INFO - 2016-03-08 18:50:41 --> URI Class Initialized
INFO - 2016-03-08 18:50:41 --> Router Class Initialized
INFO - 2016-03-08 18:50:41 --> Output Class Initialized
INFO - 2016-03-08 18:50:41 --> Security Class Initialized
DEBUG - 2016-03-08 18:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:50:41 --> Input Class Initialized
INFO - 2016-03-08 18:50:41 --> Language Class Initialized
INFO - 2016-03-08 18:50:41 --> Loader Class Initialized
INFO - 2016-03-08 18:50:41 --> Helper loaded: url_helper
INFO - 2016-03-08 18:50:41 --> Helper loaded: file_helper
INFO - 2016-03-08 18:50:41 --> Helper loaded: date_helper
INFO - 2016-03-08 18:50:41 --> Helper loaded: form_helper
INFO - 2016-03-08 18:50:41 --> Database Driver Class Initialized
INFO - 2016-03-08 18:50:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:50:42 --> Controller Class Initialized
INFO - 2016-03-08 18:50:42 --> Model Class Initialized
INFO - 2016-03-08 18:50:42 --> Model Class Initialized
INFO - 2016-03-08 18:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:50:42 --> Pagination Class Initialized
INFO - 2016-03-08 18:50:42 --> Helper loaded: text_helper
INFO - 2016-03-08 18:50:42 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:50:42 --> Final output sent to browser
DEBUG - 2016-03-08 21:50:42 --> Total execution time: 1.1615
INFO - 2016-03-08 18:50:44 --> Config Class Initialized
INFO - 2016-03-08 18:50:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:50:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:50:44 --> Utf8 Class Initialized
INFO - 2016-03-08 18:50:44 --> URI Class Initialized
INFO - 2016-03-08 18:50:44 --> Router Class Initialized
INFO - 2016-03-08 18:50:44 --> Output Class Initialized
INFO - 2016-03-08 18:50:44 --> Security Class Initialized
DEBUG - 2016-03-08 18:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:50:44 --> Input Class Initialized
INFO - 2016-03-08 18:50:44 --> Language Class Initialized
INFO - 2016-03-08 18:50:44 --> Loader Class Initialized
INFO - 2016-03-08 18:50:44 --> Helper loaded: url_helper
INFO - 2016-03-08 18:50:44 --> Helper loaded: file_helper
INFO - 2016-03-08 18:50:44 --> Helper loaded: date_helper
INFO - 2016-03-08 18:50:44 --> Helper loaded: form_helper
INFO - 2016-03-08 18:50:44 --> Database Driver Class Initialized
INFO - 2016-03-08 18:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:50:45 --> Controller Class Initialized
INFO - 2016-03-08 18:50:45 --> Model Class Initialized
INFO - 2016-03-08 18:50:45 --> Model Class Initialized
INFO - 2016-03-08 18:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:50:45 --> Pagination Class Initialized
INFO - 2016-03-08 18:50:45 --> Helper loaded: text_helper
INFO - 2016-03-08 18:50:45 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:50:45 --> Final output sent to browser
DEBUG - 2016-03-08 21:50:45 --> Total execution time: 1.1138
INFO - 2016-03-08 18:52:09 --> Config Class Initialized
INFO - 2016-03-08 18:52:09 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:52:09 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:52:09 --> Utf8 Class Initialized
INFO - 2016-03-08 18:52:09 --> URI Class Initialized
INFO - 2016-03-08 18:52:09 --> Router Class Initialized
INFO - 2016-03-08 18:52:09 --> Output Class Initialized
INFO - 2016-03-08 18:52:09 --> Security Class Initialized
DEBUG - 2016-03-08 18:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:52:09 --> Input Class Initialized
INFO - 2016-03-08 18:52:09 --> Language Class Initialized
INFO - 2016-03-08 18:52:09 --> Loader Class Initialized
INFO - 2016-03-08 18:52:09 --> Helper loaded: url_helper
INFO - 2016-03-08 18:52:09 --> Helper loaded: file_helper
INFO - 2016-03-08 18:52:09 --> Helper loaded: date_helper
INFO - 2016-03-08 18:52:09 --> Helper loaded: form_helper
INFO - 2016-03-08 18:52:09 --> Database Driver Class Initialized
INFO - 2016-03-08 18:52:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:52:10 --> Controller Class Initialized
INFO - 2016-03-08 18:52:10 --> Model Class Initialized
INFO - 2016-03-08 18:52:10 --> Model Class Initialized
INFO - 2016-03-08 18:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:52:10 --> Pagination Class Initialized
INFO - 2016-03-08 18:52:10 --> Helper loaded: text_helper
INFO - 2016-03-08 18:52:10 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:52:10 --> Final output sent to browser
DEBUG - 2016-03-08 21:52:10 --> Total execution time: 1.1625
INFO - 2016-03-08 18:52:15 --> Config Class Initialized
INFO - 2016-03-08 18:52:15 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:52:15 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:52:15 --> Utf8 Class Initialized
INFO - 2016-03-08 18:52:15 --> URI Class Initialized
INFO - 2016-03-08 18:52:15 --> Router Class Initialized
INFO - 2016-03-08 18:52:15 --> Output Class Initialized
INFO - 2016-03-08 18:52:15 --> Security Class Initialized
DEBUG - 2016-03-08 18:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:52:15 --> Input Class Initialized
INFO - 2016-03-08 18:52:15 --> Language Class Initialized
INFO - 2016-03-08 18:52:15 --> Loader Class Initialized
INFO - 2016-03-08 18:52:15 --> Helper loaded: url_helper
INFO - 2016-03-08 18:52:15 --> Helper loaded: file_helper
INFO - 2016-03-08 18:52:15 --> Helper loaded: date_helper
INFO - 2016-03-08 18:52:15 --> Helper loaded: form_helper
INFO - 2016-03-08 18:52:15 --> Database Driver Class Initialized
INFO - 2016-03-08 18:52:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:52:16 --> Controller Class Initialized
INFO - 2016-03-08 18:52:16 --> Model Class Initialized
INFO - 2016-03-08 18:52:16 --> Model Class Initialized
INFO - 2016-03-08 18:52:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:52:17 --> Pagination Class Initialized
INFO - 2016-03-08 18:52:17 --> Helper loaded: text_helper
INFO - 2016-03-08 18:52:17 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:52:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:52:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:52:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:52:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:52:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:52:17 --> Final output sent to browser
DEBUG - 2016-03-08 21:52:17 --> Total execution time: 1.1207
INFO - 2016-03-08 18:52:44 --> Config Class Initialized
INFO - 2016-03-08 18:52:44 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:52:44 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:52:44 --> Utf8 Class Initialized
INFO - 2016-03-08 18:52:44 --> URI Class Initialized
INFO - 2016-03-08 18:52:44 --> Router Class Initialized
INFO - 2016-03-08 18:52:44 --> Output Class Initialized
INFO - 2016-03-08 18:52:44 --> Security Class Initialized
DEBUG - 2016-03-08 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:52:44 --> Input Class Initialized
INFO - 2016-03-08 18:52:44 --> Language Class Initialized
INFO - 2016-03-08 18:52:44 --> Loader Class Initialized
INFO - 2016-03-08 18:52:44 --> Helper loaded: url_helper
INFO - 2016-03-08 18:52:44 --> Helper loaded: file_helper
INFO - 2016-03-08 18:52:44 --> Helper loaded: date_helper
INFO - 2016-03-08 18:52:44 --> Helper loaded: form_helper
INFO - 2016-03-08 18:52:44 --> Database Driver Class Initialized
INFO - 2016-03-08 18:52:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:52:46 --> Controller Class Initialized
INFO - 2016-03-08 18:52:46 --> Model Class Initialized
INFO - 2016-03-08 18:52:46 --> Model Class Initialized
INFO - 2016-03-08 18:52:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:52:46 --> Pagination Class Initialized
INFO - 2016-03-08 18:52:46 --> Helper loaded: text_helper
INFO - 2016-03-08 18:52:46 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:52:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:52:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:52:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:52:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:52:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:52:46 --> Final output sent to browser
DEBUG - 2016-03-08 21:52:46 --> Total execution time: 1.1752
INFO - 2016-03-08 18:52:51 --> Config Class Initialized
INFO - 2016-03-08 18:52:51 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:52:51 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:52:51 --> Utf8 Class Initialized
INFO - 2016-03-08 18:52:51 --> URI Class Initialized
INFO - 2016-03-08 18:52:51 --> Router Class Initialized
INFO - 2016-03-08 18:52:51 --> Output Class Initialized
INFO - 2016-03-08 18:52:51 --> Security Class Initialized
DEBUG - 2016-03-08 18:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:52:51 --> Input Class Initialized
INFO - 2016-03-08 18:52:51 --> Language Class Initialized
INFO - 2016-03-08 18:52:51 --> Loader Class Initialized
INFO - 2016-03-08 18:52:51 --> Helper loaded: url_helper
INFO - 2016-03-08 18:52:51 --> Helper loaded: file_helper
INFO - 2016-03-08 18:52:51 --> Helper loaded: date_helper
INFO - 2016-03-08 18:52:51 --> Helper loaded: form_helper
INFO - 2016-03-08 18:52:51 --> Database Driver Class Initialized
INFO - 2016-03-08 18:52:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:52:52 --> Controller Class Initialized
INFO - 2016-03-08 18:52:52 --> Model Class Initialized
INFO - 2016-03-08 18:52:52 --> Model Class Initialized
INFO - 2016-03-08 18:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:52:52 --> Pagination Class Initialized
INFO - 2016-03-08 18:52:52 --> Helper loaded: text_helper
INFO - 2016-03-08 18:52:52 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:52:52 --> Final output sent to browser
DEBUG - 2016-03-08 21:52:52 --> Total execution time: 1.1611
INFO - 2016-03-08 18:59:43 --> Config Class Initialized
INFO - 2016-03-08 18:59:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:59:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:59:43 --> Utf8 Class Initialized
INFO - 2016-03-08 18:59:43 --> URI Class Initialized
INFO - 2016-03-08 18:59:43 --> Router Class Initialized
INFO - 2016-03-08 18:59:43 --> Output Class Initialized
INFO - 2016-03-08 18:59:43 --> Security Class Initialized
DEBUG - 2016-03-08 18:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:59:43 --> Input Class Initialized
INFO - 2016-03-08 18:59:43 --> Language Class Initialized
INFO - 2016-03-08 18:59:43 --> Loader Class Initialized
INFO - 2016-03-08 18:59:43 --> Helper loaded: url_helper
INFO - 2016-03-08 18:59:43 --> Helper loaded: file_helper
INFO - 2016-03-08 18:59:43 --> Helper loaded: date_helper
INFO - 2016-03-08 18:59:43 --> Helper loaded: form_helper
INFO - 2016-03-08 18:59:43 --> Database Driver Class Initialized
INFO - 2016-03-08 18:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:59:44 --> Controller Class Initialized
INFO - 2016-03-08 18:59:44 --> Model Class Initialized
INFO - 2016-03-08 18:59:44 --> Model Class Initialized
INFO - 2016-03-08 18:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:59:44 --> Pagination Class Initialized
INFO - 2016-03-08 18:59:44 --> Helper loaded: text_helper
INFO - 2016-03-08 18:59:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:59:44 --> Final output sent to browser
DEBUG - 2016-03-08 21:59:44 --> Total execution time: 1.1516
INFO - 2016-03-08 18:59:47 --> Config Class Initialized
INFO - 2016-03-08 18:59:47 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:59:47 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:59:47 --> Utf8 Class Initialized
INFO - 2016-03-08 18:59:47 --> URI Class Initialized
INFO - 2016-03-08 18:59:47 --> Router Class Initialized
INFO - 2016-03-08 18:59:47 --> Output Class Initialized
INFO - 2016-03-08 18:59:47 --> Security Class Initialized
DEBUG - 2016-03-08 18:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:59:47 --> Input Class Initialized
INFO - 2016-03-08 18:59:47 --> Language Class Initialized
INFO - 2016-03-08 18:59:47 --> Loader Class Initialized
INFO - 2016-03-08 18:59:47 --> Helper loaded: url_helper
INFO - 2016-03-08 18:59:47 --> Helper loaded: file_helper
INFO - 2016-03-08 18:59:47 --> Helper loaded: date_helper
INFO - 2016-03-08 18:59:47 --> Helper loaded: form_helper
INFO - 2016-03-08 18:59:47 --> Database Driver Class Initialized
INFO - 2016-03-08 18:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:59:48 --> Controller Class Initialized
INFO - 2016-03-08 18:59:48 --> Model Class Initialized
INFO - 2016-03-08 18:59:48 --> Model Class Initialized
INFO - 2016-03-08 18:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:59:48 --> Pagination Class Initialized
INFO - 2016-03-08 18:59:48 --> Helper loaded: text_helper
INFO - 2016-03-08 18:59:48 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:59:48 --> Final output sent to browser
DEBUG - 2016-03-08 21:59:48 --> Total execution time: 1.1201
INFO - 2016-03-08 18:59:51 --> Config Class Initialized
INFO - 2016-03-08 18:59:51 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:59:51 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:59:51 --> Utf8 Class Initialized
INFO - 2016-03-08 18:59:51 --> URI Class Initialized
INFO - 2016-03-08 18:59:51 --> Router Class Initialized
INFO - 2016-03-08 18:59:51 --> Output Class Initialized
INFO - 2016-03-08 18:59:51 --> Security Class Initialized
DEBUG - 2016-03-08 18:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:59:51 --> Input Class Initialized
INFO - 2016-03-08 18:59:51 --> Language Class Initialized
INFO - 2016-03-08 18:59:51 --> Loader Class Initialized
INFO - 2016-03-08 18:59:51 --> Helper loaded: url_helper
INFO - 2016-03-08 18:59:51 --> Helper loaded: file_helper
INFO - 2016-03-08 18:59:51 --> Helper loaded: date_helper
INFO - 2016-03-08 18:59:51 --> Helper loaded: form_helper
INFO - 2016-03-08 18:59:51 --> Database Driver Class Initialized
INFO - 2016-03-08 18:59:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:59:52 --> Controller Class Initialized
INFO - 2016-03-08 18:59:52 --> Model Class Initialized
INFO - 2016-03-08 18:59:52 --> Model Class Initialized
INFO - 2016-03-08 18:59:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:59:52 --> Pagination Class Initialized
INFO - 2016-03-08 18:59:52 --> Helper loaded: text_helper
INFO - 2016-03-08 18:59:52 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 21:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 21:59:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:59:52 --> Final output sent to browser
DEBUG - 2016-03-08 21:59:52 --> Total execution time: 1.1082
INFO - 2016-03-08 18:59:53 --> Config Class Initialized
INFO - 2016-03-08 18:59:53 --> Hooks Class Initialized
DEBUG - 2016-03-08 18:59:53 --> UTF-8 Support Enabled
INFO - 2016-03-08 18:59:53 --> Utf8 Class Initialized
INFO - 2016-03-08 18:59:53 --> URI Class Initialized
INFO - 2016-03-08 18:59:53 --> Router Class Initialized
INFO - 2016-03-08 18:59:53 --> Output Class Initialized
INFO - 2016-03-08 18:59:53 --> Security Class Initialized
DEBUG - 2016-03-08 18:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 18:59:53 --> Input Class Initialized
INFO - 2016-03-08 18:59:53 --> Language Class Initialized
INFO - 2016-03-08 18:59:53 --> Loader Class Initialized
INFO - 2016-03-08 18:59:53 --> Helper loaded: url_helper
INFO - 2016-03-08 18:59:53 --> Helper loaded: file_helper
INFO - 2016-03-08 18:59:53 --> Helper loaded: date_helper
INFO - 2016-03-08 18:59:53 --> Helper loaded: form_helper
INFO - 2016-03-08 18:59:53 --> Database Driver Class Initialized
INFO - 2016-03-08 18:59:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 18:59:54 --> Controller Class Initialized
INFO - 2016-03-08 18:59:54 --> Model Class Initialized
INFO - 2016-03-08 18:59:54 --> Model Class Initialized
INFO - 2016-03-08 18:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 18:59:54 --> Pagination Class Initialized
INFO - 2016-03-08 18:59:54 --> Helper loaded: text_helper
INFO - 2016-03-08 18:59:54 --> Helper loaded: cookie_helper
INFO - 2016-03-08 21:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 21:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 21:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 21:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 21:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 21:59:54 --> Final output sent to browser
DEBUG - 2016-03-08 21:59:54 --> Total execution time: 1.1722
INFO - 2016-03-08 19:00:04 --> Config Class Initialized
INFO - 2016-03-08 19:00:04 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:00:04 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:00:04 --> Utf8 Class Initialized
INFO - 2016-03-08 19:00:04 --> URI Class Initialized
INFO - 2016-03-08 19:00:04 --> Router Class Initialized
INFO - 2016-03-08 19:00:04 --> Output Class Initialized
INFO - 2016-03-08 19:00:04 --> Security Class Initialized
DEBUG - 2016-03-08 19:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:00:04 --> Input Class Initialized
INFO - 2016-03-08 19:00:04 --> Language Class Initialized
INFO - 2016-03-08 19:00:04 --> Loader Class Initialized
INFO - 2016-03-08 19:00:04 --> Helper loaded: url_helper
INFO - 2016-03-08 19:00:04 --> Helper loaded: file_helper
INFO - 2016-03-08 19:00:04 --> Helper loaded: date_helper
INFO - 2016-03-08 19:00:04 --> Helper loaded: form_helper
INFO - 2016-03-08 19:00:04 --> Database Driver Class Initialized
INFO - 2016-03-08 19:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:00:05 --> Controller Class Initialized
INFO - 2016-03-08 19:00:05 --> Model Class Initialized
INFO - 2016-03-08 19:00:05 --> Model Class Initialized
INFO - 2016-03-08 19:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:00:05 --> Pagination Class Initialized
INFO - 2016-03-08 19:00:05 --> Helper loaded: text_helper
INFO - 2016-03-08 19:00:05 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:00:05 --> Final output sent to browser
DEBUG - 2016-03-08 22:00:05 --> Total execution time: 1.1826
INFO - 2016-03-08 19:00:07 --> Config Class Initialized
INFO - 2016-03-08 19:00:07 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:00:07 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:00:07 --> Utf8 Class Initialized
INFO - 2016-03-08 19:00:07 --> URI Class Initialized
INFO - 2016-03-08 19:00:07 --> Router Class Initialized
INFO - 2016-03-08 19:00:07 --> Output Class Initialized
INFO - 2016-03-08 19:00:07 --> Security Class Initialized
DEBUG - 2016-03-08 19:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:00:07 --> Input Class Initialized
INFO - 2016-03-08 19:00:07 --> Language Class Initialized
INFO - 2016-03-08 19:00:07 --> Loader Class Initialized
INFO - 2016-03-08 19:00:07 --> Helper loaded: url_helper
INFO - 2016-03-08 19:00:07 --> Helper loaded: file_helper
INFO - 2016-03-08 19:00:07 --> Helper loaded: date_helper
INFO - 2016-03-08 19:00:07 --> Helper loaded: form_helper
INFO - 2016-03-08 19:00:07 --> Database Driver Class Initialized
INFO - 2016-03-08 19:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:00:08 --> Controller Class Initialized
INFO - 2016-03-08 19:00:08 --> Model Class Initialized
INFO - 2016-03-08 19:00:08 --> Model Class Initialized
INFO - 2016-03-08 19:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:00:08 --> Pagination Class Initialized
INFO - 2016-03-08 19:00:08 --> Helper loaded: text_helper
INFO - 2016-03-08 19:00:08 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:00:08 --> Final output sent to browser
DEBUG - 2016-03-08 22:00:08 --> Total execution time: 1.1269
INFO - 2016-03-08 19:00:15 --> Config Class Initialized
INFO - 2016-03-08 19:00:15 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:00:15 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:00:15 --> Utf8 Class Initialized
INFO - 2016-03-08 19:00:15 --> URI Class Initialized
INFO - 2016-03-08 19:00:15 --> Router Class Initialized
INFO - 2016-03-08 19:00:15 --> Output Class Initialized
INFO - 2016-03-08 19:00:15 --> Security Class Initialized
DEBUG - 2016-03-08 19:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:00:15 --> Input Class Initialized
INFO - 2016-03-08 19:00:15 --> Language Class Initialized
INFO - 2016-03-08 19:00:15 --> Loader Class Initialized
INFO - 2016-03-08 19:00:15 --> Helper loaded: url_helper
INFO - 2016-03-08 19:00:15 --> Helper loaded: file_helper
INFO - 2016-03-08 19:00:15 --> Helper loaded: date_helper
INFO - 2016-03-08 19:00:15 --> Helper loaded: form_helper
INFO - 2016-03-08 19:00:15 --> Database Driver Class Initialized
INFO - 2016-03-08 19:00:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:00:16 --> Controller Class Initialized
INFO - 2016-03-08 19:00:16 --> Model Class Initialized
INFO - 2016-03-08 19:00:16 --> Model Class Initialized
INFO - 2016-03-08 19:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:00:16 --> Pagination Class Initialized
INFO - 2016-03-08 19:00:16 --> Helper loaded: text_helper
INFO - 2016-03-08 19:00:16 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:00:16 --> Final output sent to browser
DEBUG - 2016-03-08 22:00:16 --> Total execution time: 1.1622
INFO - 2016-03-08 19:01:13 --> Config Class Initialized
INFO - 2016-03-08 19:01:13 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:01:13 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:01:13 --> Utf8 Class Initialized
INFO - 2016-03-08 19:01:13 --> URI Class Initialized
INFO - 2016-03-08 19:01:13 --> Router Class Initialized
INFO - 2016-03-08 19:01:13 --> Output Class Initialized
INFO - 2016-03-08 19:01:13 --> Security Class Initialized
DEBUG - 2016-03-08 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:01:13 --> Input Class Initialized
INFO - 2016-03-08 19:01:13 --> Language Class Initialized
INFO - 2016-03-08 19:01:13 --> Loader Class Initialized
INFO - 2016-03-08 19:01:13 --> Helper loaded: url_helper
INFO - 2016-03-08 19:01:13 --> Helper loaded: file_helper
INFO - 2016-03-08 19:01:13 --> Helper loaded: date_helper
INFO - 2016-03-08 19:01:13 --> Helper loaded: form_helper
INFO - 2016-03-08 19:01:13 --> Database Driver Class Initialized
INFO - 2016-03-08 19:01:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:01:14 --> Controller Class Initialized
INFO - 2016-03-08 19:01:14 --> Model Class Initialized
INFO - 2016-03-08 19:01:14 --> Model Class Initialized
INFO - 2016-03-08 19:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:01:14 --> Pagination Class Initialized
INFO - 2016-03-08 19:01:14 --> Helper loaded: text_helper
INFO - 2016-03-08 19:01:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:01:14 --> Final output sent to browser
DEBUG - 2016-03-08 22:01:14 --> Total execution time: 1.1227
INFO - 2016-03-08 19:01:22 --> Config Class Initialized
INFO - 2016-03-08 19:01:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:01:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:01:22 --> Utf8 Class Initialized
INFO - 2016-03-08 19:01:22 --> URI Class Initialized
INFO - 2016-03-08 19:01:22 --> Router Class Initialized
INFO - 2016-03-08 19:01:22 --> Output Class Initialized
INFO - 2016-03-08 19:01:22 --> Security Class Initialized
DEBUG - 2016-03-08 19:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:01:22 --> Input Class Initialized
INFO - 2016-03-08 19:01:22 --> Language Class Initialized
INFO - 2016-03-08 19:01:22 --> Loader Class Initialized
INFO - 2016-03-08 19:01:22 --> Helper loaded: url_helper
INFO - 2016-03-08 19:01:22 --> Helper loaded: file_helper
INFO - 2016-03-08 19:01:22 --> Helper loaded: date_helper
INFO - 2016-03-08 19:01:22 --> Helper loaded: form_helper
INFO - 2016-03-08 19:01:22 --> Database Driver Class Initialized
INFO - 2016-03-08 19:01:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:01:23 --> Controller Class Initialized
INFO - 2016-03-08 19:01:23 --> Model Class Initialized
INFO - 2016-03-08 19:01:23 --> Model Class Initialized
INFO - 2016-03-08 19:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:01:23 --> Pagination Class Initialized
INFO - 2016-03-08 19:01:23 --> Helper loaded: text_helper
INFO - 2016-03-08 19:01:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:01:23 --> Final output sent to browser
DEBUG - 2016-03-08 22:01:23 --> Total execution time: 1.1683
INFO - 2016-03-08 19:02:13 --> Config Class Initialized
INFO - 2016-03-08 19:02:13 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:02:13 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:02:13 --> Utf8 Class Initialized
INFO - 2016-03-08 19:02:13 --> URI Class Initialized
INFO - 2016-03-08 19:02:13 --> Router Class Initialized
INFO - 2016-03-08 19:02:13 --> Output Class Initialized
INFO - 2016-03-08 19:02:13 --> Security Class Initialized
DEBUG - 2016-03-08 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:02:13 --> Input Class Initialized
INFO - 2016-03-08 19:02:13 --> Language Class Initialized
INFO - 2016-03-08 19:02:13 --> Loader Class Initialized
INFO - 2016-03-08 19:02:13 --> Helper loaded: url_helper
INFO - 2016-03-08 19:02:13 --> Helper loaded: file_helper
INFO - 2016-03-08 19:02:13 --> Helper loaded: date_helper
INFO - 2016-03-08 19:02:13 --> Helper loaded: form_helper
INFO - 2016-03-08 19:02:13 --> Database Driver Class Initialized
INFO - 2016-03-08 19:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:02:14 --> Controller Class Initialized
INFO - 2016-03-08 19:02:14 --> Model Class Initialized
INFO - 2016-03-08 19:02:14 --> Model Class Initialized
INFO - 2016-03-08 19:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:02:14 --> Pagination Class Initialized
INFO - 2016-03-08 19:02:14 --> Helper loaded: text_helper
INFO - 2016-03-08 19:02:14 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:02:14 --> Final output sent to browser
DEBUG - 2016-03-08 22:02:14 --> Total execution time: 1.1024
INFO - 2016-03-08 19:02:20 --> Config Class Initialized
INFO - 2016-03-08 19:02:20 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:02:20 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:02:20 --> Utf8 Class Initialized
INFO - 2016-03-08 19:02:20 --> URI Class Initialized
INFO - 2016-03-08 19:02:20 --> Router Class Initialized
INFO - 2016-03-08 19:02:20 --> Output Class Initialized
INFO - 2016-03-08 19:02:20 --> Security Class Initialized
DEBUG - 2016-03-08 19:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:02:20 --> Input Class Initialized
INFO - 2016-03-08 19:02:20 --> Language Class Initialized
INFO - 2016-03-08 19:02:20 --> Loader Class Initialized
INFO - 2016-03-08 19:02:20 --> Helper loaded: url_helper
INFO - 2016-03-08 19:02:20 --> Helper loaded: file_helper
INFO - 2016-03-08 19:02:20 --> Helper loaded: date_helper
INFO - 2016-03-08 19:02:20 --> Helper loaded: form_helper
INFO - 2016-03-08 19:02:20 --> Database Driver Class Initialized
INFO - 2016-03-08 19:02:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:02:21 --> Controller Class Initialized
INFO - 2016-03-08 19:02:21 --> Model Class Initialized
INFO - 2016-03-08 19:02:21 --> Model Class Initialized
INFO - 2016-03-08 19:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:02:21 --> Pagination Class Initialized
INFO - 2016-03-08 19:02:21 --> Helper loaded: text_helper
INFO - 2016-03-08 19:02:21 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:02:21 --> Final output sent to browser
DEBUG - 2016-03-08 22:02:21 --> Total execution time: 1.1007
INFO - 2016-03-08 19:02:25 --> Config Class Initialized
INFO - 2016-03-08 19:02:25 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:02:25 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:02:25 --> Utf8 Class Initialized
INFO - 2016-03-08 19:02:25 --> URI Class Initialized
INFO - 2016-03-08 19:02:25 --> Router Class Initialized
INFO - 2016-03-08 19:02:25 --> Output Class Initialized
INFO - 2016-03-08 19:02:25 --> Security Class Initialized
DEBUG - 2016-03-08 19:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:02:25 --> Input Class Initialized
INFO - 2016-03-08 19:02:25 --> Language Class Initialized
INFO - 2016-03-08 19:02:25 --> Loader Class Initialized
INFO - 2016-03-08 19:02:25 --> Helper loaded: url_helper
INFO - 2016-03-08 19:02:25 --> Helper loaded: file_helper
INFO - 2016-03-08 19:02:25 --> Helper loaded: date_helper
INFO - 2016-03-08 19:02:25 --> Helper loaded: form_helper
INFO - 2016-03-08 19:02:25 --> Database Driver Class Initialized
INFO - 2016-03-08 19:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:02:26 --> Controller Class Initialized
INFO - 2016-03-08 19:02:26 --> Model Class Initialized
INFO - 2016-03-08 19:02:26 --> Model Class Initialized
INFO - 2016-03-08 19:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:02:26 --> Pagination Class Initialized
INFO - 2016-03-08 19:02:26 --> Helper loaded: text_helper
INFO - 2016-03-08 19:02:26 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:02:26 --> Final output sent to browser
DEBUG - 2016-03-08 22:02:26 --> Total execution time: 1.1725
INFO - 2016-03-08 19:09:35 --> Config Class Initialized
INFO - 2016-03-08 19:09:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:09:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:09:35 --> Utf8 Class Initialized
INFO - 2016-03-08 19:09:35 --> URI Class Initialized
INFO - 2016-03-08 19:09:35 --> Router Class Initialized
INFO - 2016-03-08 19:09:35 --> Output Class Initialized
INFO - 2016-03-08 19:09:35 --> Security Class Initialized
DEBUG - 2016-03-08 19:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:09:35 --> Input Class Initialized
INFO - 2016-03-08 19:09:35 --> Language Class Initialized
INFO - 2016-03-08 19:09:35 --> Loader Class Initialized
INFO - 2016-03-08 19:09:35 --> Helper loaded: url_helper
INFO - 2016-03-08 19:09:35 --> Helper loaded: file_helper
INFO - 2016-03-08 19:09:35 --> Helper loaded: date_helper
INFO - 2016-03-08 19:09:35 --> Helper loaded: form_helper
INFO - 2016-03-08 19:09:35 --> Database Driver Class Initialized
INFO - 2016-03-08 19:09:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:09:36 --> Controller Class Initialized
INFO - 2016-03-08 19:09:36 --> Model Class Initialized
INFO - 2016-03-08 19:09:36 --> Model Class Initialized
INFO - 2016-03-08 19:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:09:36 --> Pagination Class Initialized
INFO - 2016-03-08 19:09:36 --> Helper loaded: text_helper
INFO - 2016-03-08 19:09:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:09:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:09:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:09:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:09:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:09:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:09:36 --> Final output sent to browser
DEBUG - 2016-03-08 22:09:36 --> Total execution time: 1.1102
INFO - 2016-03-08 19:09:39 --> Config Class Initialized
INFO - 2016-03-08 19:09:39 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:09:39 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:09:39 --> Utf8 Class Initialized
INFO - 2016-03-08 19:09:39 --> URI Class Initialized
INFO - 2016-03-08 19:09:39 --> Router Class Initialized
INFO - 2016-03-08 19:09:39 --> Output Class Initialized
INFO - 2016-03-08 19:09:39 --> Security Class Initialized
DEBUG - 2016-03-08 19:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:09:39 --> Input Class Initialized
INFO - 2016-03-08 19:09:39 --> Language Class Initialized
INFO - 2016-03-08 19:09:39 --> Loader Class Initialized
INFO - 2016-03-08 19:09:39 --> Helper loaded: url_helper
INFO - 2016-03-08 19:09:39 --> Helper loaded: file_helper
INFO - 2016-03-08 19:09:39 --> Helper loaded: date_helper
INFO - 2016-03-08 19:09:39 --> Helper loaded: form_helper
INFO - 2016-03-08 19:09:39 --> Database Driver Class Initialized
INFO - 2016-03-08 19:09:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:09:40 --> Controller Class Initialized
INFO - 2016-03-08 19:09:40 --> Model Class Initialized
INFO - 2016-03-08 19:09:40 --> Model Class Initialized
INFO - 2016-03-08 19:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:09:40 --> Pagination Class Initialized
INFO - 2016-03-08 19:09:40 --> Helper loaded: text_helper
INFO - 2016-03-08 19:09:40 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:09:40 --> Final output sent to browser
DEBUG - 2016-03-08 22:09:40 --> Total execution time: 1.1232
INFO - 2016-03-08 19:09:43 --> Config Class Initialized
INFO - 2016-03-08 19:09:43 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:09:43 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:09:43 --> Utf8 Class Initialized
INFO - 2016-03-08 19:09:43 --> URI Class Initialized
INFO - 2016-03-08 19:09:43 --> Router Class Initialized
INFO - 2016-03-08 19:09:43 --> Output Class Initialized
INFO - 2016-03-08 19:09:43 --> Security Class Initialized
DEBUG - 2016-03-08 19:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:09:43 --> Input Class Initialized
INFO - 2016-03-08 19:09:43 --> Language Class Initialized
INFO - 2016-03-08 19:09:43 --> Loader Class Initialized
INFO - 2016-03-08 19:09:43 --> Helper loaded: url_helper
INFO - 2016-03-08 19:09:43 --> Helper loaded: file_helper
INFO - 2016-03-08 19:09:43 --> Helper loaded: date_helper
INFO - 2016-03-08 19:09:43 --> Helper loaded: form_helper
INFO - 2016-03-08 19:09:43 --> Database Driver Class Initialized
INFO - 2016-03-08 19:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:09:44 --> Controller Class Initialized
INFO - 2016-03-08 19:09:44 --> Model Class Initialized
INFO - 2016-03-08 19:09:44 --> Model Class Initialized
INFO - 2016-03-08 19:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:09:44 --> Pagination Class Initialized
INFO - 2016-03-08 19:09:44 --> Helper loaded: text_helper
INFO - 2016-03-08 19:09:44 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:09:44 --> Final output sent to browser
DEBUG - 2016-03-08 22:09:44 --> Total execution time: 1.2740
INFO - 2016-03-08 19:10:48 --> Config Class Initialized
INFO - 2016-03-08 19:10:48 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:10:48 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:10:48 --> Utf8 Class Initialized
INFO - 2016-03-08 19:10:48 --> URI Class Initialized
INFO - 2016-03-08 19:10:48 --> Router Class Initialized
INFO - 2016-03-08 19:10:48 --> Output Class Initialized
INFO - 2016-03-08 19:10:48 --> Security Class Initialized
DEBUG - 2016-03-08 19:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:10:48 --> Input Class Initialized
INFO - 2016-03-08 19:10:48 --> Language Class Initialized
INFO - 2016-03-08 19:10:48 --> Loader Class Initialized
INFO - 2016-03-08 19:10:48 --> Helper loaded: url_helper
INFO - 2016-03-08 19:10:48 --> Helper loaded: file_helper
INFO - 2016-03-08 19:10:48 --> Helper loaded: date_helper
INFO - 2016-03-08 19:10:48 --> Helper loaded: form_helper
INFO - 2016-03-08 19:10:48 --> Database Driver Class Initialized
INFO - 2016-03-08 19:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:10:49 --> Controller Class Initialized
INFO - 2016-03-08 19:10:49 --> Model Class Initialized
INFO - 2016-03-08 19:10:49 --> Model Class Initialized
INFO - 2016-03-08 19:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:10:49 --> Pagination Class Initialized
INFO - 2016-03-08 19:10:49 --> Helper loaded: text_helper
INFO - 2016-03-08 19:10:49 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:10:49 --> Final output sent to browser
DEBUG - 2016-03-08 22:10:49 --> Total execution time: 1.1526
INFO - 2016-03-08 19:10:54 --> Config Class Initialized
INFO - 2016-03-08 19:10:54 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:10:54 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:10:54 --> Utf8 Class Initialized
INFO - 2016-03-08 19:10:54 --> URI Class Initialized
INFO - 2016-03-08 19:10:54 --> Router Class Initialized
INFO - 2016-03-08 19:10:54 --> Output Class Initialized
INFO - 2016-03-08 19:10:54 --> Security Class Initialized
DEBUG - 2016-03-08 19:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:10:54 --> Input Class Initialized
INFO - 2016-03-08 19:10:54 --> Language Class Initialized
INFO - 2016-03-08 19:10:54 --> Loader Class Initialized
INFO - 2016-03-08 19:10:54 --> Helper loaded: url_helper
INFO - 2016-03-08 19:10:54 --> Helper loaded: file_helper
INFO - 2016-03-08 19:10:54 --> Helper loaded: date_helper
INFO - 2016-03-08 19:10:54 --> Helper loaded: form_helper
INFO - 2016-03-08 19:10:54 --> Database Driver Class Initialized
INFO - 2016-03-08 19:10:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:10:55 --> Controller Class Initialized
INFO - 2016-03-08 19:10:55 --> Model Class Initialized
INFO - 2016-03-08 19:10:55 --> Model Class Initialized
INFO - 2016-03-08 19:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:10:55 --> Pagination Class Initialized
INFO - 2016-03-08 19:10:55 --> Helper loaded: text_helper
INFO - 2016-03-08 19:10:55 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:10:55 --> Final output sent to browser
DEBUG - 2016-03-08 22:10:55 --> Total execution time: 1.1103
INFO - 2016-03-08 19:10:57 --> Config Class Initialized
INFO - 2016-03-08 19:10:57 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:10:57 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:10:57 --> Utf8 Class Initialized
INFO - 2016-03-08 19:10:57 --> URI Class Initialized
INFO - 2016-03-08 19:10:57 --> Router Class Initialized
INFO - 2016-03-08 19:10:57 --> Output Class Initialized
INFO - 2016-03-08 19:10:57 --> Security Class Initialized
DEBUG - 2016-03-08 19:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:10:57 --> Input Class Initialized
INFO - 2016-03-08 19:10:57 --> Language Class Initialized
INFO - 2016-03-08 19:10:57 --> Loader Class Initialized
INFO - 2016-03-08 19:10:57 --> Helper loaded: url_helper
INFO - 2016-03-08 19:10:57 --> Helper loaded: file_helper
INFO - 2016-03-08 19:10:57 --> Helper loaded: date_helper
INFO - 2016-03-08 19:10:57 --> Helper loaded: form_helper
INFO - 2016-03-08 19:10:57 --> Database Driver Class Initialized
INFO - 2016-03-08 19:10:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:10:58 --> Controller Class Initialized
INFO - 2016-03-08 19:10:59 --> Model Class Initialized
INFO - 2016-03-08 19:10:59 --> Model Class Initialized
INFO - 2016-03-08 19:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:10:59 --> Pagination Class Initialized
INFO - 2016-03-08 19:10:59 --> Helper loaded: text_helper
INFO - 2016-03-08 19:10:59 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:10:59 --> Final output sent to browser
DEBUG - 2016-03-08 22:10:59 --> Total execution time: 1.1874
INFO - 2016-03-08 19:12:14 --> Config Class Initialized
INFO - 2016-03-08 19:12:14 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:12:14 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:12:14 --> Utf8 Class Initialized
INFO - 2016-03-08 19:12:14 --> URI Class Initialized
INFO - 2016-03-08 19:12:14 --> Router Class Initialized
INFO - 2016-03-08 19:12:14 --> Output Class Initialized
INFO - 2016-03-08 19:12:14 --> Security Class Initialized
DEBUG - 2016-03-08 19:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:12:14 --> Input Class Initialized
INFO - 2016-03-08 19:12:14 --> Language Class Initialized
INFO - 2016-03-08 19:12:14 --> Loader Class Initialized
INFO - 2016-03-08 19:12:14 --> Helper loaded: url_helper
INFO - 2016-03-08 19:12:14 --> Helper loaded: file_helper
INFO - 2016-03-08 19:12:14 --> Helper loaded: date_helper
INFO - 2016-03-08 19:12:14 --> Helper loaded: form_helper
INFO - 2016-03-08 19:12:14 --> Database Driver Class Initialized
INFO - 2016-03-08 19:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:12:15 --> Controller Class Initialized
INFO - 2016-03-08 19:12:15 --> Model Class Initialized
INFO - 2016-03-08 19:12:15 --> Model Class Initialized
INFO - 2016-03-08 19:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:12:15 --> Pagination Class Initialized
INFO - 2016-03-08 19:12:15 --> Helper loaded: text_helper
INFO - 2016-03-08 19:12:15 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:12:15 --> Final output sent to browser
DEBUG - 2016-03-08 22:12:15 --> Total execution time: 1.1585
INFO - 2016-03-08 19:12:19 --> Config Class Initialized
INFO - 2016-03-08 19:12:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:12:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:12:19 --> Utf8 Class Initialized
INFO - 2016-03-08 19:12:19 --> URI Class Initialized
INFO - 2016-03-08 19:12:19 --> Router Class Initialized
INFO - 2016-03-08 19:12:19 --> Output Class Initialized
INFO - 2016-03-08 19:12:19 --> Security Class Initialized
DEBUG - 2016-03-08 19:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:12:19 --> Input Class Initialized
INFO - 2016-03-08 19:12:19 --> Language Class Initialized
INFO - 2016-03-08 19:12:19 --> Loader Class Initialized
INFO - 2016-03-08 19:12:19 --> Helper loaded: url_helper
INFO - 2016-03-08 19:12:19 --> Helper loaded: file_helper
INFO - 2016-03-08 19:12:19 --> Helper loaded: date_helper
INFO - 2016-03-08 19:12:19 --> Helper loaded: form_helper
INFO - 2016-03-08 19:12:19 --> Database Driver Class Initialized
INFO - 2016-03-08 19:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:12:20 --> Controller Class Initialized
INFO - 2016-03-08 19:12:20 --> Model Class Initialized
INFO - 2016-03-08 19:12:20 --> Model Class Initialized
INFO - 2016-03-08 19:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:12:20 --> Pagination Class Initialized
INFO - 2016-03-08 19:12:20 --> Helper loaded: text_helper
INFO - 2016-03-08 19:12:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:12:20 --> Final output sent to browser
DEBUG - 2016-03-08 22:12:20 --> Total execution time: 1.0953
INFO - 2016-03-08 19:12:22 --> Config Class Initialized
INFO - 2016-03-08 19:12:22 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:12:22 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:12:22 --> Utf8 Class Initialized
INFO - 2016-03-08 19:12:22 --> URI Class Initialized
INFO - 2016-03-08 19:12:22 --> Router Class Initialized
INFO - 2016-03-08 19:12:22 --> Output Class Initialized
INFO - 2016-03-08 19:12:22 --> Security Class Initialized
DEBUG - 2016-03-08 19:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:12:22 --> Input Class Initialized
INFO - 2016-03-08 19:12:22 --> Language Class Initialized
INFO - 2016-03-08 19:12:22 --> Loader Class Initialized
INFO - 2016-03-08 19:12:22 --> Helper loaded: url_helper
INFO - 2016-03-08 19:12:22 --> Helper loaded: file_helper
INFO - 2016-03-08 19:12:22 --> Helper loaded: date_helper
INFO - 2016-03-08 19:12:22 --> Helper loaded: form_helper
INFO - 2016-03-08 19:12:22 --> Database Driver Class Initialized
INFO - 2016-03-08 19:12:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:12:23 --> Controller Class Initialized
INFO - 2016-03-08 19:12:23 --> Model Class Initialized
INFO - 2016-03-08 19:12:23 --> Model Class Initialized
INFO - 2016-03-08 19:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:12:23 --> Pagination Class Initialized
INFO - 2016-03-08 19:12:23 --> Helper loaded: text_helper
INFO - 2016-03-08 19:12:23 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:12:23 --> Final output sent to browser
DEBUG - 2016-03-08 22:12:23 --> Total execution time: 1.1530
INFO - 2016-03-08 19:12:24 --> Config Class Initialized
INFO - 2016-03-08 19:12:24 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:12:24 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:12:24 --> Utf8 Class Initialized
INFO - 2016-03-08 19:12:24 --> URI Class Initialized
INFO - 2016-03-08 19:12:24 --> Router Class Initialized
INFO - 2016-03-08 19:12:24 --> Output Class Initialized
INFO - 2016-03-08 19:12:24 --> Security Class Initialized
DEBUG - 2016-03-08 19:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:12:24 --> Input Class Initialized
INFO - 2016-03-08 19:12:24 --> Language Class Initialized
INFO - 2016-03-08 19:12:24 --> Loader Class Initialized
INFO - 2016-03-08 19:12:24 --> Helper loaded: url_helper
INFO - 2016-03-08 19:12:24 --> Helper loaded: file_helper
INFO - 2016-03-08 19:12:24 --> Helper loaded: date_helper
INFO - 2016-03-08 19:12:24 --> Helper loaded: form_helper
INFO - 2016-03-08 19:12:24 --> Database Driver Class Initialized
INFO - 2016-03-08 19:12:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:12:25 --> Controller Class Initialized
INFO - 2016-03-08 19:12:25 --> Model Class Initialized
INFO - 2016-03-08 19:12:25 --> Model Class Initialized
INFO - 2016-03-08 19:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:12:25 --> Pagination Class Initialized
INFO - 2016-03-08 19:12:25 --> Helper loaded: text_helper
INFO - 2016-03-08 19:12:25 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:12:25 --> Final output sent to browser
DEBUG - 2016-03-08 22:12:25 --> Total execution time: 1.1368
INFO - 2016-03-08 19:13:49 --> Config Class Initialized
INFO - 2016-03-08 19:13:49 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:13:49 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:13:49 --> Utf8 Class Initialized
INFO - 2016-03-08 19:13:49 --> URI Class Initialized
INFO - 2016-03-08 19:13:49 --> Router Class Initialized
INFO - 2016-03-08 19:13:49 --> Output Class Initialized
INFO - 2016-03-08 19:13:49 --> Security Class Initialized
DEBUG - 2016-03-08 19:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:13:49 --> Input Class Initialized
INFO - 2016-03-08 19:13:49 --> Language Class Initialized
INFO - 2016-03-08 19:13:49 --> Loader Class Initialized
INFO - 2016-03-08 19:13:49 --> Helper loaded: url_helper
INFO - 2016-03-08 19:13:49 --> Helper loaded: file_helper
INFO - 2016-03-08 19:13:49 --> Helper loaded: date_helper
INFO - 2016-03-08 19:13:49 --> Helper loaded: form_helper
INFO - 2016-03-08 19:13:49 --> Database Driver Class Initialized
INFO - 2016-03-08 19:13:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:13:50 --> Controller Class Initialized
INFO - 2016-03-08 19:13:50 --> Model Class Initialized
INFO - 2016-03-08 19:13:50 --> Model Class Initialized
INFO - 2016-03-08 19:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:13:50 --> Pagination Class Initialized
INFO - 2016-03-08 19:13:50 --> Helper loaded: text_helper
INFO - 2016-03-08 19:13:50 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:13:50 --> Final output sent to browser
DEBUG - 2016-03-08 22:13:50 --> Total execution time: 1.1951
INFO - 2016-03-08 19:13:54 --> Config Class Initialized
INFO - 2016-03-08 19:13:54 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:13:54 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:13:54 --> Utf8 Class Initialized
INFO - 2016-03-08 19:13:54 --> URI Class Initialized
INFO - 2016-03-08 19:13:54 --> Router Class Initialized
INFO - 2016-03-08 19:13:54 --> Output Class Initialized
INFO - 2016-03-08 19:13:54 --> Security Class Initialized
DEBUG - 2016-03-08 19:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:13:54 --> Input Class Initialized
INFO - 2016-03-08 19:13:54 --> Language Class Initialized
INFO - 2016-03-08 19:13:54 --> Loader Class Initialized
INFO - 2016-03-08 19:13:54 --> Helper loaded: url_helper
INFO - 2016-03-08 19:13:54 --> Helper loaded: file_helper
INFO - 2016-03-08 19:13:54 --> Helper loaded: date_helper
INFO - 2016-03-08 19:13:54 --> Helper loaded: form_helper
INFO - 2016-03-08 19:13:54 --> Database Driver Class Initialized
INFO - 2016-03-08 19:13:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:13:55 --> Controller Class Initialized
INFO - 2016-03-08 19:13:55 --> Model Class Initialized
INFO - 2016-03-08 19:13:55 --> Model Class Initialized
INFO - 2016-03-08 19:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:13:55 --> Pagination Class Initialized
INFO - 2016-03-08 19:13:55 --> Helper loaded: text_helper
INFO - 2016-03-08 19:13:55 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:13:55 --> Final output sent to browser
DEBUG - 2016-03-08 22:13:55 --> Total execution time: 1.0995
INFO - 2016-03-08 19:13:57 --> Config Class Initialized
INFO - 2016-03-08 19:13:57 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:13:57 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:13:57 --> Utf8 Class Initialized
INFO - 2016-03-08 19:13:57 --> URI Class Initialized
INFO - 2016-03-08 19:13:57 --> Router Class Initialized
INFO - 2016-03-08 19:13:57 --> Output Class Initialized
INFO - 2016-03-08 19:13:57 --> Security Class Initialized
DEBUG - 2016-03-08 19:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:13:57 --> Input Class Initialized
INFO - 2016-03-08 19:13:57 --> Language Class Initialized
INFO - 2016-03-08 19:13:57 --> Loader Class Initialized
INFO - 2016-03-08 19:13:57 --> Helper loaded: url_helper
INFO - 2016-03-08 19:13:57 --> Helper loaded: file_helper
INFO - 2016-03-08 19:13:57 --> Helper loaded: date_helper
INFO - 2016-03-08 19:13:57 --> Helper loaded: form_helper
INFO - 2016-03-08 19:13:57 --> Database Driver Class Initialized
INFO - 2016-03-08 19:13:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:13:58 --> Controller Class Initialized
INFO - 2016-03-08 19:13:58 --> Model Class Initialized
INFO - 2016-03-08 19:13:58 --> Model Class Initialized
INFO - 2016-03-08 19:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:13:58 --> Pagination Class Initialized
INFO - 2016-03-08 19:13:58 --> Helper loaded: text_helper
INFO - 2016-03-08 19:13:58 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-08 22:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-08 22:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:13:58 --> Final output sent to browser
DEBUG - 2016-03-08 22:13:58 --> Total execution time: 1.1290
INFO - 2016-03-08 19:13:59 --> Config Class Initialized
INFO - 2016-03-08 19:13:59 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:13:59 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:13:59 --> Utf8 Class Initialized
INFO - 2016-03-08 19:13:59 --> URI Class Initialized
INFO - 2016-03-08 19:13:59 --> Router Class Initialized
INFO - 2016-03-08 19:13:59 --> Output Class Initialized
INFO - 2016-03-08 19:13:59 --> Security Class Initialized
DEBUG - 2016-03-08 19:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:13:59 --> Input Class Initialized
INFO - 2016-03-08 19:13:59 --> Language Class Initialized
INFO - 2016-03-08 19:13:59 --> Loader Class Initialized
INFO - 2016-03-08 19:13:59 --> Helper loaded: url_helper
INFO - 2016-03-08 19:13:59 --> Helper loaded: file_helper
INFO - 2016-03-08 19:13:59 --> Helper loaded: date_helper
INFO - 2016-03-08 19:13:59 --> Helper loaded: form_helper
INFO - 2016-03-08 19:13:59 --> Database Driver Class Initialized
INFO - 2016-03-08 19:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:14:00 --> Controller Class Initialized
INFO - 2016-03-08 19:14:00 --> Model Class Initialized
INFO - 2016-03-08 19:14:00 --> Model Class Initialized
INFO - 2016-03-08 19:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:14:00 --> Pagination Class Initialized
INFO - 2016-03-08 19:14:00 --> Helper loaded: text_helper
INFO - 2016-03-08 19:14:00 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:14:00 --> Final output sent to browser
DEBUG - 2016-03-08 22:14:00 --> Total execution time: 1.1621
INFO - 2016-03-08 19:14:21 --> Config Class Initialized
INFO - 2016-03-08 19:14:21 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:14:21 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:14:21 --> Utf8 Class Initialized
INFO - 2016-03-08 19:14:21 --> URI Class Initialized
INFO - 2016-03-08 19:14:21 --> Router Class Initialized
INFO - 2016-03-08 19:14:21 --> Output Class Initialized
INFO - 2016-03-08 19:14:21 --> Security Class Initialized
DEBUG - 2016-03-08 19:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:14:21 --> Input Class Initialized
INFO - 2016-03-08 19:14:21 --> Language Class Initialized
INFO - 2016-03-08 19:14:21 --> Loader Class Initialized
INFO - 2016-03-08 19:14:21 --> Helper loaded: url_helper
INFO - 2016-03-08 19:14:21 --> Helper loaded: file_helper
INFO - 2016-03-08 19:14:21 --> Helper loaded: date_helper
INFO - 2016-03-08 19:14:21 --> Helper loaded: form_helper
INFO - 2016-03-08 19:14:21 --> Database Driver Class Initialized
INFO - 2016-03-08 19:14:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:14:22 --> Controller Class Initialized
INFO - 2016-03-08 19:14:22 --> Model Class Initialized
INFO - 2016-03-08 19:14:22 --> Model Class Initialized
INFO - 2016-03-08 19:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:14:22 --> Pagination Class Initialized
INFO - 2016-03-08 19:14:22 --> Helper loaded: text_helper
INFO - 2016-03-08 19:14:22 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:14:23 --> Final output sent to browser
DEBUG - 2016-03-08 22:14:23 --> Total execution time: 1.1558
INFO - 2016-03-08 19:15:10 --> Config Class Initialized
INFO - 2016-03-08 19:15:10 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:15:10 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:15:10 --> Utf8 Class Initialized
INFO - 2016-03-08 19:15:10 --> URI Class Initialized
INFO - 2016-03-08 19:15:10 --> Router Class Initialized
INFO - 2016-03-08 19:15:10 --> Output Class Initialized
INFO - 2016-03-08 19:15:10 --> Security Class Initialized
DEBUG - 2016-03-08 19:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:15:10 --> Input Class Initialized
INFO - 2016-03-08 19:15:10 --> Language Class Initialized
INFO - 2016-03-08 19:15:10 --> Loader Class Initialized
INFO - 2016-03-08 19:15:10 --> Helper loaded: url_helper
INFO - 2016-03-08 19:15:10 --> Helper loaded: file_helper
INFO - 2016-03-08 19:15:10 --> Helper loaded: date_helper
INFO - 2016-03-08 19:15:10 --> Helper loaded: form_helper
INFO - 2016-03-08 19:15:10 --> Database Driver Class Initialized
INFO - 2016-03-08 19:15:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:15:11 --> Controller Class Initialized
INFO - 2016-03-08 19:15:11 --> Model Class Initialized
INFO - 2016-03-08 19:15:11 --> Model Class Initialized
INFO - 2016-03-08 19:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:15:11 --> Pagination Class Initialized
INFO - 2016-03-08 19:15:11 --> Helper loaded: text_helper
INFO - 2016-03-08 19:15:11 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:15:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:15:11 --> Final output sent to browser
DEBUG - 2016-03-08 22:15:11 --> Total execution time: 1.1703
INFO - 2016-03-08 19:15:35 --> Config Class Initialized
INFO - 2016-03-08 19:15:35 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:15:35 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:15:35 --> Utf8 Class Initialized
INFO - 2016-03-08 19:15:35 --> URI Class Initialized
INFO - 2016-03-08 19:15:35 --> Router Class Initialized
INFO - 2016-03-08 19:15:35 --> Output Class Initialized
INFO - 2016-03-08 19:15:35 --> Security Class Initialized
DEBUG - 2016-03-08 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:15:35 --> Input Class Initialized
INFO - 2016-03-08 19:15:35 --> Language Class Initialized
INFO - 2016-03-08 19:15:35 --> Loader Class Initialized
INFO - 2016-03-08 19:15:35 --> Helper loaded: url_helper
INFO - 2016-03-08 19:15:35 --> Helper loaded: file_helper
INFO - 2016-03-08 19:15:35 --> Helper loaded: date_helper
INFO - 2016-03-08 19:15:35 --> Helper loaded: form_helper
INFO - 2016-03-08 19:15:35 --> Database Driver Class Initialized
INFO - 2016-03-08 19:15:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:15:36 --> Controller Class Initialized
INFO - 2016-03-08 19:15:36 --> Model Class Initialized
INFO - 2016-03-08 19:15:36 --> Model Class Initialized
INFO - 2016-03-08 19:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:15:36 --> Pagination Class Initialized
INFO - 2016-03-08 19:15:36 --> Helper loaded: text_helper
INFO - 2016-03-08 19:15:36 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:15:37 --> Final output sent to browser
DEBUG - 2016-03-08 22:15:37 --> Total execution time: 1.2349
INFO - 2016-03-08 19:15:40 --> Config Class Initialized
INFO - 2016-03-08 19:15:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:15:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:15:40 --> Utf8 Class Initialized
INFO - 2016-03-08 19:15:40 --> URI Class Initialized
INFO - 2016-03-08 19:15:40 --> Router Class Initialized
INFO - 2016-03-08 19:15:40 --> Output Class Initialized
INFO - 2016-03-08 19:15:40 --> Security Class Initialized
DEBUG - 2016-03-08 19:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:15:40 --> Input Class Initialized
INFO - 2016-03-08 19:15:40 --> Language Class Initialized
INFO - 2016-03-08 19:15:40 --> Loader Class Initialized
INFO - 2016-03-08 19:15:40 --> Helper loaded: url_helper
INFO - 2016-03-08 19:15:40 --> Helper loaded: file_helper
INFO - 2016-03-08 19:15:40 --> Helper loaded: date_helper
INFO - 2016-03-08 19:15:41 --> Helper loaded: form_helper
INFO - 2016-03-08 19:15:41 --> Database Driver Class Initialized
INFO - 2016-03-08 19:15:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:15:42 --> Controller Class Initialized
INFO - 2016-03-08 19:15:42 --> User Agent Class Initialized
INFO - 2016-03-08 19:15:42 --> Final output sent to browser
DEBUG - 2016-03-08 19:15:42 --> Total execution time: 1.1379
INFO - 2016-03-08 19:15:46 --> Config Class Initialized
INFO - 2016-03-08 19:15:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:15:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:15:46 --> Utf8 Class Initialized
INFO - 2016-03-08 19:15:46 --> URI Class Initialized
INFO - 2016-03-08 19:15:46 --> Router Class Initialized
INFO - 2016-03-08 19:15:46 --> Output Class Initialized
INFO - 2016-03-08 19:15:46 --> Security Class Initialized
DEBUG - 2016-03-08 19:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:15:46 --> Input Class Initialized
INFO - 2016-03-08 19:15:46 --> Language Class Initialized
INFO - 2016-03-08 19:15:46 --> Loader Class Initialized
INFO - 2016-03-08 19:15:46 --> Helper loaded: url_helper
INFO - 2016-03-08 19:15:46 --> Helper loaded: file_helper
INFO - 2016-03-08 19:15:46 --> Helper loaded: date_helper
INFO - 2016-03-08 19:15:46 --> Helper loaded: form_helper
INFO - 2016-03-08 19:15:46 --> Database Driver Class Initialized
INFO - 2016-03-08 19:15:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:15:47 --> Controller Class Initialized
INFO - 2016-03-08 19:15:47 --> Model Class Initialized
INFO - 2016-03-08 19:15:47 --> Model Class Initialized
INFO - 2016-03-08 19:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:15:47 --> Pagination Class Initialized
INFO - 2016-03-08 19:15:47 --> Helper loaded: text_helper
INFO - 2016-03-08 19:15:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:15:47 --> Final output sent to browser
DEBUG - 2016-03-08 22:15:47 --> Total execution time: 1.1910
INFO - 2016-03-08 19:15:50 --> Config Class Initialized
INFO - 2016-03-08 19:15:50 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:15:50 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:15:50 --> Utf8 Class Initialized
INFO - 2016-03-08 19:15:50 --> URI Class Initialized
INFO - 2016-03-08 19:15:50 --> Router Class Initialized
INFO - 2016-03-08 19:15:51 --> Output Class Initialized
INFO - 2016-03-08 19:15:51 --> Security Class Initialized
DEBUG - 2016-03-08 19:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:15:51 --> Input Class Initialized
INFO - 2016-03-08 19:15:51 --> Language Class Initialized
INFO - 2016-03-08 19:15:51 --> Loader Class Initialized
INFO - 2016-03-08 19:15:51 --> Helper loaded: url_helper
INFO - 2016-03-08 19:15:51 --> Helper loaded: file_helper
INFO - 2016-03-08 19:15:51 --> Helper loaded: date_helper
INFO - 2016-03-08 19:15:51 --> Helper loaded: form_helper
INFO - 2016-03-08 19:15:51 --> Database Driver Class Initialized
INFO - 2016-03-08 19:15:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:15:52 --> Controller Class Initialized
INFO - 2016-03-08 19:15:52 --> Model Class Initialized
INFO - 2016-03-08 19:15:52 --> Model Class Initialized
INFO - 2016-03-08 19:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:15:52 --> Pagination Class Initialized
INFO - 2016-03-08 19:15:52 --> Helper loaded: text_helper
INFO - 2016-03-08 19:15:52 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:15:52 --> Final output sent to browser
DEBUG - 2016-03-08 22:15:52 --> Total execution time: 1.2095
INFO - 2016-03-08 19:16:08 --> Config Class Initialized
INFO - 2016-03-08 19:16:08 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:16:08 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:16:08 --> Utf8 Class Initialized
INFO - 2016-03-08 19:16:08 --> URI Class Initialized
INFO - 2016-03-08 19:16:08 --> Router Class Initialized
INFO - 2016-03-08 19:16:08 --> Output Class Initialized
INFO - 2016-03-08 19:16:08 --> Security Class Initialized
DEBUG - 2016-03-08 19:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:16:08 --> Input Class Initialized
INFO - 2016-03-08 19:16:08 --> Language Class Initialized
INFO - 2016-03-08 19:16:08 --> Loader Class Initialized
INFO - 2016-03-08 19:16:08 --> Helper loaded: url_helper
INFO - 2016-03-08 19:16:08 --> Helper loaded: file_helper
INFO - 2016-03-08 19:16:08 --> Helper loaded: date_helper
INFO - 2016-03-08 19:16:08 --> Helper loaded: form_helper
INFO - 2016-03-08 19:16:08 --> Database Driver Class Initialized
INFO - 2016-03-08 19:16:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:16:09 --> Controller Class Initialized
INFO - 2016-03-08 19:16:09 --> Model Class Initialized
INFO - 2016-03-08 19:16:09 --> Model Class Initialized
INFO - 2016-03-08 19:16:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:16:09 --> Pagination Class Initialized
INFO - 2016-03-08 19:16:09 --> Helper loaded: text_helper
INFO - 2016-03-08 19:16:09 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-08 22:16:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:16:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:16:09 --> Final output sent to browser
DEBUG - 2016-03-08 22:16:09 --> Total execution time: 1.2108
INFO - 2016-03-08 19:16:19 --> Config Class Initialized
INFO - 2016-03-08 19:16:19 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:16:19 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:16:19 --> Utf8 Class Initialized
INFO - 2016-03-08 19:16:19 --> URI Class Initialized
INFO - 2016-03-08 19:16:19 --> Router Class Initialized
INFO - 2016-03-08 19:16:19 --> Output Class Initialized
INFO - 2016-03-08 19:16:19 --> Security Class Initialized
DEBUG - 2016-03-08 19:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:16:19 --> Input Class Initialized
INFO - 2016-03-08 19:16:19 --> Language Class Initialized
INFO - 2016-03-08 19:16:19 --> Loader Class Initialized
INFO - 2016-03-08 19:16:19 --> Helper loaded: url_helper
INFO - 2016-03-08 19:16:19 --> Helper loaded: file_helper
INFO - 2016-03-08 19:16:19 --> Helper loaded: date_helper
INFO - 2016-03-08 19:16:19 --> Helper loaded: form_helper
INFO - 2016-03-08 19:16:19 --> Database Driver Class Initialized
INFO - 2016-03-08 19:16:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:16:20 --> Controller Class Initialized
INFO - 2016-03-08 19:16:20 --> Model Class Initialized
INFO - 2016-03-08 19:16:20 --> Model Class Initialized
INFO - 2016-03-08 19:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:16:20 --> Pagination Class Initialized
INFO - 2016-03-08 19:16:20 --> Helper loaded: text_helper
INFO - 2016-03-08 19:16:20 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:16:20 --> Final output sent to browser
DEBUG - 2016-03-08 22:16:20 --> Total execution time: 1.1667
INFO - 2016-03-08 19:16:40 --> Config Class Initialized
INFO - 2016-03-08 19:16:40 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:16:40 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:16:40 --> Utf8 Class Initialized
INFO - 2016-03-08 19:16:40 --> URI Class Initialized
INFO - 2016-03-08 19:16:40 --> Router Class Initialized
INFO - 2016-03-08 19:16:40 --> Output Class Initialized
INFO - 2016-03-08 19:16:40 --> Security Class Initialized
DEBUG - 2016-03-08 19:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:16:40 --> Input Class Initialized
INFO - 2016-03-08 19:16:40 --> Language Class Initialized
INFO - 2016-03-08 19:16:40 --> Loader Class Initialized
INFO - 2016-03-08 19:16:40 --> Helper loaded: url_helper
INFO - 2016-03-08 19:16:40 --> Helper loaded: file_helper
INFO - 2016-03-08 19:16:40 --> Helper loaded: date_helper
INFO - 2016-03-08 19:16:40 --> Helper loaded: form_helper
INFO - 2016-03-08 19:16:40 --> Database Driver Class Initialized
INFO - 2016-03-08 19:16:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:16:41 --> Controller Class Initialized
INFO - 2016-03-08 19:16:41 --> User Agent Class Initialized
INFO - 2016-03-08 19:16:41 --> Final output sent to browser
DEBUG - 2016-03-08 19:16:41 --> Total execution time: 1.0944
INFO - 2016-03-08 19:16:46 --> Config Class Initialized
INFO - 2016-03-08 19:16:46 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:16:46 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:16:46 --> Utf8 Class Initialized
INFO - 2016-03-08 19:16:46 --> URI Class Initialized
INFO - 2016-03-08 19:16:46 --> Router Class Initialized
INFO - 2016-03-08 19:16:46 --> Output Class Initialized
INFO - 2016-03-08 19:16:46 --> Security Class Initialized
DEBUG - 2016-03-08 19:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:16:46 --> Input Class Initialized
INFO - 2016-03-08 19:16:46 --> Language Class Initialized
INFO - 2016-03-08 19:16:46 --> Loader Class Initialized
INFO - 2016-03-08 19:16:46 --> Helper loaded: url_helper
INFO - 2016-03-08 19:16:46 --> Helper loaded: file_helper
INFO - 2016-03-08 19:16:46 --> Helper loaded: date_helper
INFO - 2016-03-08 19:16:46 --> Helper loaded: form_helper
INFO - 2016-03-08 19:16:46 --> Database Driver Class Initialized
INFO - 2016-03-08 19:16:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:16:47 --> Controller Class Initialized
INFO - 2016-03-08 19:16:47 --> Model Class Initialized
INFO - 2016-03-08 19:16:47 --> Model Class Initialized
INFO - 2016-03-08 19:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:16:47 --> Pagination Class Initialized
INFO - 2016-03-08 19:16:47 --> Helper loaded: text_helper
INFO - 2016-03-08 19:16:47 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-08 22:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:16:47 --> Final output sent to browser
DEBUG - 2016-03-08 22:16:47 --> Total execution time: 1.1537
INFO - 2016-03-08 19:18:52 --> Config Class Initialized
INFO - 2016-03-08 19:18:52 --> Hooks Class Initialized
DEBUG - 2016-03-08 19:18:52 --> UTF-8 Support Enabled
INFO - 2016-03-08 19:18:52 --> Utf8 Class Initialized
INFO - 2016-03-08 19:18:52 --> URI Class Initialized
INFO - 2016-03-08 19:18:52 --> Router Class Initialized
INFO - 2016-03-08 19:18:52 --> Output Class Initialized
INFO - 2016-03-08 19:18:52 --> Security Class Initialized
DEBUG - 2016-03-08 19:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-08 19:18:52 --> Input Class Initialized
INFO - 2016-03-08 19:18:52 --> Language Class Initialized
INFO - 2016-03-08 19:18:52 --> Loader Class Initialized
INFO - 2016-03-08 19:18:52 --> Helper loaded: url_helper
INFO - 2016-03-08 19:18:52 --> Helper loaded: file_helper
INFO - 2016-03-08 19:18:52 --> Helper loaded: date_helper
INFO - 2016-03-08 19:18:52 --> Helper loaded: form_helper
INFO - 2016-03-08 19:18:52 --> Database Driver Class Initialized
INFO - 2016-03-08 19:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-08 19:18:53 --> Controller Class Initialized
INFO - 2016-03-08 19:18:53 --> Model Class Initialized
INFO - 2016-03-08 19:18:53 --> Model Class Initialized
INFO - 2016-03-08 19:18:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-08 19:18:53 --> Pagination Class Initialized
INFO - 2016-03-08 19:18:53 --> Helper loaded: text_helper
INFO - 2016-03-08 19:18:53 --> Helper loaded: cookie_helper
INFO - 2016-03-08 22:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-08 22:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-08 22:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-08 22:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-08 22:18:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-08 22:18:53 --> Final output sent to browser
DEBUG - 2016-03-08 22:18:53 --> Total execution time: 1.1797
