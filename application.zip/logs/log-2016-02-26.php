<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-26 05:54:08 --> Config Class Initialized
INFO - 2016-02-26 05:54:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:08 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:08 --> URI Class Initialized
INFO - 2016-02-26 05:54:08 --> Router Class Initialized
INFO - 2016-02-26 05:54:08 --> Output Class Initialized
INFO - 2016-02-26 05:54:08 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:08 --> Input Class Initialized
INFO - 2016-02-26 05:54:08 --> Language Class Initialized
INFO - 2016-02-26 05:54:08 --> Loader Class Initialized
INFO - 2016-02-26 05:54:08 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:08 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:08 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:08 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:08 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:09 --> Controller Class Initialized
INFO - 2016-02-26 05:54:09 --> Model Class Initialized
INFO - 2016-02-26 05:54:09 --> Model Class Initialized
INFO - 2016-02-26 05:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:09 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:09 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 08:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 08:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:54:10 --> Final output sent to browser
DEBUG - 2016-02-26 08:54:10 --> Total execution time: 1.1012
INFO - 2016-02-26 05:54:18 --> Config Class Initialized
INFO - 2016-02-26 05:54:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:18 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:18 --> URI Class Initialized
INFO - 2016-02-26 05:54:18 --> Router Class Initialized
INFO - 2016-02-26 05:54:18 --> Output Class Initialized
INFO - 2016-02-26 05:54:18 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:18 --> Input Class Initialized
INFO - 2016-02-26 05:54:18 --> Language Class Initialized
INFO - 2016-02-26 05:54:18 --> Loader Class Initialized
INFO - 2016-02-26 05:54:18 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:18 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:18 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:18 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:18 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:19 --> Controller Class Initialized
INFO - 2016-02-26 05:54:19 --> Model Class Initialized
INFO - 2016-02-26 05:54:19 --> Model Class Initialized
INFO - 2016-02-26 05:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:19 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:19 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 08:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:54:19 --> Final output sent to browser
DEBUG - 2016-02-26 08:54:19 --> Total execution time: 1.1177
INFO - 2016-02-26 05:54:21 --> Config Class Initialized
INFO - 2016-02-26 05:54:21 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:21 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:21 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:21 --> URI Class Initialized
INFO - 2016-02-26 05:54:21 --> Router Class Initialized
INFO - 2016-02-26 05:54:21 --> Output Class Initialized
INFO - 2016-02-26 05:54:21 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:21 --> Input Class Initialized
INFO - 2016-02-26 05:54:21 --> Language Class Initialized
INFO - 2016-02-26 05:54:21 --> Loader Class Initialized
INFO - 2016-02-26 05:54:21 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:21 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:21 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:21 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:21 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:22 --> Controller Class Initialized
INFO - 2016-02-26 05:54:22 --> Model Class Initialized
INFO - 2016-02-26 05:54:22 --> Model Class Initialized
INFO - 2016-02-26 05:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:22 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:22 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:22 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 08:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 08:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:54:22 --> Final output sent to browser
DEBUG - 2016-02-26 08:54:22 --> Total execution time: 1.1318
INFO - 2016-02-26 05:54:30 --> Config Class Initialized
INFO - 2016-02-26 05:54:30 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:30 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:30 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:30 --> URI Class Initialized
INFO - 2016-02-26 05:54:30 --> Router Class Initialized
INFO - 2016-02-26 05:54:30 --> Output Class Initialized
INFO - 2016-02-26 05:54:30 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:30 --> Input Class Initialized
INFO - 2016-02-26 05:54:30 --> Language Class Initialized
INFO - 2016-02-26 05:54:30 --> Loader Class Initialized
INFO - 2016-02-26 05:54:30 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:30 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:30 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:30 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:30 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:31 --> Controller Class Initialized
INFO - 2016-02-26 05:54:31 --> Model Class Initialized
INFO - 2016-02-26 05:54:31 --> Model Class Initialized
INFO - 2016-02-26 05:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:31 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:31 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:31 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 08:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 08:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:54:31 --> Final output sent to browser
DEBUG - 2016-02-26 08:54:31 --> Total execution time: 1.0831
INFO - 2016-02-26 05:54:39 --> Config Class Initialized
INFO - 2016-02-26 05:54:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:39 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:39 --> URI Class Initialized
INFO - 2016-02-26 05:54:39 --> Router Class Initialized
INFO - 2016-02-26 05:54:39 --> Output Class Initialized
INFO - 2016-02-26 05:54:39 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:39 --> Input Class Initialized
INFO - 2016-02-26 05:54:39 --> Language Class Initialized
INFO - 2016-02-26 05:54:39 --> Loader Class Initialized
INFO - 2016-02-26 05:54:39 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:39 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:39 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:39 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:39 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:40 --> Controller Class Initialized
INFO - 2016-02-26 05:54:40 --> Model Class Initialized
INFO - 2016-02-26 05:54:40 --> Model Class Initialized
INFO - 2016-02-26 05:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:40 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:40 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:40 --> Helper loaded: cookie_helper
ERROR - 2016-02-26 08:54:40 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 163
INFO - 2016-02-26 05:54:40 --> Config Class Initialized
INFO - 2016-02-26 05:54:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:40 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:40 --> URI Class Initialized
INFO - 2016-02-26 05:54:40 --> Router Class Initialized
INFO - 2016-02-26 05:54:40 --> Output Class Initialized
INFO - 2016-02-26 05:54:40 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:40 --> Input Class Initialized
INFO - 2016-02-26 05:54:40 --> Language Class Initialized
INFO - 2016-02-26 05:54:40 --> Loader Class Initialized
INFO - 2016-02-26 05:54:40 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:40 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:40 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:40 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:40 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:41 --> Controller Class Initialized
INFO - 2016-02-26 05:54:41 --> Model Class Initialized
INFO - 2016-02-26 05:54:41 --> Model Class Initialized
INFO - 2016-02-26 05:54:41 --> Form Validation Class Initialized
INFO - 2016-02-26 05:54:41 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 05:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 05:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-26 05:54:41 --> Final output sent to browser
DEBUG - 2016-02-26 05:54:41 --> Total execution time: 1.1863
INFO - 2016-02-26 05:54:43 --> Config Class Initialized
INFO - 2016-02-26 05:54:43 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:43 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:43 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:43 --> URI Class Initialized
INFO - 2016-02-26 05:54:43 --> Router Class Initialized
INFO - 2016-02-26 05:54:43 --> Output Class Initialized
INFO - 2016-02-26 05:54:43 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:43 --> Input Class Initialized
INFO - 2016-02-26 05:54:43 --> Language Class Initialized
INFO - 2016-02-26 05:54:43 --> Loader Class Initialized
INFO - 2016-02-26 05:54:43 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:43 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:43 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:43 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:43 --> Database Driver Class Initialized
INFO - 2016-02-26 05:54:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:54:44 --> Controller Class Initialized
INFO - 2016-02-26 05:54:44 --> Model Class Initialized
INFO - 2016-02-26 05:54:44 --> Model Class Initialized
INFO - 2016-02-26 05:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:54:44 --> Pagination Class Initialized
INFO - 2016-02-26 05:54:44 --> Helper loaded: text_helper
INFO - 2016-02-26 05:54:44 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 08:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 08:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:54:44 --> Final output sent to browser
DEBUG - 2016-02-26 08:54:44 --> Total execution time: 1.1455
INFO - 2016-02-26 05:54:59 --> Config Class Initialized
INFO - 2016-02-26 05:54:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:54:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:54:59 --> Utf8 Class Initialized
INFO - 2016-02-26 05:54:59 --> URI Class Initialized
INFO - 2016-02-26 05:54:59 --> Router Class Initialized
INFO - 2016-02-26 05:54:59 --> Output Class Initialized
INFO - 2016-02-26 05:54:59 --> Security Class Initialized
DEBUG - 2016-02-26 05:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:54:59 --> Input Class Initialized
INFO - 2016-02-26 05:54:59 --> Language Class Initialized
INFO - 2016-02-26 05:54:59 --> Loader Class Initialized
INFO - 2016-02-26 05:54:59 --> Helper loaded: url_helper
INFO - 2016-02-26 05:54:59 --> Helper loaded: file_helper
INFO - 2016-02-26 05:54:59 --> Helper loaded: date_helper
INFO - 2016-02-26 05:54:59 --> Helper loaded: form_helper
INFO - 2016-02-26 05:54:59 --> Database Driver Class Initialized
INFO - 2016-02-26 05:55:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:55:00 --> Controller Class Initialized
INFO - 2016-02-26 05:55:00 --> Model Class Initialized
INFO - 2016-02-26 05:55:00 --> Model Class Initialized
INFO - 2016-02-26 05:55:00 --> Form Validation Class Initialized
INFO - 2016-02-26 05:55:00 --> Helper loaded: text_helper
INFO - 2016-02-26 05:55:00 --> Config Class Initialized
INFO - 2016-02-26 05:55:00 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:55:00 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:55:00 --> Utf8 Class Initialized
INFO - 2016-02-26 05:55:00 --> URI Class Initialized
INFO - 2016-02-26 05:55:00 --> Router Class Initialized
INFO - 2016-02-26 05:55:00 --> Output Class Initialized
INFO - 2016-02-26 05:55:00 --> Security Class Initialized
DEBUG - 2016-02-26 05:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:55:00 --> Input Class Initialized
INFO - 2016-02-26 05:55:00 --> Language Class Initialized
INFO - 2016-02-26 05:55:00 --> Loader Class Initialized
INFO - 2016-02-26 05:55:00 --> Helper loaded: url_helper
INFO - 2016-02-26 05:55:00 --> Helper loaded: file_helper
INFO - 2016-02-26 05:55:00 --> Helper loaded: date_helper
INFO - 2016-02-26 05:55:00 --> Helper loaded: form_helper
INFO - 2016-02-26 05:55:00 --> Database Driver Class Initialized
INFO - 2016-02-26 05:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:55:01 --> Controller Class Initialized
INFO - 2016-02-26 05:55:01 --> Model Class Initialized
INFO - 2016-02-26 05:55:01 --> Model Class Initialized
INFO - 2016-02-26 05:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:55:01 --> Pagination Class Initialized
INFO - 2016-02-26 05:55:01 --> Helper loaded: text_helper
INFO - 2016-02-26 05:55:01 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 08:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 08:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:55:01 --> Final output sent to browser
DEBUG - 2016-02-26 08:55:01 --> Total execution time: 1.1400
INFO - 2016-02-26 05:55:06 --> Config Class Initialized
INFO - 2016-02-26 05:55:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:55:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:55:06 --> Utf8 Class Initialized
INFO - 2016-02-26 05:55:06 --> URI Class Initialized
INFO - 2016-02-26 05:55:06 --> Router Class Initialized
INFO - 2016-02-26 05:55:06 --> Output Class Initialized
INFO - 2016-02-26 05:55:06 --> Security Class Initialized
DEBUG - 2016-02-26 05:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:55:06 --> Input Class Initialized
INFO - 2016-02-26 05:55:06 --> Language Class Initialized
INFO - 2016-02-26 05:55:06 --> Loader Class Initialized
INFO - 2016-02-26 05:55:06 --> Helper loaded: url_helper
INFO - 2016-02-26 05:55:06 --> Helper loaded: file_helper
INFO - 2016-02-26 05:55:06 --> Helper loaded: date_helper
INFO - 2016-02-26 05:55:06 --> Helper loaded: form_helper
INFO - 2016-02-26 05:55:06 --> Database Driver Class Initialized
INFO - 2016-02-26 05:55:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:55:07 --> Controller Class Initialized
INFO - 2016-02-26 05:55:07 --> Model Class Initialized
INFO - 2016-02-26 05:55:07 --> Model Class Initialized
INFO - 2016-02-26 05:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:55:07 --> Pagination Class Initialized
INFO - 2016-02-26 05:55:07 --> Helper loaded: text_helper
INFO - 2016-02-26 05:55:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 08:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 08:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:55:07 --> Final output sent to browser
DEBUG - 2016-02-26 08:55:07 --> Total execution time: 1.0836
INFO - 2016-02-26 05:59:16 --> Config Class Initialized
INFO - 2016-02-26 05:59:16 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:59:16 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:59:16 --> Utf8 Class Initialized
INFO - 2016-02-26 05:59:16 --> URI Class Initialized
INFO - 2016-02-26 05:59:16 --> Router Class Initialized
INFO - 2016-02-26 05:59:16 --> Output Class Initialized
INFO - 2016-02-26 05:59:16 --> Security Class Initialized
DEBUG - 2016-02-26 05:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:59:16 --> Input Class Initialized
INFO - 2016-02-26 05:59:16 --> Language Class Initialized
INFO - 2016-02-26 05:59:16 --> Loader Class Initialized
INFO - 2016-02-26 05:59:16 --> Helper loaded: url_helper
INFO - 2016-02-26 05:59:16 --> Helper loaded: file_helper
INFO - 2016-02-26 05:59:16 --> Helper loaded: date_helper
INFO - 2016-02-26 05:59:16 --> Helper loaded: form_helper
INFO - 2016-02-26 05:59:16 --> Database Driver Class Initialized
INFO - 2016-02-26 05:59:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:59:17 --> Controller Class Initialized
INFO - 2016-02-26 05:59:17 --> Model Class Initialized
INFO - 2016-02-26 05:59:17 --> Model Class Initialized
INFO - 2016-02-26 05:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:59:17 --> Pagination Class Initialized
INFO - 2016-02-26 05:59:17 --> Helper loaded: text_helper
INFO - 2016-02-26 05:59:17 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 08:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 08:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 08:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 08:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 08:59:17 --> Final output sent to browser
DEBUG - 2016-02-26 08:59:17 --> Total execution time: 1.1266
INFO - 2016-02-26 05:59:26 --> Config Class Initialized
INFO - 2016-02-26 05:59:26 --> Hooks Class Initialized
DEBUG - 2016-02-26 05:59:26 --> UTF-8 Support Enabled
INFO - 2016-02-26 05:59:26 --> Utf8 Class Initialized
INFO - 2016-02-26 05:59:26 --> URI Class Initialized
INFO - 2016-02-26 05:59:26 --> Router Class Initialized
INFO - 2016-02-26 05:59:26 --> Output Class Initialized
INFO - 2016-02-26 05:59:26 --> Security Class Initialized
DEBUG - 2016-02-26 05:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 05:59:26 --> Input Class Initialized
INFO - 2016-02-26 05:59:26 --> Language Class Initialized
INFO - 2016-02-26 05:59:26 --> Loader Class Initialized
INFO - 2016-02-26 05:59:26 --> Helper loaded: url_helper
INFO - 2016-02-26 05:59:26 --> Helper loaded: file_helper
INFO - 2016-02-26 05:59:26 --> Helper loaded: date_helper
INFO - 2016-02-26 05:59:26 --> Helper loaded: form_helper
INFO - 2016-02-26 05:59:26 --> Database Driver Class Initialized
INFO - 2016-02-26 05:59:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 05:59:27 --> Controller Class Initialized
INFO - 2016-02-26 05:59:27 --> Model Class Initialized
INFO - 2016-02-26 05:59:27 --> Model Class Initialized
INFO - 2016-02-26 05:59:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 05:59:27 --> Pagination Class Initialized
INFO - 2016-02-26 05:59:27 --> Helper loaded: text_helper
INFO - 2016-02-26 05:59:27 --> Helper loaded: cookie_helper
INFO - 2016-02-26 08:59:27 --> Upload Class Initialized
INFO - 2016-02-26 08:59:27 --> Image Lib Class Initialized
DEBUG - 2016-02-26 08:59:27 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 08:59:27 --> Final output sent to browser
DEBUG - 2016-02-26 08:59:27 --> Total execution time: 1.1332
INFO - 2016-02-26 06:02:26 --> Config Class Initialized
INFO - 2016-02-26 06:02:26 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:02:26 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:02:26 --> Utf8 Class Initialized
INFO - 2016-02-26 06:02:26 --> URI Class Initialized
INFO - 2016-02-26 06:02:26 --> Router Class Initialized
INFO - 2016-02-26 06:02:26 --> Output Class Initialized
INFO - 2016-02-26 06:02:26 --> Security Class Initialized
DEBUG - 2016-02-26 06:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:02:26 --> Input Class Initialized
INFO - 2016-02-26 06:02:26 --> Language Class Initialized
INFO - 2016-02-26 06:02:26 --> Loader Class Initialized
INFO - 2016-02-26 06:02:26 --> Helper loaded: url_helper
INFO - 2016-02-26 06:02:26 --> Helper loaded: file_helper
INFO - 2016-02-26 06:02:26 --> Helper loaded: date_helper
INFO - 2016-02-26 06:02:26 --> Helper loaded: form_helper
INFO - 2016-02-26 06:02:26 --> Database Driver Class Initialized
INFO - 2016-02-26 06:02:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:02:27 --> Controller Class Initialized
INFO - 2016-02-26 06:02:27 --> Model Class Initialized
INFO - 2016-02-26 06:02:27 --> Model Class Initialized
INFO - 2016-02-26 06:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:02:27 --> Pagination Class Initialized
INFO - 2016-02-26 06:02:27 --> Helper loaded: text_helper
INFO - 2016-02-26 06:02:27 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:02:27 --> Upload Class Initialized
INFO - 2016-02-26 09:02:27 --> Image Lib Class Initialized
DEBUG - 2016-02-26 09:02:27 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 09:02:27 --> Final output sent to browser
DEBUG - 2016-02-26 09:02:27 --> Total execution time: 1.3983
INFO - 2016-02-26 06:09:08 --> Config Class Initialized
INFO - 2016-02-26 06:09:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:09:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:09:08 --> Utf8 Class Initialized
INFO - 2016-02-26 06:09:08 --> URI Class Initialized
INFO - 2016-02-26 06:09:08 --> Router Class Initialized
INFO - 2016-02-26 06:09:08 --> Output Class Initialized
INFO - 2016-02-26 06:09:08 --> Security Class Initialized
DEBUG - 2016-02-26 06:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:09:08 --> Input Class Initialized
INFO - 2016-02-26 06:09:08 --> Language Class Initialized
INFO - 2016-02-26 06:09:08 --> Loader Class Initialized
INFO - 2016-02-26 06:09:08 --> Helper loaded: url_helper
INFO - 2016-02-26 06:09:08 --> Helper loaded: file_helper
INFO - 2016-02-26 06:09:08 --> Helper loaded: date_helper
INFO - 2016-02-26 06:09:08 --> Helper loaded: form_helper
INFO - 2016-02-26 06:09:08 --> Database Driver Class Initialized
INFO - 2016-02-26 06:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:09:09 --> Controller Class Initialized
INFO - 2016-02-26 06:09:09 --> Model Class Initialized
INFO - 2016-02-26 06:09:09 --> Model Class Initialized
INFO - 2016-02-26 06:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:09:09 --> Pagination Class Initialized
INFO - 2016-02-26 06:09:09 --> Helper loaded: text_helper
INFO - 2016-02-26 06:09:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:09:09 --> Final output sent to browser
DEBUG - 2016-02-26 09:09:09 --> Total execution time: 1.1426
INFO - 2016-02-26 06:09:28 --> Config Class Initialized
INFO - 2016-02-26 06:09:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:09:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:09:28 --> Utf8 Class Initialized
INFO - 2016-02-26 06:09:28 --> URI Class Initialized
INFO - 2016-02-26 06:09:28 --> Router Class Initialized
INFO - 2016-02-26 06:09:28 --> Output Class Initialized
INFO - 2016-02-26 06:09:28 --> Security Class Initialized
DEBUG - 2016-02-26 06:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:09:28 --> Input Class Initialized
INFO - 2016-02-26 06:09:28 --> Language Class Initialized
INFO - 2016-02-26 06:09:28 --> Loader Class Initialized
INFO - 2016-02-26 06:09:28 --> Helper loaded: url_helper
INFO - 2016-02-26 06:09:28 --> Helper loaded: file_helper
INFO - 2016-02-26 06:09:28 --> Helper loaded: date_helper
INFO - 2016-02-26 06:09:28 --> Helper loaded: form_helper
INFO - 2016-02-26 06:09:28 --> Database Driver Class Initialized
INFO - 2016-02-26 06:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:09:29 --> Controller Class Initialized
INFO - 2016-02-26 06:09:29 --> Model Class Initialized
INFO - 2016-02-26 06:09:29 --> Model Class Initialized
INFO - 2016-02-26 06:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:09:29 --> Pagination Class Initialized
INFO - 2016-02-26 06:09:29 --> Helper loaded: text_helper
INFO - 2016-02-26 06:09:29 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:09:29 --> Upload Class Initialized
INFO - 2016-02-26 09:09:29 --> Image Lib Class Initialized
DEBUG - 2016-02-26 09:09:29 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 09:09:29 --> Final output sent to browser
DEBUG - 2016-02-26 09:09:29 --> Total execution time: 1.1665
INFO - 2016-02-26 06:29:11 --> Config Class Initialized
INFO - 2016-02-26 06:29:11 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:29:11 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:29:11 --> Utf8 Class Initialized
INFO - 2016-02-26 06:29:11 --> URI Class Initialized
INFO - 2016-02-26 06:29:11 --> Router Class Initialized
INFO - 2016-02-26 06:29:11 --> Output Class Initialized
INFO - 2016-02-26 06:29:11 --> Security Class Initialized
DEBUG - 2016-02-26 06:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:29:11 --> Input Class Initialized
INFO - 2016-02-26 06:29:11 --> Language Class Initialized
INFO - 2016-02-26 06:29:11 --> Loader Class Initialized
INFO - 2016-02-26 06:29:11 --> Helper loaded: url_helper
INFO - 2016-02-26 06:29:11 --> Helper loaded: file_helper
INFO - 2016-02-26 06:29:11 --> Helper loaded: date_helper
INFO - 2016-02-26 06:29:11 --> Helper loaded: form_helper
INFO - 2016-02-26 06:29:11 --> Database Driver Class Initialized
INFO - 2016-02-26 06:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:29:12 --> Controller Class Initialized
INFO - 2016-02-26 06:29:12 --> Model Class Initialized
INFO - 2016-02-26 06:29:12 --> Model Class Initialized
INFO - 2016-02-26 06:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:29:12 --> Pagination Class Initialized
INFO - 2016-02-26 06:29:12 --> Helper loaded: text_helper
INFO - 2016-02-26 06:29:12 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:29:12 --> Final output sent to browser
DEBUG - 2016-02-26 09:29:12 --> Total execution time: 1.0965
INFO - 2016-02-26 06:30:40 --> Config Class Initialized
INFO - 2016-02-26 06:30:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:30:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:30:40 --> Utf8 Class Initialized
INFO - 2016-02-26 06:30:40 --> URI Class Initialized
INFO - 2016-02-26 06:30:40 --> Router Class Initialized
INFO - 2016-02-26 06:30:40 --> Output Class Initialized
INFO - 2016-02-26 06:30:40 --> Security Class Initialized
DEBUG - 2016-02-26 06:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:30:40 --> Input Class Initialized
INFO - 2016-02-26 06:30:40 --> Language Class Initialized
INFO - 2016-02-26 06:30:40 --> Loader Class Initialized
INFO - 2016-02-26 06:30:40 --> Helper loaded: url_helper
INFO - 2016-02-26 06:30:40 --> Helper loaded: file_helper
INFO - 2016-02-26 06:30:40 --> Helper loaded: date_helper
INFO - 2016-02-26 06:30:40 --> Helper loaded: form_helper
INFO - 2016-02-26 06:30:40 --> Database Driver Class Initialized
INFO - 2016-02-26 06:30:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:30:41 --> Controller Class Initialized
INFO - 2016-02-26 06:30:41 --> Model Class Initialized
INFO - 2016-02-26 06:30:41 --> Model Class Initialized
INFO - 2016-02-26 06:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:30:41 --> Pagination Class Initialized
INFO - 2016-02-26 06:30:41 --> Helper loaded: text_helper
INFO - 2016-02-26 06:30:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:30:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:30:41 --> Final output sent to browser
DEBUG - 2016-02-26 09:30:41 --> Total execution time: 1.1564
INFO - 2016-02-26 06:31:38 --> Config Class Initialized
INFO - 2016-02-26 06:31:38 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:31:38 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:31:38 --> Utf8 Class Initialized
INFO - 2016-02-26 06:31:38 --> URI Class Initialized
INFO - 2016-02-26 06:31:38 --> Router Class Initialized
INFO - 2016-02-26 06:31:38 --> Output Class Initialized
INFO - 2016-02-26 06:31:38 --> Security Class Initialized
DEBUG - 2016-02-26 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:31:38 --> Input Class Initialized
INFO - 2016-02-26 06:31:38 --> Language Class Initialized
INFO - 2016-02-26 06:31:38 --> Loader Class Initialized
INFO - 2016-02-26 06:31:38 --> Helper loaded: url_helper
INFO - 2016-02-26 06:31:38 --> Helper loaded: file_helper
INFO - 2016-02-26 06:31:38 --> Helper loaded: date_helper
INFO - 2016-02-26 06:31:38 --> Helper loaded: form_helper
INFO - 2016-02-26 06:31:38 --> Database Driver Class Initialized
INFO - 2016-02-26 06:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:31:39 --> Controller Class Initialized
INFO - 2016-02-26 06:31:39 --> Model Class Initialized
INFO - 2016-02-26 06:31:39 --> Model Class Initialized
INFO - 2016-02-26 06:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:31:39 --> Pagination Class Initialized
INFO - 2016-02-26 06:31:39 --> Helper loaded: text_helper
INFO - 2016-02-26 06:31:39 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:31:39 --> Final output sent to browser
DEBUG - 2016-02-26 09:31:39 --> Total execution time: 1.1987
INFO - 2016-02-26 06:33:21 --> Config Class Initialized
INFO - 2016-02-26 06:33:21 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:33:21 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:33:21 --> Utf8 Class Initialized
INFO - 2016-02-26 06:33:21 --> URI Class Initialized
INFO - 2016-02-26 06:33:21 --> Router Class Initialized
INFO - 2016-02-26 06:33:21 --> Output Class Initialized
INFO - 2016-02-26 06:33:21 --> Security Class Initialized
DEBUG - 2016-02-26 06:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:33:21 --> Input Class Initialized
INFO - 2016-02-26 06:33:21 --> Language Class Initialized
INFO - 2016-02-26 06:33:21 --> Loader Class Initialized
INFO - 2016-02-26 06:33:21 --> Helper loaded: url_helper
INFO - 2016-02-26 06:33:21 --> Helper loaded: file_helper
INFO - 2016-02-26 06:33:21 --> Helper loaded: date_helper
INFO - 2016-02-26 06:33:21 --> Helper loaded: form_helper
INFO - 2016-02-26 06:33:21 --> Database Driver Class Initialized
INFO - 2016-02-26 06:33:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:33:22 --> Controller Class Initialized
INFO - 2016-02-26 06:33:22 --> Model Class Initialized
INFO - 2016-02-26 06:33:22 --> Model Class Initialized
INFO - 2016-02-26 06:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:33:22 --> Pagination Class Initialized
INFO - 2016-02-26 06:33:22 --> Helper loaded: text_helper
INFO - 2016-02-26 06:33:22 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:33:22 --> Final output sent to browser
DEBUG - 2016-02-26 09:33:22 --> Total execution time: 1.1445
INFO - 2016-02-26 06:34:40 --> Config Class Initialized
INFO - 2016-02-26 06:34:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:34:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:34:40 --> Utf8 Class Initialized
INFO - 2016-02-26 06:34:40 --> URI Class Initialized
INFO - 2016-02-26 06:34:40 --> Router Class Initialized
INFO - 2016-02-26 06:34:40 --> Output Class Initialized
INFO - 2016-02-26 06:34:40 --> Security Class Initialized
DEBUG - 2016-02-26 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:34:40 --> Input Class Initialized
INFO - 2016-02-26 06:34:40 --> Language Class Initialized
INFO - 2016-02-26 06:34:40 --> Loader Class Initialized
INFO - 2016-02-26 06:34:40 --> Helper loaded: url_helper
INFO - 2016-02-26 06:34:40 --> Helper loaded: file_helper
INFO - 2016-02-26 06:34:40 --> Helper loaded: date_helper
INFO - 2016-02-26 06:34:40 --> Helper loaded: form_helper
INFO - 2016-02-26 06:34:40 --> Database Driver Class Initialized
INFO - 2016-02-26 06:34:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:34:41 --> Controller Class Initialized
INFO - 2016-02-26 06:34:41 --> Model Class Initialized
INFO - 2016-02-26 06:34:41 --> Model Class Initialized
INFO - 2016-02-26 06:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:34:41 --> Pagination Class Initialized
INFO - 2016-02-26 06:34:41 --> Helper loaded: text_helper
INFO - 2016-02-26 06:34:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:34:41 --> Final output sent to browser
DEBUG - 2016-02-26 09:34:41 --> Total execution time: 1.1524
INFO - 2016-02-26 06:35:11 --> Config Class Initialized
INFO - 2016-02-26 06:35:11 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:35:11 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:35:11 --> Utf8 Class Initialized
INFO - 2016-02-26 06:35:11 --> URI Class Initialized
DEBUG - 2016-02-26 06:35:11 --> No URI present. Default controller set.
INFO - 2016-02-26 06:35:11 --> Router Class Initialized
INFO - 2016-02-26 06:35:11 --> Output Class Initialized
INFO - 2016-02-26 06:35:11 --> Security Class Initialized
DEBUG - 2016-02-26 06:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:35:11 --> Input Class Initialized
INFO - 2016-02-26 06:35:11 --> Language Class Initialized
INFO - 2016-02-26 06:35:11 --> Loader Class Initialized
INFO - 2016-02-26 06:35:11 --> Helper loaded: url_helper
INFO - 2016-02-26 06:35:11 --> Helper loaded: file_helper
INFO - 2016-02-26 06:35:11 --> Helper loaded: date_helper
INFO - 2016-02-26 06:35:11 --> Helper loaded: form_helper
INFO - 2016-02-26 06:35:11 --> Database Driver Class Initialized
INFO - 2016-02-26 06:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:35:12 --> Controller Class Initialized
INFO - 2016-02-26 06:35:12 --> Model Class Initialized
INFO - 2016-02-26 06:35:13 --> Model Class Initialized
INFO - 2016-02-26 06:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:35:13 --> Pagination Class Initialized
INFO - 2016-02-26 06:35:13 --> Helper loaded: text_helper
INFO - 2016-02-26 06:35:13 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 09:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:35:13 --> Final output sent to browser
DEBUG - 2016-02-26 09:35:13 --> Total execution time: 1.2072
INFO - 2016-02-26 06:35:15 --> Config Class Initialized
INFO - 2016-02-26 06:35:15 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:35:15 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:35:15 --> Utf8 Class Initialized
INFO - 2016-02-26 06:35:15 --> URI Class Initialized
INFO - 2016-02-26 06:35:15 --> Router Class Initialized
INFO - 2016-02-26 06:35:15 --> Output Class Initialized
INFO - 2016-02-26 06:35:15 --> Security Class Initialized
DEBUG - 2016-02-26 06:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:35:15 --> Input Class Initialized
INFO - 2016-02-26 06:35:15 --> Language Class Initialized
INFO - 2016-02-26 06:35:15 --> Loader Class Initialized
INFO - 2016-02-26 06:35:15 --> Helper loaded: url_helper
INFO - 2016-02-26 06:35:15 --> Helper loaded: file_helper
INFO - 2016-02-26 06:35:15 --> Helper loaded: date_helper
INFO - 2016-02-26 06:35:15 --> Helper loaded: form_helper
INFO - 2016-02-26 06:35:15 --> Database Driver Class Initialized
INFO - 2016-02-26 06:35:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:35:16 --> Controller Class Initialized
INFO - 2016-02-26 06:35:16 --> Model Class Initialized
INFO - 2016-02-26 06:35:16 --> Model Class Initialized
INFO - 2016-02-26 06:35:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:35:16 --> Pagination Class Initialized
INFO - 2016-02-26 06:35:16 --> Helper loaded: text_helper
INFO - 2016-02-26 06:35:16 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:35:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:35:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:35:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 09:35:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 09:35:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:35:16 --> Final output sent to browser
DEBUG - 2016-02-26 09:35:16 --> Total execution time: 1.1340
INFO - 2016-02-26 06:35:18 --> Config Class Initialized
INFO - 2016-02-26 06:35:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:35:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:35:18 --> Utf8 Class Initialized
INFO - 2016-02-26 06:35:18 --> URI Class Initialized
INFO - 2016-02-26 06:35:18 --> Router Class Initialized
INFO - 2016-02-26 06:35:18 --> Output Class Initialized
INFO - 2016-02-26 06:35:18 --> Security Class Initialized
DEBUG - 2016-02-26 06:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:35:18 --> Input Class Initialized
INFO - 2016-02-26 06:35:18 --> Language Class Initialized
INFO - 2016-02-26 06:35:18 --> Loader Class Initialized
INFO - 2016-02-26 06:35:18 --> Helper loaded: url_helper
INFO - 2016-02-26 06:35:18 --> Helper loaded: file_helper
INFO - 2016-02-26 06:35:18 --> Helper loaded: date_helper
INFO - 2016-02-26 06:35:18 --> Helper loaded: form_helper
INFO - 2016-02-26 06:35:18 --> Database Driver Class Initialized
INFO - 2016-02-26 06:35:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:35:19 --> Controller Class Initialized
INFO - 2016-02-26 06:35:19 --> Model Class Initialized
INFO - 2016-02-26 06:35:19 --> Model Class Initialized
INFO - 2016-02-26 06:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:35:19 --> Pagination Class Initialized
INFO - 2016-02-26 06:35:19 --> Helper loaded: text_helper
INFO - 2016-02-26 06:35:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:35:19 --> Final output sent to browser
DEBUG - 2016-02-26 09:35:19 --> Total execution time: 1.1092
INFO - 2016-02-26 06:35:55 --> Config Class Initialized
INFO - 2016-02-26 06:35:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:35:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:35:55 --> Utf8 Class Initialized
INFO - 2016-02-26 06:35:55 --> URI Class Initialized
INFO - 2016-02-26 06:35:55 --> Router Class Initialized
INFO - 2016-02-26 06:35:55 --> Output Class Initialized
INFO - 2016-02-26 06:35:55 --> Security Class Initialized
DEBUG - 2016-02-26 06:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:35:55 --> Input Class Initialized
INFO - 2016-02-26 06:35:55 --> Language Class Initialized
INFO - 2016-02-26 06:35:55 --> Loader Class Initialized
INFO - 2016-02-26 06:35:55 --> Helper loaded: url_helper
INFO - 2016-02-26 06:35:55 --> Helper loaded: file_helper
INFO - 2016-02-26 06:35:55 --> Helper loaded: date_helper
INFO - 2016-02-26 06:35:55 --> Helper loaded: form_helper
INFO - 2016-02-26 06:35:55 --> Database Driver Class Initialized
INFO - 2016-02-26 06:35:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:35:56 --> Controller Class Initialized
INFO - 2016-02-26 06:35:56 --> Model Class Initialized
INFO - 2016-02-26 06:35:56 --> Model Class Initialized
INFO - 2016-02-26 06:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:35:56 --> Pagination Class Initialized
INFO - 2016-02-26 06:35:56 --> Helper loaded: text_helper
INFO - 2016-02-26 06:35:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:35:56 --> Final output sent to browser
DEBUG - 2016-02-26 09:35:56 --> Total execution time: 1.1363
INFO - 2016-02-26 06:35:58 --> Config Class Initialized
INFO - 2016-02-26 06:35:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:35:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:35:59 --> Utf8 Class Initialized
INFO - 2016-02-26 06:35:59 --> URI Class Initialized
INFO - 2016-02-26 06:35:59 --> Router Class Initialized
INFO - 2016-02-26 06:35:59 --> Output Class Initialized
INFO - 2016-02-26 06:35:59 --> Security Class Initialized
DEBUG - 2016-02-26 06:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:35:59 --> Input Class Initialized
INFO - 2016-02-26 06:35:59 --> Language Class Initialized
INFO - 2016-02-26 06:35:59 --> Loader Class Initialized
INFO - 2016-02-26 06:35:59 --> Helper loaded: url_helper
INFO - 2016-02-26 06:35:59 --> Helper loaded: file_helper
INFO - 2016-02-26 06:35:59 --> Helper loaded: date_helper
INFO - 2016-02-26 06:35:59 --> Helper loaded: form_helper
INFO - 2016-02-26 06:35:59 --> Database Driver Class Initialized
INFO - 2016-02-26 06:36:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:36:00 --> Controller Class Initialized
INFO - 2016-02-26 06:36:00 --> Model Class Initialized
INFO - 2016-02-26 06:36:00 --> Model Class Initialized
INFO - 2016-02-26 06:36:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:36:00 --> Pagination Class Initialized
INFO - 2016-02-26 06:36:00 --> Helper loaded: text_helper
INFO - 2016-02-26 06:36:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:36:00 --> Final output sent to browser
DEBUG - 2016-02-26 09:36:00 --> Total execution time: 1.1424
INFO - 2016-02-26 06:36:28 --> Config Class Initialized
INFO - 2016-02-26 06:36:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:36:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:36:28 --> Utf8 Class Initialized
INFO - 2016-02-26 06:36:28 --> URI Class Initialized
INFO - 2016-02-26 06:36:28 --> Router Class Initialized
INFO - 2016-02-26 06:36:28 --> Output Class Initialized
INFO - 2016-02-26 06:36:28 --> Security Class Initialized
DEBUG - 2016-02-26 06:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:36:28 --> Input Class Initialized
INFO - 2016-02-26 06:36:28 --> Language Class Initialized
INFO - 2016-02-26 06:36:28 --> Loader Class Initialized
INFO - 2016-02-26 06:36:28 --> Helper loaded: url_helper
INFO - 2016-02-26 06:36:28 --> Helper loaded: file_helper
INFO - 2016-02-26 06:36:28 --> Helper loaded: date_helper
INFO - 2016-02-26 06:36:28 --> Helper loaded: form_helper
INFO - 2016-02-26 06:36:28 --> Database Driver Class Initialized
INFO - 2016-02-26 06:36:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:36:29 --> Controller Class Initialized
INFO - 2016-02-26 06:36:29 --> Model Class Initialized
INFO - 2016-02-26 06:36:29 --> Model Class Initialized
INFO - 2016-02-26 06:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:36:29 --> Pagination Class Initialized
INFO - 2016-02-26 06:36:30 --> Helper loaded: text_helper
INFO - 2016-02-26 06:36:30 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:36:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:36:30 --> Final output sent to browser
DEBUG - 2016-02-26 09:36:30 --> Total execution time: 1.1946
INFO - 2016-02-26 06:38:47 --> Config Class Initialized
INFO - 2016-02-26 06:38:47 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:38:47 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:38:47 --> Utf8 Class Initialized
INFO - 2016-02-26 06:38:47 --> URI Class Initialized
INFO - 2016-02-26 06:38:47 --> Router Class Initialized
INFO - 2016-02-26 06:38:47 --> Output Class Initialized
INFO - 2016-02-26 06:38:47 --> Security Class Initialized
DEBUG - 2016-02-26 06:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:38:47 --> Input Class Initialized
INFO - 2016-02-26 06:38:47 --> Language Class Initialized
INFO - 2016-02-26 06:38:47 --> Loader Class Initialized
INFO - 2016-02-26 06:38:47 --> Helper loaded: url_helper
INFO - 2016-02-26 06:38:47 --> Helper loaded: file_helper
INFO - 2016-02-26 06:38:47 --> Helper loaded: date_helper
INFO - 2016-02-26 06:38:47 --> Helper loaded: form_helper
INFO - 2016-02-26 06:38:47 --> Database Driver Class Initialized
INFO - 2016-02-26 06:38:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:38:49 --> Controller Class Initialized
INFO - 2016-02-26 06:38:49 --> Model Class Initialized
INFO - 2016-02-26 06:38:49 --> Model Class Initialized
INFO - 2016-02-26 06:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:38:49 --> Pagination Class Initialized
INFO - 2016-02-26 06:38:49 --> Helper loaded: text_helper
INFO - 2016-02-26 06:38:49 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:38:49 --> Final output sent to browser
DEBUG - 2016-02-26 09:38:49 --> Total execution time: 1.3997
INFO - 2016-02-26 06:39:49 --> Config Class Initialized
INFO - 2016-02-26 06:39:49 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:39:49 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:39:49 --> Utf8 Class Initialized
INFO - 2016-02-26 06:39:49 --> URI Class Initialized
INFO - 2016-02-26 06:39:49 --> Router Class Initialized
INFO - 2016-02-26 06:39:49 --> Output Class Initialized
INFO - 2016-02-26 06:39:49 --> Security Class Initialized
DEBUG - 2016-02-26 06:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:39:49 --> Input Class Initialized
INFO - 2016-02-26 06:39:49 --> Language Class Initialized
INFO - 2016-02-26 06:39:49 --> Loader Class Initialized
INFO - 2016-02-26 06:39:49 --> Helper loaded: url_helper
INFO - 2016-02-26 06:39:49 --> Helper loaded: file_helper
INFO - 2016-02-26 06:39:49 --> Helper loaded: date_helper
INFO - 2016-02-26 06:39:49 --> Helper loaded: form_helper
INFO - 2016-02-26 06:39:49 --> Database Driver Class Initialized
INFO - 2016-02-26 06:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:39:50 --> Controller Class Initialized
INFO - 2016-02-26 06:39:50 --> Model Class Initialized
INFO - 2016-02-26 06:39:50 --> Model Class Initialized
INFO - 2016-02-26 06:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:39:50 --> Pagination Class Initialized
INFO - 2016-02-26 06:39:50 --> Helper loaded: text_helper
INFO - 2016-02-26 06:39:50 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:39:50 --> Final output sent to browser
DEBUG - 2016-02-26 09:39:50 --> Total execution time: 1.1804
INFO - 2016-02-26 06:40:17 --> Config Class Initialized
INFO - 2016-02-26 06:40:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:40:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:40:17 --> Utf8 Class Initialized
INFO - 2016-02-26 06:40:17 --> URI Class Initialized
INFO - 2016-02-26 06:40:17 --> Router Class Initialized
INFO - 2016-02-26 06:40:17 --> Output Class Initialized
INFO - 2016-02-26 06:40:17 --> Security Class Initialized
DEBUG - 2016-02-26 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:40:17 --> Input Class Initialized
INFO - 2016-02-26 06:40:17 --> Language Class Initialized
INFO - 2016-02-26 06:40:17 --> Loader Class Initialized
INFO - 2016-02-26 06:40:17 --> Helper loaded: url_helper
INFO - 2016-02-26 06:40:17 --> Helper loaded: file_helper
INFO - 2016-02-26 06:40:17 --> Helper loaded: date_helper
INFO - 2016-02-26 06:40:17 --> Helper loaded: form_helper
INFO - 2016-02-26 06:40:17 --> Database Driver Class Initialized
INFO - 2016-02-26 06:40:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:40:18 --> Controller Class Initialized
INFO - 2016-02-26 06:40:18 --> Model Class Initialized
INFO - 2016-02-26 06:40:18 --> Model Class Initialized
INFO - 2016-02-26 06:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:40:18 --> Pagination Class Initialized
INFO - 2016-02-26 06:40:18 --> Helper loaded: text_helper
INFO - 2016-02-26 06:40:18 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:40:18 --> Final output sent to browser
DEBUG - 2016-02-26 09:40:18 --> Total execution time: 1.1842
INFO - 2016-02-26 06:40:39 --> Config Class Initialized
INFO - 2016-02-26 06:40:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:40:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:40:39 --> Utf8 Class Initialized
INFO - 2016-02-26 06:40:39 --> URI Class Initialized
INFO - 2016-02-26 06:40:39 --> Router Class Initialized
INFO - 2016-02-26 06:40:39 --> Output Class Initialized
INFO - 2016-02-26 06:40:39 --> Security Class Initialized
DEBUG - 2016-02-26 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:40:39 --> Input Class Initialized
INFO - 2016-02-26 06:40:39 --> Language Class Initialized
INFO - 2016-02-26 06:40:39 --> Loader Class Initialized
INFO - 2016-02-26 06:40:39 --> Helper loaded: url_helper
INFO - 2016-02-26 06:40:39 --> Helper loaded: file_helper
INFO - 2016-02-26 06:40:39 --> Helper loaded: date_helper
INFO - 2016-02-26 06:40:39 --> Helper loaded: form_helper
INFO - 2016-02-26 06:40:39 --> Database Driver Class Initialized
INFO - 2016-02-26 06:40:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:40:40 --> Controller Class Initialized
INFO - 2016-02-26 06:40:40 --> Model Class Initialized
INFO - 2016-02-26 06:40:41 --> Model Class Initialized
INFO - 2016-02-26 06:40:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:40:41 --> Pagination Class Initialized
INFO - 2016-02-26 06:40:41 --> Helper loaded: text_helper
INFO - 2016-02-26 06:40:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:40:41 --> Final output sent to browser
DEBUG - 2016-02-26 09:40:41 --> Total execution time: 1.1604
INFO - 2016-02-26 06:41:18 --> Config Class Initialized
INFO - 2016-02-26 06:41:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:41:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:41:18 --> Utf8 Class Initialized
INFO - 2016-02-26 06:41:18 --> URI Class Initialized
INFO - 2016-02-26 06:41:18 --> Router Class Initialized
INFO - 2016-02-26 06:41:18 --> Output Class Initialized
INFO - 2016-02-26 06:41:18 --> Security Class Initialized
DEBUG - 2016-02-26 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:41:18 --> Input Class Initialized
INFO - 2016-02-26 06:41:18 --> Language Class Initialized
INFO - 2016-02-26 06:41:18 --> Loader Class Initialized
INFO - 2016-02-26 06:41:18 --> Helper loaded: url_helper
INFO - 2016-02-26 06:41:18 --> Helper loaded: file_helper
INFO - 2016-02-26 06:41:18 --> Helper loaded: date_helper
INFO - 2016-02-26 06:41:18 --> Helper loaded: form_helper
INFO - 2016-02-26 06:41:18 --> Database Driver Class Initialized
INFO - 2016-02-26 06:41:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:41:19 --> Controller Class Initialized
INFO - 2016-02-26 06:41:19 --> Model Class Initialized
INFO - 2016-02-26 06:41:19 --> Model Class Initialized
INFO - 2016-02-26 06:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:41:19 --> Pagination Class Initialized
INFO - 2016-02-26 06:41:19 --> Helper loaded: text_helper
INFO - 2016-02-26 06:41:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:41:19 --> Final output sent to browser
DEBUG - 2016-02-26 09:41:19 --> Total execution time: 1.1796
INFO - 2016-02-26 06:58:16 --> Config Class Initialized
INFO - 2016-02-26 06:58:16 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:58:16 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:58:16 --> Utf8 Class Initialized
INFO - 2016-02-26 06:58:16 --> URI Class Initialized
INFO - 2016-02-26 06:58:16 --> Router Class Initialized
INFO - 2016-02-26 06:58:16 --> Output Class Initialized
INFO - 2016-02-26 06:58:16 --> Security Class Initialized
DEBUG - 2016-02-26 06:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:58:16 --> Input Class Initialized
INFO - 2016-02-26 06:58:16 --> Language Class Initialized
INFO - 2016-02-26 06:58:16 --> Loader Class Initialized
INFO - 2016-02-26 06:58:16 --> Helper loaded: url_helper
INFO - 2016-02-26 06:58:16 --> Helper loaded: file_helper
INFO - 2016-02-26 06:58:16 --> Helper loaded: date_helper
INFO - 2016-02-26 06:58:16 --> Helper loaded: form_helper
INFO - 2016-02-26 06:58:16 --> Database Driver Class Initialized
INFO - 2016-02-26 06:58:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:58:17 --> Controller Class Initialized
INFO - 2016-02-26 06:58:17 --> Model Class Initialized
INFO - 2016-02-26 06:58:17 --> Model Class Initialized
INFO - 2016-02-26 06:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:58:17 --> Pagination Class Initialized
INFO - 2016-02-26 06:58:17 --> Helper loaded: text_helper
INFO - 2016-02-26 06:58:17 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:58:17 --> Final output sent to browser
DEBUG - 2016-02-26 09:58:17 --> Total execution time: 1.2211
INFO - 2016-02-26 06:58:22 --> Config Class Initialized
INFO - 2016-02-26 06:58:22 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:58:22 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:58:22 --> Utf8 Class Initialized
INFO - 2016-02-26 06:58:22 --> URI Class Initialized
INFO - 2016-02-26 06:58:22 --> Router Class Initialized
INFO - 2016-02-26 06:58:22 --> Output Class Initialized
INFO - 2016-02-26 06:58:22 --> Security Class Initialized
DEBUG - 2016-02-26 06:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:58:22 --> Input Class Initialized
INFO - 2016-02-26 06:58:22 --> Language Class Initialized
INFO - 2016-02-26 06:58:22 --> Loader Class Initialized
INFO - 2016-02-26 06:58:22 --> Helper loaded: url_helper
INFO - 2016-02-26 06:58:22 --> Helper loaded: file_helper
INFO - 2016-02-26 06:58:22 --> Helper loaded: date_helper
INFO - 2016-02-26 06:58:22 --> Helper loaded: form_helper
INFO - 2016-02-26 06:58:22 --> Database Driver Class Initialized
INFO - 2016-02-26 06:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:58:23 --> Controller Class Initialized
INFO - 2016-02-26 06:58:23 --> Model Class Initialized
INFO - 2016-02-26 06:58:23 --> Model Class Initialized
INFO - 2016-02-26 06:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:58:23 --> Pagination Class Initialized
INFO - 2016-02-26 06:58:23 --> Helper loaded: text_helper
INFO - 2016-02-26 06:58:23 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 09:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:58:23 --> Final output sent to browser
DEBUG - 2016-02-26 09:58:23 --> Total execution time: 1.1578
INFO - 2016-02-26 06:58:27 --> Config Class Initialized
INFO - 2016-02-26 06:58:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:58:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:58:27 --> Utf8 Class Initialized
INFO - 2016-02-26 06:58:27 --> URI Class Initialized
INFO - 2016-02-26 06:58:27 --> Router Class Initialized
INFO - 2016-02-26 06:58:27 --> Output Class Initialized
INFO - 2016-02-26 06:58:27 --> Security Class Initialized
DEBUG - 2016-02-26 06:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:58:27 --> Input Class Initialized
INFO - 2016-02-26 06:58:27 --> Language Class Initialized
INFO - 2016-02-26 06:58:27 --> Loader Class Initialized
INFO - 2016-02-26 06:58:27 --> Helper loaded: url_helper
INFO - 2016-02-26 06:58:27 --> Helper loaded: file_helper
INFO - 2016-02-26 06:58:27 --> Helper loaded: date_helper
INFO - 2016-02-26 06:58:27 --> Helper loaded: form_helper
INFO - 2016-02-26 06:58:27 --> Database Driver Class Initialized
INFO - 2016-02-26 06:58:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:58:28 --> Controller Class Initialized
INFO - 2016-02-26 06:58:28 --> Model Class Initialized
INFO - 2016-02-26 06:58:28 --> Model Class Initialized
INFO - 2016-02-26 06:58:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:58:28 --> Pagination Class Initialized
INFO - 2016-02-26 06:58:28 --> Helper loaded: text_helper
INFO - 2016-02-26 06:58:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:58:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:58:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:58:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:58:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:58:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:58:28 --> Final output sent to browser
DEBUG - 2016-02-26 09:58:28 --> Total execution time: 1.1592
INFO - 2016-02-26 06:58:52 --> Config Class Initialized
INFO - 2016-02-26 06:58:52 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:58:52 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:58:52 --> Utf8 Class Initialized
INFO - 2016-02-26 06:58:52 --> URI Class Initialized
INFO - 2016-02-26 06:58:52 --> Router Class Initialized
INFO - 2016-02-26 06:58:52 --> Output Class Initialized
INFO - 2016-02-26 06:58:52 --> Security Class Initialized
DEBUG - 2016-02-26 06:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:58:52 --> Input Class Initialized
INFO - 2016-02-26 06:58:52 --> Language Class Initialized
INFO - 2016-02-26 06:58:52 --> Loader Class Initialized
INFO - 2016-02-26 06:58:52 --> Helper loaded: url_helper
INFO - 2016-02-26 06:58:52 --> Helper loaded: file_helper
INFO - 2016-02-26 06:58:52 --> Helper loaded: date_helper
INFO - 2016-02-26 06:58:52 --> Helper loaded: form_helper
INFO - 2016-02-26 06:58:52 --> Database Driver Class Initialized
INFO - 2016-02-26 06:58:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:58:53 --> Controller Class Initialized
INFO - 2016-02-26 06:58:53 --> Model Class Initialized
INFO - 2016-02-26 06:58:53 --> Model Class Initialized
INFO - 2016-02-26 06:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:58:53 --> Pagination Class Initialized
INFO - 2016-02-26 06:58:53 --> Helper loaded: text_helper
INFO - 2016-02-26 06:58:53 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:58:53 --> Final output sent to browser
DEBUG - 2016-02-26 09:58:53 --> Total execution time: 1.1774
INFO - 2016-02-26 06:59:43 --> Config Class Initialized
INFO - 2016-02-26 06:59:43 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:59:43 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:59:43 --> Utf8 Class Initialized
INFO - 2016-02-26 06:59:43 --> URI Class Initialized
INFO - 2016-02-26 06:59:43 --> Router Class Initialized
INFO - 2016-02-26 06:59:43 --> Output Class Initialized
INFO - 2016-02-26 06:59:43 --> Security Class Initialized
DEBUG - 2016-02-26 06:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:59:43 --> Input Class Initialized
INFO - 2016-02-26 06:59:43 --> Language Class Initialized
INFO - 2016-02-26 06:59:43 --> Loader Class Initialized
INFO - 2016-02-26 06:59:43 --> Helper loaded: url_helper
INFO - 2016-02-26 06:59:43 --> Helper loaded: file_helper
INFO - 2016-02-26 06:59:43 --> Helper loaded: date_helper
INFO - 2016-02-26 06:59:43 --> Helper loaded: form_helper
INFO - 2016-02-26 06:59:43 --> Database Driver Class Initialized
INFO - 2016-02-26 06:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:59:44 --> Controller Class Initialized
INFO - 2016-02-26 06:59:44 --> Model Class Initialized
INFO - 2016-02-26 06:59:44 --> Model Class Initialized
INFO - 2016-02-26 06:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:59:44 --> Pagination Class Initialized
INFO - 2016-02-26 06:59:44 --> Helper loaded: text_helper
INFO - 2016-02-26 06:59:44 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:59:44 --> Final output sent to browser
DEBUG - 2016-02-26 09:59:44 --> Total execution time: 1.1521
INFO - 2016-02-26 06:59:46 --> Config Class Initialized
INFO - 2016-02-26 06:59:46 --> Hooks Class Initialized
DEBUG - 2016-02-26 06:59:46 --> UTF-8 Support Enabled
INFO - 2016-02-26 06:59:46 --> Utf8 Class Initialized
INFO - 2016-02-26 06:59:46 --> URI Class Initialized
INFO - 2016-02-26 06:59:46 --> Router Class Initialized
INFO - 2016-02-26 06:59:46 --> Output Class Initialized
INFO - 2016-02-26 06:59:46 --> Security Class Initialized
DEBUG - 2016-02-26 06:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 06:59:46 --> Input Class Initialized
INFO - 2016-02-26 06:59:46 --> Language Class Initialized
INFO - 2016-02-26 06:59:46 --> Loader Class Initialized
INFO - 2016-02-26 06:59:46 --> Helper loaded: url_helper
INFO - 2016-02-26 06:59:46 --> Helper loaded: file_helper
INFO - 2016-02-26 06:59:46 --> Helper loaded: date_helper
INFO - 2016-02-26 06:59:46 --> Helper loaded: form_helper
INFO - 2016-02-26 06:59:46 --> Database Driver Class Initialized
INFO - 2016-02-26 06:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 06:59:47 --> Controller Class Initialized
INFO - 2016-02-26 06:59:47 --> Model Class Initialized
INFO - 2016-02-26 06:59:47 --> Model Class Initialized
INFO - 2016-02-26 06:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 06:59:47 --> Pagination Class Initialized
INFO - 2016-02-26 06:59:47 --> Helper loaded: text_helper
INFO - 2016-02-26 06:59:47 --> Helper loaded: cookie_helper
INFO - 2016-02-26 09:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 09:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 09:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 09:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 09:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 09:59:47 --> Final output sent to browser
DEBUG - 2016-02-26 09:59:47 --> Total execution time: 1.1818
INFO - 2016-02-26 07:02:53 --> Config Class Initialized
INFO - 2016-02-26 07:02:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:02:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:02:53 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:53 --> URI Class Initialized
INFO - 2016-02-26 07:02:53 --> Router Class Initialized
INFO - 2016-02-26 07:02:53 --> Output Class Initialized
INFO - 2016-02-26 07:02:53 --> Security Class Initialized
DEBUG - 2016-02-26 07:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:02:53 --> Input Class Initialized
INFO - 2016-02-26 07:02:53 --> Language Class Initialized
INFO - 2016-02-26 07:02:53 --> Loader Class Initialized
INFO - 2016-02-26 07:02:53 --> Helper loaded: url_helper
INFO - 2016-02-26 07:02:53 --> Helper loaded: file_helper
INFO - 2016-02-26 07:02:53 --> Helper loaded: date_helper
INFO - 2016-02-26 07:02:53 --> Helper loaded: form_helper
INFO - 2016-02-26 07:02:53 --> Database Driver Class Initialized
INFO - 2016-02-26 07:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:02:54 --> Controller Class Initialized
INFO - 2016-02-26 07:02:54 --> Model Class Initialized
INFO - 2016-02-26 07:02:54 --> Model Class Initialized
INFO - 2016-02-26 07:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:02:54 --> Pagination Class Initialized
INFO - 2016-02-26 07:02:54 --> Helper loaded: text_helper
INFO - 2016-02-26 07:02:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:02:54 --> Final output sent to browser
DEBUG - 2016-02-26 10:02:54 --> Total execution time: 1.1404
INFO - 2016-02-26 07:02:54 --> Config Class Initialized
INFO - 2016-02-26 07:02:54 --> Hooks Class Initialized
INFO - 2016-02-26 07:02:54 --> Config Class Initialized
INFO - 2016-02-26 07:02:54 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:02:54 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:02:54 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:54 --> URI Class Initialized
DEBUG - 2016-02-26 07:02:54 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:02:54 --> Router Class Initialized
INFO - 2016-02-26 07:02:54 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:54 --> URI Class Initialized
INFO - 2016-02-26 07:02:54 --> Output Class Initialized
INFO - 2016-02-26 07:02:54 --> Router Class Initialized
INFO - 2016-02-26 07:02:54 --> Security Class Initialized
INFO - 2016-02-26 07:02:54 --> Output Class Initialized
DEBUG - 2016-02-26 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:02:54 --> Security Class Initialized
INFO - 2016-02-26 07:02:54 --> Input Class Initialized
INFO - 2016-02-26 07:02:54 --> Language Class Initialized
DEBUG - 2016-02-26 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:02:54 --> Input Class Initialized
INFO - 2016-02-26 07:02:54 --> Language Class Initialized
ERROR - 2016-02-26 07:02:54 --> 404 Page Not Found: Static/dist
ERROR - 2016-02-26 07:02:54 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:02:57 --> Config Class Initialized
INFO - 2016-02-26 07:02:57 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:02:57 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:02:57 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:57 --> URI Class Initialized
INFO - 2016-02-26 07:02:57 --> Router Class Initialized
INFO - 2016-02-26 07:02:57 --> Output Class Initialized
INFO - 2016-02-26 07:02:57 --> Security Class Initialized
DEBUG - 2016-02-26 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:02:57 --> Input Class Initialized
INFO - 2016-02-26 07:02:57 --> Language Class Initialized
INFO - 2016-02-26 07:02:57 --> Loader Class Initialized
INFO - 2016-02-26 07:02:57 --> Helper loaded: url_helper
INFO - 2016-02-26 07:02:57 --> Helper loaded: file_helper
INFO - 2016-02-26 07:02:57 --> Helper loaded: date_helper
INFO - 2016-02-26 07:02:57 --> Helper loaded: form_helper
INFO - 2016-02-26 07:02:57 --> Database Driver Class Initialized
INFO - 2016-02-26 07:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:02:58 --> Controller Class Initialized
INFO - 2016-02-26 07:02:58 --> Model Class Initialized
INFO - 2016-02-26 07:02:58 --> Model Class Initialized
INFO - 2016-02-26 07:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:02:58 --> Pagination Class Initialized
INFO - 2016-02-26 07:02:58 --> Helper loaded: text_helper
INFO - 2016-02-26 07:02:58 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:02:58 --> Final output sent to browser
DEBUG - 2016-02-26 10:02:58 --> Total execution time: 1.1429
INFO - 2016-02-26 07:02:58 --> Config Class Initialized
INFO - 2016-02-26 07:02:58 --> Config Class Initialized
INFO - 2016-02-26 07:02:58 --> Hooks Class Initialized
INFO - 2016-02-26 07:02:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:02:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-26 07:02:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:02:58 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:58 --> Utf8 Class Initialized
INFO - 2016-02-26 07:02:58 --> URI Class Initialized
INFO - 2016-02-26 07:02:58 --> URI Class Initialized
INFO - 2016-02-26 07:02:58 --> Router Class Initialized
INFO - 2016-02-26 07:02:58 --> Router Class Initialized
INFO - 2016-02-26 07:02:58 --> Output Class Initialized
INFO - 2016-02-26 07:02:58 --> Output Class Initialized
INFO - 2016-02-26 07:02:58 --> Security Class Initialized
INFO - 2016-02-26 07:02:58 --> Security Class Initialized
DEBUG - 2016-02-26 07:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-02-26 07:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:02:58 --> Input Class Initialized
INFO - 2016-02-26 07:02:58 --> Input Class Initialized
INFO - 2016-02-26 07:02:58 --> Language Class Initialized
INFO - 2016-02-26 07:02:58 --> Language Class Initialized
ERROR - 2016-02-26 07:02:58 --> 404 Page Not Found: Static/dist
ERROR - 2016-02-26 07:02:58 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:06:23 --> Config Class Initialized
INFO - 2016-02-26 07:06:23 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:06:23 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:06:23 --> Utf8 Class Initialized
INFO - 2016-02-26 07:06:23 --> URI Class Initialized
INFO - 2016-02-26 07:06:23 --> Router Class Initialized
INFO - 2016-02-26 07:06:23 --> Output Class Initialized
INFO - 2016-02-26 07:06:23 --> Security Class Initialized
DEBUG - 2016-02-26 07:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:06:23 --> Input Class Initialized
INFO - 2016-02-26 07:06:23 --> Language Class Initialized
INFO - 2016-02-26 07:06:23 --> Loader Class Initialized
INFO - 2016-02-26 07:06:23 --> Helper loaded: url_helper
INFO - 2016-02-26 07:06:23 --> Helper loaded: file_helper
INFO - 2016-02-26 07:06:23 --> Helper loaded: date_helper
INFO - 2016-02-26 07:06:23 --> Helper loaded: form_helper
INFO - 2016-02-26 07:06:23 --> Database Driver Class Initialized
INFO - 2016-02-26 07:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:06:24 --> Controller Class Initialized
INFO - 2016-02-26 07:06:24 --> Model Class Initialized
INFO - 2016-02-26 07:06:24 --> Model Class Initialized
INFO - 2016-02-26 07:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:06:24 --> Pagination Class Initialized
INFO - 2016-02-26 07:06:24 --> Helper loaded: text_helper
INFO - 2016-02-26 07:06:24 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:06:24 --> Final output sent to browser
DEBUG - 2016-02-26 10:06:24 --> Total execution time: 1.1427
INFO - 2016-02-26 07:06:24 --> Config Class Initialized
INFO - 2016-02-26 07:06:24 --> Hooks Class Initialized
INFO - 2016-02-26 07:06:24 --> Config Class Initialized
INFO - 2016-02-26 07:06:24 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:06:24 --> UTF-8 Support Enabled
DEBUG - 2016-02-26 07:06:24 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:06:24 --> Utf8 Class Initialized
INFO - 2016-02-26 07:06:24 --> Utf8 Class Initialized
INFO - 2016-02-26 07:06:24 --> URI Class Initialized
INFO - 2016-02-26 07:06:24 --> URI Class Initialized
INFO - 2016-02-26 07:06:24 --> Router Class Initialized
INFO - 2016-02-26 07:06:24 --> Router Class Initialized
INFO - 2016-02-26 07:06:24 --> Output Class Initialized
INFO - 2016-02-26 07:06:24 --> Output Class Initialized
INFO - 2016-02-26 07:06:24 --> Security Class Initialized
INFO - 2016-02-26 07:06:24 --> Security Class Initialized
DEBUG - 2016-02-26 07:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-02-26 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:06:24 --> Input Class Initialized
INFO - 2016-02-26 07:06:24 --> Input Class Initialized
INFO - 2016-02-26 07:06:24 --> Language Class Initialized
INFO - 2016-02-26 07:06:24 --> Language Class Initialized
ERROR - 2016-02-26 07:06:24 --> 404 Page Not Found: Static/dist
ERROR - 2016-02-26 07:06:24 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:07:53 --> Config Class Initialized
INFO - 2016-02-26 07:07:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:07:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:07:53 --> Utf8 Class Initialized
INFO - 2016-02-26 07:07:53 --> URI Class Initialized
INFO - 2016-02-26 07:07:53 --> Router Class Initialized
INFO - 2016-02-26 07:07:53 --> Output Class Initialized
INFO - 2016-02-26 07:07:53 --> Security Class Initialized
DEBUG - 2016-02-26 07:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:07:53 --> Input Class Initialized
INFO - 2016-02-26 07:07:53 --> Language Class Initialized
INFO - 2016-02-26 07:07:53 --> Loader Class Initialized
INFO - 2016-02-26 07:07:53 --> Helper loaded: url_helper
INFO - 2016-02-26 07:07:53 --> Helper loaded: file_helper
INFO - 2016-02-26 07:07:53 --> Helper loaded: date_helper
INFO - 2016-02-26 07:07:53 --> Helper loaded: form_helper
INFO - 2016-02-26 07:07:53 --> Database Driver Class Initialized
INFO - 2016-02-26 07:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:07:54 --> Controller Class Initialized
INFO - 2016-02-26 07:07:54 --> Model Class Initialized
INFO - 2016-02-26 07:07:54 --> Model Class Initialized
INFO - 2016-02-26 07:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:07:54 --> Pagination Class Initialized
INFO - 2016-02-26 07:07:54 --> Helper loaded: text_helper
INFO - 2016-02-26 07:07:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:07:54 --> Final output sent to browser
DEBUG - 2016-02-26 10:07:54 --> Total execution time: 1.1555
INFO - 2016-02-26 07:07:54 --> Config Class Initialized
INFO - 2016-02-26 07:07:54 --> Config Class Initialized
INFO - 2016-02-26 07:07:54 --> Hooks Class Initialized
INFO - 2016-02-26 07:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:07:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-26 07:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:07:54 --> Utf8 Class Initialized
INFO - 2016-02-26 07:07:54 --> Utf8 Class Initialized
INFO - 2016-02-26 07:07:54 --> URI Class Initialized
INFO - 2016-02-26 07:07:54 --> URI Class Initialized
INFO - 2016-02-26 07:07:54 --> Router Class Initialized
INFO - 2016-02-26 07:07:54 --> Router Class Initialized
INFO - 2016-02-26 07:07:54 --> Output Class Initialized
INFO - 2016-02-26 07:07:54 --> Output Class Initialized
INFO - 2016-02-26 07:07:54 --> Security Class Initialized
INFO - 2016-02-26 07:07:54 --> Security Class Initialized
DEBUG - 2016-02-26 07:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-02-26 07:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:07:54 --> Input Class Initialized
INFO - 2016-02-26 07:07:54 --> Input Class Initialized
INFO - 2016-02-26 07:07:54 --> Language Class Initialized
INFO - 2016-02-26 07:07:54 --> Language Class Initialized
ERROR - 2016-02-26 07:07:54 --> 404 Page Not Found: Static/dist
ERROR - 2016-02-26 07:07:54 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:08:07 --> Config Class Initialized
INFO - 2016-02-26 07:08:07 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:08:07 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:08:07 --> Utf8 Class Initialized
INFO - 2016-02-26 07:08:07 --> URI Class Initialized
INFO - 2016-02-26 07:08:07 --> Router Class Initialized
INFO - 2016-02-26 07:08:07 --> Output Class Initialized
INFO - 2016-02-26 07:08:07 --> Security Class Initialized
DEBUG - 2016-02-26 07:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:08:07 --> Input Class Initialized
INFO - 2016-02-26 07:08:07 --> Language Class Initialized
INFO - 2016-02-26 07:08:07 --> Loader Class Initialized
INFO - 2016-02-26 07:08:07 --> Helper loaded: url_helper
INFO - 2016-02-26 07:08:07 --> Helper loaded: file_helper
INFO - 2016-02-26 07:08:07 --> Helper loaded: date_helper
INFO - 2016-02-26 07:08:07 --> Helper loaded: form_helper
INFO - 2016-02-26 07:08:07 --> Database Driver Class Initialized
INFO - 2016-02-26 07:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:08:08 --> Controller Class Initialized
INFO - 2016-02-26 07:08:08 --> Model Class Initialized
INFO - 2016-02-26 07:08:08 --> Model Class Initialized
INFO - 2016-02-26 07:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:08:08 --> Pagination Class Initialized
INFO - 2016-02-26 07:08:08 --> Helper loaded: text_helper
INFO - 2016-02-26 07:08:08 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:08:08 --> Final output sent to browser
DEBUG - 2016-02-26 10:08:08 --> Total execution time: 1.1355
INFO - 2016-02-26 07:08:08 --> Config Class Initialized
INFO - 2016-02-26 07:08:08 --> Hooks Class Initialized
INFO - 2016-02-26 07:08:08 --> Config Class Initialized
INFO - 2016-02-26 07:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-26 07:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:08:08 --> Utf8 Class Initialized
INFO - 2016-02-26 07:08:08 --> Utf8 Class Initialized
INFO - 2016-02-26 07:08:08 --> URI Class Initialized
INFO - 2016-02-26 07:08:08 --> URI Class Initialized
INFO - 2016-02-26 07:08:08 --> Router Class Initialized
INFO - 2016-02-26 07:08:08 --> Router Class Initialized
INFO - 2016-02-26 07:08:08 --> Output Class Initialized
INFO - 2016-02-26 07:08:08 --> Security Class Initialized
INFO - 2016-02-26 07:08:08 --> Output Class Initialized
DEBUG - 2016-02-26 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:08:08 --> Security Class Initialized
INFO - 2016-02-26 07:08:08 --> Input Class Initialized
INFO - 2016-02-26 07:08:08 --> Language Class Initialized
DEBUG - 2016-02-26 07:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-02-26 07:08:08 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:08:08 --> Input Class Initialized
INFO - 2016-02-26 07:08:08 --> Language Class Initialized
ERROR - 2016-02-26 07:08:08 --> 404 Page Not Found: Static/dist
INFO - 2016-02-26 07:12:13 --> Config Class Initialized
INFO - 2016-02-26 07:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:12:13 --> Utf8 Class Initialized
INFO - 2016-02-26 07:12:13 --> URI Class Initialized
INFO - 2016-02-26 07:12:13 --> Router Class Initialized
INFO - 2016-02-26 07:12:13 --> Output Class Initialized
INFO - 2016-02-26 07:12:14 --> Security Class Initialized
DEBUG - 2016-02-26 07:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:12:14 --> Input Class Initialized
INFO - 2016-02-26 07:12:14 --> Language Class Initialized
INFO - 2016-02-26 07:12:14 --> Loader Class Initialized
INFO - 2016-02-26 07:12:14 --> Helper loaded: url_helper
INFO - 2016-02-26 07:12:14 --> Helper loaded: file_helper
INFO - 2016-02-26 07:12:14 --> Helper loaded: date_helper
INFO - 2016-02-26 07:12:14 --> Helper loaded: form_helper
INFO - 2016-02-26 07:12:14 --> Database Driver Class Initialized
INFO - 2016-02-26 07:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:12:15 --> Controller Class Initialized
INFO - 2016-02-26 07:12:15 --> Model Class Initialized
INFO - 2016-02-26 07:12:15 --> Model Class Initialized
INFO - 2016-02-26 07:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:12:15 --> Pagination Class Initialized
INFO - 2016-02-26 07:12:15 --> Helper loaded: text_helper
INFO - 2016-02-26 07:12:15 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:12:15 --> Final output sent to browser
DEBUG - 2016-02-26 10:12:15 --> Total execution time: 1.1607
INFO - 2016-02-26 07:12:19 --> Config Class Initialized
INFO - 2016-02-26 07:12:19 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:12:19 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:12:19 --> Utf8 Class Initialized
INFO - 2016-02-26 07:12:19 --> URI Class Initialized
INFO - 2016-02-26 07:12:19 --> Router Class Initialized
INFO - 2016-02-26 07:12:19 --> Output Class Initialized
INFO - 2016-02-26 07:12:19 --> Security Class Initialized
DEBUG - 2016-02-26 07:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:12:19 --> Input Class Initialized
INFO - 2016-02-26 07:12:19 --> Language Class Initialized
INFO - 2016-02-26 07:12:19 --> Loader Class Initialized
INFO - 2016-02-26 07:12:19 --> Helper loaded: url_helper
INFO - 2016-02-26 07:12:19 --> Helper loaded: file_helper
INFO - 2016-02-26 07:12:19 --> Helper loaded: date_helper
INFO - 2016-02-26 07:12:19 --> Helper loaded: form_helper
INFO - 2016-02-26 07:12:19 --> Database Driver Class Initialized
INFO - 2016-02-26 07:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:12:20 --> Controller Class Initialized
INFO - 2016-02-26 07:12:20 --> Model Class Initialized
INFO - 2016-02-26 07:12:20 --> Model Class Initialized
INFO - 2016-02-26 07:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:12:20 --> Pagination Class Initialized
INFO - 2016-02-26 07:12:20 --> Helper loaded: text_helper
INFO - 2016-02-26 07:12:20 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:12:20 --> Final output sent to browser
DEBUG - 2016-02-26 10:12:20 --> Total execution time: 1.1697
INFO - 2016-02-26 07:13:18 --> Config Class Initialized
INFO - 2016-02-26 07:13:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:13:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:13:18 --> Utf8 Class Initialized
INFO - 2016-02-26 07:13:18 --> URI Class Initialized
INFO - 2016-02-26 07:13:18 --> Router Class Initialized
INFO - 2016-02-26 07:13:18 --> Output Class Initialized
INFO - 2016-02-26 07:13:18 --> Security Class Initialized
DEBUG - 2016-02-26 07:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:13:18 --> Input Class Initialized
INFO - 2016-02-26 07:13:18 --> Language Class Initialized
INFO - 2016-02-26 07:13:18 --> Loader Class Initialized
INFO - 2016-02-26 07:13:18 --> Helper loaded: url_helper
INFO - 2016-02-26 07:13:18 --> Helper loaded: file_helper
INFO - 2016-02-26 07:13:18 --> Helper loaded: date_helper
INFO - 2016-02-26 07:13:18 --> Helper loaded: form_helper
INFO - 2016-02-26 07:13:18 --> Database Driver Class Initialized
INFO - 2016-02-26 07:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:13:19 --> Controller Class Initialized
INFO - 2016-02-26 07:13:19 --> Model Class Initialized
INFO - 2016-02-26 07:13:19 --> Model Class Initialized
INFO - 2016-02-26 07:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:13:19 --> Pagination Class Initialized
INFO - 2016-02-26 07:13:19 --> Helper loaded: text_helper
INFO - 2016-02-26 07:13:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:13:19 --> Final output sent to browser
DEBUG - 2016-02-26 10:13:19 --> Total execution time: 1.1732
INFO - 2016-02-26 07:14:26 --> Config Class Initialized
INFO - 2016-02-26 07:14:26 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:14:26 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:14:26 --> Utf8 Class Initialized
INFO - 2016-02-26 07:14:26 --> URI Class Initialized
INFO - 2016-02-26 07:14:26 --> Router Class Initialized
INFO - 2016-02-26 07:14:26 --> Output Class Initialized
INFO - 2016-02-26 07:14:26 --> Security Class Initialized
DEBUG - 2016-02-26 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:14:26 --> Input Class Initialized
INFO - 2016-02-26 07:14:26 --> Language Class Initialized
INFO - 2016-02-26 07:14:26 --> Loader Class Initialized
INFO - 2016-02-26 07:14:26 --> Helper loaded: url_helper
INFO - 2016-02-26 07:14:26 --> Helper loaded: file_helper
INFO - 2016-02-26 07:14:26 --> Helper loaded: date_helper
INFO - 2016-02-26 07:14:26 --> Helper loaded: form_helper
INFO - 2016-02-26 07:14:26 --> Database Driver Class Initialized
INFO - 2016-02-26 07:14:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:14:27 --> Controller Class Initialized
INFO - 2016-02-26 07:14:27 --> Model Class Initialized
INFO - 2016-02-26 07:14:27 --> Model Class Initialized
INFO - 2016-02-26 07:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:14:27 --> Pagination Class Initialized
INFO - 2016-02-26 07:14:27 --> Helper loaded: text_helper
INFO - 2016-02-26 07:14:27 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:14:27 --> Final output sent to browser
DEBUG - 2016-02-26 10:14:27 --> Total execution time: 1.1551
INFO - 2016-02-26 07:16:45 --> Config Class Initialized
INFO - 2016-02-26 07:16:45 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:16:45 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:16:45 --> Utf8 Class Initialized
INFO - 2016-02-26 07:16:45 --> URI Class Initialized
INFO - 2016-02-26 07:16:45 --> Router Class Initialized
INFO - 2016-02-26 07:16:45 --> Output Class Initialized
INFO - 2016-02-26 07:16:45 --> Security Class Initialized
DEBUG - 2016-02-26 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:16:45 --> Input Class Initialized
INFO - 2016-02-26 07:16:45 --> Language Class Initialized
INFO - 2016-02-26 07:16:45 --> Loader Class Initialized
INFO - 2016-02-26 07:16:45 --> Helper loaded: url_helper
INFO - 2016-02-26 07:16:45 --> Helper loaded: file_helper
INFO - 2016-02-26 07:16:45 --> Helper loaded: date_helper
INFO - 2016-02-26 07:16:45 --> Helper loaded: form_helper
INFO - 2016-02-26 07:16:45 --> Database Driver Class Initialized
INFO - 2016-02-26 07:16:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:16:46 --> Controller Class Initialized
INFO - 2016-02-26 07:16:46 --> Model Class Initialized
INFO - 2016-02-26 07:16:46 --> Model Class Initialized
INFO - 2016-02-26 07:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:16:46 --> Pagination Class Initialized
INFO - 2016-02-26 07:16:46 --> Helper loaded: text_helper
INFO - 2016-02-26 07:16:46 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:16:46 --> Final output sent to browser
DEBUG - 2016-02-26 10:16:46 --> Total execution time: 1.1522
INFO - 2016-02-26 07:17:08 --> Config Class Initialized
INFO - 2016-02-26 07:17:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:17:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:17:08 --> Utf8 Class Initialized
INFO - 2016-02-26 07:17:08 --> URI Class Initialized
INFO - 2016-02-26 07:17:08 --> Router Class Initialized
INFO - 2016-02-26 07:17:08 --> Output Class Initialized
INFO - 2016-02-26 07:17:08 --> Security Class Initialized
DEBUG - 2016-02-26 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:17:08 --> Input Class Initialized
INFO - 2016-02-26 07:17:08 --> Language Class Initialized
INFO - 2016-02-26 07:17:08 --> Loader Class Initialized
INFO - 2016-02-26 07:17:08 --> Helper loaded: url_helper
INFO - 2016-02-26 07:17:08 --> Helper loaded: file_helper
INFO - 2016-02-26 07:17:08 --> Helper loaded: date_helper
INFO - 2016-02-26 07:17:08 --> Helper loaded: form_helper
INFO - 2016-02-26 07:17:08 --> Database Driver Class Initialized
INFO - 2016-02-26 07:17:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:17:09 --> Controller Class Initialized
INFO - 2016-02-26 07:17:09 --> Model Class Initialized
INFO - 2016-02-26 07:17:09 --> Model Class Initialized
INFO - 2016-02-26 07:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:17:09 --> Pagination Class Initialized
INFO - 2016-02-26 07:17:09 --> Helper loaded: text_helper
INFO - 2016-02-26 07:17:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:17:09 --> Final output sent to browser
DEBUG - 2016-02-26 10:17:09 --> Total execution time: 1.1437
INFO - 2016-02-26 07:20:31 --> Config Class Initialized
INFO - 2016-02-26 07:20:31 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:20:31 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:20:31 --> Utf8 Class Initialized
INFO - 2016-02-26 07:20:31 --> URI Class Initialized
INFO - 2016-02-26 07:20:31 --> Router Class Initialized
INFO - 2016-02-26 07:20:31 --> Output Class Initialized
INFO - 2016-02-26 07:20:31 --> Security Class Initialized
DEBUG - 2016-02-26 07:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:20:31 --> Input Class Initialized
INFO - 2016-02-26 07:20:31 --> Language Class Initialized
INFO - 2016-02-26 07:20:31 --> Loader Class Initialized
INFO - 2016-02-26 07:20:31 --> Helper loaded: url_helper
INFO - 2016-02-26 07:20:31 --> Helper loaded: file_helper
INFO - 2016-02-26 07:20:31 --> Helper loaded: date_helper
INFO - 2016-02-26 07:20:31 --> Helper loaded: form_helper
INFO - 2016-02-26 07:20:31 --> Database Driver Class Initialized
INFO - 2016-02-26 07:20:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:20:32 --> Controller Class Initialized
INFO - 2016-02-26 07:20:32 --> Model Class Initialized
INFO - 2016-02-26 07:20:32 --> Model Class Initialized
INFO - 2016-02-26 07:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:20:32 --> Pagination Class Initialized
INFO - 2016-02-26 07:20:32 --> Helper loaded: text_helper
INFO - 2016-02-26 07:20:32 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:20:32 --> Final output sent to browser
DEBUG - 2016-02-26 10:20:32 --> Total execution time: 1.1255
INFO - 2016-02-26 07:21:34 --> Config Class Initialized
INFO - 2016-02-26 07:21:34 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:21:34 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:21:34 --> Utf8 Class Initialized
INFO - 2016-02-26 07:21:34 --> URI Class Initialized
INFO - 2016-02-26 07:21:34 --> Router Class Initialized
INFO - 2016-02-26 07:21:34 --> Output Class Initialized
INFO - 2016-02-26 07:21:34 --> Security Class Initialized
DEBUG - 2016-02-26 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:21:34 --> Input Class Initialized
INFO - 2016-02-26 07:21:34 --> Language Class Initialized
INFO - 2016-02-26 07:21:34 --> Loader Class Initialized
INFO - 2016-02-26 07:21:34 --> Helper loaded: url_helper
INFO - 2016-02-26 07:21:34 --> Helper loaded: file_helper
INFO - 2016-02-26 07:21:34 --> Helper loaded: date_helper
INFO - 2016-02-26 07:21:34 --> Helper loaded: form_helper
INFO - 2016-02-26 07:21:34 --> Database Driver Class Initialized
INFO - 2016-02-26 07:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:21:35 --> Controller Class Initialized
INFO - 2016-02-26 07:21:35 --> Model Class Initialized
INFO - 2016-02-26 07:21:35 --> Model Class Initialized
INFO - 2016-02-26 07:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:21:35 --> Pagination Class Initialized
INFO - 2016-02-26 07:21:35 --> Helper loaded: text_helper
INFO - 2016-02-26 07:21:35 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:21:35 --> Final output sent to browser
DEBUG - 2016-02-26 10:21:35 --> Total execution time: 1.1768
INFO - 2016-02-26 07:26:18 --> Config Class Initialized
INFO - 2016-02-26 07:26:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:26:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:26:18 --> Utf8 Class Initialized
INFO - 2016-02-26 07:26:18 --> URI Class Initialized
INFO - 2016-02-26 07:26:18 --> Router Class Initialized
INFO - 2016-02-26 07:26:18 --> Output Class Initialized
INFO - 2016-02-26 07:26:18 --> Security Class Initialized
DEBUG - 2016-02-26 07:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:26:18 --> Input Class Initialized
INFO - 2016-02-26 07:26:18 --> Language Class Initialized
INFO - 2016-02-26 07:26:18 --> Loader Class Initialized
INFO - 2016-02-26 07:26:18 --> Helper loaded: url_helper
INFO - 2016-02-26 07:26:18 --> Helper loaded: file_helper
INFO - 2016-02-26 07:26:18 --> Helper loaded: date_helper
INFO - 2016-02-26 07:26:18 --> Helper loaded: form_helper
INFO - 2016-02-26 07:26:18 --> Database Driver Class Initialized
INFO - 2016-02-26 07:26:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:26:19 --> Controller Class Initialized
INFO - 2016-02-26 07:26:19 --> Model Class Initialized
INFO - 2016-02-26 07:26:19 --> Model Class Initialized
INFO - 2016-02-26 07:26:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:26:19 --> Pagination Class Initialized
INFO - 2016-02-26 07:26:19 --> Helper loaded: text_helper
INFO - 2016-02-26 07:26:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:26:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:26:20 --> Final output sent to browser
DEBUG - 2016-02-26 10:26:20 --> Total execution time: 1.1724
INFO - 2016-02-26 07:31:59 --> Config Class Initialized
INFO - 2016-02-26 07:31:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:31:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:31:59 --> Utf8 Class Initialized
INFO - 2016-02-26 07:31:59 --> URI Class Initialized
INFO - 2016-02-26 07:31:59 --> Router Class Initialized
INFO - 2016-02-26 07:31:59 --> Output Class Initialized
INFO - 2016-02-26 07:31:59 --> Security Class Initialized
DEBUG - 2016-02-26 07:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:31:59 --> Input Class Initialized
INFO - 2016-02-26 07:31:59 --> Language Class Initialized
INFO - 2016-02-26 07:31:59 --> Loader Class Initialized
INFO - 2016-02-26 07:31:59 --> Helper loaded: url_helper
INFO - 2016-02-26 07:31:59 --> Helper loaded: file_helper
INFO - 2016-02-26 07:31:59 --> Helper loaded: date_helper
INFO - 2016-02-26 07:31:59 --> Helper loaded: form_helper
INFO - 2016-02-26 07:31:59 --> Database Driver Class Initialized
INFO - 2016-02-26 07:32:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:32:00 --> Controller Class Initialized
INFO - 2016-02-26 07:32:00 --> Model Class Initialized
INFO - 2016-02-26 07:32:00 --> Model Class Initialized
INFO - 2016-02-26 07:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:32:00 --> Pagination Class Initialized
INFO - 2016-02-26 07:32:00 --> Helper loaded: text_helper
INFO - 2016-02-26 07:32:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:32:00 --> Final output sent to browser
DEBUG - 2016-02-26 10:32:00 --> Total execution time: 1.1463
INFO - 2016-02-26 07:34:02 --> Config Class Initialized
INFO - 2016-02-26 07:34:02 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:34:02 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:34:02 --> Utf8 Class Initialized
INFO - 2016-02-26 07:34:02 --> URI Class Initialized
INFO - 2016-02-26 07:34:02 --> Router Class Initialized
INFO - 2016-02-26 07:34:02 --> Output Class Initialized
INFO - 2016-02-26 07:34:02 --> Security Class Initialized
DEBUG - 2016-02-26 07:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:34:02 --> Input Class Initialized
INFO - 2016-02-26 07:34:02 --> Language Class Initialized
INFO - 2016-02-26 07:34:02 --> Loader Class Initialized
INFO - 2016-02-26 07:34:02 --> Helper loaded: url_helper
INFO - 2016-02-26 07:34:02 --> Helper loaded: file_helper
INFO - 2016-02-26 07:34:02 --> Helper loaded: date_helper
INFO - 2016-02-26 07:34:02 --> Helper loaded: form_helper
INFO - 2016-02-26 07:34:02 --> Database Driver Class Initialized
INFO - 2016-02-26 07:34:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:34:03 --> Controller Class Initialized
INFO - 2016-02-26 07:34:03 --> Model Class Initialized
INFO - 2016-02-26 07:34:03 --> Model Class Initialized
INFO - 2016-02-26 07:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:34:03 --> Pagination Class Initialized
INFO - 2016-02-26 07:34:03 --> Helper loaded: text_helper
INFO - 2016-02-26 07:34:03 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:34:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:34:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:34:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:34:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:34:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:34:03 --> Final output sent to browser
DEBUG - 2016-02-26 10:34:03 --> Total execution time: 1.1243
INFO - 2016-02-26 07:34:50 --> Config Class Initialized
INFO - 2016-02-26 07:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:34:50 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:34:50 --> Utf8 Class Initialized
INFO - 2016-02-26 07:34:50 --> URI Class Initialized
INFO - 2016-02-26 07:34:50 --> Router Class Initialized
INFO - 2016-02-26 07:34:50 --> Output Class Initialized
INFO - 2016-02-26 07:34:50 --> Security Class Initialized
DEBUG - 2016-02-26 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:34:50 --> Input Class Initialized
INFO - 2016-02-26 07:34:50 --> Language Class Initialized
INFO - 2016-02-26 07:34:50 --> Loader Class Initialized
INFO - 2016-02-26 07:34:50 --> Helper loaded: url_helper
INFO - 2016-02-26 07:34:50 --> Helper loaded: file_helper
INFO - 2016-02-26 07:34:50 --> Helper loaded: date_helper
INFO - 2016-02-26 07:34:50 --> Helper loaded: form_helper
INFO - 2016-02-26 07:34:50 --> Database Driver Class Initialized
INFO - 2016-02-26 07:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:34:51 --> Controller Class Initialized
INFO - 2016-02-26 07:34:51 --> Model Class Initialized
INFO - 2016-02-26 07:34:51 --> Model Class Initialized
INFO - 2016-02-26 07:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:34:51 --> Pagination Class Initialized
INFO - 2016-02-26 07:34:51 --> Helper loaded: text_helper
INFO - 2016-02-26 07:34:51 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:34:51 --> Final output sent to browser
DEBUG - 2016-02-26 10:34:51 --> Total execution time: 1.1586
INFO - 2016-02-26 07:36:36 --> Config Class Initialized
INFO - 2016-02-26 07:36:36 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:36:36 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:36:36 --> Utf8 Class Initialized
INFO - 2016-02-26 07:36:36 --> URI Class Initialized
INFO - 2016-02-26 07:36:36 --> Router Class Initialized
INFO - 2016-02-26 07:36:36 --> Output Class Initialized
INFO - 2016-02-26 07:36:36 --> Security Class Initialized
DEBUG - 2016-02-26 07:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:36:36 --> Input Class Initialized
INFO - 2016-02-26 07:36:36 --> Language Class Initialized
INFO - 2016-02-26 07:36:36 --> Loader Class Initialized
INFO - 2016-02-26 07:36:36 --> Helper loaded: url_helper
INFO - 2016-02-26 07:36:36 --> Helper loaded: file_helper
INFO - 2016-02-26 07:36:36 --> Helper loaded: date_helper
INFO - 2016-02-26 07:36:36 --> Helper loaded: form_helper
INFO - 2016-02-26 07:36:36 --> Database Driver Class Initialized
INFO - 2016-02-26 07:36:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:36:37 --> Controller Class Initialized
INFO - 2016-02-26 07:36:37 --> Model Class Initialized
INFO - 2016-02-26 07:36:37 --> Model Class Initialized
INFO - 2016-02-26 07:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:36:37 --> Pagination Class Initialized
INFO - 2016-02-26 07:36:37 --> Helper loaded: text_helper
INFO - 2016-02-26 07:36:37 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:36:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:36:37 --> Final output sent to browser
DEBUG - 2016-02-26 10:36:37 --> Total execution time: 1.1448
INFO - 2016-02-26 07:37:09 --> Config Class Initialized
INFO - 2016-02-26 07:37:09 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:37:10 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:37:10 --> Utf8 Class Initialized
INFO - 2016-02-26 07:37:10 --> URI Class Initialized
INFO - 2016-02-26 07:37:10 --> Router Class Initialized
INFO - 2016-02-26 07:37:10 --> Output Class Initialized
INFO - 2016-02-26 07:37:10 --> Security Class Initialized
DEBUG - 2016-02-26 07:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:37:10 --> Input Class Initialized
INFO - 2016-02-26 07:37:10 --> Language Class Initialized
INFO - 2016-02-26 07:37:10 --> Loader Class Initialized
INFO - 2016-02-26 07:37:10 --> Helper loaded: url_helper
INFO - 2016-02-26 07:37:10 --> Helper loaded: file_helper
INFO - 2016-02-26 07:37:10 --> Helper loaded: date_helper
INFO - 2016-02-26 07:37:10 --> Helper loaded: form_helper
INFO - 2016-02-26 07:37:10 --> Database Driver Class Initialized
INFO - 2016-02-26 07:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:37:11 --> Controller Class Initialized
INFO - 2016-02-26 07:37:11 --> Model Class Initialized
INFO - 2016-02-26 07:37:11 --> Model Class Initialized
INFO - 2016-02-26 07:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:37:11 --> Pagination Class Initialized
INFO - 2016-02-26 07:37:11 --> Helper loaded: text_helper
INFO - 2016-02-26 07:37:11 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:37:11 --> Final output sent to browser
DEBUG - 2016-02-26 10:37:11 --> Total execution time: 1.1736
INFO - 2016-02-26 07:37:33 --> Config Class Initialized
INFO - 2016-02-26 07:37:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:37:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:37:33 --> Utf8 Class Initialized
INFO - 2016-02-26 07:37:33 --> URI Class Initialized
INFO - 2016-02-26 07:37:33 --> Router Class Initialized
INFO - 2016-02-26 07:37:33 --> Output Class Initialized
INFO - 2016-02-26 07:37:33 --> Security Class Initialized
DEBUG - 2016-02-26 07:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:37:33 --> Input Class Initialized
INFO - 2016-02-26 07:37:33 --> Language Class Initialized
INFO - 2016-02-26 07:37:33 --> Loader Class Initialized
INFO - 2016-02-26 07:37:33 --> Helper loaded: url_helper
INFO - 2016-02-26 07:37:33 --> Helper loaded: file_helper
INFO - 2016-02-26 07:37:33 --> Helper loaded: date_helper
INFO - 2016-02-26 07:37:33 --> Helper loaded: form_helper
INFO - 2016-02-26 07:37:33 --> Database Driver Class Initialized
INFO - 2016-02-26 07:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:37:34 --> Controller Class Initialized
INFO - 2016-02-26 07:37:34 --> Model Class Initialized
INFO - 2016-02-26 07:37:34 --> Model Class Initialized
INFO - 2016-02-26 07:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:37:34 --> Pagination Class Initialized
INFO - 2016-02-26 07:37:34 --> Helper loaded: text_helper
INFO - 2016-02-26 07:37:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:37:34 --> Final output sent to browser
DEBUG - 2016-02-26 10:37:34 --> Total execution time: 1.1576
INFO - 2016-02-26 07:37:58 --> Config Class Initialized
INFO - 2016-02-26 07:37:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:37:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:37:58 --> Utf8 Class Initialized
INFO - 2016-02-26 07:37:58 --> URI Class Initialized
INFO - 2016-02-26 07:37:58 --> Router Class Initialized
INFO - 2016-02-26 07:37:58 --> Output Class Initialized
INFO - 2016-02-26 07:37:58 --> Security Class Initialized
DEBUG - 2016-02-26 07:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:37:58 --> Input Class Initialized
INFO - 2016-02-26 07:37:58 --> Language Class Initialized
INFO - 2016-02-26 07:37:58 --> Loader Class Initialized
INFO - 2016-02-26 07:37:58 --> Helper loaded: url_helper
INFO - 2016-02-26 07:37:58 --> Helper loaded: file_helper
INFO - 2016-02-26 07:37:58 --> Helper loaded: date_helper
INFO - 2016-02-26 07:37:58 --> Helper loaded: form_helper
INFO - 2016-02-26 07:37:58 --> Database Driver Class Initialized
INFO - 2016-02-26 07:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:38:00 --> Controller Class Initialized
INFO - 2016-02-26 07:38:00 --> Model Class Initialized
INFO - 2016-02-26 07:38:00 --> Model Class Initialized
INFO - 2016-02-26 07:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:38:00 --> Pagination Class Initialized
INFO - 2016-02-26 07:38:00 --> Helper loaded: text_helper
INFO - 2016-02-26 07:38:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:38:00 --> Final output sent to browser
DEBUG - 2016-02-26 10:38:00 --> Total execution time: 1.1442
INFO - 2016-02-26 07:40:29 --> Config Class Initialized
INFO - 2016-02-26 07:40:29 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:40:29 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:40:29 --> Utf8 Class Initialized
INFO - 2016-02-26 07:40:29 --> URI Class Initialized
INFO - 2016-02-26 07:40:29 --> Router Class Initialized
INFO - 2016-02-26 07:40:29 --> Output Class Initialized
INFO - 2016-02-26 07:40:29 --> Security Class Initialized
DEBUG - 2016-02-26 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:40:29 --> Input Class Initialized
INFO - 2016-02-26 07:40:29 --> Language Class Initialized
INFO - 2016-02-26 07:40:29 --> Loader Class Initialized
INFO - 2016-02-26 07:40:29 --> Helper loaded: url_helper
INFO - 2016-02-26 07:40:29 --> Helper loaded: file_helper
INFO - 2016-02-26 07:40:29 --> Helper loaded: date_helper
INFO - 2016-02-26 07:40:29 --> Helper loaded: form_helper
INFO - 2016-02-26 07:40:29 --> Database Driver Class Initialized
INFO - 2016-02-26 07:40:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:40:30 --> Controller Class Initialized
INFO - 2016-02-26 07:40:30 --> Model Class Initialized
INFO - 2016-02-26 07:40:30 --> Model Class Initialized
INFO - 2016-02-26 07:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:40:30 --> Pagination Class Initialized
INFO - 2016-02-26 07:40:30 --> Helper loaded: text_helper
INFO - 2016-02-26 07:40:30 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:40:30 --> Final output sent to browser
DEBUG - 2016-02-26 10:40:30 --> Total execution time: 1.1394
INFO - 2016-02-26 07:41:51 --> Config Class Initialized
INFO - 2016-02-26 07:41:51 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:41:51 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:41:51 --> Utf8 Class Initialized
INFO - 2016-02-26 07:41:51 --> URI Class Initialized
INFO - 2016-02-26 07:41:51 --> Router Class Initialized
INFO - 2016-02-26 07:41:51 --> Output Class Initialized
INFO - 2016-02-26 07:41:51 --> Security Class Initialized
DEBUG - 2016-02-26 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:41:51 --> Input Class Initialized
INFO - 2016-02-26 07:41:51 --> Language Class Initialized
INFO - 2016-02-26 07:41:51 --> Loader Class Initialized
INFO - 2016-02-26 07:41:51 --> Helper loaded: url_helper
INFO - 2016-02-26 07:41:51 --> Helper loaded: file_helper
INFO - 2016-02-26 07:41:51 --> Helper loaded: date_helper
INFO - 2016-02-26 07:41:51 --> Helper loaded: form_helper
INFO - 2016-02-26 07:41:51 --> Database Driver Class Initialized
INFO - 2016-02-26 07:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:41:52 --> Controller Class Initialized
INFO - 2016-02-26 07:41:52 --> Model Class Initialized
INFO - 2016-02-26 07:41:52 --> Model Class Initialized
INFO - 2016-02-26 07:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:41:52 --> Pagination Class Initialized
INFO - 2016-02-26 07:41:52 --> Helper loaded: text_helper
INFO - 2016-02-26 07:41:52 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:41:52 --> Final output sent to browser
DEBUG - 2016-02-26 10:41:52 --> Total execution time: 1.1448
INFO - 2016-02-26 07:41:55 --> Config Class Initialized
INFO - 2016-02-26 07:41:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:41:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:41:55 --> Utf8 Class Initialized
INFO - 2016-02-26 07:41:55 --> URI Class Initialized
INFO - 2016-02-26 07:41:55 --> Router Class Initialized
INFO - 2016-02-26 07:41:55 --> Output Class Initialized
INFO - 2016-02-26 07:41:55 --> Security Class Initialized
DEBUG - 2016-02-26 07:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:41:55 --> Input Class Initialized
INFO - 2016-02-26 07:41:55 --> Language Class Initialized
INFO - 2016-02-26 07:41:55 --> Loader Class Initialized
INFO - 2016-02-26 07:41:55 --> Helper loaded: url_helper
INFO - 2016-02-26 07:41:55 --> Helper loaded: file_helper
INFO - 2016-02-26 07:41:55 --> Helper loaded: date_helper
INFO - 2016-02-26 07:41:55 --> Helper loaded: form_helper
INFO - 2016-02-26 07:41:55 --> Database Driver Class Initialized
INFO - 2016-02-26 07:41:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:41:56 --> Controller Class Initialized
INFO - 2016-02-26 07:41:56 --> Model Class Initialized
INFO - 2016-02-26 07:41:56 --> Model Class Initialized
INFO - 2016-02-26 07:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:41:56 --> Pagination Class Initialized
INFO - 2016-02-26 07:41:56 --> Helper loaded: text_helper
INFO - 2016-02-26 07:41:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:41:56 --> Final output sent to browser
DEBUG - 2016-02-26 10:41:56 --> Total execution time: 1.1563
INFO - 2016-02-26 07:43:59 --> Config Class Initialized
INFO - 2016-02-26 07:43:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:43:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:43:59 --> Utf8 Class Initialized
INFO - 2016-02-26 07:43:59 --> URI Class Initialized
INFO - 2016-02-26 07:43:59 --> Router Class Initialized
INFO - 2016-02-26 07:43:59 --> Output Class Initialized
INFO - 2016-02-26 07:43:59 --> Security Class Initialized
DEBUG - 2016-02-26 07:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:43:59 --> Input Class Initialized
INFO - 2016-02-26 07:43:59 --> Language Class Initialized
INFO - 2016-02-26 07:43:59 --> Loader Class Initialized
INFO - 2016-02-26 07:43:59 --> Helper loaded: url_helper
INFO - 2016-02-26 07:43:59 --> Helper loaded: file_helper
INFO - 2016-02-26 07:43:59 --> Helper loaded: date_helper
INFO - 2016-02-26 07:43:59 --> Helper loaded: form_helper
INFO - 2016-02-26 07:43:59 --> Database Driver Class Initialized
INFO - 2016-02-26 07:44:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:44:00 --> Controller Class Initialized
INFO - 2016-02-26 07:44:00 --> Model Class Initialized
INFO - 2016-02-26 07:44:00 --> Model Class Initialized
INFO - 2016-02-26 07:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:44:00 --> Pagination Class Initialized
INFO - 2016-02-26 07:44:00 --> Helper loaded: text_helper
INFO - 2016-02-26 07:44:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:44:00 --> Final output sent to browser
DEBUG - 2016-02-26 10:44:00 --> Total execution time: 1.1559
INFO - 2016-02-26 07:45:17 --> Config Class Initialized
INFO - 2016-02-26 07:45:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:45:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:45:17 --> Utf8 Class Initialized
INFO - 2016-02-26 07:45:17 --> URI Class Initialized
INFO - 2016-02-26 07:45:17 --> Router Class Initialized
INFO - 2016-02-26 07:45:17 --> Output Class Initialized
INFO - 2016-02-26 07:45:17 --> Security Class Initialized
DEBUG - 2016-02-26 07:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:45:17 --> Input Class Initialized
INFO - 2016-02-26 07:45:17 --> Language Class Initialized
INFO - 2016-02-26 07:45:17 --> Loader Class Initialized
INFO - 2016-02-26 07:45:17 --> Helper loaded: url_helper
INFO - 2016-02-26 07:45:17 --> Helper loaded: file_helper
INFO - 2016-02-26 07:45:17 --> Helper loaded: date_helper
INFO - 2016-02-26 07:45:17 --> Helper loaded: form_helper
INFO - 2016-02-26 07:45:17 --> Database Driver Class Initialized
INFO - 2016-02-26 07:45:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:45:18 --> Controller Class Initialized
INFO - 2016-02-26 07:45:18 --> Model Class Initialized
INFO - 2016-02-26 07:45:18 --> Model Class Initialized
INFO - 2016-02-26 07:45:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:45:18 --> Pagination Class Initialized
INFO - 2016-02-26 07:45:18 --> Helper loaded: text_helper
INFO - 2016-02-26 07:45:18 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:45:18 --> Final output sent to browser
DEBUG - 2016-02-26 10:45:18 --> Total execution time: 1.1771
INFO - 2016-02-26 07:46:20 --> Config Class Initialized
INFO - 2016-02-26 07:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:46:20 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:46:20 --> Utf8 Class Initialized
INFO - 2016-02-26 07:46:20 --> URI Class Initialized
INFO - 2016-02-26 07:46:20 --> Router Class Initialized
INFO - 2016-02-26 07:46:20 --> Output Class Initialized
INFO - 2016-02-26 07:46:20 --> Security Class Initialized
DEBUG - 2016-02-26 07:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:46:20 --> Input Class Initialized
INFO - 2016-02-26 07:46:20 --> Language Class Initialized
INFO - 2016-02-26 07:46:20 --> Loader Class Initialized
INFO - 2016-02-26 07:46:20 --> Helper loaded: url_helper
INFO - 2016-02-26 07:46:20 --> Helper loaded: file_helper
INFO - 2016-02-26 07:46:20 --> Helper loaded: date_helper
INFO - 2016-02-26 07:46:20 --> Helper loaded: form_helper
INFO - 2016-02-26 07:46:20 --> Database Driver Class Initialized
INFO - 2016-02-26 07:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:46:21 --> Controller Class Initialized
INFO - 2016-02-26 07:46:21 --> Model Class Initialized
INFO - 2016-02-26 07:46:21 --> Model Class Initialized
INFO - 2016-02-26 07:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:46:21 --> Pagination Class Initialized
INFO - 2016-02-26 07:46:21 --> Helper loaded: text_helper
INFO - 2016-02-26 07:46:21 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:46:22 --> Final output sent to browser
DEBUG - 2016-02-26 10:46:22 --> Total execution time: 1.1556
INFO - 2016-02-26 07:46:44 --> Config Class Initialized
INFO - 2016-02-26 07:46:44 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:46:44 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:46:44 --> Utf8 Class Initialized
INFO - 2016-02-26 07:46:44 --> URI Class Initialized
INFO - 2016-02-26 07:46:44 --> Router Class Initialized
INFO - 2016-02-26 07:46:44 --> Output Class Initialized
INFO - 2016-02-26 07:46:44 --> Security Class Initialized
DEBUG - 2016-02-26 07:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:46:44 --> Input Class Initialized
INFO - 2016-02-26 07:46:44 --> Language Class Initialized
INFO - 2016-02-26 07:46:44 --> Loader Class Initialized
INFO - 2016-02-26 07:46:44 --> Helper loaded: url_helper
INFO - 2016-02-26 07:46:44 --> Helper loaded: file_helper
INFO - 2016-02-26 07:46:44 --> Helper loaded: date_helper
INFO - 2016-02-26 07:46:44 --> Helper loaded: form_helper
INFO - 2016-02-26 07:46:44 --> Database Driver Class Initialized
INFO - 2016-02-26 07:46:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:46:45 --> Controller Class Initialized
INFO - 2016-02-26 07:46:45 --> Model Class Initialized
INFO - 2016-02-26 07:46:45 --> Model Class Initialized
INFO - 2016-02-26 07:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:46:45 --> Pagination Class Initialized
INFO - 2016-02-26 07:46:45 --> Helper loaded: text_helper
INFO - 2016-02-26 07:46:45 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:46:45 --> Final output sent to browser
DEBUG - 2016-02-26 10:46:45 --> Total execution time: 1.2487
INFO - 2016-02-26 07:55:14 --> Config Class Initialized
INFO - 2016-02-26 07:55:14 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:55:14 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:55:14 --> Utf8 Class Initialized
INFO - 2016-02-26 07:55:14 --> URI Class Initialized
DEBUG - 2016-02-26 07:55:14 --> No URI present. Default controller set.
INFO - 2016-02-26 07:55:14 --> Router Class Initialized
INFO - 2016-02-26 07:55:14 --> Output Class Initialized
INFO - 2016-02-26 07:55:14 --> Security Class Initialized
DEBUG - 2016-02-26 07:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:55:14 --> Input Class Initialized
INFO - 2016-02-26 07:55:14 --> Language Class Initialized
INFO - 2016-02-26 07:55:14 --> Loader Class Initialized
INFO - 2016-02-26 07:55:14 --> Helper loaded: url_helper
INFO - 2016-02-26 07:55:14 --> Helper loaded: file_helper
INFO - 2016-02-26 07:55:14 --> Helper loaded: date_helper
INFO - 2016-02-26 07:55:14 --> Helper loaded: form_helper
INFO - 2016-02-26 07:55:14 --> Database Driver Class Initialized
INFO - 2016-02-26 07:55:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:55:15 --> Controller Class Initialized
INFO - 2016-02-26 07:55:15 --> Model Class Initialized
INFO - 2016-02-26 07:55:15 --> Model Class Initialized
INFO - 2016-02-26 07:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:55:15 --> Pagination Class Initialized
INFO - 2016-02-26 07:55:15 --> Helper loaded: text_helper
INFO - 2016-02-26 07:55:15 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 10:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:55:15 --> Final output sent to browser
DEBUG - 2016-02-26 10:55:15 --> Total execution time: 1.1845
INFO - 2016-02-26 07:55:17 --> Config Class Initialized
INFO - 2016-02-26 07:55:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:55:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:55:17 --> Utf8 Class Initialized
INFO - 2016-02-26 07:55:17 --> URI Class Initialized
INFO - 2016-02-26 07:55:17 --> Router Class Initialized
INFO - 2016-02-26 07:55:17 --> Output Class Initialized
INFO - 2016-02-26 07:55:17 --> Security Class Initialized
DEBUG - 2016-02-26 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:55:17 --> Input Class Initialized
INFO - 2016-02-26 07:55:17 --> Language Class Initialized
INFO - 2016-02-26 07:55:17 --> Loader Class Initialized
INFO - 2016-02-26 07:55:17 --> Helper loaded: url_helper
INFO - 2016-02-26 07:55:17 --> Helper loaded: file_helper
INFO - 2016-02-26 07:55:17 --> Helper loaded: date_helper
INFO - 2016-02-26 07:55:17 --> Helper loaded: form_helper
INFO - 2016-02-26 07:55:17 --> Database Driver Class Initialized
INFO - 2016-02-26 07:55:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:55:18 --> Controller Class Initialized
INFO - 2016-02-26 07:55:18 --> Model Class Initialized
INFO - 2016-02-26 07:55:18 --> Model Class Initialized
INFO - 2016-02-26 07:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:55:18 --> Pagination Class Initialized
INFO - 2016-02-26 07:55:18 --> Helper loaded: text_helper
INFO - 2016-02-26 07:55:18 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 10:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 10:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:55:19 --> Final output sent to browser
DEBUG - 2016-02-26 10:55:19 --> Total execution time: 1.1181
INFO - 2016-02-26 07:55:20 --> Config Class Initialized
INFO - 2016-02-26 07:55:20 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:55:20 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:55:20 --> Utf8 Class Initialized
INFO - 2016-02-26 07:55:20 --> URI Class Initialized
INFO - 2016-02-26 07:55:20 --> Router Class Initialized
INFO - 2016-02-26 07:55:20 --> Output Class Initialized
INFO - 2016-02-26 07:55:20 --> Security Class Initialized
DEBUG - 2016-02-26 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:55:20 --> Input Class Initialized
INFO - 2016-02-26 07:55:20 --> Language Class Initialized
INFO - 2016-02-26 07:55:20 --> Loader Class Initialized
INFO - 2016-02-26 07:55:20 --> Helper loaded: url_helper
INFO - 2016-02-26 07:55:20 --> Helper loaded: file_helper
INFO - 2016-02-26 07:55:20 --> Helper loaded: date_helper
INFO - 2016-02-26 07:55:20 --> Helper loaded: form_helper
INFO - 2016-02-26 07:55:20 --> Database Driver Class Initialized
INFO - 2016-02-26 07:55:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:55:21 --> Controller Class Initialized
INFO - 2016-02-26 07:55:21 --> Model Class Initialized
INFO - 2016-02-26 07:55:21 --> Model Class Initialized
INFO - 2016-02-26 07:55:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:55:21 --> Pagination Class Initialized
INFO - 2016-02-26 07:55:21 --> Helper loaded: text_helper
INFO - 2016-02-26 07:55:21 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:55:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:55:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:55:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:55:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:55:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:55:21 --> Final output sent to browser
DEBUG - 2016-02-26 10:55:21 --> Total execution time: 1.1338
INFO - 2016-02-26 07:55:31 --> Config Class Initialized
INFO - 2016-02-26 07:55:31 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:55:31 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:55:31 --> Utf8 Class Initialized
INFO - 2016-02-26 07:55:31 --> URI Class Initialized
INFO - 2016-02-26 07:55:31 --> Router Class Initialized
INFO - 2016-02-26 07:55:31 --> Output Class Initialized
INFO - 2016-02-26 07:55:31 --> Security Class Initialized
DEBUG - 2016-02-26 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:55:31 --> Input Class Initialized
INFO - 2016-02-26 07:55:31 --> Language Class Initialized
INFO - 2016-02-26 07:55:31 --> Loader Class Initialized
INFO - 2016-02-26 07:55:31 --> Helper loaded: url_helper
INFO - 2016-02-26 07:55:31 --> Helper loaded: file_helper
INFO - 2016-02-26 07:55:31 --> Helper loaded: date_helper
INFO - 2016-02-26 07:55:31 --> Helper loaded: form_helper
INFO - 2016-02-26 07:55:31 --> Database Driver Class Initialized
INFO - 2016-02-26 07:55:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:55:32 --> Controller Class Initialized
INFO - 2016-02-26 07:55:32 --> Model Class Initialized
INFO - 2016-02-26 07:55:32 --> Model Class Initialized
INFO - 2016-02-26 07:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:55:32 --> Pagination Class Initialized
INFO - 2016-02-26 07:55:32 --> Helper loaded: text_helper
INFO - 2016-02-26 07:55:32 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:55:32 --> Final output sent to browser
DEBUG - 2016-02-26 10:55:32 --> Total execution time: 1.1403
INFO - 2016-02-26 07:56:09 --> Config Class Initialized
INFO - 2016-02-26 07:56:09 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:56:09 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:56:09 --> Utf8 Class Initialized
INFO - 2016-02-26 07:56:09 --> URI Class Initialized
INFO - 2016-02-26 07:56:09 --> Router Class Initialized
INFO - 2016-02-26 07:56:09 --> Output Class Initialized
INFO - 2016-02-26 07:56:09 --> Security Class Initialized
DEBUG - 2016-02-26 07:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:56:09 --> Input Class Initialized
INFO - 2016-02-26 07:56:09 --> Language Class Initialized
INFO - 2016-02-26 07:56:09 --> Loader Class Initialized
INFO - 2016-02-26 07:56:09 --> Helper loaded: url_helper
INFO - 2016-02-26 07:56:09 --> Helper loaded: file_helper
INFO - 2016-02-26 07:56:09 --> Helper loaded: date_helper
INFO - 2016-02-26 07:56:09 --> Helper loaded: form_helper
INFO - 2016-02-26 07:56:09 --> Database Driver Class Initialized
INFO - 2016-02-26 07:56:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:56:10 --> Controller Class Initialized
INFO - 2016-02-26 07:56:10 --> Model Class Initialized
INFO - 2016-02-26 07:56:10 --> Model Class Initialized
INFO - 2016-02-26 07:56:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:56:10 --> Pagination Class Initialized
INFO - 2016-02-26 07:56:10 --> Helper loaded: text_helper
INFO - 2016-02-26 07:56:10 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:56:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:56:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:56:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:56:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:56:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:56:10 --> Final output sent to browser
DEBUG - 2016-02-26 10:56:10 --> Total execution time: 1.1614
INFO - 2016-02-26 07:56:52 --> Config Class Initialized
INFO - 2016-02-26 07:56:52 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:56:52 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:56:52 --> Utf8 Class Initialized
INFO - 2016-02-26 07:56:53 --> URI Class Initialized
INFO - 2016-02-26 07:56:53 --> Router Class Initialized
INFO - 2016-02-26 07:56:53 --> Output Class Initialized
INFO - 2016-02-26 07:56:53 --> Security Class Initialized
DEBUG - 2016-02-26 07:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:56:53 --> Input Class Initialized
INFO - 2016-02-26 07:56:53 --> Language Class Initialized
INFO - 2016-02-26 07:56:53 --> Loader Class Initialized
INFO - 2016-02-26 07:56:53 --> Helper loaded: url_helper
INFO - 2016-02-26 07:56:53 --> Helper loaded: file_helper
INFO - 2016-02-26 07:56:53 --> Helper loaded: date_helper
INFO - 2016-02-26 07:56:53 --> Helper loaded: form_helper
INFO - 2016-02-26 07:56:53 --> Database Driver Class Initialized
INFO - 2016-02-26 07:56:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:56:54 --> Controller Class Initialized
INFO - 2016-02-26 07:56:54 --> Model Class Initialized
INFO - 2016-02-26 07:56:54 --> Model Class Initialized
INFO - 2016-02-26 07:56:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:56:54 --> Pagination Class Initialized
INFO - 2016-02-26 07:56:54 --> Helper loaded: text_helper
INFO - 2016-02-26 07:56:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:56:54 --> Final output sent to browser
DEBUG - 2016-02-26 10:56:54 --> Total execution time: 1.1472
INFO - 2016-02-26 07:57:06 --> Config Class Initialized
INFO - 2016-02-26 07:57:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:57:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:57:06 --> Utf8 Class Initialized
INFO - 2016-02-26 07:57:06 --> URI Class Initialized
INFO - 2016-02-26 07:57:06 --> Router Class Initialized
INFO - 2016-02-26 07:57:06 --> Output Class Initialized
INFO - 2016-02-26 07:57:06 --> Security Class Initialized
DEBUG - 2016-02-26 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:57:06 --> Input Class Initialized
INFO - 2016-02-26 07:57:06 --> Language Class Initialized
INFO - 2016-02-26 07:57:06 --> Loader Class Initialized
INFO - 2016-02-26 07:57:06 --> Helper loaded: url_helper
INFO - 2016-02-26 07:57:06 --> Helper loaded: file_helper
INFO - 2016-02-26 07:57:06 --> Helper loaded: date_helper
INFO - 2016-02-26 07:57:06 --> Helper loaded: form_helper
INFO - 2016-02-26 07:57:06 --> Database Driver Class Initialized
INFO - 2016-02-26 07:57:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:57:07 --> Controller Class Initialized
INFO - 2016-02-26 07:57:07 --> Model Class Initialized
INFO - 2016-02-26 07:57:07 --> Model Class Initialized
INFO - 2016-02-26 07:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:57:07 --> Pagination Class Initialized
INFO - 2016-02-26 07:57:07 --> Helper loaded: text_helper
INFO - 2016-02-26 07:57:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:57:07 --> Final output sent to browser
DEBUG - 2016-02-26 10:57:07 --> Total execution time: 1.1656
INFO - 2016-02-26 07:58:06 --> Config Class Initialized
INFO - 2016-02-26 07:58:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 07:58:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 07:58:06 --> Utf8 Class Initialized
INFO - 2016-02-26 07:58:06 --> URI Class Initialized
INFO - 2016-02-26 07:58:06 --> Router Class Initialized
INFO - 2016-02-26 07:58:06 --> Output Class Initialized
INFO - 2016-02-26 07:58:06 --> Security Class Initialized
DEBUG - 2016-02-26 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 07:58:06 --> Input Class Initialized
INFO - 2016-02-26 07:58:06 --> Language Class Initialized
INFO - 2016-02-26 07:58:06 --> Loader Class Initialized
INFO - 2016-02-26 07:58:06 --> Helper loaded: url_helper
INFO - 2016-02-26 07:58:06 --> Helper loaded: file_helper
INFO - 2016-02-26 07:58:06 --> Helper loaded: date_helper
INFO - 2016-02-26 07:58:06 --> Helper loaded: form_helper
INFO - 2016-02-26 07:58:06 --> Database Driver Class Initialized
INFO - 2016-02-26 07:58:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 07:58:07 --> Controller Class Initialized
INFO - 2016-02-26 07:58:07 --> Model Class Initialized
INFO - 2016-02-26 07:58:07 --> Model Class Initialized
INFO - 2016-02-26 07:58:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 07:58:07 --> Pagination Class Initialized
INFO - 2016-02-26 07:58:07 --> Helper loaded: text_helper
INFO - 2016-02-26 07:58:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 10:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 10:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 10:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 10:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 10:58:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 10:58:07 --> Final output sent to browser
DEBUG - 2016-02-26 10:58:07 --> Total execution time: 1.1165
INFO - 2016-02-26 08:00:58 --> Config Class Initialized
INFO - 2016-02-26 08:00:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:00:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:00:58 --> Utf8 Class Initialized
INFO - 2016-02-26 08:00:58 --> URI Class Initialized
INFO - 2016-02-26 08:00:58 --> Router Class Initialized
INFO - 2016-02-26 08:00:58 --> Output Class Initialized
INFO - 2016-02-26 08:00:58 --> Security Class Initialized
DEBUG - 2016-02-26 08:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:00:58 --> Input Class Initialized
INFO - 2016-02-26 08:00:58 --> Language Class Initialized
INFO - 2016-02-26 08:00:58 --> Loader Class Initialized
INFO - 2016-02-26 08:00:58 --> Helper loaded: url_helper
INFO - 2016-02-26 08:00:58 --> Helper loaded: file_helper
INFO - 2016-02-26 08:00:58 --> Helper loaded: date_helper
INFO - 2016-02-26 08:00:58 --> Helper loaded: form_helper
INFO - 2016-02-26 08:00:58 --> Database Driver Class Initialized
INFO - 2016-02-26 08:00:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:00:59 --> Controller Class Initialized
INFO - 2016-02-26 08:00:59 --> Model Class Initialized
INFO - 2016-02-26 08:00:59 --> Model Class Initialized
INFO - 2016-02-26 08:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:00:59 --> Pagination Class Initialized
INFO - 2016-02-26 08:00:59 --> Helper loaded: text_helper
INFO - 2016-02-26 08:00:59 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:00:59 --> Final output sent to browser
DEBUG - 2016-02-26 11:00:59 --> Total execution time: 1.1308
INFO - 2016-02-26 08:01:36 --> Config Class Initialized
INFO - 2016-02-26 08:01:36 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:01:36 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:01:36 --> Utf8 Class Initialized
INFO - 2016-02-26 08:01:36 --> URI Class Initialized
INFO - 2016-02-26 08:01:36 --> Router Class Initialized
INFO - 2016-02-26 08:01:36 --> Output Class Initialized
INFO - 2016-02-26 08:01:36 --> Security Class Initialized
DEBUG - 2016-02-26 08:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:01:36 --> Input Class Initialized
INFO - 2016-02-26 08:01:36 --> Language Class Initialized
INFO - 2016-02-26 08:01:36 --> Loader Class Initialized
INFO - 2016-02-26 08:01:36 --> Helper loaded: url_helper
INFO - 2016-02-26 08:01:36 --> Helper loaded: file_helper
INFO - 2016-02-26 08:01:36 --> Helper loaded: date_helper
INFO - 2016-02-26 08:01:36 --> Helper loaded: form_helper
INFO - 2016-02-26 08:01:36 --> Database Driver Class Initialized
INFO - 2016-02-26 08:01:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:01:37 --> Controller Class Initialized
INFO - 2016-02-26 08:01:37 --> Model Class Initialized
INFO - 2016-02-26 08:01:37 --> Model Class Initialized
INFO - 2016-02-26 08:01:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:01:37 --> Pagination Class Initialized
INFO - 2016-02-26 08:01:37 --> Helper loaded: text_helper
INFO - 2016-02-26 08:01:37 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:01:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:01:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:01:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:01:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:01:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:01:37 --> Final output sent to browser
DEBUG - 2016-02-26 11:01:37 --> Total execution time: 1.2221
INFO - 2016-02-26 08:01:44 --> Config Class Initialized
INFO - 2016-02-26 08:01:44 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:01:44 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:01:44 --> Utf8 Class Initialized
INFO - 2016-02-26 08:01:44 --> URI Class Initialized
INFO - 2016-02-26 08:01:44 --> Router Class Initialized
INFO - 2016-02-26 08:01:44 --> Output Class Initialized
INFO - 2016-02-26 08:01:44 --> Security Class Initialized
DEBUG - 2016-02-26 08:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:01:44 --> Input Class Initialized
INFO - 2016-02-26 08:01:44 --> Language Class Initialized
INFO - 2016-02-26 08:01:44 --> Loader Class Initialized
INFO - 2016-02-26 08:01:44 --> Helper loaded: url_helper
INFO - 2016-02-26 08:01:44 --> Helper loaded: file_helper
INFO - 2016-02-26 08:01:44 --> Helper loaded: date_helper
INFO - 2016-02-26 08:01:44 --> Helper loaded: form_helper
INFO - 2016-02-26 08:01:44 --> Database Driver Class Initialized
INFO - 2016-02-26 08:01:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:01:45 --> Controller Class Initialized
INFO - 2016-02-26 08:01:45 --> Model Class Initialized
INFO - 2016-02-26 08:01:45 --> Model Class Initialized
INFO - 2016-02-26 08:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:01:45 --> Pagination Class Initialized
INFO - 2016-02-26 08:01:45 --> Helper loaded: text_helper
INFO - 2016-02-26 08:01:45 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:01:45 --> Final output sent to browser
DEBUG - 2016-02-26 11:01:45 --> Total execution time: 1.1493
INFO - 2016-02-26 08:03:55 --> Config Class Initialized
INFO - 2016-02-26 08:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:03:55 --> Utf8 Class Initialized
INFO - 2016-02-26 08:03:55 --> URI Class Initialized
INFO - 2016-02-26 08:03:55 --> Router Class Initialized
INFO - 2016-02-26 08:03:55 --> Output Class Initialized
INFO - 2016-02-26 08:03:55 --> Security Class Initialized
DEBUG - 2016-02-26 08:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:03:55 --> Input Class Initialized
INFO - 2016-02-26 08:03:55 --> Language Class Initialized
INFO - 2016-02-26 08:03:55 --> Loader Class Initialized
INFO - 2016-02-26 08:03:55 --> Helper loaded: url_helper
INFO - 2016-02-26 08:03:55 --> Helper loaded: file_helper
INFO - 2016-02-26 08:03:55 --> Helper loaded: date_helper
INFO - 2016-02-26 08:03:55 --> Helper loaded: form_helper
INFO - 2016-02-26 08:03:55 --> Database Driver Class Initialized
INFO - 2016-02-26 08:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:03:56 --> Controller Class Initialized
INFO - 2016-02-26 08:03:56 --> Model Class Initialized
INFO - 2016-02-26 08:03:56 --> Model Class Initialized
INFO - 2016-02-26 08:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:03:56 --> Pagination Class Initialized
INFO - 2016-02-26 08:03:56 --> Helper loaded: text_helper
INFO - 2016-02-26 08:03:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:03:56 --> Final output sent to browser
DEBUG - 2016-02-26 11:03:56 --> Total execution time: 1.1736
INFO - 2016-02-26 08:04:27 --> Config Class Initialized
INFO - 2016-02-26 08:04:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:04:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:04:27 --> Utf8 Class Initialized
INFO - 2016-02-26 08:04:27 --> URI Class Initialized
INFO - 2016-02-26 08:04:27 --> Router Class Initialized
INFO - 2016-02-26 08:04:27 --> Output Class Initialized
INFO - 2016-02-26 08:04:27 --> Security Class Initialized
DEBUG - 2016-02-26 08:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:04:27 --> Input Class Initialized
INFO - 2016-02-26 08:04:27 --> Language Class Initialized
INFO - 2016-02-26 08:04:27 --> Loader Class Initialized
INFO - 2016-02-26 08:04:27 --> Helper loaded: url_helper
INFO - 2016-02-26 08:04:27 --> Helper loaded: file_helper
INFO - 2016-02-26 08:04:27 --> Helper loaded: date_helper
INFO - 2016-02-26 08:04:27 --> Helper loaded: form_helper
INFO - 2016-02-26 08:04:27 --> Database Driver Class Initialized
INFO - 2016-02-26 08:04:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:04:28 --> Controller Class Initialized
INFO - 2016-02-26 08:04:28 --> Model Class Initialized
INFO - 2016-02-26 08:04:28 --> Model Class Initialized
INFO - 2016-02-26 08:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:04:28 --> Pagination Class Initialized
INFO - 2016-02-26 08:04:28 --> Helper loaded: text_helper
INFO - 2016-02-26 08:04:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:04:28 --> Final output sent to browser
DEBUG - 2016-02-26 11:04:28 --> Total execution time: 1.1794
INFO - 2016-02-26 08:10:53 --> Config Class Initialized
INFO - 2016-02-26 08:10:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:10:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:10:53 --> Utf8 Class Initialized
INFO - 2016-02-26 08:10:53 --> URI Class Initialized
INFO - 2016-02-26 08:10:53 --> Router Class Initialized
INFO - 2016-02-26 08:10:53 --> Output Class Initialized
INFO - 2016-02-26 08:10:53 --> Security Class Initialized
DEBUG - 2016-02-26 08:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:10:53 --> Input Class Initialized
INFO - 2016-02-26 08:10:53 --> Language Class Initialized
INFO - 2016-02-26 08:10:53 --> Loader Class Initialized
INFO - 2016-02-26 08:10:53 --> Helper loaded: url_helper
INFO - 2016-02-26 08:10:53 --> Helper loaded: file_helper
INFO - 2016-02-26 08:10:53 --> Helper loaded: date_helper
INFO - 2016-02-26 08:10:53 --> Helper loaded: form_helper
INFO - 2016-02-26 08:10:53 --> Database Driver Class Initialized
INFO - 2016-02-26 08:10:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:10:54 --> Controller Class Initialized
INFO - 2016-02-26 08:10:54 --> Model Class Initialized
INFO - 2016-02-26 08:10:54 --> Model Class Initialized
INFO - 2016-02-26 08:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:10:54 --> Pagination Class Initialized
INFO - 2016-02-26 08:10:54 --> Helper loaded: text_helper
INFO - 2016-02-26 08:10:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:10:54 --> Final output sent to browser
DEBUG - 2016-02-26 11:10:54 --> Total execution time: 1.1597
INFO - 2016-02-26 08:11:45 --> Config Class Initialized
INFO - 2016-02-26 08:11:45 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:11:45 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:11:45 --> Utf8 Class Initialized
INFO - 2016-02-26 08:11:45 --> URI Class Initialized
INFO - 2016-02-26 08:11:45 --> Router Class Initialized
INFO - 2016-02-26 08:11:45 --> Output Class Initialized
INFO - 2016-02-26 08:11:45 --> Security Class Initialized
DEBUG - 2016-02-26 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:11:45 --> Input Class Initialized
INFO - 2016-02-26 08:11:45 --> Language Class Initialized
INFO - 2016-02-26 08:11:45 --> Loader Class Initialized
INFO - 2016-02-26 08:11:45 --> Helper loaded: url_helper
INFO - 2016-02-26 08:11:45 --> Helper loaded: file_helper
INFO - 2016-02-26 08:11:45 --> Helper loaded: date_helper
INFO - 2016-02-26 08:11:45 --> Helper loaded: form_helper
INFO - 2016-02-26 08:11:45 --> Database Driver Class Initialized
INFO - 2016-02-26 08:11:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:11:47 --> Controller Class Initialized
INFO - 2016-02-26 08:11:47 --> Model Class Initialized
INFO - 2016-02-26 08:11:47 --> Model Class Initialized
INFO - 2016-02-26 08:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:11:47 --> Pagination Class Initialized
INFO - 2016-02-26 08:11:47 --> Helper loaded: text_helper
INFO - 2016-02-26 08:11:47 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:11:47 --> Final output sent to browser
DEBUG - 2016-02-26 11:11:47 --> Total execution time: 1.1195
INFO - 2016-02-26 08:12:36 --> Config Class Initialized
INFO - 2016-02-26 08:12:36 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:12:36 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:12:36 --> Utf8 Class Initialized
INFO - 2016-02-26 08:12:36 --> URI Class Initialized
INFO - 2016-02-26 08:12:36 --> Router Class Initialized
INFO - 2016-02-26 08:12:36 --> Output Class Initialized
INFO - 2016-02-26 08:12:36 --> Security Class Initialized
DEBUG - 2016-02-26 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:12:36 --> Input Class Initialized
INFO - 2016-02-26 08:12:36 --> Language Class Initialized
INFO - 2016-02-26 08:12:36 --> Loader Class Initialized
INFO - 2016-02-26 08:12:36 --> Helper loaded: url_helper
INFO - 2016-02-26 08:12:36 --> Helper loaded: file_helper
INFO - 2016-02-26 08:12:36 --> Helper loaded: date_helper
INFO - 2016-02-26 08:12:36 --> Helper loaded: form_helper
INFO - 2016-02-26 08:12:36 --> Database Driver Class Initialized
INFO - 2016-02-26 08:12:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:12:37 --> Controller Class Initialized
INFO - 2016-02-26 08:12:37 --> Model Class Initialized
INFO - 2016-02-26 08:12:37 --> Model Class Initialized
INFO - 2016-02-26 08:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:12:37 --> Pagination Class Initialized
INFO - 2016-02-26 08:12:37 --> Helper loaded: text_helper
INFO - 2016-02-26 08:12:37 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:12:37 --> Final output sent to browser
DEBUG - 2016-02-26 11:12:37 --> Total execution time: 1.1331
INFO - 2016-02-26 08:19:45 --> Config Class Initialized
INFO - 2016-02-26 08:19:45 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:19:45 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:19:45 --> Utf8 Class Initialized
INFO - 2016-02-26 08:19:45 --> URI Class Initialized
INFO - 2016-02-26 08:19:45 --> Router Class Initialized
INFO - 2016-02-26 08:19:45 --> Output Class Initialized
INFO - 2016-02-26 08:19:45 --> Security Class Initialized
DEBUG - 2016-02-26 08:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:19:45 --> Input Class Initialized
INFO - 2016-02-26 08:19:45 --> Language Class Initialized
INFO - 2016-02-26 08:19:45 --> Loader Class Initialized
INFO - 2016-02-26 08:19:45 --> Helper loaded: url_helper
INFO - 2016-02-26 08:19:45 --> Helper loaded: file_helper
INFO - 2016-02-26 08:19:45 --> Helper loaded: date_helper
INFO - 2016-02-26 08:19:45 --> Helper loaded: form_helper
INFO - 2016-02-26 08:19:45 --> Database Driver Class Initialized
INFO - 2016-02-26 08:19:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:19:46 --> Controller Class Initialized
INFO - 2016-02-26 08:19:46 --> Model Class Initialized
INFO - 2016-02-26 08:19:46 --> Model Class Initialized
INFO - 2016-02-26 08:19:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:19:46 --> Pagination Class Initialized
INFO - 2016-02-26 08:19:46 --> Helper loaded: text_helper
INFO - 2016-02-26 08:19:46 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:19:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:19:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:19:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:19:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:19:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:19:46 --> Final output sent to browser
DEBUG - 2016-02-26 11:19:46 --> Total execution time: 1.6125
INFO - 2016-02-26 08:21:51 --> Config Class Initialized
INFO - 2016-02-26 08:21:51 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:21:51 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:21:51 --> Utf8 Class Initialized
INFO - 2016-02-26 08:21:51 --> URI Class Initialized
INFO - 2016-02-26 08:21:51 --> Router Class Initialized
INFO - 2016-02-26 08:21:51 --> Output Class Initialized
INFO - 2016-02-26 08:21:51 --> Security Class Initialized
DEBUG - 2016-02-26 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:21:51 --> Input Class Initialized
INFO - 2016-02-26 08:21:51 --> Language Class Initialized
INFO - 2016-02-26 08:21:51 --> Loader Class Initialized
INFO - 2016-02-26 08:21:51 --> Helper loaded: url_helper
INFO - 2016-02-26 08:21:51 --> Helper loaded: file_helper
INFO - 2016-02-26 08:21:51 --> Helper loaded: date_helper
INFO - 2016-02-26 08:21:51 --> Helper loaded: form_helper
INFO - 2016-02-26 08:21:51 --> Database Driver Class Initialized
INFO - 2016-02-26 08:21:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:21:52 --> Controller Class Initialized
INFO - 2016-02-26 08:21:52 --> Model Class Initialized
INFO - 2016-02-26 08:21:52 --> Model Class Initialized
INFO - 2016-02-26 08:21:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:21:52 --> Pagination Class Initialized
INFO - 2016-02-26 08:21:52 --> Helper loaded: text_helper
INFO - 2016-02-26 08:21:52 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:21:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:21:52 --> Final output sent to browser
DEBUG - 2016-02-26 11:21:52 --> Total execution time: 1.1473
INFO - 2016-02-26 08:22:36 --> Config Class Initialized
INFO - 2016-02-26 08:22:36 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:22:36 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:22:36 --> Utf8 Class Initialized
INFO - 2016-02-26 08:22:36 --> URI Class Initialized
INFO - 2016-02-26 08:22:36 --> Router Class Initialized
INFO - 2016-02-26 08:22:36 --> Output Class Initialized
INFO - 2016-02-26 08:22:36 --> Security Class Initialized
DEBUG - 2016-02-26 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:22:36 --> Input Class Initialized
INFO - 2016-02-26 08:22:36 --> Language Class Initialized
INFO - 2016-02-26 08:22:36 --> Loader Class Initialized
INFO - 2016-02-26 08:22:36 --> Helper loaded: url_helper
INFO - 2016-02-26 08:22:36 --> Helper loaded: file_helper
INFO - 2016-02-26 08:22:36 --> Helper loaded: date_helper
INFO - 2016-02-26 08:22:36 --> Helper loaded: form_helper
INFO - 2016-02-26 08:22:36 --> Database Driver Class Initialized
INFO - 2016-02-26 08:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:22:37 --> Controller Class Initialized
INFO - 2016-02-26 08:22:37 --> Model Class Initialized
INFO - 2016-02-26 08:22:37 --> Model Class Initialized
INFO - 2016-02-26 08:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:22:37 --> Pagination Class Initialized
INFO - 2016-02-26 08:22:37 --> Helper loaded: text_helper
INFO - 2016-02-26 08:22:37 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:22:37 --> Final output sent to browser
DEBUG - 2016-02-26 11:22:37 --> Total execution time: 1.1785
INFO - 2016-02-26 08:22:39 --> Config Class Initialized
INFO - 2016-02-26 08:22:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:22:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:22:39 --> Utf8 Class Initialized
INFO - 2016-02-26 08:22:39 --> URI Class Initialized
INFO - 2016-02-26 08:22:39 --> Router Class Initialized
INFO - 2016-02-26 08:22:39 --> Output Class Initialized
INFO - 2016-02-26 08:22:39 --> Security Class Initialized
DEBUG - 2016-02-26 08:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:22:39 --> Input Class Initialized
INFO - 2016-02-26 08:22:39 --> Language Class Initialized
INFO - 2016-02-26 08:22:39 --> Loader Class Initialized
INFO - 2016-02-26 08:22:39 --> Helper loaded: url_helper
INFO - 2016-02-26 08:22:39 --> Helper loaded: file_helper
INFO - 2016-02-26 08:22:39 --> Helper loaded: date_helper
INFO - 2016-02-26 08:22:39 --> Helper loaded: form_helper
INFO - 2016-02-26 08:22:39 --> Database Driver Class Initialized
INFO - 2016-02-26 08:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:22:40 --> Controller Class Initialized
INFO - 2016-02-26 08:22:40 --> Model Class Initialized
INFO - 2016-02-26 08:22:40 --> Model Class Initialized
INFO - 2016-02-26 08:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:22:40 --> Pagination Class Initialized
INFO - 2016-02-26 08:22:40 --> Helper loaded: text_helper
INFO - 2016-02-26 08:22:40 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:22:40 --> Final output sent to browser
DEBUG - 2016-02-26 11:22:40 --> Total execution time: 1.1081
INFO - 2016-02-26 08:23:47 --> Config Class Initialized
INFO - 2016-02-26 08:23:47 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:23:47 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:23:47 --> Utf8 Class Initialized
INFO - 2016-02-26 08:23:47 --> URI Class Initialized
INFO - 2016-02-26 08:23:47 --> Router Class Initialized
INFO - 2016-02-26 08:23:47 --> Output Class Initialized
INFO - 2016-02-26 08:23:47 --> Security Class Initialized
DEBUG - 2016-02-26 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:23:47 --> Input Class Initialized
INFO - 2016-02-26 08:23:47 --> Language Class Initialized
INFO - 2016-02-26 08:23:47 --> Loader Class Initialized
INFO - 2016-02-26 08:23:47 --> Helper loaded: url_helper
INFO - 2016-02-26 08:23:47 --> Helper loaded: file_helper
INFO - 2016-02-26 08:23:47 --> Helper loaded: date_helper
INFO - 2016-02-26 08:23:47 --> Helper loaded: form_helper
INFO - 2016-02-26 08:23:47 --> Database Driver Class Initialized
INFO - 2016-02-26 08:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:23:48 --> Controller Class Initialized
INFO - 2016-02-26 08:23:48 --> Model Class Initialized
INFO - 2016-02-26 08:23:48 --> Model Class Initialized
INFO - 2016-02-26 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:23:48 --> Pagination Class Initialized
INFO - 2016-02-26 08:23:48 --> Helper loaded: text_helper
INFO - 2016-02-26 08:23:48 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:23:48 --> Final output sent to browser
DEBUG - 2016-02-26 11:23:48 --> Total execution time: 1.1183
INFO - 2016-02-26 08:25:55 --> Config Class Initialized
INFO - 2016-02-26 08:25:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:25:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:25:55 --> Utf8 Class Initialized
INFO - 2016-02-26 08:25:55 --> URI Class Initialized
INFO - 2016-02-26 08:25:55 --> Router Class Initialized
INFO - 2016-02-26 08:25:55 --> Output Class Initialized
INFO - 2016-02-26 08:25:55 --> Security Class Initialized
DEBUG - 2016-02-26 08:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:25:55 --> Input Class Initialized
INFO - 2016-02-26 08:25:55 --> Language Class Initialized
INFO - 2016-02-26 08:25:55 --> Loader Class Initialized
INFO - 2016-02-26 08:25:55 --> Helper loaded: url_helper
INFO - 2016-02-26 08:25:55 --> Helper loaded: file_helper
INFO - 2016-02-26 08:25:55 --> Helper loaded: date_helper
INFO - 2016-02-26 08:25:55 --> Helper loaded: form_helper
INFO - 2016-02-26 08:25:55 --> Database Driver Class Initialized
INFO - 2016-02-26 08:25:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:25:56 --> Controller Class Initialized
INFO - 2016-02-26 08:25:56 --> Model Class Initialized
INFO - 2016-02-26 08:25:56 --> Model Class Initialized
INFO - 2016-02-26 08:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:25:56 --> Pagination Class Initialized
INFO - 2016-02-26 08:25:56 --> Helper loaded: text_helper
INFO - 2016-02-26 08:25:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:25:56 --> Final output sent to browser
DEBUG - 2016-02-26 11:25:56 --> Total execution time: 1.1178
INFO - 2016-02-26 08:31:31 --> Config Class Initialized
INFO - 2016-02-26 08:31:31 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:31:31 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:31:31 --> Utf8 Class Initialized
INFO - 2016-02-26 08:31:31 --> URI Class Initialized
INFO - 2016-02-26 08:31:31 --> Router Class Initialized
INFO - 2016-02-26 08:31:31 --> Output Class Initialized
INFO - 2016-02-26 08:31:31 --> Security Class Initialized
DEBUG - 2016-02-26 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:31:31 --> Input Class Initialized
INFO - 2016-02-26 08:31:31 --> Language Class Initialized
INFO - 2016-02-26 08:31:31 --> Loader Class Initialized
INFO - 2016-02-26 08:31:31 --> Helper loaded: url_helper
INFO - 2016-02-26 08:31:31 --> Helper loaded: file_helper
INFO - 2016-02-26 08:31:31 --> Helper loaded: date_helper
INFO - 2016-02-26 08:31:31 --> Helper loaded: form_helper
INFO - 2016-02-26 08:31:31 --> Database Driver Class Initialized
INFO - 2016-02-26 08:31:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:31:32 --> Controller Class Initialized
INFO - 2016-02-26 08:31:32 --> Model Class Initialized
INFO - 2016-02-26 08:31:32 --> Model Class Initialized
INFO - 2016-02-26 08:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:31:32 --> Pagination Class Initialized
INFO - 2016-02-26 08:31:32 --> Helper loaded: text_helper
INFO - 2016-02-26 08:31:32 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:31:32 --> Final output sent to browser
DEBUG - 2016-02-26 11:31:32 --> Total execution time: 1.1691
INFO - 2016-02-26 08:32:38 --> Config Class Initialized
INFO - 2016-02-26 08:32:38 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:32:38 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:32:38 --> Utf8 Class Initialized
INFO - 2016-02-26 08:32:38 --> URI Class Initialized
DEBUG - 2016-02-26 08:32:38 --> No URI present. Default controller set.
INFO - 2016-02-26 08:32:38 --> Router Class Initialized
INFO - 2016-02-26 08:32:38 --> Output Class Initialized
INFO - 2016-02-26 08:32:38 --> Security Class Initialized
DEBUG - 2016-02-26 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:32:38 --> Input Class Initialized
INFO - 2016-02-26 08:32:38 --> Language Class Initialized
INFO - 2016-02-26 08:32:38 --> Loader Class Initialized
INFO - 2016-02-26 08:32:38 --> Helper loaded: url_helper
INFO - 2016-02-26 08:32:38 --> Helper loaded: file_helper
INFO - 2016-02-26 08:32:38 --> Helper loaded: date_helper
INFO - 2016-02-26 08:32:38 --> Helper loaded: form_helper
INFO - 2016-02-26 08:32:38 --> Database Driver Class Initialized
INFO - 2016-02-26 08:32:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:32:39 --> Controller Class Initialized
INFO - 2016-02-26 08:32:39 --> Model Class Initialized
INFO - 2016-02-26 08:32:39 --> Model Class Initialized
INFO - 2016-02-26 08:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:32:39 --> Pagination Class Initialized
INFO - 2016-02-26 08:32:39 --> Helper loaded: text_helper
INFO - 2016-02-26 08:32:39 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 11:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:32:40 --> Final output sent to browser
DEBUG - 2016-02-26 11:32:40 --> Total execution time: 1.1899
INFO - 2016-02-26 08:32:42 --> Config Class Initialized
INFO - 2016-02-26 08:32:42 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:32:42 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:32:42 --> Utf8 Class Initialized
INFO - 2016-02-26 08:32:42 --> URI Class Initialized
INFO - 2016-02-26 08:32:42 --> Router Class Initialized
INFO - 2016-02-26 08:32:42 --> Output Class Initialized
INFO - 2016-02-26 08:32:42 --> Security Class Initialized
DEBUG - 2016-02-26 08:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:32:42 --> Input Class Initialized
INFO - 2016-02-26 08:32:42 --> Language Class Initialized
INFO - 2016-02-26 08:32:42 --> Loader Class Initialized
INFO - 2016-02-26 08:32:42 --> Helper loaded: url_helper
INFO - 2016-02-26 08:32:42 --> Helper loaded: file_helper
INFO - 2016-02-26 08:32:42 --> Helper loaded: date_helper
INFO - 2016-02-26 08:32:42 --> Helper loaded: form_helper
INFO - 2016-02-26 08:32:42 --> Database Driver Class Initialized
INFO - 2016-02-26 08:32:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:32:43 --> Controller Class Initialized
INFO - 2016-02-26 08:32:43 --> Model Class Initialized
INFO - 2016-02-26 08:32:43 --> Model Class Initialized
INFO - 2016-02-26 08:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:32:43 --> Pagination Class Initialized
INFO - 2016-02-26 08:32:43 --> Helper loaded: text_helper
INFO - 2016-02-26 08:32:43 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 11:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 11:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:32:43 --> Final output sent to browser
DEBUG - 2016-02-26 11:32:43 --> Total execution time: 1.2437
INFO - 2016-02-26 08:32:45 --> Config Class Initialized
INFO - 2016-02-26 08:32:45 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:32:45 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:32:45 --> Utf8 Class Initialized
INFO - 2016-02-26 08:32:45 --> URI Class Initialized
INFO - 2016-02-26 08:32:45 --> Router Class Initialized
INFO - 2016-02-26 08:32:45 --> Output Class Initialized
INFO - 2016-02-26 08:32:45 --> Security Class Initialized
DEBUG - 2016-02-26 08:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:32:45 --> Input Class Initialized
INFO - 2016-02-26 08:32:45 --> Language Class Initialized
INFO - 2016-02-26 08:32:45 --> Loader Class Initialized
INFO - 2016-02-26 08:32:45 --> Helper loaded: url_helper
INFO - 2016-02-26 08:32:45 --> Helper loaded: file_helper
INFO - 2016-02-26 08:32:45 --> Helper loaded: date_helper
INFO - 2016-02-26 08:32:45 --> Helper loaded: form_helper
INFO - 2016-02-26 08:32:45 --> Database Driver Class Initialized
INFO - 2016-02-26 08:32:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:32:46 --> Controller Class Initialized
INFO - 2016-02-26 08:32:46 --> Model Class Initialized
INFO - 2016-02-26 08:32:46 --> Model Class Initialized
INFO - 2016-02-26 08:32:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:32:46 --> Pagination Class Initialized
INFO - 2016-02-26 08:32:46 --> Helper loaded: text_helper
INFO - 2016-02-26 08:32:46 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:32:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:32:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:32:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:32:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:32:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:32:46 --> Final output sent to browser
DEBUG - 2016-02-26 11:32:46 --> Total execution time: 1.1515
INFO - 2016-02-26 08:41:17 --> Config Class Initialized
INFO - 2016-02-26 08:41:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:41:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:41:17 --> Utf8 Class Initialized
INFO - 2016-02-26 08:41:17 --> URI Class Initialized
INFO - 2016-02-26 08:41:17 --> Router Class Initialized
INFO - 2016-02-26 08:41:17 --> Output Class Initialized
INFO - 2016-02-26 08:41:17 --> Security Class Initialized
DEBUG - 2016-02-26 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:41:17 --> Input Class Initialized
INFO - 2016-02-26 08:41:17 --> Language Class Initialized
INFO - 2016-02-26 08:41:17 --> Loader Class Initialized
INFO - 2016-02-26 08:41:17 --> Helper loaded: url_helper
INFO - 2016-02-26 08:41:17 --> Helper loaded: file_helper
INFO - 2016-02-26 08:41:17 --> Helper loaded: date_helper
INFO - 2016-02-26 08:41:17 --> Helper loaded: form_helper
INFO - 2016-02-26 08:41:17 --> Database Driver Class Initialized
INFO - 2016-02-26 08:41:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:41:18 --> Controller Class Initialized
INFO - 2016-02-26 08:41:18 --> Model Class Initialized
INFO - 2016-02-26 08:41:18 --> Model Class Initialized
INFO - 2016-02-26 08:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:41:18 --> Pagination Class Initialized
INFO - 2016-02-26 08:41:18 --> Helper loaded: text_helper
INFO - 2016-02-26 08:41:18 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:41:18 --> Final output sent to browser
DEBUG - 2016-02-26 11:41:18 --> Total execution time: 1.1638
INFO - 2016-02-26 08:42:22 --> Config Class Initialized
INFO - 2016-02-26 08:42:22 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:42:22 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:42:22 --> Utf8 Class Initialized
INFO - 2016-02-26 08:42:22 --> URI Class Initialized
INFO - 2016-02-26 08:42:22 --> Router Class Initialized
INFO - 2016-02-26 08:42:22 --> Output Class Initialized
INFO - 2016-02-26 08:42:22 --> Security Class Initialized
DEBUG - 2016-02-26 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:42:22 --> Input Class Initialized
INFO - 2016-02-26 08:42:22 --> Language Class Initialized
INFO - 2016-02-26 08:42:22 --> Loader Class Initialized
INFO - 2016-02-26 08:42:22 --> Helper loaded: url_helper
INFO - 2016-02-26 08:42:22 --> Helper loaded: file_helper
INFO - 2016-02-26 08:42:22 --> Helper loaded: date_helper
INFO - 2016-02-26 08:42:22 --> Helper loaded: form_helper
INFO - 2016-02-26 08:42:22 --> Database Driver Class Initialized
INFO - 2016-02-26 08:42:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:42:23 --> Controller Class Initialized
INFO - 2016-02-26 08:42:23 --> Model Class Initialized
INFO - 2016-02-26 08:42:23 --> Model Class Initialized
INFO - 2016-02-26 08:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:42:23 --> Pagination Class Initialized
INFO - 2016-02-26 08:42:23 --> Helper loaded: text_helper
INFO - 2016-02-26 08:42:23 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:42:23 --> Final output sent to browser
DEBUG - 2016-02-26 11:42:23 --> Total execution time: 1.1419
INFO - 2016-02-26 08:42:40 --> Config Class Initialized
INFO - 2016-02-26 08:42:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:42:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:42:40 --> Utf8 Class Initialized
INFO - 2016-02-26 08:42:40 --> URI Class Initialized
INFO - 2016-02-26 08:42:40 --> Router Class Initialized
INFO - 2016-02-26 08:42:40 --> Output Class Initialized
INFO - 2016-02-26 08:42:40 --> Security Class Initialized
DEBUG - 2016-02-26 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:42:40 --> Input Class Initialized
INFO - 2016-02-26 08:42:40 --> Language Class Initialized
INFO - 2016-02-26 08:42:40 --> Loader Class Initialized
INFO - 2016-02-26 08:42:40 --> Helper loaded: url_helper
INFO - 2016-02-26 08:42:40 --> Helper loaded: file_helper
INFO - 2016-02-26 08:42:40 --> Helper loaded: date_helper
INFO - 2016-02-26 08:42:40 --> Helper loaded: form_helper
INFO - 2016-02-26 08:42:40 --> Database Driver Class Initialized
INFO - 2016-02-26 08:42:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:42:41 --> Controller Class Initialized
INFO - 2016-02-26 08:42:41 --> Model Class Initialized
INFO - 2016-02-26 08:42:41 --> Model Class Initialized
INFO - 2016-02-26 08:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:42:41 --> Pagination Class Initialized
INFO - 2016-02-26 08:42:41 --> Helper loaded: text_helper
INFO - 2016-02-26 08:42:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:42:41 --> Final output sent to browser
DEBUG - 2016-02-26 11:42:41 --> Total execution time: 1.2519
INFO - 2016-02-26 08:43:04 --> Config Class Initialized
INFO - 2016-02-26 08:43:04 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:04 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:04 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:04 --> URI Class Initialized
INFO - 2016-02-26 08:43:04 --> Router Class Initialized
INFO - 2016-02-26 08:43:04 --> Output Class Initialized
INFO - 2016-02-26 08:43:04 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:04 --> Input Class Initialized
INFO - 2016-02-26 08:43:04 --> Language Class Initialized
INFO - 2016-02-26 08:43:04 --> Loader Class Initialized
INFO - 2016-02-26 08:43:04 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:04 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:04 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:04 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:04 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:05 --> Controller Class Initialized
INFO - 2016-02-26 08:43:05 --> Model Class Initialized
INFO - 2016-02-26 08:43:05 --> Model Class Initialized
INFO - 2016-02-26 08:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:05 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:05 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:05 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:05 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:05 --> Total execution time: 1.1894
INFO - 2016-02-26 08:43:07 --> Config Class Initialized
INFO - 2016-02-26 08:43:07 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:07 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:07 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:07 --> URI Class Initialized
DEBUG - 2016-02-26 08:43:07 --> No URI present. Default controller set.
INFO - 2016-02-26 08:43:07 --> Router Class Initialized
INFO - 2016-02-26 08:43:07 --> Output Class Initialized
INFO - 2016-02-26 08:43:07 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:07 --> Input Class Initialized
INFO - 2016-02-26 08:43:07 --> Language Class Initialized
INFO - 2016-02-26 08:43:07 --> Loader Class Initialized
INFO - 2016-02-26 08:43:07 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:07 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:07 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:07 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:07 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:08 --> Controller Class Initialized
INFO - 2016-02-26 08:43:08 --> Model Class Initialized
INFO - 2016-02-26 08:43:08 --> Model Class Initialized
INFO - 2016-02-26 08:43:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:08 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:08 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:08 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 11:43:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:08 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:08 --> Total execution time: 1.1349
INFO - 2016-02-26 08:43:30 --> Config Class Initialized
INFO - 2016-02-26 08:43:30 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:30 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:30 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:30 --> URI Class Initialized
DEBUG - 2016-02-26 08:43:30 --> No URI present. Default controller set.
INFO - 2016-02-26 08:43:30 --> Router Class Initialized
INFO - 2016-02-26 08:43:30 --> Output Class Initialized
INFO - 2016-02-26 08:43:30 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:30 --> Input Class Initialized
INFO - 2016-02-26 08:43:30 --> Language Class Initialized
INFO - 2016-02-26 08:43:30 --> Loader Class Initialized
INFO - 2016-02-26 08:43:30 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:30 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:30 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:30 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:30 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:31 --> Controller Class Initialized
INFO - 2016-02-26 08:43:31 --> Model Class Initialized
INFO - 2016-02-26 08:43:31 --> Model Class Initialized
INFO - 2016-02-26 08:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:31 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:31 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:31 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 11:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:31 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:31 --> Total execution time: 1.1583
INFO - 2016-02-26 08:43:33 --> Config Class Initialized
INFO - 2016-02-26 08:43:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:33 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:33 --> URI Class Initialized
INFO - 2016-02-26 08:43:33 --> Router Class Initialized
INFO - 2016-02-26 08:43:33 --> Output Class Initialized
INFO - 2016-02-26 08:43:33 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:33 --> Input Class Initialized
INFO - 2016-02-26 08:43:33 --> Language Class Initialized
INFO - 2016-02-26 08:43:33 --> Loader Class Initialized
INFO - 2016-02-26 08:43:33 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:33 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:33 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:33 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:33 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:34 --> Controller Class Initialized
INFO - 2016-02-26 08:43:34 --> Model Class Initialized
INFO - 2016-02-26 08:43:34 --> Model Class Initialized
INFO - 2016-02-26 08:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:34 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:34 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 11:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:34 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:34 --> Total execution time: 1.1865
INFO - 2016-02-26 08:43:49 --> Config Class Initialized
INFO - 2016-02-26 08:43:49 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:49 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:49 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:49 --> URI Class Initialized
DEBUG - 2016-02-26 08:43:49 --> No URI present. Default controller set.
INFO - 2016-02-26 08:43:49 --> Router Class Initialized
INFO - 2016-02-26 08:43:49 --> Output Class Initialized
INFO - 2016-02-26 08:43:49 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:49 --> Input Class Initialized
INFO - 2016-02-26 08:43:49 --> Language Class Initialized
INFO - 2016-02-26 08:43:49 --> Loader Class Initialized
INFO - 2016-02-26 08:43:49 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:49 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:49 --> Config Class Initialized
INFO - 2016-02-26 08:43:49 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:49 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:49 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:49 --> URI Class Initialized
DEBUG - 2016-02-26 08:43:49 --> No URI present. Default controller set.
INFO - 2016-02-26 08:43:49 --> Router Class Initialized
INFO - 2016-02-26 08:43:49 --> Output Class Initialized
INFO - 2016-02-26 08:43:49 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:49 --> Input Class Initialized
INFO - 2016-02-26 08:43:49 --> Language Class Initialized
INFO - 2016-02-26 08:43:49 --> Loader Class Initialized
INFO - 2016-02-26 08:43:49 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:49 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:49 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:50 --> Controller Class Initialized
INFO - 2016-02-26 08:43:50 --> Model Class Initialized
INFO - 2016-02-26 08:43:50 --> Model Class Initialized
INFO - 2016-02-26 08:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:50 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:50 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:50 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:50 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:50 --> Total execution time: 1.1498
INFO - 2016-02-26 08:43:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:50 --> Controller Class Initialized
INFO - 2016-02-26 08:43:50 --> Model Class Initialized
INFO - 2016-02-26 08:43:50 --> Model Class Initialized
INFO - 2016-02-26 08:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:50 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:50 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:50 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 11:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:50 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:50 --> Total execution time: 1.1505
INFO - 2016-02-26 08:43:54 --> Config Class Initialized
INFO - 2016-02-26 08:43:54 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:54 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:54 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:54 --> URI Class Initialized
INFO - 2016-02-26 08:43:54 --> Router Class Initialized
INFO - 2016-02-26 08:43:54 --> Output Class Initialized
INFO - 2016-02-26 08:43:54 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:54 --> Input Class Initialized
INFO - 2016-02-26 08:43:54 --> Language Class Initialized
INFO - 2016-02-26 08:43:54 --> Loader Class Initialized
INFO - 2016-02-26 08:43:54 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:54 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:54 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:54 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:54 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:55 --> Controller Class Initialized
INFO - 2016-02-26 08:43:55 --> Model Class Initialized
INFO - 2016-02-26 08:43:55 --> Model Class Initialized
INFO - 2016-02-26 08:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:55 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:55 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:55 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 11:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 11:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:55 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:55 --> Total execution time: 1.1245
INFO - 2016-02-26 08:43:58 --> Config Class Initialized
INFO - 2016-02-26 08:43:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:43:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:43:58 --> Utf8 Class Initialized
INFO - 2016-02-26 08:43:58 --> URI Class Initialized
INFO - 2016-02-26 08:43:58 --> Router Class Initialized
INFO - 2016-02-26 08:43:58 --> Output Class Initialized
INFO - 2016-02-26 08:43:58 --> Security Class Initialized
DEBUG - 2016-02-26 08:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:43:58 --> Input Class Initialized
INFO - 2016-02-26 08:43:58 --> Language Class Initialized
INFO - 2016-02-26 08:43:58 --> Loader Class Initialized
INFO - 2016-02-26 08:43:58 --> Helper loaded: url_helper
INFO - 2016-02-26 08:43:58 --> Helper loaded: file_helper
INFO - 2016-02-26 08:43:58 --> Helper loaded: date_helper
INFO - 2016-02-26 08:43:58 --> Helper loaded: form_helper
INFO - 2016-02-26 08:43:58 --> Database Driver Class Initialized
INFO - 2016-02-26 08:43:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:43:59 --> Controller Class Initialized
INFO - 2016-02-26 08:43:59 --> Model Class Initialized
INFO - 2016-02-26 08:43:59 --> Model Class Initialized
INFO - 2016-02-26 08:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:43:59 --> Pagination Class Initialized
INFO - 2016-02-26 08:43:59 --> Helper loaded: text_helper
INFO - 2016-02-26 08:43:59 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:43:59 --> Final output sent to browser
DEBUG - 2016-02-26 11:43:59 --> Total execution time: 1.1403
INFO - 2016-02-26 08:44:26 --> Config Class Initialized
INFO - 2016-02-26 08:44:26 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:44:26 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:44:26 --> Utf8 Class Initialized
INFO - 2016-02-26 08:44:26 --> URI Class Initialized
INFO - 2016-02-26 08:44:26 --> Router Class Initialized
INFO - 2016-02-26 08:44:26 --> Output Class Initialized
INFO - 2016-02-26 08:44:26 --> Security Class Initialized
DEBUG - 2016-02-26 08:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:44:26 --> Input Class Initialized
INFO - 2016-02-26 08:44:26 --> Language Class Initialized
INFO - 2016-02-26 08:44:26 --> Loader Class Initialized
INFO - 2016-02-26 08:44:26 --> Helper loaded: url_helper
INFO - 2016-02-26 08:44:26 --> Helper loaded: file_helper
INFO - 2016-02-26 08:44:26 --> Helper loaded: date_helper
INFO - 2016-02-26 08:44:26 --> Helper loaded: form_helper
INFO - 2016-02-26 08:44:26 --> Database Driver Class Initialized
INFO - 2016-02-26 08:44:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:44:27 --> Controller Class Initialized
INFO - 2016-02-26 08:44:27 --> Model Class Initialized
INFO - 2016-02-26 08:44:27 --> Model Class Initialized
INFO - 2016-02-26 08:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:44:27 --> Pagination Class Initialized
INFO - 2016-02-26 08:44:27 --> Helper loaded: text_helper
INFO - 2016-02-26 08:44:27 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:44:27 --> Final output sent to browser
DEBUG - 2016-02-26 11:44:27 --> Total execution time: 1.1779
INFO - 2016-02-26 08:44:39 --> Config Class Initialized
INFO - 2016-02-26 08:44:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:44:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:44:39 --> Utf8 Class Initialized
INFO - 2016-02-26 08:44:39 --> URI Class Initialized
INFO - 2016-02-26 08:44:39 --> Router Class Initialized
INFO - 2016-02-26 08:44:39 --> Output Class Initialized
INFO - 2016-02-26 08:44:39 --> Security Class Initialized
DEBUG - 2016-02-26 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:44:39 --> Input Class Initialized
INFO - 2016-02-26 08:44:39 --> Language Class Initialized
INFO - 2016-02-26 08:44:39 --> Loader Class Initialized
INFO - 2016-02-26 08:44:39 --> Helper loaded: url_helper
INFO - 2016-02-26 08:44:39 --> Helper loaded: file_helper
INFO - 2016-02-26 08:44:39 --> Helper loaded: date_helper
INFO - 2016-02-26 08:44:39 --> Helper loaded: form_helper
INFO - 2016-02-26 08:44:39 --> Database Driver Class Initialized
INFO - 2016-02-26 08:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:44:40 --> Controller Class Initialized
INFO - 2016-02-26 08:44:40 --> Model Class Initialized
INFO - 2016-02-26 08:44:40 --> Model Class Initialized
INFO - 2016-02-26 08:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:44:40 --> Pagination Class Initialized
INFO - 2016-02-26 08:44:40 --> Helper loaded: text_helper
INFO - 2016-02-26 08:44:40 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:44:40 --> Final output sent to browser
DEBUG - 2016-02-26 11:44:40 --> Total execution time: 1.1497
INFO - 2016-02-26 08:45:18 --> Config Class Initialized
INFO - 2016-02-26 08:45:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:45:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:45:18 --> Utf8 Class Initialized
INFO - 2016-02-26 08:45:18 --> URI Class Initialized
INFO - 2016-02-26 08:45:18 --> Router Class Initialized
INFO - 2016-02-26 08:45:18 --> Output Class Initialized
INFO - 2016-02-26 08:45:18 --> Security Class Initialized
DEBUG - 2016-02-26 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:45:18 --> Input Class Initialized
INFO - 2016-02-26 08:45:18 --> Language Class Initialized
INFO - 2016-02-26 08:45:18 --> Loader Class Initialized
INFO - 2016-02-26 08:45:18 --> Helper loaded: url_helper
INFO - 2016-02-26 08:45:18 --> Helper loaded: file_helper
INFO - 2016-02-26 08:45:18 --> Helper loaded: date_helper
INFO - 2016-02-26 08:45:18 --> Helper loaded: form_helper
INFO - 2016-02-26 08:45:18 --> Database Driver Class Initialized
INFO - 2016-02-26 08:45:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:45:19 --> Controller Class Initialized
INFO - 2016-02-26 08:45:19 --> Model Class Initialized
INFO - 2016-02-26 08:45:19 --> Model Class Initialized
INFO - 2016-02-26 08:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:45:19 --> Pagination Class Initialized
INFO - 2016-02-26 08:45:19 --> Helper loaded: text_helper
INFO - 2016-02-26 08:45:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:45:19 --> Final output sent to browser
DEBUG - 2016-02-26 11:45:19 --> Total execution time: 1.1444
INFO - 2016-02-26 08:45:41 --> Config Class Initialized
INFO - 2016-02-26 08:45:41 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:45:41 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:45:41 --> Utf8 Class Initialized
INFO - 2016-02-26 08:45:41 --> URI Class Initialized
INFO - 2016-02-26 08:45:41 --> Router Class Initialized
INFO - 2016-02-26 08:45:41 --> Output Class Initialized
INFO - 2016-02-26 08:45:41 --> Security Class Initialized
DEBUG - 2016-02-26 08:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:45:41 --> Input Class Initialized
INFO - 2016-02-26 08:45:41 --> Language Class Initialized
INFO - 2016-02-26 08:45:41 --> Loader Class Initialized
INFO - 2016-02-26 08:45:41 --> Helper loaded: url_helper
INFO - 2016-02-26 08:45:41 --> Helper loaded: file_helper
INFO - 2016-02-26 08:45:41 --> Helper loaded: date_helper
INFO - 2016-02-26 08:45:41 --> Helper loaded: form_helper
INFO - 2016-02-26 08:45:41 --> Database Driver Class Initialized
INFO - 2016-02-26 08:45:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:45:42 --> Controller Class Initialized
INFO - 2016-02-26 08:45:42 --> Model Class Initialized
INFO - 2016-02-26 08:45:42 --> Model Class Initialized
INFO - 2016-02-26 08:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:45:42 --> Pagination Class Initialized
INFO - 2016-02-26 08:45:42 --> Helper loaded: text_helper
INFO - 2016-02-26 08:45:42 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:45:42 --> Final output sent to browser
DEBUG - 2016-02-26 11:45:42 --> Total execution time: 1.1789
INFO - 2016-02-26 08:45:53 --> Config Class Initialized
INFO - 2016-02-26 08:45:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:45:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:45:53 --> Utf8 Class Initialized
INFO - 2016-02-26 08:45:53 --> URI Class Initialized
INFO - 2016-02-26 08:45:53 --> Router Class Initialized
INFO - 2016-02-26 08:45:53 --> Output Class Initialized
INFO - 2016-02-26 08:45:53 --> Security Class Initialized
DEBUG - 2016-02-26 08:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:45:53 --> Input Class Initialized
INFO - 2016-02-26 08:45:53 --> Language Class Initialized
INFO - 2016-02-26 08:45:53 --> Loader Class Initialized
INFO - 2016-02-26 08:45:53 --> Helper loaded: url_helper
INFO - 2016-02-26 08:45:53 --> Helper loaded: file_helper
INFO - 2016-02-26 08:45:53 --> Helper loaded: date_helper
INFO - 2016-02-26 08:45:53 --> Helper loaded: form_helper
INFO - 2016-02-26 08:45:53 --> Database Driver Class Initialized
INFO - 2016-02-26 08:45:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:45:54 --> Controller Class Initialized
INFO - 2016-02-26 08:45:54 --> Model Class Initialized
INFO - 2016-02-26 08:45:54 --> Model Class Initialized
INFO - 2016-02-26 08:45:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:45:54 --> Pagination Class Initialized
INFO - 2016-02-26 08:45:54 --> Helper loaded: text_helper
INFO - 2016-02-26 08:45:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:45:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:45:54 --> Final output sent to browser
DEBUG - 2016-02-26 11:45:54 --> Total execution time: 1.1891
INFO - 2016-02-26 08:46:13 --> Config Class Initialized
INFO - 2016-02-26 08:46:13 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:46:13 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:46:13 --> Utf8 Class Initialized
INFO - 2016-02-26 08:46:13 --> URI Class Initialized
INFO - 2016-02-26 08:46:13 --> Router Class Initialized
INFO - 2016-02-26 08:46:13 --> Output Class Initialized
INFO - 2016-02-26 08:46:13 --> Security Class Initialized
DEBUG - 2016-02-26 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:46:13 --> Input Class Initialized
INFO - 2016-02-26 08:46:13 --> Language Class Initialized
INFO - 2016-02-26 08:46:13 --> Loader Class Initialized
INFO - 2016-02-26 08:46:13 --> Helper loaded: url_helper
INFO - 2016-02-26 08:46:13 --> Helper loaded: file_helper
INFO - 2016-02-26 08:46:13 --> Helper loaded: date_helper
INFO - 2016-02-26 08:46:13 --> Helper loaded: form_helper
INFO - 2016-02-26 08:46:13 --> Database Driver Class Initialized
INFO - 2016-02-26 08:46:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:46:14 --> Controller Class Initialized
INFO - 2016-02-26 08:46:14 --> Model Class Initialized
INFO - 2016-02-26 08:46:14 --> Model Class Initialized
INFO - 2016-02-26 08:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:46:14 --> Pagination Class Initialized
INFO - 2016-02-26 08:46:14 --> Helper loaded: text_helper
INFO - 2016-02-26 08:46:14 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:46:14 --> Final output sent to browser
DEBUG - 2016-02-26 11:46:14 --> Total execution time: 1.1989
INFO - 2016-02-26 08:46:17 --> Config Class Initialized
INFO - 2016-02-26 08:46:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:46:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:46:17 --> Utf8 Class Initialized
INFO - 2016-02-26 08:46:17 --> URI Class Initialized
INFO - 2016-02-26 08:46:17 --> Router Class Initialized
INFO - 2016-02-26 08:46:17 --> Output Class Initialized
INFO - 2016-02-26 08:46:17 --> Security Class Initialized
DEBUG - 2016-02-26 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:46:17 --> Input Class Initialized
INFO - 2016-02-26 08:46:17 --> Language Class Initialized
INFO - 2016-02-26 08:46:17 --> Loader Class Initialized
INFO - 2016-02-26 08:46:17 --> Helper loaded: url_helper
INFO - 2016-02-26 08:46:17 --> Helper loaded: file_helper
INFO - 2016-02-26 08:46:17 --> Helper loaded: date_helper
INFO - 2016-02-26 08:46:17 --> Helper loaded: form_helper
INFO - 2016-02-26 08:46:17 --> Database Driver Class Initialized
INFO - 2016-02-26 08:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:46:18 --> Controller Class Initialized
INFO - 2016-02-26 08:46:18 --> Model Class Initialized
INFO - 2016-02-26 08:46:18 --> Model Class Initialized
INFO - 2016-02-26 08:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:46:18 --> Pagination Class Initialized
INFO - 2016-02-26 08:46:18 --> Helper loaded: text_helper
INFO - 2016-02-26 08:46:18 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:46:18 --> Final output sent to browser
DEBUG - 2016-02-26 11:46:18 --> Total execution time: 1.1646
INFO - 2016-02-26 08:46:27 --> Config Class Initialized
INFO - 2016-02-26 08:46:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:46:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:46:27 --> Utf8 Class Initialized
INFO - 2016-02-26 08:46:27 --> URI Class Initialized
INFO - 2016-02-26 08:46:27 --> Router Class Initialized
INFO - 2016-02-26 08:46:27 --> Output Class Initialized
INFO - 2016-02-26 08:46:27 --> Security Class Initialized
DEBUG - 2016-02-26 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:46:27 --> Input Class Initialized
INFO - 2016-02-26 08:46:27 --> Language Class Initialized
INFO - 2016-02-26 08:46:27 --> Loader Class Initialized
INFO - 2016-02-26 08:46:27 --> Helper loaded: url_helper
INFO - 2016-02-26 08:46:27 --> Helper loaded: file_helper
INFO - 2016-02-26 08:46:27 --> Helper loaded: date_helper
INFO - 2016-02-26 08:46:27 --> Helper loaded: form_helper
INFO - 2016-02-26 08:46:27 --> Database Driver Class Initialized
INFO - 2016-02-26 08:46:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:46:28 --> Controller Class Initialized
INFO - 2016-02-26 08:46:28 --> Model Class Initialized
INFO - 2016-02-26 08:46:28 --> Model Class Initialized
INFO - 2016-02-26 08:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:46:28 --> Pagination Class Initialized
INFO - 2016-02-26 08:46:28 --> Helper loaded: text_helper
INFO - 2016-02-26 08:46:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:46:28 --> Final output sent to browser
DEBUG - 2016-02-26 11:46:28 --> Total execution time: 1.2008
INFO - 2016-02-26 08:47:29 --> Config Class Initialized
INFO - 2016-02-26 08:47:29 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:47:29 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:47:29 --> Utf8 Class Initialized
INFO - 2016-02-26 08:47:29 --> URI Class Initialized
INFO - 2016-02-26 08:47:29 --> Router Class Initialized
INFO - 2016-02-26 08:47:29 --> Output Class Initialized
INFO - 2016-02-26 08:47:29 --> Security Class Initialized
DEBUG - 2016-02-26 08:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:47:29 --> Input Class Initialized
INFO - 2016-02-26 08:47:29 --> Language Class Initialized
INFO - 2016-02-26 08:47:29 --> Loader Class Initialized
INFO - 2016-02-26 08:47:29 --> Helper loaded: url_helper
INFO - 2016-02-26 08:47:29 --> Helper loaded: file_helper
INFO - 2016-02-26 08:47:29 --> Helper loaded: date_helper
INFO - 2016-02-26 08:47:29 --> Helper loaded: form_helper
INFO - 2016-02-26 08:47:29 --> Database Driver Class Initialized
INFO - 2016-02-26 08:47:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:47:30 --> Controller Class Initialized
INFO - 2016-02-26 08:47:30 --> Model Class Initialized
INFO - 2016-02-26 08:47:30 --> Model Class Initialized
INFO - 2016-02-26 08:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:47:30 --> Pagination Class Initialized
INFO - 2016-02-26 08:47:30 --> Helper loaded: text_helper
INFO - 2016-02-26 08:47:30 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:47:30 --> Final output sent to browser
DEBUG - 2016-02-26 11:47:30 --> Total execution time: 1.1447
INFO - 2016-02-26 08:48:08 --> Config Class Initialized
INFO - 2016-02-26 08:48:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:48:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:48:08 --> Utf8 Class Initialized
INFO - 2016-02-26 08:48:08 --> URI Class Initialized
INFO - 2016-02-26 08:48:08 --> Router Class Initialized
INFO - 2016-02-26 08:48:08 --> Output Class Initialized
INFO - 2016-02-26 08:48:08 --> Security Class Initialized
DEBUG - 2016-02-26 08:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:48:08 --> Input Class Initialized
INFO - 2016-02-26 08:48:08 --> Language Class Initialized
INFO - 2016-02-26 08:48:08 --> Loader Class Initialized
INFO - 2016-02-26 08:48:08 --> Helper loaded: url_helper
INFO - 2016-02-26 08:48:08 --> Helper loaded: file_helper
INFO - 2016-02-26 08:48:08 --> Helper loaded: date_helper
INFO - 2016-02-26 08:48:08 --> Helper loaded: form_helper
INFO - 2016-02-26 08:48:08 --> Database Driver Class Initialized
INFO - 2016-02-26 08:48:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:48:09 --> Controller Class Initialized
INFO - 2016-02-26 08:48:09 --> Model Class Initialized
INFO - 2016-02-26 08:48:09 --> Model Class Initialized
INFO - 2016-02-26 08:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:48:09 --> Pagination Class Initialized
INFO - 2016-02-26 08:48:09 --> Helper loaded: text_helper
INFO - 2016-02-26 08:48:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:48:09 --> Final output sent to browser
DEBUG - 2016-02-26 11:48:09 --> Total execution time: 1.1792
INFO - 2016-02-26 08:49:09 --> Config Class Initialized
INFO - 2016-02-26 08:49:09 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:49:09 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:49:09 --> Utf8 Class Initialized
INFO - 2016-02-26 08:49:09 --> URI Class Initialized
INFO - 2016-02-26 08:49:09 --> Router Class Initialized
INFO - 2016-02-26 08:49:09 --> Output Class Initialized
INFO - 2016-02-26 08:49:09 --> Security Class Initialized
DEBUG - 2016-02-26 08:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:49:09 --> Input Class Initialized
INFO - 2016-02-26 08:49:09 --> Language Class Initialized
INFO - 2016-02-26 08:49:09 --> Loader Class Initialized
INFO - 2016-02-26 08:49:09 --> Helper loaded: url_helper
INFO - 2016-02-26 08:49:09 --> Helper loaded: file_helper
INFO - 2016-02-26 08:49:09 --> Helper loaded: date_helper
INFO - 2016-02-26 08:49:09 --> Helper loaded: form_helper
INFO - 2016-02-26 08:49:09 --> Database Driver Class Initialized
INFO - 2016-02-26 08:49:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:49:10 --> Controller Class Initialized
INFO - 2016-02-26 08:49:10 --> Model Class Initialized
INFO - 2016-02-26 08:49:10 --> Model Class Initialized
INFO - 2016-02-26 08:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:49:10 --> Pagination Class Initialized
INFO - 2016-02-26 08:49:10 --> Helper loaded: text_helper
INFO - 2016-02-26 08:49:10 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:49:10 --> Final output sent to browser
DEBUG - 2016-02-26 11:49:10 --> Total execution time: 1.1453
INFO - 2016-02-26 08:53:13 --> Config Class Initialized
INFO - 2016-02-26 08:53:14 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:53:14 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:53:14 --> Utf8 Class Initialized
INFO - 2016-02-26 08:53:14 --> URI Class Initialized
INFO - 2016-02-26 08:53:14 --> Router Class Initialized
INFO - 2016-02-26 08:53:14 --> Output Class Initialized
INFO - 2016-02-26 08:53:14 --> Security Class Initialized
DEBUG - 2016-02-26 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:53:14 --> Input Class Initialized
INFO - 2016-02-26 08:53:14 --> Language Class Initialized
INFO - 2016-02-26 08:53:14 --> Loader Class Initialized
INFO - 2016-02-26 08:53:14 --> Helper loaded: url_helper
INFO - 2016-02-26 08:53:14 --> Helper loaded: file_helper
INFO - 2016-02-26 08:53:14 --> Helper loaded: date_helper
INFO - 2016-02-26 08:53:14 --> Helper loaded: form_helper
INFO - 2016-02-26 08:53:14 --> Database Driver Class Initialized
INFO - 2016-02-26 08:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:53:15 --> Controller Class Initialized
INFO - 2016-02-26 08:53:15 --> Model Class Initialized
INFO - 2016-02-26 08:53:15 --> Model Class Initialized
INFO - 2016-02-26 08:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:53:15 --> Pagination Class Initialized
INFO - 2016-02-26 08:53:15 --> Helper loaded: text_helper
INFO - 2016-02-26 08:53:15 --> Helper loaded: cookie_helper
ERROR - 2016-02-26 11:53:15 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-26 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:53:15 --> Form Validation Class Initialized
INFO - 2016-02-26 11:53:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-26 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:53:15 --> Final output sent to browser
DEBUG - 2016-02-26 11:53:15 --> Total execution time: 1.2297
INFO - 2016-02-26 08:54:28 --> Config Class Initialized
INFO - 2016-02-26 08:54:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:54:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:54:28 --> Utf8 Class Initialized
INFO - 2016-02-26 08:54:28 --> URI Class Initialized
INFO - 2016-02-26 08:54:28 --> Router Class Initialized
INFO - 2016-02-26 08:54:28 --> Output Class Initialized
INFO - 2016-02-26 08:54:28 --> Security Class Initialized
DEBUG - 2016-02-26 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:54:28 --> Input Class Initialized
INFO - 2016-02-26 08:54:28 --> Language Class Initialized
INFO - 2016-02-26 08:54:28 --> Loader Class Initialized
INFO - 2016-02-26 08:54:28 --> Helper loaded: url_helper
INFO - 2016-02-26 08:54:28 --> Helper loaded: file_helper
INFO - 2016-02-26 08:54:28 --> Helper loaded: date_helper
INFO - 2016-02-26 08:54:28 --> Helper loaded: form_helper
INFO - 2016-02-26 08:54:28 --> Database Driver Class Initialized
INFO - 2016-02-26 08:54:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:54:29 --> Controller Class Initialized
INFO - 2016-02-26 08:54:29 --> Model Class Initialized
INFO - 2016-02-26 08:54:29 --> Model Class Initialized
INFO - 2016-02-26 08:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:54:29 --> Pagination Class Initialized
INFO - 2016-02-26 08:54:29 --> Helper loaded: text_helper
INFO - 2016-02-26 08:54:29 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:54:29 --> Final output sent to browser
DEBUG - 2016-02-26 11:54:29 --> Total execution time: 1.1782
INFO - 2016-02-26 08:54:38 --> Config Class Initialized
INFO - 2016-02-26 08:54:38 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:54:38 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:54:38 --> Utf8 Class Initialized
INFO - 2016-02-26 08:54:38 --> URI Class Initialized
INFO - 2016-02-26 08:54:38 --> Router Class Initialized
INFO - 2016-02-26 08:54:38 --> Output Class Initialized
INFO - 2016-02-26 08:54:38 --> Security Class Initialized
DEBUG - 2016-02-26 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:54:38 --> Input Class Initialized
INFO - 2016-02-26 08:54:38 --> Language Class Initialized
INFO - 2016-02-26 08:54:38 --> Loader Class Initialized
INFO - 2016-02-26 08:54:38 --> Helper loaded: url_helper
INFO - 2016-02-26 08:54:38 --> Helper loaded: file_helper
INFO - 2016-02-26 08:54:38 --> Helper loaded: date_helper
INFO - 2016-02-26 08:54:38 --> Helper loaded: form_helper
INFO - 2016-02-26 08:54:38 --> Database Driver Class Initialized
INFO - 2016-02-26 08:54:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:54:39 --> Controller Class Initialized
INFO - 2016-02-26 08:54:39 --> Model Class Initialized
INFO - 2016-02-26 08:54:39 --> Model Class Initialized
INFO - 2016-02-26 08:54:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:54:39 --> Pagination Class Initialized
INFO - 2016-02-26 08:54:39 --> Helper loaded: text_helper
INFO - 2016-02-26 08:54:39 --> Helper loaded: cookie_helper
ERROR - 2016-02-26 11:54:39 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-26 11:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:54:39 --> Form Validation Class Initialized
INFO - 2016-02-26 11:54:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-26 11:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:54:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:54:39 --> Final output sent to browser
DEBUG - 2016-02-26 11:54:39 --> Total execution time: 1.1602
INFO - 2016-02-26 08:55:45 --> Config Class Initialized
INFO - 2016-02-26 08:55:45 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:55:45 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:55:45 --> Utf8 Class Initialized
INFO - 2016-02-26 08:55:45 --> URI Class Initialized
INFO - 2016-02-26 08:55:45 --> Router Class Initialized
INFO - 2016-02-26 08:55:45 --> Output Class Initialized
INFO - 2016-02-26 08:55:45 --> Security Class Initialized
DEBUG - 2016-02-26 08:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:55:45 --> Input Class Initialized
INFO - 2016-02-26 08:55:45 --> Language Class Initialized
INFO - 2016-02-26 08:55:45 --> Loader Class Initialized
INFO - 2016-02-26 08:55:45 --> Helper loaded: url_helper
INFO - 2016-02-26 08:55:45 --> Helper loaded: file_helper
INFO - 2016-02-26 08:55:45 --> Helper loaded: date_helper
INFO - 2016-02-26 08:55:45 --> Helper loaded: form_helper
INFO - 2016-02-26 08:55:45 --> Database Driver Class Initialized
INFO - 2016-02-26 08:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:55:46 --> Controller Class Initialized
INFO - 2016-02-26 08:55:46 --> Model Class Initialized
INFO - 2016-02-26 08:55:46 --> Model Class Initialized
INFO - 2016-02-26 08:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:55:46 --> Pagination Class Initialized
INFO - 2016-02-26 08:55:46 --> Helper loaded: text_helper
INFO - 2016-02-26 08:55:46 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:55:46 --> Final output sent to browser
DEBUG - 2016-02-26 11:55:46 --> Total execution time: 1.1487
INFO - 2016-02-26 08:55:51 --> Config Class Initialized
INFO - 2016-02-26 08:55:51 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:55:51 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:55:51 --> Utf8 Class Initialized
INFO - 2016-02-26 08:55:51 --> URI Class Initialized
INFO - 2016-02-26 08:55:51 --> Router Class Initialized
INFO - 2016-02-26 08:55:51 --> Output Class Initialized
INFO - 2016-02-26 08:55:51 --> Security Class Initialized
DEBUG - 2016-02-26 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:55:51 --> Input Class Initialized
INFO - 2016-02-26 08:55:51 --> Language Class Initialized
INFO - 2016-02-26 08:55:51 --> Loader Class Initialized
INFO - 2016-02-26 08:55:51 --> Helper loaded: url_helper
INFO - 2016-02-26 08:55:51 --> Helper loaded: file_helper
INFO - 2016-02-26 08:55:51 --> Helper loaded: date_helper
INFO - 2016-02-26 08:55:51 --> Helper loaded: form_helper
INFO - 2016-02-26 08:55:51 --> Database Driver Class Initialized
INFO - 2016-02-26 08:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:55:52 --> Controller Class Initialized
INFO - 2016-02-26 08:55:52 --> Model Class Initialized
INFO - 2016-02-26 08:55:52 --> Model Class Initialized
INFO - 2016-02-26 08:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:55:52 --> Pagination Class Initialized
INFO - 2016-02-26 08:55:52 --> Helper loaded: text_helper
INFO - 2016-02-26 08:55:52 --> Helper loaded: cookie_helper
ERROR - 2016-02-26 11:55:52 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-26 11:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:55:52 --> Form Validation Class Initialized
INFO - 2016-02-26 11:55:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-26 08:55:53 --> Config Class Initialized
INFO - 2016-02-26 08:55:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:55:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:55:53 --> Utf8 Class Initialized
INFO - 2016-02-26 08:55:53 --> URI Class Initialized
INFO - 2016-02-26 08:55:53 --> Router Class Initialized
INFO - 2016-02-26 08:55:53 --> Output Class Initialized
INFO - 2016-02-26 08:55:53 --> Security Class Initialized
DEBUG - 2016-02-26 08:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:55:53 --> Input Class Initialized
INFO - 2016-02-26 08:55:53 --> Language Class Initialized
INFO - 2016-02-26 08:55:53 --> Loader Class Initialized
INFO - 2016-02-26 08:55:53 --> Helper loaded: url_helper
INFO - 2016-02-26 08:55:53 --> Helper loaded: file_helper
INFO - 2016-02-26 08:55:53 --> Helper loaded: date_helper
INFO - 2016-02-26 08:55:53 --> Helper loaded: form_helper
INFO - 2016-02-26 08:55:53 --> Database Driver Class Initialized
INFO - 2016-02-26 08:55:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:55:54 --> Controller Class Initialized
INFO - 2016-02-26 08:55:54 --> Model Class Initialized
INFO - 2016-02-26 08:55:54 --> Model Class Initialized
INFO - 2016-02-26 08:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:55:54 --> Pagination Class Initialized
INFO - 2016-02-26 08:55:54 --> Helper loaded: text_helper
INFO - 2016-02-26 08:55:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-26 11:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:55:54 --> Final output sent to browser
DEBUG - 2016-02-26 11:55:54 --> Total execution time: 1.2532
INFO - 2016-02-26 08:57:03 --> Config Class Initialized
INFO - 2016-02-26 08:57:03 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:57:03 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:57:03 --> Utf8 Class Initialized
INFO - 2016-02-26 08:57:03 --> URI Class Initialized
INFO - 2016-02-26 08:57:03 --> Router Class Initialized
INFO - 2016-02-26 08:57:03 --> Output Class Initialized
INFO - 2016-02-26 08:57:03 --> Security Class Initialized
DEBUG - 2016-02-26 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:57:03 --> Input Class Initialized
INFO - 2016-02-26 08:57:03 --> Language Class Initialized
INFO - 2016-02-26 08:57:03 --> Loader Class Initialized
INFO - 2016-02-26 08:57:03 --> Helper loaded: url_helper
INFO - 2016-02-26 08:57:03 --> Helper loaded: file_helper
INFO - 2016-02-26 08:57:03 --> Helper loaded: date_helper
INFO - 2016-02-26 08:57:03 --> Helper loaded: form_helper
INFO - 2016-02-26 08:57:03 --> Database Driver Class Initialized
INFO - 2016-02-26 08:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:57:04 --> Controller Class Initialized
INFO - 2016-02-26 08:57:04 --> Model Class Initialized
INFO - 2016-02-26 08:57:04 --> Model Class Initialized
INFO - 2016-02-26 08:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:57:04 --> Pagination Class Initialized
INFO - 2016-02-26 08:57:04 --> Helper loaded: text_helper
INFO - 2016-02-26 08:57:04 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-26 11:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:57:04 --> Final output sent to browser
DEBUG - 2016-02-26 11:57:04 --> Total execution time: 1.3536
INFO - 2016-02-26 08:57:16 --> Config Class Initialized
INFO - 2016-02-26 08:57:16 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:57:16 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:57:16 --> Utf8 Class Initialized
INFO - 2016-02-26 08:57:16 --> URI Class Initialized
INFO - 2016-02-26 08:57:16 --> Router Class Initialized
INFO - 2016-02-26 08:57:16 --> Output Class Initialized
INFO - 2016-02-26 08:57:16 --> Security Class Initialized
DEBUG - 2016-02-26 08:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:57:16 --> Input Class Initialized
INFO - 2016-02-26 08:57:16 --> Language Class Initialized
INFO - 2016-02-26 08:57:16 --> Loader Class Initialized
INFO - 2016-02-26 08:57:16 --> Helper loaded: url_helper
INFO - 2016-02-26 08:57:16 --> Helper loaded: file_helper
INFO - 2016-02-26 08:57:16 --> Helper loaded: date_helper
INFO - 2016-02-26 08:57:16 --> Helper loaded: form_helper
INFO - 2016-02-26 08:57:16 --> Database Driver Class Initialized
INFO - 2016-02-26 08:57:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:57:17 --> Controller Class Initialized
INFO - 2016-02-26 08:57:17 --> Model Class Initialized
INFO - 2016-02-26 08:57:17 --> Model Class Initialized
INFO - 2016-02-26 08:57:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:57:17 --> Pagination Class Initialized
INFO - 2016-02-26 08:57:17 --> Helper loaded: text_helper
INFO - 2016-02-26 08:57:17 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:57:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:57:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:57:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:57:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:57:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:57:17 --> Final output sent to browser
DEBUG - 2016-02-26 11:57:17 --> Total execution time: 1.1604
INFO - 2016-02-26 08:58:55 --> Config Class Initialized
INFO - 2016-02-26 08:58:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:58:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:58:55 --> Utf8 Class Initialized
INFO - 2016-02-26 08:58:55 --> URI Class Initialized
INFO - 2016-02-26 08:58:55 --> Router Class Initialized
INFO - 2016-02-26 08:58:55 --> Output Class Initialized
INFO - 2016-02-26 08:58:55 --> Security Class Initialized
DEBUG - 2016-02-26 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:58:55 --> Input Class Initialized
INFO - 2016-02-26 08:58:55 --> Language Class Initialized
INFO - 2016-02-26 08:58:55 --> Loader Class Initialized
INFO - 2016-02-26 08:58:55 --> Helper loaded: url_helper
INFO - 2016-02-26 08:58:55 --> Helper loaded: file_helper
INFO - 2016-02-26 08:58:55 --> Helper loaded: date_helper
INFO - 2016-02-26 08:58:55 --> Helper loaded: form_helper
INFO - 2016-02-26 08:58:55 --> Database Driver Class Initialized
INFO - 2016-02-26 08:58:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:58:56 --> Controller Class Initialized
INFO - 2016-02-26 08:58:56 --> Model Class Initialized
INFO - 2016-02-26 08:58:56 --> Model Class Initialized
INFO - 2016-02-26 08:58:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:58:56 --> Pagination Class Initialized
INFO - 2016-02-26 08:58:56 --> Helper loaded: text_helper
INFO - 2016-02-26 08:58:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 11:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 11:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:58:56 --> Final output sent to browser
DEBUG - 2016-02-26 11:58:56 --> Total execution time: 1.1292
INFO - 2016-02-26 08:58:58 --> Config Class Initialized
INFO - 2016-02-26 08:58:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:58:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:58:58 --> Utf8 Class Initialized
INFO - 2016-02-26 08:58:58 --> URI Class Initialized
INFO - 2016-02-26 08:58:58 --> Router Class Initialized
INFO - 2016-02-26 08:58:58 --> Output Class Initialized
INFO - 2016-02-26 08:58:58 --> Security Class Initialized
DEBUG - 2016-02-26 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:58:58 --> Input Class Initialized
INFO - 2016-02-26 08:58:58 --> Language Class Initialized
INFO - 2016-02-26 08:58:58 --> Loader Class Initialized
INFO - 2016-02-26 08:58:58 --> Helper loaded: url_helper
INFO - 2016-02-26 08:58:58 --> Helper loaded: file_helper
INFO - 2016-02-26 08:58:58 --> Helper loaded: date_helper
INFO - 2016-02-26 08:58:58 --> Helper loaded: form_helper
INFO - 2016-02-26 08:58:58 --> Database Driver Class Initialized
INFO - 2016-02-26 08:58:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:58:59 --> Controller Class Initialized
INFO - 2016-02-26 08:58:59 --> Model Class Initialized
INFO - 2016-02-26 08:58:59 --> Model Class Initialized
INFO - 2016-02-26 08:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:59:00 --> Pagination Class Initialized
INFO - 2016-02-26 08:59:00 --> Helper loaded: text_helper
INFO - 2016-02-26 08:59:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:59:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:59:00 --> Final output sent to browser
DEBUG - 2016-02-26 11:59:00 --> Total execution time: 1.1691
INFO - 2016-02-26 08:59:06 --> Config Class Initialized
INFO - 2016-02-26 08:59:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:59:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:59:06 --> Utf8 Class Initialized
INFO - 2016-02-26 08:59:06 --> URI Class Initialized
INFO - 2016-02-26 08:59:06 --> Router Class Initialized
INFO - 2016-02-26 08:59:06 --> Output Class Initialized
INFO - 2016-02-26 08:59:06 --> Security Class Initialized
DEBUG - 2016-02-26 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:59:06 --> Input Class Initialized
INFO - 2016-02-26 08:59:06 --> Language Class Initialized
INFO - 2016-02-26 08:59:06 --> Loader Class Initialized
INFO - 2016-02-26 08:59:06 --> Helper loaded: url_helper
INFO - 2016-02-26 08:59:06 --> Helper loaded: file_helper
INFO - 2016-02-26 08:59:06 --> Helper loaded: date_helper
INFO - 2016-02-26 08:59:06 --> Helper loaded: form_helper
INFO - 2016-02-26 08:59:06 --> Database Driver Class Initialized
INFO - 2016-02-26 08:59:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:59:07 --> Controller Class Initialized
INFO - 2016-02-26 08:59:07 --> Model Class Initialized
INFO - 2016-02-26 08:59:07 --> Model Class Initialized
INFO - 2016-02-26 08:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:59:07 --> Pagination Class Initialized
INFO - 2016-02-26 08:59:07 --> Helper loaded: text_helper
INFO - 2016-02-26 08:59:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:59:07 --> Final output sent to browser
DEBUG - 2016-02-26 11:59:07 --> Total execution time: 1.1279
INFO - 2016-02-26 08:59:09 --> Config Class Initialized
INFO - 2016-02-26 08:59:09 --> Hooks Class Initialized
DEBUG - 2016-02-26 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-02-26 08:59:09 --> Utf8 Class Initialized
INFO - 2016-02-26 08:59:09 --> URI Class Initialized
INFO - 2016-02-26 08:59:09 --> Router Class Initialized
INFO - 2016-02-26 08:59:09 --> Output Class Initialized
INFO - 2016-02-26 08:59:09 --> Security Class Initialized
DEBUG - 2016-02-26 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 08:59:09 --> Input Class Initialized
INFO - 2016-02-26 08:59:09 --> Language Class Initialized
INFO - 2016-02-26 08:59:09 --> Loader Class Initialized
INFO - 2016-02-26 08:59:09 --> Helper loaded: url_helper
INFO - 2016-02-26 08:59:09 --> Helper loaded: file_helper
INFO - 2016-02-26 08:59:09 --> Helper loaded: date_helper
INFO - 2016-02-26 08:59:09 --> Helper loaded: form_helper
INFO - 2016-02-26 08:59:09 --> Database Driver Class Initialized
INFO - 2016-02-26 08:59:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 08:59:10 --> Controller Class Initialized
INFO - 2016-02-26 08:59:10 --> Model Class Initialized
INFO - 2016-02-26 08:59:10 --> Model Class Initialized
INFO - 2016-02-26 08:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 08:59:10 --> Pagination Class Initialized
INFO - 2016-02-26 08:59:10 --> Helper loaded: text_helper
INFO - 2016-02-26 08:59:10 --> Helper loaded: cookie_helper
INFO - 2016-02-26 11:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 11:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 11:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 11:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 11:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 11:59:10 --> Final output sent to browser
DEBUG - 2016-02-26 11:59:10 --> Total execution time: 1.1571
INFO - 2016-02-26 09:00:29 --> Config Class Initialized
INFO - 2016-02-26 09:00:29 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:00:29 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:00:29 --> Utf8 Class Initialized
INFO - 2016-02-26 09:00:29 --> URI Class Initialized
INFO - 2016-02-26 09:00:29 --> Router Class Initialized
INFO - 2016-02-26 09:00:29 --> Output Class Initialized
INFO - 2016-02-26 09:00:29 --> Security Class Initialized
DEBUG - 2016-02-26 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:00:29 --> Input Class Initialized
INFO - 2016-02-26 09:00:29 --> Language Class Initialized
INFO - 2016-02-26 09:00:29 --> Loader Class Initialized
INFO - 2016-02-26 09:00:29 --> Helper loaded: url_helper
INFO - 2016-02-26 09:00:29 --> Helper loaded: file_helper
INFO - 2016-02-26 09:00:29 --> Helper loaded: date_helper
INFO - 2016-02-26 09:00:29 --> Helper loaded: form_helper
INFO - 2016-02-26 09:00:29 --> Database Driver Class Initialized
INFO - 2016-02-26 09:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:00:30 --> Controller Class Initialized
INFO - 2016-02-26 09:00:30 --> Model Class Initialized
INFO - 2016-02-26 09:00:30 --> Model Class Initialized
INFO - 2016-02-26 09:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:00:30 --> Pagination Class Initialized
INFO - 2016-02-26 09:00:30 --> Helper loaded: text_helper
INFO - 2016-02-26 09:00:30 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:00:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:00:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:00:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 12:00:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:00:30 --> Final output sent to browser
DEBUG - 2016-02-26 12:00:30 --> Total execution time: 1.1636
INFO - 2016-02-26 09:00:33 --> Config Class Initialized
INFO - 2016-02-26 09:00:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:00:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:00:33 --> Utf8 Class Initialized
INFO - 2016-02-26 09:00:33 --> URI Class Initialized
INFO - 2016-02-26 09:00:33 --> Router Class Initialized
INFO - 2016-02-26 09:00:33 --> Output Class Initialized
INFO - 2016-02-26 09:00:33 --> Security Class Initialized
DEBUG - 2016-02-26 09:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:00:33 --> Input Class Initialized
INFO - 2016-02-26 09:00:33 --> Language Class Initialized
INFO - 2016-02-26 09:00:33 --> Loader Class Initialized
INFO - 2016-02-26 09:00:33 --> Helper loaded: url_helper
INFO - 2016-02-26 09:00:33 --> Helper loaded: file_helper
INFO - 2016-02-26 09:00:33 --> Helper loaded: date_helper
INFO - 2016-02-26 09:00:33 --> Helper loaded: form_helper
INFO - 2016-02-26 09:00:33 --> Database Driver Class Initialized
INFO - 2016-02-26 09:00:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:00:34 --> Controller Class Initialized
INFO - 2016-02-26 09:00:34 --> Model Class Initialized
INFO - 2016-02-26 09:00:34 --> Model Class Initialized
INFO - 2016-02-26 09:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:00:34 --> Pagination Class Initialized
INFO - 2016-02-26 09:00:34 --> Helper loaded: text_helper
INFO - 2016-02-26 09:00:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:00:34 --> Final output sent to browser
DEBUG - 2016-02-26 12:00:34 --> Total execution time: 1.1441
INFO - 2016-02-26 09:00:43 --> Config Class Initialized
INFO - 2016-02-26 09:00:43 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:00:43 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:00:43 --> Utf8 Class Initialized
INFO - 2016-02-26 09:00:43 --> URI Class Initialized
INFO - 2016-02-26 09:00:43 --> Router Class Initialized
INFO - 2016-02-26 09:00:43 --> Output Class Initialized
INFO - 2016-02-26 09:00:43 --> Security Class Initialized
DEBUG - 2016-02-26 09:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:00:43 --> Input Class Initialized
INFO - 2016-02-26 09:00:43 --> Language Class Initialized
INFO - 2016-02-26 09:00:43 --> Loader Class Initialized
INFO - 2016-02-26 09:00:43 --> Helper loaded: url_helper
INFO - 2016-02-26 09:00:43 --> Helper loaded: file_helper
INFO - 2016-02-26 09:00:43 --> Helper loaded: date_helper
INFO - 2016-02-26 09:00:43 --> Helper loaded: form_helper
INFO - 2016-02-26 09:00:43 --> Database Driver Class Initialized
INFO - 2016-02-26 09:00:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:00:44 --> Controller Class Initialized
INFO - 2016-02-26 09:00:44 --> Model Class Initialized
INFO - 2016-02-26 09:00:44 --> Model Class Initialized
INFO - 2016-02-26 09:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:00:44 --> Pagination Class Initialized
INFO - 2016-02-26 09:00:44 --> Helper loaded: text_helper
INFO - 2016-02-26 09:00:44 --> Helper loaded: cookie_helper
ERROR - 2016-02-26 12:00:44 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-26 12:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:00:44 --> Form Validation Class Initialized
INFO - 2016-02-26 12:00:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-26 12:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:00:44 --> Final output sent to browser
DEBUG - 2016-02-26 12:00:44 --> Total execution time: 1.1659
INFO - 2016-02-26 09:05:34 --> Config Class Initialized
INFO - 2016-02-26 09:05:34 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:34 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:34 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:34 --> URI Class Initialized
DEBUG - 2016-02-26 09:05:34 --> No URI present. Default controller set.
INFO - 2016-02-26 09:05:34 --> Router Class Initialized
INFO - 2016-02-26 09:05:34 --> Output Class Initialized
INFO - 2016-02-26 09:05:34 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:34 --> Input Class Initialized
INFO - 2016-02-26 09:05:34 --> Language Class Initialized
INFO - 2016-02-26 09:05:34 --> Loader Class Initialized
INFO - 2016-02-26 09:05:34 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:34 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:34 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:34 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:34 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:35 --> Controller Class Initialized
INFO - 2016-02-26 09:05:35 --> Model Class Initialized
INFO - 2016-02-26 09:05:35 --> Model Class Initialized
INFO - 2016-02-26 09:05:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:35 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:35 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:35 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 12:05:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:36 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:36 --> Total execution time: 1.2335
INFO - 2016-02-26 09:05:41 --> Config Class Initialized
INFO - 2016-02-26 09:05:41 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:41 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:41 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:41 --> URI Class Initialized
DEBUG - 2016-02-26 09:05:41 --> No URI present. Default controller set.
INFO - 2016-02-26 09:05:41 --> Router Class Initialized
INFO - 2016-02-26 09:05:41 --> Output Class Initialized
INFO - 2016-02-26 09:05:41 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:41 --> Input Class Initialized
INFO - 2016-02-26 09:05:41 --> Language Class Initialized
INFO - 2016-02-26 09:05:41 --> Loader Class Initialized
INFO - 2016-02-26 09:05:41 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:41 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:41 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:41 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:41 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:42 --> Controller Class Initialized
INFO - 2016-02-26 09:05:42 --> Model Class Initialized
INFO - 2016-02-26 09:05:42 --> Model Class Initialized
INFO - 2016-02-26 09:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:42 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:42 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:42 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 12:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:42 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:42 --> Total execution time: 1.1854
INFO - 2016-02-26 09:05:44 --> Config Class Initialized
INFO - 2016-02-26 09:05:44 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:44 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:44 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:44 --> URI Class Initialized
INFO - 2016-02-26 09:05:44 --> Router Class Initialized
INFO - 2016-02-26 09:05:44 --> Output Class Initialized
INFO - 2016-02-26 09:05:44 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:44 --> Input Class Initialized
INFO - 2016-02-26 09:05:44 --> Language Class Initialized
INFO - 2016-02-26 09:05:44 --> Loader Class Initialized
INFO - 2016-02-26 09:05:44 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:44 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:44 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:44 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:44 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:45 --> Controller Class Initialized
INFO - 2016-02-26 09:05:45 --> Model Class Initialized
INFO - 2016-02-26 09:05:45 --> Model Class Initialized
INFO - 2016-02-26 09:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:45 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:45 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:45 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 12:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 12:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:45 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:45 --> Total execution time: 1.1550
INFO - 2016-02-26 09:05:47 --> Config Class Initialized
INFO - 2016-02-26 09:05:47 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:47 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:47 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:47 --> URI Class Initialized
INFO - 2016-02-26 09:05:47 --> Router Class Initialized
INFO - 2016-02-26 09:05:47 --> Output Class Initialized
INFO - 2016-02-26 09:05:47 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:47 --> Input Class Initialized
INFO - 2016-02-26 09:05:47 --> Language Class Initialized
INFO - 2016-02-26 09:05:47 --> Loader Class Initialized
INFO - 2016-02-26 09:05:47 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:47 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:47 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:47 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:47 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:48 --> Controller Class Initialized
INFO - 2016-02-26 09:05:48 --> Model Class Initialized
INFO - 2016-02-26 09:05:48 --> Model Class Initialized
INFO - 2016-02-26 09:05:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:48 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:48 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:48 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:05:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:48 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:48 --> Total execution time: 1.1429
INFO - 2016-02-26 09:05:55 --> Config Class Initialized
INFO - 2016-02-26 09:05:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:55 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:55 --> URI Class Initialized
INFO - 2016-02-26 09:05:55 --> Router Class Initialized
INFO - 2016-02-26 09:05:55 --> Output Class Initialized
INFO - 2016-02-26 09:05:55 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:55 --> Input Class Initialized
INFO - 2016-02-26 09:05:55 --> Language Class Initialized
INFO - 2016-02-26 09:05:55 --> Loader Class Initialized
INFO - 2016-02-26 09:05:55 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:55 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:55 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:55 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:55 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:56 --> Controller Class Initialized
INFO - 2016-02-26 09:05:56 --> Model Class Initialized
INFO - 2016-02-26 09:05:56 --> Model Class Initialized
INFO - 2016-02-26 09:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:56 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:56 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 12:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:56 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:56 --> Total execution time: 1.1721
INFO - 2016-02-26 09:05:58 --> Config Class Initialized
INFO - 2016-02-26 09:05:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:05:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:05:58 --> Utf8 Class Initialized
INFO - 2016-02-26 09:05:58 --> URI Class Initialized
INFO - 2016-02-26 09:05:58 --> Router Class Initialized
INFO - 2016-02-26 09:05:58 --> Output Class Initialized
INFO - 2016-02-26 09:05:58 --> Security Class Initialized
DEBUG - 2016-02-26 09:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:05:58 --> Input Class Initialized
INFO - 2016-02-26 09:05:58 --> Language Class Initialized
INFO - 2016-02-26 09:05:58 --> Loader Class Initialized
INFO - 2016-02-26 09:05:58 --> Helper loaded: url_helper
INFO - 2016-02-26 09:05:58 --> Helper loaded: file_helper
INFO - 2016-02-26 09:05:58 --> Helper loaded: date_helper
INFO - 2016-02-26 09:05:58 --> Helper loaded: form_helper
INFO - 2016-02-26 09:05:58 --> Database Driver Class Initialized
INFO - 2016-02-26 09:05:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:05:59 --> Controller Class Initialized
INFO - 2016-02-26 09:05:59 --> Model Class Initialized
INFO - 2016-02-26 09:05:59 --> Model Class Initialized
INFO - 2016-02-26 09:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:05:59 --> Pagination Class Initialized
INFO - 2016-02-26 09:05:59 --> Helper loaded: text_helper
INFO - 2016-02-26 09:05:59 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-26 12:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:05:59 --> Final output sent to browser
DEBUG - 2016-02-26 12:05:59 --> Total execution time: 1.1626
INFO - 2016-02-26 09:06:14 --> Config Class Initialized
INFO - 2016-02-26 09:06:14 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:06:14 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:06:14 --> Utf8 Class Initialized
INFO - 2016-02-26 09:06:14 --> URI Class Initialized
INFO - 2016-02-26 09:06:14 --> Router Class Initialized
INFO - 2016-02-26 09:06:14 --> Output Class Initialized
INFO - 2016-02-26 09:06:14 --> Security Class Initialized
DEBUG - 2016-02-26 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:06:14 --> Input Class Initialized
INFO - 2016-02-26 09:06:14 --> Language Class Initialized
INFO - 2016-02-26 09:06:14 --> Loader Class Initialized
INFO - 2016-02-26 09:06:14 --> Helper loaded: url_helper
INFO - 2016-02-26 09:06:14 --> Helper loaded: file_helper
INFO - 2016-02-26 09:06:14 --> Helper loaded: date_helper
INFO - 2016-02-26 09:06:14 --> Helper loaded: form_helper
INFO - 2016-02-26 09:06:14 --> Database Driver Class Initialized
INFO - 2016-02-26 09:06:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:06:15 --> Controller Class Initialized
INFO - 2016-02-26 09:06:15 --> Model Class Initialized
INFO - 2016-02-26 09:06:15 --> Model Class Initialized
INFO - 2016-02-26 09:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:06:15 --> Pagination Class Initialized
INFO - 2016-02-26 09:06:15 --> Helper loaded: text_helper
INFO - 2016-02-26 09:06:15 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:06:15 --> Final output sent to browser
DEBUG - 2016-02-26 12:06:15 --> Total execution time: 1.1366
INFO - 2016-02-26 09:07:33 --> Config Class Initialized
INFO - 2016-02-26 09:07:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:07:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:07:33 --> Utf8 Class Initialized
INFO - 2016-02-26 09:07:33 --> URI Class Initialized
INFO - 2016-02-26 09:07:33 --> Router Class Initialized
INFO - 2016-02-26 09:07:33 --> Output Class Initialized
INFO - 2016-02-26 09:07:33 --> Security Class Initialized
DEBUG - 2016-02-26 09:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:07:33 --> Input Class Initialized
INFO - 2016-02-26 09:07:33 --> Language Class Initialized
INFO - 2016-02-26 09:07:33 --> Loader Class Initialized
INFO - 2016-02-26 09:07:33 --> Helper loaded: url_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: file_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: date_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: form_helper
INFO - 2016-02-26 09:07:33 --> Database Driver Class Initialized
INFO - 2016-02-26 09:07:33 --> Config Class Initialized
INFO - 2016-02-26 09:07:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:07:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:07:33 --> Utf8 Class Initialized
INFO - 2016-02-26 09:07:33 --> URI Class Initialized
INFO - 2016-02-26 09:07:33 --> Router Class Initialized
INFO - 2016-02-26 09:07:33 --> Output Class Initialized
INFO - 2016-02-26 09:07:33 --> Security Class Initialized
DEBUG - 2016-02-26 09:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:07:33 --> Input Class Initialized
INFO - 2016-02-26 09:07:33 --> Language Class Initialized
INFO - 2016-02-26 09:07:33 --> Loader Class Initialized
INFO - 2016-02-26 09:07:33 --> Helper loaded: url_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: file_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: date_helper
INFO - 2016-02-26 09:07:33 --> Helper loaded: form_helper
INFO - 2016-02-26 09:07:33 --> Database Driver Class Initialized
INFO - 2016-02-26 09:07:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:07:34 --> Controller Class Initialized
INFO - 2016-02-26 09:07:34 --> Model Class Initialized
INFO - 2016-02-26 09:07:34 --> Model Class Initialized
INFO - 2016-02-26 09:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:07:34 --> Pagination Class Initialized
INFO - 2016-02-26 09:07:34 --> Helper loaded: text_helper
INFO - 2016-02-26 09:07:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:07:34 --> Final output sent to browser
DEBUG - 2016-02-26 12:07:34 --> Total execution time: 1.1628
INFO - 2016-02-26 09:07:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:07:34 --> Controller Class Initialized
INFO - 2016-02-26 09:07:34 --> Model Class Initialized
INFO - 2016-02-26 09:07:34 --> Model Class Initialized
INFO - 2016-02-26 09:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:07:34 --> Pagination Class Initialized
INFO - 2016-02-26 09:07:34 --> Helper loaded: text_helper
INFO - 2016-02-26 09:07:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:07:34 --> Final output sent to browser
DEBUG - 2016-02-26 12:07:34 --> Total execution time: 1.1605
INFO - 2016-02-26 09:07:37 --> Config Class Initialized
INFO - 2016-02-26 09:07:37 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:07:37 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:07:37 --> Utf8 Class Initialized
INFO - 2016-02-26 09:07:37 --> URI Class Initialized
INFO - 2016-02-26 09:07:37 --> Router Class Initialized
INFO - 2016-02-26 09:07:37 --> Output Class Initialized
INFO - 2016-02-26 09:07:37 --> Security Class Initialized
DEBUG - 2016-02-26 09:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:07:37 --> Input Class Initialized
INFO - 2016-02-26 09:07:37 --> Language Class Initialized
INFO - 2016-02-26 09:07:37 --> Loader Class Initialized
INFO - 2016-02-26 09:07:37 --> Helper loaded: url_helper
INFO - 2016-02-26 09:07:37 --> Helper loaded: file_helper
INFO - 2016-02-26 09:07:37 --> Helper loaded: date_helper
INFO - 2016-02-26 09:07:37 --> Helper loaded: form_helper
INFO - 2016-02-26 09:07:37 --> Database Driver Class Initialized
INFO - 2016-02-26 09:07:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:07:38 --> Controller Class Initialized
INFO - 2016-02-26 09:07:38 --> Model Class Initialized
INFO - 2016-02-26 09:07:38 --> Model Class Initialized
INFO - 2016-02-26 09:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:07:38 --> Pagination Class Initialized
INFO - 2016-02-26 09:07:38 --> Helper loaded: text_helper
INFO - 2016-02-26 09:07:38 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:07:38 --> Final output sent to browser
DEBUG - 2016-02-26 12:07:38 --> Total execution time: 1.1230
INFO - 2016-02-26 09:22:24 --> Config Class Initialized
INFO - 2016-02-26 09:22:24 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:22:24 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:22:24 --> Utf8 Class Initialized
INFO - 2016-02-26 09:22:24 --> URI Class Initialized
INFO - 2016-02-26 09:22:24 --> Router Class Initialized
INFO - 2016-02-26 09:22:24 --> Output Class Initialized
INFO - 2016-02-26 09:22:24 --> Security Class Initialized
DEBUG - 2016-02-26 09:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:22:24 --> Input Class Initialized
INFO - 2016-02-26 09:22:24 --> Language Class Initialized
INFO - 2016-02-26 09:22:24 --> Loader Class Initialized
INFO - 2016-02-26 09:22:24 --> Helper loaded: url_helper
INFO - 2016-02-26 09:22:24 --> Helper loaded: file_helper
INFO - 2016-02-26 09:22:24 --> Helper loaded: date_helper
INFO - 2016-02-26 09:22:24 --> Helper loaded: form_helper
INFO - 2016-02-26 09:22:24 --> Database Driver Class Initialized
INFO - 2016-02-26 09:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:22:25 --> Controller Class Initialized
INFO - 2016-02-26 09:22:25 --> Model Class Initialized
INFO - 2016-02-26 09:22:25 --> Model Class Initialized
INFO - 2016-02-26 09:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:22:25 --> Pagination Class Initialized
INFO - 2016-02-26 09:22:25 --> Helper loaded: text_helper
INFO - 2016-02-26 09:22:25 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:22:25 --> Upload Class Initialized
INFO - 2016-02-26 12:22:25 --> Image Lib Class Initialized
DEBUG - 2016-02-26 12:22:25 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 12:22:25 --> Final output sent to browser
DEBUG - 2016-02-26 12:22:25 --> Total execution time: 1.1589
INFO - 2016-02-26 09:36:27 --> Config Class Initialized
INFO - 2016-02-26 09:36:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:36:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:36:27 --> Utf8 Class Initialized
INFO - 2016-02-26 09:36:27 --> URI Class Initialized
INFO - 2016-02-26 09:36:27 --> Router Class Initialized
INFO - 2016-02-26 09:36:27 --> Output Class Initialized
INFO - 2016-02-26 09:36:27 --> Security Class Initialized
DEBUG - 2016-02-26 09:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:36:27 --> Input Class Initialized
INFO - 2016-02-26 09:36:27 --> Language Class Initialized
INFO - 2016-02-26 09:36:27 --> Loader Class Initialized
INFO - 2016-02-26 09:36:27 --> Helper loaded: url_helper
INFO - 2016-02-26 09:36:27 --> Helper loaded: file_helper
INFO - 2016-02-26 09:36:27 --> Helper loaded: date_helper
INFO - 2016-02-26 09:36:27 --> Helper loaded: form_helper
INFO - 2016-02-26 09:36:27 --> Database Driver Class Initialized
INFO - 2016-02-26 09:36:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:36:28 --> Controller Class Initialized
INFO - 2016-02-26 09:36:28 --> Model Class Initialized
INFO - 2016-02-26 09:36:28 --> Model Class Initialized
INFO - 2016-02-26 09:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:36:28 --> Pagination Class Initialized
INFO - 2016-02-26 09:36:28 --> Helper loaded: text_helper
INFO - 2016-02-26 09:36:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:36:28 --> Final output sent to browser
DEBUG - 2016-02-26 12:36:28 --> Total execution time: 1.2081
INFO - 2016-02-26 09:49:26 --> Config Class Initialized
INFO - 2016-02-26 09:49:26 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:49:26 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:49:26 --> Utf8 Class Initialized
INFO - 2016-02-26 09:49:26 --> URI Class Initialized
INFO - 2016-02-26 09:49:26 --> Router Class Initialized
INFO - 2016-02-26 09:49:26 --> Output Class Initialized
INFO - 2016-02-26 09:49:26 --> Security Class Initialized
DEBUG - 2016-02-26 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:49:27 --> Input Class Initialized
INFO - 2016-02-26 09:49:27 --> Language Class Initialized
INFO - 2016-02-26 09:49:27 --> Loader Class Initialized
INFO - 2016-02-26 09:49:27 --> Helper loaded: url_helper
INFO - 2016-02-26 09:49:27 --> Helper loaded: file_helper
INFO - 2016-02-26 09:49:27 --> Helper loaded: date_helper
INFO - 2016-02-26 09:49:27 --> Helper loaded: form_helper
INFO - 2016-02-26 09:49:27 --> Database Driver Class Initialized
INFO - 2016-02-26 09:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:49:28 --> Controller Class Initialized
INFO - 2016-02-26 09:49:28 --> Model Class Initialized
INFO - 2016-02-26 09:49:28 --> Model Class Initialized
INFO - 2016-02-26 09:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:49:28 --> Pagination Class Initialized
INFO - 2016-02-26 09:49:28 --> Helper loaded: text_helper
INFO - 2016-02-26 09:49:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:49:28 --> Final output sent to browser
DEBUG - 2016-02-26 12:49:28 --> Total execution time: 1.1694
INFO - 2016-02-26 09:52:50 --> Config Class Initialized
INFO - 2016-02-26 09:52:50 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:52:50 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:52:50 --> Utf8 Class Initialized
INFO - 2016-02-26 09:52:50 --> URI Class Initialized
INFO - 2016-02-26 09:52:50 --> Router Class Initialized
INFO - 2016-02-26 09:52:50 --> Output Class Initialized
INFO - 2016-02-26 09:52:50 --> Security Class Initialized
DEBUG - 2016-02-26 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:52:50 --> Input Class Initialized
INFO - 2016-02-26 09:52:50 --> Language Class Initialized
INFO - 2016-02-26 09:52:50 --> Loader Class Initialized
INFO - 2016-02-26 09:52:50 --> Helper loaded: url_helper
INFO - 2016-02-26 09:52:50 --> Helper loaded: file_helper
INFO - 2016-02-26 09:52:50 --> Helper loaded: date_helper
INFO - 2016-02-26 09:52:50 --> Helper loaded: form_helper
INFO - 2016-02-26 09:52:50 --> Database Driver Class Initialized
INFO - 2016-02-26 09:52:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:52:51 --> Controller Class Initialized
INFO - 2016-02-26 09:52:51 --> Model Class Initialized
INFO - 2016-02-26 09:52:51 --> Model Class Initialized
INFO - 2016-02-26 09:52:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:52:51 --> Pagination Class Initialized
INFO - 2016-02-26 09:52:51 --> Helper loaded: text_helper
INFO - 2016-02-26 09:52:51 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:52:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:52:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:52:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:52:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:52:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:52:51 --> Final output sent to browser
DEBUG - 2016-02-26 12:52:51 --> Total execution time: 1.1703
INFO - 2016-02-26 09:53:04 --> Config Class Initialized
INFO - 2016-02-26 09:53:04 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:53:04 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:53:04 --> Utf8 Class Initialized
INFO - 2016-02-26 09:53:04 --> URI Class Initialized
INFO - 2016-02-26 09:53:04 --> Router Class Initialized
INFO - 2016-02-26 09:53:04 --> Output Class Initialized
INFO - 2016-02-26 09:53:04 --> Security Class Initialized
DEBUG - 2016-02-26 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:53:04 --> Input Class Initialized
INFO - 2016-02-26 09:53:04 --> Language Class Initialized
INFO - 2016-02-26 09:53:04 --> Loader Class Initialized
INFO - 2016-02-26 09:53:04 --> Helper loaded: url_helper
INFO - 2016-02-26 09:53:04 --> Helper loaded: file_helper
INFO - 2016-02-26 09:53:04 --> Helper loaded: date_helper
INFO - 2016-02-26 09:53:04 --> Helper loaded: form_helper
INFO - 2016-02-26 09:53:04 --> Database Driver Class Initialized
INFO - 2016-02-26 09:53:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:53:05 --> Controller Class Initialized
INFO - 2016-02-26 09:53:05 --> Model Class Initialized
INFO - 2016-02-26 09:53:05 --> Model Class Initialized
INFO - 2016-02-26 09:53:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:53:05 --> Pagination Class Initialized
INFO - 2016-02-26 09:53:05 --> Helper loaded: text_helper
INFO - 2016-02-26 09:53:05 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:53:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:53:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:53:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:53:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:53:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:53:05 --> Final output sent to browser
DEBUG - 2016-02-26 12:53:05 --> Total execution time: 1.1395
INFO - 2016-02-26 09:53:05 --> Config Class Initialized
INFO - 2016-02-26 09:53:05 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:53:05 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:53:05 --> Utf8 Class Initialized
INFO - 2016-02-26 09:53:05 --> URI Class Initialized
INFO - 2016-02-26 09:53:05 --> Router Class Initialized
INFO - 2016-02-26 09:53:05 --> Output Class Initialized
INFO - 2016-02-26 09:53:05 --> Security Class Initialized
DEBUG - 2016-02-26 09:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:53:05 --> Input Class Initialized
INFO - 2016-02-26 09:53:05 --> Language Class Initialized
INFO - 2016-02-26 09:53:05 --> Loader Class Initialized
INFO - 2016-02-26 09:53:05 --> Helper loaded: url_helper
INFO - 2016-02-26 09:53:05 --> Helper loaded: file_helper
INFO - 2016-02-26 09:53:05 --> Helper loaded: date_helper
INFO - 2016-02-26 09:53:05 --> Helper loaded: form_helper
INFO - 2016-02-26 09:53:05 --> Database Driver Class Initialized
INFO - 2016-02-26 09:53:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:53:06 --> Controller Class Initialized
INFO - 2016-02-26 09:53:06 --> Model Class Initialized
INFO - 2016-02-26 09:53:06 --> Model Class Initialized
INFO - 2016-02-26 09:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:53:06 --> Pagination Class Initialized
INFO - 2016-02-26 09:53:06 --> Helper loaded: text_helper
INFO - 2016-02-26 09:53:06 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:53:06 --> Final output sent to browser
DEBUG - 2016-02-26 12:53:06 --> Total execution time: 1.1565
INFO - 2016-02-26 09:54:21 --> Config Class Initialized
INFO - 2016-02-26 09:54:21 --> Hooks Class Initialized
DEBUG - 2016-02-26 09:54:21 --> UTF-8 Support Enabled
INFO - 2016-02-26 09:54:21 --> Utf8 Class Initialized
INFO - 2016-02-26 09:54:21 --> URI Class Initialized
INFO - 2016-02-26 09:54:21 --> Router Class Initialized
INFO - 2016-02-26 09:54:21 --> Output Class Initialized
INFO - 2016-02-26 09:54:21 --> Security Class Initialized
DEBUG - 2016-02-26 09:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 09:54:21 --> Input Class Initialized
INFO - 2016-02-26 09:54:21 --> Language Class Initialized
INFO - 2016-02-26 09:54:21 --> Loader Class Initialized
INFO - 2016-02-26 09:54:21 --> Helper loaded: url_helper
INFO - 2016-02-26 09:54:21 --> Helper loaded: file_helper
INFO - 2016-02-26 09:54:21 --> Helper loaded: date_helper
INFO - 2016-02-26 09:54:21 --> Helper loaded: form_helper
INFO - 2016-02-26 09:54:21 --> Database Driver Class Initialized
INFO - 2016-02-26 09:54:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 09:54:22 --> Controller Class Initialized
INFO - 2016-02-26 09:54:22 --> Model Class Initialized
INFO - 2016-02-26 09:54:22 --> Model Class Initialized
INFO - 2016-02-26 09:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 09:54:22 --> Pagination Class Initialized
INFO - 2016-02-26 09:54:22 --> Helper loaded: text_helper
INFO - 2016-02-26 09:54:22 --> Helper loaded: cookie_helper
INFO - 2016-02-26 12:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 12:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 12:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 12:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 12:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 12:54:22 --> Final output sent to browser
DEBUG - 2016-02-26 12:54:22 --> Total execution time: 1.1241
INFO - 2016-02-26 10:14:17 --> Config Class Initialized
INFO - 2016-02-26 10:14:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:14:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:14:17 --> Utf8 Class Initialized
INFO - 2016-02-26 10:14:17 --> URI Class Initialized
INFO - 2016-02-26 10:14:17 --> Router Class Initialized
INFO - 2016-02-26 10:14:17 --> Output Class Initialized
INFO - 2016-02-26 10:14:17 --> Security Class Initialized
DEBUG - 2016-02-26 10:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:14:17 --> Input Class Initialized
INFO - 2016-02-26 10:14:18 --> Language Class Initialized
INFO - 2016-02-26 10:14:18 --> Loader Class Initialized
INFO - 2016-02-26 10:14:18 --> Helper loaded: url_helper
INFO - 2016-02-26 10:14:18 --> Helper loaded: file_helper
INFO - 2016-02-26 10:14:18 --> Helper loaded: date_helper
INFO - 2016-02-26 10:14:18 --> Helper loaded: form_helper
INFO - 2016-02-26 10:14:18 --> Database Driver Class Initialized
INFO - 2016-02-26 10:14:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:14:19 --> Controller Class Initialized
INFO - 2016-02-26 10:14:19 --> Model Class Initialized
INFO - 2016-02-26 10:14:19 --> Model Class Initialized
INFO - 2016-02-26 10:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:14:19 --> Pagination Class Initialized
INFO - 2016-02-26 10:14:19 --> Helper loaded: text_helper
INFO - 2016-02-26 10:14:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:14:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:14:19 --> Final output sent to browser
DEBUG - 2016-02-26 13:14:19 --> Total execution time: 1.1547
INFO - 2016-02-26 10:14:19 --> Config Class Initialized
INFO - 2016-02-26 10:14:19 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:14:19 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:14:19 --> Utf8 Class Initialized
INFO - 2016-02-26 10:14:19 --> URI Class Initialized
INFO - 2016-02-26 10:14:19 --> Router Class Initialized
INFO - 2016-02-26 10:14:19 --> Output Class Initialized
INFO - 2016-02-26 10:14:19 --> Security Class Initialized
DEBUG - 2016-02-26 10:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:14:19 --> Input Class Initialized
INFO - 2016-02-26 10:14:19 --> Language Class Initialized
INFO - 2016-02-26 10:14:19 --> Loader Class Initialized
INFO - 2016-02-26 10:14:19 --> Helper loaded: url_helper
INFO - 2016-02-26 10:14:19 --> Helper loaded: file_helper
INFO - 2016-02-26 10:14:19 --> Helper loaded: date_helper
INFO - 2016-02-26 10:14:19 --> Helper loaded: form_helper
INFO - 2016-02-26 10:14:19 --> Database Driver Class Initialized
INFO - 2016-02-26 10:14:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:14:20 --> Controller Class Initialized
INFO - 2016-02-26 10:14:20 --> Model Class Initialized
INFO - 2016-02-26 10:14:20 --> Model Class Initialized
INFO - 2016-02-26 10:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:14:20 --> Pagination Class Initialized
INFO - 2016-02-26 10:14:20 --> Helper loaded: text_helper
INFO - 2016-02-26 10:14:20 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:14:20 --> Final output sent to browser
DEBUG - 2016-02-26 13:14:20 --> Total execution time: 1.1672
INFO - 2016-02-26 10:14:39 --> Config Class Initialized
INFO - 2016-02-26 10:14:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:14:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:14:39 --> Utf8 Class Initialized
INFO - 2016-02-26 10:14:39 --> URI Class Initialized
INFO - 2016-02-26 10:14:39 --> Router Class Initialized
INFO - 2016-02-26 10:14:39 --> Output Class Initialized
INFO - 2016-02-26 10:14:39 --> Security Class Initialized
DEBUG - 2016-02-26 10:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:14:39 --> Input Class Initialized
INFO - 2016-02-26 10:14:39 --> Language Class Initialized
INFO - 2016-02-26 10:14:39 --> Loader Class Initialized
INFO - 2016-02-26 10:14:39 --> Helper loaded: url_helper
INFO - 2016-02-26 10:14:39 --> Helper loaded: file_helper
INFO - 2016-02-26 10:14:39 --> Helper loaded: date_helper
INFO - 2016-02-26 10:14:39 --> Helper loaded: form_helper
INFO - 2016-02-26 10:14:39 --> Database Driver Class Initialized
INFO - 2016-02-26 10:14:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:14:40 --> Controller Class Initialized
INFO - 2016-02-26 10:14:40 --> Model Class Initialized
INFO - 2016-02-26 10:14:40 --> Model Class Initialized
INFO - 2016-02-26 10:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:14:40 --> Pagination Class Initialized
INFO - 2016-02-26 10:14:40 --> Helper loaded: text_helper
INFO - 2016-02-26 10:14:40 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:14:40 --> Final output sent to browser
DEBUG - 2016-02-26 13:14:40 --> Total execution time: 1.0982
INFO - 2016-02-26 10:14:44 --> Config Class Initialized
INFO - 2016-02-26 10:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:14:44 --> Utf8 Class Initialized
INFO - 2016-02-26 10:14:44 --> URI Class Initialized
INFO - 2016-02-26 10:14:44 --> Router Class Initialized
INFO - 2016-02-26 10:14:44 --> Output Class Initialized
INFO - 2016-02-26 10:14:44 --> Security Class Initialized
DEBUG - 2016-02-26 10:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:14:44 --> Input Class Initialized
INFO - 2016-02-26 10:14:44 --> Language Class Initialized
INFO - 2016-02-26 10:14:44 --> Loader Class Initialized
INFO - 2016-02-26 10:14:44 --> Helper loaded: url_helper
INFO - 2016-02-26 10:14:44 --> Helper loaded: file_helper
INFO - 2016-02-26 10:14:44 --> Helper loaded: date_helper
INFO - 2016-02-26 10:14:44 --> Helper loaded: form_helper
INFO - 2016-02-26 10:14:44 --> Database Driver Class Initialized
INFO - 2016-02-26 10:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:14:45 --> Controller Class Initialized
INFO - 2016-02-26 10:14:45 --> Model Class Initialized
INFO - 2016-02-26 10:14:45 --> Model Class Initialized
INFO - 2016-02-26 10:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:14:45 --> Pagination Class Initialized
INFO - 2016-02-26 10:14:45 --> Helper loaded: text_helper
INFO - 2016-02-26 10:14:46 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:14:46 --> Upload Class Initialized
INFO - 2016-02-26 13:14:46 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:14:46 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:14:46 --> Final output sent to browser
DEBUG - 2016-02-26 13:14:46 --> Total execution time: 1.1581
INFO - 2016-02-26 10:15:14 --> Config Class Initialized
INFO - 2016-02-26 10:15:14 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:14 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:14 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:14 --> URI Class Initialized
INFO - 2016-02-26 10:15:14 --> Router Class Initialized
INFO - 2016-02-26 10:15:14 --> Output Class Initialized
INFO - 2016-02-26 10:15:14 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:14 --> Input Class Initialized
INFO - 2016-02-26 10:15:14 --> Language Class Initialized
INFO - 2016-02-26 10:15:14 --> Loader Class Initialized
INFO - 2016-02-26 10:15:14 --> Helper loaded: url_helper
INFO - 2016-02-26 10:15:14 --> Helper loaded: file_helper
INFO - 2016-02-26 10:15:14 --> Helper loaded: date_helper
INFO - 2016-02-26 10:15:14 --> Helper loaded: form_helper
INFO - 2016-02-26 10:15:14 --> Database Driver Class Initialized
INFO - 2016-02-26 10:15:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:15:15 --> Controller Class Initialized
INFO - 2016-02-26 10:15:15 --> Model Class Initialized
INFO - 2016-02-26 10:15:15 --> Model Class Initialized
INFO - 2016-02-26 10:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:15:15 --> Pagination Class Initialized
INFO - 2016-02-26 10:15:15 --> Helper loaded: text_helper
INFO - 2016-02-26 10:15:15 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:15:16 --> Final output sent to browser
DEBUG - 2016-02-26 13:15:16 --> Total execution time: 1.1509
INFO - 2016-02-26 10:15:16 --> Config Class Initialized
INFO - 2016-02-26 10:15:16 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:16 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:16 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:16 --> URI Class Initialized
INFO - 2016-02-26 10:15:16 --> Router Class Initialized
INFO - 2016-02-26 10:15:16 --> Output Class Initialized
INFO - 2016-02-26 10:15:16 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:16 --> Input Class Initialized
INFO - 2016-02-26 10:15:16 --> Language Class Initialized
INFO - 2016-02-26 10:15:16 --> Loader Class Initialized
INFO - 2016-02-26 10:15:16 --> Helper loaded: url_helper
INFO - 2016-02-26 10:15:16 --> Helper loaded: file_helper
INFO - 2016-02-26 10:15:16 --> Helper loaded: date_helper
INFO - 2016-02-26 10:15:16 --> Helper loaded: form_helper
INFO - 2016-02-26 10:15:16 --> Database Driver Class Initialized
INFO - 2016-02-26 10:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:15:17 --> Controller Class Initialized
INFO - 2016-02-26 10:15:17 --> Model Class Initialized
INFO - 2016-02-26 10:15:17 --> Model Class Initialized
INFO - 2016-02-26 10:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:15:17 --> Pagination Class Initialized
INFO - 2016-02-26 10:15:17 --> Helper loaded: text_helper
INFO - 2016-02-26 10:15:17 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:15:17 --> Final output sent to browser
DEBUG - 2016-02-26 13:15:17 --> Total execution time: 1.1570
INFO - 2016-02-26 10:15:38 --> Config Class Initialized
INFO - 2016-02-26 10:15:38 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:38 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:38 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:38 --> URI Class Initialized
INFO - 2016-02-26 10:15:38 --> Router Class Initialized
INFO - 2016-02-26 10:15:38 --> Output Class Initialized
INFO - 2016-02-26 10:15:38 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:38 --> Input Class Initialized
INFO - 2016-02-26 10:15:38 --> Language Class Initialized
INFO - 2016-02-26 10:15:38 --> Loader Class Initialized
INFO - 2016-02-26 10:15:38 --> Helper loaded: url_helper
INFO - 2016-02-26 10:15:38 --> Helper loaded: file_helper
INFO - 2016-02-26 10:15:38 --> Helper loaded: date_helper
INFO - 2016-02-26 10:15:38 --> Helper loaded: form_helper
INFO - 2016-02-26 10:15:38 --> Database Driver Class Initialized
INFO - 2016-02-26 10:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:15:39 --> Controller Class Initialized
INFO - 2016-02-26 10:15:39 --> Model Class Initialized
INFO - 2016-02-26 10:15:39 --> Model Class Initialized
INFO - 2016-02-26 10:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:15:39 --> Pagination Class Initialized
INFO - 2016-02-26 10:15:39 --> Helper loaded: text_helper
INFO - 2016-02-26 10:15:39 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:15:39 --> Final output sent to browser
DEBUG - 2016-02-26 13:15:39 --> Total execution time: 1.1216
INFO - 2016-02-26 10:15:40 --> Config Class Initialized
INFO - 2016-02-26 10:15:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:40 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:40 --> URI Class Initialized
INFO - 2016-02-26 10:15:40 --> Router Class Initialized
INFO - 2016-02-26 10:15:40 --> Output Class Initialized
INFO - 2016-02-26 10:15:40 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:40 --> Input Class Initialized
INFO - 2016-02-26 10:15:40 --> Language Class Initialized
INFO - 2016-02-26 10:15:40 --> Loader Class Initialized
INFO - 2016-02-26 10:15:40 --> Helper loaded: url_helper
INFO - 2016-02-26 10:15:40 --> Helper loaded: file_helper
INFO - 2016-02-26 10:15:40 --> Helper loaded: date_helper
INFO - 2016-02-26 10:15:40 --> Helper loaded: form_helper
INFO - 2016-02-26 10:15:40 --> Database Driver Class Initialized
INFO - 2016-02-26 10:15:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:15:41 --> Controller Class Initialized
INFO - 2016-02-26 10:15:41 --> Model Class Initialized
INFO - 2016-02-26 10:15:41 --> Model Class Initialized
INFO - 2016-02-26 10:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:15:41 --> Pagination Class Initialized
INFO - 2016-02-26 10:15:41 --> Helper loaded: text_helper
INFO - 2016-02-26 10:15:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:15:41 --> Final output sent to browser
DEBUG - 2016-02-26 13:15:41 --> Total execution time: 1.1345
INFO - 2016-02-26 10:15:53 --> Config Class Initialized
INFO - 2016-02-26 10:15:53 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:53 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:53 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:53 --> URI Class Initialized
DEBUG - 2016-02-26 10:15:53 --> No URI present. Default controller set.
INFO - 2016-02-26 10:15:53 --> Router Class Initialized
INFO - 2016-02-26 10:15:53 --> Output Class Initialized
INFO - 2016-02-26 10:15:53 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:53 --> Input Class Initialized
INFO - 2016-02-26 10:15:53 --> Language Class Initialized
INFO - 2016-02-26 10:15:53 --> Loader Class Initialized
INFO - 2016-02-26 10:15:53 --> Helper loaded: url_helper
INFO - 2016-02-26 10:15:53 --> Helper loaded: file_helper
INFO - 2016-02-26 10:15:53 --> Helper loaded: date_helper
INFO - 2016-02-26 10:15:53 --> Helper loaded: form_helper
INFO - 2016-02-26 10:15:53 --> Database Driver Class Initialized
INFO - 2016-02-26 10:15:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:15:54 --> Controller Class Initialized
INFO - 2016-02-26 10:15:54 --> Model Class Initialized
INFO - 2016-02-26 10:15:54 --> Model Class Initialized
INFO - 2016-02-26 10:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:15:54 --> Pagination Class Initialized
INFO - 2016-02-26 10:15:54 --> Helper loaded: text_helper
INFO - 2016-02-26 10:15:54 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 13:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:15:54 --> Final output sent to browser
DEBUG - 2016-02-26 13:15:54 --> Total execution time: 1.1280
INFO - 2016-02-26 10:15:56 --> Config Class Initialized
INFO - 2016-02-26 10:15:56 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:15:56 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:15:56 --> Utf8 Class Initialized
INFO - 2016-02-26 10:15:56 --> URI Class Initialized
INFO - 2016-02-26 10:15:56 --> Router Class Initialized
INFO - 2016-02-26 10:15:56 --> Output Class Initialized
INFO - 2016-02-26 10:15:56 --> Security Class Initialized
DEBUG - 2016-02-26 10:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:15:56 --> Input Class Initialized
INFO - 2016-02-26 10:15:56 --> Language Class Initialized
ERROR - 2016-02-26 10:15:56 --> Severity: Parsing Error --> syntax error, unexpected ''thumb'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 189
INFO - 2016-02-26 10:16:24 --> Config Class Initialized
INFO - 2016-02-26 10:16:24 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:24 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:24 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:24 --> URI Class Initialized
INFO - 2016-02-26 10:16:24 --> Router Class Initialized
INFO - 2016-02-26 10:16:24 --> Output Class Initialized
INFO - 2016-02-26 10:16:24 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:24 --> Input Class Initialized
INFO - 2016-02-26 10:16:24 --> Language Class Initialized
INFO - 2016-02-26 10:16:24 --> Loader Class Initialized
INFO - 2016-02-26 10:16:24 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:24 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:24 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:24 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:24 --> Database Driver Class Initialized
INFO - 2016-02-26 10:16:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:16:25 --> Controller Class Initialized
INFO - 2016-02-26 10:16:25 --> Model Class Initialized
INFO - 2016-02-26 10:16:25 --> Model Class Initialized
INFO - 2016-02-26 10:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:16:25 --> Pagination Class Initialized
INFO - 2016-02-26 10:16:25 --> Helper loaded: text_helper
INFO - 2016-02-26 10:16:25 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 13:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 13:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:16:25 --> Final output sent to browser
DEBUG - 2016-02-26 13:16:25 --> Total execution time: 1.1746
INFO - 2016-02-26 10:16:27 --> Config Class Initialized
INFO - 2016-02-26 10:16:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:27 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:27 --> URI Class Initialized
INFO - 2016-02-26 10:16:27 --> Router Class Initialized
INFO - 2016-02-26 10:16:27 --> Output Class Initialized
INFO - 2016-02-26 10:16:27 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:27 --> Input Class Initialized
INFO - 2016-02-26 10:16:27 --> Language Class Initialized
INFO - 2016-02-26 10:16:27 --> Loader Class Initialized
INFO - 2016-02-26 10:16:27 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:27 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:27 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:27 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:27 --> Database Driver Class Initialized
INFO - 2016-02-26 10:16:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:16:28 --> Controller Class Initialized
INFO - 2016-02-26 10:16:28 --> Model Class Initialized
INFO - 2016-02-26 10:16:28 --> Model Class Initialized
INFO - 2016-02-26 10:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:16:28 --> Pagination Class Initialized
INFO - 2016-02-26 10:16:28 --> Helper loaded: text_helper
INFO - 2016-02-26 10:16:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:16:28 --> Final output sent to browser
DEBUG - 2016-02-26 13:16:28 --> Total execution time: 1.1528
INFO - 2016-02-26 10:16:28 --> Config Class Initialized
INFO - 2016-02-26 10:16:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:28 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:28 --> URI Class Initialized
INFO - 2016-02-26 10:16:28 --> Router Class Initialized
INFO - 2016-02-26 10:16:28 --> Output Class Initialized
INFO - 2016-02-26 10:16:28 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:28 --> Input Class Initialized
INFO - 2016-02-26 10:16:28 --> Language Class Initialized
INFO - 2016-02-26 10:16:28 --> Loader Class Initialized
INFO - 2016-02-26 10:16:28 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:28 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:28 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:28 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:28 --> Database Driver Class Initialized
INFO - 2016-02-26 10:16:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:16:29 --> Controller Class Initialized
INFO - 2016-02-26 10:16:29 --> Model Class Initialized
INFO - 2016-02-26 10:16:29 --> Model Class Initialized
INFO - 2016-02-26 10:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:16:29 --> Pagination Class Initialized
INFO - 2016-02-26 10:16:29 --> Helper loaded: text_helper
INFO - 2016-02-26 10:16:29 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:16:29 --> Final output sent to browser
DEBUG - 2016-02-26 13:16:29 --> Total execution time: 1.1568
INFO - 2016-02-26 10:16:32 --> Config Class Initialized
INFO - 2016-02-26 10:16:32 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:32 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:32 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:32 --> URI Class Initialized
INFO - 2016-02-26 10:16:32 --> Router Class Initialized
INFO - 2016-02-26 10:16:32 --> Output Class Initialized
INFO - 2016-02-26 10:16:32 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:32 --> Input Class Initialized
INFO - 2016-02-26 10:16:32 --> Language Class Initialized
INFO - 2016-02-26 10:16:32 --> Loader Class Initialized
INFO - 2016-02-26 10:16:32 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:32 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:32 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:32 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:32 --> Database Driver Class Initialized
INFO - 2016-02-26 10:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:16:33 --> Controller Class Initialized
INFO - 2016-02-26 10:16:33 --> Model Class Initialized
INFO - 2016-02-26 10:16:33 --> Model Class Initialized
INFO - 2016-02-26 10:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:16:33 --> Pagination Class Initialized
INFO - 2016-02-26 10:16:33 --> Helper loaded: text_helper
INFO - 2016-02-26 10:16:33 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:16:33 --> Final output sent to browser
DEBUG - 2016-02-26 13:16:33 --> Total execution time: 1.1741
INFO - 2016-02-26 10:16:33 --> Config Class Initialized
INFO - 2016-02-26 10:16:33 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:33 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:33 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:33 --> URI Class Initialized
INFO - 2016-02-26 10:16:33 --> Router Class Initialized
INFO - 2016-02-26 10:16:33 --> Output Class Initialized
INFO - 2016-02-26 10:16:33 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:33 --> Input Class Initialized
INFO - 2016-02-26 10:16:33 --> Language Class Initialized
INFO - 2016-02-26 10:16:33 --> Loader Class Initialized
INFO - 2016-02-26 10:16:33 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:33 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:33 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:33 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:33 --> Database Driver Class Initialized
INFO - 2016-02-26 10:16:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:16:34 --> Controller Class Initialized
INFO - 2016-02-26 10:16:34 --> Model Class Initialized
INFO - 2016-02-26 10:16:34 --> Model Class Initialized
INFO - 2016-02-26 10:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:16:34 --> Pagination Class Initialized
INFO - 2016-02-26 10:16:34 --> Helper loaded: text_helper
INFO - 2016-02-26 10:16:34 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:16:34 --> Final output sent to browser
DEBUG - 2016-02-26 13:16:34 --> Total execution time: 1.1623
INFO - 2016-02-26 10:16:59 --> Config Class Initialized
INFO - 2016-02-26 10:16:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:16:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:16:59 --> Utf8 Class Initialized
INFO - 2016-02-26 10:16:59 --> URI Class Initialized
INFO - 2016-02-26 10:16:59 --> Router Class Initialized
INFO - 2016-02-26 10:16:59 --> Output Class Initialized
INFO - 2016-02-26 10:16:59 --> Security Class Initialized
DEBUG - 2016-02-26 10:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:16:59 --> Input Class Initialized
INFO - 2016-02-26 10:16:59 --> Language Class Initialized
INFO - 2016-02-26 10:16:59 --> Loader Class Initialized
INFO - 2016-02-26 10:16:59 --> Helper loaded: url_helper
INFO - 2016-02-26 10:16:59 --> Helper loaded: file_helper
INFO - 2016-02-26 10:16:59 --> Helper loaded: date_helper
INFO - 2016-02-26 10:16:59 --> Helper loaded: form_helper
INFO - 2016-02-26 10:16:59 --> Database Driver Class Initialized
INFO - 2016-02-26 10:17:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:17:00 --> Controller Class Initialized
INFO - 2016-02-26 10:17:00 --> Model Class Initialized
INFO - 2016-02-26 10:17:00 --> Model Class Initialized
INFO - 2016-02-26 10:17:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:17:00 --> Pagination Class Initialized
INFO - 2016-02-26 10:17:00 --> Helper loaded: text_helper
INFO - 2016-02-26 10:17:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:17:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:17:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:17:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:17:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:17:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:17:00 --> Final output sent to browser
DEBUG - 2016-02-26 13:17:00 --> Total execution time: 1.1412
INFO - 2016-02-26 10:17:01 --> Config Class Initialized
INFO - 2016-02-26 10:17:01 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:17:01 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:17:01 --> Utf8 Class Initialized
INFO - 2016-02-26 10:17:01 --> URI Class Initialized
INFO - 2016-02-26 10:17:01 --> Router Class Initialized
INFO - 2016-02-26 10:17:01 --> Output Class Initialized
INFO - 2016-02-26 10:17:01 --> Security Class Initialized
DEBUG - 2016-02-26 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:17:01 --> Input Class Initialized
INFO - 2016-02-26 10:17:01 --> Language Class Initialized
INFO - 2016-02-26 10:17:01 --> Loader Class Initialized
INFO - 2016-02-26 10:17:01 --> Helper loaded: url_helper
INFO - 2016-02-26 10:17:01 --> Helper loaded: file_helper
INFO - 2016-02-26 10:17:01 --> Helper loaded: date_helper
INFO - 2016-02-26 10:17:01 --> Helper loaded: form_helper
INFO - 2016-02-26 10:17:01 --> Database Driver Class Initialized
INFO - 2016-02-26 10:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:17:02 --> Controller Class Initialized
INFO - 2016-02-26 10:17:02 --> Model Class Initialized
INFO - 2016-02-26 10:17:02 --> Model Class Initialized
INFO - 2016-02-26 10:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:17:02 --> Pagination Class Initialized
INFO - 2016-02-26 10:17:02 --> Helper loaded: text_helper
INFO - 2016-02-26 10:17:02 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:17:02 --> Final output sent to browser
DEBUG - 2016-02-26 13:17:02 --> Total execution time: 1.1709
INFO - 2016-02-26 10:19:46 --> Config Class Initialized
INFO - 2016-02-26 10:19:46 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:19:46 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:19:46 --> Utf8 Class Initialized
INFO - 2016-02-26 10:19:46 --> URI Class Initialized
INFO - 2016-02-26 10:19:46 --> Router Class Initialized
INFO - 2016-02-26 10:19:46 --> Output Class Initialized
INFO - 2016-02-26 10:19:46 --> Security Class Initialized
DEBUG - 2016-02-26 10:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:19:46 --> Input Class Initialized
INFO - 2016-02-26 10:19:46 --> Language Class Initialized
INFO - 2016-02-26 10:19:46 --> Loader Class Initialized
INFO - 2016-02-26 10:19:46 --> Helper loaded: url_helper
INFO - 2016-02-26 10:19:46 --> Helper loaded: file_helper
INFO - 2016-02-26 10:19:46 --> Helper loaded: date_helper
INFO - 2016-02-26 10:19:46 --> Helper loaded: form_helper
INFO - 2016-02-26 10:19:46 --> Database Driver Class Initialized
INFO - 2016-02-26 10:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:19:47 --> Controller Class Initialized
INFO - 2016-02-26 10:19:47 --> Model Class Initialized
INFO - 2016-02-26 10:19:47 --> Model Class Initialized
INFO - 2016-02-26 10:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:19:47 --> Pagination Class Initialized
INFO - 2016-02-26 10:19:47 --> Helper loaded: text_helper
INFO - 2016-02-26 10:19:47 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:19:47 --> Final output sent to browser
DEBUG - 2016-02-26 13:19:47 --> Total execution time: 1.1522
INFO - 2016-02-26 10:19:47 --> Config Class Initialized
INFO - 2016-02-26 10:19:47 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:19:47 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:19:47 --> Utf8 Class Initialized
INFO - 2016-02-26 10:19:47 --> URI Class Initialized
INFO - 2016-02-26 10:19:47 --> Router Class Initialized
INFO - 2016-02-26 10:19:47 --> Output Class Initialized
INFO - 2016-02-26 10:19:47 --> Security Class Initialized
DEBUG - 2016-02-26 10:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:19:47 --> Input Class Initialized
INFO - 2016-02-26 10:19:47 --> Language Class Initialized
INFO - 2016-02-26 10:19:47 --> Loader Class Initialized
INFO - 2016-02-26 10:19:47 --> Helper loaded: url_helper
INFO - 2016-02-26 10:19:47 --> Helper loaded: file_helper
INFO - 2016-02-26 10:19:47 --> Helper loaded: date_helper
INFO - 2016-02-26 10:19:47 --> Helper loaded: form_helper
INFO - 2016-02-26 10:19:47 --> Database Driver Class Initialized
INFO - 2016-02-26 10:19:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:19:48 --> Controller Class Initialized
INFO - 2016-02-26 10:19:48 --> Model Class Initialized
INFO - 2016-02-26 10:19:48 --> Model Class Initialized
INFO - 2016-02-26 10:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:19:48 --> Pagination Class Initialized
INFO - 2016-02-26 10:19:48 --> Helper loaded: text_helper
INFO - 2016-02-26 10:19:48 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:19:48 --> Final output sent to browser
DEBUG - 2016-02-26 13:19:48 --> Total execution time: 1.1439
INFO - 2016-02-26 10:19:56 --> Config Class Initialized
INFO - 2016-02-26 10:19:56 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:19:56 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:19:56 --> Utf8 Class Initialized
INFO - 2016-02-26 10:19:56 --> URI Class Initialized
INFO - 2016-02-26 10:19:56 --> Router Class Initialized
INFO - 2016-02-26 10:19:56 --> Output Class Initialized
INFO - 2016-02-26 10:19:56 --> Security Class Initialized
DEBUG - 2016-02-26 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:19:56 --> Input Class Initialized
INFO - 2016-02-26 10:19:56 --> Language Class Initialized
INFO - 2016-02-26 10:19:56 --> Loader Class Initialized
INFO - 2016-02-26 10:19:56 --> Helper loaded: url_helper
INFO - 2016-02-26 10:19:56 --> Helper loaded: file_helper
INFO - 2016-02-26 10:19:56 --> Helper loaded: date_helper
INFO - 2016-02-26 10:19:56 --> Helper loaded: form_helper
INFO - 2016-02-26 10:19:56 --> Database Driver Class Initialized
INFO - 2016-02-26 10:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:19:57 --> Controller Class Initialized
INFO - 2016-02-26 10:19:57 --> Model Class Initialized
INFO - 2016-02-26 10:19:57 --> Model Class Initialized
INFO - 2016-02-26 10:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:19:57 --> Pagination Class Initialized
INFO - 2016-02-26 10:19:57 --> Helper loaded: text_helper
INFO - 2016-02-26 10:19:57 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:19:57 --> Upload Class Initialized
INFO - 2016-02-26 13:19:57 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:19:57 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:19:57 --> Final output sent to browser
DEBUG - 2016-02-26 13:19:57 --> Total execution time: 1.1767
INFO - 2016-02-26 10:33:50 --> Config Class Initialized
INFO - 2016-02-26 10:33:50 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:33:50 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:33:50 --> Utf8 Class Initialized
INFO - 2016-02-26 10:33:50 --> URI Class Initialized
INFO - 2016-02-26 10:33:50 --> Router Class Initialized
INFO - 2016-02-26 10:33:50 --> Output Class Initialized
INFO - 2016-02-26 10:33:50 --> Security Class Initialized
DEBUG - 2016-02-26 10:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:33:50 --> Input Class Initialized
INFO - 2016-02-26 10:33:50 --> Language Class Initialized
INFO - 2016-02-26 10:33:50 --> Loader Class Initialized
INFO - 2016-02-26 10:33:50 --> Helper loaded: url_helper
INFO - 2016-02-26 10:33:50 --> Helper loaded: file_helper
INFO - 2016-02-26 10:33:50 --> Helper loaded: date_helper
INFO - 2016-02-26 10:33:50 --> Helper loaded: form_helper
INFO - 2016-02-26 10:33:50 --> Database Driver Class Initialized
INFO - 2016-02-26 10:33:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:33:51 --> Controller Class Initialized
INFO - 2016-02-26 10:33:51 --> Model Class Initialized
INFO - 2016-02-26 10:33:51 --> Model Class Initialized
INFO - 2016-02-26 10:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:33:51 --> Pagination Class Initialized
INFO - 2016-02-26 10:33:51 --> Helper loaded: text_helper
INFO - 2016-02-26 10:33:51 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:33:51 --> Final output sent to browser
DEBUG - 2016-02-26 13:33:51 --> Total execution time: 1.1490
INFO - 2016-02-26 10:33:52 --> Config Class Initialized
INFO - 2016-02-26 10:33:52 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:33:52 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:33:52 --> Utf8 Class Initialized
INFO - 2016-02-26 10:33:52 --> URI Class Initialized
INFO - 2016-02-26 10:33:52 --> Router Class Initialized
INFO - 2016-02-26 10:33:52 --> Output Class Initialized
INFO - 2016-02-26 10:33:52 --> Security Class Initialized
DEBUG - 2016-02-26 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:33:52 --> Input Class Initialized
INFO - 2016-02-26 10:33:52 --> Language Class Initialized
INFO - 2016-02-26 10:33:52 --> Loader Class Initialized
INFO - 2016-02-26 10:33:52 --> Helper loaded: url_helper
INFO - 2016-02-26 10:33:52 --> Helper loaded: file_helper
INFO - 2016-02-26 10:33:52 --> Helper loaded: date_helper
INFO - 2016-02-26 10:33:52 --> Helper loaded: form_helper
INFO - 2016-02-26 10:33:52 --> Database Driver Class Initialized
INFO - 2016-02-26 10:33:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:33:53 --> Controller Class Initialized
INFO - 2016-02-26 10:33:53 --> Model Class Initialized
INFO - 2016-02-26 10:33:53 --> Model Class Initialized
INFO - 2016-02-26 10:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:33:53 --> Pagination Class Initialized
INFO - 2016-02-26 10:33:53 --> Helper loaded: text_helper
INFO - 2016-02-26 10:33:53 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:33:53 --> Final output sent to browser
DEBUG - 2016-02-26 13:33:53 --> Total execution time: 1.1610
INFO - 2016-02-26 10:34:02 --> Config Class Initialized
INFO - 2016-02-26 10:34:02 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:34:02 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:34:02 --> Utf8 Class Initialized
INFO - 2016-02-26 10:34:02 --> URI Class Initialized
INFO - 2016-02-26 10:34:02 --> Router Class Initialized
INFO - 2016-02-26 10:34:02 --> Output Class Initialized
INFO - 2016-02-26 10:34:02 --> Security Class Initialized
DEBUG - 2016-02-26 10:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:34:02 --> Input Class Initialized
INFO - 2016-02-26 10:34:02 --> Language Class Initialized
INFO - 2016-02-26 10:34:02 --> Loader Class Initialized
INFO - 2016-02-26 10:34:02 --> Helper loaded: url_helper
INFO - 2016-02-26 10:34:02 --> Helper loaded: file_helper
INFO - 2016-02-26 10:34:02 --> Helper loaded: date_helper
INFO - 2016-02-26 10:34:02 --> Helper loaded: form_helper
INFO - 2016-02-26 10:34:02 --> Database Driver Class Initialized
INFO - 2016-02-26 10:34:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:34:03 --> Controller Class Initialized
INFO - 2016-02-26 10:34:03 --> Model Class Initialized
INFO - 2016-02-26 10:34:03 --> Model Class Initialized
INFO - 2016-02-26 10:34:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:34:03 --> Pagination Class Initialized
INFO - 2016-02-26 10:34:03 --> Helper loaded: text_helper
INFO - 2016-02-26 10:34:03 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:34:03 --> Upload Class Initialized
INFO - 2016-02-26 13:34:03 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:34:03 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:34:03 --> Final output sent to browser
DEBUG - 2016-02-26 13:34:03 --> Total execution time: 1.1781
INFO - 2016-02-26 10:36:19 --> Config Class Initialized
INFO - 2016-02-26 10:36:19 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:19 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:19 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:19 --> URI Class Initialized
INFO - 2016-02-26 10:36:19 --> Router Class Initialized
INFO - 2016-02-26 10:36:19 --> Output Class Initialized
INFO - 2016-02-26 10:36:19 --> Security Class Initialized
DEBUG - 2016-02-26 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:36:19 --> Input Class Initialized
INFO - 2016-02-26 10:36:19 --> Language Class Initialized
INFO - 2016-02-26 10:36:19 --> Loader Class Initialized
INFO - 2016-02-26 10:36:19 --> Helper loaded: url_helper
INFO - 2016-02-26 10:36:19 --> Helper loaded: file_helper
INFO - 2016-02-26 10:36:19 --> Helper loaded: date_helper
INFO - 2016-02-26 10:36:19 --> Helper loaded: form_helper
INFO - 2016-02-26 10:36:19 --> Database Driver Class Initialized
INFO - 2016-02-26 10:36:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:36:20 --> Controller Class Initialized
INFO - 2016-02-26 10:36:20 --> Model Class Initialized
INFO - 2016-02-26 10:36:20 --> Model Class Initialized
INFO - 2016-02-26 10:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:36:20 --> Pagination Class Initialized
INFO - 2016-02-26 10:36:20 --> Helper loaded: text_helper
INFO - 2016-02-26 10:36:20 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:36:20 --> Final output sent to browser
DEBUG - 2016-02-26 13:36:20 --> Total execution time: 1.1581
INFO - 2016-02-26 10:36:21 --> Config Class Initialized
INFO - 2016-02-26 10:36:21 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:21 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:21 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:21 --> URI Class Initialized
INFO - 2016-02-26 10:36:21 --> Router Class Initialized
INFO - 2016-02-26 10:36:21 --> Output Class Initialized
INFO - 2016-02-26 10:36:21 --> Security Class Initialized
DEBUG - 2016-02-26 10:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:36:21 --> Input Class Initialized
INFO - 2016-02-26 10:36:21 --> Language Class Initialized
INFO - 2016-02-26 10:36:21 --> Loader Class Initialized
INFO - 2016-02-26 10:36:21 --> Helper loaded: url_helper
INFO - 2016-02-26 10:36:21 --> Helper loaded: file_helper
INFO - 2016-02-26 10:36:21 --> Helper loaded: date_helper
INFO - 2016-02-26 10:36:21 --> Helper loaded: form_helper
INFO - 2016-02-26 10:36:21 --> Database Driver Class Initialized
INFO - 2016-02-26 10:36:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:36:22 --> Controller Class Initialized
INFO - 2016-02-26 10:36:22 --> Model Class Initialized
INFO - 2016-02-26 10:36:22 --> Model Class Initialized
INFO - 2016-02-26 10:36:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:36:22 --> Pagination Class Initialized
INFO - 2016-02-26 10:36:22 --> Helper loaded: text_helper
INFO - 2016-02-26 10:36:22 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:36:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:36:22 --> Final output sent to browser
DEBUG - 2016-02-26 13:36:22 --> Total execution time: 1.1446
INFO - 2016-02-26 10:36:28 --> Config Class Initialized
INFO - 2016-02-26 10:36:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:28 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:28 --> URI Class Initialized
INFO - 2016-02-26 10:36:28 --> Router Class Initialized
INFO - 2016-02-26 10:36:28 --> Output Class Initialized
INFO - 2016-02-26 10:36:28 --> Security Class Initialized
DEBUG - 2016-02-26 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:36:28 --> Input Class Initialized
INFO - 2016-02-26 10:36:28 --> Language Class Initialized
ERROR - 2016-02-26 10:36:28 --> Severity: Parsing Error --> syntax error, unexpected '$url' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-26 10:36:41 --> Config Class Initialized
INFO - 2016-02-26 10:36:41 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:41 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:41 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:41 --> URI Class Initialized
INFO - 2016-02-26 10:36:41 --> Router Class Initialized
INFO - 2016-02-26 10:36:41 --> Output Class Initialized
INFO - 2016-02-26 10:36:41 --> Security Class Initialized
DEBUG - 2016-02-26 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:36:41 --> Input Class Initialized
INFO - 2016-02-26 10:36:41 --> Language Class Initialized
ERROR - 2016-02-26 10:36:41 --> Severity: Parsing Error --> syntax error, unexpected '$url' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-26 10:36:58 --> Config Class Initialized
INFO - 2016-02-26 10:36:58 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:58 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:58 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:58 --> URI Class Initialized
INFO - 2016-02-26 10:36:58 --> Router Class Initialized
INFO - 2016-02-26 10:36:58 --> Output Class Initialized
INFO - 2016-02-26 10:36:58 --> Security Class Initialized
DEBUG - 2016-02-26 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:36:58 --> Input Class Initialized
INFO - 2016-02-26 10:36:58 --> Language Class Initialized
INFO - 2016-02-26 10:36:58 --> Loader Class Initialized
INFO - 2016-02-26 10:36:58 --> Helper loaded: url_helper
INFO - 2016-02-26 10:36:58 --> Helper loaded: file_helper
INFO - 2016-02-26 10:36:58 --> Helper loaded: date_helper
INFO - 2016-02-26 10:36:58 --> Helper loaded: form_helper
INFO - 2016-02-26 10:36:58 --> Database Driver Class Initialized
INFO - 2016-02-26 10:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:36:59 --> Controller Class Initialized
INFO - 2016-02-26 10:36:59 --> Model Class Initialized
INFO - 2016-02-26 10:36:59 --> Model Class Initialized
INFO - 2016-02-26 10:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:36:59 --> Pagination Class Initialized
INFO - 2016-02-26 10:36:59 --> Helper loaded: text_helper
INFO - 2016-02-26 10:36:59 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:36:59 --> Final output sent to browser
DEBUG - 2016-02-26 13:36:59 --> Total execution time: 1.1511
INFO - 2016-02-26 10:36:59 --> Config Class Initialized
INFO - 2016-02-26 10:36:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:36:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:36:59 --> Utf8 Class Initialized
INFO - 2016-02-26 10:36:59 --> URI Class Initialized
INFO - 2016-02-26 10:36:59 --> Router Class Initialized
INFO - 2016-02-26 10:37:00 --> Output Class Initialized
INFO - 2016-02-26 10:37:00 --> Security Class Initialized
DEBUG - 2016-02-26 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:37:00 --> Input Class Initialized
INFO - 2016-02-26 10:37:00 --> Language Class Initialized
INFO - 2016-02-26 10:37:00 --> Loader Class Initialized
INFO - 2016-02-26 10:37:00 --> Helper loaded: url_helper
INFO - 2016-02-26 10:37:00 --> Helper loaded: file_helper
INFO - 2016-02-26 10:37:00 --> Helper loaded: date_helper
INFO - 2016-02-26 10:37:00 --> Helper loaded: form_helper
INFO - 2016-02-26 10:37:00 --> Database Driver Class Initialized
INFO - 2016-02-26 10:37:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:37:01 --> Controller Class Initialized
INFO - 2016-02-26 10:37:01 --> Model Class Initialized
INFO - 2016-02-26 10:37:01 --> Model Class Initialized
INFO - 2016-02-26 10:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:37:01 --> Pagination Class Initialized
INFO - 2016-02-26 10:37:01 --> Helper loaded: text_helper
INFO - 2016-02-26 10:37:01 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:37:01 --> Final output sent to browser
DEBUG - 2016-02-26 13:37:01 --> Total execution time: 1.1603
INFO - 2016-02-26 10:37:06 --> Config Class Initialized
INFO - 2016-02-26 10:37:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:37:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:37:06 --> Utf8 Class Initialized
INFO - 2016-02-26 10:37:06 --> URI Class Initialized
INFO - 2016-02-26 10:37:06 --> Router Class Initialized
INFO - 2016-02-26 10:37:06 --> Output Class Initialized
INFO - 2016-02-26 10:37:06 --> Security Class Initialized
DEBUG - 2016-02-26 10:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:37:06 --> Input Class Initialized
INFO - 2016-02-26 10:37:06 --> Language Class Initialized
INFO - 2016-02-26 10:37:06 --> Loader Class Initialized
INFO - 2016-02-26 10:37:06 --> Helper loaded: url_helper
INFO - 2016-02-26 10:37:06 --> Helper loaded: file_helper
INFO - 2016-02-26 10:37:06 --> Helper loaded: date_helper
INFO - 2016-02-26 10:37:06 --> Helper loaded: form_helper
INFO - 2016-02-26 10:37:06 --> Database Driver Class Initialized
INFO - 2016-02-26 10:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:37:08 --> Controller Class Initialized
INFO - 2016-02-26 10:37:08 --> Model Class Initialized
INFO - 2016-02-26 10:37:08 --> Model Class Initialized
INFO - 2016-02-26 10:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:37:08 --> Pagination Class Initialized
INFO - 2016-02-26 10:37:08 --> Helper loaded: text_helper
INFO - 2016-02-26 10:37:08 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:37:08 --> Upload Class Initialized
INFO - 2016-02-26 13:37:08 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:37:08 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:37:08 --> Final output sent to browser
DEBUG - 2016-02-26 13:37:08 --> Total execution time: 1.0931
INFO - 2016-02-26 10:38:18 --> Config Class Initialized
INFO - 2016-02-26 10:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:38:18 --> Utf8 Class Initialized
INFO - 2016-02-26 10:38:18 --> URI Class Initialized
INFO - 2016-02-26 10:38:18 --> Router Class Initialized
INFO - 2016-02-26 10:38:18 --> Output Class Initialized
INFO - 2016-02-26 10:38:18 --> Security Class Initialized
DEBUG - 2016-02-26 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:38:18 --> Input Class Initialized
INFO - 2016-02-26 10:38:18 --> Language Class Initialized
INFO - 2016-02-26 10:38:18 --> Loader Class Initialized
INFO - 2016-02-26 10:38:18 --> Helper loaded: url_helper
INFO - 2016-02-26 10:38:18 --> Helper loaded: file_helper
INFO - 2016-02-26 10:38:18 --> Helper loaded: date_helper
INFO - 2016-02-26 10:38:18 --> Helper loaded: form_helper
INFO - 2016-02-26 10:38:18 --> Database Driver Class Initialized
INFO - 2016-02-26 10:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:38:19 --> Controller Class Initialized
INFO - 2016-02-26 10:38:19 --> Model Class Initialized
INFO - 2016-02-26 10:38:20 --> Model Class Initialized
INFO - 2016-02-26 10:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:38:20 --> Pagination Class Initialized
INFO - 2016-02-26 10:38:20 --> Helper loaded: text_helper
INFO - 2016-02-26 10:38:20 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:38:20 --> Final output sent to browser
DEBUG - 2016-02-26 13:38:20 --> Total execution time: 1.1788
INFO - 2016-02-26 10:38:20 --> Config Class Initialized
INFO - 2016-02-26 10:38:20 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:38:20 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:38:20 --> Utf8 Class Initialized
INFO - 2016-02-26 10:38:20 --> URI Class Initialized
INFO - 2016-02-26 10:38:20 --> Router Class Initialized
INFO - 2016-02-26 10:38:20 --> Output Class Initialized
INFO - 2016-02-26 10:38:20 --> Security Class Initialized
DEBUG - 2016-02-26 10:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:38:20 --> Input Class Initialized
INFO - 2016-02-26 10:38:20 --> Language Class Initialized
INFO - 2016-02-26 10:38:20 --> Loader Class Initialized
INFO - 2016-02-26 10:38:20 --> Helper loaded: url_helper
INFO - 2016-02-26 10:38:20 --> Helper loaded: file_helper
INFO - 2016-02-26 10:38:20 --> Helper loaded: date_helper
INFO - 2016-02-26 10:38:20 --> Helper loaded: form_helper
INFO - 2016-02-26 10:38:20 --> Database Driver Class Initialized
INFO - 2016-02-26 10:38:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:38:21 --> Controller Class Initialized
INFO - 2016-02-26 10:38:21 --> Model Class Initialized
INFO - 2016-02-26 10:38:21 --> Model Class Initialized
INFO - 2016-02-26 10:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:38:21 --> Pagination Class Initialized
INFO - 2016-02-26 10:38:21 --> Helper loaded: text_helper
INFO - 2016-02-26 10:38:21 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:38:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:38:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:38:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:38:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:38:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:38:21 --> Final output sent to browser
DEBUG - 2016-02-26 13:38:21 --> Total execution time: 1.1270
INFO - 2016-02-26 10:38:28 --> Config Class Initialized
INFO - 2016-02-26 10:38:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:38:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:38:28 --> Utf8 Class Initialized
INFO - 2016-02-26 10:38:28 --> URI Class Initialized
INFO - 2016-02-26 10:38:28 --> Router Class Initialized
INFO - 2016-02-26 10:38:28 --> Output Class Initialized
INFO - 2016-02-26 10:38:28 --> Security Class Initialized
DEBUG - 2016-02-26 10:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:38:28 --> Input Class Initialized
INFO - 2016-02-26 10:38:28 --> Language Class Initialized
INFO - 2016-02-26 10:38:28 --> Loader Class Initialized
INFO - 2016-02-26 10:38:28 --> Helper loaded: url_helper
INFO - 2016-02-26 10:38:28 --> Helper loaded: file_helper
INFO - 2016-02-26 10:38:28 --> Helper loaded: date_helper
INFO - 2016-02-26 10:38:28 --> Helper loaded: form_helper
INFO - 2016-02-26 10:38:28 --> Database Driver Class Initialized
INFO - 2016-02-26 10:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:38:29 --> Controller Class Initialized
INFO - 2016-02-26 10:38:29 --> Model Class Initialized
INFO - 2016-02-26 10:38:29 --> Model Class Initialized
INFO - 2016-02-26 10:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:38:29 --> Pagination Class Initialized
INFO - 2016-02-26 10:38:29 --> Helper loaded: text_helper
INFO - 2016-02-26 10:38:29 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:38:29 --> Upload Class Initialized
INFO - 2016-02-26 13:38:29 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:38:29 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-26 13:38:29 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-26 13:38:29 --> Final output sent to browser
DEBUG - 2016-02-26 13:38:29 --> Total execution time: 1.1883
INFO - 2016-02-26 10:40:39 --> Config Class Initialized
INFO - 2016-02-26 10:40:39 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:40:39 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:40:39 --> Utf8 Class Initialized
INFO - 2016-02-26 10:40:39 --> URI Class Initialized
INFO - 2016-02-26 10:40:39 --> Router Class Initialized
INFO - 2016-02-26 10:40:39 --> Output Class Initialized
INFO - 2016-02-26 10:40:39 --> Security Class Initialized
DEBUG - 2016-02-26 10:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:40:39 --> Input Class Initialized
INFO - 2016-02-26 10:40:39 --> Language Class Initialized
INFO - 2016-02-26 10:40:39 --> Loader Class Initialized
INFO - 2016-02-26 10:40:39 --> Helper loaded: url_helper
INFO - 2016-02-26 10:40:39 --> Helper loaded: file_helper
INFO - 2016-02-26 10:40:39 --> Helper loaded: date_helper
INFO - 2016-02-26 10:40:39 --> Helper loaded: form_helper
INFO - 2016-02-26 10:40:39 --> Database Driver Class Initialized
INFO - 2016-02-26 10:40:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:40:40 --> Controller Class Initialized
INFO - 2016-02-26 10:40:40 --> Model Class Initialized
INFO - 2016-02-26 10:40:40 --> Model Class Initialized
INFO - 2016-02-26 10:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:40:40 --> Pagination Class Initialized
INFO - 2016-02-26 10:40:40 --> Helper loaded: text_helper
INFO - 2016-02-26 10:40:40 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:40:40 --> Final output sent to browser
DEBUG - 2016-02-26 13:40:40 --> Total execution time: 1.2568
INFO - 2016-02-26 10:40:40 --> Config Class Initialized
INFO - 2016-02-26 10:40:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:40:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:40:40 --> Utf8 Class Initialized
INFO - 2016-02-26 10:40:40 --> URI Class Initialized
INFO - 2016-02-26 10:40:40 --> Router Class Initialized
INFO - 2016-02-26 10:40:40 --> Output Class Initialized
INFO - 2016-02-26 10:40:40 --> Security Class Initialized
DEBUG - 2016-02-26 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:40:40 --> Input Class Initialized
INFO - 2016-02-26 10:40:40 --> Language Class Initialized
INFO - 2016-02-26 10:40:40 --> Loader Class Initialized
INFO - 2016-02-26 10:40:40 --> Helper loaded: url_helper
INFO - 2016-02-26 10:40:40 --> Helper loaded: file_helper
INFO - 2016-02-26 10:40:40 --> Helper loaded: date_helper
INFO - 2016-02-26 10:40:40 --> Helper loaded: form_helper
INFO - 2016-02-26 10:40:40 --> Database Driver Class Initialized
INFO - 2016-02-26 10:40:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:40:41 --> Controller Class Initialized
INFO - 2016-02-26 10:40:41 --> Model Class Initialized
INFO - 2016-02-26 10:40:41 --> Model Class Initialized
INFO - 2016-02-26 10:40:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:40:41 --> Pagination Class Initialized
INFO - 2016-02-26 10:40:41 --> Helper loaded: text_helper
INFO - 2016-02-26 10:40:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:40:41 --> Final output sent to browser
DEBUG - 2016-02-26 13:40:41 --> Total execution time: 1.1479
INFO - 2016-02-26 10:40:48 --> Config Class Initialized
INFO - 2016-02-26 10:40:48 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:40:48 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:40:48 --> Utf8 Class Initialized
INFO - 2016-02-26 10:40:48 --> URI Class Initialized
INFO - 2016-02-26 10:40:48 --> Router Class Initialized
INFO - 2016-02-26 10:40:48 --> Output Class Initialized
INFO - 2016-02-26 10:40:48 --> Security Class Initialized
DEBUG - 2016-02-26 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:40:48 --> Input Class Initialized
INFO - 2016-02-26 10:40:48 --> Language Class Initialized
INFO - 2016-02-26 10:40:48 --> Loader Class Initialized
INFO - 2016-02-26 10:40:48 --> Helper loaded: url_helper
INFO - 2016-02-26 10:40:48 --> Helper loaded: file_helper
INFO - 2016-02-26 10:40:48 --> Helper loaded: date_helper
INFO - 2016-02-26 10:40:48 --> Helper loaded: form_helper
INFO - 2016-02-26 10:40:48 --> Database Driver Class Initialized
INFO - 2016-02-26 10:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:40:49 --> Controller Class Initialized
INFO - 2016-02-26 10:40:49 --> Model Class Initialized
INFO - 2016-02-26 10:40:49 --> Model Class Initialized
INFO - 2016-02-26 10:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:40:49 --> Pagination Class Initialized
INFO - 2016-02-26 10:40:49 --> Helper loaded: text_helper
INFO - 2016-02-26 10:40:49 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:40:49 --> Upload Class Initialized
INFO - 2016-02-26 13:40:49 --> Final output sent to browser
DEBUG - 2016-02-26 13:40:49 --> Total execution time: 1.1358
INFO - 2016-02-26 10:41:22 --> Config Class Initialized
INFO - 2016-02-26 10:41:22 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:41:22 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:41:22 --> Utf8 Class Initialized
INFO - 2016-02-26 10:41:22 --> URI Class Initialized
INFO - 2016-02-26 10:41:22 --> Router Class Initialized
INFO - 2016-02-26 10:41:22 --> Output Class Initialized
INFO - 2016-02-26 10:41:22 --> Security Class Initialized
DEBUG - 2016-02-26 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:41:22 --> Input Class Initialized
INFO - 2016-02-26 10:41:22 --> Language Class Initialized
INFO - 2016-02-26 10:41:22 --> Loader Class Initialized
INFO - 2016-02-26 10:41:22 --> Helper loaded: url_helper
INFO - 2016-02-26 10:41:22 --> Helper loaded: file_helper
INFO - 2016-02-26 10:41:22 --> Helper loaded: date_helper
INFO - 2016-02-26 10:41:22 --> Helper loaded: form_helper
INFO - 2016-02-26 10:41:22 --> Database Driver Class Initialized
INFO - 2016-02-26 10:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:41:23 --> Controller Class Initialized
INFO - 2016-02-26 10:41:23 --> Model Class Initialized
INFO - 2016-02-26 10:41:23 --> Model Class Initialized
INFO - 2016-02-26 10:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:41:23 --> Pagination Class Initialized
INFO - 2016-02-26 10:41:23 --> Helper loaded: text_helper
INFO - 2016-02-26 10:41:23 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:41:23 --> Upload Class Initialized
INFO - 2016-02-26 13:41:23 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:41:23 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:41:23 --> Final output sent to browser
DEBUG - 2016-02-26 13:41:23 --> Total execution time: 1.1386
INFO - 2016-02-26 10:43:32 --> Config Class Initialized
INFO - 2016-02-26 10:43:32 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:43:32 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:43:32 --> Utf8 Class Initialized
INFO - 2016-02-26 10:43:32 --> URI Class Initialized
INFO - 2016-02-26 10:43:32 --> Router Class Initialized
INFO - 2016-02-26 10:43:32 --> Output Class Initialized
INFO - 2016-02-26 10:43:32 --> Security Class Initialized
DEBUG - 2016-02-26 10:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:43:32 --> Input Class Initialized
INFO - 2016-02-26 10:43:32 --> Language Class Initialized
INFO - 2016-02-26 10:43:32 --> Loader Class Initialized
INFO - 2016-02-26 10:43:32 --> Helper loaded: url_helper
INFO - 2016-02-26 10:43:32 --> Helper loaded: file_helper
INFO - 2016-02-26 10:43:32 --> Helper loaded: date_helper
INFO - 2016-02-26 10:43:32 --> Helper loaded: form_helper
INFO - 2016-02-26 10:43:32 --> Database Driver Class Initialized
INFO - 2016-02-26 10:43:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:43:33 --> Controller Class Initialized
INFO - 2016-02-26 10:43:33 --> Model Class Initialized
INFO - 2016-02-26 10:43:33 --> Model Class Initialized
INFO - 2016-02-26 10:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:43:33 --> Pagination Class Initialized
INFO - 2016-02-26 10:43:33 --> Helper loaded: text_helper
INFO - 2016-02-26 10:43:33 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:43:33 --> Final output sent to browser
DEBUG - 2016-02-26 13:43:33 --> Total execution time: 1.1685
INFO - 2016-02-26 10:43:34 --> Config Class Initialized
INFO - 2016-02-26 10:43:34 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:43:34 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:43:34 --> Utf8 Class Initialized
INFO - 2016-02-26 10:43:34 --> URI Class Initialized
INFO - 2016-02-26 10:43:34 --> Router Class Initialized
INFO - 2016-02-26 10:43:34 --> Output Class Initialized
INFO - 2016-02-26 10:43:34 --> Security Class Initialized
DEBUG - 2016-02-26 10:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:43:34 --> Input Class Initialized
INFO - 2016-02-26 10:43:34 --> Language Class Initialized
INFO - 2016-02-26 10:43:34 --> Loader Class Initialized
INFO - 2016-02-26 10:43:34 --> Helper loaded: url_helper
INFO - 2016-02-26 10:43:34 --> Helper loaded: file_helper
INFO - 2016-02-26 10:43:34 --> Helper loaded: date_helper
INFO - 2016-02-26 10:43:34 --> Helper loaded: form_helper
INFO - 2016-02-26 10:43:34 --> Database Driver Class Initialized
INFO - 2016-02-26 10:43:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:43:35 --> Controller Class Initialized
INFO - 2016-02-26 10:43:35 --> Model Class Initialized
INFO - 2016-02-26 10:43:35 --> Model Class Initialized
INFO - 2016-02-26 10:43:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:43:35 --> Pagination Class Initialized
INFO - 2016-02-26 10:43:35 --> Helper loaded: text_helper
INFO - 2016-02-26 10:43:35 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:43:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:43:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:43:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:43:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:43:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:43:35 --> Final output sent to browser
DEBUG - 2016-02-26 13:43:35 --> Total execution time: 1.2157
INFO - 2016-02-26 10:43:42 --> Config Class Initialized
INFO - 2016-02-26 10:43:42 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:43:42 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:43:42 --> Utf8 Class Initialized
INFO - 2016-02-26 10:43:42 --> URI Class Initialized
INFO - 2016-02-26 10:43:42 --> Router Class Initialized
INFO - 2016-02-26 10:43:42 --> Output Class Initialized
INFO - 2016-02-26 10:43:42 --> Security Class Initialized
DEBUG - 2016-02-26 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:43:42 --> Input Class Initialized
INFO - 2016-02-26 10:43:42 --> Language Class Initialized
INFO - 2016-02-26 10:43:42 --> Loader Class Initialized
INFO - 2016-02-26 10:43:42 --> Helper loaded: url_helper
INFO - 2016-02-26 10:43:42 --> Helper loaded: file_helper
INFO - 2016-02-26 10:43:42 --> Helper loaded: date_helper
INFO - 2016-02-26 10:43:42 --> Helper loaded: form_helper
INFO - 2016-02-26 10:43:42 --> Database Driver Class Initialized
INFO - 2016-02-26 10:43:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:43:43 --> Controller Class Initialized
INFO - 2016-02-26 10:43:43 --> Model Class Initialized
INFO - 2016-02-26 10:43:43 --> Model Class Initialized
INFO - 2016-02-26 10:43:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:43:43 --> Pagination Class Initialized
INFO - 2016-02-26 10:43:43 --> Helper loaded: text_helper
INFO - 2016-02-26 10:43:43 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:43:43 --> Upload Class Initialized
INFO - 2016-02-26 13:43:43 --> Image Lib Class Initialized
DEBUG - 2016-02-26 13:43:43 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 13:43:43 --> Final output sent to browser
DEBUG - 2016-02-26 13:43:43 --> Total execution time: 1.1844
INFO - 2016-02-26 10:47:06 --> Config Class Initialized
INFO - 2016-02-26 10:47:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:47:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:47:06 --> Utf8 Class Initialized
INFO - 2016-02-26 10:47:06 --> URI Class Initialized
INFO - 2016-02-26 10:47:06 --> Router Class Initialized
INFO - 2016-02-26 10:47:06 --> Output Class Initialized
INFO - 2016-02-26 10:47:06 --> Security Class Initialized
DEBUG - 2016-02-26 10:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:47:06 --> Input Class Initialized
INFO - 2016-02-26 10:47:06 --> Language Class Initialized
INFO - 2016-02-26 10:47:06 --> Loader Class Initialized
INFO - 2016-02-26 10:47:06 --> Helper loaded: url_helper
INFO - 2016-02-26 10:47:06 --> Helper loaded: file_helper
INFO - 2016-02-26 10:47:06 --> Helper loaded: date_helper
INFO - 2016-02-26 10:47:06 --> Helper loaded: form_helper
INFO - 2016-02-26 10:47:06 --> Database Driver Class Initialized
INFO - 2016-02-26 10:47:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:47:07 --> Controller Class Initialized
INFO - 2016-02-26 10:47:07 --> Model Class Initialized
INFO - 2016-02-26 10:47:07 --> Model Class Initialized
INFO - 2016-02-26 10:47:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:47:07 --> Pagination Class Initialized
INFO - 2016-02-26 10:47:07 --> Helper loaded: text_helper
INFO - 2016-02-26 10:47:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:47:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:47:07 --> Final output sent to browser
DEBUG - 2016-02-26 13:47:07 --> Total execution time: 1.1176
INFO - 2016-02-26 10:47:08 --> Config Class Initialized
INFO - 2016-02-26 10:47:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:47:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:47:08 --> Utf8 Class Initialized
INFO - 2016-02-26 10:47:08 --> URI Class Initialized
INFO - 2016-02-26 10:47:08 --> Router Class Initialized
INFO - 2016-02-26 10:47:08 --> Output Class Initialized
INFO - 2016-02-26 10:47:08 --> Security Class Initialized
DEBUG - 2016-02-26 10:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:47:08 --> Input Class Initialized
INFO - 2016-02-26 10:47:08 --> Language Class Initialized
INFO - 2016-02-26 10:47:08 --> Loader Class Initialized
INFO - 2016-02-26 10:47:08 --> Helper loaded: url_helper
INFO - 2016-02-26 10:47:08 --> Helper loaded: file_helper
INFO - 2016-02-26 10:47:08 --> Helper loaded: date_helper
INFO - 2016-02-26 10:47:08 --> Helper loaded: form_helper
INFO - 2016-02-26 10:47:08 --> Database Driver Class Initialized
INFO - 2016-02-26 10:47:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:47:09 --> Controller Class Initialized
INFO - 2016-02-26 10:47:09 --> Model Class Initialized
INFO - 2016-02-26 10:47:09 --> Model Class Initialized
INFO - 2016-02-26 10:47:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:47:09 --> Pagination Class Initialized
INFO - 2016-02-26 10:47:09 --> Helper loaded: text_helper
INFO - 2016-02-26 10:47:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:47:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:47:09 --> Final output sent to browser
DEBUG - 2016-02-26 13:47:09 --> Total execution time: 1.1484
INFO - 2016-02-26 10:47:49 --> Config Class Initialized
INFO - 2016-02-26 10:47:49 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:47:50 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:47:50 --> Utf8 Class Initialized
INFO - 2016-02-26 10:47:50 --> URI Class Initialized
INFO - 2016-02-26 10:47:50 --> Router Class Initialized
INFO - 2016-02-26 10:47:50 --> Output Class Initialized
INFO - 2016-02-26 10:47:50 --> Security Class Initialized
DEBUG - 2016-02-26 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:47:50 --> Input Class Initialized
INFO - 2016-02-26 10:47:50 --> Language Class Initialized
INFO - 2016-02-26 10:47:50 --> Loader Class Initialized
INFO - 2016-02-26 10:47:50 --> Helper loaded: url_helper
INFO - 2016-02-26 10:47:50 --> Helper loaded: file_helper
INFO - 2016-02-26 10:47:50 --> Helper loaded: date_helper
INFO - 2016-02-26 10:47:50 --> Helper loaded: form_helper
INFO - 2016-02-26 10:47:50 --> Database Driver Class Initialized
INFO - 2016-02-26 10:47:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:47:51 --> Controller Class Initialized
INFO - 2016-02-26 10:47:51 --> Model Class Initialized
INFO - 2016-02-26 10:47:51 --> Model Class Initialized
INFO - 2016-02-26 10:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:47:51 --> Pagination Class Initialized
INFO - 2016-02-26 10:47:51 --> Helper loaded: text_helper
INFO - 2016-02-26 10:47:51 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:47:51 --> Final output sent to browser
DEBUG - 2016-02-26 13:47:51 --> Total execution time: 1.1064
INFO - 2016-02-26 10:47:51 --> Config Class Initialized
INFO - 2016-02-26 10:47:51 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:47:51 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:47:51 --> Utf8 Class Initialized
INFO - 2016-02-26 10:47:51 --> URI Class Initialized
INFO - 2016-02-26 10:47:51 --> Router Class Initialized
INFO - 2016-02-26 10:47:51 --> Output Class Initialized
INFO - 2016-02-26 10:47:51 --> Security Class Initialized
DEBUG - 2016-02-26 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:47:51 --> Input Class Initialized
INFO - 2016-02-26 10:47:51 --> Language Class Initialized
INFO - 2016-02-26 10:47:51 --> Loader Class Initialized
INFO - 2016-02-26 10:47:51 --> Helper loaded: url_helper
INFO - 2016-02-26 10:47:51 --> Helper loaded: file_helper
INFO - 2016-02-26 10:47:51 --> Helper loaded: date_helper
INFO - 2016-02-26 10:47:51 --> Helper loaded: form_helper
INFO - 2016-02-26 10:47:51 --> Database Driver Class Initialized
INFO - 2016-02-26 10:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:47:52 --> Controller Class Initialized
INFO - 2016-02-26 10:47:52 --> Model Class Initialized
INFO - 2016-02-26 10:47:52 --> Model Class Initialized
INFO - 2016-02-26 10:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:47:52 --> Pagination Class Initialized
INFO - 2016-02-26 10:47:52 --> Helper loaded: text_helper
INFO - 2016-02-26 10:47:52 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:47:52 --> Final output sent to browser
DEBUG - 2016-02-26 13:47:52 --> Total execution time: 1.1219
INFO - 2016-02-26 10:56:32 --> Config Class Initialized
INFO - 2016-02-26 10:56:32 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:56:32 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:56:32 --> Utf8 Class Initialized
INFO - 2016-02-26 10:56:32 --> URI Class Initialized
DEBUG - 2016-02-26 10:56:32 --> No URI present. Default controller set.
INFO - 2016-02-26 10:56:32 --> Router Class Initialized
INFO - 2016-02-26 10:56:32 --> Output Class Initialized
INFO - 2016-02-26 10:56:32 --> Security Class Initialized
DEBUG - 2016-02-26 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:56:32 --> Input Class Initialized
INFO - 2016-02-26 10:56:32 --> Language Class Initialized
INFO - 2016-02-26 10:56:32 --> Loader Class Initialized
INFO - 2016-02-26 10:56:32 --> Helper loaded: url_helper
INFO - 2016-02-26 10:56:32 --> Helper loaded: file_helper
INFO - 2016-02-26 10:56:32 --> Helper loaded: date_helper
INFO - 2016-02-26 10:56:32 --> Helper loaded: form_helper
INFO - 2016-02-26 10:56:32 --> Database Driver Class Initialized
INFO - 2016-02-26 10:56:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:56:33 --> Controller Class Initialized
INFO - 2016-02-26 10:56:33 --> Model Class Initialized
INFO - 2016-02-26 10:56:33 --> Model Class Initialized
INFO - 2016-02-26 10:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:56:33 --> Pagination Class Initialized
INFO - 2016-02-26 10:56:33 --> Helper loaded: text_helper
INFO - 2016-02-26 10:56:33 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 13:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:56:33 --> Final output sent to browser
DEBUG - 2016-02-26 13:56:33 --> Total execution time: 1.1087
INFO - 2016-02-26 10:56:44 --> Config Class Initialized
INFO - 2016-02-26 10:56:44 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:56:44 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:56:44 --> Utf8 Class Initialized
INFO - 2016-02-26 10:56:44 --> URI Class Initialized
INFO - 2016-02-26 10:56:44 --> Router Class Initialized
INFO - 2016-02-26 10:56:44 --> Output Class Initialized
INFO - 2016-02-26 10:56:44 --> Security Class Initialized
DEBUG - 2016-02-26 10:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:56:44 --> Input Class Initialized
INFO - 2016-02-26 10:56:44 --> Language Class Initialized
INFO - 2016-02-26 10:56:44 --> Loader Class Initialized
INFO - 2016-02-26 10:56:44 --> Helper loaded: url_helper
INFO - 2016-02-26 10:56:44 --> Helper loaded: file_helper
INFO - 2016-02-26 10:56:44 --> Helper loaded: date_helper
INFO - 2016-02-26 10:56:44 --> Helper loaded: form_helper
INFO - 2016-02-26 10:56:44 --> Database Driver Class Initialized
INFO - 2016-02-26 10:56:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:56:45 --> Controller Class Initialized
INFO - 2016-02-26 10:56:45 --> Model Class Initialized
INFO - 2016-02-26 10:56:45 --> Model Class Initialized
INFO - 2016-02-26 10:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:56:45 --> Pagination Class Initialized
INFO - 2016-02-26 10:56:45 --> Helper loaded: text_helper
INFO - 2016-02-26 10:56:45 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 13:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 13:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:56:45 --> Final output sent to browser
DEBUG - 2016-02-26 13:56:45 --> Total execution time: 1.1381
INFO - 2016-02-26 10:56:56 --> Config Class Initialized
INFO - 2016-02-26 10:56:56 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:56:56 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:56:56 --> Utf8 Class Initialized
INFO - 2016-02-26 10:56:56 --> URI Class Initialized
INFO - 2016-02-26 10:56:56 --> Router Class Initialized
INFO - 2016-02-26 10:56:56 --> Output Class Initialized
INFO - 2016-02-26 10:56:56 --> Security Class Initialized
DEBUG - 2016-02-26 10:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:56:56 --> Input Class Initialized
INFO - 2016-02-26 10:56:56 --> Language Class Initialized
INFO - 2016-02-26 10:56:56 --> Loader Class Initialized
INFO - 2016-02-26 10:56:56 --> Helper loaded: url_helper
INFO - 2016-02-26 10:56:56 --> Helper loaded: file_helper
INFO - 2016-02-26 10:56:56 --> Helper loaded: date_helper
INFO - 2016-02-26 10:56:56 --> Helper loaded: form_helper
INFO - 2016-02-26 10:56:56 --> Database Driver Class Initialized
INFO - 2016-02-26 10:56:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:56:57 --> Controller Class Initialized
INFO - 2016-02-26 10:56:57 --> Model Class Initialized
INFO - 2016-02-26 10:56:57 --> Model Class Initialized
INFO - 2016-02-26 10:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:56:57 --> Pagination Class Initialized
INFO - 2016-02-26 10:56:57 --> Helper loaded: text_helper
INFO - 2016-02-26 10:56:57 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:56:57 --> Final output sent to browser
DEBUG - 2016-02-26 13:56:57 --> Total execution time: 1.1427
INFO - 2016-02-26 10:56:57 --> Config Class Initialized
INFO - 2016-02-26 10:56:57 --> Hooks Class Initialized
DEBUG - 2016-02-26 10:56:57 --> UTF-8 Support Enabled
INFO - 2016-02-26 10:56:57 --> Utf8 Class Initialized
INFO - 2016-02-26 10:56:57 --> URI Class Initialized
INFO - 2016-02-26 10:56:57 --> Router Class Initialized
INFO - 2016-02-26 10:56:57 --> Output Class Initialized
INFO - 2016-02-26 10:56:57 --> Security Class Initialized
DEBUG - 2016-02-26 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 10:56:57 --> Input Class Initialized
INFO - 2016-02-26 10:56:57 --> Language Class Initialized
INFO - 2016-02-26 10:56:57 --> Loader Class Initialized
INFO - 2016-02-26 10:56:57 --> Helper loaded: url_helper
INFO - 2016-02-26 10:56:57 --> Helper loaded: file_helper
INFO - 2016-02-26 10:56:57 --> Helper loaded: date_helper
INFO - 2016-02-26 10:56:57 --> Helper loaded: form_helper
INFO - 2016-02-26 10:56:57 --> Database Driver Class Initialized
INFO - 2016-02-26 10:56:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 10:56:58 --> Controller Class Initialized
INFO - 2016-02-26 10:56:58 --> Model Class Initialized
INFO - 2016-02-26 10:56:58 --> Model Class Initialized
INFO - 2016-02-26 10:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 10:56:58 --> Pagination Class Initialized
INFO - 2016-02-26 10:56:58 --> Helper loaded: text_helper
INFO - 2016-02-26 10:56:58 --> Helper loaded: cookie_helper
INFO - 2016-02-26 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 13:56:58 --> Final output sent to browser
DEBUG - 2016-02-26 13:56:58 --> Total execution time: 1.1125
INFO - 2016-02-26 11:21:27 --> Config Class Initialized
INFO - 2016-02-26 11:21:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:21:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:21:27 --> Utf8 Class Initialized
INFO - 2016-02-26 11:21:27 --> URI Class Initialized
INFO - 2016-02-26 11:21:27 --> Router Class Initialized
INFO - 2016-02-26 11:21:27 --> Output Class Initialized
INFO - 2016-02-26 11:21:27 --> Security Class Initialized
DEBUG - 2016-02-26 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:21:27 --> Input Class Initialized
INFO - 2016-02-26 11:21:27 --> Language Class Initialized
INFO - 2016-02-26 11:21:27 --> Loader Class Initialized
INFO - 2016-02-26 11:21:27 --> Helper loaded: url_helper
INFO - 2016-02-26 11:21:27 --> Helper loaded: file_helper
INFO - 2016-02-26 11:21:27 --> Helper loaded: date_helper
INFO - 2016-02-26 11:21:27 --> Helper loaded: form_helper
INFO - 2016-02-26 11:21:27 --> Database Driver Class Initialized
INFO - 2016-02-26 11:21:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:21:28 --> Controller Class Initialized
INFO - 2016-02-26 11:21:28 --> Model Class Initialized
INFO - 2016-02-26 11:21:28 --> Model Class Initialized
INFO - 2016-02-26 11:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:21:28 --> Pagination Class Initialized
INFO - 2016-02-26 11:21:28 --> Helper loaded: text_helper
INFO - 2016-02-26 11:21:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 14:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 14:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 14:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 14:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 14:21:28 --> Final output sent to browser
DEBUG - 2016-02-26 14:21:28 --> Total execution time: 1.1726
INFO - 2016-02-26 11:21:28 --> Config Class Initialized
INFO - 2016-02-26 11:21:28 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:21:28 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:21:28 --> Utf8 Class Initialized
INFO - 2016-02-26 11:21:28 --> URI Class Initialized
INFO - 2016-02-26 11:21:28 --> Router Class Initialized
INFO - 2016-02-26 11:21:28 --> Output Class Initialized
INFO - 2016-02-26 11:21:28 --> Security Class Initialized
DEBUG - 2016-02-26 11:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:21:28 --> Input Class Initialized
INFO - 2016-02-26 11:21:28 --> Language Class Initialized
INFO - 2016-02-26 11:21:28 --> Loader Class Initialized
INFO - 2016-02-26 11:21:28 --> Helper loaded: url_helper
INFO - 2016-02-26 11:21:28 --> Helper loaded: file_helper
INFO - 2016-02-26 11:21:28 --> Helper loaded: date_helper
INFO - 2016-02-26 11:21:28 --> Helper loaded: form_helper
INFO - 2016-02-26 11:21:28 --> Database Driver Class Initialized
INFO - 2016-02-26 11:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:21:29 --> Controller Class Initialized
INFO - 2016-02-26 11:21:29 --> Model Class Initialized
INFO - 2016-02-26 11:21:29 --> Model Class Initialized
INFO - 2016-02-26 11:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:21:29 --> Pagination Class Initialized
INFO - 2016-02-26 11:21:29 --> Helper loaded: text_helper
INFO - 2016-02-26 11:21:29 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 14:21:29 --> Final output sent to browser
DEBUG - 2016-02-26 14:21:29 --> Total execution time: 1.1067
INFO - 2016-02-26 11:21:40 --> Config Class Initialized
INFO - 2016-02-26 11:21:40 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:21:40 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:21:40 --> Utf8 Class Initialized
INFO - 2016-02-26 11:21:40 --> URI Class Initialized
INFO - 2016-02-26 11:21:40 --> Router Class Initialized
INFO - 2016-02-26 11:21:40 --> Output Class Initialized
INFO - 2016-02-26 11:21:40 --> Security Class Initialized
DEBUG - 2016-02-26 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:21:40 --> Input Class Initialized
INFO - 2016-02-26 11:21:40 --> Language Class Initialized
INFO - 2016-02-26 11:21:40 --> Loader Class Initialized
INFO - 2016-02-26 11:21:40 --> Helper loaded: url_helper
INFO - 2016-02-26 11:21:40 --> Helper loaded: file_helper
INFO - 2016-02-26 11:21:40 --> Helper loaded: date_helper
INFO - 2016-02-26 11:21:40 --> Helper loaded: form_helper
INFO - 2016-02-26 11:21:40 --> Database Driver Class Initialized
INFO - 2016-02-26 11:21:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:21:41 --> Controller Class Initialized
INFO - 2016-02-26 11:21:41 --> Model Class Initialized
INFO - 2016-02-26 11:21:41 --> Model Class Initialized
INFO - 2016-02-26 11:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:21:41 --> Pagination Class Initialized
INFO - 2016-02-26 11:21:41 --> Helper loaded: text_helper
INFO - 2016-02-26 11:21:41 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:21:41 --> Upload Class Initialized
INFO - 2016-02-26 14:21:41 --> Image Lib Class Initialized
DEBUG - 2016-02-26 14:21:41 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 14:21:42 --> Final output sent to browser
DEBUG - 2016-02-26 14:21:42 --> Total execution time: 1.1808
INFO - 2016-02-26 11:22:31 --> Config Class Initialized
INFO - 2016-02-26 11:22:31 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:22:31 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:22:31 --> Utf8 Class Initialized
INFO - 2016-02-26 11:22:31 --> URI Class Initialized
INFO - 2016-02-26 11:22:31 --> Router Class Initialized
INFO - 2016-02-26 11:22:31 --> Output Class Initialized
INFO - 2016-02-26 11:22:31 --> Security Class Initialized
DEBUG - 2016-02-26 11:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:22:31 --> Input Class Initialized
INFO - 2016-02-26 11:22:31 --> Language Class Initialized
INFO - 2016-02-26 11:22:31 --> Loader Class Initialized
INFO - 2016-02-26 11:22:31 --> Helper loaded: url_helper
INFO - 2016-02-26 11:22:31 --> Helper loaded: file_helper
INFO - 2016-02-26 11:22:31 --> Helper loaded: date_helper
INFO - 2016-02-26 11:22:31 --> Helper loaded: form_helper
INFO - 2016-02-26 11:22:31 --> Database Driver Class Initialized
INFO - 2016-02-26 11:22:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:22:32 --> Controller Class Initialized
INFO - 2016-02-26 11:22:32 --> Model Class Initialized
INFO - 2016-02-26 11:22:32 --> Model Class Initialized
INFO - 2016-02-26 11:22:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:22:32 --> Pagination Class Initialized
INFO - 2016-02-26 11:22:32 --> Helper loaded: text_helper
INFO - 2016-02-26 11:22:32 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 14:22:32 --> Final output sent to browser
DEBUG - 2016-02-26 14:22:32 --> Total execution time: 1.1639
INFO - 2016-02-26 11:43:08 --> Config Class Initialized
INFO - 2016-02-26 11:43:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:43:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:43:08 --> Utf8 Class Initialized
INFO - 2016-02-26 11:43:08 --> URI Class Initialized
INFO - 2016-02-26 11:43:08 --> Router Class Initialized
INFO - 2016-02-26 11:43:08 --> Output Class Initialized
INFO - 2016-02-26 11:43:08 --> Security Class Initialized
DEBUG - 2016-02-26 11:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:43:08 --> Input Class Initialized
INFO - 2016-02-26 11:43:08 --> Language Class Initialized
INFO - 2016-02-26 11:43:08 --> Loader Class Initialized
INFO - 2016-02-26 11:43:08 --> Helper loaded: url_helper
INFO - 2016-02-26 11:43:08 --> Helper loaded: file_helper
INFO - 2016-02-26 11:43:08 --> Helper loaded: date_helper
INFO - 2016-02-26 11:43:08 --> Helper loaded: form_helper
INFO - 2016-02-26 11:43:08 --> Database Driver Class Initialized
INFO - 2016-02-26 11:43:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:43:09 --> Controller Class Initialized
INFO - 2016-02-26 11:43:09 --> Model Class Initialized
INFO - 2016-02-26 11:43:09 --> Model Class Initialized
INFO - 2016-02-26 11:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:43:09 --> Pagination Class Initialized
INFO - 2016-02-26 11:43:09 --> Helper loaded: text_helper
INFO - 2016-02-26 11:43:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 14:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 14:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 14:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 14:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 14:43:09 --> Final output sent to browser
DEBUG - 2016-02-26 14:43:09 --> Total execution time: 1.2694
INFO - 2016-02-26 11:43:09 --> Config Class Initialized
INFO - 2016-02-26 11:43:09 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:43:09 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:43:09 --> Utf8 Class Initialized
INFO - 2016-02-26 11:43:09 --> URI Class Initialized
INFO - 2016-02-26 11:43:09 --> Router Class Initialized
INFO - 2016-02-26 11:43:09 --> Output Class Initialized
INFO - 2016-02-26 11:43:09 --> Security Class Initialized
DEBUG - 2016-02-26 11:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:43:10 --> Input Class Initialized
INFO - 2016-02-26 11:43:10 --> Language Class Initialized
INFO - 2016-02-26 11:43:10 --> Loader Class Initialized
INFO - 2016-02-26 11:43:10 --> Helper loaded: url_helper
INFO - 2016-02-26 11:43:10 --> Helper loaded: file_helper
INFO - 2016-02-26 11:43:10 --> Helper loaded: date_helper
INFO - 2016-02-26 11:43:10 --> Helper loaded: form_helper
INFO - 2016-02-26 11:43:10 --> Database Driver Class Initialized
INFO - 2016-02-26 11:43:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:43:11 --> Controller Class Initialized
INFO - 2016-02-26 11:43:11 --> Model Class Initialized
INFO - 2016-02-26 11:43:11 --> Model Class Initialized
INFO - 2016-02-26 11:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:43:11 --> Pagination Class Initialized
INFO - 2016-02-26 11:43:11 --> Helper loaded: text_helper
INFO - 2016-02-26 11:43:11 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 14:43:11 --> Final output sent to browser
DEBUG - 2016-02-26 14:43:11 --> Total execution time: 1.1424
INFO - 2016-02-26 11:43:17 --> Config Class Initialized
INFO - 2016-02-26 11:43:17 --> Hooks Class Initialized
DEBUG - 2016-02-26 11:43:17 --> UTF-8 Support Enabled
INFO - 2016-02-26 11:43:17 --> Utf8 Class Initialized
INFO - 2016-02-26 11:43:17 --> URI Class Initialized
INFO - 2016-02-26 11:43:17 --> Router Class Initialized
INFO - 2016-02-26 11:43:17 --> Output Class Initialized
INFO - 2016-02-26 11:43:17 --> Security Class Initialized
DEBUG - 2016-02-26 11:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 11:43:17 --> Input Class Initialized
INFO - 2016-02-26 11:43:17 --> Language Class Initialized
INFO - 2016-02-26 11:43:17 --> Loader Class Initialized
INFO - 2016-02-26 11:43:17 --> Helper loaded: url_helper
INFO - 2016-02-26 11:43:17 --> Helper loaded: file_helper
INFO - 2016-02-26 11:43:17 --> Helper loaded: date_helper
INFO - 2016-02-26 11:43:17 --> Helper loaded: form_helper
INFO - 2016-02-26 11:43:17 --> Database Driver Class Initialized
INFO - 2016-02-26 11:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 11:43:19 --> Controller Class Initialized
INFO - 2016-02-26 11:43:19 --> Model Class Initialized
INFO - 2016-02-26 11:43:19 --> Model Class Initialized
INFO - 2016-02-26 11:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 11:43:19 --> Pagination Class Initialized
INFO - 2016-02-26 11:43:19 --> Helper loaded: text_helper
INFO - 2016-02-26 11:43:19 --> Helper loaded: cookie_helper
INFO - 2016-02-26 14:43:19 --> Upload Class Initialized
INFO - 2016-02-26 14:43:19 --> Image Lib Class Initialized
DEBUG - 2016-02-26 14:43:19 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 14:43:19 --> Final output sent to browser
DEBUG - 2016-02-26 14:43:19 --> Total execution time: 1.1626
INFO - 2016-02-26 13:22:01 --> Config Class Initialized
INFO - 2016-02-26 13:22:01 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:22:01 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:22:01 --> Utf8 Class Initialized
INFO - 2016-02-26 13:22:01 --> URI Class Initialized
INFO - 2016-02-26 13:22:01 --> Router Class Initialized
INFO - 2016-02-26 13:22:01 --> Output Class Initialized
INFO - 2016-02-26 13:22:01 --> Security Class Initialized
DEBUG - 2016-02-26 13:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:22:01 --> Input Class Initialized
INFO - 2016-02-26 13:22:01 --> Language Class Initialized
INFO - 2016-02-26 13:22:01 --> Loader Class Initialized
INFO - 2016-02-26 13:22:01 --> Helper loaded: url_helper
INFO - 2016-02-26 13:22:01 --> Helper loaded: file_helper
INFO - 2016-02-26 13:22:01 --> Helper loaded: date_helper
INFO - 2016-02-26 13:22:01 --> Helper loaded: form_helper
INFO - 2016-02-26 13:22:01 --> Database Driver Class Initialized
INFO - 2016-02-26 13:22:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:22:02 --> Controller Class Initialized
INFO - 2016-02-26 13:22:02 --> Model Class Initialized
INFO - 2016-02-26 13:22:02 --> Model Class Initialized
INFO - 2016-02-26 13:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:22:02 --> Pagination Class Initialized
INFO - 2016-02-26 13:22:02 --> Helper loaded: text_helper
INFO - 2016-02-26 13:22:02 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-26 16:22:02 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
INFO - 2016-02-26 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-02-26 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:22:02 --> Final output sent to browser
DEBUG - 2016-02-26 16:22:02 --> Total execution time: 1.1757
INFO - 2016-02-26 13:34:52 --> Config Class Initialized
INFO - 2016-02-26 13:34:52 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:34:52 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:34:52 --> Utf8 Class Initialized
INFO - 2016-02-26 13:34:52 --> URI Class Initialized
DEBUG - 2016-02-26 13:34:52 --> No URI present. Default controller set.
INFO - 2016-02-26 13:34:52 --> Router Class Initialized
INFO - 2016-02-26 13:34:52 --> Output Class Initialized
INFO - 2016-02-26 13:34:52 --> Security Class Initialized
DEBUG - 2016-02-26 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:34:52 --> Input Class Initialized
INFO - 2016-02-26 13:34:52 --> Language Class Initialized
INFO - 2016-02-26 13:34:52 --> Loader Class Initialized
INFO - 2016-02-26 13:34:52 --> Helper loaded: url_helper
INFO - 2016-02-26 13:34:52 --> Helper loaded: file_helper
INFO - 2016-02-26 13:34:52 --> Helper loaded: date_helper
INFO - 2016-02-26 13:34:52 --> Helper loaded: form_helper
INFO - 2016-02-26 13:34:52 --> Database Driver Class Initialized
INFO - 2016-02-26 13:34:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:34:53 --> Controller Class Initialized
INFO - 2016-02-26 13:34:53 --> Model Class Initialized
INFO - 2016-02-26 13:34:53 --> Model Class Initialized
INFO - 2016-02-26 13:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:34:53 --> Pagination Class Initialized
INFO - 2016-02-26 13:34:53 --> Helper loaded: text_helper
INFO - 2016-02-26 13:34:53 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-26 16:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:34:54 --> Final output sent to browser
DEBUG - 2016-02-26 16:34:54 --> Total execution time: 1.1419
INFO - 2016-02-26 13:34:55 --> Config Class Initialized
INFO - 2016-02-26 13:34:55 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:34:55 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:34:55 --> Utf8 Class Initialized
INFO - 2016-02-26 13:34:55 --> URI Class Initialized
INFO - 2016-02-26 13:34:55 --> Router Class Initialized
INFO - 2016-02-26 13:34:55 --> Output Class Initialized
INFO - 2016-02-26 13:34:55 --> Security Class Initialized
DEBUG - 2016-02-26 13:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:34:55 --> Input Class Initialized
INFO - 2016-02-26 13:34:55 --> Language Class Initialized
INFO - 2016-02-26 13:34:55 --> Loader Class Initialized
INFO - 2016-02-26 13:34:55 --> Helper loaded: url_helper
INFO - 2016-02-26 13:34:55 --> Helper loaded: file_helper
INFO - 2016-02-26 13:34:55 --> Helper loaded: date_helper
INFO - 2016-02-26 13:34:55 --> Helper loaded: form_helper
INFO - 2016-02-26 13:34:55 --> Database Driver Class Initialized
INFO - 2016-02-26 13:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:34:56 --> Controller Class Initialized
INFO - 2016-02-26 13:34:56 --> Model Class Initialized
INFO - 2016-02-26 13:34:56 --> Model Class Initialized
INFO - 2016-02-26 13:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:34:56 --> Pagination Class Initialized
INFO - 2016-02-26 13:34:56 --> Helper loaded: text_helper
INFO - 2016-02-26 13:34:56 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 16:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:34:56 --> Final output sent to browser
DEBUG - 2016-02-26 16:34:56 --> Total execution time: 1.1192
INFO - 2016-02-26 13:34:57 --> Config Class Initialized
INFO - 2016-02-26 13:34:57 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:34:57 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:34:57 --> Utf8 Class Initialized
INFO - 2016-02-26 13:34:57 --> URI Class Initialized
INFO - 2016-02-26 13:34:57 --> Router Class Initialized
INFO - 2016-02-26 13:34:57 --> Output Class Initialized
INFO - 2016-02-26 13:34:57 --> Security Class Initialized
DEBUG - 2016-02-26 13:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:34:57 --> Input Class Initialized
INFO - 2016-02-26 13:34:57 --> Language Class Initialized
INFO - 2016-02-26 13:34:57 --> Loader Class Initialized
INFO - 2016-02-26 13:34:57 --> Helper loaded: url_helper
INFO - 2016-02-26 13:34:57 --> Helper loaded: file_helper
INFO - 2016-02-26 13:34:57 --> Helper loaded: date_helper
INFO - 2016-02-26 13:34:57 --> Helper loaded: form_helper
INFO - 2016-02-26 13:34:57 --> Database Driver Class Initialized
INFO - 2016-02-26 13:34:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:34:58 --> Controller Class Initialized
INFO - 2016-02-26 13:34:58 --> Model Class Initialized
INFO - 2016-02-26 13:34:58 --> Model Class Initialized
INFO - 2016-02-26 13:34:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:34:58 --> Pagination Class Initialized
INFO - 2016-02-26 13:34:58 --> Helper loaded: text_helper
INFO - 2016-02-26 13:34:58 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:34:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:34:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:34:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 16:34:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 16:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:34:59 --> Final output sent to browser
DEBUG - 2016-02-26 16:34:59 --> Total execution time: 1.1371
INFO - 2016-02-26 13:34:59 --> Config Class Initialized
INFO - 2016-02-26 13:34:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:34:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:34:59 --> Utf8 Class Initialized
INFO - 2016-02-26 13:34:59 --> URI Class Initialized
INFO - 2016-02-26 13:34:59 --> Router Class Initialized
INFO - 2016-02-26 13:34:59 --> Output Class Initialized
INFO - 2016-02-26 13:34:59 --> Security Class Initialized
DEBUG - 2016-02-26 13:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:34:59 --> Input Class Initialized
INFO - 2016-02-26 13:34:59 --> Language Class Initialized
INFO - 2016-02-26 13:34:59 --> Loader Class Initialized
INFO - 2016-02-26 13:34:59 --> Helper loaded: url_helper
INFO - 2016-02-26 13:34:59 --> Helper loaded: file_helper
INFO - 2016-02-26 13:34:59 --> Helper loaded: date_helper
INFO - 2016-02-26 13:34:59 --> Helper loaded: form_helper
INFO - 2016-02-26 13:34:59 --> Database Driver Class Initialized
INFO - 2016-02-26 13:35:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:35:00 --> Controller Class Initialized
INFO - 2016-02-26 13:35:00 --> Model Class Initialized
INFO - 2016-02-26 13:35:00 --> Model Class Initialized
INFO - 2016-02-26 13:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:35:00 --> Pagination Class Initialized
INFO - 2016-02-26 13:35:00 --> Helper loaded: text_helper
INFO - 2016-02-26 13:35:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 16:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 16:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:35:00 --> Final output sent to browser
DEBUG - 2016-02-26 16:35:00 --> Total execution time: 1.1068
INFO - 2016-02-26 13:35:32 --> Config Class Initialized
INFO - 2016-02-26 13:35:32 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:35:32 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:35:32 --> Utf8 Class Initialized
INFO - 2016-02-26 13:35:32 --> URI Class Initialized
INFO - 2016-02-26 13:35:32 --> Router Class Initialized
INFO - 2016-02-26 13:35:32 --> Output Class Initialized
INFO - 2016-02-26 13:35:32 --> Security Class Initialized
DEBUG - 2016-02-26 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:35:32 --> Input Class Initialized
INFO - 2016-02-26 13:35:32 --> Language Class Initialized
INFO - 2016-02-26 13:35:32 --> Loader Class Initialized
INFO - 2016-02-26 13:35:32 --> Helper loaded: url_helper
INFO - 2016-02-26 13:35:32 --> Helper loaded: file_helper
INFO - 2016-02-26 13:35:32 --> Helper loaded: date_helper
INFO - 2016-02-26 13:35:32 --> Helper loaded: form_helper
INFO - 2016-02-26 13:35:32 --> Database Driver Class Initialized
INFO - 2016-02-26 13:35:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:35:33 --> Controller Class Initialized
INFO - 2016-02-26 13:35:33 --> Model Class Initialized
INFO - 2016-02-26 13:35:33 --> Model Class Initialized
INFO - 2016-02-26 13:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:35:33 --> Pagination Class Initialized
INFO - 2016-02-26 13:35:33 --> Helper loaded: text_helper
INFO - 2016-02-26 13:35:33 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:35:33 --> Upload Class Initialized
INFO - 2016-02-26 16:35:33 --> Image Lib Class Initialized
DEBUG - 2016-02-26 16:35:33 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 16:35:33 --> Final output sent to browser
DEBUG - 2016-02-26 16:35:33 --> Total execution time: 1.1719
INFO - 2016-02-26 13:37:13 --> Config Class Initialized
INFO - 2016-02-26 13:37:13 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:37:13 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:37:13 --> Utf8 Class Initialized
INFO - 2016-02-26 13:37:13 --> URI Class Initialized
INFO - 2016-02-26 13:37:13 --> Router Class Initialized
INFO - 2016-02-26 13:37:13 --> Output Class Initialized
INFO - 2016-02-26 13:37:13 --> Security Class Initialized
DEBUG - 2016-02-26 13:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:37:13 --> Input Class Initialized
INFO - 2016-02-26 13:37:13 --> Language Class Initialized
INFO - 2016-02-26 13:37:13 --> Loader Class Initialized
INFO - 2016-02-26 13:37:13 --> Helper loaded: url_helper
INFO - 2016-02-26 13:37:13 --> Helper loaded: file_helper
INFO - 2016-02-26 13:37:13 --> Helper loaded: date_helper
INFO - 2016-02-26 13:37:13 --> Helper loaded: form_helper
INFO - 2016-02-26 13:37:13 --> Database Driver Class Initialized
INFO - 2016-02-26 13:37:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:37:14 --> Controller Class Initialized
INFO - 2016-02-26 13:37:14 --> Model Class Initialized
INFO - 2016-02-26 13:37:14 --> Model Class Initialized
INFO - 2016-02-26 13:37:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:37:14 --> Pagination Class Initialized
INFO - 2016-02-26 13:37:14 --> Helper loaded: text_helper
INFO - 2016-02-26 13:37:14 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:37:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:37:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:37:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 16:37:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 16:37:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:37:14 --> Final output sent to browser
DEBUG - 2016-02-26 16:37:14 --> Total execution time: 1.1602
INFO - 2016-02-26 13:37:15 --> Config Class Initialized
INFO - 2016-02-26 13:37:15 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:37:15 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:37:15 --> Utf8 Class Initialized
INFO - 2016-02-26 13:37:15 --> URI Class Initialized
INFO - 2016-02-26 13:37:15 --> Router Class Initialized
INFO - 2016-02-26 13:37:15 --> Output Class Initialized
INFO - 2016-02-26 13:37:15 --> Security Class Initialized
DEBUG - 2016-02-26 13:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:37:15 --> Input Class Initialized
INFO - 2016-02-26 13:37:15 --> Language Class Initialized
INFO - 2016-02-26 13:37:15 --> Loader Class Initialized
INFO - 2016-02-26 13:37:15 --> Helper loaded: url_helper
INFO - 2016-02-26 13:37:15 --> Helper loaded: file_helper
INFO - 2016-02-26 13:37:15 --> Helper loaded: date_helper
INFO - 2016-02-26 13:37:15 --> Helper loaded: form_helper
INFO - 2016-02-26 13:37:15 --> Database Driver Class Initialized
INFO - 2016-02-26 13:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:37:16 --> Controller Class Initialized
INFO - 2016-02-26 13:37:16 --> Model Class Initialized
INFO - 2016-02-26 13:37:16 --> Model Class Initialized
INFO - 2016-02-26 13:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:37:16 --> Pagination Class Initialized
INFO - 2016-02-26 13:37:16 --> Helper loaded: text_helper
INFO - 2016-02-26 13:37:16 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 16:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 16:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 16:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 16:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 16:37:16 --> Final output sent to browser
DEBUG - 2016-02-26 16:37:16 --> Total execution time: 1.1783
INFO - 2016-02-26 13:37:27 --> Config Class Initialized
INFO - 2016-02-26 13:37:27 --> Hooks Class Initialized
DEBUG - 2016-02-26 13:37:27 --> UTF-8 Support Enabled
INFO - 2016-02-26 13:37:27 --> Utf8 Class Initialized
INFO - 2016-02-26 13:37:27 --> URI Class Initialized
INFO - 2016-02-26 13:37:27 --> Router Class Initialized
INFO - 2016-02-26 13:37:27 --> Output Class Initialized
INFO - 2016-02-26 13:37:27 --> Security Class Initialized
DEBUG - 2016-02-26 13:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 13:37:27 --> Input Class Initialized
INFO - 2016-02-26 13:37:27 --> Language Class Initialized
INFO - 2016-02-26 13:37:27 --> Loader Class Initialized
INFO - 2016-02-26 13:37:27 --> Helper loaded: url_helper
INFO - 2016-02-26 13:37:27 --> Helper loaded: file_helper
INFO - 2016-02-26 13:37:27 --> Helper loaded: date_helper
INFO - 2016-02-26 13:37:27 --> Helper loaded: form_helper
INFO - 2016-02-26 13:37:27 --> Database Driver Class Initialized
INFO - 2016-02-26 13:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 13:37:28 --> Controller Class Initialized
INFO - 2016-02-26 13:37:28 --> Model Class Initialized
INFO - 2016-02-26 13:37:28 --> Model Class Initialized
INFO - 2016-02-26 13:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 13:37:28 --> Pagination Class Initialized
INFO - 2016-02-26 13:37:28 --> Helper loaded: text_helper
INFO - 2016-02-26 13:37:28 --> Helper loaded: cookie_helper
INFO - 2016-02-26 16:37:28 --> Upload Class Initialized
INFO - 2016-02-26 16:37:28 --> Image Lib Class Initialized
DEBUG - 2016-02-26 16:37:28 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 16:37:28 --> Final output sent to browser
DEBUG - 2016-02-26 16:37:28 --> Total execution time: 1.1257
INFO - 2016-02-26 14:07:50 --> Config Class Initialized
INFO - 2016-02-26 14:07:50 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:07:50 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:07:50 --> Utf8 Class Initialized
INFO - 2016-02-26 14:07:50 --> URI Class Initialized
INFO - 2016-02-26 14:07:50 --> Router Class Initialized
INFO - 2016-02-26 14:07:50 --> Output Class Initialized
INFO - 2016-02-26 14:07:50 --> Security Class Initialized
DEBUG - 2016-02-26 14:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:07:50 --> Input Class Initialized
INFO - 2016-02-26 14:07:50 --> Language Class Initialized
INFO - 2016-02-26 14:07:50 --> Loader Class Initialized
INFO - 2016-02-26 14:07:50 --> Helper loaded: url_helper
INFO - 2016-02-26 14:07:50 --> Helper loaded: file_helper
INFO - 2016-02-26 14:07:50 --> Helper loaded: date_helper
INFO - 2016-02-26 14:07:50 --> Helper loaded: form_helper
INFO - 2016-02-26 14:07:50 --> Database Driver Class Initialized
INFO - 2016-02-26 14:07:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:07:51 --> Controller Class Initialized
INFO - 2016-02-26 14:07:51 --> Model Class Initialized
INFO - 2016-02-26 14:07:51 --> Model Class Initialized
INFO - 2016-02-26 14:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:07:51 --> Pagination Class Initialized
INFO - 2016-02-26 14:07:51 --> Helper loaded: text_helper
INFO - 2016-02-26 14:07:51 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:07:51 --> Final output sent to browser
DEBUG - 2016-02-26 17:07:51 --> Total execution time: 1.1589
INFO - 2016-02-26 14:07:51 --> Config Class Initialized
INFO - 2016-02-26 14:07:51 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:07:51 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:07:51 --> Utf8 Class Initialized
INFO - 2016-02-26 14:07:51 --> URI Class Initialized
INFO - 2016-02-26 14:07:51 --> Router Class Initialized
INFO - 2016-02-26 14:07:51 --> Output Class Initialized
INFO - 2016-02-26 14:07:51 --> Security Class Initialized
DEBUG - 2016-02-26 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:07:51 --> Input Class Initialized
INFO - 2016-02-26 14:07:51 --> Language Class Initialized
INFO - 2016-02-26 14:07:51 --> Loader Class Initialized
INFO - 2016-02-26 14:07:51 --> Helper loaded: url_helper
INFO - 2016-02-26 14:07:51 --> Helper loaded: file_helper
INFO - 2016-02-26 14:07:51 --> Helper loaded: date_helper
INFO - 2016-02-26 14:07:51 --> Helper loaded: form_helper
INFO - 2016-02-26 14:07:51 --> Database Driver Class Initialized
INFO - 2016-02-26 14:07:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:07:52 --> Controller Class Initialized
INFO - 2016-02-26 14:07:52 --> Model Class Initialized
INFO - 2016-02-26 14:07:52 --> Model Class Initialized
INFO - 2016-02-26 14:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:07:52 --> Pagination Class Initialized
INFO - 2016-02-26 14:07:52 --> Helper loaded: text_helper
INFO - 2016-02-26 14:07:52 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:07:52 --> Final output sent to browser
DEBUG - 2016-02-26 17:07:52 --> Total execution time: 1.1743
INFO - 2016-02-26 14:07:59 --> Config Class Initialized
INFO - 2016-02-26 14:07:59 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:07:59 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:07:59 --> Utf8 Class Initialized
INFO - 2016-02-26 14:07:59 --> URI Class Initialized
INFO - 2016-02-26 14:07:59 --> Router Class Initialized
INFO - 2016-02-26 14:07:59 --> Output Class Initialized
INFO - 2016-02-26 14:07:59 --> Security Class Initialized
DEBUG - 2016-02-26 14:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:07:59 --> Input Class Initialized
INFO - 2016-02-26 14:07:59 --> Language Class Initialized
INFO - 2016-02-26 14:07:59 --> Loader Class Initialized
INFO - 2016-02-26 14:07:59 --> Helper loaded: url_helper
INFO - 2016-02-26 14:07:59 --> Helper loaded: file_helper
INFO - 2016-02-26 14:07:59 --> Helper loaded: date_helper
INFO - 2016-02-26 14:07:59 --> Helper loaded: form_helper
INFO - 2016-02-26 14:07:59 --> Database Driver Class Initialized
INFO - 2016-02-26 14:08:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:08:00 --> Controller Class Initialized
INFO - 2016-02-26 14:08:00 --> Model Class Initialized
INFO - 2016-02-26 14:08:00 --> Model Class Initialized
INFO - 2016-02-26 14:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:08:00 --> Pagination Class Initialized
INFO - 2016-02-26 14:08:00 --> Helper loaded: text_helper
INFO - 2016-02-26 14:08:00 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:08:00 --> Final output sent to browser
DEBUG - 2016-02-26 17:08:00 --> Total execution time: 1.1382
INFO - 2016-02-26 14:08:00 --> Config Class Initialized
INFO - 2016-02-26 14:08:00 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:08:00 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:08:00 --> Utf8 Class Initialized
INFO - 2016-02-26 14:08:00 --> URI Class Initialized
INFO - 2016-02-26 14:08:00 --> Router Class Initialized
INFO - 2016-02-26 14:08:00 --> Output Class Initialized
INFO - 2016-02-26 14:08:00 --> Security Class Initialized
DEBUG - 2016-02-26 14:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:08:00 --> Input Class Initialized
INFO - 2016-02-26 14:08:00 --> Language Class Initialized
INFO - 2016-02-26 14:08:00 --> Loader Class Initialized
INFO - 2016-02-26 14:08:00 --> Helper loaded: url_helper
INFO - 2016-02-26 14:08:00 --> Helper loaded: file_helper
INFO - 2016-02-26 14:08:00 --> Helper loaded: date_helper
INFO - 2016-02-26 14:08:00 --> Helper loaded: form_helper
INFO - 2016-02-26 14:08:00 --> Database Driver Class Initialized
INFO - 2016-02-26 14:08:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:08:01 --> Controller Class Initialized
INFO - 2016-02-26 14:08:01 --> Model Class Initialized
INFO - 2016-02-26 14:08:01 --> Model Class Initialized
INFO - 2016-02-26 14:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:08:02 --> Pagination Class Initialized
INFO - 2016-02-26 14:08:02 --> Helper loaded: text_helper
INFO - 2016-02-26 14:08:02 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:08:02 --> Final output sent to browser
DEBUG - 2016-02-26 17:08:02 --> Total execution time: 1.1490
INFO - 2016-02-26 14:08:06 --> Config Class Initialized
INFO - 2016-02-26 14:08:06 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:08:06 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:08:06 --> Utf8 Class Initialized
INFO - 2016-02-26 14:08:06 --> URI Class Initialized
INFO - 2016-02-26 14:08:06 --> Router Class Initialized
INFO - 2016-02-26 14:08:06 --> Output Class Initialized
INFO - 2016-02-26 14:08:06 --> Security Class Initialized
DEBUG - 2016-02-26 14:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:08:06 --> Input Class Initialized
INFO - 2016-02-26 14:08:06 --> Language Class Initialized
INFO - 2016-02-26 14:08:06 --> Loader Class Initialized
INFO - 2016-02-26 14:08:06 --> Helper loaded: url_helper
INFO - 2016-02-26 14:08:06 --> Helper loaded: file_helper
INFO - 2016-02-26 14:08:06 --> Helper loaded: date_helper
INFO - 2016-02-26 14:08:06 --> Helper loaded: form_helper
INFO - 2016-02-26 14:08:06 --> Database Driver Class Initialized
INFO - 2016-02-26 14:08:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:08:07 --> Controller Class Initialized
INFO - 2016-02-26 14:08:07 --> Model Class Initialized
INFO - 2016-02-26 14:08:07 --> Model Class Initialized
INFO - 2016-02-26 14:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:08:07 --> Pagination Class Initialized
INFO - 2016-02-26 14:08:07 --> Helper loaded: text_helper
INFO - 2016-02-26 14:08:07 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:08:07 --> Final output sent to browser
DEBUG - 2016-02-26 17:08:07 --> Total execution time: 1.1396
INFO - 2016-02-26 14:08:08 --> Config Class Initialized
INFO - 2016-02-26 14:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:08:08 --> Utf8 Class Initialized
INFO - 2016-02-26 14:08:08 --> URI Class Initialized
INFO - 2016-02-26 14:08:08 --> Router Class Initialized
INFO - 2016-02-26 14:08:08 --> Output Class Initialized
INFO - 2016-02-26 14:08:08 --> Security Class Initialized
DEBUG - 2016-02-26 14:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:08:08 --> Input Class Initialized
INFO - 2016-02-26 14:08:08 --> Language Class Initialized
INFO - 2016-02-26 14:08:08 --> Loader Class Initialized
INFO - 2016-02-26 14:08:08 --> Helper loaded: url_helper
INFO - 2016-02-26 14:08:08 --> Helper loaded: file_helper
INFO - 2016-02-26 14:08:08 --> Helper loaded: date_helper
INFO - 2016-02-26 14:08:08 --> Helper loaded: form_helper
INFO - 2016-02-26 14:08:08 --> Database Driver Class Initialized
INFO - 2016-02-26 14:08:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:08:09 --> Controller Class Initialized
INFO - 2016-02-26 14:08:09 --> Model Class Initialized
INFO - 2016-02-26 14:08:09 --> Model Class Initialized
INFO - 2016-02-26 14:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:08:09 --> Pagination Class Initialized
INFO - 2016-02-26 14:08:09 --> Helper loaded: text_helper
INFO - 2016-02-26 14:08:09 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:08:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:08:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:08:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-26 17:08:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-26 17:08:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:08:09 --> Final output sent to browser
DEBUG - 2016-02-26 17:08:09 --> Total execution time: 1.1564
INFO - 2016-02-26 14:08:14 --> Config Class Initialized
INFO - 2016-02-26 14:08:14 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:08:14 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:08:14 --> Utf8 Class Initialized
INFO - 2016-02-26 14:08:14 --> URI Class Initialized
INFO - 2016-02-26 14:08:14 --> Router Class Initialized
INFO - 2016-02-26 14:08:14 --> Output Class Initialized
INFO - 2016-02-26 14:08:14 --> Security Class Initialized
DEBUG - 2016-02-26 14:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:08:14 --> Input Class Initialized
INFO - 2016-02-26 14:08:14 --> Language Class Initialized
INFO - 2016-02-26 14:08:14 --> Loader Class Initialized
INFO - 2016-02-26 14:08:14 --> Helper loaded: url_helper
INFO - 2016-02-26 14:08:14 --> Helper loaded: file_helper
INFO - 2016-02-26 14:08:14 --> Helper loaded: date_helper
INFO - 2016-02-26 14:08:14 --> Helper loaded: form_helper
INFO - 2016-02-26 14:08:14 --> Database Driver Class Initialized
INFO - 2016-02-26 14:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:08:15 --> Controller Class Initialized
INFO - 2016-02-26 14:08:15 --> Model Class Initialized
INFO - 2016-02-26 14:08:15 --> Model Class Initialized
INFO - 2016-02-26 14:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:08:15 --> Pagination Class Initialized
INFO - 2016-02-26 14:08:15 --> Helper loaded: text_helper
INFO - 2016-02-26 14:08:15 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:08:15 --> Upload Class Initialized
INFO - 2016-02-26 17:08:15 --> Image Lib Class Initialized
DEBUG - 2016-02-26 17:08:15 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-26 17:08:15 --> Final output sent to browser
DEBUG - 2016-02-26 17:08:15 --> Total execution time: 1.1957
INFO - 2016-02-26 14:32:00 --> Config Class Initialized
INFO - 2016-02-26 14:32:00 --> Hooks Class Initialized
DEBUG - 2016-02-26 14:32:00 --> UTF-8 Support Enabled
INFO - 2016-02-26 14:32:00 --> Utf8 Class Initialized
INFO - 2016-02-26 14:32:00 --> URI Class Initialized
INFO - 2016-02-26 14:32:00 --> Router Class Initialized
INFO - 2016-02-26 14:32:00 --> Output Class Initialized
INFO - 2016-02-26 14:32:00 --> Security Class Initialized
DEBUG - 2016-02-26 14:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-26 14:32:00 --> Input Class Initialized
INFO - 2016-02-26 14:32:00 --> Language Class Initialized
INFO - 2016-02-26 14:32:00 --> Loader Class Initialized
INFO - 2016-02-26 14:32:00 --> Helper loaded: url_helper
INFO - 2016-02-26 14:32:00 --> Helper loaded: file_helper
INFO - 2016-02-26 14:32:00 --> Helper loaded: date_helper
INFO - 2016-02-26 14:32:00 --> Helper loaded: form_helper
INFO - 2016-02-26 14:32:00 --> Database Driver Class Initialized
INFO - 2016-02-26 14:32:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-26 14:32:01 --> Controller Class Initialized
INFO - 2016-02-26 14:32:01 --> Model Class Initialized
INFO - 2016-02-26 14:32:01 --> Model Class Initialized
INFO - 2016-02-26 14:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-26 14:32:01 --> Pagination Class Initialized
INFO - 2016-02-26 14:32:01 --> Helper loaded: text_helper
INFO - 2016-02-26 14:32:01 --> Helper loaded: cookie_helper
INFO - 2016-02-26 17:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-26 17:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-26 17:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-26 17:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-26 17:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-26 17:32:01 --> Final output sent to browser
DEBUG - 2016-02-26 17:32:01 --> Total execution time: 1.1411
