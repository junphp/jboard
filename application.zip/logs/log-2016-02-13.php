<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-13 10:45:40 --> Config Class Initialized
INFO - 2016-02-13 10:45:40 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:45:40 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:45:40 --> Utf8 Class Initialized
INFO - 2016-02-13 10:45:40 --> URI Class Initialized
DEBUG - 2016-02-13 10:45:40 --> No URI present. Default controller set.
INFO - 2016-02-13 10:45:40 --> Router Class Initialized
INFO - 2016-02-13 10:45:40 --> Output Class Initialized
INFO - 2016-02-13 10:45:40 --> Security Class Initialized
DEBUG - 2016-02-13 10:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:45:40 --> Input Class Initialized
INFO - 2016-02-13 10:45:40 --> Language Class Initialized
INFO - 2016-02-13 10:45:40 --> Loader Class Initialized
INFO - 2016-02-13 10:45:40 --> Helper loaded: url_helper
INFO - 2016-02-13 10:45:40 --> Helper loaded: file_helper
INFO - 2016-02-13 10:45:40 --> Helper loaded: date_helper
INFO - 2016-02-13 10:45:40 --> Helper loaded: form_helper
INFO - 2016-02-13 10:45:40 --> Database Driver Class Initialized
INFO - 2016-02-13 10:45:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:45:42 --> Controller Class Initialized
INFO - 2016-02-13 10:45:42 --> Model Class Initialized
INFO - 2016-02-13 10:45:42 --> Model Class Initialized
INFO - 2016-02-13 10:45:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:45:42 --> Pagination Class Initialized
INFO - 2016-02-13 10:45:42 --> Helper loaded: text_helper
INFO - 2016-02-13 13:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 13:45:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 13:45:42 --> Final output sent to browser
DEBUG - 2016-02-13 13:45:42 --> Total execution time: 2.3455
INFO - 2016-02-13 10:45:47 --> Config Class Initialized
INFO - 2016-02-13 10:45:47 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:45:47 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:45:47 --> Utf8 Class Initialized
INFO - 2016-02-13 10:45:47 --> URI Class Initialized
INFO - 2016-02-13 10:45:47 --> Router Class Initialized
INFO - 2016-02-13 10:45:47 --> Output Class Initialized
INFO - 2016-02-13 10:45:47 --> Security Class Initialized
DEBUG - 2016-02-13 10:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:45:47 --> Input Class Initialized
INFO - 2016-02-13 10:45:47 --> Language Class Initialized
INFO - 2016-02-13 10:45:47 --> Loader Class Initialized
INFO - 2016-02-13 10:45:47 --> Helper loaded: url_helper
INFO - 2016-02-13 10:45:47 --> Helper loaded: file_helper
INFO - 2016-02-13 10:45:47 --> Helper loaded: date_helper
INFO - 2016-02-13 10:45:47 --> Helper loaded: form_helper
INFO - 2016-02-13 10:45:47 --> Database Driver Class Initialized
INFO - 2016-02-13 10:45:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:45:48 --> Controller Class Initialized
INFO - 2016-02-13 10:45:48 --> Model Class Initialized
INFO - 2016-02-13 10:45:48 --> Model Class Initialized
INFO - 2016-02-13 10:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:45:48 --> Pagination Class Initialized
INFO - 2016-02-13 10:45:48 --> Helper loaded: text_helper
INFO - 2016-02-13 13:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-13 13:45:49 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 12
INFO - 2016-02-13 10:51:22 --> Config Class Initialized
INFO - 2016-02-13 10:51:22 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:51:22 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:51:22 --> Utf8 Class Initialized
INFO - 2016-02-13 10:51:22 --> URI Class Initialized
INFO - 2016-02-13 10:51:22 --> Router Class Initialized
INFO - 2016-02-13 10:51:22 --> Output Class Initialized
INFO - 2016-02-13 10:51:22 --> Security Class Initialized
DEBUG - 2016-02-13 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:51:22 --> Input Class Initialized
INFO - 2016-02-13 10:51:22 --> Language Class Initialized
INFO - 2016-02-13 10:51:22 --> Loader Class Initialized
INFO - 2016-02-13 10:51:22 --> Helper loaded: url_helper
INFO - 2016-02-13 10:51:22 --> Helper loaded: file_helper
INFO - 2016-02-13 10:51:22 --> Helper loaded: date_helper
INFO - 2016-02-13 10:51:22 --> Helper loaded: form_helper
INFO - 2016-02-13 10:51:22 --> Database Driver Class Initialized
INFO - 2016-02-13 10:51:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:51:23 --> Controller Class Initialized
INFO - 2016-02-13 10:51:23 --> Model Class Initialized
INFO - 2016-02-13 10:51:23 --> Model Class Initialized
INFO - 2016-02-13 10:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:51:23 --> Pagination Class Initialized
INFO - 2016-02-13 10:51:23 --> Helper loaded: text_helper
INFO - 2016-02-13 13:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 13:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 13:51:23 --> Final output sent to browser
DEBUG - 2016-02-13 13:51:23 --> Total execution time: 1.1006
INFO - 2016-02-13 10:51:28 --> Config Class Initialized
INFO - 2016-02-13 10:51:28 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:51:28 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:51:28 --> Utf8 Class Initialized
INFO - 2016-02-13 10:51:28 --> URI Class Initialized
INFO - 2016-02-13 10:51:28 --> Router Class Initialized
INFO - 2016-02-13 10:51:28 --> Output Class Initialized
INFO - 2016-02-13 10:51:28 --> Security Class Initialized
DEBUG - 2016-02-13 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:51:28 --> Input Class Initialized
INFO - 2016-02-13 10:51:28 --> Language Class Initialized
INFO - 2016-02-13 10:51:28 --> Loader Class Initialized
INFO - 2016-02-13 10:51:28 --> Helper loaded: url_helper
INFO - 2016-02-13 10:51:28 --> Helper loaded: file_helper
INFO - 2016-02-13 10:51:28 --> Helper loaded: date_helper
INFO - 2016-02-13 10:51:28 --> Helper loaded: form_helper
INFO - 2016-02-13 10:51:28 --> Database Driver Class Initialized
INFO - 2016-02-13 10:51:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:51:29 --> Controller Class Initialized
INFO - 2016-02-13 10:51:29 --> Model Class Initialized
INFO - 2016-02-13 10:51:29 --> Model Class Initialized
INFO - 2016-02-13 10:51:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:51:29 --> Pagination Class Initialized
INFO - 2016-02-13 10:51:29 --> Helper loaded: text_helper
INFO - 2016-02-13 13:51:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:51:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-13 13:51:29 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 25
INFO - 2016-02-13 10:52:24 --> Config Class Initialized
INFO - 2016-02-13 10:52:24 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:52:24 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:52:24 --> Utf8 Class Initialized
INFO - 2016-02-13 10:52:24 --> URI Class Initialized
INFO - 2016-02-13 10:52:24 --> Router Class Initialized
INFO - 2016-02-13 10:52:24 --> Output Class Initialized
INFO - 2016-02-13 10:52:24 --> Security Class Initialized
DEBUG - 2016-02-13 10:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:52:24 --> Input Class Initialized
INFO - 2016-02-13 10:52:24 --> Language Class Initialized
INFO - 2016-02-13 10:52:24 --> Loader Class Initialized
INFO - 2016-02-13 10:52:24 --> Helper loaded: url_helper
INFO - 2016-02-13 10:52:24 --> Helper loaded: file_helper
INFO - 2016-02-13 10:52:24 --> Helper loaded: date_helper
INFO - 2016-02-13 10:52:24 --> Helper loaded: form_helper
INFO - 2016-02-13 10:52:24 --> Database Driver Class Initialized
INFO - 2016-02-13 10:52:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:52:25 --> Controller Class Initialized
INFO - 2016-02-13 10:52:25 --> Model Class Initialized
INFO - 2016-02-13 10:52:25 --> Model Class Initialized
INFO - 2016-02-13 10:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:52:25 --> Pagination Class Initialized
INFO - 2016-02-13 10:52:25 --> Helper loaded: text_helper
INFO - 2016-02-13 13:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 13:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 13:52:25 --> Final output sent to browser
DEBUG - 2016-02-13 13:52:25 --> Total execution time: 1.1055
INFO - 2016-02-13 10:52:31 --> Config Class Initialized
INFO - 2016-02-13 10:52:31 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:52:31 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:52:31 --> Utf8 Class Initialized
INFO - 2016-02-13 10:52:31 --> URI Class Initialized
INFO - 2016-02-13 10:52:31 --> Router Class Initialized
INFO - 2016-02-13 10:52:31 --> Output Class Initialized
INFO - 2016-02-13 10:52:31 --> Security Class Initialized
DEBUG - 2016-02-13 10:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:52:31 --> Input Class Initialized
INFO - 2016-02-13 10:52:31 --> Language Class Initialized
INFO - 2016-02-13 10:52:31 --> Loader Class Initialized
INFO - 2016-02-13 10:52:31 --> Helper loaded: url_helper
INFO - 2016-02-13 10:52:31 --> Helper loaded: file_helper
INFO - 2016-02-13 10:52:31 --> Helper loaded: date_helper
INFO - 2016-02-13 10:52:31 --> Helper loaded: form_helper
INFO - 2016-02-13 10:52:31 --> Database Driver Class Initialized
INFO - 2016-02-13 10:52:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:52:32 --> Controller Class Initialized
INFO - 2016-02-13 10:52:32 --> Model Class Initialized
INFO - 2016-02-13 10:52:32 --> Model Class Initialized
INFO - 2016-02-13 10:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:52:32 --> Pagination Class Initialized
INFO - 2016-02-13 10:52:32 --> Helper loaded: text_helper
INFO - 2016-02-13 13:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:52:32 --> Final output sent to browser
DEBUG - 2016-02-13 13:52:32 --> Total execution time: 1.1348
INFO - 2016-02-13 10:52:49 --> Config Class Initialized
INFO - 2016-02-13 10:52:49 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:52:49 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:52:49 --> Utf8 Class Initialized
INFO - 2016-02-13 10:52:49 --> URI Class Initialized
INFO - 2016-02-13 10:52:49 --> Router Class Initialized
INFO - 2016-02-13 10:52:49 --> Output Class Initialized
INFO - 2016-02-13 10:52:49 --> Security Class Initialized
DEBUG - 2016-02-13 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:52:49 --> Input Class Initialized
INFO - 2016-02-13 10:52:49 --> Language Class Initialized
INFO - 2016-02-13 10:52:49 --> Loader Class Initialized
INFO - 2016-02-13 10:52:49 --> Helper loaded: url_helper
INFO - 2016-02-13 10:52:49 --> Helper loaded: file_helper
INFO - 2016-02-13 10:52:49 --> Helper loaded: date_helper
INFO - 2016-02-13 10:52:49 --> Helper loaded: form_helper
INFO - 2016-02-13 10:52:49 --> Database Driver Class Initialized
INFO - 2016-02-13 10:52:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:52:50 --> Controller Class Initialized
INFO - 2016-02-13 10:52:50 --> Model Class Initialized
INFO - 2016-02-13 10:52:50 --> Model Class Initialized
INFO - 2016-02-13 10:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:52:50 --> Pagination Class Initialized
INFO - 2016-02-13 10:52:50 --> Helper loaded: text_helper
INFO - 2016-02-13 13:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:52:50 --> Final output sent to browser
DEBUG - 2016-02-13 13:52:50 --> Total execution time: 1.1216
INFO - 2016-02-13 10:53:12 --> Config Class Initialized
INFO - 2016-02-13 10:53:12 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:53:12 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:53:12 --> Utf8 Class Initialized
INFO - 2016-02-13 10:53:12 --> URI Class Initialized
INFO - 2016-02-13 10:53:12 --> Router Class Initialized
INFO - 2016-02-13 10:53:12 --> Output Class Initialized
INFO - 2016-02-13 10:53:12 --> Security Class Initialized
DEBUG - 2016-02-13 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:53:12 --> Input Class Initialized
INFO - 2016-02-13 10:53:12 --> Language Class Initialized
INFO - 2016-02-13 10:53:12 --> Loader Class Initialized
INFO - 2016-02-13 10:53:12 --> Helper loaded: url_helper
INFO - 2016-02-13 10:53:12 --> Helper loaded: file_helper
INFO - 2016-02-13 10:53:12 --> Helper loaded: date_helper
INFO - 2016-02-13 10:53:12 --> Helper loaded: form_helper
INFO - 2016-02-13 10:53:12 --> Database Driver Class Initialized
INFO - 2016-02-13 10:53:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:53:13 --> Controller Class Initialized
INFO - 2016-02-13 10:53:13 --> Model Class Initialized
INFO - 2016-02-13 10:53:13 --> Model Class Initialized
INFO - 2016-02-13 10:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:53:13 --> Pagination Class Initialized
INFO - 2016-02-13 10:53:13 --> Helper loaded: text_helper
INFO - 2016-02-13 13:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:53:13 --> Final output sent to browser
DEBUG - 2016-02-13 13:53:13 --> Total execution time: 1.0953
INFO - 2016-02-13 10:57:36 --> Config Class Initialized
INFO - 2016-02-13 10:57:36 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:57:36 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:57:36 --> Utf8 Class Initialized
INFO - 2016-02-13 10:57:36 --> URI Class Initialized
DEBUG - 2016-02-13 10:57:36 --> No URI present. Default controller set.
INFO - 2016-02-13 10:57:36 --> Router Class Initialized
INFO - 2016-02-13 10:57:36 --> Output Class Initialized
INFO - 2016-02-13 10:57:36 --> Security Class Initialized
DEBUG - 2016-02-13 10:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:57:36 --> Input Class Initialized
INFO - 2016-02-13 10:57:36 --> Language Class Initialized
INFO - 2016-02-13 10:57:36 --> Loader Class Initialized
INFO - 2016-02-13 10:57:36 --> Helper loaded: url_helper
INFO - 2016-02-13 10:57:36 --> Helper loaded: file_helper
INFO - 2016-02-13 10:57:36 --> Helper loaded: date_helper
INFO - 2016-02-13 10:57:36 --> Helper loaded: form_helper
INFO - 2016-02-13 10:57:36 --> Database Driver Class Initialized
INFO - 2016-02-13 10:57:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:57:37 --> Controller Class Initialized
INFO - 2016-02-13 10:57:37 --> Model Class Initialized
INFO - 2016-02-13 10:57:37 --> Model Class Initialized
INFO - 2016-02-13 10:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:57:37 --> Pagination Class Initialized
INFO - 2016-02-13 10:57:37 --> Helper loaded: text_helper
INFO - 2016-02-13 13:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 13:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 13:57:37 --> Final output sent to browser
DEBUG - 2016-02-13 13:57:37 --> Total execution time: 1.2434
INFO - 2016-02-13 10:57:41 --> Config Class Initialized
INFO - 2016-02-13 10:57:41 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:57:41 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:57:41 --> Utf8 Class Initialized
INFO - 2016-02-13 10:57:41 --> URI Class Initialized
INFO - 2016-02-13 10:57:41 --> Router Class Initialized
INFO - 2016-02-13 10:57:41 --> Output Class Initialized
INFO - 2016-02-13 10:57:41 --> Security Class Initialized
DEBUG - 2016-02-13 10:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:57:41 --> Input Class Initialized
INFO - 2016-02-13 10:57:41 --> Language Class Initialized
INFO - 2016-02-13 10:57:41 --> Loader Class Initialized
INFO - 2016-02-13 10:57:41 --> Helper loaded: url_helper
INFO - 2016-02-13 10:57:41 --> Helper loaded: file_helper
INFO - 2016-02-13 10:57:41 --> Helper loaded: date_helper
INFO - 2016-02-13 10:57:41 --> Helper loaded: form_helper
INFO - 2016-02-13 10:57:41 --> Database Driver Class Initialized
INFO - 2016-02-13 10:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:57:42 --> Controller Class Initialized
INFO - 2016-02-13 10:57:42 --> Model Class Initialized
INFO - 2016-02-13 10:57:42 --> Model Class Initialized
INFO - 2016-02-13 10:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:57:42 --> Pagination Class Initialized
INFO - 2016-02-13 10:57:42 --> Helper loaded: text_helper
INFO - 2016-02-13 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:57:42 --> Final output sent to browser
DEBUG - 2016-02-13 13:57:42 --> Total execution time: 1.1080
INFO - 2016-02-13 10:58:26 --> Config Class Initialized
INFO - 2016-02-13 10:58:26 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:58:26 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:58:26 --> Utf8 Class Initialized
INFO - 2016-02-13 10:58:26 --> URI Class Initialized
INFO - 2016-02-13 10:58:26 --> Router Class Initialized
INFO - 2016-02-13 10:58:26 --> Output Class Initialized
INFO - 2016-02-13 10:58:26 --> Security Class Initialized
DEBUG - 2016-02-13 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:58:26 --> Input Class Initialized
INFO - 2016-02-13 10:58:26 --> Language Class Initialized
INFO - 2016-02-13 10:58:26 --> Loader Class Initialized
INFO - 2016-02-13 10:58:26 --> Helper loaded: url_helper
INFO - 2016-02-13 10:58:26 --> Helper loaded: file_helper
INFO - 2016-02-13 10:58:26 --> Helper loaded: date_helper
INFO - 2016-02-13 10:58:26 --> Helper loaded: form_helper
INFO - 2016-02-13 10:58:26 --> Database Driver Class Initialized
INFO - 2016-02-13 10:58:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:58:27 --> Controller Class Initialized
INFO - 2016-02-13 10:58:27 --> Model Class Initialized
INFO - 2016-02-13 10:58:27 --> Model Class Initialized
INFO - 2016-02-13 10:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:58:27 --> Pagination Class Initialized
INFO - 2016-02-13 10:58:27 --> Helper loaded: text_helper
INFO - 2016-02-13 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:58:27 --> Final output sent to browser
DEBUG - 2016-02-13 13:58:27 --> Total execution time: 1.1139
INFO - 2016-02-13 10:58:32 --> Config Class Initialized
INFO - 2016-02-13 10:58:32 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:58:32 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:58:32 --> Utf8 Class Initialized
INFO - 2016-02-13 10:58:32 --> URI Class Initialized
INFO - 2016-02-13 10:58:32 --> Router Class Initialized
INFO - 2016-02-13 10:58:32 --> Output Class Initialized
INFO - 2016-02-13 10:58:32 --> Security Class Initialized
DEBUG - 2016-02-13 10:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:58:32 --> Input Class Initialized
INFO - 2016-02-13 10:58:32 --> Language Class Initialized
INFO - 2016-02-13 10:58:32 --> Loader Class Initialized
INFO - 2016-02-13 10:58:32 --> Helper loaded: url_helper
INFO - 2016-02-13 10:58:32 --> Helper loaded: file_helper
INFO - 2016-02-13 10:58:32 --> Helper loaded: date_helper
INFO - 2016-02-13 10:58:32 --> Helper loaded: form_helper
INFO - 2016-02-13 10:58:32 --> Database Driver Class Initialized
INFO - 2016-02-13 10:58:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:58:33 --> Controller Class Initialized
INFO - 2016-02-13 10:58:33 --> Model Class Initialized
INFO - 2016-02-13 10:58:33 --> Model Class Initialized
INFO - 2016-02-13 10:58:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:58:33 --> Pagination Class Initialized
INFO - 2016-02-13 10:58:33 --> Helper loaded: text_helper
INFO - 2016-02-13 13:58:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:58:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:58:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:58:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:58:33 --> Final output sent to browser
DEBUG - 2016-02-13 13:58:33 --> Total execution time: 1.1275
INFO - 2016-02-13 10:58:38 --> Config Class Initialized
INFO - 2016-02-13 10:58:38 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:58:38 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:58:38 --> Utf8 Class Initialized
INFO - 2016-02-13 10:58:38 --> URI Class Initialized
INFO - 2016-02-13 10:58:38 --> Router Class Initialized
INFO - 2016-02-13 10:58:38 --> Output Class Initialized
INFO - 2016-02-13 10:58:38 --> Security Class Initialized
DEBUG - 2016-02-13 10:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:58:38 --> Input Class Initialized
INFO - 2016-02-13 10:58:38 --> Language Class Initialized
INFO - 2016-02-13 10:58:38 --> Loader Class Initialized
INFO - 2016-02-13 10:58:38 --> Helper loaded: url_helper
INFO - 2016-02-13 10:58:38 --> Helper loaded: file_helper
INFO - 2016-02-13 10:58:38 --> Helper loaded: date_helper
INFO - 2016-02-13 10:58:38 --> Helper loaded: form_helper
INFO - 2016-02-13 10:58:38 --> Database Driver Class Initialized
INFO - 2016-02-13 10:58:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:58:39 --> Controller Class Initialized
INFO - 2016-02-13 10:58:39 --> Model Class Initialized
INFO - 2016-02-13 10:58:39 --> Model Class Initialized
INFO - 2016-02-13 10:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:58:39 --> Pagination Class Initialized
INFO - 2016-02-13 10:58:39 --> Helper loaded: text_helper
INFO - 2016-02-13 13:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:58:39 --> Final output sent to browser
DEBUG - 2016-02-13 13:58:39 --> Total execution time: 1.1308
INFO - 2016-02-13 10:59:08 --> Config Class Initialized
INFO - 2016-02-13 10:59:08 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:59:08 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:59:08 --> Utf8 Class Initialized
INFO - 2016-02-13 10:59:08 --> URI Class Initialized
INFO - 2016-02-13 10:59:08 --> Router Class Initialized
INFO - 2016-02-13 10:59:08 --> Output Class Initialized
INFO - 2016-02-13 10:59:08 --> Security Class Initialized
DEBUG - 2016-02-13 10:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:59:08 --> Input Class Initialized
INFO - 2016-02-13 10:59:08 --> Language Class Initialized
INFO - 2016-02-13 10:59:08 --> Loader Class Initialized
INFO - 2016-02-13 10:59:08 --> Helper loaded: url_helper
INFO - 2016-02-13 10:59:08 --> Helper loaded: file_helper
INFO - 2016-02-13 10:59:08 --> Helper loaded: date_helper
INFO - 2016-02-13 10:59:08 --> Helper loaded: form_helper
INFO - 2016-02-13 10:59:08 --> Database Driver Class Initialized
INFO - 2016-02-13 10:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:59:09 --> Controller Class Initialized
INFO - 2016-02-13 10:59:09 --> Model Class Initialized
INFO - 2016-02-13 10:59:09 --> Model Class Initialized
INFO - 2016-02-13 10:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:59:09 --> Pagination Class Initialized
INFO - 2016-02-13 10:59:09 --> Helper loaded: text_helper
INFO - 2016-02-13 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:59:09 --> Final output sent to browser
DEBUG - 2016-02-13 13:59:09 --> Total execution time: 1.1458
INFO - 2016-02-13 10:59:31 --> Config Class Initialized
INFO - 2016-02-13 10:59:31 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:59:31 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:59:31 --> Utf8 Class Initialized
INFO - 2016-02-13 10:59:31 --> URI Class Initialized
INFO - 2016-02-13 10:59:31 --> Router Class Initialized
INFO - 2016-02-13 10:59:31 --> Output Class Initialized
INFO - 2016-02-13 10:59:31 --> Security Class Initialized
DEBUG - 2016-02-13 10:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:59:31 --> Input Class Initialized
INFO - 2016-02-13 10:59:31 --> Language Class Initialized
INFO - 2016-02-13 10:59:31 --> Loader Class Initialized
INFO - 2016-02-13 10:59:31 --> Helper loaded: url_helper
INFO - 2016-02-13 10:59:31 --> Helper loaded: file_helper
INFO - 2016-02-13 10:59:31 --> Helper loaded: date_helper
INFO - 2016-02-13 10:59:31 --> Helper loaded: form_helper
INFO - 2016-02-13 10:59:31 --> Database Driver Class Initialized
INFO - 2016-02-13 10:59:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:59:32 --> Controller Class Initialized
INFO - 2016-02-13 10:59:32 --> Model Class Initialized
INFO - 2016-02-13 10:59:32 --> Model Class Initialized
INFO - 2016-02-13 10:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:59:32 --> Pagination Class Initialized
INFO - 2016-02-13 10:59:32 --> Helper loaded: text_helper
INFO - 2016-02-13 13:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:59:32 --> Final output sent to browser
DEBUG - 2016-02-13 13:59:32 --> Total execution time: 1.1077
INFO - 2016-02-13 10:59:40 --> Config Class Initialized
INFO - 2016-02-13 10:59:40 --> Hooks Class Initialized
DEBUG - 2016-02-13 10:59:40 --> UTF-8 Support Enabled
INFO - 2016-02-13 10:59:40 --> Utf8 Class Initialized
INFO - 2016-02-13 10:59:40 --> URI Class Initialized
INFO - 2016-02-13 10:59:40 --> Router Class Initialized
INFO - 2016-02-13 10:59:40 --> Output Class Initialized
INFO - 2016-02-13 10:59:40 --> Security Class Initialized
DEBUG - 2016-02-13 10:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 10:59:40 --> Input Class Initialized
INFO - 2016-02-13 10:59:40 --> Language Class Initialized
INFO - 2016-02-13 10:59:40 --> Loader Class Initialized
INFO - 2016-02-13 10:59:40 --> Helper loaded: url_helper
INFO - 2016-02-13 10:59:40 --> Helper loaded: file_helper
INFO - 2016-02-13 10:59:40 --> Helper loaded: date_helper
INFO - 2016-02-13 10:59:40 --> Helper loaded: form_helper
INFO - 2016-02-13 10:59:40 --> Database Driver Class Initialized
INFO - 2016-02-13 10:59:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 10:59:41 --> Controller Class Initialized
INFO - 2016-02-13 10:59:41 --> Model Class Initialized
INFO - 2016-02-13 10:59:41 --> Model Class Initialized
INFO - 2016-02-13 10:59:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 10:59:41 --> Pagination Class Initialized
INFO - 2016-02-13 10:59:41 --> Helper loaded: text_helper
INFO - 2016-02-13 13:59:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 13:59:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 13:59:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 13:59:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 13:59:41 --> Final output sent to browser
DEBUG - 2016-02-13 13:59:41 --> Total execution time: 1.1447
INFO - 2016-02-13 11:02:36 --> Config Class Initialized
INFO - 2016-02-13 11:02:36 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:02:36 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:02:36 --> Utf8 Class Initialized
INFO - 2016-02-13 11:02:36 --> URI Class Initialized
INFO - 2016-02-13 11:02:36 --> Router Class Initialized
INFO - 2016-02-13 11:02:36 --> Output Class Initialized
INFO - 2016-02-13 11:02:36 --> Security Class Initialized
DEBUG - 2016-02-13 11:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:02:36 --> Input Class Initialized
INFO - 2016-02-13 11:02:36 --> Language Class Initialized
INFO - 2016-02-13 11:02:36 --> Loader Class Initialized
INFO - 2016-02-13 11:02:36 --> Helper loaded: url_helper
INFO - 2016-02-13 11:02:36 --> Helper loaded: file_helper
INFO - 2016-02-13 11:02:36 --> Helper loaded: date_helper
INFO - 2016-02-13 11:02:36 --> Helper loaded: form_helper
INFO - 2016-02-13 11:02:36 --> Database Driver Class Initialized
INFO - 2016-02-13 11:02:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:02:37 --> Controller Class Initialized
INFO - 2016-02-13 11:02:37 --> Model Class Initialized
INFO - 2016-02-13 11:02:37 --> Model Class Initialized
INFO - 2016-02-13 11:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:02:37 --> Pagination Class Initialized
INFO - 2016-02-13 11:02:37 --> Helper loaded: text_helper
INFO - 2016-02-13 14:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:02:37 --> Final output sent to browser
DEBUG - 2016-02-13 14:02:37 --> Total execution time: 1.1266
INFO - 2016-02-13 11:04:00 --> Config Class Initialized
INFO - 2016-02-13 11:04:00 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:04:00 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:04:00 --> Utf8 Class Initialized
INFO - 2016-02-13 11:04:00 --> URI Class Initialized
INFO - 2016-02-13 11:04:00 --> Router Class Initialized
INFO - 2016-02-13 11:04:00 --> Output Class Initialized
INFO - 2016-02-13 11:04:00 --> Security Class Initialized
DEBUG - 2016-02-13 11:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:04:00 --> Input Class Initialized
INFO - 2016-02-13 11:04:00 --> Language Class Initialized
INFO - 2016-02-13 11:04:00 --> Loader Class Initialized
INFO - 2016-02-13 11:04:00 --> Helper loaded: url_helper
INFO - 2016-02-13 11:04:00 --> Helper loaded: file_helper
INFO - 2016-02-13 11:04:00 --> Helper loaded: date_helper
INFO - 2016-02-13 11:04:00 --> Helper loaded: form_helper
INFO - 2016-02-13 11:04:00 --> Database Driver Class Initialized
INFO - 2016-02-13 11:04:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:04:01 --> Controller Class Initialized
INFO - 2016-02-13 11:04:01 --> Model Class Initialized
INFO - 2016-02-13 11:04:01 --> Model Class Initialized
INFO - 2016-02-13 11:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:04:01 --> Pagination Class Initialized
INFO - 2016-02-13 11:04:01 --> Helper loaded: text_helper
INFO - 2016-02-13 14:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:04:01 --> Final output sent to browser
DEBUG - 2016-02-13 14:04:01 --> Total execution time: 1.1124
INFO - 2016-02-13 11:04:23 --> Config Class Initialized
INFO - 2016-02-13 11:04:23 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:04:23 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:04:23 --> Utf8 Class Initialized
INFO - 2016-02-13 11:04:23 --> URI Class Initialized
INFO - 2016-02-13 11:04:23 --> Router Class Initialized
INFO - 2016-02-13 11:04:23 --> Output Class Initialized
INFO - 2016-02-13 11:04:23 --> Security Class Initialized
DEBUG - 2016-02-13 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:04:23 --> Input Class Initialized
INFO - 2016-02-13 11:04:23 --> Language Class Initialized
INFO - 2016-02-13 11:04:23 --> Loader Class Initialized
INFO - 2016-02-13 11:04:23 --> Helper loaded: url_helper
INFO - 2016-02-13 11:04:23 --> Helper loaded: file_helper
INFO - 2016-02-13 11:04:23 --> Helper loaded: date_helper
INFO - 2016-02-13 11:04:23 --> Helper loaded: form_helper
INFO - 2016-02-13 11:04:23 --> Database Driver Class Initialized
INFO - 2016-02-13 11:04:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:04:24 --> Controller Class Initialized
INFO - 2016-02-13 11:04:24 --> Model Class Initialized
INFO - 2016-02-13 11:04:24 --> Model Class Initialized
INFO - 2016-02-13 11:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:04:24 --> Pagination Class Initialized
INFO - 2016-02-13 11:04:24 --> Helper loaded: text_helper
INFO - 2016-02-13 14:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:04:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:04:24 --> Final output sent to browser
DEBUG - 2016-02-13 14:04:24 --> Total execution time: 1.1162
INFO - 2016-02-13 11:04:43 --> Config Class Initialized
INFO - 2016-02-13 11:04:43 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:04:43 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:04:43 --> Utf8 Class Initialized
INFO - 2016-02-13 11:04:43 --> URI Class Initialized
INFO - 2016-02-13 11:04:43 --> Router Class Initialized
INFO - 2016-02-13 11:04:43 --> Output Class Initialized
INFO - 2016-02-13 11:04:43 --> Security Class Initialized
DEBUG - 2016-02-13 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:04:43 --> Input Class Initialized
INFO - 2016-02-13 11:04:43 --> Language Class Initialized
INFO - 2016-02-13 11:04:43 --> Loader Class Initialized
INFO - 2016-02-13 11:04:43 --> Helper loaded: url_helper
INFO - 2016-02-13 11:04:43 --> Helper loaded: file_helper
INFO - 2016-02-13 11:04:43 --> Helper loaded: date_helper
INFO - 2016-02-13 11:04:43 --> Helper loaded: form_helper
INFO - 2016-02-13 11:04:43 --> Database Driver Class Initialized
INFO - 2016-02-13 11:04:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:04:44 --> Controller Class Initialized
INFO - 2016-02-13 11:04:44 --> Model Class Initialized
INFO - 2016-02-13 11:04:44 --> Model Class Initialized
INFO - 2016-02-13 11:04:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:04:44 --> Pagination Class Initialized
INFO - 2016-02-13 11:04:44 --> Helper loaded: text_helper
INFO - 2016-02-13 14:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:04:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:04:44 --> Final output sent to browser
DEBUG - 2016-02-13 14:04:44 --> Total execution time: 1.1114
INFO - 2016-02-13 11:13:04 --> Config Class Initialized
INFO - 2016-02-13 11:13:04 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:13:04 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:13:04 --> Utf8 Class Initialized
INFO - 2016-02-13 11:13:04 --> URI Class Initialized
DEBUG - 2016-02-13 11:13:04 --> No URI present. Default controller set.
INFO - 2016-02-13 11:13:04 --> Router Class Initialized
INFO - 2016-02-13 11:13:04 --> Output Class Initialized
INFO - 2016-02-13 11:13:04 --> Security Class Initialized
DEBUG - 2016-02-13 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:13:04 --> Input Class Initialized
INFO - 2016-02-13 11:13:04 --> Language Class Initialized
INFO - 2016-02-13 11:13:04 --> Loader Class Initialized
INFO - 2016-02-13 11:13:04 --> Helper loaded: url_helper
INFO - 2016-02-13 11:13:04 --> Helper loaded: file_helper
INFO - 2016-02-13 11:13:04 --> Helper loaded: date_helper
INFO - 2016-02-13 11:13:04 --> Helper loaded: form_helper
INFO - 2016-02-13 11:13:04 --> Database Driver Class Initialized
INFO - 2016-02-13 11:13:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:13:05 --> Controller Class Initialized
INFO - 2016-02-13 11:13:05 --> Model Class Initialized
INFO - 2016-02-13 11:13:05 --> Model Class Initialized
INFO - 2016-02-13 11:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:13:05 --> Pagination Class Initialized
INFO - 2016-02-13 11:13:05 --> Helper loaded: text_helper
INFO - 2016-02-13 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:13:05 --> Final output sent to browser
DEBUG - 2016-02-13 14:13:05 --> Total execution time: 1.1450
INFO - 2016-02-13 11:13:13 --> Config Class Initialized
INFO - 2016-02-13 11:13:13 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:13:13 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:13:13 --> Utf8 Class Initialized
INFO - 2016-02-13 11:13:13 --> URI Class Initialized
INFO - 2016-02-13 11:13:13 --> Router Class Initialized
INFO - 2016-02-13 11:13:13 --> Output Class Initialized
INFO - 2016-02-13 11:13:13 --> Security Class Initialized
DEBUG - 2016-02-13 11:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:13:13 --> Input Class Initialized
INFO - 2016-02-13 11:13:13 --> Language Class Initialized
INFO - 2016-02-13 11:13:13 --> Loader Class Initialized
INFO - 2016-02-13 11:13:13 --> Helper loaded: url_helper
INFO - 2016-02-13 11:13:13 --> Helper loaded: file_helper
INFO - 2016-02-13 11:13:13 --> Helper loaded: date_helper
INFO - 2016-02-13 11:13:13 --> Helper loaded: form_helper
INFO - 2016-02-13 11:13:13 --> Database Driver Class Initialized
INFO - 2016-02-13 11:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:13:14 --> Controller Class Initialized
INFO - 2016-02-13 11:13:14 --> Model Class Initialized
INFO - 2016-02-13 11:13:14 --> Model Class Initialized
INFO - 2016-02-13 11:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:13:14 --> Pagination Class Initialized
INFO - 2016-02-13 11:13:14 --> Helper loaded: text_helper
ERROR - 2016-02-13 14:13:14 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 333
INFO - 2016-02-13 14:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:13:14 --> Final output sent to browser
DEBUG - 2016-02-13 14:13:14 --> Total execution time: 1.1239
INFO - 2016-02-13 11:13:38 --> Config Class Initialized
INFO - 2016-02-13 11:13:38 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:13:38 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:13:38 --> Utf8 Class Initialized
INFO - 2016-02-13 11:13:38 --> URI Class Initialized
DEBUG - 2016-02-13 11:13:38 --> No URI present. Default controller set.
INFO - 2016-02-13 11:13:38 --> Router Class Initialized
INFO - 2016-02-13 11:13:38 --> Output Class Initialized
INFO - 2016-02-13 11:13:38 --> Security Class Initialized
DEBUG - 2016-02-13 11:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:13:38 --> Input Class Initialized
INFO - 2016-02-13 11:13:38 --> Language Class Initialized
INFO - 2016-02-13 11:13:39 --> Loader Class Initialized
INFO - 2016-02-13 11:13:39 --> Helper loaded: url_helper
INFO - 2016-02-13 11:13:39 --> Helper loaded: file_helper
INFO - 2016-02-13 11:13:39 --> Helper loaded: date_helper
INFO - 2016-02-13 11:13:39 --> Helper loaded: form_helper
INFO - 2016-02-13 11:13:39 --> Database Driver Class Initialized
INFO - 2016-02-13 11:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:13:40 --> Controller Class Initialized
INFO - 2016-02-13 11:13:40 --> Model Class Initialized
INFO - 2016-02-13 11:13:40 --> Model Class Initialized
INFO - 2016-02-13 11:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:13:40 --> Pagination Class Initialized
INFO - 2016-02-13 11:13:40 --> Helper loaded: text_helper
INFO - 2016-02-13 14:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:13:40 --> Final output sent to browser
DEBUG - 2016-02-13 14:13:40 --> Total execution time: 1.1352
INFO - 2016-02-13 11:13:44 --> Config Class Initialized
INFO - 2016-02-13 11:13:44 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:13:44 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:13:44 --> Utf8 Class Initialized
INFO - 2016-02-13 11:13:44 --> URI Class Initialized
INFO - 2016-02-13 11:13:44 --> Router Class Initialized
INFO - 2016-02-13 11:13:44 --> Output Class Initialized
INFO - 2016-02-13 11:13:44 --> Security Class Initialized
DEBUG - 2016-02-13 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:13:44 --> Input Class Initialized
INFO - 2016-02-13 11:13:44 --> Language Class Initialized
INFO - 2016-02-13 11:13:44 --> Loader Class Initialized
INFO - 2016-02-13 11:13:44 --> Helper loaded: url_helper
INFO - 2016-02-13 11:13:44 --> Helper loaded: file_helper
INFO - 2016-02-13 11:13:44 --> Helper loaded: date_helper
INFO - 2016-02-13 11:13:44 --> Helper loaded: form_helper
INFO - 2016-02-13 11:13:44 --> Database Driver Class Initialized
INFO - 2016-02-13 11:13:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:13:45 --> Controller Class Initialized
INFO - 2016-02-13 11:13:45 --> Model Class Initialized
INFO - 2016-02-13 11:13:45 --> Model Class Initialized
INFO - 2016-02-13 11:13:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:13:45 --> Pagination Class Initialized
INFO - 2016-02-13 11:13:45 --> Helper loaded: text_helper
INFO - 2016-02-13 14:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:13:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:13:45 --> Final output sent to browser
DEBUG - 2016-02-13 14:13:45 --> Total execution time: 1.1525
INFO - 2016-02-13 11:14:42 --> Config Class Initialized
INFO - 2016-02-13 11:14:42 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:14:42 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:14:42 --> Utf8 Class Initialized
INFO - 2016-02-13 11:14:42 --> URI Class Initialized
DEBUG - 2016-02-13 11:14:42 --> No URI present. Default controller set.
INFO - 2016-02-13 11:14:42 --> Router Class Initialized
INFO - 2016-02-13 11:14:42 --> Output Class Initialized
INFO - 2016-02-13 11:14:42 --> Security Class Initialized
DEBUG - 2016-02-13 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:14:42 --> Input Class Initialized
INFO - 2016-02-13 11:14:42 --> Language Class Initialized
INFO - 2016-02-13 11:14:42 --> Loader Class Initialized
INFO - 2016-02-13 11:14:42 --> Helper loaded: url_helper
INFO - 2016-02-13 11:14:42 --> Helper loaded: file_helper
INFO - 2016-02-13 11:14:42 --> Helper loaded: date_helper
INFO - 2016-02-13 11:14:42 --> Helper loaded: form_helper
INFO - 2016-02-13 11:14:42 --> Database Driver Class Initialized
INFO - 2016-02-13 11:14:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:14:43 --> Controller Class Initialized
INFO - 2016-02-13 11:14:43 --> Model Class Initialized
INFO - 2016-02-13 11:14:43 --> Model Class Initialized
INFO - 2016-02-13 11:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:14:43 --> Pagination Class Initialized
INFO - 2016-02-13 11:14:43 --> Helper loaded: text_helper
INFO - 2016-02-13 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:14:43 --> Final output sent to browser
DEBUG - 2016-02-13 14:14:43 --> Total execution time: 1.3385
INFO - 2016-02-13 11:14:47 --> Config Class Initialized
INFO - 2016-02-13 11:14:47 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:14:47 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:14:47 --> Utf8 Class Initialized
INFO - 2016-02-13 11:14:47 --> URI Class Initialized
INFO - 2016-02-13 11:14:47 --> Router Class Initialized
INFO - 2016-02-13 11:14:47 --> Output Class Initialized
INFO - 2016-02-13 11:14:47 --> Security Class Initialized
DEBUG - 2016-02-13 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:14:47 --> Input Class Initialized
INFO - 2016-02-13 11:14:47 --> Language Class Initialized
INFO - 2016-02-13 11:14:47 --> Loader Class Initialized
INFO - 2016-02-13 11:14:47 --> Helper loaded: url_helper
INFO - 2016-02-13 11:14:47 --> Helper loaded: file_helper
INFO - 2016-02-13 11:14:47 --> Helper loaded: date_helper
INFO - 2016-02-13 11:14:47 --> Helper loaded: form_helper
INFO - 2016-02-13 11:14:47 --> Database Driver Class Initialized
INFO - 2016-02-13 11:14:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:14:48 --> Controller Class Initialized
INFO - 2016-02-13 11:14:48 --> Model Class Initialized
INFO - 2016-02-13 11:14:48 --> Model Class Initialized
INFO - 2016-02-13 11:14:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:14:48 --> Pagination Class Initialized
INFO - 2016-02-13 11:14:48 --> Helper loaded: text_helper
INFO - 2016-02-13 14:14:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:14:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:14:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:14:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:14:48 --> Final output sent to browser
DEBUG - 2016-02-13 14:14:48 --> Total execution time: 1.1238
INFO - 2016-02-13 11:16:21 --> Config Class Initialized
INFO - 2016-02-13 11:16:21 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:16:21 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:16:21 --> Utf8 Class Initialized
INFO - 2016-02-13 11:16:21 --> URI Class Initialized
DEBUG - 2016-02-13 11:16:21 --> No URI present. Default controller set.
INFO - 2016-02-13 11:16:21 --> Router Class Initialized
INFO - 2016-02-13 11:16:21 --> Output Class Initialized
INFO - 2016-02-13 11:16:21 --> Security Class Initialized
DEBUG - 2016-02-13 11:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:16:21 --> Input Class Initialized
INFO - 2016-02-13 11:16:21 --> Language Class Initialized
INFO - 2016-02-13 11:16:21 --> Loader Class Initialized
INFO - 2016-02-13 11:16:21 --> Helper loaded: url_helper
INFO - 2016-02-13 11:16:21 --> Helper loaded: file_helper
INFO - 2016-02-13 11:16:21 --> Helper loaded: date_helper
INFO - 2016-02-13 11:16:21 --> Helper loaded: form_helper
INFO - 2016-02-13 11:16:21 --> Database Driver Class Initialized
INFO - 2016-02-13 11:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:16:22 --> Controller Class Initialized
INFO - 2016-02-13 11:16:22 --> Model Class Initialized
INFO - 2016-02-13 11:16:22 --> Model Class Initialized
INFO - 2016-02-13 11:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:16:22 --> Pagination Class Initialized
INFO - 2016-02-13 11:16:22 --> Helper loaded: text_helper
INFO - 2016-02-13 14:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:16:22 --> Final output sent to browser
DEBUG - 2016-02-13 14:16:22 --> Total execution time: 1.1267
INFO - 2016-02-13 11:19:58 --> Config Class Initialized
INFO - 2016-02-13 11:19:58 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:19:58 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:19:58 --> Utf8 Class Initialized
INFO - 2016-02-13 11:19:58 --> URI Class Initialized
INFO - 2016-02-13 11:19:58 --> Router Class Initialized
INFO - 2016-02-13 11:19:58 --> Output Class Initialized
INFO - 2016-02-13 11:19:58 --> Security Class Initialized
DEBUG - 2016-02-13 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:19:58 --> Input Class Initialized
INFO - 2016-02-13 11:19:58 --> Language Class Initialized
INFO - 2016-02-13 11:19:58 --> Loader Class Initialized
INFO - 2016-02-13 11:19:58 --> Helper loaded: url_helper
INFO - 2016-02-13 11:19:58 --> Helper loaded: file_helper
INFO - 2016-02-13 11:19:58 --> Helper loaded: date_helper
INFO - 2016-02-13 11:19:58 --> Helper loaded: form_helper
INFO - 2016-02-13 11:19:58 --> Database Driver Class Initialized
INFO - 2016-02-13 11:19:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:19:59 --> Controller Class Initialized
INFO - 2016-02-13 11:19:59 --> Model Class Initialized
INFO - 2016-02-13 11:19:59 --> Model Class Initialized
INFO - 2016-02-13 11:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:19:59 --> Pagination Class Initialized
INFO - 2016-02-13 11:19:59 --> Helper loaded: text_helper
INFO - 2016-02-13 14:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:19:59 --> Final output sent to browser
DEBUG - 2016-02-13 14:19:59 --> Total execution time: 1.0865
INFO - 2016-02-13 11:20:59 --> Config Class Initialized
INFO - 2016-02-13 11:20:59 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:20:59 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:20:59 --> Utf8 Class Initialized
INFO - 2016-02-13 11:20:59 --> URI Class Initialized
INFO - 2016-02-13 11:20:59 --> Router Class Initialized
INFO - 2016-02-13 11:20:59 --> Output Class Initialized
INFO - 2016-02-13 11:20:59 --> Security Class Initialized
DEBUG - 2016-02-13 11:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:20:59 --> Input Class Initialized
INFO - 2016-02-13 11:20:59 --> Language Class Initialized
INFO - 2016-02-13 11:20:59 --> Loader Class Initialized
INFO - 2016-02-13 11:20:59 --> Helper loaded: url_helper
INFO - 2016-02-13 11:20:59 --> Helper loaded: file_helper
INFO - 2016-02-13 11:20:59 --> Helper loaded: date_helper
INFO - 2016-02-13 11:20:59 --> Helper loaded: form_helper
INFO - 2016-02-13 11:20:59 --> Database Driver Class Initialized
INFO - 2016-02-13 11:21:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:21:00 --> Controller Class Initialized
INFO - 2016-02-13 11:21:00 --> Model Class Initialized
INFO - 2016-02-13 11:21:00 --> Model Class Initialized
INFO - 2016-02-13 11:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:21:00 --> Pagination Class Initialized
INFO - 2016-02-13 11:21:00 --> Helper loaded: text_helper
INFO - 2016-02-13 14:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:21:00 --> Final output sent to browser
DEBUG - 2016-02-13 14:21:00 --> Total execution time: 1.1027
INFO - 2016-02-13 11:21:11 --> Config Class Initialized
INFO - 2016-02-13 11:21:11 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:21:11 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:21:11 --> Utf8 Class Initialized
INFO - 2016-02-13 11:21:11 --> URI Class Initialized
INFO - 2016-02-13 11:21:11 --> Router Class Initialized
INFO - 2016-02-13 11:21:11 --> Output Class Initialized
INFO - 2016-02-13 11:21:11 --> Security Class Initialized
DEBUG - 2016-02-13 11:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:21:11 --> Input Class Initialized
INFO - 2016-02-13 11:21:11 --> Language Class Initialized
INFO - 2016-02-13 11:21:11 --> Loader Class Initialized
INFO - 2016-02-13 11:21:11 --> Helper loaded: url_helper
INFO - 2016-02-13 11:21:11 --> Helper loaded: file_helper
INFO - 2016-02-13 11:21:11 --> Helper loaded: date_helper
INFO - 2016-02-13 11:21:11 --> Helper loaded: form_helper
INFO - 2016-02-13 11:21:11 --> Database Driver Class Initialized
INFO - 2016-02-13 11:21:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:21:12 --> Controller Class Initialized
INFO - 2016-02-13 11:21:12 --> Model Class Initialized
INFO - 2016-02-13 11:21:12 --> Model Class Initialized
INFO - 2016-02-13 11:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:21:12 --> Pagination Class Initialized
INFO - 2016-02-13 11:21:12 --> Helper loaded: text_helper
INFO - 2016-02-13 14:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:21:12 --> Final output sent to browser
DEBUG - 2016-02-13 14:21:12 --> Total execution time: 1.1317
INFO - 2016-02-13 11:21:29 --> Config Class Initialized
INFO - 2016-02-13 11:21:29 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:21:29 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:21:29 --> Utf8 Class Initialized
INFO - 2016-02-13 11:21:29 --> URI Class Initialized
INFO - 2016-02-13 11:21:29 --> Router Class Initialized
INFO - 2016-02-13 11:21:29 --> Output Class Initialized
INFO - 2016-02-13 11:21:29 --> Security Class Initialized
DEBUG - 2016-02-13 11:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:21:29 --> Input Class Initialized
INFO - 2016-02-13 11:21:29 --> Language Class Initialized
INFO - 2016-02-13 11:21:29 --> Loader Class Initialized
INFO - 2016-02-13 11:21:29 --> Helper loaded: url_helper
INFO - 2016-02-13 11:21:29 --> Helper loaded: file_helper
INFO - 2016-02-13 11:21:29 --> Helper loaded: date_helper
INFO - 2016-02-13 11:21:29 --> Helper loaded: form_helper
INFO - 2016-02-13 11:21:29 --> Database Driver Class Initialized
INFO - 2016-02-13 11:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:21:30 --> Controller Class Initialized
INFO - 2016-02-13 11:21:30 --> Model Class Initialized
INFO - 2016-02-13 11:21:30 --> Model Class Initialized
INFO - 2016-02-13 11:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:21:30 --> Pagination Class Initialized
INFO - 2016-02-13 11:21:30 --> Helper loaded: text_helper
INFO - 2016-02-13 14:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-13 14:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:21:30 --> Final output sent to browser
DEBUG - 2016-02-13 14:21:30 --> Total execution time: 1.2238
INFO - 2016-02-13 11:21:37 --> Config Class Initialized
INFO - 2016-02-13 11:21:37 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:21:37 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:21:37 --> Utf8 Class Initialized
INFO - 2016-02-13 11:21:37 --> URI Class Initialized
DEBUG - 2016-02-13 11:21:37 --> No URI present. Default controller set.
INFO - 2016-02-13 11:21:37 --> Router Class Initialized
INFO - 2016-02-13 11:21:37 --> Output Class Initialized
INFO - 2016-02-13 11:21:37 --> Security Class Initialized
DEBUG - 2016-02-13 11:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:21:37 --> Input Class Initialized
INFO - 2016-02-13 11:21:37 --> Language Class Initialized
INFO - 2016-02-13 11:21:37 --> Loader Class Initialized
INFO - 2016-02-13 11:21:37 --> Helper loaded: url_helper
INFO - 2016-02-13 11:21:37 --> Helper loaded: file_helper
INFO - 2016-02-13 11:21:37 --> Helper loaded: date_helper
INFO - 2016-02-13 11:21:37 --> Helper loaded: form_helper
INFO - 2016-02-13 11:21:37 --> Database Driver Class Initialized
INFO - 2016-02-13 11:21:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:21:38 --> Controller Class Initialized
INFO - 2016-02-13 11:21:38 --> Model Class Initialized
INFO - 2016-02-13 11:21:38 --> Model Class Initialized
INFO - 2016-02-13 11:21:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:21:38 --> Pagination Class Initialized
INFO - 2016-02-13 11:21:39 --> Helper loaded: text_helper
INFO - 2016-02-13 14:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:21:39 --> Final output sent to browser
DEBUG - 2016-02-13 14:21:39 --> Total execution time: 1.1476
INFO - 2016-02-13 11:22:54 --> Config Class Initialized
INFO - 2016-02-13 11:22:54 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:22:54 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:22:54 --> Utf8 Class Initialized
INFO - 2016-02-13 11:22:54 --> URI Class Initialized
INFO - 2016-02-13 11:22:54 --> Router Class Initialized
INFO - 2016-02-13 11:22:54 --> Output Class Initialized
INFO - 2016-02-13 11:22:54 --> Security Class Initialized
DEBUG - 2016-02-13 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:22:54 --> Input Class Initialized
INFO - 2016-02-13 11:22:54 --> Language Class Initialized
INFO - 2016-02-13 11:22:54 --> Loader Class Initialized
INFO - 2016-02-13 11:22:54 --> Helper loaded: url_helper
INFO - 2016-02-13 11:22:54 --> Helper loaded: file_helper
INFO - 2016-02-13 11:22:54 --> Helper loaded: date_helper
INFO - 2016-02-13 11:22:54 --> Helper loaded: form_helper
INFO - 2016-02-13 11:22:54 --> Database Driver Class Initialized
INFO - 2016-02-13 11:22:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:22:55 --> Controller Class Initialized
INFO - 2016-02-13 11:22:55 --> Model Class Initialized
INFO - 2016-02-13 11:22:55 --> Model Class Initialized
INFO - 2016-02-13 11:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:22:55 --> Pagination Class Initialized
INFO - 2016-02-13 11:22:55 --> Helper loaded: text_helper
INFO - 2016-02-13 14:22:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:22:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:22:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 14:22:55 --> Final output sent to browser
DEBUG - 2016-02-13 14:22:55 --> Total execution time: 1.0893
INFO - 2016-02-13 11:23:19 --> Config Class Initialized
INFO - 2016-02-13 11:23:19 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:23:19 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:23:19 --> Utf8 Class Initialized
INFO - 2016-02-13 11:23:19 --> URI Class Initialized
DEBUG - 2016-02-13 11:23:19 --> No URI present. Default controller set.
INFO - 2016-02-13 11:23:19 --> Router Class Initialized
INFO - 2016-02-13 11:23:19 --> Output Class Initialized
INFO - 2016-02-13 11:23:19 --> Security Class Initialized
DEBUG - 2016-02-13 11:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:23:19 --> Input Class Initialized
INFO - 2016-02-13 11:23:19 --> Language Class Initialized
INFO - 2016-02-13 11:23:19 --> Loader Class Initialized
INFO - 2016-02-13 11:23:19 --> Helper loaded: url_helper
INFO - 2016-02-13 11:23:19 --> Helper loaded: file_helper
INFO - 2016-02-13 11:23:19 --> Helper loaded: date_helper
INFO - 2016-02-13 11:23:19 --> Helper loaded: form_helper
INFO - 2016-02-13 11:23:19 --> Database Driver Class Initialized
INFO - 2016-02-13 11:23:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:23:21 --> Controller Class Initialized
INFO - 2016-02-13 11:23:21 --> Model Class Initialized
INFO - 2016-02-13 11:23:21 --> Model Class Initialized
INFO - 2016-02-13 11:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:23:21 --> Pagination Class Initialized
INFO - 2016-02-13 11:23:21 --> Helper loaded: text_helper
INFO - 2016-02-13 14:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:23:21 --> Final output sent to browser
DEBUG - 2016-02-13 14:23:21 --> Total execution time: 1.1508
INFO - 2016-02-13 11:24:17 --> Config Class Initialized
INFO - 2016-02-13 11:24:17 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:24:17 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:24:17 --> Utf8 Class Initialized
INFO - 2016-02-13 11:24:17 --> URI Class Initialized
INFO - 2016-02-13 11:24:17 --> Router Class Initialized
INFO - 2016-02-13 11:24:17 --> Output Class Initialized
INFO - 2016-02-13 11:24:17 --> Security Class Initialized
DEBUG - 2016-02-13 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:24:17 --> Input Class Initialized
INFO - 2016-02-13 11:24:17 --> Language Class Initialized
INFO - 2016-02-13 11:24:17 --> Loader Class Initialized
INFO - 2016-02-13 11:24:17 --> Helper loaded: url_helper
INFO - 2016-02-13 11:24:17 --> Helper loaded: file_helper
INFO - 2016-02-13 11:24:17 --> Helper loaded: date_helper
INFO - 2016-02-13 11:24:17 --> Helper loaded: form_helper
INFO - 2016-02-13 11:24:17 --> Database Driver Class Initialized
INFO - 2016-02-13 11:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:24:18 --> Controller Class Initialized
INFO - 2016-02-13 11:24:18 --> Model Class Initialized
INFO - 2016-02-13 11:24:18 --> Model Class Initialized
INFO - 2016-02-13 11:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:24:18 --> Pagination Class Initialized
INFO - 2016-02-13 11:24:18 --> Helper loaded: text_helper
INFO - 2016-02-13 14:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-13 14:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:24:18 --> Final output sent to browser
DEBUG - 2016-02-13 14:24:18 --> Total execution time: 1.1917
INFO - 2016-02-13 11:25:03 --> Config Class Initialized
INFO - 2016-02-13 11:25:03 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:25:03 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:25:03 --> Utf8 Class Initialized
INFO - 2016-02-13 11:25:03 --> URI Class Initialized
DEBUG - 2016-02-13 11:25:03 --> No URI present. Default controller set.
INFO - 2016-02-13 11:25:03 --> Router Class Initialized
INFO - 2016-02-13 11:25:03 --> Output Class Initialized
INFO - 2016-02-13 11:25:03 --> Security Class Initialized
DEBUG - 2016-02-13 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:25:03 --> Input Class Initialized
INFO - 2016-02-13 11:25:03 --> Language Class Initialized
INFO - 2016-02-13 11:25:03 --> Loader Class Initialized
INFO - 2016-02-13 11:25:03 --> Helper loaded: url_helper
INFO - 2016-02-13 11:25:03 --> Helper loaded: file_helper
INFO - 2016-02-13 11:25:03 --> Helper loaded: date_helper
INFO - 2016-02-13 11:25:03 --> Helper loaded: form_helper
INFO - 2016-02-13 11:25:03 --> Database Driver Class Initialized
INFO - 2016-02-13 11:25:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:25:04 --> Controller Class Initialized
INFO - 2016-02-13 11:25:04 --> Model Class Initialized
INFO - 2016-02-13 11:25:04 --> Model Class Initialized
INFO - 2016-02-13 11:25:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:25:04 --> Pagination Class Initialized
INFO - 2016-02-13 11:25:04 --> Helper loaded: text_helper
INFO - 2016-02-13 14:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:25:04 --> Final output sent to browser
DEBUG - 2016-02-13 14:25:04 --> Total execution time: 1.1449
INFO - 2016-02-13 11:41:19 --> Config Class Initialized
INFO - 2016-02-13 11:41:19 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:41:19 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:41:19 --> Utf8 Class Initialized
INFO - 2016-02-13 11:41:19 --> URI Class Initialized
INFO - 2016-02-13 11:41:19 --> Router Class Initialized
INFO - 2016-02-13 11:41:19 --> Output Class Initialized
INFO - 2016-02-13 11:41:19 --> Security Class Initialized
DEBUG - 2016-02-13 11:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:41:19 --> Input Class Initialized
INFO - 2016-02-13 11:41:19 --> Language Class Initialized
INFO - 2016-02-13 11:41:19 --> Loader Class Initialized
INFO - 2016-02-13 11:41:19 --> Helper loaded: url_helper
INFO - 2016-02-13 11:41:19 --> Helper loaded: file_helper
INFO - 2016-02-13 11:41:19 --> Helper loaded: date_helper
INFO - 2016-02-13 11:41:19 --> Helper loaded: form_helper
INFO - 2016-02-13 11:41:19 --> Database Driver Class Initialized
INFO - 2016-02-13 11:41:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:41:20 --> Controller Class Initialized
INFO - 2016-02-13 11:41:20 --> Model Class Initialized
INFO - 2016-02-13 11:41:20 --> Model Class Initialized
INFO - 2016-02-13 11:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:41:20 --> Pagination Class Initialized
INFO - 2016-02-13 11:41:20 --> Helper loaded: text_helper
INFO - 2016-02-13 14:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:41:20 --> Final output sent to browser
DEBUG - 2016-02-13 14:41:20 --> Total execution time: 1.5123
INFO - 2016-02-13 11:41:28 --> Config Class Initialized
INFO - 2016-02-13 11:41:28 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:41:28 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:41:28 --> Utf8 Class Initialized
INFO - 2016-02-13 11:41:28 --> URI Class Initialized
INFO - 2016-02-13 11:41:28 --> Router Class Initialized
INFO - 2016-02-13 11:41:28 --> Output Class Initialized
INFO - 2016-02-13 11:41:28 --> Security Class Initialized
DEBUG - 2016-02-13 11:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:41:28 --> Input Class Initialized
INFO - 2016-02-13 11:41:28 --> Language Class Initialized
INFO - 2016-02-13 11:41:28 --> Loader Class Initialized
INFO - 2016-02-13 11:41:28 --> Helper loaded: url_helper
INFO - 2016-02-13 11:41:28 --> Helper loaded: file_helper
INFO - 2016-02-13 11:41:28 --> Helper loaded: date_helper
INFO - 2016-02-13 11:41:28 --> Helper loaded: form_helper
INFO - 2016-02-13 11:41:28 --> Database Driver Class Initialized
INFO - 2016-02-13 11:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:41:29 --> Controller Class Initialized
INFO - 2016-02-13 11:41:29 --> Model Class Initialized
INFO - 2016-02-13 11:41:29 --> Model Class Initialized
INFO - 2016-02-13 11:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:41:29 --> Pagination Class Initialized
INFO - 2016-02-13 11:41:29 --> Helper loaded: text_helper
INFO - 2016-02-13 11:41:29 --> Config Class Initialized
INFO - 2016-02-13 11:41:29 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:41:29 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:41:29 --> Utf8 Class Initialized
INFO - 2016-02-13 11:41:29 --> URI Class Initialized
INFO - 2016-02-13 11:41:29 --> Router Class Initialized
INFO - 2016-02-13 11:41:29 --> Output Class Initialized
INFO - 2016-02-13 11:41:29 --> Security Class Initialized
DEBUG - 2016-02-13 11:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:41:29 --> Input Class Initialized
INFO - 2016-02-13 11:41:29 --> Language Class Initialized
INFO - 2016-02-13 11:41:29 --> Loader Class Initialized
INFO - 2016-02-13 11:41:29 --> Helper loaded: url_helper
INFO - 2016-02-13 11:41:29 --> Helper loaded: file_helper
INFO - 2016-02-13 11:41:29 --> Helper loaded: date_helper
INFO - 2016-02-13 11:41:29 --> Helper loaded: form_helper
INFO - 2016-02-13 11:41:29 --> Database Driver Class Initialized
INFO - 2016-02-13 11:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:41:30 --> Controller Class Initialized
INFO - 2016-02-13 11:41:30 --> Model Class Initialized
INFO - 2016-02-13 11:41:30 --> Model Class Initialized
INFO - 2016-02-13 11:41:30 --> Form Validation Class Initialized
INFO - 2016-02-13 11:41:30 --> Helper loaded: text_helper
INFO - 2016-02-13 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-13 11:41:30 --> Final output sent to browser
DEBUG - 2016-02-13 11:41:30 --> Total execution time: 1.2478
INFO - 2016-02-13 11:41:33 --> Config Class Initialized
INFO - 2016-02-13 11:41:33 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:41:33 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:41:33 --> Utf8 Class Initialized
INFO - 2016-02-13 11:41:33 --> URI Class Initialized
DEBUG - 2016-02-13 11:41:33 --> No URI present. Default controller set.
INFO - 2016-02-13 11:41:33 --> Router Class Initialized
INFO - 2016-02-13 11:41:33 --> Output Class Initialized
INFO - 2016-02-13 11:41:33 --> Security Class Initialized
DEBUG - 2016-02-13 11:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:41:33 --> Input Class Initialized
INFO - 2016-02-13 11:41:33 --> Language Class Initialized
INFO - 2016-02-13 11:41:33 --> Loader Class Initialized
INFO - 2016-02-13 11:41:33 --> Helper loaded: url_helper
INFO - 2016-02-13 11:41:33 --> Helper loaded: file_helper
INFO - 2016-02-13 11:41:33 --> Helper loaded: date_helper
INFO - 2016-02-13 11:41:33 --> Helper loaded: form_helper
INFO - 2016-02-13 11:41:33 --> Database Driver Class Initialized
INFO - 2016-02-13 11:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:41:34 --> Controller Class Initialized
INFO - 2016-02-13 11:41:34 --> Model Class Initialized
INFO - 2016-02-13 11:41:34 --> Model Class Initialized
INFO - 2016-02-13 11:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:41:34 --> Pagination Class Initialized
INFO - 2016-02-13 11:41:34 --> Helper loaded: text_helper
INFO - 2016-02-13 14:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:41:34 --> Final output sent to browser
DEBUG - 2016-02-13 14:41:34 --> Total execution time: 1.1265
INFO - 2016-02-13 11:47:30 --> Config Class Initialized
INFO - 2016-02-13 11:47:30 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:47:30 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:47:30 --> Utf8 Class Initialized
INFO - 2016-02-13 11:47:30 --> URI Class Initialized
DEBUG - 2016-02-13 11:47:30 --> No URI present. Default controller set.
INFO - 2016-02-13 11:47:30 --> Router Class Initialized
INFO - 2016-02-13 11:47:30 --> Output Class Initialized
INFO - 2016-02-13 11:47:30 --> Security Class Initialized
DEBUG - 2016-02-13 11:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:47:30 --> Input Class Initialized
INFO - 2016-02-13 11:47:30 --> Language Class Initialized
INFO - 2016-02-13 11:47:30 --> Loader Class Initialized
INFO - 2016-02-13 11:47:30 --> Helper loaded: url_helper
INFO - 2016-02-13 11:47:30 --> Helper loaded: file_helper
INFO - 2016-02-13 11:47:30 --> Helper loaded: date_helper
INFO - 2016-02-13 11:47:30 --> Helper loaded: form_helper
INFO - 2016-02-13 11:47:30 --> Database Driver Class Initialized
INFO - 2016-02-13 11:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:47:31 --> Controller Class Initialized
INFO - 2016-02-13 11:47:31 --> Model Class Initialized
INFO - 2016-02-13 11:47:31 --> Model Class Initialized
INFO - 2016-02-13 11:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:47:31 --> Pagination Class Initialized
INFO - 2016-02-13 11:47:32 --> Helper loaded: text_helper
INFO - 2016-02-13 14:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:47:32 --> Final output sent to browser
DEBUG - 2016-02-13 14:47:32 --> Total execution time: 1.1281
INFO - 2016-02-13 11:53:47 --> Config Class Initialized
INFO - 2016-02-13 11:53:47 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:53:47 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:53:47 --> Utf8 Class Initialized
INFO - 2016-02-13 11:53:47 --> URI Class Initialized
INFO - 2016-02-13 11:53:47 --> Router Class Initialized
INFO - 2016-02-13 11:53:47 --> Output Class Initialized
INFO - 2016-02-13 11:53:47 --> Security Class Initialized
DEBUG - 2016-02-13 11:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:53:47 --> Input Class Initialized
INFO - 2016-02-13 11:53:47 --> Language Class Initialized
INFO - 2016-02-13 11:53:47 --> Loader Class Initialized
INFO - 2016-02-13 11:53:47 --> Helper loaded: url_helper
INFO - 2016-02-13 11:53:47 --> Helper loaded: file_helper
INFO - 2016-02-13 11:53:47 --> Helper loaded: date_helper
INFO - 2016-02-13 11:53:47 --> Helper loaded: form_helper
INFO - 2016-02-13 11:53:47 --> Database Driver Class Initialized
INFO - 2016-02-13 11:53:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:53:48 --> Controller Class Initialized
INFO - 2016-02-13 11:53:48 --> Model Class Initialized
INFO - 2016-02-13 11:53:48 --> Model Class Initialized
INFO - 2016-02-13 11:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:53:48 --> Pagination Class Initialized
INFO - 2016-02-13 11:53:48 --> Helper loaded: text_helper
INFO - 2016-02-13 14:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-13 14:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 14:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:53:48 --> Final output sent to browser
DEBUG - 2016-02-13 14:53:48 --> Total execution time: 1.1641
INFO - 2016-02-13 11:59:17 --> Config Class Initialized
INFO - 2016-02-13 11:59:17 --> Hooks Class Initialized
DEBUG - 2016-02-13 11:59:17 --> UTF-8 Support Enabled
INFO - 2016-02-13 11:59:17 --> Utf8 Class Initialized
INFO - 2016-02-13 11:59:17 --> URI Class Initialized
DEBUG - 2016-02-13 11:59:17 --> No URI present. Default controller set.
INFO - 2016-02-13 11:59:17 --> Router Class Initialized
INFO - 2016-02-13 11:59:17 --> Output Class Initialized
INFO - 2016-02-13 11:59:17 --> Security Class Initialized
DEBUG - 2016-02-13 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 11:59:17 --> Input Class Initialized
INFO - 2016-02-13 11:59:17 --> Language Class Initialized
INFO - 2016-02-13 11:59:17 --> Loader Class Initialized
INFO - 2016-02-13 11:59:17 --> Helper loaded: url_helper
INFO - 2016-02-13 11:59:17 --> Helper loaded: file_helper
INFO - 2016-02-13 11:59:17 --> Helper loaded: date_helper
INFO - 2016-02-13 11:59:17 --> Helper loaded: form_helper
INFO - 2016-02-13 11:59:17 --> Database Driver Class Initialized
INFO - 2016-02-13 11:59:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 11:59:18 --> Controller Class Initialized
INFO - 2016-02-13 11:59:18 --> Model Class Initialized
INFO - 2016-02-13 11:59:18 --> Model Class Initialized
INFO - 2016-02-13 11:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 11:59:18 --> Pagination Class Initialized
INFO - 2016-02-13 11:59:18 --> Helper loaded: text_helper
INFO - 2016-02-13 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 14:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 14:59:18 --> Final output sent to browser
DEBUG - 2016-02-13 14:59:18 --> Total execution time: 1.1289
INFO - 2016-02-13 14:21:30 --> Config Class Initialized
INFO - 2016-02-13 14:21:30 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:21:30 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:21:30 --> Utf8 Class Initialized
INFO - 2016-02-13 14:21:30 --> URI Class Initialized
DEBUG - 2016-02-13 14:21:30 --> No URI present. Default controller set.
INFO - 2016-02-13 14:21:30 --> Router Class Initialized
INFO - 2016-02-13 14:21:30 --> Output Class Initialized
INFO - 2016-02-13 14:21:30 --> Security Class Initialized
DEBUG - 2016-02-13 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:21:30 --> Input Class Initialized
INFO - 2016-02-13 14:21:30 --> Language Class Initialized
INFO - 2016-02-13 14:21:30 --> Loader Class Initialized
INFO - 2016-02-13 14:21:30 --> Helper loaded: url_helper
INFO - 2016-02-13 14:21:30 --> Helper loaded: file_helper
INFO - 2016-02-13 14:21:30 --> Helper loaded: date_helper
INFO - 2016-02-13 14:21:30 --> Helper loaded: form_helper
INFO - 2016-02-13 14:21:30 --> Database Driver Class Initialized
INFO - 2016-02-13 14:21:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:21:32 --> Controller Class Initialized
INFO - 2016-02-13 14:21:32 --> Model Class Initialized
INFO - 2016-02-13 14:21:32 --> Model Class Initialized
INFO - 2016-02-13 14:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:21:32 --> Pagination Class Initialized
INFO - 2016-02-13 14:21:32 --> Helper loaded: text_helper
INFO - 2016-02-13 17:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 17:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:21:32 --> Final output sent to browser
DEBUG - 2016-02-13 17:21:32 --> Total execution time: 1.1074
INFO - 2016-02-13 14:22:00 --> Config Class Initialized
INFO - 2016-02-13 14:22:00 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:00 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:00 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:00 --> URI Class Initialized
INFO - 2016-02-13 14:22:00 --> Router Class Initialized
INFO - 2016-02-13 14:22:00 --> Output Class Initialized
INFO - 2016-02-13 14:22:00 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:00 --> Input Class Initialized
INFO - 2016-02-13 14:22:00 --> Language Class Initialized
INFO - 2016-02-13 14:22:00 --> Loader Class Initialized
INFO - 2016-02-13 14:22:00 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:00 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:00 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:00 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:00 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:01 --> Controller Class Initialized
INFO - 2016-02-13 14:22:01 --> Model Class Initialized
INFO - 2016-02-13 14:22:01 --> Model Class Initialized
INFO - 2016-02-13 14:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:22:01 --> Pagination Class Initialized
INFO - 2016-02-13 14:22:01 --> Helper loaded: text_helper
INFO - 2016-02-13 17:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-13 17:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-13 17:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:22:01 --> Final output sent to browser
DEBUG - 2016-02-13 17:22:01 --> Total execution time: 1.1668
INFO - 2016-02-13 14:22:19 --> Config Class Initialized
INFO - 2016-02-13 14:22:19 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:19 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:19 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:19 --> URI Class Initialized
INFO - 2016-02-13 14:22:19 --> Router Class Initialized
INFO - 2016-02-13 14:22:19 --> Output Class Initialized
INFO - 2016-02-13 14:22:19 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:19 --> Input Class Initialized
INFO - 2016-02-13 14:22:19 --> Language Class Initialized
INFO - 2016-02-13 14:22:19 --> Loader Class Initialized
INFO - 2016-02-13 14:22:19 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:19 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:19 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:19 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:19 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:20 --> Controller Class Initialized
INFO - 2016-02-13 14:22:20 --> Model Class Initialized
INFO - 2016-02-13 14:22:20 --> Model Class Initialized
INFO - 2016-02-13 14:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:22:20 --> Pagination Class Initialized
INFO - 2016-02-13 14:22:20 --> Helper loaded: text_helper
INFO - 2016-02-13 17:22:20 --> Final output sent to browser
DEBUG - 2016-02-13 17:22:20 --> Total execution time: 1.0760
INFO - 2016-02-13 14:22:29 --> Config Class Initialized
INFO - 2016-02-13 14:22:29 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:29 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:29 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:29 --> URI Class Initialized
INFO - 2016-02-13 14:22:29 --> Router Class Initialized
INFO - 2016-02-13 14:22:29 --> Output Class Initialized
INFO - 2016-02-13 14:22:29 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:29 --> Input Class Initialized
INFO - 2016-02-13 14:22:29 --> Language Class Initialized
INFO - 2016-02-13 14:22:29 --> Loader Class Initialized
INFO - 2016-02-13 14:22:29 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:30 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:30 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:30 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:30 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:31 --> Controller Class Initialized
INFO - 2016-02-13 14:22:31 --> Model Class Initialized
INFO - 2016-02-13 14:22:31 --> Model Class Initialized
INFO - 2016-02-13 14:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:22:31 --> Pagination Class Initialized
INFO - 2016-02-13 14:22:31 --> Helper loaded: text_helper
INFO - 2016-02-13 14:22:31 --> Config Class Initialized
INFO - 2016-02-13 14:22:31 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:31 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:31 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:31 --> URI Class Initialized
INFO - 2016-02-13 14:22:31 --> Router Class Initialized
INFO - 2016-02-13 14:22:31 --> Output Class Initialized
INFO - 2016-02-13 14:22:31 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:31 --> Input Class Initialized
INFO - 2016-02-13 14:22:31 --> Language Class Initialized
INFO - 2016-02-13 14:22:31 --> Loader Class Initialized
INFO - 2016-02-13 14:22:31 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:31 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:31 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:31 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:31 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:32 --> Controller Class Initialized
INFO - 2016-02-13 14:22:32 --> Model Class Initialized
INFO - 2016-02-13 14:22:32 --> Model Class Initialized
INFO - 2016-02-13 14:22:32 --> Form Validation Class Initialized
INFO - 2016-02-13 14:22:32 --> Helper loaded: text_helper
INFO - 2016-02-13 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 14:22:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-13 14:22:32 --> Final output sent to browser
DEBUG - 2016-02-13 14:22:32 --> Total execution time: 1.1212
INFO - 2016-02-13 14:22:43 --> Config Class Initialized
INFO - 2016-02-13 14:22:43 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:43 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:43 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:43 --> URI Class Initialized
DEBUG - 2016-02-13 14:22:43 --> No URI present. Default controller set.
INFO - 2016-02-13 14:22:43 --> Router Class Initialized
INFO - 2016-02-13 14:22:43 --> Output Class Initialized
INFO - 2016-02-13 14:22:43 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:43 --> Input Class Initialized
INFO - 2016-02-13 14:22:43 --> Language Class Initialized
INFO - 2016-02-13 14:22:43 --> Loader Class Initialized
INFO - 2016-02-13 14:22:43 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:43 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:43 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:43 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:43 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:44 --> Controller Class Initialized
INFO - 2016-02-13 14:22:44 --> Model Class Initialized
INFO - 2016-02-13 14:22:44 --> Model Class Initialized
INFO - 2016-02-13 14:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:22:44 --> Pagination Class Initialized
INFO - 2016-02-13 14:22:44 --> Helper loaded: text_helper
INFO - 2016-02-13 17:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 17:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:22:44 --> Final output sent to browser
DEBUG - 2016-02-13 17:22:44 --> Total execution time: 1.1207
INFO - 2016-02-13 14:22:48 --> Config Class Initialized
INFO - 2016-02-13 14:22:48 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:22:48 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:22:48 --> Utf8 Class Initialized
INFO - 2016-02-13 14:22:48 --> URI Class Initialized
INFO - 2016-02-13 14:22:48 --> Router Class Initialized
INFO - 2016-02-13 14:22:48 --> Output Class Initialized
INFO - 2016-02-13 14:22:48 --> Security Class Initialized
DEBUG - 2016-02-13 14:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:22:49 --> Input Class Initialized
INFO - 2016-02-13 14:22:49 --> Language Class Initialized
INFO - 2016-02-13 14:22:49 --> Loader Class Initialized
INFO - 2016-02-13 14:22:49 --> Helper loaded: url_helper
INFO - 2016-02-13 14:22:49 --> Helper loaded: file_helper
INFO - 2016-02-13 14:22:49 --> Helper loaded: date_helper
INFO - 2016-02-13 14:22:49 --> Helper loaded: form_helper
INFO - 2016-02-13 14:22:49 --> Database Driver Class Initialized
INFO - 2016-02-13 14:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:22:50 --> Controller Class Initialized
INFO - 2016-02-13 14:22:50 --> Model Class Initialized
INFO - 2016-02-13 14:22:50 --> Model Class Initialized
INFO - 2016-02-13 14:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:22:50 --> Pagination Class Initialized
INFO - 2016-02-13 14:22:50 --> Helper loaded: text_helper
INFO - 2016-02-13 17:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 17:22:50 --> Final output sent to browser
DEBUG - 2016-02-13 17:22:50 --> Total execution time: 1.1259
INFO - 2016-02-13 14:23:06 --> Config Class Initialized
INFO - 2016-02-13 14:23:06 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:23:06 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:23:06 --> Utf8 Class Initialized
INFO - 2016-02-13 14:23:06 --> URI Class Initialized
DEBUG - 2016-02-13 14:23:06 --> No URI present. Default controller set.
INFO - 2016-02-13 14:23:06 --> Router Class Initialized
INFO - 2016-02-13 14:23:06 --> Output Class Initialized
INFO - 2016-02-13 14:23:06 --> Security Class Initialized
DEBUG - 2016-02-13 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:23:06 --> Input Class Initialized
INFO - 2016-02-13 14:23:06 --> Language Class Initialized
INFO - 2016-02-13 14:23:06 --> Loader Class Initialized
INFO - 2016-02-13 14:23:06 --> Helper loaded: url_helper
INFO - 2016-02-13 14:23:06 --> Helper loaded: file_helper
INFO - 2016-02-13 14:23:06 --> Helper loaded: date_helper
INFO - 2016-02-13 14:23:06 --> Helper loaded: form_helper
INFO - 2016-02-13 14:23:06 --> Database Driver Class Initialized
INFO - 2016-02-13 14:23:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:23:07 --> Controller Class Initialized
INFO - 2016-02-13 14:23:07 --> Model Class Initialized
INFO - 2016-02-13 14:23:07 --> Model Class Initialized
INFO - 2016-02-13 14:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:23:07 --> Pagination Class Initialized
INFO - 2016-02-13 14:23:07 --> Helper loaded: text_helper
INFO - 2016-02-13 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:23:07 --> Final output sent to browser
DEBUG - 2016-02-13 17:23:07 --> Total execution time: 1.1369
INFO - 2016-02-13 14:23:11 --> Config Class Initialized
INFO - 2016-02-13 14:23:11 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:23:11 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:23:11 --> Utf8 Class Initialized
INFO - 2016-02-13 14:23:11 --> URI Class Initialized
INFO - 2016-02-13 14:23:11 --> Router Class Initialized
INFO - 2016-02-13 14:23:11 --> Output Class Initialized
INFO - 2016-02-13 14:23:11 --> Security Class Initialized
DEBUG - 2016-02-13 14:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:23:11 --> Input Class Initialized
INFO - 2016-02-13 14:23:11 --> Language Class Initialized
INFO - 2016-02-13 14:23:11 --> Loader Class Initialized
INFO - 2016-02-13 14:23:11 --> Helper loaded: url_helper
INFO - 2016-02-13 14:23:11 --> Helper loaded: file_helper
INFO - 2016-02-13 14:23:11 --> Helper loaded: date_helper
INFO - 2016-02-13 14:23:11 --> Helper loaded: form_helper
INFO - 2016-02-13 14:23:11 --> Database Driver Class Initialized
INFO - 2016-02-13 14:23:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:23:12 --> Controller Class Initialized
INFO - 2016-02-13 14:23:12 --> Model Class Initialized
INFO - 2016-02-13 14:23:12 --> Model Class Initialized
INFO - 2016-02-13 14:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:23:12 --> Pagination Class Initialized
INFO - 2016-02-13 14:23:12 --> Helper loaded: text_helper
INFO - 2016-02-13 17:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 17:23:12 --> Final output sent to browser
DEBUG - 2016-02-13 17:23:12 --> Total execution time: 1.1372
INFO - 2016-02-13 14:24:23 --> Config Class Initialized
INFO - 2016-02-13 14:24:23 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:24:23 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:24:23 --> Utf8 Class Initialized
INFO - 2016-02-13 14:24:23 --> URI Class Initialized
DEBUG - 2016-02-13 14:24:23 --> No URI present. Default controller set.
INFO - 2016-02-13 14:24:23 --> Router Class Initialized
INFO - 2016-02-13 14:24:23 --> Output Class Initialized
INFO - 2016-02-13 14:24:23 --> Security Class Initialized
DEBUG - 2016-02-13 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:24:23 --> Input Class Initialized
INFO - 2016-02-13 14:24:23 --> Language Class Initialized
INFO - 2016-02-13 14:24:23 --> Loader Class Initialized
INFO - 2016-02-13 14:24:23 --> Helper loaded: url_helper
INFO - 2016-02-13 14:24:23 --> Helper loaded: file_helper
INFO - 2016-02-13 14:24:23 --> Helper loaded: date_helper
INFO - 2016-02-13 14:24:23 --> Helper loaded: form_helper
INFO - 2016-02-13 14:24:23 --> Database Driver Class Initialized
INFO - 2016-02-13 14:24:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:24:24 --> Controller Class Initialized
INFO - 2016-02-13 14:24:24 --> Model Class Initialized
INFO - 2016-02-13 14:24:24 --> Model Class Initialized
INFO - 2016-02-13 14:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:24:24 --> Pagination Class Initialized
INFO - 2016-02-13 14:24:24 --> Helper loaded: text_helper
INFO - 2016-02-13 17:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 17:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:24:24 --> Final output sent to browser
DEBUG - 2016-02-13 17:24:24 --> Total execution time: 1.1483
INFO - 2016-02-13 14:24:26 --> Config Class Initialized
INFO - 2016-02-13 14:24:26 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:24:26 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:24:26 --> Utf8 Class Initialized
INFO - 2016-02-13 14:24:26 --> URI Class Initialized
INFO - 2016-02-13 14:24:26 --> Router Class Initialized
INFO - 2016-02-13 14:24:26 --> Output Class Initialized
INFO - 2016-02-13 14:24:26 --> Security Class Initialized
DEBUG - 2016-02-13 14:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:24:26 --> Input Class Initialized
INFO - 2016-02-13 14:24:26 --> Language Class Initialized
INFO - 2016-02-13 14:24:26 --> Loader Class Initialized
INFO - 2016-02-13 14:24:26 --> Helper loaded: url_helper
INFO - 2016-02-13 14:24:26 --> Helper loaded: file_helper
INFO - 2016-02-13 14:24:26 --> Helper loaded: date_helper
INFO - 2016-02-13 14:24:26 --> Helper loaded: form_helper
INFO - 2016-02-13 14:24:26 --> Database Driver Class Initialized
INFO - 2016-02-13 14:24:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:24:27 --> Controller Class Initialized
INFO - 2016-02-13 14:24:27 --> Model Class Initialized
INFO - 2016-02-13 14:24:27 --> Model Class Initialized
INFO - 2016-02-13 14:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:24:27 --> Pagination Class Initialized
INFO - 2016-02-13 14:24:27 --> Helper loaded: text_helper
INFO - 2016-02-13 17:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-13 17:24:27 --> Final output sent to browser
DEBUG - 2016-02-13 17:24:27 --> Total execution time: 1.1365
INFO - 2016-02-13 14:24:38 --> Config Class Initialized
INFO - 2016-02-13 14:24:38 --> Hooks Class Initialized
DEBUG - 2016-02-13 14:24:38 --> UTF-8 Support Enabled
INFO - 2016-02-13 14:24:38 --> Utf8 Class Initialized
INFO - 2016-02-13 14:24:38 --> URI Class Initialized
DEBUG - 2016-02-13 14:24:38 --> No URI present. Default controller set.
INFO - 2016-02-13 14:24:38 --> Router Class Initialized
INFO - 2016-02-13 14:24:38 --> Output Class Initialized
INFO - 2016-02-13 14:24:38 --> Security Class Initialized
DEBUG - 2016-02-13 14:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-13 14:24:38 --> Input Class Initialized
INFO - 2016-02-13 14:24:38 --> Language Class Initialized
INFO - 2016-02-13 14:24:38 --> Loader Class Initialized
INFO - 2016-02-13 14:24:38 --> Helper loaded: url_helper
INFO - 2016-02-13 14:24:38 --> Helper loaded: file_helper
INFO - 2016-02-13 14:24:38 --> Helper loaded: date_helper
INFO - 2016-02-13 14:24:38 --> Helper loaded: form_helper
INFO - 2016-02-13 14:24:38 --> Database Driver Class Initialized
INFO - 2016-02-13 14:24:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-13 14:24:39 --> Controller Class Initialized
INFO - 2016-02-13 14:24:39 --> Model Class Initialized
INFO - 2016-02-13 14:24:39 --> Model Class Initialized
INFO - 2016-02-13 14:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-13 14:24:39 --> Pagination Class Initialized
INFO - 2016-02-13 14:24:39 --> Helper loaded: text_helper
INFO - 2016-02-13 17:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-13 17:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-13 17:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-13 17:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-13 17:24:39 --> Final output sent to browser
DEBUG - 2016-02-13 17:24:39 --> Total execution time: 1.1186
