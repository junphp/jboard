<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-19 00:02:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:02:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:02:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:02:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:02:27 --> Final output sent to browser
DEBUG - 2016-02-19 00:02:27 --> Total execution time: 1.8597
INFO - 2016-02-19 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:02:46 --> Final output sent to browser
DEBUG - 2016-02-19 00:02:46 --> Total execution time: 1.3584
INFO - 2016-02-19 00:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:04:40 --> Final output sent to browser
DEBUG - 2016-02-19 00:04:40 --> Total execution time: 1.1424
INFO - 2016-02-19 00:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:06:51 --> Final output sent to browser
DEBUG - 2016-02-19 00:06:51 --> Total execution time: 1.1386
INFO - 2016-02-19 00:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:07:30 --> Final output sent to browser
DEBUG - 2016-02-19 00:07:30 --> Total execution time: 1.1651
INFO - 2016-02-19 00:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:14:42 --> Final output sent to browser
DEBUG - 2016-02-19 00:14:42 --> Total execution time: 1.2183
INFO - 2016-02-19 00:14:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:14:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:14:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:14:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:14:52 --> Final output sent to browser
DEBUG - 2016-02-19 00:14:52 --> Total execution time: 1.1141
INFO - 2016-02-19 00:14:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:14:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:14:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:14:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:14:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:14:55 --> Final output sent to browser
DEBUG - 2016-02-19 00:14:55 --> Total execution time: 1.1333
INFO - 2016-02-19 00:15:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:15:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:15:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:15:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:15:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:15:24 --> Final output sent to browser
DEBUG - 2016-02-19 00:15:24 --> Total execution time: 1.2049
INFO - 2016-02-19 00:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:15:43 --> Final output sent to browser
DEBUG - 2016-02-19 00:15:43 --> Total execution time: 1.1855
INFO - 2016-02-19 00:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:17:29 --> Final output sent to browser
DEBUG - 2016-02-19 00:17:29 --> Total execution time: 1.1924
INFO - 2016-02-19 00:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:18:42 --> Final output sent to browser
DEBUG - 2016-02-19 00:18:42 --> Total execution time: 1.1804
INFO - 2016-02-19 00:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:23:53 --> Final output sent to browser
DEBUG - 2016-02-19 00:23:53 --> Total execution time: 1.2418
INFO - 2016-02-19 00:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:26:03 --> Final output sent to browser
DEBUG - 2016-02-19 00:26:03 --> Total execution time: 1.2177
INFO - 2016-02-19 00:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:26:59 --> Final output sent to browser
DEBUG - 2016-02-19 00:26:59 --> Total execution time: 1.1878
INFO - 2016-02-19 00:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:27:25 --> Final output sent to browser
DEBUG - 2016-02-19 00:27:25 --> Total execution time: 1.1301
INFO - 2016-02-19 00:27:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:27:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:27:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:27:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:27:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:27:48 --> Final output sent to browser
DEBUG - 2016-02-19 00:27:48 --> Total execution time: 1.1819
INFO - 2016-02-19 00:31:59 --> Final output sent to browser
DEBUG - 2016-02-19 00:31:59 --> Total execution time: 1.1209
INFO - 2016-02-19 00:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:36:26 --> Final output sent to browser
DEBUG - 2016-02-19 00:36:26 --> Total execution time: 1.1293
INFO - 2016-02-19 00:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:36:29 --> Final output sent to browser
DEBUG - 2016-02-19 00:36:29 --> Total execution time: 1.2079
INFO - 2016-02-19 00:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:36:32 --> Final output sent to browser
DEBUG - 2016-02-19 00:36:32 --> Total execution time: 1.1015
INFO - 2016-02-19 00:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:36:35 --> Final output sent to browser
DEBUG - 2016-02-19 00:36:35 --> Total execution time: 1.2061
INFO - 2016-02-19 00:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:38:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:38:49 --> Final output sent to browser
DEBUG - 2016-02-19 00:38:49 --> Total execution time: 1.1834
INFO - 2016-02-19 00:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:39:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:10 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:10 --> Total execution time: 1.1095
INFO - 2016-02-19 00:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:28 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:28 --> Total execution time: 1.2292
INFO - 2016-02-19 00:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:33 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:33 --> Total execution time: 1.1061
INFO - 2016-02-19 00:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:39:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:37 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:37 --> Total execution time: 1.2550
INFO - 2016-02-19 00:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:43 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:43 --> Total execution time: 1.1039
INFO - 2016-02-19 00:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:39:45 --> Final output sent to browser
DEBUG - 2016-02-19 00:39:45 --> Total execution time: 1.1512
INFO - 2016-02-19 00:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:42:47 --> Final output sent to browser
DEBUG - 2016-02-19 00:42:47 --> Total execution time: 1.2567
INFO - 2016-02-19 00:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 00:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 00:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:43:38 --> Final output sent to browser
DEBUG - 2016-02-19 00:43:38 --> Total execution time: 1.2503
INFO - 2016-02-19 00:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:50:17 --> Final output sent to browser
DEBUG - 2016-02-19 00:50:17 --> Total execution time: 1.1408
INFO - 2016-02-19 00:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:51:27 --> Final output sent to browser
DEBUG - 2016-02-19 00:51:27 --> Total execution time: 1.1386
INFO - 2016-02-19 00:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:51:42 --> Final output sent to browser
DEBUG - 2016-02-19 00:51:42 --> Total execution time: 1.1714
INFO - 2016-02-19 00:52:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:52:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:52:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:52:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:52:28 --> Final output sent to browser
DEBUG - 2016-02-19 00:52:28 --> Total execution time: 1.1172
INFO - 2016-02-19 00:52:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:52:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:52:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:52:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:52:41 --> Final output sent to browser
DEBUG - 2016-02-19 00:52:41 --> Total execution time: 1.1204
INFO - 2016-02-19 00:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 00:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 00:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 00:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 00:52:45 --> Final output sent to browser
DEBUG - 2016-02-19 00:52:45 --> Total execution time: 1.0945
INFO - 2016-02-19 05:05:54 --> Config Class Initialized
INFO - 2016-02-19 05:05:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:05:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:05:54 --> Utf8 Class Initialized
INFO - 2016-02-19 05:05:54 --> URI Class Initialized
DEBUG - 2016-02-19 05:05:54 --> No URI present. Default controller set.
INFO - 2016-02-19 05:05:54 --> Router Class Initialized
INFO - 2016-02-19 05:05:54 --> Output Class Initialized
INFO - 2016-02-19 05:05:54 --> Security Class Initialized
DEBUG - 2016-02-19 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:05:54 --> Input Class Initialized
INFO - 2016-02-19 05:05:54 --> Language Class Initialized
INFO - 2016-02-19 05:05:54 --> Loader Class Initialized
INFO - 2016-02-19 05:05:54 --> Helper loaded: url_helper
INFO - 2016-02-19 05:05:54 --> Helper loaded: file_helper
INFO - 2016-02-19 05:05:54 --> Helper loaded: date_helper
INFO - 2016-02-19 05:05:54 --> Helper loaded: form_helper
INFO - 2016-02-19 05:05:54 --> Database Driver Class Initialized
INFO - 2016-02-19 05:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:05:55 --> Controller Class Initialized
INFO - 2016-02-19 05:05:55 --> Model Class Initialized
INFO - 2016-02-19 05:05:55 --> Model Class Initialized
INFO - 2016-02-19 05:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:05:55 --> Pagination Class Initialized
INFO - 2016-02-19 05:05:55 --> Helper loaded: text_helper
INFO - 2016-02-19 05:05:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:05:55 --> Final output sent to browser
DEBUG - 2016-02-19 08:05:55 --> Total execution time: 1.1445
INFO - 2016-02-19 05:13:19 --> Config Class Initialized
INFO - 2016-02-19 05:13:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:13:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:13:19 --> Utf8 Class Initialized
INFO - 2016-02-19 05:13:19 --> URI Class Initialized
DEBUG - 2016-02-19 05:13:19 --> No URI present. Default controller set.
INFO - 2016-02-19 05:13:19 --> Router Class Initialized
INFO - 2016-02-19 05:13:19 --> Output Class Initialized
INFO - 2016-02-19 05:13:19 --> Security Class Initialized
DEBUG - 2016-02-19 05:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:13:19 --> Input Class Initialized
INFO - 2016-02-19 05:13:19 --> Language Class Initialized
INFO - 2016-02-19 05:13:19 --> Loader Class Initialized
INFO - 2016-02-19 05:13:19 --> Helper loaded: url_helper
INFO - 2016-02-19 05:13:19 --> Helper loaded: file_helper
INFO - 2016-02-19 05:13:19 --> Helper loaded: date_helper
INFO - 2016-02-19 05:13:19 --> Helper loaded: form_helper
INFO - 2016-02-19 05:13:19 --> Database Driver Class Initialized
INFO - 2016-02-19 05:13:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:13:20 --> Controller Class Initialized
INFO - 2016-02-19 05:13:20 --> Model Class Initialized
INFO - 2016-02-19 05:13:20 --> Model Class Initialized
INFO - 2016-02-19 05:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:13:20 --> Pagination Class Initialized
INFO - 2016-02-19 05:13:20 --> Helper loaded: text_helper
INFO - 2016-02-19 05:13:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:13:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:13:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:13:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:13:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:13:20 --> Final output sent to browser
DEBUG - 2016-02-19 08:13:20 --> Total execution time: 1.1142
INFO - 2016-02-19 05:13:21 --> Config Class Initialized
INFO - 2016-02-19 05:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:13:21 --> Utf8 Class Initialized
INFO - 2016-02-19 05:13:21 --> URI Class Initialized
INFO - 2016-02-19 05:13:21 --> Router Class Initialized
INFO - 2016-02-19 05:13:21 --> Output Class Initialized
INFO - 2016-02-19 05:13:21 --> Security Class Initialized
DEBUG - 2016-02-19 05:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:13:21 --> Input Class Initialized
INFO - 2016-02-19 05:13:21 --> Language Class Initialized
INFO - 2016-02-19 05:13:21 --> Loader Class Initialized
INFO - 2016-02-19 05:13:21 --> Helper loaded: url_helper
INFO - 2016-02-19 05:13:21 --> Helper loaded: file_helper
INFO - 2016-02-19 05:13:21 --> Helper loaded: date_helper
INFO - 2016-02-19 05:13:21 --> Helper loaded: form_helper
INFO - 2016-02-19 05:13:21 --> Database Driver Class Initialized
INFO - 2016-02-19 05:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:13:23 --> Controller Class Initialized
INFO - 2016-02-19 05:13:23 --> Model Class Initialized
INFO - 2016-02-19 05:13:23 --> Model Class Initialized
INFO - 2016-02-19 05:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:13:23 --> Pagination Class Initialized
INFO - 2016-02-19 05:13:23 --> Helper loaded: text_helper
INFO - 2016-02-19 05:13:23 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:13:23 --> Final output sent to browser
DEBUG - 2016-02-19 08:13:23 --> Total execution time: 1.1640
INFO - 2016-02-19 05:14:27 --> Config Class Initialized
INFO - 2016-02-19 05:14:27 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:14:27 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:14:27 --> Utf8 Class Initialized
INFO - 2016-02-19 05:14:27 --> URI Class Initialized
DEBUG - 2016-02-19 05:14:27 --> No URI present. Default controller set.
INFO - 2016-02-19 05:14:27 --> Router Class Initialized
INFO - 2016-02-19 05:14:27 --> Output Class Initialized
INFO - 2016-02-19 05:14:27 --> Security Class Initialized
DEBUG - 2016-02-19 05:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:14:27 --> Input Class Initialized
INFO - 2016-02-19 05:14:27 --> Language Class Initialized
INFO - 2016-02-19 05:14:27 --> Loader Class Initialized
INFO - 2016-02-19 05:14:27 --> Helper loaded: url_helper
INFO - 2016-02-19 05:14:27 --> Helper loaded: file_helper
INFO - 2016-02-19 05:14:27 --> Helper loaded: date_helper
INFO - 2016-02-19 05:14:27 --> Helper loaded: form_helper
INFO - 2016-02-19 05:14:27 --> Database Driver Class Initialized
INFO - 2016-02-19 05:14:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:14:28 --> Controller Class Initialized
INFO - 2016-02-19 05:14:29 --> Model Class Initialized
INFO - 2016-02-19 05:14:29 --> Model Class Initialized
INFO - 2016-02-19 05:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:14:29 --> Pagination Class Initialized
INFO - 2016-02-19 05:14:29 --> Helper loaded: text_helper
INFO - 2016-02-19 05:14:29 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:14:29 --> Final output sent to browser
DEBUG - 2016-02-19 08:14:29 --> Total execution time: 1.1434
INFO - 2016-02-19 05:14:47 --> Config Class Initialized
INFO - 2016-02-19 05:14:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:14:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:14:47 --> Utf8 Class Initialized
INFO - 2016-02-19 05:14:47 --> URI Class Initialized
INFO - 2016-02-19 05:14:47 --> Router Class Initialized
INFO - 2016-02-19 05:14:47 --> Output Class Initialized
INFO - 2016-02-19 05:14:47 --> Security Class Initialized
DEBUG - 2016-02-19 05:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:14:47 --> Input Class Initialized
INFO - 2016-02-19 05:14:47 --> Language Class Initialized
INFO - 2016-02-19 05:14:47 --> Loader Class Initialized
INFO - 2016-02-19 05:14:47 --> Helper loaded: url_helper
INFO - 2016-02-19 05:14:47 --> Helper loaded: file_helper
INFO - 2016-02-19 05:14:47 --> Helper loaded: date_helper
INFO - 2016-02-19 05:14:47 --> Helper loaded: form_helper
INFO - 2016-02-19 05:14:47 --> Database Driver Class Initialized
INFO - 2016-02-19 05:14:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:14:48 --> Controller Class Initialized
INFO - 2016-02-19 05:14:48 --> Model Class Initialized
INFO - 2016-02-19 05:14:48 --> Model Class Initialized
INFO - 2016-02-19 05:14:48 --> Form Validation Class Initialized
INFO - 2016-02-19 05:14:48 --> Helper loaded: text_helper
INFO - 2016-02-19 05:14:48 --> Config Class Initialized
INFO - 2016-02-19 05:14:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:14:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:14:48 --> Utf8 Class Initialized
INFO - 2016-02-19 05:14:48 --> URI Class Initialized
DEBUG - 2016-02-19 05:14:48 --> No URI present. Default controller set.
INFO - 2016-02-19 05:14:48 --> Router Class Initialized
INFO - 2016-02-19 05:14:48 --> Output Class Initialized
INFO - 2016-02-19 05:14:48 --> Security Class Initialized
DEBUG - 2016-02-19 05:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:14:48 --> Input Class Initialized
INFO - 2016-02-19 05:14:48 --> Language Class Initialized
INFO - 2016-02-19 05:14:48 --> Loader Class Initialized
INFO - 2016-02-19 05:14:48 --> Helper loaded: url_helper
INFO - 2016-02-19 05:14:48 --> Helper loaded: file_helper
INFO - 2016-02-19 05:14:48 --> Helper loaded: date_helper
INFO - 2016-02-19 05:14:48 --> Helper loaded: form_helper
INFO - 2016-02-19 05:14:48 --> Database Driver Class Initialized
INFO - 2016-02-19 05:14:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:14:49 --> Controller Class Initialized
INFO - 2016-02-19 05:14:49 --> Model Class Initialized
INFO - 2016-02-19 05:14:49 --> Model Class Initialized
INFO - 2016-02-19 05:14:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:14:49 --> Pagination Class Initialized
INFO - 2016-02-19 05:14:49 --> Helper loaded: text_helper
INFO - 2016-02-19 05:14:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:14:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:14:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:14:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:14:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:14:49 --> Final output sent to browser
DEBUG - 2016-02-19 08:14:49 --> Total execution time: 1.1394
INFO - 2016-02-19 05:16:32 --> Config Class Initialized
INFO - 2016-02-19 05:16:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:16:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:16:32 --> Utf8 Class Initialized
INFO - 2016-02-19 05:16:32 --> URI Class Initialized
INFO - 2016-02-19 05:16:32 --> Router Class Initialized
INFO - 2016-02-19 05:16:32 --> Output Class Initialized
INFO - 2016-02-19 05:16:32 --> Security Class Initialized
DEBUG - 2016-02-19 05:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:16:32 --> Input Class Initialized
INFO - 2016-02-19 05:16:32 --> Language Class Initialized
INFO - 2016-02-19 05:16:32 --> Loader Class Initialized
INFO - 2016-02-19 05:16:32 --> Helper loaded: url_helper
INFO - 2016-02-19 05:16:32 --> Helper loaded: file_helper
INFO - 2016-02-19 05:16:32 --> Helper loaded: date_helper
INFO - 2016-02-19 05:16:32 --> Helper loaded: form_helper
INFO - 2016-02-19 05:16:32 --> Database Driver Class Initialized
INFO - 2016-02-19 05:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:16:33 --> Controller Class Initialized
INFO - 2016-02-19 05:16:33 --> Model Class Initialized
INFO - 2016-02-19 05:16:33 --> Model Class Initialized
INFO - 2016-02-19 05:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:16:33 --> Pagination Class Initialized
INFO - 2016-02-19 05:16:33 --> Helper loaded: text_helper
INFO - 2016-02-19 05:16:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:16:33 --> Form Validation Class Initialized
INFO - 2016-02-19 08:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 08:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:16:33 --> Final output sent to browser
DEBUG - 2016-02-19 08:16:33 --> Total execution time: 1.1355
INFO - 2016-02-19 05:17:09 --> Config Class Initialized
INFO - 2016-02-19 05:17:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:17:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:17:09 --> Utf8 Class Initialized
INFO - 2016-02-19 05:17:09 --> URI Class Initialized
DEBUG - 2016-02-19 05:17:09 --> No URI present. Default controller set.
INFO - 2016-02-19 05:17:09 --> Router Class Initialized
INFO - 2016-02-19 05:17:09 --> Output Class Initialized
INFO - 2016-02-19 05:17:09 --> Security Class Initialized
DEBUG - 2016-02-19 05:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:17:09 --> Input Class Initialized
INFO - 2016-02-19 05:17:09 --> Language Class Initialized
INFO - 2016-02-19 05:17:09 --> Loader Class Initialized
INFO - 2016-02-19 05:17:09 --> Helper loaded: url_helper
INFO - 2016-02-19 05:17:09 --> Helper loaded: file_helper
INFO - 2016-02-19 05:17:09 --> Helper loaded: date_helper
INFO - 2016-02-19 05:17:09 --> Helper loaded: form_helper
INFO - 2016-02-19 05:17:09 --> Database Driver Class Initialized
INFO - 2016-02-19 05:17:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:17:10 --> Controller Class Initialized
INFO - 2016-02-19 05:17:10 --> Model Class Initialized
INFO - 2016-02-19 05:17:10 --> Model Class Initialized
INFO - 2016-02-19 05:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:17:10 --> Pagination Class Initialized
INFO - 2016-02-19 05:17:10 --> Helper loaded: text_helper
INFO - 2016-02-19 05:17:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:17:10 --> Final output sent to browser
DEBUG - 2016-02-19 08:17:10 --> Total execution time: 1.1055
INFO - 2016-02-19 05:17:15 --> Config Class Initialized
INFO - 2016-02-19 05:17:15 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:17:15 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:17:15 --> Utf8 Class Initialized
INFO - 2016-02-19 05:17:15 --> URI Class Initialized
INFO - 2016-02-19 05:17:15 --> Router Class Initialized
INFO - 2016-02-19 05:17:15 --> Output Class Initialized
INFO - 2016-02-19 05:17:15 --> Security Class Initialized
DEBUG - 2016-02-19 05:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:17:15 --> Input Class Initialized
INFO - 2016-02-19 05:17:15 --> Language Class Initialized
INFO - 2016-02-19 05:17:15 --> Loader Class Initialized
INFO - 2016-02-19 05:17:15 --> Helper loaded: url_helper
INFO - 2016-02-19 05:17:15 --> Helper loaded: file_helper
INFO - 2016-02-19 05:17:15 --> Helper loaded: date_helper
INFO - 2016-02-19 05:17:15 --> Helper loaded: form_helper
INFO - 2016-02-19 05:17:15 --> Database Driver Class Initialized
INFO - 2016-02-19 05:17:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:17:16 --> Controller Class Initialized
INFO - 2016-02-19 05:17:16 --> Model Class Initialized
INFO - 2016-02-19 05:17:16 --> Model Class Initialized
INFO - 2016-02-19 05:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:17:16 --> Pagination Class Initialized
INFO - 2016-02-19 05:17:16 --> Helper loaded: text_helper
INFO - 2016-02-19 05:17:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:17:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:17:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:17:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:17:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:17:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:17:16 --> Final output sent to browser
DEBUG - 2016-02-19 08:17:16 --> Total execution time: 1.1276
INFO - 2016-02-19 05:28:44 --> Config Class Initialized
INFO - 2016-02-19 05:28:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:28:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:28:44 --> Utf8 Class Initialized
INFO - 2016-02-19 05:28:44 --> URI Class Initialized
DEBUG - 2016-02-19 05:28:44 --> No URI present. Default controller set.
INFO - 2016-02-19 05:28:44 --> Router Class Initialized
INFO - 2016-02-19 05:28:44 --> Output Class Initialized
INFO - 2016-02-19 05:28:44 --> Security Class Initialized
DEBUG - 2016-02-19 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:28:44 --> Input Class Initialized
INFO - 2016-02-19 05:28:44 --> Language Class Initialized
INFO - 2016-02-19 05:28:44 --> Loader Class Initialized
INFO - 2016-02-19 05:28:45 --> Helper loaded: url_helper
INFO - 2016-02-19 05:28:45 --> Helper loaded: file_helper
INFO - 2016-02-19 05:28:45 --> Helper loaded: date_helper
INFO - 2016-02-19 05:28:45 --> Helper loaded: form_helper
INFO - 2016-02-19 05:28:45 --> Database Driver Class Initialized
INFO - 2016-02-19 05:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:28:46 --> Controller Class Initialized
INFO - 2016-02-19 05:28:46 --> Model Class Initialized
INFO - 2016-02-19 05:28:46 --> Model Class Initialized
INFO - 2016-02-19 05:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:28:46 --> Pagination Class Initialized
INFO - 2016-02-19 05:28:46 --> Helper loaded: text_helper
INFO - 2016-02-19 05:28:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:28:46 --> Final output sent to browser
DEBUG - 2016-02-19 08:28:46 --> Total execution time: 1.1535
INFO - 2016-02-19 05:28:48 --> Config Class Initialized
INFO - 2016-02-19 05:28:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:28:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:28:48 --> Utf8 Class Initialized
INFO - 2016-02-19 05:28:48 --> URI Class Initialized
INFO - 2016-02-19 05:28:48 --> Router Class Initialized
INFO - 2016-02-19 05:28:48 --> Output Class Initialized
INFO - 2016-02-19 05:28:48 --> Security Class Initialized
DEBUG - 2016-02-19 05:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:28:48 --> Input Class Initialized
INFO - 2016-02-19 05:28:48 --> Language Class Initialized
INFO - 2016-02-19 05:28:48 --> Loader Class Initialized
INFO - 2016-02-19 05:28:48 --> Helper loaded: url_helper
INFO - 2016-02-19 05:28:48 --> Helper loaded: file_helper
INFO - 2016-02-19 05:28:48 --> Helper loaded: date_helper
INFO - 2016-02-19 05:28:48 --> Helper loaded: form_helper
INFO - 2016-02-19 05:28:48 --> Database Driver Class Initialized
INFO - 2016-02-19 05:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:28:49 --> Controller Class Initialized
INFO - 2016-02-19 05:28:49 --> Model Class Initialized
INFO - 2016-02-19 05:28:49 --> Model Class Initialized
INFO - 2016-02-19 05:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:28:49 --> Pagination Class Initialized
INFO - 2016-02-19 05:28:49 --> Helper loaded: text_helper
INFO - 2016-02-19 05:28:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 08:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:28:49 --> Final output sent to browser
DEBUG - 2016-02-19 08:28:49 --> Total execution time: 1.1651
INFO - 2016-02-19 05:29:59 --> Config Class Initialized
INFO - 2016-02-19 05:29:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:29:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:29:59 --> Utf8 Class Initialized
INFO - 2016-02-19 05:29:59 --> URI Class Initialized
DEBUG - 2016-02-19 05:29:59 --> No URI present. Default controller set.
INFO - 2016-02-19 05:29:59 --> Router Class Initialized
INFO - 2016-02-19 05:29:59 --> Output Class Initialized
INFO - 2016-02-19 05:29:59 --> Security Class Initialized
DEBUG - 2016-02-19 05:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:29:59 --> Input Class Initialized
INFO - 2016-02-19 05:29:59 --> Language Class Initialized
INFO - 2016-02-19 05:29:59 --> Loader Class Initialized
INFO - 2016-02-19 05:29:59 --> Helper loaded: url_helper
INFO - 2016-02-19 05:29:59 --> Helper loaded: file_helper
INFO - 2016-02-19 05:29:59 --> Helper loaded: date_helper
INFO - 2016-02-19 05:29:59 --> Helper loaded: form_helper
INFO - 2016-02-19 05:29:59 --> Database Driver Class Initialized
INFO - 2016-02-19 05:30:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:30:00 --> Controller Class Initialized
INFO - 2016-02-19 05:30:00 --> Model Class Initialized
INFO - 2016-02-19 05:30:00 --> Model Class Initialized
INFO - 2016-02-19 05:30:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:30:00 --> Pagination Class Initialized
INFO - 2016-02-19 05:30:00 --> Helper loaded: text_helper
INFO - 2016-02-19 05:30:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:30:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:30:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:30:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:30:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:30:00 --> Final output sent to browser
DEBUG - 2016-02-19 08:30:00 --> Total execution time: 1.1562
INFO - 2016-02-19 05:30:02 --> Config Class Initialized
INFO - 2016-02-19 05:30:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:30:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:30:02 --> Utf8 Class Initialized
INFO - 2016-02-19 05:30:02 --> URI Class Initialized
INFO - 2016-02-19 05:30:02 --> Router Class Initialized
INFO - 2016-02-19 05:30:02 --> Output Class Initialized
INFO - 2016-02-19 05:30:02 --> Security Class Initialized
DEBUG - 2016-02-19 05:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:30:02 --> Input Class Initialized
INFO - 2016-02-19 05:30:02 --> Language Class Initialized
INFO - 2016-02-19 05:30:02 --> Loader Class Initialized
INFO - 2016-02-19 05:30:02 --> Helper loaded: url_helper
INFO - 2016-02-19 05:30:02 --> Helper loaded: file_helper
INFO - 2016-02-19 05:30:02 --> Helper loaded: date_helper
INFO - 2016-02-19 05:30:02 --> Helper loaded: form_helper
INFO - 2016-02-19 05:30:02 --> Database Driver Class Initialized
INFO - 2016-02-19 05:30:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:30:03 --> Controller Class Initialized
INFO - 2016-02-19 05:30:03 --> Model Class Initialized
INFO - 2016-02-19 05:30:03 --> Model Class Initialized
INFO - 2016-02-19 05:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:30:03 --> Pagination Class Initialized
INFO - 2016-02-19 05:30:03 --> Helper loaded: text_helper
INFO - 2016-02-19 05:30:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 08:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:30:03 --> Final output sent to browser
DEBUG - 2016-02-19 08:30:03 --> Total execution time: 1.1647
INFO - 2016-02-19 05:30:41 --> Config Class Initialized
INFO - 2016-02-19 05:30:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:30:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:30:41 --> Utf8 Class Initialized
INFO - 2016-02-19 05:30:41 --> URI Class Initialized
INFO - 2016-02-19 05:30:41 --> Router Class Initialized
INFO - 2016-02-19 05:30:41 --> Output Class Initialized
INFO - 2016-02-19 05:30:41 --> Security Class Initialized
DEBUG - 2016-02-19 05:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:30:41 --> Input Class Initialized
INFO - 2016-02-19 05:30:41 --> Language Class Initialized
INFO - 2016-02-19 05:30:41 --> Loader Class Initialized
INFO - 2016-02-19 05:30:41 --> Helper loaded: url_helper
INFO - 2016-02-19 05:30:41 --> Helper loaded: file_helper
INFO - 2016-02-19 05:30:41 --> Helper loaded: date_helper
INFO - 2016-02-19 05:30:41 --> Helper loaded: form_helper
INFO - 2016-02-19 05:30:41 --> Database Driver Class Initialized
INFO - 2016-02-19 05:30:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:30:42 --> Controller Class Initialized
INFO - 2016-02-19 05:30:42 --> Model Class Initialized
INFO - 2016-02-19 05:30:42 --> Model Class Initialized
INFO - 2016-02-19 05:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:30:42 --> Pagination Class Initialized
INFO - 2016-02-19 05:30:42 --> Helper loaded: text_helper
INFO - 2016-02-19 05:30:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:30:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:30:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:30:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 08:30:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:30:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:30:42 --> Final output sent to browser
DEBUG - 2016-02-19 08:30:42 --> Total execution time: 1.1744
INFO - 2016-02-19 05:43:47 --> Config Class Initialized
INFO - 2016-02-19 05:43:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:43:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:43:47 --> Utf8 Class Initialized
INFO - 2016-02-19 05:43:47 --> URI Class Initialized
INFO - 2016-02-19 05:43:47 --> Router Class Initialized
INFO - 2016-02-19 05:43:47 --> Output Class Initialized
INFO - 2016-02-19 05:43:47 --> Security Class Initialized
DEBUG - 2016-02-19 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:43:47 --> Input Class Initialized
INFO - 2016-02-19 05:43:47 --> Language Class Initialized
INFO - 2016-02-19 05:43:47 --> Loader Class Initialized
INFO - 2016-02-19 05:43:47 --> Helper loaded: url_helper
INFO - 2016-02-19 05:43:47 --> Helper loaded: file_helper
INFO - 2016-02-19 05:43:47 --> Helper loaded: date_helper
INFO - 2016-02-19 05:43:47 --> Helper loaded: form_helper
INFO - 2016-02-19 05:43:47 --> Database Driver Class Initialized
INFO - 2016-02-19 05:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:43:48 --> Controller Class Initialized
INFO - 2016-02-19 05:43:48 --> Model Class Initialized
INFO - 2016-02-19 05:43:48 --> Model Class Initialized
INFO - 2016-02-19 05:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:43:48 --> Pagination Class Initialized
INFO - 2016-02-19 05:43:48 --> Helper loaded: text_helper
INFO - 2016-02-19 05:43:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:43:48 --> Upload Class Initialized
INFO - 2016-02-19 08:43:48 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-19 08:43:48 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-19 08:43:48 --> Final output sent to browser
DEBUG - 2016-02-19 08:43:48 --> Total execution time: 1.2868
INFO - 2016-02-19 05:44:28 --> Config Class Initialized
INFO - 2016-02-19 05:44:28 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:44:28 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:44:28 --> Utf8 Class Initialized
INFO - 2016-02-19 05:44:28 --> URI Class Initialized
INFO - 2016-02-19 05:44:28 --> Router Class Initialized
INFO - 2016-02-19 05:44:28 --> Output Class Initialized
INFO - 2016-02-19 05:44:28 --> Security Class Initialized
DEBUG - 2016-02-19 05:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:44:28 --> Input Class Initialized
INFO - 2016-02-19 05:44:28 --> Language Class Initialized
INFO - 2016-02-19 05:44:28 --> Loader Class Initialized
INFO - 2016-02-19 05:44:28 --> Helper loaded: url_helper
INFO - 2016-02-19 05:44:28 --> Helper loaded: file_helper
INFO - 2016-02-19 05:44:28 --> Helper loaded: date_helper
INFO - 2016-02-19 05:44:28 --> Helper loaded: form_helper
INFO - 2016-02-19 05:44:28 --> Database Driver Class Initialized
INFO - 2016-02-19 05:44:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:44:29 --> Controller Class Initialized
INFO - 2016-02-19 05:44:29 --> Model Class Initialized
INFO - 2016-02-19 05:44:29 --> Model Class Initialized
INFO - 2016-02-19 05:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:44:29 --> Pagination Class Initialized
INFO - 2016-02-19 05:44:29 --> Helper loaded: text_helper
INFO - 2016-02-19 05:44:29 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:44:29 --> Upload Class Initialized
INFO - 2016-02-19 08:44:29 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-19 08:44:29 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-19 08:44:29 --> Final output sent to browser
DEBUG - 2016-02-19 08:44:29 --> Total execution time: 1.1517
INFO - 2016-02-19 05:48:41 --> Config Class Initialized
INFO - 2016-02-19 05:48:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:48:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:48:41 --> Utf8 Class Initialized
INFO - 2016-02-19 05:48:41 --> URI Class Initialized
INFO - 2016-02-19 05:48:41 --> Router Class Initialized
INFO - 2016-02-19 05:48:41 --> Output Class Initialized
INFO - 2016-02-19 05:48:41 --> Security Class Initialized
DEBUG - 2016-02-19 05:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:48:41 --> Input Class Initialized
INFO - 2016-02-19 05:48:41 --> Language Class Initialized
INFO - 2016-02-19 05:48:41 --> Loader Class Initialized
INFO - 2016-02-19 05:48:41 --> Helper loaded: url_helper
INFO - 2016-02-19 05:48:41 --> Helper loaded: file_helper
INFO - 2016-02-19 05:48:41 --> Helper loaded: date_helper
INFO - 2016-02-19 05:48:41 --> Helper loaded: form_helper
INFO - 2016-02-19 05:48:41 --> Database Driver Class Initialized
INFO - 2016-02-19 05:48:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:48:42 --> Controller Class Initialized
INFO - 2016-02-19 05:48:42 --> Model Class Initialized
INFO - 2016-02-19 05:48:42 --> Model Class Initialized
INFO - 2016-02-19 05:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:48:42 --> Pagination Class Initialized
INFO - 2016-02-19 05:48:42 --> Helper loaded: text_helper
INFO - 2016-02-19 05:48:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:48:42 --> Upload Class Initialized
INFO - 2016-02-19 08:48:42 --> Final output sent to browser
DEBUG - 2016-02-19 08:48:42 --> Total execution time: 1.1755
INFO - 2016-02-19 05:48:57 --> Config Class Initialized
INFO - 2016-02-19 05:48:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:48:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:48:57 --> Utf8 Class Initialized
INFO - 2016-02-19 05:48:57 --> URI Class Initialized
INFO - 2016-02-19 05:48:57 --> Router Class Initialized
INFO - 2016-02-19 05:48:57 --> Output Class Initialized
INFO - 2016-02-19 05:48:57 --> Security Class Initialized
DEBUG - 2016-02-19 05:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:48:57 --> Input Class Initialized
INFO - 2016-02-19 05:48:57 --> Language Class Initialized
INFO - 2016-02-19 05:48:57 --> Loader Class Initialized
INFO - 2016-02-19 05:48:57 --> Helper loaded: url_helper
INFO - 2016-02-19 05:48:57 --> Helper loaded: file_helper
INFO - 2016-02-19 05:48:57 --> Helper loaded: date_helper
INFO - 2016-02-19 05:48:57 --> Helper loaded: form_helper
INFO - 2016-02-19 05:48:57 --> Database Driver Class Initialized
INFO - 2016-02-19 05:48:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:48:58 --> Controller Class Initialized
INFO - 2016-02-19 05:48:58 --> Model Class Initialized
INFO - 2016-02-19 05:48:58 --> Model Class Initialized
INFO - 2016-02-19 05:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:48:58 --> Pagination Class Initialized
INFO - 2016-02-19 05:48:58 --> Helper loaded: text_helper
INFO - 2016-02-19 05:48:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:48:58 --> Form Validation Class Initialized
INFO - 2016-02-19 08:48:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-19 05:48:58 --> Config Class Initialized
INFO - 2016-02-19 05:48:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:48:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:48:58 --> Utf8 Class Initialized
INFO - 2016-02-19 05:48:58 --> URI Class Initialized
INFO - 2016-02-19 05:48:58 --> Router Class Initialized
INFO - 2016-02-19 05:48:58 --> Output Class Initialized
INFO - 2016-02-19 05:48:58 --> Security Class Initialized
DEBUG - 2016-02-19 05:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:48:58 --> Input Class Initialized
INFO - 2016-02-19 05:48:58 --> Language Class Initialized
INFO - 2016-02-19 05:48:58 --> Loader Class Initialized
INFO - 2016-02-19 05:48:58 --> Helper loaded: url_helper
INFO - 2016-02-19 05:48:58 --> Helper loaded: file_helper
INFO - 2016-02-19 05:48:58 --> Helper loaded: date_helper
INFO - 2016-02-19 05:48:58 --> Helper loaded: form_helper
INFO - 2016-02-19 05:48:58 --> Database Driver Class Initialized
INFO - 2016-02-19 05:48:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:48:59 --> Controller Class Initialized
INFO - 2016-02-19 05:48:59 --> Model Class Initialized
INFO - 2016-02-19 05:48:59 --> Model Class Initialized
INFO - 2016-02-19 05:48:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:48:59 --> Pagination Class Initialized
INFO - 2016-02-19 05:48:59 --> Helper loaded: text_helper
INFO - 2016-02-19 05:48:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:48:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:48:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:48:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:48:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:48:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:48:59 --> Final output sent to browser
DEBUG - 2016-02-19 08:48:59 --> Total execution time: 1.1771
INFO - 2016-02-19 05:49:10 --> Config Class Initialized
INFO - 2016-02-19 05:49:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:49:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:49:10 --> Utf8 Class Initialized
INFO - 2016-02-19 05:49:10 --> URI Class Initialized
INFO - 2016-02-19 05:49:10 --> Router Class Initialized
INFO - 2016-02-19 05:49:10 --> Output Class Initialized
INFO - 2016-02-19 05:49:10 --> Security Class Initialized
DEBUG - 2016-02-19 05:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:49:10 --> Input Class Initialized
INFO - 2016-02-19 05:49:10 --> Language Class Initialized
INFO - 2016-02-19 05:49:10 --> Loader Class Initialized
INFO - 2016-02-19 05:49:10 --> Helper loaded: url_helper
INFO - 2016-02-19 05:49:10 --> Helper loaded: file_helper
INFO - 2016-02-19 05:49:10 --> Helper loaded: date_helper
INFO - 2016-02-19 05:49:10 --> Helper loaded: form_helper
INFO - 2016-02-19 05:49:10 --> Database Driver Class Initialized
INFO - 2016-02-19 05:49:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:49:11 --> Controller Class Initialized
INFO - 2016-02-19 05:49:11 --> Model Class Initialized
INFO - 2016-02-19 05:49:11 --> Model Class Initialized
INFO - 2016-02-19 05:49:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:49:11 --> Pagination Class Initialized
INFO - 2016-02-19 05:49:11 --> Helper loaded: text_helper
INFO - 2016-02-19 05:49:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:49:11 --> Final output sent to browser
DEBUG - 2016-02-19 08:49:11 --> Total execution time: 1.2001
INFO - 2016-02-19 05:49:15 --> Config Class Initialized
INFO - 2016-02-19 05:49:15 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:49:15 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:49:15 --> Utf8 Class Initialized
INFO - 2016-02-19 05:49:15 --> URI Class Initialized
INFO - 2016-02-19 05:49:15 --> Router Class Initialized
INFO - 2016-02-19 05:49:15 --> Output Class Initialized
INFO - 2016-02-19 05:49:15 --> Security Class Initialized
DEBUG - 2016-02-19 05:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:49:15 --> Input Class Initialized
INFO - 2016-02-19 05:49:15 --> Language Class Initialized
INFO - 2016-02-19 05:49:15 --> Loader Class Initialized
INFO - 2016-02-19 05:49:15 --> Helper loaded: url_helper
INFO - 2016-02-19 05:49:15 --> Helper loaded: file_helper
INFO - 2016-02-19 05:49:15 --> Helper loaded: date_helper
INFO - 2016-02-19 05:49:15 --> Helper loaded: form_helper
INFO - 2016-02-19 05:49:15 --> Database Driver Class Initialized
INFO - 2016-02-19 05:49:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:49:16 --> Controller Class Initialized
INFO - 2016-02-19 05:49:16 --> Model Class Initialized
INFO - 2016-02-19 05:49:16 --> Model Class Initialized
INFO - 2016-02-19 05:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:49:16 --> Pagination Class Initialized
INFO - 2016-02-19 05:49:16 --> Helper loaded: text_helper
INFO - 2016-02-19 05:49:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 05:49:19 --> Config Class Initialized
INFO - 2016-02-19 05:49:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:49:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:49:19 --> Utf8 Class Initialized
INFO - 2016-02-19 05:49:19 --> URI Class Initialized
INFO - 2016-02-19 05:49:19 --> Router Class Initialized
INFO - 2016-02-19 05:49:19 --> Output Class Initialized
INFO - 2016-02-19 05:49:19 --> Security Class Initialized
DEBUG - 2016-02-19 05:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:49:19 --> Input Class Initialized
INFO - 2016-02-19 05:49:19 --> Language Class Initialized
INFO - 2016-02-19 05:49:19 --> Loader Class Initialized
INFO - 2016-02-19 05:49:19 --> Helper loaded: url_helper
INFO - 2016-02-19 05:49:19 --> Helper loaded: file_helper
INFO - 2016-02-19 05:49:19 --> Helper loaded: date_helper
INFO - 2016-02-19 05:49:19 --> Helper loaded: form_helper
INFO - 2016-02-19 05:49:19 --> Database Driver Class Initialized
INFO - 2016-02-19 05:49:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:49:20 --> Controller Class Initialized
INFO - 2016-02-19 05:49:20 --> Model Class Initialized
INFO - 2016-02-19 05:49:20 --> Model Class Initialized
INFO - 2016-02-19 05:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:49:20 --> Pagination Class Initialized
INFO - 2016-02-19 05:49:20 --> Helper loaded: text_helper
INFO - 2016-02-19 05:49:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 05:49:54 --> Config Class Initialized
INFO - 2016-02-19 05:49:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:49:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:49:54 --> Utf8 Class Initialized
INFO - 2016-02-19 05:49:54 --> URI Class Initialized
DEBUG - 2016-02-19 05:49:54 --> No URI present. Default controller set.
INFO - 2016-02-19 05:49:54 --> Router Class Initialized
INFO - 2016-02-19 05:49:54 --> Output Class Initialized
INFO - 2016-02-19 05:49:54 --> Security Class Initialized
DEBUG - 2016-02-19 05:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:49:54 --> Input Class Initialized
INFO - 2016-02-19 05:49:54 --> Language Class Initialized
INFO - 2016-02-19 05:49:54 --> Loader Class Initialized
INFO - 2016-02-19 05:49:54 --> Helper loaded: url_helper
INFO - 2016-02-19 05:49:54 --> Helper loaded: file_helper
INFO - 2016-02-19 05:49:54 --> Helper loaded: date_helper
INFO - 2016-02-19 05:49:54 --> Helper loaded: form_helper
INFO - 2016-02-19 05:49:54 --> Database Driver Class Initialized
INFO - 2016-02-19 05:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:49:55 --> Controller Class Initialized
INFO - 2016-02-19 05:49:55 --> Model Class Initialized
INFO - 2016-02-19 05:49:55 --> Model Class Initialized
INFO - 2016-02-19 05:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:49:55 --> Pagination Class Initialized
INFO - 2016-02-19 05:49:55 --> Helper loaded: text_helper
INFO - 2016-02-19 05:49:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:49:55 --> Final output sent to browser
DEBUG - 2016-02-19 08:49:55 --> Total execution time: 1.1749
INFO - 2016-02-19 05:50:02 --> Config Class Initialized
INFO - 2016-02-19 05:50:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:02 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:02 --> URI Class Initialized
INFO - 2016-02-19 05:50:02 --> Router Class Initialized
INFO - 2016-02-19 05:50:02 --> Output Class Initialized
INFO - 2016-02-19 05:50:02 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:02 --> Input Class Initialized
INFO - 2016-02-19 05:50:02 --> Language Class Initialized
INFO - 2016-02-19 05:50:02 --> Loader Class Initialized
INFO - 2016-02-19 05:50:02 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:02 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:02 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:02 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:02 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:03 --> Controller Class Initialized
INFO - 2016-02-19 05:50:03 --> Model Class Initialized
INFO - 2016-02-19 05:50:03 --> Model Class Initialized
INFO - 2016-02-19 05:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:03 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:04 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:04 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:50:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:50:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:50:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:50:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:50:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:50:04 --> Final output sent to browser
DEBUG - 2016-02-19 08:50:04 --> Total execution time: 1.2415
INFO - 2016-02-19 05:50:07 --> Config Class Initialized
INFO - 2016-02-19 05:50:07 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:07 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:07 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:07 --> URI Class Initialized
INFO - 2016-02-19 05:50:07 --> Router Class Initialized
INFO - 2016-02-19 05:50:07 --> Output Class Initialized
INFO - 2016-02-19 05:50:07 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:07 --> Input Class Initialized
INFO - 2016-02-19 05:50:07 --> Language Class Initialized
INFO - 2016-02-19 05:50:07 --> Loader Class Initialized
INFO - 2016-02-19 05:50:07 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:07 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:07 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:07 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:07 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:08 --> Controller Class Initialized
INFO - 2016-02-19 05:50:08 --> Model Class Initialized
INFO - 2016-02-19 05:50:08 --> Model Class Initialized
INFO - 2016-02-19 05:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:08 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:08 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 05:50:12 --> Config Class Initialized
INFO - 2016-02-19 05:50:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:12 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:12 --> URI Class Initialized
INFO - 2016-02-19 05:50:12 --> Router Class Initialized
INFO - 2016-02-19 05:50:12 --> Output Class Initialized
INFO - 2016-02-19 05:50:12 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:13 --> Input Class Initialized
INFO - 2016-02-19 05:50:13 --> Language Class Initialized
INFO - 2016-02-19 05:50:13 --> Loader Class Initialized
INFO - 2016-02-19 05:50:13 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:13 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:13 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:13 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:13 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:14 --> Controller Class Initialized
INFO - 2016-02-19 05:50:14 --> Model Class Initialized
INFO - 2016-02-19 05:50:14 --> Model Class Initialized
INFO - 2016-02-19 05:50:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:14 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:14 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:50:14 --> Final output sent to browser
DEBUG - 2016-02-19 08:50:14 --> Total execution time: 1.1874
INFO - 2016-02-19 05:50:35 --> Config Class Initialized
INFO - 2016-02-19 05:50:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:35 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:35 --> URI Class Initialized
INFO - 2016-02-19 05:50:35 --> Router Class Initialized
INFO - 2016-02-19 05:50:35 --> Output Class Initialized
INFO - 2016-02-19 05:50:35 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:35 --> Input Class Initialized
INFO - 2016-02-19 05:50:35 --> Language Class Initialized
INFO - 2016-02-19 05:50:35 --> Loader Class Initialized
INFO - 2016-02-19 05:50:35 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:35 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:35 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:35 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:35 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:36 --> Controller Class Initialized
INFO - 2016-02-19 05:50:36 --> Model Class Initialized
INFO - 2016-02-19 05:50:36 --> Model Class Initialized
INFO - 2016-02-19 05:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:36 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:36 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:50:36 --> Final output sent to browser
DEBUG - 2016-02-19 08:50:36 --> Total execution time: 1.1638
INFO - 2016-02-19 05:50:41 --> Config Class Initialized
INFO - 2016-02-19 05:50:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:41 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:41 --> URI Class Initialized
INFO - 2016-02-19 05:50:41 --> Router Class Initialized
INFO - 2016-02-19 05:50:41 --> Output Class Initialized
INFO - 2016-02-19 05:50:41 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:41 --> Input Class Initialized
INFO - 2016-02-19 05:50:41 --> Language Class Initialized
INFO - 2016-02-19 05:50:41 --> Loader Class Initialized
INFO - 2016-02-19 05:50:41 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:41 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:41 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:41 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:41 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:42 --> Controller Class Initialized
INFO - 2016-02-19 05:50:42 --> Model Class Initialized
INFO - 2016-02-19 05:50:42 --> Model Class Initialized
INFO - 2016-02-19 05:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:42 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:42 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 05:50:47 --> Config Class Initialized
INFO - 2016-02-19 05:50:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:50:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:50:47 --> Utf8 Class Initialized
INFO - 2016-02-19 05:50:47 --> URI Class Initialized
DEBUG - 2016-02-19 05:50:47 --> No URI present. Default controller set.
INFO - 2016-02-19 05:50:47 --> Router Class Initialized
INFO - 2016-02-19 05:50:47 --> Output Class Initialized
INFO - 2016-02-19 05:50:47 --> Security Class Initialized
DEBUG - 2016-02-19 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:50:47 --> Input Class Initialized
INFO - 2016-02-19 05:50:47 --> Language Class Initialized
INFO - 2016-02-19 05:50:47 --> Loader Class Initialized
INFO - 2016-02-19 05:50:47 --> Helper loaded: url_helper
INFO - 2016-02-19 05:50:47 --> Helper loaded: file_helper
INFO - 2016-02-19 05:50:47 --> Helper loaded: date_helper
INFO - 2016-02-19 05:50:47 --> Helper loaded: form_helper
INFO - 2016-02-19 05:50:47 --> Database Driver Class Initialized
INFO - 2016-02-19 05:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:50:48 --> Controller Class Initialized
INFO - 2016-02-19 05:50:48 --> Model Class Initialized
INFO - 2016-02-19 05:50:48 --> Model Class Initialized
INFO - 2016-02-19 05:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:50:48 --> Pagination Class Initialized
INFO - 2016-02-19 05:50:48 --> Helper loaded: text_helper
INFO - 2016-02-19 05:50:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:50:48 --> Final output sent to browser
DEBUG - 2016-02-19 08:50:48 --> Total execution time: 1.1492
INFO - 2016-02-19 05:57:35 --> Config Class Initialized
INFO - 2016-02-19 05:57:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:57:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:57:35 --> Utf8 Class Initialized
INFO - 2016-02-19 05:57:35 --> URI Class Initialized
INFO - 2016-02-19 05:57:35 --> Router Class Initialized
INFO - 2016-02-19 05:57:35 --> Output Class Initialized
INFO - 2016-02-19 05:57:35 --> Security Class Initialized
DEBUG - 2016-02-19 05:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:57:35 --> Input Class Initialized
INFO - 2016-02-19 05:57:35 --> Language Class Initialized
INFO - 2016-02-19 05:57:35 --> Loader Class Initialized
INFO - 2016-02-19 05:57:35 --> Helper loaded: url_helper
INFO - 2016-02-19 05:57:35 --> Helper loaded: file_helper
INFO - 2016-02-19 05:57:35 --> Helper loaded: date_helper
INFO - 2016-02-19 05:57:35 --> Helper loaded: form_helper
INFO - 2016-02-19 05:57:35 --> Database Driver Class Initialized
INFO - 2016-02-19 05:57:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:57:36 --> Controller Class Initialized
INFO - 2016-02-19 05:57:36 --> Model Class Initialized
INFO - 2016-02-19 05:57:36 --> Model Class Initialized
INFO - 2016-02-19 05:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:57:36 --> Pagination Class Initialized
INFO - 2016-02-19 05:57:36 --> Helper loaded: text_helper
INFO - 2016-02-19 05:57:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:57:36 --> Final output sent to browser
DEBUG - 2016-02-19 08:57:36 --> Total execution time: 1.2212
INFO - 2016-02-19 05:57:39 --> Config Class Initialized
INFO - 2016-02-19 05:57:39 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:57:39 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:57:39 --> Utf8 Class Initialized
INFO - 2016-02-19 05:57:39 --> URI Class Initialized
INFO - 2016-02-19 05:57:39 --> Router Class Initialized
INFO - 2016-02-19 05:57:39 --> Output Class Initialized
INFO - 2016-02-19 05:57:39 --> Security Class Initialized
DEBUG - 2016-02-19 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:57:39 --> Input Class Initialized
INFO - 2016-02-19 05:57:39 --> Language Class Initialized
INFO - 2016-02-19 05:57:39 --> Loader Class Initialized
INFO - 2016-02-19 05:57:39 --> Helper loaded: url_helper
INFO - 2016-02-19 05:57:39 --> Helper loaded: file_helper
INFO - 2016-02-19 05:57:39 --> Helper loaded: date_helper
INFO - 2016-02-19 05:57:39 --> Helper loaded: form_helper
INFO - 2016-02-19 05:57:39 --> Database Driver Class Initialized
INFO - 2016-02-19 05:57:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:57:40 --> Controller Class Initialized
INFO - 2016-02-19 05:57:40 --> Model Class Initialized
INFO - 2016-02-19 05:57:40 --> Model Class Initialized
INFO - 2016-02-19 05:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:57:40 --> Pagination Class Initialized
INFO - 2016-02-19 05:57:40 --> Helper loaded: text_helper
INFO - 2016-02-19 05:57:40 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:57:41 --> Final output sent to browser
DEBUG - 2016-02-19 08:57:41 --> Total execution time: 1.3195
INFO - 2016-02-19 05:57:45 --> Config Class Initialized
INFO - 2016-02-19 05:57:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:57:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:57:45 --> Utf8 Class Initialized
INFO - 2016-02-19 05:57:45 --> URI Class Initialized
INFO - 2016-02-19 05:57:45 --> Router Class Initialized
INFO - 2016-02-19 05:57:45 --> Output Class Initialized
INFO - 2016-02-19 05:57:45 --> Security Class Initialized
DEBUG - 2016-02-19 05:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:57:45 --> Input Class Initialized
INFO - 2016-02-19 05:57:45 --> Language Class Initialized
INFO - 2016-02-19 05:57:45 --> Loader Class Initialized
INFO - 2016-02-19 05:57:45 --> Helper loaded: url_helper
INFO - 2016-02-19 05:57:45 --> Helper loaded: file_helper
INFO - 2016-02-19 05:57:45 --> Helper loaded: date_helper
INFO - 2016-02-19 05:57:45 --> Helper loaded: form_helper
INFO - 2016-02-19 05:57:45 --> Database Driver Class Initialized
INFO - 2016-02-19 05:57:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:57:47 --> Controller Class Initialized
INFO - 2016-02-19 05:57:47 --> Model Class Initialized
INFO - 2016-02-19 05:57:47 --> Model Class Initialized
INFO - 2016-02-19 05:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:57:47 --> Pagination Class Initialized
INFO - 2016-02-19 05:57:47 --> Helper loaded: text_helper
INFO - 2016-02-19 05:57:47 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:57:47 --> Final output sent to browser
DEBUG - 2016-02-19 08:57:47 --> Total execution time: 1.1349
INFO - 2016-02-19 05:57:48 --> Config Class Initialized
INFO - 2016-02-19 05:57:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:57:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:57:48 --> Utf8 Class Initialized
INFO - 2016-02-19 05:57:48 --> URI Class Initialized
INFO - 2016-02-19 05:57:48 --> Router Class Initialized
INFO - 2016-02-19 05:57:48 --> Output Class Initialized
INFO - 2016-02-19 05:57:48 --> Security Class Initialized
DEBUG - 2016-02-19 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:57:48 --> Input Class Initialized
INFO - 2016-02-19 05:57:48 --> Language Class Initialized
INFO - 2016-02-19 05:57:48 --> Loader Class Initialized
INFO - 2016-02-19 05:57:48 --> Helper loaded: url_helper
INFO - 2016-02-19 05:57:48 --> Helper loaded: file_helper
INFO - 2016-02-19 05:57:48 --> Helper loaded: date_helper
INFO - 2016-02-19 05:57:48 --> Helper loaded: form_helper
INFO - 2016-02-19 05:57:48 --> Database Driver Class Initialized
INFO - 2016-02-19 05:57:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:57:49 --> Controller Class Initialized
INFO - 2016-02-19 05:57:49 --> Model Class Initialized
INFO - 2016-02-19 05:57:49 --> Model Class Initialized
INFO - 2016-02-19 05:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:57:49 --> Pagination Class Initialized
INFO - 2016-02-19 05:57:49 --> Helper loaded: text_helper
INFO - 2016-02-19 05:57:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:57:49 --> Final output sent to browser
DEBUG - 2016-02-19 08:57:49 --> Total execution time: 1.1856
INFO - 2016-02-19 05:57:54 --> Config Class Initialized
INFO - 2016-02-19 05:57:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:57:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:57:54 --> Utf8 Class Initialized
INFO - 2016-02-19 05:57:54 --> URI Class Initialized
INFO - 2016-02-19 05:57:54 --> Router Class Initialized
INFO - 2016-02-19 05:57:54 --> Output Class Initialized
INFO - 2016-02-19 05:57:54 --> Security Class Initialized
DEBUG - 2016-02-19 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:57:54 --> Input Class Initialized
INFO - 2016-02-19 05:57:54 --> Language Class Initialized
INFO - 2016-02-19 05:57:54 --> Loader Class Initialized
INFO - 2016-02-19 05:57:54 --> Helper loaded: url_helper
INFO - 2016-02-19 05:57:54 --> Helper loaded: file_helper
INFO - 2016-02-19 05:57:54 --> Helper loaded: date_helper
INFO - 2016-02-19 05:57:54 --> Helper loaded: form_helper
INFO - 2016-02-19 05:57:54 --> Database Driver Class Initialized
INFO - 2016-02-19 05:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:57:55 --> Controller Class Initialized
INFO - 2016-02-19 05:57:55 --> Model Class Initialized
INFO - 2016-02-19 05:57:55 --> Model Class Initialized
INFO - 2016-02-19 05:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:57:55 --> Pagination Class Initialized
INFO - 2016-02-19 05:57:55 --> Helper loaded: text_helper
INFO - 2016-02-19 05:57:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:57:55 --> Final output sent to browser
DEBUG - 2016-02-19 08:57:55 --> Total execution time: 1.1788
INFO - 2016-02-19 05:58:48 --> Config Class Initialized
INFO - 2016-02-19 05:58:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:58:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:58:48 --> Utf8 Class Initialized
INFO - 2016-02-19 05:58:48 --> URI Class Initialized
INFO - 2016-02-19 05:58:48 --> Router Class Initialized
INFO - 2016-02-19 05:58:48 --> Output Class Initialized
INFO - 2016-02-19 05:58:48 --> Security Class Initialized
DEBUG - 2016-02-19 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:58:48 --> Input Class Initialized
INFO - 2016-02-19 05:58:48 --> Language Class Initialized
INFO - 2016-02-19 05:58:48 --> Loader Class Initialized
INFO - 2016-02-19 05:58:48 --> Helper loaded: url_helper
INFO - 2016-02-19 05:58:48 --> Helper loaded: file_helper
INFO - 2016-02-19 05:58:48 --> Helper loaded: date_helper
INFO - 2016-02-19 05:58:48 --> Helper loaded: form_helper
INFO - 2016-02-19 05:58:48 --> Database Driver Class Initialized
INFO - 2016-02-19 05:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:58:49 --> Controller Class Initialized
INFO - 2016-02-19 05:58:49 --> Model Class Initialized
INFO - 2016-02-19 05:58:49 --> Model Class Initialized
INFO - 2016-02-19 05:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:58:49 --> Pagination Class Initialized
INFO - 2016-02-19 05:58:49 --> Helper loaded: text_helper
INFO - 2016-02-19 05:58:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:58:49 --> Final output sent to browser
DEBUG - 2016-02-19 08:58:49 --> Total execution time: 1.1627
INFO - 2016-02-19 05:58:51 --> Config Class Initialized
INFO - 2016-02-19 05:58:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:58:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:58:51 --> Utf8 Class Initialized
INFO - 2016-02-19 05:58:51 --> URI Class Initialized
INFO - 2016-02-19 05:58:51 --> Router Class Initialized
INFO - 2016-02-19 05:58:51 --> Output Class Initialized
INFO - 2016-02-19 05:58:51 --> Security Class Initialized
DEBUG - 2016-02-19 05:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:58:51 --> Input Class Initialized
INFO - 2016-02-19 05:58:51 --> Language Class Initialized
INFO - 2016-02-19 05:58:51 --> Loader Class Initialized
INFO - 2016-02-19 05:58:51 --> Helper loaded: url_helper
INFO - 2016-02-19 05:58:51 --> Helper loaded: file_helper
INFO - 2016-02-19 05:58:51 --> Helper loaded: date_helper
INFO - 2016-02-19 05:58:51 --> Helper loaded: form_helper
INFO - 2016-02-19 05:58:51 --> Database Driver Class Initialized
INFO - 2016-02-19 05:58:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:58:52 --> Controller Class Initialized
INFO - 2016-02-19 05:58:52 --> Model Class Initialized
INFO - 2016-02-19 05:58:52 --> Model Class Initialized
INFO - 2016-02-19 05:58:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:58:52 --> Pagination Class Initialized
INFO - 2016-02-19 05:58:52 --> Helper loaded: text_helper
INFO - 2016-02-19 05:58:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:58:52 --> Final output sent to browser
DEBUG - 2016-02-19 08:58:52 --> Total execution time: 1.1667
INFO - 2016-02-19 05:58:57 --> Config Class Initialized
INFO - 2016-02-19 05:58:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:58:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:58:57 --> Utf8 Class Initialized
INFO - 2016-02-19 05:58:57 --> URI Class Initialized
INFO - 2016-02-19 05:58:57 --> Router Class Initialized
INFO - 2016-02-19 05:58:57 --> Output Class Initialized
INFO - 2016-02-19 05:58:57 --> Security Class Initialized
DEBUG - 2016-02-19 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:58:57 --> Input Class Initialized
INFO - 2016-02-19 05:58:57 --> Language Class Initialized
INFO - 2016-02-19 05:58:57 --> Loader Class Initialized
INFO - 2016-02-19 05:58:57 --> Helper loaded: url_helper
INFO - 2016-02-19 05:58:57 --> Helper loaded: file_helper
INFO - 2016-02-19 05:58:57 --> Helper loaded: date_helper
INFO - 2016-02-19 05:58:57 --> Helper loaded: form_helper
INFO - 2016-02-19 05:58:57 --> Database Driver Class Initialized
INFO - 2016-02-19 05:58:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:58:58 --> Controller Class Initialized
INFO - 2016-02-19 05:58:58 --> Model Class Initialized
INFO - 2016-02-19 05:58:58 --> Model Class Initialized
INFO - 2016-02-19 05:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:58:58 --> Pagination Class Initialized
INFO - 2016-02-19 05:58:58 --> Helper loaded: text_helper
INFO - 2016-02-19 05:58:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 05:59:09 --> Config Class Initialized
INFO - 2016-02-19 05:59:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:59:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:59:09 --> Utf8 Class Initialized
INFO - 2016-02-19 05:59:09 --> URI Class Initialized
DEBUG - 2016-02-19 05:59:09 --> No URI present. Default controller set.
INFO - 2016-02-19 05:59:09 --> Router Class Initialized
INFO - 2016-02-19 05:59:09 --> Output Class Initialized
INFO - 2016-02-19 05:59:09 --> Security Class Initialized
DEBUG - 2016-02-19 05:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:59:09 --> Input Class Initialized
INFO - 2016-02-19 05:59:09 --> Language Class Initialized
INFO - 2016-02-19 05:59:09 --> Loader Class Initialized
INFO - 2016-02-19 05:59:09 --> Helper loaded: url_helper
INFO - 2016-02-19 05:59:09 --> Helper loaded: file_helper
INFO - 2016-02-19 05:59:09 --> Helper loaded: date_helper
INFO - 2016-02-19 05:59:10 --> Helper loaded: form_helper
INFO - 2016-02-19 05:59:10 --> Database Driver Class Initialized
INFO - 2016-02-19 05:59:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:59:11 --> Controller Class Initialized
INFO - 2016-02-19 05:59:11 --> Model Class Initialized
INFO - 2016-02-19 05:59:11 --> Model Class Initialized
INFO - 2016-02-19 05:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:59:11 --> Pagination Class Initialized
INFO - 2016-02-19 05:59:11 --> Helper loaded: text_helper
INFO - 2016-02-19 05:59:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 08:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:59:11 --> Final output sent to browser
DEBUG - 2016-02-19 08:59:11 --> Total execution time: 1.1443
INFO - 2016-02-19 05:59:13 --> Config Class Initialized
INFO - 2016-02-19 05:59:13 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:59:13 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:59:13 --> Utf8 Class Initialized
INFO - 2016-02-19 05:59:13 --> URI Class Initialized
INFO - 2016-02-19 05:59:13 --> Router Class Initialized
INFO - 2016-02-19 05:59:13 --> Output Class Initialized
INFO - 2016-02-19 05:59:13 --> Security Class Initialized
DEBUG - 2016-02-19 05:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:59:13 --> Input Class Initialized
INFO - 2016-02-19 05:59:13 --> Language Class Initialized
INFO - 2016-02-19 05:59:13 --> Loader Class Initialized
INFO - 2016-02-19 05:59:13 --> Helper loaded: url_helper
INFO - 2016-02-19 05:59:13 --> Helper loaded: file_helper
INFO - 2016-02-19 05:59:13 --> Helper loaded: date_helper
INFO - 2016-02-19 05:59:13 --> Helper loaded: form_helper
INFO - 2016-02-19 05:59:13 --> Database Driver Class Initialized
INFO - 2016-02-19 05:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:59:14 --> Controller Class Initialized
INFO - 2016-02-19 05:59:14 --> Model Class Initialized
INFO - 2016-02-19 05:59:14 --> Model Class Initialized
INFO - 2016-02-19 05:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:59:14 --> Pagination Class Initialized
INFO - 2016-02-19 05:59:14 --> Helper loaded: text_helper
INFO - 2016-02-19 05:59:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 08:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 08:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 08:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 08:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 08:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 08:59:14 --> Final output sent to browser
DEBUG - 2016-02-19 08:59:14 --> Total execution time: 1.2327
INFO - 2016-02-19 05:59:18 --> Config Class Initialized
INFO - 2016-02-19 05:59:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 05:59:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 05:59:18 --> Utf8 Class Initialized
INFO - 2016-02-19 05:59:18 --> URI Class Initialized
INFO - 2016-02-19 05:59:19 --> Router Class Initialized
INFO - 2016-02-19 05:59:19 --> Output Class Initialized
INFO - 2016-02-19 05:59:19 --> Security Class Initialized
DEBUG - 2016-02-19 05:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 05:59:19 --> Input Class Initialized
INFO - 2016-02-19 05:59:19 --> Language Class Initialized
INFO - 2016-02-19 05:59:19 --> Loader Class Initialized
INFO - 2016-02-19 05:59:19 --> Helper loaded: url_helper
INFO - 2016-02-19 05:59:19 --> Helper loaded: file_helper
INFO - 2016-02-19 05:59:19 --> Helper loaded: date_helper
INFO - 2016-02-19 05:59:19 --> Helper loaded: form_helper
INFO - 2016-02-19 05:59:19 --> Database Driver Class Initialized
INFO - 2016-02-19 05:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 05:59:20 --> Controller Class Initialized
INFO - 2016-02-19 05:59:20 --> Model Class Initialized
INFO - 2016-02-19 05:59:20 --> Model Class Initialized
INFO - 2016-02-19 05:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 05:59:20 --> Pagination Class Initialized
INFO - 2016-02-19 05:59:20 --> Helper loaded: text_helper
INFO - 2016-02-19 05:59:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 06:00:05 --> Config Class Initialized
INFO - 2016-02-19 06:00:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:00:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:00:05 --> Utf8 Class Initialized
INFO - 2016-02-19 06:00:05 --> URI Class Initialized
INFO - 2016-02-19 06:00:05 --> Router Class Initialized
INFO - 2016-02-19 06:00:05 --> Output Class Initialized
INFO - 2016-02-19 06:00:05 --> Security Class Initialized
DEBUG - 2016-02-19 06:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:00:05 --> Input Class Initialized
INFO - 2016-02-19 06:00:05 --> Language Class Initialized
INFO - 2016-02-19 06:00:05 --> Loader Class Initialized
INFO - 2016-02-19 06:00:05 --> Helper loaded: url_helper
INFO - 2016-02-19 06:00:05 --> Helper loaded: file_helper
INFO - 2016-02-19 06:00:05 --> Helper loaded: date_helper
INFO - 2016-02-19 06:00:05 --> Helper loaded: form_helper
INFO - 2016-02-19 06:00:05 --> Database Driver Class Initialized
INFO - 2016-02-19 06:00:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:00:06 --> Controller Class Initialized
INFO - 2016-02-19 06:00:06 --> Model Class Initialized
INFO - 2016-02-19 06:00:06 --> Model Class Initialized
INFO - 2016-02-19 06:00:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:00:06 --> Pagination Class Initialized
INFO - 2016-02-19 06:00:06 --> Helper loaded: text_helper
INFO - 2016-02-19 06:00:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:00:06 --> Final output sent to browser
DEBUG - 2016-02-19 09:00:06 --> Total execution time: 1.1408
INFO - 2016-02-19 06:00:10 --> Config Class Initialized
INFO - 2016-02-19 06:00:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:00:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:00:10 --> Utf8 Class Initialized
INFO - 2016-02-19 06:00:10 --> URI Class Initialized
INFO - 2016-02-19 06:00:10 --> Router Class Initialized
INFO - 2016-02-19 06:00:10 --> Output Class Initialized
INFO - 2016-02-19 06:00:10 --> Security Class Initialized
DEBUG - 2016-02-19 06:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:00:10 --> Input Class Initialized
INFO - 2016-02-19 06:00:10 --> Language Class Initialized
INFO - 2016-02-19 06:00:10 --> Loader Class Initialized
INFO - 2016-02-19 06:00:10 --> Helper loaded: url_helper
INFO - 2016-02-19 06:00:10 --> Helper loaded: file_helper
INFO - 2016-02-19 06:00:10 --> Helper loaded: date_helper
INFO - 2016-02-19 06:00:10 --> Helper loaded: form_helper
INFO - 2016-02-19 06:00:10 --> Database Driver Class Initialized
INFO - 2016-02-19 06:00:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:00:11 --> Controller Class Initialized
INFO - 2016-02-19 06:00:11 --> Model Class Initialized
INFO - 2016-02-19 06:00:11 --> Model Class Initialized
INFO - 2016-02-19 06:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:00:11 --> Pagination Class Initialized
INFO - 2016-02-19 06:00:11 --> Helper loaded: text_helper
INFO - 2016-02-19 06:00:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:00:11 --> Final output sent to browser
DEBUG - 2016-02-19 09:00:11 --> Total execution time: 1.1557
INFO - 2016-02-19 06:02:59 --> Config Class Initialized
INFO - 2016-02-19 06:02:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:02:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:02:59 --> Utf8 Class Initialized
INFO - 2016-02-19 06:02:59 --> URI Class Initialized
INFO - 2016-02-19 06:02:59 --> Router Class Initialized
INFO - 2016-02-19 06:02:59 --> Output Class Initialized
INFO - 2016-02-19 06:02:59 --> Security Class Initialized
DEBUG - 2016-02-19 06:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:02:59 --> Input Class Initialized
INFO - 2016-02-19 06:02:59 --> Language Class Initialized
INFO - 2016-02-19 06:02:59 --> Loader Class Initialized
INFO - 2016-02-19 06:02:59 --> Helper loaded: url_helper
INFO - 2016-02-19 06:02:59 --> Helper loaded: file_helper
INFO - 2016-02-19 06:02:59 --> Helper loaded: date_helper
INFO - 2016-02-19 06:02:59 --> Helper loaded: form_helper
INFO - 2016-02-19 06:02:59 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:00 --> Controller Class Initialized
INFO - 2016-02-19 06:03:00 --> Model Class Initialized
INFO - 2016-02-19 06:03:00 --> Model Class Initialized
INFO - 2016-02-19 06:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:00 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:00 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:00 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:00 --> Total execution time: 1.1490
INFO - 2016-02-19 06:03:02 --> Config Class Initialized
INFO - 2016-02-19 06:03:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:02 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:02 --> URI Class Initialized
INFO - 2016-02-19 06:03:02 --> Router Class Initialized
INFO - 2016-02-19 06:03:02 --> Output Class Initialized
INFO - 2016-02-19 06:03:02 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:02 --> Input Class Initialized
INFO - 2016-02-19 06:03:02 --> Language Class Initialized
INFO - 2016-02-19 06:03:02 --> Loader Class Initialized
INFO - 2016-02-19 06:03:02 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:02 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:02 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:02 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:02 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:03 --> Controller Class Initialized
INFO - 2016-02-19 06:03:03 --> Model Class Initialized
INFO - 2016-02-19 06:03:03 --> Model Class Initialized
INFO - 2016-02-19 06:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:03 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:03 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:03 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:03 --> Total execution time: 1.1958
INFO - 2016-02-19 06:03:06 --> Config Class Initialized
INFO - 2016-02-19 06:03:06 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:06 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:06 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:06 --> URI Class Initialized
INFO - 2016-02-19 06:03:06 --> Router Class Initialized
INFO - 2016-02-19 06:03:06 --> Output Class Initialized
INFO - 2016-02-19 06:03:06 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:06 --> Input Class Initialized
INFO - 2016-02-19 06:03:06 --> Language Class Initialized
INFO - 2016-02-19 06:03:06 --> Loader Class Initialized
INFO - 2016-02-19 06:03:06 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:06 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:06 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:06 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:06 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:07 --> Controller Class Initialized
INFO - 2016-02-19 06:03:07 --> Model Class Initialized
INFO - 2016-02-19 06:03:07 --> Model Class Initialized
INFO - 2016-02-19 06:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:07 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:07 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:07 --> Helper loaded: cookie_helper
INFO - 2016-02-19 06:03:09 --> Config Class Initialized
INFO - 2016-02-19 06:03:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:09 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:09 --> URI Class Initialized
INFO - 2016-02-19 06:03:09 --> Router Class Initialized
INFO - 2016-02-19 06:03:09 --> Output Class Initialized
INFO - 2016-02-19 06:03:09 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:09 --> Input Class Initialized
INFO - 2016-02-19 06:03:09 --> Language Class Initialized
INFO - 2016-02-19 06:03:09 --> Loader Class Initialized
INFO - 2016-02-19 06:03:09 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:09 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:09 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:09 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:09 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:10 --> Controller Class Initialized
INFO - 2016-02-19 06:03:10 --> Model Class Initialized
INFO - 2016-02-19 06:03:10 --> Model Class Initialized
INFO - 2016-02-19 06:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:10 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:10 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:10 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:10 --> Total execution time: 1.2643
INFO - 2016-02-19 06:03:12 --> Config Class Initialized
INFO - 2016-02-19 06:03:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:12 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:12 --> URI Class Initialized
INFO - 2016-02-19 06:03:12 --> Router Class Initialized
INFO - 2016-02-19 06:03:12 --> Output Class Initialized
INFO - 2016-02-19 06:03:12 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:12 --> Input Class Initialized
INFO - 2016-02-19 06:03:12 --> Language Class Initialized
INFO - 2016-02-19 06:03:12 --> Loader Class Initialized
INFO - 2016-02-19 06:03:12 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:12 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:12 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:12 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:12 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:13 --> Controller Class Initialized
INFO - 2016-02-19 06:03:13 --> Model Class Initialized
INFO - 2016-02-19 06:03:13 --> Model Class Initialized
INFO - 2016-02-19 06:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:13 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:13 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:13 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:13 --> Total execution time: 1.2404
INFO - 2016-02-19 06:03:16 --> Config Class Initialized
INFO - 2016-02-19 06:03:16 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:16 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:16 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:16 --> URI Class Initialized
INFO - 2016-02-19 06:03:16 --> Router Class Initialized
INFO - 2016-02-19 06:03:16 --> Output Class Initialized
INFO - 2016-02-19 06:03:16 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:16 --> Input Class Initialized
INFO - 2016-02-19 06:03:16 --> Language Class Initialized
INFO - 2016-02-19 06:03:16 --> Loader Class Initialized
INFO - 2016-02-19 06:03:16 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:16 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:16 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:16 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:16 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:17 --> Controller Class Initialized
INFO - 2016-02-19 06:03:17 --> Model Class Initialized
INFO - 2016-02-19 06:03:17 --> Model Class Initialized
INFO - 2016-02-19 06:03:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:17 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:17 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:17 --> Helper loaded: cookie_helper
INFO - 2016-02-19 06:03:21 --> Config Class Initialized
INFO - 2016-02-19 06:03:21 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:21 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:21 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:21 --> URI Class Initialized
INFO - 2016-02-19 06:03:21 --> Router Class Initialized
INFO - 2016-02-19 06:03:21 --> Output Class Initialized
INFO - 2016-02-19 06:03:21 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:21 --> Input Class Initialized
INFO - 2016-02-19 06:03:21 --> Language Class Initialized
INFO - 2016-02-19 06:03:21 --> Loader Class Initialized
INFO - 2016-02-19 06:03:21 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:21 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:21 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:21 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:21 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:22 --> Controller Class Initialized
INFO - 2016-02-19 06:03:22 --> Model Class Initialized
INFO - 2016-02-19 06:03:22 --> Model Class Initialized
INFO - 2016-02-19 06:03:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:22 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:22 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:22 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:03:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:22 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:22 --> Total execution time: 1.1454
INFO - 2016-02-19 06:03:24 --> Config Class Initialized
INFO - 2016-02-19 06:03:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:03:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:03:24 --> Utf8 Class Initialized
INFO - 2016-02-19 06:03:24 --> URI Class Initialized
INFO - 2016-02-19 06:03:24 --> Router Class Initialized
INFO - 2016-02-19 06:03:24 --> Output Class Initialized
INFO - 2016-02-19 06:03:24 --> Security Class Initialized
DEBUG - 2016-02-19 06:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:03:24 --> Input Class Initialized
INFO - 2016-02-19 06:03:24 --> Language Class Initialized
INFO - 2016-02-19 06:03:24 --> Loader Class Initialized
INFO - 2016-02-19 06:03:24 --> Helper loaded: url_helper
INFO - 2016-02-19 06:03:24 --> Helper loaded: file_helper
INFO - 2016-02-19 06:03:24 --> Helper loaded: date_helper
INFO - 2016-02-19 06:03:24 --> Helper loaded: form_helper
INFO - 2016-02-19 06:03:24 --> Database Driver Class Initialized
INFO - 2016-02-19 06:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:03:25 --> Controller Class Initialized
INFO - 2016-02-19 06:03:25 --> Model Class Initialized
INFO - 2016-02-19 06:03:25 --> Model Class Initialized
INFO - 2016-02-19 06:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:03:25 --> Pagination Class Initialized
INFO - 2016-02-19 06:03:25 --> Helper loaded: text_helper
INFO - 2016-02-19 06:03:25 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:03:25 --> Final output sent to browser
DEBUG - 2016-02-19 09:03:25 --> Total execution time: 1.2198
INFO - 2016-02-19 06:20:57 --> Config Class Initialized
INFO - 2016-02-19 06:20:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:20:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:20:57 --> Utf8 Class Initialized
INFO - 2016-02-19 06:20:57 --> URI Class Initialized
INFO - 2016-02-19 06:20:57 --> Router Class Initialized
INFO - 2016-02-19 06:20:57 --> Output Class Initialized
INFO - 2016-02-19 06:20:57 --> Security Class Initialized
DEBUG - 2016-02-19 06:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:20:57 --> Input Class Initialized
INFO - 2016-02-19 06:20:57 --> Language Class Initialized
INFO - 2016-02-19 06:20:57 --> Loader Class Initialized
INFO - 2016-02-19 06:20:57 --> Helper loaded: url_helper
INFO - 2016-02-19 06:20:57 --> Helper loaded: file_helper
INFO - 2016-02-19 06:20:57 --> Helper loaded: date_helper
INFO - 2016-02-19 06:20:57 --> Helper loaded: form_helper
INFO - 2016-02-19 06:20:57 --> Database Driver Class Initialized
INFO - 2016-02-19 06:20:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:20:58 --> Controller Class Initialized
INFO - 2016-02-19 06:20:58 --> Model Class Initialized
INFO - 2016-02-19 06:20:58 --> Model Class Initialized
INFO - 2016-02-19 06:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:20:58 --> Pagination Class Initialized
INFO - 2016-02-19 06:20:58 --> Helper loaded: text_helper
INFO - 2016-02-19 06:20:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 06:21:01 --> Config Class Initialized
INFO - 2016-02-19 06:21:01 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:21:01 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:21:01 --> Utf8 Class Initialized
INFO - 2016-02-19 06:21:01 --> URI Class Initialized
INFO - 2016-02-19 06:21:01 --> Router Class Initialized
INFO - 2016-02-19 06:21:01 --> Output Class Initialized
INFO - 2016-02-19 06:21:01 --> Security Class Initialized
DEBUG - 2016-02-19 06:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:21:01 --> Input Class Initialized
INFO - 2016-02-19 06:21:01 --> Language Class Initialized
INFO - 2016-02-19 06:21:01 --> Loader Class Initialized
INFO - 2016-02-19 06:21:01 --> Helper loaded: url_helper
INFO - 2016-02-19 06:21:01 --> Helper loaded: file_helper
INFO - 2016-02-19 06:21:01 --> Helper loaded: date_helper
INFO - 2016-02-19 06:21:01 --> Helper loaded: form_helper
INFO - 2016-02-19 06:21:01 --> Database Driver Class Initialized
INFO - 2016-02-19 06:21:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:21:02 --> Controller Class Initialized
INFO - 2016-02-19 06:21:02 --> Model Class Initialized
INFO - 2016-02-19 06:21:02 --> Model Class Initialized
INFO - 2016-02-19 06:21:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:21:02 --> Pagination Class Initialized
INFO - 2016-02-19 06:21:02 --> Helper loaded: text_helper
INFO - 2016-02-19 06:21:02 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:21:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:21:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:21:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:21:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:21:02 --> Final output sent to browser
DEBUG - 2016-02-19 09:21:02 --> Total execution time: 1.1799
INFO - 2016-02-19 06:21:13 --> Config Class Initialized
INFO - 2016-02-19 06:21:13 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:21:13 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:21:13 --> Utf8 Class Initialized
INFO - 2016-02-19 06:21:13 --> URI Class Initialized
INFO - 2016-02-19 06:21:13 --> Router Class Initialized
INFO - 2016-02-19 06:21:13 --> Output Class Initialized
INFO - 2016-02-19 06:21:13 --> Security Class Initialized
DEBUG - 2016-02-19 06:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:21:13 --> Input Class Initialized
INFO - 2016-02-19 06:21:13 --> Language Class Initialized
INFO - 2016-02-19 06:21:13 --> Loader Class Initialized
INFO - 2016-02-19 06:21:13 --> Helper loaded: url_helper
INFO - 2016-02-19 06:21:13 --> Helper loaded: file_helper
INFO - 2016-02-19 06:21:13 --> Helper loaded: date_helper
INFO - 2016-02-19 06:21:13 --> Helper loaded: form_helper
INFO - 2016-02-19 06:21:13 --> Database Driver Class Initialized
INFO - 2016-02-19 06:21:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:21:14 --> Controller Class Initialized
INFO - 2016-02-19 06:21:14 --> Model Class Initialized
INFO - 2016-02-19 06:21:14 --> Model Class Initialized
INFO - 2016-02-19 06:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:21:14 --> Pagination Class Initialized
INFO - 2016-02-19 06:21:14 --> Helper loaded: text_helper
INFO - 2016-02-19 06:21:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:21:14 --> Final output sent to browser
DEBUG - 2016-02-19 09:21:14 --> Total execution time: 1.1593
INFO - 2016-02-19 06:23:48 --> Config Class Initialized
INFO - 2016-02-19 06:23:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:23:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:23:48 --> Utf8 Class Initialized
INFO - 2016-02-19 06:23:48 --> URI Class Initialized
DEBUG - 2016-02-19 06:23:48 --> No URI present. Default controller set.
INFO - 2016-02-19 06:23:48 --> Router Class Initialized
INFO - 2016-02-19 06:23:48 --> Output Class Initialized
INFO - 2016-02-19 06:23:48 --> Security Class Initialized
DEBUG - 2016-02-19 06:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:23:48 --> Input Class Initialized
INFO - 2016-02-19 06:23:48 --> Language Class Initialized
INFO - 2016-02-19 06:23:48 --> Loader Class Initialized
INFO - 2016-02-19 06:23:48 --> Helper loaded: url_helper
INFO - 2016-02-19 06:23:48 --> Helper loaded: file_helper
INFO - 2016-02-19 06:23:48 --> Helper loaded: date_helper
INFO - 2016-02-19 06:23:48 --> Helper loaded: form_helper
INFO - 2016-02-19 06:23:48 --> Database Driver Class Initialized
INFO - 2016-02-19 06:23:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:23:49 --> Controller Class Initialized
INFO - 2016-02-19 06:23:49 --> Model Class Initialized
INFO - 2016-02-19 06:23:49 --> Model Class Initialized
INFO - 2016-02-19 06:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:23:49 --> Pagination Class Initialized
INFO - 2016-02-19 06:23:49 --> Helper loaded: text_helper
INFO - 2016-02-19 06:23:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:23:49 --> Final output sent to browser
DEBUG - 2016-02-19 09:23:49 --> Total execution time: 1.1683
INFO - 2016-02-19 06:23:56 --> Config Class Initialized
INFO - 2016-02-19 06:23:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:23:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:23:56 --> Utf8 Class Initialized
INFO - 2016-02-19 06:23:56 --> URI Class Initialized
INFO - 2016-02-19 06:23:56 --> Router Class Initialized
INFO - 2016-02-19 06:23:56 --> Output Class Initialized
INFO - 2016-02-19 06:23:56 --> Security Class Initialized
DEBUG - 2016-02-19 06:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:23:56 --> Input Class Initialized
INFO - 2016-02-19 06:23:56 --> Language Class Initialized
INFO - 2016-02-19 06:23:56 --> Loader Class Initialized
INFO - 2016-02-19 06:23:56 --> Helper loaded: url_helper
INFO - 2016-02-19 06:23:56 --> Helper loaded: file_helper
INFO - 2016-02-19 06:23:56 --> Helper loaded: date_helper
INFO - 2016-02-19 06:23:56 --> Helper loaded: form_helper
INFO - 2016-02-19 06:23:56 --> Database Driver Class Initialized
INFO - 2016-02-19 06:23:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:23:57 --> Controller Class Initialized
INFO - 2016-02-19 06:23:57 --> Model Class Initialized
INFO - 2016-02-19 06:23:57 --> Model Class Initialized
INFO - 2016-02-19 06:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:23:57 --> Pagination Class Initialized
INFO - 2016-02-19 06:23:57 --> Helper loaded: text_helper
INFO - 2016-02-19 06:23:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:23:57 --> Final output sent to browser
DEBUG - 2016-02-19 09:23:57 --> Total execution time: 1.1404
INFO - 2016-02-19 06:25:39 --> Config Class Initialized
INFO - 2016-02-19 06:25:39 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:25:39 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:25:39 --> Utf8 Class Initialized
INFO - 2016-02-19 06:25:39 --> URI Class Initialized
DEBUG - 2016-02-19 06:25:39 --> No URI present. Default controller set.
INFO - 2016-02-19 06:25:39 --> Router Class Initialized
INFO - 2016-02-19 06:25:39 --> Output Class Initialized
INFO - 2016-02-19 06:25:39 --> Security Class Initialized
DEBUG - 2016-02-19 06:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:25:39 --> Input Class Initialized
INFO - 2016-02-19 06:25:39 --> Language Class Initialized
INFO - 2016-02-19 06:25:39 --> Loader Class Initialized
INFO - 2016-02-19 06:25:39 --> Helper loaded: url_helper
INFO - 2016-02-19 06:25:39 --> Helper loaded: file_helper
INFO - 2016-02-19 06:25:39 --> Helper loaded: date_helper
INFO - 2016-02-19 06:25:39 --> Helper loaded: form_helper
INFO - 2016-02-19 06:25:39 --> Database Driver Class Initialized
INFO - 2016-02-19 06:25:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:25:40 --> Controller Class Initialized
INFO - 2016-02-19 06:25:40 --> Model Class Initialized
INFO - 2016-02-19 06:25:40 --> Model Class Initialized
INFO - 2016-02-19 06:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:25:40 --> Pagination Class Initialized
INFO - 2016-02-19 06:25:40 --> Helper loaded: text_helper
INFO - 2016-02-19 06:25:40 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:25:40 --> Final output sent to browser
DEBUG - 2016-02-19 09:25:40 --> Total execution time: 1.1660
INFO - 2016-02-19 06:25:41 --> Config Class Initialized
INFO - 2016-02-19 06:25:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:25:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:25:41 --> Utf8 Class Initialized
INFO - 2016-02-19 06:25:41 --> URI Class Initialized
INFO - 2016-02-19 06:25:41 --> Router Class Initialized
INFO - 2016-02-19 06:25:41 --> Output Class Initialized
INFO - 2016-02-19 06:25:41 --> Security Class Initialized
DEBUG - 2016-02-19 06:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:25:41 --> Input Class Initialized
INFO - 2016-02-19 06:25:41 --> Language Class Initialized
INFO - 2016-02-19 06:25:41 --> Loader Class Initialized
INFO - 2016-02-19 06:25:41 --> Helper loaded: url_helper
INFO - 2016-02-19 06:25:41 --> Helper loaded: file_helper
INFO - 2016-02-19 06:25:41 --> Helper loaded: date_helper
INFO - 2016-02-19 06:25:41 --> Helper loaded: form_helper
INFO - 2016-02-19 06:25:41 --> Database Driver Class Initialized
INFO - 2016-02-19 06:25:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:25:43 --> Controller Class Initialized
INFO - 2016-02-19 06:25:43 --> Model Class Initialized
INFO - 2016-02-19 06:25:43 --> Model Class Initialized
INFO - 2016-02-19 06:25:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:25:43 --> Pagination Class Initialized
INFO - 2016-02-19 06:25:43 --> Helper loaded: text_helper
INFO - 2016-02-19 06:25:43 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:25:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:25:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:25:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:25:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:25:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:25:43 --> Final output sent to browser
DEBUG - 2016-02-19 09:25:43 --> Total execution time: 1.1610
INFO - 2016-02-19 06:26:38 --> Config Class Initialized
INFO - 2016-02-19 06:26:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:26:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:26:38 --> Utf8 Class Initialized
INFO - 2016-02-19 06:26:38 --> URI Class Initialized
INFO - 2016-02-19 06:26:38 --> Router Class Initialized
INFO - 2016-02-19 06:26:38 --> Output Class Initialized
INFO - 2016-02-19 06:26:38 --> Security Class Initialized
DEBUG - 2016-02-19 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:26:38 --> Input Class Initialized
INFO - 2016-02-19 06:26:38 --> Language Class Initialized
INFO - 2016-02-19 06:26:38 --> Loader Class Initialized
INFO - 2016-02-19 06:26:38 --> Helper loaded: url_helper
INFO - 2016-02-19 06:26:38 --> Helper loaded: file_helper
INFO - 2016-02-19 06:26:38 --> Helper loaded: date_helper
INFO - 2016-02-19 06:26:38 --> Helper loaded: form_helper
INFO - 2016-02-19 06:26:38 --> Database Driver Class Initialized
INFO - 2016-02-19 06:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:26:39 --> Controller Class Initialized
INFO - 2016-02-19 06:26:39 --> Model Class Initialized
INFO - 2016-02-19 06:26:39 --> Model Class Initialized
INFO - 2016-02-19 06:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:26:39 --> Pagination Class Initialized
INFO - 2016-02-19 06:26:39 --> Helper loaded: text_helper
INFO - 2016-02-19 06:26:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:26:39 --> Final output sent to browser
DEBUG - 2016-02-19 09:26:39 --> Total execution time: 1.1587
INFO - 2016-02-19 06:26:41 --> Config Class Initialized
INFO - 2016-02-19 06:26:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:26:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:26:41 --> Utf8 Class Initialized
INFO - 2016-02-19 06:26:41 --> URI Class Initialized
DEBUG - 2016-02-19 06:26:41 --> No URI present. Default controller set.
INFO - 2016-02-19 06:26:41 --> Router Class Initialized
INFO - 2016-02-19 06:26:41 --> Output Class Initialized
INFO - 2016-02-19 06:26:41 --> Security Class Initialized
DEBUG - 2016-02-19 06:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:26:41 --> Input Class Initialized
INFO - 2016-02-19 06:26:41 --> Language Class Initialized
INFO - 2016-02-19 06:26:41 --> Loader Class Initialized
INFO - 2016-02-19 06:26:41 --> Helper loaded: url_helper
INFO - 2016-02-19 06:26:41 --> Helper loaded: file_helper
INFO - 2016-02-19 06:26:41 --> Helper loaded: date_helper
INFO - 2016-02-19 06:26:41 --> Helper loaded: form_helper
INFO - 2016-02-19 06:26:41 --> Database Driver Class Initialized
INFO - 2016-02-19 06:26:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:26:42 --> Controller Class Initialized
INFO - 2016-02-19 06:26:42 --> Model Class Initialized
INFO - 2016-02-19 06:26:42 --> Model Class Initialized
INFO - 2016-02-19 06:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:26:42 --> Pagination Class Initialized
INFO - 2016-02-19 06:26:42 --> Helper loaded: text_helper
INFO - 2016-02-19 06:26:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:26:42 --> Final output sent to browser
DEBUG - 2016-02-19 09:26:42 --> Total execution time: 1.1541
INFO - 2016-02-19 06:26:44 --> Config Class Initialized
INFO - 2016-02-19 06:26:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:26:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:26:44 --> Utf8 Class Initialized
INFO - 2016-02-19 06:26:44 --> URI Class Initialized
INFO - 2016-02-19 06:26:44 --> Router Class Initialized
INFO - 2016-02-19 06:26:44 --> Output Class Initialized
INFO - 2016-02-19 06:26:44 --> Security Class Initialized
DEBUG - 2016-02-19 06:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:26:44 --> Input Class Initialized
INFO - 2016-02-19 06:26:44 --> Language Class Initialized
INFO - 2016-02-19 06:26:44 --> Loader Class Initialized
INFO - 2016-02-19 06:26:44 --> Helper loaded: url_helper
INFO - 2016-02-19 06:26:44 --> Helper loaded: file_helper
INFO - 2016-02-19 06:26:44 --> Helper loaded: date_helper
INFO - 2016-02-19 06:26:44 --> Helper loaded: form_helper
INFO - 2016-02-19 06:26:44 --> Database Driver Class Initialized
INFO - 2016-02-19 06:26:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:26:45 --> Controller Class Initialized
INFO - 2016-02-19 06:26:45 --> Model Class Initialized
INFO - 2016-02-19 06:26:45 --> Model Class Initialized
INFO - 2016-02-19 06:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:26:45 --> Pagination Class Initialized
INFO - 2016-02-19 06:26:45 --> Helper loaded: text_helper
INFO - 2016-02-19 06:26:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:26:45 --> Final output sent to browser
DEBUG - 2016-02-19 09:26:45 --> Total execution time: 1.1428
INFO - 2016-02-19 06:31:06 --> Config Class Initialized
INFO - 2016-02-19 06:31:06 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:31:06 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:31:06 --> Utf8 Class Initialized
INFO - 2016-02-19 06:31:06 --> URI Class Initialized
DEBUG - 2016-02-19 06:31:06 --> No URI present. Default controller set.
INFO - 2016-02-19 06:31:06 --> Router Class Initialized
INFO - 2016-02-19 06:31:06 --> Output Class Initialized
INFO - 2016-02-19 06:31:06 --> Security Class Initialized
DEBUG - 2016-02-19 06:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:31:06 --> Input Class Initialized
INFO - 2016-02-19 06:31:06 --> Language Class Initialized
INFO - 2016-02-19 06:31:06 --> Loader Class Initialized
INFO - 2016-02-19 06:31:06 --> Helper loaded: url_helper
INFO - 2016-02-19 06:31:06 --> Helper loaded: file_helper
INFO - 2016-02-19 06:31:06 --> Helper loaded: date_helper
INFO - 2016-02-19 06:31:06 --> Helper loaded: form_helper
INFO - 2016-02-19 06:31:06 --> Database Driver Class Initialized
INFO - 2016-02-19 06:31:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:31:07 --> Controller Class Initialized
INFO - 2016-02-19 06:31:07 --> Model Class Initialized
INFO - 2016-02-19 06:31:07 --> Model Class Initialized
INFO - 2016-02-19 06:31:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:31:07 --> Pagination Class Initialized
INFO - 2016-02-19 06:31:07 --> Helper loaded: text_helper
INFO - 2016-02-19 06:31:07 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:31:07 --> Final output sent to browser
DEBUG - 2016-02-19 09:31:07 --> Total execution time: 1.1733
INFO - 2016-02-19 06:31:12 --> Config Class Initialized
INFO - 2016-02-19 06:31:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:31:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:31:12 --> Utf8 Class Initialized
INFO - 2016-02-19 06:31:12 --> URI Class Initialized
INFO - 2016-02-19 06:31:12 --> Router Class Initialized
INFO - 2016-02-19 06:31:12 --> Output Class Initialized
INFO - 2016-02-19 06:31:12 --> Security Class Initialized
DEBUG - 2016-02-19 06:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:31:12 --> Input Class Initialized
INFO - 2016-02-19 06:31:12 --> Language Class Initialized
INFO - 2016-02-19 06:31:12 --> Loader Class Initialized
INFO - 2016-02-19 06:31:12 --> Helper loaded: url_helper
INFO - 2016-02-19 06:31:12 --> Helper loaded: file_helper
INFO - 2016-02-19 06:31:12 --> Helper loaded: date_helper
INFO - 2016-02-19 06:31:12 --> Helper loaded: form_helper
INFO - 2016-02-19 06:31:12 --> Database Driver Class Initialized
INFO - 2016-02-19 06:31:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:31:13 --> Controller Class Initialized
INFO - 2016-02-19 06:31:13 --> Model Class Initialized
INFO - 2016-02-19 06:31:13 --> Model Class Initialized
INFO - 2016-02-19 06:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:31:13 --> Pagination Class Initialized
INFO - 2016-02-19 06:31:13 --> Helper loaded: text_helper
INFO - 2016-02-19 06:31:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:31:13 --> Final output sent to browser
DEBUG - 2016-02-19 09:31:13 --> Total execution time: 1.2151
INFO - 2016-02-19 06:32:09 --> Config Class Initialized
INFO - 2016-02-19 06:32:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:32:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:32:09 --> Utf8 Class Initialized
INFO - 2016-02-19 06:32:09 --> URI Class Initialized
DEBUG - 2016-02-19 06:32:09 --> No URI present. Default controller set.
INFO - 2016-02-19 06:32:09 --> Router Class Initialized
INFO - 2016-02-19 06:32:09 --> Output Class Initialized
INFO - 2016-02-19 06:32:09 --> Security Class Initialized
DEBUG - 2016-02-19 06:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:32:09 --> Input Class Initialized
INFO - 2016-02-19 06:32:09 --> Language Class Initialized
INFO - 2016-02-19 06:32:09 --> Loader Class Initialized
INFO - 2016-02-19 06:32:09 --> Helper loaded: url_helper
INFO - 2016-02-19 06:32:09 --> Helper loaded: file_helper
INFO - 2016-02-19 06:32:09 --> Helper loaded: date_helper
INFO - 2016-02-19 06:32:09 --> Helper loaded: form_helper
INFO - 2016-02-19 06:32:09 --> Database Driver Class Initialized
INFO - 2016-02-19 06:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:32:10 --> Controller Class Initialized
INFO - 2016-02-19 06:32:10 --> Model Class Initialized
INFO - 2016-02-19 06:32:10 --> Model Class Initialized
INFO - 2016-02-19 06:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:32:10 --> Pagination Class Initialized
INFO - 2016-02-19 06:32:10 --> Helper loaded: text_helper
INFO - 2016-02-19 06:32:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:32:10 --> Final output sent to browser
DEBUG - 2016-02-19 09:32:10 --> Total execution time: 1.1028
INFO - 2016-02-19 06:32:12 --> Config Class Initialized
INFO - 2016-02-19 06:32:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:32:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:32:12 --> Utf8 Class Initialized
INFO - 2016-02-19 06:32:12 --> URI Class Initialized
INFO - 2016-02-19 06:32:12 --> Router Class Initialized
INFO - 2016-02-19 06:32:12 --> Output Class Initialized
INFO - 2016-02-19 06:32:12 --> Security Class Initialized
DEBUG - 2016-02-19 06:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:32:12 --> Input Class Initialized
INFO - 2016-02-19 06:32:12 --> Language Class Initialized
INFO - 2016-02-19 06:32:12 --> Loader Class Initialized
INFO - 2016-02-19 06:32:12 --> Helper loaded: url_helper
INFO - 2016-02-19 06:32:12 --> Helper loaded: file_helper
INFO - 2016-02-19 06:32:12 --> Helper loaded: date_helper
INFO - 2016-02-19 06:32:12 --> Helper loaded: form_helper
INFO - 2016-02-19 06:32:12 --> Database Driver Class Initialized
INFO - 2016-02-19 06:32:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:32:13 --> Controller Class Initialized
INFO - 2016-02-19 06:32:13 --> Model Class Initialized
INFO - 2016-02-19 06:32:13 --> Model Class Initialized
INFO - 2016-02-19 06:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:32:13 --> Pagination Class Initialized
INFO - 2016-02-19 06:32:13 --> Helper loaded: text_helper
INFO - 2016-02-19 06:32:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:32:13 --> Final output sent to browser
DEBUG - 2016-02-19 09:32:13 --> Total execution time: 1.1430
INFO - 2016-02-19 06:32:17 --> Config Class Initialized
INFO - 2016-02-19 06:32:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:32:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:32:17 --> Utf8 Class Initialized
INFO - 2016-02-19 06:32:17 --> URI Class Initialized
INFO - 2016-02-19 06:32:17 --> Router Class Initialized
INFO - 2016-02-19 06:32:17 --> Output Class Initialized
INFO - 2016-02-19 06:32:17 --> Security Class Initialized
DEBUG - 2016-02-19 06:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:32:17 --> Input Class Initialized
INFO - 2016-02-19 06:32:17 --> Language Class Initialized
INFO - 2016-02-19 06:32:17 --> Loader Class Initialized
INFO - 2016-02-19 06:32:17 --> Helper loaded: url_helper
INFO - 2016-02-19 06:32:17 --> Helper loaded: file_helper
INFO - 2016-02-19 06:32:17 --> Helper loaded: date_helper
INFO - 2016-02-19 06:32:17 --> Helper loaded: form_helper
INFO - 2016-02-19 06:32:17 --> Database Driver Class Initialized
INFO - 2016-02-19 06:32:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:32:18 --> Controller Class Initialized
INFO - 2016-02-19 06:32:18 --> Model Class Initialized
INFO - 2016-02-19 06:32:18 --> Model Class Initialized
INFO - 2016-02-19 06:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:32:18 --> Pagination Class Initialized
INFO - 2016-02-19 06:32:18 --> Helper loaded: text_helper
INFO - 2016-02-19 06:32:18 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:32:18 --> Final output sent to browser
DEBUG - 2016-02-19 09:32:18 --> Total execution time: 1.1722
INFO - 2016-02-19 06:32:47 --> Config Class Initialized
INFO - 2016-02-19 06:32:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:32:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:32:47 --> Utf8 Class Initialized
INFO - 2016-02-19 06:32:47 --> URI Class Initialized
DEBUG - 2016-02-19 06:32:47 --> No URI present. Default controller set.
INFO - 2016-02-19 06:32:47 --> Router Class Initialized
INFO - 2016-02-19 06:32:47 --> Output Class Initialized
INFO - 2016-02-19 06:32:47 --> Security Class Initialized
DEBUG - 2016-02-19 06:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:32:47 --> Input Class Initialized
INFO - 2016-02-19 06:32:47 --> Language Class Initialized
INFO - 2016-02-19 06:32:47 --> Loader Class Initialized
INFO - 2016-02-19 06:32:47 --> Helper loaded: url_helper
INFO - 2016-02-19 06:32:47 --> Helper loaded: file_helper
INFO - 2016-02-19 06:32:47 --> Helper loaded: date_helper
INFO - 2016-02-19 06:32:47 --> Helper loaded: form_helper
INFO - 2016-02-19 06:32:47 --> Database Driver Class Initialized
INFO - 2016-02-19 06:32:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:32:48 --> Controller Class Initialized
INFO - 2016-02-19 06:32:48 --> Model Class Initialized
INFO - 2016-02-19 06:32:48 --> Model Class Initialized
INFO - 2016-02-19 06:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:32:48 --> Pagination Class Initialized
INFO - 2016-02-19 06:32:48 --> Helper loaded: text_helper
INFO - 2016-02-19 06:32:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:32:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:32:48 --> Final output sent to browser
DEBUG - 2016-02-19 09:32:48 --> Total execution time: 1.1288
INFO - 2016-02-19 06:32:53 --> Config Class Initialized
INFO - 2016-02-19 06:32:53 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:32:53 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:32:53 --> Utf8 Class Initialized
INFO - 2016-02-19 06:32:53 --> URI Class Initialized
INFO - 2016-02-19 06:32:53 --> Router Class Initialized
INFO - 2016-02-19 06:32:53 --> Output Class Initialized
INFO - 2016-02-19 06:32:53 --> Security Class Initialized
DEBUG - 2016-02-19 06:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:32:53 --> Input Class Initialized
INFO - 2016-02-19 06:32:53 --> Language Class Initialized
INFO - 2016-02-19 06:32:53 --> Loader Class Initialized
INFO - 2016-02-19 06:32:53 --> Helper loaded: url_helper
INFO - 2016-02-19 06:32:53 --> Helper loaded: file_helper
INFO - 2016-02-19 06:32:53 --> Helper loaded: date_helper
INFO - 2016-02-19 06:32:53 --> Helper loaded: form_helper
INFO - 2016-02-19 06:32:53 --> Database Driver Class Initialized
INFO - 2016-02-19 06:32:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:32:54 --> Controller Class Initialized
INFO - 2016-02-19 06:32:54 --> Model Class Initialized
INFO - 2016-02-19 06:32:54 --> Model Class Initialized
INFO - 2016-02-19 06:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:32:54 --> Pagination Class Initialized
INFO - 2016-02-19 06:32:54 --> Helper loaded: text_helper
INFO - 2016-02-19 06:32:54 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:32:54 --> Final output sent to browser
DEBUG - 2016-02-19 09:32:54 --> Total execution time: 1.1828
INFO - 2016-02-19 06:41:24 --> Config Class Initialized
INFO - 2016-02-19 06:41:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:41:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:41:24 --> Utf8 Class Initialized
INFO - 2016-02-19 06:41:24 --> URI Class Initialized
DEBUG - 2016-02-19 06:41:24 --> No URI present. Default controller set.
INFO - 2016-02-19 06:41:24 --> Router Class Initialized
INFO - 2016-02-19 06:41:24 --> Output Class Initialized
INFO - 2016-02-19 06:41:24 --> Security Class Initialized
DEBUG - 2016-02-19 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:41:24 --> Input Class Initialized
INFO - 2016-02-19 06:41:24 --> Language Class Initialized
INFO - 2016-02-19 06:41:24 --> Loader Class Initialized
INFO - 2016-02-19 06:41:24 --> Helper loaded: url_helper
INFO - 2016-02-19 06:41:24 --> Helper loaded: file_helper
INFO - 2016-02-19 06:41:24 --> Helper loaded: date_helper
INFO - 2016-02-19 06:41:24 --> Helper loaded: form_helper
INFO - 2016-02-19 06:41:24 --> Database Driver Class Initialized
INFO - 2016-02-19 06:41:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:41:25 --> Controller Class Initialized
INFO - 2016-02-19 06:41:25 --> Model Class Initialized
INFO - 2016-02-19 06:41:25 --> Model Class Initialized
INFO - 2016-02-19 06:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:41:25 --> Pagination Class Initialized
INFO - 2016-02-19 06:41:25 --> Helper loaded: text_helper
INFO - 2016-02-19 06:41:25 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:41:25 --> Final output sent to browser
DEBUG - 2016-02-19 09:41:25 --> Total execution time: 1.1177
INFO - 2016-02-19 06:41:29 --> Config Class Initialized
INFO - 2016-02-19 06:41:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:41:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:41:29 --> Utf8 Class Initialized
INFO - 2016-02-19 06:41:29 --> URI Class Initialized
INFO - 2016-02-19 06:41:29 --> Router Class Initialized
INFO - 2016-02-19 06:41:29 --> Output Class Initialized
INFO - 2016-02-19 06:41:29 --> Security Class Initialized
DEBUG - 2016-02-19 06:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:41:29 --> Input Class Initialized
INFO - 2016-02-19 06:41:29 --> Language Class Initialized
INFO - 2016-02-19 06:41:29 --> Loader Class Initialized
INFO - 2016-02-19 06:41:29 --> Helper loaded: url_helper
INFO - 2016-02-19 06:41:29 --> Helper loaded: file_helper
INFO - 2016-02-19 06:41:29 --> Helper loaded: date_helper
INFO - 2016-02-19 06:41:29 --> Helper loaded: form_helper
INFO - 2016-02-19 06:41:29 --> Database Driver Class Initialized
INFO - 2016-02-19 06:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:41:30 --> Controller Class Initialized
INFO - 2016-02-19 06:41:30 --> Model Class Initialized
INFO - 2016-02-19 06:41:30 --> Model Class Initialized
INFO - 2016-02-19 06:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:41:30 --> Pagination Class Initialized
INFO - 2016-02-19 06:41:30 --> Helper loaded: text_helper
INFO - 2016-02-19 06:41:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 09:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:41:30 --> Final output sent to browser
DEBUG - 2016-02-19 09:41:30 --> Total execution time: 1.1388
INFO - 2016-02-19 06:41:38 --> Config Class Initialized
INFO - 2016-02-19 06:41:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:41:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:41:38 --> Utf8 Class Initialized
INFO - 2016-02-19 06:41:38 --> URI Class Initialized
INFO - 2016-02-19 06:41:38 --> Router Class Initialized
INFO - 2016-02-19 06:41:38 --> Output Class Initialized
INFO - 2016-02-19 06:41:38 --> Security Class Initialized
DEBUG - 2016-02-19 06:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:41:38 --> Input Class Initialized
INFO - 2016-02-19 06:41:38 --> Language Class Initialized
INFO - 2016-02-19 06:41:38 --> Loader Class Initialized
INFO - 2016-02-19 06:41:38 --> Helper loaded: url_helper
INFO - 2016-02-19 06:41:38 --> Helper loaded: file_helper
INFO - 2016-02-19 06:41:38 --> Helper loaded: date_helper
INFO - 2016-02-19 06:41:38 --> Helper loaded: form_helper
INFO - 2016-02-19 06:41:38 --> Database Driver Class Initialized
INFO - 2016-02-19 06:41:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:41:39 --> Controller Class Initialized
INFO - 2016-02-19 06:41:39 --> Model Class Initialized
INFO - 2016-02-19 06:41:39 --> Model Class Initialized
INFO - 2016-02-19 06:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:41:39 --> Pagination Class Initialized
INFO - 2016-02-19 06:41:39 --> Helper loaded: text_helper
INFO - 2016-02-19 06:41:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:41:39 --> Upload Class Initialized
INFO - 2016-02-19 09:41:39 --> Final output sent to browser
DEBUG - 2016-02-19 09:41:39 --> Total execution time: 1.1524
INFO - 2016-02-19 06:42:41 --> Config Class Initialized
INFO - 2016-02-19 06:42:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:42:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:42:41 --> Utf8 Class Initialized
INFO - 2016-02-19 06:42:41 --> URI Class Initialized
INFO - 2016-02-19 06:42:41 --> Router Class Initialized
INFO - 2016-02-19 06:42:41 --> Output Class Initialized
INFO - 2016-02-19 06:42:41 --> Security Class Initialized
DEBUG - 2016-02-19 06:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:42:41 --> Input Class Initialized
INFO - 2016-02-19 06:42:41 --> Language Class Initialized
INFO - 2016-02-19 06:42:41 --> Loader Class Initialized
INFO - 2016-02-19 06:42:41 --> Helper loaded: url_helper
INFO - 2016-02-19 06:42:41 --> Helper loaded: file_helper
INFO - 2016-02-19 06:42:41 --> Helper loaded: date_helper
INFO - 2016-02-19 06:42:41 --> Helper loaded: form_helper
INFO - 2016-02-19 06:42:41 --> Database Driver Class Initialized
INFO - 2016-02-19 06:42:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:42:42 --> Controller Class Initialized
INFO - 2016-02-19 06:42:42 --> Model Class Initialized
INFO - 2016-02-19 06:42:42 --> Model Class Initialized
INFO - 2016-02-19 06:42:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:42:42 --> Pagination Class Initialized
INFO - 2016-02-19 06:42:42 --> Helper loaded: text_helper
INFO - 2016-02-19 06:42:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:42:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:42:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:42:42 --> Form Validation Class Initialized
INFO - 2016-02-19 09:42:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-19 06:42:43 --> Config Class Initialized
INFO - 2016-02-19 06:42:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:42:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:42:43 --> Utf8 Class Initialized
INFO - 2016-02-19 06:42:43 --> URI Class Initialized
INFO - 2016-02-19 06:42:43 --> Router Class Initialized
INFO - 2016-02-19 06:42:43 --> Output Class Initialized
INFO - 2016-02-19 06:42:43 --> Security Class Initialized
DEBUG - 2016-02-19 06:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:42:43 --> Input Class Initialized
INFO - 2016-02-19 06:42:43 --> Language Class Initialized
INFO - 2016-02-19 06:42:43 --> Loader Class Initialized
INFO - 2016-02-19 06:42:43 --> Helper loaded: url_helper
INFO - 2016-02-19 06:42:43 --> Helper loaded: file_helper
INFO - 2016-02-19 06:42:43 --> Helper loaded: date_helper
INFO - 2016-02-19 06:42:43 --> Helper loaded: form_helper
INFO - 2016-02-19 06:42:43 --> Database Driver Class Initialized
INFO - 2016-02-19 06:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:42:44 --> Controller Class Initialized
INFO - 2016-02-19 06:42:44 --> Model Class Initialized
INFO - 2016-02-19 06:42:44 --> Model Class Initialized
INFO - 2016-02-19 06:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:42:44 --> Pagination Class Initialized
INFO - 2016-02-19 06:42:44 --> Helper loaded: text_helper
INFO - 2016-02-19 06:42:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:42:44 --> Final output sent to browser
DEBUG - 2016-02-19 09:42:44 --> Total execution time: 1.2096
INFO - 2016-02-19 06:59:11 --> Config Class Initialized
INFO - 2016-02-19 06:59:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:59:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:59:11 --> Utf8 Class Initialized
INFO - 2016-02-19 06:59:11 --> URI Class Initialized
DEBUG - 2016-02-19 06:59:11 --> No URI present. Default controller set.
INFO - 2016-02-19 06:59:11 --> Router Class Initialized
INFO - 2016-02-19 06:59:11 --> Output Class Initialized
INFO - 2016-02-19 06:59:11 --> Security Class Initialized
DEBUG - 2016-02-19 06:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:59:11 --> Input Class Initialized
INFO - 2016-02-19 06:59:11 --> Language Class Initialized
INFO - 2016-02-19 06:59:11 --> Loader Class Initialized
INFO - 2016-02-19 06:59:11 --> Helper loaded: url_helper
INFO - 2016-02-19 06:59:11 --> Helper loaded: file_helper
INFO - 2016-02-19 06:59:11 --> Helper loaded: date_helper
INFO - 2016-02-19 06:59:11 --> Helper loaded: form_helper
INFO - 2016-02-19 06:59:11 --> Database Driver Class Initialized
INFO - 2016-02-19 06:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:59:12 --> Controller Class Initialized
INFO - 2016-02-19 06:59:12 --> Model Class Initialized
INFO - 2016-02-19 06:59:12 --> Model Class Initialized
INFO - 2016-02-19 06:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:59:12 --> Pagination Class Initialized
INFO - 2016-02-19 06:59:12 --> Helper loaded: text_helper
INFO - 2016-02-19 06:59:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 09:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:59:12 --> Final output sent to browser
DEBUG - 2016-02-19 09:59:12 --> Total execution time: 1.1319
INFO - 2016-02-19 06:59:15 --> Config Class Initialized
INFO - 2016-02-19 06:59:15 --> Hooks Class Initialized
DEBUG - 2016-02-19 06:59:15 --> UTF-8 Support Enabled
INFO - 2016-02-19 06:59:15 --> Utf8 Class Initialized
INFO - 2016-02-19 06:59:15 --> URI Class Initialized
INFO - 2016-02-19 06:59:15 --> Router Class Initialized
INFO - 2016-02-19 06:59:15 --> Output Class Initialized
INFO - 2016-02-19 06:59:15 --> Security Class Initialized
DEBUG - 2016-02-19 06:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 06:59:15 --> Input Class Initialized
INFO - 2016-02-19 06:59:15 --> Language Class Initialized
INFO - 2016-02-19 06:59:15 --> Loader Class Initialized
INFO - 2016-02-19 06:59:15 --> Helper loaded: url_helper
INFO - 2016-02-19 06:59:15 --> Helper loaded: file_helper
INFO - 2016-02-19 06:59:15 --> Helper loaded: date_helper
INFO - 2016-02-19 06:59:15 --> Helper loaded: form_helper
INFO - 2016-02-19 06:59:15 --> Database Driver Class Initialized
INFO - 2016-02-19 06:59:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 06:59:16 --> Controller Class Initialized
INFO - 2016-02-19 06:59:16 --> Model Class Initialized
INFO - 2016-02-19 06:59:16 --> Model Class Initialized
INFO - 2016-02-19 06:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 06:59:16 --> Pagination Class Initialized
INFO - 2016-02-19 06:59:16 --> Helper loaded: text_helper
INFO - 2016-02-19 06:59:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 09:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 09:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 09:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 09:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 09:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 09:59:16 --> Final output sent to browser
DEBUG - 2016-02-19 09:59:16 --> Total execution time: 1.2859
INFO - 2016-02-19 07:00:19 --> Config Class Initialized
INFO - 2016-02-19 07:00:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:00:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:00:19 --> Utf8 Class Initialized
INFO - 2016-02-19 07:00:19 --> URI Class Initialized
DEBUG - 2016-02-19 07:00:19 --> No URI present. Default controller set.
INFO - 2016-02-19 07:00:19 --> Router Class Initialized
INFO - 2016-02-19 07:00:19 --> Output Class Initialized
INFO - 2016-02-19 07:00:20 --> Security Class Initialized
DEBUG - 2016-02-19 07:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:00:20 --> Input Class Initialized
INFO - 2016-02-19 07:00:20 --> Language Class Initialized
INFO - 2016-02-19 07:00:20 --> Loader Class Initialized
INFO - 2016-02-19 07:00:20 --> Helper loaded: url_helper
INFO - 2016-02-19 07:00:20 --> Helper loaded: file_helper
INFO - 2016-02-19 07:00:20 --> Helper loaded: date_helper
INFO - 2016-02-19 07:00:20 --> Helper loaded: form_helper
INFO - 2016-02-19 07:00:20 --> Database Driver Class Initialized
INFO - 2016-02-19 07:00:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:00:21 --> Controller Class Initialized
INFO - 2016-02-19 07:00:21 --> Model Class Initialized
INFO - 2016-02-19 07:00:21 --> Model Class Initialized
INFO - 2016-02-19 07:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:00:21 --> Pagination Class Initialized
INFO - 2016-02-19 07:00:21 --> Helper loaded: text_helper
INFO - 2016-02-19 07:00:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:00:21 --> Final output sent to browser
DEBUG - 2016-02-19 10:00:21 --> Total execution time: 1.1159
INFO - 2016-02-19 07:00:25 --> Config Class Initialized
INFO - 2016-02-19 07:00:25 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:00:25 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:00:25 --> Utf8 Class Initialized
INFO - 2016-02-19 07:00:25 --> URI Class Initialized
INFO - 2016-02-19 07:00:25 --> Router Class Initialized
INFO - 2016-02-19 07:00:25 --> Output Class Initialized
INFO - 2016-02-19 07:00:25 --> Security Class Initialized
DEBUG - 2016-02-19 07:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:00:25 --> Input Class Initialized
INFO - 2016-02-19 07:00:25 --> Language Class Initialized
INFO - 2016-02-19 07:00:25 --> Loader Class Initialized
INFO - 2016-02-19 07:00:25 --> Helper loaded: url_helper
INFO - 2016-02-19 07:00:25 --> Helper loaded: file_helper
INFO - 2016-02-19 07:00:25 --> Helper loaded: date_helper
INFO - 2016-02-19 07:00:25 --> Helper loaded: form_helper
INFO - 2016-02-19 07:00:25 --> Database Driver Class Initialized
INFO - 2016-02-19 07:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:00:26 --> Controller Class Initialized
INFO - 2016-02-19 07:00:26 --> Model Class Initialized
INFO - 2016-02-19 07:00:26 --> Model Class Initialized
INFO - 2016-02-19 07:00:26 --> Form Validation Class Initialized
INFO - 2016-02-19 07:00:26 --> Helper loaded: text_helper
INFO - 2016-02-19 07:00:26 --> Config Class Initialized
INFO - 2016-02-19 07:00:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:00:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:00:26 --> Utf8 Class Initialized
INFO - 2016-02-19 07:00:26 --> URI Class Initialized
DEBUG - 2016-02-19 07:00:26 --> No URI present. Default controller set.
INFO - 2016-02-19 07:00:26 --> Router Class Initialized
INFO - 2016-02-19 07:00:26 --> Output Class Initialized
INFO - 2016-02-19 07:00:26 --> Security Class Initialized
DEBUG - 2016-02-19 07:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:00:26 --> Input Class Initialized
INFO - 2016-02-19 07:00:26 --> Language Class Initialized
INFO - 2016-02-19 07:00:26 --> Loader Class Initialized
INFO - 2016-02-19 07:00:26 --> Helper loaded: url_helper
INFO - 2016-02-19 07:00:26 --> Helper loaded: file_helper
INFO - 2016-02-19 07:00:26 --> Helper loaded: date_helper
INFO - 2016-02-19 07:00:26 --> Helper loaded: form_helper
INFO - 2016-02-19 07:00:26 --> Database Driver Class Initialized
INFO - 2016-02-19 07:00:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:00:27 --> Controller Class Initialized
INFO - 2016-02-19 07:00:27 --> Model Class Initialized
INFO - 2016-02-19 07:00:27 --> Model Class Initialized
INFO - 2016-02-19 07:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:00:27 --> Pagination Class Initialized
INFO - 2016-02-19 07:00:27 --> Helper loaded: text_helper
INFO - 2016-02-19 07:00:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:00:27 --> Final output sent to browser
DEBUG - 2016-02-19 10:00:27 --> Total execution time: 1.1464
INFO - 2016-02-19 07:00:34 --> Config Class Initialized
INFO - 2016-02-19 07:00:34 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:00:34 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:00:34 --> Utf8 Class Initialized
INFO - 2016-02-19 07:00:34 --> URI Class Initialized
INFO - 2016-02-19 07:00:34 --> Router Class Initialized
INFO - 2016-02-19 07:00:34 --> Output Class Initialized
INFO - 2016-02-19 07:00:34 --> Security Class Initialized
DEBUG - 2016-02-19 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:00:34 --> Input Class Initialized
INFO - 2016-02-19 07:00:34 --> Language Class Initialized
INFO - 2016-02-19 07:00:34 --> Loader Class Initialized
INFO - 2016-02-19 07:00:34 --> Helper loaded: url_helper
INFO - 2016-02-19 07:00:34 --> Helper loaded: file_helper
INFO - 2016-02-19 07:00:34 --> Helper loaded: date_helper
INFO - 2016-02-19 07:00:34 --> Helper loaded: form_helper
INFO - 2016-02-19 07:00:34 --> Database Driver Class Initialized
INFO - 2016-02-19 07:00:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:00:35 --> Controller Class Initialized
INFO - 2016-02-19 07:00:35 --> Model Class Initialized
INFO - 2016-02-19 07:00:35 --> Model Class Initialized
INFO - 2016-02-19 07:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:00:35 --> Pagination Class Initialized
INFO - 2016-02-19 07:00:35 --> Helper loaded: text_helper
INFO - 2016-02-19 07:00:35 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:00:35 --> Final output sent to browser
DEBUG - 2016-02-19 10:00:35 --> Total execution time: 1.2508
INFO - 2016-02-19 07:03:30 --> Config Class Initialized
INFO - 2016-02-19 07:03:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:30 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:30 --> URI Class Initialized
DEBUG - 2016-02-19 07:03:30 --> No URI present. Default controller set.
INFO - 2016-02-19 07:03:30 --> Router Class Initialized
INFO - 2016-02-19 07:03:30 --> Output Class Initialized
INFO - 2016-02-19 07:03:30 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:30 --> Input Class Initialized
INFO - 2016-02-19 07:03:30 --> Language Class Initialized
INFO - 2016-02-19 07:03:30 --> Loader Class Initialized
INFO - 2016-02-19 07:03:30 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:30 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:30 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:30 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:30 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:31 --> Controller Class Initialized
INFO - 2016-02-19 07:03:31 --> Model Class Initialized
INFO - 2016-02-19 07:03:31 --> Model Class Initialized
INFO - 2016-02-19 07:03:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:03:31 --> Pagination Class Initialized
INFO - 2016-02-19 07:03:31 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:03:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:03:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:03:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:03:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:03:31 --> Final output sent to browser
DEBUG - 2016-02-19 10:03:31 --> Total execution time: 1.1715
INFO - 2016-02-19 07:03:32 --> Config Class Initialized
INFO - 2016-02-19 07:03:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:32 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:32 --> URI Class Initialized
INFO - 2016-02-19 07:03:32 --> Router Class Initialized
INFO - 2016-02-19 07:03:32 --> Output Class Initialized
INFO - 2016-02-19 07:03:32 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:32 --> Input Class Initialized
INFO - 2016-02-19 07:03:32 --> Language Class Initialized
INFO - 2016-02-19 07:03:32 --> Loader Class Initialized
INFO - 2016-02-19 07:03:32 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:32 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:32 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:32 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:32 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:33 --> Controller Class Initialized
INFO - 2016-02-19 07:03:33 --> Model Class Initialized
INFO - 2016-02-19 07:03:33 --> Model Class Initialized
INFO - 2016-02-19 07:03:33 --> Form Validation Class Initialized
INFO - 2016-02-19 07:03:33 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 07:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 07:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-19 07:03:34 --> Model Class Initialized
INFO - 2016-02-19 07:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 07:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 07:03:34 --> Final output sent to browser
DEBUG - 2016-02-19 07:03:34 --> Total execution time: 1.2169
INFO - 2016-02-19 07:03:35 --> Config Class Initialized
INFO - 2016-02-19 07:03:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:35 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:35 --> URI Class Initialized
DEBUG - 2016-02-19 07:03:35 --> No URI present. Default controller set.
INFO - 2016-02-19 07:03:35 --> Router Class Initialized
INFO - 2016-02-19 07:03:35 --> Output Class Initialized
INFO - 2016-02-19 07:03:35 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:35 --> Input Class Initialized
INFO - 2016-02-19 07:03:35 --> Language Class Initialized
INFO - 2016-02-19 07:03:35 --> Loader Class Initialized
INFO - 2016-02-19 07:03:35 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:35 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:35 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:35 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:35 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:36 --> Controller Class Initialized
INFO - 2016-02-19 07:03:36 --> Model Class Initialized
INFO - 2016-02-19 07:03:36 --> Model Class Initialized
INFO - 2016-02-19 07:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:03:36 --> Pagination Class Initialized
INFO - 2016-02-19 07:03:36 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:03:36 --> Final output sent to browser
DEBUG - 2016-02-19 10:03:36 --> Total execution time: 1.0923
INFO - 2016-02-19 07:03:50 --> Config Class Initialized
INFO - 2016-02-19 07:03:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:50 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:50 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:50 --> URI Class Initialized
INFO - 2016-02-19 07:03:50 --> Router Class Initialized
INFO - 2016-02-19 07:03:50 --> Output Class Initialized
INFO - 2016-02-19 07:03:50 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:50 --> Input Class Initialized
INFO - 2016-02-19 07:03:50 --> Language Class Initialized
INFO - 2016-02-19 07:03:50 --> Loader Class Initialized
INFO - 2016-02-19 07:03:50 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:50 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:50 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:50 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:50 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:51 --> Controller Class Initialized
INFO - 2016-02-19 07:03:51 --> Model Class Initialized
INFO - 2016-02-19 07:03:51 --> Model Class Initialized
INFO - 2016-02-19 07:03:51 --> Form Validation Class Initialized
INFO - 2016-02-19 07:03:51 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:51 --> Config Class Initialized
INFO - 2016-02-19 07:03:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:51 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:51 --> URI Class Initialized
DEBUG - 2016-02-19 07:03:51 --> No URI present. Default controller set.
INFO - 2016-02-19 07:03:51 --> Router Class Initialized
INFO - 2016-02-19 07:03:51 --> Output Class Initialized
INFO - 2016-02-19 07:03:51 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:51 --> Input Class Initialized
INFO - 2016-02-19 07:03:51 --> Language Class Initialized
INFO - 2016-02-19 07:03:51 --> Loader Class Initialized
INFO - 2016-02-19 07:03:51 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:51 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:51 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:51 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:51 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:52 --> Controller Class Initialized
INFO - 2016-02-19 07:03:52 --> Model Class Initialized
INFO - 2016-02-19 07:03:52 --> Model Class Initialized
INFO - 2016-02-19 07:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:03:52 --> Pagination Class Initialized
INFO - 2016-02-19 07:03:52 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:03:52 --> Final output sent to browser
DEBUG - 2016-02-19 10:03:52 --> Total execution time: 1.1371
INFO - 2016-02-19 07:03:55 --> Config Class Initialized
INFO - 2016-02-19 07:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:03:55 --> Utf8 Class Initialized
INFO - 2016-02-19 07:03:55 --> URI Class Initialized
INFO - 2016-02-19 07:03:55 --> Router Class Initialized
INFO - 2016-02-19 07:03:55 --> Output Class Initialized
INFO - 2016-02-19 07:03:55 --> Security Class Initialized
DEBUG - 2016-02-19 07:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:03:55 --> Input Class Initialized
INFO - 2016-02-19 07:03:55 --> Language Class Initialized
INFO - 2016-02-19 07:03:55 --> Loader Class Initialized
INFO - 2016-02-19 07:03:55 --> Helper loaded: url_helper
INFO - 2016-02-19 07:03:55 --> Helper loaded: file_helper
INFO - 2016-02-19 07:03:55 --> Helper loaded: date_helper
INFO - 2016-02-19 07:03:55 --> Helper loaded: form_helper
INFO - 2016-02-19 07:03:55 --> Database Driver Class Initialized
INFO - 2016-02-19 07:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:03:56 --> Controller Class Initialized
INFO - 2016-02-19 07:03:56 --> Model Class Initialized
INFO - 2016-02-19 07:03:56 --> Model Class Initialized
INFO - 2016-02-19 07:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:03:56 --> Pagination Class Initialized
INFO - 2016-02-19 07:03:56 --> Helper loaded: text_helper
INFO - 2016-02-19 07:03:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:03:56 --> Final output sent to browser
DEBUG - 2016-02-19 10:03:56 --> Total execution time: 1.1640
INFO - 2016-02-19 07:04:01 --> Config Class Initialized
INFO - 2016-02-19 07:04:01 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:01 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:01 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:01 --> URI Class Initialized
INFO - 2016-02-19 07:04:01 --> Router Class Initialized
INFO - 2016-02-19 07:04:01 --> Output Class Initialized
INFO - 2016-02-19 07:04:01 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:01 --> Input Class Initialized
INFO - 2016-02-19 07:04:01 --> Language Class Initialized
INFO - 2016-02-19 07:04:01 --> Loader Class Initialized
INFO - 2016-02-19 07:04:01 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:01 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:01 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:01 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:01 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:02 --> Controller Class Initialized
INFO - 2016-02-19 07:04:02 --> Model Class Initialized
INFO - 2016-02-19 07:04:02 --> Model Class Initialized
INFO - 2016-02-19 07:04:02 --> Form Validation Class Initialized
INFO - 2016-02-19 07:04:02 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:02 --> Config Class Initialized
INFO - 2016-02-19 07:04:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:02 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:02 --> URI Class Initialized
DEBUG - 2016-02-19 07:04:02 --> No URI present. Default controller set.
INFO - 2016-02-19 07:04:02 --> Router Class Initialized
INFO - 2016-02-19 07:04:02 --> Output Class Initialized
INFO - 2016-02-19 07:04:02 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:02 --> Input Class Initialized
INFO - 2016-02-19 07:04:02 --> Language Class Initialized
INFO - 2016-02-19 07:04:02 --> Loader Class Initialized
INFO - 2016-02-19 07:04:02 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:02 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:02 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:02 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:02 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:03 --> Controller Class Initialized
INFO - 2016-02-19 07:04:03 --> Model Class Initialized
INFO - 2016-02-19 07:04:03 --> Model Class Initialized
INFO - 2016-02-19 07:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:04:04 --> Pagination Class Initialized
INFO - 2016-02-19 07:04:04 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:04 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:04:04 --> Final output sent to browser
DEBUG - 2016-02-19 10:04:04 --> Total execution time: 1.1322
INFO - 2016-02-19 07:04:13 --> Config Class Initialized
INFO - 2016-02-19 07:04:13 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:13 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:13 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:13 --> URI Class Initialized
INFO - 2016-02-19 07:04:13 --> Router Class Initialized
INFO - 2016-02-19 07:04:13 --> Output Class Initialized
INFO - 2016-02-19 07:04:13 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:13 --> Input Class Initialized
INFO - 2016-02-19 07:04:13 --> Language Class Initialized
INFO - 2016-02-19 07:04:13 --> Loader Class Initialized
INFO - 2016-02-19 07:04:13 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:13 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:13 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:13 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:13 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:14 --> Controller Class Initialized
INFO - 2016-02-19 07:04:14 --> Model Class Initialized
INFO - 2016-02-19 07:04:14 --> Model Class Initialized
INFO - 2016-02-19 07:04:14 --> Form Validation Class Initialized
INFO - 2016-02-19 07:04:14 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:14 --> Config Class Initialized
INFO - 2016-02-19 07:04:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:14 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:14 --> URI Class Initialized
DEBUG - 2016-02-19 07:04:14 --> No URI present. Default controller set.
INFO - 2016-02-19 07:04:14 --> Router Class Initialized
INFO - 2016-02-19 07:04:14 --> Output Class Initialized
INFO - 2016-02-19 07:04:14 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:14 --> Input Class Initialized
INFO - 2016-02-19 07:04:14 --> Language Class Initialized
INFO - 2016-02-19 07:04:14 --> Loader Class Initialized
INFO - 2016-02-19 07:04:14 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:14 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:14 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:14 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:14 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:15 --> Controller Class Initialized
INFO - 2016-02-19 07:04:15 --> Model Class Initialized
INFO - 2016-02-19 07:04:15 --> Model Class Initialized
INFO - 2016-02-19 07:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:04:15 --> Pagination Class Initialized
INFO - 2016-02-19 07:04:15 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:04:15 --> Final output sent to browser
DEBUG - 2016-02-19 10:04:15 --> Total execution time: 1.0978
INFO - 2016-02-19 07:04:19 --> Config Class Initialized
INFO - 2016-02-19 07:04:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:19 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:19 --> URI Class Initialized
INFO - 2016-02-19 07:04:19 --> Router Class Initialized
INFO - 2016-02-19 07:04:19 --> Output Class Initialized
INFO - 2016-02-19 07:04:19 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:19 --> Input Class Initialized
INFO - 2016-02-19 07:04:19 --> Language Class Initialized
INFO - 2016-02-19 07:04:19 --> Loader Class Initialized
INFO - 2016-02-19 07:04:19 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:19 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:19 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:19 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:19 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:20 --> Controller Class Initialized
INFO - 2016-02-19 07:04:20 --> Model Class Initialized
INFO - 2016-02-19 07:04:20 --> Model Class Initialized
INFO - 2016-02-19 07:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:04:20 --> Pagination Class Initialized
INFO - 2016-02-19 07:04:20 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 10:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:04:20 --> Final output sent to browser
DEBUG - 2016-02-19 10:04:20 --> Total execution time: 1.1446
INFO - 2016-02-19 07:04:40 --> Config Class Initialized
INFO - 2016-02-19 07:04:40 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:04:40 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:04:40 --> Utf8 Class Initialized
INFO - 2016-02-19 07:04:40 --> URI Class Initialized
INFO - 2016-02-19 07:04:40 --> Router Class Initialized
INFO - 2016-02-19 07:04:40 --> Output Class Initialized
INFO - 2016-02-19 07:04:40 --> Security Class Initialized
DEBUG - 2016-02-19 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:04:40 --> Input Class Initialized
INFO - 2016-02-19 07:04:40 --> Language Class Initialized
INFO - 2016-02-19 07:04:40 --> Loader Class Initialized
INFO - 2016-02-19 07:04:40 --> Helper loaded: url_helper
INFO - 2016-02-19 07:04:40 --> Helper loaded: file_helper
INFO - 2016-02-19 07:04:40 --> Helper loaded: date_helper
INFO - 2016-02-19 07:04:40 --> Helper loaded: form_helper
INFO - 2016-02-19 07:04:40 --> Database Driver Class Initialized
INFO - 2016-02-19 07:04:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:04:41 --> Controller Class Initialized
INFO - 2016-02-19 07:04:41 --> Model Class Initialized
INFO - 2016-02-19 07:04:41 --> Model Class Initialized
INFO - 2016-02-19 07:04:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:04:41 --> Pagination Class Initialized
INFO - 2016-02-19 07:04:41 --> Helper loaded: text_helper
INFO - 2016-02-19 07:04:41 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:04:41 --> Upload Class Initialized
INFO - 2016-02-19 10:04:41 --> Final output sent to browser
DEBUG - 2016-02-19 10:04:41 --> Total execution time: 1.1151
INFO - 2016-02-19 07:05:30 --> Config Class Initialized
INFO - 2016-02-19 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:05:30 --> Utf8 Class Initialized
INFO - 2016-02-19 07:05:30 --> URI Class Initialized
INFO - 2016-02-19 07:05:30 --> Router Class Initialized
INFO - 2016-02-19 07:05:30 --> Output Class Initialized
INFO - 2016-02-19 07:05:30 --> Security Class Initialized
DEBUG - 2016-02-19 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:05:30 --> Input Class Initialized
INFO - 2016-02-19 07:05:30 --> Language Class Initialized
INFO - 2016-02-19 07:05:30 --> Loader Class Initialized
INFO - 2016-02-19 07:05:30 --> Helper loaded: url_helper
INFO - 2016-02-19 07:05:30 --> Helper loaded: file_helper
INFO - 2016-02-19 07:05:30 --> Helper loaded: date_helper
INFO - 2016-02-19 07:05:30 --> Helper loaded: form_helper
INFO - 2016-02-19 07:05:30 --> Database Driver Class Initialized
INFO - 2016-02-19 07:05:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:05:31 --> Controller Class Initialized
INFO - 2016-02-19 07:05:31 --> Model Class Initialized
INFO - 2016-02-19 07:05:31 --> Model Class Initialized
INFO - 2016-02-19 07:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:05:31 --> Pagination Class Initialized
INFO - 2016-02-19 07:05:31 --> Helper loaded: text_helper
INFO - 2016-02-19 07:05:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:05:31 --> Form Validation Class Initialized
INFO - 2016-02-19 10:05:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-19 07:05:31 --> Config Class Initialized
INFO - 2016-02-19 07:05:31 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:05:31 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:05:31 --> Utf8 Class Initialized
INFO - 2016-02-19 07:05:31 --> URI Class Initialized
INFO - 2016-02-19 07:05:31 --> Router Class Initialized
INFO - 2016-02-19 07:05:31 --> Output Class Initialized
INFO - 2016-02-19 07:05:31 --> Security Class Initialized
DEBUG - 2016-02-19 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:05:31 --> Input Class Initialized
INFO - 2016-02-19 07:05:31 --> Language Class Initialized
INFO - 2016-02-19 07:05:31 --> Loader Class Initialized
INFO - 2016-02-19 07:05:31 --> Helper loaded: url_helper
INFO - 2016-02-19 07:05:31 --> Helper loaded: file_helper
INFO - 2016-02-19 07:05:31 --> Helper loaded: date_helper
INFO - 2016-02-19 07:05:31 --> Helper loaded: form_helper
INFO - 2016-02-19 07:05:31 --> Database Driver Class Initialized
INFO - 2016-02-19 07:05:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:05:32 --> Controller Class Initialized
INFO - 2016-02-19 07:05:32 --> Model Class Initialized
INFO - 2016-02-19 07:05:32 --> Model Class Initialized
INFO - 2016-02-19 07:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:05:32 --> Pagination Class Initialized
INFO - 2016-02-19 07:05:32 --> Helper loaded: text_helper
INFO - 2016-02-19 07:05:32 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:05:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:05:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:05:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:05:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:05:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:05:32 --> Final output sent to browser
DEBUG - 2016-02-19 10:05:32 --> Total execution time: 1.1752
INFO - 2016-02-19 07:20:08 --> Config Class Initialized
INFO - 2016-02-19 07:20:08 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:20:08 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:20:08 --> Utf8 Class Initialized
INFO - 2016-02-19 07:20:08 --> URI Class Initialized
INFO - 2016-02-19 07:20:08 --> Router Class Initialized
INFO - 2016-02-19 07:20:08 --> Output Class Initialized
INFO - 2016-02-19 07:20:08 --> Security Class Initialized
DEBUG - 2016-02-19 07:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:20:08 --> Input Class Initialized
INFO - 2016-02-19 07:20:08 --> Language Class Initialized
INFO - 2016-02-19 07:20:08 --> Loader Class Initialized
INFO - 2016-02-19 07:20:08 --> Helper loaded: url_helper
INFO - 2016-02-19 07:20:08 --> Helper loaded: file_helper
INFO - 2016-02-19 07:20:08 --> Helper loaded: date_helper
INFO - 2016-02-19 07:20:08 --> Helper loaded: form_helper
INFO - 2016-02-19 07:20:08 --> Database Driver Class Initialized
INFO - 2016-02-19 07:20:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:20:09 --> Controller Class Initialized
INFO - 2016-02-19 07:20:09 --> Model Class Initialized
INFO - 2016-02-19 07:20:09 --> Model Class Initialized
INFO - 2016-02-19 07:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:20:09 --> Pagination Class Initialized
INFO - 2016-02-19 07:20:09 --> Helper loaded: text_helper
INFO - 2016-02-19 07:20:09 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:20:09 --> Final output sent to browser
DEBUG - 2016-02-19 10:20:09 --> Total execution time: 1.2187
INFO - 2016-02-19 07:21:09 --> Config Class Initialized
INFO - 2016-02-19 07:21:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:21:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:21:09 --> Utf8 Class Initialized
INFO - 2016-02-19 07:21:09 --> URI Class Initialized
DEBUG - 2016-02-19 07:21:09 --> No URI present. Default controller set.
INFO - 2016-02-19 07:21:09 --> Router Class Initialized
INFO - 2016-02-19 07:21:09 --> Output Class Initialized
INFO - 2016-02-19 07:21:09 --> Security Class Initialized
DEBUG - 2016-02-19 07:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:21:09 --> Input Class Initialized
INFO - 2016-02-19 07:21:09 --> Language Class Initialized
INFO - 2016-02-19 07:21:09 --> Loader Class Initialized
INFO - 2016-02-19 07:21:09 --> Helper loaded: url_helper
INFO - 2016-02-19 07:21:09 --> Helper loaded: file_helper
INFO - 2016-02-19 07:21:09 --> Helper loaded: date_helper
INFO - 2016-02-19 07:21:09 --> Helper loaded: form_helper
INFO - 2016-02-19 07:21:09 --> Database Driver Class Initialized
INFO - 2016-02-19 07:21:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:21:10 --> Controller Class Initialized
INFO - 2016-02-19 07:21:10 --> Model Class Initialized
INFO - 2016-02-19 07:21:10 --> Model Class Initialized
INFO - 2016-02-19 07:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:21:10 --> Pagination Class Initialized
INFO - 2016-02-19 07:21:10 --> Helper loaded: text_helper
INFO - 2016-02-19 07:21:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:21:10 --> Final output sent to browser
DEBUG - 2016-02-19 10:21:10 --> Total execution time: 1.1246
INFO - 2016-02-19 07:21:12 --> Config Class Initialized
INFO - 2016-02-19 07:21:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:21:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:21:12 --> Utf8 Class Initialized
INFO - 2016-02-19 07:21:12 --> URI Class Initialized
INFO - 2016-02-19 07:21:12 --> Router Class Initialized
INFO - 2016-02-19 07:21:12 --> Output Class Initialized
INFO - 2016-02-19 07:21:12 --> Security Class Initialized
DEBUG - 2016-02-19 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:21:12 --> Input Class Initialized
INFO - 2016-02-19 07:21:12 --> Language Class Initialized
INFO - 2016-02-19 07:21:12 --> Loader Class Initialized
INFO - 2016-02-19 07:21:12 --> Helper loaded: url_helper
INFO - 2016-02-19 07:21:12 --> Helper loaded: file_helper
INFO - 2016-02-19 07:21:12 --> Helper loaded: date_helper
INFO - 2016-02-19 07:21:12 --> Helper loaded: form_helper
INFO - 2016-02-19 07:21:12 --> Database Driver Class Initialized
INFO - 2016-02-19 07:21:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:21:13 --> Controller Class Initialized
INFO - 2016-02-19 07:21:13 --> Model Class Initialized
INFO - 2016-02-19 07:21:13 --> Model Class Initialized
INFO - 2016-02-19 07:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:21:13 --> Pagination Class Initialized
INFO - 2016-02-19 07:21:13 --> Helper loaded: text_helper
INFO - 2016-02-19 07:21:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 10:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:21:13 --> Final output sent to browser
DEBUG - 2016-02-19 10:21:13 --> Total execution time: 1.1422
INFO - 2016-02-19 07:23:37 --> Config Class Initialized
INFO - 2016-02-19 07:23:37 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:23:37 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:23:37 --> Utf8 Class Initialized
INFO - 2016-02-19 07:23:37 --> URI Class Initialized
DEBUG - 2016-02-19 07:23:37 --> No URI present. Default controller set.
INFO - 2016-02-19 07:23:37 --> Router Class Initialized
INFO - 2016-02-19 07:23:37 --> Output Class Initialized
INFO - 2016-02-19 07:23:37 --> Security Class Initialized
DEBUG - 2016-02-19 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:23:37 --> Input Class Initialized
INFO - 2016-02-19 07:23:37 --> Language Class Initialized
INFO - 2016-02-19 07:23:37 --> Loader Class Initialized
INFO - 2016-02-19 07:23:37 --> Helper loaded: url_helper
INFO - 2016-02-19 07:23:37 --> Helper loaded: file_helper
INFO - 2016-02-19 07:23:37 --> Helper loaded: date_helper
INFO - 2016-02-19 07:23:37 --> Helper loaded: form_helper
INFO - 2016-02-19 07:23:37 --> Database Driver Class Initialized
INFO - 2016-02-19 07:23:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:23:38 --> Controller Class Initialized
INFO - 2016-02-19 07:23:38 --> Model Class Initialized
INFO - 2016-02-19 07:23:38 --> Model Class Initialized
INFO - 2016-02-19 07:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:23:38 --> Pagination Class Initialized
INFO - 2016-02-19 07:23:38 --> Helper loaded: text_helper
INFO - 2016-02-19 07:23:38 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:23:38 --> Final output sent to browser
DEBUG - 2016-02-19 10:23:38 --> Total execution time: 1.1409
INFO - 2016-02-19 07:23:41 --> Config Class Initialized
INFO - 2016-02-19 07:23:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:23:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:23:41 --> Utf8 Class Initialized
INFO - 2016-02-19 07:23:41 --> URI Class Initialized
INFO - 2016-02-19 07:23:41 --> Router Class Initialized
INFO - 2016-02-19 07:23:41 --> Output Class Initialized
INFO - 2016-02-19 07:23:41 --> Security Class Initialized
DEBUG - 2016-02-19 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:23:41 --> Input Class Initialized
INFO - 2016-02-19 07:23:41 --> Language Class Initialized
INFO - 2016-02-19 07:23:41 --> Loader Class Initialized
INFO - 2016-02-19 07:23:41 --> Helper loaded: url_helper
INFO - 2016-02-19 07:23:41 --> Helper loaded: file_helper
INFO - 2016-02-19 07:23:41 --> Helper loaded: date_helper
INFO - 2016-02-19 07:23:41 --> Helper loaded: form_helper
INFO - 2016-02-19 07:23:41 --> Database Driver Class Initialized
INFO - 2016-02-19 07:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:23:42 --> Controller Class Initialized
INFO - 2016-02-19 07:23:42 --> Model Class Initialized
INFO - 2016-02-19 07:23:42 --> Model Class Initialized
INFO - 2016-02-19 07:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:23:42 --> Pagination Class Initialized
INFO - 2016-02-19 07:23:42 --> Helper loaded: text_helper
INFO - 2016-02-19 07:23:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 10:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:23:42 --> Final output sent to browser
DEBUG - 2016-02-19 10:23:42 --> Total execution time: 1.1457
INFO - 2016-02-19 07:23:48 --> Config Class Initialized
INFO - 2016-02-19 07:23:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:23:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:23:48 --> Utf8 Class Initialized
INFO - 2016-02-19 07:23:48 --> URI Class Initialized
DEBUG - 2016-02-19 07:23:48 --> No URI present. Default controller set.
INFO - 2016-02-19 07:23:48 --> Router Class Initialized
INFO - 2016-02-19 07:23:48 --> Output Class Initialized
INFO - 2016-02-19 07:23:48 --> Security Class Initialized
DEBUG - 2016-02-19 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:23:48 --> Input Class Initialized
INFO - 2016-02-19 07:23:48 --> Language Class Initialized
INFO - 2016-02-19 07:23:48 --> Loader Class Initialized
INFO - 2016-02-19 07:23:48 --> Helper loaded: url_helper
INFO - 2016-02-19 07:23:48 --> Helper loaded: file_helper
INFO - 2016-02-19 07:23:48 --> Helper loaded: date_helper
INFO - 2016-02-19 07:23:48 --> Helper loaded: form_helper
INFO - 2016-02-19 07:23:48 --> Database Driver Class Initialized
INFO - 2016-02-19 07:23:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:23:49 --> Controller Class Initialized
INFO - 2016-02-19 07:23:49 --> Model Class Initialized
INFO - 2016-02-19 07:23:49 --> Model Class Initialized
INFO - 2016-02-19 07:23:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:23:49 --> Pagination Class Initialized
INFO - 2016-02-19 07:23:49 --> Helper loaded: text_helper
INFO - 2016-02-19 07:23:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:23:49 --> Final output sent to browser
DEBUG - 2016-02-19 10:23:49 --> Total execution time: 1.1503
INFO - 2016-02-19 07:23:51 --> Config Class Initialized
INFO - 2016-02-19 07:23:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:23:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:23:51 --> Utf8 Class Initialized
INFO - 2016-02-19 07:23:51 --> URI Class Initialized
INFO - 2016-02-19 07:23:51 --> Router Class Initialized
INFO - 2016-02-19 07:23:51 --> Output Class Initialized
INFO - 2016-02-19 07:23:51 --> Security Class Initialized
DEBUG - 2016-02-19 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:23:51 --> Input Class Initialized
INFO - 2016-02-19 07:23:51 --> Language Class Initialized
INFO - 2016-02-19 07:23:51 --> Loader Class Initialized
INFO - 2016-02-19 07:23:51 --> Helper loaded: url_helper
INFO - 2016-02-19 07:23:51 --> Helper loaded: file_helper
INFO - 2016-02-19 07:23:51 --> Helper loaded: date_helper
INFO - 2016-02-19 07:23:51 --> Helper loaded: form_helper
INFO - 2016-02-19 07:23:51 --> Database Driver Class Initialized
INFO - 2016-02-19 07:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:23:52 --> Controller Class Initialized
INFO - 2016-02-19 07:23:52 --> Model Class Initialized
INFO - 2016-02-19 07:23:52 --> Model Class Initialized
INFO - 2016-02-19 07:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:23:52 --> Pagination Class Initialized
INFO - 2016-02-19 07:23:52 --> Helper loaded: text_helper
INFO - 2016-02-19 07:23:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:23:52 --> Final output sent to browser
DEBUG - 2016-02-19 10:23:52 --> Total execution time: 1.1716
INFO - 2016-02-19 07:23:59 --> Config Class Initialized
INFO - 2016-02-19 07:23:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:23:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:23:59 --> Utf8 Class Initialized
INFO - 2016-02-19 07:23:59 --> URI Class Initialized
DEBUG - 2016-02-19 07:23:59 --> No URI present. Default controller set.
INFO - 2016-02-19 07:23:59 --> Router Class Initialized
INFO - 2016-02-19 07:23:59 --> Output Class Initialized
INFO - 2016-02-19 07:23:59 --> Security Class Initialized
DEBUG - 2016-02-19 07:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:23:59 --> Input Class Initialized
INFO - 2016-02-19 07:23:59 --> Language Class Initialized
INFO - 2016-02-19 07:23:59 --> Loader Class Initialized
INFO - 2016-02-19 07:23:59 --> Helper loaded: url_helper
INFO - 2016-02-19 07:23:59 --> Helper loaded: file_helper
INFO - 2016-02-19 07:23:59 --> Helper loaded: date_helper
INFO - 2016-02-19 07:23:59 --> Helper loaded: form_helper
INFO - 2016-02-19 07:23:59 --> Database Driver Class Initialized
INFO - 2016-02-19 07:24:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:24:00 --> Controller Class Initialized
INFO - 2016-02-19 07:24:00 --> Model Class Initialized
INFO - 2016-02-19 07:24:00 --> Model Class Initialized
INFO - 2016-02-19 07:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:24:00 --> Pagination Class Initialized
INFO - 2016-02-19 07:24:00 --> Helper loaded: text_helper
INFO - 2016-02-19 07:24:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:24:00 --> Final output sent to browser
DEBUG - 2016-02-19 10:24:00 --> Total execution time: 1.1042
INFO - 2016-02-19 07:26:16 --> Config Class Initialized
INFO - 2016-02-19 07:26:16 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:26:16 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:26:16 --> Utf8 Class Initialized
INFO - 2016-02-19 07:26:16 --> URI Class Initialized
INFO - 2016-02-19 07:26:16 --> Router Class Initialized
INFO - 2016-02-19 07:26:16 --> Output Class Initialized
INFO - 2016-02-19 07:26:16 --> Security Class Initialized
DEBUG - 2016-02-19 07:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:26:16 --> Input Class Initialized
INFO - 2016-02-19 07:26:16 --> Language Class Initialized
INFO - 2016-02-19 07:26:16 --> Loader Class Initialized
INFO - 2016-02-19 07:26:16 --> Helper loaded: url_helper
INFO - 2016-02-19 07:26:16 --> Helper loaded: file_helper
INFO - 2016-02-19 07:26:16 --> Helper loaded: date_helper
INFO - 2016-02-19 07:26:16 --> Helper loaded: form_helper
INFO - 2016-02-19 07:26:16 --> Database Driver Class Initialized
INFO - 2016-02-19 07:26:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:26:17 --> Controller Class Initialized
INFO - 2016-02-19 07:26:17 --> Model Class Initialized
INFO - 2016-02-19 07:26:17 --> Model Class Initialized
INFO - 2016-02-19 07:26:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:26:17 --> Pagination Class Initialized
INFO - 2016-02-19 07:26:18 --> Helper loaded: text_helper
INFO - 2016-02-19 07:26:18 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:26:18 --> Final output sent to browser
DEBUG - 2016-02-19 10:26:18 --> Total execution time: 1.0981
INFO - 2016-02-19 07:26:20 --> Config Class Initialized
INFO - 2016-02-19 07:26:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:26:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:26:20 --> Utf8 Class Initialized
INFO - 2016-02-19 07:26:20 --> URI Class Initialized
INFO - 2016-02-19 07:26:20 --> Router Class Initialized
INFO - 2016-02-19 07:26:20 --> Output Class Initialized
INFO - 2016-02-19 07:26:20 --> Security Class Initialized
DEBUG - 2016-02-19 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:26:20 --> Input Class Initialized
INFO - 2016-02-19 07:26:20 --> Language Class Initialized
INFO - 2016-02-19 07:26:20 --> Loader Class Initialized
INFO - 2016-02-19 07:26:20 --> Helper loaded: url_helper
INFO - 2016-02-19 07:26:20 --> Helper loaded: file_helper
INFO - 2016-02-19 07:26:20 --> Helper loaded: date_helper
INFO - 2016-02-19 07:26:20 --> Helper loaded: form_helper
INFO - 2016-02-19 07:26:20 --> Database Driver Class Initialized
INFO - 2016-02-19 07:26:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:26:21 --> Controller Class Initialized
INFO - 2016-02-19 07:26:21 --> Model Class Initialized
INFO - 2016-02-19 07:26:21 --> Model Class Initialized
INFO - 2016-02-19 07:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:26:21 --> Pagination Class Initialized
INFO - 2016-02-19 07:26:21 --> Helper loaded: text_helper
INFO - 2016-02-19 07:26:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:26:21 --> Final output sent to browser
DEBUG - 2016-02-19 10:26:21 --> Total execution time: 1.1376
INFO - 2016-02-19 07:27:20 --> Config Class Initialized
INFO - 2016-02-19 07:27:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:27:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:27:20 --> Utf8 Class Initialized
INFO - 2016-02-19 07:27:20 --> URI Class Initialized
INFO - 2016-02-19 07:27:20 --> Router Class Initialized
INFO - 2016-02-19 07:27:20 --> Output Class Initialized
INFO - 2016-02-19 07:27:20 --> Security Class Initialized
DEBUG - 2016-02-19 07:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:27:20 --> Input Class Initialized
INFO - 2016-02-19 07:27:20 --> Language Class Initialized
INFO - 2016-02-19 07:27:20 --> Loader Class Initialized
INFO - 2016-02-19 07:27:20 --> Helper loaded: url_helper
INFO - 2016-02-19 07:27:20 --> Helper loaded: file_helper
INFO - 2016-02-19 07:27:20 --> Helper loaded: date_helper
INFO - 2016-02-19 07:27:20 --> Helper loaded: form_helper
INFO - 2016-02-19 07:27:20 --> Database Driver Class Initialized
INFO - 2016-02-19 07:27:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:27:21 --> Controller Class Initialized
INFO - 2016-02-19 07:27:21 --> Model Class Initialized
INFO - 2016-02-19 07:27:21 --> Model Class Initialized
INFO - 2016-02-19 07:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:27:21 --> Pagination Class Initialized
INFO - 2016-02-19 07:27:22 --> Helper loaded: text_helper
INFO - 2016-02-19 07:27:22 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:27:22 --> Final output sent to browser
DEBUG - 2016-02-19 10:27:22 --> Total execution time: 1.1042
INFO - 2016-02-19 07:27:23 --> Config Class Initialized
INFO - 2016-02-19 07:27:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:27:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:27:23 --> Utf8 Class Initialized
INFO - 2016-02-19 07:27:23 --> URI Class Initialized
INFO - 2016-02-19 07:27:23 --> Router Class Initialized
INFO - 2016-02-19 07:27:23 --> Output Class Initialized
INFO - 2016-02-19 07:27:23 --> Security Class Initialized
DEBUG - 2016-02-19 07:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:27:23 --> Input Class Initialized
INFO - 2016-02-19 07:27:23 --> Language Class Initialized
INFO - 2016-02-19 07:27:23 --> Loader Class Initialized
INFO - 2016-02-19 07:27:23 --> Helper loaded: url_helper
INFO - 2016-02-19 07:27:23 --> Helper loaded: file_helper
INFO - 2016-02-19 07:27:23 --> Helper loaded: date_helper
INFO - 2016-02-19 07:27:23 --> Helper loaded: form_helper
INFO - 2016-02-19 07:27:23 --> Database Driver Class Initialized
INFO - 2016-02-19 07:27:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:27:24 --> Controller Class Initialized
INFO - 2016-02-19 07:27:24 --> Model Class Initialized
INFO - 2016-02-19 07:27:24 --> Model Class Initialized
INFO - 2016-02-19 07:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:27:24 --> Pagination Class Initialized
INFO - 2016-02-19 07:27:24 --> Helper loaded: text_helper
INFO - 2016-02-19 07:27:24 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:27:24 --> Final output sent to browser
DEBUG - 2016-02-19 10:27:24 --> Total execution time: 1.2002
INFO - 2016-02-19 07:28:48 --> Config Class Initialized
INFO - 2016-02-19 07:28:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:28:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:28:48 --> Utf8 Class Initialized
INFO - 2016-02-19 07:28:48 --> URI Class Initialized
DEBUG - 2016-02-19 07:28:48 --> No URI present. Default controller set.
INFO - 2016-02-19 07:28:48 --> Router Class Initialized
INFO - 2016-02-19 07:28:48 --> Output Class Initialized
INFO - 2016-02-19 07:28:48 --> Security Class Initialized
DEBUG - 2016-02-19 07:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:28:48 --> Input Class Initialized
INFO - 2016-02-19 07:28:48 --> Language Class Initialized
INFO - 2016-02-19 07:28:48 --> Loader Class Initialized
INFO - 2016-02-19 07:28:48 --> Helper loaded: url_helper
INFO - 2016-02-19 07:28:48 --> Helper loaded: file_helper
INFO - 2016-02-19 07:28:48 --> Helper loaded: date_helper
INFO - 2016-02-19 07:28:48 --> Helper loaded: form_helper
INFO - 2016-02-19 07:28:48 --> Database Driver Class Initialized
INFO - 2016-02-19 07:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:28:49 --> Controller Class Initialized
INFO - 2016-02-19 07:28:49 --> Model Class Initialized
INFO - 2016-02-19 07:28:49 --> Model Class Initialized
INFO - 2016-02-19 07:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:28:49 --> Pagination Class Initialized
INFO - 2016-02-19 07:28:49 --> Helper loaded: text_helper
INFO - 2016-02-19 07:28:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:28:49 --> Final output sent to browser
DEBUG - 2016-02-19 10:28:49 --> Total execution time: 1.1589
INFO - 2016-02-19 07:28:50 --> Config Class Initialized
INFO - 2016-02-19 07:28:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:28:50 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:28:50 --> Utf8 Class Initialized
INFO - 2016-02-19 07:28:50 --> URI Class Initialized
INFO - 2016-02-19 07:28:50 --> Router Class Initialized
INFO - 2016-02-19 07:28:51 --> Output Class Initialized
INFO - 2016-02-19 07:28:51 --> Security Class Initialized
DEBUG - 2016-02-19 07:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:28:51 --> Input Class Initialized
INFO - 2016-02-19 07:28:51 --> Language Class Initialized
INFO - 2016-02-19 07:28:51 --> Loader Class Initialized
INFO - 2016-02-19 07:28:51 --> Helper loaded: url_helper
INFO - 2016-02-19 07:28:51 --> Helper loaded: file_helper
INFO - 2016-02-19 07:28:51 --> Helper loaded: date_helper
INFO - 2016-02-19 07:28:51 --> Helper loaded: form_helper
INFO - 2016-02-19 07:28:51 --> Database Driver Class Initialized
INFO - 2016-02-19 07:28:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:28:52 --> Controller Class Initialized
INFO - 2016-02-19 07:28:52 --> Model Class Initialized
INFO - 2016-02-19 07:28:52 --> Model Class Initialized
INFO - 2016-02-19 07:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:28:52 --> Pagination Class Initialized
INFO - 2016-02-19 07:28:52 --> Helper loaded: text_helper
INFO - 2016-02-19 07:28:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:28:52 --> Final output sent to browser
DEBUG - 2016-02-19 10:28:52 --> Total execution time: 1.1930
INFO - 2016-02-19 07:29:55 --> Config Class Initialized
INFO - 2016-02-19 07:29:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:29:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:29:55 --> Utf8 Class Initialized
INFO - 2016-02-19 07:29:55 --> URI Class Initialized
INFO - 2016-02-19 07:29:55 --> Router Class Initialized
INFO - 2016-02-19 07:29:55 --> Output Class Initialized
INFO - 2016-02-19 07:29:55 --> Security Class Initialized
DEBUG - 2016-02-19 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:29:55 --> Input Class Initialized
INFO - 2016-02-19 07:29:55 --> Language Class Initialized
INFO - 2016-02-19 07:29:55 --> Loader Class Initialized
INFO - 2016-02-19 07:29:55 --> Helper loaded: url_helper
INFO - 2016-02-19 07:29:55 --> Helper loaded: file_helper
INFO - 2016-02-19 07:29:55 --> Helper loaded: date_helper
INFO - 2016-02-19 07:29:55 --> Helper loaded: form_helper
INFO - 2016-02-19 07:29:55 --> Database Driver Class Initialized
INFO - 2016-02-19 07:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:29:56 --> Controller Class Initialized
INFO - 2016-02-19 07:29:56 --> Model Class Initialized
INFO - 2016-02-19 07:29:56 --> Model Class Initialized
INFO - 2016-02-19 07:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:29:56 --> Pagination Class Initialized
INFO - 2016-02-19 07:29:56 --> Helper loaded: text_helper
INFO - 2016-02-19 07:29:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:29:56 --> Final output sent to browser
DEBUG - 2016-02-19 10:29:56 --> Total execution time: 1.2446
INFO - 2016-02-19 07:30:32 --> Config Class Initialized
INFO - 2016-02-19 07:30:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:30:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:30:32 --> Utf8 Class Initialized
INFO - 2016-02-19 07:30:32 --> URI Class Initialized
DEBUG - 2016-02-19 07:30:32 --> No URI present. Default controller set.
INFO - 2016-02-19 07:30:32 --> Router Class Initialized
INFO - 2016-02-19 07:30:32 --> Output Class Initialized
INFO - 2016-02-19 07:30:32 --> Security Class Initialized
DEBUG - 2016-02-19 07:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:30:32 --> Input Class Initialized
INFO - 2016-02-19 07:30:32 --> Language Class Initialized
INFO - 2016-02-19 07:30:32 --> Loader Class Initialized
INFO - 2016-02-19 07:30:32 --> Helper loaded: url_helper
INFO - 2016-02-19 07:30:32 --> Helper loaded: file_helper
INFO - 2016-02-19 07:30:32 --> Helper loaded: date_helper
INFO - 2016-02-19 07:30:32 --> Helper loaded: form_helper
INFO - 2016-02-19 07:30:32 --> Database Driver Class Initialized
INFO - 2016-02-19 07:30:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:30:33 --> Controller Class Initialized
INFO - 2016-02-19 07:30:33 --> Model Class Initialized
INFO - 2016-02-19 07:30:33 --> Model Class Initialized
INFO - 2016-02-19 07:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:30:33 --> Pagination Class Initialized
INFO - 2016-02-19 07:30:33 --> Helper loaded: text_helper
INFO - 2016-02-19 07:30:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:30:33 --> Final output sent to browser
DEBUG - 2016-02-19 10:30:33 --> Total execution time: 1.1146
INFO - 2016-02-19 07:30:34 --> Config Class Initialized
INFO - 2016-02-19 07:30:34 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:30:34 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:30:34 --> Utf8 Class Initialized
INFO - 2016-02-19 07:30:34 --> URI Class Initialized
INFO - 2016-02-19 07:30:34 --> Router Class Initialized
INFO - 2016-02-19 07:30:34 --> Output Class Initialized
INFO - 2016-02-19 07:30:34 --> Security Class Initialized
DEBUG - 2016-02-19 07:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:30:34 --> Input Class Initialized
INFO - 2016-02-19 07:30:34 --> Language Class Initialized
INFO - 2016-02-19 07:30:34 --> Loader Class Initialized
INFO - 2016-02-19 07:30:34 --> Helper loaded: url_helper
INFO - 2016-02-19 07:30:34 --> Helper loaded: file_helper
INFO - 2016-02-19 07:30:34 --> Helper loaded: date_helper
INFO - 2016-02-19 07:30:34 --> Helper loaded: form_helper
INFO - 2016-02-19 07:30:34 --> Database Driver Class Initialized
INFO - 2016-02-19 07:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:30:35 --> Controller Class Initialized
INFO - 2016-02-19 07:30:35 --> Model Class Initialized
INFO - 2016-02-19 07:30:35 --> Model Class Initialized
INFO - 2016-02-19 07:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:30:35 --> Pagination Class Initialized
INFO - 2016-02-19 07:30:35 --> Helper loaded: text_helper
INFO - 2016-02-19 07:30:35 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:30:35 --> Final output sent to browser
DEBUG - 2016-02-19 10:30:35 --> Total execution time: 1.1938
INFO - 2016-02-19 07:31:30 --> Config Class Initialized
INFO - 2016-02-19 07:31:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:31:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:31:30 --> Utf8 Class Initialized
INFO - 2016-02-19 07:31:30 --> URI Class Initialized
DEBUG - 2016-02-19 07:31:30 --> No URI present. Default controller set.
INFO - 2016-02-19 07:31:30 --> Router Class Initialized
INFO - 2016-02-19 07:31:30 --> Output Class Initialized
INFO - 2016-02-19 07:31:30 --> Security Class Initialized
DEBUG - 2016-02-19 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:31:30 --> Input Class Initialized
INFO - 2016-02-19 07:31:30 --> Language Class Initialized
INFO - 2016-02-19 07:31:30 --> Loader Class Initialized
INFO - 2016-02-19 07:31:30 --> Helper loaded: url_helper
INFO - 2016-02-19 07:31:30 --> Helper loaded: file_helper
INFO - 2016-02-19 07:31:30 --> Helper loaded: date_helper
INFO - 2016-02-19 07:31:31 --> Helper loaded: form_helper
INFO - 2016-02-19 07:31:31 --> Database Driver Class Initialized
INFO - 2016-02-19 07:31:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:31:32 --> Controller Class Initialized
INFO - 2016-02-19 07:31:32 --> Model Class Initialized
INFO - 2016-02-19 07:31:32 --> Model Class Initialized
INFO - 2016-02-19 07:31:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:31:32 --> Pagination Class Initialized
INFO - 2016-02-19 07:31:32 --> Helper loaded: text_helper
INFO - 2016-02-19 07:31:32 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:31:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:31:32 --> Final output sent to browser
DEBUG - 2016-02-19 10:31:32 --> Total execution time: 1.1070
INFO - 2016-02-19 07:31:33 --> Config Class Initialized
INFO - 2016-02-19 07:31:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:31:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:31:33 --> Utf8 Class Initialized
INFO - 2016-02-19 07:31:33 --> URI Class Initialized
INFO - 2016-02-19 07:31:33 --> Router Class Initialized
INFO - 2016-02-19 07:31:33 --> Output Class Initialized
INFO - 2016-02-19 07:31:33 --> Security Class Initialized
DEBUG - 2016-02-19 07:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:31:33 --> Input Class Initialized
INFO - 2016-02-19 07:31:33 --> Language Class Initialized
INFO - 2016-02-19 07:31:33 --> Loader Class Initialized
INFO - 2016-02-19 07:31:33 --> Helper loaded: url_helper
INFO - 2016-02-19 07:31:33 --> Helper loaded: file_helper
INFO - 2016-02-19 07:31:33 --> Helper loaded: date_helper
INFO - 2016-02-19 07:31:33 --> Helper loaded: form_helper
INFO - 2016-02-19 07:31:33 --> Database Driver Class Initialized
INFO - 2016-02-19 07:31:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:31:34 --> Controller Class Initialized
INFO - 2016-02-19 07:31:34 --> Model Class Initialized
INFO - 2016-02-19 07:31:34 --> Model Class Initialized
INFO - 2016-02-19 07:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:31:34 --> Pagination Class Initialized
INFO - 2016-02-19 07:31:34 --> Helper loaded: text_helper
INFO - 2016-02-19 07:31:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:31:34 --> Final output sent to browser
DEBUG - 2016-02-19 10:31:34 --> Total execution time: 1.1877
INFO - 2016-02-19 07:32:55 --> Config Class Initialized
INFO - 2016-02-19 07:32:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:32:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:32:55 --> Utf8 Class Initialized
INFO - 2016-02-19 07:32:55 --> URI Class Initialized
DEBUG - 2016-02-19 07:32:55 --> No URI present. Default controller set.
INFO - 2016-02-19 07:32:55 --> Router Class Initialized
INFO - 2016-02-19 07:32:55 --> Output Class Initialized
INFO - 2016-02-19 07:32:55 --> Security Class Initialized
DEBUG - 2016-02-19 07:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:32:55 --> Input Class Initialized
INFO - 2016-02-19 07:32:55 --> Language Class Initialized
INFO - 2016-02-19 07:32:55 --> Loader Class Initialized
INFO - 2016-02-19 07:32:55 --> Helper loaded: url_helper
INFO - 2016-02-19 07:32:55 --> Helper loaded: file_helper
INFO - 2016-02-19 07:32:55 --> Helper loaded: date_helper
INFO - 2016-02-19 07:32:55 --> Helper loaded: form_helper
INFO - 2016-02-19 07:32:55 --> Database Driver Class Initialized
INFO - 2016-02-19 07:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:32:56 --> Controller Class Initialized
INFO - 2016-02-19 07:32:56 --> Model Class Initialized
INFO - 2016-02-19 07:32:56 --> Model Class Initialized
INFO - 2016-02-19 07:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:32:56 --> Pagination Class Initialized
INFO - 2016-02-19 07:32:56 --> Helper loaded: text_helper
INFO - 2016-02-19 07:32:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:32:56 --> Final output sent to browser
DEBUG - 2016-02-19 10:32:56 --> Total execution time: 1.1625
INFO - 2016-02-19 07:32:57 --> Config Class Initialized
INFO - 2016-02-19 07:32:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:32:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:32:57 --> Utf8 Class Initialized
INFO - 2016-02-19 07:32:57 --> URI Class Initialized
INFO - 2016-02-19 07:32:57 --> Router Class Initialized
INFO - 2016-02-19 07:32:57 --> Output Class Initialized
INFO - 2016-02-19 07:32:57 --> Security Class Initialized
DEBUG - 2016-02-19 07:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:32:57 --> Input Class Initialized
INFO - 2016-02-19 07:32:57 --> Language Class Initialized
INFO - 2016-02-19 07:32:57 --> Loader Class Initialized
INFO - 2016-02-19 07:32:57 --> Helper loaded: url_helper
INFO - 2016-02-19 07:32:57 --> Helper loaded: file_helper
INFO - 2016-02-19 07:32:57 --> Helper loaded: date_helper
INFO - 2016-02-19 07:32:57 --> Helper loaded: form_helper
INFO - 2016-02-19 07:32:57 --> Database Driver Class Initialized
INFO - 2016-02-19 07:32:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:32:58 --> Controller Class Initialized
INFO - 2016-02-19 07:32:58 --> Model Class Initialized
INFO - 2016-02-19 07:32:58 --> Model Class Initialized
INFO - 2016-02-19 07:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:32:58 --> Pagination Class Initialized
INFO - 2016-02-19 07:32:58 --> Helper loaded: text_helper
INFO - 2016-02-19 07:32:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:32:59 --> Final output sent to browser
DEBUG - 2016-02-19 10:32:59 --> Total execution time: 1.1825
INFO - 2016-02-19 07:35:53 --> Config Class Initialized
INFO - 2016-02-19 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:35:53 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:35:53 --> Utf8 Class Initialized
INFO - 2016-02-19 07:35:53 --> URI Class Initialized
INFO - 2016-02-19 07:35:53 --> Router Class Initialized
INFO - 2016-02-19 07:35:53 --> Output Class Initialized
INFO - 2016-02-19 07:35:53 --> Security Class Initialized
DEBUG - 2016-02-19 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:35:53 --> Input Class Initialized
INFO - 2016-02-19 07:35:53 --> Language Class Initialized
INFO - 2016-02-19 07:35:53 --> Loader Class Initialized
INFO - 2016-02-19 07:35:53 --> Helper loaded: url_helper
INFO - 2016-02-19 07:35:53 --> Helper loaded: file_helper
INFO - 2016-02-19 07:35:53 --> Helper loaded: date_helper
INFO - 2016-02-19 07:35:54 --> Helper loaded: form_helper
INFO - 2016-02-19 07:35:54 --> Database Driver Class Initialized
INFO - 2016-02-19 07:35:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:35:55 --> Controller Class Initialized
INFO - 2016-02-19 07:35:55 --> Model Class Initialized
INFO - 2016-02-19 07:35:55 --> Model Class Initialized
INFO - 2016-02-19 07:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:35:55 --> Pagination Class Initialized
INFO - 2016-02-19 07:35:55 --> Helper loaded: text_helper
INFO - 2016-02-19 07:35:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:35:55 --> Final output sent to browser
DEBUG - 2016-02-19 10:35:55 --> Total execution time: 1.2120
INFO - 2016-02-19 07:36:35 --> Config Class Initialized
INFO - 2016-02-19 07:36:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:36:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:36:35 --> Utf8 Class Initialized
INFO - 2016-02-19 07:36:35 --> URI Class Initialized
INFO - 2016-02-19 07:36:35 --> Router Class Initialized
INFO - 2016-02-19 07:36:35 --> Output Class Initialized
INFO - 2016-02-19 07:36:35 --> Security Class Initialized
DEBUG - 2016-02-19 07:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:36:35 --> Input Class Initialized
INFO - 2016-02-19 07:36:35 --> Language Class Initialized
INFO - 2016-02-19 07:36:35 --> Loader Class Initialized
INFO - 2016-02-19 07:36:35 --> Helper loaded: url_helper
INFO - 2016-02-19 07:36:35 --> Helper loaded: file_helper
INFO - 2016-02-19 07:36:35 --> Helper loaded: date_helper
INFO - 2016-02-19 07:36:35 --> Helper loaded: form_helper
INFO - 2016-02-19 07:36:35 --> Database Driver Class Initialized
INFO - 2016-02-19 07:36:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:36:36 --> Controller Class Initialized
INFO - 2016-02-19 07:36:36 --> Model Class Initialized
INFO - 2016-02-19 07:36:36 --> Model Class Initialized
INFO - 2016-02-19 07:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:36:36 --> Pagination Class Initialized
INFO - 2016-02-19 07:36:36 --> Helper loaded: text_helper
INFO - 2016-02-19 07:36:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:36:36 --> Final output sent to browser
DEBUG - 2016-02-19 10:36:36 --> Total execution time: 1.1556
INFO - 2016-02-19 07:39:10 --> Config Class Initialized
INFO - 2016-02-19 07:39:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:39:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:39:10 --> Utf8 Class Initialized
INFO - 2016-02-19 07:39:10 --> URI Class Initialized
DEBUG - 2016-02-19 07:39:10 --> No URI present. Default controller set.
INFO - 2016-02-19 07:39:10 --> Router Class Initialized
INFO - 2016-02-19 07:39:10 --> Output Class Initialized
INFO - 2016-02-19 07:39:10 --> Security Class Initialized
DEBUG - 2016-02-19 07:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:39:10 --> Input Class Initialized
INFO - 2016-02-19 07:39:10 --> Language Class Initialized
INFO - 2016-02-19 07:39:10 --> Loader Class Initialized
INFO - 2016-02-19 07:39:10 --> Helper loaded: url_helper
INFO - 2016-02-19 07:39:10 --> Helper loaded: file_helper
INFO - 2016-02-19 07:39:10 --> Helper loaded: date_helper
INFO - 2016-02-19 07:39:10 --> Helper loaded: form_helper
INFO - 2016-02-19 07:39:10 --> Database Driver Class Initialized
INFO - 2016-02-19 07:39:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:39:12 --> Controller Class Initialized
INFO - 2016-02-19 07:39:12 --> Model Class Initialized
INFO - 2016-02-19 07:39:12 --> Model Class Initialized
INFO - 2016-02-19 07:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:39:12 --> Pagination Class Initialized
INFO - 2016-02-19 07:39:12 --> Helper loaded: text_helper
INFO - 2016-02-19 07:39:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:39:12 --> Final output sent to browser
DEBUG - 2016-02-19 10:39:12 --> Total execution time: 1.1468
INFO - 2016-02-19 07:39:13 --> Config Class Initialized
INFO - 2016-02-19 07:39:13 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:39:13 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:39:13 --> Utf8 Class Initialized
INFO - 2016-02-19 07:39:13 --> URI Class Initialized
INFO - 2016-02-19 07:39:13 --> Router Class Initialized
INFO - 2016-02-19 07:39:13 --> Output Class Initialized
INFO - 2016-02-19 07:39:13 --> Security Class Initialized
DEBUG - 2016-02-19 07:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:39:13 --> Input Class Initialized
INFO - 2016-02-19 07:39:13 --> Language Class Initialized
INFO - 2016-02-19 07:39:13 --> Loader Class Initialized
INFO - 2016-02-19 07:39:13 --> Helper loaded: url_helper
INFO - 2016-02-19 07:39:13 --> Helper loaded: file_helper
INFO - 2016-02-19 07:39:13 --> Helper loaded: date_helper
INFO - 2016-02-19 07:39:13 --> Helper loaded: form_helper
INFO - 2016-02-19 07:39:13 --> Database Driver Class Initialized
INFO - 2016-02-19 07:39:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:39:14 --> Controller Class Initialized
INFO - 2016-02-19 07:39:14 --> Model Class Initialized
INFO - 2016-02-19 07:39:14 --> Model Class Initialized
INFO - 2016-02-19 07:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:39:14 --> Pagination Class Initialized
INFO - 2016-02-19 07:39:14 --> Helper loaded: text_helper
INFO - 2016-02-19 07:39:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:39:14 --> Final output sent to browser
DEBUG - 2016-02-19 10:39:14 --> Total execution time: 1.1285
INFO - 2016-02-19 07:40:08 --> Config Class Initialized
INFO - 2016-02-19 07:40:08 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:40:08 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:40:08 --> Utf8 Class Initialized
INFO - 2016-02-19 07:40:08 --> URI Class Initialized
INFO - 2016-02-19 07:40:08 --> Router Class Initialized
INFO - 2016-02-19 07:40:08 --> Output Class Initialized
INFO - 2016-02-19 07:40:08 --> Security Class Initialized
DEBUG - 2016-02-19 07:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:40:08 --> Input Class Initialized
INFO - 2016-02-19 07:40:08 --> Language Class Initialized
INFO - 2016-02-19 07:40:08 --> Loader Class Initialized
INFO - 2016-02-19 07:40:08 --> Helper loaded: url_helper
INFO - 2016-02-19 07:40:08 --> Helper loaded: file_helper
INFO - 2016-02-19 07:40:08 --> Helper loaded: date_helper
INFO - 2016-02-19 07:40:08 --> Helper loaded: form_helper
INFO - 2016-02-19 07:40:08 --> Database Driver Class Initialized
INFO - 2016-02-19 07:40:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:40:09 --> Controller Class Initialized
INFO - 2016-02-19 07:40:09 --> Model Class Initialized
INFO - 2016-02-19 07:40:09 --> Model Class Initialized
INFO - 2016-02-19 07:40:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:40:09 --> Pagination Class Initialized
INFO - 2016-02-19 07:40:09 --> Helper loaded: text_helper
INFO - 2016-02-19 07:40:09 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:40:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:40:09 --> Final output sent to browser
DEBUG - 2016-02-19 10:40:09 --> Total execution time: 1.1832
INFO - 2016-02-19 07:41:26 --> Config Class Initialized
INFO - 2016-02-19 07:41:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:41:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:41:26 --> Utf8 Class Initialized
INFO - 2016-02-19 07:41:26 --> URI Class Initialized
INFO - 2016-02-19 07:41:26 --> Router Class Initialized
INFO - 2016-02-19 07:41:26 --> Output Class Initialized
INFO - 2016-02-19 07:41:26 --> Security Class Initialized
DEBUG - 2016-02-19 07:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:41:26 --> Input Class Initialized
INFO - 2016-02-19 07:41:26 --> Language Class Initialized
INFO - 2016-02-19 07:41:26 --> Loader Class Initialized
INFO - 2016-02-19 07:41:26 --> Helper loaded: url_helper
INFO - 2016-02-19 07:41:26 --> Helper loaded: file_helper
INFO - 2016-02-19 07:41:26 --> Helper loaded: date_helper
INFO - 2016-02-19 07:41:26 --> Helper loaded: form_helper
INFO - 2016-02-19 07:41:26 --> Database Driver Class Initialized
INFO - 2016-02-19 07:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:41:27 --> Controller Class Initialized
INFO - 2016-02-19 07:41:27 --> Model Class Initialized
INFO - 2016-02-19 07:41:27 --> Model Class Initialized
INFO - 2016-02-19 07:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:41:27 --> Pagination Class Initialized
INFO - 2016-02-19 07:41:27 --> Helper loaded: text_helper
INFO - 2016-02-19 07:41:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:41:27 --> Final output sent to browser
DEBUG - 2016-02-19 10:41:27 --> Total execution time: 1.2014
INFO - 2016-02-19 07:43:32 --> Config Class Initialized
INFO - 2016-02-19 07:43:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:43:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:43:32 --> Utf8 Class Initialized
INFO - 2016-02-19 07:43:32 --> URI Class Initialized
INFO - 2016-02-19 07:43:32 --> Router Class Initialized
INFO - 2016-02-19 07:43:32 --> Output Class Initialized
INFO - 2016-02-19 07:43:32 --> Security Class Initialized
DEBUG - 2016-02-19 07:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:43:32 --> Input Class Initialized
INFO - 2016-02-19 07:43:32 --> Language Class Initialized
INFO - 2016-02-19 07:43:32 --> Loader Class Initialized
INFO - 2016-02-19 07:43:32 --> Helper loaded: url_helper
INFO - 2016-02-19 07:43:32 --> Helper loaded: file_helper
INFO - 2016-02-19 07:43:32 --> Helper loaded: date_helper
INFO - 2016-02-19 07:43:32 --> Helper loaded: form_helper
INFO - 2016-02-19 07:43:32 --> Database Driver Class Initialized
INFO - 2016-02-19 07:43:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:43:33 --> Controller Class Initialized
INFO - 2016-02-19 07:43:33 --> Model Class Initialized
INFO - 2016-02-19 07:43:33 --> Model Class Initialized
INFO - 2016-02-19 07:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:43:33 --> Pagination Class Initialized
INFO - 2016-02-19 07:43:33 --> Helper loaded: text_helper
INFO - 2016-02-19 07:43:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:43:33 --> Final output sent to browser
DEBUG - 2016-02-19 10:43:33 --> Total execution time: 1.3266
INFO - 2016-02-19 07:44:26 --> Config Class Initialized
INFO - 2016-02-19 07:44:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:44:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:44:26 --> Utf8 Class Initialized
INFO - 2016-02-19 07:44:26 --> URI Class Initialized
INFO - 2016-02-19 07:44:26 --> Router Class Initialized
INFO - 2016-02-19 07:44:26 --> Output Class Initialized
INFO - 2016-02-19 07:44:26 --> Security Class Initialized
DEBUG - 2016-02-19 07:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:44:26 --> Input Class Initialized
INFO - 2016-02-19 07:44:26 --> Language Class Initialized
INFO - 2016-02-19 07:44:26 --> Loader Class Initialized
INFO - 2016-02-19 07:44:26 --> Helper loaded: url_helper
INFO - 2016-02-19 07:44:26 --> Helper loaded: file_helper
INFO - 2016-02-19 07:44:26 --> Helper loaded: date_helper
INFO - 2016-02-19 07:44:26 --> Helper loaded: form_helper
INFO - 2016-02-19 07:44:26 --> Database Driver Class Initialized
INFO - 2016-02-19 07:44:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:44:27 --> Controller Class Initialized
INFO - 2016-02-19 07:44:27 --> Model Class Initialized
INFO - 2016-02-19 07:44:27 --> Model Class Initialized
INFO - 2016-02-19 07:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:44:27 --> Pagination Class Initialized
INFO - 2016-02-19 07:44:27 --> Helper loaded: text_helper
INFO - 2016-02-19 07:44:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:44:27 --> Final output sent to browser
DEBUG - 2016-02-19 10:44:27 --> Total execution time: 1.1949
INFO - 2016-02-19 07:44:45 --> Config Class Initialized
INFO - 2016-02-19 07:44:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:44:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:44:45 --> Utf8 Class Initialized
INFO - 2016-02-19 07:44:45 --> URI Class Initialized
DEBUG - 2016-02-19 07:44:45 --> No URI present. Default controller set.
INFO - 2016-02-19 07:44:45 --> Router Class Initialized
INFO - 2016-02-19 07:44:45 --> Output Class Initialized
INFO - 2016-02-19 07:44:45 --> Security Class Initialized
DEBUG - 2016-02-19 07:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:44:45 --> Input Class Initialized
INFO - 2016-02-19 07:44:45 --> Language Class Initialized
INFO - 2016-02-19 07:44:45 --> Loader Class Initialized
INFO - 2016-02-19 07:44:45 --> Helper loaded: url_helper
INFO - 2016-02-19 07:44:45 --> Helper loaded: file_helper
INFO - 2016-02-19 07:44:45 --> Helper loaded: date_helper
INFO - 2016-02-19 07:44:45 --> Helper loaded: form_helper
INFO - 2016-02-19 07:44:45 --> Database Driver Class Initialized
INFO - 2016-02-19 07:44:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:44:46 --> Controller Class Initialized
INFO - 2016-02-19 07:44:46 --> Model Class Initialized
INFO - 2016-02-19 07:44:46 --> Model Class Initialized
INFO - 2016-02-19 07:44:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:44:46 --> Pagination Class Initialized
INFO - 2016-02-19 07:44:46 --> Helper loaded: text_helper
INFO - 2016-02-19 07:44:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:44:46 --> Final output sent to browser
DEBUG - 2016-02-19 10:44:46 --> Total execution time: 1.1247
INFO - 2016-02-19 07:44:49 --> Config Class Initialized
INFO - 2016-02-19 07:44:49 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:44:49 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:44:49 --> Utf8 Class Initialized
INFO - 2016-02-19 07:44:49 --> URI Class Initialized
INFO - 2016-02-19 07:44:49 --> Router Class Initialized
INFO - 2016-02-19 07:44:49 --> Output Class Initialized
INFO - 2016-02-19 07:44:49 --> Security Class Initialized
DEBUG - 2016-02-19 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:44:49 --> Input Class Initialized
INFO - 2016-02-19 07:44:49 --> Language Class Initialized
INFO - 2016-02-19 07:44:49 --> Loader Class Initialized
INFO - 2016-02-19 07:44:49 --> Helper loaded: url_helper
INFO - 2016-02-19 07:44:49 --> Helper loaded: file_helper
INFO - 2016-02-19 07:44:49 --> Helper loaded: date_helper
INFO - 2016-02-19 07:44:49 --> Helper loaded: form_helper
INFO - 2016-02-19 07:44:49 --> Database Driver Class Initialized
INFO - 2016-02-19 07:44:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:44:50 --> Controller Class Initialized
INFO - 2016-02-19 07:44:50 --> Model Class Initialized
INFO - 2016-02-19 07:44:50 --> Model Class Initialized
INFO - 2016-02-19 07:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:44:50 --> Pagination Class Initialized
INFO - 2016-02-19 07:44:50 --> Helper loaded: text_helper
INFO - 2016-02-19 07:44:50 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:44:50 --> Final output sent to browser
DEBUG - 2016-02-19 10:44:50 --> Total execution time: 1.2256
INFO - 2016-02-19 07:45:07 --> Config Class Initialized
INFO - 2016-02-19 07:45:07 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:07 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:07 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:07 --> URI Class Initialized
INFO - 2016-02-19 07:45:07 --> Router Class Initialized
INFO - 2016-02-19 07:45:07 --> Output Class Initialized
INFO - 2016-02-19 07:45:07 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:07 --> Input Class Initialized
INFO - 2016-02-19 07:45:07 --> Language Class Initialized
INFO - 2016-02-19 07:45:07 --> Loader Class Initialized
INFO - 2016-02-19 07:45:07 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:07 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:07 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:07 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:07 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:08 --> Controller Class Initialized
INFO - 2016-02-19 07:45:08 --> Model Class Initialized
INFO - 2016-02-19 07:45:08 --> Model Class Initialized
INFO - 2016-02-19 07:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:08 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:08 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:08 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:08 --> Total execution time: 1.2749
INFO - 2016-02-19 07:45:28 --> Config Class Initialized
INFO - 2016-02-19 07:45:28 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:28 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:28 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:28 --> URI Class Initialized
INFO - 2016-02-19 07:45:28 --> Router Class Initialized
INFO - 2016-02-19 07:45:28 --> Output Class Initialized
INFO - 2016-02-19 07:45:28 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:28 --> Input Class Initialized
INFO - 2016-02-19 07:45:28 --> Language Class Initialized
INFO - 2016-02-19 07:45:28 --> Loader Class Initialized
INFO - 2016-02-19 07:45:28 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:28 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:28 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:28 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:28 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:29 --> Controller Class Initialized
INFO - 2016-02-19 07:45:29 --> Model Class Initialized
INFO - 2016-02-19 07:45:29 --> Model Class Initialized
INFO - 2016-02-19 07:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:29 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:29 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:29 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:29 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:29 --> Total execution time: 1.2383
INFO - 2016-02-19 07:45:32 --> Config Class Initialized
INFO - 2016-02-19 07:45:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:32 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:32 --> URI Class Initialized
DEBUG - 2016-02-19 07:45:32 --> No URI present. Default controller set.
INFO - 2016-02-19 07:45:32 --> Router Class Initialized
INFO - 2016-02-19 07:45:32 --> Output Class Initialized
INFO - 2016-02-19 07:45:32 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:32 --> Input Class Initialized
INFO - 2016-02-19 07:45:32 --> Language Class Initialized
INFO - 2016-02-19 07:45:32 --> Loader Class Initialized
INFO - 2016-02-19 07:45:32 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:32 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:32 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:32 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:32 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:33 --> Controller Class Initialized
INFO - 2016-02-19 07:45:33 --> Model Class Initialized
INFO - 2016-02-19 07:45:33 --> Model Class Initialized
INFO - 2016-02-19 07:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:33 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:33 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:45:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:33 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:33 --> Total execution time: 1.1267
INFO - 2016-02-19 07:45:36 --> Config Class Initialized
INFO - 2016-02-19 07:45:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:36 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:36 --> URI Class Initialized
INFO - 2016-02-19 07:45:36 --> Router Class Initialized
INFO - 2016-02-19 07:45:36 --> Output Class Initialized
INFO - 2016-02-19 07:45:36 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:36 --> Input Class Initialized
INFO - 2016-02-19 07:45:36 --> Language Class Initialized
INFO - 2016-02-19 07:45:36 --> Loader Class Initialized
INFO - 2016-02-19 07:45:36 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:36 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:36 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:36 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:36 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:37 --> Controller Class Initialized
INFO - 2016-02-19 07:45:37 --> Model Class Initialized
INFO - 2016-02-19 07:45:37 --> Model Class Initialized
INFO - 2016-02-19 07:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:37 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:37 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:37 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:37 --> Total execution time: 1.1448
INFO - 2016-02-19 07:45:43 --> Config Class Initialized
INFO - 2016-02-19 07:45:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:43 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:43 --> URI Class Initialized
DEBUG - 2016-02-19 07:45:43 --> No URI present. Default controller set.
INFO - 2016-02-19 07:45:43 --> Router Class Initialized
INFO - 2016-02-19 07:45:43 --> Output Class Initialized
INFO - 2016-02-19 07:45:43 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:43 --> Input Class Initialized
INFO - 2016-02-19 07:45:43 --> Language Class Initialized
INFO - 2016-02-19 07:45:43 --> Loader Class Initialized
INFO - 2016-02-19 07:45:43 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:43 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:43 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:43 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:43 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:44 --> Controller Class Initialized
INFO - 2016-02-19 07:45:44 --> Model Class Initialized
INFO - 2016-02-19 07:45:44 --> Model Class Initialized
INFO - 2016-02-19 07:45:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:44 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:44 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:45:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:44 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:44 --> Total execution time: 1.1449
INFO - 2016-02-19 07:45:46 --> Config Class Initialized
INFO - 2016-02-19 07:45:46 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:45:46 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:45:46 --> Utf8 Class Initialized
INFO - 2016-02-19 07:45:46 --> URI Class Initialized
INFO - 2016-02-19 07:45:46 --> Router Class Initialized
INFO - 2016-02-19 07:45:46 --> Output Class Initialized
INFO - 2016-02-19 07:45:46 --> Security Class Initialized
DEBUG - 2016-02-19 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:45:46 --> Input Class Initialized
INFO - 2016-02-19 07:45:46 --> Language Class Initialized
INFO - 2016-02-19 07:45:46 --> Loader Class Initialized
INFO - 2016-02-19 07:45:46 --> Helper loaded: url_helper
INFO - 2016-02-19 07:45:46 --> Helper loaded: file_helper
INFO - 2016-02-19 07:45:46 --> Helper loaded: date_helper
INFO - 2016-02-19 07:45:46 --> Helper loaded: form_helper
INFO - 2016-02-19 07:45:46 --> Database Driver Class Initialized
INFO - 2016-02-19 07:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:45:47 --> Controller Class Initialized
INFO - 2016-02-19 07:45:47 --> Model Class Initialized
INFO - 2016-02-19 07:45:47 --> Model Class Initialized
INFO - 2016-02-19 07:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:45:47 --> Pagination Class Initialized
INFO - 2016-02-19 07:45:47 --> Helper loaded: text_helper
INFO - 2016-02-19 07:45:47 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:45:47 --> Final output sent to browser
DEBUG - 2016-02-19 10:45:47 --> Total execution time: 1.1775
INFO - 2016-02-19 07:46:06 --> Config Class Initialized
INFO - 2016-02-19 07:46:06 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:46:06 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:46:06 --> Utf8 Class Initialized
INFO - 2016-02-19 07:46:06 --> URI Class Initialized
DEBUG - 2016-02-19 07:46:06 --> No URI present. Default controller set.
INFO - 2016-02-19 07:46:06 --> Router Class Initialized
INFO - 2016-02-19 07:46:06 --> Output Class Initialized
INFO - 2016-02-19 07:46:06 --> Security Class Initialized
DEBUG - 2016-02-19 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:46:06 --> Input Class Initialized
INFO - 2016-02-19 07:46:06 --> Language Class Initialized
INFO - 2016-02-19 07:46:06 --> Loader Class Initialized
INFO - 2016-02-19 07:46:06 --> Helper loaded: url_helper
INFO - 2016-02-19 07:46:06 --> Helper loaded: file_helper
INFO - 2016-02-19 07:46:06 --> Helper loaded: date_helper
INFO - 2016-02-19 07:46:06 --> Helper loaded: form_helper
INFO - 2016-02-19 07:46:06 --> Database Driver Class Initialized
INFO - 2016-02-19 07:46:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:46:07 --> Controller Class Initialized
INFO - 2016-02-19 07:46:07 --> Model Class Initialized
INFO - 2016-02-19 07:46:07 --> Model Class Initialized
INFO - 2016-02-19 07:46:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:46:07 --> Pagination Class Initialized
INFO - 2016-02-19 07:46:07 --> Helper loaded: text_helper
INFO - 2016-02-19 07:46:07 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:46:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:46:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:46:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:46:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:46:07 --> Final output sent to browser
DEBUG - 2016-02-19 10:46:07 --> Total execution time: 1.1346
INFO - 2016-02-19 07:46:12 --> Config Class Initialized
INFO - 2016-02-19 07:46:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:46:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:46:12 --> Utf8 Class Initialized
INFO - 2016-02-19 07:46:12 --> URI Class Initialized
INFO - 2016-02-19 07:46:12 --> Router Class Initialized
INFO - 2016-02-19 07:46:12 --> Output Class Initialized
INFO - 2016-02-19 07:46:12 --> Security Class Initialized
DEBUG - 2016-02-19 07:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:46:12 --> Input Class Initialized
INFO - 2016-02-19 07:46:12 --> Language Class Initialized
INFO - 2016-02-19 07:46:12 --> Loader Class Initialized
INFO - 2016-02-19 07:46:12 --> Helper loaded: url_helper
INFO - 2016-02-19 07:46:12 --> Helper loaded: file_helper
INFO - 2016-02-19 07:46:12 --> Helper loaded: date_helper
INFO - 2016-02-19 07:46:12 --> Helper loaded: form_helper
INFO - 2016-02-19 07:46:12 --> Database Driver Class Initialized
INFO - 2016-02-19 07:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:46:13 --> Controller Class Initialized
INFO - 2016-02-19 07:46:13 --> Model Class Initialized
INFO - 2016-02-19 07:46:13 --> Model Class Initialized
INFO - 2016-02-19 07:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:46:13 --> Pagination Class Initialized
INFO - 2016-02-19 07:46:13 --> Helper loaded: text_helper
INFO - 2016-02-19 07:46:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:46:13 --> Final output sent to browser
DEBUG - 2016-02-19 10:46:13 --> Total execution time: 1.2003
INFO - 2016-02-19 07:46:20 --> Config Class Initialized
INFO - 2016-02-19 07:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:46:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:46:20 --> Utf8 Class Initialized
INFO - 2016-02-19 07:46:20 --> URI Class Initialized
DEBUG - 2016-02-19 07:46:20 --> No URI present. Default controller set.
INFO - 2016-02-19 07:46:20 --> Router Class Initialized
INFO - 2016-02-19 07:46:20 --> Output Class Initialized
INFO - 2016-02-19 07:46:20 --> Security Class Initialized
DEBUG - 2016-02-19 07:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:46:20 --> Input Class Initialized
INFO - 2016-02-19 07:46:20 --> Language Class Initialized
INFO - 2016-02-19 07:46:20 --> Loader Class Initialized
INFO - 2016-02-19 07:46:20 --> Helper loaded: url_helper
INFO - 2016-02-19 07:46:20 --> Helper loaded: file_helper
INFO - 2016-02-19 07:46:20 --> Helper loaded: date_helper
INFO - 2016-02-19 07:46:20 --> Helper loaded: form_helper
INFO - 2016-02-19 07:46:20 --> Database Driver Class Initialized
INFO - 2016-02-19 07:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:46:21 --> Controller Class Initialized
INFO - 2016-02-19 07:46:21 --> Model Class Initialized
INFO - 2016-02-19 07:46:21 --> Model Class Initialized
INFO - 2016-02-19 07:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:46:21 --> Pagination Class Initialized
INFO - 2016-02-19 07:46:21 --> Helper loaded: text_helper
INFO - 2016-02-19 07:46:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:46:21 --> Final output sent to browser
DEBUG - 2016-02-19 10:46:21 --> Total execution time: 1.1232
INFO - 2016-02-19 07:46:23 --> Config Class Initialized
INFO - 2016-02-19 07:46:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:46:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:46:23 --> Utf8 Class Initialized
INFO - 2016-02-19 07:46:23 --> URI Class Initialized
INFO - 2016-02-19 07:46:23 --> Router Class Initialized
INFO - 2016-02-19 07:46:23 --> Output Class Initialized
INFO - 2016-02-19 07:46:23 --> Security Class Initialized
DEBUG - 2016-02-19 07:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:46:23 --> Input Class Initialized
INFO - 2016-02-19 07:46:23 --> Language Class Initialized
INFO - 2016-02-19 07:46:23 --> Loader Class Initialized
INFO - 2016-02-19 07:46:23 --> Helper loaded: url_helper
INFO - 2016-02-19 07:46:23 --> Helper loaded: file_helper
INFO - 2016-02-19 07:46:23 --> Helper loaded: date_helper
INFO - 2016-02-19 07:46:23 --> Helper loaded: form_helper
INFO - 2016-02-19 07:46:23 --> Database Driver Class Initialized
INFO - 2016-02-19 07:46:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:46:24 --> Controller Class Initialized
INFO - 2016-02-19 07:46:24 --> Model Class Initialized
INFO - 2016-02-19 07:46:24 --> Model Class Initialized
INFO - 2016-02-19 07:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:46:24 --> Pagination Class Initialized
INFO - 2016-02-19 07:46:24 --> Helper loaded: text_helper
INFO - 2016-02-19 07:46:24 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:46:24 --> Final output sent to browser
DEBUG - 2016-02-19 10:46:25 --> Total execution time: 1.1431
INFO - 2016-02-19 07:48:38 --> Config Class Initialized
INFO - 2016-02-19 07:48:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:48:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:48:38 --> Utf8 Class Initialized
INFO - 2016-02-19 07:48:38 --> URI Class Initialized
DEBUG - 2016-02-19 07:48:38 --> No URI present. Default controller set.
INFO - 2016-02-19 07:48:38 --> Router Class Initialized
INFO - 2016-02-19 07:48:38 --> Output Class Initialized
INFO - 2016-02-19 07:48:38 --> Security Class Initialized
DEBUG - 2016-02-19 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:48:38 --> Input Class Initialized
INFO - 2016-02-19 07:48:38 --> Language Class Initialized
INFO - 2016-02-19 07:48:38 --> Loader Class Initialized
INFO - 2016-02-19 07:48:38 --> Helper loaded: url_helper
INFO - 2016-02-19 07:48:38 --> Helper loaded: file_helper
INFO - 2016-02-19 07:48:38 --> Helper loaded: date_helper
INFO - 2016-02-19 07:48:38 --> Helper loaded: form_helper
INFO - 2016-02-19 07:48:38 --> Database Driver Class Initialized
INFO - 2016-02-19 07:48:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:48:39 --> Controller Class Initialized
INFO - 2016-02-19 07:48:39 --> Model Class Initialized
INFO - 2016-02-19 07:48:39 --> Model Class Initialized
INFO - 2016-02-19 07:48:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:48:39 --> Pagination Class Initialized
INFO - 2016-02-19 07:48:39 --> Helper loaded: text_helper
INFO - 2016-02-19 07:48:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 10:48:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:48:39 --> Final output sent to browser
DEBUG - 2016-02-19 10:48:39 --> Total execution time: 1.1009
INFO - 2016-02-19 07:48:40 --> Config Class Initialized
INFO - 2016-02-19 07:48:40 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:48:40 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:48:40 --> Utf8 Class Initialized
INFO - 2016-02-19 07:48:40 --> URI Class Initialized
INFO - 2016-02-19 07:48:40 --> Router Class Initialized
INFO - 2016-02-19 07:48:40 --> Output Class Initialized
INFO - 2016-02-19 07:48:40 --> Security Class Initialized
DEBUG - 2016-02-19 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:48:40 --> Input Class Initialized
INFO - 2016-02-19 07:48:40 --> Language Class Initialized
INFO - 2016-02-19 07:48:40 --> Loader Class Initialized
INFO - 2016-02-19 07:48:40 --> Helper loaded: url_helper
INFO - 2016-02-19 07:48:40 --> Helper loaded: file_helper
INFO - 2016-02-19 07:48:40 --> Helper loaded: date_helper
INFO - 2016-02-19 07:48:40 --> Helper loaded: form_helper
INFO - 2016-02-19 07:48:40 --> Database Driver Class Initialized
INFO - 2016-02-19 07:48:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:48:41 --> Controller Class Initialized
INFO - 2016-02-19 07:48:41 --> Model Class Initialized
INFO - 2016-02-19 07:48:41 --> Model Class Initialized
INFO - 2016-02-19 07:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:48:41 --> Pagination Class Initialized
INFO - 2016-02-19 07:48:41 --> Helper loaded: text_helper
INFO - 2016-02-19 07:48:41 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:48:41 --> Final output sent to browser
DEBUG - 2016-02-19 10:48:41 --> Total execution time: 1.2661
INFO - 2016-02-19 07:50:02 --> Config Class Initialized
INFO - 2016-02-19 07:50:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:50:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:50:02 --> Utf8 Class Initialized
INFO - 2016-02-19 07:50:02 --> URI Class Initialized
INFO - 2016-02-19 07:50:02 --> Router Class Initialized
INFO - 2016-02-19 07:50:02 --> Output Class Initialized
INFO - 2016-02-19 07:50:02 --> Security Class Initialized
DEBUG - 2016-02-19 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:50:02 --> Input Class Initialized
INFO - 2016-02-19 07:50:02 --> Language Class Initialized
INFO - 2016-02-19 07:50:02 --> Loader Class Initialized
INFO - 2016-02-19 07:50:02 --> Helper loaded: url_helper
INFO - 2016-02-19 07:50:02 --> Helper loaded: file_helper
INFO - 2016-02-19 07:50:02 --> Helper loaded: date_helper
INFO - 2016-02-19 07:50:02 --> Helper loaded: form_helper
INFO - 2016-02-19 07:50:02 --> Database Driver Class Initialized
INFO - 2016-02-19 07:50:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:50:03 --> Controller Class Initialized
INFO - 2016-02-19 07:50:03 --> Model Class Initialized
INFO - 2016-02-19 07:50:03 --> Model Class Initialized
INFO - 2016-02-19 07:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:50:03 --> Pagination Class Initialized
INFO - 2016-02-19 07:50:03 --> Helper loaded: text_helper
INFO - 2016-02-19 07:50:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:50:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:50:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:50:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
ERROR - 2016-02-19 10:50:03 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-19 10:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-19 10:50:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:50:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:50:03 --> Final output sent to browser
DEBUG - 2016-02-19 10:50:03 --> Total execution time: 1.2238
INFO - 2016-02-19 07:50:54 --> Config Class Initialized
INFO - 2016-02-19 07:50:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:50:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:50:54 --> Utf8 Class Initialized
INFO - 2016-02-19 07:50:54 --> URI Class Initialized
INFO - 2016-02-19 07:50:54 --> Router Class Initialized
INFO - 2016-02-19 07:50:54 --> Output Class Initialized
INFO - 2016-02-19 07:50:54 --> Security Class Initialized
DEBUG - 2016-02-19 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:50:54 --> Input Class Initialized
INFO - 2016-02-19 07:50:54 --> Language Class Initialized
INFO - 2016-02-19 07:50:54 --> Loader Class Initialized
INFO - 2016-02-19 07:50:54 --> Helper loaded: url_helper
INFO - 2016-02-19 07:50:54 --> Helper loaded: file_helper
INFO - 2016-02-19 07:50:54 --> Helper loaded: date_helper
INFO - 2016-02-19 07:50:54 --> Helper loaded: form_helper
INFO - 2016-02-19 07:50:54 --> Database Driver Class Initialized
INFO - 2016-02-19 07:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:50:55 --> Controller Class Initialized
INFO - 2016-02-19 07:50:55 --> Model Class Initialized
INFO - 2016-02-19 07:50:55 --> Model Class Initialized
INFO - 2016-02-19 07:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:50:55 --> Pagination Class Initialized
INFO - 2016-02-19 07:50:55 --> Helper loaded: text_helper
INFO - 2016-02-19 07:50:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:50:55 --> Upload Class Initialized
INFO - 2016-02-19 10:50:55 --> Final output sent to browser
DEBUG - 2016-02-19 10:50:55 --> Total execution time: 1.1251
INFO - 2016-02-19 07:51:00 --> Config Class Initialized
INFO - 2016-02-19 07:51:00 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:51:00 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:51:00 --> Utf8 Class Initialized
INFO - 2016-02-19 07:51:00 --> URI Class Initialized
INFO - 2016-02-19 07:51:00 --> Router Class Initialized
INFO - 2016-02-19 07:51:00 --> Output Class Initialized
INFO - 2016-02-19 07:51:00 --> Security Class Initialized
DEBUG - 2016-02-19 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:51:00 --> Input Class Initialized
INFO - 2016-02-19 07:51:00 --> Language Class Initialized
ERROR - 2016-02-19 07:51:00 --> 404 Page Not Found: Jboard/updatepost
INFO - 2016-02-19 07:52:18 --> Config Class Initialized
INFO - 2016-02-19 07:52:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:52:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:52:18 --> Utf8 Class Initialized
INFO - 2016-02-19 07:52:18 --> URI Class Initialized
INFO - 2016-02-19 07:52:18 --> Router Class Initialized
INFO - 2016-02-19 07:52:18 --> Output Class Initialized
INFO - 2016-02-19 07:52:18 --> Security Class Initialized
DEBUG - 2016-02-19 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:52:18 --> Input Class Initialized
INFO - 2016-02-19 07:52:18 --> Language Class Initialized
INFO - 2016-02-19 07:52:18 --> Loader Class Initialized
INFO - 2016-02-19 07:52:18 --> Helper loaded: url_helper
INFO - 2016-02-19 07:52:18 --> Helper loaded: file_helper
INFO - 2016-02-19 07:52:18 --> Helper loaded: date_helper
INFO - 2016-02-19 07:52:18 --> Helper loaded: form_helper
INFO - 2016-02-19 07:52:18 --> Database Driver Class Initialized
INFO - 2016-02-19 07:52:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:52:19 --> Controller Class Initialized
INFO - 2016-02-19 07:52:19 --> Model Class Initialized
INFO - 2016-02-19 07:52:19 --> Model Class Initialized
INFO - 2016-02-19 07:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:52:19 --> Pagination Class Initialized
INFO - 2016-02-19 07:52:19 --> Helper loaded: text_helper
INFO - 2016-02-19 07:52:19 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
ERROR - 2016-02-19 10:52:19 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-19 10:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-19 10:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:52:19 --> Final output sent to browser
DEBUG - 2016-02-19 10:52:19 --> Total execution time: 1.1830
INFO - 2016-02-19 07:52:36 --> Config Class Initialized
INFO - 2016-02-19 07:52:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:52:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:52:36 --> Utf8 Class Initialized
INFO - 2016-02-19 07:52:36 --> URI Class Initialized
INFO - 2016-02-19 07:52:36 --> Router Class Initialized
INFO - 2016-02-19 07:52:36 --> Output Class Initialized
INFO - 2016-02-19 07:52:36 --> Security Class Initialized
DEBUG - 2016-02-19 07:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:52:36 --> Input Class Initialized
INFO - 2016-02-19 07:52:36 --> Language Class Initialized
INFO - 2016-02-19 07:52:36 --> Loader Class Initialized
INFO - 2016-02-19 07:52:36 --> Helper loaded: url_helper
INFO - 2016-02-19 07:52:36 --> Helper loaded: file_helper
INFO - 2016-02-19 07:52:36 --> Helper loaded: date_helper
INFO - 2016-02-19 07:52:36 --> Helper loaded: form_helper
INFO - 2016-02-19 07:52:36 --> Database Driver Class Initialized
INFO - 2016-02-19 07:52:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:52:38 --> Controller Class Initialized
INFO - 2016-02-19 07:52:38 --> Model Class Initialized
INFO - 2016-02-19 07:52:38 --> Model Class Initialized
INFO - 2016-02-19 07:52:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:52:38 --> Pagination Class Initialized
INFO - 2016-02-19 07:52:38 --> Helper loaded: text_helper
INFO - 2016-02-19 07:52:38 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:52:38 --> Upload Class Initialized
INFO - 2016-02-19 10:52:38 --> Final output sent to browser
DEBUG - 2016-02-19 10:52:38 --> Total execution time: 1.1309
INFO - 2016-02-19 07:52:41 --> Config Class Initialized
INFO - 2016-02-19 07:52:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:52:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:52:41 --> Utf8 Class Initialized
INFO - 2016-02-19 07:52:42 --> URI Class Initialized
INFO - 2016-02-19 07:52:42 --> Router Class Initialized
INFO - 2016-02-19 07:52:42 --> Output Class Initialized
INFO - 2016-02-19 07:52:42 --> Security Class Initialized
DEBUG - 2016-02-19 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:52:42 --> Input Class Initialized
INFO - 2016-02-19 07:52:42 --> Language Class Initialized
ERROR - 2016-02-19 07:52:42 --> 404 Page Not Found: Jboard/updatepost
INFO - 2016-02-19 07:54:22 --> Config Class Initialized
INFO - 2016-02-19 07:54:22 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:54:22 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:54:22 --> Utf8 Class Initialized
INFO - 2016-02-19 07:54:22 --> URI Class Initialized
INFO - 2016-02-19 07:54:22 --> Router Class Initialized
INFO - 2016-02-19 07:54:22 --> Output Class Initialized
INFO - 2016-02-19 07:54:22 --> Security Class Initialized
DEBUG - 2016-02-19 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:54:22 --> Input Class Initialized
INFO - 2016-02-19 07:54:22 --> Language Class Initialized
INFO - 2016-02-19 07:54:22 --> Loader Class Initialized
INFO - 2016-02-19 07:54:22 --> Helper loaded: url_helper
INFO - 2016-02-19 07:54:22 --> Helper loaded: file_helper
INFO - 2016-02-19 07:54:22 --> Helper loaded: date_helper
INFO - 2016-02-19 07:54:22 --> Helper loaded: form_helper
INFO - 2016-02-19 07:54:22 --> Database Driver Class Initialized
INFO - 2016-02-19 07:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:54:23 --> Controller Class Initialized
INFO - 2016-02-19 07:54:23 --> Model Class Initialized
INFO - 2016-02-19 07:54:23 --> Model Class Initialized
INFO - 2016-02-19 07:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:54:23 --> Pagination Class Initialized
INFO - 2016-02-19 07:54:23 --> Helper loaded: text_helper
INFO - 2016-02-19 07:54:23 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
ERROR - 2016-02-19 10:54:23 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-19 10:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-19 10:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:54:23 --> Final output sent to browser
DEBUG - 2016-02-19 10:54:23 --> Total execution time: 1.1303
INFO - 2016-02-19 07:54:35 --> Config Class Initialized
INFO - 2016-02-19 07:54:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:54:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:54:35 --> Utf8 Class Initialized
INFO - 2016-02-19 07:54:35 --> URI Class Initialized
INFO - 2016-02-19 07:54:35 --> Router Class Initialized
INFO - 2016-02-19 07:54:35 --> Output Class Initialized
INFO - 2016-02-19 07:54:35 --> Security Class Initialized
DEBUG - 2016-02-19 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:54:35 --> Input Class Initialized
INFO - 2016-02-19 07:54:35 --> Language Class Initialized
INFO - 2016-02-19 07:54:35 --> Loader Class Initialized
INFO - 2016-02-19 07:54:35 --> Helper loaded: url_helper
INFO - 2016-02-19 07:54:35 --> Helper loaded: file_helper
INFO - 2016-02-19 07:54:35 --> Helper loaded: date_helper
INFO - 2016-02-19 07:54:35 --> Helper loaded: form_helper
INFO - 2016-02-19 07:54:35 --> Database Driver Class Initialized
INFO - 2016-02-19 07:54:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:54:36 --> Controller Class Initialized
INFO - 2016-02-19 07:54:36 --> Model Class Initialized
INFO - 2016-02-19 07:54:36 --> Model Class Initialized
INFO - 2016-02-19 07:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:54:36 --> Pagination Class Initialized
INFO - 2016-02-19 07:54:36 --> Helper loaded: text_helper
INFO - 2016-02-19 07:54:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:54:36 --> Upload Class Initialized
INFO - 2016-02-19 10:54:36 --> Final output sent to browser
DEBUG - 2016-02-19 10:54:36 --> Total execution time: 1.1550
INFO - 2016-02-19 07:54:39 --> Config Class Initialized
INFO - 2016-02-19 07:54:39 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:54:39 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:54:39 --> Utf8 Class Initialized
INFO - 2016-02-19 07:54:39 --> URI Class Initialized
INFO - 2016-02-19 07:54:39 --> Router Class Initialized
INFO - 2016-02-19 07:54:39 --> Output Class Initialized
INFO - 2016-02-19 07:54:39 --> Security Class Initialized
DEBUG - 2016-02-19 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:54:39 --> Input Class Initialized
INFO - 2016-02-19 07:54:39 --> Language Class Initialized
INFO - 2016-02-19 07:54:39 --> Loader Class Initialized
INFO - 2016-02-19 07:54:39 --> Helper loaded: url_helper
INFO - 2016-02-19 07:54:39 --> Helper loaded: file_helper
INFO - 2016-02-19 07:54:39 --> Helper loaded: date_helper
INFO - 2016-02-19 07:54:39 --> Helper loaded: form_helper
INFO - 2016-02-19 07:54:39 --> Database Driver Class Initialized
INFO - 2016-02-19 07:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:54:40 --> Controller Class Initialized
INFO - 2016-02-19 07:54:40 --> Model Class Initialized
INFO - 2016-02-19 07:54:40 --> Model Class Initialized
INFO - 2016-02-19 07:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:54:40 --> Pagination Class Initialized
INFO - 2016-02-19 07:54:40 --> Helper loaded: text_helper
INFO - 2016-02-19 07:54:40 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:54:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:54:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 07:54:41 --> Config Class Initialized
INFO - 2016-02-19 07:54:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:54:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:54:41 --> Utf8 Class Initialized
INFO - 2016-02-19 07:54:41 --> URI Class Initialized
INFO - 2016-02-19 07:54:41 --> Router Class Initialized
INFO - 2016-02-19 07:54:41 --> Output Class Initialized
INFO - 2016-02-19 07:54:41 --> Security Class Initialized
DEBUG - 2016-02-19 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:54:41 --> Input Class Initialized
INFO - 2016-02-19 07:54:41 --> Language Class Initialized
INFO - 2016-02-19 07:54:41 --> Loader Class Initialized
INFO - 2016-02-19 07:54:41 --> Helper loaded: url_helper
INFO - 2016-02-19 07:54:41 --> Helper loaded: file_helper
INFO - 2016-02-19 07:54:41 --> Helper loaded: date_helper
INFO - 2016-02-19 07:54:41 --> Helper loaded: form_helper
INFO - 2016-02-19 07:54:41 --> Database Driver Class Initialized
INFO - 2016-02-19 07:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:54:42 --> Controller Class Initialized
INFO - 2016-02-19 07:54:42 --> Model Class Initialized
INFO - 2016-02-19 07:54:42 --> Model Class Initialized
INFO - 2016-02-19 07:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:54:42 --> Pagination Class Initialized
INFO - 2016-02-19 07:54:42 --> Helper loaded: text_helper
INFO - 2016-02-19 07:54:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:54:42 --> Final output sent to browser
DEBUG - 2016-02-19 10:54:42 --> Total execution time: 1.1351
INFO - 2016-02-19 07:56:48 --> Config Class Initialized
INFO - 2016-02-19 07:56:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:56:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:56:48 --> Utf8 Class Initialized
INFO - 2016-02-19 07:56:48 --> URI Class Initialized
INFO - 2016-02-19 07:56:48 --> Router Class Initialized
INFO - 2016-02-19 07:56:48 --> Output Class Initialized
INFO - 2016-02-19 07:56:48 --> Security Class Initialized
DEBUG - 2016-02-19 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:56:48 --> Input Class Initialized
INFO - 2016-02-19 07:56:48 --> Language Class Initialized
INFO - 2016-02-19 07:56:48 --> Loader Class Initialized
INFO - 2016-02-19 07:56:48 --> Helper loaded: url_helper
INFO - 2016-02-19 07:56:48 --> Helper loaded: file_helper
INFO - 2016-02-19 07:56:48 --> Helper loaded: date_helper
INFO - 2016-02-19 07:56:48 --> Helper loaded: form_helper
INFO - 2016-02-19 07:56:48 --> Database Driver Class Initialized
INFO - 2016-02-19 07:56:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:56:49 --> Controller Class Initialized
INFO - 2016-02-19 07:56:49 --> Model Class Initialized
INFO - 2016-02-19 07:56:49 --> Model Class Initialized
INFO - 2016-02-19 07:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:56:49 --> Pagination Class Initialized
INFO - 2016-02-19 07:56:49 --> Helper loaded: text_helper
INFO - 2016-02-19 07:56:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:56:49 --> Final output sent to browser
DEBUG - 2016-02-19 10:56:49 --> Total execution time: 1.2499
INFO - 2016-02-19 07:57:06 --> Config Class Initialized
INFO - 2016-02-19 07:57:06 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:57:06 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:57:06 --> Utf8 Class Initialized
INFO - 2016-02-19 07:57:06 --> URI Class Initialized
INFO - 2016-02-19 07:57:06 --> Router Class Initialized
INFO - 2016-02-19 07:57:06 --> Output Class Initialized
INFO - 2016-02-19 07:57:06 --> Security Class Initialized
DEBUG - 2016-02-19 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:57:06 --> Input Class Initialized
INFO - 2016-02-19 07:57:06 --> Language Class Initialized
INFO - 2016-02-19 07:57:06 --> Loader Class Initialized
INFO - 2016-02-19 07:57:06 --> Helper loaded: url_helper
INFO - 2016-02-19 07:57:06 --> Helper loaded: file_helper
INFO - 2016-02-19 07:57:06 --> Helper loaded: date_helper
INFO - 2016-02-19 07:57:06 --> Helper loaded: form_helper
INFO - 2016-02-19 07:57:06 --> Database Driver Class Initialized
INFO - 2016-02-19 07:57:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:57:07 --> Controller Class Initialized
INFO - 2016-02-19 07:57:07 --> Model Class Initialized
INFO - 2016-02-19 07:57:07 --> Model Class Initialized
INFO - 2016-02-19 07:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:57:07 --> Pagination Class Initialized
INFO - 2016-02-19 07:57:07 --> Helper loaded: text_helper
INFO - 2016-02-19 07:57:07 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:57:07 --> Final output sent to browser
DEBUG - 2016-02-19 10:57:07 --> Total execution time: 1.2308
INFO - 2016-02-19 07:57:36 --> Config Class Initialized
INFO - 2016-02-19 07:57:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:57:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:57:36 --> Utf8 Class Initialized
INFO - 2016-02-19 07:57:36 --> URI Class Initialized
INFO - 2016-02-19 07:57:36 --> Router Class Initialized
INFO - 2016-02-19 07:57:36 --> Output Class Initialized
INFO - 2016-02-19 07:57:36 --> Security Class Initialized
DEBUG - 2016-02-19 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:57:36 --> Input Class Initialized
INFO - 2016-02-19 07:57:36 --> Language Class Initialized
INFO - 2016-02-19 07:57:36 --> Loader Class Initialized
INFO - 2016-02-19 07:57:36 --> Helper loaded: url_helper
INFO - 2016-02-19 07:57:36 --> Helper loaded: file_helper
INFO - 2016-02-19 07:57:36 --> Helper loaded: date_helper
INFO - 2016-02-19 07:57:36 --> Helper loaded: form_helper
INFO - 2016-02-19 07:57:36 --> Database Driver Class Initialized
INFO - 2016-02-19 07:57:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:57:37 --> Controller Class Initialized
INFO - 2016-02-19 07:57:37 --> Model Class Initialized
INFO - 2016-02-19 07:57:37 --> Model Class Initialized
INFO - 2016-02-19 07:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:57:37 --> Pagination Class Initialized
INFO - 2016-02-19 07:57:37 --> Helper loaded: text_helper
INFO - 2016-02-19 07:57:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:57:37 --> Final output sent to browser
DEBUG - 2016-02-19 10:57:37 --> Total execution time: 1.2220
INFO - 2016-02-19 07:57:43 --> Config Class Initialized
INFO - 2016-02-19 07:57:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:57:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:57:43 --> Utf8 Class Initialized
INFO - 2016-02-19 07:57:43 --> URI Class Initialized
INFO - 2016-02-19 07:57:43 --> Router Class Initialized
INFO - 2016-02-19 07:57:43 --> Output Class Initialized
INFO - 2016-02-19 07:57:43 --> Security Class Initialized
DEBUG - 2016-02-19 07:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:57:43 --> Input Class Initialized
INFO - 2016-02-19 07:57:43 --> Language Class Initialized
INFO - 2016-02-19 07:57:43 --> Loader Class Initialized
INFO - 2016-02-19 07:57:43 --> Helper loaded: url_helper
INFO - 2016-02-19 07:57:43 --> Helper loaded: file_helper
INFO - 2016-02-19 07:57:43 --> Helper loaded: date_helper
INFO - 2016-02-19 07:57:43 --> Helper loaded: form_helper
INFO - 2016-02-19 07:57:43 --> Database Driver Class Initialized
INFO - 2016-02-19 07:57:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:57:44 --> Controller Class Initialized
INFO - 2016-02-19 07:57:44 --> Model Class Initialized
INFO - 2016-02-19 07:57:44 --> Model Class Initialized
INFO - 2016-02-19 07:57:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:57:44 --> Pagination Class Initialized
INFO - 2016-02-19 07:57:44 --> Helper loaded: text_helper
INFO - 2016-02-19 07:57:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:57:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:57:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:57:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:57:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:57:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:57:44 --> Final output sent to browser
DEBUG - 2016-02-19 10:57:44 --> Total execution time: 1.2830
INFO - 2016-02-19 07:57:55 --> Config Class Initialized
INFO - 2016-02-19 07:57:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:57:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:57:55 --> Utf8 Class Initialized
INFO - 2016-02-19 07:57:55 --> URI Class Initialized
INFO - 2016-02-19 07:57:55 --> Router Class Initialized
INFO - 2016-02-19 07:57:55 --> Output Class Initialized
INFO - 2016-02-19 07:57:55 --> Security Class Initialized
DEBUG - 2016-02-19 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:57:55 --> Input Class Initialized
INFO - 2016-02-19 07:57:55 --> Language Class Initialized
INFO - 2016-02-19 07:57:55 --> Loader Class Initialized
INFO - 2016-02-19 07:57:55 --> Helper loaded: url_helper
INFO - 2016-02-19 07:57:55 --> Helper loaded: file_helper
INFO - 2016-02-19 07:57:55 --> Helper loaded: date_helper
INFO - 2016-02-19 07:57:55 --> Helper loaded: form_helper
INFO - 2016-02-19 07:57:55 --> Database Driver Class Initialized
INFO - 2016-02-19 07:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:57:56 --> Controller Class Initialized
INFO - 2016-02-19 07:57:56 --> Model Class Initialized
INFO - 2016-02-19 07:57:56 --> Model Class Initialized
INFO - 2016-02-19 07:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:57:56 --> Pagination Class Initialized
INFO - 2016-02-19 07:57:56 --> Helper loaded: text_helper
INFO - 2016-02-19 07:57:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:57:56 --> Final output sent to browser
DEBUG - 2016-02-19 10:57:56 --> Total execution time: 1.1992
INFO - 2016-02-19 07:58:09 --> Config Class Initialized
INFO - 2016-02-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:58:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:58:09 --> Utf8 Class Initialized
INFO - 2016-02-19 07:58:09 --> URI Class Initialized
INFO - 2016-02-19 07:58:09 --> Router Class Initialized
INFO - 2016-02-19 07:58:09 --> Output Class Initialized
INFO - 2016-02-19 07:58:09 --> Security Class Initialized
DEBUG - 2016-02-19 07:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:58:09 --> Input Class Initialized
INFO - 2016-02-19 07:58:09 --> Language Class Initialized
INFO - 2016-02-19 07:58:09 --> Loader Class Initialized
INFO - 2016-02-19 07:58:09 --> Helper loaded: url_helper
INFO - 2016-02-19 07:58:09 --> Helper loaded: file_helper
INFO - 2016-02-19 07:58:09 --> Helper loaded: date_helper
INFO - 2016-02-19 07:58:09 --> Helper loaded: form_helper
INFO - 2016-02-19 07:58:09 --> Database Driver Class Initialized
INFO - 2016-02-19 07:58:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:58:10 --> Controller Class Initialized
INFO - 2016-02-19 07:58:10 --> Model Class Initialized
INFO - 2016-02-19 07:58:10 --> Model Class Initialized
INFO - 2016-02-19 07:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:58:11 --> Pagination Class Initialized
INFO - 2016-02-19 07:58:11 --> Helper loaded: text_helper
INFO - 2016-02-19 07:58:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:58:11 --> Final output sent to browser
DEBUG - 2016-02-19 10:58:11 --> Total execution time: 1.1744
INFO - 2016-02-19 07:58:45 --> Config Class Initialized
INFO - 2016-02-19 07:58:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 07:58:46 --> UTF-8 Support Enabled
INFO - 2016-02-19 07:58:46 --> Utf8 Class Initialized
INFO - 2016-02-19 07:58:46 --> URI Class Initialized
INFO - 2016-02-19 07:58:46 --> Router Class Initialized
INFO - 2016-02-19 07:58:46 --> Output Class Initialized
INFO - 2016-02-19 07:58:46 --> Security Class Initialized
DEBUG - 2016-02-19 07:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 07:58:46 --> Input Class Initialized
INFO - 2016-02-19 07:58:46 --> Language Class Initialized
INFO - 2016-02-19 07:58:46 --> Loader Class Initialized
INFO - 2016-02-19 07:58:46 --> Helper loaded: url_helper
INFO - 2016-02-19 07:58:46 --> Helper loaded: file_helper
INFO - 2016-02-19 07:58:46 --> Helper loaded: date_helper
INFO - 2016-02-19 07:58:46 --> Helper loaded: form_helper
INFO - 2016-02-19 07:58:46 --> Database Driver Class Initialized
INFO - 2016-02-19 07:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 07:58:47 --> Controller Class Initialized
INFO - 2016-02-19 07:58:47 --> Model Class Initialized
INFO - 2016-02-19 07:58:47 --> Model Class Initialized
INFO - 2016-02-19 07:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 07:58:47 --> Pagination Class Initialized
INFO - 2016-02-19 07:58:47 --> Helper loaded: text_helper
INFO - 2016-02-19 07:58:47 --> Helper loaded: cookie_helper
INFO - 2016-02-19 10:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 10:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 10:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 10:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 10:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 10:58:47 --> Final output sent to browser
DEBUG - 2016-02-19 10:58:47 --> Total execution time: 1.2217
INFO - 2016-02-19 08:02:44 --> Config Class Initialized
INFO - 2016-02-19 08:02:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:02:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:02:44 --> Utf8 Class Initialized
INFO - 2016-02-19 08:02:44 --> URI Class Initialized
INFO - 2016-02-19 08:02:44 --> Router Class Initialized
INFO - 2016-02-19 08:02:44 --> Output Class Initialized
INFO - 2016-02-19 08:02:44 --> Security Class Initialized
DEBUG - 2016-02-19 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:02:44 --> Input Class Initialized
INFO - 2016-02-19 08:02:44 --> Language Class Initialized
INFO - 2016-02-19 08:02:44 --> Loader Class Initialized
INFO - 2016-02-19 08:02:44 --> Helper loaded: url_helper
INFO - 2016-02-19 08:02:44 --> Helper loaded: file_helper
INFO - 2016-02-19 08:02:44 --> Helper loaded: date_helper
INFO - 2016-02-19 08:02:44 --> Helper loaded: form_helper
INFO - 2016-02-19 08:02:44 --> Database Driver Class Initialized
INFO - 2016-02-19 08:02:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:02:45 --> Controller Class Initialized
INFO - 2016-02-19 08:02:45 --> Model Class Initialized
INFO - 2016-02-19 08:02:45 --> Model Class Initialized
INFO - 2016-02-19 08:02:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:02:45 --> Pagination Class Initialized
INFO - 2016-02-19 08:02:45 --> Helper loaded: text_helper
INFO - 2016-02-19 08:02:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:02:45 --> Final output sent to browser
DEBUG - 2016-02-19 11:02:45 --> Total execution time: 1.2232
INFO - 2016-02-19 08:03:04 --> Config Class Initialized
INFO - 2016-02-19 08:03:04 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:03:04 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:03:04 --> Utf8 Class Initialized
INFO - 2016-02-19 08:03:04 --> URI Class Initialized
INFO - 2016-02-19 08:03:04 --> Router Class Initialized
INFO - 2016-02-19 08:03:04 --> Output Class Initialized
INFO - 2016-02-19 08:03:04 --> Security Class Initialized
DEBUG - 2016-02-19 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:03:04 --> Input Class Initialized
INFO - 2016-02-19 08:03:05 --> Language Class Initialized
INFO - 2016-02-19 08:03:05 --> Loader Class Initialized
INFO - 2016-02-19 08:03:05 --> Helper loaded: url_helper
INFO - 2016-02-19 08:03:05 --> Helper loaded: file_helper
INFO - 2016-02-19 08:03:05 --> Helper loaded: date_helper
INFO - 2016-02-19 08:03:05 --> Helper loaded: form_helper
INFO - 2016-02-19 08:03:05 --> Database Driver Class Initialized
INFO - 2016-02-19 08:03:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:03:06 --> Controller Class Initialized
INFO - 2016-02-19 08:03:06 --> Model Class Initialized
INFO - 2016-02-19 08:03:06 --> Model Class Initialized
INFO - 2016-02-19 08:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:03:06 --> Pagination Class Initialized
INFO - 2016-02-19 08:03:06 --> Helper loaded: text_helper
INFO - 2016-02-19 08:03:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:03:06 --> Final output sent to browser
DEBUG - 2016-02-19 11:03:06 --> Total execution time: 1.2167
INFO - 2016-02-19 08:03:33 --> Config Class Initialized
INFO - 2016-02-19 08:03:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:03:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:03:33 --> Utf8 Class Initialized
INFO - 2016-02-19 08:03:33 --> URI Class Initialized
INFO - 2016-02-19 08:03:33 --> Router Class Initialized
INFO - 2016-02-19 08:03:33 --> Output Class Initialized
INFO - 2016-02-19 08:03:33 --> Security Class Initialized
DEBUG - 2016-02-19 08:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:03:33 --> Input Class Initialized
INFO - 2016-02-19 08:03:33 --> Language Class Initialized
INFO - 2016-02-19 08:03:33 --> Loader Class Initialized
INFO - 2016-02-19 08:03:33 --> Helper loaded: url_helper
INFO - 2016-02-19 08:03:33 --> Helper loaded: file_helper
INFO - 2016-02-19 08:03:33 --> Helper loaded: date_helper
INFO - 2016-02-19 08:03:33 --> Helper loaded: form_helper
INFO - 2016-02-19 08:03:33 --> Database Driver Class Initialized
INFO - 2016-02-19 08:03:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:03:34 --> Controller Class Initialized
INFO - 2016-02-19 08:03:34 --> Model Class Initialized
INFO - 2016-02-19 08:03:34 --> Model Class Initialized
INFO - 2016-02-19 08:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:03:34 --> Pagination Class Initialized
INFO - 2016-02-19 08:03:34 --> Helper loaded: text_helper
INFO - 2016-02-19 08:03:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:03:34 --> Final output sent to browser
DEBUG - 2016-02-19 11:03:34 --> Total execution time: 1.1808
INFO - 2016-02-19 08:07:12 --> Config Class Initialized
INFO - 2016-02-19 08:07:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:12 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:12 --> URI Class Initialized
INFO - 2016-02-19 08:07:12 --> Router Class Initialized
INFO - 2016-02-19 08:07:12 --> Output Class Initialized
INFO - 2016-02-19 08:07:12 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:12 --> Input Class Initialized
INFO - 2016-02-19 08:07:12 --> Language Class Initialized
INFO - 2016-02-19 08:07:12 --> Loader Class Initialized
INFO - 2016-02-19 08:07:12 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:12 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:12 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:12 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:12 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:14 --> Controller Class Initialized
INFO - 2016-02-19 08:07:14 --> Model Class Initialized
INFO - 2016-02-19 08:07:14 --> Model Class Initialized
INFO - 2016-02-19 08:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:14 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:14 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:14 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:14 --> Total execution time: 1.2811
INFO - 2016-02-19 08:07:25 --> Config Class Initialized
INFO - 2016-02-19 08:07:25 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:25 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:25 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:25 --> URI Class Initialized
INFO - 2016-02-19 08:07:25 --> Router Class Initialized
INFO - 2016-02-19 08:07:25 --> Output Class Initialized
INFO - 2016-02-19 08:07:25 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:25 --> Input Class Initialized
INFO - 2016-02-19 08:07:25 --> Language Class Initialized
INFO - 2016-02-19 08:07:25 --> Loader Class Initialized
INFO - 2016-02-19 08:07:25 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:25 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:25 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:25 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:25 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:26 --> Controller Class Initialized
INFO - 2016-02-19 08:07:26 --> Model Class Initialized
INFO - 2016-02-19 08:07:26 --> Model Class Initialized
INFO - 2016-02-19 08:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:26 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:26 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:26 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:26 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:26 --> Total execution time: 1.2041
INFO - 2016-02-19 08:07:30 --> Config Class Initialized
INFO - 2016-02-19 08:07:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:30 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:30 --> URI Class Initialized
DEBUG - 2016-02-19 08:07:30 --> No URI present. Default controller set.
INFO - 2016-02-19 08:07:30 --> Router Class Initialized
INFO - 2016-02-19 08:07:30 --> Output Class Initialized
INFO - 2016-02-19 08:07:30 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:30 --> Input Class Initialized
INFO - 2016-02-19 08:07:30 --> Language Class Initialized
INFO - 2016-02-19 08:07:30 --> Loader Class Initialized
INFO - 2016-02-19 08:07:30 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:30 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:30 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:30 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:30 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:31 --> Controller Class Initialized
INFO - 2016-02-19 08:07:31 --> Model Class Initialized
INFO - 2016-02-19 08:07:31 --> Model Class Initialized
INFO - 2016-02-19 08:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:31 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:31 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:31 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:31 --> Total execution time: 1.1665
INFO - 2016-02-19 08:07:33 --> Config Class Initialized
INFO - 2016-02-19 08:07:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:33 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:33 --> URI Class Initialized
INFO - 2016-02-19 08:07:33 --> Router Class Initialized
INFO - 2016-02-19 08:07:33 --> Output Class Initialized
INFO - 2016-02-19 08:07:33 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:33 --> Input Class Initialized
INFO - 2016-02-19 08:07:33 --> Language Class Initialized
INFO - 2016-02-19 08:07:33 --> Loader Class Initialized
INFO - 2016-02-19 08:07:33 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:33 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:33 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:33 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:33 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:34 --> Controller Class Initialized
INFO - 2016-02-19 08:07:34 --> Model Class Initialized
INFO - 2016-02-19 08:07:34 --> Model Class Initialized
INFO - 2016-02-19 08:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:34 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:34 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:34 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:34 --> Total execution time: 1.2071
INFO - 2016-02-19 08:07:51 --> Config Class Initialized
INFO - 2016-02-19 08:07:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:51 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:51 --> URI Class Initialized
DEBUG - 2016-02-19 08:07:51 --> No URI present. Default controller set.
INFO - 2016-02-19 08:07:51 --> Router Class Initialized
INFO - 2016-02-19 08:07:51 --> Output Class Initialized
INFO - 2016-02-19 08:07:51 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:51 --> Input Class Initialized
INFO - 2016-02-19 08:07:51 --> Language Class Initialized
INFO - 2016-02-19 08:07:51 --> Loader Class Initialized
INFO - 2016-02-19 08:07:51 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:51 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:51 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:51 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:51 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:52 --> Controller Class Initialized
INFO - 2016-02-19 08:07:52 --> Model Class Initialized
INFO - 2016-02-19 08:07:52 --> Model Class Initialized
INFO - 2016-02-19 08:07:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:52 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:52 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:07:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:52 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:52 --> Total execution time: 1.1081
INFO - 2016-02-19 08:07:54 --> Config Class Initialized
INFO - 2016-02-19 08:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:54 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:54 --> URI Class Initialized
INFO - 2016-02-19 08:07:54 --> Router Class Initialized
INFO - 2016-02-19 08:07:54 --> Output Class Initialized
INFO - 2016-02-19 08:07:54 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:54 --> Input Class Initialized
INFO - 2016-02-19 08:07:54 --> Language Class Initialized
INFO - 2016-02-19 08:07:54 --> Loader Class Initialized
INFO - 2016-02-19 08:07:54 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:54 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:54 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:54 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:54 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:55 --> Controller Class Initialized
INFO - 2016-02-19 08:07:55 --> Model Class Initialized
INFO - 2016-02-19 08:07:55 --> Model Class Initialized
INFO - 2016-02-19 08:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:55 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:55 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:55 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:55 --> Total execution time: 1.1326
INFO - 2016-02-19 08:07:58 --> Config Class Initialized
INFO - 2016-02-19 08:07:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:07:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:07:58 --> Utf8 Class Initialized
INFO - 2016-02-19 08:07:58 --> URI Class Initialized
INFO - 2016-02-19 08:07:58 --> Router Class Initialized
INFO - 2016-02-19 08:07:58 --> Output Class Initialized
INFO - 2016-02-19 08:07:58 --> Security Class Initialized
DEBUG - 2016-02-19 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:07:58 --> Input Class Initialized
INFO - 2016-02-19 08:07:58 --> Language Class Initialized
INFO - 2016-02-19 08:07:58 --> Loader Class Initialized
INFO - 2016-02-19 08:07:58 --> Helper loaded: url_helper
INFO - 2016-02-19 08:07:58 --> Helper loaded: file_helper
INFO - 2016-02-19 08:07:58 --> Helper loaded: date_helper
INFO - 2016-02-19 08:07:58 --> Helper loaded: form_helper
INFO - 2016-02-19 08:07:58 --> Database Driver Class Initialized
INFO - 2016-02-19 08:07:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:07:59 --> Controller Class Initialized
INFO - 2016-02-19 08:07:59 --> Model Class Initialized
INFO - 2016-02-19 08:07:59 --> Model Class Initialized
INFO - 2016-02-19 08:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:07:59 --> Pagination Class Initialized
INFO - 2016-02-19 08:07:59 --> Helper loaded: text_helper
INFO - 2016-02-19 08:07:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:07:59 --> Final output sent to browser
DEBUG - 2016-02-19 11:07:59 --> Total execution time: 1.3314
INFO - 2016-02-19 08:08:35 --> Config Class Initialized
INFO - 2016-02-19 08:08:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:08:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:08:35 --> Utf8 Class Initialized
INFO - 2016-02-19 08:08:35 --> URI Class Initialized
DEBUG - 2016-02-19 08:08:35 --> No URI present. Default controller set.
INFO - 2016-02-19 08:08:35 --> Router Class Initialized
INFO - 2016-02-19 08:08:35 --> Output Class Initialized
INFO - 2016-02-19 08:08:35 --> Security Class Initialized
DEBUG - 2016-02-19 08:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:08:35 --> Input Class Initialized
INFO - 2016-02-19 08:08:35 --> Language Class Initialized
INFO - 2016-02-19 08:08:35 --> Loader Class Initialized
INFO - 2016-02-19 08:08:35 --> Helper loaded: url_helper
INFO - 2016-02-19 08:08:35 --> Helper loaded: file_helper
INFO - 2016-02-19 08:08:35 --> Helper loaded: date_helper
INFO - 2016-02-19 08:08:35 --> Helper loaded: form_helper
INFO - 2016-02-19 08:08:35 --> Database Driver Class Initialized
INFO - 2016-02-19 08:08:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:08:37 --> Controller Class Initialized
INFO - 2016-02-19 08:08:37 --> Model Class Initialized
INFO - 2016-02-19 08:08:37 --> Model Class Initialized
INFO - 2016-02-19 08:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:08:37 --> Pagination Class Initialized
INFO - 2016-02-19 08:08:37 --> Helper loaded: text_helper
INFO - 2016-02-19 08:08:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:08:37 --> Final output sent to browser
DEBUG - 2016-02-19 11:08:37 --> Total execution time: 1.1487
INFO - 2016-02-19 08:08:38 --> Config Class Initialized
INFO - 2016-02-19 08:08:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:08:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:08:38 --> Utf8 Class Initialized
INFO - 2016-02-19 08:08:38 --> URI Class Initialized
INFO - 2016-02-19 08:08:38 --> Router Class Initialized
INFO - 2016-02-19 08:08:38 --> Output Class Initialized
INFO - 2016-02-19 08:08:38 --> Security Class Initialized
DEBUG - 2016-02-19 08:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:08:38 --> Input Class Initialized
INFO - 2016-02-19 08:08:38 --> Language Class Initialized
INFO - 2016-02-19 08:08:38 --> Loader Class Initialized
INFO - 2016-02-19 08:08:38 --> Helper loaded: url_helper
INFO - 2016-02-19 08:08:38 --> Helper loaded: file_helper
INFO - 2016-02-19 08:08:38 --> Helper loaded: date_helper
INFO - 2016-02-19 08:08:38 --> Helper loaded: form_helper
INFO - 2016-02-19 08:08:38 --> Database Driver Class Initialized
INFO - 2016-02-19 08:08:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:08:39 --> Controller Class Initialized
INFO - 2016-02-19 08:08:39 --> Model Class Initialized
INFO - 2016-02-19 08:08:39 --> Model Class Initialized
INFO - 2016-02-19 08:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:08:39 --> Pagination Class Initialized
INFO - 2016-02-19 08:08:39 --> Helper loaded: text_helper
INFO - 2016-02-19 08:08:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:08:39 --> Final output sent to browser
DEBUG - 2016-02-19 11:08:39 --> Total execution time: 1.2104
INFO - 2016-02-19 08:09:05 --> Config Class Initialized
INFO - 2016-02-19 08:09:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:09:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:09:05 --> Utf8 Class Initialized
INFO - 2016-02-19 08:09:05 --> URI Class Initialized
INFO - 2016-02-19 08:09:05 --> Router Class Initialized
INFO - 2016-02-19 08:09:05 --> Output Class Initialized
INFO - 2016-02-19 08:09:05 --> Security Class Initialized
DEBUG - 2016-02-19 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:09:05 --> Input Class Initialized
INFO - 2016-02-19 08:09:05 --> Language Class Initialized
INFO - 2016-02-19 08:09:05 --> Loader Class Initialized
INFO - 2016-02-19 08:09:05 --> Helper loaded: url_helper
INFO - 2016-02-19 08:09:05 --> Helper loaded: file_helper
INFO - 2016-02-19 08:09:05 --> Helper loaded: date_helper
INFO - 2016-02-19 08:09:05 --> Helper loaded: form_helper
INFO - 2016-02-19 08:09:05 --> Database Driver Class Initialized
INFO - 2016-02-19 08:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:09:06 --> Controller Class Initialized
INFO - 2016-02-19 08:09:06 --> Model Class Initialized
INFO - 2016-02-19 08:09:06 --> Model Class Initialized
INFO - 2016-02-19 08:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:09:06 --> Pagination Class Initialized
INFO - 2016-02-19 08:09:06 --> Helper loaded: text_helper
INFO - 2016-02-19 08:09:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:09:06 --> Final output sent to browser
DEBUG - 2016-02-19 11:09:06 --> Total execution time: 1.2080
INFO - 2016-02-19 08:10:38 --> Config Class Initialized
INFO - 2016-02-19 08:10:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:10:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:10:38 --> Utf8 Class Initialized
INFO - 2016-02-19 08:10:38 --> URI Class Initialized
DEBUG - 2016-02-19 08:10:38 --> No URI present. Default controller set.
INFO - 2016-02-19 08:10:38 --> Router Class Initialized
INFO - 2016-02-19 08:10:38 --> Output Class Initialized
INFO - 2016-02-19 08:10:38 --> Security Class Initialized
DEBUG - 2016-02-19 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:10:38 --> Input Class Initialized
INFO - 2016-02-19 08:10:38 --> Language Class Initialized
INFO - 2016-02-19 08:10:38 --> Loader Class Initialized
INFO - 2016-02-19 08:10:38 --> Helper loaded: url_helper
INFO - 2016-02-19 08:10:38 --> Helper loaded: file_helper
INFO - 2016-02-19 08:10:38 --> Helper loaded: date_helper
INFO - 2016-02-19 08:10:38 --> Helper loaded: form_helper
INFO - 2016-02-19 08:10:38 --> Database Driver Class Initialized
INFO - 2016-02-19 08:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:10:39 --> Controller Class Initialized
INFO - 2016-02-19 08:10:39 --> Model Class Initialized
INFO - 2016-02-19 08:10:39 --> Model Class Initialized
INFO - 2016-02-19 08:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:10:39 --> Pagination Class Initialized
INFO - 2016-02-19 08:10:39 --> Helper loaded: text_helper
INFO - 2016-02-19 08:10:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:10:39 --> Final output sent to browser
DEBUG - 2016-02-19 11:10:39 --> Total execution time: 1.1439
INFO - 2016-02-19 08:10:41 --> Config Class Initialized
INFO - 2016-02-19 08:10:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:10:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:10:41 --> Utf8 Class Initialized
INFO - 2016-02-19 08:10:41 --> URI Class Initialized
INFO - 2016-02-19 08:10:41 --> Router Class Initialized
INFO - 2016-02-19 08:10:41 --> Output Class Initialized
INFO - 2016-02-19 08:10:41 --> Security Class Initialized
DEBUG - 2016-02-19 08:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:10:41 --> Input Class Initialized
INFO - 2016-02-19 08:10:41 --> Language Class Initialized
INFO - 2016-02-19 08:10:41 --> Loader Class Initialized
INFO - 2016-02-19 08:10:41 --> Helper loaded: url_helper
INFO - 2016-02-19 08:10:41 --> Helper loaded: file_helper
INFO - 2016-02-19 08:10:41 --> Helper loaded: date_helper
INFO - 2016-02-19 08:10:41 --> Helper loaded: form_helper
INFO - 2016-02-19 08:10:41 --> Database Driver Class Initialized
INFO - 2016-02-19 08:10:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:10:42 --> Controller Class Initialized
INFO - 2016-02-19 08:10:42 --> Model Class Initialized
INFO - 2016-02-19 08:10:42 --> Model Class Initialized
INFO - 2016-02-19 08:10:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:10:42 --> Pagination Class Initialized
INFO - 2016-02-19 08:10:42 --> Helper loaded: text_helper
INFO - 2016-02-19 08:10:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:10:43 --> Final output sent to browser
DEBUG - 2016-02-19 11:10:43 --> Total execution time: 1.2192
INFO - 2016-02-19 08:10:55 --> Config Class Initialized
INFO - 2016-02-19 08:10:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:10:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:10:55 --> Utf8 Class Initialized
INFO - 2016-02-19 08:10:55 --> URI Class Initialized
DEBUG - 2016-02-19 08:10:55 --> No URI present. Default controller set.
INFO - 2016-02-19 08:10:55 --> Router Class Initialized
INFO - 2016-02-19 08:10:55 --> Output Class Initialized
INFO - 2016-02-19 08:10:55 --> Security Class Initialized
DEBUG - 2016-02-19 08:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:10:55 --> Input Class Initialized
INFO - 2016-02-19 08:10:55 --> Language Class Initialized
INFO - 2016-02-19 08:10:55 --> Loader Class Initialized
INFO - 2016-02-19 08:10:55 --> Helper loaded: url_helper
INFO - 2016-02-19 08:10:55 --> Helper loaded: file_helper
INFO - 2016-02-19 08:10:55 --> Helper loaded: date_helper
INFO - 2016-02-19 08:10:55 --> Helper loaded: form_helper
INFO - 2016-02-19 08:10:55 --> Database Driver Class Initialized
INFO - 2016-02-19 08:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:10:56 --> Controller Class Initialized
INFO - 2016-02-19 08:10:56 --> Model Class Initialized
INFO - 2016-02-19 08:10:56 --> Model Class Initialized
INFO - 2016-02-19 08:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:10:57 --> Pagination Class Initialized
INFO - 2016-02-19 08:10:57 --> Helper loaded: text_helper
INFO - 2016-02-19 08:10:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:10:57 --> Final output sent to browser
DEBUG - 2016-02-19 11:10:57 --> Total execution time: 1.1383
INFO - 2016-02-19 08:10:58 --> Config Class Initialized
INFO - 2016-02-19 08:10:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:10:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:10:58 --> Utf8 Class Initialized
INFO - 2016-02-19 08:10:58 --> URI Class Initialized
INFO - 2016-02-19 08:10:58 --> Router Class Initialized
INFO - 2016-02-19 08:10:58 --> Output Class Initialized
INFO - 2016-02-19 08:10:58 --> Security Class Initialized
DEBUG - 2016-02-19 08:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:10:58 --> Input Class Initialized
INFO - 2016-02-19 08:10:58 --> Language Class Initialized
INFO - 2016-02-19 08:10:58 --> Loader Class Initialized
INFO - 2016-02-19 08:10:58 --> Helper loaded: url_helper
INFO - 2016-02-19 08:10:58 --> Helper loaded: file_helper
INFO - 2016-02-19 08:10:58 --> Helper loaded: date_helper
INFO - 2016-02-19 08:10:58 --> Helper loaded: form_helper
INFO - 2016-02-19 08:10:58 --> Database Driver Class Initialized
INFO - 2016-02-19 08:10:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:10:59 --> Controller Class Initialized
INFO - 2016-02-19 08:10:59 --> Model Class Initialized
INFO - 2016-02-19 08:10:59 --> Model Class Initialized
INFO - 2016-02-19 08:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:10:59 --> Pagination Class Initialized
INFO - 2016-02-19 08:10:59 --> Helper loaded: text_helper
INFO - 2016-02-19 08:10:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:10:59 --> Final output sent to browser
DEBUG - 2016-02-19 11:10:59 --> Total execution time: 1.1821
INFO - 2016-02-19 08:11:07 --> Config Class Initialized
INFO - 2016-02-19 08:11:07 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:11:07 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:11:07 --> Utf8 Class Initialized
INFO - 2016-02-19 08:11:07 --> URI Class Initialized
DEBUG - 2016-02-19 08:11:07 --> No URI present. Default controller set.
INFO - 2016-02-19 08:11:07 --> Router Class Initialized
INFO - 2016-02-19 08:11:07 --> Output Class Initialized
INFO - 2016-02-19 08:11:07 --> Security Class Initialized
DEBUG - 2016-02-19 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:11:07 --> Input Class Initialized
INFO - 2016-02-19 08:11:07 --> Language Class Initialized
INFO - 2016-02-19 08:11:07 --> Loader Class Initialized
INFO - 2016-02-19 08:11:07 --> Helper loaded: url_helper
INFO - 2016-02-19 08:11:07 --> Helper loaded: file_helper
INFO - 2016-02-19 08:11:07 --> Helper loaded: date_helper
INFO - 2016-02-19 08:11:07 --> Helper loaded: form_helper
INFO - 2016-02-19 08:11:07 --> Database Driver Class Initialized
INFO - 2016-02-19 08:11:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:11:08 --> Controller Class Initialized
INFO - 2016-02-19 08:11:08 --> Model Class Initialized
INFO - 2016-02-19 08:11:08 --> Model Class Initialized
INFO - 2016-02-19 08:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:11:08 --> Pagination Class Initialized
INFO - 2016-02-19 08:11:08 --> Helper loaded: text_helper
INFO - 2016-02-19 08:11:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:11:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:11:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:11:09 --> Final output sent to browser
DEBUG - 2016-02-19 11:11:09 --> Total execution time: 1.1670
INFO - 2016-02-19 08:11:10 --> Config Class Initialized
INFO - 2016-02-19 08:11:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:11:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:11:10 --> Utf8 Class Initialized
INFO - 2016-02-19 08:11:10 --> URI Class Initialized
INFO - 2016-02-19 08:11:10 --> Router Class Initialized
INFO - 2016-02-19 08:11:10 --> Output Class Initialized
INFO - 2016-02-19 08:11:10 --> Security Class Initialized
DEBUG - 2016-02-19 08:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:11:10 --> Input Class Initialized
INFO - 2016-02-19 08:11:10 --> Language Class Initialized
INFO - 2016-02-19 08:11:10 --> Loader Class Initialized
INFO - 2016-02-19 08:11:10 --> Helper loaded: url_helper
INFO - 2016-02-19 08:11:10 --> Helper loaded: file_helper
INFO - 2016-02-19 08:11:10 --> Helper loaded: date_helper
INFO - 2016-02-19 08:11:10 --> Helper loaded: form_helper
INFO - 2016-02-19 08:11:10 --> Database Driver Class Initialized
INFO - 2016-02-19 08:11:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:11:11 --> Controller Class Initialized
INFO - 2016-02-19 08:11:11 --> Model Class Initialized
INFO - 2016-02-19 08:11:11 --> Model Class Initialized
INFO - 2016-02-19 08:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:11:11 --> Pagination Class Initialized
INFO - 2016-02-19 08:11:11 --> Helper loaded: text_helper
INFO - 2016-02-19 08:11:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:11:11 --> Final output sent to browser
DEBUG - 2016-02-19 11:11:11 --> Total execution time: 1.2076
INFO - 2016-02-19 08:12:35 --> Config Class Initialized
INFO - 2016-02-19 08:12:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:12:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:12:35 --> Utf8 Class Initialized
INFO - 2016-02-19 08:12:35 --> URI Class Initialized
INFO - 2016-02-19 08:12:35 --> Router Class Initialized
INFO - 2016-02-19 08:12:35 --> Output Class Initialized
INFO - 2016-02-19 08:12:35 --> Security Class Initialized
DEBUG - 2016-02-19 08:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:12:35 --> Input Class Initialized
INFO - 2016-02-19 08:12:35 --> Language Class Initialized
INFO - 2016-02-19 08:12:35 --> Loader Class Initialized
INFO - 2016-02-19 08:12:35 --> Helper loaded: url_helper
INFO - 2016-02-19 08:12:35 --> Helper loaded: file_helper
INFO - 2016-02-19 08:12:35 --> Helper loaded: date_helper
INFO - 2016-02-19 08:12:35 --> Helper loaded: form_helper
INFO - 2016-02-19 08:12:35 --> Database Driver Class Initialized
INFO - 2016-02-19 08:12:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:12:36 --> Controller Class Initialized
INFO - 2016-02-19 08:12:36 --> Model Class Initialized
INFO - 2016-02-19 08:12:36 --> Model Class Initialized
INFO - 2016-02-19 08:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:12:36 --> Pagination Class Initialized
INFO - 2016-02-19 08:12:36 --> Helper loaded: text_helper
INFO - 2016-02-19 08:12:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:12:36 --> Final output sent to browser
DEBUG - 2016-02-19 11:12:36 --> Total execution time: 1.2133
INFO - 2016-02-19 08:13:39 --> Config Class Initialized
INFO - 2016-02-19 08:13:39 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:13:39 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:13:39 --> Utf8 Class Initialized
INFO - 2016-02-19 08:13:39 --> URI Class Initialized
DEBUG - 2016-02-19 08:13:39 --> No URI present. Default controller set.
INFO - 2016-02-19 08:13:39 --> Router Class Initialized
INFO - 2016-02-19 08:13:39 --> Output Class Initialized
INFO - 2016-02-19 08:13:39 --> Security Class Initialized
DEBUG - 2016-02-19 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:13:39 --> Input Class Initialized
INFO - 2016-02-19 08:13:39 --> Language Class Initialized
INFO - 2016-02-19 08:13:39 --> Loader Class Initialized
INFO - 2016-02-19 08:13:39 --> Helper loaded: url_helper
INFO - 2016-02-19 08:13:39 --> Helper loaded: file_helper
INFO - 2016-02-19 08:13:39 --> Helper loaded: date_helper
INFO - 2016-02-19 08:13:39 --> Helper loaded: form_helper
INFO - 2016-02-19 08:13:39 --> Database Driver Class Initialized
INFO - 2016-02-19 08:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:13:40 --> Controller Class Initialized
INFO - 2016-02-19 08:13:40 --> Model Class Initialized
INFO - 2016-02-19 08:13:40 --> Model Class Initialized
INFO - 2016-02-19 08:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:13:40 --> Pagination Class Initialized
INFO - 2016-02-19 08:13:40 --> Helper loaded: text_helper
INFO - 2016-02-19 08:13:40 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:13:40 --> Final output sent to browser
DEBUG - 2016-02-19 11:13:40 --> Total execution time: 1.1353
INFO - 2016-02-19 08:13:43 --> Config Class Initialized
INFO - 2016-02-19 08:13:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:13:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:13:43 --> Utf8 Class Initialized
INFO - 2016-02-19 08:13:43 --> URI Class Initialized
INFO - 2016-02-19 08:13:43 --> Router Class Initialized
INFO - 2016-02-19 08:13:43 --> Output Class Initialized
INFO - 2016-02-19 08:13:43 --> Security Class Initialized
DEBUG - 2016-02-19 08:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:13:43 --> Input Class Initialized
INFO - 2016-02-19 08:13:43 --> Language Class Initialized
INFO - 2016-02-19 08:13:43 --> Loader Class Initialized
INFO - 2016-02-19 08:13:43 --> Helper loaded: url_helper
INFO - 2016-02-19 08:13:43 --> Helper loaded: file_helper
INFO - 2016-02-19 08:13:43 --> Helper loaded: date_helper
INFO - 2016-02-19 08:13:43 --> Helper loaded: form_helper
INFO - 2016-02-19 08:13:43 --> Database Driver Class Initialized
INFO - 2016-02-19 08:13:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:13:44 --> Controller Class Initialized
INFO - 2016-02-19 08:13:44 --> Model Class Initialized
INFO - 2016-02-19 08:13:44 --> Model Class Initialized
INFO - 2016-02-19 08:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:13:44 --> Pagination Class Initialized
INFO - 2016-02-19 08:13:44 --> Helper loaded: text_helper
INFO - 2016-02-19 08:13:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:13:44 --> Final output sent to browser
DEBUG - 2016-02-19 11:13:44 --> Total execution time: 1.1477
INFO - 2016-02-19 08:16:51 --> Config Class Initialized
INFO - 2016-02-19 08:16:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:16:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:16:51 --> Utf8 Class Initialized
INFO - 2016-02-19 08:16:51 --> URI Class Initialized
DEBUG - 2016-02-19 08:16:51 --> No URI present. Default controller set.
INFO - 2016-02-19 08:16:51 --> Router Class Initialized
INFO - 2016-02-19 08:16:51 --> Output Class Initialized
INFO - 2016-02-19 08:16:51 --> Security Class Initialized
DEBUG - 2016-02-19 08:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:16:51 --> Input Class Initialized
INFO - 2016-02-19 08:16:51 --> Language Class Initialized
INFO - 2016-02-19 08:16:51 --> Loader Class Initialized
INFO - 2016-02-19 08:16:51 --> Helper loaded: url_helper
INFO - 2016-02-19 08:16:51 --> Helper loaded: file_helper
INFO - 2016-02-19 08:16:51 --> Helper loaded: date_helper
INFO - 2016-02-19 08:16:51 --> Helper loaded: form_helper
INFO - 2016-02-19 08:16:51 --> Database Driver Class Initialized
INFO - 2016-02-19 08:16:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:16:52 --> Controller Class Initialized
INFO - 2016-02-19 08:16:52 --> Model Class Initialized
INFO - 2016-02-19 08:16:52 --> Model Class Initialized
INFO - 2016-02-19 08:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:16:52 --> Pagination Class Initialized
INFO - 2016-02-19 08:16:52 --> Helper loaded: text_helper
INFO - 2016-02-19 08:16:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:16:52 --> Final output sent to browser
DEBUG - 2016-02-19 11:16:52 --> Total execution time: 1.1186
INFO - 2016-02-19 08:16:54 --> Config Class Initialized
INFO - 2016-02-19 08:16:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:16:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:16:54 --> Utf8 Class Initialized
INFO - 2016-02-19 08:16:54 --> URI Class Initialized
INFO - 2016-02-19 08:16:54 --> Router Class Initialized
INFO - 2016-02-19 08:16:54 --> Output Class Initialized
INFO - 2016-02-19 08:16:54 --> Security Class Initialized
DEBUG - 2016-02-19 08:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:16:54 --> Input Class Initialized
INFO - 2016-02-19 08:16:54 --> Language Class Initialized
INFO - 2016-02-19 08:16:54 --> Loader Class Initialized
INFO - 2016-02-19 08:16:54 --> Helper loaded: url_helper
INFO - 2016-02-19 08:16:54 --> Helper loaded: file_helper
INFO - 2016-02-19 08:16:54 --> Helper loaded: date_helper
INFO - 2016-02-19 08:16:54 --> Helper loaded: form_helper
INFO - 2016-02-19 08:16:54 --> Database Driver Class Initialized
INFO - 2016-02-19 08:16:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:16:55 --> Controller Class Initialized
INFO - 2016-02-19 08:16:55 --> Model Class Initialized
INFO - 2016-02-19 08:16:55 --> Model Class Initialized
INFO - 2016-02-19 08:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:16:55 --> Pagination Class Initialized
INFO - 2016-02-19 08:16:55 --> Helper loaded: text_helper
INFO - 2016-02-19 08:16:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:16:55 --> Final output sent to browser
DEBUG - 2016-02-19 11:16:55 --> Total execution time: 1.1779
INFO - 2016-02-19 08:19:11 --> Config Class Initialized
INFO - 2016-02-19 08:19:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:19:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:19:11 --> Utf8 Class Initialized
INFO - 2016-02-19 08:19:11 --> URI Class Initialized
INFO - 2016-02-19 08:19:11 --> Router Class Initialized
INFO - 2016-02-19 08:19:11 --> Output Class Initialized
INFO - 2016-02-19 08:19:11 --> Security Class Initialized
DEBUG - 2016-02-19 08:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:19:11 --> Input Class Initialized
INFO - 2016-02-19 08:19:11 --> Language Class Initialized
INFO - 2016-02-19 08:19:11 --> Loader Class Initialized
INFO - 2016-02-19 08:19:11 --> Helper loaded: url_helper
INFO - 2016-02-19 08:19:11 --> Helper loaded: file_helper
INFO - 2016-02-19 08:19:11 --> Helper loaded: date_helper
INFO - 2016-02-19 08:19:11 --> Helper loaded: form_helper
INFO - 2016-02-19 08:19:11 --> Database Driver Class Initialized
INFO - 2016-02-19 08:19:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:19:12 --> Controller Class Initialized
INFO - 2016-02-19 08:19:12 --> Model Class Initialized
INFO - 2016-02-19 08:19:12 --> Model Class Initialized
INFO - 2016-02-19 08:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:19:12 --> Pagination Class Initialized
INFO - 2016-02-19 08:19:12 --> Helper loaded: text_helper
INFO - 2016-02-19 08:19:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:19:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:19:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:19:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:19:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:19:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:19:12 --> Final output sent to browser
DEBUG - 2016-02-19 11:19:12 --> Total execution time: 1.1471
INFO - 2016-02-19 08:25:32 --> Config Class Initialized
INFO - 2016-02-19 08:25:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:25:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:25:32 --> Utf8 Class Initialized
INFO - 2016-02-19 08:25:32 --> URI Class Initialized
INFO - 2016-02-19 08:25:32 --> Router Class Initialized
INFO - 2016-02-19 08:25:32 --> Output Class Initialized
INFO - 2016-02-19 08:25:32 --> Security Class Initialized
DEBUG - 2016-02-19 08:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:25:32 --> Input Class Initialized
INFO - 2016-02-19 08:25:32 --> Language Class Initialized
INFO - 2016-02-19 08:25:32 --> Loader Class Initialized
INFO - 2016-02-19 08:25:32 --> Helper loaded: url_helper
INFO - 2016-02-19 08:25:32 --> Helper loaded: file_helper
INFO - 2016-02-19 08:25:32 --> Helper loaded: date_helper
INFO - 2016-02-19 08:25:32 --> Helper loaded: form_helper
INFO - 2016-02-19 08:25:32 --> Database Driver Class Initialized
INFO - 2016-02-19 08:25:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:25:33 --> Controller Class Initialized
INFO - 2016-02-19 08:25:33 --> Model Class Initialized
INFO - 2016-02-19 08:25:33 --> Model Class Initialized
INFO - 2016-02-19 08:25:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:25:33 --> Pagination Class Initialized
INFO - 2016-02-19 08:25:33 --> Helper loaded: text_helper
INFO - 2016-02-19 08:25:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:25:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:25:33 --> Final output sent to browser
DEBUG - 2016-02-19 11:25:33 --> Total execution time: 1.1828
INFO - 2016-02-19 08:28:02 --> Config Class Initialized
INFO - 2016-02-19 08:28:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:28:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:28:02 --> Utf8 Class Initialized
INFO - 2016-02-19 08:28:02 --> URI Class Initialized
DEBUG - 2016-02-19 08:28:02 --> No URI present. Default controller set.
INFO - 2016-02-19 08:28:02 --> Router Class Initialized
INFO - 2016-02-19 08:28:02 --> Output Class Initialized
INFO - 2016-02-19 08:28:02 --> Security Class Initialized
DEBUG - 2016-02-19 08:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:28:02 --> Input Class Initialized
INFO - 2016-02-19 08:28:02 --> Language Class Initialized
INFO - 2016-02-19 08:28:02 --> Loader Class Initialized
INFO - 2016-02-19 08:28:02 --> Helper loaded: url_helper
INFO - 2016-02-19 08:28:02 --> Helper loaded: file_helper
INFO - 2016-02-19 08:28:02 --> Helper loaded: date_helper
INFO - 2016-02-19 08:28:02 --> Helper loaded: form_helper
INFO - 2016-02-19 08:28:02 --> Database Driver Class Initialized
INFO - 2016-02-19 08:28:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:28:03 --> Controller Class Initialized
INFO - 2016-02-19 08:28:03 --> Model Class Initialized
INFO - 2016-02-19 08:28:03 --> Model Class Initialized
INFO - 2016-02-19 08:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:28:03 --> Pagination Class Initialized
INFO - 2016-02-19 08:28:03 --> Helper loaded: text_helper
INFO - 2016-02-19 08:28:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:28:03 --> Final output sent to browser
DEBUG - 2016-02-19 11:28:03 --> Total execution time: 1.1256
INFO - 2016-02-19 08:28:05 --> Config Class Initialized
INFO - 2016-02-19 08:28:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:28:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:28:05 --> Utf8 Class Initialized
INFO - 2016-02-19 08:28:05 --> URI Class Initialized
INFO - 2016-02-19 08:28:05 --> Router Class Initialized
INFO - 2016-02-19 08:28:05 --> Output Class Initialized
INFO - 2016-02-19 08:28:05 --> Security Class Initialized
DEBUG - 2016-02-19 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:28:05 --> Input Class Initialized
INFO - 2016-02-19 08:28:05 --> Language Class Initialized
INFO - 2016-02-19 08:28:05 --> Loader Class Initialized
INFO - 2016-02-19 08:28:05 --> Helper loaded: url_helper
INFO - 2016-02-19 08:28:05 --> Helper loaded: file_helper
INFO - 2016-02-19 08:28:05 --> Helper loaded: date_helper
INFO - 2016-02-19 08:28:05 --> Helper loaded: form_helper
INFO - 2016-02-19 08:28:05 --> Database Driver Class Initialized
INFO - 2016-02-19 08:28:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:28:06 --> Controller Class Initialized
INFO - 2016-02-19 08:28:06 --> Model Class Initialized
INFO - 2016-02-19 08:28:06 --> Model Class Initialized
INFO - 2016-02-19 08:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:28:06 --> Pagination Class Initialized
INFO - 2016-02-19 08:28:06 --> Helper loaded: text_helper
INFO - 2016-02-19 08:28:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:28:06 --> Final output sent to browser
DEBUG - 2016-02-19 11:28:06 --> Total execution time: 1.2636
INFO - 2016-02-19 08:28:34 --> Config Class Initialized
INFO - 2016-02-19 08:28:34 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:28:34 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:28:34 --> Utf8 Class Initialized
INFO - 2016-02-19 08:28:34 --> URI Class Initialized
INFO - 2016-02-19 08:28:34 --> Router Class Initialized
INFO - 2016-02-19 08:28:34 --> Output Class Initialized
INFO - 2016-02-19 08:28:34 --> Security Class Initialized
DEBUG - 2016-02-19 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:28:34 --> Input Class Initialized
INFO - 2016-02-19 08:28:34 --> Language Class Initialized
INFO - 2016-02-19 08:28:34 --> Loader Class Initialized
INFO - 2016-02-19 08:28:34 --> Helper loaded: url_helper
INFO - 2016-02-19 08:28:34 --> Helper loaded: file_helper
INFO - 2016-02-19 08:28:34 --> Helper loaded: date_helper
INFO - 2016-02-19 08:28:34 --> Helper loaded: form_helper
INFO - 2016-02-19 08:28:34 --> Database Driver Class Initialized
INFO - 2016-02-19 08:28:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:28:35 --> Controller Class Initialized
INFO - 2016-02-19 08:28:35 --> Model Class Initialized
INFO - 2016-02-19 08:28:35 --> Model Class Initialized
INFO - 2016-02-19 08:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:28:35 --> Pagination Class Initialized
INFO - 2016-02-19 08:28:35 --> Helper loaded: text_helper
INFO - 2016-02-19 08:28:35 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:28:35 --> Final output sent to browser
DEBUG - 2016-02-19 11:28:35 --> Total execution time: 1.2294
INFO - 2016-02-19 08:28:43 --> Config Class Initialized
INFO - 2016-02-19 08:28:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:28:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:28:43 --> Utf8 Class Initialized
INFO - 2016-02-19 08:28:43 --> URI Class Initialized
INFO - 2016-02-19 08:28:43 --> Router Class Initialized
INFO - 2016-02-19 08:28:43 --> Output Class Initialized
INFO - 2016-02-19 08:28:43 --> Security Class Initialized
DEBUG - 2016-02-19 08:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:28:43 --> Input Class Initialized
INFO - 2016-02-19 08:28:43 --> Language Class Initialized
INFO - 2016-02-19 08:28:43 --> Loader Class Initialized
INFO - 2016-02-19 08:28:43 --> Helper loaded: url_helper
INFO - 2016-02-19 08:28:43 --> Helper loaded: file_helper
INFO - 2016-02-19 08:28:43 --> Helper loaded: date_helper
INFO - 2016-02-19 08:28:43 --> Helper loaded: form_helper
INFO - 2016-02-19 08:28:43 --> Database Driver Class Initialized
INFO - 2016-02-19 08:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:28:44 --> Controller Class Initialized
INFO - 2016-02-19 08:28:44 --> Model Class Initialized
INFO - 2016-02-19 08:28:44 --> Model Class Initialized
INFO - 2016-02-19 08:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:28:44 --> Pagination Class Initialized
INFO - 2016-02-19 08:28:44 --> Helper loaded: text_helper
INFO - 2016-02-19 08:28:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:28:44 --> Final output sent to browser
DEBUG - 2016-02-19 11:28:44 --> Total execution time: 1.2475
INFO - 2016-02-19 08:32:52 --> Config Class Initialized
INFO - 2016-02-19 08:32:52 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:32:52 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:32:52 --> Utf8 Class Initialized
INFO - 2016-02-19 08:32:52 --> URI Class Initialized
DEBUG - 2016-02-19 08:32:52 --> No URI present. Default controller set.
INFO - 2016-02-19 08:32:52 --> Router Class Initialized
INFO - 2016-02-19 08:32:52 --> Output Class Initialized
INFO - 2016-02-19 08:32:52 --> Security Class Initialized
DEBUG - 2016-02-19 08:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:32:52 --> Input Class Initialized
INFO - 2016-02-19 08:32:52 --> Language Class Initialized
INFO - 2016-02-19 08:32:52 --> Loader Class Initialized
INFO - 2016-02-19 08:32:52 --> Helper loaded: url_helper
INFO - 2016-02-19 08:32:52 --> Helper loaded: file_helper
INFO - 2016-02-19 08:32:52 --> Helper loaded: date_helper
INFO - 2016-02-19 08:32:52 --> Helper loaded: form_helper
INFO - 2016-02-19 08:32:52 --> Database Driver Class Initialized
INFO - 2016-02-19 08:32:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:32:53 --> Controller Class Initialized
INFO - 2016-02-19 08:32:53 --> Model Class Initialized
INFO - 2016-02-19 08:32:53 --> Model Class Initialized
INFO - 2016-02-19 08:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:32:53 --> Pagination Class Initialized
INFO - 2016-02-19 08:32:53 --> Helper loaded: text_helper
INFO - 2016-02-19 08:32:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:32:53 --> Final output sent to browser
DEBUG - 2016-02-19 11:32:53 --> Total execution time: 1.1141
INFO - 2016-02-19 08:32:55 --> Config Class Initialized
INFO - 2016-02-19 08:32:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:32:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:32:55 --> Utf8 Class Initialized
INFO - 2016-02-19 08:32:55 --> URI Class Initialized
INFO - 2016-02-19 08:32:55 --> Router Class Initialized
INFO - 2016-02-19 08:32:55 --> Output Class Initialized
INFO - 2016-02-19 08:32:55 --> Security Class Initialized
DEBUG - 2016-02-19 08:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:32:55 --> Input Class Initialized
INFO - 2016-02-19 08:32:55 --> Language Class Initialized
INFO - 2016-02-19 08:32:55 --> Loader Class Initialized
INFO - 2016-02-19 08:32:55 --> Helper loaded: url_helper
INFO - 2016-02-19 08:32:55 --> Helper loaded: file_helper
INFO - 2016-02-19 08:32:55 --> Helper loaded: date_helper
INFO - 2016-02-19 08:32:55 --> Helper loaded: form_helper
INFO - 2016-02-19 08:32:55 --> Database Driver Class Initialized
INFO - 2016-02-19 08:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:32:56 --> Controller Class Initialized
INFO - 2016-02-19 08:32:56 --> Model Class Initialized
INFO - 2016-02-19 08:32:56 --> Model Class Initialized
INFO - 2016-02-19 08:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:32:56 --> Pagination Class Initialized
INFO - 2016-02-19 08:32:56 --> Helper loaded: text_helper
INFO - 2016-02-19 08:32:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:32:56 --> Final output sent to browser
DEBUG - 2016-02-19 11:32:56 --> Total execution time: 1.1940
INFO - 2016-02-19 08:33:55 --> Config Class Initialized
INFO - 2016-02-19 08:33:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:33:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:33:55 --> Utf8 Class Initialized
INFO - 2016-02-19 08:33:55 --> URI Class Initialized
INFO - 2016-02-19 08:33:55 --> Router Class Initialized
INFO - 2016-02-19 08:33:55 --> Output Class Initialized
INFO - 2016-02-19 08:33:55 --> Security Class Initialized
DEBUG - 2016-02-19 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:33:55 --> Input Class Initialized
INFO - 2016-02-19 08:33:55 --> Language Class Initialized
INFO - 2016-02-19 08:33:55 --> Loader Class Initialized
INFO - 2016-02-19 08:33:55 --> Helper loaded: url_helper
INFO - 2016-02-19 08:33:55 --> Helper loaded: file_helper
INFO - 2016-02-19 08:33:55 --> Helper loaded: date_helper
INFO - 2016-02-19 08:33:55 --> Helper loaded: form_helper
INFO - 2016-02-19 08:33:55 --> Database Driver Class Initialized
INFO - 2016-02-19 08:33:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:33:56 --> Controller Class Initialized
INFO - 2016-02-19 08:33:56 --> Model Class Initialized
INFO - 2016-02-19 08:33:56 --> Model Class Initialized
INFO - 2016-02-19 08:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:33:56 --> Pagination Class Initialized
INFO - 2016-02-19 08:33:56 --> Helper loaded: text_helper
INFO - 2016-02-19 08:33:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:33:56 --> Final output sent to browser
DEBUG - 2016-02-19 11:33:56 --> Total execution time: 1.2025
INFO - 2016-02-19 08:34:23 --> Config Class Initialized
INFO - 2016-02-19 08:34:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:34:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:34:23 --> Utf8 Class Initialized
INFO - 2016-02-19 08:34:23 --> URI Class Initialized
INFO - 2016-02-19 08:34:23 --> Router Class Initialized
INFO - 2016-02-19 08:34:23 --> Output Class Initialized
INFO - 2016-02-19 08:34:23 --> Security Class Initialized
DEBUG - 2016-02-19 08:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:34:23 --> Input Class Initialized
INFO - 2016-02-19 08:34:23 --> Language Class Initialized
INFO - 2016-02-19 08:34:23 --> Loader Class Initialized
INFO - 2016-02-19 08:34:23 --> Helper loaded: url_helper
INFO - 2016-02-19 08:34:23 --> Helper loaded: file_helper
INFO - 2016-02-19 08:34:23 --> Helper loaded: date_helper
INFO - 2016-02-19 08:34:23 --> Helper loaded: form_helper
INFO - 2016-02-19 08:34:23 --> Database Driver Class Initialized
INFO - 2016-02-19 08:34:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:34:24 --> Controller Class Initialized
INFO - 2016-02-19 08:34:24 --> Model Class Initialized
INFO - 2016-02-19 08:34:24 --> Model Class Initialized
INFO - 2016-02-19 08:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:34:24 --> Pagination Class Initialized
INFO - 2016-02-19 08:34:24 --> Helper loaded: text_helper
INFO - 2016-02-19 08:34:24 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:34:24 --> Final output sent to browser
DEBUG - 2016-02-19 11:34:24 --> Total execution time: 1.2417
INFO - 2016-02-19 08:36:49 --> Config Class Initialized
INFO - 2016-02-19 08:36:49 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:36:49 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:36:49 --> Utf8 Class Initialized
INFO - 2016-02-19 08:36:49 --> URI Class Initialized
INFO - 2016-02-19 08:36:49 --> Router Class Initialized
INFO - 2016-02-19 08:36:49 --> Output Class Initialized
INFO - 2016-02-19 08:36:49 --> Security Class Initialized
DEBUG - 2016-02-19 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:36:49 --> Input Class Initialized
INFO - 2016-02-19 08:36:49 --> Language Class Initialized
INFO - 2016-02-19 08:36:49 --> Loader Class Initialized
INFO - 2016-02-19 08:36:49 --> Helper loaded: url_helper
INFO - 2016-02-19 08:36:49 --> Helper loaded: file_helper
INFO - 2016-02-19 08:36:49 --> Helper loaded: date_helper
INFO - 2016-02-19 08:36:49 --> Helper loaded: form_helper
INFO - 2016-02-19 08:36:49 --> Database Driver Class Initialized
INFO - 2016-02-19 08:36:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:36:50 --> Controller Class Initialized
INFO - 2016-02-19 08:36:50 --> Model Class Initialized
INFO - 2016-02-19 08:36:50 --> Model Class Initialized
INFO - 2016-02-19 08:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:36:50 --> Pagination Class Initialized
INFO - 2016-02-19 08:36:50 --> Helper loaded: text_helper
INFO - 2016-02-19 08:36:50 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:36:50 --> Final output sent to browser
DEBUG - 2016-02-19 11:36:50 --> Total execution time: 1.2062
INFO - 2016-02-19 08:37:14 --> Config Class Initialized
INFO - 2016-02-19 08:37:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:37:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:37:14 --> Utf8 Class Initialized
INFO - 2016-02-19 08:37:14 --> URI Class Initialized
INFO - 2016-02-19 08:37:14 --> Router Class Initialized
INFO - 2016-02-19 08:37:14 --> Output Class Initialized
INFO - 2016-02-19 08:37:14 --> Security Class Initialized
DEBUG - 2016-02-19 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:37:14 --> Input Class Initialized
INFO - 2016-02-19 08:37:14 --> Language Class Initialized
INFO - 2016-02-19 08:37:14 --> Loader Class Initialized
INFO - 2016-02-19 08:37:14 --> Helper loaded: url_helper
INFO - 2016-02-19 08:37:14 --> Helper loaded: file_helper
INFO - 2016-02-19 08:37:14 --> Helper loaded: date_helper
INFO - 2016-02-19 08:37:14 --> Helper loaded: form_helper
INFO - 2016-02-19 08:37:14 --> Database Driver Class Initialized
INFO - 2016-02-19 08:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:37:15 --> Controller Class Initialized
INFO - 2016-02-19 08:37:15 --> Model Class Initialized
INFO - 2016-02-19 08:37:15 --> Model Class Initialized
INFO - 2016-02-19 08:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:37:15 --> Pagination Class Initialized
INFO - 2016-02-19 08:37:15 --> Helper loaded: text_helper
INFO - 2016-02-19 08:37:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:37:15 --> Final output sent to browser
DEBUG - 2016-02-19 11:37:15 --> Total execution time: 1.2259
INFO - 2016-02-19 08:37:44 --> Config Class Initialized
INFO - 2016-02-19 08:37:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:37:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:37:44 --> Utf8 Class Initialized
INFO - 2016-02-19 08:37:44 --> URI Class Initialized
INFO - 2016-02-19 08:37:44 --> Router Class Initialized
INFO - 2016-02-19 08:37:44 --> Output Class Initialized
INFO - 2016-02-19 08:37:44 --> Security Class Initialized
DEBUG - 2016-02-19 08:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:37:44 --> Input Class Initialized
INFO - 2016-02-19 08:37:44 --> Language Class Initialized
INFO - 2016-02-19 08:37:44 --> Loader Class Initialized
INFO - 2016-02-19 08:37:44 --> Helper loaded: url_helper
INFO - 2016-02-19 08:37:44 --> Helper loaded: file_helper
INFO - 2016-02-19 08:37:44 --> Helper loaded: date_helper
INFO - 2016-02-19 08:37:44 --> Helper loaded: form_helper
INFO - 2016-02-19 08:37:44 --> Database Driver Class Initialized
INFO - 2016-02-19 08:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:37:45 --> Controller Class Initialized
INFO - 2016-02-19 08:37:45 --> Model Class Initialized
INFO - 2016-02-19 08:37:45 --> Model Class Initialized
INFO - 2016-02-19 08:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:37:45 --> Pagination Class Initialized
INFO - 2016-02-19 08:37:45 --> Helper loaded: text_helper
INFO - 2016-02-19 08:37:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:37:45 --> Final output sent to browser
DEBUG - 2016-02-19 11:37:45 --> Total execution time: 1.1893
INFO - 2016-02-19 08:37:59 --> Config Class Initialized
INFO - 2016-02-19 08:37:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:37:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:37:59 --> Utf8 Class Initialized
INFO - 2016-02-19 08:37:59 --> URI Class Initialized
DEBUG - 2016-02-19 08:37:59 --> No URI present. Default controller set.
INFO - 2016-02-19 08:37:59 --> Router Class Initialized
INFO - 2016-02-19 08:37:59 --> Output Class Initialized
INFO - 2016-02-19 08:37:59 --> Security Class Initialized
DEBUG - 2016-02-19 08:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:37:59 --> Input Class Initialized
INFO - 2016-02-19 08:37:59 --> Language Class Initialized
INFO - 2016-02-19 08:37:59 --> Loader Class Initialized
INFO - 2016-02-19 08:37:59 --> Helper loaded: url_helper
INFO - 2016-02-19 08:37:59 --> Helper loaded: file_helper
INFO - 2016-02-19 08:37:59 --> Helper loaded: date_helper
INFO - 2016-02-19 08:37:59 --> Helper loaded: form_helper
INFO - 2016-02-19 08:37:59 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:00 --> Controller Class Initialized
INFO - 2016-02-19 08:38:00 --> Model Class Initialized
INFO - 2016-02-19 08:38:00 --> Model Class Initialized
INFO - 2016-02-19 08:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:00 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:00 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:00 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:00 --> Total execution time: 1.1123
INFO - 2016-02-19 08:38:02 --> Config Class Initialized
INFO - 2016-02-19 08:38:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:38:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:38:02 --> Utf8 Class Initialized
INFO - 2016-02-19 08:38:02 --> URI Class Initialized
INFO - 2016-02-19 08:38:02 --> Router Class Initialized
INFO - 2016-02-19 08:38:02 --> Output Class Initialized
INFO - 2016-02-19 08:38:02 --> Security Class Initialized
DEBUG - 2016-02-19 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:38:02 --> Input Class Initialized
INFO - 2016-02-19 08:38:02 --> Language Class Initialized
INFO - 2016-02-19 08:38:02 --> Loader Class Initialized
INFO - 2016-02-19 08:38:02 --> Helper loaded: url_helper
INFO - 2016-02-19 08:38:02 --> Helper loaded: file_helper
INFO - 2016-02-19 08:38:02 --> Helper loaded: date_helper
INFO - 2016-02-19 08:38:02 --> Helper loaded: form_helper
INFO - 2016-02-19 08:38:02 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:03 --> Controller Class Initialized
INFO - 2016-02-19 08:38:03 --> Model Class Initialized
INFO - 2016-02-19 08:38:03 --> Model Class Initialized
INFO - 2016-02-19 08:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:03 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:03 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:03 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:03 --> Total execution time: 1.1776
INFO - 2016-02-19 08:38:05 --> Config Class Initialized
INFO - 2016-02-19 08:38:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:38:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:38:05 --> Utf8 Class Initialized
INFO - 2016-02-19 08:38:05 --> URI Class Initialized
DEBUG - 2016-02-19 08:38:05 --> No URI present. Default controller set.
INFO - 2016-02-19 08:38:05 --> Router Class Initialized
INFO - 2016-02-19 08:38:05 --> Output Class Initialized
INFO - 2016-02-19 08:38:05 --> Security Class Initialized
DEBUG - 2016-02-19 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:38:05 --> Input Class Initialized
INFO - 2016-02-19 08:38:05 --> Language Class Initialized
INFO - 2016-02-19 08:38:05 --> Loader Class Initialized
INFO - 2016-02-19 08:38:05 --> Helper loaded: url_helper
INFO - 2016-02-19 08:38:05 --> Helper loaded: file_helper
INFO - 2016-02-19 08:38:05 --> Helper loaded: date_helper
INFO - 2016-02-19 08:38:05 --> Helper loaded: form_helper
INFO - 2016-02-19 08:38:05 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:06 --> Controller Class Initialized
INFO - 2016-02-19 08:38:06 --> Model Class Initialized
INFO - 2016-02-19 08:38:06 --> Model Class Initialized
INFO - 2016-02-19 08:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:06 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:06 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:06 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:06 --> Total execution time: 1.1303
INFO - 2016-02-19 08:38:07 --> Config Class Initialized
INFO - 2016-02-19 08:38:07 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:38:07 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:38:07 --> Utf8 Class Initialized
INFO - 2016-02-19 08:38:07 --> URI Class Initialized
INFO - 2016-02-19 08:38:07 --> Router Class Initialized
INFO - 2016-02-19 08:38:07 --> Output Class Initialized
INFO - 2016-02-19 08:38:07 --> Security Class Initialized
DEBUG - 2016-02-19 08:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:38:07 --> Input Class Initialized
INFO - 2016-02-19 08:38:07 --> Language Class Initialized
INFO - 2016-02-19 08:38:07 --> Loader Class Initialized
INFO - 2016-02-19 08:38:07 --> Helper loaded: url_helper
INFO - 2016-02-19 08:38:07 --> Helper loaded: file_helper
INFO - 2016-02-19 08:38:07 --> Helper loaded: date_helper
INFO - 2016-02-19 08:38:07 --> Helper loaded: form_helper
INFO - 2016-02-19 08:38:07 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:08 --> Controller Class Initialized
INFO - 2016-02-19 08:38:08 --> Model Class Initialized
INFO - 2016-02-19 08:38:08 --> Model Class Initialized
INFO - 2016-02-19 08:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:08 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:08 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:08 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:08 --> Total execution time: 1.1925
INFO - 2016-02-19 08:38:33 --> Config Class Initialized
INFO - 2016-02-19 08:38:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:38:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:38:33 --> Utf8 Class Initialized
INFO - 2016-02-19 08:38:33 --> URI Class Initialized
DEBUG - 2016-02-19 08:38:33 --> No URI present. Default controller set.
INFO - 2016-02-19 08:38:33 --> Router Class Initialized
INFO - 2016-02-19 08:38:33 --> Output Class Initialized
INFO - 2016-02-19 08:38:33 --> Security Class Initialized
DEBUG - 2016-02-19 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:38:33 --> Input Class Initialized
INFO - 2016-02-19 08:38:33 --> Language Class Initialized
INFO - 2016-02-19 08:38:33 --> Loader Class Initialized
INFO - 2016-02-19 08:38:33 --> Helper loaded: url_helper
INFO - 2016-02-19 08:38:33 --> Helper loaded: file_helper
INFO - 2016-02-19 08:38:33 --> Helper loaded: date_helper
INFO - 2016-02-19 08:38:33 --> Helper loaded: form_helper
INFO - 2016-02-19 08:38:33 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:34 --> Controller Class Initialized
INFO - 2016-02-19 08:38:34 --> Model Class Initialized
INFO - 2016-02-19 08:38:34 --> Model Class Initialized
INFO - 2016-02-19 08:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:34 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:34 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:38:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:34 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:34 --> Total execution time: 1.1721
INFO - 2016-02-19 08:38:36 --> Config Class Initialized
INFO - 2016-02-19 08:38:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:38:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:38:36 --> Utf8 Class Initialized
INFO - 2016-02-19 08:38:36 --> URI Class Initialized
INFO - 2016-02-19 08:38:36 --> Router Class Initialized
INFO - 2016-02-19 08:38:36 --> Output Class Initialized
INFO - 2016-02-19 08:38:36 --> Security Class Initialized
DEBUG - 2016-02-19 08:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:38:36 --> Input Class Initialized
INFO - 2016-02-19 08:38:36 --> Language Class Initialized
INFO - 2016-02-19 08:38:36 --> Loader Class Initialized
INFO - 2016-02-19 08:38:36 --> Helper loaded: url_helper
INFO - 2016-02-19 08:38:36 --> Helper loaded: file_helper
INFO - 2016-02-19 08:38:36 --> Helper loaded: date_helper
INFO - 2016-02-19 08:38:36 --> Helper loaded: form_helper
INFO - 2016-02-19 08:38:36 --> Database Driver Class Initialized
INFO - 2016-02-19 08:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:38:37 --> Controller Class Initialized
INFO - 2016-02-19 08:38:37 --> Model Class Initialized
INFO - 2016-02-19 08:38:37 --> Model Class Initialized
INFO - 2016-02-19 08:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:38:37 --> Pagination Class Initialized
INFO - 2016-02-19 08:38:37 --> Helper loaded: text_helper
INFO - 2016-02-19 08:38:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:38:38 --> Final output sent to browser
DEBUG - 2016-02-19 11:38:38 --> Total execution time: 1.2515
INFO - 2016-02-19 08:39:29 --> Config Class Initialized
INFO - 2016-02-19 08:39:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:39:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:39:29 --> Utf8 Class Initialized
INFO - 2016-02-19 08:39:29 --> URI Class Initialized
INFO - 2016-02-19 08:39:29 --> Router Class Initialized
INFO - 2016-02-19 08:39:29 --> Output Class Initialized
INFO - 2016-02-19 08:39:29 --> Security Class Initialized
DEBUG - 2016-02-19 08:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:39:29 --> Input Class Initialized
INFO - 2016-02-19 08:39:29 --> Language Class Initialized
INFO - 2016-02-19 08:39:29 --> Loader Class Initialized
INFO - 2016-02-19 08:39:29 --> Helper loaded: url_helper
INFO - 2016-02-19 08:39:29 --> Helper loaded: file_helper
INFO - 2016-02-19 08:39:29 --> Helper loaded: date_helper
INFO - 2016-02-19 08:39:29 --> Helper loaded: form_helper
INFO - 2016-02-19 08:39:29 --> Database Driver Class Initialized
INFO - 2016-02-19 08:39:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:39:30 --> Controller Class Initialized
INFO - 2016-02-19 08:39:30 --> Model Class Initialized
INFO - 2016-02-19 08:39:30 --> Model Class Initialized
INFO - 2016-02-19 08:39:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:39:30 --> Pagination Class Initialized
INFO - 2016-02-19 08:39:30 --> Helper loaded: text_helper
INFO - 2016-02-19 08:39:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:39:30 --> Final output sent to browser
DEBUG - 2016-02-19 11:39:30 --> Total execution time: 1.1807
INFO - 2016-02-19 08:39:34 --> Config Class Initialized
INFO - 2016-02-19 08:39:34 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:39:34 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:39:34 --> Utf8 Class Initialized
INFO - 2016-02-19 08:39:34 --> URI Class Initialized
DEBUG - 2016-02-19 08:39:34 --> No URI present. Default controller set.
INFO - 2016-02-19 08:39:34 --> Router Class Initialized
INFO - 2016-02-19 08:39:34 --> Output Class Initialized
INFO - 2016-02-19 08:39:34 --> Security Class Initialized
DEBUG - 2016-02-19 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:39:34 --> Input Class Initialized
INFO - 2016-02-19 08:39:34 --> Language Class Initialized
INFO - 2016-02-19 08:39:34 --> Loader Class Initialized
INFO - 2016-02-19 08:39:34 --> Helper loaded: url_helper
INFO - 2016-02-19 08:39:34 --> Helper loaded: file_helper
INFO - 2016-02-19 08:39:34 --> Helper loaded: date_helper
INFO - 2016-02-19 08:39:34 --> Helper loaded: form_helper
INFO - 2016-02-19 08:39:34 --> Database Driver Class Initialized
INFO - 2016-02-19 08:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:39:35 --> Controller Class Initialized
INFO - 2016-02-19 08:39:35 --> Model Class Initialized
INFO - 2016-02-19 08:39:35 --> Model Class Initialized
INFO - 2016-02-19 08:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:39:35 --> Pagination Class Initialized
INFO - 2016-02-19 08:39:35 --> Helper loaded: text_helper
INFO - 2016-02-19 08:39:35 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:39:35 --> Final output sent to browser
DEBUG - 2016-02-19 11:39:35 --> Total execution time: 1.1738
INFO - 2016-02-19 08:39:36 --> Config Class Initialized
INFO - 2016-02-19 08:39:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:39:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:39:36 --> Utf8 Class Initialized
INFO - 2016-02-19 08:39:36 --> URI Class Initialized
INFO - 2016-02-19 08:39:36 --> Router Class Initialized
INFO - 2016-02-19 08:39:36 --> Output Class Initialized
INFO - 2016-02-19 08:39:36 --> Security Class Initialized
DEBUG - 2016-02-19 08:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:39:36 --> Input Class Initialized
INFO - 2016-02-19 08:39:36 --> Language Class Initialized
INFO - 2016-02-19 08:39:37 --> Loader Class Initialized
INFO - 2016-02-19 08:39:37 --> Helper loaded: url_helper
INFO - 2016-02-19 08:39:37 --> Helper loaded: file_helper
INFO - 2016-02-19 08:39:37 --> Helper loaded: date_helper
INFO - 2016-02-19 08:39:37 --> Helper loaded: form_helper
INFO - 2016-02-19 08:39:37 --> Database Driver Class Initialized
INFO - 2016-02-19 08:39:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:39:38 --> Controller Class Initialized
INFO - 2016-02-19 08:39:38 --> Model Class Initialized
INFO - 2016-02-19 08:39:38 --> Model Class Initialized
INFO - 2016-02-19 08:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:39:38 --> Pagination Class Initialized
INFO - 2016-02-19 08:39:38 --> Helper loaded: text_helper
INFO - 2016-02-19 08:39:38 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:39:38 --> Final output sent to browser
DEBUG - 2016-02-19 11:39:38 --> Total execution time: 1.1973
INFO - 2016-02-19 08:39:42 --> Config Class Initialized
INFO - 2016-02-19 08:39:42 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:39:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:39:43 --> Utf8 Class Initialized
INFO - 2016-02-19 08:39:43 --> URI Class Initialized
DEBUG - 2016-02-19 08:39:43 --> No URI present. Default controller set.
INFO - 2016-02-19 08:39:43 --> Router Class Initialized
INFO - 2016-02-19 08:39:43 --> Output Class Initialized
INFO - 2016-02-19 08:39:43 --> Security Class Initialized
DEBUG - 2016-02-19 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:39:43 --> Input Class Initialized
INFO - 2016-02-19 08:39:43 --> Language Class Initialized
INFO - 2016-02-19 08:39:43 --> Loader Class Initialized
INFO - 2016-02-19 08:39:43 --> Helper loaded: url_helper
INFO - 2016-02-19 08:39:43 --> Helper loaded: file_helper
INFO - 2016-02-19 08:39:43 --> Helper loaded: date_helper
INFO - 2016-02-19 08:39:43 --> Helper loaded: form_helper
INFO - 2016-02-19 08:39:43 --> Database Driver Class Initialized
INFO - 2016-02-19 08:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:39:44 --> Controller Class Initialized
INFO - 2016-02-19 08:39:44 --> Model Class Initialized
INFO - 2016-02-19 08:39:44 --> Model Class Initialized
INFO - 2016-02-19 08:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:39:44 --> Pagination Class Initialized
INFO - 2016-02-19 08:39:44 --> Helper loaded: text_helper
INFO - 2016-02-19 08:39:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:39:44 --> Final output sent to browser
DEBUG - 2016-02-19 11:39:44 --> Total execution time: 1.1725
INFO - 2016-02-19 08:39:45 --> Config Class Initialized
INFO - 2016-02-19 08:39:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:39:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:39:45 --> Utf8 Class Initialized
INFO - 2016-02-19 08:39:45 --> URI Class Initialized
INFO - 2016-02-19 08:39:45 --> Router Class Initialized
INFO - 2016-02-19 08:39:45 --> Output Class Initialized
INFO - 2016-02-19 08:39:45 --> Security Class Initialized
DEBUG - 2016-02-19 08:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:39:45 --> Input Class Initialized
INFO - 2016-02-19 08:39:45 --> Language Class Initialized
INFO - 2016-02-19 08:39:45 --> Loader Class Initialized
INFO - 2016-02-19 08:39:45 --> Helper loaded: url_helper
INFO - 2016-02-19 08:39:45 --> Helper loaded: file_helper
INFO - 2016-02-19 08:39:45 --> Helper loaded: date_helper
INFO - 2016-02-19 08:39:45 --> Helper loaded: form_helper
INFO - 2016-02-19 08:39:45 --> Database Driver Class Initialized
INFO - 2016-02-19 08:39:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:39:46 --> Controller Class Initialized
INFO - 2016-02-19 08:39:46 --> Model Class Initialized
INFO - 2016-02-19 08:39:46 --> Model Class Initialized
INFO - 2016-02-19 08:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:39:46 --> Pagination Class Initialized
INFO - 2016-02-19 08:39:46 --> Helper loaded: text_helper
INFO - 2016-02-19 08:39:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:39:46 --> Final output sent to browser
DEBUG - 2016-02-19 11:39:46 --> Total execution time: 1.1907
INFO - 2016-02-19 08:40:29 --> Config Class Initialized
INFO - 2016-02-19 08:40:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:29 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:29 --> URI Class Initialized
INFO - 2016-02-19 08:40:29 --> Router Class Initialized
INFO - 2016-02-19 08:40:29 --> Output Class Initialized
INFO - 2016-02-19 08:40:29 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:29 --> Input Class Initialized
INFO - 2016-02-19 08:40:29 --> Language Class Initialized
INFO - 2016-02-19 08:40:29 --> Loader Class Initialized
INFO - 2016-02-19 08:40:29 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:29 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:29 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:29 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:29 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:30 --> Controller Class Initialized
INFO - 2016-02-19 08:40:30 --> Model Class Initialized
INFO - 2016-02-19 08:40:30 --> Model Class Initialized
INFO - 2016-02-19 08:40:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:30 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:30 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:40:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:30 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:30 --> Total execution time: 1.2129
INFO - 2016-02-19 08:40:35 --> Config Class Initialized
INFO - 2016-02-19 08:40:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:35 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:35 --> URI Class Initialized
DEBUG - 2016-02-19 08:40:35 --> No URI present. Default controller set.
INFO - 2016-02-19 08:40:35 --> Router Class Initialized
INFO - 2016-02-19 08:40:35 --> Output Class Initialized
INFO - 2016-02-19 08:40:35 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:35 --> Input Class Initialized
INFO - 2016-02-19 08:40:35 --> Language Class Initialized
INFO - 2016-02-19 08:40:35 --> Loader Class Initialized
INFO - 2016-02-19 08:40:35 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:35 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:35 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:35 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:35 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:36 --> Controller Class Initialized
INFO - 2016-02-19 08:40:36 --> Model Class Initialized
INFO - 2016-02-19 08:40:36 --> Model Class Initialized
INFO - 2016-02-19 08:40:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:36 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:36 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:40:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:36 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:36 --> Total execution time: 1.1524
INFO - 2016-02-19 08:40:37 --> Config Class Initialized
INFO - 2016-02-19 08:40:37 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:37 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:37 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:37 --> URI Class Initialized
INFO - 2016-02-19 08:40:37 --> Router Class Initialized
INFO - 2016-02-19 08:40:37 --> Output Class Initialized
INFO - 2016-02-19 08:40:37 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:37 --> Input Class Initialized
INFO - 2016-02-19 08:40:37 --> Language Class Initialized
INFO - 2016-02-19 08:40:37 --> Loader Class Initialized
INFO - 2016-02-19 08:40:37 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:37 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:37 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:37 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:37 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:38 --> Controller Class Initialized
INFO - 2016-02-19 08:40:38 --> Model Class Initialized
INFO - 2016-02-19 08:40:38 --> Model Class Initialized
INFO - 2016-02-19 08:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:38 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:38 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:38 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:39 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:39 --> Total execution time: 1.2840
INFO - 2016-02-19 08:40:45 --> Config Class Initialized
INFO - 2016-02-19 08:40:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:45 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:45 --> URI Class Initialized
DEBUG - 2016-02-19 08:40:45 --> No URI present. Default controller set.
INFO - 2016-02-19 08:40:45 --> Router Class Initialized
INFO - 2016-02-19 08:40:45 --> Output Class Initialized
INFO - 2016-02-19 08:40:45 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:45 --> Input Class Initialized
INFO - 2016-02-19 08:40:45 --> Language Class Initialized
INFO - 2016-02-19 08:40:45 --> Loader Class Initialized
INFO - 2016-02-19 08:40:45 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:45 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:45 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:45 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:45 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:46 --> Controller Class Initialized
INFO - 2016-02-19 08:40:46 --> Model Class Initialized
INFO - 2016-02-19 08:40:46 --> Model Class Initialized
INFO - 2016-02-19 08:40:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:46 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:46 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:46 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:46 --> Total execution time: 1.1490
INFO - 2016-02-19 08:40:48 --> Config Class Initialized
INFO - 2016-02-19 08:40:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:48 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:48 --> URI Class Initialized
INFO - 2016-02-19 08:40:48 --> Router Class Initialized
INFO - 2016-02-19 08:40:48 --> Output Class Initialized
INFO - 2016-02-19 08:40:48 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:48 --> Input Class Initialized
INFO - 2016-02-19 08:40:48 --> Language Class Initialized
INFO - 2016-02-19 08:40:48 --> Loader Class Initialized
INFO - 2016-02-19 08:40:48 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:48 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:48 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:48 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:48 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:49 --> Controller Class Initialized
INFO - 2016-02-19 08:40:49 --> Model Class Initialized
INFO - 2016-02-19 08:40:49 --> Model Class Initialized
INFO - 2016-02-19 08:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:49 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:49 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:50 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:50 --> Total execution time: 1.2316
INFO - 2016-02-19 08:40:52 --> Config Class Initialized
INFO - 2016-02-19 08:40:52 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:52 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:52 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:52 --> URI Class Initialized
DEBUG - 2016-02-19 08:40:52 --> No URI present. Default controller set.
INFO - 2016-02-19 08:40:52 --> Router Class Initialized
INFO - 2016-02-19 08:40:52 --> Output Class Initialized
INFO - 2016-02-19 08:40:52 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:52 --> Input Class Initialized
INFO - 2016-02-19 08:40:52 --> Language Class Initialized
INFO - 2016-02-19 08:40:52 --> Loader Class Initialized
INFO - 2016-02-19 08:40:52 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:52 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:52 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:52 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:52 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:53 --> Controller Class Initialized
INFO - 2016-02-19 08:40:53 --> Model Class Initialized
INFO - 2016-02-19 08:40:53 --> Model Class Initialized
INFO - 2016-02-19 08:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:53 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:53 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:53 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:53 --> Total execution time: 1.1417
INFO - 2016-02-19 08:40:55 --> Config Class Initialized
INFO - 2016-02-19 08:40:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:40:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:40:55 --> Utf8 Class Initialized
INFO - 2016-02-19 08:40:55 --> URI Class Initialized
INFO - 2016-02-19 08:40:55 --> Router Class Initialized
INFO - 2016-02-19 08:40:55 --> Output Class Initialized
INFO - 2016-02-19 08:40:55 --> Security Class Initialized
DEBUG - 2016-02-19 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:40:55 --> Input Class Initialized
INFO - 2016-02-19 08:40:55 --> Language Class Initialized
INFO - 2016-02-19 08:40:55 --> Loader Class Initialized
INFO - 2016-02-19 08:40:55 --> Helper loaded: url_helper
INFO - 2016-02-19 08:40:55 --> Helper loaded: file_helper
INFO - 2016-02-19 08:40:55 --> Helper loaded: date_helper
INFO - 2016-02-19 08:40:55 --> Helper loaded: form_helper
INFO - 2016-02-19 08:40:55 --> Database Driver Class Initialized
INFO - 2016-02-19 08:40:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:40:56 --> Controller Class Initialized
INFO - 2016-02-19 08:40:56 --> Model Class Initialized
INFO - 2016-02-19 08:40:56 --> Model Class Initialized
INFO - 2016-02-19 08:40:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:40:56 --> Pagination Class Initialized
INFO - 2016-02-19 08:40:56 --> Helper loaded: text_helper
INFO - 2016-02-19 08:40:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:40:56 --> Final output sent to browser
DEBUG - 2016-02-19 11:40:56 --> Total execution time: 1.1675
INFO - 2016-02-19 08:41:30 --> Config Class Initialized
INFO - 2016-02-19 08:41:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:30 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:30 --> URI Class Initialized
DEBUG - 2016-02-19 08:41:30 --> No URI present. Default controller set.
INFO - 2016-02-19 08:41:30 --> Router Class Initialized
INFO - 2016-02-19 08:41:30 --> Output Class Initialized
INFO - 2016-02-19 08:41:30 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:30 --> Input Class Initialized
INFO - 2016-02-19 08:41:30 --> Language Class Initialized
INFO - 2016-02-19 08:41:30 --> Loader Class Initialized
INFO - 2016-02-19 08:41:30 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:30 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:30 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:30 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:30 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:31 --> Controller Class Initialized
INFO - 2016-02-19 08:41:31 --> Model Class Initialized
INFO - 2016-02-19 08:41:31 --> Model Class Initialized
INFO - 2016-02-19 08:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:31 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:31 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:31 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:31 --> Total execution time: 1.1660
INFO - 2016-02-19 08:41:33 --> Config Class Initialized
INFO - 2016-02-19 08:41:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:33 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:33 --> URI Class Initialized
INFO - 2016-02-19 08:41:33 --> Router Class Initialized
INFO - 2016-02-19 08:41:33 --> Output Class Initialized
INFO - 2016-02-19 08:41:33 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:33 --> Input Class Initialized
INFO - 2016-02-19 08:41:33 --> Language Class Initialized
INFO - 2016-02-19 08:41:33 --> Loader Class Initialized
INFO - 2016-02-19 08:41:33 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:33 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:33 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:33 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:33 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:34 --> Controller Class Initialized
INFO - 2016-02-19 08:41:34 --> Model Class Initialized
INFO - 2016-02-19 08:41:34 --> Model Class Initialized
INFO - 2016-02-19 08:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:34 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:34 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:34 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:34 --> Total execution time: 1.1860
INFO - 2016-02-19 08:41:38 --> Config Class Initialized
INFO - 2016-02-19 08:41:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:38 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:38 --> URI Class Initialized
DEBUG - 2016-02-19 08:41:38 --> No URI present. Default controller set.
INFO - 2016-02-19 08:41:38 --> Router Class Initialized
INFO - 2016-02-19 08:41:38 --> Output Class Initialized
INFO - 2016-02-19 08:41:38 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:38 --> Input Class Initialized
INFO - 2016-02-19 08:41:38 --> Language Class Initialized
INFO - 2016-02-19 08:41:38 --> Loader Class Initialized
INFO - 2016-02-19 08:41:38 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:38 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:38 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:38 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:38 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:39 --> Controller Class Initialized
INFO - 2016-02-19 08:41:39 --> Model Class Initialized
INFO - 2016-02-19 08:41:39 --> Model Class Initialized
INFO - 2016-02-19 08:41:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:39 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:39 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:39 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:39 --> Total execution time: 1.1604
INFO - 2016-02-19 08:41:41 --> Config Class Initialized
INFO - 2016-02-19 08:41:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:41 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:41 --> URI Class Initialized
INFO - 2016-02-19 08:41:41 --> Router Class Initialized
INFO - 2016-02-19 08:41:41 --> Output Class Initialized
INFO - 2016-02-19 08:41:41 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:41 --> Input Class Initialized
INFO - 2016-02-19 08:41:41 --> Language Class Initialized
INFO - 2016-02-19 08:41:41 --> Loader Class Initialized
INFO - 2016-02-19 08:41:41 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:41 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:41 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:41 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:41 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:42 --> Controller Class Initialized
INFO - 2016-02-19 08:41:42 --> Model Class Initialized
INFO - 2016-02-19 08:41:42 --> Model Class Initialized
INFO - 2016-02-19 08:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:42 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:42 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:42 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:42 --> Total execution time: 1.2122
INFO - 2016-02-19 08:41:50 --> Config Class Initialized
INFO - 2016-02-19 08:41:50 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:50 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:50 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:50 --> URI Class Initialized
DEBUG - 2016-02-19 08:41:50 --> No URI present. Default controller set.
INFO - 2016-02-19 08:41:50 --> Router Class Initialized
INFO - 2016-02-19 08:41:50 --> Output Class Initialized
INFO - 2016-02-19 08:41:50 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:50 --> Input Class Initialized
INFO - 2016-02-19 08:41:50 --> Language Class Initialized
INFO - 2016-02-19 08:41:50 --> Loader Class Initialized
INFO - 2016-02-19 08:41:50 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:50 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:50 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:50 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:50 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:51 --> Controller Class Initialized
INFO - 2016-02-19 08:41:51 --> Model Class Initialized
INFO - 2016-02-19 08:41:51 --> Model Class Initialized
INFO - 2016-02-19 08:41:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:51 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:51 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:51 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:41:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:51 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:51 --> Total execution time: 1.1385
INFO - 2016-02-19 08:41:55 --> Config Class Initialized
INFO - 2016-02-19 08:41:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:55 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:55 --> URI Class Initialized
INFO - 2016-02-19 08:41:55 --> Router Class Initialized
INFO - 2016-02-19 08:41:55 --> Output Class Initialized
INFO - 2016-02-19 08:41:55 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:55 --> Input Class Initialized
INFO - 2016-02-19 08:41:55 --> Language Class Initialized
INFO - 2016-02-19 08:41:55 --> Loader Class Initialized
INFO - 2016-02-19 08:41:55 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:55 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:55 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:55 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:55 --> Database Driver Class Initialized
INFO - 2016-02-19 08:41:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:41:56 --> Controller Class Initialized
INFO - 2016-02-19 08:41:56 --> Model Class Initialized
INFO - 2016-02-19 08:41:56 --> Model Class Initialized
INFO - 2016-02-19 08:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:41:56 --> Pagination Class Initialized
INFO - 2016-02-19 08:41:56 --> Helper loaded: text_helper
INFO - 2016-02-19 08:41:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:41:56 --> Final output sent to browser
DEBUG - 2016-02-19 11:41:56 --> Total execution time: 1.2080
INFO - 2016-02-19 08:41:59 --> Config Class Initialized
INFO - 2016-02-19 08:41:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:41:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:41:59 --> Utf8 Class Initialized
INFO - 2016-02-19 08:41:59 --> URI Class Initialized
DEBUG - 2016-02-19 08:41:59 --> No URI present. Default controller set.
INFO - 2016-02-19 08:41:59 --> Router Class Initialized
INFO - 2016-02-19 08:41:59 --> Output Class Initialized
INFO - 2016-02-19 08:41:59 --> Security Class Initialized
DEBUG - 2016-02-19 08:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:41:59 --> Input Class Initialized
INFO - 2016-02-19 08:41:59 --> Language Class Initialized
INFO - 2016-02-19 08:41:59 --> Loader Class Initialized
INFO - 2016-02-19 08:41:59 --> Helper loaded: url_helper
INFO - 2016-02-19 08:41:59 --> Helper loaded: file_helper
INFO - 2016-02-19 08:41:59 --> Helper loaded: date_helper
INFO - 2016-02-19 08:41:59 --> Helper loaded: form_helper
INFO - 2016-02-19 08:41:59 --> Database Driver Class Initialized
INFO - 2016-02-19 08:42:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:42:00 --> Controller Class Initialized
INFO - 2016-02-19 08:42:00 --> Model Class Initialized
INFO - 2016-02-19 08:42:00 --> Model Class Initialized
INFO - 2016-02-19 08:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:42:00 --> Pagination Class Initialized
INFO - 2016-02-19 08:42:00 --> Helper loaded: text_helper
INFO - 2016-02-19 08:42:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:42:00 --> Final output sent to browser
DEBUG - 2016-02-19 11:42:00 --> Total execution time: 1.1345
INFO - 2016-02-19 08:43:25 --> Config Class Initialized
INFO - 2016-02-19 08:43:25 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:43:25 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:43:25 --> Utf8 Class Initialized
INFO - 2016-02-19 08:43:25 --> URI Class Initialized
INFO - 2016-02-19 08:43:25 --> Router Class Initialized
INFO - 2016-02-19 08:43:25 --> Output Class Initialized
INFO - 2016-02-19 08:43:25 --> Security Class Initialized
DEBUG - 2016-02-19 08:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:43:25 --> Input Class Initialized
INFO - 2016-02-19 08:43:25 --> Language Class Initialized
INFO - 2016-02-19 08:43:25 --> Loader Class Initialized
INFO - 2016-02-19 08:43:25 --> Helper loaded: url_helper
INFO - 2016-02-19 08:43:25 --> Helper loaded: file_helper
INFO - 2016-02-19 08:43:25 --> Helper loaded: date_helper
INFO - 2016-02-19 08:43:25 --> Helper loaded: form_helper
INFO - 2016-02-19 08:43:25 --> Database Driver Class Initialized
INFO - 2016-02-19 08:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:43:26 --> Controller Class Initialized
INFO - 2016-02-19 08:43:26 --> Model Class Initialized
INFO - 2016-02-19 08:43:26 --> Model Class Initialized
INFO - 2016-02-19 08:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:43:26 --> Pagination Class Initialized
INFO - 2016-02-19 08:43:26 --> Helper loaded: text_helper
INFO - 2016-02-19 08:43:26 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:43:26 --> Final output sent to browser
DEBUG - 2016-02-19 11:43:26 --> Total execution time: 1.1813
INFO - 2016-02-19 08:43:40 --> Config Class Initialized
INFO - 2016-02-19 08:43:40 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:43:40 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:43:40 --> Utf8 Class Initialized
INFO - 2016-02-19 08:43:40 --> URI Class Initialized
DEBUG - 2016-02-19 08:43:40 --> No URI present. Default controller set.
INFO - 2016-02-19 08:43:40 --> Router Class Initialized
INFO - 2016-02-19 08:43:40 --> Output Class Initialized
INFO - 2016-02-19 08:43:40 --> Security Class Initialized
DEBUG - 2016-02-19 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:43:40 --> Input Class Initialized
INFO - 2016-02-19 08:43:41 --> Language Class Initialized
INFO - 2016-02-19 08:43:41 --> Loader Class Initialized
INFO - 2016-02-19 08:43:41 --> Helper loaded: url_helper
INFO - 2016-02-19 08:43:41 --> Helper loaded: file_helper
INFO - 2016-02-19 08:43:41 --> Helper loaded: date_helper
INFO - 2016-02-19 08:43:41 --> Helper loaded: form_helper
INFO - 2016-02-19 08:43:41 --> Database Driver Class Initialized
INFO - 2016-02-19 08:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:43:42 --> Controller Class Initialized
INFO - 2016-02-19 08:43:42 --> Model Class Initialized
INFO - 2016-02-19 08:43:42 --> Model Class Initialized
INFO - 2016-02-19 08:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:43:42 --> Pagination Class Initialized
INFO - 2016-02-19 08:43:42 --> Helper loaded: text_helper
INFO - 2016-02-19 08:43:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:43:42 --> Final output sent to browser
DEBUG - 2016-02-19 11:43:42 --> Total execution time: 1.1623
INFO - 2016-02-19 08:43:44 --> Config Class Initialized
INFO - 2016-02-19 08:43:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:43:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:43:44 --> Utf8 Class Initialized
INFO - 2016-02-19 08:43:44 --> URI Class Initialized
INFO - 2016-02-19 08:43:44 --> Router Class Initialized
INFO - 2016-02-19 08:43:44 --> Output Class Initialized
INFO - 2016-02-19 08:43:44 --> Security Class Initialized
DEBUG - 2016-02-19 08:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:43:44 --> Input Class Initialized
INFO - 2016-02-19 08:43:44 --> Language Class Initialized
INFO - 2016-02-19 08:43:44 --> Loader Class Initialized
INFO - 2016-02-19 08:43:44 --> Helper loaded: url_helper
INFO - 2016-02-19 08:43:44 --> Helper loaded: file_helper
INFO - 2016-02-19 08:43:44 --> Helper loaded: date_helper
INFO - 2016-02-19 08:43:44 --> Helper loaded: form_helper
INFO - 2016-02-19 08:43:44 --> Database Driver Class Initialized
INFO - 2016-02-19 08:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:43:45 --> Controller Class Initialized
INFO - 2016-02-19 08:43:45 --> Model Class Initialized
INFO - 2016-02-19 08:43:45 --> Model Class Initialized
INFO - 2016-02-19 08:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:43:45 --> Pagination Class Initialized
INFO - 2016-02-19 08:43:45 --> Helper loaded: text_helper
INFO - 2016-02-19 08:43:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:43:45 --> Final output sent to browser
DEBUG - 2016-02-19 11:43:45 --> Total execution time: 1.1236
INFO - 2016-02-19 08:43:52 --> Config Class Initialized
INFO - 2016-02-19 08:43:52 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:43:52 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:43:52 --> Utf8 Class Initialized
INFO - 2016-02-19 08:43:52 --> URI Class Initialized
INFO - 2016-02-19 08:43:52 --> Router Class Initialized
INFO - 2016-02-19 08:43:52 --> Output Class Initialized
INFO - 2016-02-19 08:43:52 --> Security Class Initialized
DEBUG - 2016-02-19 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:43:52 --> Input Class Initialized
INFO - 2016-02-19 08:43:52 --> Language Class Initialized
INFO - 2016-02-19 08:43:52 --> Loader Class Initialized
INFO - 2016-02-19 08:43:52 --> Helper loaded: url_helper
INFO - 2016-02-19 08:43:52 --> Helper loaded: file_helper
INFO - 2016-02-19 08:43:52 --> Helper loaded: date_helper
INFO - 2016-02-19 08:43:52 --> Helper loaded: form_helper
INFO - 2016-02-19 08:43:52 --> Database Driver Class Initialized
INFO - 2016-02-19 08:43:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:43:53 --> Controller Class Initialized
INFO - 2016-02-19 08:43:53 --> Model Class Initialized
INFO - 2016-02-19 08:43:53 --> Model Class Initialized
INFO - 2016-02-19 08:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:43:53 --> Pagination Class Initialized
INFO - 2016-02-19 08:43:53 --> Helper loaded: text_helper
INFO - 2016-02-19 08:43:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 11:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 11:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:43:53 --> Final output sent to browser
DEBUG - 2016-02-19 11:43:53 --> Total execution time: 1.1493
INFO - 2016-02-19 08:43:59 --> Config Class Initialized
INFO - 2016-02-19 08:43:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 08:43:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 08:43:59 --> Utf8 Class Initialized
INFO - 2016-02-19 08:43:59 --> URI Class Initialized
DEBUG - 2016-02-19 08:43:59 --> No URI present. Default controller set.
INFO - 2016-02-19 08:43:59 --> Router Class Initialized
INFO - 2016-02-19 08:43:59 --> Output Class Initialized
INFO - 2016-02-19 08:43:59 --> Security Class Initialized
DEBUG - 2016-02-19 08:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 08:43:59 --> Input Class Initialized
INFO - 2016-02-19 08:43:59 --> Language Class Initialized
INFO - 2016-02-19 08:43:59 --> Loader Class Initialized
INFO - 2016-02-19 08:43:59 --> Helper loaded: url_helper
INFO - 2016-02-19 08:43:59 --> Helper loaded: file_helper
INFO - 2016-02-19 08:43:59 --> Helper loaded: date_helper
INFO - 2016-02-19 08:43:59 --> Helper loaded: form_helper
INFO - 2016-02-19 08:43:59 --> Database Driver Class Initialized
INFO - 2016-02-19 08:44:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 08:44:00 --> Controller Class Initialized
INFO - 2016-02-19 08:44:00 --> Model Class Initialized
INFO - 2016-02-19 08:44:00 --> Model Class Initialized
INFO - 2016-02-19 08:44:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 08:44:00 --> Pagination Class Initialized
INFO - 2016-02-19 08:44:00 --> Helper loaded: text_helper
INFO - 2016-02-19 08:44:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 11:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 11:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 11:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 11:44:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 11:44:00 --> Final output sent to browser
DEBUG - 2016-02-19 11:44:00 --> Total execution time: 1.0976
INFO - 2016-02-19 10:37:36 --> Config Class Initialized
INFO - 2016-02-19 10:37:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:37:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:37:36 --> Utf8 Class Initialized
INFO - 2016-02-19 10:37:36 --> URI Class Initialized
INFO - 2016-02-19 10:37:36 --> Router Class Initialized
INFO - 2016-02-19 10:37:36 --> Output Class Initialized
INFO - 2016-02-19 10:37:36 --> Security Class Initialized
DEBUG - 2016-02-19 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:37:36 --> Input Class Initialized
INFO - 2016-02-19 10:37:36 --> Language Class Initialized
INFO - 2016-02-19 10:37:36 --> Loader Class Initialized
INFO - 2016-02-19 10:37:36 --> Helper loaded: url_helper
INFO - 2016-02-19 10:37:36 --> Helper loaded: file_helper
INFO - 2016-02-19 10:37:36 --> Helper loaded: date_helper
INFO - 2016-02-19 10:37:36 --> Helper loaded: form_helper
INFO - 2016-02-19 10:37:36 --> Database Driver Class Initialized
INFO - 2016-02-19 10:37:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:37:37 --> Controller Class Initialized
INFO - 2016-02-19 10:37:37 --> Model Class Initialized
INFO - 2016-02-19 10:37:37 --> Model Class Initialized
INFO - 2016-02-19 10:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:37:37 --> Pagination Class Initialized
INFO - 2016-02-19 10:37:37 --> Helper loaded: text_helper
INFO - 2016-02-19 10:37:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:37:37 --> Final output sent to browser
DEBUG - 2016-02-19 13:37:37 --> Total execution time: 1.4156
INFO - 2016-02-19 10:37:58 --> Config Class Initialized
INFO - 2016-02-19 10:37:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:37:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:37:58 --> Utf8 Class Initialized
INFO - 2016-02-19 10:37:58 --> URI Class Initialized
DEBUG - 2016-02-19 10:37:58 --> No URI present. Default controller set.
INFO - 2016-02-19 10:37:58 --> Router Class Initialized
INFO - 2016-02-19 10:37:58 --> Output Class Initialized
INFO - 2016-02-19 10:37:58 --> Security Class Initialized
DEBUG - 2016-02-19 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:37:58 --> Input Class Initialized
INFO - 2016-02-19 10:37:58 --> Language Class Initialized
INFO - 2016-02-19 10:37:58 --> Loader Class Initialized
INFO - 2016-02-19 10:37:58 --> Helper loaded: url_helper
INFO - 2016-02-19 10:37:58 --> Helper loaded: file_helper
INFO - 2016-02-19 10:37:58 --> Helper loaded: date_helper
INFO - 2016-02-19 10:37:58 --> Helper loaded: form_helper
INFO - 2016-02-19 10:37:58 --> Database Driver Class Initialized
INFO - 2016-02-19 10:37:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:37:59 --> Controller Class Initialized
INFO - 2016-02-19 10:37:59 --> Model Class Initialized
INFO - 2016-02-19 10:37:59 --> Model Class Initialized
INFO - 2016-02-19 10:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:37:59 --> Pagination Class Initialized
INFO - 2016-02-19 10:37:59 --> Helper loaded: text_helper
INFO - 2016-02-19 10:37:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:37:59 --> Final output sent to browser
DEBUG - 2016-02-19 13:37:59 --> Total execution time: 1.1599
INFO - 2016-02-19 10:38:01 --> Config Class Initialized
INFO - 2016-02-19 10:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:38:01 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:38:01 --> Utf8 Class Initialized
INFO - 2016-02-19 10:38:01 --> URI Class Initialized
INFO - 2016-02-19 10:38:01 --> Router Class Initialized
INFO - 2016-02-19 10:38:01 --> Output Class Initialized
INFO - 2016-02-19 10:38:01 --> Security Class Initialized
DEBUG - 2016-02-19 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:38:01 --> Input Class Initialized
INFO - 2016-02-19 10:38:01 --> Language Class Initialized
INFO - 2016-02-19 10:38:01 --> Loader Class Initialized
INFO - 2016-02-19 10:38:01 --> Helper loaded: url_helper
INFO - 2016-02-19 10:38:01 --> Helper loaded: file_helper
INFO - 2016-02-19 10:38:01 --> Helper loaded: date_helper
INFO - 2016-02-19 10:38:01 --> Helper loaded: form_helper
INFO - 2016-02-19 10:38:01 --> Database Driver Class Initialized
INFO - 2016-02-19 10:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:38:02 --> Controller Class Initialized
INFO - 2016-02-19 10:38:02 --> Model Class Initialized
INFO - 2016-02-19 10:38:02 --> Model Class Initialized
INFO - 2016-02-19 10:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:38:02 --> Pagination Class Initialized
INFO - 2016-02-19 10:38:02 --> Helper loaded: text_helper
INFO - 2016-02-19 10:38:02 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:38:02 --> Final output sent to browser
DEBUG - 2016-02-19 13:38:02 --> Total execution time: 1.1830
INFO - 2016-02-19 10:38:16 --> Config Class Initialized
INFO - 2016-02-19 10:38:16 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:38:16 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:38:16 --> Utf8 Class Initialized
INFO - 2016-02-19 10:38:16 --> URI Class Initialized
DEBUG - 2016-02-19 10:38:16 --> No URI present. Default controller set.
INFO - 2016-02-19 10:38:16 --> Router Class Initialized
INFO - 2016-02-19 10:38:16 --> Output Class Initialized
INFO - 2016-02-19 10:38:16 --> Security Class Initialized
DEBUG - 2016-02-19 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:38:16 --> Input Class Initialized
INFO - 2016-02-19 10:38:16 --> Language Class Initialized
INFO - 2016-02-19 10:38:16 --> Loader Class Initialized
INFO - 2016-02-19 10:38:16 --> Helper loaded: url_helper
INFO - 2016-02-19 10:38:16 --> Helper loaded: file_helper
INFO - 2016-02-19 10:38:16 --> Helper loaded: date_helper
INFO - 2016-02-19 10:38:16 --> Helper loaded: form_helper
INFO - 2016-02-19 10:38:16 --> Database Driver Class Initialized
INFO - 2016-02-19 10:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:38:17 --> Controller Class Initialized
INFO - 2016-02-19 10:38:17 --> Model Class Initialized
INFO - 2016-02-19 10:38:17 --> Model Class Initialized
INFO - 2016-02-19 10:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:38:17 --> Pagination Class Initialized
INFO - 2016-02-19 10:38:17 --> Helper loaded: text_helper
INFO - 2016-02-19 10:38:17 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:38:17 --> Final output sent to browser
DEBUG - 2016-02-19 13:38:17 --> Total execution time: 1.1436
INFO - 2016-02-19 10:38:23 --> Config Class Initialized
INFO - 2016-02-19 10:38:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:38:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:38:23 --> Utf8 Class Initialized
INFO - 2016-02-19 10:38:23 --> URI Class Initialized
INFO - 2016-02-19 10:38:23 --> Router Class Initialized
INFO - 2016-02-19 10:38:23 --> Output Class Initialized
INFO - 2016-02-19 10:38:23 --> Security Class Initialized
DEBUG - 2016-02-19 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:38:23 --> Input Class Initialized
INFO - 2016-02-19 10:38:23 --> Language Class Initialized
INFO - 2016-02-19 10:38:23 --> Loader Class Initialized
INFO - 2016-02-19 10:38:23 --> Helper loaded: url_helper
INFO - 2016-02-19 10:38:23 --> Helper loaded: file_helper
INFO - 2016-02-19 10:38:23 --> Helper loaded: date_helper
INFO - 2016-02-19 10:38:23 --> Helper loaded: form_helper
INFO - 2016-02-19 10:38:23 --> Database Driver Class Initialized
INFO - 2016-02-19 10:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:38:24 --> Controller Class Initialized
INFO - 2016-02-19 10:38:24 --> Model Class Initialized
INFO - 2016-02-19 10:38:24 --> Model Class Initialized
INFO - 2016-02-19 10:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:38:24 --> Pagination Class Initialized
INFO - 2016-02-19 10:38:24 --> Helper loaded: text_helper
INFO - 2016-02-19 10:38:24 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:38:24 --> Final output sent to browser
DEBUG - 2016-02-19 13:38:24 --> Total execution time: 1.1495
INFO - 2016-02-19 10:38:47 --> Config Class Initialized
INFO - 2016-02-19 10:38:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:38:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:38:47 --> Utf8 Class Initialized
INFO - 2016-02-19 10:38:47 --> URI Class Initialized
DEBUG - 2016-02-19 10:38:47 --> No URI present. Default controller set.
INFO - 2016-02-19 10:38:47 --> Router Class Initialized
INFO - 2016-02-19 10:38:47 --> Output Class Initialized
INFO - 2016-02-19 10:38:47 --> Security Class Initialized
DEBUG - 2016-02-19 10:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:38:47 --> Input Class Initialized
INFO - 2016-02-19 10:38:47 --> Language Class Initialized
INFO - 2016-02-19 10:38:47 --> Loader Class Initialized
INFO - 2016-02-19 10:38:47 --> Helper loaded: url_helper
INFO - 2016-02-19 10:38:47 --> Helper loaded: file_helper
INFO - 2016-02-19 10:38:47 --> Helper loaded: date_helper
INFO - 2016-02-19 10:38:47 --> Helper loaded: form_helper
INFO - 2016-02-19 10:38:47 --> Database Driver Class Initialized
INFO - 2016-02-19 10:38:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:38:48 --> Controller Class Initialized
INFO - 2016-02-19 10:38:48 --> Model Class Initialized
INFO - 2016-02-19 10:38:48 --> Model Class Initialized
INFO - 2016-02-19 10:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:38:48 --> Pagination Class Initialized
INFO - 2016-02-19 10:38:48 --> Helper loaded: text_helper
INFO - 2016-02-19 10:38:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:38:48 --> Final output sent to browser
DEBUG - 2016-02-19 13:38:48 --> Total execution time: 1.1656
INFO - 2016-02-19 10:42:42 --> Config Class Initialized
INFO - 2016-02-19 10:42:42 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:42:42 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:42:42 --> Utf8 Class Initialized
INFO - 2016-02-19 10:42:42 --> URI Class Initialized
INFO - 2016-02-19 10:42:42 --> Router Class Initialized
INFO - 2016-02-19 10:42:42 --> Output Class Initialized
INFO - 2016-02-19 10:42:42 --> Security Class Initialized
DEBUG - 2016-02-19 10:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:42:42 --> Input Class Initialized
INFO - 2016-02-19 10:42:42 --> Language Class Initialized
INFO - 2016-02-19 10:42:42 --> Loader Class Initialized
INFO - 2016-02-19 10:42:42 --> Helper loaded: url_helper
INFO - 2016-02-19 10:42:42 --> Helper loaded: file_helper
INFO - 2016-02-19 10:42:42 --> Helper loaded: date_helper
INFO - 2016-02-19 10:42:42 --> Helper loaded: form_helper
INFO - 2016-02-19 10:42:42 --> Database Driver Class Initialized
INFO - 2016-02-19 10:42:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:42:43 --> Controller Class Initialized
INFO - 2016-02-19 10:42:43 --> Model Class Initialized
INFO - 2016-02-19 10:42:43 --> Model Class Initialized
INFO - 2016-02-19 10:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:42:43 --> Pagination Class Initialized
INFO - 2016-02-19 10:42:43 --> Helper loaded: text_helper
INFO - 2016-02-19 10:42:43 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:42:44 --> Final output sent to browser
DEBUG - 2016-02-19 13:42:44 --> Total execution time: 1.2297
INFO - 2016-02-19 10:42:56 --> Config Class Initialized
INFO - 2016-02-19 10:42:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:42:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:42:56 --> Utf8 Class Initialized
INFO - 2016-02-19 10:42:56 --> URI Class Initialized
DEBUG - 2016-02-19 10:42:56 --> No URI present. Default controller set.
INFO - 2016-02-19 10:42:56 --> Router Class Initialized
INFO - 2016-02-19 10:42:56 --> Output Class Initialized
INFO - 2016-02-19 10:42:56 --> Security Class Initialized
DEBUG - 2016-02-19 10:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:42:56 --> Input Class Initialized
INFO - 2016-02-19 10:42:56 --> Language Class Initialized
INFO - 2016-02-19 10:42:56 --> Loader Class Initialized
INFO - 2016-02-19 10:42:56 --> Helper loaded: url_helper
INFO - 2016-02-19 10:42:56 --> Helper loaded: file_helper
INFO - 2016-02-19 10:42:56 --> Helper loaded: date_helper
INFO - 2016-02-19 10:42:56 --> Helper loaded: form_helper
INFO - 2016-02-19 10:42:56 --> Database Driver Class Initialized
INFO - 2016-02-19 10:42:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:42:57 --> Controller Class Initialized
INFO - 2016-02-19 10:42:57 --> Model Class Initialized
INFO - 2016-02-19 10:42:57 --> Model Class Initialized
INFO - 2016-02-19 10:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:42:57 --> Pagination Class Initialized
INFO - 2016-02-19 10:42:57 --> Helper loaded: text_helper
INFO - 2016-02-19 10:42:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:42:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:42:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:42:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:42:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:42:57 --> Final output sent to browser
DEBUG - 2016-02-19 13:42:57 --> Total execution time: 1.1417
INFO - 2016-02-19 10:42:59 --> Config Class Initialized
INFO - 2016-02-19 10:42:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:42:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:42:59 --> Utf8 Class Initialized
INFO - 2016-02-19 10:42:59 --> URI Class Initialized
INFO - 2016-02-19 10:42:59 --> Router Class Initialized
INFO - 2016-02-19 10:42:59 --> Output Class Initialized
INFO - 2016-02-19 10:42:59 --> Security Class Initialized
DEBUG - 2016-02-19 10:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:42:59 --> Input Class Initialized
INFO - 2016-02-19 10:42:59 --> Language Class Initialized
INFO - 2016-02-19 10:42:59 --> Loader Class Initialized
INFO - 2016-02-19 10:42:59 --> Helper loaded: url_helper
INFO - 2016-02-19 10:42:59 --> Helper loaded: file_helper
INFO - 2016-02-19 10:42:59 --> Helper loaded: date_helper
INFO - 2016-02-19 10:42:59 --> Helper loaded: form_helper
INFO - 2016-02-19 10:42:59 --> Database Driver Class Initialized
INFO - 2016-02-19 10:43:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:43:00 --> Controller Class Initialized
INFO - 2016-02-19 10:43:00 --> Model Class Initialized
INFO - 2016-02-19 10:43:00 --> Model Class Initialized
INFO - 2016-02-19 10:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:43:00 --> Pagination Class Initialized
INFO - 2016-02-19 10:43:00 --> Helper loaded: text_helper
INFO - 2016-02-19 10:43:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:43:00 --> Final output sent to browser
DEBUG - 2016-02-19 13:43:00 --> Total execution time: 1.1869
INFO - 2016-02-19 10:45:20 --> Config Class Initialized
INFO - 2016-02-19 10:45:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:45:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:45:20 --> Utf8 Class Initialized
INFO - 2016-02-19 10:45:20 --> URI Class Initialized
INFO - 2016-02-19 10:45:20 --> Router Class Initialized
INFO - 2016-02-19 10:45:20 --> Output Class Initialized
INFO - 2016-02-19 10:45:20 --> Security Class Initialized
DEBUG - 2016-02-19 10:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:45:20 --> Input Class Initialized
INFO - 2016-02-19 10:45:20 --> Language Class Initialized
INFO - 2016-02-19 10:45:20 --> Loader Class Initialized
INFO - 2016-02-19 10:45:20 --> Helper loaded: url_helper
INFO - 2016-02-19 10:45:20 --> Helper loaded: file_helper
INFO - 2016-02-19 10:45:20 --> Helper loaded: date_helper
INFO - 2016-02-19 10:45:20 --> Helper loaded: form_helper
INFO - 2016-02-19 10:45:20 --> Database Driver Class Initialized
INFO - 2016-02-19 10:45:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:45:21 --> Controller Class Initialized
INFO - 2016-02-19 10:45:21 --> Model Class Initialized
INFO - 2016-02-19 10:45:21 --> Model Class Initialized
INFO - 2016-02-19 10:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:45:21 --> Pagination Class Initialized
INFO - 2016-02-19 10:45:21 --> Helper loaded: text_helper
INFO - 2016-02-19 10:45:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:45:22 --> Final output sent to browser
DEBUG - 2016-02-19 13:45:22 --> Total execution time: 1.1860
INFO - 2016-02-19 10:48:46 --> Config Class Initialized
INFO - 2016-02-19 10:48:46 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:48:46 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:48:46 --> Utf8 Class Initialized
INFO - 2016-02-19 10:48:46 --> URI Class Initialized
INFO - 2016-02-19 10:48:46 --> Router Class Initialized
INFO - 2016-02-19 10:48:46 --> Output Class Initialized
INFO - 2016-02-19 10:48:46 --> Security Class Initialized
DEBUG - 2016-02-19 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:48:46 --> Input Class Initialized
INFO - 2016-02-19 10:48:46 --> Language Class Initialized
INFO - 2016-02-19 10:48:46 --> Loader Class Initialized
INFO - 2016-02-19 10:48:46 --> Helper loaded: url_helper
INFO - 2016-02-19 10:48:46 --> Helper loaded: file_helper
INFO - 2016-02-19 10:48:46 --> Helper loaded: date_helper
INFO - 2016-02-19 10:48:46 --> Helper loaded: form_helper
INFO - 2016-02-19 10:48:46 --> Database Driver Class Initialized
INFO - 2016-02-19 10:48:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:48:48 --> Controller Class Initialized
INFO - 2016-02-19 10:48:48 --> Model Class Initialized
INFO - 2016-02-19 10:48:48 --> Model Class Initialized
INFO - 2016-02-19 10:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:48:48 --> Pagination Class Initialized
INFO - 2016-02-19 10:48:48 --> Helper loaded: text_helper
INFO - 2016-02-19 10:48:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:48:48 --> Final output sent to browser
DEBUG - 2016-02-19 13:48:48 --> Total execution time: 1.2414
INFO - 2016-02-19 10:49:25 --> Config Class Initialized
INFO - 2016-02-19 10:49:25 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:49:25 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:49:25 --> Utf8 Class Initialized
INFO - 2016-02-19 10:49:25 --> URI Class Initialized
DEBUG - 2016-02-19 10:49:25 --> No URI present. Default controller set.
INFO - 2016-02-19 10:49:25 --> Router Class Initialized
INFO - 2016-02-19 10:49:25 --> Output Class Initialized
INFO - 2016-02-19 10:49:25 --> Security Class Initialized
DEBUG - 2016-02-19 10:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:49:25 --> Input Class Initialized
INFO - 2016-02-19 10:49:25 --> Language Class Initialized
INFO - 2016-02-19 10:49:25 --> Loader Class Initialized
INFO - 2016-02-19 10:49:25 --> Helper loaded: url_helper
INFO - 2016-02-19 10:49:25 --> Helper loaded: file_helper
INFO - 2016-02-19 10:49:25 --> Helper loaded: date_helper
INFO - 2016-02-19 10:49:25 --> Helper loaded: form_helper
INFO - 2016-02-19 10:49:25 --> Database Driver Class Initialized
INFO - 2016-02-19 10:49:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:49:26 --> Controller Class Initialized
INFO - 2016-02-19 10:49:26 --> Model Class Initialized
INFO - 2016-02-19 10:49:26 --> Model Class Initialized
INFO - 2016-02-19 10:49:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:49:26 --> Pagination Class Initialized
INFO - 2016-02-19 10:49:26 --> Helper loaded: text_helper
INFO - 2016-02-19 10:49:26 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:49:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:49:26 --> Final output sent to browser
DEBUG - 2016-02-19 13:49:26 --> Total execution time: 1.1190
INFO - 2016-02-19 10:49:28 --> Config Class Initialized
INFO - 2016-02-19 10:49:28 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:49:28 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:49:28 --> Utf8 Class Initialized
INFO - 2016-02-19 10:49:28 --> URI Class Initialized
INFO - 2016-02-19 10:49:28 --> Router Class Initialized
INFO - 2016-02-19 10:49:28 --> Output Class Initialized
INFO - 2016-02-19 10:49:28 --> Security Class Initialized
DEBUG - 2016-02-19 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:49:28 --> Input Class Initialized
INFO - 2016-02-19 10:49:28 --> Language Class Initialized
INFO - 2016-02-19 10:49:28 --> Loader Class Initialized
INFO - 2016-02-19 10:49:28 --> Helper loaded: url_helper
INFO - 2016-02-19 10:49:28 --> Helper loaded: file_helper
INFO - 2016-02-19 10:49:28 --> Helper loaded: date_helper
INFO - 2016-02-19 10:49:28 --> Helper loaded: form_helper
INFO - 2016-02-19 10:49:28 --> Database Driver Class Initialized
INFO - 2016-02-19 10:49:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:49:29 --> Controller Class Initialized
INFO - 2016-02-19 10:49:29 --> Model Class Initialized
INFO - 2016-02-19 10:49:29 --> Model Class Initialized
INFO - 2016-02-19 10:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:49:29 --> Pagination Class Initialized
INFO - 2016-02-19 10:49:29 --> Helper loaded: text_helper
INFO - 2016-02-19 10:49:29 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:49:29 --> Final output sent to browser
DEBUG - 2016-02-19 13:49:29 --> Total execution time: 1.1182
INFO - 2016-02-19 10:49:31 --> Config Class Initialized
INFO - 2016-02-19 10:49:31 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:49:31 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:49:31 --> Utf8 Class Initialized
INFO - 2016-02-19 10:49:31 --> URI Class Initialized
INFO - 2016-02-19 10:49:31 --> Router Class Initialized
INFO - 2016-02-19 10:49:31 --> Output Class Initialized
INFO - 2016-02-19 10:49:31 --> Security Class Initialized
DEBUG - 2016-02-19 10:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:49:31 --> Input Class Initialized
INFO - 2016-02-19 10:49:31 --> Language Class Initialized
INFO - 2016-02-19 10:49:31 --> Loader Class Initialized
INFO - 2016-02-19 10:49:31 --> Helper loaded: url_helper
INFO - 2016-02-19 10:49:31 --> Helper loaded: file_helper
INFO - 2016-02-19 10:49:31 --> Helper loaded: date_helper
INFO - 2016-02-19 10:49:31 --> Helper loaded: form_helper
INFO - 2016-02-19 10:49:31 --> Database Driver Class Initialized
INFO - 2016-02-19 10:49:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:49:32 --> Controller Class Initialized
INFO - 2016-02-19 10:49:32 --> Model Class Initialized
INFO - 2016-02-19 10:49:32 --> Model Class Initialized
INFO - 2016-02-19 10:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:49:32 --> Pagination Class Initialized
INFO - 2016-02-19 10:49:32 --> Helper loaded: text_helper
INFO - 2016-02-19 10:49:32 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 13:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 13:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:49:33 --> Final output sent to browser
DEBUG - 2016-02-19 13:49:33 --> Total execution time: 1.2979
INFO - 2016-02-19 10:53:52 --> Config Class Initialized
INFO - 2016-02-19 10:53:52 --> Hooks Class Initialized
DEBUG - 2016-02-19 10:53:52 --> UTF-8 Support Enabled
INFO - 2016-02-19 10:53:52 --> Utf8 Class Initialized
INFO - 2016-02-19 10:53:52 --> URI Class Initialized
DEBUG - 2016-02-19 10:53:52 --> No URI present. Default controller set.
INFO - 2016-02-19 10:53:52 --> Router Class Initialized
INFO - 2016-02-19 10:53:52 --> Output Class Initialized
INFO - 2016-02-19 10:53:52 --> Security Class Initialized
DEBUG - 2016-02-19 10:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 10:53:52 --> Input Class Initialized
INFO - 2016-02-19 10:53:52 --> Language Class Initialized
INFO - 2016-02-19 10:53:52 --> Loader Class Initialized
INFO - 2016-02-19 10:53:52 --> Helper loaded: url_helper
INFO - 2016-02-19 10:53:52 --> Helper loaded: file_helper
INFO - 2016-02-19 10:53:52 --> Helper loaded: date_helper
INFO - 2016-02-19 10:53:52 --> Helper loaded: form_helper
INFO - 2016-02-19 10:53:52 --> Database Driver Class Initialized
INFO - 2016-02-19 10:53:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 10:53:53 --> Controller Class Initialized
INFO - 2016-02-19 10:53:53 --> Model Class Initialized
INFO - 2016-02-19 10:53:53 --> Model Class Initialized
INFO - 2016-02-19 10:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 10:53:53 --> Pagination Class Initialized
INFO - 2016-02-19 10:53:53 --> Helper loaded: text_helper
INFO - 2016-02-19 10:53:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 13:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 13:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 13:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 13:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 13:53:53 --> Final output sent to browser
DEBUG - 2016-02-19 13:53:53 --> Total execution time: 1.1661
INFO - 2016-02-19 11:00:00 --> Config Class Initialized
INFO - 2016-02-19 11:00:00 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:00:00 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:00:00 --> Utf8 Class Initialized
INFO - 2016-02-19 11:00:00 --> URI Class Initialized
DEBUG - 2016-02-19 11:00:00 --> No URI present. Default controller set.
INFO - 2016-02-19 11:00:00 --> Router Class Initialized
INFO - 2016-02-19 11:00:00 --> Output Class Initialized
INFO - 2016-02-19 11:00:00 --> Security Class Initialized
DEBUG - 2016-02-19 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:00:00 --> Input Class Initialized
INFO - 2016-02-19 11:00:00 --> Language Class Initialized
INFO - 2016-02-19 11:00:00 --> Loader Class Initialized
INFO - 2016-02-19 11:00:00 --> Helper loaded: url_helper
INFO - 2016-02-19 11:00:00 --> Helper loaded: file_helper
INFO - 2016-02-19 11:00:00 --> Helper loaded: date_helper
INFO - 2016-02-19 11:00:00 --> Helper loaded: form_helper
INFO - 2016-02-19 11:00:00 --> Database Driver Class Initialized
INFO - 2016-02-19 11:00:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:00:01 --> Controller Class Initialized
INFO - 2016-02-19 11:00:01 --> Model Class Initialized
INFO - 2016-02-19 11:00:01 --> Model Class Initialized
INFO - 2016-02-19 11:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:00:01 --> Pagination Class Initialized
INFO - 2016-02-19 11:00:01 --> Helper loaded: text_helper
INFO - 2016-02-19 11:00:01 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:00:01 --> Final output sent to browser
DEBUG - 2016-02-19 14:00:01 --> Total execution time: 1.1645
INFO - 2016-02-19 11:01:11 --> Config Class Initialized
INFO - 2016-02-19 11:01:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:01:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:01:11 --> Utf8 Class Initialized
INFO - 2016-02-19 11:01:11 --> URI Class Initialized
DEBUG - 2016-02-19 11:01:11 --> No URI present. Default controller set.
INFO - 2016-02-19 11:01:11 --> Router Class Initialized
INFO - 2016-02-19 11:01:11 --> Output Class Initialized
INFO - 2016-02-19 11:01:11 --> Security Class Initialized
DEBUG - 2016-02-19 11:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:01:11 --> Input Class Initialized
INFO - 2016-02-19 11:01:11 --> Language Class Initialized
INFO - 2016-02-19 11:01:11 --> Loader Class Initialized
INFO - 2016-02-19 11:01:11 --> Helper loaded: url_helper
INFO - 2016-02-19 11:01:11 --> Helper loaded: file_helper
INFO - 2016-02-19 11:01:11 --> Helper loaded: date_helper
INFO - 2016-02-19 11:01:11 --> Helper loaded: form_helper
INFO - 2016-02-19 11:01:11 --> Database Driver Class Initialized
INFO - 2016-02-19 11:01:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:01:12 --> Controller Class Initialized
INFO - 2016-02-19 11:01:12 --> Model Class Initialized
INFO - 2016-02-19 11:01:12 --> Model Class Initialized
INFO - 2016-02-19 11:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:01:12 --> Pagination Class Initialized
INFO - 2016-02-19 11:01:12 --> Helper loaded: text_helper
INFO - 2016-02-19 11:01:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:01:12 --> Final output sent to browser
DEBUG - 2016-02-19 14:01:12 --> Total execution time: 1.1533
INFO - 2016-02-19 11:01:51 --> Config Class Initialized
INFO - 2016-02-19 11:01:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:01:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:01:51 --> Utf8 Class Initialized
INFO - 2016-02-19 11:01:51 --> URI Class Initialized
DEBUG - 2016-02-19 11:01:51 --> No URI present. Default controller set.
INFO - 2016-02-19 11:01:51 --> Router Class Initialized
INFO - 2016-02-19 11:01:51 --> Output Class Initialized
INFO - 2016-02-19 11:01:51 --> Security Class Initialized
DEBUG - 2016-02-19 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:01:51 --> Input Class Initialized
INFO - 2016-02-19 11:01:51 --> Language Class Initialized
INFO - 2016-02-19 11:01:51 --> Loader Class Initialized
INFO - 2016-02-19 11:01:51 --> Helper loaded: url_helper
INFO - 2016-02-19 11:01:51 --> Helper loaded: file_helper
INFO - 2016-02-19 11:01:51 --> Helper loaded: date_helper
INFO - 2016-02-19 11:01:51 --> Helper loaded: form_helper
INFO - 2016-02-19 11:01:51 --> Database Driver Class Initialized
INFO - 2016-02-19 11:01:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:01:52 --> Controller Class Initialized
INFO - 2016-02-19 11:01:52 --> Model Class Initialized
INFO - 2016-02-19 11:01:52 --> Model Class Initialized
INFO - 2016-02-19 11:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:01:52 --> Pagination Class Initialized
INFO - 2016-02-19 11:01:52 --> Helper loaded: text_helper
INFO - 2016-02-19 11:01:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:01:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:01:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:01:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:01:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:01:52 --> Final output sent to browser
DEBUG - 2016-02-19 14:01:52 --> Total execution time: 1.1699
INFO - 2016-02-19 11:04:45 --> Config Class Initialized
INFO - 2016-02-19 11:04:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:04:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:04:45 --> Utf8 Class Initialized
INFO - 2016-02-19 11:04:45 --> URI Class Initialized
DEBUG - 2016-02-19 11:04:45 --> No URI present. Default controller set.
INFO - 2016-02-19 11:04:45 --> Router Class Initialized
INFO - 2016-02-19 11:04:45 --> Output Class Initialized
INFO - 2016-02-19 11:04:45 --> Security Class Initialized
DEBUG - 2016-02-19 11:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:04:45 --> Input Class Initialized
INFO - 2016-02-19 11:04:45 --> Language Class Initialized
INFO - 2016-02-19 11:04:45 --> Loader Class Initialized
INFO - 2016-02-19 11:04:45 --> Helper loaded: url_helper
INFO - 2016-02-19 11:04:45 --> Helper loaded: file_helper
INFO - 2016-02-19 11:04:45 --> Helper loaded: date_helper
INFO - 2016-02-19 11:04:45 --> Helper loaded: form_helper
INFO - 2016-02-19 11:04:45 --> Database Driver Class Initialized
INFO - 2016-02-19 11:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:04:46 --> Controller Class Initialized
INFO - 2016-02-19 11:04:46 --> Model Class Initialized
INFO - 2016-02-19 11:04:46 --> Model Class Initialized
INFO - 2016-02-19 11:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:04:46 --> Pagination Class Initialized
INFO - 2016-02-19 11:04:46 --> Helper loaded: text_helper
INFO - 2016-02-19 11:04:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:04:46 --> Final output sent to browser
DEBUG - 2016-02-19 14:04:46 --> Total execution time: 1.1852
INFO - 2016-02-19 11:05:58 --> Config Class Initialized
INFO - 2016-02-19 11:05:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:05:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:05:58 --> Utf8 Class Initialized
INFO - 2016-02-19 11:05:58 --> URI Class Initialized
DEBUG - 2016-02-19 11:05:58 --> No URI present. Default controller set.
INFO - 2016-02-19 11:05:58 --> Router Class Initialized
INFO - 2016-02-19 11:05:58 --> Output Class Initialized
INFO - 2016-02-19 11:05:58 --> Security Class Initialized
DEBUG - 2016-02-19 11:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:05:58 --> Input Class Initialized
INFO - 2016-02-19 11:05:58 --> Language Class Initialized
INFO - 2016-02-19 11:05:58 --> Loader Class Initialized
INFO - 2016-02-19 11:05:58 --> Helper loaded: url_helper
INFO - 2016-02-19 11:05:58 --> Helper loaded: file_helper
INFO - 2016-02-19 11:05:58 --> Helper loaded: date_helper
INFO - 2016-02-19 11:05:58 --> Helper loaded: form_helper
INFO - 2016-02-19 11:05:58 --> Database Driver Class Initialized
INFO - 2016-02-19 11:05:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:05:59 --> Controller Class Initialized
INFO - 2016-02-19 11:05:59 --> Model Class Initialized
INFO - 2016-02-19 11:05:59 --> Model Class Initialized
INFO - 2016-02-19 11:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:05:59 --> Pagination Class Initialized
INFO - 2016-02-19 11:05:59 --> Helper loaded: text_helper
INFO - 2016-02-19 11:05:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:05:59 --> Final output sent to browser
DEBUG - 2016-02-19 14:05:59 --> Total execution time: 1.1846
INFO - 2016-02-19 11:06:26 --> Config Class Initialized
INFO - 2016-02-19 11:06:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:06:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:06:26 --> Utf8 Class Initialized
INFO - 2016-02-19 11:06:26 --> URI Class Initialized
DEBUG - 2016-02-19 11:06:26 --> No URI present. Default controller set.
INFO - 2016-02-19 11:06:26 --> Router Class Initialized
INFO - 2016-02-19 11:06:26 --> Output Class Initialized
INFO - 2016-02-19 11:06:26 --> Security Class Initialized
DEBUG - 2016-02-19 11:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:06:26 --> Input Class Initialized
INFO - 2016-02-19 11:06:26 --> Language Class Initialized
INFO - 2016-02-19 11:06:26 --> Loader Class Initialized
INFO - 2016-02-19 11:06:26 --> Helper loaded: url_helper
INFO - 2016-02-19 11:06:26 --> Helper loaded: file_helper
INFO - 2016-02-19 11:06:26 --> Helper loaded: date_helper
INFO - 2016-02-19 11:06:26 --> Helper loaded: form_helper
INFO - 2016-02-19 11:06:26 --> Database Driver Class Initialized
INFO - 2016-02-19 11:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:06:27 --> Controller Class Initialized
INFO - 2016-02-19 11:06:27 --> Model Class Initialized
INFO - 2016-02-19 11:06:27 --> Model Class Initialized
INFO - 2016-02-19 11:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:06:27 --> Pagination Class Initialized
INFO - 2016-02-19 11:06:27 --> Helper loaded: text_helper
INFO - 2016-02-19 11:06:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:06:27 --> Final output sent to browser
DEBUG - 2016-02-19 14:06:27 --> Total execution time: 1.1653
INFO - 2016-02-19 11:08:33 --> Config Class Initialized
INFO - 2016-02-19 11:08:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:08:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:08:33 --> Utf8 Class Initialized
INFO - 2016-02-19 11:08:33 --> URI Class Initialized
DEBUG - 2016-02-19 11:08:33 --> No URI present. Default controller set.
INFO - 2016-02-19 11:08:33 --> Router Class Initialized
INFO - 2016-02-19 11:08:33 --> Output Class Initialized
INFO - 2016-02-19 11:08:33 --> Security Class Initialized
DEBUG - 2016-02-19 11:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:08:33 --> Input Class Initialized
INFO - 2016-02-19 11:08:33 --> Language Class Initialized
INFO - 2016-02-19 11:08:33 --> Loader Class Initialized
INFO - 2016-02-19 11:08:33 --> Helper loaded: url_helper
INFO - 2016-02-19 11:08:33 --> Helper loaded: file_helper
INFO - 2016-02-19 11:08:33 --> Helper loaded: date_helper
INFO - 2016-02-19 11:08:33 --> Helper loaded: form_helper
INFO - 2016-02-19 11:08:33 --> Database Driver Class Initialized
INFO - 2016-02-19 11:08:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:08:34 --> Controller Class Initialized
INFO - 2016-02-19 11:08:34 --> Model Class Initialized
INFO - 2016-02-19 11:08:34 --> Model Class Initialized
INFO - 2016-02-19 11:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:08:34 --> Pagination Class Initialized
INFO - 2016-02-19 11:08:34 --> Helper loaded: text_helper
INFO - 2016-02-19 11:08:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:08:34 --> Final output sent to browser
DEBUG - 2016-02-19 14:08:34 --> Total execution time: 1.1377
INFO - 2016-02-19 11:11:43 --> Config Class Initialized
INFO - 2016-02-19 11:11:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:11:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:11:43 --> Utf8 Class Initialized
INFO - 2016-02-19 11:11:43 --> URI Class Initialized
DEBUG - 2016-02-19 11:11:43 --> No URI present. Default controller set.
INFO - 2016-02-19 11:11:43 --> Router Class Initialized
INFO - 2016-02-19 11:11:43 --> Output Class Initialized
INFO - 2016-02-19 11:11:43 --> Security Class Initialized
DEBUG - 2016-02-19 11:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:11:43 --> Input Class Initialized
INFO - 2016-02-19 11:11:43 --> Language Class Initialized
INFO - 2016-02-19 11:11:43 --> Loader Class Initialized
INFO - 2016-02-19 11:11:43 --> Helper loaded: url_helper
INFO - 2016-02-19 11:11:43 --> Helper loaded: file_helper
INFO - 2016-02-19 11:11:43 --> Helper loaded: date_helper
INFO - 2016-02-19 11:11:43 --> Helper loaded: form_helper
INFO - 2016-02-19 11:11:43 --> Database Driver Class Initialized
INFO - 2016-02-19 11:11:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:11:45 --> Controller Class Initialized
INFO - 2016-02-19 11:11:45 --> Model Class Initialized
INFO - 2016-02-19 11:11:45 --> Model Class Initialized
INFO - 2016-02-19 11:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:11:45 --> Pagination Class Initialized
INFO - 2016-02-19 11:11:45 --> Helper loaded: text_helper
INFO - 2016-02-19 11:11:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:11:45 --> Final output sent to browser
DEBUG - 2016-02-19 14:11:45 --> Total execution time: 1.1703
INFO - 2016-02-19 11:12:33 --> Config Class Initialized
INFO - 2016-02-19 11:12:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:12:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:12:33 --> Utf8 Class Initialized
INFO - 2016-02-19 11:12:33 --> URI Class Initialized
INFO - 2016-02-19 11:12:33 --> Router Class Initialized
INFO - 2016-02-19 11:12:33 --> Output Class Initialized
INFO - 2016-02-19 11:12:33 --> Security Class Initialized
DEBUG - 2016-02-19 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:12:33 --> Input Class Initialized
INFO - 2016-02-19 11:12:33 --> Language Class Initialized
INFO - 2016-02-19 11:12:33 --> Loader Class Initialized
INFO - 2016-02-19 11:12:33 --> Helper loaded: url_helper
INFO - 2016-02-19 11:12:33 --> Helper loaded: file_helper
INFO - 2016-02-19 11:12:33 --> Helper loaded: date_helper
INFO - 2016-02-19 11:12:33 --> Helper loaded: form_helper
INFO - 2016-02-19 11:12:33 --> Database Driver Class Initialized
INFO - 2016-02-19 11:12:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:12:34 --> Controller Class Initialized
INFO - 2016-02-19 11:12:34 --> Model Class Initialized
INFO - 2016-02-19 11:12:34 --> Model Class Initialized
INFO - 2016-02-19 11:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:12:34 --> Pagination Class Initialized
INFO - 2016-02-19 11:12:34 --> Helper loaded: text_helper
INFO - 2016-02-19 11:12:34 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:12:34 --> Final output sent to browser
DEBUG - 2016-02-19 14:12:34 --> Total execution time: 1.1147
INFO - 2016-02-19 11:12:51 --> Config Class Initialized
INFO - 2016-02-19 11:12:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:12:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:12:51 --> Utf8 Class Initialized
INFO - 2016-02-19 11:12:51 --> URI Class Initialized
INFO - 2016-02-19 11:12:51 --> Router Class Initialized
INFO - 2016-02-19 11:12:51 --> Output Class Initialized
INFO - 2016-02-19 11:12:51 --> Security Class Initialized
DEBUG - 2016-02-19 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:12:51 --> Input Class Initialized
INFO - 2016-02-19 11:12:51 --> Language Class Initialized
INFO - 2016-02-19 11:12:51 --> Loader Class Initialized
INFO - 2016-02-19 11:12:51 --> Helper loaded: url_helper
INFO - 2016-02-19 11:12:51 --> Helper loaded: file_helper
INFO - 2016-02-19 11:12:51 --> Helper loaded: date_helper
INFO - 2016-02-19 11:12:51 --> Helper loaded: form_helper
INFO - 2016-02-19 11:12:51 --> Database Driver Class Initialized
INFO - 2016-02-19 11:12:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:12:53 --> Controller Class Initialized
INFO - 2016-02-19 11:12:53 --> Model Class Initialized
INFO - 2016-02-19 11:12:53 --> Model Class Initialized
INFO - 2016-02-19 11:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:12:53 --> Pagination Class Initialized
INFO - 2016-02-19 11:12:53 --> Helper loaded: text_helper
INFO - 2016-02-19 11:12:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:12:53 --> Final output sent to browser
DEBUG - 2016-02-19 14:12:53 --> Total execution time: 1.1199
INFO - 2016-02-19 11:12:56 --> Config Class Initialized
INFO - 2016-02-19 11:12:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:12:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:12:56 --> Utf8 Class Initialized
INFO - 2016-02-19 11:12:56 --> URI Class Initialized
INFO - 2016-02-19 11:12:56 --> Router Class Initialized
INFO - 2016-02-19 11:12:56 --> Output Class Initialized
INFO - 2016-02-19 11:12:56 --> Security Class Initialized
DEBUG - 2016-02-19 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:12:56 --> Input Class Initialized
INFO - 2016-02-19 11:12:56 --> Language Class Initialized
INFO - 2016-02-19 11:12:56 --> Loader Class Initialized
INFO - 2016-02-19 11:12:56 --> Helper loaded: url_helper
INFO - 2016-02-19 11:12:56 --> Helper loaded: file_helper
INFO - 2016-02-19 11:12:56 --> Helper loaded: date_helper
INFO - 2016-02-19 11:12:56 --> Helper loaded: form_helper
INFO - 2016-02-19 11:12:56 --> Database Driver Class Initialized
INFO - 2016-02-19 11:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:12:57 --> Controller Class Initialized
INFO - 2016-02-19 11:12:57 --> Model Class Initialized
INFO - 2016-02-19 11:12:57 --> Model Class Initialized
INFO - 2016-02-19 11:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:12:57 --> Pagination Class Initialized
INFO - 2016-02-19 11:12:57 --> Helper loaded: text_helper
INFO - 2016-02-19 11:12:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:12:57 --> Final output sent to browser
DEBUG - 2016-02-19 14:12:57 --> Total execution time: 1.2109
INFO - 2016-02-19 11:14:44 --> Config Class Initialized
INFO - 2016-02-19 11:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:14:44 --> Utf8 Class Initialized
INFO - 2016-02-19 11:14:44 --> URI Class Initialized
INFO - 2016-02-19 11:14:44 --> Router Class Initialized
INFO - 2016-02-19 11:14:44 --> Output Class Initialized
INFO - 2016-02-19 11:14:44 --> Security Class Initialized
DEBUG - 2016-02-19 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:14:44 --> Input Class Initialized
INFO - 2016-02-19 11:14:44 --> Language Class Initialized
INFO - 2016-02-19 11:14:44 --> Loader Class Initialized
INFO - 2016-02-19 11:14:44 --> Helper loaded: url_helper
INFO - 2016-02-19 11:14:44 --> Helper loaded: file_helper
INFO - 2016-02-19 11:14:44 --> Helper loaded: date_helper
INFO - 2016-02-19 11:14:44 --> Helper loaded: form_helper
INFO - 2016-02-19 11:14:44 --> Database Driver Class Initialized
INFO - 2016-02-19 11:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:14:45 --> Controller Class Initialized
INFO - 2016-02-19 11:14:45 --> Model Class Initialized
INFO - 2016-02-19 11:14:45 --> Model Class Initialized
INFO - 2016-02-19 11:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:14:45 --> Pagination Class Initialized
INFO - 2016-02-19 11:14:45 --> Helper loaded: text_helper
INFO - 2016-02-19 11:14:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:14:45 --> Final output sent to browser
DEBUG - 2016-02-19 14:14:45 --> Total execution time: 1.2005
INFO - 2016-02-19 11:16:48 --> Config Class Initialized
INFO - 2016-02-19 11:16:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:16:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:16:48 --> Utf8 Class Initialized
INFO - 2016-02-19 11:16:48 --> URI Class Initialized
INFO - 2016-02-19 11:16:48 --> Router Class Initialized
INFO - 2016-02-19 11:16:48 --> Output Class Initialized
INFO - 2016-02-19 11:16:48 --> Security Class Initialized
DEBUG - 2016-02-19 11:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:16:48 --> Input Class Initialized
INFO - 2016-02-19 11:16:48 --> Language Class Initialized
INFO - 2016-02-19 11:16:48 --> Loader Class Initialized
INFO - 2016-02-19 11:16:48 --> Helper loaded: url_helper
INFO - 2016-02-19 11:16:48 --> Helper loaded: file_helper
INFO - 2016-02-19 11:16:48 --> Helper loaded: date_helper
INFO - 2016-02-19 11:16:48 --> Helper loaded: form_helper
INFO - 2016-02-19 11:16:48 --> Database Driver Class Initialized
INFO - 2016-02-19 11:16:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:16:49 --> Controller Class Initialized
INFO - 2016-02-19 11:16:49 --> Model Class Initialized
INFO - 2016-02-19 11:16:49 --> Model Class Initialized
INFO - 2016-02-19 11:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:16:49 --> Pagination Class Initialized
INFO - 2016-02-19 11:16:49 --> Helper loaded: text_helper
INFO - 2016-02-19 11:16:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:16:49 --> Final output sent to browser
DEBUG - 2016-02-19 14:16:49 --> Total execution time: 1.2356
INFO - 2016-02-19 11:17:04 --> Config Class Initialized
INFO - 2016-02-19 11:17:04 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:17:04 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:17:04 --> Utf8 Class Initialized
INFO - 2016-02-19 11:17:04 --> URI Class Initialized
DEBUG - 2016-02-19 11:17:04 --> No URI present. Default controller set.
INFO - 2016-02-19 11:17:04 --> Router Class Initialized
INFO - 2016-02-19 11:17:04 --> Output Class Initialized
INFO - 2016-02-19 11:17:04 --> Security Class Initialized
DEBUG - 2016-02-19 11:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:17:04 --> Input Class Initialized
INFO - 2016-02-19 11:17:04 --> Language Class Initialized
INFO - 2016-02-19 11:17:04 --> Loader Class Initialized
INFO - 2016-02-19 11:17:04 --> Helper loaded: url_helper
INFO - 2016-02-19 11:17:04 --> Helper loaded: file_helper
INFO - 2016-02-19 11:17:04 --> Helper loaded: date_helper
INFO - 2016-02-19 11:17:04 --> Helper loaded: form_helper
INFO - 2016-02-19 11:17:04 --> Database Driver Class Initialized
INFO - 2016-02-19 11:17:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:17:05 --> Controller Class Initialized
INFO - 2016-02-19 11:17:05 --> Model Class Initialized
INFO - 2016-02-19 11:17:05 --> Model Class Initialized
INFO - 2016-02-19 11:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:17:05 --> Pagination Class Initialized
INFO - 2016-02-19 11:17:05 --> Helper loaded: text_helper
INFO - 2016-02-19 11:17:05 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:17:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:17:05 --> Final output sent to browser
DEBUG - 2016-02-19 14:17:05 --> Total execution time: 1.1316
INFO - 2016-02-19 11:17:59 --> Config Class Initialized
INFO - 2016-02-19 11:17:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:17:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:17:59 --> Utf8 Class Initialized
INFO - 2016-02-19 11:17:59 --> URI Class Initialized
INFO - 2016-02-19 11:17:59 --> Router Class Initialized
INFO - 2016-02-19 11:17:59 --> Output Class Initialized
INFO - 2016-02-19 11:17:59 --> Security Class Initialized
DEBUG - 2016-02-19 11:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:17:59 --> Input Class Initialized
INFO - 2016-02-19 11:17:59 --> Language Class Initialized
INFO - 2016-02-19 11:17:59 --> Loader Class Initialized
INFO - 2016-02-19 11:17:59 --> Helper loaded: url_helper
INFO - 2016-02-19 11:17:59 --> Helper loaded: file_helper
INFO - 2016-02-19 11:17:59 --> Helper loaded: date_helper
INFO - 2016-02-19 11:17:59 --> Helper loaded: form_helper
INFO - 2016-02-19 11:17:59 --> Database Driver Class Initialized
INFO - 2016-02-19 11:18:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:18:00 --> Controller Class Initialized
INFO - 2016-02-19 11:18:00 --> Model Class Initialized
INFO - 2016-02-19 11:18:00 --> Model Class Initialized
INFO - 2016-02-19 11:18:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:18:00 --> Pagination Class Initialized
INFO - 2016-02-19 11:18:00 --> Helper loaded: text_helper
INFO - 2016-02-19 11:18:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:18:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:18:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:18:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 14:18:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:18:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:18:00 --> Final output sent to browser
DEBUG - 2016-02-19 14:18:00 --> Total execution time: 1.1591
INFO - 2016-02-19 11:19:47 --> Config Class Initialized
INFO - 2016-02-19 11:19:47 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:19:47 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:19:47 --> Utf8 Class Initialized
INFO - 2016-02-19 11:19:47 --> URI Class Initialized
DEBUG - 2016-02-19 11:19:47 --> No URI present. Default controller set.
INFO - 2016-02-19 11:19:47 --> Router Class Initialized
INFO - 2016-02-19 11:19:47 --> Output Class Initialized
INFO - 2016-02-19 11:19:47 --> Security Class Initialized
DEBUG - 2016-02-19 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:19:47 --> Input Class Initialized
INFO - 2016-02-19 11:19:47 --> Language Class Initialized
INFO - 2016-02-19 11:19:47 --> Loader Class Initialized
INFO - 2016-02-19 11:19:47 --> Helper loaded: url_helper
INFO - 2016-02-19 11:19:47 --> Helper loaded: file_helper
INFO - 2016-02-19 11:19:47 --> Helper loaded: date_helper
INFO - 2016-02-19 11:19:47 --> Helper loaded: form_helper
INFO - 2016-02-19 11:19:47 --> Database Driver Class Initialized
INFO - 2016-02-19 11:19:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:19:48 --> Controller Class Initialized
INFO - 2016-02-19 11:19:48 --> Model Class Initialized
INFO - 2016-02-19 11:19:48 --> Model Class Initialized
INFO - 2016-02-19 11:19:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:19:48 --> Pagination Class Initialized
INFO - 2016-02-19 11:19:48 --> Helper loaded: text_helper
INFO - 2016-02-19 11:19:48 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:19:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:19:48 --> Final output sent to browser
DEBUG - 2016-02-19 14:19:48 --> Total execution time: 1.1488
INFO - 2016-02-19 11:20:43 --> Config Class Initialized
INFO - 2016-02-19 11:20:43 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:20:43 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:20:43 --> Utf8 Class Initialized
INFO - 2016-02-19 11:20:43 --> URI Class Initialized
INFO - 2016-02-19 11:20:43 --> Router Class Initialized
INFO - 2016-02-19 11:20:43 --> Output Class Initialized
INFO - 2016-02-19 11:20:43 --> Security Class Initialized
DEBUG - 2016-02-19 11:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:20:43 --> Input Class Initialized
INFO - 2016-02-19 11:20:43 --> Language Class Initialized
INFO - 2016-02-19 11:20:43 --> Loader Class Initialized
INFO - 2016-02-19 11:20:43 --> Helper loaded: url_helper
INFO - 2016-02-19 11:20:43 --> Helper loaded: file_helper
INFO - 2016-02-19 11:20:43 --> Helper loaded: date_helper
INFO - 2016-02-19 11:20:43 --> Helper loaded: form_helper
INFO - 2016-02-19 11:20:43 --> Database Driver Class Initialized
INFO - 2016-02-19 11:20:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:20:44 --> Controller Class Initialized
INFO - 2016-02-19 11:20:44 --> Model Class Initialized
INFO - 2016-02-19 11:20:44 --> Model Class Initialized
INFO - 2016-02-19 11:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:20:44 --> Pagination Class Initialized
INFO - 2016-02-19 11:20:44 --> Helper loaded: text_helper
INFO - 2016-02-19 11:20:44 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:20:44 --> Final output sent to browser
DEBUG - 2016-02-19 14:20:44 --> Total execution time: 1.1815
INFO - 2016-02-19 11:20:51 --> Config Class Initialized
INFO - 2016-02-19 11:20:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:20:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:20:51 --> Utf8 Class Initialized
INFO - 2016-02-19 11:20:51 --> URI Class Initialized
DEBUG - 2016-02-19 11:20:51 --> No URI present. Default controller set.
INFO - 2016-02-19 11:20:51 --> Router Class Initialized
INFO - 2016-02-19 11:20:51 --> Output Class Initialized
INFO - 2016-02-19 11:20:51 --> Security Class Initialized
DEBUG - 2016-02-19 11:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:20:51 --> Input Class Initialized
INFO - 2016-02-19 11:20:51 --> Language Class Initialized
INFO - 2016-02-19 11:20:51 --> Loader Class Initialized
INFO - 2016-02-19 11:20:51 --> Helper loaded: url_helper
INFO - 2016-02-19 11:20:51 --> Helper loaded: file_helper
INFO - 2016-02-19 11:20:51 --> Helper loaded: date_helper
INFO - 2016-02-19 11:20:51 --> Helper loaded: form_helper
INFO - 2016-02-19 11:20:51 --> Database Driver Class Initialized
INFO - 2016-02-19 11:20:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:20:52 --> Controller Class Initialized
INFO - 2016-02-19 11:20:52 --> Model Class Initialized
INFO - 2016-02-19 11:20:52 --> Model Class Initialized
INFO - 2016-02-19 11:20:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:20:52 --> Pagination Class Initialized
INFO - 2016-02-19 11:20:53 --> Helper loaded: text_helper
INFO - 2016-02-19 11:20:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:20:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:20:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:20:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:20:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:20:53 --> Final output sent to browser
DEBUG - 2016-02-19 14:20:53 --> Total execution time: 1.0983
INFO - 2016-02-19 11:25:17 --> Config Class Initialized
INFO - 2016-02-19 11:25:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:25:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:25:17 --> Utf8 Class Initialized
INFO - 2016-02-19 11:25:17 --> URI Class Initialized
INFO - 2016-02-19 11:25:17 --> Router Class Initialized
INFO - 2016-02-19 11:25:17 --> Output Class Initialized
INFO - 2016-02-19 11:25:17 --> Security Class Initialized
DEBUG - 2016-02-19 11:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:25:17 --> Input Class Initialized
INFO - 2016-02-19 11:25:17 --> Language Class Initialized
INFO - 2016-02-19 11:25:17 --> Loader Class Initialized
INFO - 2016-02-19 11:25:17 --> Helper loaded: url_helper
INFO - 2016-02-19 11:25:17 --> Helper loaded: file_helper
INFO - 2016-02-19 11:25:17 --> Helper loaded: date_helper
INFO - 2016-02-19 11:25:17 --> Helper loaded: form_helper
INFO - 2016-02-19 11:25:17 --> Database Driver Class Initialized
INFO - 2016-02-19 11:25:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:25:18 --> Controller Class Initialized
INFO - 2016-02-19 11:25:18 --> Model Class Initialized
INFO - 2016-02-19 11:25:18 --> Model Class Initialized
INFO - 2016-02-19 11:25:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:25:18 --> Pagination Class Initialized
INFO - 2016-02-19 11:25:18 --> Helper loaded: text_helper
INFO - 2016-02-19 11:25:18 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:25:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:25:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:25:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:25:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:25:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:25:18 --> Final output sent to browser
DEBUG - 2016-02-19 14:25:18 --> Total execution time: 1.1915
INFO - 2016-02-19 11:34:26 --> Config Class Initialized
INFO - 2016-02-19 11:34:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:34:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:34:26 --> Utf8 Class Initialized
INFO - 2016-02-19 11:34:26 --> URI Class Initialized
INFO - 2016-02-19 11:34:26 --> Router Class Initialized
INFO - 2016-02-19 11:34:26 --> Output Class Initialized
INFO - 2016-02-19 11:34:26 --> Security Class Initialized
DEBUG - 2016-02-19 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:34:26 --> Input Class Initialized
INFO - 2016-02-19 11:34:26 --> Language Class Initialized
INFO - 2016-02-19 11:34:26 --> Loader Class Initialized
INFO - 2016-02-19 11:34:26 --> Helper loaded: url_helper
INFO - 2016-02-19 11:34:26 --> Helper loaded: file_helper
INFO - 2016-02-19 11:34:26 --> Helper loaded: date_helper
INFO - 2016-02-19 11:34:26 --> Helper loaded: form_helper
INFO - 2016-02-19 11:34:26 --> Database Driver Class Initialized
INFO - 2016-02-19 11:34:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:34:27 --> Controller Class Initialized
INFO - 2016-02-19 11:34:27 --> Model Class Initialized
INFO - 2016-02-19 11:34:27 --> Model Class Initialized
INFO - 2016-02-19 11:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:34:27 --> Pagination Class Initialized
INFO - 2016-02-19 11:34:27 --> Helper loaded: text_helper
INFO - 2016-02-19 11:34:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:34:27 --> Final output sent to browser
DEBUG - 2016-02-19 14:34:27 --> Total execution time: 1.2096
INFO - 2016-02-19 11:34:29 --> Config Class Initialized
INFO - 2016-02-19 11:34:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:34:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:34:29 --> Utf8 Class Initialized
INFO - 2016-02-19 11:34:29 --> URI Class Initialized
INFO - 2016-02-19 11:34:29 --> Router Class Initialized
INFO - 2016-02-19 11:34:29 --> Output Class Initialized
INFO - 2016-02-19 11:34:29 --> Security Class Initialized
DEBUG - 2016-02-19 11:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:34:29 --> Input Class Initialized
INFO - 2016-02-19 11:34:29 --> Language Class Initialized
INFO - 2016-02-19 11:34:29 --> Loader Class Initialized
INFO - 2016-02-19 11:34:29 --> Helper loaded: url_helper
INFO - 2016-02-19 11:34:29 --> Helper loaded: file_helper
INFO - 2016-02-19 11:34:29 --> Helper loaded: date_helper
INFO - 2016-02-19 11:34:29 --> Helper loaded: form_helper
INFO - 2016-02-19 11:34:29 --> Database Driver Class Initialized
INFO - 2016-02-19 11:34:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:34:30 --> Controller Class Initialized
INFO - 2016-02-19 11:34:30 --> Model Class Initialized
INFO - 2016-02-19 11:34:30 --> Model Class Initialized
INFO - 2016-02-19 11:34:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:34:30 --> Pagination Class Initialized
INFO - 2016-02-19 11:34:30 --> Helper loaded: text_helper
INFO - 2016-02-19 11:34:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:34:30 --> Final output sent to browser
DEBUG - 2016-02-19 14:34:30 --> Total execution time: 1.1828
INFO - 2016-02-19 11:34:55 --> Config Class Initialized
INFO - 2016-02-19 11:34:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:34:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:34:55 --> Utf8 Class Initialized
INFO - 2016-02-19 11:34:55 --> URI Class Initialized
INFO - 2016-02-19 11:34:55 --> Router Class Initialized
INFO - 2016-02-19 11:34:55 --> Output Class Initialized
INFO - 2016-02-19 11:34:55 --> Security Class Initialized
DEBUG - 2016-02-19 11:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:34:55 --> Input Class Initialized
INFO - 2016-02-19 11:34:55 --> Language Class Initialized
INFO - 2016-02-19 11:34:55 --> Loader Class Initialized
INFO - 2016-02-19 11:34:55 --> Helper loaded: url_helper
INFO - 2016-02-19 11:34:55 --> Helper loaded: file_helper
INFO - 2016-02-19 11:34:55 --> Helper loaded: date_helper
INFO - 2016-02-19 11:34:55 --> Helper loaded: form_helper
INFO - 2016-02-19 11:34:55 --> Database Driver Class Initialized
INFO - 2016-02-19 11:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:34:56 --> Controller Class Initialized
INFO - 2016-02-19 11:34:56 --> Model Class Initialized
INFO - 2016-02-19 11:34:56 --> Model Class Initialized
INFO - 2016-02-19 11:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:34:56 --> Pagination Class Initialized
INFO - 2016-02-19 11:34:56 --> Helper loaded: text_helper
INFO - 2016-02-19 11:34:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:34:57 --> Final output sent to browser
DEBUG - 2016-02-19 14:34:57 --> Total execution time: 1.2370
INFO - 2016-02-19 11:35:23 --> Config Class Initialized
INFO - 2016-02-19 11:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:35:23 --> Utf8 Class Initialized
INFO - 2016-02-19 11:35:23 --> URI Class Initialized
INFO - 2016-02-19 11:35:23 --> Router Class Initialized
INFO - 2016-02-19 11:35:23 --> Output Class Initialized
INFO - 2016-02-19 11:35:23 --> Security Class Initialized
DEBUG - 2016-02-19 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:35:23 --> Input Class Initialized
INFO - 2016-02-19 11:35:23 --> Language Class Initialized
INFO - 2016-02-19 11:35:23 --> Loader Class Initialized
INFO - 2016-02-19 11:35:23 --> Helper loaded: url_helper
INFO - 2016-02-19 11:35:23 --> Helper loaded: file_helper
INFO - 2016-02-19 11:35:23 --> Helper loaded: date_helper
INFO - 2016-02-19 11:35:23 --> Helper loaded: form_helper
INFO - 2016-02-19 11:35:23 --> Database Driver Class Initialized
INFO - 2016-02-19 11:35:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:35:24 --> Controller Class Initialized
INFO - 2016-02-19 11:35:24 --> Model Class Initialized
INFO - 2016-02-19 11:35:24 --> Model Class Initialized
INFO - 2016-02-19 11:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:35:24 --> Pagination Class Initialized
INFO - 2016-02-19 11:35:24 --> Helper loaded: text_helper
INFO - 2016-02-19 11:35:24 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:35:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:35:24 --> Final output sent to browser
DEBUG - 2016-02-19 14:35:24 --> Total execution time: 1.1947
INFO - 2016-02-19 11:37:20 --> Config Class Initialized
INFO - 2016-02-19 11:37:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:37:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:37:20 --> Utf8 Class Initialized
INFO - 2016-02-19 11:37:20 --> URI Class Initialized
INFO - 2016-02-19 11:37:20 --> Router Class Initialized
INFO - 2016-02-19 11:37:20 --> Output Class Initialized
INFO - 2016-02-19 11:37:20 --> Security Class Initialized
DEBUG - 2016-02-19 11:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:37:20 --> Input Class Initialized
INFO - 2016-02-19 11:37:20 --> Language Class Initialized
INFO - 2016-02-19 11:37:20 --> Loader Class Initialized
INFO - 2016-02-19 11:37:20 --> Helper loaded: url_helper
INFO - 2016-02-19 11:37:20 --> Helper loaded: file_helper
INFO - 2016-02-19 11:37:20 --> Helper loaded: date_helper
INFO - 2016-02-19 11:37:20 --> Helper loaded: form_helper
INFO - 2016-02-19 11:37:20 --> Database Driver Class Initialized
INFO - 2016-02-19 11:37:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:37:21 --> Controller Class Initialized
INFO - 2016-02-19 11:37:21 --> Model Class Initialized
INFO - 2016-02-19 11:37:21 --> Model Class Initialized
INFO - 2016-02-19 11:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:37:21 --> Pagination Class Initialized
INFO - 2016-02-19 11:37:21 --> Helper loaded: text_helper
INFO - 2016-02-19 11:37:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:37:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:37:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:37:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:37:22 --> Final output sent to browser
DEBUG - 2016-02-19 14:37:22 --> Total execution time: 1.2263
INFO - 2016-02-19 11:37:23 --> Config Class Initialized
INFO - 2016-02-19 11:37:23 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:37:23 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:37:23 --> Utf8 Class Initialized
INFO - 2016-02-19 11:37:23 --> URI Class Initialized
INFO - 2016-02-19 11:37:23 --> Router Class Initialized
INFO - 2016-02-19 11:37:23 --> Output Class Initialized
INFO - 2016-02-19 11:37:23 --> Security Class Initialized
DEBUG - 2016-02-19 11:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:37:23 --> Input Class Initialized
INFO - 2016-02-19 11:37:23 --> Language Class Initialized
INFO - 2016-02-19 11:37:23 --> Loader Class Initialized
INFO - 2016-02-19 11:37:23 --> Helper loaded: url_helper
INFO - 2016-02-19 11:37:23 --> Helper loaded: file_helper
INFO - 2016-02-19 11:37:23 --> Helper loaded: date_helper
INFO - 2016-02-19 11:37:23 --> Helper loaded: form_helper
INFO - 2016-02-19 11:37:23 --> Database Driver Class Initialized
INFO - 2016-02-19 11:37:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:37:24 --> Controller Class Initialized
INFO - 2016-02-19 11:37:24 --> Model Class Initialized
INFO - 2016-02-19 11:37:24 --> Model Class Initialized
INFO - 2016-02-19 11:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:37:24 --> Pagination Class Initialized
INFO - 2016-02-19 11:37:24 --> Helper loaded: text_helper
INFO - 2016-02-19 11:37:24 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 14:37:24 --> Severity: Warning --> Missing argument 1 for Jboard::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 104
INFO - 2016-02-19 14:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-19 14:37:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-19 14:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:37:24 --> Final output sent to browser
DEBUG - 2016-02-19 14:37:24 --> Total execution time: 1.2086
INFO - 2016-02-19 11:38:09 --> Config Class Initialized
INFO - 2016-02-19 11:38:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:09 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:09 --> URI Class Initialized
INFO - 2016-02-19 11:38:09 --> Router Class Initialized
INFO - 2016-02-19 11:38:09 --> Output Class Initialized
INFO - 2016-02-19 11:38:09 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:09 --> Input Class Initialized
INFO - 2016-02-19 11:38:09 --> Language Class Initialized
INFO - 2016-02-19 11:38:09 --> Loader Class Initialized
INFO - 2016-02-19 11:38:09 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:09 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:09 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:09 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:09 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:10 --> Controller Class Initialized
INFO - 2016-02-19 11:38:10 --> Model Class Initialized
INFO - 2016-02-19 11:38:10 --> Model Class Initialized
INFO - 2016-02-19 11:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:10 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:10 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:10 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 14:38:10 --> Severity: Warning --> Missing argument 1 for Jboard::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 104
INFO - 2016-02-19 14:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-19 14:38:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 54
INFO - 2016-02-19 14:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:10 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:10 --> Total execution time: 1.1915
INFO - 2016-02-19 11:38:11 --> Config Class Initialized
INFO - 2016-02-19 11:38:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:11 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:11 --> URI Class Initialized
INFO - 2016-02-19 11:38:11 --> Router Class Initialized
INFO - 2016-02-19 11:38:11 --> Output Class Initialized
INFO - 2016-02-19 11:38:11 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:11 --> Input Class Initialized
INFO - 2016-02-19 11:38:11 --> Language Class Initialized
INFO - 2016-02-19 11:38:11 --> Loader Class Initialized
INFO - 2016-02-19 11:38:11 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:11 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:11 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:11 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:11 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:12 --> Controller Class Initialized
INFO - 2016-02-19 11:38:12 --> Model Class Initialized
INFO - 2016-02-19 11:38:12 --> Model Class Initialized
INFO - 2016-02-19 11:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:12 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:12 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:12 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:12 --> Total execution time: 1.2055
INFO - 2016-02-19 11:38:14 --> Config Class Initialized
INFO - 2016-02-19 11:38:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:14 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:14 --> URI Class Initialized
INFO - 2016-02-19 11:38:14 --> Router Class Initialized
INFO - 2016-02-19 11:38:14 --> Output Class Initialized
INFO - 2016-02-19 11:38:14 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:14 --> Input Class Initialized
INFO - 2016-02-19 11:38:14 --> Language Class Initialized
INFO - 2016-02-19 11:38:14 --> Loader Class Initialized
INFO - 2016-02-19 11:38:14 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:14 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:14 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:14 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:14 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:16 --> Controller Class Initialized
INFO - 2016-02-19 11:38:16 --> Model Class Initialized
INFO - 2016-02-19 11:38:16 --> Model Class Initialized
INFO - 2016-02-19 11:38:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:16 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:16 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:16 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:16 --> Total execution time: 1.2256
INFO - 2016-02-19 11:38:18 --> Config Class Initialized
INFO - 2016-02-19 11:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:18 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:18 --> URI Class Initialized
INFO - 2016-02-19 11:38:18 --> Router Class Initialized
INFO - 2016-02-19 11:38:18 --> Output Class Initialized
INFO - 2016-02-19 11:38:18 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:18 --> Input Class Initialized
INFO - 2016-02-19 11:38:18 --> Language Class Initialized
INFO - 2016-02-19 11:38:18 --> Loader Class Initialized
INFO - 2016-02-19 11:38:18 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:18 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:18 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:18 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:18 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:19 --> Controller Class Initialized
INFO - 2016-02-19 11:38:19 --> Model Class Initialized
INFO - 2016-02-19 11:38:19 --> Model Class Initialized
INFO - 2016-02-19 11:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:19 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:19 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:19 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:19 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:19 --> Total execution time: 1.2568
INFO - 2016-02-19 11:38:24 --> Config Class Initialized
INFO - 2016-02-19 11:38:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:24 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:24 --> URI Class Initialized
INFO - 2016-02-19 11:38:24 --> Router Class Initialized
INFO - 2016-02-19 11:38:24 --> Output Class Initialized
INFO - 2016-02-19 11:38:24 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:24 --> Input Class Initialized
INFO - 2016-02-19 11:38:24 --> Language Class Initialized
INFO - 2016-02-19 11:38:24 --> Loader Class Initialized
INFO - 2016-02-19 11:38:24 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:24 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:24 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:24 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:24 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:25 --> Controller Class Initialized
INFO - 2016-02-19 11:38:25 --> Model Class Initialized
INFO - 2016-02-19 11:38:25 --> Model Class Initialized
INFO - 2016-02-19 11:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:25 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:25 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:25 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:25 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:25 --> Total execution time: 1.1848
INFO - 2016-02-19 11:38:51 --> Config Class Initialized
INFO - 2016-02-19 11:38:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:51 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:51 --> URI Class Initialized
INFO - 2016-02-19 11:38:51 --> Router Class Initialized
INFO - 2016-02-19 11:38:51 --> Output Class Initialized
INFO - 2016-02-19 11:38:51 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:51 --> Input Class Initialized
INFO - 2016-02-19 11:38:51 --> Language Class Initialized
INFO - 2016-02-19 11:38:51 --> Loader Class Initialized
INFO - 2016-02-19 11:38:51 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:51 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:51 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:51 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:52 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:53 --> Controller Class Initialized
INFO - 2016-02-19 11:38:53 --> Model Class Initialized
INFO - 2016-02-19 11:38:53 --> Model Class Initialized
INFO - 2016-02-19 11:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:53 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:53 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:53 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:53 --> Total execution time: 1.2023
INFO - 2016-02-19 11:38:54 --> Config Class Initialized
INFO - 2016-02-19 11:38:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:54 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:54 --> URI Class Initialized
INFO - 2016-02-19 11:38:54 --> Router Class Initialized
INFO - 2016-02-19 11:38:54 --> Output Class Initialized
INFO - 2016-02-19 11:38:54 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:54 --> Input Class Initialized
INFO - 2016-02-19 11:38:54 --> Language Class Initialized
INFO - 2016-02-19 11:38:54 --> Loader Class Initialized
INFO - 2016-02-19 11:38:54 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:54 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:54 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:54 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:54 --> Database Driver Class Initialized
INFO - 2016-02-19 11:38:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:38:55 --> Controller Class Initialized
INFO - 2016-02-19 11:38:55 --> Model Class Initialized
INFO - 2016-02-19 11:38:55 --> Model Class Initialized
INFO - 2016-02-19 11:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:38:55 --> Pagination Class Initialized
INFO - 2016-02-19 11:38:55 --> Helper loaded: text_helper
INFO - 2016-02-19 11:38:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:38:55 --> Final output sent to browser
DEBUG - 2016-02-19 14:38:55 --> Total execution time: 1.1855
INFO - 2016-02-19 11:38:59 --> Config Class Initialized
INFO - 2016-02-19 11:38:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:38:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:38:59 --> Utf8 Class Initialized
INFO - 2016-02-19 11:38:59 --> URI Class Initialized
INFO - 2016-02-19 11:38:59 --> Router Class Initialized
INFO - 2016-02-19 11:38:59 --> Output Class Initialized
INFO - 2016-02-19 11:38:59 --> Security Class Initialized
DEBUG - 2016-02-19 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:38:59 --> Input Class Initialized
INFO - 2016-02-19 11:38:59 --> Language Class Initialized
INFO - 2016-02-19 11:38:59 --> Loader Class Initialized
INFO - 2016-02-19 11:38:59 --> Helper loaded: url_helper
INFO - 2016-02-19 11:38:59 --> Helper loaded: file_helper
INFO - 2016-02-19 11:38:59 --> Helper loaded: date_helper
INFO - 2016-02-19 11:38:59 --> Helper loaded: form_helper
INFO - 2016-02-19 11:38:59 --> Database Driver Class Initialized
INFO - 2016-02-19 11:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:39:00 --> Controller Class Initialized
INFO - 2016-02-19 11:39:00 --> Model Class Initialized
INFO - 2016-02-19 11:39:00 --> Model Class Initialized
INFO - 2016-02-19 11:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:39:00 --> Pagination Class Initialized
INFO - 2016-02-19 11:39:00 --> Helper loaded: text_helper
INFO - 2016-02-19 11:39:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:39:00 --> Final output sent to browser
DEBUG - 2016-02-19 14:39:00 --> Total execution time: 1.1719
INFO - 2016-02-19 11:39:02 --> Config Class Initialized
INFO - 2016-02-19 11:39:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:39:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:39:02 --> Utf8 Class Initialized
INFO - 2016-02-19 11:39:02 --> URI Class Initialized
INFO - 2016-02-19 11:39:02 --> Router Class Initialized
INFO - 2016-02-19 11:39:02 --> Output Class Initialized
INFO - 2016-02-19 11:39:02 --> Security Class Initialized
DEBUG - 2016-02-19 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:39:02 --> Input Class Initialized
INFO - 2016-02-19 11:39:02 --> Language Class Initialized
INFO - 2016-02-19 11:39:02 --> Loader Class Initialized
INFO - 2016-02-19 11:39:02 --> Helper loaded: url_helper
INFO - 2016-02-19 11:39:02 --> Helper loaded: file_helper
INFO - 2016-02-19 11:39:02 --> Helper loaded: date_helper
INFO - 2016-02-19 11:39:02 --> Helper loaded: form_helper
INFO - 2016-02-19 11:39:02 --> Database Driver Class Initialized
INFO - 2016-02-19 11:39:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:39:03 --> Controller Class Initialized
INFO - 2016-02-19 11:39:03 --> Model Class Initialized
INFO - 2016-02-19 11:39:03 --> Model Class Initialized
INFO - 2016-02-19 11:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:39:03 --> Pagination Class Initialized
INFO - 2016-02-19 11:39:03 --> Helper loaded: text_helper
INFO - 2016-02-19 11:39:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:39:03 --> Final output sent to browser
DEBUG - 2016-02-19 14:39:03 --> Total execution time: 1.1506
INFO - 2016-02-19 11:39:05 --> Config Class Initialized
INFO - 2016-02-19 11:39:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:39:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:39:05 --> Utf8 Class Initialized
INFO - 2016-02-19 11:39:05 --> URI Class Initialized
INFO - 2016-02-19 11:39:05 --> Router Class Initialized
INFO - 2016-02-19 11:39:05 --> Output Class Initialized
INFO - 2016-02-19 11:39:05 --> Security Class Initialized
DEBUG - 2016-02-19 11:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:39:05 --> Input Class Initialized
INFO - 2016-02-19 11:39:05 --> Language Class Initialized
INFO - 2016-02-19 11:39:05 --> Loader Class Initialized
INFO - 2016-02-19 11:39:05 --> Helper loaded: url_helper
INFO - 2016-02-19 11:39:05 --> Helper loaded: file_helper
INFO - 2016-02-19 11:39:05 --> Helper loaded: date_helper
INFO - 2016-02-19 11:39:05 --> Helper loaded: form_helper
INFO - 2016-02-19 11:39:05 --> Database Driver Class Initialized
INFO - 2016-02-19 11:39:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:39:06 --> Controller Class Initialized
INFO - 2016-02-19 11:39:06 --> Model Class Initialized
INFO - 2016-02-19 11:39:06 --> Model Class Initialized
INFO - 2016-02-19 11:39:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:39:06 --> Pagination Class Initialized
INFO - 2016-02-19 11:39:06 --> Helper loaded: text_helper
INFO - 2016-02-19 11:39:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 54
ERROR - 2016-02-19 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 56
INFO - 2016-02-19 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:39:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:39:06 --> Final output sent to browser
DEBUG - 2016-02-19 14:39:06 --> Total execution time: 1.1892
INFO - 2016-02-19 11:39:11 --> Config Class Initialized
INFO - 2016-02-19 11:39:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:39:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:39:11 --> Utf8 Class Initialized
INFO - 2016-02-19 11:39:11 --> URI Class Initialized
INFO - 2016-02-19 11:39:11 --> Router Class Initialized
INFO - 2016-02-19 11:39:11 --> Output Class Initialized
INFO - 2016-02-19 11:39:11 --> Security Class Initialized
DEBUG - 2016-02-19 11:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:39:11 --> Input Class Initialized
INFO - 2016-02-19 11:39:11 --> Language Class Initialized
INFO - 2016-02-19 11:39:11 --> Loader Class Initialized
INFO - 2016-02-19 11:39:11 --> Helper loaded: url_helper
INFO - 2016-02-19 11:39:11 --> Helper loaded: file_helper
INFO - 2016-02-19 11:39:11 --> Helper loaded: date_helper
INFO - 2016-02-19 11:39:11 --> Helper loaded: form_helper
INFO - 2016-02-19 11:39:11 --> Database Driver Class Initialized
INFO - 2016-02-19 11:39:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:39:12 --> Controller Class Initialized
INFO - 2016-02-19 11:39:12 --> Model Class Initialized
INFO - 2016-02-19 11:39:12 --> Model Class Initialized
INFO - 2016-02-19 11:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:39:12 --> Pagination Class Initialized
INFO - 2016-02-19 11:39:12 --> Helper loaded: text_helper
INFO - 2016-02-19 11:39:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:39:12 --> Final output sent to browser
DEBUG - 2016-02-19 14:39:12 --> Total execution time: 1.2369
INFO - 2016-02-19 11:47:32 --> Config Class Initialized
INFO - 2016-02-19 11:47:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:47:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:47:32 --> Utf8 Class Initialized
INFO - 2016-02-19 11:47:32 --> URI Class Initialized
INFO - 2016-02-19 11:47:32 --> Router Class Initialized
INFO - 2016-02-19 11:47:32 --> Output Class Initialized
INFO - 2016-02-19 11:47:32 --> Security Class Initialized
DEBUG - 2016-02-19 11:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:47:32 --> Input Class Initialized
INFO - 2016-02-19 11:47:32 --> Language Class Initialized
INFO - 2016-02-19 11:47:32 --> Loader Class Initialized
INFO - 2016-02-19 11:47:32 --> Helper loaded: url_helper
INFO - 2016-02-19 11:47:32 --> Helper loaded: file_helper
INFO - 2016-02-19 11:47:32 --> Helper loaded: date_helper
INFO - 2016-02-19 11:47:32 --> Helper loaded: form_helper
INFO - 2016-02-19 11:47:32 --> Database Driver Class Initialized
INFO - 2016-02-19 11:47:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:47:33 --> Controller Class Initialized
INFO - 2016-02-19 11:47:33 --> Model Class Initialized
INFO - 2016-02-19 11:47:33 --> Model Class Initialized
INFO - 2016-02-19 11:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:47:33 --> Pagination Class Initialized
INFO - 2016-02-19 11:47:33 --> Helper loaded: text_helper
INFO - 2016-02-19 11:47:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:47:33 --> Final output sent to browser
DEBUG - 2016-02-19 14:47:33 --> Total execution time: 1.1948
INFO - 2016-02-19 11:48:05 --> Config Class Initialized
INFO - 2016-02-19 11:48:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:48:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:48:05 --> Utf8 Class Initialized
INFO - 2016-02-19 11:48:05 --> URI Class Initialized
INFO - 2016-02-19 11:48:05 --> Router Class Initialized
INFO - 2016-02-19 11:48:05 --> Output Class Initialized
INFO - 2016-02-19 11:48:05 --> Security Class Initialized
DEBUG - 2016-02-19 11:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:48:05 --> Input Class Initialized
INFO - 2016-02-19 11:48:05 --> Language Class Initialized
INFO - 2016-02-19 11:48:05 --> Loader Class Initialized
INFO - 2016-02-19 11:48:05 --> Helper loaded: url_helper
INFO - 2016-02-19 11:48:05 --> Helper loaded: file_helper
INFO - 2016-02-19 11:48:05 --> Helper loaded: date_helper
INFO - 2016-02-19 11:48:05 --> Helper loaded: form_helper
INFO - 2016-02-19 11:48:05 --> Database Driver Class Initialized
INFO - 2016-02-19 11:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:48:06 --> Controller Class Initialized
INFO - 2016-02-19 11:48:06 --> Model Class Initialized
INFO - 2016-02-19 11:48:06 --> Model Class Initialized
INFO - 2016-02-19 11:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:48:06 --> Pagination Class Initialized
INFO - 2016-02-19 11:48:06 --> Helper loaded: text_helper
INFO - 2016-02-19 11:48:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:48:06 --> Final output sent to browser
DEBUG - 2016-02-19 14:48:06 --> Total execution time: 1.2879
INFO - 2016-02-19 11:49:12 --> Config Class Initialized
INFO - 2016-02-19 11:49:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:49:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:49:12 --> Utf8 Class Initialized
INFO - 2016-02-19 11:49:12 --> URI Class Initialized
INFO - 2016-02-19 11:49:12 --> Router Class Initialized
INFO - 2016-02-19 11:49:12 --> Output Class Initialized
INFO - 2016-02-19 11:49:12 --> Security Class Initialized
DEBUG - 2016-02-19 11:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:49:12 --> Input Class Initialized
INFO - 2016-02-19 11:49:12 --> Language Class Initialized
INFO - 2016-02-19 11:49:12 --> Loader Class Initialized
INFO - 2016-02-19 11:49:12 --> Helper loaded: url_helper
INFO - 2016-02-19 11:49:12 --> Helper loaded: file_helper
INFO - 2016-02-19 11:49:12 --> Helper loaded: date_helper
INFO - 2016-02-19 11:49:12 --> Helper loaded: form_helper
INFO - 2016-02-19 11:49:12 --> Database Driver Class Initialized
INFO - 2016-02-19 11:49:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:49:13 --> Controller Class Initialized
INFO - 2016-02-19 11:49:13 --> Model Class Initialized
INFO - 2016-02-19 11:49:13 --> Model Class Initialized
INFO - 2016-02-19 11:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:49:13 --> Pagination Class Initialized
INFO - 2016-02-19 11:49:13 --> Helper loaded: text_helper
INFO - 2016-02-19 11:49:13 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:49:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:49:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:49:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:49:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:49:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:49:13 --> Final output sent to browser
DEBUG - 2016-02-19 14:49:13 --> Total execution time: 1.3563
INFO - 2016-02-19 11:49:38 --> Config Class Initialized
INFO - 2016-02-19 11:49:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:49:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:49:38 --> Utf8 Class Initialized
INFO - 2016-02-19 11:49:38 --> URI Class Initialized
INFO - 2016-02-19 11:49:38 --> Router Class Initialized
INFO - 2016-02-19 11:49:38 --> Output Class Initialized
INFO - 2016-02-19 11:49:38 --> Security Class Initialized
DEBUG - 2016-02-19 11:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:49:38 --> Input Class Initialized
INFO - 2016-02-19 11:49:38 --> Language Class Initialized
INFO - 2016-02-19 11:49:38 --> Loader Class Initialized
INFO - 2016-02-19 11:49:38 --> Helper loaded: url_helper
INFO - 2016-02-19 11:49:38 --> Helper loaded: file_helper
INFO - 2016-02-19 11:49:38 --> Helper loaded: date_helper
INFO - 2016-02-19 11:49:38 --> Helper loaded: form_helper
INFO - 2016-02-19 11:49:38 --> Database Driver Class Initialized
INFO - 2016-02-19 11:49:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:49:39 --> Controller Class Initialized
INFO - 2016-02-19 11:49:39 --> Model Class Initialized
INFO - 2016-02-19 11:49:39 --> Model Class Initialized
INFO - 2016-02-19 11:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:49:39 --> Pagination Class Initialized
INFO - 2016-02-19 11:49:39 --> Helper loaded: text_helper
INFO - 2016-02-19 11:49:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:49:39 --> Final output sent to browser
DEBUG - 2016-02-19 14:49:39 --> Total execution time: 1.2180
INFO - 2016-02-19 11:51:24 --> Config Class Initialized
INFO - 2016-02-19 11:51:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:51:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:51:24 --> Utf8 Class Initialized
INFO - 2016-02-19 11:51:24 --> URI Class Initialized
INFO - 2016-02-19 11:51:24 --> Router Class Initialized
INFO - 2016-02-19 11:51:24 --> Output Class Initialized
INFO - 2016-02-19 11:51:24 --> Security Class Initialized
DEBUG - 2016-02-19 11:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:51:24 --> Input Class Initialized
INFO - 2016-02-19 11:51:24 --> Language Class Initialized
ERROR - 2016-02-19 11:51:24 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 131
INFO - 2016-02-19 11:57:17 --> Config Class Initialized
INFO - 2016-02-19 11:57:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:57:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:57:17 --> Utf8 Class Initialized
INFO - 2016-02-19 11:57:17 --> URI Class Initialized
INFO - 2016-02-19 11:57:17 --> Router Class Initialized
INFO - 2016-02-19 11:57:17 --> Output Class Initialized
INFO - 2016-02-19 11:57:17 --> Security Class Initialized
DEBUG - 2016-02-19 11:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:57:17 --> Input Class Initialized
INFO - 2016-02-19 11:57:17 --> Language Class Initialized
ERROR - 2016-02-19 11:57:17 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 131
INFO - 2016-02-19 11:57:18 --> Config Class Initialized
INFO - 2016-02-19 11:57:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:57:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:57:18 --> Utf8 Class Initialized
INFO - 2016-02-19 11:57:18 --> URI Class Initialized
INFO - 2016-02-19 11:57:18 --> Router Class Initialized
INFO - 2016-02-19 11:57:18 --> Output Class Initialized
INFO - 2016-02-19 11:57:18 --> Security Class Initialized
DEBUG - 2016-02-19 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:57:18 --> Input Class Initialized
INFO - 2016-02-19 11:57:18 --> Language Class Initialized
ERROR - 2016-02-19 11:57:18 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 131
INFO - 2016-02-19 11:57:39 --> Config Class Initialized
INFO - 2016-02-19 11:57:39 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:57:39 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:57:39 --> Utf8 Class Initialized
INFO - 2016-02-19 11:57:39 --> URI Class Initialized
INFO - 2016-02-19 11:57:39 --> Router Class Initialized
INFO - 2016-02-19 11:57:39 --> Output Class Initialized
INFO - 2016-02-19 11:57:39 --> Security Class Initialized
DEBUG - 2016-02-19 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:57:39 --> Input Class Initialized
INFO - 2016-02-19 11:57:39 --> Language Class Initialized
INFO - 2016-02-19 11:57:39 --> Loader Class Initialized
INFO - 2016-02-19 11:57:39 --> Helper loaded: url_helper
INFO - 2016-02-19 11:57:39 --> Helper loaded: file_helper
INFO - 2016-02-19 11:57:39 --> Helper loaded: date_helper
INFO - 2016-02-19 11:57:39 --> Helper loaded: form_helper
INFO - 2016-02-19 11:57:39 --> Database Driver Class Initialized
INFO - 2016-02-19 11:57:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:57:40 --> Controller Class Initialized
INFO - 2016-02-19 11:57:40 --> Model Class Initialized
INFO - 2016-02-19 11:57:40 --> Model Class Initialized
INFO - 2016-02-19 11:57:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:57:40 --> Pagination Class Initialized
INFO - 2016-02-19 11:57:40 --> Helper loaded: text_helper
INFO - 2016-02-19 11:57:40 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:57:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:57:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:57:40 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::get_last_id() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 131
INFO - 2016-02-19 11:57:58 --> Config Class Initialized
INFO - 2016-02-19 11:57:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:57:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:57:58 --> Utf8 Class Initialized
INFO - 2016-02-19 11:57:58 --> URI Class Initialized
INFO - 2016-02-19 11:57:58 --> Router Class Initialized
INFO - 2016-02-19 11:57:58 --> Output Class Initialized
INFO - 2016-02-19 11:57:58 --> Security Class Initialized
DEBUG - 2016-02-19 11:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:57:58 --> Input Class Initialized
INFO - 2016-02-19 11:57:58 --> Language Class Initialized
INFO - 2016-02-19 11:57:58 --> Loader Class Initialized
INFO - 2016-02-19 11:57:58 --> Helper loaded: url_helper
INFO - 2016-02-19 11:57:58 --> Helper loaded: file_helper
INFO - 2016-02-19 11:57:58 --> Helper loaded: date_helper
INFO - 2016-02-19 11:57:58 --> Helper loaded: form_helper
INFO - 2016-02-19 11:57:58 --> Database Driver Class Initialized
INFO - 2016-02-19 11:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:57:59 --> Controller Class Initialized
INFO - 2016-02-19 11:57:59 --> Model Class Initialized
INFO - 2016-02-19 11:57:59 --> Model Class Initialized
INFO - 2016-02-19 11:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:57:59 --> Pagination Class Initialized
INFO - 2016-02-19 11:57:59 --> Helper loaded: text_helper
INFO - 2016-02-19 11:57:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:57:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 14:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:57:59 --> Final output sent to browser
DEBUG - 2016-02-19 14:57:59 --> Total execution time: 1.2181
INFO - 2016-02-19 11:58:03 --> Config Class Initialized
INFO - 2016-02-19 11:58:03 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:58:03 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:58:03 --> Utf8 Class Initialized
INFO - 2016-02-19 11:58:03 --> URI Class Initialized
DEBUG - 2016-02-19 11:58:03 --> No URI present. Default controller set.
INFO - 2016-02-19 11:58:03 --> Router Class Initialized
INFO - 2016-02-19 11:58:03 --> Output Class Initialized
INFO - 2016-02-19 11:58:03 --> Security Class Initialized
DEBUG - 2016-02-19 11:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:58:03 --> Input Class Initialized
INFO - 2016-02-19 11:58:03 --> Language Class Initialized
INFO - 2016-02-19 11:58:03 --> Loader Class Initialized
INFO - 2016-02-19 11:58:03 --> Helper loaded: url_helper
INFO - 2016-02-19 11:58:03 --> Helper loaded: file_helper
INFO - 2016-02-19 11:58:03 --> Helper loaded: date_helper
INFO - 2016-02-19 11:58:03 --> Helper loaded: form_helper
INFO - 2016-02-19 11:58:03 --> Database Driver Class Initialized
INFO - 2016-02-19 11:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:58:04 --> Controller Class Initialized
INFO - 2016-02-19 11:58:04 --> Model Class Initialized
INFO - 2016-02-19 11:58:04 --> Model Class Initialized
INFO - 2016-02-19 11:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:58:04 --> Pagination Class Initialized
INFO - 2016-02-19 11:58:04 --> Helper loaded: text_helper
INFO - 2016-02-19 11:58:04 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 14:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 14:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:58:04 --> Final output sent to browser
DEBUG - 2016-02-19 14:58:04 --> Total execution time: 1.1301
INFO - 2016-02-19 11:58:09 --> Config Class Initialized
INFO - 2016-02-19 11:58:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 11:58:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 11:58:09 --> Utf8 Class Initialized
INFO - 2016-02-19 11:58:09 --> URI Class Initialized
INFO - 2016-02-19 11:58:09 --> Router Class Initialized
INFO - 2016-02-19 11:58:09 --> Output Class Initialized
INFO - 2016-02-19 11:58:09 --> Security Class Initialized
DEBUG - 2016-02-19 11:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 11:58:09 --> Input Class Initialized
INFO - 2016-02-19 11:58:09 --> Language Class Initialized
INFO - 2016-02-19 11:58:09 --> Loader Class Initialized
INFO - 2016-02-19 11:58:09 --> Helper loaded: url_helper
INFO - 2016-02-19 11:58:09 --> Helper loaded: file_helper
INFO - 2016-02-19 11:58:09 --> Helper loaded: date_helper
INFO - 2016-02-19 11:58:09 --> Helper loaded: form_helper
INFO - 2016-02-19 11:58:09 --> Database Driver Class Initialized
INFO - 2016-02-19 11:58:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 11:58:10 --> Controller Class Initialized
INFO - 2016-02-19 11:58:10 --> Model Class Initialized
INFO - 2016-02-19 11:58:10 --> Model Class Initialized
INFO - 2016-02-19 11:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 11:58:10 --> Pagination Class Initialized
INFO - 2016-02-19 11:58:10 --> Helper loaded: text_helper
INFO - 2016-02-19 11:58:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 14:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 14:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 14:58:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 14:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 14:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 14:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 14:58:10 --> Final output sent to browser
DEBUG - 2016-02-19 14:58:10 --> Total execution time: 1.1998
INFO - 2016-02-19 12:01:03 --> Config Class Initialized
INFO - 2016-02-19 12:01:03 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:01:03 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:01:03 --> Utf8 Class Initialized
INFO - 2016-02-19 12:01:03 --> URI Class Initialized
INFO - 2016-02-19 12:01:03 --> Router Class Initialized
INFO - 2016-02-19 12:01:03 --> Output Class Initialized
INFO - 2016-02-19 12:01:03 --> Security Class Initialized
DEBUG - 2016-02-19 12:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:01:03 --> Input Class Initialized
INFO - 2016-02-19 12:01:03 --> Language Class Initialized
INFO - 2016-02-19 12:01:03 --> Loader Class Initialized
INFO - 2016-02-19 12:01:03 --> Helper loaded: url_helper
INFO - 2016-02-19 12:01:03 --> Helper loaded: file_helper
INFO - 2016-02-19 12:01:03 --> Helper loaded: date_helper
INFO - 2016-02-19 12:01:03 --> Helper loaded: form_helper
INFO - 2016-02-19 12:01:03 --> Database Driver Class Initialized
INFO - 2016-02-19 12:01:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:01:04 --> Controller Class Initialized
INFO - 2016-02-19 12:01:04 --> Model Class Initialized
INFO - 2016-02-19 12:01:04 --> Model Class Initialized
INFO - 2016-02-19 12:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:01:04 --> Pagination Class Initialized
INFO - 2016-02-19 12:01:04 --> Helper loaded: text_helper
INFO - 2016-02-19 12:01:04 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:01:04 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 15:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:01:04 --> Final output sent to browser
DEBUG - 2016-02-19 15:01:04 --> Total execution time: 1.2104
INFO - 2016-02-19 12:02:54 --> Config Class Initialized
INFO - 2016-02-19 12:02:54 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:02:54 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:02:54 --> Utf8 Class Initialized
INFO - 2016-02-19 12:02:54 --> URI Class Initialized
INFO - 2016-02-19 12:02:54 --> Router Class Initialized
INFO - 2016-02-19 12:02:54 --> Output Class Initialized
INFO - 2016-02-19 12:02:54 --> Security Class Initialized
DEBUG - 2016-02-19 12:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:02:54 --> Input Class Initialized
INFO - 2016-02-19 12:02:54 --> Language Class Initialized
INFO - 2016-02-19 12:02:54 --> Loader Class Initialized
INFO - 2016-02-19 12:02:54 --> Helper loaded: url_helper
INFO - 2016-02-19 12:02:54 --> Helper loaded: file_helper
INFO - 2016-02-19 12:02:54 --> Helper loaded: date_helper
INFO - 2016-02-19 12:02:54 --> Helper loaded: form_helper
INFO - 2016-02-19 12:02:54 --> Database Driver Class Initialized
INFO - 2016-02-19 12:02:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:02:55 --> Controller Class Initialized
INFO - 2016-02-19 12:02:55 --> Model Class Initialized
INFO - 2016-02-19 12:02:55 --> Model Class Initialized
INFO - 2016-02-19 12:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:02:55 --> Pagination Class Initialized
INFO - 2016-02-19 12:02:55 --> Helper loaded: text_helper
INFO - 2016-02-19 12:02:55 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:02:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:02:56 --> Final output sent to browser
DEBUG - 2016-02-19 15:02:56 --> Total execution time: 1.2190
INFO - 2016-02-19 12:04:14 --> Config Class Initialized
INFO - 2016-02-19 12:04:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:14 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:14 --> URI Class Initialized
DEBUG - 2016-02-19 12:04:14 --> No URI present. Default controller set.
INFO - 2016-02-19 12:04:14 --> Router Class Initialized
INFO - 2016-02-19 12:04:14 --> Output Class Initialized
INFO - 2016-02-19 12:04:14 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:14 --> Input Class Initialized
INFO - 2016-02-19 12:04:14 --> Language Class Initialized
INFO - 2016-02-19 12:04:14 --> Loader Class Initialized
INFO - 2016-02-19 12:04:14 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:14 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:14 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:14 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:14 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:15 --> Controller Class Initialized
INFO - 2016-02-19 12:04:15 --> Model Class Initialized
INFO - 2016-02-19 12:04:15 --> Model Class Initialized
INFO - 2016-02-19 12:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:15 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:15 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 15:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:16 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:16 --> Total execution time: 1.1444
INFO - 2016-02-19 12:04:30 --> Config Class Initialized
INFO - 2016-02-19 12:04:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:30 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:30 --> URI Class Initialized
INFO - 2016-02-19 12:04:30 --> Router Class Initialized
INFO - 2016-02-19 12:04:30 --> Output Class Initialized
INFO - 2016-02-19 12:04:30 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:30 --> Input Class Initialized
INFO - 2016-02-19 12:04:30 --> Language Class Initialized
INFO - 2016-02-19 12:04:30 --> Loader Class Initialized
INFO - 2016-02-19 12:04:30 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:30 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:30 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:30 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:30 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:31 --> Controller Class Initialized
INFO - 2016-02-19 12:04:31 --> Model Class Initialized
INFO - 2016-02-19 12:04:31 --> Model Class Initialized
INFO - 2016-02-19 12:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:31 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:31 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 15:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:31 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:31 --> Total execution time: 1.1344
INFO - 2016-02-19 12:04:36 --> Config Class Initialized
INFO - 2016-02-19 12:04:36 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:36 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:36 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:36 --> URI Class Initialized
INFO - 2016-02-19 12:04:36 --> Router Class Initialized
INFO - 2016-02-19 12:04:36 --> Output Class Initialized
INFO - 2016-02-19 12:04:36 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:36 --> Input Class Initialized
INFO - 2016-02-19 12:04:36 --> Language Class Initialized
INFO - 2016-02-19 12:04:36 --> Loader Class Initialized
INFO - 2016-02-19 12:04:36 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:36 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:36 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:36 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:36 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:37 --> Controller Class Initialized
INFO - 2016-02-19 12:04:37 --> Model Class Initialized
INFO - 2016-02-19 12:04:37 --> Model Class Initialized
INFO - 2016-02-19 12:04:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:37 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:37 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:37 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:04:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:37 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:37 --> Total execution time: 1.1859
INFO - 2016-02-19 12:04:42 --> Config Class Initialized
INFO - 2016-02-19 12:04:42 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:42 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:42 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:42 --> URI Class Initialized
INFO - 2016-02-19 12:04:42 --> Router Class Initialized
INFO - 2016-02-19 12:04:42 --> Output Class Initialized
INFO - 2016-02-19 12:04:42 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:42 --> Input Class Initialized
INFO - 2016-02-19 12:04:42 --> Language Class Initialized
INFO - 2016-02-19 12:04:42 --> Loader Class Initialized
INFO - 2016-02-19 12:04:42 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:42 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:42 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:42 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:42 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:43 --> Controller Class Initialized
INFO - 2016-02-19 12:04:43 --> Model Class Initialized
INFO - 2016-02-19 12:04:43 --> Model Class Initialized
INFO - 2016-02-19 12:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:43 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:43 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:43 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:43 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:43 --> Total execution time: 1.1350
INFO - 2016-02-19 12:04:45 --> Config Class Initialized
INFO - 2016-02-19 12:04:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:45 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:45 --> URI Class Initialized
INFO - 2016-02-19 12:04:45 --> Router Class Initialized
INFO - 2016-02-19 12:04:45 --> Output Class Initialized
INFO - 2016-02-19 12:04:45 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:45 --> Input Class Initialized
INFO - 2016-02-19 12:04:45 --> Language Class Initialized
INFO - 2016-02-19 12:04:45 --> Loader Class Initialized
INFO - 2016-02-19 12:04:45 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:45 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:45 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:45 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:45 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:46 --> Controller Class Initialized
INFO - 2016-02-19 12:04:46 --> Model Class Initialized
INFO - 2016-02-19 12:04:46 --> Model Class Initialized
INFO - 2016-02-19 12:04:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:46 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:46 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:04:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:46 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:46 --> Total execution time: 1.1553
INFO - 2016-02-19 12:04:48 --> Config Class Initialized
INFO - 2016-02-19 12:04:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:48 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:48 --> URI Class Initialized
INFO - 2016-02-19 12:04:48 --> Router Class Initialized
INFO - 2016-02-19 12:04:48 --> Output Class Initialized
INFO - 2016-02-19 12:04:48 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:48 --> Input Class Initialized
INFO - 2016-02-19 12:04:48 --> Language Class Initialized
INFO - 2016-02-19 12:04:48 --> Loader Class Initialized
INFO - 2016-02-19 12:04:48 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:48 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:48 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:48 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:48 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:49 --> Controller Class Initialized
INFO - 2016-02-19 12:04:49 --> Model Class Initialized
INFO - 2016-02-19 12:04:49 --> Model Class Initialized
INFO - 2016-02-19 12:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:49 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:49 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:49 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 54
ERROR - 2016-02-19 15:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 56
INFO - 2016-02-19 15:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:49 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:49 --> Total execution time: 1.1929
INFO - 2016-02-19 12:04:55 --> Config Class Initialized
INFO - 2016-02-19 12:04:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:04:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:04:55 --> Utf8 Class Initialized
INFO - 2016-02-19 12:04:55 --> URI Class Initialized
INFO - 2016-02-19 12:04:55 --> Router Class Initialized
INFO - 2016-02-19 12:04:55 --> Output Class Initialized
INFO - 2016-02-19 12:04:55 --> Security Class Initialized
DEBUG - 2016-02-19 12:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:04:55 --> Input Class Initialized
INFO - 2016-02-19 12:04:55 --> Language Class Initialized
INFO - 2016-02-19 12:04:55 --> Loader Class Initialized
INFO - 2016-02-19 12:04:55 --> Helper loaded: url_helper
INFO - 2016-02-19 12:04:55 --> Helper loaded: file_helper
INFO - 2016-02-19 12:04:55 --> Helper loaded: date_helper
INFO - 2016-02-19 12:04:55 --> Helper loaded: form_helper
INFO - 2016-02-19 12:04:55 --> Database Driver Class Initialized
INFO - 2016-02-19 12:04:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:04:56 --> Controller Class Initialized
INFO - 2016-02-19 12:04:56 --> Model Class Initialized
INFO - 2016-02-19 12:04:56 --> Model Class Initialized
INFO - 2016-02-19 12:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:04:56 --> Pagination Class Initialized
INFO - 2016-02-19 12:04:56 --> Helper loaded: text_helper
INFO - 2016-02-19 12:04:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:04:56 --> Final output sent to browser
DEBUG - 2016-02-19 15:04:56 --> Total execution time: 1.2129
INFO - 2016-02-19 12:09:44 --> Config Class Initialized
INFO - 2016-02-19 12:09:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:09:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:09:44 --> Utf8 Class Initialized
INFO - 2016-02-19 12:09:44 --> URI Class Initialized
INFO - 2016-02-19 12:09:44 --> Router Class Initialized
INFO - 2016-02-19 12:09:44 --> Output Class Initialized
INFO - 2016-02-19 12:09:44 --> Security Class Initialized
DEBUG - 2016-02-19 12:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:09:44 --> Input Class Initialized
INFO - 2016-02-19 12:09:44 --> Language Class Initialized
INFO - 2016-02-19 12:09:44 --> Loader Class Initialized
INFO - 2016-02-19 12:09:44 --> Helper loaded: url_helper
INFO - 2016-02-19 12:09:44 --> Helper loaded: file_helper
INFO - 2016-02-19 12:09:44 --> Helper loaded: date_helper
INFO - 2016-02-19 12:09:44 --> Helper loaded: form_helper
INFO - 2016-02-19 12:09:44 --> Database Driver Class Initialized
INFO - 2016-02-19 12:09:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:09:45 --> Controller Class Initialized
INFO - 2016-02-19 12:09:45 --> Model Class Initialized
INFO - 2016-02-19 12:09:45 --> Model Class Initialized
INFO - 2016-02-19 12:09:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:09:45 --> Pagination Class Initialized
INFO - 2016-02-19 12:09:45 --> Helper loaded: text_helper
INFO - 2016-02-19 12:09:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:09:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 57
ERROR - 2016-02-19 15:09:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 15:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:09:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:09:45 --> Final output sent to browser
DEBUG - 2016-02-19 15:09:45 --> Total execution time: 1.2358
INFO - 2016-02-19 12:10:06 --> Config Class Initialized
INFO - 2016-02-19 12:10:06 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:10:06 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:10:06 --> Utf8 Class Initialized
INFO - 2016-02-19 12:10:06 --> URI Class Initialized
INFO - 2016-02-19 12:10:06 --> Router Class Initialized
INFO - 2016-02-19 12:10:06 --> Output Class Initialized
INFO - 2016-02-19 12:10:06 --> Security Class Initialized
DEBUG - 2016-02-19 12:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:10:06 --> Input Class Initialized
INFO - 2016-02-19 12:10:06 --> Language Class Initialized
INFO - 2016-02-19 12:10:06 --> Loader Class Initialized
INFO - 2016-02-19 12:10:06 --> Helper loaded: url_helper
INFO - 2016-02-19 12:10:06 --> Helper loaded: file_helper
INFO - 2016-02-19 12:10:06 --> Helper loaded: date_helper
INFO - 2016-02-19 12:10:06 --> Helper loaded: form_helper
INFO - 2016-02-19 12:10:06 --> Database Driver Class Initialized
INFO - 2016-02-19 12:10:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:10:08 --> Controller Class Initialized
INFO - 2016-02-19 12:10:08 --> Model Class Initialized
INFO - 2016-02-19 12:10:08 --> Model Class Initialized
INFO - 2016-02-19 12:10:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:10:08 --> Pagination Class Initialized
INFO - 2016-02-19 12:10:08 --> Helper loaded: text_helper
INFO - 2016-02-19 12:10:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:10:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:10:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:10:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 15:10:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:10:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:10:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:10:08 --> Final output sent to browser
DEBUG - 2016-02-19 15:10:08 --> Total execution time: 1.2554
INFO - 2016-02-19 12:10:58 --> Config Class Initialized
INFO - 2016-02-19 12:10:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:10:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:10:58 --> Utf8 Class Initialized
INFO - 2016-02-19 12:10:58 --> URI Class Initialized
INFO - 2016-02-19 12:10:58 --> Router Class Initialized
INFO - 2016-02-19 12:10:58 --> Output Class Initialized
INFO - 2016-02-19 12:10:58 --> Security Class Initialized
DEBUG - 2016-02-19 12:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:10:58 --> Input Class Initialized
INFO - 2016-02-19 12:10:58 --> Language Class Initialized
INFO - 2016-02-19 12:10:58 --> Loader Class Initialized
INFO - 2016-02-19 12:10:58 --> Helper loaded: url_helper
INFO - 2016-02-19 12:10:58 --> Helper loaded: file_helper
INFO - 2016-02-19 12:10:58 --> Helper loaded: date_helper
INFO - 2016-02-19 12:10:58 --> Helper loaded: form_helper
INFO - 2016-02-19 12:10:58 --> Database Driver Class Initialized
INFO - 2016-02-19 12:10:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:10:59 --> Controller Class Initialized
INFO - 2016-02-19 12:10:59 --> Model Class Initialized
INFO - 2016-02-19 12:10:59 --> Model Class Initialized
INFO - 2016-02-19 12:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:10:59 --> Pagination Class Initialized
INFO - 2016-02-19 12:10:59 --> Helper loaded: text_helper
INFO - 2016-02-19 12:10:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:10:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 15:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:10:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:10:59 --> Final output sent to browser
DEBUG - 2016-02-19 15:10:59 --> Total execution time: 1.2212
INFO - 2016-02-19 12:11:53 --> Config Class Initialized
INFO - 2016-02-19 12:11:53 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:11:53 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:11:53 --> Utf8 Class Initialized
INFO - 2016-02-19 12:11:53 --> URI Class Initialized
INFO - 2016-02-19 12:11:53 --> Router Class Initialized
INFO - 2016-02-19 12:11:53 --> Output Class Initialized
INFO - 2016-02-19 12:11:53 --> Security Class Initialized
DEBUG - 2016-02-19 12:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:11:53 --> Input Class Initialized
INFO - 2016-02-19 12:11:53 --> Language Class Initialized
INFO - 2016-02-19 12:11:53 --> Loader Class Initialized
INFO - 2016-02-19 12:11:53 --> Helper loaded: url_helper
INFO - 2016-02-19 12:11:53 --> Helper loaded: file_helper
INFO - 2016-02-19 12:11:53 --> Helper loaded: date_helper
INFO - 2016-02-19 12:11:53 --> Helper loaded: form_helper
INFO - 2016-02-19 12:11:53 --> Database Driver Class Initialized
INFO - 2016-02-19 12:11:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:11:54 --> Controller Class Initialized
INFO - 2016-02-19 12:11:54 --> Model Class Initialized
INFO - 2016-02-19 12:11:54 --> Model Class Initialized
INFO - 2016-02-19 12:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:11:54 --> Pagination Class Initialized
INFO - 2016-02-19 12:11:54 --> Helper loaded: text_helper
INFO - 2016-02-19 12:11:54 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:11:54 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 15:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:11:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:11:54 --> Final output sent to browser
DEBUG - 2016-02-19 15:11:54 --> Total execution time: 1.2017
INFO - 2016-02-19 12:13:48 --> Config Class Initialized
INFO - 2016-02-19 12:13:48 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:13:48 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:13:49 --> Utf8 Class Initialized
INFO - 2016-02-19 12:13:49 --> URI Class Initialized
INFO - 2016-02-19 12:13:49 --> Router Class Initialized
INFO - 2016-02-19 12:13:49 --> Output Class Initialized
INFO - 2016-02-19 12:13:49 --> Security Class Initialized
DEBUG - 2016-02-19 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:13:49 --> Input Class Initialized
INFO - 2016-02-19 12:13:49 --> Language Class Initialized
INFO - 2016-02-19 12:13:49 --> Loader Class Initialized
INFO - 2016-02-19 12:13:49 --> Helper loaded: url_helper
INFO - 2016-02-19 12:13:49 --> Helper loaded: file_helper
INFO - 2016-02-19 12:13:49 --> Helper loaded: date_helper
INFO - 2016-02-19 12:13:49 --> Helper loaded: form_helper
INFO - 2016-02-19 12:13:49 --> Database Driver Class Initialized
INFO - 2016-02-19 12:13:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:13:50 --> Controller Class Initialized
INFO - 2016-02-19 12:13:50 --> Model Class Initialized
INFO - 2016-02-19 12:13:50 --> Model Class Initialized
INFO - 2016-02-19 12:13:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:13:50 --> Pagination Class Initialized
INFO - 2016-02-19 12:13:50 --> Helper loaded: text_helper
INFO - 2016-02-19 12:13:50 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:13:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 15:13:50 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 12:15:29 --> Config Class Initialized
INFO - 2016-02-19 12:15:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 12:15:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 12:15:29 --> Utf8 Class Initialized
INFO - 2016-02-19 12:15:29 --> URI Class Initialized
INFO - 2016-02-19 12:15:29 --> Router Class Initialized
INFO - 2016-02-19 12:15:29 --> Output Class Initialized
INFO - 2016-02-19 12:15:29 --> Security Class Initialized
DEBUG - 2016-02-19 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 12:15:29 --> Input Class Initialized
INFO - 2016-02-19 12:15:29 --> Language Class Initialized
INFO - 2016-02-19 12:15:29 --> Loader Class Initialized
INFO - 2016-02-19 12:15:29 --> Helper loaded: url_helper
INFO - 2016-02-19 12:15:29 --> Helper loaded: file_helper
INFO - 2016-02-19 12:15:29 --> Helper loaded: date_helper
INFO - 2016-02-19 12:15:29 --> Helper loaded: form_helper
INFO - 2016-02-19 12:15:29 --> Database Driver Class Initialized
INFO - 2016-02-19 12:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 12:15:30 --> Controller Class Initialized
INFO - 2016-02-19 12:15:30 --> Model Class Initialized
INFO - 2016-02-19 12:15:30 --> Model Class Initialized
INFO - 2016-02-19 12:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 12:15:30 --> Pagination Class Initialized
INFO - 2016-02-19 12:15:30 --> Helper loaded: text_helper
INFO - 2016-02-19 12:15:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 15:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 15:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 15:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 15:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 15:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 15:15:30 --> Final output sent to browser
DEBUG - 2016-02-19 15:15:30 --> Total execution time: 1.2007
INFO - 2016-02-19 13:10:18 --> Config Class Initialized
INFO - 2016-02-19 13:10:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:10:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:10:19 --> Utf8 Class Initialized
INFO - 2016-02-19 13:10:19 --> URI Class Initialized
INFO - 2016-02-19 13:10:19 --> Router Class Initialized
INFO - 2016-02-19 13:10:19 --> Output Class Initialized
INFO - 2016-02-19 13:10:19 --> Security Class Initialized
DEBUG - 2016-02-19 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:10:19 --> Input Class Initialized
INFO - 2016-02-19 13:10:19 --> Language Class Initialized
INFO - 2016-02-19 13:10:19 --> Loader Class Initialized
INFO - 2016-02-19 13:10:19 --> Helper loaded: url_helper
INFO - 2016-02-19 13:10:19 --> Helper loaded: file_helper
INFO - 2016-02-19 13:10:19 --> Helper loaded: date_helper
INFO - 2016-02-19 13:10:19 --> Helper loaded: form_helper
INFO - 2016-02-19 13:10:19 --> Database Driver Class Initialized
INFO - 2016-02-19 13:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:10:20 --> Controller Class Initialized
INFO - 2016-02-19 13:10:20 --> Model Class Initialized
INFO - 2016-02-19 13:10:20 --> Model Class Initialized
INFO - 2016-02-19 13:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:10:20 --> Pagination Class Initialized
INFO - 2016-02-19 13:10:20 --> Helper loaded: text_helper
INFO - 2016-02-19 13:10:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:10:20 --> Final output sent to browser
DEBUG - 2016-02-19 16:10:20 --> Total execution time: 1.2314
INFO - 2016-02-19 13:10:55 --> Config Class Initialized
INFO - 2016-02-19 13:10:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:10:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:10:55 --> Utf8 Class Initialized
INFO - 2016-02-19 13:10:55 --> URI Class Initialized
INFO - 2016-02-19 13:10:55 --> Router Class Initialized
INFO - 2016-02-19 13:10:55 --> Output Class Initialized
INFO - 2016-02-19 13:10:55 --> Security Class Initialized
DEBUG - 2016-02-19 13:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:10:55 --> Input Class Initialized
INFO - 2016-02-19 13:10:55 --> Language Class Initialized
INFO - 2016-02-19 13:10:55 --> Loader Class Initialized
INFO - 2016-02-19 13:10:55 --> Helper loaded: url_helper
INFO - 2016-02-19 13:10:55 --> Helper loaded: file_helper
INFO - 2016-02-19 13:10:55 --> Helper loaded: date_helper
INFO - 2016-02-19 13:10:55 --> Helper loaded: form_helper
INFO - 2016-02-19 13:10:55 --> Database Driver Class Initialized
INFO - 2016-02-19 13:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:10:56 --> Controller Class Initialized
INFO - 2016-02-19 13:10:56 --> Model Class Initialized
INFO - 2016-02-19 13:10:56 --> Model Class Initialized
INFO - 2016-02-19 13:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:10:56 --> Pagination Class Initialized
INFO - 2016-02-19 13:10:56 --> Helper loaded: text_helper
INFO - 2016-02-19 13:10:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:10:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 16:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:10:56 --> Final output sent to browser
DEBUG - 2016-02-19 16:10:56 --> Total execution time: 1.1733
INFO - 2016-02-19 13:11:30 --> Config Class Initialized
INFO - 2016-02-19 13:11:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:11:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:11:30 --> Utf8 Class Initialized
INFO - 2016-02-19 13:11:30 --> URI Class Initialized
INFO - 2016-02-19 13:11:30 --> Router Class Initialized
INFO - 2016-02-19 13:11:30 --> Output Class Initialized
INFO - 2016-02-19 13:11:30 --> Security Class Initialized
DEBUG - 2016-02-19 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:11:30 --> Input Class Initialized
INFO - 2016-02-19 13:11:30 --> Language Class Initialized
INFO - 2016-02-19 13:11:30 --> Loader Class Initialized
INFO - 2016-02-19 13:11:30 --> Helper loaded: url_helper
INFO - 2016-02-19 13:11:30 --> Helper loaded: file_helper
INFO - 2016-02-19 13:11:30 --> Helper loaded: date_helper
INFO - 2016-02-19 13:11:30 --> Helper loaded: form_helper
INFO - 2016-02-19 13:11:30 --> Database Driver Class Initialized
INFO - 2016-02-19 13:11:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:11:31 --> Controller Class Initialized
INFO - 2016-02-19 13:11:31 --> Model Class Initialized
INFO - 2016-02-19 13:11:31 --> Model Class Initialized
INFO - 2016-02-19 13:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:11:31 --> Pagination Class Initialized
INFO - 2016-02-19 13:11:31 --> Helper loaded: text_helper
INFO - 2016-02-19 13:11:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:11:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 59
INFO - 2016-02-19 16:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:11:31 --> Final output sent to browser
DEBUG - 2016-02-19 16:11:31 --> Total execution time: 1.1920
INFO - 2016-02-19 13:12:35 --> Config Class Initialized
INFO - 2016-02-19 13:12:35 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:12:35 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:12:35 --> Utf8 Class Initialized
INFO - 2016-02-19 13:12:35 --> URI Class Initialized
DEBUG - 2016-02-19 13:12:35 --> No URI present. Default controller set.
INFO - 2016-02-19 13:12:35 --> Router Class Initialized
INFO - 2016-02-19 13:12:35 --> Output Class Initialized
INFO - 2016-02-19 13:12:35 --> Security Class Initialized
DEBUG - 2016-02-19 13:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:12:35 --> Input Class Initialized
INFO - 2016-02-19 13:12:35 --> Language Class Initialized
INFO - 2016-02-19 13:12:35 --> Loader Class Initialized
INFO - 2016-02-19 13:12:35 --> Helper loaded: url_helper
INFO - 2016-02-19 13:12:35 --> Helper loaded: file_helper
INFO - 2016-02-19 13:12:35 --> Helper loaded: date_helper
INFO - 2016-02-19 13:12:35 --> Helper loaded: form_helper
INFO - 2016-02-19 13:12:35 --> Database Driver Class Initialized
INFO - 2016-02-19 13:12:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:12:36 --> Controller Class Initialized
INFO - 2016-02-19 13:12:36 --> Model Class Initialized
INFO - 2016-02-19 13:12:36 --> Model Class Initialized
INFO - 2016-02-19 13:12:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:12:36 --> Pagination Class Initialized
INFO - 2016-02-19 13:12:36 --> Helper loaded: text_helper
INFO - 2016-02-19 13:12:36 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:12:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:12:36 --> Final output sent to browser
DEBUG - 2016-02-19 16:12:36 --> Total execution time: 1.1421
INFO - 2016-02-19 13:12:42 --> Config Class Initialized
INFO - 2016-02-19 13:12:42 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:12:42 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:12:42 --> Utf8 Class Initialized
INFO - 2016-02-19 13:12:42 --> URI Class Initialized
INFO - 2016-02-19 13:12:42 --> Router Class Initialized
INFO - 2016-02-19 13:12:42 --> Output Class Initialized
INFO - 2016-02-19 13:12:42 --> Security Class Initialized
DEBUG - 2016-02-19 13:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:12:42 --> Input Class Initialized
INFO - 2016-02-19 13:12:42 --> Language Class Initialized
INFO - 2016-02-19 13:12:42 --> Loader Class Initialized
INFO - 2016-02-19 13:12:42 --> Helper loaded: url_helper
INFO - 2016-02-19 13:12:42 --> Helper loaded: file_helper
INFO - 2016-02-19 13:12:42 --> Helper loaded: date_helper
INFO - 2016-02-19 13:12:42 --> Helper loaded: form_helper
INFO - 2016-02-19 13:12:42 --> Database Driver Class Initialized
INFO - 2016-02-19 13:12:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:12:43 --> Controller Class Initialized
INFO - 2016-02-19 13:12:43 --> Model Class Initialized
INFO - 2016-02-19 13:12:43 --> Model Class Initialized
INFO - 2016-02-19 13:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:12:43 --> Pagination Class Initialized
INFO - 2016-02-19 13:12:43 --> Helper loaded: text_helper
INFO - 2016-02-19 13:12:43 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:12:43 --> Final output sent to browser
DEBUG - 2016-02-19 16:12:43 --> Total execution time: 1.1919
INFO - 2016-02-19 13:12:56 --> Config Class Initialized
INFO - 2016-02-19 13:12:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:12:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:12:56 --> Utf8 Class Initialized
INFO - 2016-02-19 13:12:56 --> URI Class Initialized
INFO - 2016-02-19 13:12:56 --> Router Class Initialized
INFO - 2016-02-19 13:12:56 --> Output Class Initialized
INFO - 2016-02-19 13:12:56 --> Security Class Initialized
DEBUG - 2016-02-19 13:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:12:56 --> Input Class Initialized
INFO - 2016-02-19 13:12:56 --> Language Class Initialized
INFO - 2016-02-19 13:12:56 --> Loader Class Initialized
INFO - 2016-02-19 13:12:56 --> Helper loaded: url_helper
INFO - 2016-02-19 13:12:56 --> Helper loaded: file_helper
INFO - 2016-02-19 13:12:56 --> Helper loaded: date_helper
INFO - 2016-02-19 13:12:56 --> Helper loaded: form_helper
INFO - 2016-02-19 13:12:56 --> Database Driver Class Initialized
INFO - 2016-02-19 13:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:12:57 --> Controller Class Initialized
INFO - 2016-02-19 13:12:57 --> Model Class Initialized
INFO - 2016-02-19 13:12:57 --> Model Class Initialized
INFO - 2016-02-19 13:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:12:57 --> Pagination Class Initialized
INFO - 2016-02-19 13:12:57 --> Helper loaded: text_helper
INFO - 2016-02-19 13:12:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:12:57 --> Final output sent to browser
DEBUG - 2016-02-19 16:12:57 --> Total execution time: 1.5100
INFO - 2016-02-19 13:13:16 --> Config Class Initialized
INFO - 2016-02-19 13:13:16 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:13:16 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:13:16 --> Utf8 Class Initialized
INFO - 2016-02-19 13:13:16 --> URI Class Initialized
DEBUG - 2016-02-19 13:13:16 --> No URI present. Default controller set.
INFO - 2016-02-19 13:13:16 --> Router Class Initialized
INFO - 2016-02-19 13:13:16 --> Output Class Initialized
INFO - 2016-02-19 13:13:16 --> Security Class Initialized
DEBUG - 2016-02-19 13:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:13:16 --> Input Class Initialized
INFO - 2016-02-19 13:13:16 --> Language Class Initialized
INFO - 2016-02-19 13:13:16 --> Loader Class Initialized
INFO - 2016-02-19 13:13:16 --> Helper loaded: url_helper
INFO - 2016-02-19 13:13:16 --> Helper loaded: file_helper
INFO - 2016-02-19 13:13:16 --> Helper loaded: date_helper
INFO - 2016-02-19 13:13:16 --> Helper loaded: form_helper
INFO - 2016-02-19 13:13:16 --> Database Driver Class Initialized
INFO - 2016-02-19 13:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:13:17 --> Controller Class Initialized
INFO - 2016-02-19 13:13:17 --> Model Class Initialized
INFO - 2016-02-19 13:13:17 --> Model Class Initialized
INFO - 2016-02-19 13:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:13:17 --> Pagination Class Initialized
INFO - 2016-02-19 13:13:17 --> Helper loaded: text_helper
INFO - 2016-02-19 13:13:17 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:13:17 --> Final output sent to browser
DEBUG - 2016-02-19 16:13:17 --> Total execution time: 1.1650
INFO - 2016-02-19 13:13:20 --> Config Class Initialized
INFO - 2016-02-19 13:13:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:13:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:13:20 --> Utf8 Class Initialized
INFO - 2016-02-19 13:13:20 --> URI Class Initialized
INFO - 2016-02-19 13:13:20 --> Router Class Initialized
INFO - 2016-02-19 13:13:20 --> Output Class Initialized
INFO - 2016-02-19 13:13:20 --> Security Class Initialized
DEBUG - 2016-02-19 13:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:13:20 --> Input Class Initialized
INFO - 2016-02-19 13:13:20 --> Language Class Initialized
INFO - 2016-02-19 13:13:20 --> Loader Class Initialized
INFO - 2016-02-19 13:13:20 --> Helper loaded: url_helper
INFO - 2016-02-19 13:13:20 --> Helper loaded: file_helper
INFO - 2016-02-19 13:13:20 --> Helper loaded: date_helper
INFO - 2016-02-19 13:13:20 --> Helper loaded: form_helper
INFO - 2016-02-19 13:13:20 --> Database Driver Class Initialized
INFO - 2016-02-19 13:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:13:21 --> Controller Class Initialized
INFO - 2016-02-19 13:13:21 --> Model Class Initialized
INFO - 2016-02-19 13:13:21 --> Model Class Initialized
INFO - 2016-02-19 13:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:13:21 --> Pagination Class Initialized
INFO - 2016-02-19 13:13:21 --> Helper loaded: text_helper
INFO - 2016-02-19 13:13:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:13:21 --> Final output sent to browser
DEBUG - 2016-02-19 16:13:21 --> Total execution time: 1.1388
INFO - 2016-02-19 13:15:15 --> Config Class Initialized
INFO - 2016-02-19 13:15:15 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:15:15 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:15:15 --> Utf8 Class Initialized
INFO - 2016-02-19 13:15:15 --> URI Class Initialized
INFO - 2016-02-19 13:15:15 --> Router Class Initialized
INFO - 2016-02-19 13:15:15 --> Output Class Initialized
INFO - 2016-02-19 13:15:15 --> Security Class Initialized
DEBUG - 2016-02-19 13:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:15:15 --> Input Class Initialized
INFO - 2016-02-19 13:15:15 --> Language Class Initialized
INFO - 2016-02-19 13:15:15 --> Loader Class Initialized
INFO - 2016-02-19 13:15:15 --> Helper loaded: url_helper
INFO - 2016-02-19 13:15:15 --> Helper loaded: file_helper
INFO - 2016-02-19 13:15:15 --> Helper loaded: date_helper
INFO - 2016-02-19 13:15:15 --> Helper loaded: form_helper
INFO - 2016-02-19 13:15:15 --> Database Driver Class Initialized
INFO - 2016-02-19 13:15:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:15:16 --> Controller Class Initialized
INFO - 2016-02-19 13:15:16 --> Model Class Initialized
INFO - 2016-02-19 13:15:16 --> Model Class Initialized
INFO - 2016-02-19 13:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:15:16 --> Pagination Class Initialized
INFO - 2016-02-19 13:15:16 --> Helper loaded: text_helper
INFO - 2016-02-19 13:15:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:15:16 --> Final output sent to browser
DEBUG - 2016-02-19 16:15:16 --> Total execution time: 1.1253
INFO - 2016-02-19 13:15:26 --> Config Class Initialized
INFO - 2016-02-19 13:15:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:15:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:15:26 --> Utf8 Class Initialized
INFO - 2016-02-19 13:15:26 --> URI Class Initialized
INFO - 2016-02-19 13:15:26 --> Router Class Initialized
INFO - 2016-02-19 13:15:26 --> Output Class Initialized
INFO - 2016-02-19 13:15:26 --> Security Class Initialized
DEBUG - 2016-02-19 13:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:15:26 --> Input Class Initialized
INFO - 2016-02-19 13:15:26 --> Language Class Initialized
INFO - 2016-02-19 13:15:26 --> Loader Class Initialized
INFO - 2016-02-19 13:15:26 --> Helper loaded: url_helper
INFO - 2016-02-19 13:15:26 --> Helper loaded: file_helper
INFO - 2016-02-19 13:15:26 --> Helper loaded: date_helper
INFO - 2016-02-19 13:15:26 --> Helper loaded: form_helper
INFO - 2016-02-19 13:15:26 --> Database Driver Class Initialized
INFO - 2016-02-19 13:15:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:15:27 --> Controller Class Initialized
INFO - 2016-02-19 13:15:27 --> Model Class Initialized
INFO - 2016-02-19 13:15:27 --> Model Class Initialized
INFO - 2016-02-19 13:15:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:15:27 --> Pagination Class Initialized
INFO - 2016-02-19 13:15:27 --> Helper loaded: text_helper
INFO - 2016-02-19 13:15:27 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:15:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:15:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:15:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:15:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:15:27 --> Final output sent to browser
DEBUG - 2016-02-19 16:15:27 --> Total execution time: 1.1039
INFO - 2016-02-19 13:16:44 --> Config Class Initialized
INFO - 2016-02-19 13:16:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:16:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:16:44 --> Utf8 Class Initialized
INFO - 2016-02-19 13:16:44 --> URI Class Initialized
INFO - 2016-02-19 13:16:44 --> Router Class Initialized
INFO - 2016-02-19 13:16:44 --> Output Class Initialized
INFO - 2016-02-19 13:16:44 --> Security Class Initialized
DEBUG - 2016-02-19 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:16:44 --> Input Class Initialized
INFO - 2016-02-19 13:16:44 --> Language Class Initialized
INFO - 2016-02-19 13:16:44 --> Loader Class Initialized
INFO - 2016-02-19 13:16:44 --> Helper loaded: url_helper
INFO - 2016-02-19 13:16:44 --> Helper loaded: file_helper
INFO - 2016-02-19 13:16:44 --> Helper loaded: date_helper
INFO - 2016-02-19 13:16:44 --> Helper loaded: form_helper
INFO - 2016-02-19 13:16:44 --> Database Driver Class Initialized
INFO - 2016-02-19 13:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:16:45 --> Controller Class Initialized
INFO - 2016-02-19 13:16:45 --> Model Class Initialized
INFO - 2016-02-19 13:16:45 --> Model Class Initialized
INFO - 2016-02-19 13:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:16:45 --> Pagination Class Initialized
INFO - 2016-02-19 13:16:45 --> Helper loaded: text_helper
INFO - 2016-02-19 13:16:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:16:45 --> Final output sent to browser
DEBUG - 2016-02-19 16:16:45 --> Total execution time: 1.1806
INFO - 2016-02-19 13:16:52 --> Config Class Initialized
INFO - 2016-02-19 13:16:52 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:16:52 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:16:52 --> Utf8 Class Initialized
INFO - 2016-02-19 13:16:52 --> URI Class Initialized
INFO - 2016-02-19 13:16:52 --> Router Class Initialized
INFO - 2016-02-19 13:16:52 --> Output Class Initialized
INFO - 2016-02-19 13:16:52 --> Security Class Initialized
DEBUG - 2016-02-19 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:16:52 --> Input Class Initialized
INFO - 2016-02-19 13:16:52 --> Language Class Initialized
INFO - 2016-02-19 13:16:52 --> Loader Class Initialized
INFO - 2016-02-19 13:16:52 --> Helper loaded: url_helper
INFO - 2016-02-19 13:16:52 --> Helper loaded: file_helper
INFO - 2016-02-19 13:16:52 --> Helper loaded: date_helper
INFO - 2016-02-19 13:16:52 --> Helper loaded: form_helper
INFO - 2016-02-19 13:16:52 --> Database Driver Class Initialized
INFO - 2016-02-19 13:16:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:16:53 --> Controller Class Initialized
INFO - 2016-02-19 13:16:53 --> Model Class Initialized
INFO - 2016-02-19 13:16:53 --> Model Class Initialized
INFO - 2016-02-19 13:16:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:16:53 --> Pagination Class Initialized
INFO - 2016-02-19 13:16:53 --> Helper loaded: text_helper
INFO - 2016-02-19 13:16:53 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:16:53 --> Final output sent to browser
DEBUG - 2016-02-19 16:16:53 --> Total execution time: 1.1418
INFO - 2016-02-19 13:18:57 --> Config Class Initialized
INFO - 2016-02-19 13:18:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:18:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:18:57 --> Utf8 Class Initialized
INFO - 2016-02-19 13:18:57 --> URI Class Initialized
INFO - 2016-02-19 13:18:57 --> Router Class Initialized
INFO - 2016-02-19 13:18:57 --> Output Class Initialized
INFO - 2016-02-19 13:18:57 --> Security Class Initialized
DEBUG - 2016-02-19 13:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:18:57 --> Input Class Initialized
INFO - 2016-02-19 13:18:57 --> Language Class Initialized
INFO - 2016-02-19 13:18:57 --> Loader Class Initialized
INFO - 2016-02-19 13:18:57 --> Helper loaded: url_helper
INFO - 2016-02-19 13:18:57 --> Helper loaded: file_helper
INFO - 2016-02-19 13:18:57 --> Helper loaded: date_helper
INFO - 2016-02-19 13:18:57 --> Helper loaded: form_helper
INFO - 2016-02-19 13:18:57 --> Database Driver Class Initialized
INFO - 2016-02-19 13:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:18:58 --> Controller Class Initialized
INFO - 2016-02-19 13:18:58 --> Model Class Initialized
INFO - 2016-02-19 13:18:58 --> Model Class Initialized
INFO - 2016-02-19 13:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:18:58 --> Pagination Class Initialized
INFO - 2016-02-19 13:18:58 --> Helper loaded: text_helper
INFO - 2016-02-19 13:18:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:18:58 --> Final output sent to browser
DEBUG - 2016-02-19 16:18:58 --> Total execution time: 1.1664
INFO - 2016-02-19 13:19:02 --> Config Class Initialized
INFO - 2016-02-19 13:19:02 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:19:02 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:19:02 --> Utf8 Class Initialized
INFO - 2016-02-19 13:19:02 --> URI Class Initialized
DEBUG - 2016-02-19 13:19:02 --> No URI present. Default controller set.
INFO - 2016-02-19 13:19:02 --> Router Class Initialized
INFO - 2016-02-19 13:19:02 --> Output Class Initialized
INFO - 2016-02-19 13:19:02 --> Security Class Initialized
DEBUG - 2016-02-19 13:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:19:02 --> Input Class Initialized
INFO - 2016-02-19 13:19:02 --> Language Class Initialized
INFO - 2016-02-19 13:19:02 --> Loader Class Initialized
INFO - 2016-02-19 13:19:02 --> Helper loaded: url_helper
INFO - 2016-02-19 13:19:02 --> Helper loaded: file_helper
INFO - 2016-02-19 13:19:02 --> Helper loaded: date_helper
INFO - 2016-02-19 13:19:02 --> Helper loaded: form_helper
INFO - 2016-02-19 13:19:02 --> Database Driver Class Initialized
INFO - 2016-02-19 13:19:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:19:03 --> Controller Class Initialized
INFO - 2016-02-19 13:19:03 --> Model Class Initialized
INFO - 2016-02-19 13:19:03 --> Model Class Initialized
INFO - 2016-02-19 13:19:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:19:03 --> Pagination Class Initialized
INFO - 2016-02-19 13:19:03 --> Helper loaded: text_helper
INFO - 2016-02-19 13:19:03 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:19:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:19:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:19:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:19:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:19:03 --> Final output sent to browser
DEBUG - 2016-02-19 16:19:03 --> Total execution time: 1.1540
INFO - 2016-02-19 13:19:18 --> Config Class Initialized
INFO - 2016-02-19 13:19:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:19:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:19:18 --> Utf8 Class Initialized
INFO - 2016-02-19 13:19:18 --> URI Class Initialized
DEBUG - 2016-02-19 13:19:18 --> No URI present. Default controller set.
INFO - 2016-02-19 13:19:18 --> Router Class Initialized
INFO - 2016-02-19 13:19:18 --> Output Class Initialized
INFO - 2016-02-19 13:19:18 --> Security Class Initialized
DEBUG - 2016-02-19 13:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:19:18 --> Input Class Initialized
INFO - 2016-02-19 13:19:18 --> Language Class Initialized
INFO - 2016-02-19 13:19:18 --> Loader Class Initialized
INFO - 2016-02-19 13:19:18 --> Helper loaded: url_helper
INFO - 2016-02-19 13:19:18 --> Helper loaded: file_helper
INFO - 2016-02-19 13:19:18 --> Helper loaded: date_helper
INFO - 2016-02-19 13:19:18 --> Helper loaded: form_helper
INFO - 2016-02-19 13:19:18 --> Database Driver Class Initialized
INFO - 2016-02-19 13:19:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:19:19 --> Controller Class Initialized
INFO - 2016-02-19 13:19:19 --> Model Class Initialized
INFO - 2016-02-19 13:19:19 --> Model Class Initialized
INFO - 2016-02-19 13:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:19:19 --> Pagination Class Initialized
INFO - 2016-02-19 13:19:19 --> Helper loaded: text_helper
INFO - 2016-02-19 13:19:19 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:19:19 --> Final output sent to browser
DEBUG - 2016-02-19 16:19:19 --> Total execution time: 1.1617
INFO - 2016-02-19 13:19:29 --> Config Class Initialized
INFO - 2016-02-19 13:19:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:19:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:19:29 --> Utf8 Class Initialized
INFO - 2016-02-19 13:19:29 --> URI Class Initialized
INFO - 2016-02-19 13:19:29 --> Router Class Initialized
INFO - 2016-02-19 13:19:29 --> Output Class Initialized
INFO - 2016-02-19 13:19:29 --> Security Class Initialized
DEBUG - 2016-02-19 13:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:19:29 --> Input Class Initialized
INFO - 2016-02-19 13:19:29 --> Language Class Initialized
INFO - 2016-02-19 13:19:29 --> Loader Class Initialized
INFO - 2016-02-19 13:19:29 --> Helper loaded: url_helper
INFO - 2016-02-19 13:19:29 --> Helper loaded: file_helper
INFO - 2016-02-19 13:19:29 --> Helper loaded: date_helper
INFO - 2016-02-19 13:19:29 --> Helper loaded: form_helper
INFO - 2016-02-19 13:19:29 --> Database Driver Class Initialized
INFO - 2016-02-19 13:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:19:30 --> Controller Class Initialized
INFO - 2016-02-19 13:19:30 --> Model Class Initialized
INFO - 2016-02-19 13:19:30 --> Model Class Initialized
INFO - 2016-02-19 13:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:19:30 --> Pagination Class Initialized
INFO - 2016-02-19 13:19:30 --> Helper loaded: text_helper
INFO - 2016-02-19 13:19:30 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:19:30 --> Final output sent to browser
DEBUG - 2016-02-19 16:19:30 --> Total execution time: 1.1661
INFO - 2016-02-19 13:23:14 --> Config Class Initialized
INFO - 2016-02-19 13:23:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:23:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:23:14 --> Utf8 Class Initialized
INFO - 2016-02-19 13:23:14 --> URI Class Initialized
DEBUG - 2016-02-19 13:23:14 --> No URI present. Default controller set.
INFO - 2016-02-19 13:23:14 --> Router Class Initialized
INFO - 2016-02-19 13:23:14 --> Output Class Initialized
INFO - 2016-02-19 13:23:14 --> Security Class Initialized
DEBUG - 2016-02-19 13:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:23:14 --> Input Class Initialized
INFO - 2016-02-19 13:23:14 --> Language Class Initialized
INFO - 2016-02-19 13:23:14 --> Loader Class Initialized
INFO - 2016-02-19 13:23:14 --> Helper loaded: url_helper
INFO - 2016-02-19 13:23:14 --> Helper loaded: file_helper
INFO - 2016-02-19 13:23:14 --> Helper loaded: date_helper
INFO - 2016-02-19 13:23:14 --> Helper loaded: form_helper
INFO - 2016-02-19 13:23:14 --> Database Driver Class Initialized
INFO - 2016-02-19 13:23:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:23:15 --> Controller Class Initialized
INFO - 2016-02-19 13:23:15 --> Model Class Initialized
INFO - 2016-02-19 13:23:15 --> Model Class Initialized
INFO - 2016-02-19 13:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:23:15 --> Pagination Class Initialized
INFO - 2016-02-19 13:23:15 --> Helper loaded: text_helper
INFO - 2016-02-19 13:23:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:23:15 --> Final output sent to browser
DEBUG - 2016-02-19 16:23:15 --> Total execution time: 1.1584
INFO - 2016-02-19 13:23:55 --> Config Class Initialized
INFO - 2016-02-19 13:23:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:23:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:23:55 --> Utf8 Class Initialized
INFO - 2016-02-19 13:23:55 --> URI Class Initialized
DEBUG - 2016-02-19 13:23:55 --> No URI present. Default controller set.
INFO - 2016-02-19 13:23:55 --> Router Class Initialized
INFO - 2016-02-19 13:23:55 --> Output Class Initialized
INFO - 2016-02-19 13:23:55 --> Security Class Initialized
DEBUG - 2016-02-19 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:23:55 --> Input Class Initialized
INFO - 2016-02-19 13:23:55 --> Language Class Initialized
INFO - 2016-02-19 13:23:55 --> Loader Class Initialized
INFO - 2016-02-19 13:23:55 --> Helper loaded: url_helper
INFO - 2016-02-19 13:23:55 --> Helper loaded: file_helper
INFO - 2016-02-19 13:23:55 --> Helper loaded: date_helper
INFO - 2016-02-19 13:23:55 --> Helper loaded: form_helper
INFO - 2016-02-19 13:23:55 --> Database Driver Class Initialized
INFO - 2016-02-19 13:23:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:23:56 --> Controller Class Initialized
INFO - 2016-02-19 13:23:56 --> Model Class Initialized
INFO - 2016-02-19 13:23:56 --> Model Class Initialized
INFO - 2016-02-19 13:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:23:56 --> Pagination Class Initialized
INFO - 2016-02-19 13:23:56 --> Helper loaded: text_helper
INFO - 2016-02-19 13:23:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:23:56 --> Final output sent to browser
DEBUG - 2016-02-19 16:23:56 --> Total execution time: 1.1617
INFO - 2016-02-19 13:23:57 --> Config Class Initialized
INFO - 2016-02-19 13:23:57 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:23:57 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:23:57 --> Utf8 Class Initialized
INFO - 2016-02-19 13:23:57 --> URI Class Initialized
DEBUG - 2016-02-19 13:23:57 --> No URI present. Default controller set.
INFO - 2016-02-19 13:23:57 --> Router Class Initialized
INFO - 2016-02-19 13:23:57 --> Output Class Initialized
INFO - 2016-02-19 13:23:57 --> Security Class Initialized
DEBUG - 2016-02-19 13:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:23:57 --> Input Class Initialized
INFO - 2016-02-19 13:23:57 --> Language Class Initialized
INFO - 2016-02-19 13:23:57 --> Loader Class Initialized
INFO - 2016-02-19 13:23:57 --> Helper loaded: url_helper
INFO - 2016-02-19 13:23:57 --> Helper loaded: file_helper
INFO - 2016-02-19 13:23:57 --> Helper loaded: date_helper
INFO - 2016-02-19 13:23:57 --> Helper loaded: form_helper
INFO - 2016-02-19 13:23:57 --> Database Driver Class Initialized
INFO - 2016-02-19 13:23:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:23:58 --> Controller Class Initialized
INFO - 2016-02-19 13:23:58 --> Model Class Initialized
INFO - 2016-02-19 13:23:58 --> Model Class Initialized
INFO - 2016-02-19 13:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:23:58 --> Pagination Class Initialized
INFO - 2016-02-19 13:23:58 --> Helper loaded: text_helper
INFO - 2016-02-19 13:23:58 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:23:58 --> Final output sent to browser
DEBUG - 2016-02-19 16:23:58 --> Total execution time: 1.1189
INFO - 2016-02-19 13:23:59 --> Config Class Initialized
INFO - 2016-02-19 13:23:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:23:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:23:59 --> Utf8 Class Initialized
INFO - 2016-02-19 13:23:59 --> URI Class Initialized
INFO - 2016-02-19 13:23:59 --> Router Class Initialized
INFO - 2016-02-19 13:23:59 --> Output Class Initialized
INFO - 2016-02-19 13:23:59 --> Security Class Initialized
DEBUG - 2016-02-19 13:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:23:59 --> Input Class Initialized
INFO - 2016-02-19 13:23:59 --> Language Class Initialized
INFO - 2016-02-19 13:23:59 --> Loader Class Initialized
INFO - 2016-02-19 13:23:59 --> Helper loaded: url_helper
INFO - 2016-02-19 13:23:59 --> Helper loaded: file_helper
INFO - 2016-02-19 13:23:59 --> Helper loaded: date_helper
INFO - 2016-02-19 13:23:59 --> Helper loaded: form_helper
INFO - 2016-02-19 13:23:59 --> Database Driver Class Initialized
INFO - 2016-02-19 13:24:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:24:00 --> Controller Class Initialized
INFO - 2016-02-19 13:24:00 --> Model Class Initialized
INFO - 2016-02-19 13:24:00 --> Model Class Initialized
INFO - 2016-02-19 13:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:24:00 --> Pagination Class Initialized
INFO - 2016-02-19 13:24:00 --> Helper loaded: text_helper
INFO - 2016-02-19 13:24:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:24:00 --> Final output sent to browser
DEBUG - 2016-02-19 16:24:00 --> Total execution time: 1.2408
INFO - 2016-02-19 13:24:01 --> Config Class Initialized
INFO - 2016-02-19 13:24:01 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:24:01 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:24:01 --> Utf8 Class Initialized
INFO - 2016-02-19 13:24:01 --> URI Class Initialized
DEBUG - 2016-02-19 13:24:01 --> No URI present. Default controller set.
INFO - 2016-02-19 13:24:01 --> Router Class Initialized
INFO - 2016-02-19 13:24:01 --> Output Class Initialized
INFO - 2016-02-19 13:24:01 --> Security Class Initialized
DEBUG - 2016-02-19 13:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:24:01 --> Input Class Initialized
INFO - 2016-02-19 13:24:01 --> Language Class Initialized
INFO - 2016-02-19 13:24:01 --> Loader Class Initialized
INFO - 2016-02-19 13:24:01 --> Helper loaded: url_helper
INFO - 2016-02-19 13:24:01 --> Helper loaded: file_helper
INFO - 2016-02-19 13:24:01 --> Helper loaded: date_helper
INFO - 2016-02-19 13:24:01 --> Helper loaded: form_helper
INFO - 2016-02-19 13:24:01 --> Database Driver Class Initialized
INFO - 2016-02-19 13:24:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:24:02 --> Controller Class Initialized
INFO - 2016-02-19 13:24:02 --> Model Class Initialized
INFO - 2016-02-19 13:24:02 --> Model Class Initialized
INFO - 2016-02-19 13:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:24:02 --> Pagination Class Initialized
INFO - 2016-02-19 13:24:02 --> Helper loaded: text_helper
INFO - 2016-02-19 13:24:02 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:24:02 --> Final output sent to browser
DEBUG - 2016-02-19 16:24:02 --> Total execution time: 1.1308
INFO - 2016-02-19 13:24:41 --> Config Class Initialized
INFO - 2016-02-19 13:24:41 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:24:41 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:24:41 --> Utf8 Class Initialized
INFO - 2016-02-19 13:24:41 --> URI Class Initialized
INFO - 2016-02-19 13:24:41 --> Router Class Initialized
INFO - 2016-02-19 13:24:41 --> Output Class Initialized
INFO - 2016-02-19 13:24:41 --> Security Class Initialized
DEBUG - 2016-02-19 13:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:24:41 --> Input Class Initialized
INFO - 2016-02-19 13:24:41 --> Language Class Initialized
INFO - 2016-02-19 13:24:41 --> Loader Class Initialized
INFO - 2016-02-19 13:24:41 --> Helper loaded: url_helper
INFO - 2016-02-19 13:24:41 --> Helper loaded: file_helper
INFO - 2016-02-19 13:24:41 --> Helper loaded: date_helper
INFO - 2016-02-19 13:24:41 --> Helper loaded: form_helper
INFO - 2016-02-19 13:24:41 --> Database Driver Class Initialized
INFO - 2016-02-19 13:24:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:24:42 --> Controller Class Initialized
INFO - 2016-02-19 13:24:42 --> Model Class Initialized
INFO - 2016-02-19 13:24:42 --> Model Class Initialized
INFO - 2016-02-19 13:24:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:24:42 --> Pagination Class Initialized
INFO - 2016-02-19 13:24:42 --> Helper loaded: text_helper
INFO - 2016-02-19 13:24:42 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:24:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:24:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:24:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:24:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:24:42 --> Final output sent to browser
DEBUG - 2016-02-19 16:24:42 --> Total execution time: 1.1425
INFO - 2016-02-19 13:25:09 --> Config Class Initialized
INFO - 2016-02-19 13:25:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:25:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:25:09 --> Utf8 Class Initialized
INFO - 2016-02-19 13:25:09 --> URI Class Initialized
INFO - 2016-02-19 13:25:09 --> Router Class Initialized
INFO - 2016-02-19 13:25:09 --> Output Class Initialized
INFO - 2016-02-19 13:25:09 --> Security Class Initialized
DEBUG - 2016-02-19 13:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:25:09 --> Input Class Initialized
INFO - 2016-02-19 13:25:09 --> Language Class Initialized
INFO - 2016-02-19 13:25:09 --> Loader Class Initialized
INFO - 2016-02-19 13:25:09 --> Helper loaded: url_helper
INFO - 2016-02-19 13:25:09 --> Helper loaded: file_helper
INFO - 2016-02-19 13:25:09 --> Helper loaded: date_helper
INFO - 2016-02-19 13:25:09 --> Helper loaded: form_helper
INFO - 2016-02-19 13:25:09 --> Database Driver Class Initialized
INFO - 2016-02-19 13:25:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:25:10 --> Controller Class Initialized
INFO - 2016-02-19 13:25:10 --> Model Class Initialized
INFO - 2016-02-19 13:25:10 --> Model Class Initialized
INFO - 2016-02-19 13:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:25:10 --> Pagination Class Initialized
INFO - 2016-02-19 13:25:10 --> Helper loaded: text_helper
INFO - 2016-02-19 13:25:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:25:10 --> Final output sent to browser
DEBUG - 2016-02-19 16:25:10 --> Total execution time: 1.1538
INFO - 2016-02-19 13:25:15 --> Config Class Initialized
INFO - 2016-02-19 13:25:15 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:25:15 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:25:15 --> Utf8 Class Initialized
INFO - 2016-02-19 13:25:15 --> URI Class Initialized
INFO - 2016-02-19 13:25:15 --> Router Class Initialized
INFO - 2016-02-19 13:25:15 --> Output Class Initialized
INFO - 2016-02-19 13:25:15 --> Security Class Initialized
DEBUG - 2016-02-19 13:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:25:15 --> Input Class Initialized
INFO - 2016-02-19 13:25:15 --> Language Class Initialized
INFO - 2016-02-19 13:25:15 --> Loader Class Initialized
INFO - 2016-02-19 13:25:15 --> Helper loaded: url_helper
INFO - 2016-02-19 13:25:15 --> Helper loaded: file_helper
INFO - 2016-02-19 13:25:15 --> Helper loaded: date_helper
INFO - 2016-02-19 13:25:15 --> Helper loaded: form_helper
INFO - 2016-02-19 13:25:15 --> Database Driver Class Initialized
INFO - 2016-02-19 13:25:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:25:16 --> Controller Class Initialized
INFO - 2016-02-19 13:25:16 --> Model Class Initialized
INFO - 2016-02-19 13:25:16 --> Model Class Initialized
INFO - 2016-02-19 13:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:25:16 --> Pagination Class Initialized
INFO - 2016-02-19 13:25:16 --> Helper loaded: text_helper
INFO - 2016-02-19 13:25:16 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:25:16 --> Final output sent to browser
DEBUG - 2016-02-19 16:25:16 --> Total execution time: 1.2098
INFO - 2016-02-19 13:26:42 --> Config Class Initialized
INFO - 2016-02-19 13:26:42 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:26:42 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:26:42 --> Utf8 Class Initialized
INFO - 2016-02-19 13:26:42 --> URI Class Initialized
INFO - 2016-02-19 13:26:42 --> Router Class Initialized
INFO - 2016-02-19 13:26:42 --> Output Class Initialized
INFO - 2016-02-19 13:26:42 --> Security Class Initialized
DEBUG - 2016-02-19 13:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:26:42 --> Input Class Initialized
INFO - 2016-02-19 13:26:42 --> Language Class Initialized
INFO - 2016-02-19 13:26:42 --> Loader Class Initialized
INFO - 2016-02-19 13:26:42 --> Helper loaded: url_helper
INFO - 2016-02-19 13:26:42 --> Helper loaded: file_helper
INFO - 2016-02-19 13:26:42 --> Helper loaded: date_helper
INFO - 2016-02-19 13:26:42 --> Helper loaded: form_helper
INFO - 2016-02-19 13:26:42 --> Database Driver Class Initialized
INFO - 2016-02-19 13:26:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:26:43 --> Controller Class Initialized
INFO - 2016-02-19 13:26:43 --> Model Class Initialized
INFO - 2016-02-19 13:26:43 --> Model Class Initialized
INFO - 2016-02-19 13:26:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:26:43 --> Pagination Class Initialized
INFO - 2016-02-19 13:26:43 --> Helper loaded: text_helper
INFO - 2016-02-19 13:26:43 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:26:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:26:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-19 16:26:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:26:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:26:43 --> Final output sent to browser
DEBUG - 2016-02-19 16:26:43 --> Total execution time: 1.1659
INFO - 2016-02-19 13:27:09 --> Config Class Initialized
INFO - 2016-02-19 13:27:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:27:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:27:09 --> Utf8 Class Initialized
INFO - 2016-02-19 13:27:09 --> URI Class Initialized
DEBUG - 2016-02-19 13:27:09 --> No URI present. Default controller set.
INFO - 2016-02-19 13:27:09 --> Router Class Initialized
INFO - 2016-02-19 13:27:09 --> Output Class Initialized
INFO - 2016-02-19 13:27:09 --> Security Class Initialized
DEBUG - 2016-02-19 13:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:27:09 --> Input Class Initialized
INFO - 2016-02-19 13:27:09 --> Language Class Initialized
INFO - 2016-02-19 13:27:09 --> Loader Class Initialized
INFO - 2016-02-19 13:27:09 --> Helper loaded: url_helper
INFO - 2016-02-19 13:27:09 --> Helper loaded: file_helper
INFO - 2016-02-19 13:27:09 --> Helper loaded: date_helper
INFO - 2016-02-19 13:27:09 --> Helper loaded: form_helper
INFO - 2016-02-19 13:27:09 --> Database Driver Class Initialized
INFO - 2016-02-19 13:27:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:27:10 --> Controller Class Initialized
INFO - 2016-02-19 13:27:10 --> Model Class Initialized
INFO - 2016-02-19 13:27:10 --> Model Class Initialized
INFO - 2016-02-19 13:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:27:10 --> Pagination Class Initialized
INFO - 2016-02-19 13:27:10 --> Helper loaded: text_helper
INFO - 2016-02-19 13:27:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:27:10 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-19 16:27:10 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-19 16:27:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-19 16:27:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 13:28:58 --> Config Class Initialized
INFO - 2016-02-19 13:28:58 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:28:58 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:28:58 --> Utf8 Class Initialized
INFO - 2016-02-19 13:28:58 --> URI Class Initialized
INFO - 2016-02-19 13:28:58 --> Router Class Initialized
INFO - 2016-02-19 13:28:58 --> Output Class Initialized
INFO - 2016-02-19 13:28:58 --> Security Class Initialized
DEBUG - 2016-02-19 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:28:58 --> Input Class Initialized
INFO - 2016-02-19 13:28:58 --> Language Class Initialized
INFO - 2016-02-19 13:28:58 --> Loader Class Initialized
INFO - 2016-02-19 13:28:58 --> Helper loaded: url_helper
INFO - 2016-02-19 13:28:58 --> Helper loaded: file_helper
INFO - 2016-02-19 13:28:58 --> Helper loaded: date_helper
INFO - 2016-02-19 13:28:58 --> Helper loaded: form_helper
INFO - 2016-02-19 13:28:58 --> Database Driver Class Initialized
INFO - 2016-02-19 13:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:28:59 --> Controller Class Initialized
INFO - 2016-02-19 13:28:59 --> Model Class Initialized
INFO - 2016-02-19 13:28:59 --> Model Class Initialized
INFO - 2016-02-19 13:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:28:59 --> Pagination Class Initialized
INFO - 2016-02-19 13:28:59 --> Helper loaded: text_helper
INFO - 2016-02-19 13:28:59 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:28:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-19 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:28:59 --> Final output sent to browser
DEBUG - 2016-02-19 16:28:59 --> Total execution time: 1.1876
INFO - 2016-02-19 13:33:18 --> Config Class Initialized
INFO - 2016-02-19 13:33:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:33:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:33:18 --> Utf8 Class Initialized
INFO - 2016-02-19 13:33:18 --> URI Class Initialized
INFO - 2016-02-19 13:33:18 --> Router Class Initialized
INFO - 2016-02-19 13:33:19 --> Output Class Initialized
INFO - 2016-02-19 13:33:19 --> Security Class Initialized
DEBUG - 2016-02-19 13:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:33:19 --> Input Class Initialized
INFO - 2016-02-19 13:33:19 --> Language Class Initialized
INFO - 2016-02-19 13:33:19 --> Loader Class Initialized
INFO - 2016-02-19 13:33:19 --> Helper loaded: url_helper
INFO - 2016-02-19 13:33:19 --> Helper loaded: file_helper
INFO - 2016-02-19 13:33:19 --> Helper loaded: date_helper
INFO - 2016-02-19 13:33:19 --> Helper loaded: form_helper
INFO - 2016-02-19 13:33:19 --> Database Driver Class Initialized
INFO - 2016-02-19 13:33:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:33:20 --> Controller Class Initialized
INFO - 2016-02-19 13:33:20 --> Model Class Initialized
INFO - 2016-02-19 13:33:20 --> Model Class Initialized
INFO - 2016-02-19 13:33:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:33:20 --> Pagination Class Initialized
INFO - 2016-02-19 13:33:20 --> Helper loaded: text_helper
INFO - 2016-02-19 13:33:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-19 16:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:33:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:33:20 --> Final output sent to browser
DEBUG - 2016-02-19 16:33:20 --> Total execution time: 1.1414
INFO - 2016-02-19 13:33:24 --> Config Class Initialized
INFO - 2016-02-19 13:33:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:33:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:33:24 --> Utf8 Class Initialized
INFO - 2016-02-19 13:33:24 --> URI Class Initialized
INFO - 2016-02-19 13:33:24 --> Router Class Initialized
INFO - 2016-02-19 13:33:24 --> Output Class Initialized
INFO - 2016-02-19 13:33:24 --> Security Class Initialized
DEBUG - 2016-02-19 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:33:24 --> Input Class Initialized
INFO - 2016-02-19 13:33:24 --> Language Class Initialized
INFO - 2016-02-19 13:33:24 --> Loader Class Initialized
INFO - 2016-02-19 13:33:24 --> Helper loaded: url_helper
INFO - 2016-02-19 13:33:24 --> Helper loaded: file_helper
INFO - 2016-02-19 13:33:24 --> Helper loaded: date_helper
INFO - 2016-02-19 13:33:24 --> Helper loaded: form_helper
INFO - 2016-02-19 13:33:24 --> Database Driver Class Initialized
INFO - 2016-02-19 13:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:33:25 --> Controller Class Initialized
INFO - 2016-02-19 13:33:25 --> Model Class Initialized
INFO - 2016-02-19 13:33:25 --> Model Class Initialized
INFO - 2016-02-19 13:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:33:25 --> Pagination Class Initialized
INFO - 2016-02-19 13:33:25 --> Helper loaded: text_helper
INFO - 2016-02-19 13:33:25 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:33:25 --> Final output sent to browser
DEBUG - 2016-02-19 16:33:25 --> Total execution time: 1.1368
INFO - 2016-02-19 13:33:45 --> Config Class Initialized
INFO - 2016-02-19 13:33:45 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:33:45 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:33:45 --> Utf8 Class Initialized
INFO - 2016-02-19 13:33:45 --> URI Class Initialized
INFO - 2016-02-19 13:33:45 --> Router Class Initialized
INFO - 2016-02-19 13:33:45 --> Output Class Initialized
INFO - 2016-02-19 13:33:45 --> Security Class Initialized
DEBUG - 2016-02-19 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:33:45 --> Input Class Initialized
INFO - 2016-02-19 13:33:45 --> Language Class Initialized
INFO - 2016-02-19 13:33:45 --> Loader Class Initialized
INFO - 2016-02-19 13:33:45 --> Helper loaded: url_helper
INFO - 2016-02-19 13:33:45 --> Helper loaded: file_helper
INFO - 2016-02-19 13:33:45 --> Helper loaded: date_helper
INFO - 2016-02-19 13:33:45 --> Helper loaded: form_helper
INFO - 2016-02-19 13:33:45 --> Database Driver Class Initialized
INFO - 2016-02-19 13:33:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:33:46 --> Controller Class Initialized
INFO - 2016-02-19 13:33:46 --> Model Class Initialized
INFO - 2016-02-19 13:33:46 --> Model Class Initialized
INFO - 2016-02-19 13:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:33:46 --> Pagination Class Initialized
INFO - 2016-02-19 13:33:46 --> Helper loaded: text_helper
INFO - 2016-02-19 13:33:46 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-19 16:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:33:46 --> Final output sent to browser
DEBUG - 2016-02-19 16:33:46 --> Total execution time: 1.2034
INFO - 2016-02-19 13:38:32 --> Config Class Initialized
INFO - 2016-02-19 13:38:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:38:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:38:32 --> Utf8 Class Initialized
INFO - 2016-02-19 13:38:32 --> URI Class Initialized
INFO - 2016-02-19 13:38:32 --> Router Class Initialized
INFO - 2016-02-19 13:38:32 --> Output Class Initialized
INFO - 2016-02-19 13:38:32 --> Security Class Initialized
DEBUG - 2016-02-19 13:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:38:32 --> Input Class Initialized
INFO - 2016-02-19 13:38:32 --> Language Class Initialized
INFO - 2016-02-19 13:38:32 --> Loader Class Initialized
INFO - 2016-02-19 13:38:32 --> Helper loaded: url_helper
INFO - 2016-02-19 13:38:32 --> Helper loaded: file_helper
INFO - 2016-02-19 13:38:32 --> Helper loaded: date_helper
INFO - 2016-02-19 13:38:32 --> Helper loaded: form_helper
INFO - 2016-02-19 13:38:32 --> Database Driver Class Initialized
INFO - 2016-02-19 13:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:38:33 --> Controller Class Initialized
INFO - 2016-02-19 13:38:33 --> Model Class Initialized
INFO - 2016-02-19 13:38:33 --> Model Class Initialized
INFO - 2016-02-19 13:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:38:33 --> Pagination Class Initialized
INFO - 2016-02-19 13:38:33 --> Helper loaded: text_helper
INFO - 2016-02-19 13:38:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:38:33 --> Final output sent to browser
DEBUG - 2016-02-19 16:38:33 --> Total execution time: 1.1722
INFO - 2016-02-19 13:44:19 --> Config Class Initialized
INFO - 2016-02-19 13:44:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:44:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:44:19 --> Utf8 Class Initialized
INFO - 2016-02-19 13:44:19 --> URI Class Initialized
DEBUG - 2016-02-19 13:44:19 --> No URI present. Default controller set.
INFO - 2016-02-19 13:44:19 --> Router Class Initialized
INFO - 2016-02-19 13:44:19 --> Output Class Initialized
INFO - 2016-02-19 13:44:19 --> Security Class Initialized
DEBUG - 2016-02-19 13:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:44:19 --> Input Class Initialized
INFO - 2016-02-19 13:44:19 --> Language Class Initialized
INFO - 2016-02-19 13:44:19 --> Loader Class Initialized
INFO - 2016-02-19 13:44:19 --> Helper loaded: url_helper
INFO - 2016-02-19 13:44:19 --> Helper loaded: file_helper
INFO - 2016-02-19 13:44:19 --> Helper loaded: date_helper
INFO - 2016-02-19 13:44:19 --> Helper loaded: form_helper
INFO - 2016-02-19 13:44:19 --> Database Driver Class Initialized
INFO - 2016-02-19 13:44:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:44:20 --> Controller Class Initialized
INFO - 2016-02-19 13:44:20 --> Model Class Initialized
INFO - 2016-02-19 13:44:20 --> Model Class Initialized
INFO - 2016-02-19 13:44:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:44:20 --> Pagination Class Initialized
INFO - 2016-02-19 13:44:20 --> Helper loaded: text_helper
INFO - 2016-02-19 13:44:20 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:44:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:44:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:44:20 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-19 16:44:20 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-19 16:44:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-19 16:44:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 13:44:24 --> Config Class Initialized
INFO - 2016-02-19 13:44:24 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:44:24 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:44:24 --> Utf8 Class Initialized
INFO - 2016-02-19 13:44:24 --> URI Class Initialized
INFO - 2016-02-19 13:44:24 --> Router Class Initialized
INFO - 2016-02-19 13:44:24 --> Output Class Initialized
INFO - 2016-02-19 13:44:24 --> Security Class Initialized
DEBUG - 2016-02-19 13:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:44:24 --> Input Class Initialized
INFO - 2016-02-19 13:44:24 --> Language Class Initialized
INFO - 2016-02-19 13:44:24 --> Loader Class Initialized
INFO - 2016-02-19 13:44:24 --> Helper loaded: url_helper
INFO - 2016-02-19 13:44:24 --> Helper loaded: file_helper
INFO - 2016-02-19 13:44:24 --> Helper loaded: date_helper
INFO - 2016-02-19 13:44:24 --> Helper loaded: form_helper
INFO - 2016-02-19 13:44:24 --> Database Driver Class Initialized
INFO - 2016-02-19 13:44:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:44:25 --> Controller Class Initialized
INFO - 2016-02-19 13:44:25 --> Model Class Initialized
INFO - 2016-02-19 13:44:25 --> Model Class Initialized
INFO - 2016-02-19 13:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:44:25 --> Pagination Class Initialized
INFO - 2016-02-19 13:44:25 --> Helper loaded: text_helper
INFO - 2016-02-19 13:44:25 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:44:25 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\talk.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-19 16:44:25 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-19 16:44:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-19 16:44:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 13:46:04 --> Config Class Initialized
INFO - 2016-02-19 13:46:04 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:46:04 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:46:04 --> Utf8 Class Initialized
INFO - 2016-02-19 13:46:04 --> URI Class Initialized
INFO - 2016-02-19 13:46:04 --> Router Class Initialized
INFO - 2016-02-19 13:46:04 --> Output Class Initialized
INFO - 2016-02-19 13:46:04 --> Security Class Initialized
DEBUG - 2016-02-19 13:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:46:04 --> Input Class Initialized
INFO - 2016-02-19 13:46:04 --> Language Class Initialized
INFO - 2016-02-19 13:46:04 --> Loader Class Initialized
INFO - 2016-02-19 13:46:04 --> Helper loaded: url_helper
INFO - 2016-02-19 13:46:04 --> Helper loaded: file_helper
INFO - 2016-02-19 13:46:04 --> Helper loaded: date_helper
INFO - 2016-02-19 13:46:04 --> Helper loaded: form_helper
INFO - 2016-02-19 13:46:04 --> Database Driver Class Initialized
INFO - 2016-02-19 13:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:46:05 --> Controller Class Initialized
INFO - 2016-02-19 13:46:05 --> Model Class Initialized
INFO - 2016-02-19 13:46:05 --> Model Class Initialized
INFO - 2016-02-19 13:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:46:05 --> Pagination Class Initialized
INFO - 2016-02-19 13:46:05 --> Helper loaded: text_helper
INFO - 2016-02-19 13:46:05 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:46:05 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\talk.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-19 16:46:05 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-19 16:46:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19' at line 2 - Invalid query: SELECT *
FROM 19
INFO - 2016-02-19 16:46:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 13:46:46 --> Config Class Initialized
INFO - 2016-02-19 13:46:46 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:46:46 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:46:46 --> Utf8 Class Initialized
INFO - 2016-02-19 13:46:46 --> URI Class Initialized
INFO - 2016-02-19 13:46:46 --> Router Class Initialized
INFO - 2016-02-19 13:46:46 --> Output Class Initialized
INFO - 2016-02-19 13:46:46 --> Security Class Initialized
DEBUG - 2016-02-19 13:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:46:46 --> Input Class Initialized
INFO - 2016-02-19 13:46:46 --> Language Class Initialized
INFO - 2016-02-19 13:46:46 --> Loader Class Initialized
INFO - 2016-02-19 13:46:46 --> Helper loaded: url_helper
INFO - 2016-02-19 13:46:46 --> Helper loaded: file_helper
INFO - 2016-02-19 13:46:46 --> Helper loaded: date_helper
INFO - 2016-02-19 13:46:46 --> Helper loaded: form_helper
INFO - 2016-02-19 13:46:46 --> Database Driver Class Initialized
INFO - 2016-02-19 13:46:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:46:47 --> Controller Class Initialized
INFO - 2016-02-19 13:46:47 --> Model Class Initialized
INFO - 2016-02-19 13:46:47 --> Model Class Initialized
INFO - 2016-02-19 13:46:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:46:47 --> Pagination Class Initialized
INFO - 2016-02-19 13:46:47 --> Helper loaded: text_helper
INFO - 2016-02-19 13:46:47 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:46:47 --> Query error: Table 'jdboard.talk' doesn't exist - Invalid query: SELECT *
FROM `talk`
 LIMIT 19
INFO - 2016-02-19 16:46:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 13:47:32 --> Config Class Initialized
INFO - 2016-02-19 13:47:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:47:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:47:32 --> Utf8 Class Initialized
INFO - 2016-02-19 13:47:32 --> URI Class Initialized
INFO - 2016-02-19 13:47:32 --> Router Class Initialized
INFO - 2016-02-19 13:47:32 --> Output Class Initialized
INFO - 2016-02-19 13:47:32 --> Security Class Initialized
DEBUG - 2016-02-19 13:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:47:32 --> Input Class Initialized
INFO - 2016-02-19 13:47:32 --> Language Class Initialized
INFO - 2016-02-19 13:47:32 --> Loader Class Initialized
INFO - 2016-02-19 13:47:32 --> Helper loaded: url_helper
INFO - 2016-02-19 13:47:32 --> Helper loaded: file_helper
INFO - 2016-02-19 13:47:32 --> Helper loaded: date_helper
INFO - 2016-02-19 13:47:32 --> Helper loaded: form_helper
INFO - 2016-02-19 13:47:32 --> Database Driver Class Initialized
INFO - 2016-02-19 13:47:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:47:33 --> Controller Class Initialized
INFO - 2016-02-19 13:47:33 --> Model Class Initialized
INFO - 2016-02-19 13:47:33 --> Model Class Initialized
INFO - 2016-02-19 13:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:47:33 --> Pagination Class Initialized
INFO - 2016-02-19 13:47:33 --> Helper loaded: text_helper
INFO - 2016-02-19 13:47:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 16:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-19 16:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:47:33 --> Final output sent to browser
DEBUG - 2016-02-19 16:47:33 --> Total execution time: 1.1664
INFO - 2016-02-19 13:49:32 --> Config Class Initialized
INFO - 2016-02-19 13:49:32 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:49:32 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:49:32 --> Utf8 Class Initialized
INFO - 2016-02-19 13:49:32 --> URI Class Initialized
INFO - 2016-02-19 13:49:32 --> Router Class Initialized
INFO - 2016-02-19 13:49:32 --> Output Class Initialized
INFO - 2016-02-19 13:49:32 --> Security Class Initialized
DEBUG - 2016-02-19 13:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:49:32 --> Input Class Initialized
INFO - 2016-02-19 13:49:32 --> Language Class Initialized
INFO - 2016-02-19 13:49:32 --> Loader Class Initialized
INFO - 2016-02-19 13:49:32 --> Helper loaded: url_helper
INFO - 2016-02-19 13:49:32 --> Helper loaded: file_helper
INFO - 2016-02-19 13:49:32 --> Helper loaded: date_helper
INFO - 2016-02-19 13:49:32 --> Helper loaded: form_helper
INFO - 2016-02-19 13:49:32 --> Database Driver Class Initialized
INFO - 2016-02-19 13:49:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:49:33 --> Controller Class Initialized
INFO - 2016-02-19 13:49:33 --> Model Class Initialized
INFO - 2016-02-19 13:49:33 --> Model Class Initialized
INFO - 2016-02-19 13:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:49:33 --> Pagination Class Initialized
INFO - 2016-02-19 13:49:33 --> Helper loaded: text_helper
INFO - 2016-02-19 13:49:33 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:49:33 --> Final output sent to browser
DEBUG - 2016-02-19 16:49:33 --> Total execution time: 1.1509
INFO - 2016-02-19 13:49:38 --> Config Class Initialized
INFO - 2016-02-19 13:49:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:49:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:49:38 --> Utf8 Class Initialized
INFO - 2016-02-19 13:49:38 --> URI Class Initialized
INFO - 2016-02-19 13:49:38 --> Router Class Initialized
INFO - 2016-02-19 13:49:38 --> Output Class Initialized
INFO - 2016-02-19 13:49:38 --> Security Class Initialized
DEBUG - 2016-02-19 13:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:49:38 --> Input Class Initialized
INFO - 2016-02-19 13:49:38 --> Language Class Initialized
INFO - 2016-02-19 13:49:38 --> Loader Class Initialized
INFO - 2016-02-19 13:49:38 --> Helper loaded: url_helper
INFO - 2016-02-19 13:49:38 --> Helper loaded: file_helper
INFO - 2016-02-19 13:49:38 --> Helper loaded: date_helper
INFO - 2016-02-19 13:49:38 --> Helper loaded: form_helper
INFO - 2016-02-19 13:49:38 --> Database Driver Class Initialized
INFO - 2016-02-19 13:49:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:49:39 --> Controller Class Initialized
INFO - 2016-02-19 13:49:39 --> Model Class Initialized
INFO - 2016-02-19 13:49:39 --> Model Class Initialized
INFO - 2016-02-19 13:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:49:39 --> Pagination Class Initialized
INFO - 2016-02-19 13:49:39 --> Helper loaded: text_helper
INFO - 2016-02-19 13:49:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 16:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:49:39 --> Final output sent to browser
DEBUG - 2016-02-19 16:49:39 --> Total execution time: 1.2068
INFO - 2016-02-19 13:49:51 --> Config Class Initialized
INFO - 2016-02-19 13:49:51 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:49:51 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:49:51 --> Utf8 Class Initialized
INFO - 2016-02-19 13:49:51 --> URI Class Initialized
INFO - 2016-02-19 13:49:51 --> Router Class Initialized
INFO - 2016-02-19 13:49:51 --> Output Class Initialized
INFO - 2016-02-19 13:49:51 --> Security Class Initialized
DEBUG - 2016-02-19 13:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:49:51 --> Input Class Initialized
INFO - 2016-02-19 13:49:51 --> Language Class Initialized
INFO - 2016-02-19 13:49:51 --> Loader Class Initialized
INFO - 2016-02-19 13:49:51 --> Helper loaded: url_helper
INFO - 2016-02-19 13:49:51 --> Helper loaded: file_helper
INFO - 2016-02-19 13:49:51 --> Helper loaded: date_helper
INFO - 2016-02-19 13:49:51 --> Helper loaded: form_helper
INFO - 2016-02-19 13:49:51 --> Database Driver Class Initialized
INFO - 2016-02-19 13:49:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:49:52 --> Controller Class Initialized
INFO - 2016-02-19 13:49:52 --> Model Class Initialized
INFO - 2016-02-19 13:49:52 --> Model Class Initialized
INFO - 2016-02-19 13:49:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:49:52 --> Pagination Class Initialized
INFO - 2016-02-19 13:49:52 --> Helper loaded: text_helper
INFO - 2016-02-19 13:49:52 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:49:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:49:52 --> Final output sent to browser
DEBUG - 2016-02-19 16:49:52 --> Total execution time: 1.1622
INFO - 2016-02-19 13:50:55 --> Config Class Initialized
INFO - 2016-02-19 13:50:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:50:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:50:55 --> Utf8 Class Initialized
INFO - 2016-02-19 13:50:55 --> URI Class Initialized
INFO - 2016-02-19 13:50:55 --> Router Class Initialized
INFO - 2016-02-19 13:50:55 --> Output Class Initialized
INFO - 2016-02-19 13:50:55 --> Security Class Initialized
DEBUG - 2016-02-19 13:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:50:55 --> Input Class Initialized
INFO - 2016-02-19 13:50:55 --> Language Class Initialized
INFO - 2016-02-19 13:50:55 --> Loader Class Initialized
INFO - 2016-02-19 13:50:55 --> Helper loaded: url_helper
INFO - 2016-02-19 13:50:55 --> Helper loaded: file_helper
INFO - 2016-02-19 13:50:55 --> Helper loaded: date_helper
INFO - 2016-02-19 13:50:55 --> Helper loaded: form_helper
INFO - 2016-02-19 13:50:55 --> Database Driver Class Initialized
INFO - 2016-02-19 13:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:50:56 --> Controller Class Initialized
INFO - 2016-02-19 13:50:56 --> Model Class Initialized
INFO - 2016-02-19 13:50:56 --> Model Class Initialized
INFO - 2016-02-19 13:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:50:56 --> Pagination Class Initialized
INFO - 2016-02-19 13:50:56 --> Helper loaded: text_helper
INFO - 2016-02-19 13:50:56 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:50:56 --> Final output sent to browser
DEBUG - 2016-02-19 16:50:56 --> Total execution time: 1.1439
INFO - 2016-02-19 13:51:30 --> Config Class Initialized
INFO - 2016-02-19 13:51:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:51:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:51:30 --> Utf8 Class Initialized
INFO - 2016-02-19 13:51:30 --> URI Class Initialized
INFO - 2016-02-19 13:51:30 --> Router Class Initialized
INFO - 2016-02-19 13:51:30 --> Output Class Initialized
INFO - 2016-02-19 13:51:30 --> Security Class Initialized
DEBUG - 2016-02-19 13:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:51:30 --> Input Class Initialized
INFO - 2016-02-19 13:51:30 --> Language Class Initialized
INFO - 2016-02-19 13:51:30 --> Loader Class Initialized
INFO - 2016-02-19 13:51:30 --> Helper loaded: url_helper
INFO - 2016-02-19 13:51:30 --> Helper loaded: file_helper
INFO - 2016-02-19 13:51:30 --> Helper loaded: date_helper
INFO - 2016-02-19 13:51:30 --> Helper loaded: form_helper
INFO - 2016-02-19 13:51:30 --> Database Driver Class Initialized
INFO - 2016-02-19 13:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:51:31 --> Controller Class Initialized
INFO - 2016-02-19 13:51:31 --> Model Class Initialized
INFO - 2016-02-19 13:51:31 --> Model Class Initialized
INFO - 2016-02-19 13:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:51:31 --> Pagination Class Initialized
INFO - 2016-02-19 13:51:31 --> Helper loaded: text_helper
INFO - 2016-02-19 13:51:31 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:51:31 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 154
INFO - 2016-02-19 16:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:51:31 --> Form Validation Class Initialized
INFO - 2016-02-19 16:51:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:51:31 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:51:31 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:51:31 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:51:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:51:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 13:52:11 --> Config Class Initialized
INFO - 2016-02-19 13:52:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:52:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:52:11 --> Utf8 Class Initialized
INFO - 2016-02-19 13:52:11 --> URI Class Initialized
INFO - 2016-02-19 13:52:11 --> Router Class Initialized
INFO - 2016-02-19 13:52:11 --> Output Class Initialized
INFO - 2016-02-19 13:52:11 --> Security Class Initialized
DEBUG - 2016-02-19 13:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:52:11 --> Input Class Initialized
INFO - 2016-02-19 13:52:11 --> Language Class Initialized
INFO - 2016-02-19 13:52:11 --> Loader Class Initialized
INFO - 2016-02-19 13:52:11 --> Helper loaded: url_helper
INFO - 2016-02-19 13:52:11 --> Helper loaded: file_helper
INFO - 2016-02-19 13:52:11 --> Helper loaded: date_helper
INFO - 2016-02-19 13:52:11 --> Helper loaded: form_helper
INFO - 2016-02-19 13:52:11 --> Database Driver Class Initialized
INFO - 2016-02-19 13:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:52:12 --> Controller Class Initialized
INFO - 2016-02-19 13:52:12 --> Model Class Initialized
INFO - 2016-02-19 13:52:12 --> Model Class Initialized
INFO - 2016-02-19 13:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:52:12 --> Pagination Class Initialized
INFO - 2016-02-19 13:52:12 --> Helper loaded: text_helper
INFO - 2016-02-19 13:52:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:52:12 --> Final output sent to browser
DEBUG - 2016-02-19 16:52:13 --> Total execution time: 1.1343
INFO - 2016-02-19 13:52:21 --> Config Class Initialized
INFO - 2016-02-19 13:52:21 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:52:21 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:52:21 --> Utf8 Class Initialized
INFO - 2016-02-19 13:52:21 --> URI Class Initialized
INFO - 2016-02-19 13:52:21 --> Router Class Initialized
INFO - 2016-02-19 13:52:21 --> Output Class Initialized
INFO - 2016-02-19 13:52:21 --> Security Class Initialized
DEBUG - 2016-02-19 13:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:52:21 --> Input Class Initialized
INFO - 2016-02-19 13:52:21 --> Language Class Initialized
INFO - 2016-02-19 13:52:21 --> Loader Class Initialized
INFO - 2016-02-19 13:52:21 --> Helper loaded: url_helper
INFO - 2016-02-19 13:52:21 --> Helper loaded: file_helper
INFO - 2016-02-19 13:52:21 --> Helper loaded: date_helper
INFO - 2016-02-19 13:52:21 --> Helper loaded: form_helper
INFO - 2016-02-19 13:52:21 --> Database Driver Class Initialized
INFO - 2016-02-19 13:52:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:52:22 --> Controller Class Initialized
INFO - 2016-02-19 13:52:22 --> Model Class Initialized
INFO - 2016-02-19 13:52:22 --> Model Class Initialized
INFO - 2016-02-19 13:52:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:52:22 --> Pagination Class Initialized
INFO - 2016-02-19 13:52:22 --> Helper loaded: text_helper
INFO - 2016-02-19 13:52:22 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:52:22 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 154
INFO - 2016-02-19 16:52:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:52:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:52:22 --> Form Validation Class Initialized
INFO - 2016-02-19 16:52:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:52:22 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:52:22 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:52:22 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:52:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:52:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 13:54:29 --> Config Class Initialized
INFO - 2016-02-19 13:54:29 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:54:29 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:54:29 --> Utf8 Class Initialized
INFO - 2016-02-19 13:54:29 --> URI Class Initialized
INFO - 2016-02-19 13:54:29 --> Router Class Initialized
INFO - 2016-02-19 13:54:29 --> Output Class Initialized
INFO - 2016-02-19 13:54:29 --> Security Class Initialized
DEBUG - 2016-02-19 13:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:54:29 --> Input Class Initialized
INFO - 2016-02-19 13:54:29 --> Language Class Initialized
ERROR - 2016-02-19 13:54:29 --> Severity: Parsing Error --> syntax error, unexpected '"' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 182
INFO - 2016-02-19 13:55:05 --> Config Class Initialized
INFO - 2016-02-19 13:55:05 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:55:05 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:55:05 --> Utf8 Class Initialized
INFO - 2016-02-19 13:55:05 --> URI Class Initialized
INFO - 2016-02-19 13:55:05 --> Router Class Initialized
INFO - 2016-02-19 13:55:05 --> Output Class Initialized
INFO - 2016-02-19 13:55:05 --> Security Class Initialized
DEBUG - 2016-02-19 13:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:55:05 --> Input Class Initialized
INFO - 2016-02-19 13:55:05 --> Language Class Initialized
INFO - 2016-02-19 13:55:05 --> Loader Class Initialized
INFO - 2016-02-19 13:55:05 --> Helper loaded: url_helper
INFO - 2016-02-19 13:55:05 --> Helper loaded: file_helper
INFO - 2016-02-19 13:55:05 --> Helper loaded: date_helper
INFO - 2016-02-19 13:55:05 --> Helper loaded: form_helper
INFO - 2016-02-19 13:55:05 --> Database Driver Class Initialized
INFO - 2016-02-19 13:55:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:55:06 --> Controller Class Initialized
INFO - 2016-02-19 13:55:06 --> Model Class Initialized
INFO - 2016-02-19 13:55:06 --> Model Class Initialized
INFO - 2016-02-19 13:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:55:06 --> Pagination Class Initialized
INFO - 2016-02-19 13:55:06 --> Helper loaded: text_helper
INFO - 2016-02-19 13:55:06 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 16:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:55:06 --> Final output sent to browser
DEBUG - 2016-02-19 16:55:06 --> Total execution time: 1.1677
INFO - 2016-02-19 13:55:10 --> Config Class Initialized
INFO - 2016-02-19 13:55:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:55:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:55:10 --> Utf8 Class Initialized
INFO - 2016-02-19 13:55:10 --> URI Class Initialized
INFO - 2016-02-19 13:55:10 --> Router Class Initialized
INFO - 2016-02-19 13:55:10 --> Output Class Initialized
INFO - 2016-02-19 13:55:10 --> Security Class Initialized
DEBUG - 2016-02-19 13:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:55:10 --> Input Class Initialized
INFO - 2016-02-19 13:55:10 --> Language Class Initialized
INFO - 2016-02-19 13:55:10 --> Loader Class Initialized
INFO - 2016-02-19 13:55:10 --> Helper loaded: url_helper
INFO - 2016-02-19 13:55:10 --> Helper loaded: file_helper
INFO - 2016-02-19 13:55:10 --> Helper loaded: date_helper
INFO - 2016-02-19 13:55:10 --> Helper loaded: form_helper
INFO - 2016-02-19 13:55:10 --> Database Driver Class Initialized
INFO - 2016-02-19 13:55:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:55:11 --> Controller Class Initialized
INFO - 2016-02-19 13:55:11 --> Model Class Initialized
INFO - 2016-02-19 13:55:11 --> Model Class Initialized
INFO - 2016-02-19 13:55:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:55:11 --> Pagination Class Initialized
INFO - 2016-02-19 13:55:11 --> Helper loaded: text_helper
INFO - 2016-02-19 13:55:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:55:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:55:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:55:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:55:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:55:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:55:11 --> Final output sent to browser
DEBUG - 2016-02-19 16:55:11 --> Total execution time: 1.1568
INFO - 2016-02-19 13:55:19 --> Config Class Initialized
INFO - 2016-02-19 13:55:19 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:55:19 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:55:19 --> Utf8 Class Initialized
INFO - 2016-02-19 13:55:19 --> URI Class Initialized
INFO - 2016-02-19 13:55:19 --> Router Class Initialized
INFO - 2016-02-19 13:55:19 --> Output Class Initialized
INFO - 2016-02-19 13:55:19 --> Security Class Initialized
DEBUG - 2016-02-19 13:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:55:19 --> Input Class Initialized
INFO - 2016-02-19 13:55:19 --> Language Class Initialized
INFO - 2016-02-19 13:55:19 --> Loader Class Initialized
INFO - 2016-02-19 13:55:19 --> Helper loaded: url_helper
INFO - 2016-02-19 13:55:19 --> Helper loaded: file_helper
INFO - 2016-02-19 13:55:19 --> Helper loaded: date_helper
INFO - 2016-02-19 13:55:19 --> Helper loaded: form_helper
INFO - 2016-02-19 13:55:19 --> Database Driver Class Initialized
INFO - 2016-02-19 13:55:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:55:20 --> Controller Class Initialized
INFO - 2016-02-19 13:55:20 --> Model Class Initialized
INFO - 2016-02-19 13:55:20 --> Model Class Initialized
INFO - 2016-02-19 13:55:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:55:20 --> Pagination Class Initialized
INFO - 2016-02-19 13:55:20 --> Helper loaded: text_helper
INFO - 2016-02-19 13:55:20 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:55:20 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
INFO - 2016-02-19 16:55:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:55:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:55:20 --> Form Validation Class Initialized
INFO - 2016-02-19 16:55:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:55:20 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:55:20 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:55:20 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:55:20 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:55:20 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:55:20 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:55:20 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:55:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 13:56:49 --> Config Class Initialized
INFO - 2016-02-19 13:56:49 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:56:49 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:56:49 --> Utf8 Class Initialized
INFO - 2016-02-19 13:56:49 --> URI Class Initialized
INFO - 2016-02-19 13:56:49 --> Router Class Initialized
INFO - 2016-02-19 13:56:49 --> Output Class Initialized
INFO - 2016-02-19 13:56:49 --> Security Class Initialized
DEBUG - 2016-02-19 13:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:56:49 --> Input Class Initialized
INFO - 2016-02-19 13:56:49 --> Language Class Initialized
INFO - 2016-02-19 13:56:49 --> Loader Class Initialized
INFO - 2016-02-19 13:56:49 --> Helper loaded: url_helper
INFO - 2016-02-19 13:56:49 --> Helper loaded: file_helper
INFO - 2016-02-19 13:56:49 --> Helper loaded: date_helper
INFO - 2016-02-19 13:56:49 --> Helper loaded: form_helper
INFO - 2016-02-19 13:56:49 --> Database Driver Class Initialized
INFO - 2016-02-19 13:56:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:56:50 --> Controller Class Initialized
INFO - 2016-02-19 13:56:50 --> Model Class Initialized
INFO - 2016-02-19 13:56:50 --> Model Class Initialized
INFO - 2016-02-19 13:56:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:56:50 --> Pagination Class Initialized
INFO - 2016-02-19 13:56:50 --> Helper loaded: text_helper
INFO - 2016-02-19 13:56:50 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:56:50 --> Final output sent to browser
DEBUG - 2016-02-19 16:56:50 --> Total execution time: 1.1317
INFO - 2016-02-19 13:56:55 --> Config Class Initialized
INFO - 2016-02-19 13:56:55 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:56:55 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:56:55 --> Utf8 Class Initialized
INFO - 2016-02-19 13:56:55 --> URI Class Initialized
INFO - 2016-02-19 13:56:55 --> Router Class Initialized
INFO - 2016-02-19 13:56:55 --> Output Class Initialized
INFO - 2016-02-19 13:56:55 --> Security Class Initialized
DEBUG - 2016-02-19 13:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:56:55 --> Input Class Initialized
INFO - 2016-02-19 13:56:55 --> Language Class Initialized
INFO - 2016-02-19 13:56:55 --> Loader Class Initialized
INFO - 2016-02-19 13:56:55 --> Helper loaded: url_helper
INFO - 2016-02-19 13:56:55 --> Helper loaded: file_helper
INFO - 2016-02-19 13:56:55 --> Helper loaded: date_helper
INFO - 2016-02-19 13:56:55 --> Helper loaded: form_helper
INFO - 2016-02-19 13:56:55 --> Database Driver Class Initialized
INFO - 2016-02-19 13:56:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:56:56 --> Controller Class Initialized
INFO - 2016-02-19 13:56:56 --> Model Class Initialized
INFO - 2016-02-19 13:56:56 --> Model Class Initialized
INFO - 2016-02-19 13:56:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:56:56 --> Pagination Class Initialized
INFO - 2016-02-19 13:56:56 --> Helper loaded: text_helper
INFO - 2016-02-19 13:56:56 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:56:56 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
INFO - 2016-02-19 16:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:56:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:56:56 --> Form Validation Class Initialized
INFO - 2016-02-19 16:56:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:56:56 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:56:56 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:56:56 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:56:56 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:56:56 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:56:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:56:56 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:56:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:56:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 13:58:11 --> Config Class Initialized
INFO - 2016-02-19 13:58:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:58:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:58:11 --> Utf8 Class Initialized
INFO - 2016-02-19 13:58:11 --> URI Class Initialized
INFO - 2016-02-19 13:58:11 --> Router Class Initialized
INFO - 2016-02-19 13:58:11 --> Output Class Initialized
INFO - 2016-02-19 13:58:11 --> Security Class Initialized
DEBUG - 2016-02-19 13:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:58:11 --> Input Class Initialized
INFO - 2016-02-19 13:58:11 --> Language Class Initialized
INFO - 2016-02-19 13:58:11 --> Loader Class Initialized
INFO - 2016-02-19 13:58:11 --> Helper loaded: url_helper
INFO - 2016-02-19 13:58:11 --> Helper loaded: file_helper
INFO - 2016-02-19 13:58:11 --> Helper loaded: date_helper
INFO - 2016-02-19 13:58:11 --> Helper loaded: form_helper
INFO - 2016-02-19 13:58:11 --> Database Driver Class Initialized
INFO - 2016-02-19 13:58:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:58:12 --> Controller Class Initialized
INFO - 2016-02-19 13:58:12 --> Model Class Initialized
INFO - 2016-02-19 13:58:12 --> Model Class Initialized
INFO - 2016-02-19 13:58:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:58:12 --> Pagination Class Initialized
INFO - 2016-02-19 13:58:12 --> Helper loaded: text_helper
INFO - 2016-02-19 13:58:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:58:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:58:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:58:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:58:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:58:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:58:12 --> Final output sent to browser
DEBUG - 2016-02-19 16:58:12 --> Total execution time: 1.1536
INFO - 2016-02-19 13:58:17 --> Config Class Initialized
INFO - 2016-02-19 13:58:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:58:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:58:17 --> Utf8 Class Initialized
INFO - 2016-02-19 13:58:17 --> URI Class Initialized
INFO - 2016-02-19 13:58:17 --> Router Class Initialized
INFO - 2016-02-19 13:58:17 --> Output Class Initialized
INFO - 2016-02-19 13:58:17 --> Security Class Initialized
DEBUG - 2016-02-19 13:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:58:17 --> Input Class Initialized
INFO - 2016-02-19 13:58:17 --> Language Class Initialized
INFO - 2016-02-19 13:58:17 --> Loader Class Initialized
INFO - 2016-02-19 13:58:17 --> Helper loaded: url_helper
INFO - 2016-02-19 13:58:17 --> Helper loaded: file_helper
INFO - 2016-02-19 13:58:17 --> Helper loaded: date_helper
INFO - 2016-02-19 13:58:17 --> Helper loaded: form_helper
INFO - 2016-02-19 13:58:17 --> Database Driver Class Initialized
INFO - 2016-02-19 13:58:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:58:18 --> Controller Class Initialized
INFO - 2016-02-19 13:58:18 --> Model Class Initialized
INFO - 2016-02-19 13:58:18 --> Model Class Initialized
INFO - 2016-02-19 13:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:58:18 --> Pagination Class Initialized
INFO - 2016-02-19 13:58:18 --> Helper loaded: text_helper
INFO - 2016-02-19 13:58:18 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:58:18 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
INFO - 2016-02-19 16:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:58:18 --> Form Validation Class Initialized
INFO - 2016-02-19 16:58:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:58:18 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:58:18 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:58:18 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:58:18 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:58:18 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:58:18 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:58:18 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:58:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:58:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 13:59:07 --> Config Class Initialized
INFO - 2016-02-19 13:59:07 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:59:07 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:59:07 --> Utf8 Class Initialized
INFO - 2016-02-19 13:59:07 --> URI Class Initialized
INFO - 2016-02-19 13:59:07 --> Router Class Initialized
INFO - 2016-02-19 13:59:07 --> Output Class Initialized
INFO - 2016-02-19 13:59:07 --> Security Class Initialized
DEBUG - 2016-02-19 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:59:07 --> Input Class Initialized
INFO - 2016-02-19 13:59:07 --> Language Class Initialized
INFO - 2016-02-19 13:59:07 --> Loader Class Initialized
INFO - 2016-02-19 13:59:07 --> Helper loaded: url_helper
INFO - 2016-02-19 13:59:07 --> Helper loaded: file_helper
INFO - 2016-02-19 13:59:07 --> Helper loaded: date_helper
INFO - 2016-02-19 13:59:07 --> Helper loaded: form_helper
INFO - 2016-02-19 13:59:07 --> Database Driver Class Initialized
INFO - 2016-02-19 13:59:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:59:08 --> Controller Class Initialized
INFO - 2016-02-19 13:59:08 --> Model Class Initialized
INFO - 2016-02-19 13:59:08 --> Model Class Initialized
INFO - 2016-02-19 13:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:59:08 --> Pagination Class Initialized
INFO - 2016-02-19 13:59:08 --> Helper loaded: text_helper
INFO - 2016-02-19 13:59:08 --> Helper loaded: cookie_helper
INFO - 2016-02-19 16:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 16:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 16:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 16:59:08 --> Final output sent to browser
DEBUG - 2016-02-19 16:59:08 --> Total execution time: 1.1282
INFO - 2016-02-19 13:59:12 --> Config Class Initialized
INFO - 2016-02-19 13:59:12 --> Hooks Class Initialized
DEBUG - 2016-02-19 13:59:12 --> UTF-8 Support Enabled
INFO - 2016-02-19 13:59:12 --> Utf8 Class Initialized
INFO - 2016-02-19 13:59:12 --> URI Class Initialized
INFO - 2016-02-19 13:59:12 --> Router Class Initialized
INFO - 2016-02-19 13:59:12 --> Output Class Initialized
INFO - 2016-02-19 13:59:12 --> Security Class Initialized
DEBUG - 2016-02-19 13:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 13:59:12 --> Input Class Initialized
INFO - 2016-02-19 13:59:12 --> Language Class Initialized
INFO - 2016-02-19 13:59:12 --> Loader Class Initialized
INFO - 2016-02-19 13:59:12 --> Helper loaded: url_helper
INFO - 2016-02-19 13:59:12 --> Helper loaded: file_helper
INFO - 2016-02-19 13:59:12 --> Helper loaded: date_helper
INFO - 2016-02-19 13:59:12 --> Helper loaded: form_helper
INFO - 2016-02-19 13:59:12 --> Database Driver Class Initialized
INFO - 2016-02-19 13:59:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 13:59:13 --> Controller Class Initialized
INFO - 2016-02-19 13:59:13 --> Model Class Initialized
INFO - 2016-02-19 13:59:13 --> Model Class Initialized
INFO - 2016-02-19 13:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 13:59:13 --> Pagination Class Initialized
INFO - 2016-02-19 13:59:13 --> Helper loaded: text_helper
INFO - 2016-02-19 13:59:13 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 16:59:13 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
INFO - 2016-02-19 16:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 16:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 16:59:13 --> Form Validation Class Initialized
INFO - 2016-02-19 16:59:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 16:59:13 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 16:59:13 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 16:59:13 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 16:59:13 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 16:59:13 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 16:59:13 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 16:59:13 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 16:59:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 16:59:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 14:01:10 --> Config Class Initialized
INFO - 2016-02-19 14:01:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:01:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:01:10 --> Utf8 Class Initialized
INFO - 2016-02-19 14:01:10 --> URI Class Initialized
INFO - 2016-02-19 14:01:10 --> Router Class Initialized
INFO - 2016-02-19 14:01:10 --> Output Class Initialized
INFO - 2016-02-19 14:01:10 --> Security Class Initialized
DEBUG - 2016-02-19 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:01:10 --> Input Class Initialized
INFO - 2016-02-19 14:01:10 --> Language Class Initialized
INFO - 2016-02-19 14:01:10 --> Loader Class Initialized
INFO - 2016-02-19 14:01:10 --> Helper loaded: url_helper
INFO - 2016-02-19 14:01:10 --> Helper loaded: file_helper
INFO - 2016-02-19 14:01:10 --> Helper loaded: date_helper
INFO - 2016-02-19 14:01:10 --> Helper loaded: form_helper
INFO - 2016-02-19 14:01:10 --> Database Driver Class Initialized
INFO - 2016-02-19 14:01:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:01:11 --> Controller Class Initialized
INFO - 2016-02-19 14:01:11 --> Model Class Initialized
INFO - 2016-02-19 14:01:11 --> Model Class Initialized
INFO - 2016-02-19 14:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:01:11 --> Pagination Class Initialized
INFO - 2016-02-19 14:01:11 --> Helper loaded: text_helper
INFO - 2016-02-19 14:01:11 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 17:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:01:11 --> Final output sent to browser
DEBUG - 2016-02-19 17:01:11 --> Total execution time: 1.1296
INFO - 2016-02-19 14:02:56 --> Config Class Initialized
INFO - 2016-02-19 14:02:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:02:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:02:56 --> Utf8 Class Initialized
INFO - 2016-02-19 14:02:56 --> URI Class Initialized
INFO - 2016-02-19 14:02:56 --> Router Class Initialized
INFO - 2016-02-19 14:02:56 --> Output Class Initialized
INFO - 2016-02-19 14:02:56 --> Security Class Initialized
DEBUG - 2016-02-19 14:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:02:56 --> Input Class Initialized
INFO - 2016-02-19 14:02:56 --> Language Class Initialized
INFO - 2016-02-19 14:02:56 --> Loader Class Initialized
INFO - 2016-02-19 14:02:56 --> Helper loaded: url_helper
INFO - 2016-02-19 14:02:56 --> Helper loaded: file_helper
INFO - 2016-02-19 14:02:56 --> Helper loaded: date_helper
INFO - 2016-02-19 14:02:56 --> Helper loaded: form_helper
INFO - 2016-02-19 14:02:56 --> Database Driver Class Initialized
INFO - 2016-02-19 14:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:02:57 --> Controller Class Initialized
INFO - 2016-02-19 14:02:57 --> Model Class Initialized
INFO - 2016-02-19 14:02:57 --> Model Class Initialized
INFO - 2016-02-19 14:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:02:57 --> Pagination Class Initialized
INFO - 2016-02-19 14:02:57 --> Helper loaded: text_helper
INFO - 2016-02-19 14:02:57 --> Helper loaded: cookie_helper
ERROR - 2016-02-19 17:02:57 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 152
INFO - 2016-02-19 17:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:02:57 --> Form Validation Class Initialized
INFO - 2016-02-19 17:02:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 17:02:57 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 17:02:57 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 17:02:57 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 17:02:57 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 17:02:57 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 17:02:57 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 17:02:57 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 17:02:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 17:02:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 14:04:11 --> Config Class Initialized
INFO - 2016-02-19 14:04:11 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:04:11 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:04:11 --> Utf8 Class Initialized
INFO - 2016-02-19 14:04:11 --> URI Class Initialized
INFO - 2016-02-19 14:04:11 --> Router Class Initialized
INFO - 2016-02-19 14:04:11 --> Output Class Initialized
INFO - 2016-02-19 14:04:11 --> Security Class Initialized
DEBUG - 2016-02-19 14:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:04:11 --> Input Class Initialized
INFO - 2016-02-19 14:04:11 --> Language Class Initialized
INFO - 2016-02-19 14:04:11 --> Loader Class Initialized
INFO - 2016-02-19 14:04:11 --> Helper loaded: url_helper
INFO - 2016-02-19 14:04:11 --> Helper loaded: file_helper
INFO - 2016-02-19 14:04:11 --> Helper loaded: date_helper
INFO - 2016-02-19 14:04:11 --> Helper loaded: form_helper
INFO - 2016-02-19 14:04:11 --> Database Driver Class Initialized
INFO - 2016-02-19 14:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:04:12 --> Controller Class Initialized
INFO - 2016-02-19 14:04:12 --> Model Class Initialized
INFO - 2016-02-19 14:04:12 --> Model Class Initialized
INFO - 2016-02-19 14:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:04:12 --> Pagination Class Initialized
INFO - 2016-02-19 14:04:12 --> Helper loaded: text_helper
INFO - 2016-02-19 14:04:12 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 17:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:04:12 --> Final output sent to browser
DEBUG - 2016-02-19 17:04:12 --> Total execution time: 1.1672
INFO - 2016-02-19 14:04:18 --> Config Class Initialized
INFO - 2016-02-19 14:04:18 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:04:18 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:04:18 --> Utf8 Class Initialized
INFO - 2016-02-19 14:04:18 --> URI Class Initialized
INFO - 2016-02-19 14:04:18 --> Router Class Initialized
INFO - 2016-02-19 14:04:18 --> Output Class Initialized
INFO - 2016-02-19 14:04:18 --> Security Class Initialized
DEBUG - 2016-02-19 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:04:18 --> Input Class Initialized
INFO - 2016-02-19 14:04:18 --> Language Class Initialized
INFO - 2016-02-19 14:04:18 --> Loader Class Initialized
INFO - 2016-02-19 14:04:18 --> Helper loaded: url_helper
INFO - 2016-02-19 14:04:18 --> Helper loaded: file_helper
INFO - 2016-02-19 14:04:18 --> Helper loaded: date_helper
INFO - 2016-02-19 14:04:18 --> Helper loaded: form_helper
INFO - 2016-02-19 14:04:18 --> Database Driver Class Initialized
INFO - 2016-02-19 14:04:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:04:19 --> Controller Class Initialized
INFO - 2016-02-19 14:04:19 --> Model Class Initialized
INFO - 2016-02-19 14:04:19 --> Model Class Initialized
INFO - 2016-02-19 14:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:04:19 --> Pagination Class Initialized
INFO - 2016-02-19 14:04:19 --> Helper loaded: text_helper
INFO - 2016-02-19 14:04:19 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:04:19 --> Form Validation Class Initialized
INFO - 2016-02-19 17:04:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-19 17:04:19 --> Severity: Warning --> Missing argument 2 for Jboard_model::add(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 179 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 89
ERROR - 2016-02-19 17:04:19 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 92
ERROR - 2016-02-19 17:04:19 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-19 17:04:19 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 94
ERROR - 2016-02-19 17:04:19 --> Severity: Notice --> Undefined variable: user_info C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-19 17:04:19 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-19 17:04:19 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), NULL, NULL, NULL, NULL)
INFO - 2016-02-19 17:04:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-19 17:04:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-19 14:05:14 --> Config Class Initialized
INFO - 2016-02-19 14:05:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:05:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:05:14 --> Utf8 Class Initialized
INFO - 2016-02-19 14:05:14 --> URI Class Initialized
INFO - 2016-02-19 14:05:14 --> Router Class Initialized
INFO - 2016-02-19 14:05:14 --> Output Class Initialized
INFO - 2016-02-19 14:05:14 --> Security Class Initialized
DEBUG - 2016-02-19 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:05:14 --> Input Class Initialized
INFO - 2016-02-19 14:05:14 --> Language Class Initialized
INFO - 2016-02-19 14:05:14 --> Loader Class Initialized
INFO - 2016-02-19 14:05:14 --> Helper loaded: url_helper
INFO - 2016-02-19 14:05:14 --> Helper loaded: file_helper
INFO - 2016-02-19 14:05:14 --> Helper loaded: date_helper
INFO - 2016-02-19 14:05:14 --> Helper loaded: form_helper
INFO - 2016-02-19 14:05:14 --> Database Driver Class Initialized
INFO - 2016-02-19 14:05:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:05:15 --> Controller Class Initialized
INFO - 2016-02-19 14:05:15 --> Model Class Initialized
INFO - 2016-02-19 14:05:15 --> Model Class Initialized
INFO - 2016-02-19 14:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:05:15 --> Pagination Class Initialized
INFO - 2016-02-19 14:05:15 --> Helper loaded: text_helper
INFO - 2016-02-19 14:05:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 17:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:05:15 --> Final output sent to browser
DEBUG - 2016-02-19 17:05:15 --> Total execution time: 1.1296
INFO - 2016-02-19 14:05:20 --> Config Class Initialized
INFO - 2016-02-19 14:05:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:05:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:05:20 --> Utf8 Class Initialized
INFO - 2016-02-19 14:05:20 --> URI Class Initialized
INFO - 2016-02-19 14:05:20 --> Router Class Initialized
INFO - 2016-02-19 14:05:20 --> Output Class Initialized
INFO - 2016-02-19 14:05:20 --> Security Class Initialized
DEBUG - 2016-02-19 14:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:05:20 --> Input Class Initialized
INFO - 2016-02-19 14:05:20 --> Language Class Initialized
INFO - 2016-02-19 14:05:20 --> Loader Class Initialized
INFO - 2016-02-19 14:05:20 --> Helper loaded: url_helper
INFO - 2016-02-19 14:05:20 --> Helper loaded: file_helper
INFO - 2016-02-19 14:05:20 --> Helper loaded: date_helper
INFO - 2016-02-19 14:05:20 --> Helper loaded: form_helper
INFO - 2016-02-19 14:05:20 --> Database Driver Class Initialized
INFO - 2016-02-19 14:05:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:05:21 --> Controller Class Initialized
INFO - 2016-02-19 14:05:21 --> Model Class Initialized
INFO - 2016-02-19 14:05:21 --> Model Class Initialized
INFO - 2016-02-19 14:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:05:21 --> Pagination Class Initialized
INFO - 2016-02-19 14:05:21 --> Helper loaded: text_helper
INFO - 2016-02-19 14:05:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:05:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:05:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:05:21 --> Form Validation Class Initialized
INFO - 2016-02-19 17:05:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-19 14:05:21 --> Config Class Initialized
INFO - 2016-02-19 14:05:21 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:05:21 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:05:21 --> Utf8 Class Initialized
INFO - 2016-02-19 14:05:21 --> URI Class Initialized
INFO - 2016-02-19 14:05:21 --> Router Class Initialized
INFO - 2016-02-19 14:05:21 --> Output Class Initialized
INFO - 2016-02-19 14:05:21 --> Security Class Initialized
DEBUG - 2016-02-19 14:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:05:21 --> Input Class Initialized
INFO - 2016-02-19 14:05:21 --> Language Class Initialized
ERROR - 2016-02-19 14:05:21 --> 404 Page Not Found: Picture/get
INFO - 2016-02-19 14:12:25 --> Config Class Initialized
INFO - 2016-02-19 14:12:25 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:12:25 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:12:25 --> Utf8 Class Initialized
INFO - 2016-02-19 14:12:25 --> URI Class Initialized
INFO - 2016-02-19 14:12:25 --> Router Class Initialized
INFO - 2016-02-19 14:12:25 --> Output Class Initialized
INFO - 2016-02-19 14:12:25 --> Security Class Initialized
DEBUG - 2016-02-19 14:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:12:25 --> Input Class Initialized
INFO - 2016-02-19 14:12:25 --> Language Class Initialized
INFO - 2016-02-19 14:12:25 --> Loader Class Initialized
INFO - 2016-02-19 14:12:25 --> Helper loaded: url_helper
INFO - 2016-02-19 14:12:25 --> Helper loaded: file_helper
INFO - 2016-02-19 14:12:25 --> Helper loaded: date_helper
INFO - 2016-02-19 14:12:25 --> Helper loaded: form_helper
INFO - 2016-02-19 14:12:25 --> Database Driver Class Initialized
INFO - 2016-02-19 14:12:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:12:26 --> Controller Class Initialized
INFO - 2016-02-19 14:12:26 --> Model Class Initialized
INFO - 2016-02-19 14:12:26 --> Model Class Initialized
INFO - 2016-02-19 14:12:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:12:26 --> Pagination Class Initialized
INFO - 2016-02-19 14:12:26 --> Helper loaded: text_helper
INFO - 2016-02-19 14:12:26 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:12:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 17:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:12:27 --> Final output sent to browser
DEBUG - 2016-02-19 17:12:27 --> Total execution time: 1.1616
INFO - 2016-02-19 14:12:30 --> Config Class Initialized
INFO - 2016-02-19 14:12:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:12:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:12:30 --> Utf8 Class Initialized
INFO - 2016-02-19 14:12:30 --> URI Class Initialized
INFO - 2016-02-19 14:12:30 --> Router Class Initialized
INFO - 2016-02-19 14:12:30 --> Output Class Initialized
INFO - 2016-02-19 14:12:30 --> Security Class Initialized
DEBUG - 2016-02-19 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:12:30 --> Input Class Initialized
INFO - 2016-02-19 14:12:30 --> Language Class Initialized
INFO - 2016-02-19 14:12:30 --> Loader Class Initialized
INFO - 2016-02-19 14:12:30 --> Helper loaded: url_helper
INFO - 2016-02-19 14:12:30 --> Helper loaded: file_helper
INFO - 2016-02-19 14:12:30 --> Helper loaded: date_helper
INFO - 2016-02-19 14:12:30 --> Helper loaded: form_helper
INFO - 2016-02-19 14:12:30 --> Database Driver Class Initialized
INFO - 2016-02-19 14:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:12:31 --> Controller Class Initialized
INFO - 2016-02-19 14:12:31 --> Model Class Initialized
INFO - 2016-02-19 14:12:31 --> Model Class Initialized
INFO - 2016-02-19 14:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:12:31 --> Pagination Class Initialized
INFO - 2016-02-19 14:12:31 --> Helper loaded: text_helper
INFO - 2016-02-19 14:12:31 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:12:31 --> Final output sent to browser
DEBUG - 2016-02-19 17:12:31 --> Total execution time: 1.1545
INFO - 2016-02-19 14:12:34 --> Config Class Initialized
INFO - 2016-02-19 14:12:34 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:12:34 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:12:34 --> Utf8 Class Initialized
INFO - 2016-02-19 14:12:34 --> URI Class Initialized
INFO - 2016-02-19 14:12:34 --> Router Class Initialized
INFO - 2016-02-19 14:12:34 --> Output Class Initialized
INFO - 2016-02-19 14:12:34 --> Security Class Initialized
DEBUG - 2016-02-19 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:12:34 --> Input Class Initialized
INFO - 2016-02-19 14:12:34 --> Language Class Initialized
INFO - 2016-02-19 14:12:34 --> Loader Class Initialized
INFO - 2016-02-19 14:12:34 --> Helper loaded: url_helper
INFO - 2016-02-19 14:12:34 --> Helper loaded: file_helper
INFO - 2016-02-19 14:12:34 --> Helper loaded: date_helper
INFO - 2016-02-19 14:12:34 --> Helper loaded: form_helper
INFO - 2016-02-19 14:12:34 --> Database Driver Class Initialized
INFO - 2016-02-19 14:12:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:12:35 --> Controller Class Initialized
INFO - 2016-02-19 14:12:35 --> Model Class Initialized
INFO - 2016-02-19 14:12:35 --> Model Class Initialized
INFO - 2016-02-19 14:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:12:35 --> Pagination Class Initialized
INFO - 2016-02-19 14:12:35 --> Helper loaded: text_helper
INFO - 2016-02-19 14:12:35 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:12:35 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT *
FROM `jboard`
WHERE `id` = '5'
INFO - 2016-02-19 17:12:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 14:13:56 --> Config Class Initialized
INFO - 2016-02-19 14:13:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:13:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:13:56 --> Utf8 Class Initialized
INFO - 2016-02-19 14:13:56 --> URI Class Initialized
INFO - 2016-02-19 14:13:56 --> Router Class Initialized
INFO - 2016-02-19 14:13:56 --> Output Class Initialized
INFO - 2016-02-19 14:13:56 --> Security Class Initialized
DEBUG - 2016-02-19 14:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:13:56 --> Input Class Initialized
INFO - 2016-02-19 14:13:56 --> Language Class Initialized
INFO - 2016-02-19 14:13:56 --> Loader Class Initialized
INFO - 2016-02-19 14:13:56 --> Helper loaded: url_helper
INFO - 2016-02-19 14:13:56 --> Helper loaded: file_helper
INFO - 2016-02-19 14:13:56 --> Helper loaded: date_helper
INFO - 2016-02-19 14:13:56 --> Helper loaded: form_helper
INFO - 2016-02-19 14:13:56 --> Database Driver Class Initialized
INFO - 2016-02-19 14:13:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:13:57 --> Controller Class Initialized
INFO - 2016-02-19 14:13:57 --> Model Class Initialized
INFO - 2016-02-19 14:13:57 --> Model Class Initialized
INFO - 2016-02-19 14:13:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:13:57 --> Pagination Class Initialized
INFO - 2016-02-19 14:13:57 --> Helper loaded: text_helper
INFO - 2016-02-19 14:13:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:13:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:13:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:13:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:13:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:13:57 --> Final output sent to browser
DEBUG - 2016-02-19 17:13:57 --> Total execution time: 1.1478
INFO - 2016-02-19 14:13:59 --> Config Class Initialized
INFO - 2016-02-19 14:13:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:13:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:13:59 --> Utf8 Class Initialized
INFO - 2016-02-19 14:13:59 --> URI Class Initialized
INFO - 2016-02-19 14:13:59 --> Router Class Initialized
INFO - 2016-02-19 14:13:59 --> Output Class Initialized
INFO - 2016-02-19 14:13:59 --> Security Class Initialized
DEBUG - 2016-02-19 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:13:59 --> Input Class Initialized
INFO - 2016-02-19 14:13:59 --> Language Class Initialized
INFO - 2016-02-19 14:13:59 --> Loader Class Initialized
INFO - 2016-02-19 14:13:59 --> Helper loaded: url_helper
INFO - 2016-02-19 14:13:59 --> Helper loaded: file_helper
INFO - 2016-02-19 14:13:59 --> Helper loaded: date_helper
INFO - 2016-02-19 14:13:59 --> Helper loaded: form_helper
INFO - 2016-02-19 14:13:59 --> Database Driver Class Initialized
INFO - 2016-02-19 14:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:14:00 --> Controller Class Initialized
INFO - 2016-02-19 14:14:00 --> Model Class Initialized
INFO - 2016-02-19 14:14:00 --> Model Class Initialized
INFO - 2016-02-19 14:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:14:00 --> Pagination Class Initialized
INFO - 2016-02-19 14:14:00 --> Helper loaded: text_helper
INFO - 2016-02-19 14:14:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:14:00 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT *
FROM `jboard`
WHERE `id` = '5'
INFO - 2016-02-19 17:14:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 14:15:13 --> Config Class Initialized
INFO - 2016-02-19 14:15:13 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:15:13 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:15:13 --> Utf8 Class Initialized
INFO - 2016-02-19 14:15:13 --> URI Class Initialized
INFO - 2016-02-19 14:15:13 --> Router Class Initialized
INFO - 2016-02-19 14:15:13 --> Output Class Initialized
INFO - 2016-02-19 14:15:13 --> Security Class Initialized
DEBUG - 2016-02-19 14:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:15:13 --> Input Class Initialized
INFO - 2016-02-19 14:15:13 --> Language Class Initialized
INFO - 2016-02-19 14:15:13 --> Loader Class Initialized
INFO - 2016-02-19 14:15:13 --> Helper loaded: url_helper
INFO - 2016-02-19 14:15:13 --> Helper loaded: file_helper
INFO - 2016-02-19 14:15:13 --> Helper loaded: date_helper
INFO - 2016-02-19 14:15:13 --> Helper loaded: form_helper
INFO - 2016-02-19 14:15:13 --> Database Driver Class Initialized
INFO - 2016-02-19 14:15:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:15:14 --> Controller Class Initialized
INFO - 2016-02-19 14:15:14 --> Model Class Initialized
INFO - 2016-02-19 14:15:14 --> Model Class Initialized
INFO - 2016-02-19 14:15:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:15:14 --> Pagination Class Initialized
INFO - 2016-02-19 14:15:14 --> Helper loaded: text_helper
INFO - 2016-02-19 14:15:14 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:15:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:15:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:15:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-19 17:15:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-19 17:15:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-19 17:15:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-19 17:15:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-19 17:15:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:15:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:15:14 --> Final output sent to browser
DEBUG - 2016-02-19 17:15:14 --> Total execution time: 1.1709
INFO - 2016-02-19 14:16:38 --> Config Class Initialized
INFO - 2016-02-19 14:16:38 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:16:38 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:16:38 --> Utf8 Class Initialized
INFO - 2016-02-19 14:16:38 --> URI Class Initialized
INFO - 2016-02-19 14:16:38 --> Router Class Initialized
INFO - 2016-02-19 14:16:38 --> Output Class Initialized
INFO - 2016-02-19 14:16:38 --> Security Class Initialized
DEBUG - 2016-02-19 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:16:38 --> Input Class Initialized
INFO - 2016-02-19 14:16:38 --> Language Class Initialized
INFO - 2016-02-19 14:16:38 --> Loader Class Initialized
INFO - 2016-02-19 14:16:38 --> Helper loaded: url_helper
INFO - 2016-02-19 14:16:38 --> Helper loaded: file_helper
INFO - 2016-02-19 14:16:38 --> Helper loaded: date_helper
INFO - 2016-02-19 14:16:38 --> Helper loaded: form_helper
INFO - 2016-02-19 14:16:38 --> Database Driver Class Initialized
INFO - 2016-02-19 14:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:16:39 --> Controller Class Initialized
INFO - 2016-02-19 14:16:39 --> Model Class Initialized
INFO - 2016-02-19 14:16:39 --> Model Class Initialized
INFO - 2016-02-19 14:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:16:39 --> Pagination Class Initialized
INFO - 2016-02-19 14:16:39 --> Helper loaded: text_helper
INFO - 2016-02-19 14:16:39 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:16:39 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 96
ERROR - 2016-02-19 17:16:39 --> Query error: No tables used - Invalid query: SELECT *
 LIMIT 19
INFO - 2016-02-19 17:16:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 14:17:00 --> Config Class Initialized
INFO - 2016-02-19 14:17:00 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:17:00 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:17:00 --> Utf8 Class Initialized
INFO - 2016-02-19 14:17:00 --> URI Class Initialized
INFO - 2016-02-19 14:17:00 --> Router Class Initialized
INFO - 2016-02-19 14:17:00 --> Output Class Initialized
INFO - 2016-02-19 14:17:00 --> Security Class Initialized
DEBUG - 2016-02-19 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:17:00 --> Input Class Initialized
INFO - 2016-02-19 14:17:00 --> Language Class Initialized
INFO - 2016-02-19 14:17:00 --> Loader Class Initialized
INFO - 2016-02-19 14:17:00 --> Helper loaded: url_helper
INFO - 2016-02-19 14:17:00 --> Helper loaded: file_helper
INFO - 2016-02-19 14:17:00 --> Helper loaded: date_helper
INFO - 2016-02-19 14:17:00 --> Helper loaded: form_helper
INFO - 2016-02-19 14:17:00 --> Database Driver Class Initialized
INFO - 2016-02-19 14:17:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:17:01 --> Controller Class Initialized
INFO - 2016-02-19 14:17:01 --> Model Class Initialized
INFO - 2016-02-19 14:17:01 --> Model Class Initialized
INFO - 2016-02-19 14:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:17:01 --> Pagination Class Initialized
INFO - 2016-02-19 14:17:01 --> Helper loaded: text_helper
INFO - 2016-02-19 14:17:01 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:17:01 --> Final output sent to browser
DEBUG - 2016-02-19 17:17:01 --> Total execution time: 1.1944
INFO - 2016-02-19 14:17:03 --> Config Class Initialized
INFO - 2016-02-19 14:17:03 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:17:03 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:17:03 --> Utf8 Class Initialized
INFO - 2016-02-19 14:17:03 --> URI Class Initialized
INFO - 2016-02-19 14:17:03 --> Router Class Initialized
INFO - 2016-02-19 14:17:03 --> Output Class Initialized
INFO - 2016-02-19 14:17:03 --> Security Class Initialized
DEBUG - 2016-02-19 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:17:03 --> Input Class Initialized
INFO - 2016-02-19 14:17:03 --> Language Class Initialized
INFO - 2016-02-19 14:17:03 --> Loader Class Initialized
INFO - 2016-02-19 14:17:03 --> Helper loaded: url_helper
INFO - 2016-02-19 14:17:03 --> Helper loaded: file_helper
INFO - 2016-02-19 14:17:03 --> Helper loaded: date_helper
INFO - 2016-02-19 14:17:03 --> Helper loaded: form_helper
INFO - 2016-02-19 14:17:03 --> Database Driver Class Initialized
INFO - 2016-02-19 14:17:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:17:04 --> Controller Class Initialized
INFO - 2016-02-19 14:17:04 --> Model Class Initialized
INFO - 2016-02-19 14:17:04 --> Model Class Initialized
INFO - 2016-02-19 14:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:17:04 --> Pagination Class Initialized
INFO - 2016-02-19 14:17:04 --> Helper loaded: text_helper
INFO - 2016-02-19 14:17:04 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 17:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:17:04 --> Final output sent to browser
DEBUG - 2016-02-19 17:17:04 --> Total execution time: 1.1485
INFO - 2016-02-19 14:17:20 --> Config Class Initialized
INFO - 2016-02-19 14:17:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:17:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:17:20 --> Utf8 Class Initialized
INFO - 2016-02-19 14:17:20 --> URI Class Initialized
INFO - 2016-02-19 14:17:20 --> Router Class Initialized
INFO - 2016-02-19 14:17:20 --> Output Class Initialized
INFO - 2016-02-19 14:17:20 --> Security Class Initialized
DEBUG - 2016-02-19 14:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:17:20 --> Input Class Initialized
INFO - 2016-02-19 14:17:20 --> Language Class Initialized
INFO - 2016-02-19 14:17:20 --> Loader Class Initialized
INFO - 2016-02-19 14:17:20 --> Helper loaded: url_helper
INFO - 2016-02-19 14:17:20 --> Helper loaded: file_helper
INFO - 2016-02-19 14:17:20 --> Helper loaded: date_helper
INFO - 2016-02-19 14:17:20 --> Helper loaded: form_helper
INFO - 2016-02-19 14:17:20 --> Database Driver Class Initialized
INFO - 2016-02-19 14:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:17:21 --> Controller Class Initialized
INFO - 2016-02-19 14:17:21 --> Model Class Initialized
INFO - 2016-02-19 14:17:21 --> Model Class Initialized
INFO - 2016-02-19 14:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:17:21 --> Pagination Class Initialized
INFO - 2016-02-19 14:17:21 --> Helper loaded: text_helper
INFO - 2016-02-19 14:17:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:17:21 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT *
FROM `Jboard`
WHERE `id` = '48'
INFO - 2016-02-19 17:17:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 14:17:26 --> Config Class Initialized
INFO - 2016-02-19 14:17:26 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:17:26 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:17:26 --> Utf8 Class Initialized
INFO - 2016-02-19 14:17:26 --> URI Class Initialized
INFO - 2016-02-19 14:17:26 --> Router Class Initialized
INFO - 2016-02-19 14:17:26 --> Output Class Initialized
INFO - 2016-02-19 14:17:26 --> Security Class Initialized
DEBUG - 2016-02-19 14:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:17:26 --> Input Class Initialized
INFO - 2016-02-19 14:17:26 --> Language Class Initialized
INFO - 2016-02-19 14:17:26 --> Loader Class Initialized
INFO - 2016-02-19 14:17:26 --> Helper loaded: url_helper
INFO - 2016-02-19 14:17:26 --> Helper loaded: file_helper
INFO - 2016-02-19 14:17:26 --> Helper loaded: date_helper
INFO - 2016-02-19 14:17:26 --> Helper loaded: form_helper
INFO - 2016-02-19 14:17:26 --> Database Driver Class Initialized
INFO - 2016-02-19 14:17:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:17:27 --> Controller Class Initialized
INFO - 2016-02-19 14:17:27 --> Model Class Initialized
INFO - 2016-02-19 14:17:27 --> Model Class Initialized
INFO - 2016-02-19 14:17:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:17:27 --> Pagination Class Initialized
INFO - 2016-02-19 14:17:27 --> Helper loaded: text_helper
INFO - 2016-02-19 14:17:28 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:17:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:17:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:17:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 17:17:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:17:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:17:28 --> Final output sent to browser
DEBUG - 2016-02-19 17:17:28 --> Total execution time: 1.1854
INFO - 2016-02-19 14:18:10 --> Config Class Initialized
INFO - 2016-02-19 14:18:10 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:18:10 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:18:10 --> Utf8 Class Initialized
INFO - 2016-02-19 14:18:10 --> URI Class Initialized
INFO - 2016-02-19 14:18:10 --> Router Class Initialized
INFO - 2016-02-19 14:18:10 --> Output Class Initialized
INFO - 2016-02-19 14:18:10 --> Security Class Initialized
DEBUG - 2016-02-19 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:18:10 --> Input Class Initialized
INFO - 2016-02-19 14:18:10 --> Language Class Initialized
ERROR - 2016-02-19 14:18:10 --> 404 Page Not Found: Jboard/picture
INFO - 2016-02-19 14:18:14 --> Config Class Initialized
INFO - 2016-02-19 14:18:14 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:18:14 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:18:14 --> Utf8 Class Initialized
INFO - 2016-02-19 14:18:14 --> URI Class Initialized
INFO - 2016-02-19 14:18:14 --> Router Class Initialized
INFO - 2016-02-19 14:18:14 --> Output Class Initialized
INFO - 2016-02-19 14:18:14 --> Security Class Initialized
DEBUG - 2016-02-19 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:18:14 --> Input Class Initialized
INFO - 2016-02-19 14:18:14 --> Language Class Initialized
INFO - 2016-02-19 14:18:14 --> Loader Class Initialized
INFO - 2016-02-19 14:18:14 --> Helper loaded: url_helper
INFO - 2016-02-19 14:18:14 --> Helper loaded: file_helper
INFO - 2016-02-19 14:18:14 --> Helper loaded: date_helper
INFO - 2016-02-19 14:18:14 --> Helper loaded: form_helper
INFO - 2016-02-19 14:18:14 --> Database Driver Class Initialized
INFO - 2016-02-19 14:18:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:18:15 --> Controller Class Initialized
INFO - 2016-02-19 14:18:15 --> Model Class Initialized
INFO - 2016-02-19 14:18:15 --> Model Class Initialized
INFO - 2016-02-19 14:18:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:18:15 --> Pagination Class Initialized
INFO - 2016-02-19 14:18:15 --> Helper loaded: text_helper
INFO - 2016-02-19 14:18:15 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:18:15 --> Final output sent to browser
DEBUG - 2016-02-19 17:18:15 --> Total execution time: 1.1540
INFO - 2016-02-19 14:18:17 --> Config Class Initialized
INFO - 2016-02-19 14:18:17 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:18:17 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:18:17 --> Utf8 Class Initialized
INFO - 2016-02-19 14:18:17 --> URI Class Initialized
INFO - 2016-02-19 14:18:17 --> Router Class Initialized
INFO - 2016-02-19 14:18:17 --> Output Class Initialized
INFO - 2016-02-19 14:18:17 --> Security Class Initialized
DEBUG - 2016-02-19 14:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:18:17 --> Input Class Initialized
INFO - 2016-02-19 14:18:17 --> Language Class Initialized
INFO - 2016-02-19 14:18:17 --> Loader Class Initialized
INFO - 2016-02-19 14:18:17 --> Helper loaded: url_helper
INFO - 2016-02-19 14:18:17 --> Helper loaded: file_helper
INFO - 2016-02-19 14:18:17 --> Helper loaded: date_helper
INFO - 2016-02-19 14:18:17 --> Helper loaded: form_helper
INFO - 2016-02-19 14:18:17 --> Database Driver Class Initialized
INFO - 2016-02-19 14:18:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:18:18 --> Controller Class Initialized
INFO - 2016-02-19 14:18:18 --> Model Class Initialized
INFO - 2016-02-19 14:18:18 --> Model Class Initialized
INFO - 2016-02-19 14:18:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:18:18 --> Pagination Class Initialized
INFO - 2016-02-19 14:18:18 --> Helper loaded: text_helper
INFO - 2016-02-19 14:18:18 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:18:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:18:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:18:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:18:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:18:18 --> Final output sent to browser
DEBUG - 2016-02-19 17:18:18 --> Total execution time: 1.1677
INFO - 2016-02-19 14:21:09 --> Config Class Initialized
INFO - 2016-02-19 14:21:09 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:21:09 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:21:09 --> Utf8 Class Initialized
INFO - 2016-02-19 14:21:09 --> URI Class Initialized
INFO - 2016-02-19 14:21:09 --> Router Class Initialized
INFO - 2016-02-19 14:21:09 --> Output Class Initialized
INFO - 2016-02-19 14:21:09 --> Security Class Initialized
DEBUG - 2016-02-19 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:21:09 --> Input Class Initialized
INFO - 2016-02-19 14:21:09 --> Language Class Initialized
INFO - 2016-02-19 14:21:09 --> Loader Class Initialized
INFO - 2016-02-19 14:21:09 --> Helper loaded: url_helper
INFO - 2016-02-19 14:21:09 --> Helper loaded: file_helper
INFO - 2016-02-19 14:21:09 --> Helper loaded: date_helper
INFO - 2016-02-19 14:21:09 --> Helper loaded: form_helper
INFO - 2016-02-19 14:21:09 --> Database Driver Class Initialized
INFO - 2016-02-19 14:21:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:21:10 --> Controller Class Initialized
INFO - 2016-02-19 14:21:10 --> Model Class Initialized
INFO - 2016-02-19 14:21:10 --> Model Class Initialized
INFO - 2016-02-19 14:21:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:21:10 --> Pagination Class Initialized
INFO - 2016-02-19 14:21:10 --> Helper loaded: text_helper
INFO - 2016-02-19 14:21:10 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:21:11 --> Final output sent to browser
DEBUG - 2016-02-19 17:21:11 --> Total execution time: 1.2339
INFO - 2016-02-19 14:23:53 --> Config Class Initialized
INFO - 2016-02-19 14:23:53 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:23:53 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:23:53 --> Utf8 Class Initialized
INFO - 2016-02-19 14:23:53 --> URI Class Initialized
DEBUG - 2016-02-19 14:23:53 --> No URI present. Default controller set.
INFO - 2016-02-19 14:23:53 --> Router Class Initialized
INFO - 2016-02-19 14:23:53 --> Output Class Initialized
INFO - 2016-02-19 14:23:53 --> Security Class Initialized
DEBUG - 2016-02-19 14:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:23:53 --> Input Class Initialized
INFO - 2016-02-19 14:23:53 --> Language Class Initialized
INFO - 2016-02-19 14:23:53 --> Loader Class Initialized
INFO - 2016-02-19 14:23:53 --> Helper loaded: url_helper
INFO - 2016-02-19 14:23:53 --> Helper loaded: file_helper
INFO - 2016-02-19 14:23:53 --> Helper loaded: date_helper
INFO - 2016-02-19 14:23:53 --> Helper loaded: form_helper
INFO - 2016-02-19 14:23:53 --> Database Driver Class Initialized
INFO - 2016-02-19 14:23:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:23:54 --> Controller Class Initialized
INFO - 2016-02-19 14:23:54 --> Model Class Initialized
INFO - 2016-02-19 14:23:54 --> Model Class Initialized
INFO - 2016-02-19 14:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:23:54 --> Pagination Class Initialized
INFO - 2016-02-19 14:23:54 --> Helper loaded: text_helper
INFO - 2016-02-19 14:23:54 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:23:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:23:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-19 17:23:54 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-19 17:23:54 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-19 17:23:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19' at line 2 - Invalid query: SELECT *
FROM 19
INFO - 2016-02-19 17:23:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-19 14:23:59 --> Config Class Initialized
INFO - 2016-02-19 14:23:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:23:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:23:59 --> Utf8 Class Initialized
INFO - 2016-02-19 14:23:59 --> URI Class Initialized
INFO - 2016-02-19 14:23:59 --> Router Class Initialized
INFO - 2016-02-19 14:23:59 --> Output Class Initialized
INFO - 2016-02-19 14:23:59 --> Security Class Initialized
DEBUG - 2016-02-19 14:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:23:59 --> Input Class Initialized
INFO - 2016-02-19 14:23:59 --> Language Class Initialized
INFO - 2016-02-19 14:23:59 --> Loader Class Initialized
INFO - 2016-02-19 14:23:59 --> Helper loaded: url_helper
INFO - 2016-02-19 14:23:59 --> Helper loaded: file_helper
INFO - 2016-02-19 14:23:59 --> Helper loaded: date_helper
INFO - 2016-02-19 14:23:59 --> Helper loaded: form_helper
INFO - 2016-02-19 14:23:59 --> Database Driver Class Initialized
INFO - 2016-02-19 14:24:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:24:00 --> Controller Class Initialized
INFO - 2016-02-19 14:24:00 --> Model Class Initialized
INFO - 2016-02-19 14:24:00 --> Model Class Initialized
INFO - 2016-02-19 14:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:24:00 --> Pagination Class Initialized
INFO - 2016-02-19 14:24:00 --> Helper loaded: text_helper
INFO - 2016-02-19 14:24:00 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 17:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:24:00 --> Final output sent to browser
DEBUG - 2016-02-19 17:24:00 --> Total execution time: 1.1382
INFO - 2016-02-19 14:24:04 --> Config Class Initialized
INFO - 2016-02-19 14:24:04 --> Hooks Class Initialized
DEBUG - 2016-02-19 14:24:04 --> UTF-8 Support Enabled
INFO - 2016-02-19 14:24:04 --> Utf8 Class Initialized
INFO - 2016-02-19 14:24:04 --> URI Class Initialized
INFO - 2016-02-19 14:24:04 --> Router Class Initialized
INFO - 2016-02-19 14:24:04 --> Output Class Initialized
INFO - 2016-02-19 14:24:04 --> Security Class Initialized
DEBUG - 2016-02-19 14:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 14:24:04 --> Input Class Initialized
INFO - 2016-02-19 14:24:04 --> Language Class Initialized
INFO - 2016-02-19 14:24:04 --> Loader Class Initialized
INFO - 2016-02-19 14:24:04 --> Helper loaded: url_helper
INFO - 2016-02-19 14:24:04 --> Helper loaded: file_helper
INFO - 2016-02-19 14:24:04 --> Helper loaded: date_helper
INFO - 2016-02-19 14:24:04 --> Helper loaded: form_helper
INFO - 2016-02-19 14:24:04 --> Database Driver Class Initialized
INFO - 2016-02-19 14:24:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 14:24:05 --> Controller Class Initialized
INFO - 2016-02-19 14:24:05 --> Model Class Initialized
INFO - 2016-02-19 14:24:05 --> Model Class Initialized
INFO - 2016-02-19 14:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 14:24:05 --> Pagination Class Initialized
INFO - 2016-02-19 14:24:05 --> Helper loaded: text_helper
INFO - 2016-02-19 14:24:05 --> Helper loaded: cookie_helper
INFO - 2016-02-19 17:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 17:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 17:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-19 17:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 17:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 17:24:05 --> Final output sent to browser
DEBUG - 2016-02-19 17:24:05 --> Total execution time: 1.2014
INFO - 2016-02-19 18:14:20 --> Config Class Initialized
INFO - 2016-02-19 18:14:20 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:14:20 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:14:20 --> Utf8 Class Initialized
INFO - 2016-02-19 18:14:20 --> URI Class Initialized
INFO - 2016-02-19 18:14:20 --> Router Class Initialized
INFO - 2016-02-19 18:14:20 --> Output Class Initialized
INFO - 2016-02-19 18:14:20 --> Security Class Initialized
DEBUG - 2016-02-19 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:14:20 --> Input Class Initialized
INFO - 2016-02-19 18:14:20 --> Language Class Initialized
INFO - 2016-02-19 18:14:20 --> Loader Class Initialized
INFO - 2016-02-19 18:14:20 --> Helper loaded: url_helper
INFO - 2016-02-19 18:14:20 --> Helper loaded: file_helper
INFO - 2016-02-19 18:14:20 --> Helper loaded: date_helper
INFO - 2016-02-19 18:14:20 --> Helper loaded: form_helper
INFO - 2016-02-19 18:14:20 --> Database Driver Class Initialized
INFO - 2016-02-19 18:14:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:14:21 --> Controller Class Initialized
INFO - 2016-02-19 18:14:21 --> Model Class Initialized
INFO - 2016-02-19 18:14:21 --> Model Class Initialized
INFO - 2016-02-19 18:14:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:14:21 --> Pagination Class Initialized
INFO - 2016-02-19 18:14:21 --> Helper loaded: text_helper
INFO - 2016-02-19 18:14:21 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:14:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:14:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:14:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 21:14:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:14:21 --> Final output sent to browser
DEBUG - 2016-02-19 21:14:21 --> Total execution time: 1.1845
INFO - 2016-02-19 18:14:28 --> Config Class Initialized
INFO - 2016-02-19 18:14:28 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:14:28 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:14:28 --> Utf8 Class Initialized
INFO - 2016-02-19 18:14:28 --> URI Class Initialized
INFO - 2016-02-19 18:14:28 --> Router Class Initialized
INFO - 2016-02-19 18:14:28 --> Output Class Initialized
INFO - 2016-02-19 18:14:28 --> Security Class Initialized
DEBUG - 2016-02-19 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:14:28 --> Input Class Initialized
INFO - 2016-02-19 18:14:28 --> Language Class Initialized
INFO - 2016-02-19 18:14:28 --> Loader Class Initialized
INFO - 2016-02-19 18:14:28 --> Helper loaded: url_helper
INFO - 2016-02-19 18:14:28 --> Helper loaded: file_helper
INFO - 2016-02-19 18:14:28 --> Helper loaded: date_helper
INFO - 2016-02-19 18:14:28 --> Helper loaded: form_helper
INFO - 2016-02-19 18:14:28 --> Database Driver Class Initialized
INFO - 2016-02-19 18:14:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:14:29 --> Controller Class Initialized
INFO - 2016-02-19 18:14:29 --> Model Class Initialized
INFO - 2016-02-19 18:14:29 --> Model Class Initialized
INFO - 2016-02-19 18:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:14:29 --> Pagination Class Initialized
INFO - 2016-02-19 18:14:29 --> Helper loaded: text_helper
INFO - 2016-02-19 18:14:29 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 21:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 21:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:14:29 --> Final output sent to browser
DEBUG - 2016-02-19 21:14:29 --> Total execution time: 1.1434
INFO - 2016-02-19 18:15:56 --> Config Class Initialized
INFO - 2016-02-19 18:15:56 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:15:56 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:15:56 --> Utf8 Class Initialized
INFO - 2016-02-19 18:15:56 --> URI Class Initialized
INFO - 2016-02-19 18:15:56 --> Router Class Initialized
INFO - 2016-02-19 18:15:56 --> Output Class Initialized
INFO - 2016-02-19 18:15:56 --> Security Class Initialized
DEBUG - 2016-02-19 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:15:56 --> Input Class Initialized
INFO - 2016-02-19 18:15:56 --> Language Class Initialized
INFO - 2016-02-19 18:15:56 --> Loader Class Initialized
INFO - 2016-02-19 18:15:56 --> Helper loaded: url_helper
INFO - 2016-02-19 18:15:56 --> Helper loaded: file_helper
INFO - 2016-02-19 18:15:56 --> Helper loaded: date_helper
INFO - 2016-02-19 18:15:56 --> Helper loaded: form_helper
INFO - 2016-02-19 18:15:56 --> Database Driver Class Initialized
INFO - 2016-02-19 18:15:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:15:57 --> Controller Class Initialized
INFO - 2016-02-19 18:15:57 --> Model Class Initialized
INFO - 2016-02-19 18:15:57 --> Model Class Initialized
INFO - 2016-02-19 18:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:15:57 --> Pagination Class Initialized
INFO - 2016-02-19 18:15:57 --> Helper loaded: text_helper
INFO - 2016-02-19 18:15:57 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 21:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:15:57 --> Final output sent to browser
DEBUG - 2016-02-19 21:15:57 --> Total execution time: 1.1472
INFO - 2016-02-19 18:15:59 --> Config Class Initialized
INFO - 2016-02-19 18:15:59 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:15:59 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:15:59 --> Utf8 Class Initialized
INFO - 2016-02-19 18:15:59 --> URI Class Initialized
INFO - 2016-02-19 18:15:59 --> Router Class Initialized
INFO - 2016-02-19 18:15:59 --> Output Class Initialized
INFO - 2016-02-19 18:15:59 --> Security Class Initialized
DEBUG - 2016-02-19 18:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:15:59 --> Input Class Initialized
INFO - 2016-02-19 18:15:59 --> Language Class Initialized
ERROR - 2016-02-19 18:15:59 --> 404 Page Not Found: Picture/write
INFO - 2016-02-19 18:16:30 --> Config Class Initialized
INFO - 2016-02-19 18:16:30 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:16:30 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:16:30 --> Utf8 Class Initialized
INFO - 2016-02-19 18:16:30 --> URI Class Initialized
INFO - 2016-02-19 18:16:30 --> Router Class Initialized
INFO - 2016-02-19 18:16:30 --> Output Class Initialized
INFO - 2016-02-19 18:16:30 --> Security Class Initialized
DEBUG - 2016-02-19 18:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:16:30 --> Input Class Initialized
INFO - 2016-02-19 18:16:30 --> Language Class Initialized
INFO - 2016-02-19 18:16:30 --> Loader Class Initialized
INFO - 2016-02-19 18:16:30 --> Helper loaded: url_helper
INFO - 2016-02-19 18:16:30 --> Helper loaded: file_helper
INFO - 2016-02-19 18:16:30 --> Helper loaded: date_helper
INFO - 2016-02-19 18:16:30 --> Helper loaded: form_helper
INFO - 2016-02-19 18:16:30 --> Database Driver Class Initialized
INFO - 2016-02-19 18:16:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:16:32 --> Controller Class Initialized
INFO - 2016-02-19 18:16:32 --> Model Class Initialized
INFO - 2016-02-19 18:16:32 --> Model Class Initialized
INFO - 2016-02-19 18:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:16:32 --> Pagination Class Initialized
INFO - 2016-02-19 18:16:32 --> Helper loaded: text_helper
INFO - 2016-02-19 18:16:32 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:16:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:16:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:16:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 21:16:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:16:32 --> Final output sent to browser
DEBUG - 2016-02-19 21:16:32 --> Total execution time: 1.1688
INFO - 2016-02-19 18:16:33 --> Config Class Initialized
INFO - 2016-02-19 18:16:33 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:16:33 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:16:33 --> Utf8 Class Initialized
INFO - 2016-02-19 18:16:33 --> URI Class Initialized
INFO - 2016-02-19 18:16:33 --> Router Class Initialized
INFO - 2016-02-19 18:16:33 --> Output Class Initialized
INFO - 2016-02-19 18:16:33 --> Security Class Initialized
DEBUG - 2016-02-19 18:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:16:33 --> Input Class Initialized
INFO - 2016-02-19 18:16:33 --> Language Class Initialized
ERROR - 2016-02-19 18:16:33 --> 404 Page Not Found: Picture/write
INFO - 2016-02-19 18:17:40 --> Config Class Initialized
INFO - 2016-02-19 18:17:40 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:17:40 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:17:40 --> Utf8 Class Initialized
INFO - 2016-02-19 18:17:40 --> URI Class Initialized
INFO - 2016-02-19 18:17:40 --> Router Class Initialized
INFO - 2016-02-19 18:17:40 --> Output Class Initialized
INFO - 2016-02-19 18:17:40 --> Security Class Initialized
DEBUG - 2016-02-19 18:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:17:40 --> Input Class Initialized
INFO - 2016-02-19 18:17:40 --> Language Class Initialized
INFO - 2016-02-19 18:17:40 --> Loader Class Initialized
INFO - 2016-02-19 18:17:40 --> Helper loaded: url_helper
INFO - 2016-02-19 18:17:40 --> Helper loaded: file_helper
INFO - 2016-02-19 18:17:40 --> Helper loaded: date_helper
INFO - 2016-02-19 18:17:40 --> Helper loaded: form_helper
INFO - 2016-02-19 18:17:40 --> Database Driver Class Initialized
INFO - 2016-02-19 18:17:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:17:41 --> Controller Class Initialized
INFO - 2016-02-19 18:17:41 --> Model Class Initialized
INFO - 2016-02-19 18:17:41 --> Model Class Initialized
INFO - 2016-02-19 18:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:17:41 --> Pagination Class Initialized
INFO - 2016-02-19 18:17:41 --> Helper loaded: text_helper
INFO - 2016-02-19 18:17:41 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-19 21:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:17:41 --> Final output sent to browser
DEBUG - 2016-02-19 21:17:41 --> Total execution time: 1.1627
INFO - 2016-02-19 18:17:44 --> Config Class Initialized
INFO - 2016-02-19 18:17:44 --> Hooks Class Initialized
DEBUG - 2016-02-19 18:17:44 --> UTF-8 Support Enabled
INFO - 2016-02-19 18:17:44 --> Utf8 Class Initialized
INFO - 2016-02-19 18:17:44 --> URI Class Initialized
INFO - 2016-02-19 18:17:44 --> Router Class Initialized
INFO - 2016-02-19 18:17:44 --> Output Class Initialized
INFO - 2016-02-19 18:17:44 --> Security Class Initialized
DEBUG - 2016-02-19 18:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-19 18:17:44 --> Input Class Initialized
INFO - 2016-02-19 18:17:44 --> Language Class Initialized
INFO - 2016-02-19 18:17:44 --> Loader Class Initialized
INFO - 2016-02-19 18:17:44 --> Helper loaded: url_helper
INFO - 2016-02-19 18:17:44 --> Helper loaded: file_helper
INFO - 2016-02-19 18:17:44 --> Helper loaded: date_helper
INFO - 2016-02-19 18:17:44 --> Helper loaded: form_helper
INFO - 2016-02-19 18:17:44 --> Database Driver Class Initialized
INFO - 2016-02-19 18:17:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-19 18:17:45 --> Controller Class Initialized
INFO - 2016-02-19 18:17:45 --> Model Class Initialized
INFO - 2016-02-19 18:17:45 --> Model Class Initialized
INFO - 2016-02-19 18:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-19 18:17:45 --> Pagination Class Initialized
INFO - 2016-02-19 18:17:45 --> Helper loaded: text_helper
INFO - 2016-02-19 18:17:45 --> Helper loaded: cookie_helper
INFO - 2016-02-19 21:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-19 21:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-19 21:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-19 21:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-19 21:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-19 21:17:45 --> Final output sent to browser
DEBUG - 2016-02-19 21:17:45 --> Total execution time: 1.1836
