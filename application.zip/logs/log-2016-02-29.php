<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-29 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 00:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:10:23 --> Final output sent to browser
DEBUG - 2016-02-29 00:10:23 --> Total execution time: 1.1915
INFO - 2016-02-29 00:15:29 --> Form Validation Class Initialized
INFO - 2016-02-29 00:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-29 00:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-29 00:15:29 --> Final output sent to browser
DEBUG - 2016-02-29 00:15:29 --> Total execution time: 1.3309
INFO - 2016-02-29 00:20:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:20:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:20:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 00:20:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:20:57 --> Final output sent to browser
DEBUG - 2016-02-29 00:20:57 --> Total execution time: 1.2219
INFO - 2016-02-29 00:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 00:21:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:21:10 --> Final output sent to browser
DEBUG - 2016-02-29 00:21:10 --> Total execution time: 1.0946
INFO - 2016-02-29 00:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 00:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:21:16 --> Final output sent to browser
DEBUG - 2016-02-29 00:21:16 --> Total execution time: 1.1349
INFO - 2016-02-29 00:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 00:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:21:32 --> Final output sent to browser
DEBUG - 2016-02-29 00:21:32 --> Total execution time: 1.1665
INFO - 2016-02-29 00:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 00:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 00:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 00:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 00:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 00:21:35 --> Final output sent to browser
DEBUG - 2016-02-29 00:21:35 --> Total execution time: 1.2850
INFO - 2016-02-29 05:30:30 --> Config Class Initialized
INFO - 2016-02-29 05:30:30 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:30:30 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:30:30 --> Utf8 Class Initialized
INFO - 2016-02-29 05:30:30 --> URI Class Initialized
DEBUG - 2016-02-29 05:30:30 --> No URI present. Default controller set.
INFO - 2016-02-29 05:30:30 --> Router Class Initialized
INFO - 2016-02-29 05:30:30 --> Output Class Initialized
INFO - 2016-02-29 05:30:30 --> Security Class Initialized
DEBUG - 2016-02-29 05:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:30:30 --> Input Class Initialized
INFO - 2016-02-29 05:30:30 --> Language Class Initialized
INFO - 2016-02-29 05:30:30 --> Loader Class Initialized
INFO - 2016-02-29 05:30:30 --> Helper loaded: url_helper
INFO - 2016-02-29 05:30:30 --> Helper loaded: file_helper
INFO - 2016-02-29 05:30:30 --> Helper loaded: date_helper
INFO - 2016-02-29 05:30:30 --> Helper loaded: form_helper
INFO - 2016-02-29 05:30:30 --> Database Driver Class Initialized
INFO - 2016-02-29 05:30:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:30:31 --> Controller Class Initialized
INFO - 2016-02-29 05:30:31 --> Model Class Initialized
INFO - 2016-02-29 05:30:31 --> Model Class Initialized
INFO - 2016-02-29 05:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:30:31 --> Pagination Class Initialized
INFO - 2016-02-29 05:30:31 --> Helper loaded: text_helper
INFO - 2016-02-29 05:30:31 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:30:31 --> Final output sent to browser
DEBUG - 2016-02-29 08:30:31 --> Total execution time: 1.0968
INFO - 2016-02-29 05:30:36 --> Config Class Initialized
INFO - 2016-02-29 05:30:36 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:30:36 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:30:36 --> Utf8 Class Initialized
INFO - 2016-02-29 05:30:36 --> URI Class Initialized
INFO - 2016-02-29 05:30:36 --> Router Class Initialized
INFO - 2016-02-29 05:30:36 --> Output Class Initialized
INFO - 2016-02-29 05:30:36 --> Security Class Initialized
DEBUG - 2016-02-29 05:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:30:36 --> Input Class Initialized
INFO - 2016-02-29 05:30:36 --> Language Class Initialized
INFO - 2016-02-29 05:30:36 --> Loader Class Initialized
INFO - 2016-02-29 05:30:36 --> Helper loaded: url_helper
INFO - 2016-02-29 05:30:36 --> Helper loaded: file_helper
INFO - 2016-02-29 05:30:36 --> Helper loaded: date_helper
INFO - 2016-02-29 05:30:36 --> Helper loaded: form_helper
INFO - 2016-02-29 05:30:36 --> Database Driver Class Initialized
INFO - 2016-02-29 05:30:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:30:37 --> Controller Class Initialized
INFO - 2016-02-29 05:30:37 --> Model Class Initialized
INFO - 2016-02-29 05:30:37 --> Model Class Initialized
INFO - 2016-02-29 05:30:37 --> Form Validation Class Initialized
INFO - 2016-02-29 05:30:37 --> Helper loaded: text_helper
INFO - 2016-02-29 05:30:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 05:30:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-29 05:30:37 --> Final output sent to browser
DEBUG - 2016-02-29 05:30:37 --> Total execution time: 1.1223
INFO - 2016-02-29 05:30:39 --> Config Class Initialized
INFO - 2016-02-29 05:30:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:30:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:30:39 --> Utf8 Class Initialized
INFO - 2016-02-29 05:30:39 --> URI Class Initialized
DEBUG - 2016-02-29 05:30:39 --> No URI present. Default controller set.
INFO - 2016-02-29 05:30:39 --> Router Class Initialized
INFO - 2016-02-29 05:30:39 --> Output Class Initialized
INFO - 2016-02-29 05:30:39 --> Security Class Initialized
DEBUG - 2016-02-29 05:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:30:39 --> Input Class Initialized
INFO - 2016-02-29 05:30:39 --> Language Class Initialized
INFO - 2016-02-29 05:30:39 --> Loader Class Initialized
INFO - 2016-02-29 05:30:39 --> Helper loaded: url_helper
INFO - 2016-02-29 05:30:39 --> Helper loaded: file_helper
INFO - 2016-02-29 05:30:39 --> Helper loaded: date_helper
INFO - 2016-02-29 05:30:39 --> Helper loaded: form_helper
INFO - 2016-02-29 05:30:39 --> Database Driver Class Initialized
INFO - 2016-02-29 05:30:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:30:40 --> Controller Class Initialized
INFO - 2016-02-29 05:30:40 --> Model Class Initialized
INFO - 2016-02-29 05:30:40 --> Model Class Initialized
INFO - 2016-02-29 05:30:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:30:40 --> Pagination Class Initialized
INFO - 2016-02-29 05:30:40 --> Helper loaded: text_helper
INFO - 2016-02-29 05:30:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:30:40 --> Final output sent to browser
DEBUG - 2016-02-29 08:30:40 --> Total execution time: 1.1103
INFO - 2016-02-29 05:30:47 --> Config Class Initialized
INFO - 2016-02-29 05:30:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:30:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:30:47 --> Utf8 Class Initialized
INFO - 2016-02-29 05:30:47 --> URI Class Initialized
INFO - 2016-02-29 05:30:47 --> Router Class Initialized
INFO - 2016-02-29 05:30:47 --> Output Class Initialized
INFO - 2016-02-29 05:30:47 --> Security Class Initialized
DEBUG - 2016-02-29 05:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:30:47 --> Input Class Initialized
INFO - 2016-02-29 05:30:47 --> Language Class Initialized
INFO - 2016-02-29 05:30:47 --> Loader Class Initialized
INFO - 2016-02-29 05:30:47 --> Helper loaded: url_helper
INFO - 2016-02-29 05:30:47 --> Helper loaded: file_helper
INFO - 2016-02-29 05:30:47 --> Helper loaded: date_helper
INFO - 2016-02-29 05:30:47 --> Helper loaded: form_helper
INFO - 2016-02-29 05:30:47 --> Database Driver Class Initialized
INFO - 2016-02-29 05:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:30:48 --> Controller Class Initialized
INFO - 2016-02-29 05:30:48 --> Model Class Initialized
INFO - 2016-02-29 05:30:48 --> Model Class Initialized
INFO - 2016-02-29 05:30:48 --> Form Validation Class Initialized
INFO - 2016-02-29 05:30:48 --> Helper loaded: text_helper
INFO - 2016-02-29 05:30:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 05:30:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-29 05:30:48 --> Final output sent to browser
DEBUG - 2016-02-29 05:30:48 --> Total execution time: 1.1292
INFO - 2016-02-29 05:31:00 --> Config Class Initialized
INFO - 2016-02-29 05:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:31:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:31:00 --> Utf8 Class Initialized
INFO - 2016-02-29 05:31:00 --> URI Class Initialized
DEBUG - 2016-02-29 05:31:00 --> No URI present. Default controller set.
INFO - 2016-02-29 05:31:00 --> Router Class Initialized
INFO - 2016-02-29 05:31:00 --> Output Class Initialized
INFO - 2016-02-29 05:31:00 --> Security Class Initialized
DEBUG - 2016-02-29 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:31:00 --> Input Class Initialized
INFO - 2016-02-29 05:31:00 --> Language Class Initialized
INFO - 2016-02-29 05:31:00 --> Loader Class Initialized
INFO - 2016-02-29 05:31:00 --> Helper loaded: url_helper
INFO - 2016-02-29 05:31:00 --> Helper loaded: file_helper
INFO - 2016-02-29 05:31:00 --> Helper loaded: date_helper
INFO - 2016-02-29 05:31:00 --> Helper loaded: form_helper
INFO - 2016-02-29 05:31:00 --> Database Driver Class Initialized
INFO - 2016-02-29 05:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:31:01 --> Controller Class Initialized
INFO - 2016-02-29 05:31:01 --> Model Class Initialized
INFO - 2016-02-29 05:31:01 --> Model Class Initialized
INFO - 2016-02-29 05:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:31:01 --> Pagination Class Initialized
INFO - 2016-02-29 05:31:01 --> Helper loaded: text_helper
INFO - 2016-02-29 05:31:01 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:31:01 --> Final output sent to browser
DEBUG - 2016-02-29 08:31:01 --> Total execution time: 1.1108
INFO - 2016-02-29 05:32:21 --> Config Class Initialized
INFO - 2016-02-29 05:32:21 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:32:21 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:32:21 --> Utf8 Class Initialized
INFO - 2016-02-29 05:32:21 --> URI Class Initialized
INFO - 2016-02-29 05:32:21 --> Router Class Initialized
INFO - 2016-02-29 05:32:21 --> Output Class Initialized
INFO - 2016-02-29 05:32:21 --> Security Class Initialized
DEBUG - 2016-02-29 05:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:32:21 --> Input Class Initialized
INFO - 2016-02-29 05:32:21 --> Language Class Initialized
INFO - 2016-02-29 05:32:21 --> Loader Class Initialized
INFO - 2016-02-29 05:32:21 --> Helper loaded: url_helper
INFO - 2016-02-29 05:32:21 --> Helper loaded: file_helper
INFO - 2016-02-29 05:32:21 --> Helper loaded: date_helper
INFO - 2016-02-29 05:32:21 --> Helper loaded: form_helper
INFO - 2016-02-29 05:32:21 --> Database Driver Class Initialized
INFO - 2016-02-29 05:32:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:32:22 --> Controller Class Initialized
INFO - 2016-02-29 05:32:22 --> Model Class Initialized
INFO - 2016-02-29 05:32:22 --> Model Class Initialized
INFO - 2016-02-29 05:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:32:22 --> Pagination Class Initialized
INFO - 2016-02-29 05:32:22 --> Helper loaded: text_helper
INFO - 2016-02-29 05:32:22 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 08:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:32:22 --> Final output sent to browser
DEBUG - 2016-02-29 08:32:22 --> Total execution time: 1.1122
INFO - 2016-02-29 05:32:24 --> Config Class Initialized
INFO - 2016-02-29 05:32:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:32:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:32:24 --> Utf8 Class Initialized
INFO - 2016-02-29 05:32:24 --> URI Class Initialized
INFO - 2016-02-29 05:32:24 --> Router Class Initialized
INFO - 2016-02-29 05:32:24 --> Output Class Initialized
INFO - 2016-02-29 05:32:24 --> Security Class Initialized
DEBUG - 2016-02-29 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:32:24 --> Input Class Initialized
INFO - 2016-02-29 05:32:24 --> Language Class Initialized
INFO - 2016-02-29 05:32:24 --> Loader Class Initialized
INFO - 2016-02-29 05:32:24 --> Helper loaded: url_helper
INFO - 2016-02-29 05:32:24 --> Helper loaded: file_helper
INFO - 2016-02-29 05:32:24 --> Helper loaded: date_helper
INFO - 2016-02-29 05:32:24 --> Helper loaded: form_helper
INFO - 2016-02-29 05:32:24 --> Database Driver Class Initialized
INFO - 2016-02-29 05:32:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:32:25 --> Controller Class Initialized
INFO - 2016-02-29 05:32:25 --> Model Class Initialized
INFO - 2016-02-29 05:32:25 --> Model Class Initialized
INFO - 2016-02-29 05:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:32:25 --> Pagination Class Initialized
INFO - 2016-02-29 05:32:25 --> Helper loaded: text_helper
INFO - 2016-02-29 05:32:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 08:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 08:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:32:25 --> Final output sent to browser
DEBUG - 2016-02-29 08:32:25 --> Total execution time: 1.2282
INFO - 2016-02-29 05:32:33 --> Config Class Initialized
INFO - 2016-02-29 05:32:33 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:32:33 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:32:33 --> Utf8 Class Initialized
INFO - 2016-02-29 05:32:33 --> URI Class Initialized
DEBUG - 2016-02-29 05:32:33 --> No URI present. Default controller set.
INFO - 2016-02-29 05:32:33 --> Router Class Initialized
INFO - 2016-02-29 05:32:33 --> Output Class Initialized
INFO - 2016-02-29 05:32:33 --> Security Class Initialized
DEBUG - 2016-02-29 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:32:33 --> Input Class Initialized
INFO - 2016-02-29 05:32:33 --> Language Class Initialized
INFO - 2016-02-29 05:32:33 --> Loader Class Initialized
INFO - 2016-02-29 05:32:33 --> Helper loaded: url_helper
INFO - 2016-02-29 05:32:33 --> Helper loaded: file_helper
INFO - 2016-02-29 05:32:33 --> Helper loaded: date_helper
INFO - 2016-02-29 05:32:33 --> Helper loaded: form_helper
INFO - 2016-02-29 05:32:33 --> Database Driver Class Initialized
INFO - 2016-02-29 05:32:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:32:34 --> Controller Class Initialized
INFO - 2016-02-29 05:32:34 --> Model Class Initialized
INFO - 2016-02-29 05:32:34 --> Model Class Initialized
INFO - 2016-02-29 05:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:32:34 --> Pagination Class Initialized
INFO - 2016-02-29 05:32:34 --> Helper loaded: text_helper
INFO - 2016-02-29 05:32:34 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:32:34 --> Final output sent to browser
DEBUG - 2016-02-29 08:32:34 --> Total execution time: 1.1188
INFO - 2016-02-29 05:36:19 --> Config Class Initialized
INFO - 2016-02-29 05:36:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:36:19 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:36:19 --> Utf8 Class Initialized
INFO - 2016-02-29 05:36:19 --> URI Class Initialized
DEBUG - 2016-02-29 05:36:19 --> No URI present. Default controller set.
INFO - 2016-02-29 05:36:19 --> Router Class Initialized
INFO - 2016-02-29 05:36:19 --> Output Class Initialized
INFO - 2016-02-29 05:36:19 --> Security Class Initialized
DEBUG - 2016-02-29 05:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:36:19 --> Input Class Initialized
INFO - 2016-02-29 05:36:19 --> Language Class Initialized
INFO - 2016-02-29 05:36:19 --> Loader Class Initialized
INFO - 2016-02-29 05:36:19 --> Helper loaded: url_helper
INFO - 2016-02-29 05:36:19 --> Helper loaded: file_helper
INFO - 2016-02-29 05:36:19 --> Helper loaded: date_helper
INFO - 2016-02-29 05:36:19 --> Helper loaded: form_helper
INFO - 2016-02-29 05:36:19 --> Database Driver Class Initialized
INFO - 2016-02-29 05:36:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:36:20 --> Controller Class Initialized
INFO - 2016-02-29 05:36:20 --> Model Class Initialized
INFO - 2016-02-29 05:36:20 --> Model Class Initialized
INFO - 2016-02-29 05:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:36:20 --> Pagination Class Initialized
INFO - 2016-02-29 05:36:20 --> Helper loaded: text_helper
INFO - 2016-02-29 05:36:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:36:20 --> Final output sent to browser
DEBUG - 2016-02-29 08:36:20 --> Total execution time: 1.1680
INFO - 2016-02-29 05:36:23 --> Config Class Initialized
INFO - 2016-02-29 05:36:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:36:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:36:23 --> Utf8 Class Initialized
INFO - 2016-02-29 05:36:23 --> URI Class Initialized
INFO - 2016-02-29 05:36:23 --> Router Class Initialized
INFO - 2016-02-29 05:36:23 --> Output Class Initialized
INFO - 2016-02-29 05:36:23 --> Security Class Initialized
DEBUG - 2016-02-29 05:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:36:23 --> Input Class Initialized
INFO - 2016-02-29 05:36:23 --> Language Class Initialized
INFO - 2016-02-29 05:36:23 --> Loader Class Initialized
INFO - 2016-02-29 05:36:23 --> Helper loaded: url_helper
INFO - 2016-02-29 05:36:23 --> Helper loaded: file_helper
INFO - 2016-02-29 05:36:23 --> Helper loaded: date_helper
INFO - 2016-02-29 05:36:23 --> Helper loaded: form_helper
INFO - 2016-02-29 05:36:23 --> Database Driver Class Initialized
INFO - 2016-02-29 05:36:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:36:24 --> Controller Class Initialized
INFO - 2016-02-29 05:36:24 --> Model Class Initialized
INFO - 2016-02-29 05:36:24 --> Model Class Initialized
INFO - 2016-02-29 05:36:24 --> Form Validation Class Initialized
INFO - 2016-02-29 05:36:24 --> Helper loaded: text_helper
INFO - 2016-02-29 05:36:24 --> Final output sent to browser
DEBUG - 2016-02-29 05:36:24 --> Total execution time: 1.0979
INFO - 2016-02-29 05:37:04 --> Config Class Initialized
INFO - 2016-02-29 05:37:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:37:04 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:37:04 --> Utf8 Class Initialized
INFO - 2016-02-29 05:37:04 --> URI Class Initialized
DEBUG - 2016-02-29 05:37:04 --> No URI present. Default controller set.
INFO - 2016-02-29 05:37:04 --> Router Class Initialized
INFO - 2016-02-29 05:37:04 --> Output Class Initialized
INFO - 2016-02-29 05:37:04 --> Security Class Initialized
DEBUG - 2016-02-29 05:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:37:04 --> Input Class Initialized
INFO - 2016-02-29 05:37:04 --> Language Class Initialized
INFO - 2016-02-29 05:37:04 --> Loader Class Initialized
INFO - 2016-02-29 05:37:04 --> Helper loaded: url_helper
INFO - 2016-02-29 05:37:04 --> Helper loaded: file_helper
INFO - 2016-02-29 05:37:04 --> Helper loaded: date_helper
INFO - 2016-02-29 05:37:04 --> Helper loaded: form_helper
INFO - 2016-02-29 05:37:04 --> Database Driver Class Initialized
INFO - 2016-02-29 05:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:37:05 --> Controller Class Initialized
INFO - 2016-02-29 05:37:05 --> Model Class Initialized
INFO - 2016-02-29 05:37:05 --> Model Class Initialized
INFO - 2016-02-29 05:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:37:05 --> Pagination Class Initialized
INFO - 2016-02-29 05:37:05 --> Helper loaded: text_helper
INFO - 2016-02-29 05:37:05 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:37:05 --> Final output sent to browser
DEBUG - 2016-02-29 08:37:05 --> Total execution time: 1.1465
INFO - 2016-02-29 05:37:08 --> Config Class Initialized
INFO - 2016-02-29 05:37:08 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:37:08 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:37:08 --> Utf8 Class Initialized
INFO - 2016-02-29 05:37:08 --> URI Class Initialized
INFO - 2016-02-29 05:37:08 --> Router Class Initialized
INFO - 2016-02-29 05:37:09 --> Output Class Initialized
INFO - 2016-02-29 05:37:09 --> Security Class Initialized
DEBUG - 2016-02-29 05:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:37:09 --> Input Class Initialized
INFO - 2016-02-29 05:37:09 --> Language Class Initialized
INFO - 2016-02-29 05:37:09 --> Loader Class Initialized
INFO - 2016-02-29 05:37:09 --> Helper loaded: url_helper
INFO - 2016-02-29 05:37:09 --> Helper loaded: file_helper
INFO - 2016-02-29 05:37:09 --> Helper loaded: date_helper
INFO - 2016-02-29 05:37:09 --> Helper loaded: form_helper
INFO - 2016-02-29 05:37:09 --> Database Driver Class Initialized
INFO - 2016-02-29 05:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:37:10 --> Controller Class Initialized
INFO - 2016-02-29 05:37:10 --> Model Class Initialized
INFO - 2016-02-29 05:37:10 --> Model Class Initialized
INFO - 2016-02-29 05:37:10 --> Form Validation Class Initialized
INFO - 2016-02-29 05:37:10 --> Helper loaded: text_helper
INFO - 2016-02-29 05:37:10 --> Final output sent to browser
DEBUG - 2016-02-29 05:37:10 --> Total execution time: 1.4151
INFO - 2016-02-29 05:37:24 --> Config Class Initialized
INFO - 2016-02-29 05:37:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:37:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:37:24 --> Utf8 Class Initialized
INFO - 2016-02-29 05:37:24 --> URI Class Initialized
DEBUG - 2016-02-29 05:37:24 --> No URI present. Default controller set.
INFO - 2016-02-29 05:37:24 --> Router Class Initialized
INFO - 2016-02-29 05:37:24 --> Output Class Initialized
INFO - 2016-02-29 05:37:24 --> Security Class Initialized
DEBUG - 2016-02-29 05:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:37:24 --> Input Class Initialized
INFO - 2016-02-29 05:37:24 --> Language Class Initialized
INFO - 2016-02-29 05:37:24 --> Loader Class Initialized
INFO - 2016-02-29 05:37:24 --> Helper loaded: url_helper
INFO - 2016-02-29 05:37:24 --> Helper loaded: file_helper
INFO - 2016-02-29 05:37:24 --> Helper loaded: date_helper
INFO - 2016-02-29 05:37:24 --> Helper loaded: form_helper
INFO - 2016-02-29 05:37:24 --> Database Driver Class Initialized
INFO - 2016-02-29 05:37:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:37:25 --> Controller Class Initialized
INFO - 2016-02-29 05:37:25 --> Model Class Initialized
INFO - 2016-02-29 05:37:25 --> Model Class Initialized
INFO - 2016-02-29 05:37:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:37:25 --> Pagination Class Initialized
INFO - 2016-02-29 05:37:25 --> Helper loaded: text_helper
INFO - 2016-02-29 05:37:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:37:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:37:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:37:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:37:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:37:25 --> Final output sent to browser
DEBUG - 2016-02-29 08:37:25 --> Total execution time: 1.1541
INFO - 2016-02-29 05:37:27 --> Config Class Initialized
INFO - 2016-02-29 05:37:27 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:37:27 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:37:27 --> Utf8 Class Initialized
INFO - 2016-02-29 05:37:27 --> URI Class Initialized
INFO - 2016-02-29 05:37:27 --> Router Class Initialized
INFO - 2016-02-29 05:37:27 --> Output Class Initialized
INFO - 2016-02-29 05:37:27 --> Security Class Initialized
DEBUG - 2016-02-29 05:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:37:27 --> Input Class Initialized
INFO - 2016-02-29 05:37:27 --> Language Class Initialized
INFO - 2016-02-29 05:37:27 --> Loader Class Initialized
INFO - 2016-02-29 05:37:27 --> Helper loaded: url_helper
INFO - 2016-02-29 05:37:27 --> Helper loaded: file_helper
INFO - 2016-02-29 05:37:27 --> Helper loaded: date_helper
INFO - 2016-02-29 05:37:27 --> Helper loaded: form_helper
INFO - 2016-02-29 05:37:27 --> Database Driver Class Initialized
INFO - 2016-02-29 05:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:37:28 --> Controller Class Initialized
INFO - 2016-02-29 05:37:28 --> Model Class Initialized
INFO - 2016-02-29 05:37:28 --> Model Class Initialized
INFO - 2016-02-29 05:37:28 --> Form Validation Class Initialized
INFO - 2016-02-29 05:37:28 --> Helper loaded: text_helper
INFO - 2016-02-29 05:37:28 --> Final output sent to browser
DEBUG - 2016-02-29 05:37:28 --> Total execution time: 1.1115
INFO - 2016-02-29 05:38:08 --> Config Class Initialized
INFO - 2016-02-29 05:38:08 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:38:08 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:38:08 --> Utf8 Class Initialized
INFO - 2016-02-29 05:38:08 --> URI Class Initialized
DEBUG - 2016-02-29 05:38:08 --> No URI present. Default controller set.
INFO - 2016-02-29 05:38:08 --> Router Class Initialized
INFO - 2016-02-29 05:38:08 --> Output Class Initialized
INFO - 2016-02-29 05:38:08 --> Security Class Initialized
DEBUG - 2016-02-29 05:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:38:08 --> Input Class Initialized
INFO - 2016-02-29 05:38:08 --> Language Class Initialized
INFO - 2016-02-29 05:38:08 --> Loader Class Initialized
INFO - 2016-02-29 05:38:08 --> Helper loaded: url_helper
INFO - 2016-02-29 05:38:08 --> Helper loaded: file_helper
INFO - 2016-02-29 05:38:08 --> Helper loaded: date_helper
INFO - 2016-02-29 05:38:08 --> Helper loaded: form_helper
INFO - 2016-02-29 05:38:08 --> Database Driver Class Initialized
INFO - 2016-02-29 05:38:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:38:09 --> Controller Class Initialized
INFO - 2016-02-29 05:38:09 --> Model Class Initialized
INFO - 2016-02-29 05:38:09 --> Model Class Initialized
INFO - 2016-02-29 05:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:38:09 --> Pagination Class Initialized
INFO - 2016-02-29 05:38:09 --> Helper loaded: text_helper
INFO - 2016-02-29 05:38:09 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:38:09 --> Final output sent to browser
DEBUG - 2016-02-29 08:38:09 --> Total execution time: 1.1642
INFO - 2016-02-29 05:38:12 --> Config Class Initialized
INFO - 2016-02-29 05:38:12 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:38:12 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:38:12 --> Utf8 Class Initialized
INFO - 2016-02-29 05:38:12 --> URI Class Initialized
INFO - 2016-02-29 05:38:12 --> Router Class Initialized
INFO - 2016-02-29 05:38:12 --> Output Class Initialized
INFO - 2016-02-29 05:38:12 --> Security Class Initialized
DEBUG - 2016-02-29 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:38:12 --> Input Class Initialized
INFO - 2016-02-29 05:38:12 --> Language Class Initialized
INFO - 2016-02-29 05:38:12 --> Loader Class Initialized
INFO - 2016-02-29 05:38:12 --> Helper loaded: url_helper
INFO - 2016-02-29 05:38:12 --> Helper loaded: file_helper
INFO - 2016-02-29 05:38:12 --> Helper loaded: date_helper
INFO - 2016-02-29 05:38:12 --> Helper loaded: form_helper
INFO - 2016-02-29 05:38:12 --> Database Driver Class Initialized
INFO - 2016-02-29 05:38:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:38:13 --> Controller Class Initialized
INFO - 2016-02-29 05:38:13 --> Model Class Initialized
INFO - 2016-02-29 05:38:13 --> Model Class Initialized
INFO - 2016-02-29 05:38:13 --> Form Validation Class Initialized
INFO - 2016-02-29 05:38:13 --> Helper loaded: text_helper
INFO - 2016-02-29 05:38:13 --> Final output sent to browser
DEBUG - 2016-02-29 05:38:13 --> Total execution time: 1.1031
INFO - 2016-02-29 05:38:36 --> Config Class Initialized
INFO - 2016-02-29 05:38:36 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:38:36 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:38:36 --> Utf8 Class Initialized
INFO - 2016-02-29 05:38:36 --> URI Class Initialized
DEBUG - 2016-02-29 05:38:36 --> No URI present. Default controller set.
INFO - 2016-02-29 05:38:36 --> Router Class Initialized
INFO - 2016-02-29 05:38:36 --> Output Class Initialized
INFO - 2016-02-29 05:38:36 --> Security Class Initialized
DEBUG - 2016-02-29 05:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:38:36 --> Input Class Initialized
INFO - 2016-02-29 05:38:36 --> Language Class Initialized
INFO - 2016-02-29 05:38:36 --> Loader Class Initialized
INFO - 2016-02-29 05:38:36 --> Helper loaded: url_helper
INFO - 2016-02-29 05:38:36 --> Helper loaded: file_helper
INFO - 2016-02-29 05:38:36 --> Helper loaded: date_helper
INFO - 2016-02-29 05:38:36 --> Helper loaded: form_helper
INFO - 2016-02-29 05:38:36 --> Database Driver Class Initialized
INFO - 2016-02-29 05:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:38:37 --> Controller Class Initialized
INFO - 2016-02-29 05:38:37 --> Model Class Initialized
INFO - 2016-02-29 05:38:37 --> Model Class Initialized
INFO - 2016-02-29 05:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:38:37 --> Pagination Class Initialized
INFO - 2016-02-29 05:38:37 --> Helper loaded: text_helper
INFO - 2016-02-29 05:38:37 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 08:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:38:37 --> Final output sent to browser
DEBUG - 2016-02-29 08:38:37 --> Total execution time: 1.1461
INFO - 2016-02-29 05:38:45 --> Config Class Initialized
INFO - 2016-02-29 05:38:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:38:45 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:38:45 --> Utf8 Class Initialized
INFO - 2016-02-29 05:38:45 --> URI Class Initialized
INFO - 2016-02-29 05:38:45 --> Router Class Initialized
INFO - 2016-02-29 05:38:45 --> Output Class Initialized
INFO - 2016-02-29 05:38:45 --> Security Class Initialized
DEBUG - 2016-02-29 05:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:38:45 --> Input Class Initialized
INFO - 2016-02-29 05:38:45 --> Language Class Initialized
INFO - 2016-02-29 05:38:45 --> Loader Class Initialized
INFO - 2016-02-29 05:38:45 --> Helper loaded: url_helper
INFO - 2016-02-29 05:38:45 --> Helper loaded: file_helper
INFO - 2016-02-29 05:38:45 --> Helper loaded: date_helper
INFO - 2016-02-29 05:38:45 --> Helper loaded: form_helper
INFO - 2016-02-29 05:38:45 --> Database Driver Class Initialized
INFO - 2016-02-29 05:38:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:38:46 --> Controller Class Initialized
INFO - 2016-02-29 05:38:46 --> Model Class Initialized
INFO - 2016-02-29 05:38:46 --> Model Class Initialized
INFO - 2016-02-29 05:38:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:38:46 --> Pagination Class Initialized
INFO - 2016-02-29 05:38:46 --> Helper loaded: text_helper
INFO - 2016-02-29 05:38:46 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:38:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:38:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:38:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 08:38:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-29 08:38:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:38:46 --> Final output sent to browser
DEBUG - 2016-02-29 08:38:46 --> Total execution time: 1.1745
INFO - 2016-02-29 05:38:50 --> Config Class Initialized
INFO - 2016-02-29 05:38:50 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:38:50 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:38:50 --> Utf8 Class Initialized
INFO - 2016-02-29 05:38:50 --> URI Class Initialized
INFO - 2016-02-29 05:38:50 --> Router Class Initialized
INFO - 2016-02-29 05:38:50 --> Output Class Initialized
INFO - 2016-02-29 05:38:50 --> Security Class Initialized
DEBUG - 2016-02-29 05:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:38:50 --> Input Class Initialized
INFO - 2016-02-29 05:38:50 --> Language Class Initialized
INFO - 2016-02-29 05:38:50 --> Loader Class Initialized
INFO - 2016-02-29 05:38:50 --> Helper loaded: url_helper
INFO - 2016-02-29 05:38:50 --> Helper loaded: file_helper
INFO - 2016-02-29 05:38:50 --> Helper loaded: date_helper
INFO - 2016-02-29 05:38:50 --> Helper loaded: form_helper
INFO - 2016-02-29 05:38:50 --> Database Driver Class Initialized
INFO - 2016-02-29 05:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:38:51 --> Controller Class Initialized
INFO - 2016-02-29 05:38:51 --> Model Class Initialized
INFO - 2016-02-29 05:38:51 --> Model Class Initialized
INFO - 2016-02-29 05:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:38:51 --> Pagination Class Initialized
INFO - 2016-02-29 05:38:51 --> Helper loaded: text_helper
INFO - 2016-02-29 05:38:51 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 08:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 08:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:38:51 --> Final output sent to browser
DEBUG - 2016-02-29 08:38:51 --> Total execution time: 1.1941
INFO - 2016-02-29 05:39:01 --> Config Class Initialized
INFO - 2016-02-29 05:39:01 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:39:01 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:39:01 --> Utf8 Class Initialized
INFO - 2016-02-29 05:39:01 --> URI Class Initialized
INFO - 2016-02-29 05:39:01 --> Router Class Initialized
INFO - 2016-02-29 05:39:01 --> Output Class Initialized
INFO - 2016-02-29 05:39:01 --> Security Class Initialized
DEBUG - 2016-02-29 05:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:39:01 --> Input Class Initialized
INFO - 2016-02-29 05:39:01 --> Language Class Initialized
INFO - 2016-02-29 05:39:01 --> Loader Class Initialized
INFO - 2016-02-29 05:39:01 --> Helper loaded: url_helper
INFO - 2016-02-29 05:39:01 --> Helper loaded: file_helper
INFO - 2016-02-29 05:39:01 --> Helper loaded: date_helper
INFO - 2016-02-29 05:39:01 --> Helper loaded: form_helper
INFO - 2016-02-29 05:39:01 --> Database Driver Class Initialized
INFO - 2016-02-29 05:39:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:39:02 --> Controller Class Initialized
INFO - 2016-02-29 05:39:02 --> Model Class Initialized
INFO - 2016-02-29 05:39:02 --> Model Class Initialized
INFO - 2016-02-29 05:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:39:02 --> Pagination Class Initialized
INFO - 2016-02-29 05:39:02 --> Helper loaded: text_helper
INFO - 2016-02-29 05:39:02 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 08:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:39:02 --> Final output sent to browser
DEBUG - 2016-02-29 08:39:02 --> Total execution time: 1.1759
INFO - 2016-02-29 05:39:04 --> Config Class Initialized
INFO - 2016-02-29 05:39:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 05:39:04 --> UTF-8 Support Enabled
INFO - 2016-02-29 05:39:04 --> Utf8 Class Initialized
INFO - 2016-02-29 05:39:04 --> URI Class Initialized
INFO - 2016-02-29 05:39:04 --> Router Class Initialized
INFO - 2016-02-29 05:39:04 --> Output Class Initialized
INFO - 2016-02-29 05:39:04 --> Security Class Initialized
DEBUG - 2016-02-29 05:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 05:39:04 --> Input Class Initialized
INFO - 2016-02-29 05:39:04 --> Language Class Initialized
INFO - 2016-02-29 05:39:04 --> Loader Class Initialized
INFO - 2016-02-29 05:39:04 --> Helper loaded: url_helper
INFO - 2016-02-29 05:39:04 --> Helper loaded: file_helper
INFO - 2016-02-29 05:39:04 --> Helper loaded: date_helper
INFO - 2016-02-29 05:39:04 --> Helper loaded: form_helper
INFO - 2016-02-29 05:39:04 --> Database Driver Class Initialized
INFO - 2016-02-29 05:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 05:39:05 --> Controller Class Initialized
INFO - 2016-02-29 05:39:05 --> Model Class Initialized
INFO - 2016-02-29 05:39:05 --> Model Class Initialized
INFO - 2016-02-29 05:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 05:39:05 --> Pagination Class Initialized
INFO - 2016-02-29 05:39:05 --> Helper loaded: text_helper
INFO - 2016-02-29 05:39:05 --> Helper loaded: cookie_helper
INFO - 2016-02-29 08:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 08:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 08:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 08:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 08:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 08:39:05 --> Final output sent to browser
DEBUG - 2016-02-29 08:39:05 --> Total execution time: 1.2073
INFO - 2016-02-29 06:07:39 --> Config Class Initialized
INFO - 2016-02-29 06:07:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:07:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:07:39 --> Utf8 Class Initialized
INFO - 2016-02-29 06:07:39 --> URI Class Initialized
DEBUG - 2016-02-29 06:07:39 --> No URI present. Default controller set.
INFO - 2016-02-29 06:07:39 --> Router Class Initialized
INFO - 2016-02-29 06:07:39 --> Output Class Initialized
INFO - 2016-02-29 06:07:39 --> Security Class Initialized
DEBUG - 2016-02-29 06:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:07:39 --> Input Class Initialized
INFO - 2016-02-29 06:07:39 --> Language Class Initialized
INFO - 2016-02-29 06:07:39 --> Loader Class Initialized
INFO - 2016-02-29 06:07:39 --> Helper loaded: url_helper
INFO - 2016-02-29 06:07:39 --> Helper loaded: file_helper
INFO - 2016-02-29 06:07:39 --> Helper loaded: date_helper
INFO - 2016-02-29 06:07:39 --> Helper loaded: form_helper
INFO - 2016-02-29 06:07:39 --> Database Driver Class Initialized
INFO - 2016-02-29 06:07:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:07:40 --> Controller Class Initialized
INFO - 2016-02-29 06:07:40 --> Model Class Initialized
INFO - 2016-02-29 06:07:40 --> Model Class Initialized
INFO - 2016-02-29 06:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:07:40 --> Pagination Class Initialized
INFO - 2016-02-29 06:07:40 --> Helper loaded: text_helper
INFO - 2016-02-29 06:07:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:07:40 --> Final output sent to browser
DEBUG - 2016-02-29 09:07:40 --> Total execution time: 1.1548
INFO - 2016-02-29 06:07:43 --> Config Class Initialized
INFO - 2016-02-29 06:07:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:07:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:07:43 --> Utf8 Class Initialized
INFO - 2016-02-29 06:07:43 --> URI Class Initialized
INFO - 2016-02-29 06:07:43 --> Router Class Initialized
INFO - 2016-02-29 06:07:43 --> Output Class Initialized
INFO - 2016-02-29 06:07:43 --> Security Class Initialized
DEBUG - 2016-02-29 06:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:07:43 --> Input Class Initialized
INFO - 2016-02-29 06:07:43 --> Language Class Initialized
INFO - 2016-02-29 06:07:43 --> Loader Class Initialized
INFO - 2016-02-29 06:07:43 --> Helper loaded: url_helper
INFO - 2016-02-29 06:07:43 --> Helper loaded: file_helper
INFO - 2016-02-29 06:07:43 --> Helper loaded: date_helper
INFO - 2016-02-29 06:07:43 --> Helper loaded: form_helper
INFO - 2016-02-29 06:07:43 --> Database Driver Class Initialized
INFO - 2016-02-29 06:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:07:44 --> Controller Class Initialized
INFO - 2016-02-29 06:07:44 --> Model Class Initialized
INFO - 2016-02-29 06:07:44 --> Model Class Initialized
INFO - 2016-02-29 06:07:44 --> Form Validation Class Initialized
INFO - 2016-02-29 06:07:44 --> Helper loaded: text_helper
INFO - 2016-02-29 06:07:44 --> Final output sent to browser
DEBUG - 2016-02-29 06:07:44 --> Total execution time: 1.1357
INFO - 2016-02-29 06:09:31 --> Config Class Initialized
INFO - 2016-02-29 06:09:31 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:09:31 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:09:31 --> Utf8 Class Initialized
INFO - 2016-02-29 06:09:31 --> URI Class Initialized
DEBUG - 2016-02-29 06:09:31 --> No URI present. Default controller set.
INFO - 2016-02-29 06:09:31 --> Router Class Initialized
INFO - 2016-02-29 06:09:31 --> Output Class Initialized
INFO - 2016-02-29 06:09:31 --> Security Class Initialized
DEBUG - 2016-02-29 06:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:09:31 --> Input Class Initialized
INFO - 2016-02-29 06:09:31 --> Language Class Initialized
INFO - 2016-02-29 06:09:31 --> Loader Class Initialized
INFO - 2016-02-29 06:09:31 --> Helper loaded: url_helper
INFO - 2016-02-29 06:09:31 --> Helper loaded: file_helper
INFO - 2016-02-29 06:09:31 --> Helper loaded: date_helper
INFO - 2016-02-29 06:09:31 --> Helper loaded: form_helper
INFO - 2016-02-29 06:09:31 --> Database Driver Class Initialized
INFO - 2016-02-29 06:09:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:09:32 --> Controller Class Initialized
INFO - 2016-02-29 06:09:32 --> Model Class Initialized
INFO - 2016-02-29 06:09:32 --> Model Class Initialized
INFO - 2016-02-29 06:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:09:32 --> Pagination Class Initialized
INFO - 2016-02-29 06:09:32 --> Helper loaded: text_helper
INFO - 2016-02-29 06:09:32 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:09:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:09:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:09:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:09:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:09:32 --> Final output sent to browser
DEBUG - 2016-02-29 09:09:32 --> Total execution time: 1.1779
INFO - 2016-02-29 06:09:34 --> Config Class Initialized
INFO - 2016-02-29 06:09:34 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:09:34 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:09:34 --> Utf8 Class Initialized
INFO - 2016-02-29 06:09:34 --> URI Class Initialized
INFO - 2016-02-29 06:09:34 --> Router Class Initialized
INFO - 2016-02-29 06:09:34 --> Output Class Initialized
INFO - 2016-02-29 06:09:34 --> Security Class Initialized
DEBUG - 2016-02-29 06:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:09:34 --> Input Class Initialized
INFO - 2016-02-29 06:09:34 --> Language Class Initialized
INFO - 2016-02-29 06:09:34 --> Loader Class Initialized
INFO - 2016-02-29 06:09:34 --> Helper loaded: url_helper
INFO - 2016-02-29 06:09:34 --> Helper loaded: file_helper
INFO - 2016-02-29 06:09:34 --> Helper loaded: date_helper
INFO - 2016-02-29 06:09:34 --> Helper loaded: form_helper
INFO - 2016-02-29 06:09:34 --> Database Driver Class Initialized
INFO - 2016-02-29 06:09:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:09:35 --> Controller Class Initialized
INFO - 2016-02-29 06:09:35 --> Model Class Initialized
INFO - 2016-02-29 06:09:35 --> Model Class Initialized
INFO - 2016-02-29 06:09:35 --> Form Validation Class Initialized
INFO - 2016-02-29 06:09:35 --> Helper loaded: text_helper
INFO - 2016-02-29 06:09:35 --> Final output sent to browser
DEBUG - 2016-02-29 06:09:35 --> Total execution time: 1.1248
INFO - 2016-02-29 06:11:24 --> Config Class Initialized
INFO - 2016-02-29 06:11:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:11:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:11:24 --> Utf8 Class Initialized
INFO - 2016-02-29 06:11:24 --> URI Class Initialized
DEBUG - 2016-02-29 06:11:24 --> No URI present. Default controller set.
INFO - 2016-02-29 06:11:24 --> Router Class Initialized
INFO - 2016-02-29 06:11:24 --> Output Class Initialized
INFO - 2016-02-29 06:11:24 --> Security Class Initialized
DEBUG - 2016-02-29 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:11:24 --> Input Class Initialized
INFO - 2016-02-29 06:11:24 --> Language Class Initialized
INFO - 2016-02-29 06:11:24 --> Loader Class Initialized
INFO - 2016-02-29 06:11:24 --> Helper loaded: url_helper
INFO - 2016-02-29 06:11:24 --> Helper loaded: file_helper
INFO - 2016-02-29 06:11:24 --> Helper loaded: date_helper
INFO - 2016-02-29 06:11:24 --> Helper loaded: form_helper
INFO - 2016-02-29 06:11:24 --> Database Driver Class Initialized
INFO - 2016-02-29 06:11:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:11:25 --> Controller Class Initialized
INFO - 2016-02-29 06:11:25 --> Model Class Initialized
INFO - 2016-02-29 06:11:25 --> Model Class Initialized
INFO - 2016-02-29 06:11:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:11:25 --> Pagination Class Initialized
INFO - 2016-02-29 06:11:25 --> Helper loaded: text_helper
INFO - 2016-02-29 06:11:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:11:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:11:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:11:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:11:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:11:25 --> Final output sent to browser
DEBUG - 2016-02-29 09:11:25 --> Total execution time: 1.1879
INFO - 2016-02-29 06:11:26 --> Config Class Initialized
INFO - 2016-02-29 06:11:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:11:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:11:26 --> Utf8 Class Initialized
INFO - 2016-02-29 06:11:26 --> URI Class Initialized
INFO - 2016-02-29 06:11:26 --> Router Class Initialized
INFO - 2016-02-29 06:11:26 --> Output Class Initialized
INFO - 2016-02-29 06:11:26 --> Security Class Initialized
DEBUG - 2016-02-29 06:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:11:26 --> Input Class Initialized
INFO - 2016-02-29 06:11:26 --> Language Class Initialized
INFO - 2016-02-29 06:11:26 --> Loader Class Initialized
INFO - 2016-02-29 06:11:26 --> Helper loaded: url_helper
INFO - 2016-02-29 06:11:26 --> Helper loaded: file_helper
INFO - 2016-02-29 06:11:26 --> Helper loaded: date_helper
INFO - 2016-02-29 06:11:26 --> Helper loaded: form_helper
INFO - 2016-02-29 06:11:26 --> Database Driver Class Initialized
INFO - 2016-02-29 06:11:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:11:27 --> Controller Class Initialized
INFO - 2016-02-29 06:11:27 --> Model Class Initialized
INFO - 2016-02-29 06:11:27 --> Model Class Initialized
INFO - 2016-02-29 06:11:27 --> Form Validation Class Initialized
INFO - 2016-02-29 06:11:27 --> Helper loaded: text_helper
INFO - 2016-02-29 06:11:27 --> Final output sent to browser
DEBUG - 2016-02-29 06:11:27 --> Total execution time: 1.0988
INFO - 2016-02-29 06:13:12 --> Config Class Initialized
INFO - 2016-02-29 06:13:12 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:13:12 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:13:12 --> Utf8 Class Initialized
INFO - 2016-02-29 06:13:12 --> URI Class Initialized
DEBUG - 2016-02-29 06:13:12 --> No URI present. Default controller set.
INFO - 2016-02-29 06:13:12 --> Router Class Initialized
INFO - 2016-02-29 06:13:12 --> Output Class Initialized
INFO - 2016-02-29 06:13:12 --> Security Class Initialized
DEBUG - 2016-02-29 06:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:13:12 --> Input Class Initialized
INFO - 2016-02-29 06:13:12 --> Language Class Initialized
INFO - 2016-02-29 06:13:12 --> Loader Class Initialized
INFO - 2016-02-29 06:13:12 --> Helper loaded: url_helper
INFO - 2016-02-29 06:13:12 --> Helper loaded: file_helper
INFO - 2016-02-29 06:13:12 --> Helper loaded: date_helper
INFO - 2016-02-29 06:13:12 --> Helper loaded: form_helper
INFO - 2016-02-29 06:13:12 --> Database Driver Class Initialized
INFO - 2016-02-29 06:13:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:13:13 --> Controller Class Initialized
INFO - 2016-02-29 06:13:13 --> Model Class Initialized
INFO - 2016-02-29 06:13:13 --> Model Class Initialized
INFO - 2016-02-29 06:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:13:13 --> Pagination Class Initialized
INFO - 2016-02-29 06:13:13 --> Helper loaded: text_helper
INFO - 2016-02-29 06:13:13 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:13:13 --> Final output sent to browser
DEBUG - 2016-02-29 09:13:13 --> Total execution time: 1.1624
INFO - 2016-02-29 06:13:16 --> Config Class Initialized
INFO - 2016-02-29 06:13:16 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:13:16 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:13:16 --> Utf8 Class Initialized
INFO - 2016-02-29 06:13:16 --> URI Class Initialized
INFO - 2016-02-29 06:13:16 --> Router Class Initialized
INFO - 2016-02-29 06:13:16 --> Output Class Initialized
INFO - 2016-02-29 06:13:16 --> Security Class Initialized
DEBUG - 2016-02-29 06:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:13:16 --> Input Class Initialized
INFO - 2016-02-29 06:13:16 --> Language Class Initialized
INFO - 2016-02-29 06:13:16 --> Loader Class Initialized
INFO - 2016-02-29 06:13:16 --> Helper loaded: url_helper
INFO - 2016-02-29 06:13:16 --> Helper loaded: file_helper
INFO - 2016-02-29 06:13:16 --> Helper loaded: date_helper
INFO - 2016-02-29 06:13:16 --> Helper loaded: form_helper
INFO - 2016-02-29 06:13:16 --> Database Driver Class Initialized
INFO - 2016-02-29 06:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:13:17 --> Controller Class Initialized
INFO - 2016-02-29 06:13:17 --> Model Class Initialized
INFO - 2016-02-29 06:13:17 --> Model Class Initialized
INFO - 2016-02-29 06:13:17 --> Form Validation Class Initialized
INFO - 2016-02-29 06:13:17 --> Helper loaded: text_helper
INFO - 2016-02-29 06:13:17 --> Final output sent to browser
DEBUG - 2016-02-29 06:13:17 --> Total execution time: 1.1022
INFO - 2016-02-29 06:14:38 --> Config Class Initialized
INFO - 2016-02-29 06:14:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:14:38 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:14:38 --> Utf8 Class Initialized
INFO - 2016-02-29 06:14:38 --> URI Class Initialized
DEBUG - 2016-02-29 06:14:38 --> No URI present. Default controller set.
INFO - 2016-02-29 06:14:38 --> Router Class Initialized
INFO - 2016-02-29 06:14:38 --> Output Class Initialized
INFO - 2016-02-29 06:14:38 --> Security Class Initialized
DEBUG - 2016-02-29 06:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:14:38 --> Input Class Initialized
INFO - 2016-02-29 06:14:38 --> Language Class Initialized
INFO - 2016-02-29 06:14:38 --> Loader Class Initialized
INFO - 2016-02-29 06:14:38 --> Helper loaded: url_helper
INFO - 2016-02-29 06:14:38 --> Helper loaded: file_helper
INFO - 2016-02-29 06:14:38 --> Helper loaded: date_helper
INFO - 2016-02-29 06:14:38 --> Helper loaded: form_helper
INFO - 2016-02-29 06:14:38 --> Database Driver Class Initialized
INFO - 2016-02-29 06:14:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:14:40 --> Controller Class Initialized
INFO - 2016-02-29 06:14:40 --> Model Class Initialized
INFO - 2016-02-29 06:14:40 --> Model Class Initialized
INFO - 2016-02-29 06:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:14:40 --> Pagination Class Initialized
INFO - 2016-02-29 06:14:40 --> Helper loaded: text_helper
INFO - 2016-02-29 06:14:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:14:40 --> Final output sent to browser
DEBUG - 2016-02-29 09:14:40 --> Total execution time: 1.1497
INFO - 2016-02-29 06:14:42 --> Config Class Initialized
INFO - 2016-02-29 06:14:42 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:14:42 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:14:42 --> Utf8 Class Initialized
INFO - 2016-02-29 06:14:42 --> URI Class Initialized
INFO - 2016-02-29 06:14:42 --> Router Class Initialized
INFO - 2016-02-29 06:14:42 --> Output Class Initialized
INFO - 2016-02-29 06:14:42 --> Security Class Initialized
DEBUG - 2016-02-29 06:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:14:42 --> Input Class Initialized
INFO - 2016-02-29 06:14:42 --> Language Class Initialized
INFO - 2016-02-29 06:14:42 --> Loader Class Initialized
INFO - 2016-02-29 06:14:42 --> Helper loaded: url_helper
INFO - 2016-02-29 06:14:42 --> Helper loaded: file_helper
INFO - 2016-02-29 06:14:42 --> Helper loaded: date_helper
INFO - 2016-02-29 06:14:42 --> Helper loaded: form_helper
INFO - 2016-02-29 06:14:42 --> Database Driver Class Initialized
INFO - 2016-02-29 06:14:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:14:43 --> Controller Class Initialized
INFO - 2016-02-29 06:14:43 --> Model Class Initialized
INFO - 2016-02-29 06:14:43 --> Model Class Initialized
INFO - 2016-02-29 06:14:43 --> Form Validation Class Initialized
INFO - 2016-02-29 06:14:43 --> Helper loaded: text_helper
INFO - 2016-02-29 06:14:43 --> Final output sent to browser
DEBUG - 2016-02-29 06:14:43 --> Total execution time: 1.0879
INFO - 2016-02-29 06:15:37 --> Config Class Initialized
INFO - 2016-02-29 06:15:37 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:15:37 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:15:37 --> Utf8 Class Initialized
INFO - 2016-02-29 06:15:37 --> URI Class Initialized
DEBUG - 2016-02-29 06:15:37 --> No URI present. Default controller set.
INFO - 2016-02-29 06:15:37 --> Router Class Initialized
INFO - 2016-02-29 06:15:37 --> Output Class Initialized
INFO - 2016-02-29 06:15:37 --> Security Class Initialized
DEBUG - 2016-02-29 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:15:37 --> Input Class Initialized
INFO - 2016-02-29 06:15:37 --> Language Class Initialized
INFO - 2016-02-29 06:15:37 --> Loader Class Initialized
INFO - 2016-02-29 06:15:37 --> Helper loaded: url_helper
INFO - 2016-02-29 06:15:37 --> Helper loaded: file_helper
INFO - 2016-02-29 06:15:37 --> Helper loaded: date_helper
INFO - 2016-02-29 06:15:37 --> Helper loaded: form_helper
INFO - 2016-02-29 06:15:37 --> Database Driver Class Initialized
INFO - 2016-02-29 06:15:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:15:38 --> Controller Class Initialized
INFO - 2016-02-29 06:15:38 --> Model Class Initialized
INFO - 2016-02-29 06:15:38 --> Model Class Initialized
INFO - 2016-02-29 06:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:15:38 --> Pagination Class Initialized
INFO - 2016-02-29 06:15:38 --> Helper loaded: text_helper
INFO - 2016-02-29 06:15:38 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:15:38 --> Final output sent to browser
DEBUG - 2016-02-29 09:15:38 --> Total execution time: 1.1607
INFO - 2016-02-29 06:15:40 --> Config Class Initialized
INFO - 2016-02-29 06:15:40 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:15:40 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:15:40 --> Utf8 Class Initialized
INFO - 2016-02-29 06:15:40 --> URI Class Initialized
INFO - 2016-02-29 06:15:40 --> Router Class Initialized
INFO - 2016-02-29 06:15:40 --> Output Class Initialized
INFO - 2016-02-29 06:15:40 --> Security Class Initialized
DEBUG - 2016-02-29 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:15:40 --> Input Class Initialized
INFO - 2016-02-29 06:15:40 --> Language Class Initialized
INFO - 2016-02-29 06:15:40 --> Loader Class Initialized
INFO - 2016-02-29 06:15:40 --> Helper loaded: url_helper
INFO - 2016-02-29 06:15:40 --> Helper loaded: file_helper
INFO - 2016-02-29 06:15:40 --> Helper loaded: date_helper
INFO - 2016-02-29 06:15:40 --> Helper loaded: form_helper
INFO - 2016-02-29 06:15:40 --> Database Driver Class Initialized
INFO - 2016-02-29 06:15:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:15:41 --> Controller Class Initialized
INFO - 2016-02-29 06:15:41 --> Model Class Initialized
INFO - 2016-02-29 06:15:41 --> Model Class Initialized
INFO - 2016-02-29 06:15:41 --> Form Validation Class Initialized
INFO - 2016-02-29 06:15:41 --> Helper loaded: text_helper
INFO - 2016-02-29 06:15:41 --> Final output sent to browser
DEBUG - 2016-02-29 06:15:41 --> Total execution time: 1.0921
INFO - 2016-02-29 06:19:42 --> Config Class Initialized
INFO - 2016-02-29 06:19:42 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:19:42 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:19:42 --> Utf8 Class Initialized
INFO - 2016-02-29 06:19:42 --> URI Class Initialized
DEBUG - 2016-02-29 06:19:42 --> No URI present. Default controller set.
INFO - 2016-02-29 06:19:42 --> Router Class Initialized
INFO - 2016-02-29 06:19:42 --> Output Class Initialized
INFO - 2016-02-29 06:19:42 --> Security Class Initialized
DEBUG - 2016-02-29 06:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:19:42 --> Input Class Initialized
INFO - 2016-02-29 06:19:42 --> Language Class Initialized
INFO - 2016-02-29 06:19:42 --> Loader Class Initialized
INFO - 2016-02-29 06:19:42 --> Helper loaded: url_helper
INFO - 2016-02-29 06:19:42 --> Helper loaded: file_helper
INFO - 2016-02-29 06:19:42 --> Helper loaded: date_helper
INFO - 2016-02-29 06:19:42 --> Helper loaded: form_helper
INFO - 2016-02-29 06:19:42 --> Database Driver Class Initialized
INFO - 2016-02-29 06:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:19:43 --> Controller Class Initialized
INFO - 2016-02-29 06:19:43 --> Model Class Initialized
INFO - 2016-02-29 06:19:43 --> Model Class Initialized
INFO - 2016-02-29 06:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:19:43 --> Pagination Class Initialized
INFO - 2016-02-29 06:19:43 --> Helper loaded: text_helper
INFO - 2016-02-29 06:19:43 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:19:43 --> Final output sent to browser
DEBUG - 2016-02-29 09:19:43 --> Total execution time: 1.1253
INFO - 2016-02-29 06:19:45 --> Config Class Initialized
INFO - 2016-02-29 06:19:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:19:45 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:19:45 --> Utf8 Class Initialized
INFO - 2016-02-29 06:19:46 --> URI Class Initialized
INFO - 2016-02-29 06:19:46 --> Router Class Initialized
INFO - 2016-02-29 06:19:46 --> Output Class Initialized
INFO - 2016-02-29 06:19:46 --> Security Class Initialized
DEBUG - 2016-02-29 06:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:19:46 --> Input Class Initialized
INFO - 2016-02-29 06:19:46 --> Language Class Initialized
INFO - 2016-02-29 06:19:46 --> Loader Class Initialized
INFO - 2016-02-29 06:19:46 --> Helper loaded: url_helper
INFO - 2016-02-29 06:19:46 --> Helper loaded: file_helper
INFO - 2016-02-29 06:19:46 --> Helper loaded: date_helper
INFO - 2016-02-29 06:19:46 --> Helper loaded: form_helper
INFO - 2016-02-29 06:19:46 --> Database Driver Class Initialized
INFO - 2016-02-29 06:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:19:47 --> Controller Class Initialized
INFO - 2016-02-29 06:19:47 --> Model Class Initialized
INFO - 2016-02-29 06:19:47 --> Model Class Initialized
INFO - 2016-02-29 06:19:47 --> Form Validation Class Initialized
INFO - 2016-02-29 06:19:47 --> Helper loaded: text_helper
INFO - 2016-02-29 06:19:47 --> Final output sent to browser
DEBUG - 2016-02-29 06:19:47 --> Total execution time: 1.0897
INFO - 2016-02-29 06:21:08 --> Config Class Initialized
INFO - 2016-02-29 06:21:08 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:21:08 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:21:08 --> Utf8 Class Initialized
INFO - 2016-02-29 06:21:08 --> URI Class Initialized
DEBUG - 2016-02-29 06:21:08 --> No URI present. Default controller set.
INFO - 2016-02-29 06:21:08 --> Router Class Initialized
INFO - 2016-02-29 06:21:08 --> Output Class Initialized
INFO - 2016-02-29 06:21:08 --> Security Class Initialized
DEBUG - 2016-02-29 06:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:21:08 --> Input Class Initialized
INFO - 2016-02-29 06:21:08 --> Language Class Initialized
INFO - 2016-02-29 06:21:08 --> Loader Class Initialized
INFO - 2016-02-29 06:21:08 --> Helper loaded: url_helper
INFO - 2016-02-29 06:21:08 --> Helper loaded: file_helper
INFO - 2016-02-29 06:21:08 --> Helper loaded: date_helper
INFO - 2016-02-29 06:21:08 --> Helper loaded: form_helper
INFO - 2016-02-29 06:21:08 --> Database Driver Class Initialized
INFO - 2016-02-29 06:21:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:21:09 --> Controller Class Initialized
INFO - 2016-02-29 06:21:09 --> Model Class Initialized
INFO - 2016-02-29 06:21:09 --> Model Class Initialized
INFO - 2016-02-29 06:21:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:21:09 --> Pagination Class Initialized
INFO - 2016-02-29 06:21:09 --> Helper loaded: text_helper
INFO - 2016-02-29 06:21:09 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:21:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:21:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:21:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:21:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:21:09 --> Final output sent to browser
DEBUG - 2016-02-29 09:21:09 --> Total execution time: 1.1337
INFO - 2016-02-29 06:21:16 --> Config Class Initialized
INFO - 2016-02-29 06:21:16 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:21:16 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:21:16 --> Utf8 Class Initialized
INFO - 2016-02-29 06:21:16 --> URI Class Initialized
INFO - 2016-02-29 06:21:16 --> Router Class Initialized
INFO - 2016-02-29 06:21:16 --> Output Class Initialized
INFO - 2016-02-29 06:21:16 --> Security Class Initialized
DEBUG - 2016-02-29 06:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:21:16 --> Input Class Initialized
INFO - 2016-02-29 06:21:16 --> Language Class Initialized
INFO - 2016-02-29 06:21:16 --> Loader Class Initialized
INFO - 2016-02-29 06:21:16 --> Helper loaded: url_helper
INFO - 2016-02-29 06:21:16 --> Helper loaded: file_helper
INFO - 2016-02-29 06:21:16 --> Helper loaded: date_helper
INFO - 2016-02-29 06:21:16 --> Helper loaded: form_helper
INFO - 2016-02-29 06:21:16 --> Database Driver Class Initialized
INFO - 2016-02-29 06:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:21:17 --> Controller Class Initialized
INFO - 2016-02-29 06:21:17 --> Model Class Initialized
INFO - 2016-02-29 06:21:17 --> Model Class Initialized
INFO - 2016-02-29 06:21:17 --> Form Validation Class Initialized
INFO - 2016-02-29 06:21:17 --> Helper loaded: text_helper
INFO - 2016-02-29 06:21:17 --> Final output sent to browser
DEBUG - 2016-02-29 06:21:17 --> Total execution time: 1.0881
INFO - 2016-02-29 06:24:25 --> Config Class Initialized
INFO - 2016-02-29 06:24:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:24:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:24:25 --> Utf8 Class Initialized
INFO - 2016-02-29 06:24:25 --> URI Class Initialized
INFO - 2016-02-29 06:24:25 --> Router Class Initialized
INFO - 2016-02-29 06:24:25 --> Output Class Initialized
INFO - 2016-02-29 06:24:25 --> Security Class Initialized
DEBUG - 2016-02-29 06:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:24:25 --> Input Class Initialized
INFO - 2016-02-29 06:24:25 --> Language Class Initialized
INFO - 2016-02-29 06:24:25 --> Loader Class Initialized
INFO - 2016-02-29 06:24:25 --> Helper loaded: url_helper
INFO - 2016-02-29 06:24:25 --> Helper loaded: file_helper
INFO - 2016-02-29 06:24:25 --> Helper loaded: date_helper
INFO - 2016-02-29 06:24:25 --> Helper loaded: form_helper
INFO - 2016-02-29 06:24:25 --> Database Driver Class Initialized
INFO - 2016-02-29 06:24:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:24:26 --> Controller Class Initialized
INFO - 2016-02-29 06:24:26 --> Model Class Initialized
INFO - 2016-02-29 06:24:26 --> Model Class Initialized
INFO - 2016-02-29 06:24:26 --> Form Validation Class Initialized
INFO - 2016-02-29 06:24:26 --> Helper loaded: text_helper
INFO - 2016-02-29 06:24:26 --> Config Class Initialized
INFO - 2016-02-29 06:24:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:24:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:24:26 --> Utf8 Class Initialized
INFO - 2016-02-29 06:24:26 --> URI Class Initialized
DEBUG - 2016-02-29 06:24:26 --> No URI present. Default controller set.
INFO - 2016-02-29 06:24:26 --> Router Class Initialized
INFO - 2016-02-29 06:24:26 --> Output Class Initialized
INFO - 2016-02-29 06:24:26 --> Security Class Initialized
DEBUG - 2016-02-29 06:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:24:26 --> Input Class Initialized
INFO - 2016-02-29 06:24:26 --> Language Class Initialized
INFO - 2016-02-29 06:24:26 --> Loader Class Initialized
INFO - 2016-02-29 06:24:26 --> Helper loaded: url_helper
INFO - 2016-02-29 06:24:26 --> Helper loaded: file_helper
INFO - 2016-02-29 06:24:26 --> Helper loaded: date_helper
INFO - 2016-02-29 06:24:26 --> Helper loaded: form_helper
INFO - 2016-02-29 06:24:26 --> Database Driver Class Initialized
INFO - 2016-02-29 06:24:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:24:27 --> Controller Class Initialized
INFO - 2016-02-29 06:24:27 --> Model Class Initialized
INFO - 2016-02-29 06:24:27 --> Model Class Initialized
INFO - 2016-02-29 06:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:24:27 --> Pagination Class Initialized
INFO - 2016-02-29 06:24:27 --> Helper loaded: text_helper
INFO - 2016-02-29 06:24:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:24:27 --> Final output sent to browser
DEBUG - 2016-02-29 09:24:27 --> Total execution time: 1.1457
INFO - 2016-02-29 06:25:38 --> Config Class Initialized
INFO - 2016-02-29 06:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:25:38 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:25:38 --> Utf8 Class Initialized
INFO - 2016-02-29 06:25:38 --> URI Class Initialized
DEBUG - 2016-02-29 06:25:38 --> No URI present. Default controller set.
INFO - 2016-02-29 06:25:38 --> Router Class Initialized
INFO - 2016-02-29 06:25:38 --> Output Class Initialized
INFO - 2016-02-29 06:25:38 --> Security Class Initialized
DEBUG - 2016-02-29 06:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:25:38 --> Input Class Initialized
INFO - 2016-02-29 06:25:38 --> Language Class Initialized
INFO - 2016-02-29 06:25:38 --> Loader Class Initialized
INFO - 2016-02-29 06:25:38 --> Helper loaded: url_helper
INFO - 2016-02-29 06:25:38 --> Helper loaded: file_helper
INFO - 2016-02-29 06:25:38 --> Helper loaded: date_helper
INFO - 2016-02-29 06:25:38 --> Helper loaded: form_helper
INFO - 2016-02-29 06:25:38 --> Database Driver Class Initialized
INFO - 2016-02-29 06:25:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:25:39 --> Controller Class Initialized
INFO - 2016-02-29 06:25:39 --> Model Class Initialized
INFO - 2016-02-29 06:25:39 --> Model Class Initialized
INFO - 2016-02-29 06:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:25:39 --> Pagination Class Initialized
INFO - 2016-02-29 06:25:39 --> Helper loaded: text_helper
INFO - 2016-02-29 06:25:39 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:25:39 --> Final output sent to browser
DEBUG - 2016-02-29 09:25:39 --> Total execution time: 1.1552
INFO - 2016-02-29 06:25:42 --> Config Class Initialized
INFO - 2016-02-29 06:25:42 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:25:42 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:25:42 --> Utf8 Class Initialized
INFO - 2016-02-29 06:25:42 --> URI Class Initialized
INFO - 2016-02-29 06:25:42 --> Router Class Initialized
INFO - 2016-02-29 06:25:42 --> Output Class Initialized
INFO - 2016-02-29 06:25:42 --> Security Class Initialized
DEBUG - 2016-02-29 06:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:25:42 --> Input Class Initialized
INFO - 2016-02-29 06:25:42 --> Language Class Initialized
INFO - 2016-02-29 06:25:42 --> Loader Class Initialized
INFO - 2016-02-29 06:25:42 --> Helper loaded: url_helper
INFO - 2016-02-29 06:25:42 --> Helper loaded: file_helper
INFO - 2016-02-29 06:25:42 --> Helper loaded: date_helper
INFO - 2016-02-29 06:25:42 --> Helper loaded: form_helper
INFO - 2016-02-29 06:25:42 --> Database Driver Class Initialized
INFO - 2016-02-29 06:25:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:25:43 --> Controller Class Initialized
INFO - 2016-02-29 06:25:43 --> Model Class Initialized
INFO - 2016-02-29 06:25:43 --> Model Class Initialized
INFO - 2016-02-29 06:25:43 --> Form Validation Class Initialized
INFO - 2016-02-29 06:25:43 --> Helper loaded: text_helper
INFO - 2016-02-29 06:25:44 --> Config Class Initialized
INFO - 2016-02-29 06:25:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:25:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:25:44 --> Utf8 Class Initialized
INFO - 2016-02-29 06:25:44 --> URI Class Initialized
DEBUG - 2016-02-29 06:25:44 --> No URI present. Default controller set.
INFO - 2016-02-29 06:25:44 --> Router Class Initialized
INFO - 2016-02-29 06:25:44 --> Output Class Initialized
INFO - 2016-02-29 06:25:44 --> Security Class Initialized
DEBUG - 2016-02-29 06:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:25:44 --> Input Class Initialized
INFO - 2016-02-29 06:25:44 --> Language Class Initialized
INFO - 2016-02-29 06:25:44 --> Loader Class Initialized
INFO - 2016-02-29 06:25:44 --> Helper loaded: url_helper
INFO - 2016-02-29 06:25:44 --> Helper loaded: file_helper
INFO - 2016-02-29 06:25:44 --> Helper loaded: date_helper
INFO - 2016-02-29 06:25:44 --> Helper loaded: form_helper
INFO - 2016-02-29 06:25:44 --> Database Driver Class Initialized
INFO - 2016-02-29 06:25:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:25:45 --> Controller Class Initialized
INFO - 2016-02-29 06:25:45 --> Model Class Initialized
INFO - 2016-02-29 06:25:45 --> Model Class Initialized
INFO - 2016-02-29 06:25:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:25:45 --> Pagination Class Initialized
INFO - 2016-02-29 06:25:45 --> Helper loaded: text_helper
INFO - 2016-02-29 06:25:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:25:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:25:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:25:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:25:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:25:45 --> Final output sent to browser
DEBUG - 2016-02-29 09:25:45 --> Total execution time: 1.1706
INFO - 2016-02-29 06:26:06 --> Config Class Initialized
INFO - 2016-02-29 06:26:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:06 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:06 --> URI Class Initialized
INFO - 2016-02-29 06:26:06 --> Router Class Initialized
INFO - 2016-02-29 06:26:06 --> Output Class Initialized
INFO - 2016-02-29 06:26:06 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:06 --> Input Class Initialized
INFO - 2016-02-29 06:26:06 --> Language Class Initialized
INFO - 2016-02-29 06:26:06 --> Loader Class Initialized
INFO - 2016-02-29 06:26:06 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:06 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:06 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:06 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:06 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:07 --> Controller Class Initialized
INFO - 2016-02-29 06:26:07 --> Model Class Initialized
INFO - 2016-02-29 06:26:07 --> Model Class Initialized
INFO - 2016-02-29 06:26:07 --> Form Validation Class Initialized
INFO - 2016-02-29 06:26:07 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:07 --> Config Class Initialized
INFO - 2016-02-29 06:26:07 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:07 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:07 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:07 --> URI Class Initialized
DEBUG - 2016-02-29 06:26:07 --> No URI present. Default controller set.
INFO - 2016-02-29 06:26:07 --> Router Class Initialized
INFO - 2016-02-29 06:26:07 --> Output Class Initialized
INFO - 2016-02-29 06:26:07 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:07 --> Input Class Initialized
INFO - 2016-02-29 06:26:07 --> Language Class Initialized
INFO - 2016-02-29 06:26:07 --> Loader Class Initialized
INFO - 2016-02-29 06:26:07 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:07 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:07 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:08 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:08 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:09 --> Controller Class Initialized
INFO - 2016-02-29 06:26:09 --> Model Class Initialized
INFO - 2016-02-29 06:26:09 --> Model Class Initialized
INFO - 2016-02-29 06:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:26:09 --> Pagination Class Initialized
INFO - 2016-02-29 06:26:09 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:09 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:26:09 --> Final output sent to browser
DEBUG - 2016-02-29 09:26:09 --> Total execution time: 1.1625
INFO - 2016-02-29 06:26:29 --> Config Class Initialized
INFO - 2016-02-29 06:26:29 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:29 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:29 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:29 --> URI Class Initialized
DEBUG - 2016-02-29 06:26:29 --> No URI present. Default controller set.
INFO - 2016-02-29 06:26:29 --> Router Class Initialized
INFO - 2016-02-29 06:26:29 --> Output Class Initialized
INFO - 2016-02-29 06:26:29 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:29 --> Input Class Initialized
INFO - 2016-02-29 06:26:29 --> Language Class Initialized
INFO - 2016-02-29 06:26:29 --> Loader Class Initialized
INFO - 2016-02-29 06:26:29 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:29 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:29 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:29 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:29 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:30 --> Controller Class Initialized
INFO - 2016-02-29 06:26:30 --> Model Class Initialized
INFO - 2016-02-29 06:26:30 --> Model Class Initialized
INFO - 2016-02-29 06:26:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:26:30 --> Pagination Class Initialized
INFO - 2016-02-29 06:26:30 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:30 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:26:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:26:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:26:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:26:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:26:30 --> Final output sent to browser
DEBUG - 2016-02-29 09:26:30 --> Total execution time: 1.1268
INFO - 2016-02-29 06:26:32 --> Config Class Initialized
INFO - 2016-02-29 06:26:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:32 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:32 --> URI Class Initialized
INFO - 2016-02-29 06:26:32 --> Router Class Initialized
INFO - 2016-02-29 06:26:32 --> Output Class Initialized
INFO - 2016-02-29 06:26:32 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:32 --> Input Class Initialized
INFO - 2016-02-29 06:26:32 --> Language Class Initialized
INFO - 2016-02-29 06:26:32 --> Loader Class Initialized
INFO - 2016-02-29 06:26:32 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:32 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:32 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:32 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:32 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:33 --> Controller Class Initialized
INFO - 2016-02-29 06:26:33 --> Model Class Initialized
INFO - 2016-02-29 06:26:33 --> Model Class Initialized
INFO - 2016-02-29 06:26:33 --> Form Validation Class Initialized
INFO - 2016-02-29 06:26:33 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:33 --> Config Class Initialized
INFO - 2016-02-29 06:26:33 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:33 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:33 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:33 --> URI Class Initialized
DEBUG - 2016-02-29 06:26:33 --> No URI present. Default controller set.
INFO - 2016-02-29 06:26:33 --> Router Class Initialized
INFO - 2016-02-29 06:26:33 --> Output Class Initialized
INFO - 2016-02-29 06:26:33 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:33 --> Input Class Initialized
INFO - 2016-02-29 06:26:33 --> Language Class Initialized
INFO - 2016-02-29 06:26:33 --> Loader Class Initialized
INFO - 2016-02-29 06:26:33 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:33 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:33 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:33 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:33 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:34 --> Controller Class Initialized
INFO - 2016-02-29 06:26:34 --> Model Class Initialized
INFO - 2016-02-29 06:26:34 --> Model Class Initialized
INFO - 2016-02-29 06:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:26:34 --> Pagination Class Initialized
INFO - 2016-02-29 06:26:34 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:34 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:26:34 --> Final output sent to browser
DEBUG - 2016-02-29 09:26:34 --> Total execution time: 1.1884
INFO - 2016-02-29 06:26:45 --> Config Class Initialized
INFO - 2016-02-29 06:26:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:26:45 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:26:45 --> Utf8 Class Initialized
INFO - 2016-02-29 06:26:45 --> URI Class Initialized
INFO - 2016-02-29 06:26:45 --> Router Class Initialized
INFO - 2016-02-29 06:26:45 --> Output Class Initialized
INFO - 2016-02-29 06:26:45 --> Security Class Initialized
DEBUG - 2016-02-29 06:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:26:45 --> Input Class Initialized
INFO - 2016-02-29 06:26:45 --> Language Class Initialized
INFO - 2016-02-29 06:26:45 --> Loader Class Initialized
INFO - 2016-02-29 06:26:45 --> Helper loaded: url_helper
INFO - 2016-02-29 06:26:45 --> Helper loaded: file_helper
INFO - 2016-02-29 06:26:45 --> Helper loaded: date_helper
INFO - 2016-02-29 06:26:45 --> Helper loaded: form_helper
INFO - 2016-02-29 06:26:45 --> Database Driver Class Initialized
INFO - 2016-02-29 06:26:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:26:46 --> Controller Class Initialized
INFO - 2016-02-29 06:26:46 --> Model Class Initialized
INFO - 2016-02-29 06:26:46 --> Model Class Initialized
INFO - 2016-02-29 06:26:46 --> Form Validation Class Initialized
INFO - 2016-02-29 06:26:46 --> Helper loaded: text_helper
INFO - 2016-02-29 06:26:46 --> Final output sent to browser
DEBUG - 2016-02-29 06:26:46 --> Total execution time: 1.1888
INFO - 2016-02-29 06:29:44 --> Config Class Initialized
INFO - 2016-02-29 06:29:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:29:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:29:44 --> Utf8 Class Initialized
INFO - 2016-02-29 06:29:44 --> URI Class Initialized
DEBUG - 2016-02-29 06:29:44 --> No URI present. Default controller set.
INFO - 2016-02-29 06:29:44 --> Router Class Initialized
INFO - 2016-02-29 06:29:44 --> Output Class Initialized
INFO - 2016-02-29 06:29:44 --> Security Class Initialized
DEBUG - 2016-02-29 06:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:29:44 --> Input Class Initialized
INFO - 2016-02-29 06:29:44 --> Language Class Initialized
INFO - 2016-02-29 06:29:44 --> Loader Class Initialized
INFO - 2016-02-29 06:29:44 --> Helper loaded: url_helper
INFO - 2016-02-29 06:29:44 --> Helper loaded: file_helper
INFO - 2016-02-29 06:29:44 --> Helper loaded: date_helper
INFO - 2016-02-29 06:29:44 --> Helper loaded: form_helper
INFO - 2016-02-29 06:29:44 --> Database Driver Class Initialized
INFO - 2016-02-29 06:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:29:45 --> Controller Class Initialized
INFO - 2016-02-29 06:29:45 --> Model Class Initialized
INFO - 2016-02-29 06:29:45 --> Model Class Initialized
INFO - 2016-02-29 06:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:29:45 --> Pagination Class Initialized
INFO - 2016-02-29 06:29:45 --> Helper loaded: text_helper
INFO - 2016-02-29 06:29:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:29:45 --> Final output sent to browser
DEBUG - 2016-02-29 09:29:45 --> Total execution time: 1.2247
INFO - 2016-02-29 06:29:46 --> Config Class Initialized
INFO - 2016-02-29 06:29:46 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:29:46 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:29:46 --> Utf8 Class Initialized
INFO - 2016-02-29 06:29:46 --> URI Class Initialized
INFO - 2016-02-29 06:29:46 --> Router Class Initialized
INFO - 2016-02-29 06:29:46 --> Output Class Initialized
INFO - 2016-02-29 06:29:46 --> Security Class Initialized
DEBUG - 2016-02-29 06:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:29:46 --> Input Class Initialized
INFO - 2016-02-29 06:29:46 --> Language Class Initialized
ERROR - 2016-02-29 06:29:47 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 111
INFO - 2016-02-29 06:30:07 --> Config Class Initialized
INFO - 2016-02-29 06:30:07 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:07 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:07 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:07 --> URI Class Initialized
INFO - 2016-02-29 06:30:07 --> Router Class Initialized
INFO - 2016-02-29 06:30:07 --> Output Class Initialized
INFO - 2016-02-29 06:30:07 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:07 --> Input Class Initialized
INFO - 2016-02-29 06:30:07 --> Language Class Initialized
ERROR - 2016-02-29 06:30:07 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 111
INFO - 2016-02-29 06:30:11 --> Config Class Initialized
INFO - 2016-02-29 06:30:11 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:11 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:11 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:11 --> URI Class Initialized
DEBUG - 2016-02-29 06:30:11 --> No URI present. Default controller set.
INFO - 2016-02-29 06:30:11 --> Router Class Initialized
INFO - 2016-02-29 06:30:11 --> Output Class Initialized
INFO - 2016-02-29 06:30:11 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:11 --> Input Class Initialized
INFO - 2016-02-29 06:30:11 --> Language Class Initialized
INFO - 2016-02-29 06:30:11 --> Loader Class Initialized
INFO - 2016-02-29 06:30:11 --> Helper loaded: url_helper
INFO - 2016-02-29 06:30:11 --> Helper loaded: file_helper
INFO - 2016-02-29 06:30:11 --> Helper loaded: date_helper
INFO - 2016-02-29 06:30:11 --> Helper loaded: form_helper
INFO - 2016-02-29 06:30:11 --> Database Driver Class Initialized
INFO - 2016-02-29 06:30:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:30:12 --> Controller Class Initialized
INFO - 2016-02-29 06:30:12 --> Model Class Initialized
INFO - 2016-02-29 06:30:12 --> Model Class Initialized
INFO - 2016-02-29 06:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:30:12 --> Pagination Class Initialized
INFO - 2016-02-29 06:30:12 --> Helper loaded: text_helper
INFO - 2016-02-29 06:30:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:30:12 --> Final output sent to browser
DEBUG - 2016-02-29 09:30:12 --> Total execution time: 1.1238
INFO - 2016-02-29 06:30:14 --> Config Class Initialized
INFO - 2016-02-29 06:30:14 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:14 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:14 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:14 --> URI Class Initialized
INFO - 2016-02-29 06:30:14 --> Router Class Initialized
INFO - 2016-02-29 06:30:14 --> Output Class Initialized
INFO - 2016-02-29 06:30:14 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:14 --> Input Class Initialized
INFO - 2016-02-29 06:30:14 --> Language Class Initialized
ERROR - 2016-02-29 06:30:14 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 111
INFO - 2016-02-29 06:30:32 --> Config Class Initialized
INFO - 2016-02-29 06:30:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:32 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:32 --> URI Class Initialized
INFO - 2016-02-29 06:30:32 --> Router Class Initialized
INFO - 2016-02-29 06:30:33 --> Output Class Initialized
INFO - 2016-02-29 06:30:33 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:33 --> Input Class Initialized
INFO - 2016-02-29 06:30:33 --> Language Class Initialized
INFO - 2016-02-29 06:30:33 --> Loader Class Initialized
INFO - 2016-02-29 06:30:33 --> Helper loaded: url_helper
INFO - 2016-02-29 06:30:33 --> Helper loaded: file_helper
INFO - 2016-02-29 06:30:33 --> Helper loaded: date_helper
INFO - 2016-02-29 06:30:33 --> Helper loaded: form_helper
INFO - 2016-02-29 06:30:33 --> Database Driver Class Initialized
INFO - 2016-02-29 06:30:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:30:34 --> Controller Class Initialized
INFO - 2016-02-29 06:30:34 --> Model Class Initialized
INFO - 2016-02-29 06:30:34 --> Model Class Initialized
INFO - 2016-02-29 06:30:34 --> Form Validation Class Initialized
INFO - 2016-02-29 06:30:34 --> Helper loaded: text_helper
INFO - 2016-02-29 06:30:34 --> Config Class Initialized
INFO - 2016-02-29 06:30:34 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:34 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:34 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:34 --> URI Class Initialized
DEBUG - 2016-02-29 06:30:34 --> No URI present. Default controller set.
INFO - 2016-02-29 06:30:34 --> Router Class Initialized
INFO - 2016-02-29 06:30:34 --> Output Class Initialized
INFO - 2016-02-29 06:30:34 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:34 --> Input Class Initialized
INFO - 2016-02-29 06:30:34 --> Language Class Initialized
INFO - 2016-02-29 06:30:34 --> Loader Class Initialized
INFO - 2016-02-29 06:30:34 --> Helper loaded: url_helper
INFO - 2016-02-29 06:30:34 --> Helper loaded: file_helper
INFO - 2016-02-29 06:30:34 --> Helper loaded: date_helper
INFO - 2016-02-29 06:30:34 --> Helper loaded: form_helper
INFO - 2016-02-29 06:30:34 --> Database Driver Class Initialized
INFO - 2016-02-29 06:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:30:35 --> Controller Class Initialized
INFO - 2016-02-29 06:30:35 --> Model Class Initialized
INFO - 2016-02-29 06:30:35 --> Model Class Initialized
INFO - 2016-02-29 06:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:30:35 --> Pagination Class Initialized
INFO - 2016-02-29 06:30:35 --> Helper loaded: text_helper
INFO - 2016-02-29 06:30:35 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:30:35 --> Final output sent to browser
DEBUG - 2016-02-29 09:30:35 --> Total execution time: 1.2264
INFO - 2016-02-29 06:30:47 --> Config Class Initialized
INFO - 2016-02-29 06:30:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:30:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:30:47 --> Utf8 Class Initialized
INFO - 2016-02-29 06:30:47 --> URI Class Initialized
INFO - 2016-02-29 06:30:47 --> Router Class Initialized
INFO - 2016-02-29 06:30:47 --> Output Class Initialized
INFO - 2016-02-29 06:30:47 --> Security Class Initialized
DEBUG - 2016-02-29 06:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:30:47 --> Input Class Initialized
INFO - 2016-02-29 06:30:47 --> Language Class Initialized
INFO - 2016-02-29 06:30:47 --> Loader Class Initialized
INFO - 2016-02-29 06:30:47 --> Helper loaded: url_helper
INFO - 2016-02-29 06:30:47 --> Helper loaded: file_helper
INFO - 2016-02-29 06:30:47 --> Helper loaded: date_helper
INFO - 2016-02-29 06:30:47 --> Helper loaded: form_helper
INFO - 2016-02-29 06:30:47 --> Database Driver Class Initialized
INFO - 2016-02-29 06:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:30:48 --> Controller Class Initialized
INFO - 2016-02-29 06:30:48 --> Model Class Initialized
INFO - 2016-02-29 06:30:48 --> Model Class Initialized
INFO - 2016-02-29 06:30:48 --> Form Validation Class Initialized
INFO - 2016-02-29 06:30:48 --> Helper loaded: text_helper
INFO - 2016-02-29 06:30:48 --> Final output sent to browser
DEBUG - 2016-02-29 06:30:48 --> Total execution time: 1.1982
INFO - 2016-02-29 06:31:51 --> Config Class Initialized
INFO - 2016-02-29 06:31:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:31:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:31:51 --> Utf8 Class Initialized
INFO - 2016-02-29 06:31:51 --> URI Class Initialized
DEBUG - 2016-02-29 06:31:51 --> No URI present. Default controller set.
INFO - 2016-02-29 06:31:51 --> Router Class Initialized
INFO - 2016-02-29 06:31:51 --> Output Class Initialized
INFO - 2016-02-29 06:31:51 --> Security Class Initialized
DEBUG - 2016-02-29 06:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:31:51 --> Input Class Initialized
INFO - 2016-02-29 06:31:51 --> Language Class Initialized
INFO - 2016-02-29 06:31:51 --> Loader Class Initialized
INFO - 2016-02-29 06:31:51 --> Helper loaded: url_helper
INFO - 2016-02-29 06:31:51 --> Helper loaded: file_helper
INFO - 2016-02-29 06:31:51 --> Helper loaded: date_helper
INFO - 2016-02-29 06:31:51 --> Helper loaded: form_helper
INFO - 2016-02-29 06:31:51 --> Database Driver Class Initialized
INFO - 2016-02-29 06:31:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:31:52 --> Controller Class Initialized
INFO - 2016-02-29 06:31:52 --> Model Class Initialized
INFO - 2016-02-29 06:31:52 --> Model Class Initialized
INFO - 2016-02-29 06:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:31:52 --> Pagination Class Initialized
INFO - 2016-02-29 06:31:52 --> Helper loaded: text_helper
INFO - 2016-02-29 06:31:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:31:52 --> Final output sent to browser
DEBUG - 2016-02-29 09:31:52 --> Total execution time: 1.1844
INFO - 2016-02-29 06:31:53 --> Config Class Initialized
INFO - 2016-02-29 06:31:53 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:31:53 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:31:53 --> Utf8 Class Initialized
INFO - 2016-02-29 06:31:53 --> URI Class Initialized
INFO - 2016-02-29 06:31:53 --> Router Class Initialized
INFO - 2016-02-29 06:31:53 --> Output Class Initialized
INFO - 2016-02-29 06:31:53 --> Security Class Initialized
DEBUG - 2016-02-29 06:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:31:53 --> Input Class Initialized
INFO - 2016-02-29 06:31:53 --> Language Class Initialized
INFO - 2016-02-29 06:31:53 --> Loader Class Initialized
INFO - 2016-02-29 06:31:53 --> Helper loaded: url_helper
INFO - 2016-02-29 06:31:53 --> Helper loaded: file_helper
INFO - 2016-02-29 06:31:53 --> Helper loaded: date_helper
INFO - 2016-02-29 06:31:53 --> Helper loaded: form_helper
INFO - 2016-02-29 06:31:53 --> Database Driver Class Initialized
INFO - 2016-02-29 06:31:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:31:54 --> Controller Class Initialized
INFO - 2016-02-29 06:31:54 --> Model Class Initialized
INFO - 2016-02-29 06:31:54 --> Model Class Initialized
INFO - 2016-02-29 06:31:54 --> Form Validation Class Initialized
INFO - 2016-02-29 06:31:54 --> Helper loaded: text_helper
INFO - 2016-02-29 06:31:55 --> Config Class Initialized
INFO - 2016-02-29 06:31:55 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:31:55 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:31:55 --> Utf8 Class Initialized
INFO - 2016-02-29 06:31:55 --> URI Class Initialized
DEBUG - 2016-02-29 06:31:55 --> No URI present. Default controller set.
INFO - 2016-02-29 06:31:55 --> Router Class Initialized
INFO - 2016-02-29 06:31:55 --> Output Class Initialized
INFO - 2016-02-29 06:31:55 --> Security Class Initialized
DEBUG - 2016-02-29 06:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:31:55 --> Input Class Initialized
INFO - 2016-02-29 06:31:55 --> Language Class Initialized
INFO - 2016-02-29 06:31:55 --> Loader Class Initialized
INFO - 2016-02-29 06:31:55 --> Helper loaded: url_helper
INFO - 2016-02-29 06:31:55 --> Helper loaded: file_helper
INFO - 2016-02-29 06:31:55 --> Helper loaded: date_helper
INFO - 2016-02-29 06:31:55 --> Helper loaded: form_helper
INFO - 2016-02-29 06:31:55 --> Database Driver Class Initialized
INFO - 2016-02-29 06:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:31:56 --> Controller Class Initialized
INFO - 2016-02-29 06:31:56 --> Model Class Initialized
INFO - 2016-02-29 06:31:56 --> Model Class Initialized
INFO - 2016-02-29 06:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:31:56 --> Pagination Class Initialized
INFO - 2016-02-29 06:31:56 --> Helper loaded: text_helper
INFO - 2016-02-29 06:31:56 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:31:56 --> Final output sent to browser
DEBUG - 2016-02-29 09:31:56 --> Total execution time: 1.1747
INFO - 2016-02-29 06:32:08 --> Config Class Initialized
INFO - 2016-02-29 06:32:08 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:32:08 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:32:08 --> Utf8 Class Initialized
INFO - 2016-02-29 06:32:08 --> URI Class Initialized
INFO - 2016-02-29 06:32:08 --> Router Class Initialized
INFO - 2016-02-29 06:32:08 --> Output Class Initialized
INFO - 2016-02-29 06:32:08 --> Security Class Initialized
DEBUG - 2016-02-29 06:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:32:08 --> Input Class Initialized
INFO - 2016-02-29 06:32:08 --> Language Class Initialized
INFO - 2016-02-29 06:32:08 --> Loader Class Initialized
INFO - 2016-02-29 06:32:08 --> Helper loaded: url_helper
INFO - 2016-02-29 06:32:08 --> Helper loaded: file_helper
INFO - 2016-02-29 06:32:08 --> Helper loaded: date_helper
INFO - 2016-02-29 06:32:08 --> Helper loaded: form_helper
INFO - 2016-02-29 06:32:08 --> Database Driver Class Initialized
INFO - 2016-02-29 06:32:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:32:09 --> Controller Class Initialized
INFO - 2016-02-29 06:32:09 --> Model Class Initialized
INFO - 2016-02-29 06:32:09 --> Model Class Initialized
INFO - 2016-02-29 06:32:09 --> Form Validation Class Initialized
INFO - 2016-02-29 06:32:09 --> Helper loaded: text_helper
INFO - 2016-02-29 06:32:09 --> Final output sent to browser
DEBUG - 2016-02-29 06:32:09 --> Total execution time: 1.2171
INFO - 2016-02-29 06:33:22 --> Config Class Initialized
INFO - 2016-02-29 06:33:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:33:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:33:22 --> Utf8 Class Initialized
INFO - 2016-02-29 06:33:22 --> URI Class Initialized
DEBUG - 2016-02-29 06:33:22 --> No URI present. Default controller set.
INFO - 2016-02-29 06:33:22 --> Router Class Initialized
INFO - 2016-02-29 06:33:22 --> Output Class Initialized
INFO - 2016-02-29 06:33:22 --> Security Class Initialized
DEBUG - 2016-02-29 06:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:33:22 --> Input Class Initialized
INFO - 2016-02-29 06:33:22 --> Language Class Initialized
INFO - 2016-02-29 06:33:22 --> Loader Class Initialized
INFO - 2016-02-29 06:33:22 --> Helper loaded: url_helper
INFO - 2016-02-29 06:33:22 --> Helper loaded: file_helper
INFO - 2016-02-29 06:33:22 --> Helper loaded: date_helper
INFO - 2016-02-29 06:33:22 --> Helper loaded: form_helper
INFO - 2016-02-29 06:33:22 --> Database Driver Class Initialized
INFO - 2016-02-29 06:33:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:33:23 --> Controller Class Initialized
INFO - 2016-02-29 06:33:23 --> Model Class Initialized
INFO - 2016-02-29 06:33:23 --> Model Class Initialized
INFO - 2016-02-29 06:33:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:33:23 --> Pagination Class Initialized
INFO - 2016-02-29 06:33:23 --> Helper loaded: text_helper
INFO - 2016-02-29 06:33:23 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:33:23 --> Final output sent to browser
DEBUG - 2016-02-29 09:33:23 --> Total execution time: 1.1781
INFO - 2016-02-29 06:33:24 --> Config Class Initialized
INFO - 2016-02-29 06:33:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:33:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:33:24 --> Utf8 Class Initialized
INFO - 2016-02-29 06:33:24 --> URI Class Initialized
INFO - 2016-02-29 06:33:24 --> Router Class Initialized
INFO - 2016-02-29 06:33:24 --> Output Class Initialized
INFO - 2016-02-29 06:33:24 --> Security Class Initialized
DEBUG - 2016-02-29 06:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:33:24 --> Input Class Initialized
INFO - 2016-02-29 06:33:24 --> Language Class Initialized
INFO - 2016-02-29 06:33:24 --> Loader Class Initialized
INFO - 2016-02-29 06:33:24 --> Helper loaded: url_helper
INFO - 2016-02-29 06:33:24 --> Helper loaded: file_helper
INFO - 2016-02-29 06:33:24 --> Helper loaded: date_helper
INFO - 2016-02-29 06:33:24 --> Helper loaded: form_helper
INFO - 2016-02-29 06:33:24 --> Database Driver Class Initialized
INFO - 2016-02-29 06:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:33:25 --> Controller Class Initialized
INFO - 2016-02-29 06:33:25 --> Model Class Initialized
INFO - 2016-02-29 06:33:25 --> Model Class Initialized
INFO - 2016-02-29 06:33:25 --> Form Validation Class Initialized
INFO - 2016-02-29 06:33:25 --> Helper loaded: text_helper
INFO - 2016-02-29 06:33:25 --> Config Class Initialized
INFO - 2016-02-29 06:33:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:33:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:33:25 --> Utf8 Class Initialized
INFO - 2016-02-29 06:33:25 --> URI Class Initialized
DEBUG - 2016-02-29 06:33:25 --> No URI present. Default controller set.
INFO - 2016-02-29 06:33:25 --> Router Class Initialized
INFO - 2016-02-29 06:33:25 --> Output Class Initialized
INFO - 2016-02-29 06:33:25 --> Security Class Initialized
DEBUG - 2016-02-29 06:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:33:25 --> Input Class Initialized
INFO - 2016-02-29 06:33:25 --> Language Class Initialized
INFO - 2016-02-29 06:33:25 --> Loader Class Initialized
INFO - 2016-02-29 06:33:25 --> Helper loaded: url_helper
INFO - 2016-02-29 06:33:25 --> Helper loaded: file_helper
INFO - 2016-02-29 06:33:25 --> Helper loaded: date_helper
INFO - 2016-02-29 06:33:25 --> Helper loaded: form_helper
INFO - 2016-02-29 06:33:25 --> Database Driver Class Initialized
INFO - 2016-02-29 06:33:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:33:26 --> Controller Class Initialized
INFO - 2016-02-29 06:33:26 --> Model Class Initialized
INFO - 2016-02-29 06:33:27 --> Model Class Initialized
INFO - 2016-02-29 06:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:33:27 --> Pagination Class Initialized
INFO - 2016-02-29 06:33:27 --> Helper loaded: text_helper
INFO - 2016-02-29 06:33:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:33:27 --> Final output sent to browser
DEBUG - 2016-02-29 09:33:27 --> Total execution time: 1.1565
INFO - 2016-02-29 06:33:35 --> Config Class Initialized
INFO - 2016-02-29 06:33:35 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:33:35 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:33:35 --> Utf8 Class Initialized
INFO - 2016-02-29 06:33:35 --> URI Class Initialized
INFO - 2016-02-29 06:33:35 --> Router Class Initialized
INFO - 2016-02-29 06:33:35 --> Output Class Initialized
INFO - 2016-02-29 06:33:35 --> Security Class Initialized
DEBUG - 2016-02-29 06:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:33:35 --> Input Class Initialized
INFO - 2016-02-29 06:33:35 --> Language Class Initialized
INFO - 2016-02-29 06:33:35 --> Loader Class Initialized
INFO - 2016-02-29 06:33:35 --> Helper loaded: url_helper
INFO - 2016-02-29 06:33:35 --> Helper loaded: file_helper
INFO - 2016-02-29 06:33:35 --> Helper loaded: date_helper
INFO - 2016-02-29 06:33:35 --> Helper loaded: form_helper
INFO - 2016-02-29 06:33:35 --> Database Driver Class Initialized
INFO - 2016-02-29 06:33:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:33:36 --> Controller Class Initialized
INFO - 2016-02-29 06:33:36 --> Model Class Initialized
INFO - 2016-02-29 06:33:36 --> Model Class Initialized
INFO - 2016-02-29 06:33:36 --> Form Validation Class Initialized
INFO - 2016-02-29 06:33:36 --> Helper loaded: text_helper
INFO - 2016-02-29 06:33:36 --> Final output sent to browser
DEBUG - 2016-02-29 06:33:36 --> Total execution time: 1.1995
INFO - 2016-02-29 06:33:36 --> Config Class Initialized
INFO - 2016-02-29 06:33:36 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:33:36 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:33:36 --> Utf8 Class Initialized
INFO - 2016-02-29 06:33:36 --> URI Class Initialized
INFO - 2016-02-29 06:33:36 --> Router Class Initialized
INFO - 2016-02-29 06:33:36 --> Output Class Initialized
INFO - 2016-02-29 06:33:36 --> Security Class Initialized
DEBUG - 2016-02-29 06:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:33:36 --> Input Class Initialized
INFO - 2016-02-29 06:33:36 --> Language Class Initialized
ERROR - 2016-02-29 06:33:36 --> 404 Page Not Found: %5Bobject%20Object%5D/index
INFO - 2016-02-29 06:34:18 --> Config Class Initialized
INFO - 2016-02-29 06:34:18 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:34:18 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:34:18 --> Utf8 Class Initialized
INFO - 2016-02-29 06:34:18 --> URI Class Initialized
DEBUG - 2016-02-29 06:34:18 --> No URI present. Default controller set.
INFO - 2016-02-29 06:34:18 --> Router Class Initialized
INFO - 2016-02-29 06:34:18 --> Output Class Initialized
INFO - 2016-02-29 06:34:18 --> Security Class Initialized
DEBUG - 2016-02-29 06:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:34:18 --> Input Class Initialized
INFO - 2016-02-29 06:34:18 --> Language Class Initialized
INFO - 2016-02-29 06:34:18 --> Loader Class Initialized
INFO - 2016-02-29 06:34:18 --> Helper loaded: url_helper
INFO - 2016-02-29 06:34:18 --> Helper loaded: file_helper
INFO - 2016-02-29 06:34:18 --> Helper loaded: date_helper
INFO - 2016-02-29 06:34:18 --> Helper loaded: form_helper
INFO - 2016-02-29 06:34:18 --> Database Driver Class Initialized
INFO - 2016-02-29 06:34:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:34:19 --> Controller Class Initialized
INFO - 2016-02-29 06:34:19 --> Model Class Initialized
INFO - 2016-02-29 06:34:19 --> Model Class Initialized
INFO - 2016-02-29 06:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:34:19 --> Pagination Class Initialized
INFO - 2016-02-29 06:34:19 --> Helper loaded: text_helper
INFO - 2016-02-29 06:34:19 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:34:19 --> Final output sent to browser
DEBUG - 2016-02-29 09:34:19 --> Total execution time: 1.1611
INFO - 2016-02-29 06:35:22 --> Config Class Initialized
INFO - 2016-02-29 06:35:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:35:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:35:22 --> Utf8 Class Initialized
INFO - 2016-02-29 06:35:22 --> URI Class Initialized
INFO - 2016-02-29 06:35:22 --> Router Class Initialized
INFO - 2016-02-29 06:35:22 --> Output Class Initialized
INFO - 2016-02-29 06:35:22 --> Security Class Initialized
DEBUG - 2016-02-29 06:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:35:22 --> Input Class Initialized
INFO - 2016-02-29 06:35:22 --> Language Class Initialized
INFO - 2016-02-29 06:35:22 --> Loader Class Initialized
INFO - 2016-02-29 06:35:22 --> Helper loaded: url_helper
INFO - 2016-02-29 06:35:22 --> Helper loaded: file_helper
INFO - 2016-02-29 06:35:22 --> Helper loaded: date_helper
INFO - 2016-02-29 06:35:22 --> Helper loaded: form_helper
INFO - 2016-02-29 06:35:22 --> Database Driver Class Initialized
INFO - 2016-02-29 06:35:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:35:23 --> Controller Class Initialized
INFO - 2016-02-29 06:35:23 --> Model Class Initialized
INFO - 2016-02-29 06:35:23 --> Model Class Initialized
INFO - 2016-02-29 06:35:23 --> Form Validation Class Initialized
INFO - 2016-02-29 06:35:23 --> Helper loaded: text_helper
INFO - 2016-02-29 06:35:23 --> Config Class Initialized
INFO - 2016-02-29 06:35:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:35:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:35:23 --> Utf8 Class Initialized
INFO - 2016-02-29 06:35:23 --> URI Class Initialized
DEBUG - 2016-02-29 06:35:23 --> No URI present. Default controller set.
INFO - 2016-02-29 06:35:23 --> Router Class Initialized
INFO - 2016-02-29 06:35:23 --> Output Class Initialized
INFO - 2016-02-29 06:35:23 --> Security Class Initialized
DEBUG - 2016-02-29 06:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:35:23 --> Input Class Initialized
INFO - 2016-02-29 06:35:23 --> Language Class Initialized
INFO - 2016-02-29 06:35:23 --> Loader Class Initialized
INFO - 2016-02-29 06:35:23 --> Helper loaded: url_helper
INFO - 2016-02-29 06:35:23 --> Helper loaded: file_helper
INFO - 2016-02-29 06:35:23 --> Helper loaded: date_helper
INFO - 2016-02-29 06:35:23 --> Helper loaded: form_helper
INFO - 2016-02-29 06:35:23 --> Database Driver Class Initialized
INFO - 2016-02-29 06:35:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:35:25 --> Controller Class Initialized
INFO - 2016-02-29 06:35:25 --> Model Class Initialized
INFO - 2016-02-29 06:35:25 --> Model Class Initialized
INFO - 2016-02-29 06:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:35:25 --> Pagination Class Initialized
INFO - 2016-02-29 06:35:25 --> Helper loaded: text_helper
INFO - 2016-02-29 06:35:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:35:25 --> Final output sent to browser
DEBUG - 2016-02-29 09:35:25 --> Total execution time: 1.1306
INFO - 2016-02-29 06:35:26 --> Config Class Initialized
INFO - 2016-02-29 06:35:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:35:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:35:26 --> Utf8 Class Initialized
INFO - 2016-02-29 06:35:26 --> URI Class Initialized
DEBUG - 2016-02-29 06:35:26 --> No URI present. Default controller set.
INFO - 2016-02-29 06:35:26 --> Router Class Initialized
INFO - 2016-02-29 06:35:27 --> Output Class Initialized
INFO - 2016-02-29 06:35:27 --> Security Class Initialized
DEBUG - 2016-02-29 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:35:27 --> Input Class Initialized
INFO - 2016-02-29 06:35:27 --> Language Class Initialized
INFO - 2016-02-29 06:35:27 --> Loader Class Initialized
INFO - 2016-02-29 06:35:27 --> Helper loaded: url_helper
INFO - 2016-02-29 06:35:27 --> Helper loaded: file_helper
INFO - 2016-02-29 06:35:27 --> Helper loaded: date_helper
INFO - 2016-02-29 06:35:27 --> Helper loaded: form_helper
INFO - 2016-02-29 06:35:27 --> Database Driver Class Initialized
INFO - 2016-02-29 06:35:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:35:28 --> Controller Class Initialized
INFO - 2016-02-29 06:35:28 --> Model Class Initialized
INFO - 2016-02-29 06:35:28 --> Model Class Initialized
INFO - 2016-02-29 06:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:35:28 --> Pagination Class Initialized
INFO - 2016-02-29 06:35:28 --> Helper loaded: text_helper
INFO - 2016-02-29 06:35:28 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:35:28 --> Final output sent to browser
DEBUG - 2016-02-29 09:35:28 --> Total execution time: 1.1875
INFO - 2016-02-29 06:35:38 --> Config Class Initialized
INFO - 2016-02-29 06:35:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:35:38 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:35:38 --> Utf8 Class Initialized
INFO - 2016-02-29 06:35:38 --> URI Class Initialized
INFO - 2016-02-29 06:35:38 --> Router Class Initialized
INFO - 2016-02-29 06:35:38 --> Output Class Initialized
INFO - 2016-02-29 06:35:38 --> Security Class Initialized
DEBUG - 2016-02-29 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:35:38 --> Input Class Initialized
INFO - 2016-02-29 06:35:38 --> Language Class Initialized
INFO - 2016-02-29 06:35:38 --> Loader Class Initialized
INFO - 2016-02-29 06:35:38 --> Helper loaded: url_helper
INFO - 2016-02-29 06:35:38 --> Helper loaded: file_helper
INFO - 2016-02-29 06:35:38 --> Helper loaded: date_helper
INFO - 2016-02-29 06:35:38 --> Helper loaded: form_helper
INFO - 2016-02-29 06:35:38 --> Database Driver Class Initialized
INFO - 2016-02-29 06:35:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:35:39 --> Controller Class Initialized
INFO - 2016-02-29 06:35:39 --> Model Class Initialized
INFO - 2016-02-29 06:35:39 --> Model Class Initialized
INFO - 2016-02-29 06:35:39 --> Form Validation Class Initialized
INFO - 2016-02-29 06:35:39 --> Helper loaded: text_helper
INFO - 2016-02-29 06:35:39 --> Final output sent to browser
DEBUG - 2016-02-29 06:35:39 --> Total execution time: 1.2024
INFO - 2016-02-29 06:36:09 --> Config Class Initialized
INFO - 2016-02-29 06:36:09 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:36:09 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:36:09 --> Utf8 Class Initialized
INFO - 2016-02-29 06:36:09 --> URI Class Initialized
DEBUG - 2016-02-29 06:36:09 --> No URI present. Default controller set.
INFO - 2016-02-29 06:36:09 --> Router Class Initialized
INFO - 2016-02-29 06:36:09 --> Output Class Initialized
INFO - 2016-02-29 06:36:09 --> Security Class Initialized
DEBUG - 2016-02-29 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:36:09 --> Input Class Initialized
INFO - 2016-02-29 06:36:09 --> Language Class Initialized
INFO - 2016-02-29 06:36:09 --> Loader Class Initialized
INFO - 2016-02-29 06:36:09 --> Helper loaded: url_helper
INFO - 2016-02-29 06:36:09 --> Helper loaded: file_helper
INFO - 2016-02-29 06:36:09 --> Helper loaded: date_helper
INFO - 2016-02-29 06:36:09 --> Helper loaded: form_helper
INFO - 2016-02-29 06:36:09 --> Database Driver Class Initialized
INFO - 2016-02-29 06:36:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:36:10 --> Controller Class Initialized
INFO - 2016-02-29 06:36:10 --> Model Class Initialized
INFO - 2016-02-29 06:36:10 --> Model Class Initialized
INFO - 2016-02-29 06:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:36:10 --> Pagination Class Initialized
INFO - 2016-02-29 06:36:10 --> Helper loaded: text_helper
INFO - 2016-02-29 06:36:10 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:36:10 --> Final output sent to browser
DEBUG - 2016-02-29 09:36:10 --> Total execution time: 1.1619
INFO - 2016-02-29 06:43:47 --> Config Class Initialized
INFO - 2016-02-29 06:43:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:43:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:43:47 --> Utf8 Class Initialized
INFO - 2016-02-29 06:43:47 --> URI Class Initialized
DEBUG - 2016-02-29 06:43:47 --> No URI present. Default controller set.
INFO - 2016-02-29 06:43:47 --> Router Class Initialized
INFO - 2016-02-29 06:43:47 --> Output Class Initialized
INFO - 2016-02-29 06:43:47 --> Security Class Initialized
DEBUG - 2016-02-29 06:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:43:47 --> Input Class Initialized
INFO - 2016-02-29 06:43:47 --> Language Class Initialized
INFO - 2016-02-29 06:43:47 --> Loader Class Initialized
INFO - 2016-02-29 06:43:47 --> Helper loaded: url_helper
INFO - 2016-02-29 06:43:47 --> Helper loaded: file_helper
INFO - 2016-02-29 06:43:47 --> Helper loaded: date_helper
INFO - 2016-02-29 06:43:47 --> Helper loaded: form_helper
INFO - 2016-02-29 06:43:47 --> Database Driver Class Initialized
INFO - 2016-02-29 06:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:43:48 --> Controller Class Initialized
INFO - 2016-02-29 06:43:48 --> Model Class Initialized
INFO - 2016-02-29 06:43:48 --> Model Class Initialized
INFO - 2016-02-29 06:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:43:48 --> Pagination Class Initialized
INFO - 2016-02-29 06:43:48 --> Helper loaded: text_helper
INFO - 2016-02-29 06:43:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-29 09:43:48 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 67
INFO - 2016-02-29 09:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:43:48 --> Final output sent to browser
DEBUG - 2016-02-29 09:43:48 --> Total execution time: 1.1823
INFO - 2016-02-29 06:43:50 --> Config Class Initialized
INFO - 2016-02-29 06:43:50 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:43:50 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:43:50 --> Utf8 Class Initialized
INFO - 2016-02-29 06:43:50 --> URI Class Initialized
INFO - 2016-02-29 06:43:50 --> Router Class Initialized
INFO - 2016-02-29 06:43:50 --> Output Class Initialized
INFO - 2016-02-29 06:43:50 --> Security Class Initialized
DEBUG - 2016-02-29 06:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:43:50 --> Input Class Initialized
INFO - 2016-02-29 06:43:50 --> Language Class Initialized
INFO - 2016-02-29 06:43:50 --> Loader Class Initialized
INFO - 2016-02-29 06:43:50 --> Helper loaded: url_helper
INFO - 2016-02-29 06:43:50 --> Helper loaded: file_helper
INFO - 2016-02-29 06:43:50 --> Helper loaded: date_helper
INFO - 2016-02-29 06:43:50 --> Helper loaded: form_helper
INFO - 2016-02-29 06:43:50 --> Database Driver Class Initialized
INFO - 2016-02-29 06:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:43:51 --> Controller Class Initialized
INFO - 2016-02-29 06:43:51 --> Model Class Initialized
INFO - 2016-02-29 06:43:51 --> Model Class Initialized
INFO - 2016-02-29 06:43:51 --> Form Validation Class Initialized
INFO - 2016-02-29 06:43:51 --> Helper loaded: text_helper
INFO - 2016-02-29 06:43:51 --> Config Class Initialized
INFO - 2016-02-29 06:43:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:43:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:43:51 --> Utf8 Class Initialized
INFO - 2016-02-29 06:43:51 --> URI Class Initialized
DEBUG - 2016-02-29 06:43:51 --> No URI present. Default controller set.
INFO - 2016-02-29 06:43:51 --> Router Class Initialized
INFO - 2016-02-29 06:43:51 --> Output Class Initialized
INFO - 2016-02-29 06:43:51 --> Security Class Initialized
DEBUG - 2016-02-29 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:43:51 --> Input Class Initialized
INFO - 2016-02-29 06:43:51 --> Language Class Initialized
INFO - 2016-02-29 06:43:51 --> Loader Class Initialized
INFO - 2016-02-29 06:43:51 --> Helper loaded: url_helper
INFO - 2016-02-29 06:43:51 --> Helper loaded: file_helper
INFO - 2016-02-29 06:43:51 --> Helper loaded: date_helper
INFO - 2016-02-29 06:43:51 --> Helper loaded: form_helper
INFO - 2016-02-29 06:43:51 --> Database Driver Class Initialized
INFO - 2016-02-29 06:43:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:43:52 --> Controller Class Initialized
INFO - 2016-02-29 06:43:52 --> Model Class Initialized
INFO - 2016-02-29 06:43:52 --> Model Class Initialized
INFO - 2016-02-29 06:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:43:52 --> Pagination Class Initialized
INFO - 2016-02-29 06:43:52 --> Helper loaded: text_helper
INFO - 2016-02-29 06:43:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-29 09:43:52 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 67
INFO - 2016-02-29 09:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:43:52 --> Final output sent to browser
DEBUG - 2016-02-29 09:43:52 --> Total execution time: 1.1108
INFO - 2016-02-29 06:44:05 --> Config Class Initialized
INFO - 2016-02-29 06:44:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:44:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:44:05 --> Utf8 Class Initialized
INFO - 2016-02-29 06:44:05 --> URI Class Initialized
DEBUG - 2016-02-29 06:44:05 --> No URI present. Default controller set.
INFO - 2016-02-29 06:44:05 --> Router Class Initialized
INFO - 2016-02-29 06:44:05 --> Output Class Initialized
INFO - 2016-02-29 06:44:05 --> Security Class Initialized
DEBUG - 2016-02-29 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:44:05 --> Input Class Initialized
INFO - 2016-02-29 06:44:05 --> Language Class Initialized
INFO - 2016-02-29 06:44:05 --> Loader Class Initialized
INFO - 2016-02-29 06:44:05 --> Helper loaded: url_helper
INFO - 2016-02-29 06:44:05 --> Helper loaded: file_helper
INFO - 2016-02-29 06:44:05 --> Helper loaded: date_helper
INFO - 2016-02-29 06:44:05 --> Helper loaded: form_helper
INFO - 2016-02-29 06:44:05 --> Database Driver Class Initialized
INFO - 2016-02-29 06:44:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:44:06 --> Controller Class Initialized
INFO - 2016-02-29 06:44:06 --> Model Class Initialized
INFO - 2016-02-29 06:44:06 --> Model Class Initialized
INFO - 2016-02-29 06:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:44:06 --> Pagination Class Initialized
INFO - 2016-02-29 06:44:06 --> Helper loaded: text_helper
INFO - 2016-02-29 06:44:06 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-29 09:44:06 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 67
INFO - 2016-02-29 09:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:44:06 --> Final output sent to browser
DEBUG - 2016-02-29 09:44:06 --> Total execution time: 1.1322
INFO - 2016-02-29 06:45:10 --> Config Class Initialized
INFO - 2016-02-29 06:45:10 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:45:10 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:45:10 --> Utf8 Class Initialized
INFO - 2016-02-29 06:45:10 --> URI Class Initialized
INFO - 2016-02-29 06:45:10 --> Router Class Initialized
INFO - 2016-02-29 06:45:10 --> Output Class Initialized
INFO - 2016-02-29 06:45:10 --> Security Class Initialized
DEBUG - 2016-02-29 06:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:45:10 --> Input Class Initialized
INFO - 2016-02-29 06:45:10 --> Language Class Initialized
INFO - 2016-02-29 06:45:11 --> Loader Class Initialized
INFO - 2016-02-29 06:45:11 --> Helper loaded: url_helper
INFO - 2016-02-29 06:45:11 --> Helper loaded: file_helper
INFO - 2016-02-29 06:45:11 --> Helper loaded: date_helper
INFO - 2016-02-29 06:45:11 --> Helper loaded: form_helper
INFO - 2016-02-29 06:45:11 --> Database Driver Class Initialized
INFO - 2016-02-29 06:45:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:45:12 --> Controller Class Initialized
INFO - 2016-02-29 06:45:12 --> Model Class Initialized
INFO - 2016-02-29 06:45:12 --> Model Class Initialized
INFO - 2016-02-29 06:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:45:12 --> Pagination Class Initialized
INFO - 2016-02-29 06:45:12 --> Helper loaded: text_helper
INFO - 2016-02-29 06:45:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-29 09:45:12 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 67
INFO - 2016-02-29 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:45:12 --> Final output sent to browser
DEBUG - 2016-02-29 09:45:12 --> Total execution time: 1.1239
INFO - 2016-02-29 06:45:15 --> Config Class Initialized
INFO - 2016-02-29 06:45:15 --> Hooks Class Initialized
DEBUG - 2016-02-29 06:45:15 --> UTF-8 Support Enabled
INFO - 2016-02-29 06:45:15 --> Utf8 Class Initialized
INFO - 2016-02-29 06:45:15 --> URI Class Initialized
DEBUG - 2016-02-29 06:45:15 --> No URI present. Default controller set.
INFO - 2016-02-29 06:45:15 --> Router Class Initialized
INFO - 2016-02-29 06:45:15 --> Output Class Initialized
INFO - 2016-02-29 06:45:15 --> Security Class Initialized
DEBUG - 2016-02-29 06:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 06:45:15 --> Input Class Initialized
INFO - 2016-02-29 06:45:15 --> Language Class Initialized
INFO - 2016-02-29 06:45:15 --> Loader Class Initialized
INFO - 2016-02-29 06:45:15 --> Helper loaded: url_helper
INFO - 2016-02-29 06:45:15 --> Helper loaded: file_helper
INFO - 2016-02-29 06:45:15 --> Helper loaded: date_helper
INFO - 2016-02-29 06:45:15 --> Helper loaded: form_helper
INFO - 2016-02-29 06:45:15 --> Database Driver Class Initialized
INFO - 2016-02-29 06:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 06:45:16 --> Controller Class Initialized
INFO - 2016-02-29 06:45:16 --> Model Class Initialized
INFO - 2016-02-29 06:45:16 --> Model Class Initialized
INFO - 2016-02-29 06:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 06:45:16 --> Pagination Class Initialized
INFO - 2016-02-29 06:45:16 --> Helper loaded: text_helper
INFO - 2016-02-29 06:45:16 --> Helper loaded: cookie_helper
INFO - 2016-02-29 09:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-29 09:45:16 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 67
INFO - 2016-02-29 09:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 09:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 09:45:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 09:45:16 --> Final output sent to browser
DEBUG - 2016-02-29 09:45:16 --> Total execution time: 1.1445
INFO - 2016-02-29 07:40:19 --> Config Class Initialized
INFO - 2016-02-29 07:40:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:40:19 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:40:19 --> Utf8 Class Initialized
INFO - 2016-02-29 07:40:19 --> URI Class Initialized
DEBUG - 2016-02-29 07:40:19 --> No URI present. Default controller set.
INFO - 2016-02-29 07:40:19 --> Router Class Initialized
INFO - 2016-02-29 07:40:19 --> Output Class Initialized
INFO - 2016-02-29 07:40:19 --> Security Class Initialized
DEBUG - 2016-02-29 07:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:40:19 --> Input Class Initialized
INFO - 2016-02-29 07:40:19 --> Language Class Initialized
INFO - 2016-02-29 07:40:19 --> Loader Class Initialized
INFO - 2016-02-29 07:40:19 --> Helper loaded: url_helper
INFO - 2016-02-29 07:40:19 --> Helper loaded: file_helper
INFO - 2016-02-29 07:40:19 --> Helper loaded: date_helper
INFO - 2016-02-29 07:40:19 --> Helper loaded: form_helper
INFO - 2016-02-29 07:40:19 --> Database Driver Class Initialized
INFO - 2016-02-29 07:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:40:20 --> Controller Class Initialized
INFO - 2016-02-29 07:40:20 --> Model Class Initialized
INFO - 2016-02-29 07:40:20 --> Model Class Initialized
INFO - 2016-02-29 07:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:40:20 --> Pagination Class Initialized
INFO - 2016-02-29 07:40:20 --> Helper loaded: text_helper
INFO - 2016-02-29 07:40:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:40:20 --> Final output sent to browser
DEBUG - 2016-02-29 10:40:20 --> Total execution time: 1.1407
INFO - 2016-02-29 07:40:25 --> Config Class Initialized
INFO - 2016-02-29 07:40:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:40:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:40:25 --> Utf8 Class Initialized
INFO - 2016-02-29 07:40:25 --> URI Class Initialized
INFO - 2016-02-29 07:40:25 --> Router Class Initialized
INFO - 2016-02-29 07:40:25 --> Output Class Initialized
INFO - 2016-02-29 07:40:25 --> Security Class Initialized
DEBUG - 2016-02-29 07:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:40:25 --> Input Class Initialized
INFO - 2016-02-29 07:40:25 --> Language Class Initialized
INFO - 2016-02-29 07:40:25 --> Loader Class Initialized
INFO - 2016-02-29 07:40:25 --> Helper loaded: url_helper
INFO - 2016-02-29 07:40:25 --> Helper loaded: file_helper
INFO - 2016-02-29 07:40:25 --> Helper loaded: date_helper
INFO - 2016-02-29 07:40:25 --> Helper loaded: form_helper
INFO - 2016-02-29 07:40:25 --> Database Driver Class Initialized
INFO - 2016-02-29 07:40:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:40:26 --> Controller Class Initialized
INFO - 2016-02-29 07:40:26 --> Model Class Initialized
INFO - 2016-02-29 07:40:26 --> Model Class Initialized
INFO - 2016-02-29 07:40:26 --> Form Validation Class Initialized
INFO - 2016-02-29 07:40:26 --> Helper loaded: text_helper
INFO - 2016-02-29 07:40:26 --> Final output sent to browser
DEBUG - 2016-02-29 07:40:26 --> Total execution time: 1.0761
INFO - 2016-02-29 07:41:24 --> Config Class Initialized
INFO - 2016-02-29 07:41:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:41:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:41:24 --> Utf8 Class Initialized
INFO - 2016-02-29 07:41:24 --> URI Class Initialized
INFO - 2016-02-29 07:41:24 --> Router Class Initialized
INFO - 2016-02-29 07:41:24 --> Output Class Initialized
INFO - 2016-02-29 07:41:24 --> Security Class Initialized
DEBUG - 2016-02-29 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:41:24 --> Input Class Initialized
INFO - 2016-02-29 07:41:24 --> Language Class Initialized
INFO - 2016-02-29 07:41:24 --> Loader Class Initialized
INFO - 2016-02-29 07:41:24 --> Helper loaded: url_helper
INFO - 2016-02-29 07:41:24 --> Helper loaded: file_helper
INFO - 2016-02-29 07:41:24 --> Helper loaded: date_helper
INFO - 2016-02-29 07:41:24 --> Helper loaded: form_helper
INFO - 2016-02-29 07:41:24 --> Database Driver Class Initialized
INFO - 2016-02-29 07:41:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:41:25 --> Controller Class Initialized
INFO - 2016-02-29 07:41:25 --> Model Class Initialized
INFO - 2016-02-29 07:41:25 --> Model Class Initialized
INFO - 2016-02-29 07:41:25 --> Form Validation Class Initialized
INFO - 2016-02-29 07:41:25 --> Helper loaded: text_helper
INFO - 2016-02-29 07:41:25 --> Final output sent to browser
DEBUG - 2016-02-29 07:41:25 --> Total execution time: 1.1930
INFO - 2016-02-29 07:41:32 --> Config Class Initialized
INFO - 2016-02-29 07:41:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:41:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:41:32 --> Utf8 Class Initialized
INFO - 2016-02-29 07:41:32 --> URI Class Initialized
INFO - 2016-02-29 07:41:32 --> Router Class Initialized
INFO - 2016-02-29 07:41:32 --> Output Class Initialized
INFO - 2016-02-29 07:41:32 --> Security Class Initialized
DEBUG - 2016-02-29 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:41:32 --> Input Class Initialized
INFO - 2016-02-29 07:41:32 --> Language Class Initialized
INFO - 2016-02-29 07:41:32 --> Loader Class Initialized
INFO - 2016-02-29 07:41:32 --> Helper loaded: url_helper
INFO - 2016-02-29 07:41:32 --> Helper loaded: file_helper
INFO - 2016-02-29 07:41:32 --> Helper loaded: date_helper
INFO - 2016-02-29 07:41:32 --> Helper loaded: form_helper
INFO - 2016-02-29 07:41:32 --> Database Driver Class Initialized
INFO - 2016-02-29 07:41:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:41:33 --> Controller Class Initialized
INFO - 2016-02-29 07:41:33 --> Model Class Initialized
INFO - 2016-02-29 07:41:33 --> Model Class Initialized
INFO - 2016-02-29 07:41:33 --> Form Validation Class Initialized
INFO - 2016-02-29 07:41:33 --> Helper loaded: text_helper
INFO - 2016-02-29 07:41:33 --> Final output sent to browser
DEBUG - 2016-02-29 07:41:33 --> Total execution time: 1.2083
INFO - 2016-02-29 07:45:44 --> Config Class Initialized
INFO - 2016-02-29 07:45:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:45:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:45:44 --> Utf8 Class Initialized
INFO - 2016-02-29 07:45:44 --> URI Class Initialized
DEBUG - 2016-02-29 07:45:44 --> No URI present. Default controller set.
INFO - 2016-02-29 07:45:44 --> Router Class Initialized
INFO - 2016-02-29 07:45:44 --> Output Class Initialized
INFO - 2016-02-29 07:45:44 --> Security Class Initialized
DEBUG - 2016-02-29 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:45:44 --> Input Class Initialized
INFO - 2016-02-29 07:45:44 --> Language Class Initialized
INFO - 2016-02-29 07:45:44 --> Loader Class Initialized
INFO - 2016-02-29 07:45:44 --> Helper loaded: url_helper
INFO - 2016-02-29 07:45:44 --> Helper loaded: file_helper
INFO - 2016-02-29 07:45:44 --> Helper loaded: date_helper
INFO - 2016-02-29 07:45:44 --> Helper loaded: form_helper
INFO - 2016-02-29 07:45:44 --> Database Driver Class Initialized
INFO - 2016-02-29 07:45:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:45:45 --> Controller Class Initialized
INFO - 2016-02-29 07:45:45 --> Model Class Initialized
INFO - 2016-02-29 07:45:45 --> Model Class Initialized
INFO - 2016-02-29 07:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:45:45 --> Pagination Class Initialized
INFO - 2016-02-29 07:45:45 --> Helper loaded: text_helper
INFO - 2016-02-29 07:45:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:45:46 --> Final output sent to browser
DEBUG - 2016-02-29 10:45:46 --> Total execution time: 1.1417
INFO - 2016-02-29 07:45:47 --> Config Class Initialized
INFO - 2016-02-29 07:45:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:45:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:45:47 --> Utf8 Class Initialized
INFO - 2016-02-29 07:45:47 --> URI Class Initialized
INFO - 2016-02-29 07:45:47 --> Router Class Initialized
INFO - 2016-02-29 07:45:47 --> Output Class Initialized
INFO - 2016-02-29 07:45:47 --> Security Class Initialized
DEBUG - 2016-02-29 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:45:47 --> Input Class Initialized
INFO - 2016-02-29 07:45:47 --> Language Class Initialized
INFO - 2016-02-29 07:45:47 --> Loader Class Initialized
INFO - 2016-02-29 07:45:47 --> Helper loaded: url_helper
INFO - 2016-02-29 07:45:47 --> Helper loaded: file_helper
INFO - 2016-02-29 07:45:47 --> Helper loaded: date_helper
INFO - 2016-02-29 07:45:47 --> Helper loaded: form_helper
INFO - 2016-02-29 07:45:47 --> Database Driver Class Initialized
INFO - 2016-02-29 07:45:48 --> Config Class Initialized
INFO - 2016-02-29 07:45:48 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:45:48 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:45:48 --> Utf8 Class Initialized
INFO - 2016-02-29 07:45:48 --> URI Class Initialized
INFO - 2016-02-29 07:45:48 --> Router Class Initialized
INFO - 2016-02-29 07:45:48 --> Output Class Initialized
INFO - 2016-02-29 07:45:48 --> Security Class Initialized
DEBUG - 2016-02-29 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:45:48 --> Input Class Initialized
INFO - 2016-02-29 07:45:48 --> Language Class Initialized
INFO - 2016-02-29 07:45:48 --> Loader Class Initialized
INFO - 2016-02-29 07:45:48 --> Helper loaded: url_helper
INFO - 2016-02-29 07:45:48 --> Helper loaded: file_helper
INFO - 2016-02-29 07:45:48 --> Helper loaded: date_helper
INFO - 2016-02-29 07:45:48 --> Helper loaded: form_helper
INFO - 2016-02-29 07:45:48 --> Database Driver Class Initialized
INFO - 2016-02-29 07:45:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:45:48 --> Controller Class Initialized
INFO - 2016-02-29 07:45:48 --> Model Class Initialized
INFO - 2016-02-29 07:45:48 --> Model Class Initialized
INFO - 2016-02-29 07:45:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:45:48 --> Pagination Class Initialized
INFO - 2016-02-29 07:45:48 --> Helper loaded: text_helper
INFO - 2016-02-29 07:45:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:45:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:45:48 --> Final output sent to browser
DEBUG - 2016-02-29 10:45:48 --> Total execution time: 1.1221
INFO - 2016-02-29 07:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:45:49 --> Controller Class Initialized
INFO - 2016-02-29 07:45:49 --> Model Class Initialized
INFO - 2016-02-29 07:45:49 --> Model Class Initialized
INFO - 2016-02-29 07:45:49 --> Form Validation Class Initialized
INFO - 2016-02-29 07:45:49 --> Helper loaded: text_helper
INFO - 2016-02-29 07:45:49 --> Config Class Initialized
INFO - 2016-02-29 07:45:49 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:45:49 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:45:49 --> Utf8 Class Initialized
INFO - 2016-02-29 07:45:49 --> URI Class Initialized
DEBUG - 2016-02-29 07:45:49 --> No URI present. Default controller set.
INFO - 2016-02-29 07:45:49 --> Router Class Initialized
INFO - 2016-02-29 07:45:49 --> Output Class Initialized
INFO - 2016-02-29 07:45:49 --> Security Class Initialized
DEBUG - 2016-02-29 07:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:45:49 --> Input Class Initialized
INFO - 2016-02-29 07:45:49 --> Language Class Initialized
INFO - 2016-02-29 07:45:49 --> Loader Class Initialized
INFO - 2016-02-29 07:45:49 --> Helper loaded: url_helper
INFO - 2016-02-29 07:45:49 --> Helper loaded: file_helper
INFO - 2016-02-29 07:45:49 --> Helper loaded: date_helper
INFO - 2016-02-29 07:45:49 --> Helper loaded: form_helper
INFO - 2016-02-29 07:45:49 --> Database Driver Class Initialized
INFO - 2016-02-29 07:45:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:45:50 --> Controller Class Initialized
INFO - 2016-02-29 07:45:50 --> Model Class Initialized
INFO - 2016-02-29 07:45:50 --> Model Class Initialized
INFO - 2016-02-29 07:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:45:50 --> Pagination Class Initialized
INFO - 2016-02-29 07:45:50 --> Helper loaded: text_helper
INFO - 2016-02-29 07:45:50 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:45:50 --> Final output sent to browser
DEBUG - 2016-02-29 10:45:50 --> Total execution time: 1.1103
INFO - 2016-02-29 07:46:00 --> Config Class Initialized
INFO - 2016-02-29 07:46:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:00 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:00 --> URI Class Initialized
INFO - 2016-02-29 07:46:00 --> Router Class Initialized
INFO - 2016-02-29 07:46:00 --> Output Class Initialized
INFO - 2016-02-29 07:46:00 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:00 --> Input Class Initialized
INFO - 2016-02-29 07:46:00 --> Language Class Initialized
INFO - 2016-02-29 07:46:00 --> Loader Class Initialized
INFO - 2016-02-29 07:46:00 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:00 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:00 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:00 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:00 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:01 --> Controller Class Initialized
INFO - 2016-02-29 07:46:01 --> Model Class Initialized
INFO - 2016-02-29 07:46:01 --> Model Class Initialized
INFO - 2016-02-29 07:46:01 --> Form Validation Class Initialized
INFO - 2016-02-29 07:46:01 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:01 --> Final output sent to browser
DEBUG - 2016-02-29 07:46:01 --> Total execution time: 1.1570
INFO - 2016-02-29 07:46:15 --> Config Class Initialized
INFO - 2016-02-29 07:46:15 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:15 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:15 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:15 --> URI Class Initialized
INFO - 2016-02-29 07:46:15 --> Router Class Initialized
INFO - 2016-02-29 07:46:15 --> Output Class Initialized
INFO - 2016-02-29 07:46:15 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:15 --> Input Class Initialized
INFO - 2016-02-29 07:46:15 --> Language Class Initialized
INFO - 2016-02-29 07:46:15 --> Loader Class Initialized
INFO - 2016-02-29 07:46:15 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:15 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:15 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:15 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:15 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:16 --> Controller Class Initialized
INFO - 2016-02-29 07:46:16 --> Model Class Initialized
INFO - 2016-02-29 07:46:16 --> Model Class Initialized
INFO - 2016-02-29 07:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:46:16 --> Pagination Class Initialized
INFO - 2016-02-29 07:46:16 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:16 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:46:16 --> Final output sent to browser
DEBUG - 2016-02-29 10:46:16 --> Total execution time: 1.1173
INFO - 2016-02-29 07:46:17 --> Config Class Initialized
INFO - 2016-02-29 07:46:17 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:17 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:17 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:17 --> URI Class Initialized
INFO - 2016-02-29 07:46:17 --> Router Class Initialized
INFO - 2016-02-29 07:46:17 --> Output Class Initialized
INFO - 2016-02-29 07:46:17 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:17 --> Input Class Initialized
INFO - 2016-02-29 07:46:17 --> Language Class Initialized
INFO - 2016-02-29 07:46:17 --> Loader Class Initialized
INFO - 2016-02-29 07:46:17 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:17 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:17 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:17 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:17 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:18 --> Controller Class Initialized
INFO - 2016-02-29 07:46:18 --> Model Class Initialized
INFO - 2016-02-29 07:46:18 --> Model Class Initialized
INFO - 2016-02-29 07:46:19 --> Form Validation Class Initialized
INFO - 2016-02-29 07:46:19 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:19 --> Config Class Initialized
INFO - 2016-02-29 07:46:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:19 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:19 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:19 --> URI Class Initialized
DEBUG - 2016-02-29 07:46:19 --> No URI present. Default controller set.
INFO - 2016-02-29 07:46:19 --> Router Class Initialized
INFO - 2016-02-29 07:46:19 --> Output Class Initialized
INFO - 2016-02-29 07:46:19 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:19 --> Input Class Initialized
INFO - 2016-02-29 07:46:19 --> Language Class Initialized
INFO - 2016-02-29 07:46:19 --> Loader Class Initialized
INFO - 2016-02-29 07:46:19 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:19 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:19 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:19 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:19 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:20 --> Controller Class Initialized
INFO - 2016-02-29 07:46:20 --> Model Class Initialized
INFO - 2016-02-29 07:46:20 --> Model Class Initialized
INFO - 2016-02-29 07:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:46:20 --> Pagination Class Initialized
INFO - 2016-02-29 07:46:20 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:46:20 --> Final output sent to browser
DEBUG - 2016-02-29 10:46:20 --> Total execution time: 1.1198
INFO - 2016-02-29 07:46:22 --> Config Class Initialized
INFO - 2016-02-29 07:46:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:22 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:22 --> URI Class Initialized
INFO - 2016-02-29 07:46:22 --> Router Class Initialized
INFO - 2016-02-29 07:46:22 --> Output Class Initialized
INFO - 2016-02-29 07:46:22 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:22 --> Input Class Initialized
INFO - 2016-02-29 07:46:22 --> Language Class Initialized
INFO - 2016-02-29 07:46:22 --> Loader Class Initialized
INFO - 2016-02-29 07:46:22 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:22 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:22 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:22 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:22 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:23 --> Controller Class Initialized
INFO - 2016-02-29 07:46:23 --> Model Class Initialized
INFO - 2016-02-29 07:46:23 --> Model Class Initialized
INFO - 2016-02-29 07:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:46:23 --> Pagination Class Initialized
INFO - 2016-02-29 07:46:23 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:23 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:46:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:46:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:46:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:46:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:46:23 --> Final output sent to browser
DEBUG - 2016-02-29 10:46:23 --> Total execution time: 1.1364
INFO - 2016-02-29 07:46:24 --> Config Class Initialized
INFO - 2016-02-29 07:46:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:24 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:24 --> URI Class Initialized
INFO - 2016-02-29 07:46:24 --> Router Class Initialized
INFO - 2016-02-29 07:46:24 --> Output Class Initialized
INFO - 2016-02-29 07:46:24 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:24 --> Input Class Initialized
INFO - 2016-02-29 07:46:24 --> Language Class Initialized
INFO - 2016-02-29 07:46:24 --> Loader Class Initialized
INFO - 2016-02-29 07:46:24 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:24 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:24 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:24 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:24 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:25 --> Controller Class Initialized
INFO - 2016-02-29 07:46:25 --> Model Class Initialized
INFO - 2016-02-29 07:46:25 --> Model Class Initialized
INFO - 2016-02-29 07:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:46:25 --> Pagination Class Initialized
INFO - 2016-02-29 07:46:25 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 10:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 10:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:46:25 --> Final output sent to browser
DEBUG - 2016-02-29 10:46:25 --> Total execution time: 1.2213
INFO - 2016-02-29 07:46:42 --> Config Class Initialized
INFO - 2016-02-29 07:46:42 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:46:42 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:46:42 --> Utf8 Class Initialized
INFO - 2016-02-29 07:46:42 --> URI Class Initialized
INFO - 2016-02-29 07:46:42 --> Router Class Initialized
INFO - 2016-02-29 07:46:42 --> Output Class Initialized
INFO - 2016-02-29 07:46:42 --> Security Class Initialized
DEBUG - 2016-02-29 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:46:42 --> Input Class Initialized
INFO - 2016-02-29 07:46:42 --> Language Class Initialized
INFO - 2016-02-29 07:46:42 --> Loader Class Initialized
INFO - 2016-02-29 07:46:42 --> Helper loaded: url_helper
INFO - 2016-02-29 07:46:42 --> Helper loaded: file_helper
INFO - 2016-02-29 07:46:42 --> Helper loaded: date_helper
INFO - 2016-02-29 07:46:42 --> Helper loaded: form_helper
INFO - 2016-02-29 07:46:42 --> Database Driver Class Initialized
INFO - 2016-02-29 07:46:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:46:43 --> Controller Class Initialized
INFO - 2016-02-29 07:46:43 --> Model Class Initialized
INFO - 2016-02-29 07:46:43 --> Model Class Initialized
INFO - 2016-02-29 07:46:43 --> Form Validation Class Initialized
INFO - 2016-02-29 07:46:43 --> Helper loaded: text_helper
INFO - 2016-02-29 07:46:43 --> Final output sent to browser
DEBUG - 2016-02-29 07:46:43 --> Total execution time: 1.1549
INFO - 2016-02-29 07:48:02 --> Config Class Initialized
INFO - 2016-02-29 07:48:02 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:02 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:02 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:02 --> URI Class Initialized
DEBUG - 2016-02-29 07:48:02 --> No URI present. Default controller set.
INFO - 2016-02-29 07:48:02 --> Router Class Initialized
INFO - 2016-02-29 07:48:02 --> Output Class Initialized
INFO - 2016-02-29 07:48:02 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:02 --> Input Class Initialized
INFO - 2016-02-29 07:48:02 --> Language Class Initialized
INFO - 2016-02-29 07:48:02 --> Loader Class Initialized
INFO - 2016-02-29 07:48:02 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:02 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:02 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:02 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:02 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:03 --> Controller Class Initialized
INFO - 2016-02-29 07:48:03 --> Model Class Initialized
INFO - 2016-02-29 07:48:03 --> Model Class Initialized
INFO - 2016-02-29 07:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:03 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:03 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:03 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:03 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:03 --> Total execution time: 1.1197
INFO - 2016-02-29 07:48:05 --> Config Class Initialized
INFO - 2016-02-29 07:48:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:05 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:05 --> URI Class Initialized
INFO - 2016-02-29 07:48:05 --> Router Class Initialized
INFO - 2016-02-29 07:48:05 --> Output Class Initialized
INFO - 2016-02-29 07:48:05 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:05 --> Input Class Initialized
INFO - 2016-02-29 07:48:05 --> Language Class Initialized
INFO - 2016-02-29 07:48:05 --> Loader Class Initialized
INFO - 2016-02-29 07:48:05 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:05 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:05 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:05 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:05 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:06 --> Controller Class Initialized
INFO - 2016-02-29 07:48:06 --> Model Class Initialized
INFO - 2016-02-29 07:48:06 --> Model Class Initialized
INFO - 2016-02-29 07:48:06 --> Form Validation Class Initialized
INFO - 2016-02-29 07:48:06 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:06 --> Config Class Initialized
INFO - 2016-02-29 07:48:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:06 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:06 --> URI Class Initialized
DEBUG - 2016-02-29 07:48:06 --> No URI present. Default controller set.
INFO - 2016-02-29 07:48:06 --> Router Class Initialized
INFO - 2016-02-29 07:48:06 --> Output Class Initialized
INFO - 2016-02-29 07:48:06 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:06 --> Input Class Initialized
INFO - 2016-02-29 07:48:06 --> Language Class Initialized
INFO - 2016-02-29 07:48:06 --> Loader Class Initialized
INFO - 2016-02-29 07:48:06 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:06 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:06 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:06 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:06 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:07 --> Config Class Initialized
INFO - 2016-02-29 07:48:07 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:07 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:07 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:07 --> URI Class Initialized
INFO - 2016-02-29 07:48:07 --> Router Class Initialized
INFO - 2016-02-29 07:48:07 --> Output Class Initialized
INFO - 2016-02-29 07:48:07 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:07 --> Input Class Initialized
INFO - 2016-02-29 07:48:07 --> Language Class Initialized
INFO - 2016-02-29 07:48:07 --> Loader Class Initialized
INFO - 2016-02-29 07:48:07 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:07 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:07 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:07 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:07 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:07 --> Controller Class Initialized
INFO - 2016-02-29 07:48:07 --> Model Class Initialized
INFO - 2016-02-29 07:48:07 --> Model Class Initialized
INFO - 2016-02-29 07:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:07 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:07 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:07 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:07 --> Total execution time: 1.1633
INFO - 2016-02-29 07:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:08 --> Controller Class Initialized
INFO - 2016-02-29 07:48:08 --> Model Class Initialized
INFO - 2016-02-29 07:48:08 --> Model Class Initialized
INFO - 2016-02-29 07:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:08 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:08 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:08 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:08 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:08 --> Total execution time: 1.1297
INFO - 2016-02-29 07:48:10 --> Config Class Initialized
INFO - 2016-02-29 07:48:10 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:10 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:10 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:10 --> URI Class Initialized
INFO - 2016-02-29 07:48:10 --> Router Class Initialized
INFO - 2016-02-29 07:48:10 --> Output Class Initialized
INFO - 2016-02-29 07:48:10 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:10 --> Input Class Initialized
INFO - 2016-02-29 07:48:10 --> Language Class Initialized
INFO - 2016-02-29 07:48:10 --> Loader Class Initialized
INFO - 2016-02-29 07:48:10 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:10 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:10 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:10 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:10 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:11 --> Controller Class Initialized
INFO - 2016-02-29 07:48:11 --> Model Class Initialized
INFO - 2016-02-29 07:48:11 --> Model Class Initialized
INFO - 2016-02-29 07:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:11 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:11 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:11 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 10:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 10:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:11 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:11 --> Total execution time: 1.1748
INFO - 2016-02-29 07:48:20 --> Config Class Initialized
INFO - 2016-02-29 07:48:20 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:20 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:20 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:20 --> URI Class Initialized
INFO - 2016-02-29 07:48:20 --> Router Class Initialized
INFO - 2016-02-29 07:48:20 --> Output Class Initialized
INFO - 2016-02-29 07:48:20 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:20 --> Input Class Initialized
INFO - 2016-02-29 07:48:20 --> Language Class Initialized
INFO - 2016-02-29 07:48:20 --> Loader Class Initialized
INFO - 2016-02-29 07:48:20 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:20 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:20 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:20 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:20 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:21 --> Controller Class Initialized
INFO - 2016-02-29 07:48:21 --> Model Class Initialized
INFO - 2016-02-29 07:48:21 --> Model Class Initialized
INFO - 2016-02-29 07:48:21 --> Form Validation Class Initialized
INFO - 2016-02-29 07:48:21 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:21 --> Final output sent to browser
DEBUG - 2016-02-29 07:48:21 --> Total execution time: 1.1810
INFO - 2016-02-29 07:48:21 --> Config Class Initialized
INFO - 2016-02-29 07:48:21 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:21 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:21 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:21 --> URI Class Initialized
INFO - 2016-02-29 07:48:21 --> Router Class Initialized
INFO - 2016-02-29 07:48:21 --> Output Class Initialized
INFO - 2016-02-29 07:48:21 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:21 --> Input Class Initialized
INFO - 2016-02-29 07:48:21 --> Language Class Initialized
INFO - 2016-02-29 07:48:21 --> Loader Class Initialized
INFO - 2016-02-29 07:48:21 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:21 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:21 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:21 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:21 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:22 --> Controller Class Initialized
INFO - 2016-02-29 07:48:22 --> Model Class Initialized
INFO - 2016-02-29 07:48:22 --> Model Class Initialized
INFO - 2016-02-29 07:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:22 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:22 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:22 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 10:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 10:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:22 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:22 --> Total execution time: 1.1775
INFO - 2016-02-29 07:48:32 --> Config Class Initialized
INFO - 2016-02-29 07:48:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:32 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:32 --> URI Class Initialized
INFO - 2016-02-29 07:48:32 --> Router Class Initialized
INFO - 2016-02-29 07:48:32 --> Output Class Initialized
INFO - 2016-02-29 07:48:32 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:32 --> Input Class Initialized
INFO - 2016-02-29 07:48:32 --> Language Class Initialized
INFO - 2016-02-29 07:48:32 --> Loader Class Initialized
INFO - 2016-02-29 07:48:32 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:32 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:32 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:32 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:32 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:33 --> Controller Class Initialized
INFO - 2016-02-29 07:48:33 --> Model Class Initialized
INFO - 2016-02-29 07:48:33 --> Model Class Initialized
INFO - 2016-02-29 07:48:33 --> Form Validation Class Initialized
INFO - 2016-02-29 07:48:33 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:33 --> Config Class Initialized
INFO - 2016-02-29 07:48:33 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:33 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:33 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:33 --> URI Class Initialized
DEBUG - 2016-02-29 07:48:33 --> No URI present. Default controller set.
INFO - 2016-02-29 07:48:33 --> Router Class Initialized
INFO - 2016-02-29 07:48:33 --> Output Class Initialized
INFO - 2016-02-29 07:48:33 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:33 --> Input Class Initialized
INFO - 2016-02-29 07:48:33 --> Language Class Initialized
INFO - 2016-02-29 07:48:33 --> Loader Class Initialized
INFO - 2016-02-29 07:48:33 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:33 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:33 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:33 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:33 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:34 --> Controller Class Initialized
INFO - 2016-02-29 07:48:34 --> Model Class Initialized
INFO - 2016-02-29 07:48:34 --> Model Class Initialized
INFO - 2016-02-29 07:48:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:34 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:34 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:34 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:48:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:34 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:34 --> Total execution time: 1.1002
INFO - 2016-02-29 07:48:40 --> Config Class Initialized
INFO - 2016-02-29 07:48:40 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:40 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:40 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:40 --> URI Class Initialized
INFO - 2016-02-29 07:48:40 --> Router Class Initialized
INFO - 2016-02-29 07:48:40 --> Output Class Initialized
INFO - 2016-02-29 07:48:40 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:40 --> Input Class Initialized
INFO - 2016-02-29 07:48:40 --> Language Class Initialized
INFO - 2016-02-29 07:48:40 --> Loader Class Initialized
INFO - 2016-02-29 07:48:40 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:40 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:40 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:40 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:40 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:41 --> Controller Class Initialized
INFO - 2016-02-29 07:48:41 --> Model Class Initialized
INFO - 2016-02-29 07:48:41 --> Model Class Initialized
INFO - 2016-02-29 07:48:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:41 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:41 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:41 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:48:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:41 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:41 --> Total execution time: 1.1169
INFO - 2016-02-29 07:48:43 --> Config Class Initialized
INFO - 2016-02-29 07:48:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:43 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:43 --> URI Class Initialized
INFO - 2016-02-29 07:48:43 --> Router Class Initialized
INFO - 2016-02-29 07:48:43 --> Output Class Initialized
INFO - 2016-02-29 07:48:43 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:43 --> Input Class Initialized
INFO - 2016-02-29 07:48:43 --> Language Class Initialized
INFO - 2016-02-29 07:48:43 --> Loader Class Initialized
INFO - 2016-02-29 07:48:43 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:43 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:43 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:43 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:43 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:44 --> Controller Class Initialized
INFO - 2016-02-29 07:48:44 --> Model Class Initialized
INFO - 2016-02-29 07:48:44 --> Model Class Initialized
INFO - 2016-02-29 07:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:44 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:44 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:44 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 10:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:44 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:44 --> Total execution time: 1.1037
INFO - 2016-02-29 07:48:47 --> Config Class Initialized
INFO - 2016-02-29 07:48:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:47 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:47 --> URI Class Initialized
INFO - 2016-02-29 07:48:47 --> Router Class Initialized
INFO - 2016-02-29 07:48:47 --> Output Class Initialized
INFO - 2016-02-29 07:48:47 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:47 --> Input Class Initialized
INFO - 2016-02-29 07:48:47 --> Language Class Initialized
INFO - 2016-02-29 07:48:47 --> Loader Class Initialized
INFO - 2016-02-29 07:48:47 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:47 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:47 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:47 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:47 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:48 --> Controller Class Initialized
INFO - 2016-02-29 07:48:48 --> Model Class Initialized
INFO - 2016-02-29 07:48:48 --> Model Class Initialized
INFO - 2016-02-29 07:48:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:48 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:48 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 10:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 10:48:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:48:48 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:48 --> Total execution time: 1.2631
INFO - 2016-02-29 07:48:56 --> Config Class Initialized
INFO - 2016-02-29 07:48:56 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:48:56 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:48:56 --> Utf8 Class Initialized
INFO - 2016-02-29 07:48:56 --> URI Class Initialized
INFO - 2016-02-29 07:48:56 --> Router Class Initialized
INFO - 2016-02-29 07:48:56 --> Output Class Initialized
INFO - 2016-02-29 07:48:56 --> Security Class Initialized
DEBUG - 2016-02-29 07:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:48:56 --> Input Class Initialized
INFO - 2016-02-29 07:48:56 --> Language Class Initialized
INFO - 2016-02-29 07:48:56 --> Loader Class Initialized
INFO - 2016-02-29 07:48:56 --> Helper loaded: url_helper
INFO - 2016-02-29 07:48:56 --> Helper loaded: file_helper
INFO - 2016-02-29 07:48:56 --> Helper loaded: date_helper
INFO - 2016-02-29 07:48:56 --> Helper loaded: form_helper
INFO - 2016-02-29 07:48:56 --> Database Driver Class Initialized
INFO - 2016-02-29 07:48:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:48:57 --> Controller Class Initialized
INFO - 2016-02-29 07:48:57 --> Model Class Initialized
INFO - 2016-02-29 07:48:57 --> Model Class Initialized
INFO - 2016-02-29 07:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:48:57 --> Pagination Class Initialized
INFO - 2016-02-29 07:48:57 --> Helper loaded: text_helper
INFO - 2016-02-29 07:48:57 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:48:57 --> Final output sent to browser
DEBUG - 2016-02-29 10:48:57 --> Total execution time: 1.0890
INFO - 2016-02-29 07:49:18 --> Config Class Initialized
INFO - 2016-02-29 07:49:18 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:49:18 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:49:18 --> Utf8 Class Initialized
INFO - 2016-02-29 07:49:18 --> URI Class Initialized
INFO - 2016-02-29 07:49:18 --> Router Class Initialized
INFO - 2016-02-29 07:49:18 --> Output Class Initialized
INFO - 2016-02-29 07:49:18 --> Security Class Initialized
DEBUG - 2016-02-29 07:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:49:18 --> Input Class Initialized
INFO - 2016-02-29 07:49:18 --> Language Class Initialized
INFO - 2016-02-29 07:49:18 --> Loader Class Initialized
INFO - 2016-02-29 07:49:18 --> Helper loaded: url_helper
INFO - 2016-02-29 07:49:18 --> Helper loaded: file_helper
INFO - 2016-02-29 07:49:18 --> Helper loaded: date_helper
INFO - 2016-02-29 07:49:18 --> Helper loaded: form_helper
INFO - 2016-02-29 07:49:18 --> Database Driver Class Initialized
INFO - 2016-02-29 07:49:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:49:19 --> Controller Class Initialized
INFO - 2016-02-29 07:49:19 --> Model Class Initialized
INFO - 2016-02-29 07:49:19 --> Model Class Initialized
INFO - 2016-02-29 07:49:19 --> Form Validation Class Initialized
INFO - 2016-02-29 07:49:19 --> Helper loaded: text_helper
INFO - 2016-02-29 07:49:19 --> Final output sent to browser
DEBUG - 2016-02-29 07:49:19 --> Total execution time: 1.1833
INFO - 2016-02-29 07:49:19 --> Config Class Initialized
INFO - 2016-02-29 07:49:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:49:19 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:49:19 --> Utf8 Class Initialized
INFO - 2016-02-29 07:49:19 --> URI Class Initialized
INFO - 2016-02-29 07:49:19 --> Router Class Initialized
INFO - 2016-02-29 07:49:19 --> Output Class Initialized
INFO - 2016-02-29 07:49:19 --> Security Class Initialized
DEBUG - 2016-02-29 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:49:19 --> Input Class Initialized
INFO - 2016-02-29 07:49:19 --> Language Class Initialized
INFO - 2016-02-29 07:49:19 --> Loader Class Initialized
INFO - 2016-02-29 07:49:19 --> Helper loaded: url_helper
INFO - 2016-02-29 07:49:19 --> Helper loaded: file_helper
INFO - 2016-02-29 07:49:19 --> Helper loaded: date_helper
INFO - 2016-02-29 07:49:19 --> Helper loaded: form_helper
INFO - 2016-02-29 07:49:19 --> Database Driver Class Initialized
INFO - 2016-02-29 07:49:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:49:20 --> Controller Class Initialized
INFO - 2016-02-29 07:49:20 --> Model Class Initialized
INFO - 2016-02-29 07:49:20 --> Model Class Initialized
INFO - 2016-02-29 07:49:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:49:20 --> Pagination Class Initialized
INFO - 2016-02-29 07:49:20 --> Helper loaded: text_helper
INFO - 2016-02-29 07:49:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 10:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 10:49:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:49:20 --> Final output sent to browser
DEBUG - 2016-02-29 10:49:20 --> Total execution time: 1.1773
INFO - 2016-02-29 07:50:06 --> Config Class Initialized
INFO - 2016-02-29 07:50:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:50:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:50:06 --> Utf8 Class Initialized
INFO - 2016-02-29 07:50:06 --> URI Class Initialized
DEBUG - 2016-02-29 07:50:06 --> No URI present. Default controller set.
INFO - 2016-02-29 07:50:06 --> Router Class Initialized
INFO - 2016-02-29 07:50:06 --> Output Class Initialized
INFO - 2016-02-29 07:50:06 --> Security Class Initialized
DEBUG - 2016-02-29 07:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:50:06 --> Input Class Initialized
INFO - 2016-02-29 07:50:06 --> Language Class Initialized
INFO - 2016-02-29 07:50:06 --> Loader Class Initialized
INFO - 2016-02-29 07:50:06 --> Helper loaded: url_helper
INFO - 2016-02-29 07:50:06 --> Helper loaded: file_helper
INFO - 2016-02-29 07:50:06 --> Helper loaded: date_helper
INFO - 2016-02-29 07:50:06 --> Helper loaded: form_helper
INFO - 2016-02-29 07:50:06 --> Database Driver Class Initialized
INFO - 2016-02-29 07:50:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:50:07 --> Controller Class Initialized
INFO - 2016-02-29 07:50:07 --> Model Class Initialized
INFO - 2016-02-29 07:50:07 --> Model Class Initialized
INFO - 2016-02-29 07:50:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:50:07 --> Pagination Class Initialized
INFO - 2016-02-29 07:50:07 --> Helper loaded: text_helper
INFO - 2016-02-29 07:50:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:50:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:50:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:50:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:50:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:50:07 --> Final output sent to browser
DEBUG - 2016-02-29 10:50:07 --> Total execution time: 1.1472
INFO - 2016-02-29 07:50:10 --> Config Class Initialized
INFO - 2016-02-29 07:50:10 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:50:10 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:50:10 --> Utf8 Class Initialized
INFO - 2016-02-29 07:50:10 --> URI Class Initialized
INFO - 2016-02-29 07:50:10 --> Router Class Initialized
INFO - 2016-02-29 07:50:10 --> Output Class Initialized
INFO - 2016-02-29 07:50:10 --> Security Class Initialized
DEBUG - 2016-02-29 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:50:10 --> Input Class Initialized
INFO - 2016-02-29 07:50:10 --> Language Class Initialized
INFO - 2016-02-29 07:50:10 --> Loader Class Initialized
INFO - 2016-02-29 07:50:10 --> Helper loaded: url_helper
INFO - 2016-02-29 07:50:10 --> Helper loaded: file_helper
INFO - 2016-02-29 07:50:10 --> Helper loaded: date_helper
INFO - 2016-02-29 07:50:10 --> Helper loaded: form_helper
INFO - 2016-02-29 07:50:10 --> Database Driver Class Initialized
INFO - 2016-02-29 07:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:50:11 --> Controller Class Initialized
INFO - 2016-02-29 07:50:11 --> Model Class Initialized
INFO - 2016-02-29 07:50:11 --> Model Class Initialized
INFO - 2016-02-29 07:50:11 --> Form Validation Class Initialized
INFO - 2016-02-29 07:50:11 --> Helper loaded: text_helper
INFO - 2016-02-29 07:50:11 --> Config Class Initialized
INFO - 2016-02-29 07:50:11 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:50:11 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:50:11 --> Utf8 Class Initialized
INFO - 2016-02-29 07:50:11 --> URI Class Initialized
DEBUG - 2016-02-29 07:50:11 --> No URI present. Default controller set.
INFO - 2016-02-29 07:50:11 --> Router Class Initialized
INFO - 2016-02-29 07:50:11 --> Output Class Initialized
INFO - 2016-02-29 07:50:11 --> Security Class Initialized
DEBUG - 2016-02-29 07:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:50:11 --> Input Class Initialized
INFO - 2016-02-29 07:50:11 --> Language Class Initialized
INFO - 2016-02-29 07:50:11 --> Loader Class Initialized
INFO - 2016-02-29 07:50:11 --> Helper loaded: url_helper
INFO - 2016-02-29 07:50:11 --> Helper loaded: file_helper
INFO - 2016-02-29 07:50:11 --> Helper loaded: date_helper
INFO - 2016-02-29 07:50:11 --> Helper loaded: form_helper
INFO - 2016-02-29 07:50:11 --> Database Driver Class Initialized
INFO - 2016-02-29 07:50:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:50:12 --> Controller Class Initialized
INFO - 2016-02-29 07:50:12 --> Model Class Initialized
INFO - 2016-02-29 07:50:12 --> Model Class Initialized
INFO - 2016-02-29 07:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:50:12 --> Pagination Class Initialized
INFO - 2016-02-29 07:50:12 --> Helper loaded: text_helper
INFO - 2016-02-29 07:50:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:50:13 --> Final output sent to browser
DEBUG - 2016-02-29 10:50:13 --> Total execution time: 1.1462
INFO - 2016-02-29 07:50:25 --> Config Class Initialized
INFO - 2016-02-29 07:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:50:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:50:25 --> Utf8 Class Initialized
INFO - 2016-02-29 07:50:25 --> URI Class Initialized
INFO - 2016-02-29 07:50:25 --> Router Class Initialized
INFO - 2016-02-29 07:50:25 --> Output Class Initialized
INFO - 2016-02-29 07:50:25 --> Security Class Initialized
DEBUG - 2016-02-29 07:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:50:25 --> Input Class Initialized
INFO - 2016-02-29 07:50:25 --> Language Class Initialized
INFO - 2016-02-29 07:50:25 --> Loader Class Initialized
INFO - 2016-02-29 07:50:25 --> Helper loaded: url_helper
INFO - 2016-02-29 07:50:25 --> Helper loaded: file_helper
INFO - 2016-02-29 07:50:25 --> Helper loaded: date_helper
INFO - 2016-02-29 07:50:25 --> Helper loaded: form_helper
INFO - 2016-02-29 07:50:25 --> Database Driver Class Initialized
INFO - 2016-02-29 07:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:50:26 --> Controller Class Initialized
INFO - 2016-02-29 07:50:26 --> Model Class Initialized
INFO - 2016-02-29 07:50:26 --> Model Class Initialized
INFO - 2016-02-29 07:50:26 --> Form Validation Class Initialized
INFO - 2016-02-29 07:50:26 --> Helper loaded: text_helper
INFO - 2016-02-29 07:50:26 --> Final output sent to browser
DEBUG - 2016-02-29 07:50:26 --> Total execution time: 1.1963
INFO - 2016-02-29 07:50:26 --> Config Class Initialized
INFO - 2016-02-29 07:50:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:50:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:50:26 --> Utf8 Class Initialized
INFO - 2016-02-29 07:50:26 --> URI Class Initialized
DEBUG - 2016-02-29 07:50:26 --> No URI present. Default controller set.
INFO - 2016-02-29 07:50:26 --> Router Class Initialized
INFO - 2016-02-29 07:50:26 --> Output Class Initialized
INFO - 2016-02-29 07:50:26 --> Security Class Initialized
DEBUG - 2016-02-29 07:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:50:26 --> Input Class Initialized
INFO - 2016-02-29 07:50:26 --> Language Class Initialized
INFO - 2016-02-29 07:50:26 --> Loader Class Initialized
INFO - 2016-02-29 07:50:26 --> Helper loaded: url_helper
INFO - 2016-02-29 07:50:26 --> Helper loaded: file_helper
INFO - 2016-02-29 07:50:26 --> Helper loaded: date_helper
INFO - 2016-02-29 07:50:26 --> Helper loaded: form_helper
INFO - 2016-02-29 07:50:26 --> Database Driver Class Initialized
INFO - 2016-02-29 07:50:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:50:27 --> Controller Class Initialized
INFO - 2016-02-29 07:50:27 --> Model Class Initialized
INFO - 2016-02-29 07:50:27 --> Model Class Initialized
INFO - 2016-02-29 07:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:50:27 --> Pagination Class Initialized
INFO - 2016-02-29 07:50:27 --> Helper loaded: text_helper
INFO - 2016-02-29 07:50:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:50:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:50:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:50:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:50:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:50:27 --> Final output sent to browser
DEBUG - 2016-02-29 10:50:27 --> Total execution time: 1.1198
INFO - 2016-02-29 07:53:50 --> Config Class Initialized
INFO - 2016-02-29 07:53:50 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:53:50 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:53:50 --> Utf8 Class Initialized
INFO - 2016-02-29 07:53:50 --> URI Class Initialized
INFO - 2016-02-29 07:53:50 --> Router Class Initialized
INFO - 2016-02-29 07:53:50 --> Output Class Initialized
INFO - 2016-02-29 07:53:50 --> Security Class Initialized
DEBUG - 2016-02-29 07:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:53:50 --> Input Class Initialized
INFO - 2016-02-29 07:53:50 --> Language Class Initialized
INFO - 2016-02-29 07:53:50 --> Loader Class Initialized
INFO - 2016-02-29 07:53:50 --> Helper loaded: url_helper
INFO - 2016-02-29 07:53:50 --> Helper loaded: file_helper
INFO - 2016-02-29 07:53:50 --> Helper loaded: date_helper
INFO - 2016-02-29 07:53:50 --> Helper loaded: form_helper
INFO - 2016-02-29 07:53:50 --> Database Driver Class Initialized
INFO - 2016-02-29 07:53:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:53:51 --> Controller Class Initialized
INFO - 2016-02-29 07:53:51 --> Model Class Initialized
INFO - 2016-02-29 07:53:51 --> Model Class Initialized
INFO - 2016-02-29 07:53:51 --> Form Validation Class Initialized
INFO - 2016-02-29 07:53:51 --> Helper loaded: text_helper
INFO - 2016-02-29 07:53:51 --> Config Class Initialized
INFO - 2016-02-29 07:53:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 07:53:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 07:53:51 --> Utf8 Class Initialized
INFO - 2016-02-29 07:53:51 --> URI Class Initialized
DEBUG - 2016-02-29 07:53:51 --> No URI present. Default controller set.
INFO - 2016-02-29 07:53:51 --> Router Class Initialized
INFO - 2016-02-29 07:53:51 --> Output Class Initialized
INFO - 2016-02-29 07:53:51 --> Security Class Initialized
DEBUG - 2016-02-29 07:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 07:53:51 --> Input Class Initialized
INFO - 2016-02-29 07:53:51 --> Language Class Initialized
INFO - 2016-02-29 07:53:51 --> Loader Class Initialized
INFO - 2016-02-29 07:53:51 --> Helper loaded: url_helper
INFO - 2016-02-29 07:53:51 --> Helper loaded: file_helper
INFO - 2016-02-29 07:53:51 --> Helper loaded: date_helper
INFO - 2016-02-29 07:53:51 --> Helper loaded: form_helper
INFO - 2016-02-29 07:53:51 --> Database Driver Class Initialized
INFO - 2016-02-29 07:53:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 07:53:52 --> Controller Class Initialized
INFO - 2016-02-29 07:53:52 --> Model Class Initialized
INFO - 2016-02-29 07:53:52 --> Model Class Initialized
INFO - 2016-02-29 07:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 07:53:52 --> Pagination Class Initialized
INFO - 2016-02-29 07:53:52 --> Helper loaded: text_helper
INFO - 2016-02-29 07:53:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 10:53:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 10:53:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 10:53:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 10:53:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 10:53:52 --> Final output sent to browser
DEBUG - 2016-02-29 10:53:52 --> Total execution time: 1.1131
INFO - 2016-02-29 08:00:41 --> Config Class Initialized
INFO - 2016-02-29 08:00:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:00:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:00:41 --> Utf8 Class Initialized
INFO - 2016-02-29 08:00:41 --> URI Class Initialized
DEBUG - 2016-02-29 08:00:41 --> No URI present. Default controller set.
INFO - 2016-02-29 08:00:41 --> Router Class Initialized
INFO - 2016-02-29 08:00:41 --> Output Class Initialized
INFO - 2016-02-29 08:00:41 --> Security Class Initialized
DEBUG - 2016-02-29 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:00:41 --> Input Class Initialized
INFO - 2016-02-29 08:00:41 --> Language Class Initialized
INFO - 2016-02-29 08:00:41 --> Loader Class Initialized
INFO - 2016-02-29 08:00:41 --> Helper loaded: url_helper
INFO - 2016-02-29 08:00:41 --> Helper loaded: file_helper
INFO - 2016-02-29 08:00:41 --> Helper loaded: date_helper
INFO - 2016-02-29 08:00:41 --> Helper loaded: form_helper
INFO - 2016-02-29 08:00:41 --> Database Driver Class Initialized
INFO - 2016-02-29 08:00:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:00:42 --> Controller Class Initialized
INFO - 2016-02-29 08:00:42 --> Model Class Initialized
INFO - 2016-02-29 08:00:42 --> Model Class Initialized
INFO - 2016-02-29 08:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:00:42 --> Pagination Class Initialized
INFO - 2016-02-29 08:00:42 --> Helper loaded: text_helper
INFO - 2016-02-29 08:00:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:00:42 --> Final output sent to browser
DEBUG - 2016-02-29 11:00:42 --> Total execution time: 1.1835
INFO - 2016-02-29 08:00:52 --> Config Class Initialized
INFO - 2016-02-29 08:00:52 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:00:52 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:00:52 --> Utf8 Class Initialized
INFO - 2016-02-29 08:00:52 --> URI Class Initialized
INFO - 2016-02-29 08:00:52 --> Router Class Initialized
INFO - 2016-02-29 08:00:52 --> Output Class Initialized
INFO - 2016-02-29 08:00:52 --> Security Class Initialized
DEBUG - 2016-02-29 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:00:52 --> Input Class Initialized
INFO - 2016-02-29 08:00:52 --> Language Class Initialized
INFO - 2016-02-29 08:00:52 --> Loader Class Initialized
INFO - 2016-02-29 08:00:52 --> Helper loaded: url_helper
INFO - 2016-02-29 08:00:52 --> Helper loaded: file_helper
INFO - 2016-02-29 08:00:52 --> Helper loaded: date_helper
INFO - 2016-02-29 08:00:52 --> Helper loaded: form_helper
INFO - 2016-02-29 08:00:52 --> Database Driver Class Initialized
INFO - 2016-02-29 08:00:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:00:53 --> Controller Class Initialized
INFO - 2016-02-29 08:00:53 --> Model Class Initialized
INFO - 2016-02-29 08:00:53 --> Model Class Initialized
INFO - 2016-02-29 08:00:53 --> Form Validation Class Initialized
INFO - 2016-02-29 08:00:53 --> Helper loaded: text_helper
INFO - 2016-02-29 08:00:53 --> Final output sent to browser
DEBUG - 2016-02-29 08:00:53 --> Total execution time: 1.1929
INFO - 2016-02-29 08:00:53 --> Config Class Initialized
INFO - 2016-02-29 08:00:53 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:00:53 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:00:53 --> Utf8 Class Initialized
INFO - 2016-02-29 08:00:53 --> URI Class Initialized
DEBUG - 2016-02-29 08:00:53 --> No URI present. Default controller set.
INFO - 2016-02-29 08:00:53 --> Router Class Initialized
INFO - 2016-02-29 08:00:53 --> Output Class Initialized
INFO - 2016-02-29 08:00:53 --> Security Class Initialized
DEBUG - 2016-02-29 08:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:00:53 --> Input Class Initialized
INFO - 2016-02-29 08:00:53 --> Language Class Initialized
INFO - 2016-02-29 08:00:53 --> Loader Class Initialized
INFO - 2016-02-29 08:00:53 --> Helper loaded: url_helper
INFO - 2016-02-29 08:00:53 --> Helper loaded: file_helper
INFO - 2016-02-29 08:00:53 --> Helper loaded: date_helper
INFO - 2016-02-29 08:00:53 --> Helper loaded: form_helper
INFO - 2016-02-29 08:00:53 --> Database Driver Class Initialized
INFO - 2016-02-29 08:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:00:54 --> Controller Class Initialized
INFO - 2016-02-29 08:00:54 --> Model Class Initialized
INFO - 2016-02-29 08:00:54 --> Model Class Initialized
INFO - 2016-02-29 08:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:00:54 --> Pagination Class Initialized
INFO - 2016-02-29 08:00:54 --> Helper loaded: text_helper
INFO - 2016-02-29 08:00:54 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:00:54 --> Final output sent to browser
DEBUG - 2016-02-29 11:00:54 --> Total execution time: 1.1671
INFO - 2016-02-29 08:01:03 --> Config Class Initialized
INFO - 2016-02-29 08:01:03 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:01:03 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:01:03 --> Utf8 Class Initialized
INFO - 2016-02-29 08:01:03 --> URI Class Initialized
INFO - 2016-02-29 08:01:03 --> Router Class Initialized
INFO - 2016-02-29 08:01:03 --> Output Class Initialized
INFO - 2016-02-29 08:01:03 --> Security Class Initialized
DEBUG - 2016-02-29 08:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:01:03 --> Input Class Initialized
INFO - 2016-02-29 08:01:03 --> Language Class Initialized
INFO - 2016-02-29 08:01:03 --> Loader Class Initialized
INFO - 2016-02-29 08:01:03 --> Helper loaded: url_helper
INFO - 2016-02-29 08:01:03 --> Helper loaded: file_helper
INFO - 2016-02-29 08:01:03 --> Helper loaded: date_helper
INFO - 2016-02-29 08:01:03 --> Helper loaded: form_helper
INFO - 2016-02-29 08:01:04 --> Database Driver Class Initialized
INFO - 2016-02-29 08:01:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:01:05 --> Controller Class Initialized
INFO - 2016-02-29 08:01:05 --> Model Class Initialized
INFO - 2016-02-29 08:01:05 --> Model Class Initialized
INFO - 2016-02-29 08:01:05 --> Form Validation Class Initialized
INFO - 2016-02-29 08:01:05 --> Helper loaded: text_helper
INFO - 2016-02-29 08:01:05 --> Config Class Initialized
INFO - 2016-02-29 08:01:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:01:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:01:05 --> Utf8 Class Initialized
INFO - 2016-02-29 08:01:05 --> URI Class Initialized
DEBUG - 2016-02-29 08:01:05 --> No URI present. Default controller set.
INFO - 2016-02-29 08:01:05 --> Router Class Initialized
INFO - 2016-02-29 08:01:05 --> Output Class Initialized
INFO - 2016-02-29 08:01:05 --> Security Class Initialized
DEBUG - 2016-02-29 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:01:05 --> Input Class Initialized
INFO - 2016-02-29 08:01:05 --> Language Class Initialized
INFO - 2016-02-29 08:01:05 --> Loader Class Initialized
INFO - 2016-02-29 08:01:05 --> Helper loaded: url_helper
INFO - 2016-02-29 08:01:05 --> Helper loaded: file_helper
INFO - 2016-02-29 08:01:05 --> Helper loaded: date_helper
INFO - 2016-02-29 08:01:05 --> Helper loaded: form_helper
INFO - 2016-02-29 08:01:05 --> Database Driver Class Initialized
INFO - 2016-02-29 08:01:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:01:06 --> Controller Class Initialized
INFO - 2016-02-29 08:01:06 --> Model Class Initialized
INFO - 2016-02-29 08:01:06 --> Model Class Initialized
INFO - 2016-02-29 08:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:01:06 --> Pagination Class Initialized
INFO - 2016-02-29 08:01:06 --> Helper loaded: text_helper
INFO - 2016-02-29 08:01:06 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:01:06 --> Final output sent to browser
DEBUG - 2016-02-29 11:01:06 --> Total execution time: 1.2720
INFO - 2016-02-29 08:04:14 --> Config Class Initialized
INFO - 2016-02-29 08:04:14 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:04:14 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:04:14 --> Utf8 Class Initialized
INFO - 2016-02-29 08:04:14 --> URI Class Initialized
DEBUG - 2016-02-29 08:04:14 --> No URI present. Default controller set.
INFO - 2016-02-29 08:04:14 --> Router Class Initialized
INFO - 2016-02-29 08:04:14 --> Output Class Initialized
INFO - 2016-02-29 08:04:14 --> Security Class Initialized
DEBUG - 2016-02-29 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:04:14 --> Input Class Initialized
INFO - 2016-02-29 08:04:14 --> Language Class Initialized
INFO - 2016-02-29 08:04:14 --> Loader Class Initialized
INFO - 2016-02-29 08:04:14 --> Helper loaded: url_helper
INFO - 2016-02-29 08:04:14 --> Helper loaded: file_helper
INFO - 2016-02-29 08:04:14 --> Helper loaded: date_helper
INFO - 2016-02-29 08:04:14 --> Helper loaded: form_helper
INFO - 2016-02-29 08:04:14 --> Database Driver Class Initialized
INFO - 2016-02-29 08:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:04:15 --> Controller Class Initialized
INFO - 2016-02-29 08:04:15 --> Model Class Initialized
INFO - 2016-02-29 08:04:15 --> Model Class Initialized
INFO - 2016-02-29 08:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:04:15 --> Pagination Class Initialized
INFO - 2016-02-29 08:04:15 --> Helper loaded: text_helper
INFO - 2016-02-29 08:04:15 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:04:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:04:15 --> Final output sent to browser
DEBUG - 2016-02-29 11:04:15 --> Total execution time: 1.1899
INFO - 2016-02-29 08:04:46 --> Config Class Initialized
INFO - 2016-02-29 08:04:46 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:04:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:04:47 --> Utf8 Class Initialized
INFO - 2016-02-29 08:04:47 --> URI Class Initialized
DEBUG - 2016-02-29 08:04:47 --> No URI present. Default controller set.
INFO - 2016-02-29 08:04:47 --> Router Class Initialized
INFO - 2016-02-29 08:04:47 --> Output Class Initialized
INFO - 2016-02-29 08:04:47 --> Security Class Initialized
DEBUG - 2016-02-29 08:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:04:47 --> Input Class Initialized
INFO - 2016-02-29 08:04:47 --> Language Class Initialized
INFO - 2016-02-29 08:04:47 --> Loader Class Initialized
INFO - 2016-02-29 08:04:47 --> Helper loaded: url_helper
INFO - 2016-02-29 08:04:47 --> Helper loaded: file_helper
INFO - 2016-02-29 08:04:47 --> Helper loaded: date_helper
INFO - 2016-02-29 08:04:47 --> Helper loaded: form_helper
INFO - 2016-02-29 08:04:47 --> Database Driver Class Initialized
INFO - 2016-02-29 08:04:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:04:48 --> Controller Class Initialized
INFO - 2016-02-29 08:04:48 --> Model Class Initialized
INFO - 2016-02-29 08:04:48 --> Model Class Initialized
INFO - 2016-02-29 08:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:04:48 --> Pagination Class Initialized
INFO - 2016-02-29 08:04:48 --> Helper loaded: text_helper
INFO - 2016-02-29 08:04:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:04:48 --> Final output sent to browser
DEBUG - 2016-02-29 11:04:48 --> Total execution time: 1.1870
INFO - 2016-02-29 08:08:50 --> Config Class Initialized
INFO - 2016-02-29 08:08:50 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:08:50 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:08:50 --> Utf8 Class Initialized
INFO - 2016-02-29 08:08:50 --> URI Class Initialized
DEBUG - 2016-02-29 08:08:50 --> No URI present. Default controller set.
INFO - 2016-02-29 08:08:50 --> Router Class Initialized
INFO - 2016-02-29 08:08:50 --> Output Class Initialized
INFO - 2016-02-29 08:08:50 --> Security Class Initialized
DEBUG - 2016-02-29 08:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:08:50 --> Input Class Initialized
INFO - 2016-02-29 08:08:50 --> Language Class Initialized
INFO - 2016-02-29 08:08:50 --> Loader Class Initialized
INFO - 2016-02-29 08:08:50 --> Helper loaded: url_helper
INFO - 2016-02-29 08:08:50 --> Helper loaded: file_helper
INFO - 2016-02-29 08:08:50 --> Helper loaded: date_helper
INFO - 2016-02-29 08:08:50 --> Helper loaded: form_helper
INFO - 2016-02-29 08:08:50 --> Database Driver Class Initialized
INFO - 2016-02-29 08:08:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:08:51 --> Controller Class Initialized
INFO - 2016-02-29 08:08:51 --> Model Class Initialized
INFO - 2016-02-29 08:08:51 --> Model Class Initialized
INFO - 2016-02-29 08:08:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:08:51 --> Pagination Class Initialized
INFO - 2016-02-29 08:08:51 --> Helper loaded: text_helper
INFO - 2016-02-29 08:08:51 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:08:51 --> Final output sent to browser
DEBUG - 2016-02-29 11:08:51 --> Total execution time: 1.1481
INFO - 2016-02-29 08:10:28 --> Config Class Initialized
INFO - 2016-02-29 08:10:28 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:10:28 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:10:28 --> Utf8 Class Initialized
INFO - 2016-02-29 08:10:28 --> URI Class Initialized
DEBUG - 2016-02-29 08:10:28 --> No URI present. Default controller set.
INFO - 2016-02-29 08:10:28 --> Router Class Initialized
INFO - 2016-02-29 08:10:28 --> Output Class Initialized
INFO - 2016-02-29 08:10:28 --> Security Class Initialized
DEBUG - 2016-02-29 08:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:10:28 --> Input Class Initialized
INFO - 2016-02-29 08:10:28 --> Language Class Initialized
INFO - 2016-02-29 08:10:28 --> Loader Class Initialized
INFO - 2016-02-29 08:10:28 --> Helper loaded: url_helper
INFO - 2016-02-29 08:10:28 --> Helper loaded: file_helper
INFO - 2016-02-29 08:10:28 --> Helper loaded: date_helper
INFO - 2016-02-29 08:10:28 --> Helper loaded: form_helper
INFO - 2016-02-29 08:10:28 --> Database Driver Class Initialized
INFO - 2016-02-29 08:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:10:29 --> Controller Class Initialized
INFO - 2016-02-29 08:10:29 --> Model Class Initialized
INFO - 2016-02-29 08:10:29 --> Model Class Initialized
INFO - 2016-02-29 08:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:10:29 --> Pagination Class Initialized
INFO - 2016-02-29 08:10:29 --> Helper loaded: text_helper
INFO - 2016-02-29 08:10:29 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:10:29 --> Final output sent to browser
DEBUG - 2016-02-29 11:10:29 --> Total execution time: 1.1564
INFO - 2016-02-29 08:10:45 --> Config Class Initialized
INFO - 2016-02-29 08:10:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:10:45 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:10:45 --> Utf8 Class Initialized
INFO - 2016-02-29 08:10:45 --> URI Class Initialized
DEBUG - 2016-02-29 08:10:45 --> No URI present. Default controller set.
INFO - 2016-02-29 08:10:45 --> Router Class Initialized
INFO - 2016-02-29 08:10:45 --> Output Class Initialized
INFO - 2016-02-29 08:10:45 --> Security Class Initialized
DEBUG - 2016-02-29 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:10:45 --> Input Class Initialized
INFO - 2016-02-29 08:10:45 --> Language Class Initialized
INFO - 2016-02-29 08:10:45 --> Loader Class Initialized
INFO - 2016-02-29 08:10:45 --> Helper loaded: url_helper
INFO - 2016-02-29 08:10:45 --> Helper loaded: file_helper
INFO - 2016-02-29 08:10:45 --> Helper loaded: date_helper
INFO - 2016-02-29 08:10:45 --> Helper loaded: form_helper
INFO - 2016-02-29 08:10:45 --> Database Driver Class Initialized
INFO - 2016-02-29 08:10:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:10:46 --> Controller Class Initialized
INFO - 2016-02-29 08:10:46 --> Model Class Initialized
INFO - 2016-02-29 08:10:46 --> Model Class Initialized
INFO - 2016-02-29 08:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:10:46 --> Pagination Class Initialized
INFO - 2016-02-29 08:10:46 --> Helper loaded: text_helper
INFO - 2016-02-29 08:10:46 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:10:46 --> Final output sent to browser
DEBUG - 2016-02-29 11:10:46 --> Total execution time: 1.1793
INFO - 2016-02-29 08:11:39 --> Config Class Initialized
INFO - 2016-02-29 08:11:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:11:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:11:39 --> Utf8 Class Initialized
INFO - 2016-02-29 08:11:39 --> URI Class Initialized
DEBUG - 2016-02-29 08:11:39 --> No URI present. Default controller set.
INFO - 2016-02-29 08:11:39 --> Router Class Initialized
INFO - 2016-02-29 08:11:39 --> Output Class Initialized
INFO - 2016-02-29 08:11:39 --> Security Class Initialized
DEBUG - 2016-02-29 08:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:11:39 --> Input Class Initialized
INFO - 2016-02-29 08:11:39 --> Language Class Initialized
INFO - 2016-02-29 08:11:40 --> Loader Class Initialized
INFO - 2016-02-29 08:11:40 --> Helper loaded: url_helper
INFO - 2016-02-29 08:11:40 --> Helper loaded: file_helper
INFO - 2016-02-29 08:11:40 --> Helper loaded: date_helper
INFO - 2016-02-29 08:11:40 --> Helper loaded: form_helper
INFO - 2016-02-29 08:11:40 --> Database Driver Class Initialized
INFO - 2016-02-29 08:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:11:41 --> Controller Class Initialized
INFO - 2016-02-29 08:11:41 --> Model Class Initialized
INFO - 2016-02-29 08:11:41 --> Model Class Initialized
INFO - 2016-02-29 08:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:11:41 --> Pagination Class Initialized
INFO - 2016-02-29 08:11:41 --> Helper loaded: text_helper
INFO - 2016-02-29 08:11:41 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:11:41 --> Final output sent to browser
DEBUG - 2016-02-29 11:11:41 --> Total execution time: 1.1547
INFO - 2016-02-29 08:13:07 --> Config Class Initialized
INFO - 2016-02-29 08:13:07 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:13:07 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:13:07 --> Utf8 Class Initialized
INFO - 2016-02-29 08:13:07 --> URI Class Initialized
DEBUG - 2016-02-29 08:13:07 --> No URI present. Default controller set.
INFO - 2016-02-29 08:13:07 --> Router Class Initialized
INFO - 2016-02-29 08:13:07 --> Output Class Initialized
INFO - 2016-02-29 08:13:08 --> Security Class Initialized
DEBUG - 2016-02-29 08:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:13:08 --> Input Class Initialized
INFO - 2016-02-29 08:13:08 --> Language Class Initialized
INFO - 2016-02-29 08:13:08 --> Loader Class Initialized
INFO - 2016-02-29 08:13:08 --> Helper loaded: url_helper
INFO - 2016-02-29 08:13:08 --> Helper loaded: file_helper
INFO - 2016-02-29 08:13:08 --> Helper loaded: date_helper
INFO - 2016-02-29 08:13:08 --> Helper loaded: form_helper
INFO - 2016-02-29 08:13:08 --> Database Driver Class Initialized
INFO - 2016-02-29 08:13:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:13:09 --> Controller Class Initialized
INFO - 2016-02-29 08:13:09 --> Model Class Initialized
INFO - 2016-02-29 08:13:09 --> Model Class Initialized
INFO - 2016-02-29 08:13:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:13:09 --> Pagination Class Initialized
INFO - 2016-02-29 08:13:09 --> Helper loaded: text_helper
INFO - 2016-02-29 08:13:09 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:13:09 --> Final output sent to browser
DEBUG - 2016-02-29 11:13:09 --> Total execution time: 1.1488
INFO - 2016-02-29 08:14:44 --> Config Class Initialized
INFO - 2016-02-29 08:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:14:44 --> Utf8 Class Initialized
INFO - 2016-02-29 08:14:44 --> URI Class Initialized
DEBUG - 2016-02-29 08:14:44 --> No URI present. Default controller set.
INFO - 2016-02-29 08:14:44 --> Router Class Initialized
INFO - 2016-02-29 08:14:44 --> Output Class Initialized
INFO - 2016-02-29 08:14:44 --> Security Class Initialized
DEBUG - 2016-02-29 08:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:14:44 --> Input Class Initialized
INFO - 2016-02-29 08:14:44 --> Language Class Initialized
INFO - 2016-02-29 08:14:44 --> Loader Class Initialized
INFO - 2016-02-29 08:14:44 --> Helper loaded: url_helper
INFO - 2016-02-29 08:14:44 --> Helper loaded: file_helper
INFO - 2016-02-29 08:14:44 --> Helper loaded: date_helper
INFO - 2016-02-29 08:14:44 --> Helper loaded: form_helper
INFO - 2016-02-29 08:14:44 --> Database Driver Class Initialized
INFO - 2016-02-29 08:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:14:45 --> Controller Class Initialized
INFO - 2016-02-29 08:14:45 --> Model Class Initialized
INFO - 2016-02-29 08:14:45 --> Model Class Initialized
INFO - 2016-02-29 08:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:14:45 --> Pagination Class Initialized
INFO - 2016-02-29 08:14:45 --> Helper loaded: text_helper
INFO - 2016-02-29 08:14:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:14:45 --> Final output sent to browser
DEBUG - 2016-02-29 11:14:45 --> Total execution time: 1.1492
INFO - 2016-02-29 08:15:05 --> Config Class Initialized
INFO - 2016-02-29 08:15:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:15:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:15:05 --> Utf8 Class Initialized
INFO - 2016-02-29 08:15:05 --> URI Class Initialized
DEBUG - 2016-02-29 08:15:05 --> No URI present. Default controller set.
INFO - 2016-02-29 08:15:06 --> Router Class Initialized
INFO - 2016-02-29 08:15:06 --> Output Class Initialized
INFO - 2016-02-29 08:15:06 --> Security Class Initialized
DEBUG - 2016-02-29 08:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:15:06 --> Input Class Initialized
INFO - 2016-02-29 08:15:06 --> Language Class Initialized
INFO - 2016-02-29 08:15:06 --> Loader Class Initialized
INFO - 2016-02-29 08:15:06 --> Helper loaded: url_helper
INFO - 2016-02-29 08:15:06 --> Helper loaded: file_helper
INFO - 2016-02-29 08:15:06 --> Helper loaded: date_helper
INFO - 2016-02-29 08:15:06 --> Helper loaded: form_helper
INFO - 2016-02-29 08:15:06 --> Database Driver Class Initialized
INFO - 2016-02-29 08:15:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:15:07 --> Controller Class Initialized
INFO - 2016-02-29 08:15:07 --> Model Class Initialized
INFO - 2016-02-29 08:15:07 --> Model Class Initialized
INFO - 2016-02-29 08:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:15:07 --> Pagination Class Initialized
INFO - 2016-02-29 08:15:07 --> Helper loaded: text_helper
INFO - 2016-02-29 08:15:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:15:07 --> Final output sent to browser
DEBUG - 2016-02-29 11:15:07 --> Total execution time: 1.1516
INFO - 2016-02-29 08:16:01 --> Config Class Initialized
INFO - 2016-02-29 08:16:01 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:16:01 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:16:01 --> Utf8 Class Initialized
INFO - 2016-02-29 08:16:01 --> URI Class Initialized
DEBUG - 2016-02-29 08:16:01 --> No URI present. Default controller set.
INFO - 2016-02-29 08:16:01 --> Router Class Initialized
INFO - 2016-02-29 08:16:01 --> Output Class Initialized
INFO - 2016-02-29 08:16:01 --> Security Class Initialized
DEBUG - 2016-02-29 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:16:01 --> Input Class Initialized
INFO - 2016-02-29 08:16:01 --> Language Class Initialized
INFO - 2016-02-29 08:16:01 --> Loader Class Initialized
INFO - 2016-02-29 08:16:01 --> Helper loaded: url_helper
INFO - 2016-02-29 08:16:01 --> Helper loaded: file_helper
INFO - 2016-02-29 08:16:01 --> Helper loaded: date_helper
INFO - 2016-02-29 08:16:01 --> Helper loaded: form_helper
INFO - 2016-02-29 08:16:01 --> Database Driver Class Initialized
INFO - 2016-02-29 08:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:16:02 --> Controller Class Initialized
INFO - 2016-02-29 08:16:02 --> Model Class Initialized
INFO - 2016-02-29 08:16:02 --> Model Class Initialized
INFO - 2016-02-29 08:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:16:02 --> Pagination Class Initialized
INFO - 2016-02-29 08:16:02 --> Helper loaded: text_helper
INFO - 2016-02-29 08:16:02 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:16:02 --> Final output sent to browser
DEBUG - 2016-02-29 11:16:02 --> Total execution time: 1.1759
INFO - 2016-02-29 08:16:24 --> Config Class Initialized
INFO - 2016-02-29 08:16:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:16:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:16:24 --> Utf8 Class Initialized
INFO - 2016-02-29 08:16:24 --> URI Class Initialized
DEBUG - 2016-02-29 08:16:24 --> No URI present. Default controller set.
INFO - 2016-02-29 08:16:24 --> Router Class Initialized
INFO - 2016-02-29 08:16:24 --> Output Class Initialized
INFO - 2016-02-29 08:16:24 --> Security Class Initialized
DEBUG - 2016-02-29 08:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:16:24 --> Input Class Initialized
INFO - 2016-02-29 08:16:24 --> Language Class Initialized
INFO - 2016-02-29 08:16:24 --> Loader Class Initialized
INFO - 2016-02-29 08:16:24 --> Helper loaded: url_helper
INFO - 2016-02-29 08:16:24 --> Helper loaded: file_helper
INFO - 2016-02-29 08:16:24 --> Helper loaded: date_helper
INFO - 2016-02-29 08:16:24 --> Helper loaded: form_helper
INFO - 2016-02-29 08:16:24 --> Database Driver Class Initialized
INFO - 2016-02-29 08:16:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:16:25 --> Controller Class Initialized
INFO - 2016-02-29 08:16:25 --> Model Class Initialized
INFO - 2016-02-29 08:16:25 --> Model Class Initialized
INFO - 2016-02-29 08:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:16:25 --> Pagination Class Initialized
INFO - 2016-02-29 08:16:25 --> Helper loaded: text_helper
INFO - 2016-02-29 08:16:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:16:25 --> Final output sent to browser
DEBUG - 2016-02-29 11:16:25 --> Total execution time: 1.1753
INFO - 2016-02-29 08:16:48 --> Config Class Initialized
INFO - 2016-02-29 08:16:48 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:16:48 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:16:48 --> Utf8 Class Initialized
INFO - 2016-02-29 08:16:48 --> URI Class Initialized
DEBUG - 2016-02-29 08:16:48 --> No URI present. Default controller set.
INFO - 2016-02-29 08:16:48 --> Router Class Initialized
INFO - 2016-02-29 08:16:48 --> Output Class Initialized
INFO - 2016-02-29 08:16:48 --> Security Class Initialized
DEBUG - 2016-02-29 08:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:16:48 --> Input Class Initialized
INFO - 2016-02-29 08:16:48 --> Language Class Initialized
INFO - 2016-02-29 08:16:48 --> Loader Class Initialized
INFO - 2016-02-29 08:16:48 --> Helper loaded: url_helper
INFO - 2016-02-29 08:16:48 --> Helper loaded: file_helper
INFO - 2016-02-29 08:16:48 --> Helper loaded: date_helper
INFO - 2016-02-29 08:16:48 --> Helper loaded: form_helper
INFO - 2016-02-29 08:16:48 --> Database Driver Class Initialized
INFO - 2016-02-29 08:16:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:16:49 --> Controller Class Initialized
INFO - 2016-02-29 08:16:49 --> Model Class Initialized
INFO - 2016-02-29 08:16:49 --> Model Class Initialized
INFO - 2016-02-29 08:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:16:49 --> Pagination Class Initialized
INFO - 2016-02-29 08:16:49 --> Helper loaded: text_helper
INFO - 2016-02-29 08:16:49 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:16:49 --> Final output sent to browser
DEBUG - 2016-02-29 11:16:49 --> Total execution time: 1.1820
INFO - 2016-02-29 08:17:33 --> Config Class Initialized
INFO - 2016-02-29 08:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:17:33 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:17:33 --> Utf8 Class Initialized
INFO - 2016-02-29 08:17:33 --> URI Class Initialized
DEBUG - 2016-02-29 08:17:33 --> No URI present. Default controller set.
INFO - 2016-02-29 08:17:33 --> Router Class Initialized
INFO - 2016-02-29 08:17:33 --> Output Class Initialized
INFO - 2016-02-29 08:17:33 --> Security Class Initialized
DEBUG - 2016-02-29 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:17:33 --> Input Class Initialized
INFO - 2016-02-29 08:17:33 --> Language Class Initialized
INFO - 2016-02-29 08:17:33 --> Loader Class Initialized
INFO - 2016-02-29 08:17:33 --> Helper loaded: url_helper
INFO - 2016-02-29 08:17:33 --> Helper loaded: file_helper
INFO - 2016-02-29 08:17:33 --> Helper loaded: date_helper
INFO - 2016-02-29 08:17:33 --> Helper loaded: form_helper
INFO - 2016-02-29 08:17:33 --> Database Driver Class Initialized
INFO - 2016-02-29 08:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:17:34 --> Controller Class Initialized
INFO - 2016-02-29 08:17:34 --> Model Class Initialized
INFO - 2016-02-29 08:17:34 --> Model Class Initialized
INFO - 2016-02-29 08:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:17:34 --> Pagination Class Initialized
INFO - 2016-02-29 08:17:34 --> Helper loaded: text_helper
INFO - 2016-02-29 08:17:34 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:17:34 --> Final output sent to browser
DEBUG - 2016-02-29 11:17:34 --> Total execution time: 1.1399
INFO - 2016-02-29 08:18:51 --> Config Class Initialized
INFO - 2016-02-29 08:18:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:18:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:18:51 --> Utf8 Class Initialized
INFO - 2016-02-29 08:18:51 --> URI Class Initialized
DEBUG - 2016-02-29 08:18:51 --> No URI present. Default controller set.
INFO - 2016-02-29 08:18:51 --> Router Class Initialized
INFO - 2016-02-29 08:18:51 --> Output Class Initialized
INFO - 2016-02-29 08:18:51 --> Security Class Initialized
DEBUG - 2016-02-29 08:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:18:51 --> Input Class Initialized
INFO - 2016-02-29 08:18:51 --> Language Class Initialized
INFO - 2016-02-29 08:18:51 --> Loader Class Initialized
INFO - 2016-02-29 08:18:51 --> Helper loaded: url_helper
INFO - 2016-02-29 08:18:51 --> Helper loaded: file_helper
INFO - 2016-02-29 08:18:51 --> Helper loaded: date_helper
INFO - 2016-02-29 08:18:51 --> Helper loaded: form_helper
INFO - 2016-02-29 08:18:51 --> Database Driver Class Initialized
INFO - 2016-02-29 08:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:18:52 --> Controller Class Initialized
INFO - 2016-02-29 08:18:52 --> Model Class Initialized
INFO - 2016-02-29 08:18:52 --> Model Class Initialized
INFO - 2016-02-29 08:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:18:52 --> Pagination Class Initialized
INFO - 2016-02-29 08:18:52 --> Helper loaded: text_helper
INFO - 2016-02-29 08:18:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:18:52 --> Final output sent to browser
DEBUG - 2016-02-29 11:18:52 --> Total execution time: 1.1550
INFO - 2016-02-29 08:19:04 --> Config Class Initialized
INFO - 2016-02-29 08:19:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:19:04 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:19:04 --> Utf8 Class Initialized
INFO - 2016-02-29 08:19:04 --> URI Class Initialized
DEBUG - 2016-02-29 08:19:04 --> No URI present. Default controller set.
INFO - 2016-02-29 08:19:04 --> Router Class Initialized
INFO - 2016-02-29 08:19:04 --> Output Class Initialized
INFO - 2016-02-29 08:19:04 --> Security Class Initialized
DEBUG - 2016-02-29 08:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:19:04 --> Input Class Initialized
INFO - 2016-02-29 08:19:04 --> Language Class Initialized
INFO - 2016-02-29 08:19:04 --> Loader Class Initialized
INFO - 2016-02-29 08:19:04 --> Helper loaded: url_helper
INFO - 2016-02-29 08:19:04 --> Helper loaded: file_helper
INFO - 2016-02-29 08:19:04 --> Helper loaded: date_helper
INFO - 2016-02-29 08:19:04 --> Helper loaded: form_helper
INFO - 2016-02-29 08:19:04 --> Database Driver Class Initialized
INFO - 2016-02-29 08:19:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:19:05 --> Controller Class Initialized
INFO - 2016-02-29 08:19:05 --> Model Class Initialized
INFO - 2016-02-29 08:19:05 --> Model Class Initialized
INFO - 2016-02-29 08:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:19:05 --> Pagination Class Initialized
INFO - 2016-02-29 08:19:05 --> Helper loaded: text_helper
INFO - 2016-02-29 08:19:05 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:19:05 --> Final output sent to browser
DEBUG - 2016-02-29 11:19:05 --> Total execution time: 1.0964
INFO - 2016-02-29 08:21:00 --> Config Class Initialized
INFO - 2016-02-29 08:21:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:21:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:21:00 --> Utf8 Class Initialized
INFO - 2016-02-29 08:21:00 --> URI Class Initialized
DEBUG - 2016-02-29 08:21:00 --> No URI present. Default controller set.
INFO - 2016-02-29 08:21:00 --> Router Class Initialized
INFO - 2016-02-29 08:21:00 --> Output Class Initialized
INFO - 2016-02-29 08:21:00 --> Security Class Initialized
DEBUG - 2016-02-29 08:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:21:00 --> Input Class Initialized
INFO - 2016-02-29 08:21:00 --> Language Class Initialized
INFO - 2016-02-29 08:21:00 --> Loader Class Initialized
INFO - 2016-02-29 08:21:00 --> Helper loaded: url_helper
INFO - 2016-02-29 08:21:00 --> Helper loaded: file_helper
INFO - 2016-02-29 08:21:00 --> Helper loaded: date_helper
INFO - 2016-02-29 08:21:00 --> Helper loaded: form_helper
INFO - 2016-02-29 08:21:00 --> Database Driver Class Initialized
INFO - 2016-02-29 08:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:21:01 --> Controller Class Initialized
INFO - 2016-02-29 08:21:01 --> Model Class Initialized
INFO - 2016-02-29 08:21:01 --> Model Class Initialized
INFO - 2016-02-29 08:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:21:01 --> Pagination Class Initialized
INFO - 2016-02-29 08:21:01 --> Helper loaded: text_helper
INFO - 2016-02-29 08:21:01 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:21:01 --> Final output sent to browser
DEBUG - 2016-02-29 11:21:01 --> Total execution time: 1.1864
INFO - 2016-02-29 08:21:35 --> Config Class Initialized
INFO - 2016-02-29 08:21:35 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:21:35 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:21:35 --> Utf8 Class Initialized
INFO - 2016-02-29 08:21:35 --> URI Class Initialized
INFO - 2016-02-29 08:21:35 --> Router Class Initialized
INFO - 2016-02-29 08:21:35 --> Output Class Initialized
INFO - 2016-02-29 08:21:35 --> Security Class Initialized
DEBUG - 2016-02-29 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:21:35 --> Input Class Initialized
INFO - 2016-02-29 08:21:35 --> Language Class Initialized
INFO - 2016-02-29 08:21:35 --> Loader Class Initialized
INFO - 2016-02-29 08:21:35 --> Helper loaded: url_helper
INFO - 2016-02-29 08:21:35 --> Helper loaded: file_helper
INFO - 2016-02-29 08:21:35 --> Helper loaded: date_helper
INFO - 2016-02-29 08:21:35 --> Helper loaded: form_helper
INFO - 2016-02-29 08:21:35 --> Database Driver Class Initialized
INFO - 2016-02-29 08:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:21:36 --> Controller Class Initialized
INFO - 2016-02-29 08:21:36 --> Model Class Initialized
INFO - 2016-02-29 08:21:36 --> Model Class Initialized
INFO - 2016-02-29 08:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:21:36 --> Pagination Class Initialized
INFO - 2016-02-29 08:21:36 --> Helper loaded: text_helper
INFO - 2016-02-29 08:21:36 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 11:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 11:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:21:36 --> Final output sent to browser
DEBUG - 2016-02-29 11:21:36 --> Total execution time: 1.1881
INFO - 2016-02-29 08:21:39 --> Config Class Initialized
INFO - 2016-02-29 08:21:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:21:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:21:39 --> Utf8 Class Initialized
INFO - 2016-02-29 08:21:39 --> URI Class Initialized
INFO - 2016-02-29 08:21:39 --> Router Class Initialized
INFO - 2016-02-29 08:21:39 --> Output Class Initialized
INFO - 2016-02-29 08:21:39 --> Security Class Initialized
DEBUG - 2016-02-29 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:21:39 --> Input Class Initialized
INFO - 2016-02-29 08:21:39 --> Language Class Initialized
INFO - 2016-02-29 08:21:39 --> Loader Class Initialized
INFO - 2016-02-29 08:21:39 --> Helper loaded: url_helper
INFO - 2016-02-29 08:21:39 --> Helper loaded: file_helper
INFO - 2016-02-29 08:21:39 --> Helper loaded: date_helper
INFO - 2016-02-29 08:21:39 --> Helper loaded: form_helper
INFO - 2016-02-29 08:21:39 --> Database Driver Class Initialized
INFO - 2016-02-29 08:21:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:21:40 --> Controller Class Initialized
INFO - 2016-02-29 08:21:40 --> Model Class Initialized
INFO - 2016-02-29 08:21:40 --> Model Class Initialized
INFO - 2016-02-29 08:21:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:21:40 --> Pagination Class Initialized
INFO - 2016-02-29 08:21:40 --> Helper loaded: text_helper
INFO - 2016-02-29 08:21:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 11:21:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:21:40 --> Final output sent to browser
DEBUG - 2016-02-29 11:21:40 --> Total execution time: 1.1249
INFO - 2016-02-29 08:22:01 --> Config Class Initialized
INFO - 2016-02-29 08:22:01 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:22:01 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:22:01 --> Utf8 Class Initialized
INFO - 2016-02-29 08:22:01 --> URI Class Initialized
INFO - 2016-02-29 08:22:01 --> Router Class Initialized
INFO - 2016-02-29 08:22:01 --> Output Class Initialized
INFO - 2016-02-29 08:22:01 --> Security Class Initialized
DEBUG - 2016-02-29 08:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:22:01 --> Input Class Initialized
INFO - 2016-02-29 08:22:01 --> Language Class Initialized
INFO - 2016-02-29 08:22:01 --> Loader Class Initialized
INFO - 2016-02-29 08:22:01 --> Helper loaded: url_helper
INFO - 2016-02-29 08:22:01 --> Helper loaded: file_helper
INFO - 2016-02-29 08:22:01 --> Helper loaded: date_helper
INFO - 2016-02-29 08:22:01 --> Helper loaded: form_helper
INFO - 2016-02-29 08:22:01 --> Database Driver Class Initialized
INFO - 2016-02-29 08:22:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:22:02 --> Controller Class Initialized
INFO - 2016-02-29 08:22:02 --> Model Class Initialized
INFO - 2016-02-29 08:22:02 --> Model Class Initialized
INFO - 2016-02-29 08:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:22:02 --> Pagination Class Initialized
INFO - 2016-02-29 08:22:02 --> Helper loaded: text_helper
INFO - 2016-02-29 08:22:02 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 11:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:22:02 --> Final output sent to browser
DEBUG - 2016-02-29 11:22:02 --> Total execution time: 1.1617
INFO - 2016-02-29 08:23:02 --> Config Class Initialized
INFO - 2016-02-29 08:23:02 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:23:02 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:23:02 --> Utf8 Class Initialized
INFO - 2016-02-29 08:23:02 --> URI Class Initialized
INFO - 2016-02-29 08:23:02 --> Router Class Initialized
INFO - 2016-02-29 08:23:02 --> Output Class Initialized
INFO - 2016-02-29 08:23:02 --> Security Class Initialized
DEBUG - 2016-02-29 08:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:23:02 --> Input Class Initialized
INFO - 2016-02-29 08:23:02 --> Language Class Initialized
INFO - 2016-02-29 08:23:02 --> Loader Class Initialized
INFO - 2016-02-29 08:23:02 --> Helper loaded: url_helper
INFO - 2016-02-29 08:23:02 --> Helper loaded: file_helper
INFO - 2016-02-29 08:23:02 --> Helper loaded: date_helper
INFO - 2016-02-29 08:23:02 --> Helper loaded: form_helper
INFO - 2016-02-29 08:23:02 --> Database Driver Class Initialized
INFO - 2016-02-29 08:23:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:23:03 --> Controller Class Initialized
INFO - 2016-02-29 08:23:03 --> Model Class Initialized
INFO - 2016-02-29 08:23:03 --> Model Class Initialized
INFO - 2016-02-29 08:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:23:03 --> Pagination Class Initialized
INFO - 2016-02-29 08:23:03 --> Helper loaded: text_helper
INFO - 2016-02-29 08:23:03 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 11:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:23:04 --> Final output sent to browser
DEBUG - 2016-02-29 11:23:04 --> Total execution time: 1.1480
INFO - 2016-02-29 08:23:25 --> Config Class Initialized
INFO - 2016-02-29 08:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:23:25 --> Utf8 Class Initialized
INFO - 2016-02-29 08:23:25 --> URI Class Initialized
INFO - 2016-02-29 08:23:25 --> Router Class Initialized
INFO - 2016-02-29 08:23:25 --> Output Class Initialized
INFO - 2016-02-29 08:23:25 --> Security Class Initialized
DEBUG - 2016-02-29 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:23:25 --> Input Class Initialized
INFO - 2016-02-29 08:23:25 --> Language Class Initialized
INFO - 2016-02-29 08:23:25 --> Loader Class Initialized
INFO - 2016-02-29 08:23:25 --> Helper loaded: url_helper
INFO - 2016-02-29 08:23:25 --> Helper loaded: file_helper
INFO - 2016-02-29 08:23:25 --> Helper loaded: date_helper
INFO - 2016-02-29 08:23:25 --> Helper loaded: form_helper
INFO - 2016-02-29 08:23:25 --> Database Driver Class Initialized
INFO - 2016-02-29 08:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:23:26 --> Controller Class Initialized
INFO - 2016-02-29 08:23:26 --> Model Class Initialized
INFO - 2016-02-29 08:23:26 --> Model Class Initialized
INFO - 2016-02-29 08:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:23:26 --> Pagination Class Initialized
INFO - 2016-02-29 08:23:26 --> Helper loaded: text_helper
INFO - 2016-02-29 08:23:26 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:23:26 --> Final output sent to browser
DEBUG - 2016-02-29 11:23:26 --> Total execution time: 1.1056
INFO - 2016-02-29 08:23:41 --> Config Class Initialized
INFO - 2016-02-29 08:23:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:23:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:23:41 --> Utf8 Class Initialized
INFO - 2016-02-29 08:23:41 --> URI Class Initialized
INFO - 2016-02-29 08:23:41 --> Router Class Initialized
INFO - 2016-02-29 08:23:41 --> Output Class Initialized
INFO - 2016-02-29 08:23:41 --> Security Class Initialized
DEBUG - 2016-02-29 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:23:41 --> Input Class Initialized
INFO - 2016-02-29 08:23:41 --> Language Class Initialized
INFO - 2016-02-29 08:23:41 --> Loader Class Initialized
INFO - 2016-02-29 08:23:41 --> Helper loaded: url_helper
INFO - 2016-02-29 08:23:41 --> Helper loaded: file_helper
INFO - 2016-02-29 08:23:41 --> Helper loaded: date_helper
INFO - 2016-02-29 08:23:41 --> Helper loaded: form_helper
INFO - 2016-02-29 08:23:41 --> Database Driver Class Initialized
INFO - 2016-02-29 08:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:23:42 --> Controller Class Initialized
INFO - 2016-02-29 08:23:42 --> Model Class Initialized
INFO - 2016-02-29 08:23:42 --> Model Class Initialized
INFO - 2016-02-29 08:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:23:42 --> Pagination Class Initialized
INFO - 2016-02-29 08:23:42 --> Helper loaded: text_helper
INFO - 2016-02-29 08:23:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 11:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:23:42 --> Final output sent to browser
DEBUG - 2016-02-29 11:23:42 --> Total execution time: 1.1149
INFO - 2016-02-29 08:23:43 --> Config Class Initialized
INFO - 2016-02-29 08:23:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:23:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:23:43 --> Utf8 Class Initialized
INFO - 2016-02-29 08:23:43 --> URI Class Initialized
DEBUG - 2016-02-29 08:23:43 --> No URI present. Default controller set.
INFO - 2016-02-29 08:23:43 --> Router Class Initialized
INFO - 2016-02-29 08:23:43 --> Output Class Initialized
INFO - 2016-02-29 08:23:43 --> Security Class Initialized
DEBUG - 2016-02-29 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:23:43 --> Input Class Initialized
INFO - 2016-02-29 08:23:43 --> Language Class Initialized
INFO - 2016-02-29 08:23:43 --> Loader Class Initialized
INFO - 2016-02-29 08:23:43 --> Helper loaded: url_helper
INFO - 2016-02-29 08:23:43 --> Helper loaded: file_helper
INFO - 2016-02-29 08:23:43 --> Helper loaded: date_helper
INFO - 2016-02-29 08:23:43 --> Helper loaded: form_helper
INFO - 2016-02-29 08:23:43 --> Database Driver Class Initialized
INFO - 2016-02-29 08:23:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:23:44 --> Controller Class Initialized
INFO - 2016-02-29 08:23:44 --> Model Class Initialized
INFO - 2016-02-29 08:23:44 --> Model Class Initialized
INFO - 2016-02-29 08:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:23:44 --> Pagination Class Initialized
INFO - 2016-02-29 08:23:44 --> Helper loaded: text_helper
INFO - 2016-02-29 08:23:44 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:23:44 --> Final output sent to browser
DEBUG - 2016-02-29 11:23:44 --> Total execution time: 1.1020
INFO - 2016-02-29 08:24:57 --> Config Class Initialized
INFO - 2016-02-29 08:24:57 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:24:57 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:24:57 --> Utf8 Class Initialized
INFO - 2016-02-29 08:24:57 --> URI Class Initialized
DEBUG - 2016-02-29 08:24:57 --> No URI present. Default controller set.
INFO - 2016-02-29 08:24:57 --> Router Class Initialized
INFO - 2016-02-29 08:24:57 --> Output Class Initialized
INFO - 2016-02-29 08:24:57 --> Security Class Initialized
DEBUG - 2016-02-29 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:24:57 --> Input Class Initialized
INFO - 2016-02-29 08:24:57 --> Language Class Initialized
INFO - 2016-02-29 08:24:57 --> Loader Class Initialized
INFO - 2016-02-29 08:24:57 --> Helper loaded: url_helper
INFO - 2016-02-29 08:24:57 --> Helper loaded: file_helper
INFO - 2016-02-29 08:24:57 --> Helper loaded: date_helper
INFO - 2016-02-29 08:24:57 --> Helper loaded: form_helper
INFO - 2016-02-29 08:24:57 --> Database Driver Class Initialized
INFO - 2016-02-29 08:24:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:24:58 --> Controller Class Initialized
INFO - 2016-02-29 08:24:58 --> Model Class Initialized
INFO - 2016-02-29 08:24:58 --> Model Class Initialized
INFO - 2016-02-29 08:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:24:58 --> Pagination Class Initialized
INFO - 2016-02-29 08:24:58 --> Helper loaded: text_helper
INFO - 2016-02-29 08:24:58 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:24:58 --> Final output sent to browser
DEBUG - 2016-02-29 11:24:58 --> Total execution time: 1.1207
INFO - 2016-02-29 08:25:27 --> Config Class Initialized
INFO - 2016-02-29 08:25:27 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:25:27 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:25:27 --> Utf8 Class Initialized
INFO - 2016-02-29 08:25:27 --> URI Class Initialized
DEBUG - 2016-02-29 08:25:27 --> No URI present. Default controller set.
INFO - 2016-02-29 08:25:27 --> Router Class Initialized
INFO - 2016-02-29 08:25:27 --> Output Class Initialized
INFO - 2016-02-29 08:25:27 --> Security Class Initialized
DEBUG - 2016-02-29 08:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:25:27 --> Input Class Initialized
INFO - 2016-02-29 08:25:27 --> Language Class Initialized
INFO - 2016-02-29 08:25:27 --> Loader Class Initialized
INFO - 2016-02-29 08:25:27 --> Helper loaded: url_helper
INFO - 2016-02-29 08:25:27 --> Helper loaded: file_helper
INFO - 2016-02-29 08:25:27 --> Helper loaded: date_helper
INFO - 2016-02-29 08:25:27 --> Helper loaded: form_helper
INFO - 2016-02-29 08:25:27 --> Database Driver Class Initialized
INFO - 2016-02-29 08:25:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:25:28 --> Controller Class Initialized
INFO - 2016-02-29 08:25:28 --> Model Class Initialized
INFO - 2016-02-29 08:25:28 --> Model Class Initialized
INFO - 2016-02-29 08:25:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:25:28 --> Pagination Class Initialized
INFO - 2016-02-29 08:25:28 --> Helper loaded: text_helper
INFO - 2016-02-29 08:25:28 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:25:28 --> Final output sent to browser
DEBUG - 2016-02-29 11:25:28 --> Total execution time: 1.1717
INFO - 2016-02-29 08:25:45 --> Config Class Initialized
INFO - 2016-02-29 08:25:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:25:46 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:25:46 --> Utf8 Class Initialized
INFO - 2016-02-29 08:25:46 --> URI Class Initialized
DEBUG - 2016-02-29 08:25:46 --> No URI present. Default controller set.
INFO - 2016-02-29 08:25:46 --> Router Class Initialized
INFO - 2016-02-29 08:25:46 --> Output Class Initialized
INFO - 2016-02-29 08:25:46 --> Security Class Initialized
DEBUG - 2016-02-29 08:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:25:46 --> Input Class Initialized
INFO - 2016-02-29 08:25:46 --> Language Class Initialized
INFO - 2016-02-29 08:25:46 --> Loader Class Initialized
INFO - 2016-02-29 08:25:46 --> Helper loaded: url_helper
INFO - 2016-02-29 08:25:46 --> Helper loaded: file_helper
INFO - 2016-02-29 08:25:46 --> Helper loaded: date_helper
INFO - 2016-02-29 08:25:46 --> Helper loaded: form_helper
INFO - 2016-02-29 08:25:46 --> Database Driver Class Initialized
INFO - 2016-02-29 08:25:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:25:47 --> Controller Class Initialized
INFO - 2016-02-29 08:25:47 --> Model Class Initialized
INFO - 2016-02-29 08:25:47 --> Model Class Initialized
INFO - 2016-02-29 08:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:25:47 --> Pagination Class Initialized
INFO - 2016-02-29 08:25:47 --> Helper loaded: text_helper
INFO - 2016-02-29 08:25:47 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:25:47 --> Final output sent to browser
DEBUG - 2016-02-29 11:25:47 --> Total execution time: 1.1381
INFO - 2016-02-29 08:26:21 --> Config Class Initialized
INFO - 2016-02-29 08:26:21 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:26:21 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:26:21 --> Utf8 Class Initialized
INFO - 2016-02-29 08:26:21 --> URI Class Initialized
DEBUG - 2016-02-29 08:26:21 --> No URI present. Default controller set.
INFO - 2016-02-29 08:26:21 --> Router Class Initialized
INFO - 2016-02-29 08:26:21 --> Output Class Initialized
INFO - 2016-02-29 08:26:21 --> Security Class Initialized
DEBUG - 2016-02-29 08:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:26:21 --> Input Class Initialized
INFO - 2016-02-29 08:26:21 --> Language Class Initialized
INFO - 2016-02-29 08:26:21 --> Loader Class Initialized
INFO - 2016-02-29 08:26:21 --> Helper loaded: url_helper
INFO - 2016-02-29 08:26:21 --> Helper loaded: file_helper
INFO - 2016-02-29 08:26:21 --> Helper loaded: date_helper
INFO - 2016-02-29 08:26:21 --> Helper loaded: form_helper
INFO - 2016-02-29 08:26:21 --> Database Driver Class Initialized
INFO - 2016-02-29 08:26:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:26:22 --> Controller Class Initialized
INFO - 2016-02-29 08:26:22 --> Model Class Initialized
INFO - 2016-02-29 08:26:22 --> Model Class Initialized
INFO - 2016-02-29 08:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:26:22 --> Pagination Class Initialized
INFO - 2016-02-29 08:26:22 --> Helper loaded: text_helper
INFO - 2016-02-29 08:26:22 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:26:22 --> Final output sent to browser
DEBUG - 2016-02-29 11:26:22 --> Total execution time: 1.1157
INFO - 2016-02-29 08:26:54 --> Config Class Initialized
INFO - 2016-02-29 08:26:54 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:26:54 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:26:54 --> Utf8 Class Initialized
INFO - 2016-02-29 08:26:54 --> URI Class Initialized
DEBUG - 2016-02-29 08:26:54 --> No URI present. Default controller set.
INFO - 2016-02-29 08:26:54 --> Router Class Initialized
INFO - 2016-02-29 08:26:54 --> Output Class Initialized
INFO - 2016-02-29 08:26:54 --> Security Class Initialized
DEBUG - 2016-02-29 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:26:54 --> Input Class Initialized
INFO - 2016-02-29 08:26:54 --> Language Class Initialized
INFO - 2016-02-29 08:26:54 --> Loader Class Initialized
INFO - 2016-02-29 08:26:54 --> Helper loaded: url_helper
INFO - 2016-02-29 08:26:54 --> Helper loaded: file_helper
INFO - 2016-02-29 08:26:54 --> Helper loaded: date_helper
INFO - 2016-02-29 08:26:54 --> Helper loaded: form_helper
INFO - 2016-02-29 08:26:54 --> Database Driver Class Initialized
INFO - 2016-02-29 08:26:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:26:55 --> Controller Class Initialized
INFO - 2016-02-29 08:26:55 --> Model Class Initialized
INFO - 2016-02-29 08:26:55 --> Model Class Initialized
INFO - 2016-02-29 08:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:26:55 --> Pagination Class Initialized
INFO - 2016-02-29 08:26:55 --> Helper loaded: text_helper
INFO - 2016-02-29 08:26:55 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:26:55 --> Final output sent to browser
DEBUG - 2016-02-29 11:26:55 --> Total execution time: 1.1170
INFO - 2016-02-29 08:27:10 --> Config Class Initialized
INFO - 2016-02-29 08:27:10 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:27:10 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:27:10 --> Utf8 Class Initialized
INFO - 2016-02-29 08:27:10 --> URI Class Initialized
DEBUG - 2016-02-29 08:27:10 --> No URI present. Default controller set.
INFO - 2016-02-29 08:27:10 --> Router Class Initialized
INFO - 2016-02-29 08:27:10 --> Output Class Initialized
INFO - 2016-02-29 08:27:10 --> Security Class Initialized
DEBUG - 2016-02-29 08:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:27:10 --> Input Class Initialized
INFO - 2016-02-29 08:27:10 --> Language Class Initialized
INFO - 2016-02-29 08:27:10 --> Loader Class Initialized
INFO - 2016-02-29 08:27:10 --> Helper loaded: url_helper
INFO - 2016-02-29 08:27:10 --> Helper loaded: file_helper
INFO - 2016-02-29 08:27:10 --> Helper loaded: date_helper
INFO - 2016-02-29 08:27:10 --> Helper loaded: form_helper
INFO - 2016-02-29 08:27:10 --> Database Driver Class Initialized
INFO - 2016-02-29 08:27:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:27:11 --> Controller Class Initialized
INFO - 2016-02-29 08:27:11 --> Model Class Initialized
INFO - 2016-02-29 08:27:11 --> Model Class Initialized
INFO - 2016-02-29 08:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:27:11 --> Pagination Class Initialized
INFO - 2016-02-29 08:27:11 --> Helper loaded: text_helper
INFO - 2016-02-29 08:27:11 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:27:11 --> Final output sent to browser
DEBUG - 2016-02-29 11:27:11 --> Total execution time: 1.1672
INFO - 2016-02-29 08:27:36 --> Config Class Initialized
INFO - 2016-02-29 08:27:36 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:27:36 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:27:36 --> Utf8 Class Initialized
INFO - 2016-02-29 08:27:36 --> URI Class Initialized
DEBUG - 2016-02-29 08:27:36 --> No URI present. Default controller set.
INFO - 2016-02-29 08:27:36 --> Router Class Initialized
INFO - 2016-02-29 08:27:36 --> Output Class Initialized
INFO - 2016-02-29 08:27:36 --> Security Class Initialized
DEBUG - 2016-02-29 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:27:36 --> Input Class Initialized
INFO - 2016-02-29 08:27:36 --> Language Class Initialized
INFO - 2016-02-29 08:27:36 --> Loader Class Initialized
INFO - 2016-02-29 08:27:36 --> Helper loaded: url_helper
INFO - 2016-02-29 08:27:36 --> Helper loaded: file_helper
INFO - 2016-02-29 08:27:36 --> Helper loaded: date_helper
INFO - 2016-02-29 08:27:36 --> Helper loaded: form_helper
INFO - 2016-02-29 08:27:36 --> Database Driver Class Initialized
INFO - 2016-02-29 08:27:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:27:37 --> Controller Class Initialized
INFO - 2016-02-29 08:27:37 --> Model Class Initialized
INFO - 2016-02-29 08:27:37 --> Model Class Initialized
INFO - 2016-02-29 08:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:27:37 --> Pagination Class Initialized
INFO - 2016-02-29 08:27:37 --> Helper loaded: text_helper
INFO - 2016-02-29 08:27:37 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:27:37 --> Final output sent to browser
DEBUG - 2016-02-29 11:27:37 --> Total execution time: 1.1086
INFO - 2016-02-29 08:27:44 --> Config Class Initialized
INFO - 2016-02-29 08:27:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:27:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:27:44 --> Utf8 Class Initialized
INFO - 2016-02-29 08:27:44 --> URI Class Initialized
DEBUG - 2016-02-29 08:27:44 --> No URI present. Default controller set.
INFO - 2016-02-29 08:27:44 --> Router Class Initialized
INFO - 2016-02-29 08:27:44 --> Output Class Initialized
INFO - 2016-02-29 08:27:44 --> Security Class Initialized
DEBUG - 2016-02-29 08:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:27:44 --> Input Class Initialized
INFO - 2016-02-29 08:27:44 --> Language Class Initialized
INFO - 2016-02-29 08:27:44 --> Loader Class Initialized
INFO - 2016-02-29 08:27:44 --> Helper loaded: url_helper
INFO - 2016-02-29 08:27:44 --> Helper loaded: file_helper
INFO - 2016-02-29 08:27:44 --> Helper loaded: date_helper
INFO - 2016-02-29 08:27:44 --> Helper loaded: form_helper
INFO - 2016-02-29 08:27:44 --> Database Driver Class Initialized
INFO - 2016-02-29 08:27:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:27:45 --> Controller Class Initialized
INFO - 2016-02-29 08:27:45 --> Model Class Initialized
INFO - 2016-02-29 08:27:45 --> Model Class Initialized
INFO - 2016-02-29 08:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:27:45 --> Pagination Class Initialized
INFO - 2016-02-29 08:27:45 --> Helper loaded: text_helper
INFO - 2016-02-29 08:27:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:27:45 --> Final output sent to browser
DEBUG - 2016-02-29 11:27:45 --> Total execution time: 1.1564
INFO - 2016-02-29 08:31:38 --> Config Class Initialized
INFO - 2016-02-29 08:31:38 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:31:38 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:31:38 --> Utf8 Class Initialized
INFO - 2016-02-29 08:31:38 --> URI Class Initialized
DEBUG - 2016-02-29 08:31:38 --> No URI present. Default controller set.
INFO - 2016-02-29 08:31:38 --> Router Class Initialized
INFO - 2016-02-29 08:31:38 --> Output Class Initialized
INFO - 2016-02-29 08:31:38 --> Security Class Initialized
DEBUG - 2016-02-29 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:31:38 --> Input Class Initialized
INFO - 2016-02-29 08:31:38 --> Language Class Initialized
INFO - 2016-02-29 08:31:38 --> Loader Class Initialized
INFO - 2016-02-29 08:31:38 --> Helper loaded: url_helper
INFO - 2016-02-29 08:31:38 --> Helper loaded: file_helper
INFO - 2016-02-29 08:31:38 --> Helper loaded: date_helper
INFO - 2016-02-29 08:31:38 --> Helper loaded: form_helper
INFO - 2016-02-29 08:31:38 --> Database Driver Class Initialized
INFO - 2016-02-29 08:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:31:39 --> Controller Class Initialized
INFO - 2016-02-29 08:31:39 --> Model Class Initialized
INFO - 2016-02-29 08:31:39 --> Model Class Initialized
INFO - 2016-02-29 08:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:31:39 --> Pagination Class Initialized
INFO - 2016-02-29 08:31:39 --> Helper loaded: text_helper
INFO - 2016-02-29 08:31:39 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:31:39 --> Final output sent to browser
DEBUG - 2016-02-29 11:31:39 --> Total execution time: 1.1902
INFO - 2016-02-29 08:32:29 --> Config Class Initialized
INFO - 2016-02-29 08:32:29 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:32:29 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:32:29 --> Utf8 Class Initialized
INFO - 2016-02-29 08:32:29 --> URI Class Initialized
DEBUG - 2016-02-29 08:32:29 --> No URI present. Default controller set.
INFO - 2016-02-29 08:32:29 --> Router Class Initialized
INFO - 2016-02-29 08:32:29 --> Output Class Initialized
INFO - 2016-02-29 08:32:29 --> Security Class Initialized
DEBUG - 2016-02-29 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:32:29 --> Input Class Initialized
INFO - 2016-02-29 08:32:29 --> Language Class Initialized
INFO - 2016-02-29 08:32:29 --> Loader Class Initialized
INFO - 2016-02-29 08:32:29 --> Helper loaded: url_helper
INFO - 2016-02-29 08:32:29 --> Helper loaded: file_helper
INFO - 2016-02-29 08:32:29 --> Helper loaded: date_helper
INFO - 2016-02-29 08:32:29 --> Helper loaded: form_helper
INFO - 2016-02-29 08:32:29 --> Database Driver Class Initialized
INFO - 2016-02-29 08:32:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:32:30 --> Controller Class Initialized
INFO - 2016-02-29 08:32:30 --> Model Class Initialized
INFO - 2016-02-29 08:32:30 --> Model Class Initialized
INFO - 2016-02-29 08:32:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:32:30 --> Pagination Class Initialized
INFO - 2016-02-29 08:32:30 --> Helper loaded: text_helper
INFO - 2016-02-29 08:32:30 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:32:31 --> Final output sent to browser
DEBUG - 2016-02-29 11:32:31 --> Total execution time: 1.3829
INFO - 2016-02-29 08:33:00 --> Config Class Initialized
INFO - 2016-02-29 08:33:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:33:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:33:00 --> Utf8 Class Initialized
INFO - 2016-02-29 08:33:00 --> URI Class Initialized
DEBUG - 2016-02-29 08:33:00 --> No URI present. Default controller set.
INFO - 2016-02-29 08:33:00 --> Router Class Initialized
INFO - 2016-02-29 08:33:00 --> Output Class Initialized
INFO - 2016-02-29 08:33:00 --> Security Class Initialized
DEBUG - 2016-02-29 08:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:33:00 --> Input Class Initialized
INFO - 2016-02-29 08:33:00 --> Language Class Initialized
INFO - 2016-02-29 08:33:00 --> Loader Class Initialized
INFO - 2016-02-29 08:33:00 --> Helper loaded: url_helper
INFO - 2016-02-29 08:33:00 --> Helper loaded: file_helper
INFO - 2016-02-29 08:33:00 --> Helper loaded: date_helper
INFO - 2016-02-29 08:33:00 --> Helper loaded: form_helper
INFO - 2016-02-29 08:33:00 --> Database Driver Class Initialized
INFO - 2016-02-29 08:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:33:01 --> Controller Class Initialized
INFO - 2016-02-29 08:33:01 --> Model Class Initialized
INFO - 2016-02-29 08:33:01 --> Model Class Initialized
INFO - 2016-02-29 08:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:33:01 --> Pagination Class Initialized
INFO - 2016-02-29 08:33:01 --> Helper loaded: text_helper
INFO - 2016-02-29 08:33:01 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:33:01 --> Final output sent to browser
DEBUG - 2016-02-29 11:33:01 --> Total execution time: 1.1497
INFO - 2016-02-29 08:33:27 --> Config Class Initialized
INFO - 2016-02-29 08:33:27 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:33:27 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:33:27 --> Utf8 Class Initialized
INFO - 2016-02-29 08:33:27 --> URI Class Initialized
DEBUG - 2016-02-29 08:33:27 --> No URI present. Default controller set.
INFO - 2016-02-29 08:33:27 --> Router Class Initialized
INFO - 2016-02-29 08:33:27 --> Output Class Initialized
INFO - 2016-02-29 08:33:27 --> Security Class Initialized
DEBUG - 2016-02-29 08:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:33:27 --> Input Class Initialized
INFO - 2016-02-29 08:33:27 --> Language Class Initialized
INFO - 2016-02-29 08:33:27 --> Loader Class Initialized
INFO - 2016-02-29 08:33:27 --> Helper loaded: url_helper
INFO - 2016-02-29 08:33:27 --> Helper loaded: file_helper
INFO - 2016-02-29 08:33:27 --> Helper loaded: date_helper
INFO - 2016-02-29 08:33:27 --> Helper loaded: form_helper
INFO - 2016-02-29 08:33:27 --> Database Driver Class Initialized
INFO - 2016-02-29 08:33:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:33:28 --> Controller Class Initialized
INFO - 2016-02-29 08:33:28 --> Model Class Initialized
INFO - 2016-02-29 08:33:28 --> Model Class Initialized
INFO - 2016-02-29 08:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:33:28 --> Pagination Class Initialized
INFO - 2016-02-29 08:33:28 --> Helper loaded: text_helper
INFO - 2016-02-29 08:33:28 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:33:28 --> Final output sent to browser
DEBUG - 2016-02-29 11:33:28 --> Total execution time: 1.1018
INFO - 2016-02-29 08:33:41 --> Config Class Initialized
INFO - 2016-02-29 08:33:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:33:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:33:41 --> Utf8 Class Initialized
INFO - 2016-02-29 08:33:41 --> URI Class Initialized
DEBUG - 2016-02-29 08:33:41 --> No URI present. Default controller set.
INFO - 2016-02-29 08:33:41 --> Router Class Initialized
INFO - 2016-02-29 08:33:41 --> Output Class Initialized
INFO - 2016-02-29 08:33:41 --> Security Class Initialized
DEBUG - 2016-02-29 08:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:33:41 --> Input Class Initialized
INFO - 2016-02-29 08:33:41 --> Language Class Initialized
INFO - 2016-02-29 08:33:41 --> Loader Class Initialized
INFO - 2016-02-29 08:33:41 --> Helper loaded: url_helper
INFO - 2016-02-29 08:33:41 --> Helper loaded: file_helper
INFO - 2016-02-29 08:33:41 --> Helper loaded: date_helper
INFO - 2016-02-29 08:33:41 --> Helper loaded: form_helper
INFO - 2016-02-29 08:33:41 --> Database Driver Class Initialized
INFO - 2016-02-29 08:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:33:42 --> Controller Class Initialized
INFO - 2016-02-29 08:33:42 --> Model Class Initialized
INFO - 2016-02-29 08:33:42 --> Model Class Initialized
INFO - 2016-02-29 08:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:33:42 --> Pagination Class Initialized
INFO - 2016-02-29 08:33:42 --> Helper loaded: text_helper
INFO - 2016-02-29 08:33:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:33:42 --> Final output sent to browser
DEBUG - 2016-02-29 11:33:42 --> Total execution time: 1.1176
INFO - 2016-02-29 08:35:06 --> Config Class Initialized
INFO - 2016-02-29 08:35:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:35:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:35:06 --> Utf8 Class Initialized
INFO - 2016-02-29 08:35:06 --> URI Class Initialized
DEBUG - 2016-02-29 08:35:06 --> No URI present. Default controller set.
INFO - 2016-02-29 08:35:06 --> Router Class Initialized
INFO - 2016-02-29 08:35:06 --> Output Class Initialized
INFO - 2016-02-29 08:35:06 --> Security Class Initialized
DEBUG - 2016-02-29 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:35:06 --> Input Class Initialized
INFO - 2016-02-29 08:35:06 --> Language Class Initialized
INFO - 2016-02-29 08:35:06 --> Loader Class Initialized
INFO - 2016-02-29 08:35:06 --> Helper loaded: url_helper
INFO - 2016-02-29 08:35:06 --> Helper loaded: file_helper
INFO - 2016-02-29 08:35:06 --> Helper loaded: date_helper
INFO - 2016-02-29 08:35:06 --> Helper loaded: form_helper
INFO - 2016-02-29 08:35:06 --> Database Driver Class Initialized
INFO - 2016-02-29 08:35:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:35:07 --> Controller Class Initialized
INFO - 2016-02-29 08:35:07 --> Model Class Initialized
INFO - 2016-02-29 08:35:07 --> Model Class Initialized
INFO - 2016-02-29 08:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:35:07 --> Pagination Class Initialized
INFO - 2016-02-29 08:35:07 --> Helper loaded: text_helper
INFO - 2016-02-29 08:35:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:35:07 --> Final output sent to browser
DEBUG - 2016-02-29 11:35:07 --> Total execution time: 1.1138
INFO - 2016-02-29 08:35:48 --> Config Class Initialized
INFO - 2016-02-29 08:35:48 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:35:48 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:35:48 --> Utf8 Class Initialized
INFO - 2016-02-29 08:35:48 --> URI Class Initialized
DEBUG - 2016-02-29 08:35:48 --> No URI present. Default controller set.
INFO - 2016-02-29 08:35:48 --> Router Class Initialized
INFO - 2016-02-29 08:35:48 --> Output Class Initialized
INFO - 2016-02-29 08:35:48 --> Security Class Initialized
DEBUG - 2016-02-29 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:35:48 --> Input Class Initialized
INFO - 2016-02-29 08:35:48 --> Language Class Initialized
INFO - 2016-02-29 08:35:48 --> Loader Class Initialized
INFO - 2016-02-29 08:35:48 --> Helper loaded: url_helper
INFO - 2016-02-29 08:35:48 --> Helper loaded: file_helper
INFO - 2016-02-29 08:35:48 --> Helper loaded: date_helper
INFO - 2016-02-29 08:35:48 --> Helper loaded: form_helper
INFO - 2016-02-29 08:35:48 --> Database Driver Class Initialized
INFO - 2016-02-29 08:35:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:35:50 --> Controller Class Initialized
INFO - 2016-02-29 08:35:50 --> Model Class Initialized
INFO - 2016-02-29 08:35:50 --> Model Class Initialized
INFO - 2016-02-29 08:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:35:50 --> Pagination Class Initialized
INFO - 2016-02-29 08:35:50 --> Helper loaded: text_helper
INFO - 2016-02-29 08:35:50 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:35:50 --> Final output sent to browser
DEBUG - 2016-02-29 11:35:50 --> Total execution time: 1.1507
INFO - 2016-02-29 08:36:10 --> Config Class Initialized
INFO - 2016-02-29 08:36:10 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:36:10 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:36:10 --> Utf8 Class Initialized
INFO - 2016-02-29 08:36:10 --> URI Class Initialized
DEBUG - 2016-02-29 08:36:10 --> No URI present. Default controller set.
INFO - 2016-02-29 08:36:10 --> Router Class Initialized
INFO - 2016-02-29 08:36:10 --> Output Class Initialized
INFO - 2016-02-29 08:36:10 --> Security Class Initialized
DEBUG - 2016-02-29 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:36:10 --> Input Class Initialized
INFO - 2016-02-29 08:36:10 --> Language Class Initialized
INFO - 2016-02-29 08:36:10 --> Loader Class Initialized
INFO - 2016-02-29 08:36:10 --> Helper loaded: url_helper
INFO - 2016-02-29 08:36:10 --> Helper loaded: file_helper
INFO - 2016-02-29 08:36:10 --> Helper loaded: date_helper
INFO - 2016-02-29 08:36:10 --> Helper loaded: form_helper
INFO - 2016-02-29 08:36:10 --> Database Driver Class Initialized
INFO - 2016-02-29 08:36:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:36:11 --> Controller Class Initialized
INFO - 2016-02-29 08:36:11 --> Model Class Initialized
INFO - 2016-02-29 08:36:11 --> Model Class Initialized
INFO - 2016-02-29 08:36:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:36:11 --> Pagination Class Initialized
INFO - 2016-02-29 08:36:11 --> Helper loaded: text_helper
INFO - 2016-02-29 08:36:11 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:36:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:36:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:36:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:36:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:36:11 --> Final output sent to browser
DEBUG - 2016-02-29 11:36:11 --> Total execution time: 1.1440
INFO - 2016-02-29 08:36:32 --> Config Class Initialized
INFO - 2016-02-29 08:36:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:36:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:36:32 --> Utf8 Class Initialized
INFO - 2016-02-29 08:36:32 --> URI Class Initialized
DEBUG - 2016-02-29 08:36:32 --> No URI present. Default controller set.
INFO - 2016-02-29 08:36:32 --> Router Class Initialized
INFO - 2016-02-29 08:36:32 --> Output Class Initialized
INFO - 2016-02-29 08:36:32 --> Security Class Initialized
DEBUG - 2016-02-29 08:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:36:32 --> Input Class Initialized
INFO - 2016-02-29 08:36:32 --> Language Class Initialized
INFO - 2016-02-29 08:36:32 --> Loader Class Initialized
INFO - 2016-02-29 08:36:32 --> Helper loaded: url_helper
INFO - 2016-02-29 08:36:32 --> Helper loaded: file_helper
INFO - 2016-02-29 08:36:32 --> Helper loaded: date_helper
INFO - 2016-02-29 08:36:32 --> Helper loaded: form_helper
INFO - 2016-02-29 08:36:32 --> Database Driver Class Initialized
INFO - 2016-02-29 08:36:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:36:33 --> Controller Class Initialized
INFO - 2016-02-29 08:36:33 --> Model Class Initialized
INFO - 2016-02-29 08:36:33 --> Model Class Initialized
INFO - 2016-02-29 08:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:36:33 --> Pagination Class Initialized
INFO - 2016-02-29 08:36:33 --> Helper loaded: text_helper
INFO - 2016-02-29 08:36:33 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:36:33 --> Final output sent to browser
DEBUG - 2016-02-29 11:36:33 --> Total execution time: 1.1410
INFO - 2016-02-29 08:36:57 --> Config Class Initialized
INFO - 2016-02-29 08:36:57 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:36:57 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:36:57 --> Utf8 Class Initialized
INFO - 2016-02-29 08:36:57 --> URI Class Initialized
DEBUG - 2016-02-29 08:36:57 --> No URI present. Default controller set.
INFO - 2016-02-29 08:36:57 --> Router Class Initialized
INFO - 2016-02-29 08:36:57 --> Output Class Initialized
INFO - 2016-02-29 08:36:57 --> Security Class Initialized
DEBUG - 2016-02-29 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:36:57 --> Input Class Initialized
INFO - 2016-02-29 08:36:57 --> Language Class Initialized
INFO - 2016-02-29 08:36:57 --> Loader Class Initialized
INFO - 2016-02-29 08:36:57 --> Helper loaded: url_helper
INFO - 2016-02-29 08:36:57 --> Helper loaded: file_helper
INFO - 2016-02-29 08:36:57 --> Helper loaded: date_helper
INFO - 2016-02-29 08:36:57 --> Helper loaded: form_helper
INFO - 2016-02-29 08:36:57 --> Database Driver Class Initialized
INFO - 2016-02-29 08:36:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:36:58 --> Controller Class Initialized
INFO - 2016-02-29 08:36:58 --> Model Class Initialized
INFO - 2016-02-29 08:36:58 --> Model Class Initialized
INFO - 2016-02-29 08:36:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:36:58 --> Pagination Class Initialized
INFO - 2016-02-29 08:36:58 --> Helper loaded: text_helper
INFO - 2016-02-29 08:36:58 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:36:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:36:58 --> Final output sent to browser
DEBUG - 2016-02-29 11:36:58 --> Total execution time: 1.1311
INFO - 2016-02-29 08:38:30 --> Config Class Initialized
INFO - 2016-02-29 08:38:30 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:38:30 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:38:30 --> Utf8 Class Initialized
INFO - 2016-02-29 08:38:30 --> URI Class Initialized
DEBUG - 2016-02-29 08:38:30 --> No URI present. Default controller set.
INFO - 2016-02-29 08:38:30 --> Router Class Initialized
INFO - 2016-02-29 08:38:30 --> Output Class Initialized
INFO - 2016-02-29 08:38:30 --> Security Class Initialized
DEBUG - 2016-02-29 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:38:30 --> Input Class Initialized
INFO - 2016-02-29 08:38:30 --> Language Class Initialized
INFO - 2016-02-29 08:38:30 --> Loader Class Initialized
INFO - 2016-02-29 08:38:30 --> Helper loaded: url_helper
INFO - 2016-02-29 08:38:30 --> Helper loaded: file_helper
INFO - 2016-02-29 08:38:30 --> Helper loaded: date_helper
INFO - 2016-02-29 08:38:30 --> Helper loaded: form_helper
INFO - 2016-02-29 08:38:30 --> Database Driver Class Initialized
INFO - 2016-02-29 08:38:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:38:31 --> Controller Class Initialized
INFO - 2016-02-29 08:38:31 --> Model Class Initialized
INFO - 2016-02-29 08:38:31 --> Model Class Initialized
INFO - 2016-02-29 08:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:38:31 --> Pagination Class Initialized
INFO - 2016-02-29 08:38:31 --> Helper loaded: text_helper
INFO - 2016-02-29 08:38:31 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:38:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:38:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:38:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:38:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:38:31 --> Final output sent to browser
DEBUG - 2016-02-29 11:38:31 --> Total execution time: 1.1350
INFO - 2016-02-29 08:38:43 --> Config Class Initialized
INFO - 2016-02-29 08:38:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:38:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:38:43 --> Utf8 Class Initialized
INFO - 2016-02-29 08:38:43 --> URI Class Initialized
DEBUG - 2016-02-29 08:38:43 --> No URI present. Default controller set.
INFO - 2016-02-29 08:38:43 --> Router Class Initialized
INFO - 2016-02-29 08:38:43 --> Output Class Initialized
INFO - 2016-02-29 08:38:43 --> Security Class Initialized
DEBUG - 2016-02-29 08:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:38:43 --> Input Class Initialized
INFO - 2016-02-29 08:38:43 --> Language Class Initialized
INFO - 2016-02-29 08:38:43 --> Loader Class Initialized
INFO - 2016-02-29 08:38:43 --> Helper loaded: url_helper
INFO - 2016-02-29 08:38:43 --> Helper loaded: file_helper
INFO - 2016-02-29 08:38:43 --> Helper loaded: date_helper
INFO - 2016-02-29 08:38:43 --> Helper loaded: form_helper
INFO - 2016-02-29 08:38:43 --> Database Driver Class Initialized
INFO - 2016-02-29 08:38:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:38:44 --> Controller Class Initialized
INFO - 2016-02-29 08:38:44 --> Model Class Initialized
INFO - 2016-02-29 08:38:44 --> Model Class Initialized
INFO - 2016-02-29 08:38:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:38:44 --> Pagination Class Initialized
INFO - 2016-02-29 08:38:44 --> Helper loaded: text_helper
INFO - 2016-02-29 08:38:44 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:38:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:38:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:38:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:38:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:38:44 --> Final output sent to browser
DEBUG - 2016-02-29 11:38:44 --> Total execution time: 1.1146
INFO - 2016-02-29 08:40:12 --> Config Class Initialized
INFO - 2016-02-29 08:40:12 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:40:12 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:40:12 --> Utf8 Class Initialized
INFO - 2016-02-29 08:40:12 --> URI Class Initialized
DEBUG - 2016-02-29 08:40:12 --> No URI present. Default controller set.
INFO - 2016-02-29 08:40:12 --> Router Class Initialized
INFO - 2016-02-29 08:40:12 --> Output Class Initialized
INFO - 2016-02-29 08:40:12 --> Security Class Initialized
DEBUG - 2016-02-29 08:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:40:12 --> Input Class Initialized
INFO - 2016-02-29 08:40:12 --> Language Class Initialized
INFO - 2016-02-29 08:40:12 --> Loader Class Initialized
INFO - 2016-02-29 08:40:12 --> Helper loaded: url_helper
INFO - 2016-02-29 08:40:12 --> Helper loaded: file_helper
INFO - 2016-02-29 08:40:12 --> Helper loaded: date_helper
INFO - 2016-02-29 08:40:12 --> Helper loaded: form_helper
INFO - 2016-02-29 08:40:12 --> Database Driver Class Initialized
INFO - 2016-02-29 08:40:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:40:13 --> Controller Class Initialized
INFO - 2016-02-29 08:40:13 --> Model Class Initialized
INFO - 2016-02-29 08:40:13 --> Model Class Initialized
INFO - 2016-02-29 08:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:40:13 --> Pagination Class Initialized
INFO - 2016-02-29 08:40:13 --> Helper loaded: text_helper
INFO - 2016-02-29 08:40:13 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:40:14 --> Final output sent to browser
DEBUG - 2016-02-29 11:40:14 --> Total execution time: 1.1984
INFO - 2016-02-29 08:40:32 --> Config Class Initialized
INFO - 2016-02-29 08:40:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:40:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:40:32 --> Utf8 Class Initialized
INFO - 2016-02-29 08:40:32 --> URI Class Initialized
DEBUG - 2016-02-29 08:40:32 --> No URI present. Default controller set.
INFO - 2016-02-29 08:40:32 --> Router Class Initialized
INFO - 2016-02-29 08:40:32 --> Output Class Initialized
INFO - 2016-02-29 08:40:32 --> Security Class Initialized
DEBUG - 2016-02-29 08:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:40:32 --> Input Class Initialized
INFO - 2016-02-29 08:40:32 --> Language Class Initialized
INFO - 2016-02-29 08:40:32 --> Loader Class Initialized
INFO - 2016-02-29 08:40:32 --> Helper loaded: url_helper
INFO - 2016-02-29 08:40:32 --> Helper loaded: file_helper
INFO - 2016-02-29 08:40:32 --> Helper loaded: date_helper
INFO - 2016-02-29 08:40:32 --> Helper loaded: form_helper
INFO - 2016-02-29 08:40:32 --> Database Driver Class Initialized
INFO - 2016-02-29 08:40:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:40:33 --> Controller Class Initialized
INFO - 2016-02-29 08:40:33 --> Model Class Initialized
INFO - 2016-02-29 08:40:33 --> Model Class Initialized
INFO - 2016-02-29 08:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:40:33 --> Pagination Class Initialized
INFO - 2016-02-29 08:40:33 --> Helper loaded: text_helper
INFO - 2016-02-29 08:40:33 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:40:33 --> Final output sent to browser
DEBUG - 2016-02-29 11:40:33 --> Total execution time: 1.1170
INFO - 2016-02-29 08:41:11 --> Config Class Initialized
INFO - 2016-02-29 08:41:11 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:41:11 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:41:11 --> Utf8 Class Initialized
INFO - 2016-02-29 08:41:11 --> URI Class Initialized
DEBUG - 2016-02-29 08:41:11 --> No URI present. Default controller set.
INFO - 2016-02-29 08:41:11 --> Router Class Initialized
INFO - 2016-02-29 08:41:11 --> Output Class Initialized
INFO - 2016-02-29 08:41:11 --> Security Class Initialized
DEBUG - 2016-02-29 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:41:11 --> Input Class Initialized
INFO - 2016-02-29 08:41:11 --> Language Class Initialized
INFO - 2016-02-29 08:41:11 --> Loader Class Initialized
INFO - 2016-02-29 08:41:11 --> Helper loaded: url_helper
INFO - 2016-02-29 08:41:11 --> Helper loaded: file_helper
INFO - 2016-02-29 08:41:11 --> Helper loaded: date_helper
INFO - 2016-02-29 08:41:11 --> Helper loaded: form_helper
INFO - 2016-02-29 08:41:11 --> Database Driver Class Initialized
INFO - 2016-02-29 08:41:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:41:12 --> Controller Class Initialized
INFO - 2016-02-29 08:41:12 --> Model Class Initialized
INFO - 2016-02-29 08:41:12 --> Model Class Initialized
INFO - 2016-02-29 08:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:41:12 --> Pagination Class Initialized
INFO - 2016-02-29 08:41:12 --> Helper loaded: text_helper
INFO - 2016-02-29 08:41:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:41:12 --> Final output sent to browser
DEBUG - 2016-02-29 11:41:12 --> Total execution time: 1.1495
INFO - 2016-02-29 08:41:26 --> Config Class Initialized
INFO - 2016-02-29 08:41:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:41:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:41:26 --> Utf8 Class Initialized
INFO - 2016-02-29 08:41:26 --> URI Class Initialized
DEBUG - 2016-02-29 08:41:26 --> No URI present. Default controller set.
INFO - 2016-02-29 08:41:26 --> Router Class Initialized
INFO - 2016-02-29 08:41:26 --> Output Class Initialized
INFO - 2016-02-29 08:41:26 --> Security Class Initialized
DEBUG - 2016-02-29 08:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:41:26 --> Input Class Initialized
INFO - 2016-02-29 08:41:26 --> Language Class Initialized
INFO - 2016-02-29 08:41:26 --> Loader Class Initialized
INFO - 2016-02-29 08:41:26 --> Helper loaded: url_helper
INFO - 2016-02-29 08:41:26 --> Helper loaded: file_helper
INFO - 2016-02-29 08:41:26 --> Helper loaded: date_helper
INFO - 2016-02-29 08:41:26 --> Helper loaded: form_helper
INFO - 2016-02-29 08:41:26 --> Database Driver Class Initialized
INFO - 2016-02-29 08:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:41:27 --> Controller Class Initialized
INFO - 2016-02-29 08:41:27 --> Model Class Initialized
INFO - 2016-02-29 08:41:27 --> Model Class Initialized
INFO - 2016-02-29 08:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:41:27 --> Pagination Class Initialized
INFO - 2016-02-29 08:41:27 --> Helper loaded: text_helper
INFO - 2016-02-29 08:41:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:41:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:41:27 --> Final output sent to browser
DEBUG - 2016-02-29 11:41:27 --> Total execution time: 1.1387
INFO - 2016-02-29 08:41:47 --> Config Class Initialized
INFO - 2016-02-29 08:41:47 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:41:47 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:41:47 --> Utf8 Class Initialized
INFO - 2016-02-29 08:41:47 --> URI Class Initialized
DEBUG - 2016-02-29 08:41:47 --> No URI present. Default controller set.
INFO - 2016-02-29 08:41:47 --> Router Class Initialized
INFO - 2016-02-29 08:41:47 --> Output Class Initialized
INFO - 2016-02-29 08:41:47 --> Security Class Initialized
DEBUG - 2016-02-29 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:41:47 --> Input Class Initialized
INFO - 2016-02-29 08:41:47 --> Language Class Initialized
INFO - 2016-02-29 08:41:47 --> Loader Class Initialized
INFO - 2016-02-29 08:41:47 --> Helper loaded: url_helper
INFO - 2016-02-29 08:41:47 --> Helper loaded: file_helper
INFO - 2016-02-29 08:41:47 --> Helper loaded: date_helper
INFO - 2016-02-29 08:41:47 --> Helper loaded: form_helper
INFO - 2016-02-29 08:41:47 --> Database Driver Class Initialized
INFO - 2016-02-29 08:41:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:41:48 --> Controller Class Initialized
INFO - 2016-02-29 08:41:48 --> Model Class Initialized
INFO - 2016-02-29 08:41:48 --> Model Class Initialized
INFO - 2016-02-29 08:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:41:48 --> Pagination Class Initialized
INFO - 2016-02-29 08:41:48 --> Helper loaded: text_helper
INFO - 2016-02-29 08:41:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:41:48 --> Final output sent to browser
DEBUG - 2016-02-29 11:41:48 --> Total execution time: 1.1424
INFO - 2016-02-29 08:41:55 --> Config Class Initialized
INFO - 2016-02-29 08:41:55 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:41:55 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:41:55 --> Utf8 Class Initialized
INFO - 2016-02-29 08:41:55 --> URI Class Initialized
DEBUG - 2016-02-29 08:41:55 --> No URI present. Default controller set.
INFO - 2016-02-29 08:41:55 --> Router Class Initialized
INFO - 2016-02-29 08:41:55 --> Output Class Initialized
INFO - 2016-02-29 08:41:55 --> Security Class Initialized
DEBUG - 2016-02-29 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:41:55 --> Input Class Initialized
INFO - 2016-02-29 08:41:55 --> Language Class Initialized
INFO - 2016-02-29 08:41:55 --> Loader Class Initialized
INFO - 2016-02-29 08:41:55 --> Helper loaded: url_helper
INFO - 2016-02-29 08:41:55 --> Helper loaded: file_helper
INFO - 2016-02-29 08:41:55 --> Helper loaded: date_helper
INFO - 2016-02-29 08:41:55 --> Helper loaded: form_helper
INFO - 2016-02-29 08:41:55 --> Database Driver Class Initialized
INFO - 2016-02-29 08:41:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:41:56 --> Controller Class Initialized
INFO - 2016-02-29 08:41:56 --> Model Class Initialized
INFO - 2016-02-29 08:41:56 --> Model Class Initialized
INFO - 2016-02-29 08:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:41:56 --> Pagination Class Initialized
INFO - 2016-02-29 08:41:56 --> Helper loaded: text_helper
INFO - 2016-02-29 08:41:56 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:41:56 --> Final output sent to browser
DEBUG - 2016-02-29 11:41:56 --> Total execution time: 1.1293
INFO - 2016-02-29 08:52:06 --> Config Class Initialized
INFO - 2016-02-29 08:52:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:52:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:52:06 --> Utf8 Class Initialized
INFO - 2016-02-29 08:52:06 --> URI Class Initialized
DEBUG - 2016-02-29 08:52:06 --> No URI present. Default controller set.
INFO - 2016-02-29 08:52:07 --> Router Class Initialized
INFO - 2016-02-29 08:52:07 --> Output Class Initialized
INFO - 2016-02-29 08:52:07 --> Security Class Initialized
DEBUG - 2016-02-29 08:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:52:07 --> Input Class Initialized
INFO - 2016-02-29 08:52:07 --> Language Class Initialized
INFO - 2016-02-29 08:52:07 --> Loader Class Initialized
INFO - 2016-02-29 08:52:07 --> Helper loaded: url_helper
INFO - 2016-02-29 08:52:07 --> Helper loaded: file_helper
INFO - 2016-02-29 08:52:07 --> Helper loaded: date_helper
INFO - 2016-02-29 08:52:07 --> Helper loaded: form_helper
INFO - 2016-02-29 08:52:07 --> Database Driver Class Initialized
INFO - 2016-02-29 08:52:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:52:08 --> Controller Class Initialized
INFO - 2016-02-29 08:52:08 --> Model Class Initialized
INFO - 2016-02-29 08:52:08 --> Model Class Initialized
INFO - 2016-02-29 08:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:52:08 --> Pagination Class Initialized
INFO - 2016-02-29 08:52:08 --> Helper loaded: text_helper
INFO - 2016-02-29 08:52:08 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:52:08 --> Final output sent to browser
DEBUG - 2016-02-29 11:52:08 --> Total execution time: 1.5229
INFO - 2016-02-29 08:52:25 --> Config Class Initialized
INFO - 2016-02-29 08:52:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 08:52:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 08:52:25 --> Utf8 Class Initialized
INFO - 2016-02-29 08:52:25 --> URI Class Initialized
DEBUG - 2016-02-29 08:52:25 --> No URI present. Default controller set.
INFO - 2016-02-29 08:52:25 --> Router Class Initialized
INFO - 2016-02-29 08:52:25 --> Output Class Initialized
INFO - 2016-02-29 08:52:25 --> Security Class Initialized
DEBUG - 2016-02-29 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 08:52:25 --> Input Class Initialized
INFO - 2016-02-29 08:52:25 --> Language Class Initialized
INFO - 2016-02-29 08:52:26 --> Loader Class Initialized
INFO - 2016-02-29 08:52:26 --> Helper loaded: url_helper
INFO - 2016-02-29 08:52:26 --> Helper loaded: file_helper
INFO - 2016-02-29 08:52:26 --> Helper loaded: date_helper
INFO - 2016-02-29 08:52:26 --> Helper loaded: form_helper
INFO - 2016-02-29 08:52:26 --> Database Driver Class Initialized
INFO - 2016-02-29 08:52:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 08:52:27 --> Controller Class Initialized
INFO - 2016-02-29 08:52:27 --> Model Class Initialized
INFO - 2016-02-29 08:52:27 --> Model Class Initialized
INFO - 2016-02-29 08:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 08:52:27 --> Pagination Class Initialized
INFO - 2016-02-29 08:52:27 --> Helper loaded: text_helper
INFO - 2016-02-29 08:52:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 11:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 11:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 11:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 11:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 11:52:27 --> Final output sent to browser
DEBUG - 2016-02-29 11:52:27 --> Total execution time: 1.1468
INFO - 2016-02-29 09:15:53 --> Config Class Initialized
INFO - 2016-02-29 09:15:53 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:15:53 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:15:53 --> Utf8 Class Initialized
INFO - 2016-02-29 09:15:53 --> URI Class Initialized
DEBUG - 2016-02-29 09:15:53 --> No URI present. Default controller set.
INFO - 2016-02-29 09:15:53 --> Router Class Initialized
INFO - 2016-02-29 09:15:53 --> Output Class Initialized
INFO - 2016-02-29 09:15:53 --> Security Class Initialized
DEBUG - 2016-02-29 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:15:53 --> Input Class Initialized
INFO - 2016-02-29 09:15:53 --> Language Class Initialized
INFO - 2016-02-29 09:15:53 --> Loader Class Initialized
INFO - 2016-02-29 09:15:53 --> Helper loaded: url_helper
INFO - 2016-02-29 09:15:53 --> Helper loaded: file_helper
INFO - 2016-02-29 09:15:53 --> Helper loaded: date_helper
INFO - 2016-02-29 09:15:53 --> Helper loaded: form_helper
INFO - 2016-02-29 09:15:53 --> Database Driver Class Initialized
INFO - 2016-02-29 09:15:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:15:54 --> Controller Class Initialized
INFO - 2016-02-29 09:15:54 --> Model Class Initialized
INFO - 2016-02-29 09:15:54 --> Model Class Initialized
INFO - 2016-02-29 09:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:15:54 --> Pagination Class Initialized
INFO - 2016-02-29 09:15:54 --> Helper loaded: text_helper
INFO - 2016-02-29 09:15:54 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:15:54 --> Final output sent to browser
DEBUG - 2016-02-29 12:15:54 --> Total execution time: 1.1217
INFO - 2016-02-29 09:15:56 --> Config Class Initialized
INFO - 2016-02-29 09:15:56 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:15:56 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:15:56 --> Utf8 Class Initialized
INFO - 2016-02-29 09:15:56 --> URI Class Initialized
INFO - 2016-02-29 09:15:56 --> Router Class Initialized
INFO - 2016-02-29 09:15:56 --> Output Class Initialized
INFO - 2016-02-29 09:15:56 --> Security Class Initialized
DEBUG - 2016-02-29 09:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:15:56 --> Input Class Initialized
INFO - 2016-02-29 09:15:56 --> Language Class Initialized
INFO - 2016-02-29 09:15:56 --> Loader Class Initialized
INFO - 2016-02-29 09:15:56 --> Helper loaded: url_helper
INFO - 2016-02-29 09:15:56 --> Helper loaded: file_helper
INFO - 2016-02-29 09:15:56 --> Helper loaded: date_helper
INFO - 2016-02-29 09:15:56 --> Helper loaded: form_helper
INFO - 2016-02-29 09:15:56 --> Database Driver Class Initialized
INFO - 2016-02-29 09:15:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:15:57 --> Controller Class Initialized
INFO - 2016-02-29 09:15:57 --> Model Class Initialized
INFO - 2016-02-29 09:15:57 --> Model Class Initialized
INFO - 2016-02-29 09:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:15:57 --> Pagination Class Initialized
INFO - 2016-02-29 09:15:57 --> Helper loaded: text_helper
INFO - 2016-02-29 09:15:57 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 12:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 12:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:15:57 --> Final output sent to browser
DEBUG - 2016-02-29 12:15:57 --> Total execution time: 1.1960
INFO - 2016-02-29 09:27:22 --> Config Class Initialized
INFO - 2016-02-29 09:27:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:27:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:27:22 --> Utf8 Class Initialized
INFO - 2016-02-29 09:27:22 --> URI Class Initialized
DEBUG - 2016-02-29 09:27:22 --> No URI present. Default controller set.
INFO - 2016-02-29 09:27:22 --> Router Class Initialized
INFO - 2016-02-29 09:27:22 --> Output Class Initialized
INFO - 2016-02-29 09:27:22 --> Security Class Initialized
DEBUG - 2016-02-29 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:27:22 --> Input Class Initialized
INFO - 2016-02-29 09:27:22 --> Language Class Initialized
INFO - 2016-02-29 09:27:22 --> Loader Class Initialized
INFO - 2016-02-29 09:27:22 --> Helper loaded: url_helper
INFO - 2016-02-29 09:27:22 --> Helper loaded: file_helper
INFO - 2016-02-29 09:27:22 --> Helper loaded: date_helper
INFO - 2016-02-29 09:27:22 --> Helper loaded: form_helper
INFO - 2016-02-29 09:27:22 --> Database Driver Class Initialized
INFO - 2016-02-29 09:27:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:27:23 --> Controller Class Initialized
INFO - 2016-02-29 09:27:23 --> Model Class Initialized
INFO - 2016-02-29 09:27:23 --> Model Class Initialized
INFO - 2016-02-29 09:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:27:23 --> Pagination Class Initialized
INFO - 2016-02-29 09:27:23 --> Helper loaded: text_helper
INFO - 2016-02-29 09:27:23 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:27:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:27:23 --> Final output sent to browser
DEBUG - 2016-02-29 12:27:23 --> Total execution time: 1.1323
INFO - 2016-02-29 09:28:06 --> Config Class Initialized
INFO - 2016-02-29 09:28:06 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:28:06 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:28:06 --> Utf8 Class Initialized
INFO - 2016-02-29 09:28:06 --> URI Class Initialized
DEBUG - 2016-02-29 09:28:06 --> No URI present. Default controller set.
INFO - 2016-02-29 09:28:06 --> Router Class Initialized
INFO - 2016-02-29 09:28:06 --> Output Class Initialized
INFO - 2016-02-29 09:28:06 --> Security Class Initialized
DEBUG - 2016-02-29 09:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:28:06 --> Input Class Initialized
INFO - 2016-02-29 09:28:06 --> Language Class Initialized
INFO - 2016-02-29 09:28:06 --> Loader Class Initialized
INFO - 2016-02-29 09:28:06 --> Helper loaded: url_helper
INFO - 2016-02-29 09:28:06 --> Helper loaded: file_helper
INFO - 2016-02-29 09:28:06 --> Helper loaded: date_helper
INFO - 2016-02-29 09:28:06 --> Helper loaded: form_helper
INFO - 2016-02-29 09:28:06 --> Database Driver Class Initialized
INFO - 2016-02-29 09:28:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:28:07 --> Controller Class Initialized
INFO - 2016-02-29 09:28:07 --> Model Class Initialized
INFO - 2016-02-29 09:28:07 --> Model Class Initialized
INFO - 2016-02-29 09:28:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:28:07 --> Pagination Class Initialized
INFO - 2016-02-29 09:28:07 --> Helper loaded: text_helper
INFO - 2016-02-29 09:28:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:28:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:28:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:28:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:28:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:28:07 --> Final output sent to browser
DEBUG - 2016-02-29 12:28:07 --> Total execution time: 1.2086
INFO - 2016-02-29 09:28:21 --> Config Class Initialized
INFO - 2016-02-29 09:28:21 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:28:21 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:28:21 --> Utf8 Class Initialized
INFO - 2016-02-29 09:28:21 --> URI Class Initialized
DEBUG - 2016-02-29 09:28:21 --> No URI present. Default controller set.
INFO - 2016-02-29 09:28:21 --> Router Class Initialized
INFO - 2016-02-29 09:28:21 --> Output Class Initialized
INFO - 2016-02-29 09:28:21 --> Security Class Initialized
DEBUG - 2016-02-29 09:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:28:21 --> Input Class Initialized
INFO - 2016-02-29 09:28:21 --> Language Class Initialized
INFO - 2016-02-29 09:28:21 --> Loader Class Initialized
INFO - 2016-02-29 09:28:21 --> Helper loaded: url_helper
INFO - 2016-02-29 09:28:21 --> Helper loaded: file_helper
INFO - 2016-02-29 09:28:21 --> Helper loaded: date_helper
INFO - 2016-02-29 09:28:21 --> Helper loaded: form_helper
INFO - 2016-02-29 09:28:21 --> Database Driver Class Initialized
INFO - 2016-02-29 09:28:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:28:22 --> Controller Class Initialized
INFO - 2016-02-29 09:28:22 --> Model Class Initialized
INFO - 2016-02-29 09:28:22 --> Model Class Initialized
INFO - 2016-02-29 09:28:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:28:22 --> Pagination Class Initialized
INFO - 2016-02-29 09:28:22 --> Helper loaded: text_helper
INFO - 2016-02-29 09:28:22 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:28:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:28:22 --> Final output sent to browser
DEBUG - 2016-02-29 12:28:22 --> Total execution time: 1.1742
INFO - 2016-02-29 09:28:39 --> Config Class Initialized
INFO - 2016-02-29 09:28:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:28:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:28:39 --> Utf8 Class Initialized
INFO - 2016-02-29 09:28:39 --> URI Class Initialized
DEBUG - 2016-02-29 09:28:39 --> No URI present. Default controller set.
INFO - 2016-02-29 09:28:39 --> Router Class Initialized
INFO - 2016-02-29 09:28:39 --> Output Class Initialized
INFO - 2016-02-29 09:28:39 --> Security Class Initialized
DEBUG - 2016-02-29 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:28:39 --> Input Class Initialized
INFO - 2016-02-29 09:28:39 --> Language Class Initialized
INFO - 2016-02-29 09:28:39 --> Loader Class Initialized
INFO - 2016-02-29 09:28:39 --> Helper loaded: url_helper
INFO - 2016-02-29 09:28:39 --> Helper loaded: file_helper
INFO - 2016-02-29 09:28:39 --> Helper loaded: date_helper
INFO - 2016-02-29 09:28:39 --> Helper loaded: form_helper
INFO - 2016-02-29 09:28:39 --> Database Driver Class Initialized
INFO - 2016-02-29 09:28:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:28:40 --> Controller Class Initialized
INFO - 2016-02-29 09:28:40 --> Model Class Initialized
INFO - 2016-02-29 09:28:40 --> Model Class Initialized
INFO - 2016-02-29 09:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:28:40 --> Pagination Class Initialized
INFO - 2016-02-29 09:28:40 --> Helper loaded: text_helper
INFO - 2016-02-29 09:28:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:28:40 --> Final output sent to browser
DEBUG - 2016-02-29 12:28:40 --> Total execution time: 1.1686
INFO - 2016-02-29 09:28:58 --> Config Class Initialized
INFO - 2016-02-29 09:28:58 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:28:58 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:28:58 --> Utf8 Class Initialized
INFO - 2016-02-29 09:28:58 --> URI Class Initialized
DEBUG - 2016-02-29 09:28:58 --> No URI present. Default controller set.
INFO - 2016-02-29 09:28:58 --> Router Class Initialized
INFO - 2016-02-29 09:28:58 --> Output Class Initialized
INFO - 2016-02-29 09:28:58 --> Security Class Initialized
DEBUG - 2016-02-29 09:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:28:58 --> Input Class Initialized
INFO - 2016-02-29 09:28:58 --> Language Class Initialized
INFO - 2016-02-29 09:28:58 --> Loader Class Initialized
INFO - 2016-02-29 09:28:58 --> Helper loaded: url_helper
INFO - 2016-02-29 09:28:58 --> Helper loaded: file_helper
INFO - 2016-02-29 09:28:58 --> Helper loaded: date_helper
INFO - 2016-02-29 09:28:58 --> Helper loaded: form_helper
INFO - 2016-02-29 09:28:58 --> Database Driver Class Initialized
INFO - 2016-02-29 09:29:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:29:00 --> Controller Class Initialized
INFO - 2016-02-29 09:29:00 --> Model Class Initialized
INFO - 2016-02-29 09:29:00 --> Model Class Initialized
INFO - 2016-02-29 09:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:29:00 --> Pagination Class Initialized
INFO - 2016-02-29 09:29:00 --> Helper loaded: text_helper
INFO - 2016-02-29 09:29:00 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:29:00 --> Final output sent to browser
DEBUG - 2016-02-29 12:29:00 --> Total execution time: 1.1919
INFO - 2016-02-29 09:29:13 --> Config Class Initialized
INFO - 2016-02-29 09:29:13 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:29:13 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:29:13 --> Utf8 Class Initialized
INFO - 2016-02-29 09:29:13 --> URI Class Initialized
DEBUG - 2016-02-29 09:29:13 --> No URI present. Default controller set.
INFO - 2016-02-29 09:29:13 --> Router Class Initialized
INFO - 2016-02-29 09:29:13 --> Output Class Initialized
INFO - 2016-02-29 09:29:13 --> Security Class Initialized
DEBUG - 2016-02-29 09:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:29:13 --> Input Class Initialized
INFO - 2016-02-29 09:29:13 --> Language Class Initialized
INFO - 2016-02-29 09:29:13 --> Loader Class Initialized
INFO - 2016-02-29 09:29:13 --> Helper loaded: url_helper
INFO - 2016-02-29 09:29:13 --> Helper loaded: file_helper
INFO - 2016-02-29 09:29:13 --> Helper loaded: date_helper
INFO - 2016-02-29 09:29:13 --> Helper loaded: form_helper
INFO - 2016-02-29 09:29:13 --> Database Driver Class Initialized
INFO - 2016-02-29 09:29:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:29:14 --> Controller Class Initialized
INFO - 2016-02-29 09:29:14 --> Model Class Initialized
INFO - 2016-02-29 09:29:14 --> Model Class Initialized
INFO - 2016-02-29 09:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:29:14 --> Pagination Class Initialized
INFO - 2016-02-29 09:29:14 --> Helper loaded: text_helper
INFO - 2016-02-29 09:29:14 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:29:14 --> Final output sent to browser
DEBUG - 2016-02-29 12:29:14 --> Total execution time: 1.1810
INFO - 2016-02-29 09:35:34 --> Config Class Initialized
INFO - 2016-02-29 09:35:34 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:35:34 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:35:34 --> Utf8 Class Initialized
INFO - 2016-02-29 09:35:34 --> URI Class Initialized
DEBUG - 2016-02-29 09:35:34 --> No URI present. Default controller set.
INFO - 2016-02-29 09:35:34 --> Router Class Initialized
INFO - 2016-02-29 09:35:34 --> Output Class Initialized
INFO - 2016-02-29 09:35:34 --> Security Class Initialized
DEBUG - 2016-02-29 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:35:34 --> Input Class Initialized
INFO - 2016-02-29 09:35:34 --> Language Class Initialized
INFO - 2016-02-29 09:35:34 --> Loader Class Initialized
INFO - 2016-02-29 09:35:34 --> Helper loaded: url_helper
INFO - 2016-02-29 09:35:34 --> Helper loaded: file_helper
INFO - 2016-02-29 09:35:34 --> Helper loaded: date_helper
INFO - 2016-02-29 09:35:34 --> Helper loaded: form_helper
INFO - 2016-02-29 09:35:34 --> Database Driver Class Initialized
INFO - 2016-02-29 09:35:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:35:35 --> Controller Class Initialized
INFO - 2016-02-29 09:35:35 --> Model Class Initialized
INFO - 2016-02-29 09:35:35 --> Model Class Initialized
INFO - 2016-02-29 09:35:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:35:35 --> Pagination Class Initialized
INFO - 2016-02-29 09:35:35 --> Helper loaded: text_helper
INFO - 2016-02-29 09:35:35 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:35:35 --> Final output sent to browser
DEBUG - 2016-02-29 12:35:35 --> Total execution time: 1.2054
INFO - 2016-02-29 09:37:04 --> Config Class Initialized
INFO - 2016-02-29 09:37:04 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:37:04 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:37:04 --> Utf8 Class Initialized
INFO - 2016-02-29 09:37:04 --> URI Class Initialized
DEBUG - 2016-02-29 09:37:04 --> No URI present. Default controller set.
INFO - 2016-02-29 09:37:04 --> Router Class Initialized
INFO - 2016-02-29 09:37:04 --> Output Class Initialized
INFO - 2016-02-29 09:37:04 --> Security Class Initialized
DEBUG - 2016-02-29 09:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:37:04 --> Input Class Initialized
INFO - 2016-02-29 09:37:04 --> Language Class Initialized
INFO - 2016-02-29 09:37:04 --> Loader Class Initialized
INFO - 2016-02-29 09:37:04 --> Helper loaded: url_helper
INFO - 2016-02-29 09:37:04 --> Helper loaded: file_helper
INFO - 2016-02-29 09:37:04 --> Helper loaded: date_helper
INFO - 2016-02-29 09:37:04 --> Helper loaded: form_helper
INFO - 2016-02-29 09:37:04 --> Database Driver Class Initialized
INFO - 2016-02-29 09:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:37:05 --> Controller Class Initialized
INFO - 2016-02-29 09:37:05 --> Model Class Initialized
INFO - 2016-02-29 09:37:05 --> Model Class Initialized
INFO - 2016-02-29 09:37:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:37:05 --> Pagination Class Initialized
INFO - 2016-02-29 09:37:05 --> Helper loaded: text_helper
INFO - 2016-02-29 09:37:05 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:37:05 --> Final output sent to browser
DEBUG - 2016-02-29 12:37:05 --> Total execution time: 1.2319
INFO - 2016-02-29 09:37:51 --> Config Class Initialized
INFO - 2016-02-29 09:37:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:37:51 --> Utf8 Class Initialized
INFO - 2016-02-29 09:37:51 --> URI Class Initialized
INFO - 2016-02-29 09:37:51 --> Router Class Initialized
INFO - 2016-02-29 09:37:51 --> Output Class Initialized
INFO - 2016-02-29 09:37:51 --> Security Class Initialized
DEBUG - 2016-02-29 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:37:51 --> Input Class Initialized
INFO - 2016-02-29 09:37:51 --> Language Class Initialized
INFO - 2016-02-29 09:37:51 --> Loader Class Initialized
INFO - 2016-02-29 09:37:51 --> Helper loaded: url_helper
INFO - 2016-02-29 09:37:51 --> Helper loaded: file_helper
INFO - 2016-02-29 09:37:51 --> Helper loaded: date_helper
INFO - 2016-02-29 09:37:51 --> Helper loaded: form_helper
INFO - 2016-02-29 09:37:51 --> Database Driver Class Initialized
INFO - 2016-02-29 09:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:37:52 --> Controller Class Initialized
INFO - 2016-02-29 09:37:52 --> Model Class Initialized
INFO - 2016-02-29 09:37:52 --> Model Class Initialized
INFO - 2016-02-29 09:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:37:52 --> Pagination Class Initialized
INFO - 2016-02-29 09:37:52 --> Helper loaded: text_helper
INFO - 2016-02-29 09:37:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 12:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:37:52 --> Final output sent to browser
DEBUG - 2016-02-29 12:37:52 --> Total execution time: 1.1662
INFO - 2016-02-29 09:42:54 --> Config Class Initialized
INFO - 2016-02-29 09:42:54 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:42:54 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:42:54 --> Utf8 Class Initialized
INFO - 2016-02-29 09:42:54 --> URI Class Initialized
INFO - 2016-02-29 09:42:54 --> Router Class Initialized
INFO - 2016-02-29 09:42:54 --> Output Class Initialized
INFO - 2016-02-29 09:42:54 --> Security Class Initialized
DEBUG - 2016-02-29 09:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:42:54 --> Input Class Initialized
INFO - 2016-02-29 09:42:54 --> Language Class Initialized
INFO - 2016-02-29 09:42:54 --> Loader Class Initialized
INFO - 2016-02-29 09:42:54 --> Helper loaded: url_helper
INFO - 2016-02-29 09:42:54 --> Helper loaded: file_helper
INFO - 2016-02-29 09:42:54 --> Helper loaded: date_helper
INFO - 2016-02-29 09:42:54 --> Helper loaded: form_helper
INFO - 2016-02-29 09:42:54 --> Database Driver Class Initialized
INFO - 2016-02-29 09:42:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:42:55 --> Controller Class Initialized
INFO - 2016-02-29 09:42:55 --> Model Class Initialized
INFO - 2016-02-29 09:42:55 --> Model Class Initialized
INFO - 2016-02-29 09:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:42:55 --> Pagination Class Initialized
INFO - 2016-02-29 09:42:55 --> Helper loaded: text_helper
INFO - 2016-02-29 09:42:55 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 12:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:42:55 --> Final output sent to browser
DEBUG - 2016-02-29 12:42:55 --> Total execution time: 1.1560
INFO - 2016-02-29 09:42:57 --> Config Class Initialized
INFO - 2016-02-29 09:42:57 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:42:57 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:42:57 --> Utf8 Class Initialized
INFO - 2016-02-29 09:42:57 --> URI Class Initialized
DEBUG - 2016-02-29 09:42:57 --> No URI present. Default controller set.
INFO - 2016-02-29 09:42:57 --> Router Class Initialized
INFO - 2016-02-29 09:42:57 --> Output Class Initialized
INFO - 2016-02-29 09:42:57 --> Security Class Initialized
DEBUG - 2016-02-29 09:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:42:57 --> Input Class Initialized
INFO - 2016-02-29 09:42:57 --> Language Class Initialized
INFO - 2016-02-29 09:42:57 --> Loader Class Initialized
INFO - 2016-02-29 09:42:57 --> Helper loaded: url_helper
INFO - 2016-02-29 09:42:57 --> Helper loaded: file_helper
INFO - 2016-02-29 09:42:57 --> Helper loaded: date_helper
INFO - 2016-02-29 09:42:57 --> Helper loaded: form_helper
INFO - 2016-02-29 09:42:57 --> Database Driver Class Initialized
INFO - 2016-02-29 09:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:42:58 --> Controller Class Initialized
INFO - 2016-02-29 09:42:58 --> Model Class Initialized
INFO - 2016-02-29 09:42:58 --> Model Class Initialized
INFO - 2016-02-29 09:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:42:58 --> Pagination Class Initialized
INFO - 2016-02-29 09:42:58 --> Helper loaded: text_helper
INFO - 2016-02-29 09:42:58 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:42:58 --> Final output sent to browser
DEBUG - 2016-02-29 12:42:58 --> Total execution time: 1.1415
INFO - 2016-02-29 09:43:24 --> Config Class Initialized
INFO - 2016-02-29 09:43:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:43:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:43:24 --> Utf8 Class Initialized
INFO - 2016-02-29 09:43:24 --> URI Class Initialized
DEBUG - 2016-02-29 09:43:24 --> No URI present. Default controller set.
INFO - 2016-02-29 09:43:24 --> Router Class Initialized
INFO - 2016-02-29 09:43:24 --> Output Class Initialized
INFO - 2016-02-29 09:43:24 --> Security Class Initialized
DEBUG - 2016-02-29 09:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:43:24 --> Input Class Initialized
INFO - 2016-02-29 09:43:24 --> Language Class Initialized
INFO - 2016-02-29 09:43:24 --> Loader Class Initialized
INFO - 2016-02-29 09:43:24 --> Helper loaded: url_helper
INFO - 2016-02-29 09:43:24 --> Helper loaded: file_helper
INFO - 2016-02-29 09:43:24 --> Helper loaded: date_helper
INFO - 2016-02-29 09:43:24 --> Helper loaded: form_helper
INFO - 2016-02-29 09:43:24 --> Database Driver Class Initialized
INFO - 2016-02-29 09:43:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:43:25 --> Controller Class Initialized
INFO - 2016-02-29 09:43:25 --> Model Class Initialized
INFO - 2016-02-29 09:43:25 --> Model Class Initialized
INFO - 2016-02-29 09:43:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:43:25 --> Pagination Class Initialized
INFO - 2016-02-29 09:43:25 --> Helper loaded: text_helper
INFO - 2016-02-29 09:43:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 12:43:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:43:25 --> Final output sent to browser
DEBUG - 2016-02-29 12:43:25 --> Total execution time: 1.1588
INFO - 2016-02-29 09:43:29 --> Config Class Initialized
INFO - 2016-02-29 09:43:29 --> Hooks Class Initialized
DEBUG - 2016-02-29 09:43:29 --> UTF-8 Support Enabled
INFO - 2016-02-29 09:43:29 --> Utf8 Class Initialized
INFO - 2016-02-29 09:43:29 --> URI Class Initialized
INFO - 2016-02-29 09:43:29 --> Router Class Initialized
INFO - 2016-02-29 09:43:29 --> Output Class Initialized
INFO - 2016-02-29 09:43:29 --> Security Class Initialized
DEBUG - 2016-02-29 09:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 09:43:29 --> Input Class Initialized
INFO - 2016-02-29 09:43:29 --> Language Class Initialized
INFO - 2016-02-29 09:43:29 --> Loader Class Initialized
INFO - 2016-02-29 09:43:29 --> Helper loaded: url_helper
INFO - 2016-02-29 09:43:29 --> Helper loaded: file_helper
INFO - 2016-02-29 09:43:29 --> Helper loaded: date_helper
INFO - 2016-02-29 09:43:29 --> Helper loaded: form_helper
INFO - 2016-02-29 09:43:29 --> Database Driver Class Initialized
INFO - 2016-02-29 09:43:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 09:43:30 --> Controller Class Initialized
INFO - 2016-02-29 09:43:30 --> Model Class Initialized
INFO - 2016-02-29 09:43:30 --> Model Class Initialized
INFO - 2016-02-29 09:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 09:43:31 --> Pagination Class Initialized
INFO - 2016-02-29 09:43:31 --> Helper loaded: text_helper
INFO - 2016-02-29 09:43:31 --> Helper loaded: cookie_helper
INFO - 2016-02-29 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 12:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 12:43:31 --> Final output sent to browser
DEBUG - 2016-02-29 12:43:31 --> Total execution time: 1.1543
INFO - 2016-02-29 13:46:39 --> Config Class Initialized
INFO - 2016-02-29 13:46:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:46:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:46:39 --> Utf8 Class Initialized
INFO - 2016-02-29 13:46:39 --> URI Class Initialized
INFO - 2016-02-29 13:46:39 --> Router Class Initialized
INFO - 2016-02-29 13:46:39 --> Output Class Initialized
INFO - 2016-02-29 13:46:39 --> Security Class Initialized
DEBUG - 2016-02-29 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:46:39 --> Input Class Initialized
INFO - 2016-02-29 13:46:39 --> Language Class Initialized
INFO - 2016-02-29 13:46:39 --> Loader Class Initialized
INFO - 2016-02-29 13:46:39 --> Helper loaded: url_helper
INFO - 2016-02-29 13:46:39 --> Helper loaded: file_helper
INFO - 2016-02-29 13:46:39 --> Helper loaded: date_helper
INFO - 2016-02-29 13:46:39 --> Helper loaded: form_helper
INFO - 2016-02-29 13:46:39 --> Database Driver Class Initialized
INFO - 2016-02-29 13:46:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:46:40 --> Controller Class Initialized
INFO - 2016-02-29 13:46:40 --> Model Class Initialized
INFO - 2016-02-29 13:46:40 --> Model Class Initialized
INFO - 2016-02-29 13:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:46:40 --> Pagination Class Initialized
INFO - 2016-02-29 13:46:40 --> Helper loaded: text_helper
INFO - 2016-02-29 13:46:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:46:40 --> Final output sent to browser
DEBUG - 2016-02-29 16:46:40 --> Total execution time: 1.1659
INFO - 2016-02-29 13:48:08 --> Config Class Initialized
INFO - 2016-02-29 13:48:08 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:08 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:08 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:08 --> URI Class Initialized
INFO - 2016-02-29 13:48:08 --> Router Class Initialized
INFO - 2016-02-29 13:48:08 --> Output Class Initialized
INFO - 2016-02-29 13:48:08 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:08 --> Input Class Initialized
INFO - 2016-02-29 13:48:08 --> Language Class Initialized
INFO - 2016-02-29 13:48:08 --> Loader Class Initialized
INFO - 2016-02-29 13:48:08 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:08 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:08 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:08 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:08 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:09 --> Controller Class Initialized
INFO - 2016-02-29 13:48:09 --> Model Class Initialized
INFO - 2016-02-29 13:48:09 --> Model Class Initialized
INFO - 2016-02-29 13:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:09 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:09 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:09 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:09 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:09 --> Total execution time: 1.2146
INFO - 2016-02-29 13:48:22 --> Config Class Initialized
INFO - 2016-02-29 13:48:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:22 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:22 --> URI Class Initialized
INFO - 2016-02-29 13:48:22 --> Router Class Initialized
INFO - 2016-02-29 13:48:22 --> Output Class Initialized
INFO - 2016-02-29 13:48:22 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:22 --> Input Class Initialized
INFO - 2016-02-29 13:48:22 --> Language Class Initialized
INFO - 2016-02-29 13:48:22 --> Loader Class Initialized
INFO - 2016-02-29 13:48:22 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:22 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:22 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:22 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:22 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:23 --> Controller Class Initialized
INFO - 2016-02-29 13:48:23 --> Model Class Initialized
INFO - 2016-02-29 13:48:23 --> Model Class Initialized
INFO - 2016-02-29 13:48:23 --> Form Validation Class Initialized
INFO - 2016-02-29 13:48:23 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:23 --> Final output sent to browser
DEBUG - 2016-02-29 13:48:23 --> Total execution time: 1.1729
INFO - 2016-02-29 13:48:23 --> Config Class Initialized
INFO - 2016-02-29 13:48:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:23 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:23 --> URI Class Initialized
INFO - 2016-02-29 13:48:23 --> Router Class Initialized
INFO - 2016-02-29 13:48:23 --> Output Class Initialized
INFO - 2016-02-29 13:48:23 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:23 --> Input Class Initialized
INFO - 2016-02-29 13:48:23 --> Language Class Initialized
INFO - 2016-02-29 13:48:23 --> Loader Class Initialized
INFO - 2016-02-29 13:48:23 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:23 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:23 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:23 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:23 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:24 --> Controller Class Initialized
INFO - 2016-02-29 13:48:24 --> Model Class Initialized
INFO - 2016-02-29 13:48:24 --> Model Class Initialized
INFO - 2016-02-29 13:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:24 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:24 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:24 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:24 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:24 --> Total execution time: 1.1273
INFO - 2016-02-29 13:48:31 --> Config Class Initialized
INFO - 2016-02-29 13:48:31 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:31 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:31 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:31 --> URI Class Initialized
INFO - 2016-02-29 13:48:31 --> Router Class Initialized
INFO - 2016-02-29 13:48:31 --> Output Class Initialized
INFO - 2016-02-29 13:48:31 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:31 --> Input Class Initialized
INFO - 2016-02-29 13:48:31 --> Language Class Initialized
INFO - 2016-02-29 13:48:31 --> Loader Class Initialized
INFO - 2016-02-29 13:48:31 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:31 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:31 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:31 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:31 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:32 --> Controller Class Initialized
INFO - 2016-02-29 13:48:32 --> Model Class Initialized
INFO - 2016-02-29 13:48:32 --> Model Class Initialized
INFO - 2016-02-29 13:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:32 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:32 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:32 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 16:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:32 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:32 --> Total execution time: 1.1107
INFO - 2016-02-29 13:48:35 --> Config Class Initialized
INFO - 2016-02-29 13:48:35 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:35 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:35 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:35 --> URI Class Initialized
INFO - 2016-02-29 13:48:35 --> Router Class Initialized
INFO - 2016-02-29 13:48:35 --> Output Class Initialized
INFO - 2016-02-29 13:48:35 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:35 --> Input Class Initialized
INFO - 2016-02-29 13:48:35 --> Language Class Initialized
INFO - 2016-02-29 13:48:35 --> Loader Class Initialized
INFO - 2016-02-29 13:48:35 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:35 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:35 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:35 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:35 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:36 --> Controller Class Initialized
INFO - 2016-02-29 13:48:36 --> Model Class Initialized
INFO - 2016-02-29 13:48:36 --> Model Class Initialized
INFO - 2016-02-29 13:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:36 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:36 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:36 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:36 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:36 --> Total execution time: 1.1897
INFO - 2016-02-29 13:48:41 --> Config Class Initialized
INFO - 2016-02-29 13:48:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:41 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:41 --> URI Class Initialized
INFO - 2016-02-29 13:48:41 --> Router Class Initialized
INFO - 2016-02-29 13:48:41 --> Output Class Initialized
INFO - 2016-02-29 13:48:41 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:41 --> Input Class Initialized
INFO - 2016-02-29 13:48:41 --> Language Class Initialized
INFO - 2016-02-29 13:48:41 --> Loader Class Initialized
INFO - 2016-02-29 13:48:41 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:41 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:41 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:41 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:41 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:42 --> Controller Class Initialized
INFO - 2016-02-29 13:48:42 --> Model Class Initialized
INFO - 2016-02-29 13:48:42 --> Model Class Initialized
INFO - 2016-02-29 13:48:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:42 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:42 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 16:48:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:42 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:42 --> Total execution time: 1.1301
INFO - 2016-02-29 13:48:46 --> Config Class Initialized
INFO - 2016-02-29 13:48:46 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:48:46 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:48:46 --> Utf8 Class Initialized
INFO - 2016-02-29 13:48:46 --> URI Class Initialized
INFO - 2016-02-29 13:48:46 --> Router Class Initialized
INFO - 2016-02-29 13:48:46 --> Output Class Initialized
INFO - 2016-02-29 13:48:46 --> Security Class Initialized
DEBUG - 2016-02-29 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:48:46 --> Input Class Initialized
INFO - 2016-02-29 13:48:46 --> Language Class Initialized
INFO - 2016-02-29 13:48:46 --> Loader Class Initialized
INFO - 2016-02-29 13:48:46 --> Helper loaded: url_helper
INFO - 2016-02-29 13:48:46 --> Helper loaded: file_helper
INFO - 2016-02-29 13:48:46 --> Helper loaded: date_helper
INFO - 2016-02-29 13:48:46 --> Helper loaded: form_helper
INFO - 2016-02-29 13:48:46 --> Database Driver Class Initialized
INFO - 2016-02-29 13:48:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:48:47 --> Controller Class Initialized
INFO - 2016-02-29 13:48:47 --> Model Class Initialized
INFO - 2016-02-29 13:48:47 --> Model Class Initialized
INFO - 2016-02-29 13:48:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:48:47 --> Pagination Class Initialized
INFO - 2016-02-29 13:48:47 --> Helper loaded: text_helper
INFO - 2016-02-29 13:48:47 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:48:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:48:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:48:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:48:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:48:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:48:47 --> Final output sent to browser
DEBUG - 2016-02-29 16:48:47 --> Total execution time: 1.2055
INFO - 2016-02-29 13:49:09 --> Config Class Initialized
INFO - 2016-02-29 13:49:09 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:49:09 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:49:09 --> Utf8 Class Initialized
INFO - 2016-02-29 13:49:09 --> URI Class Initialized
INFO - 2016-02-29 13:49:09 --> Router Class Initialized
INFO - 2016-02-29 13:49:09 --> Output Class Initialized
INFO - 2016-02-29 13:49:09 --> Security Class Initialized
DEBUG - 2016-02-29 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:49:09 --> Input Class Initialized
INFO - 2016-02-29 13:49:09 --> Language Class Initialized
INFO - 2016-02-29 13:49:09 --> Loader Class Initialized
INFO - 2016-02-29 13:49:09 --> Helper loaded: url_helper
INFO - 2016-02-29 13:49:09 --> Helper loaded: file_helper
INFO - 2016-02-29 13:49:09 --> Helper loaded: date_helper
INFO - 2016-02-29 13:49:09 --> Helper loaded: form_helper
INFO - 2016-02-29 13:49:09 --> Database Driver Class Initialized
INFO - 2016-02-29 13:49:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:49:10 --> Controller Class Initialized
INFO - 2016-02-29 13:49:10 --> Model Class Initialized
INFO - 2016-02-29 13:49:10 --> Model Class Initialized
INFO - 2016-02-29 13:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:49:10 --> Pagination Class Initialized
INFO - 2016-02-29 13:49:10 --> Helper loaded: text_helper
INFO - 2016-02-29 13:49:10 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:49:10 --> Final output sent to browser
DEBUG - 2016-02-29 16:49:10 --> Total execution time: 1.1376
INFO - 2016-02-29 13:49:32 --> Config Class Initialized
INFO - 2016-02-29 13:49:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:49:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:49:32 --> Utf8 Class Initialized
INFO - 2016-02-29 13:49:32 --> URI Class Initialized
INFO - 2016-02-29 13:49:32 --> Router Class Initialized
INFO - 2016-02-29 13:49:32 --> Output Class Initialized
INFO - 2016-02-29 13:49:32 --> Security Class Initialized
DEBUG - 2016-02-29 13:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:49:32 --> Input Class Initialized
INFO - 2016-02-29 13:49:32 --> Language Class Initialized
INFO - 2016-02-29 13:49:32 --> Loader Class Initialized
INFO - 2016-02-29 13:49:32 --> Helper loaded: url_helper
INFO - 2016-02-29 13:49:32 --> Helper loaded: file_helper
INFO - 2016-02-29 13:49:32 --> Helper loaded: date_helper
INFO - 2016-02-29 13:49:32 --> Helper loaded: form_helper
INFO - 2016-02-29 13:49:32 --> Database Driver Class Initialized
INFO - 2016-02-29 13:49:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:49:33 --> Controller Class Initialized
INFO - 2016-02-29 13:49:33 --> Model Class Initialized
INFO - 2016-02-29 13:49:33 --> Model Class Initialized
INFO - 2016-02-29 13:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:49:33 --> Pagination Class Initialized
INFO - 2016-02-29 13:49:33 --> Helper loaded: text_helper
INFO - 2016-02-29 13:49:33 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:49:33 --> Final output sent to browser
DEBUG - 2016-02-29 16:49:33 --> Total execution time: 1.1497
INFO - 2016-02-29 13:50:15 --> Config Class Initialized
INFO - 2016-02-29 13:50:15 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:50:15 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:50:15 --> Utf8 Class Initialized
INFO - 2016-02-29 13:50:15 --> URI Class Initialized
INFO - 2016-02-29 13:50:15 --> Router Class Initialized
INFO - 2016-02-29 13:50:15 --> Output Class Initialized
INFO - 2016-02-29 13:50:15 --> Security Class Initialized
DEBUG - 2016-02-29 13:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:50:15 --> Input Class Initialized
INFO - 2016-02-29 13:50:15 --> Language Class Initialized
INFO - 2016-02-29 13:50:15 --> Loader Class Initialized
INFO - 2016-02-29 13:50:15 --> Helper loaded: url_helper
INFO - 2016-02-29 13:50:15 --> Helper loaded: file_helper
INFO - 2016-02-29 13:50:15 --> Helper loaded: date_helper
INFO - 2016-02-29 13:50:15 --> Helper loaded: form_helper
INFO - 2016-02-29 13:50:15 --> Database Driver Class Initialized
INFO - 2016-02-29 13:50:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:50:16 --> Controller Class Initialized
INFO - 2016-02-29 13:50:16 --> Model Class Initialized
INFO - 2016-02-29 13:50:16 --> Model Class Initialized
INFO - 2016-02-29 13:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:50:16 --> Pagination Class Initialized
INFO - 2016-02-29 13:50:16 --> Helper loaded: text_helper
INFO - 2016-02-29 13:50:16 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:50:16 --> Final output sent to browser
DEBUG - 2016-02-29 16:50:16 --> Total execution time: 1.1730
INFO - 2016-02-29 13:53:29 --> Config Class Initialized
INFO - 2016-02-29 13:53:29 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:53:29 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:53:29 --> Utf8 Class Initialized
INFO - 2016-02-29 13:53:29 --> URI Class Initialized
INFO - 2016-02-29 13:53:29 --> Router Class Initialized
INFO - 2016-02-29 13:53:29 --> Output Class Initialized
INFO - 2016-02-29 13:53:29 --> Security Class Initialized
DEBUG - 2016-02-29 13:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:53:29 --> Input Class Initialized
INFO - 2016-02-29 13:53:29 --> Language Class Initialized
INFO - 2016-02-29 13:53:29 --> Loader Class Initialized
INFO - 2016-02-29 13:53:29 --> Helper loaded: url_helper
INFO - 2016-02-29 13:53:29 --> Helper loaded: file_helper
INFO - 2016-02-29 13:53:29 --> Helper loaded: date_helper
INFO - 2016-02-29 13:53:29 --> Helper loaded: form_helper
INFO - 2016-02-29 13:53:29 --> Database Driver Class Initialized
INFO - 2016-02-29 13:53:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:53:30 --> Controller Class Initialized
INFO - 2016-02-29 13:53:30 --> Model Class Initialized
INFO - 2016-02-29 13:53:30 --> Model Class Initialized
INFO - 2016-02-29 13:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:53:30 --> Pagination Class Initialized
INFO - 2016-02-29 13:53:30 --> Helper loaded: text_helper
INFO - 2016-02-29 13:53:30 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:53:30 --> Final output sent to browser
DEBUG - 2016-02-29 16:53:30 --> Total execution time: 1.1613
INFO - 2016-02-29 13:55:05 --> Config Class Initialized
INFO - 2016-02-29 13:55:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:55:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:55:05 --> Utf8 Class Initialized
INFO - 2016-02-29 13:55:06 --> URI Class Initialized
INFO - 2016-02-29 13:55:06 --> Router Class Initialized
INFO - 2016-02-29 13:55:06 --> Output Class Initialized
INFO - 2016-02-29 13:55:06 --> Security Class Initialized
DEBUG - 2016-02-29 13:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:55:06 --> Input Class Initialized
INFO - 2016-02-29 13:55:06 --> Language Class Initialized
INFO - 2016-02-29 13:55:06 --> Loader Class Initialized
INFO - 2016-02-29 13:55:06 --> Helper loaded: url_helper
INFO - 2016-02-29 13:55:06 --> Helper loaded: file_helper
INFO - 2016-02-29 13:55:06 --> Helper loaded: date_helper
INFO - 2016-02-29 13:55:06 --> Helper loaded: form_helper
INFO - 2016-02-29 13:55:06 --> Database Driver Class Initialized
INFO - 2016-02-29 13:55:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:55:07 --> Controller Class Initialized
INFO - 2016-02-29 13:55:07 --> Model Class Initialized
INFO - 2016-02-29 13:55:07 --> Model Class Initialized
INFO - 2016-02-29 13:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:55:07 --> Pagination Class Initialized
INFO - 2016-02-29 13:55:07 --> Helper loaded: text_helper
INFO - 2016-02-29 13:55:07 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:55:07 --> Final output sent to browser
DEBUG - 2016-02-29 16:55:07 --> Total execution time: 1.2454
INFO - 2016-02-29 13:56:11 --> Config Class Initialized
INFO - 2016-02-29 13:56:11 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:56:11 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:56:11 --> Utf8 Class Initialized
INFO - 2016-02-29 13:56:11 --> URI Class Initialized
INFO - 2016-02-29 13:56:11 --> Router Class Initialized
INFO - 2016-02-29 13:56:11 --> Output Class Initialized
INFO - 2016-02-29 13:56:11 --> Security Class Initialized
DEBUG - 2016-02-29 13:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:56:11 --> Input Class Initialized
INFO - 2016-02-29 13:56:11 --> Language Class Initialized
INFO - 2016-02-29 13:56:11 --> Loader Class Initialized
INFO - 2016-02-29 13:56:11 --> Helper loaded: url_helper
INFO - 2016-02-29 13:56:11 --> Helper loaded: file_helper
INFO - 2016-02-29 13:56:11 --> Helper loaded: date_helper
INFO - 2016-02-29 13:56:11 --> Helper loaded: form_helper
INFO - 2016-02-29 13:56:11 --> Database Driver Class Initialized
INFO - 2016-02-29 13:56:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:56:12 --> Controller Class Initialized
INFO - 2016-02-29 13:56:12 --> Model Class Initialized
INFO - 2016-02-29 13:56:12 --> Model Class Initialized
INFO - 2016-02-29 13:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:56:12 --> Pagination Class Initialized
INFO - 2016-02-29 13:56:12 --> Helper loaded: text_helper
INFO - 2016-02-29 13:56:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:56:12 --> Final output sent to browser
DEBUG - 2016-02-29 16:56:12 --> Total execution time: 1.1775
INFO - 2016-02-29 13:59:43 --> Config Class Initialized
INFO - 2016-02-29 13:59:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:59:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:59:43 --> Utf8 Class Initialized
INFO - 2016-02-29 13:59:43 --> URI Class Initialized
INFO - 2016-02-29 13:59:43 --> Router Class Initialized
INFO - 2016-02-29 13:59:43 --> Output Class Initialized
INFO - 2016-02-29 13:59:43 --> Security Class Initialized
DEBUG - 2016-02-29 13:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:59:43 --> Input Class Initialized
INFO - 2016-02-29 13:59:43 --> Language Class Initialized
INFO - 2016-02-29 13:59:43 --> Loader Class Initialized
INFO - 2016-02-29 13:59:43 --> Helper loaded: url_helper
INFO - 2016-02-29 13:59:43 --> Helper loaded: file_helper
INFO - 2016-02-29 13:59:43 --> Helper loaded: date_helper
INFO - 2016-02-29 13:59:43 --> Helper loaded: form_helper
INFO - 2016-02-29 13:59:43 --> Database Driver Class Initialized
INFO - 2016-02-29 13:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:59:44 --> Controller Class Initialized
INFO - 2016-02-29 13:59:44 --> Model Class Initialized
INFO - 2016-02-29 13:59:44 --> Model Class Initialized
INFO - 2016-02-29 13:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:59:44 --> Pagination Class Initialized
INFO - 2016-02-29 13:59:44 --> Helper loaded: text_helper
INFO - 2016-02-29 13:59:44 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 16:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:59:44 --> Final output sent to browser
DEBUG - 2016-02-29 16:59:44 --> Total execution time: 1.1346
INFO - 2016-02-29 13:59:45 --> Config Class Initialized
INFO - 2016-02-29 13:59:45 --> Hooks Class Initialized
DEBUG - 2016-02-29 13:59:45 --> UTF-8 Support Enabled
INFO - 2016-02-29 13:59:45 --> Utf8 Class Initialized
INFO - 2016-02-29 13:59:45 --> URI Class Initialized
INFO - 2016-02-29 13:59:45 --> Router Class Initialized
INFO - 2016-02-29 13:59:45 --> Output Class Initialized
INFO - 2016-02-29 13:59:45 --> Security Class Initialized
DEBUG - 2016-02-29 13:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 13:59:45 --> Input Class Initialized
INFO - 2016-02-29 13:59:45 --> Language Class Initialized
INFO - 2016-02-29 13:59:45 --> Loader Class Initialized
INFO - 2016-02-29 13:59:45 --> Helper loaded: url_helper
INFO - 2016-02-29 13:59:45 --> Helper loaded: file_helper
INFO - 2016-02-29 13:59:45 --> Helper loaded: date_helper
INFO - 2016-02-29 13:59:45 --> Helper loaded: form_helper
INFO - 2016-02-29 13:59:45 --> Database Driver Class Initialized
INFO - 2016-02-29 13:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 13:59:46 --> Controller Class Initialized
INFO - 2016-02-29 13:59:46 --> Model Class Initialized
INFO - 2016-02-29 13:59:46 --> Model Class Initialized
INFO - 2016-02-29 13:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 13:59:46 --> Pagination Class Initialized
INFO - 2016-02-29 13:59:46 --> Helper loaded: text_helper
INFO - 2016-02-29 13:59:46 --> Helper loaded: cookie_helper
INFO - 2016-02-29 16:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 16:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 16:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 16:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 16:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 16:59:47 --> Final output sent to browser
DEBUG - 2016-02-29 16:59:47 --> Total execution time: 1.2310
INFO - 2016-02-29 14:00:03 --> Config Class Initialized
INFO - 2016-02-29 14:00:03 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:03 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:03 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:03 --> URI Class Initialized
INFO - 2016-02-29 14:00:03 --> Router Class Initialized
INFO - 2016-02-29 14:00:03 --> Output Class Initialized
INFO - 2016-02-29 14:00:03 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:03 --> Input Class Initialized
INFO - 2016-02-29 14:00:03 --> Language Class Initialized
INFO - 2016-02-29 14:00:03 --> Loader Class Initialized
INFO - 2016-02-29 14:00:03 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:03 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:03 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:03 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:03 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:04 --> Controller Class Initialized
INFO - 2016-02-29 14:00:04 --> Model Class Initialized
INFO - 2016-02-29 14:00:04 --> Model Class Initialized
INFO - 2016-02-29 14:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:04 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:04 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:04 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:00:04 --> Final output sent to browser
DEBUG - 2016-02-29 17:00:04 --> Total execution time: 1.3410
INFO - 2016-02-29 14:00:07 --> Config Class Initialized
INFO - 2016-02-29 14:00:07 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:07 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:07 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:07 --> URI Class Initialized
INFO - 2016-02-29 14:00:07 --> Router Class Initialized
INFO - 2016-02-29 14:00:07 --> Output Class Initialized
INFO - 2016-02-29 14:00:07 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:07 --> Input Class Initialized
INFO - 2016-02-29 14:00:07 --> Language Class Initialized
INFO - 2016-02-29 14:00:07 --> Loader Class Initialized
INFO - 2016-02-29 14:00:07 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:07 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:07 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:07 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:07 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:08 --> Controller Class Initialized
INFO - 2016-02-29 14:00:08 --> Model Class Initialized
INFO - 2016-02-29 14:00:08 --> Model Class Initialized
INFO - 2016-02-29 14:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:08 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:08 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:08 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:11 --> Config Class Initialized
INFO - 2016-02-29 14:00:11 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:11 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:11 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:11 --> URI Class Initialized
INFO - 2016-02-29 14:00:11 --> Router Class Initialized
INFO - 2016-02-29 14:00:11 --> Output Class Initialized
INFO - 2016-02-29 14:00:11 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:11 --> Input Class Initialized
INFO - 2016-02-29 14:00:11 --> Language Class Initialized
INFO - 2016-02-29 14:00:11 --> Loader Class Initialized
INFO - 2016-02-29 14:00:11 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:11 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:11 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:11 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:11 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:12 --> Controller Class Initialized
INFO - 2016-02-29 14:00:12 --> Model Class Initialized
INFO - 2016-02-29 14:00:12 --> Model Class Initialized
INFO - 2016-02-29 14:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:12 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:12 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:12 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:13 --> Config Class Initialized
INFO - 2016-02-29 14:00:13 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:13 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:13 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:13 --> URI Class Initialized
INFO - 2016-02-29 14:00:13 --> Router Class Initialized
INFO - 2016-02-29 14:00:13 --> Output Class Initialized
INFO - 2016-02-29 14:00:13 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:13 --> Input Class Initialized
INFO - 2016-02-29 14:00:13 --> Language Class Initialized
INFO - 2016-02-29 14:00:13 --> Loader Class Initialized
INFO - 2016-02-29 14:00:13 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:13 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:13 --> Config Class Initialized
INFO - 2016-02-29 14:00:13 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:13 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:13 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:13 --> URI Class Initialized
INFO - 2016-02-29 14:00:13 --> Router Class Initialized
INFO - 2016-02-29 14:00:13 --> Output Class Initialized
INFO - 2016-02-29 14:00:13 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:13 --> Input Class Initialized
INFO - 2016-02-29 14:00:13 --> Language Class Initialized
INFO - 2016-02-29 14:00:13 --> Loader Class Initialized
INFO - 2016-02-29 14:00:13 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:13 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:13 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:14 --> Controller Class Initialized
INFO - 2016-02-29 14:00:14 --> Model Class Initialized
INFO - 2016-02-29 14:00:14 --> Model Class Initialized
INFO - 2016-02-29 14:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:14 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:14 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:14 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:14 --> Controller Class Initialized
INFO - 2016-02-29 14:00:14 --> Model Class Initialized
INFO - 2016-02-29 14:00:14 --> Model Class Initialized
INFO - 2016-02-29 14:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:14 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:14 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:14 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:16 --> Config Class Initialized
INFO - 2016-02-29 14:00:16 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:16 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:16 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:16 --> URI Class Initialized
INFO - 2016-02-29 14:00:16 --> Router Class Initialized
INFO - 2016-02-29 14:00:16 --> Output Class Initialized
INFO - 2016-02-29 14:00:16 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:16 --> Input Class Initialized
INFO - 2016-02-29 14:00:16 --> Language Class Initialized
INFO - 2016-02-29 14:00:16 --> Loader Class Initialized
INFO - 2016-02-29 14:00:16 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:16 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:16 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:16 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:16 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:17 --> Controller Class Initialized
INFO - 2016-02-29 14:00:17 --> Model Class Initialized
INFO - 2016-02-29 14:00:17 --> Model Class Initialized
INFO - 2016-02-29 14:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:17 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:17 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:17 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:19 --> Config Class Initialized
INFO - 2016-02-29 14:00:19 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:19 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:19 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:19 --> URI Class Initialized
INFO - 2016-02-29 14:00:19 --> Router Class Initialized
INFO - 2016-02-29 14:00:19 --> Output Class Initialized
INFO - 2016-02-29 14:00:19 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:19 --> Input Class Initialized
INFO - 2016-02-29 14:00:19 --> Language Class Initialized
INFO - 2016-02-29 14:00:19 --> Loader Class Initialized
INFO - 2016-02-29 14:00:19 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:19 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:19 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:19 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:19 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:20 --> Controller Class Initialized
INFO - 2016-02-29 14:00:20 --> Model Class Initialized
INFO - 2016-02-29 14:00:20 --> Model Class Initialized
INFO - 2016-02-29 14:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:20 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:20 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 17:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:00:20 --> Final output sent to browser
DEBUG - 2016-02-29 17:00:20 --> Total execution time: 1.1439
INFO - 2016-02-29 14:00:22 --> Config Class Initialized
INFO - 2016-02-29 14:00:22 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:22 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:22 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:22 --> URI Class Initialized
INFO - 2016-02-29 14:00:22 --> Router Class Initialized
INFO - 2016-02-29 14:00:22 --> Output Class Initialized
INFO - 2016-02-29 14:00:22 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:22 --> Input Class Initialized
INFO - 2016-02-29 14:00:22 --> Language Class Initialized
INFO - 2016-02-29 14:00:22 --> Loader Class Initialized
INFO - 2016-02-29 14:00:22 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:22 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:22 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:22 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:22 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:23 --> Controller Class Initialized
INFO - 2016-02-29 14:00:23 --> Model Class Initialized
INFO - 2016-02-29 14:00:23 --> Model Class Initialized
INFO - 2016-02-29 14:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:23 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:23 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:23 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:00:23 --> Final output sent to browser
DEBUG - 2016-02-29 17:00:23 --> Total execution time: 1.2973
INFO - 2016-02-29 14:00:25 --> Config Class Initialized
INFO - 2016-02-29 14:00:25 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:25 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:25 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:25 --> URI Class Initialized
INFO - 2016-02-29 14:00:25 --> Router Class Initialized
INFO - 2016-02-29 14:00:25 --> Output Class Initialized
INFO - 2016-02-29 14:00:25 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:25 --> Input Class Initialized
INFO - 2016-02-29 14:00:25 --> Language Class Initialized
INFO - 2016-02-29 14:00:25 --> Loader Class Initialized
INFO - 2016-02-29 14:00:25 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:25 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:25 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:25 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:25 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:26 --> Controller Class Initialized
INFO - 2016-02-29 14:00:26 --> Model Class Initialized
INFO - 2016-02-29 14:00:26 --> Model Class Initialized
INFO - 2016-02-29 14:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:26 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:26 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:26 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:29 --> Config Class Initialized
INFO - 2016-02-29 14:00:29 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:29 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:29 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:29 --> URI Class Initialized
INFO - 2016-02-29 14:00:29 --> Router Class Initialized
INFO - 2016-02-29 14:00:29 --> Output Class Initialized
INFO - 2016-02-29 14:00:29 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:29 --> Input Class Initialized
INFO - 2016-02-29 14:00:29 --> Language Class Initialized
INFO - 2016-02-29 14:00:29 --> Loader Class Initialized
INFO - 2016-02-29 14:00:29 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:29 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:29 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:29 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:29 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:30 --> Controller Class Initialized
INFO - 2016-02-29 14:00:30 --> Model Class Initialized
INFO - 2016-02-29 14:00:30 --> Model Class Initialized
INFO - 2016-02-29 14:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:30 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:30 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:30 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:00:57 --> Config Class Initialized
INFO - 2016-02-29 14:00:57 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:00:57 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:00:57 --> Utf8 Class Initialized
INFO - 2016-02-29 14:00:57 --> URI Class Initialized
INFO - 2016-02-29 14:00:57 --> Router Class Initialized
INFO - 2016-02-29 14:00:57 --> Output Class Initialized
INFO - 2016-02-29 14:00:57 --> Security Class Initialized
DEBUG - 2016-02-29 14:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:00:57 --> Input Class Initialized
INFO - 2016-02-29 14:00:57 --> Language Class Initialized
INFO - 2016-02-29 14:00:57 --> Loader Class Initialized
INFO - 2016-02-29 14:00:57 --> Helper loaded: url_helper
INFO - 2016-02-29 14:00:57 --> Helper loaded: file_helper
INFO - 2016-02-29 14:00:57 --> Helper loaded: date_helper
INFO - 2016-02-29 14:00:57 --> Helper loaded: form_helper
INFO - 2016-02-29 14:00:57 --> Database Driver Class Initialized
INFO - 2016-02-29 14:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:00:58 --> Controller Class Initialized
INFO - 2016-02-29 14:00:58 --> Model Class Initialized
INFO - 2016-02-29 14:00:58 --> Model Class Initialized
INFO - 2016-02-29 14:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:00:58 --> Pagination Class Initialized
INFO - 2016-02-29 14:00:58 --> Helper loaded: text_helper
INFO - 2016-02-29 14:00:58 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:00:58 --> Final output sent to browser
DEBUG - 2016-02-29 17:00:58 --> Total execution time: 1.1948
INFO - 2016-02-29 14:01:01 --> Config Class Initialized
INFO - 2016-02-29 14:01:01 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:01:01 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:01:01 --> Utf8 Class Initialized
INFO - 2016-02-29 14:01:01 --> URI Class Initialized
INFO - 2016-02-29 14:01:01 --> Router Class Initialized
INFO - 2016-02-29 14:01:01 --> Output Class Initialized
INFO - 2016-02-29 14:01:01 --> Security Class Initialized
DEBUG - 2016-02-29 14:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:01:01 --> Input Class Initialized
INFO - 2016-02-29 14:01:01 --> Language Class Initialized
INFO - 2016-02-29 14:01:01 --> Loader Class Initialized
INFO - 2016-02-29 14:01:01 --> Helper loaded: url_helper
INFO - 2016-02-29 14:01:01 --> Helper loaded: file_helper
INFO - 2016-02-29 14:01:01 --> Helper loaded: date_helper
INFO - 2016-02-29 14:01:01 --> Helper loaded: form_helper
INFO - 2016-02-29 14:01:01 --> Database Driver Class Initialized
INFO - 2016-02-29 14:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:01:02 --> Controller Class Initialized
INFO - 2016-02-29 14:01:02 --> Model Class Initialized
INFO - 2016-02-29 14:01:02 --> Model Class Initialized
INFO - 2016-02-29 14:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:01:02 --> Pagination Class Initialized
INFO - 2016-02-29 14:01:02 --> Helper loaded: text_helper
INFO - 2016-02-29 14:01:02 --> Helper loaded: cookie_helper
INFO - 2016-02-29 14:01:58 --> Config Class Initialized
INFO - 2016-02-29 14:01:58 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:01:58 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:01:58 --> Utf8 Class Initialized
INFO - 2016-02-29 14:01:58 --> URI Class Initialized
INFO - 2016-02-29 14:01:58 --> Router Class Initialized
INFO - 2016-02-29 14:01:58 --> Output Class Initialized
INFO - 2016-02-29 14:01:58 --> Security Class Initialized
DEBUG - 2016-02-29 14:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:01:58 --> Input Class Initialized
INFO - 2016-02-29 14:01:58 --> Language Class Initialized
INFO - 2016-02-29 14:01:58 --> Loader Class Initialized
INFO - 2016-02-29 14:01:58 --> Helper loaded: url_helper
INFO - 2016-02-29 14:01:58 --> Helper loaded: file_helper
INFO - 2016-02-29 14:01:58 --> Helper loaded: date_helper
INFO - 2016-02-29 14:01:58 --> Helper loaded: form_helper
INFO - 2016-02-29 14:01:58 --> Database Driver Class Initialized
INFO - 2016-02-29 14:01:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:01:59 --> Controller Class Initialized
INFO - 2016-02-29 14:01:59 --> Model Class Initialized
INFO - 2016-02-29 14:01:59 --> Model Class Initialized
INFO - 2016-02-29 14:01:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:01:59 --> Pagination Class Initialized
INFO - 2016-02-29 14:01:59 --> Helper loaded: text_helper
INFO - 2016-02-29 14:01:59 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:01:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:01:59 --> Final output sent to browser
DEBUG - 2016-02-29 17:01:59 --> Total execution time: 1.1910
INFO - 2016-02-29 14:04:41 --> Config Class Initialized
INFO - 2016-02-29 14:04:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:04:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:04:41 --> Utf8 Class Initialized
INFO - 2016-02-29 14:04:41 --> URI Class Initialized
DEBUG - 2016-02-29 14:04:41 --> No URI present. Default controller set.
INFO - 2016-02-29 14:04:41 --> Router Class Initialized
INFO - 2016-02-29 14:04:41 --> Output Class Initialized
INFO - 2016-02-29 14:04:41 --> Security Class Initialized
DEBUG - 2016-02-29 14:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:04:41 --> Input Class Initialized
INFO - 2016-02-29 14:04:41 --> Language Class Initialized
INFO - 2016-02-29 14:04:41 --> Loader Class Initialized
INFO - 2016-02-29 14:04:41 --> Helper loaded: url_helper
INFO - 2016-02-29 14:04:41 --> Helper loaded: file_helper
INFO - 2016-02-29 14:04:41 --> Helper loaded: date_helper
INFO - 2016-02-29 14:04:41 --> Helper loaded: form_helper
INFO - 2016-02-29 14:04:41 --> Database Driver Class Initialized
INFO - 2016-02-29 14:04:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:04:42 --> Controller Class Initialized
INFO - 2016-02-29 14:04:42 --> Model Class Initialized
INFO - 2016-02-29 14:04:42 --> Model Class Initialized
INFO - 2016-02-29 14:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:04:42 --> Pagination Class Initialized
INFO - 2016-02-29 14:04:42 --> Helper loaded: text_helper
INFO - 2016-02-29 14:04:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 17:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:04:42 --> Final output sent to browser
DEBUG - 2016-02-29 17:04:42 --> Total execution time: 1.1383
INFO - 2016-02-29 14:04:43 --> Config Class Initialized
INFO - 2016-02-29 14:04:43 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:04:43 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:04:43 --> Utf8 Class Initialized
INFO - 2016-02-29 14:04:43 --> URI Class Initialized
INFO - 2016-02-29 14:04:43 --> Router Class Initialized
INFO - 2016-02-29 14:04:43 --> Output Class Initialized
INFO - 2016-02-29 14:04:43 --> Security Class Initialized
DEBUG - 2016-02-29 14:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:04:43 --> Input Class Initialized
INFO - 2016-02-29 14:04:43 --> Language Class Initialized
INFO - 2016-02-29 14:04:43 --> Loader Class Initialized
INFO - 2016-02-29 14:04:43 --> Helper loaded: url_helper
INFO - 2016-02-29 14:04:43 --> Helper loaded: file_helper
INFO - 2016-02-29 14:04:43 --> Helper loaded: date_helper
INFO - 2016-02-29 14:04:43 --> Helper loaded: form_helper
INFO - 2016-02-29 14:04:43 --> Database Driver Class Initialized
INFO - 2016-02-29 14:04:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:04:44 --> Controller Class Initialized
INFO - 2016-02-29 14:04:44 --> Model Class Initialized
INFO - 2016-02-29 14:04:44 --> Model Class Initialized
INFO - 2016-02-29 14:04:44 --> Form Validation Class Initialized
INFO - 2016-02-29 14:04:44 --> Helper loaded: text_helper
INFO - 2016-02-29 14:04:44 --> Config Class Initialized
INFO - 2016-02-29 14:04:44 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:04:44 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:04:44 --> Utf8 Class Initialized
INFO - 2016-02-29 14:04:44 --> URI Class Initialized
DEBUG - 2016-02-29 14:04:44 --> No URI present. Default controller set.
INFO - 2016-02-29 14:04:44 --> Router Class Initialized
INFO - 2016-02-29 14:04:44 --> Output Class Initialized
INFO - 2016-02-29 14:04:44 --> Security Class Initialized
DEBUG - 2016-02-29 14:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:04:44 --> Input Class Initialized
INFO - 2016-02-29 14:04:44 --> Language Class Initialized
INFO - 2016-02-29 14:04:44 --> Loader Class Initialized
INFO - 2016-02-29 14:04:44 --> Helper loaded: url_helper
INFO - 2016-02-29 14:04:44 --> Helper loaded: file_helper
INFO - 2016-02-29 14:04:44 --> Helper loaded: date_helper
INFO - 2016-02-29 14:04:44 --> Helper loaded: form_helper
INFO - 2016-02-29 14:04:44 --> Database Driver Class Initialized
INFO - 2016-02-29 14:04:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:04:45 --> Controller Class Initialized
INFO - 2016-02-29 14:04:45 --> Model Class Initialized
INFO - 2016-02-29 14:04:45 --> Model Class Initialized
INFO - 2016-02-29 14:04:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:04:45 --> Pagination Class Initialized
INFO - 2016-02-29 14:04:45 --> Helper loaded: text_helper
INFO - 2016-02-29 14:04:45 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:04:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:04:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:04:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 17:04:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:04:45 --> Final output sent to browser
DEBUG - 2016-02-29 17:04:45 --> Total execution time: 1.1052
INFO - 2016-02-29 14:06:00 --> Config Class Initialized
INFO - 2016-02-29 14:06:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:06:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:06:00 --> Utf8 Class Initialized
INFO - 2016-02-29 14:06:00 --> URI Class Initialized
INFO - 2016-02-29 14:06:00 --> Router Class Initialized
INFO - 2016-02-29 14:06:00 --> Output Class Initialized
INFO - 2016-02-29 14:06:00 --> Security Class Initialized
DEBUG - 2016-02-29 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:06:00 --> Input Class Initialized
INFO - 2016-02-29 14:06:00 --> Language Class Initialized
INFO - 2016-02-29 14:06:00 --> Loader Class Initialized
INFO - 2016-02-29 14:06:00 --> Helper loaded: url_helper
INFO - 2016-02-29 14:06:00 --> Helper loaded: file_helper
INFO - 2016-02-29 14:06:00 --> Helper loaded: date_helper
INFO - 2016-02-29 14:06:00 --> Helper loaded: form_helper
INFO - 2016-02-29 14:06:00 --> Database Driver Class Initialized
INFO - 2016-02-29 14:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:06:01 --> Controller Class Initialized
INFO - 2016-02-29 14:06:01 --> Model Class Initialized
INFO - 2016-02-29 14:06:01 --> Model Class Initialized
INFO - 2016-02-29 14:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:06:01 --> Pagination Class Initialized
INFO - 2016-02-29 14:06:01 --> Helper loaded: text_helper
INFO - 2016-02-29 14:06:01 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 17:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-29 17:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:06:01 --> Final output sent to browser
DEBUG - 2016-02-29 17:06:01 --> Total execution time: 1.1312
INFO - 2016-02-29 14:06:02 --> Config Class Initialized
INFO - 2016-02-29 14:06:02 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:06:02 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:06:02 --> Utf8 Class Initialized
INFO - 2016-02-29 14:06:02 --> URI Class Initialized
INFO - 2016-02-29 14:06:02 --> Router Class Initialized
INFO - 2016-02-29 14:06:02 --> Output Class Initialized
INFO - 2016-02-29 14:06:02 --> Security Class Initialized
DEBUG - 2016-02-29 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:06:02 --> Input Class Initialized
INFO - 2016-02-29 14:06:02 --> Language Class Initialized
INFO - 2016-02-29 14:06:02 --> Loader Class Initialized
INFO - 2016-02-29 14:06:02 --> Helper loaded: url_helper
INFO - 2016-02-29 14:06:02 --> Helper loaded: file_helper
INFO - 2016-02-29 14:06:02 --> Helper loaded: date_helper
INFO - 2016-02-29 14:06:02 --> Helper loaded: form_helper
INFO - 2016-02-29 14:06:02 --> Database Driver Class Initialized
INFO - 2016-02-29 14:06:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:06:03 --> Controller Class Initialized
INFO - 2016-02-29 14:06:03 --> Model Class Initialized
INFO - 2016-02-29 14:06:03 --> Model Class Initialized
INFO - 2016-02-29 14:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:06:03 --> Pagination Class Initialized
INFO - 2016-02-29 14:06:03 --> Helper loaded: text_helper
INFO - 2016-02-29 14:06:03 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:06:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:06:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:06:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-29 17:06:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:06:03 --> Final output sent to browser
DEBUG - 2016-02-29 17:06:03 --> Total execution time: 1.1054
INFO - 2016-02-29 14:06:05 --> Config Class Initialized
INFO - 2016-02-29 14:06:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:06:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:06:05 --> Utf8 Class Initialized
INFO - 2016-02-29 14:06:05 --> URI Class Initialized
INFO - 2016-02-29 14:06:05 --> Router Class Initialized
INFO - 2016-02-29 14:06:05 --> Output Class Initialized
INFO - 2016-02-29 14:06:05 --> Security Class Initialized
DEBUG - 2016-02-29 14:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:06:05 --> Input Class Initialized
INFO - 2016-02-29 14:06:05 --> Language Class Initialized
INFO - 2016-02-29 14:06:05 --> Loader Class Initialized
INFO - 2016-02-29 14:06:05 --> Helper loaded: url_helper
INFO - 2016-02-29 14:06:05 --> Helper loaded: file_helper
INFO - 2016-02-29 14:06:05 --> Helper loaded: date_helper
INFO - 2016-02-29 14:06:05 --> Helper loaded: form_helper
INFO - 2016-02-29 14:06:05 --> Database Driver Class Initialized
INFO - 2016-02-29 14:06:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:06:06 --> Controller Class Initialized
INFO - 2016-02-29 14:06:06 --> Model Class Initialized
INFO - 2016-02-29 14:06:06 --> Model Class Initialized
INFO - 2016-02-29 14:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:06:06 --> Pagination Class Initialized
INFO - 2016-02-29 14:06:06 --> Helper loaded: text_helper
INFO - 2016-02-29 14:06:06 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:06:06 --> Final output sent to browser
DEBUG - 2016-02-29 17:06:06 --> Total execution time: 1.1600
INFO - 2016-02-29 14:06:21 --> Config Class Initialized
INFO - 2016-02-29 14:06:21 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:06:21 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:06:21 --> Utf8 Class Initialized
INFO - 2016-02-29 14:06:21 --> URI Class Initialized
INFO - 2016-02-29 14:06:21 --> Router Class Initialized
INFO - 2016-02-29 14:06:21 --> Output Class Initialized
INFO - 2016-02-29 14:06:21 --> Security Class Initialized
DEBUG - 2016-02-29 14:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:06:21 --> Input Class Initialized
INFO - 2016-02-29 14:06:21 --> Language Class Initialized
INFO - 2016-02-29 14:06:21 --> Loader Class Initialized
INFO - 2016-02-29 14:06:21 --> Helper loaded: url_helper
INFO - 2016-02-29 14:06:21 --> Helper loaded: file_helper
INFO - 2016-02-29 14:06:21 --> Helper loaded: date_helper
INFO - 2016-02-29 14:06:21 --> Helper loaded: form_helper
INFO - 2016-02-29 14:06:21 --> Database Driver Class Initialized
INFO - 2016-02-29 14:06:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:06:22 --> Controller Class Initialized
INFO - 2016-02-29 14:06:22 --> Model Class Initialized
INFO - 2016-02-29 14:06:23 --> Model Class Initialized
INFO - 2016-02-29 14:06:23 --> Form Validation Class Initialized
INFO - 2016-02-29 14:06:23 --> Helper loaded: text_helper
INFO - 2016-02-29 14:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 14:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-29 14:06:23 --> Final output sent to browser
DEBUG - 2016-02-29 14:06:23 --> Total execution time: 1.1010
INFO - 2016-02-29 14:06:26 --> Config Class Initialized
INFO - 2016-02-29 14:06:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:06:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:06:26 --> Utf8 Class Initialized
INFO - 2016-02-29 14:06:26 --> URI Class Initialized
INFO - 2016-02-29 14:06:26 --> Router Class Initialized
INFO - 2016-02-29 14:06:26 --> Output Class Initialized
INFO - 2016-02-29 14:06:26 --> Security Class Initialized
DEBUG - 2016-02-29 14:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:06:26 --> Input Class Initialized
INFO - 2016-02-29 14:06:26 --> Language Class Initialized
INFO - 2016-02-29 14:06:26 --> Loader Class Initialized
INFO - 2016-02-29 14:06:26 --> Helper loaded: url_helper
INFO - 2016-02-29 14:06:26 --> Helper loaded: file_helper
INFO - 2016-02-29 14:06:26 --> Helper loaded: date_helper
INFO - 2016-02-29 14:06:26 --> Helper loaded: form_helper
INFO - 2016-02-29 14:06:26 --> Database Driver Class Initialized
INFO - 2016-02-29 14:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:06:27 --> Controller Class Initialized
INFO - 2016-02-29 14:06:27 --> Model Class Initialized
INFO - 2016-02-29 14:06:27 --> Model Class Initialized
INFO - 2016-02-29 14:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:06:27 --> Pagination Class Initialized
INFO - 2016-02-29 14:06:27 --> Helper loaded: text_helper
INFO - 2016-02-29 14:06:27 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:06:27 --> Final output sent to browser
DEBUG - 2016-02-29 17:06:27 --> Total execution time: 1.2027
INFO - 2016-02-29 14:07:46 --> Config Class Initialized
INFO - 2016-02-29 14:07:46 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:07:46 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:07:46 --> Utf8 Class Initialized
INFO - 2016-02-29 14:07:46 --> URI Class Initialized
INFO - 2016-02-29 14:07:46 --> Router Class Initialized
INFO - 2016-02-29 14:07:46 --> Output Class Initialized
INFO - 2016-02-29 14:07:46 --> Security Class Initialized
DEBUG - 2016-02-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:07:47 --> Input Class Initialized
INFO - 2016-02-29 14:07:47 --> Language Class Initialized
INFO - 2016-02-29 14:07:47 --> Loader Class Initialized
INFO - 2016-02-29 14:07:47 --> Helper loaded: url_helper
INFO - 2016-02-29 14:07:47 --> Helper loaded: file_helper
INFO - 2016-02-29 14:07:47 --> Helper loaded: date_helper
INFO - 2016-02-29 14:07:47 --> Helper loaded: form_helper
INFO - 2016-02-29 14:07:47 --> Database Driver Class Initialized
INFO - 2016-02-29 14:07:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:07:48 --> Controller Class Initialized
INFO - 2016-02-29 14:07:48 --> Model Class Initialized
INFO - 2016-02-29 14:07:48 --> Model Class Initialized
INFO - 2016-02-29 14:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:07:48 --> Pagination Class Initialized
INFO - 2016-02-29 14:07:48 --> Helper loaded: text_helper
INFO - 2016-02-29 14:07:48 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:07:48 --> Final output sent to browser
DEBUG - 2016-02-29 17:07:48 --> Total execution time: 1.2020
INFO - 2016-02-29 14:08:51 --> Config Class Initialized
INFO - 2016-02-29 14:08:51 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:08:51 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:08:51 --> Utf8 Class Initialized
INFO - 2016-02-29 14:08:51 --> URI Class Initialized
INFO - 2016-02-29 14:08:51 --> Router Class Initialized
INFO - 2016-02-29 14:08:51 --> Output Class Initialized
INFO - 2016-02-29 14:08:51 --> Security Class Initialized
DEBUG - 2016-02-29 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:08:51 --> Input Class Initialized
INFO - 2016-02-29 14:08:51 --> Language Class Initialized
INFO - 2016-02-29 14:08:51 --> Loader Class Initialized
INFO - 2016-02-29 14:08:51 --> Helper loaded: url_helper
INFO - 2016-02-29 14:08:51 --> Helper loaded: file_helper
INFO - 2016-02-29 14:08:51 --> Helper loaded: date_helper
INFO - 2016-02-29 14:08:51 --> Helper loaded: form_helper
INFO - 2016-02-29 14:08:51 --> Database Driver Class Initialized
INFO - 2016-02-29 14:08:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:08:52 --> Controller Class Initialized
INFO - 2016-02-29 14:08:52 --> Model Class Initialized
INFO - 2016-02-29 14:08:52 --> Model Class Initialized
INFO - 2016-02-29 14:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:08:52 --> Pagination Class Initialized
INFO - 2016-02-29 14:08:52 --> Helper loaded: text_helper
INFO - 2016-02-29 14:08:52 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:08:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:08:52 --> Final output sent to browser
DEBUG - 2016-02-29 17:08:52 --> Total execution time: 1.1744
INFO - 2016-02-29 14:09:23 --> Config Class Initialized
INFO - 2016-02-29 14:09:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:09:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:09:23 --> Utf8 Class Initialized
INFO - 2016-02-29 14:09:23 --> URI Class Initialized
INFO - 2016-02-29 14:09:23 --> Router Class Initialized
INFO - 2016-02-29 14:09:23 --> Output Class Initialized
INFO - 2016-02-29 14:09:23 --> Security Class Initialized
DEBUG - 2016-02-29 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:09:23 --> Input Class Initialized
INFO - 2016-02-29 14:09:23 --> Language Class Initialized
INFO - 2016-02-29 14:09:23 --> Loader Class Initialized
INFO - 2016-02-29 14:09:23 --> Helper loaded: url_helper
INFO - 2016-02-29 14:09:23 --> Helper loaded: file_helper
INFO - 2016-02-29 14:09:23 --> Helper loaded: date_helper
INFO - 2016-02-29 14:09:23 --> Helper loaded: form_helper
INFO - 2016-02-29 14:09:23 --> Database Driver Class Initialized
INFO - 2016-02-29 14:09:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:09:24 --> Controller Class Initialized
INFO - 2016-02-29 14:09:24 --> Model Class Initialized
INFO - 2016-02-29 14:09:24 --> Model Class Initialized
INFO - 2016-02-29 14:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:09:24 --> Pagination Class Initialized
INFO - 2016-02-29 14:09:24 --> Helper loaded: text_helper
INFO - 2016-02-29 14:09:24 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:09:24 --> Final output sent to browser
DEBUG - 2016-02-29 17:09:24 --> Total execution time: 1.1540
INFO - 2016-02-29 14:10:23 --> Config Class Initialized
INFO - 2016-02-29 14:10:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:10:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:10:23 --> Utf8 Class Initialized
INFO - 2016-02-29 14:10:23 --> URI Class Initialized
INFO - 2016-02-29 14:10:23 --> Router Class Initialized
INFO - 2016-02-29 14:10:23 --> Output Class Initialized
INFO - 2016-02-29 14:10:23 --> Security Class Initialized
DEBUG - 2016-02-29 14:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:10:23 --> Input Class Initialized
INFO - 2016-02-29 14:10:23 --> Language Class Initialized
INFO - 2016-02-29 14:10:23 --> Loader Class Initialized
INFO - 2016-02-29 14:10:23 --> Helper loaded: url_helper
INFO - 2016-02-29 14:10:23 --> Helper loaded: file_helper
INFO - 2016-02-29 14:10:23 --> Helper loaded: date_helper
INFO - 2016-02-29 14:10:23 --> Helper loaded: form_helper
INFO - 2016-02-29 14:10:23 --> Database Driver Class Initialized
INFO - 2016-02-29 14:10:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:10:24 --> Controller Class Initialized
INFO - 2016-02-29 14:10:24 --> Model Class Initialized
INFO - 2016-02-29 14:10:24 --> Model Class Initialized
INFO - 2016-02-29 14:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:10:24 --> Pagination Class Initialized
INFO - 2016-02-29 14:10:24 --> Helper loaded: text_helper
INFO - 2016-02-29 14:10:24 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:10:24 --> Final output sent to browser
DEBUG - 2016-02-29 17:10:24 --> Total execution time: 1.1581
INFO - 2016-02-29 14:11:26 --> Config Class Initialized
INFO - 2016-02-29 14:11:26 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:11:26 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:11:26 --> Utf8 Class Initialized
INFO - 2016-02-29 14:11:26 --> URI Class Initialized
INFO - 2016-02-29 14:11:26 --> Router Class Initialized
INFO - 2016-02-29 14:11:26 --> Output Class Initialized
INFO - 2016-02-29 14:11:26 --> Security Class Initialized
DEBUG - 2016-02-29 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:11:26 --> Input Class Initialized
INFO - 2016-02-29 14:11:26 --> Language Class Initialized
INFO - 2016-02-29 14:11:26 --> Loader Class Initialized
INFO - 2016-02-29 14:11:26 --> Helper loaded: url_helper
INFO - 2016-02-29 14:11:26 --> Helper loaded: file_helper
INFO - 2016-02-29 14:11:26 --> Helper loaded: date_helper
INFO - 2016-02-29 14:11:26 --> Helper loaded: form_helper
INFO - 2016-02-29 14:11:26 --> Database Driver Class Initialized
INFO - 2016-02-29 14:11:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:11:28 --> Controller Class Initialized
INFO - 2016-02-29 14:11:28 --> Model Class Initialized
INFO - 2016-02-29 14:11:28 --> Model Class Initialized
INFO - 2016-02-29 14:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:11:28 --> Pagination Class Initialized
INFO - 2016-02-29 14:11:28 --> Helper loaded: text_helper
INFO - 2016-02-29 14:11:28 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:11:28 --> Final output sent to browser
DEBUG - 2016-02-29 17:11:28 --> Total execution time: 1.1778
INFO - 2016-02-29 14:12:46 --> Config Class Initialized
INFO - 2016-02-29 14:12:46 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:12:46 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:12:46 --> Utf8 Class Initialized
INFO - 2016-02-29 14:12:46 --> URI Class Initialized
INFO - 2016-02-29 14:12:46 --> Router Class Initialized
INFO - 2016-02-29 14:12:46 --> Output Class Initialized
INFO - 2016-02-29 14:12:46 --> Security Class Initialized
DEBUG - 2016-02-29 14:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:12:46 --> Input Class Initialized
INFO - 2016-02-29 14:12:46 --> Language Class Initialized
INFO - 2016-02-29 14:12:46 --> Loader Class Initialized
INFO - 2016-02-29 14:12:46 --> Helper loaded: url_helper
INFO - 2016-02-29 14:12:46 --> Helper loaded: file_helper
INFO - 2016-02-29 14:12:46 --> Helper loaded: date_helper
INFO - 2016-02-29 14:12:46 --> Helper loaded: form_helper
INFO - 2016-02-29 14:12:46 --> Database Driver Class Initialized
INFO - 2016-02-29 14:12:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:12:47 --> Controller Class Initialized
INFO - 2016-02-29 14:12:47 --> Model Class Initialized
INFO - 2016-02-29 14:12:47 --> Model Class Initialized
INFO - 2016-02-29 14:12:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:12:47 --> Pagination Class Initialized
INFO - 2016-02-29 14:12:47 --> Helper loaded: text_helper
INFO - 2016-02-29 14:12:47 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:12:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:12:47 --> Final output sent to browser
DEBUG - 2016-02-29 17:12:47 --> Total execution time: 1.2119
INFO - 2016-02-29 14:15:03 --> Config Class Initialized
INFO - 2016-02-29 14:15:03 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:15:03 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:15:03 --> Utf8 Class Initialized
INFO - 2016-02-29 14:15:03 --> URI Class Initialized
INFO - 2016-02-29 14:15:03 --> Router Class Initialized
INFO - 2016-02-29 14:15:03 --> Output Class Initialized
INFO - 2016-02-29 14:15:03 --> Security Class Initialized
DEBUG - 2016-02-29 14:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:15:03 --> Input Class Initialized
INFO - 2016-02-29 14:15:03 --> Language Class Initialized
INFO - 2016-02-29 14:15:03 --> Loader Class Initialized
INFO - 2016-02-29 14:15:03 --> Helper loaded: url_helper
INFO - 2016-02-29 14:15:03 --> Helper loaded: file_helper
INFO - 2016-02-29 14:15:03 --> Helper loaded: date_helper
INFO - 2016-02-29 14:15:03 --> Helper loaded: form_helper
INFO - 2016-02-29 14:15:03 --> Database Driver Class Initialized
INFO - 2016-02-29 14:15:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:15:04 --> Controller Class Initialized
INFO - 2016-02-29 14:15:04 --> Model Class Initialized
INFO - 2016-02-29 14:15:04 --> Model Class Initialized
INFO - 2016-02-29 14:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:15:04 --> Pagination Class Initialized
INFO - 2016-02-29 14:15:04 --> Helper loaded: text_helper
INFO - 2016-02-29 14:15:04 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:15:04 --> Final output sent to browser
DEBUG - 2016-02-29 17:15:04 --> Total execution time: 1.1824
INFO - 2016-02-29 14:16:56 --> Config Class Initialized
INFO - 2016-02-29 14:16:56 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:16:56 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:16:56 --> Utf8 Class Initialized
INFO - 2016-02-29 14:16:56 --> URI Class Initialized
INFO - 2016-02-29 14:16:56 --> Router Class Initialized
INFO - 2016-02-29 14:16:56 --> Output Class Initialized
INFO - 2016-02-29 14:16:56 --> Security Class Initialized
DEBUG - 2016-02-29 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:16:56 --> Input Class Initialized
INFO - 2016-02-29 14:16:56 --> Language Class Initialized
INFO - 2016-02-29 14:16:56 --> Loader Class Initialized
INFO - 2016-02-29 14:16:56 --> Helper loaded: url_helper
INFO - 2016-02-29 14:16:56 --> Helper loaded: file_helper
INFO - 2016-02-29 14:16:56 --> Helper loaded: date_helper
INFO - 2016-02-29 14:16:56 --> Helper loaded: form_helper
INFO - 2016-02-29 14:16:56 --> Database Driver Class Initialized
INFO - 2016-02-29 14:16:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:16:57 --> Controller Class Initialized
INFO - 2016-02-29 14:16:57 --> Model Class Initialized
INFO - 2016-02-29 14:16:57 --> Model Class Initialized
INFO - 2016-02-29 14:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:16:57 --> Pagination Class Initialized
INFO - 2016-02-29 14:16:57 --> Helper loaded: text_helper
INFO - 2016-02-29 14:16:57 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:16:57 --> Final output sent to browser
DEBUG - 2016-02-29 17:16:57 --> Total execution time: 1.1922
INFO - 2016-02-29 14:17:18 --> Config Class Initialized
INFO - 2016-02-29 14:17:18 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:17:18 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:17:18 --> Utf8 Class Initialized
INFO - 2016-02-29 14:17:18 --> URI Class Initialized
INFO - 2016-02-29 14:17:18 --> Router Class Initialized
INFO - 2016-02-29 14:17:18 --> Output Class Initialized
INFO - 2016-02-29 14:17:18 --> Security Class Initialized
DEBUG - 2016-02-29 14:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:17:18 --> Input Class Initialized
INFO - 2016-02-29 14:17:19 --> Language Class Initialized
INFO - 2016-02-29 14:17:19 --> Loader Class Initialized
INFO - 2016-02-29 14:17:19 --> Helper loaded: url_helper
INFO - 2016-02-29 14:17:19 --> Helper loaded: file_helper
INFO - 2016-02-29 14:17:19 --> Helper loaded: date_helper
INFO - 2016-02-29 14:17:19 --> Helper loaded: form_helper
INFO - 2016-02-29 14:17:19 --> Database Driver Class Initialized
INFO - 2016-02-29 14:17:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:17:20 --> Controller Class Initialized
INFO - 2016-02-29 14:17:20 --> Model Class Initialized
INFO - 2016-02-29 14:17:20 --> Model Class Initialized
INFO - 2016-02-29 14:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:17:20 --> Pagination Class Initialized
INFO - 2016-02-29 14:17:20 --> Helper loaded: text_helper
INFO - 2016-02-29 14:17:20 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:17:20 --> Final output sent to browser
DEBUG - 2016-02-29 17:17:20 --> Total execution time: 1.1924
INFO - 2016-02-29 14:23:41 --> Config Class Initialized
INFO - 2016-02-29 14:23:41 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:23:41 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:23:41 --> Utf8 Class Initialized
INFO - 2016-02-29 14:23:41 --> URI Class Initialized
INFO - 2016-02-29 14:23:41 --> Router Class Initialized
INFO - 2016-02-29 14:23:41 --> Output Class Initialized
INFO - 2016-02-29 14:23:41 --> Security Class Initialized
DEBUG - 2016-02-29 14:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:23:41 --> Input Class Initialized
INFO - 2016-02-29 14:23:41 --> Language Class Initialized
INFO - 2016-02-29 14:23:41 --> Loader Class Initialized
INFO - 2016-02-29 14:23:41 --> Helper loaded: url_helper
INFO - 2016-02-29 14:23:41 --> Helper loaded: file_helper
INFO - 2016-02-29 14:23:41 --> Helper loaded: date_helper
INFO - 2016-02-29 14:23:41 --> Helper loaded: form_helper
INFO - 2016-02-29 14:23:41 --> Database Driver Class Initialized
INFO - 2016-02-29 14:23:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:23:42 --> Controller Class Initialized
INFO - 2016-02-29 14:23:42 --> Model Class Initialized
INFO - 2016-02-29 14:23:42 --> Model Class Initialized
INFO - 2016-02-29 14:23:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:23:42 --> Pagination Class Initialized
INFO - 2016-02-29 14:23:42 --> Helper loaded: text_helper
INFO - 2016-02-29 14:23:42 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:23:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:23:42 --> Final output sent to browser
DEBUG - 2016-02-29 17:23:42 --> Total execution time: 1.1773
INFO - 2016-02-29 14:23:56 --> Config Class Initialized
INFO - 2016-02-29 14:23:56 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:23:56 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:23:56 --> Utf8 Class Initialized
INFO - 2016-02-29 14:23:56 --> URI Class Initialized
INFO - 2016-02-29 14:23:56 --> Router Class Initialized
INFO - 2016-02-29 14:23:56 --> Output Class Initialized
INFO - 2016-02-29 14:23:56 --> Security Class Initialized
DEBUG - 2016-02-29 14:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:23:56 --> Input Class Initialized
INFO - 2016-02-29 14:23:56 --> Language Class Initialized
INFO - 2016-02-29 14:23:56 --> Loader Class Initialized
INFO - 2016-02-29 14:23:56 --> Helper loaded: url_helper
INFO - 2016-02-29 14:23:56 --> Helper loaded: file_helper
INFO - 2016-02-29 14:23:56 --> Helper loaded: date_helper
INFO - 2016-02-29 14:23:56 --> Helper loaded: form_helper
INFO - 2016-02-29 14:23:56 --> Database Driver Class Initialized
INFO - 2016-02-29 14:23:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:23:57 --> Controller Class Initialized
INFO - 2016-02-29 14:23:57 --> Model Class Initialized
INFO - 2016-02-29 14:23:57 --> Model Class Initialized
INFO - 2016-02-29 14:23:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:23:57 --> Pagination Class Initialized
INFO - 2016-02-29 14:23:57 --> Helper loaded: text_helper
INFO - 2016-02-29 14:23:57 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:23:57 --> Final output sent to browser
DEBUG - 2016-02-29 17:23:57 --> Total execution time: 1.1738
INFO - 2016-02-29 14:24:00 --> Config Class Initialized
INFO - 2016-02-29 14:24:00 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:24:00 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:24:00 --> Utf8 Class Initialized
INFO - 2016-02-29 14:24:00 --> URI Class Initialized
INFO - 2016-02-29 14:24:00 --> Router Class Initialized
INFO - 2016-02-29 14:24:00 --> Output Class Initialized
INFO - 2016-02-29 14:24:00 --> Security Class Initialized
DEBUG - 2016-02-29 14:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:24:00 --> Input Class Initialized
INFO - 2016-02-29 14:24:00 --> Language Class Initialized
INFO - 2016-02-29 14:24:00 --> Loader Class Initialized
INFO - 2016-02-29 14:24:00 --> Helper loaded: url_helper
INFO - 2016-02-29 14:24:00 --> Helper loaded: file_helper
INFO - 2016-02-29 14:24:00 --> Helper loaded: date_helper
INFO - 2016-02-29 14:24:00 --> Helper loaded: form_helper
INFO - 2016-02-29 14:24:00 --> Database Driver Class Initialized
INFO - 2016-02-29 14:24:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:24:01 --> Controller Class Initialized
INFO - 2016-02-29 14:24:01 --> Model Class Initialized
INFO - 2016-02-29 14:24:01 --> Model Class Initialized
INFO - 2016-02-29 14:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:24:01 --> Pagination Class Initialized
INFO - 2016-02-29 14:24:01 --> Helper loaded: text_helper
INFO - 2016-02-29 14:24:01 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:24:01 --> Final output sent to browser
DEBUG - 2016-02-29 17:24:01 --> Total execution time: 1.2701
INFO - 2016-02-29 14:24:13 --> Config Class Initialized
INFO - 2016-02-29 14:24:13 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:24:13 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:24:13 --> Utf8 Class Initialized
INFO - 2016-02-29 14:24:13 --> URI Class Initialized
INFO - 2016-02-29 14:24:13 --> Router Class Initialized
INFO - 2016-02-29 14:24:13 --> Output Class Initialized
INFO - 2016-02-29 14:24:13 --> Security Class Initialized
DEBUG - 2016-02-29 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:24:13 --> Input Class Initialized
INFO - 2016-02-29 14:24:13 --> Language Class Initialized
INFO - 2016-02-29 14:24:13 --> Loader Class Initialized
INFO - 2016-02-29 14:24:13 --> Helper loaded: url_helper
INFO - 2016-02-29 14:24:13 --> Helper loaded: file_helper
INFO - 2016-02-29 14:24:13 --> Helper loaded: date_helper
INFO - 2016-02-29 14:24:13 --> Helper loaded: form_helper
INFO - 2016-02-29 14:24:13 --> Database Driver Class Initialized
INFO - 2016-02-29 14:24:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:24:14 --> Controller Class Initialized
INFO - 2016-02-29 14:24:14 --> Model Class Initialized
INFO - 2016-02-29 14:24:14 --> Model Class Initialized
INFO - 2016-02-29 14:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:24:14 --> Pagination Class Initialized
INFO - 2016-02-29 14:24:14 --> Helper loaded: text_helper
INFO - 2016-02-29 14:24:14 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:24:14 --> Final output sent to browser
DEBUG - 2016-02-29 17:24:14 --> Total execution time: 1.1716
INFO - 2016-02-29 14:24:32 --> Config Class Initialized
INFO - 2016-02-29 14:24:32 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:24:32 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:24:32 --> Utf8 Class Initialized
INFO - 2016-02-29 14:24:32 --> URI Class Initialized
INFO - 2016-02-29 14:24:32 --> Router Class Initialized
INFO - 2016-02-29 14:24:32 --> Output Class Initialized
INFO - 2016-02-29 14:24:32 --> Security Class Initialized
DEBUG - 2016-02-29 14:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:24:32 --> Input Class Initialized
INFO - 2016-02-29 14:24:32 --> Language Class Initialized
INFO - 2016-02-29 14:24:32 --> Loader Class Initialized
INFO - 2016-02-29 14:24:32 --> Helper loaded: url_helper
INFO - 2016-02-29 14:24:32 --> Helper loaded: file_helper
INFO - 2016-02-29 14:24:32 --> Helper loaded: date_helper
INFO - 2016-02-29 14:24:32 --> Helper loaded: form_helper
INFO - 2016-02-29 14:24:32 --> Database Driver Class Initialized
INFO - 2016-02-29 14:24:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:24:33 --> Controller Class Initialized
INFO - 2016-02-29 14:24:33 --> Model Class Initialized
INFO - 2016-02-29 14:24:33 --> Model Class Initialized
INFO - 2016-02-29 14:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:24:33 --> Pagination Class Initialized
INFO - 2016-02-29 14:24:33 --> Helper loaded: text_helper
INFO - 2016-02-29 14:24:33 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:24:34 --> Final output sent to browser
DEBUG - 2016-02-29 17:24:34 --> Total execution time: 1.1923
INFO - 2016-02-29 14:24:59 --> Config Class Initialized
INFO - 2016-02-29 14:24:59 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:24:59 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:24:59 --> Utf8 Class Initialized
INFO - 2016-02-29 14:24:59 --> URI Class Initialized
INFO - 2016-02-29 14:24:59 --> Router Class Initialized
INFO - 2016-02-29 14:24:59 --> Output Class Initialized
INFO - 2016-02-29 14:24:59 --> Security Class Initialized
DEBUG - 2016-02-29 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:24:59 --> Input Class Initialized
INFO - 2016-02-29 14:24:59 --> Language Class Initialized
INFO - 2016-02-29 14:24:59 --> Loader Class Initialized
INFO - 2016-02-29 14:24:59 --> Helper loaded: url_helper
INFO - 2016-02-29 14:24:59 --> Helper loaded: file_helper
INFO - 2016-02-29 14:24:59 --> Helper loaded: date_helper
INFO - 2016-02-29 14:24:59 --> Helper loaded: form_helper
INFO - 2016-02-29 14:24:59 --> Database Driver Class Initialized
INFO - 2016-02-29 14:25:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:25:00 --> Controller Class Initialized
INFO - 2016-02-29 14:25:00 --> Model Class Initialized
INFO - 2016-02-29 14:25:00 --> Model Class Initialized
INFO - 2016-02-29 14:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:25:00 --> Pagination Class Initialized
INFO - 2016-02-29 14:25:00 --> Helper loaded: text_helper
INFO - 2016-02-29 14:25:00 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:25:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:25:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:25:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:25:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:25:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:25:00 --> Final output sent to browser
DEBUG - 2016-02-29 17:25:00 --> Total execution time: 1.1606
INFO - 2016-02-29 14:25:23 --> Config Class Initialized
INFO - 2016-02-29 14:25:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:25:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:25:23 --> Utf8 Class Initialized
INFO - 2016-02-29 14:25:23 --> URI Class Initialized
INFO - 2016-02-29 14:25:23 --> Router Class Initialized
INFO - 2016-02-29 14:25:23 --> Output Class Initialized
INFO - 2016-02-29 14:25:23 --> Security Class Initialized
DEBUG - 2016-02-29 14:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:25:23 --> Input Class Initialized
INFO - 2016-02-29 14:25:23 --> Language Class Initialized
INFO - 2016-02-29 14:25:23 --> Loader Class Initialized
INFO - 2016-02-29 14:25:23 --> Helper loaded: url_helper
INFO - 2016-02-29 14:25:23 --> Helper loaded: file_helper
INFO - 2016-02-29 14:25:23 --> Helper loaded: date_helper
INFO - 2016-02-29 14:25:23 --> Helper loaded: form_helper
INFO - 2016-02-29 14:25:23 --> Database Driver Class Initialized
INFO - 2016-02-29 14:25:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:25:24 --> Controller Class Initialized
INFO - 2016-02-29 14:25:24 --> Model Class Initialized
INFO - 2016-02-29 14:25:24 --> Model Class Initialized
INFO - 2016-02-29 14:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:25:24 --> Pagination Class Initialized
INFO - 2016-02-29 14:25:24 --> Helper loaded: text_helper
INFO - 2016-02-29 14:25:24 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:25:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:25:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:25:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:25:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:25:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:25:24 --> Final output sent to browser
DEBUG - 2016-02-29 17:25:24 --> Total execution time: 1.2575
INFO - 2016-02-29 14:26:24 --> Config Class Initialized
INFO - 2016-02-29 14:26:24 --> Hooks Class Initialized
DEBUG - 2016-02-29 14:26:24 --> UTF-8 Support Enabled
INFO - 2016-02-29 14:26:24 --> Utf8 Class Initialized
INFO - 2016-02-29 14:26:24 --> URI Class Initialized
INFO - 2016-02-29 14:26:24 --> Router Class Initialized
INFO - 2016-02-29 14:26:24 --> Output Class Initialized
INFO - 2016-02-29 14:26:24 --> Security Class Initialized
DEBUG - 2016-02-29 14:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 14:26:24 --> Input Class Initialized
INFO - 2016-02-29 14:26:24 --> Language Class Initialized
INFO - 2016-02-29 14:26:24 --> Loader Class Initialized
INFO - 2016-02-29 14:26:24 --> Helper loaded: url_helper
INFO - 2016-02-29 14:26:24 --> Helper loaded: file_helper
INFO - 2016-02-29 14:26:24 --> Helper loaded: date_helper
INFO - 2016-02-29 14:26:24 --> Helper loaded: form_helper
INFO - 2016-02-29 14:26:24 --> Database Driver Class Initialized
INFO - 2016-02-29 14:26:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 14:26:25 --> Controller Class Initialized
INFO - 2016-02-29 14:26:25 --> Model Class Initialized
INFO - 2016-02-29 14:26:25 --> Model Class Initialized
INFO - 2016-02-29 14:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 14:26:25 --> Pagination Class Initialized
INFO - 2016-02-29 14:26:25 --> Helper loaded: text_helper
INFO - 2016-02-29 14:26:25 --> Helper loaded: cookie_helper
INFO - 2016-02-29 17:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 17:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 17:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 17:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 17:26:25 --> Final output sent to browser
DEBUG - 2016-02-29 17:26:25 --> Total execution time: 1.2093
INFO - 2016-02-29 17:55:23 --> Config Class Initialized
INFO - 2016-02-29 17:55:23 --> Hooks Class Initialized
DEBUG - 2016-02-29 17:55:23 --> UTF-8 Support Enabled
INFO - 2016-02-29 17:55:23 --> Utf8 Class Initialized
INFO - 2016-02-29 17:55:23 --> URI Class Initialized
DEBUG - 2016-02-29 17:55:23 --> No URI present. Default controller set.
INFO - 2016-02-29 17:55:23 --> Router Class Initialized
INFO - 2016-02-29 17:55:23 --> Output Class Initialized
INFO - 2016-02-29 17:55:23 --> Security Class Initialized
DEBUG - 2016-02-29 17:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 17:55:23 --> Input Class Initialized
INFO - 2016-02-29 17:55:23 --> Language Class Initialized
INFO - 2016-02-29 17:55:23 --> Loader Class Initialized
INFO - 2016-02-29 17:55:23 --> Helper loaded: url_helper
INFO - 2016-02-29 17:55:23 --> Helper loaded: file_helper
INFO - 2016-02-29 17:55:23 --> Helper loaded: date_helper
INFO - 2016-02-29 17:55:23 --> Helper loaded: form_helper
INFO - 2016-02-29 17:55:23 --> Database Driver Class Initialized
INFO - 2016-02-29 17:55:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 17:55:24 --> Controller Class Initialized
INFO - 2016-02-29 17:55:24 --> Model Class Initialized
INFO - 2016-02-29 17:55:24 --> Model Class Initialized
INFO - 2016-02-29 17:55:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 17:55:24 --> Pagination Class Initialized
INFO - 2016-02-29 17:55:24 --> Helper loaded: text_helper
INFO - 2016-02-29 17:55:24 --> Helper loaded: cookie_helper
INFO - 2016-02-29 20:55:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 20:55:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 20:55:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 20:55:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 20:55:24 --> Final output sent to browser
DEBUG - 2016-02-29 20:55:24 --> Total execution time: 1.1631
INFO - 2016-02-29 17:55:52 --> Config Class Initialized
INFO - 2016-02-29 17:55:52 --> Hooks Class Initialized
DEBUG - 2016-02-29 17:55:52 --> UTF-8 Support Enabled
INFO - 2016-02-29 17:55:52 --> Utf8 Class Initialized
INFO - 2016-02-29 17:55:52 --> URI Class Initialized
INFO - 2016-02-29 17:55:52 --> Router Class Initialized
INFO - 2016-02-29 17:55:53 --> Output Class Initialized
INFO - 2016-02-29 17:55:53 --> Security Class Initialized
DEBUG - 2016-02-29 17:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 17:55:53 --> Input Class Initialized
INFO - 2016-02-29 17:55:53 --> Language Class Initialized
INFO - 2016-02-29 17:55:53 --> Loader Class Initialized
INFO - 2016-02-29 17:55:53 --> Helper loaded: url_helper
INFO - 2016-02-29 17:55:53 --> Helper loaded: file_helper
INFO - 2016-02-29 17:55:53 --> Helper loaded: date_helper
INFO - 2016-02-29 17:55:53 --> Helper loaded: form_helper
INFO - 2016-02-29 17:55:53 --> Database Driver Class Initialized
INFO - 2016-02-29 17:55:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 17:55:54 --> Controller Class Initialized
INFO - 2016-02-29 17:55:54 --> Model Class Initialized
INFO - 2016-02-29 17:55:54 --> Model Class Initialized
INFO - 2016-02-29 17:55:54 --> Form Validation Class Initialized
INFO - 2016-02-29 17:55:54 --> Helper loaded: text_helper
INFO - 2016-02-29 17:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 17:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-29 17:55:54 --> Final output sent to browser
DEBUG - 2016-02-29 17:55:54 --> Total execution time: 1.1188
INFO - 2016-02-29 17:55:58 --> Config Class Initialized
INFO - 2016-02-29 17:55:58 --> Hooks Class Initialized
DEBUG - 2016-02-29 17:55:58 --> UTF-8 Support Enabled
INFO - 2016-02-29 17:55:58 --> Utf8 Class Initialized
INFO - 2016-02-29 17:55:58 --> URI Class Initialized
DEBUG - 2016-02-29 17:55:58 --> No URI present. Default controller set.
INFO - 2016-02-29 17:55:58 --> Router Class Initialized
INFO - 2016-02-29 17:55:58 --> Output Class Initialized
INFO - 2016-02-29 17:55:58 --> Security Class Initialized
DEBUG - 2016-02-29 17:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 17:55:58 --> Input Class Initialized
INFO - 2016-02-29 17:55:58 --> Language Class Initialized
INFO - 2016-02-29 17:55:58 --> Loader Class Initialized
INFO - 2016-02-29 17:55:58 --> Helper loaded: url_helper
INFO - 2016-02-29 17:55:58 --> Helper loaded: file_helper
INFO - 2016-02-29 17:55:58 --> Helper loaded: date_helper
INFO - 2016-02-29 17:55:58 --> Helper loaded: form_helper
INFO - 2016-02-29 17:55:58 --> Database Driver Class Initialized
INFO - 2016-02-29 17:55:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 17:55:59 --> Controller Class Initialized
INFO - 2016-02-29 17:55:59 --> Model Class Initialized
INFO - 2016-02-29 17:55:59 --> Model Class Initialized
INFO - 2016-02-29 17:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 17:55:59 --> Pagination Class Initialized
INFO - 2016-02-29 17:55:59 --> Helper loaded: text_helper
INFO - 2016-02-29 17:55:59 --> Helper loaded: cookie_helper
INFO - 2016-02-29 20:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 20:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 20:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-29 20:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 20:55:59 --> Final output sent to browser
DEBUG - 2016-02-29 20:55:59 --> Total execution time: 1.1278
INFO - 2016-02-29 17:56:05 --> Config Class Initialized
INFO - 2016-02-29 17:56:05 --> Hooks Class Initialized
DEBUG - 2016-02-29 17:56:05 --> UTF-8 Support Enabled
INFO - 2016-02-29 17:56:05 --> Utf8 Class Initialized
INFO - 2016-02-29 17:56:05 --> URI Class Initialized
INFO - 2016-02-29 17:56:05 --> Router Class Initialized
INFO - 2016-02-29 17:56:05 --> Output Class Initialized
INFO - 2016-02-29 17:56:05 --> Security Class Initialized
DEBUG - 2016-02-29 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 17:56:05 --> Input Class Initialized
INFO - 2016-02-29 17:56:05 --> Language Class Initialized
INFO - 2016-02-29 17:56:05 --> Loader Class Initialized
INFO - 2016-02-29 17:56:05 --> Helper loaded: url_helper
INFO - 2016-02-29 17:56:05 --> Helper loaded: file_helper
INFO - 2016-02-29 17:56:05 --> Helper loaded: date_helper
INFO - 2016-02-29 17:56:05 --> Helper loaded: form_helper
INFO - 2016-02-29 17:56:05 --> Database Driver Class Initialized
INFO - 2016-02-29 17:56:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 17:56:06 --> Controller Class Initialized
INFO - 2016-02-29 17:56:07 --> Model Class Initialized
INFO - 2016-02-29 17:56:07 --> Model Class Initialized
INFO - 2016-02-29 17:56:07 --> Form Validation Class Initialized
INFO - 2016-02-29 17:56:07 --> Helper loaded: text_helper
INFO - 2016-02-29 17:56:07 --> Final output sent to browser
DEBUG - 2016-02-29 17:56:07 --> Total execution time: 1.1044
INFO - 2016-02-29 17:56:39 --> Config Class Initialized
INFO - 2016-02-29 17:56:39 --> Hooks Class Initialized
DEBUG - 2016-02-29 17:56:39 --> UTF-8 Support Enabled
INFO - 2016-02-29 17:56:39 --> Utf8 Class Initialized
INFO - 2016-02-29 17:56:39 --> URI Class Initialized
INFO - 2016-02-29 17:56:39 --> Router Class Initialized
INFO - 2016-02-29 17:56:39 --> Output Class Initialized
INFO - 2016-02-29 17:56:39 --> Security Class Initialized
DEBUG - 2016-02-29 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-29 17:56:39 --> Input Class Initialized
INFO - 2016-02-29 17:56:39 --> Language Class Initialized
INFO - 2016-02-29 17:56:39 --> Loader Class Initialized
INFO - 2016-02-29 17:56:39 --> Helper loaded: url_helper
INFO - 2016-02-29 17:56:39 --> Helper loaded: file_helper
INFO - 2016-02-29 17:56:39 --> Helper loaded: date_helper
INFO - 2016-02-29 17:56:39 --> Helper loaded: form_helper
INFO - 2016-02-29 17:56:39 --> Database Driver Class Initialized
INFO - 2016-02-29 17:56:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-29 17:56:40 --> Controller Class Initialized
INFO - 2016-02-29 17:56:40 --> Model Class Initialized
INFO - 2016-02-29 17:56:40 --> Model Class Initialized
INFO - 2016-02-29 17:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-29 17:56:40 --> Pagination Class Initialized
INFO - 2016-02-29 17:56:40 --> Helper loaded: text_helper
INFO - 2016-02-29 17:56:40 --> Helper loaded: cookie_helper
INFO - 2016-02-29 20:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-29 20:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-29 20:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-29 20:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-29 20:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-29 20:56:40 --> Final output sent to browser
DEBUG - 2016-02-29 20:56:40 --> Total execution time: 1.2036
