<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-10 08:00:57 --> Config Class Initialized
INFO - 2016-02-10 08:00:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:00:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:00:57 --> Utf8 Class Initialized
INFO - 2016-02-10 08:00:57 --> URI Class Initialized
DEBUG - 2016-02-10 08:00:57 --> No URI present. Default controller set.
INFO - 2016-02-10 08:00:57 --> Router Class Initialized
INFO - 2016-02-10 08:00:57 --> Output Class Initialized
INFO - 2016-02-10 08:00:57 --> Security Class Initialized
DEBUG - 2016-02-10 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:00:57 --> Input Class Initialized
INFO - 2016-02-10 08:00:57 --> Language Class Initialized
INFO - 2016-02-10 08:00:57 --> Loader Class Initialized
INFO - 2016-02-10 08:00:57 --> Helper loaded: url_helper
INFO - 2016-02-10 08:00:57 --> Helper loaded: file_helper
INFO - 2016-02-10 08:00:57 --> Helper loaded: date_helper
INFO - 2016-02-10 08:00:57 --> Helper loaded: form_helper
INFO - 2016-02-10 08:00:57 --> Database Driver Class Initialized
INFO - 2016-02-10 08:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:00:58 --> Controller Class Initialized
INFO - 2016-02-10 08:00:58 --> Model Class Initialized
INFO - 2016-02-10 08:00:59 --> Model Class Initialized
INFO - 2016-02-10 08:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:00:59 --> Pagination Class Initialized
INFO - 2016-02-10 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:00:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:00:59 --> Final output sent to browser
DEBUG - 2016-02-10 11:00:59 --> Total execution time: 1.1990
INFO - 2016-02-10 08:01:41 --> Config Class Initialized
INFO - 2016-02-10 08:01:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:01:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:01:41 --> Utf8 Class Initialized
INFO - 2016-02-10 08:01:41 --> URI Class Initialized
INFO - 2016-02-10 08:01:41 --> Router Class Initialized
INFO - 2016-02-10 08:01:41 --> Output Class Initialized
INFO - 2016-02-10 08:01:41 --> Security Class Initialized
DEBUG - 2016-02-10 08:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:01:41 --> Input Class Initialized
INFO - 2016-02-10 08:01:41 --> Language Class Initialized
INFO - 2016-02-10 08:01:41 --> Loader Class Initialized
INFO - 2016-02-10 08:01:41 --> Helper loaded: url_helper
INFO - 2016-02-10 08:01:41 --> Helper loaded: file_helper
INFO - 2016-02-10 08:01:41 --> Helper loaded: date_helper
INFO - 2016-02-10 08:01:41 --> Helper loaded: form_helper
INFO - 2016-02-10 08:01:41 --> Database Driver Class Initialized
INFO - 2016-02-10 08:01:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:01:42 --> Controller Class Initialized
INFO - 2016-02-10 08:01:42 --> Model Class Initialized
INFO - 2016-02-10 08:01:42 --> Model Class Initialized
INFO - 2016-02-10 08:01:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:01:42 --> Pagination Class Initialized
INFO - 2016-02-10 11:01:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:01:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:01:42 --> Helper loaded: text_helper
INFO - 2016-02-10 11:01:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:01:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:01:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:01:42 --> Final output sent to browser
DEBUG - 2016-02-10 11:01:42 --> Total execution time: 1.1270
INFO - 2016-02-10 08:01:43 --> Config Class Initialized
INFO - 2016-02-10 08:01:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:01:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:01:43 --> Utf8 Class Initialized
INFO - 2016-02-10 08:01:43 --> URI Class Initialized
INFO - 2016-02-10 08:01:43 --> Router Class Initialized
INFO - 2016-02-10 08:01:43 --> Output Class Initialized
INFO - 2016-02-10 08:01:43 --> Security Class Initialized
DEBUG - 2016-02-10 08:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:01:43 --> Input Class Initialized
INFO - 2016-02-10 08:01:43 --> Language Class Initialized
INFO - 2016-02-10 08:01:43 --> Loader Class Initialized
INFO - 2016-02-10 08:01:43 --> Helper loaded: url_helper
INFO - 2016-02-10 08:01:43 --> Helper loaded: file_helper
INFO - 2016-02-10 08:01:43 --> Helper loaded: date_helper
INFO - 2016-02-10 08:01:43 --> Helper loaded: form_helper
INFO - 2016-02-10 08:01:43 --> Database Driver Class Initialized
INFO - 2016-02-10 08:01:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:01:44 --> Controller Class Initialized
INFO - 2016-02-10 08:01:44 --> Model Class Initialized
INFO - 2016-02-10 08:01:44 --> Model Class Initialized
INFO - 2016-02-10 08:01:44 --> Form Validation Class Initialized
INFO - 2016-02-10 08:01:44 --> Helper loaded: text_helper
INFO - 2016-02-10 08:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 08:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 08:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 08:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 08:01:44 --> Final output sent to browser
DEBUG - 2016-02-10 08:01:44 --> Total execution time: 1.0951
INFO - 2016-02-10 08:01:49 --> Config Class Initialized
INFO - 2016-02-10 08:01:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:01:49 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:01:49 --> Utf8 Class Initialized
INFO - 2016-02-10 08:01:49 --> URI Class Initialized
INFO - 2016-02-10 08:01:49 --> Router Class Initialized
INFO - 2016-02-10 08:01:49 --> Output Class Initialized
INFO - 2016-02-10 08:01:49 --> Security Class Initialized
DEBUG - 2016-02-10 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:01:49 --> Input Class Initialized
INFO - 2016-02-10 08:01:49 --> Language Class Initialized
INFO - 2016-02-10 08:01:49 --> Loader Class Initialized
INFO - 2016-02-10 08:01:49 --> Helper loaded: url_helper
INFO - 2016-02-10 08:01:49 --> Helper loaded: file_helper
INFO - 2016-02-10 08:01:49 --> Helper loaded: date_helper
INFO - 2016-02-10 08:01:49 --> Helper loaded: form_helper
INFO - 2016-02-10 08:01:49 --> Database Driver Class Initialized
INFO - 2016-02-10 08:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:01:50 --> Controller Class Initialized
INFO - 2016-02-10 08:01:50 --> Model Class Initialized
INFO - 2016-02-10 08:01:50 --> Model Class Initialized
INFO - 2016-02-10 08:01:50 --> Form Validation Class Initialized
INFO - 2016-02-10 08:01:50 --> Helper loaded: text_helper
INFO - 2016-02-10 08:01:50 --> Config Class Initialized
INFO - 2016-02-10 08:01:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:01:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:01:50 --> Utf8 Class Initialized
INFO - 2016-02-10 08:01:50 --> URI Class Initialized
INFO - 2016-02-10 08:01:50 --> Router Class Initialized
INFO - 2016-02-10 08:01:50 --> Output Class Initialized
INFO - 2016-02-10 08:01:50 --> Security Class Initialized
DEBUG - 2016-02-10 08:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:01:50 --> Input Class Initialized
INFO - 2016-02-10 08:01:50 --> Language Class Initialized
INFO - 2016-02-10 08:01:50 --> Loader Class Initialized
INFO - 2016-02-10 08:01:50 --> Helper loaded: url_helper
INFO - 2016-02-10 08:01:50 --> Helper loaded: file_helper
INFO - 2016-02-10 08:01:50 --> Helper loaded: date_helper
INFO - 2016-02-10 08:01:50 --> Helper loaded: form_helper
INFO - 2016-02-10 08:01:50 --> Database Driver Class Initialized
INFO - 2016-02-10 08:01:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:01:51 --> Controller Class Initialized
INFO - 2016-02-10 08:01:51 --> Model Class Initialized
INFO - 2016-02-10 08:01:51 --> Model Class Initialized
INFO - 2016-02-10 08:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:01:51 --> Pagination Class Initialized
INFO - 2016-02-10 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:01:51 --> Final output sent to browser
DEBUG - 2016-02-10 11:01:51 --> Total execution time: 1.0829
INFO - 2016-02-10 08:01:53 --> Config Class Initialized
INFO - 2016-02-10 08:01:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:01:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:01:53 --> Utf8 Class Initialized
INFO - 2016-02-10 08:01:53 --> URI Class Initialized
INFO - 2016-02-10 08:01:53 --> Router Class Initialized
INFO - 2016-02-10 08:01:53 --> Output Class Initialized
INFO - 2016-02-10 08:01:53 --> Security Class Initialized
DEBUG - 2016-02-10 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:01:53 --> Input Class Initialized
INFO - 2016-02-10 08:01:53 --> Language Class Initialized
INFO - 2016-02-10 08:01:53 --> Loader Class Initialized
INFO - 2016-02-10 08:01:53 --> Helper loaded: url_helper
INFO - 2016-02-10 08:01:53 --> Helper loaded: file_helper
INFO - 2016-02-10 08:01:53 --> Helper loaded: date_helper
INFO - 2016-02-10 08:01:53 --> Helper loaded: form_helper
INFO - 2016-02-10 08:01:53 --> Database Driver Class Initialized
INFO - 2016-02-10 08:01:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:01:54 --> Controller Class Initialized
INFO - 2016-02-10 08:01:54 --> Model Class Initialized
INFO - 2016-02-10 08:01:54 --> Model Class Initialized
INFO - 2016-02-10 08:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:01:54 --> Pagination Class Initialized
INFO - 2016-02-10 11:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:01:54 --> Helper loaded: text_helper
INFO - 2016-02-10 11:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:01:54 --> Final output sent to browser
DEBUG - 2016-02-10 11:01:54 --> Total execution time: 1.1136
INFO - 2016-02-10 08:02:13 --> Config Class Initialized
INFO - 2016-02-10 08:02:13 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:02:13 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:02:13 --> Utf8 Class Initialized
INFO - 2016-02-10 08:02:13 --> URI Class Initialized
INFO - 2016-02-10 08:02:13 --> Router Class Initialized
INFO - 2016-02-10 08:02:13 --> Output Class Initialized
INFO - 2016-02-10 08:02:13 --> Security Class Initialized
DEBUG - 2016-02-10 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:02:13 --> Input Class Initialized
INFO - 2016-02-10 08:02:13 --> Language Class Initialized
INFO - 2016-02-10 08:02:13 --> Loader Class Initialized
INFO - 2016-02-10 08:02:13 --> Helper loaded: url_helper
INFO - 2016-02-10 08:02:13 --> Helper loaded: file_helper
INFO - 2016-02-10 08:02:13 --> Helper loaded: date_helper
INFO - 2016-02-10 08:02:13 --> Helper loaded: form_helper
INFO - 2016-02-10 08:02:13 --> Database Driver Class Initialized
INFO - 2016-02-10 08:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:02:14 --> Controller Class Initialized
INFO - 2016-02-10 08:02:14 --> Model Class Initialized
INFO - 2016-02-10 08:02:14 --> Model Class Initialized
INFO - 2016-02-10 08:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:02:14 --> Pagination Class Initialized
INFO - 2016-02-10 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:02:14 --> Helper loaded: text_helper
INFO - 2016-02-10 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:02:14 --> Final output sent to browser
DEBUG - 2016-02-10 11:02:14 --> Total execution time: 1.1842
INFO - 2016-02-10 08:02:45 --> Config Class Initialized
INFO - 2016-02-10 08:02:45 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:02:45 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:02:45 --> Utf8 Class Initialized
INFO - 2016-02-10 08:02:45 --> URI Class Initialized
INFO - 2016-02-10 08:02:45 --> Router Class Initialized
INFO - 2016-02-10 08:02:45 --> Output Class Initialized
INFO - 2016-02-10 08:02:45 --> Security Class Initialized
DEBUG - 2016-02-10 08:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:02:45 --> Input Class Initialized
INFO - 2016-02-10 08:02:45 --> Language Class Initialized
INFO - 2016-02-10 08:02:45 --> Loader Class Initialized
INFO - 2016-02-10 08:02:45 --> Helper loaded: url_helper
INFO - 2016-02-10 08:02:45 --> Helper loaded: file_helper
INFO - 2016-02-10 08:02:45 --> Helper loaded: date_helper
INFO - 2016-02-10 08:02:45 --> Helper loaded: form_helper
INFO - 2016-02-10 08:02:45 --> Database Driver Class Initialized
INFO - 2016-02-10 08:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:02:46 --> Controller Class Initialized
INFO - 2016-02-10 08:02:46 --> Model Class Initialized
INFO - 2016-02-10 08:02:46 --> Model Class Initialized
INFO - 2016-02-10 08:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:02:46 --> Pagination Class Initialized
INFO - 2016-02-10 11:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:02:46 --> Helper loaded: text_helper
INFO - 2016-02-10 11:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:02:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:02:46 --> Final output sent to browser
DEBUG - 2016-02-10 11:02:46 --> Total execution time: 1.1271
INFO - 2016-02-10 08:02:56 --> Config Class Initialized
INFO - 2016-02-10 08:02:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:02:56 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:02:56 --> Utf8 Class Initialized
INFO - 2016-02-10 08:02:56 --> URI Class Initialized
INFO - 2016-02-10 08:02:56 --> Router Class Initialized
INFO - 2016-02-10 08:02:56 --> Output Class Initialized
INFO - 2016-02-10 08:02:56 --> Security Class Initialized
DEBUG - 2016-02-10 08:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:02:56 --> Input Class Initialized
INFO - 2016-02-10 08:02:56 --> Language Class Initialized
INFO - 2016-02-10 08:02:56 --> Loader Class Initialized
INFO - 2016-02-10 08:02:56 --> Helper loaded: url_helper
INFO - 2016-02-10 08:02:56 --> Helper loaded: file_helper
INFO - 2016-02-10 08:02:56 --> Helper loaded: date_helper
INFO - 2016-02-10 08:02:56 --> Helper loaded: form_helper
INFO - 2016-02-10 08:02:56 --> Database Driver Class Initialized
INFO - 2016-02-10 08:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:02:57 --> Controller Class Initialized
INFO - 2016-02-10 08:02:57 --> Model Class Initialized
INFO - 2016-02-10 08:02:57 --> Model Class Initialized
INFO - 2016-02-10 08:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:02:57 --> Pagination Class Initialized
INFO - 2016-02-10 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:02:57 --> Helper loaded: text_helper
INFO - 2016-02-10 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:02:57 --> Final output sent to browser
DEBUG - 2016-02-10 11:02:57 --> Total execution time: 1.1468
INFO - 2016-02-10 08:03:08 --> Config Class Initialized
INFO - 2016-02-10 08:03:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:03:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:03:08 --> Utf8 Class Initialized
INFO - 2016-02-10 08:03:08 --> URI Class Initialized
INFO - 2016-02-10 08:03:08 --> Router Class Initialized
INFO - 2016-02-10 08:03:08 --> Output Class Initialized
INFO - 2016-02-10 08:03:08 --> Security Class Initialized
DEBUG - 2016-02-10 08:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:03:08 --> Input Class Initialized
INFO - 2016-02-10 08:03:08 --> Language Class Initialized
INFO - 2016-02-10 08:03:08 --> Loader Class Initialized
INFO - 2016-02-10 08:03:08 --> Helper loaded: url_helper
INFO - 2016-02-10 08:03:08 --> Helper loaded: file_helper
INFO - 2016-02-10 08:03:08 --> Helper loaded: date_helper
INFO - 2016-02-10 08:03:08 --> Helper loaded: form_helper
INFO - 2016-02-10 08:03:08 --> Database Driver Class Initialized
INFO - 2016-02-10 08:03:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:03:09 --> Controller Class Initialized
INFO - 2016-02-10 08:03:09 --> Model Class Initialized
INFO - 2016-02-10 08:03:09 --> Model Class Initialized
INFO - 2016-02-10 08:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:03:09 --> Pagination Class Initialized
INFO - 2016-02-10 11:03:09 --> Form Validation Class Initialized
INFO - 2016-02-10 11:03:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:03:09 --> Model Class Initialized
INFO - 2016-02-10 11:03:09 --> Final output sent to browser
DEBUG - 2016-02-10 11:03:09 --> Total execution time: 1.1972
INFO - 2016-02-10 08:07:46 --> Config Class Initialized
INFO - 2016-02-10 08:07:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:07:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:07:46 --> Utf8 Class Initialized
INFO - 2016-02-10 08:07:46 --> URI Class Initialized
INFO - 2016-02-10 08:07:46 --> Router Class Initialized
INFO - 2016-02-10 08:07:46 --> Output Class Initialized
INFO - 2016-02-10 08:07:46 --> Security Class Initialized
DEBUG - 2016-02-10 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:07:46 --> Input Class Initialized
INFO - 2016-02-10 08:07:46 --> Language Class Initialized
INFO - 2016-02-10 08:07:46 --> Loader Class Initialized
INFO - 2016-02-10 08:07:46 --> Helper loaded: url_helper
INFO - 2016-02-10 08:07:46 --> Helper loaded: file_helper
INFO - 2016-02-10 08:07:46 --> Helper loaded: date_helper
INFO - 2016-02-10 08:07:46 --> Helper loaded: form_helper
INFO - 2016-02-10 08:07:46 --> Database Driver Class Initialized
INFO - 2016-02-10 08:07:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:07:47 --> Controller Class Initialized
INFO - 2016-02-10 08:07:47 --> Model Class Initialized
INFO - 2016-02-10 08:07:47 --> Model Class Initialized
INFO - 2016-02-10 08:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:07:47 --> Pagination Class Initialized
INFO - 2016-02-10 11:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:07:47 --> Helper loaded: text_helper
INFO - 2016-02-10 11:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:07:47 --> Final output sent to browser
DEBUG - 2016-02-10 11:07:47 --> Total execution time: 1.1390
INFO - 2016-02-10 08:10:08 --> Config Class Initialized
INFO - 2016-02-10 08:10:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:10:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:10:08 --> Utf8 Class Initialized
INFO - 2016-02-10 08:10:08 --> URI Class Initialized
INFO - 2016-02-10 08:10:08 --> Router Class Initialized
INFO - 2016-02-10 08:10:08 --> Output Class Initialized
INFO - 2016-02-10 08:10:08 --> Security Class Initialized
DEBUG - 2016-02-10 08:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:10:08 --> Input Class Initialized
INFO - 2016-02-10 08:10:08 --> Language Class Initialized
INFO - 2016-02-10 08:10:08 --> Loader Class Initialized
INFO - 2016-02-10 08:10:08 --> Helper loaded: url_helper
INFO - 2016-02-10 08:10:08 --> Helper loaded: file_helper
INFO - 2016-02-10 08:10:08 --> Helper loaded: date_helper
INFO - 2016-02-10 08:10:08 --> Helper loaded: form_helper
INFO - 2016-02-10 08:10:08 --> Database Driver Class Initialized
INFO - 2016-02-10 08:10:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:10:09 --> Controller Class Initialized
INFO - 2016-02-10 08:10:09 --> Model Class Initialized
INFO - 2016-02-10 08:10:09 --> Model Class Initialized
INFO - 2016-02-10 08:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:10:09 --> Pagination Class Initialized
INFO - 2016-02-10 11:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:10:09 --> Helper loaded: text_helper
INFO - 2016-02-10 11:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:10:09 --> Final output sent to browser
DEBUG - 2016-02-10 11:10:09 --> Total execution time: 1.2225
INFO - 2016-02-10 08:10:23 --> Config Class Initialized
INFO - 2016-02-10 08:10:23 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:10:23 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:10:23 --> Utf8 Class Initialized
INFO - 2016-02-10 08:10:23 --> URI Class Initialized
INFO - 2016-02-10 08:10:23 --> Router Class Initialized
INFO - 2016-02-10 08:10:23 --> Output Class Initialized
INFO - 2016-02-10 08:10:23 --> Security Class Initialized
DEBUG - 2016-02-10 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:10:23 --> Input Class Initialized
INFO - 2016-02-10 08:10:23 --> Language Class Initialized
INFO - 2016-02-10 08:10:23 --> Loader Class Initialized
INFO - 2016-02-10 08:10:23 --> Helper loaded: url_helper
INFO - 2016-02-10 08:10:23 --> Helper loaded: file_helper
INFO - 2016-02-10 08:10:23 --> Helper loaded: date_helper
INFO - 2016-02-10 08:10:23 --> Helper loaded: form_helper
INFO - 2016-02-10 08:10:23 --> Database Driver Class Initialized
INFO - 2016-02-10 08:10:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:10:24 --> Controller Class Initialized
INFO - 2016-02-10 08:10:24 --> Model Class Initialized
INFO - 2016-02-10 08:10:24 --> Model Class Initialized
INFO - 2016-02-10 08:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:10:24 --> Pagination Class Initialized
INFO - 2016-02-10 11:10:24 --> Form Validation Class Initialized
INFO - 2016-02-10 11:10:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:10:24 --> Model Class Initialized
INFO - 2016-02-10 11:10:24 --> Final output sent to browser
DEBUG - 2016-02-10 11:10:24 --> Total execution time: 1.1743
INFO - 2016-02-10 08:13:00 --> Config Class Initialized
INFO - 2016-02-10 08:13:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:13:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:13:00 --> Utf8 Class Initialized
INFO - 2016-02-10 08:13:00 --> URI Class Initialized
INFO - 2016-02-10 08:13:00 --> Router Class Initialized
INFO - 2016-02-10 08:13:00 --> Output Class Initialized
INFO - 2016-02-10 08:13:00 --> Security Class Initialized
DEBUG - 2016-02-10 08:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:13:00 --> Input Class Initialized
INFO - 2016-02-10 08:13:00 --> Language Class Initialized
INFO - 2016-02-10 08:13:00 --> Loader Class Initialized
INFO - 2016-02-10 08:13:00 --> Helper loaded: url_helper
INFO - 2016-02-10 08:13:00 --> Helper loaded: file_helper
INFO - 2016-02-10 08:13:00 --> Helper loaded: date_helper
INFO - 2016-02-10 08:13:00 --> Helper loaded: form_helper
INFO - 2016-02-10 08:13:00 --> Database Driver Class Initialized
INFO - 2016-02-10 08:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:13:01 --> Controller Class Initialized
INFO - 2016-02-10 08:13:01 --> Model Class Initialized
INFO - 2016-02-10 08:13:01 --> Model Class Initialized
INFO - 2016-02-10 08:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:13:01 --> Pagination Class Initialized
INFO - 2016-02-10 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:13:01 --> Helper loaded: text_helper
INFO - 2016-02-10 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:13:01 --> Final output sent to browser
DEBUG - 2016-02-10 11:13:01 --> Total execution time: 1.1462
INFO - 2016-02-10 08:13:14 --> Config Class Initialized
INFO - 2016-02-10 08:13:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:13:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:13:14 --> Utf8 Class Initialized
INFO - 2016-02-10 08:13:14 --> URI Class Initialized
INFO - 2016-02-10 08:13:14 --> Router Class Initialized
INFO - 2016-02-10 08:13:14 --> Output Class Initialized
INFO - 2016-02-10 08:13:14 --> Security Class Initialized
DEBUG - 2016-02-10 08:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:13:14 --> Input Class Initialized
INFO - 2016-02-10 08:13:14 --> Language Class Initialized
INFO - 2016-02-10 08:13:14 --> Loader Class Initialized
INFO - 2016-02-10 08:13:15 --> Helper loaded: url_helper
INFO - 2016-02-10 08:13:15 --> Helper loaded: file_helper
INFO - 2016-02-10 08:13:15 --> Helper loaded: date_helper
INFO - 2016-02-10 08:13:15 --> Helper loaded: form_helper
INFO - 2016-02-10 08:13:15 --> Database Driver Class Initialized
INFO - 2016-02-10 08:13:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:13:16 --> Controller Class Initialized
INFO - 2016-02-10 08:13:16 --> Model Class Initialized
INFO - 2016-02-10 08:13:16 --> Model Class Initialized
INFO - 2016-02-10 08:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:13:16 --> Pagination Class Initialized
INFO - 2016-02-10 11:13:16 --> Form Validation Class Initialized
INFO - 2016-02-10 11:13:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:13:16 --> Model Class Initialized
INFO - 2016-02-10 11:13:16 --> Final output sent to browser
DEBUG - 2016-02-10 11:13:16 --> Total execution time: 1.1984
INFO - 2016-02-10 08:22:14 --> Config Class Initialized
INFO - 2016-02-10 08:22:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:22:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:22:14 --> Utf8 Class Initialized
INFO - 2016-02-10 08:22:14 --> URI Class Initialized
INFO - 2016-02-10 08:22:14 --> Router Class Initialized
INFO - 2016-02-10 08:22:14 --> Output Class Initialized
INFO - 2016-02-10 08:22:14 --> Security Class Initialized
DEBUG - 2016-02-10 08:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:22:14 --> Input Class Initialized
INFO - 2016-02-10 08:22:14 --> Language Class Initialized
INFO - 2016-02-10 08:22:14 --> Loader Class Initialized
INFO - 2016-02-10 08:22:14 --> Helper loaded: url_helper
INFO - 2016-02-10 08:22:14 --> Helper loaded: file_helper
INFO - 2016-02-10 08:22:14 --> Helper loaded: date_helper
INFO - 2016-02-10 08:22:14 --> Helper loaded: form_helper
INFO - 2016-02-10 08:22:14 --> Database Driver Class Initialized
INFO - 2016-02-10 08:22:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:22:15 --> Controller Class Initialized
INFO - 2016-02-10 08:22:15 --> Model Class Initialized
INFO - 2016-02-10 08:22:15 --> Model Class Initialized
INFO - 2016-02-10 08:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:22:15 --> Pagination Class Initialized
INFO - 2016-02-10 11:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:22:15 --> Helper loaded: text_helper
INFO - 2016-02-10 11:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:22:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:22:15 --> Final output sent to browser
DEBUG - 2016-02-10 11:22:15 --> Total execution time: 1.1698
INFO - 2016-02-10 08:22:58 --> Config Class Initialized
INFO - 2016-02-10 08:22:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:22:58 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:22:58 --> Utf8 Class Initialized
INFO - 2016-02-10 08:22:58 --> URI Class Initialized
INFO - 2016-02-10 08:22:58 --> Router Class Initialized
INFO - 2016-02-10 08:22:58 --> Output Class Initialized
INFO - 2016-02-10 08:22:58 --> Security Class Initialized
DEBUG - 2016-02-10 08:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:22:58 --> Input Class Initialized
INFO - 2016-02-10 08:22:58 --> Language Class Initialized
INFO - 2016-02-10 08:22:58 --> Loader Class Initialized
INFO - 2016-02-10 08:22:58 --> Helper loaded: url_helper
INFO - 2016-02-10 08:22:58 --> Helper loaded: file_helper
INFO - 2016-02-10 08:22:58 --> Helper loaded: date_helper
INFO - 2016-02-10 08:22:58 --> Helper loaded: form_helper
INFO - 2016-02-10 08:22:58 --> Database Driver Class Initialized
INFO - 2016-02-10 08:22:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:22:59 --> Controller Class Initialized
INFO - 2016-02-10 08:22:59 --> Model Class Initialized
INFO - 2016-02-10 08:22:59 --> Model Class Initialized
INFO - 2016-02-10 08:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:22:59 --> Pagination Class Initialized
INFO - 2016-02-10 11:22:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:22:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:22:59 --> Helper loaded: text_helper
INFO - 2016-02-10 11:22:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:22:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:22:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:22:59 --> Final output sent to browser
DEBUG - 2016-02-10 11:22:59 --> Total execution time: 1.2707
INFO - 2016-02-10 08:23:10 --> Config Class Initialized
INFO - 2016-02-10 08:23:10 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:23:10 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:23:10 --> Utf8 Class Initialized
INFO - 2016-02-10 08:23:10 --> URI Class Initialized
INFO - 2016-02-10 08:23:10 --> Router Class Initialized
INFO - 2016-02-10 08:23:10 --> Output Class Initialized
INFO - 2016-02-10 08:23:10 --> Security Class Initialized
DEBUG - 2016-02-10 08:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:23:10 --> Input Class Initialized
INFO - 2016-02-10 08:23:10 --> Language Class Initialized
INFO - 2016-02-10 08:23:10 --> Loader Class Initialized
INFO - 2016-02-10 08:23:10 --> Helper loaded: url_helper
INFO - 2016-02-10 08:23:10 --> Helper loaded: file_helper
INFO - 2016-02-10 08:23:10 --> Helper loaded: date_helper
INFO - 2016-02-10 08:23:10 --> Helper loaded: form_helper
INFO - 2016-02-10 08:23:10 --> Database Driver Class Initialized
INFO - 2016-02-10 08:23:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:23:11 --> Controller Class Initialized
INFO - 2016-02-10 08:23:11 --> Model Class Initialized
INFO - 2016-02-10 08:23:11 --> Model Class Initialized
INFO - 2016-02-10 08:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:23:11 --> Pagination Class Initialized
INFO - 2016-02-10 11:23:11 --> Form Validation Class Initialized
INFO - 2016-02-10 11:23:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:23:11 --> Model Class Initialized
INFO - 2016-02-10 11:23:12 --> Final output sent to browser
DEBUG - 2016-02-10 11:23:12 --> Total execution time: 1.1623
INFO - 2016-02-10 08:24:40 --> Config Class Initialized
INFO - 2016-02-10 08:24:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:24:40 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:24:40 --> Utf8 Class Initialized
INFO - 2016-02-10 08:24:40 --> URI Class Initialized
INFO - 2016-02-10 08:24:40 --> Router Class Initialized
INFO - 2016-02-10 08:24:40 --> Output Class Initialized
INFO - 2016-02-10 08:24:40 --> Security Class Initialized
DEBUG - 2016-02-10 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:24:40 --> Input Class Initialized
INFO - 2016-02-10 08:24:40 --> Language Class Initialized
INFO - 2016-02-10 08:24:40 --> Loader Class Initialized
INFO - 2016-02-10 08:24:40 --> Helper loaded: url_helper
INFO - 2016-02-10 08:24:40 --> Helper loaded: file_helper
INFO - 2016-02-10 08:24:40 --> Helper loaded: date_helper
INFO - 2016-02-10 08:24:40 --> Helper loaded: form_helper
INFO - 2016-02-10 08:24:40 --> Database Driver Class Initialized
INFO - 2016-02-10 08:24:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:24:41 --> Controller Class Initialized
INFO - 2016-02-10 08:24:41 --> Model Class Initialized
INFO - 2016-02-10 08:24:41 --> Model Class Initialized
INFO - 2016-02-10 08:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:24:41 --> Pagination Class Initialized
INFO - 2016-02-10 11:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:24:41 --> Helper loaded: text_helper
INFO - 2016-02-10 11:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:24:41 --> Final output sent to browser
DEBUG - 2016-02-10 11:24:41 --> Total execution time: 1.1612
INFO - 2016-02-10 08:25:06 --> Config Class Initialized
INFO - 2016-02-10 08:25:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:25:06 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:25:06 --> Utf8 Class Initialized
INFO - 2016-02-10 08:25:06 --> URI Class Initialized
INFO - 2016-02-10 08:25:06 --> Router Class Initialized
INFO - 2016-02-10 08:25:06 --> Output Class Initialized
INFO - 2016-02-10 08:25:06 --> Security Class Initialized
DEBUG - 2016-02-10 08:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:25:06 --> Input Class Initialized
INFO - 2016-02-10 08:25:06 --> Language Class Initialized
INFO - 2016-02-10 08:25:06 --> Loader Class Initialized
INFO - 2016-02-10 08:25:06 --> Helper loaded: url_helper
INFO - 2016-02-10 08:25:06 --> Helper loaded: file_helper
INFO - 2016-02-10 08:25:06 --> Helper loaded: date_helper
INFO - 2016-02-10 08:25:06 --> Helper loaded: form_helper
INFO - 2016-02-10 08:25:06 --> Database Driver Class Initialized
INFO - 2016-02-10 08:25:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:25:07 --> Controller Class Initialized
INFO - 2016-02-10 08:25:07 --> Model Class Initialized
INFO - 2016-02-10 08:25:07 --> Model Class Initialized
INFO - 2016-02-10 08:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:25:07 --> Pagination Class Initialized
INFO - 2016-02-10 11:25:07 --> Form Validation Class Initialized
INFO - 2016-02-10 11:25:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:25:07 --> Model Class Initialized
INFO - 2016-02-10 11:25:07 --> Final output sent to browser
DEBUG - 2016-02-10 11:25:07 --> Total execution time: 1.1931
INFO - 2016-02-10 08:25:37 --> Config Class Initialized
INFO - 2016-02-10 08:25:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:25:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:25:37 --> Utf8 Class Initialized
INFO - 2016-02-10 08:25:37 --> URI Class Initialized
DEBUG - 2016-02-10 08:25:37 --> No URI present. Default controller set.
INFO - 2016-02-10 08:25:37 --> Router Class Initialized
INFO - 2016-02-10 08:25:37 --> Output Class Initialized
INFO - 2016-02-10 08:25:37 --> Security Class Initialized
DEBUG - 2016-02-10 08:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:25:37 --> Input Class Initialized
INFO - 2016-02-10 08:25:37 --> Language Class Initialized
INFO - 2016-02-10 08:25:37 --> Loader Class Initialized
INFO - 2016-02-10 08:25:37 --> Helper loaded: url_helper
INFO - 2016-02-10 08:25:37 --> Helper loaded: file_helper
INFO - 2016-02-10 08:25:37 --> Helper loaded: date_helper
INFO - 2016-02-10 08:25:37 --> Helper loaded: form_helper
INFO - 2016-02-10 08:25:37 --> Database Driver Class Initialized
INFO - 2016-02-10 08:25:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:25:38 --> Controller Class Initialized
INFO - 2016-02-10 08:25:38 --> Model Class Initialized
INFO - 2016-02-10 08:25:38 --> Model Class Initialized
INFO - 2016-02-10 08:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:25:38 --> Pagination Class Initialized
INFO - 2016-02-10 11:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:25:38 --> Final output sent to browser
DEBUG - 2016-02-10 11:25:38 --> Total execution time: 1.1145
INFO - 2016-02-10 08:25:39 --> Config Class Initialized
INFO - 2016-02-10 08:25:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:25:39 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:25:39 --> Utf8 Class Initialized
INFO - 2016-02-10 08:25:39 --> URI Class Initialized
INFO - 2016-02-10 08:25:39 --> Router Class Initialized
INFO - 2016-02-10 08:25:39 --> Output Class Initialized
INFO - 2016-02-10 08:25:39 --> Security Class Initialized
DEBUG - 2016-02-10 08:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:25:39 --> Input Class Initialized
INFO - 2016-02-10 08:25:39 --> Language Class Initialized
INFO - 2016-02-10 08:25:39 --> Loader Class Initialized
INFO - 2016-02-10 08:25:39 --> Helper loaded: url_helper
INFO - 2016-02-10 08:25:39 --> Helper loaded: file_helper
INFO - 2016-02-10 08:25:39 --> Helper loaded: date_helper
INFO - 2016-02-10 08:25:39 --> Helper loaded: form_helper
INFO - 2016-02-10 08:25:39 --> Database Driver Class Initialized
INFO - 2016-02-10 08:25:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:25:40 --> Controller Class Initialized
INFO - 2016-02-10 08:25:40 --> Model Class Initialized
INFO - 2016-02-10 08:25:40 --> Model Class Initialized
INFO - 2016-02-10 08:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:25:40 --> Pagination Class Initialized
INFO - 2016-02-10 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:25:40 --> Helper loaded: text_helper
INFO - 2016-02-10 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:25:40 --> Final output sent to browser
DEBUG - 2016-02-10 11:25:40 --> Total execution time: 1.1217
INFO - 2016-02-10 08:28:45 --> Config Class Initialized
INFO - 2016-02-10 08:28:45 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:28:45 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:28:45 --> Utf8 Class Initialized
INFO - 2016-02-10 08:28:45 --> URI Class Initialized
INFO - 2016-02-10 08:28:45 --> Router Class Initialized
INFO - 2016-02-10 08:28:45 --> Output Class Initialized
INFO - 2016-02-10 08:28:45 --> Security Class Initialized
DEBUG - 2016-02-10 08:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:28:45 --> Input Class Initialized
INFO - 2016-02-10 08:28:45 --> Language Class Initialized
INFO - 2016-02-10 08:28:45 --> Loader Class Initialized
INFO - 2016-02-10 08:28:45 --> Helper loaded: url_helper
INFO - 2016-02-10 08:28:45 --> Helper loaded: file_helper
INFO - 2016-02-10 08:28:45 --> Helper loaded: date_helper
INFO - 2016-02-10 08:28:45 --> Helper loaded: form_helper
INFO - 2016-02-10 08:28:45 --> Database Driver Class Initialized
INFO - 2016-02-10 08:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:28:46 --> Controller Class Initialized
INFO - 2016-02-10 08:28:46 --> Model Class Initialized
INFO - 2016-02-10 08:28:46 --> Model Class Initialized
INFO - 2016-02-10 08:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:28:46 --> Pagination Class Initialized
INFO - 2016-02-10 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:28:46 --> Helper loaded: text_helper
INFO - 2016-02-10 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:28:46 --> Final output sent to browser
DEBUG - 2016-02-10 11:28:46 --> Total execution time: 1.1815
INFO - 2016-02-10 08:29:03 --> Config Class Initialized
INFO - 2016-02-10 08:29:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:29:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:29:03 --> Utf8 Class Initialized
INFO - 2016-02-10 08:29:03 --> URI Class Initialized
INFO - 2016-02-10 08:29:03 --> Router Class Initialized
INFO - 2016-02-10 08:29:03 --> Output Class Initialized
INFO - 2016-02-10 08:29:03 --> Security Class Initialized
DEBUG - 2016-02-10 08:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:29:03 --> Input Class Initialized
INFO - 2016-02-10 08:29:03 --> Language Class Initialized
INFO - 2016-02-10 08:29:03 --> Loader Class Initialized
INFO - 2016-02-10 08:29:03 --> Helper loaded: url_helper
INFO - 2016-02-10 08:29:03 --> Helper loaded: file_helper
INFO - 2016-02-10 08:29:03 --> Helper loaded: date_helper
INFO - 2016-02-10 08:29:03 --> Helper loaded: form_helper
INFO - 2016-02-10 08:29:03 --> Database Driver Class Initialized
INFO - 2016-02-10 08:29:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:29:04 --> Controller Class Initialized
INFO - 2016-02-10 08:29:04 --> Model Class Initialized
INFO - 2016-02-10 08:29:04 --> Model Class Initialized
INFO - 2016-02-10 08:29:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:29:04 --> Pagination Class Initialized
INFO - 2016-02-10 11:29:04 --> Form Validation Class Initialized
INFO - 2016-02-10 11:29:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:29:04 --> Model Class Initialized
INFO - 2016-02-10 11:29:04 --> Final output sent to browser
DEBUG - 2016-02-10 11:29:04 --> Total execution time: 1.1776
INFO - 2016-02-10 08:29:09 --> Config Class Initialized
INFO - 2016-02-10 08:29:09 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:29:09 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:29:09 --> Utf8 Class Initialized
INFO - 2016-02-10 08:29:09 --> URI Class Initialized
INFO - 2016-02-10 08:29:09 --> Router Class Initialized
INFO - 2016-02-10 08:29:09 --> Output Class Initialized
INFO - 2016-02-10 08:29:09 --> Security Class Initialized
DEBUG - 2016-02-10 08:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:29:09 --> Input Class Initialized
INFO - 2016-02-10 08:29:09 --> Language Class Initialized
INFO - 2016-02-10 08:29:09 --> Loader Class Initialized
INFO - 2016-02-10 08:29:09 --> Helper loaded: url_helper
INFO - 2016-02-10 08:29:09 --> Helper loaded: file_helper
INFO - 2016-02-10 08:29:09 --> Helper loaded: date_helper
INFO - 2016-02-10 08:29:09 --> Helper loaded: form_helper
INFO - 2016-02-10 08:29:09 --> Database Driver Class Initialized
INFO - 2016-02-10 08:29:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:29:10 --> Controller Class Initialized
INFO - 2016-02-10 08:29:10 --> Model Class Initialized
INFO - 2016-02-10 08:29:10 --> Model Class Initialized
INFO - 2016-02-10 08:29:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:29:10 --> Pagination Class Initialized
INFO - 2016-02-10 11:29:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:29:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:29:10 --> Helper loaded: text_helper
INFO - 2016-02-10 11:29:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:29:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:29:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:29:10 --> Final output sent to browser
DEBUG - 2016-02-10 11:29:10 --> Total execution time: 1.1627
INFO - 2016-02-10 08:30:14 --> Config Class Initialized
INFO - 2016-02-10 08:30:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:30:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:30:14 --> Utf8 Class Initialized
INFO - 2016-02-10 08:30:14 --> URI Class Initialized
INFO - 2016-02-10 08:30:14 --> Router Class Initialized
INFO - 2016-02-10 08:30:14 --> Output Class Initialized
INFO - 2016-02-10 08:30:14 --> Security Class Initialized
DEBUG - 2016-02-10 08:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:30:14 --> Input Class Initialized
INFO - 2016-02-10 08:30:14 --> Language Class Initialized
INFO - 2016-02-10 08:30:14 --> Loader Class Initialized
INFO - 2016-02-10 08:30:14 --> Helper loaded: url_helper
INFO - 2016-02-10 08:30:14 --> Helper loaded: file_helper
INFO - 2016-02-10 08:30:14 --> Helper loaded: date_helper
INFO - 2016-02-10 08:30:14 --> Helper loaded: form_helper
INFO - 2016-02-10 08:30:14 --> Database Driver Class Initialized
INFO - 2016-02-10 08:30:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:30:15 --> Controller Class Initialized
INFO - 2016-02-10 08:30:15 --> Model Class Initialized
INFO - 2016-02-10 08:30:15 --> Model Class Initialized
INFO - 2016-02-10 08:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:30:15 --> Pagination Class Initialized
INFO - 2016-02-10 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:30:15 --> Helper loaded: text_helper
INFO - 2016-02-10 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:30:15 --> Final output sent to browser
DEBUG - 2016-02-10 11:30:15 --> Total execution time: 1.1699
INFO - 2016-02-10 08:31:20 --> Config Class Initialized
INFO - 2016-02-10 08:31:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:31:20 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:31:20 --> Utf8 Class Initialized
INFO - 2016-02-10 08:31:20 --> URI Class Initialized
INFO - 2016-02-10 08:31:20 --> Router Class Initialized
INFO - 2016-02-10 08:31:20 --> Output Class Initialized
INFO - 2016-02-10 08:31:20 --> Security Class Initialized
DEBUG - 2016-02-10 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:31:20 --> Input Class Initialized
INFO - 2016-02-10 08:31:20 --> Language Class Initialized
INFO - 2016-02-10 08:31:20 --> Loader Class Initialized
INFO - 2016-02-10 08:31:20 --> Helper loaded: url_helper
INFO - 2016-02-10 08:31:20 --> Helper loaded: file_helper
INFO - 2016-02-10 08:31:20 --> Helper loaded: date_helper
INFO - 2016-02-10 08:31:20 --> Helper loaded: form_helper
INFO - 2016-02-10 08:31:20 --> Database Driver Class Initialized
INFO - 2016-02-10 08:31:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:31:21 --> Controller Class Initialized
INFO - 2016-02-10 08:31:21 --> Model Class Initialized
INFO - 2016-02-10 08:31:21 --> Model Class Initialized
INFO - 2016-02-10 08:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:31:21 --> Pagination Class Initialized
INFO - 2016-02-10 11:31:21 --> Form Validation Class Initialized
INFO - 2016-02-10 11:31:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:31:21 --> Model Class Initialized
INFO - 2016-02-10 11:31:21 --> Final output sent to browser
DEBUG - 2016-02-10 11:31:21 --> Total execution time: 1.1742
INFO - 2016-02-10 08:31:28 --> Config Class Initialized
INFO - 2016-02-10 08:31:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:31:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:31:28 --> Utf8 Class Initialized
INFO - 2016-02-10 08:31:28 --> URI Class Initialized
INFO - 2016-02-10 08:31:28 --> Router Class Initialized
INFO - 2016-02-10 08:31:28 --> Output Class Initialized
INFO - 2016-02-10 08:31:28 --> Security Class Initialized
DEBUG - 2016-02-10 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:31:28 --> Input Class Initialized
INFO - 2016-02-10 08:31:28 --> Language Class Initialized
INFO - 2016-02-10 08:31:28 --> Loader Class Initialized
INFO - 2016-02-10 08:31:28 --> Helper loaded: url_helper
INFO - 2016-02-10 08:31:28 --> Helper loaded: file_helper
INFO - 2016-02-10 08:31:28 --> Helper loaded: date_helper
INFO - 2016-02-10 08:31:28 --> Helper loaded: form_helper
INFO - 2016-02-10 08:31:28 --> Database Driver Class Initialized
INFO - 2016-02-10 08:31:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:31:29 --> Controller Class Initialized
INFO - 2016-02-10 08:31:29 --> Model Class Initialized
INFO - 2016-02-10 08:31:29 --> Model Class Initialized
INFO - 2016-02-10 08:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:31:29 --> Pagination Class Initialized
INFO - 2016-02-10 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:31:29 --> Helper loaded: text_helper
INFO - 2016-02-10 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:31:29 --> Final output sent to browser
DEBUG - 2016-02-10 11:31:29 --> Total execution time: 1.1751
INFO - 2016-02-10 08:31:42 --> Config Class Initialized
INFO - 2016-02-10 08:31:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:31:42 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:31:42 --> Utf8 Class Initialized
INFO - 2016-02-10 08:31:42 --> URI Class Initialized
INFO - 2016-02-10 08:31:42 --> Router Class Initialized
INFO - 2016-02-10 08:31:42 --> Output Class Initialized
INFO - 2016-02-10 08:31:42 --> Security Class Initialized
DEBUG - 2016-02-10 08:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:31:43 --> Input Class Initialized
INFO - 2016-02-10 08:31:43 --> Language Class Initialized
INFO - 2016-02-10 08:31:43 --> Loader Class Initialized
INFO - 2016-02-10 08:31:43 --> Helper loaded: url_helper
INFO - 2016-02-10 08:31:43 --> Helper loaded: file_helper
INFO - 2016-02-10 08:31:43 --> Helper loaded: date_helper
INFO - 2016-02-10 08:31:43 --> Helper loaded: form_helper
INFO - 2016-02-10 08:31:43 --> Database Driver Class Initialized
INFO - 2016-02-10 08:31:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:31:44 --> Controller Class Initialized
INFO - 2016-02-10 08:31:44 --> Model Class Initialized
INFO - 2016-02-10 08:31:44 --> Model Class Initialized
INFO - 2016-02-10 08:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:31:44 --> Pagination Class Initialized
INFO - 2016-02-10 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:31:44 --> Helper loaded: text_helper
INFO - 2016-02-10 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:31:44 --> Final output sent to browser
DEBUG - 2016-02-10 11:31:44 --> Total execution time: 1.1790
INFO - 2016-02-10 08:32:11 --> Config Class Initialized
INFO - 2016-02-10 08:32:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:32:11 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:32:11 --> Utf8 Class Initialized
INFO - 2016-02-10 08:32:11 --> URI Class Initialized
INFO - 2016-02-10 08:32:11 --> Router Class Initialized
INFO - 2016-02-10 08:32:11 --> Output Class Initialized
INFO - 2016-02-10 08:32:11 --> Security Class Initialized
DEBUG - 2016-02-10 08:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:32:11 --> Input Class Initialized
INFO - 2016-02-10 08:32:11 --> Language Class Initialized
INFO - 2016-02-10 08:32:11 --> Loader Class Initialized
INFO - 2016-02-10 08:32:11 --> Helper loaded: url_helper
INFO - 2016-02-10 08:32:11 --> Helper loaded: file_helper
INFO - 2016-02-10 08:32:11 --> Helper loaded: date_helper
INFO - 2016-02-10 08:32:11 --> Helper loaded: form_helper
INFO - 2016-02-10 08:32:11 --> Database Driver Class Initialized
INFO - 2016-02-10 08:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:32:12 --> Controller Class Initialized
INFO - 2016-02-10 08:32:12 --> Model Class Initialized
INFO - 2016-02-10 08:32:12 --> Model Class Initialized
INFO - 2016-02-10 08:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:32:12 --> Pagination Class Initialized
INFO - 2016-02-10 11:32:12 --> Form Validation Class Initialized
INFO - 2016-02-10 11:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:32:12 --> Model Class Initialized
INFO - 2016-02-10 11:32:12 --> Final output sent to browser
DEBUG - 2016-02-10 11:32:12 --> Total execution time: 1.1893
INFO - 2016-02-10 08:33:00 --> Config Class Initialized
INFO - 2016-02-10 08:33:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:33:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:33:00 --> Utf8 Class Initialized
INFO - 2016-02-10 08:33:00 --> URI Class Initialized
DEBUG - 2016-02-10 08:33:00 --> No URI present. Default controller set.
INFO - 2016-02-10 08:33:00 --> Router Class Initialized
INFO - 2016-02-10 08:33:00 --> Output Class Initialized
INFO - 2016-02-10 08:33:00 --> Security Class Initialized
DEBUG - 2016-02-10 08:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:33:00 --> Input Class Initialized
INFO - 2016-02-10 08:33:00 --> Language Class Initialized
INFO - 2016-02-10 08:33:00 --> Loader Class Initialized
INFO - 2016-02-10 08:33:00 --> Helper loaded: url_helper
INFO - 2016-02-10 08:33:00 --> Helper loaded: file_helper
INFO - 2016-02-10 08:33:00 --> Helper loaded: date_helper
INFO - 2016-02-10 08:33:00 --> Helper loaded: form_helper
INFO - 2016-02-10 08:33:00 --> Database Driver Class Initialized
INFO - 2016-02-10 08:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:33:01 --> Controller Class Initialized
INFO - 2016-02-10 08:33:01 --> Model Class Initialized
INFO - 2016-02-10 08:33:01 --> Model Class Initialized
INFO - 2016-02-10 08:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:33:01 --> Pagination Class Initialized
INFO - 2016-02-10 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:33:01 --> Final output sent to browser
DEBUG - 2016-02-10 11:33:01 --> Total execution time: 1.1290
INFO - 2016-02-10 08:33:05 --> Config Class Initialized
INFO - 2016-02-10 08:33:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:33:05 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:33:05 --> Utf8 Class Initialized
INFO - 2016-02-10 08:33:05 --> URI Class Initialized
INFO - 2016-02-10 08:33:05 --> Router Class Initialized
INFO - 2016-02-10 08:33:05 --> Output Class Initialized
INFO - 2016-02-10 08:33:05 --> Security Class Initialized
DEBUG - 2016-02-10 08:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:33:05 --> Input Class Initialized
INFO - 2016-02-10 08:33:05 --> Language Class Initialized
INFO - 2016-02-10 08:33:05 --> Loader Class Initialized
INFO - 2016-02-10 08:33:05 --> Helper loaded: url_helper
INFO - 2016-02-10 08:33:05 --> Helper loaded: file_helper
INFO - 2016-02-10 08:33:05 --> Helper loaded: date_helper
INFO - 2016-02-10 08:33:05 --> Helper loaded: form_helper
INFO - 2016-02-10 08:33:05 --> Database Driver Class Initialized
INFO - 2016-02-10 08:33:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:33:06 --> Controller Class Initialized
INFO - 2016-02-10 08:33:06 --> Model Class Initialized
INFO - 2016-02-10 08:33:06 --> Model Class Initialized
INFO - 2016-02-10 08:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:33:06 --> Pagination Class Initialized
INFO - 2016-02-10 11:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:33:06 --> Helper loaded: text_helper
INFO - 2016-02-10 11:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:33:06 --> Final output sent to browser
DEBUG - 2016-02-10 11:33:06 --> Total execution time: 1.2004
INFO - 2016-02-10 08:33:22 --> Config Class Initialized
INFO - 2016-02-10 08:33:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:33:22 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:33:22 --> Utf8 Class Initialized
INFO - 2016-02-10 08:33:22 --> URI Class Initialized
DEBUG - 2016-02-10 08:33:22 --> No URI present. Default controller set.
INFO - 2016-02-10 08:33:22 --> Router Class Initialized
INFO - 2016-02-10 08:33:22 --> Output Class Initialized
INFO - 2016-02-10 08:33:22 --> Security Class Initialized
DEBUG - 2016-02-10 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:33:22 --> Input Class Initialized
INFO - 2016-02-10 08:33:22 --> Language Class Initialized
INFO - 2016-02-10 08:33:22 --> Loader Class Initialized
INFO - 2016-02-10 08:33:22 --> Helper loaded: url_helper
INFO - 2016-02-10 08:33:22 --> Helper loaded: file_helper
INFO - 2016-02-10 08:33:22 --> Helper loaded: date_helper
INFO - 2016-02-10 08:33:22 --> Helper loaded: form_helper
INFO - 2016-02-10 08:33:22 --> Database Driver Class Initialized
INFO - 2016-02-10 08:33:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:33:23 --> Controller Class Initialized
INFO - 2016-02-10 08:33:23 --> Model Class Initialized
INFO - 2016-02-10 08:33:23 --> Model Class Initialized
INFO - 2016-02-10 08:33:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:33:23 --> Pagination Class Initialized
INFO - 2016-02-10 11:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:33:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:33:23 --> Final output sent to browser
DEBUG - 2016-02-10 11:33:23 --> Total execution time: 1.0831
INFO - 2016-02-10 08:40:22 --> Config Class Initialized
INFO - 2016-02-10 08:40:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:40:22 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:40:22 --> Utf8 Class Initialized
INFO - 2016-02-10 08:40:22 --> URI Class Initialized
DEBUG - 2016-02-10 08:40:22 --> No URI present. Default controller set.
INFO - 2016-02-10 08:40:22 --> Router Class Initialized
INFO - 2016-02-10 08:40:22 --> Output Class Initialized
INFO - 2016-02-10 08:40:22 --> Security Class Initialized
DEBUG - 2016-02-10 08:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:40:22 --> Input Class Initialized
INFO - 2016-02-10 08:40:22 --> Language Class Initialized
INFO - 2016-02-10 08:40:22 --> Loader Class Initialized
INFO - 2016-02-10 08:40:22 --> Helper loaded: url_helper
INFO - 2016-02-10 08:40:22 --> Helper loaded: file_helper
INFO - 2016-02-10 08:40:22 --> Helper loaded: date_helper
INFO - 2016-02-10 08:40:22 --> Helper loaded: form_helper
INFO - 2016-02-10 08:40:22 --> Database Driver Class Initialized
INFO - 2016-02-10 08:40:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:40:23 --> Controller Class Initialized
INFO - 2016-02-10 08:40:23 --> Model Class Initialized
INFO - 2016-02-10 08:40:23 --> Model Class Initialized
INFO - 2016-02-10 08:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:40:23 --> Pagination Class Initialized
INFO - 2016-02-10 11:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:40:23 --> Final output sent to browser
DEBUG - 2016-02-10 11:40:23 --> Total execution time: 1.1327
INFO - 2016-02-10 08:40:28 --> Config Class Initialized
INFO - 2016-02-10 08:40:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:40:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:40:28 --> Utf8 Class Initialized
INFO - 2016-02-10 08:40:28 --> URI Class Initialized
DEBUG - 2016-02-10 08:40:28 --> No URI present. Default controller set.
INFO - 2016-02-10 08:40:28 --> Router Class Initialized
INFO - 2016-02-10 08:40:28 --> Output Class Initialized
INFO - 2016-02-10 08:40:28 --> Security Class Initialized
DEBUG - 2016-02-10 08:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:40:28 --> Input Class Initialized
INFO - 2016-02-10 08:40:28 --> Language Class Initialized
INFO - 2016-02-10 08:40:28 --> Loader Class Initialized
INFO - 2016-02-10 08:40:28 --> Helper loaded: url_helper
INFO - 2016-02-10 08:40:28 --> Helper loaded: file_helper
INFO - 2016-02-10 08:40:28 --> Helper loaded: date_helper
INFO - 2016-02-10 08:40:28 --> Helper loaded: form_helper
INFO - 2016-02-10 08:40:28 --> Database Driver Class Initialized
INFO - 2016-02-10 08:40:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:40:29 --> Controller Class Initialized
INFO - 2016-02-10 08:40:29 --> Model Class Initialized
INFO - 2016-02-10 08:40:29 --> Model Class Initialized
INFO - 2016-02-10 08:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:40:29 --> Pagination Class Initialized
INFO - 2016-02-10 11:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:40:29 --> Final output sent to browser
DEBUG - 2016-02-10 11:40:29 --> Total execution time: 1.1124
INFO - 2016-02-10 08:40:34 --> Config Class Initialized
INFO - 2016-02-10 08:40:34 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:40:34 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:40:34 --> Utf8 Class Initialized
INFO - 2016-02-10 08:40:34 --> URI Class Initialized
INFO - 2016-02-10 08:40:34 --> Router Class Initialized
INFO - 2016-02-10 08:40:34 --> Output Class Initialized
INFO - 2016-02-10 08:40:34 --> Security Class Initialized
DEBUG - 2016-02-10 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:40:34 --> Input Class Initialized
INFO - 2016-02-10 08:40:34 --> Language Class Initialized
INFO - 2016-02-10 08:40:34 --> Loader Class Initialized
INFO - 2016-02-10 08:40:34 --> Helper loaded: url_helper
INFO - 2016-02-10 08:40:34 --> Helper loaded: file_helper
INFO - 2016-02-10 08:40:34 --> Helper loaded: date_helper
INFO - 2016-02-10 08:40:34 --> Helper loaded: form_helper
INFO - 2016-02-10 08:40:34 --> Database Driver Class Initialized
INFO - 2016-02-10 08:40:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:40:35 --> Controller Class Initialized
INFO - 2016-02-10 08:40:35 --> Model Class Initialized
INFO - 2016-02-10 08:40:35 --> Model Class Initialized
INFO - 2016-02-10 08:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:40:35 --> Pagination Class Initialized
INFO - 2016-02-10 11:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:40:35 --> Final output sent to browser
DEBUG - 2016-02-10 11:40:35 --> Total execution time: 1.0988
INFO - 2016-02-10 08:40:38 --> Config Class Initialized
INFO - 2016-02-10 08:40:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:40:38 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:40:38 --> Utf8 Class Initialized
INFO - 2016-02-10 08:40:38 --> URI Class Initialized
INFO - 2016-02-10 08:40:38 --> Router Class Initialized
INFO - 2016-02-10 08:40:38 --> Output Class Initialized
INFO - 2016-02-10 08:40:38 --> Security Class Initialized
DEBUG - 2016-02-10 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:40:38 --> Input Class Initialized
INFO - 2016-02-10 08:40:38 --> Language Class Initialized
INFO - 2016-02-10 08:40:38 --> Loader Class Initialized
INFO - 2016-02-10 08:40:38 --> Helper loaded: url_helper
INFO - 2016-02-10 08:40:38 --> Helper loaded: file_helper
INFO - 2016-02-10 08:40:38 --> Helper loaded: date_helper
INFO - 2016-02-10 08:40:38 --> Helper loaded: form_helper
INFO - 2016-02-10 08:40:38 --> Database Driver Class Initialized
INFO - 2016-02-10 08:40:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:40:39 --> Controller Class Initialized
INFO - 2016-02-10 08:40:39 --> Model Class Initialized
INFO - 2016-02-10 08:40:39 --> Model Class Initialized
INFO - 2016-02-10 08:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:40:39 --> Pagination Class Initialized
INFO - 2016-02-10 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:40:39 --> Helper loaded: text_helper
INFO - 2016-02-10 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:40:39 --> Final output sent to browser
DEBUG - 2016-02-10 11:40:39 --> Total execution time: 1.1348
INFO - 2016-02-10 08:40:48 --> Config Class Initialized
INFO - 2016-02-10 08:40:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:40:48 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:40:48 --> Utf8 Class Initialized
INFO - 2016-02-10 08:40:48 --> URI Class Initialized
DEBUG - 2016-02-10 08:40:48 --> No URI present. Default controller set.
INFO - 2016-02-10 08:40:48 --> Router Class Initialized
INFO - 2016-02-10 08:40:48 --> Output Class Initialized
INFO - 2016-02-10 08:40:48 --> Security Class Initialized
DEBUG - 2016-02-10 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:40:48 --> Input Class Initialized
INFO - 2016-02-10 08:40:48 --> Language Class Initialized
INFO - 2016-02-10 08:40:48 --> Loader Class Initialized
INFO - 2016-02-10 08:40:48 --> Helper loaded: url_helper
INFO - 2016-02-10 08:40:48 --> Helper loaded: file_helper
INFO - 2016-02-10 08:40:48 --> Helper loaded: date_helper
INFO - 2016-02-10 08:40:48 --> Helper loaded: form_helper
INFO - 2016-02-10 08:40:48 --> Database Driver Class Initialized
INFO - 2016-02-10 08:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:40:49 --> Controller Class Initialized
INFO - 2016-02-10 08:40:49 --> Model Class Initialized
INFO - 2016-02-10 08:40:49 --> Model Class Initialized
INFO - 2016-02-10 08:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:40:49 --> Pagination Class Initialized
INFO - 2016-02-10 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 11:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:40:49 --> Final output sent to browser
DEBUG - 2016-02-10 11:40:49 --> Total execution time: 1.0934
INFO - 2016-02-10 08:44:29 --> Config Class Initialized
INFO - 2016-02-10 08:44:29 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:44:29 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:44:29 --> Utf8 Class Initialized
INFO - 2016-02-10 08:44:29 --> URI Class Initialized
INFO - 2016-02-10 08:44:29 --> Router Class Initialized
INFO - 2016-02-10 08:44:29 --> Output Class Initialized
INFO - 2016-02-10 08:44:29 --> Security Class Initialized
DEBUG - 2016-02-10 08:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:44:29 --> Input Class Initialized
INFO - 2016-02-10 08:44:29 --> Language Class Initialized
INFO - 2016-02-10 08:44:29 --> Loader Class Initialized
INFO - 2016-02-10 08:44:29 --> Helper loaded: url_helper
INFO - 2016-02-10 08:44:29 --> Helper loaded: file_helper
INFO - 2016-02-10 08:44:29 --> Helper loaded: date_helper
INFO - 2016-02-10 08:44:29 --> Helper loaded: form_helper
INFO - 2016-02-10 08:44:29 --> Database Driver Class Initialized
INFO - 2016-02-10 08:44:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:44:30 --> Controller Class Initialized
INFO - 2016-02-10 08:44:30 --> Model Class Initialized
INFO - 2016-02-10 08:44:30 --> Model Class Initialized
INFO - 2016-02-10 08:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:44:30 --> Pagination Class Initialized
INFO - 2016-02-10 11:44:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:44:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:44:30 --> Helper loaded: text_helper
INFO - 2016-02-10 11:44:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:44:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:44:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:44:30 --> Final output sent to browser
DEBUG - 2016-02-10 11:44:30 --> Total execution time: 1.1823
INFO - 2016-02-10 08:44:33 --> Config Class Initialized
INFO - 2016-02-10 08:44:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:44:33 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:44:33 --> Utf8 Class Initialized
INFO - 2016-02-10 08:44:33 --> URI Class Initialized
INFO - 2016-02-10 08:44:33 --> Router Class Initialized
INFO - 2016-02-10 08:44:33 --> Output Class Initialized
INFO - 2016-02-10 08:44:33 --> Security Class Initialized
DEBUG - 2016-02-10 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:44:33 --> Input Class Initialized
INFO - 2016-02-10 08:44:33 --> Language Class Initialized
INFO - 2016-02-10 08:44:33 --> Loader Class Initialized
INFO - 2016-02-10 08:44:33 --> Helper loaded: url_helper
INFO - 2016-02-10 08:44:33 --> Helper loaded: file_helper
INFO - 2016-02-10 08:44:33 --> Helper loaded: date_helper
INFO - 2016-02-10 08:44:33 --> Helper loaded: form_helper
INFO - 2016-02-10 08:44:33 --> Database Driver Class Initialized
INFO - 2016-02-10 08:44:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:44:34 --> Controller Class Initialized
INFO - 2016-02-10 08:44:34 --> Model Class Initialized
INFO - 2016-02-10 08:44:34 --> Model Class Initialized
INFO - 2016-02-10 08:44:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:44:34 --> Pagination Class Initialized
INFO - 2016-02-10 11:44:34 --> Form Validation Class Initialized
INFO - 2016-02-10 11:44:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:44:34 --> Final output sent to browser
DEBUG - 2016-02-10 11:44:34 --> Total execution time: 1.1159
INFO - 2016-02-10 08:44:36 --> Config Class Initialized
INFO - 2016-02-10 08:44:36 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:44:36 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:44:36 --> Utf8 Class Initialized
INFO - 2016-02-10 08:44:36 --> URI Class Initialized
INFO - 2016-02-10 08:44:36 --> Router Class Initialized
INFO - 2016-02-10 08:44:36 --> Output Class Initialized
INFO - 2016-02-10 08:44:36 --> Security Class Initialized
DEBUG - 2016-02-10 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:44:36 --> Input Class Initialized
INFO - 2016-02-10 08:44:36 --> Language Class Initialized
INFO - 2016-02-10 08:44:36 --> Loader Class Initialized
INFO - 2016-02-10 08:44:36 --> Helper loaded: url_helper
INFO - 2016-02-10 08:44:36 --> Helper loaded: file_helper
INFO - 2016-02-10 08:44:36 --> Helper loaded: date_helper
INFO - 2016-02-10 08:44:36 --> Helper loaded: form_helper
INFO - 2016-02-10 08:44:36 --> Database Driver Class Initialized
INFO - 2016-02-10 08:44:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:44:37 --> Controller Class Initialized
INFO - 2016-02-10 08:44:37 --> Model Class Initialized
INFO - 2016-02-10 08:44:37 --> Model Class Initialized
INFO - 2016-02-10 08:44:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:44:37 --> Pagination Class Initialized
INFO - 2016-02-10 11:44:37 --> Form Validation Class Initialized
INFO - 2016-02-10 11:44:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:44:37 --> Final output sent to browser
DEBUG - 2016-02-10 11:44:37 --> Total execution time: 1.1400
INFO - 2016-02-10 08:44:37 --> Config Class Initialized
INFO - 2016-02-10 08:44:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:44:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:44:37 --> Utf8 Class Initialized
INFO - 2016-02-10 08:44:37 --> URI Class Initialized
INFO - 2016-02-10 08:44:37 --> Router Class Initialized
INFO - 2016-02-10 08:44:37 --> Output Class Initialized
INFO - 2016-02-10 08:44:37 --> Security Class Initialized
DEBUG - 2016-02-10 08:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:44:37 --> Input Class Initialized
INFO - 2016-02-10 08:44:37 --> Language Class Initialized
INFO - 2016-02-10 08:44:37 --> Loader Class Initialized
INFO - 2016-02-10 08:44:37 --> Helper loaded: url_helper
INFO - 2016-02-10 08:44:37 --> Helper loaded: file_helper
INFO - 2016-02-10 08:44:37 --> Helper loaded: date_helper
INFO - 2016-02-10 08:44:37 --> Helper loaded: form_helper
INFO - 2016-02-10 08:44:37 --> Database Driver Class Initialized
INFO - 2016-02-10 08:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:44:38 --> Controller Class Initialized
INFO - 2016-02-10 08:44:39 --> Model Class Initialized
INFO - 2016-02-10 08:44:39 --> Model Class Initialized
INFO - 2016-02-10 08:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:44:39 --> Pagination Class Initialized
INFO - 2016-02-10 11:44:39 --> Form Validation Class Initialized
INFO - 2016-02-10 11:44:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:44:39 --> Final output sent to browser
DEBUG - 2016-02-10 11:44:39 --> Total execution time: 1.1352
INFO - 2016-02-10 08:44:39 --> Config Class Initialized
INFO - 2016-02-10 08:44:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:44:39 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:44:39 --> Utf8 Class Initialized
INFO - 2016-02-10 08:44:39 --> URI Class Initialized
INFO - 2016-02-10 08:44:39 --> Router Class Initialized
INFO - 2016-02-10 08:44:39 --> Output Class Initialized
INFO - 2016-02-10 08:44:39 --> Security Class Initialized
DEBUG - 2016-02-10 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:44:39 --> Input Class Initialized
INFO - 2016-02-10 08:44:39 --> Language Class Initialized
INFO - 2016-02-10 08:44:39 --> Loader Class Initialized
INFO - 2016-02-10 08:44:39 --> Helper loaded: url_helper
INFO - 2016-02-10 08:44:39 --> Helper loaded: file_helper
INFO - 2016-02-10 08:44:39 --> Helper loaded: date_helper
INFO - 2016-02-10 08:44:39 --> Helper loaded: form_helper
INFO - 2016-02-10 08:44:39 --> Database Driver Class Initialized
INFO - 2016-02-10 08:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:44:40 --> Controller Class Initialized
INFO - 2016-02-10 08:44:40 --> Model Class Initialized
INFO - 2016-02-10 08:44:40 --> Model Class Initialized
INFO - 2016-02-10 08:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:44:40 --> Pagination Class Initialized
INFO - 2016-02-10 11:44:40 --> Form Validation Class Initialized
INFO - 2016-02-10 11:44:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:44:40 --> Final output sent to browser
DEBUG - 2016-02-10 11:44:40 --> Total execution time: 1.1234
INFO - 2016-02-10 08:49:06 --> Config Class Initialized
INFO - 2016-02-10 08:49:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:49:06 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:49:06 --> Utf8 Class Initialized
INFO - 2016-02-10 08:49:06 --> URI Class Initialized
INFO - 2016-02-10 08:49:06 --> Router Class Initialized
INFO - 2016-02-10 08:49:06 --> Output Class Initialized
INFO - 2016-02-10 08:49:06 --> Security Class Initialized
DEBUG - 2016-02-10 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:49:06 --> Input Class Initialized
INFO - 2016-02-10 08:49:06 --> Language Class Initialized
INFO - 2016-02-10 08:49:06 --> Loader Class Initialized
INFO - 2016-02-10 08:49:06 --> Helper loaded: url_helper
INFO - 2016-02-10 08:49:06 --> Helper loaded: file_helper
INFO - 2016-02-10 08:49:06 --> Helper loaded: date_helper
INFO - 2016-02-10 08:49:06 --> Helper loaded: form_helper
INFO - 2016-02-10 08:49:06 --> Database Driver Class Initialized
INFO - 2016-02-10 08:49:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:49:07 --> Controller Class Initialized
INFO - 2016-02-10 08:49:07 --> Model Class Initialized
INFO - 2016-02-10 08:49:07 --> Model Class Initialized
INFO - 2016-02-10 08:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:49:07 --> Pagination Class Initialized
INFO - 2016-02-10 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:49:07 --> Helper loaded: text_helper
INFO - 2016-02-10 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:49:07 --> Final output sent to browser
DEBUG - 2016-02-10 11:49:07 --> Total execution time: 1.1922
INFO - 2016-02-10 08:49:11 --> Config Class Initialized
INFO - 2016-02-10 08:49:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:49:11 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:49:11 --> Utf8 Class Initialized
INFO - 2016-02-10 08:49:11 --> URI Class Initialized
INFO - 2016-02-10 08:49:11 --> Router Class Initialized
INFO - 2016-02-10 08:49:11 --> Output Class Initialized
INFO - 2016-02-10 08:49:11 --> Security Class Initialized
DEBUG - 2016-02-10 08:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:49:11 --> Input Class Initialized
INFO - 2016-02-10 08:49:11 --> Language Class Initialized
INFO - 2016-02-10 08:49:11 --> Loader Class Initialized
INFO - 2016-02-10 08:49:12 --> Helper loaded: url_helper
INFO - 2016-02-10 08:49:12 --> Helper loaded: file_helper
INFO - 2016-02-10 08:49:12 --> Helper loaded: date_helper
INFO - 2016-02-10 08:49:12 --> Helper loaded: form_helper
INFO - 2016-02-10 08:49:12 --> Database Driver Class Initialized
INFO - 2016-02-10 08:49:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:49:13 --> Controller Class Initialized
INFO - 2016-02-10 08:49:13 --> Model Class Initialized
INFO - 2016-02-10 08:49:13 --> Model Class Initialized
INFO - 2016-02-10 08:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:49:13 --> Pagination Class Initialized
INFO - 2016-02-10 11:49:13 --> Form Validation Class Initialized
INFO - 2016-02-10 11:49:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:49:13 --> Final output sent to browser
DEBUG - 2016-02-10 11:49:13 --> Total execution time: 1.1464
INFO - 2016-02-10 08:51:05 --> Config Class Initialized
INFO - 2016-02-10 08:51:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:51:05 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:51:05 --> Utf8 Class Initialized
INFO - 2016-02-10 08:51:05 --> URI Class Initialized
INFO - 2016-02-10 08:51:05 --> Router Class Initialized
INFO - 2016-02-10 08:51:05 --> Output Class Initialized
INFO - 2016-02-10 08:51:05 --> Security Class Initialized
DEBUG - 2016-02-10 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:51:05 --> Input Class Initialized
INFO - 2016-02-10 08:51:05 --> Language Class Initialized
INFO - 2016-02-10 08:51:05 --> Loader Class Initialized
INFO - 2016-02-10 08:51:05 --> Helper loaded: url_helper
INFO - 2016-02-10 08:51:05 --> Helper loaded: file_helper
INFO - 2016-02-10 08:51:05 --> Helper loaded: date_helper
INFO - 2016-02-10 08:51:05 --> Helper loaded: form_helper
INFO - 2016-02-10 08:51:05 --> Database Driver Class Initialized
INFO - 2016-02-10 08:51:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:51:06 --> Controller Class Initialized
INFO - 2016-02-10 08:51:06 --> Model Class Initialized
INFO - 2016-02-10 08:51:06 --> Model Class Initialized
INFO - 2016-02-10 08:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:51:06 --> Pagination Class Initialized
INFO - 2016-02-10 11:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:51:06 --> Helper loaded: text_helper
INFO - 2016-02-10 11:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:51:06 --> Final output sent to browser
DEBUG - 2016-02-10 11:51:06 --> Total execution time: 1.1665
INFO - 2016-02-10 08:51:08 --> Config Class Initialized
INFO - 2016-02-10 08:51:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:51:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:51:08 --> Utf8 Class Initialized
INFO - 2016-02-10 08:51:08 --> URI Class Initialized
INFO - 2016-02-10 08:51:08 --> Router Class Initialized
INFO - 2016-02-10 08:51:08 --> Output Class Initialized
INFO - 2016-02-10 08:51:08 --> Security Class Initialized
DEBUG - 2016-02-10 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:51:08 --> Input Class Initialized
INFO - 2016-02-10 08:51:08 --> Language Class Initialized
INFO - 2016-02-10 08:51:08 --> Loader Class Initialized
INFO - 2016-02-10 08:51:08 --> Helper loaded: url_helper
INFO - 2016-02-10 08:51:08 --> Helper loaded: file_helper
INFO - 2016-02-10 08:51:08 --> Helper loaded: date_helper
INFO - 2016-02-10 08:51:08 --> Helper loaded: form_helper
INFO - 2016-02-10 08:51:08 --> Database Driver Class Initialized
INFO - 2016-02-10 08:51:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:51:09 --> Controller Class Initialized
INFO - 2016-02-10 08:51:09 --> Model Class Initialized
INFO - 2016-02-10 08:51:09 --> Model Class Initialized
INFO - 2016-02-10 08:51:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:51:09 --> Pagination Class Initialized
INFO - 2016-02-10 11:51:09 --> Form Validation Class Initialized
INFO - 2016-02-10 11:51:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 11:51:09 --> Final output sent to browser
DEBUG - 2016-02-10 11:51:09 --> Total execution time: 1.0909
INFO - 2016-02-10 08:54:19 --> Config Class Initialized
INFO - 2016-02-10 08:54:19 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:54:19 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:54:19 --> Utf8 Class Initialized
INFO - 2016-02-10 08:54:19 --> URI Class Initialized
INFO - 2016-02-10 08:54:19 --> Router Class Initialized
INFO - 2016-02-10 08:54:19 --> Output Class Initialized
INFO - 2016-02-10 08:54:19 --> Security Class Initialized
DEBUG - 2016-02-10 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:54:19 --> Input Class Initialized
INFO - 2016-02-10 08:54:19 --> Language Class Initialized
INFO - 2016-02-10 08:54:19 --> Loader Class Initialized
INFO - 2016-02-10 08:54:19 --> Helper loaded: url_helper
INFO - 2016-02-10 08:54:19 --> Helper loaded: file_helper
INFO - 2016-02-10 08:54:19 --> Helper loaded: date_helper
INFO - 2016-02-10 08:54:19 --> Helper loaded: form_helper
INFO - 2016-02-10 08:54:19 --> Database Driver Class Initialized
INFO - 2016-02-10 08:54:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:54:20 --> Controller Class Initialized
INFO - 2016-02-10 08:54:20 --> Model Class Initialized
INFO - 2016-02-10 08:54:20 --> Model Class Initialized
INFO - 2016-02-10 08:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:54:20 --> Pagination Class Initialized
INFO - 2016-02-10 11:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:54:20 --> Helper loaded: text_helper
INFO - 2016-02-10 11:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:54:20 --> Final output sent to browser
DEBUG - 2016-02-10 11:54:20 --> Total execution time: 1.1543
INFO - 2016-02-10 08:56:54 --> Config Class Initialized
INFO - 2016-02-10 08:56:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 08:56:54 --> UTF-8 Support Enabled
INFO - 2016-02-10 08:56:54 --> Utf8 Class Initialized
INFO - 2016-02-10 08:56:54 --> URI Class Initialized
INFO - 2016-02-10 08:56:54 --> Router Class Initialized
INFO - 2016-02-10 08:56:54 --> Output Class Initialized
INFO - 2016-02-10 08:56:54 --> Security Class Initialized
DEBUG - 2016-02-10 08:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 08:56:54 --> Input Class Initialized
INFO - 2016-02-10 08:56:54 --> Language Class Initialized
INFO - 2016-02-10 08:56:54 --> Loader Class Initialized
INFO - 2016-02-10 08:56:54 --> Helper loaded: url_helper
INFO - 2016-02-10 08:56:54 --> Helper loaded: file_helper
INFO - 2016-02-10 08:56:54 --> Helper loaded: date_helper
INFO - 2016-02-10 08:56:54 --> Helper loaded: form_helper
INFO - 2016-02-10 08:56:54 --> Database Driver Class Initialized
INFO - 2016-02-10 08:56:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 08:56:55 --> Controller Class Initialized
INFO - 2016-02-10 08:56:55 --> Model Class Initialized
INFO - 2016-02-10 08:56:55 --> Model Class Initialized
INFO - 2016-02-10 08:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 08:56:55 --> Pagination Class Initialized
INFO - 2016-02-10 11:56:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 11:56:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 11:56:55 --> Helper loaded: text_helper
INFO - 2016-02-10 11:56:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 11:56:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 11:56:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 11:56:55 --> Final output sent to browser
DEBUG - 2016-02-10 11:56:55 --> Total execution time: 1.1547
INFO - 2016-02-10 09:00:01 --> Config Class Initialized
INFO - 2016-02-10 09:00:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:00:01 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:00:01 --> Utf8 Class Initialized
INFO - 2016-02-10 09:00:01 --> URI Class Initialized
INFO - 2016-02-10 09:00:01 --> Router Class Initialized
INFO - 2016-02-10 09:00:01 --> Output Class Initialized
INFO - 2016-02-10 09:00:01 --> Security Class Initialized
DEBUG - 2016-02-10 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:00:01 --> Input Class Initialized
INFO - 2016-02-10 09:00:01 --> Language Class Initialized
INFO - 2016-02-10 09:00:01 --> Loader Class Initialized
INFO - 2016-02-10 09:00:01 --> Helper loaded: url_helper
INFO - 2016-02-10 09:00:01 --> Helper loaded: file_helper
INFO - 2016-02-10 09:00:01 --> Helper loaded: date_helper
INFO - 2016-02-10 09:00:01 --> Helper loaded: form_helper
INFO - 2016-02-10 09:00:01 --> Database Driver Class Initialized
INFO - 2016-02-10 09:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:00:02 --> Controller Class Initialized
INFO - 2016-02-10 09:00:02 --> Model Class Initialized
INFO - 2016-02-10 09:00:02 --> Model Class Initialized
INFO - 2016-02-10 09:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:00:02 --> Pagination Class Initialized
INFO - 2016-02-10 12:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:00:02 --> Helper loaded: text_helper
INFO - 2016-02-10 12:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:00:02 --> Final output sent to browser
DEBUG - 2016-02-10 12:00:02 --> Total execution time: 1.1769
INFO - 2016-02-10 09:00:06 --> Config Class Initialized
INFO - 2016-02-10 09:00:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:00:06 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:00:06 --> Utf8 Class Initialized
INFO - 2016-02-10 09:00:06 --> URI Class Initialized
INFO - 2016-02-10 09:00:06 --> Router Class Initialized
INFO - 2016-02-10 09:00:06 --> Output Class Initialized
INFO - 2016-02-10 09:00:06 --> Security Class Initialized
DEBUG - 2016-02-10 09:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:00:06 --> Input Class Initialized
INFO - 2016-02-10 09:00:06 --> Language Class Initialized
INFO - 2016-02-10 09:00:06 --> Loader Class Initialized
INFO - 2016-02-10 09:00:06 --> Helper loaded: url_helper
INFO - 2016-02-10 09:00:06 --> Helper loaded: file_helper
INFO - 2016-02-10 09:00:06 --> Helper loaded: date_helper
INFO - 2016-02-10 09:00:06 --> Helper loaded: form_helper
INFO - 2016-02-10 09:00:06 --> Database Driver Class Initialized
INFO - 2016-02-10 09:00:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:00:07 --> Controller Class Initialized
INFO - 2016-02-10 09:00:07 --> Model Class Initialized
INFO - 2016-02-10 09:00:07 --> Model Class Initialized
INFO - 2016-02-10 09:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:00:07 --> Pagination Class Initialized
INFO - 2016-02-10 12:00:07 --> Form Validation Class Initialized
INFO - 2016-02-10 12:00:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 12:00:07 --> Final output sent to browser
DEBUG - 2016-02-10 12:00:07 --> Total execution time: 1.0958
INFO - 2016-02-10 09:02:32 --> Config Class Initialized
INFO - 2016-02-10 09:02:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:02:32 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:02:32 --> Utf8 Class Initialized
INFO - 2016-02-10 09:02:32 --> URI Class Initialized
INFO - 2016-02-10 09:02:32 --> Router Class Initialized
INFO - 2016-02-10 09:02:32 --> Output Class Initialized
INFO - 2016-02-10 09:02:32 --> Security Class Initialized
DEBUG - 2016-02-10 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:02:32 --> Input Class Initialized
INFO - 2016-02-10 09:02:32 --> Language Class Initialized
INFO - 2016-02-10 09:02:32 --> Loader Class Initialized
INFO - 2016-02-10 09:02:32 --> Helper loaded: url_helper
INFO - 2016-02-10 09:02:32 --> Helper loaded: file_helper
INFO - 2016-02-10 09:02:32 --> Helper loaded: date_helper
INFO - 2016-02-10 09:02:32 --> Helper loaded: form_helper
INFO - 2016-02-10 09:02:32 --> Database Driver Class Initialized
INFO - 2016-02-10 09:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:02:33 --> Controller Class Initialized
INFO - 2016-02-10 09:02:33 --> Model Class Initialized
INFO - 2016-02-10 09:02:33 --> Model Class Initialized
INFO - 2016-02-10 09:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:02:33 --> Pagination Class Initialized
INFO - 2016-02-10 12:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:02:33 --> Helper loaded: text_helper
INFO - 2016-02-10 12:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:02:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:02:33 --> Final output sent to browser
DEBUG - 2016-02-10 12:02:33 --> Total execution time: 1.1749
INFO - 2016-02-10 09:03:03 --> Config Class Initialized
INFO - 2016-02-10 09:03:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:03:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:03:03 --> Utf8 Class Initialized
INFO - 2016-02-10 09:03:03 --> URI Class Initialized
INFO - 2016-02-10 09:03:03 --> Router Class Initialized
INFO - 2016-02-10 09:03:03 --> Output Class Initialized
INFO - 2016-02-10 09:03:03 --> Security Class Initialized
DEBUG - 2016-02-10 09:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:03:03 --> Input Class Initialized
INFO - 2016-02-10 09:03:03 --> Language Class Initialized
INFO - 2016-02-10 09:03:03 --> Loader Class Initialized
INFO - 2016-02-10 09:03:03 --> Helper loaded: url_helper
INFO - 2016-02-10 09:03:03 --> Helper loaded: file_helper
INFO - 2016-02-10 09:03:03 --> Helper loaded: date_helper
INFO - 2016-02-10 09:03:03 --> Helper loaded: form_helper
INFO - 2016-02-10 09:03:03 --> Database Driver Class Initialized
INFO - 2016-02-10 09:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:03:04 --> Controller Class Initialized
INFO - 2016-02-10 09:03:04 --> Model Class Initialized
INFO - 2016-02-10 09:03:04 --> Model Class Initialized
INFO - 2016-02-10 09:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:03:04 --> Pagination Class Initialized
INFO - 2016-02-10 12:03:04 --> Form Validation Class Initialized
INFO - 2016-02-10 12:03:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 12:03:04 --> Model Class Initialized
INFO - 2016-02-10 12:03:04 --> Final output sent to browser
DEBUG - 2016-02-10 12:03:04 --> Total execution time: 1.1796
INFO - 2016-02-10 09:04:14 --> Config Class Initialized
INFO - 2016-02-10 09:04:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:04:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:04:14 --> Utf8 Class Initialized
INFO - 2016-02-10 09:04:14 --> URI Class Initialized
INFO - 2016-02-10 09:04:14 --> Router Class Initialized
INFO - 2016-02-10 09:04:14 --> Output Class Initialized
INFO - 2016-02-10 09:04:14 --> Security Class Initialized
DEBUG - 2016-02-10 09:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:04:14 --> Input Class Initialized
INFO - 2016-02-10 09:04:14 --> Language Class Initialized
INFO - 2016-02-10 09:04:14 --> Loader Class Initialized
INFO - 2016-02-10 09:04:14 --> Helper loaded: url_helper
INFO - 2016-02-10 09:04:14 --> Helper loaded: file_helper
INFO - 2016-02-10 09:04:14 --> Helper loaded: date_helper
INFO - 2016-02-10 09:04:14 --> Helper loaded: form_helper
INFO - 2016-02-10 09:04:14 --> Database Driver Class Initialized
INFO - 2016-02-10 09:04:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:04:15 --> Controller Class Initialized
INFO - 2016-02-10 09:04:15 --> Model Class Initialized
INFO - 2016-02-10 09:04:15 --> Model Class Initialized
INFO - 2016-02-10 09:04:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:04:15 --> Pagination Class Initialized
INFO - 2016-02-10 12:04:15 --> Form Validation Class Initialized
INFO - 2016-02-10 12:04:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 12:04:15 --> Model Class Initialized
INFO - 2016-02-10 12:04:16 --> Final output sent to browser
DEBUG - 2016-02-10 12:04:16 --> Total execution time: 1.1822
INFO - 2016-02-10 09:04:39 --> Config Class Initialized
INFO - 2016-02-10 09:04:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:04:39 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:04:39 --> Utf8 Class Initialized
INFO - 2016-02-10 09:04:39 --> URI Class Initialized
INFO - 2016-02-10 09:04:39 --> Router Class Initialized
INFO - 2016-02-10 09:04:39 --> Output Class Initialized
INFO - 2016-02-10 09:04:39 --> Security Class Initialized
DEBUG - 2016-02-10 09:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:04:39 --> Input Class Initialized
INFO - 2016-02-10 09:04:39 --> Language Class Initialized
INFO - 2016-02-10 09:04:39 --> Loader Class Initialized
INFO - 2016-02-10 09:04:39 --> Helper loaded: url_helper
INFO - 2016-02-10 09:04:39 --> Helper loaded: file_helper
INFO - 2016-02-10 09:04:39 --> Helper loaded: date_helper
INFO - 2016-02-10 09:04:39 --> Helper loaded: form_helper
INFO - 2016-02-10 09:04:39 --> Database Driver Class Initialized
INFO - 2016-02-10 09:04:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:04:40 --> Controller Class Initialized
INFO - 2016-02-10 09:04:40 --> Model Class Initialized
INFO - 2016-02-10 09:04:40 --> Model Class Initialized
INFO - 2016-02-10 09:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:04:40 --> Pagination Class Initialized
INFO - 2016-02-10 12:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:04:40 --> Helper loaded: text_helper
INFO - 2016-02-10 12:04:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:04:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:04:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:04:41 --> Final output sent to browser
DEBUG - 2016-02-10 12:04:41 --> Total execution time: 1.1622
INFO - 2016-02-10 09:05:14 --> Config Class Initialized
INFO - 2016-02-10 09:05:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:05:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:05:14 --> Utf8 Class Initialized
INFO - 2016-02-10 09:05:14 --> URI Class Initialized
INFO - 2016-02-10 09:05:14 --> Router Class Initialized
INFO - 2016-02-10 09:05:14 --> Output Class Initialized
INFO - 2016-02-10 09:05:14 --> Security Class Initialized
DEBUG - 2016-02-10 09:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:05:14 --> Input Class Initialized
INFO - 2016-02-10 09:05:14 --> Language Class Initialized
INFO - 2016-02-10 09:05:14 --> Loader Class Initialized
INFO - 2016-02-10 09:05:14 --> Helper loaded: url_helper
INFO - 2016-02-10 09:05:14 --> Helper loaded: file_helper
INFO - 2016-02-10 09:05:14 --> Helper loaded: date_helper
INFO - 2016-02-10 09:05:14 --> Helper loaded: form_helper
INFO - 2016-02-10 09:05:14 --> Database Driver Class Initialized
INFO - 2016-02-10 09:05:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:05:15 --> Controller Class Initialized
INFO - 2016-02-10 09:05:15 --> Model Class Initialized
INFO - 2016-02-10 09:05:15 --> Model Class Initialized
INFO - 2016-02-10 09:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:05:15 --> Pagination Class Initialized
INFO - 2016-02-10 12:05:15 --> Form Validation Class Initialized
INFO - 2016-02-10 12:05:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 12:05:15 --> Final output sent to browser
DEBUG - 2016-02-10 12:05:15 --> Total execution time: 1.1071
INFO - 2016-02-10 09:07:15 --> Config Class Initialized
INFO - 2016-02-10 09:07:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:07:15 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:07:15 --> Utf8 Class Initialized
INFO - 2016-02-10 09:07:15 --> URI Class Initialized
INFO - 2016-02-10 09:07:15 --> Router Class Initialized
INFO - 2016-02-10 09:07:15 --> Output Class Initialized
INFO - 2016-02-10 09:07:15 --> Security Class Initialized
DEBUG - 2016-02-10 09:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:07:15 --> Input Class Initialized
INFO - 2016-02-10 09:07:15 --> Language Class Initialized
INFO - 2016-02-10 09:07:15 --> Loader Class Initialized
INFO - 2016-02-10 09:07:15 --> Helper loaded: url_helper
INFO - 2016-02-10 09:07:15 --> Helper loaded: file_helper
INFO - 2016-02-10 09:07:15 --> Helper loaded: date_helper
INFO - 2016-02-10 09:07:15 --> Helper loaded: form_helper
INFO - 2016-02-10 09:07:15 --> Database Driver Class Initialized
INFO - 2016-02-10 09:07:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:07:16 --> Controller Class Initialized
INFO - 2016-02-10 09:07:16 --> Model Class Initialized
INFO - 2016-02-10 09:07:16 --> Model Class Initialized
INFO - 2016-02-10 09:07:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:07:16 --> Pagination Class Initialized
INFO - 2016-02-10 12:07:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:07:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:07:16 --> Helper loaded: text_helper
INFO - 2016-02-10 12:07:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:07:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:07:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:07:16 --> Final output sent to browser
DEBUG - 2016-02-10 12:07:16 --> Total execution time: 1.1420
INFO - 2016-02-10 09:08:21 --> Config Class Initialized
INFO - 2016-02-10 09:08:21 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:08:21 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:08:21 --> Utf8 Class Initialized
INFO - 2016-02-10 09:08:21 --> URI Class Initialized
INFO - 2016-02-10 09:08:21 --> Router Class Initialized
INFO - 2016-02-10 09:08:21 --> Output Class Initialized
INFO - 2016-02-10 09:08:21 --> Security Class Initialized
DEBUG - 2016-02-10 09:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:08:21 --> Input Class Initialized
INFO - 2016-02-10 09:08:21 --> Language Class Initialized
INFO - 2016-02-10 09:08:21 --> Loader Class Initialized
INFO - 2016-02-10 09:08:21 --> Helper loaded: url_helper
INFO - 2016-02-10 09:08:21 --> Helper loaded: file_helper
INFO - 2016-02-10 09:08:21 --> Helper loaded: date_helper
INFO - 2016-02-10 09:08:21 --> Helper loaded: form_helper
INFO - 2016-02-10 09:08:21 --> Database Driver Class Initialized
INFO - 2016-02-10 09:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:08:22 --> Controller Class Initialized
INFO - 2016-02-10 09:08:22 --> Model Class Initialized
INFO - 2016-02-10 09:08:22 --> Model Class Initialized
INFO - 2016-02-10 09:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:08:22 --> Pagination Class Initialized
INFO - 2016-02-10 12:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:08:22 --> Helper loaded: text_helper
INFO - 2016-02-10 12:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:08:22 --> Final output sent to browser
DEBUG - 2016-02-10 12:08:22 --> Total execution time: 1.1982
INFO - 2016-02-10 09:08:56 --> Config Class Initialized
INFO - 2016-02-10 09:08:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:08:56 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:08:56 --> Utf8 Class Initialized
INFO - 2016-02-10 09:08:56 --> URI Class Initialized
INFO - 2016-02-10 09:08:56 --> Router Class Initialized
INFO - 2016-02-10 09:08:56 --> Output Class Initialized
INFO - 2016-02-10 09:08:56 --> Security Class Initialized
DEBUG - 2016-02-10 09:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:08:56 --> Input Class Initialized
INFO - 2016-02-10 09:08:56 --> Language Class Initialized
INFO - 2016-02-10 09:08:56 --> Loader Class Initialized
INFO - 2016-02-10 09:08:56 --> Helper loaded: url_helper
INFO - 2016-02-10 09:08:56 --> Helper loaded: file_helper
INFO - 2016-02-10 09:08:56 --> Helper loaded: date_helper
INFO - 2016-02-10 09:08:56 --> Helper loaded: form_helper
INFO - 2016-02-10 09:08:56 --> Database Driver Class Initialized
INFO - 2016-02-10 09:08:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:08:57 --> Controller Class Initialized
INFO - 2016-02-10 09:08:57 --> Model Class Initialized
INFO - 2016-02-10 09:08:57 --> Model Class Initialized
INFO - 2016-02-10 09:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:08:57 --> Pagination Class Initialized
INFO - 2016-02-10 12:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:08:57 --> Helper loaded: text_helper
INFO - 2016-02-10 12:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:08:58 --> Final output sent to browser
DEBUG - 2016-02-10 12:08:58 --> Total execution time: 1.1565
INFO - 2016-02-10 09:09:32 --> Config Class Initialized
INFO - 2016-02-10 09:09:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:09:32 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:09:32 --> Utf8 Class Initialized
INFO - 2016-02-10 09:09:32 --> URI Class Initialized
INFO - 2016-02-10 09:09:32 --> Router Class Initialized
INFO - 2016-02-10 09:09:32 --> Output Class Initialized
INFO - 2016-02-10 09:09:32 --> Security Class Initialized
DEBUG - 2016-02-10 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:09:32 --> Input Class Initialized
INFO - 2016-02-10 09:09:32 --> Language Class Initialized
INFO - 2016-02-10 09:09:32 --> Loader Class Initialized
INFO - 2016-02-10 09:09:32 --> Helper loaded: url_helper
INFO - 2016-02-10 09:09:32 --> Helper loaded: file_helper
INFO - 2016-02-10 09:09:32 --> Helper loaded: date_helper
INFO - 2016-02-10 09:09:32 --> Helper loaded: form_helper
INFO - 2016-02-10 09:09:32 --> Database Driver Class Initialized
INFO - 2016-02-10 09:09:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:09:33 --> Controller Class Initialized
INFO - 2016-02-10 09:09:33 --> Model Class Initialized
INFO - 2016-02-10 09:09:33 --> Model Class Initialized
INFO - 2016-02-10 09:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:09:33 --> Pagination Class Initialized
INFO - 2016-02-10 12:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:09:33 --> Helper loaded: text_helper
INFO - 2016-02-10 12:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:09:33 --> Final output sent to browser
DEBUG - 2016-02-10 12:09:33 --> Total execution time: 1.1547
INFO - 2016-02-10 09:10:05 --> Config Class Initialized
INFO - 2016-02-10 09:10:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:10:05 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:10:05 --> Utf8 Class Initialized
INFO - 2016-02-10 09:10:05 --> URI Class Initialized
INFO - 2016-02-10 09:10:05 --> Router Class Initialized
INFO - 2016-02-10 09:10:05 --> Output Class Initialized
INFO - 2016-02-10 09:10:05 --> Security Class Initialized
DEBUG - 2016-02-10 09:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:10:05 --> Input Class Initialized
INFO - 2016-02-10 09:10:05 --> Language Class Initialized
INFO - 2016-02-10 09:10:05 --> Loader Class Initialized
INFO - 2016-02-10 09:10:05 --> Helper loaded: url_helper
INFO - 2016-02-10 09:10:05 --> Helper loaded: file_helper
INFO - 2016-02-10 09:10:05 --> Helper loaded: date_helper
INFO - 2016-02-10 09:10:05 --> Helper loaded: form_helper
INFO - 2016-02-10 09:10:05 --> Database Driver Class Initialized
INFO - 2016-02-10 09:10:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:10:06 --> Controller Class Initialized
INFO - 2016-02-10 09:10:06 --> Model Class Initialized
INFO - 2016-02-10 09:10:06 --> Model Class Initialized
INFO - 2016-02-10 09:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:10:06 --> Pagination Class Initialized
INFO - 2016-02-10 12:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:10:06 --> Helper loaded: text_helper
INFO - 2016-02-10 12:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:10:07 --> Final output sent to browser
DEBUG - 2016-02-10 12:10:07 --> Total execution time: 1.1901
INFO - 2016-02-10 09:10:22 --> Config Class Initialized
INFO - 2016-02-10 09:10:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:10:22 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:10:22 --> Utf8 Class Initialized
INFO - 2016-02-10 09:10:22 --> URI Class Initialized
INFO - 2016-02-10 09:10:22 --> Router Class Initialized
INFO - 2016-02-10 09:10:22 --> Output Class Initialized
INFO - 2016-02-10 09:10:22 --> Security Class Initialized
DEBUG - 2016-02-10 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:10:22 --> Input Class Initialized
INFO - 2016-02-10 09:10:22 --> Language Class Initialized
INFO - 2016-02-10 09:10:22 --> Loader Class Initialized
INFO - 2016-02-10 09:10:22 --> Helper loaded: url_helper
INFO - 2016-02-10 09:10:22 --> Helper loaded: file_helper
INFO - 2016-02-10 09:10:22 --> Helper loaded: date_helper
INFO - 2016-02-10 09:10:22 --> Helper loaded: form_helper
INFO - 2016-02-10 09:10:22 --> Database Driver Class Initialized
INFO - 2016-02-10 09:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:10:23 --> Controller Class Initialized
INFO - 2016-02-10 09:10:23 --> Model Class Initialized
INFO - 2016-02-10 09:10:23 --> Model Class Initialized
INFO - 2016-02-10 09:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:10:23 --> Pagination Class Initialized
INFO - 2016-02-10 12:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:10:23 --> Helper loaded: text_helper
INFO - 2016-02-10 12:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:10:23 --> Final output sent to browser
DEBUG - 2016-02-10 12:10:23 --> Total execution time: 1.1622
INFO - 2016-02-10 09:10:35 --> Config Class Initialized
INFO - 2016-02-10 09:10:35 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:10:35 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:10:35 --> Utf8 Class Initialized
INFO - 2016-02-10 09:10:35 --> URI Class Initialized
INFO - 2016-02-10 09:10:35 --> Router Class Initialized
INFO - 2016-02-10 09:10:35 --> Output Class Initialized
INFO - 2016-02-10 09:10:35 --> Security Class Initialized
DEBUG - 2016-02-10 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:10:35 --> Input Class Initialized
INFO - 2016-02-10 09:10:35 --> Language Class Initialized
INFO - 2016-02-10 09:10:35 --> Loader Class Initialized
INFO - 2016-02-10 09:10:35 --> Helper loaded: url_helper
INFO - 2016-02-10 09:10:35 --> Helper loaded: file_helper
INFO - 2016-02-10 09:10:35 --> Helper loaded: date_helper
INFO - 2016-02-10 09:10:35 --> Helper loaded: form_helper
INFO - 2016-02-10 09:10:35 --> Database Driver Class Initialized
INFO - 2016-02-10 09:10:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:10:36 --> Controller Class Initialized
INFO - 2016-02-10 09:10:36 --> Model Class Initialized
INFO - 2016-02-10 09:10:36 --> Model Class Initialized
INFO - 2016-02-10 09:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:10:36 --> Pagination Class Initialized
INFO - 2016-02-10 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:10:36 --> Helper loaded: text_helper
INFO - 2016-02-10 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:10:36 --> Final output sent to browser
DEBUG - 2016-02-10 12:10:36 --> Total execution time: 1.1440
INFO - 2016-02-10 09:10:43 --> Config Class Initialized
INFO - 2016-02-10 09:10:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:10:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:10:43 --> Utf8 Class Initialized
INFO - 2016-02-10 09:10:43 --> URI Class Initialized
INFO - 2016-02-10 09:10:43 --> Router Class Initialized
INFO - 2016-02-10 09:10:43 --> Output Class Initialized
INFO - 2016-02-10 09:10:43 --> Security Class Initialized
DEBUG - 2016-02-10 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:10:43 --> Input Class Initialized
INFO - 2016-02-10 09:10:43 --> Language Class Initialized
INFO - 2016-02-10 09:10:43 --> Loader Class Initialized
INFO - 2016-02-10 09:10:43 --> Helper loaded: url_helper
INFO - 2016-02-10 09:10:43 --> Helper loaded: file_helper
INFO - 2016-02-10 09:10:43 --> Helper loaded: date_helper
INFO - 2016-02-10 09:10:43 --> Helper loaded: form_helper
INFO - 2016-02-10 09:10:43 --> Database Driver Class Initialized
INFO - 2016-02-10 09:10:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:10:44 --> Controller Class Initialized
INFO - 2016-02-10 09:10:44 --> Model Class Initialized
INFO - 2016-02-10 09:10:44 --> Model Class Initialized
INFO - 2016-02-10 09:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:10:44 --> Pagination Class Initialized
INFO - 2016-02-10 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:10:44 --> Helper loaded: text_helper
INFO - 2016-02-10 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:10:44 --> Final output sent to browser
DEBUG - 2016-02-10 12:10:44 --> Total execution time: 1.1778
INFO - 2016-02-10 09:10:53 --> Config Class Initialized
INFO - 2016-02-10 09:10:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:10:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:10:53 --> Utf8 Class Initialized
INFO - 2016-02-10 09:10:53 --> URI Class Initialized
INFO - 2016-02-10 09:10:53 --> Router Class Initialized
INFO - 2016-02-10 09:10:53 --> Output Class Initialized
INFO - 2016-02-10 09:10:53 --> Security Class Initialized
DEBUG - 2016-02-10 09:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:10:53 --> Input Class Initialized
INFO - 2016-02-10 09:10:53 --> Language Class Initialized
INFO - 2016-02-10 09:10:53 --> Loader Class Initialized
INFO - 2016-02-10 09:10:53 --> Helper loaded: url_helper
INFO - 2016-02-10 09:10:53 --> Helper loaded: file_helper
INFO - 2016-02-10 09:10:53 --> Helper loaded: date_helper
INFO - 2016-02-10 09:10:53 --> Helper loaded: form_helper
INFO - 2016-02-10 09:10:53 --> Database Driver Class Initialized
INFO - 2016-02-10 09:10:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:10:54 --> Controller Class Initialized
INFO - 2016-02-10 09:10:54 --> Model Class Initialized
INFO - 2016-02-10 09:10:54 --> Model Class Initialized
INFO - 2016-02-10 09:10:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:10:54 --> Pagination Class Initialized
INFO - 2016-02-10 12:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:10:54 --> Helper loaded: text_helper
INFO - 2016-02-10 12:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:10:54 --> Final output sent to browser
DEBUG - 2016-02-10 12:10:54 --> Total execution time: 1.2768
INFO - 2016-02-10 09:11:17 --> Config Class Initialized
INFO - 2016-02-10 09:11:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:11:17 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:11:17 --> Utf8 Class Initialized
INFO - 2016-02-10 09:11:17 --> URI Class Initialized
INFO - 2016-02-10 09:11:17 --> Router Class Initialized
INFO - 2016-02-10 09:11:17 --> Output Class Initialized
INFO - 2016-02-10 09:11:17 --> Security Class Initialized
DEBUG - 2016-02-10 09:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:11:17 --> Input Class Initialized
INFO - 2016-02-10 09:11:17 --> Language Class Initialized
INFO - 2016-02-10 09:11:17 --> Loader Class Initialized
INFO - 2016-02-10 09:11:17 --> Helper loaded: url_helper
INFO - 2016-02-10 09:11:17 --> Helper loaded: file_helper
INFO - 2016-02-10 09:11:17 --> Helper loaded: date_helper
INFO - 2016-02-10 09:11:17 --> Helper loaded: form_helper
INFO - 2016-02-10 09:11:17 --> Database Driver Class Initialized
INFO - 2016-02-10 09:11:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:11:18 --> Controller Class Initialized
INFO - 2016-02-10 09:11:18 --> Model Class Initialized
INFO - 2016-02-10 09:11:18 --> Model Class Initialized
INFO - 2016-02-10 09:11:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:11:18 --> Pagination Class Initialized
INFO - 2016-02-10 12:11:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:11:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:11:18 --> Helper loaded: text_helper
INFO - 2016-02-10 12:11:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:11:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:11:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:11:18 --> Final output sent to browser
DEBUG - 2016-02-10 12:11:18 --> Total execution time: 1.1647
INFO - 2016-02-10 09:11:27 --> Config Class Initialized
INFO - 2016-02-10 09:11:27 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:11:27 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:11:27 --> Utf8 Class Initialized
INFO - 2016-02-10 09:11:27 --> URI Class Initialized
INFO - 2016-02-10 09:11:27 --> Router Class Initialized
INFO - 2016-02-10 09:11:27 --> Output Class Initialized
INFO - 2016-02-10 09:11:27 --> Security Class Initialized
DEBUG - 2016-02-10 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:11:27 --> Input Class Initialized
INFO - 2016-02-10 09:11:27 --> Language Class Initialized
INFO - 2016-02-10 09:11:27 --> Loader Class Initialized
INFO - 2016-02-10 09:11:27 --> Helper loaded: url_helper
INFO - 2016-02-10 09:11:27 --> Helper loaded: file_helper
INFO - 2016-02-10 09:11:27 --> Helper loaded: date_helper
INFO - 2016-02-10 09:11:27 --> Helper loaded: form_helper
INFO - 2016-02-10 09:11:27 --> Database Driver Class Initialized
INFO - 2016-02-10 09:11:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:11:28 --> Controller Class Initialized
INFO - 2016-02-10 09:11:28 --> Model Class Initialized
INFO - 2016-02-10 09:11:28 --> Model Class Initialized
INFO - 2016-02-10 09:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:11:28 --> Pagination Class Initialized
INFO - 2016-02-10 12:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:11:28 --> Helper loaded: text_helper
INFO - 2016-02-10 12:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:11:28 --> Final output sent to browser
DEBUG - 2016-02-10 12:11:28 --> Total execution time: 1.1338
INFO - 2016-02-10 09:16:12 --> Config Class Initialized
INFO - 2016-02-10 09:16:12 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:16:12 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:16:13 --> Utf8 Class Initialized
INFO - 2016-02-10 09:16:13 --> URI Class Initialized
INFO - 2016-02-10 09:16:13 --> Router Class Initialized
INFO - 2016-02-10 09:16:13 --> Output Class Initialized
INFO - 2016-02-10 09:16:13 --> Security Class Initialized
DEBUG - 2016-02-10 09:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:16:13 --> Input Class Initialized
INFO - 2016-02-10 09:16:13 --> Language Class Initialized
INFO - 2016-02-10 09:16:13 --> Loader Class Initialized
INFO - 2016-02-10 09:16:13 --> Helper loaded: url_helper
INFO - 2016-02-10 09:16:13 --> Helper loaded: file_helper
INFO - 2016-02-10 09:16:13 --> Helper loaded: date_helper
INFO - 2016-02-10 09:16:13 --> Helper loaded: form_helper
INFO - 2016-02-10 09:16:13 --> Database Driver Class Initialized
INFO - 2016-02-10 09:16:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:16:14 --> Controller Class Initialized
INFO - 2016-02-10 09:16:14 --> Model Class Initialized
INFO - 2016-02-10 09:16:14 --> Model Class Initialized
INFO - 2016-02-10 09:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:16:14 --> Pagination Class Initialized
INFO - 2016-02-10 12:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:16:14 --> Helper loaded: text_helper
INFO - 2016-02-10 12:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:16:14 --> Final output sent to browser
DEBUG - 2016-02-10 12:16:14 --> Total execution time: 1.1637
INFO - 2016-02-10 09:16:43 --> Config Class Initialized
INFO - 2016-02-10 09:16:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:16:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:16:43 --> Utf8 Class Initialized
INFO - 2016-02-10 09:16:43 --> URI Class Initialized
INFO - 2016-02-10 09:16:43 --> Router Class Initialized
INFO - 2016-02-10 09:16:43 --> Output Class Initialized
INFO - 2016-02-10 09:16:43 --> Security Class Initialized
DEBUG - 2016-02-10 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:16:43 --> Input Class Initialized
INFO - 2016-02-10 09:16:43 --> Language Class Initialized
INFO - 2016-02-10 09:16:43 --> Loader Class Initialized
INFO - 2016-02-10 09:16:43 --> Helper loaded: url_helper
INFO - 2016-02-10 09:16:43 --> Helper loaded: file_helper
INFO - 2016-02-10 09:16:43 --> Helper loaded: date_helper
INFO - 2016-02-10 09:16:43 --> Helper loaded: form_helper
INFO - 2016-02-10 09:16:43 --> Database Driver Class Initialized
INFO - 2016-02-10 09:16:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:16:44 --> Controller Class Initialized
INFO - 2016-02-10 09:16:44 --> Model Class Initialized
INFO - 2016-02-10 09:16:44 --> Model Class Initialized
INFO - 2016-02-10 09:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:16:44 --> Pagination Class Initialized
INFO - 2016-02-10 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:16:44 --> Helper loaded: text_helper
INFO - 2016-02-10 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:16:44 --> Final output sent to browser
DEBUG - 2016-02-10 12:16:44 --> Total execution time: 1.1552
INFO - 2016-02-10 09:19:29 --> Config Class Initialized
INFO - 2016-02-10 09:19:29 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:19:29 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:19:29 --> Utf8 Class Initialized
INFO - 2016-02-10 09:19:29 --> URI Class Initialized
DEBUG - 2016-02-10 09:19:29 --> No URI present. Default controller set.
INFO - 2016-02-10 09:19:29 --> Router Class Initialized
INFO - 2016-02-10 09:19:29 --> Output Class Initialized
INFO - 2016-02-10 09:19:29 --> Security Class Initialized
DEBUG - 2016-02-10 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:19:29 --> Input Class Initialized
INFO - 2016-02-10 09:19:29 --> Language Class Initialized
INFO - 2016-02-10 09:19:29 --> Loader Class Initialized
INFO - 2016-02-10 09:19:29 --> Helper loaded: url_helper
INFO - 2016-02-10 09:19:29 --> Helper loaded: file_helper
INFO - 2016-02-10 09:19:29 --> Helper loaded: date_helper
INFO - 2016-02-10 09:19:29 --> Helper loaded: form_helper
INFO - 2016-02-10 09:19:29 --> Database Driver Class Initialized
INFO - 2016-02-10 09:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:19:30 --> Controller Class Initialized
INFO - 2016-02-10 09:19:30 --> Model Class Initialized
INFO - 2016-02-10 09:19:30 --> Model Class Initialized
INFO - 2016-02-10 09:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:19:30 --> Pagination Class Initialized
INFO - 2016-02-10 12:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 12:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:19:30 --> Final output sent to browser
DEBUG - 2016-02-10 12:19:30 --> Total execution time: 1.1028
INFO - 2016-02-10 09:19:41 --> Config Class Initialized
INFO - 2016-02-10 09:19:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:19:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:19:41 --> Utf8 Class Initialized
INFO - 2016-02-10 09:19:41 --> URI Class Initialized
INFO - 2016-02-10 09:19:41 --> Router Class Initialized
INFO - 2016-02-10 09:19:41 --> Output Class Initialized
INFO - 2016-02-10 09:19:41 --> Security Class Initialized
DEBUG - 2016-02-10 09:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:19:41 --> Input Class Initialized
INFO - 2016-02-10 09:19:41 --> Language Class Initialized
INFO - 2016-02-10 09:19:41 --> Loader Class Initialized
INFO - 2016-02-10 09:19:41 --> Helper loaded: url_helper
INFO - 2016-02-10 09:19:41 --> Helper loaded: file_helper
INFO - 2016-02-10 09:19:41 --> Helper loaded: date_helper
INFO - 2016-02-10 09:19:41 --> Helper loaded: form_helper
INFO - 2016-02-10 09:19:41 --> Database Driver Class Initialized
INFO - 2016-02-10 09:19:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:19:42 --> Controller Class Initialized
INFO - 2016-02-10 09:19:42 --> Model Class Initialized
INFO - 2016-02-10 09:19:42 --> Model Class Initialized
INFO - 2016-02-10 09:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:19:42 --> Pagination Class Initialized
INFO - 2016-02-10 12:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:19:42 --> Helper loaded: text_helper
INFO - 2016-02-10 12:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:19:42 --> Final output sent to browser
DEBUG - 2016-02-10 12:19:42 --> Total execution time: 1.1709
INFO - 2016-02-10 09:20:37 --> Config Class Initialized
INFO - 2016-02-10 09:20:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:20:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:20:37 --> Utf8 Class Initialized
INFO - 2016-02-10 09:20:37 --> URI Class Initialized
DEBUG - 2016-02-10 09:20:37 --> No URI present. Default controller set.
INFO - 2016-02-10 09:20:37 --> Router Class Initialized
INFO - 2016-02-10 09:20:37 --> Output Class Initialized
INFO - 2016-02-10 09:20:37 --> Security Class Initialized
DEBUG - 2016-02-10 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:20:37 --> Input Class Initialized
INFO - 2016-02-10 09:20:37 --> Language Class Initialized
INFO - 2016-02-10 09:20:37 --> Loader Class Initialized
INFO - 2016-02-10 09:20:37 --> Helper loaded: url_helper
INFO - 2016-02-10 09:20:37 --> Helper loaded: file_helper
INFO - 2016-02-10 09:20:37 --> Helper loaded: date_helper
INFO - 2016-02-10 09:20:37 --> Helper loaded: form_helper
INFO - 2016-02-10 09:20:37 --> Database Driver Class Initialized
INFO - 2016-02-10 09:20:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:20:38 --> Controller Class Initialized
INFO - 2016-02-10 09:20:38 --> Model Class Initialized
INFO - 2016-02-10 09:20:38 --> Model Class Initialized
INFO - 2016-02-10 09:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:20:38 --> Pagination Class Initialized
INFO - 2016-02-10 12:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 12:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:20:38 --> Final output sent to browser
DEBUG - 2016-02-10 12:20:38 --> Total execution time: 1.1042
INFO - 2016-02-10 09:47:01 --> Config Class Initialized
INFO - 2016-02-10 09:47:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 09:47:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 09:47:02 --> Utf8 Class Initialized
INFO - 2016-02-10 09:47:02 --> URI Class Initialized
INFO - 2016-02-10 09:47:02 --> Router Class Initialized
INFO - 2016-02-10 09:47:02 --> Output Class Initialized
INFO - 2016-02-10 09:47:02 --> Security Class Initialized
DEBUG - 2016-02-10 09:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 09:47:02 --> Input Class Initialized
INFO - 2016-02-10 09:47:02 --> Language Class Initialized
INFO - 2016-02-10 09:47:02 --> Loader Class Initialized
INFO - 2016-02-10 09:47:02 --> Helper loaded: url_helper
INFO - 2016-02-10 09:47:02 --> Helper loaded: file_helper
INFO - 2016-02-10 09:47:02 --> Helper loaded: date_helper
INFO - 2016-02-10 09:47:02 --> Helper loaded: form_helper
INFO - 2016-02-10 09:47:02 --> Database Driver Class Initialized
INFO - 2016-02-10 09:47:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 09:47:03 --> Controller Class Initialized
INFO - 2016-02-10 09:47:03 --> Model Class Initialized
INFO - 2016-02-10 09:47:03 --> Model Class Initialized
INFO - 2016-02-10 09:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 09:47:03 --> Pagination Class Initialized
INFO - 2016-02-10 12:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 12:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 12:47:03 --> Helper loaded: text_helper
INFO - 2016-02-10 12:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 12:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 12:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 12:47:03 --> Final output sent to browser
DEBUG - 2016-02-10 12:47:03 --> Total execution time: 1.6790
INFO - 2016-02-10 11:26:13 --> Config Class Initialized
INFO - 2016-02-10 11:26:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 11:26:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 11:26:14 --> Utf8 Class Initialized
INFO - 2016-02-10 11:26:14 --> URI Class Initialized
INFO - 2016-02-10 11:26:14 --> Router Class Initialized
INFO - 2016-02-10 11:26:14 --> Output Class Initialized
INFO - 2016-02-10 11:26:14 --> Security Class Initialized
DEBUG - 2016-02-10 11:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 11:26:14 --> Input Class Initialized
INFO - 2016-02-10 11:26:14 --> Language Class Initialized
INFO - 2016-02-10 11:26:14 --> Loader Class Initialized
INFO - 2016-02-10 11:26:14 --> Helper loaded: url_helper
INFO - 2016-02-10 11:26:14 --> Helper loaded: file_helper
INFO - 2016-02-10 11:26:14 --> Helper loaded: date_helper
INFO - 2016-02-10 11:26:14 --> Helper loaded: form_helper
INFO - 2016-02-10 11:26:14 --> Database Driver Class Initialized
INFO - 2016-02-10 11:26:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 11:26:15 --> Controller Class Initialized
INFO - 2016-02-10 11:26:15 --> Model Class Initialized
INFO - 2016-02-10 11:26:15 --> Model Class Initialized
INFO - 2016-02-10 11:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 11:26:15 --> Pagination Class Initialized
INFO - 2016-02-10 14:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 14:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 14:26:15 --> Helper loaded: text_helper
INFO - 2016-02-10 14:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 14:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 14:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 14:26:15 --> Final output sent to browser
DEBUG - 2016-02-10 14:26:15 --> Total execution time: 1.8733
INFO - 2016-02-10 11:26:23 --> Config Class Initialized
INFO - 2016-02-10 11:26:23 --> Hooks Class Initialized
DEBUG - 2016-02-10 11:26:23 --> UTF-8 Support Enabled
INFO - 2016-02-10 11:26:23 --> Utf8 Class Initialized
INFO - 2016-02-10 11:26:23 --> URI Class Initialized
INFO - 2016-02-10 11:26:23 --> Router Class Initialized
INFO - 2016-02-10 11:26:23 --> Output Class Initialized
INFO - 2016-02-10 11:26:23 --> Security Class Initialized
DEBUG - 2016-02-10 11:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 11:26:23 --> Input Class Initialized
INFO - 2016-02-10 11:26:23 --> Language Class Initialized
INFO - 2016-02-10 11:26:23 --> Loader Class Initialized
INFO - 2016-02-10 11:26:23 --> Helper loaded: url_helper
INFO - 2016-02-10 11:26:23 --> Helper loaded: file_helper
INFO - 2016-02-10 11:26:23 --> Helper loaded: date_helper
INFO - 2016-02-10 11:26:23 --> Helper loaded: form_helper
INFO - 2016-02-10 11:26:23 --> Database Driver Class Initialized
INFO - 2016-02-10 11:26:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 11:26:24 --> Controller Class Initialized
INFO - 2016-02-10 11:26:24 --> Model Class Initialized
INFO - 2016-02-10 11:26:24 --> Model Class Initialized
INFO - 2016-02-10 11:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 11:26:24 --> Pagination Class Initialized
INFO - 2016-02-10 14:26:24 --> Form Validation Class Initialized
INFO - 2016-02-10 14:26:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 14:26:24 --> Model Class Initialized
INFO - 2016-02-10 14:26:25 --> Final output sent to browser
DEBUG - 2016-02-10 14:26:25 --> Total execution time: 1.2396
INFO - 2016-02-10 12:12:24 --> Config Class Initialized
INFO - 2016-02-10 12:12:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:12:24 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:12:24 --> Utf8 Class Initialized
INFO - 2016-02-10 12:12:24 --> URI Class Initialized
INFO - 2016-02-10 12:12:24 --> Router Class Initialized
INFO - 2016-02-10 12:12:24 --> Output Class Initialized
INFO - 2016-02-10 12:12:24 --> Security Class Initialized
DEBUG - 2016-02-10 12:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:12:24 --> Input Class Initialized
INFO - 2016-02-10 12:12:24 --> Language Class Initialized
INFO - 2016-02-10 12:12:24 --> Loader Class Initialized
INFO - 2016-02-10 12:12:24 --> Helper loaded: url_helper
INFO - 2016-02-10 12:12:24 --> Helper loaded: file_helper
INFO - 2016-02-10 12:12:24 --> Helper loaded: date_helper
INFO - 2016-02-10 12:12:24 --> Helper loaded: form_helper
INFO - 2016-02-10 12:12:24 --> Database Driver Class Initialized
INFO - 2016-02-10 12:12:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:12:25 --> Controller Class Initialized
INFO - 2016-02-10 12:12:25 --> Model Class Initialized
INFO - 2016-02-10 12:12:25 --> Model Class Initialized
INFO - 2016-02-10 12:12:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:12:25 --> Pagination Class Initialized
INFO - 2016-02-10 15:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:12:25 --> Helper loaded: text_helper
INFO - 2016-02-10 15:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:12:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:12:25 --> Final output sent to browser
DEBUG - 2016-02-10 15:12:25 --> Total execution time: 1.1764
INFO - 2016-02-10 12:12:32 --> Config Class Initialized
INFO - 2016-02-10 12:12:32 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:12:32 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:12:32 --> Utf8 Class Initialized
INFO - 2016-02-10 12:12:32 --> URI Class Initialized
INFO - 2016-02-10 12:12:32 --> Router Class Initialized
INFO - 2016-02-10 12:12:32 --> Output Class Initialized
INFO - 2016-02-10 12:12:32 --> Security Class Initialized
DEBUG - 2016-02-10 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:12:32 --> Input Class Initialized
INFO - 2016-02-10 12:12:32 --> Language Class Initialized
INFO - 2016-02-10 12:12:32 --> Loader Class Initialized
INFO - 2016-02-10 12:12:32 --> Helper loaded: url_helper
INFO - 2016-02-10 12:12:32 --> Helper loaded: file_helper
INFO - 2016-02-10 12:12:32 --> Helper loaded: date_helper
INFO - 2016-02-10 12:12:32 --> Helper loaded: form_helper
INFO - 2016-02-10 12:12:32 --> Database Driver Class Initialized
INFO - 2016-02-10 12:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:12:33 --> Controller Class Initialized
INFO - 2016-02-10 12:12:33 --> Model Class Initialized
INFO - 2016-02-10 12:12:33 --> Model Class Initialized
INFO - 2016-02-10 12:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:12:33 --> Pagination Class Initialized
INFO - 2016-02-10 15:12:33 --> Final output sent to browser
DEBUG - 2016-02-10 15:12:33 --> Total execution time: 1.1219
INFO - 2016-02-10 12:13:12 --> Config Class Initialized
INFO - 2016-02-10 12:13:12 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:13:12 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:13:12 --> Utf8 Class Initialized
INFO - 2016-02-10 12:13:12 --> URI Class Initialized
INFO - 2016-02-10 12:13:12 --> Router Class Initialized
INFO - 2016-02-10 12:13:12 --> Output Class Initialized
INFO - 2016-02-10 12:13:12 --> Security Class Initialized
DEBUG - 2016-02-10 12:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:13:12 --> Input Class Initialized
INFO - 2016-02-10 12:13:12 --> Language Class Initialized
INFO - 2016-02-10 12:13:12 --> Loader Class Initialized
INFO - 2016-02-10 12:13:12 --> Helper loaded: url_helper
INFO - 2016-02-10 12:13:12 --> Helper loaded: file_helper
INFO - 2016-02-10 12:13:12 --> Helper loaded: date_helper
INFO - 2016-02-10 12:13:12 --> Helper loaded: form_helper
INFO - 2016-02-10 12:13:12 --> Database Driver Class Initialized
INFO - 2016-02-10 12:13:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:13:13 --> Controller Class Initialized
INFO - 2016-02-10 12:13:13 --> Model Class Initialized
INFO - 2016-02-10 12:13:13 --> Model Class Initialized
INFO - 2016-02-10 12:13:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:13:13 --> Pagination Class Initialized
INFO - 2016-02-10 15:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:13:13 --> Helper loaded: text_helper
INFO - 2016-02-10 15:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:13:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:13:13 --> Final output sent to browser
DEBUG - 2016-02-10 15:13:13 --> Total execution time: 1.1833
INFO - 2016-02-10 12:13:28 --> Config Class Initialized
INFO - 2016-02-10 12:13:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:13:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:13:28 --> Utf8 Class Initialized
INFO - 2016-02-10 12:13:28 --> URI Class Initialized
INFO - 2016-02-10 12:13:28 --> Router Class Initialized
INFO - 2016-02-10 12:13:28 --> Output Class Initialized
INFO - 2016-02-10 12:13:28 --> Security Class Initialized
DEBUG - 2016-02-10 12:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:13:28 --> Input Class Initialized
INFO - 2016-02-10 12:13:28 --> Language Class Initialized
INFO - 2016-02-10 12:13:28 --> Loader Class Initialized
INFO - 2016-02-10 12:13:28 --> Helper loaded: url_helper
INFO - 2016-02-10 12:13:28 --> Helper loaded: file_helper
INFO - 2016-02-10 12:13:28 --> Helper loaded: date_helper
INFO - 2016-02-10 12:13:28 --> Helper loaded: form_helper
INFO - 2016-02-10 12:13:28 --> Database Driver Class Initialized
INFO - 2016-02-10 12:13:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:13:29 --> Controller Class Initialized
INFO - 2016-02-10 12:13:29 --> Model Class Initialized
INFO - 2016-02-10 12:13:29 --> Model Class Initialized
INFO - 2016-02-10 12:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:13:29 --> Pagination Class Initialized
INFO - 2016-02-10 15:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:13:29 --> Helper loaded: text_helper
INFO - 2016-02-10 15:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:13:29 --> Final output sent to browser
DEBUG - 2016-02-10 15:13:29 --> Total execution time: 1.1495
INFO - 2016-02-10 12:13:37 --> Config Class Initialized
INFO - 2016-02-10 12:13:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:13:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:13:37 --> Utf8 Class Initialized
INFO - 2016-02-10 12:13:37 --> URI Class Initialized
INFO - 2016-02-10 12:13:37 --> Router Class Initialized
INFO - 2016-02-10 12:13:37 --> Output Class Initialized
INFO - 2016-02-10 12:13:37 --> Security Class Initialized
DEBUG - 2016-02-10 12:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:13:37 --> Input Class Initialized
INFO - 2016-02-10 12:13:37 --> Language Class Initialized
INFO - 2016-02-10 12:13:37 --> Loader Class Initialized
INFO - 2016-02-10 12:13:37 --> Helper loaded: url_helper
INFO - 2016-02-10 12:13:37 --> Helper loaded: file_helper
INFO - 2016-02-10 12:13:37 --> Helper loaded: date_helper
INFO - 2016-02-10 12:13:37 --> Helper loaded: form_helper
INFO - 2016-02-10 12:13:37 --> Database Driver Class Initialized
INFO - 2016-02-10 12:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:13:38 --> Controller Class Initialized
INFO - 2016-02-10 12:13:38 --> Model Class Initialized
INFO - 2016-02-10 12:13:38 --> Model Class Initialized
INFO - 2016-02-10 12:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:13:38 --> Pagination Class Initialized
INFO - 2016-02-10 15:13:38 --> Final output sent to browser
DEBUG - 2016-02-10 15:13:38 --> Total execution time: 1.1640
INFO - 2016-02-10 12:13:57 --> Config Class Initialized
INFO - 2016-02-10 12:13:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:13:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:13:57 --> Utf8 Class Initialized
INFO - 2016-02-10 12:13:57 --> URI Class Initialized
INFO - 2016-02-10 12:13:57 --> Router Class Initialized
INFO - 2016-02-10 12:13:57 --> Output Class Initialized
INFO - 2016-02-10 12:13:57 --> Security Class Initialized
DEBUG - 2016-02-10 12:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:13:57 --> Input Class Initialized
INFO - 2016-02-10 12:13:57 --> Language Class Initialized
INFO - 2016-02-10 12:13:57 --> Loader Class Initialized
INFO - 2016-02-10 12:13:57 --> Helper loaded: url_helper
INFO - 2016-02-10 12:13:57 --> Helper loaded: file_helper
INFO - 2016-02-10 12:13:57 --> Helper loaded: date_helper
INFO - 2016-02-10 12:13:57 --> Helper loaded: form_helper
INFO - 2016-02-10 12:13:57 --> Database Driver Class Initialized
INFO - 2016-02-10 12:13:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:13:58 --> Controller Class Initialized
INFO - 2016-02-10 12:13:58 --> Model Class Initialized
INFO - 2016-02-10 12:13:58 --> Model Class Initialized
INFO - 2016-02-10 12:13:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:13:58 --> Pagination Class Initialized
INFO - 2016-02-10 15:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:13:58 --> Helper loaded: text_helper
INFO - 2016-02-10 15:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:13:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:13:58 --> Final output sent to browser
DEBUG - 2016-02-10 15:13:58 --> Total execution time: 1.1853
INFO - 2016-02-10 12:14:01 --> Config Class Initialized
INFO - 2016-02-10 12:14:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:14:01 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:14:01 --> Utf8 Class Initialized
INFO - 2016-02-10 12:14:01 --> URI Class Initialized
INFO - 2016-02-10 12:14:01 --> Router Class Initialized
INFO - 2016-02-10 12:14:01 --> Output Class Initialized
INFO - 2016-02-10 12:14:01 --> Security Class Initialized
DEBUG - 2016-02-10 12:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:14:01 --> Input Class Initialized
INFO - 2016-02-10 12:14:01 --> Language Class Initialized
INFO - 2016-02-10 12:14:01 --> Loader Class Initialized
INFO - 2016-02-10 12:14:01 --> Helper loaded: url_helper
INFO - 2016-02-10 12:14:01 --> Helper loaded: file_helper
INFO - 2016-02-10 12:14:01 --> Helper loaded: date_helper
INFO - 2016-02-10 12:14:01 --> Helper loaded: form_helper
INFO - 2016-02-10 12:14:01 --> Database Driver Class Initialized
INFO - 2016-02-10 12:14:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:14:02 --> Controller Class Initialized
INFO - 2016-02-10 12:14:02 --> Model Class Initialized
INFO - 2016-02-10 12:14:02 --> Model Class Initialized
INFO - 2016-02-10 12:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:14:02 --> Pagination Class Initialized
INFO - 2016-02-10 15:14:02 --> Final output sent to browser
DEBUG - 2016-02-10 15:14:02 --> Total execution time: 1.1225
INFO - 2016-02-10 12:14:26 --> Config Class Initialized
INFO - 2016-02-10 12:14:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:14:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:14:26 --> Utf8 Class Initialized
INFO - 2016-02-10 12:14:26 --> URI Class Initialized
INFO - 2016-02-10 12:14:26 --> Router Class Initialized
INFO - 2016-02-10 12:14:26 --> Output Class Initialized
INFO - 2016-02-10 12:14:26 --> Security Class Initialized
DEBUG - 2016-02-10 12:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:14:26 --> Input Class Initialized
INFO - 2016-02-10 12:14:26 --> Language Class Initialized
INFO - 2016-02-10 12:14:26 --> Loader Class Initialized
INFO - 2016-02-10 12:14:27 --> Helper loaded: url_helper
INFO - 2016-02-10 12:14:27 --> Helper loaded: file_helper
INFO - 2016-02-10 12:14:27 --> Helper loaded: date_helper
INFO - 2016-02-10 12:14:27 --> Helper loaded: form_helper
INFO - 2016-02-10 12:14:27 --> Database Driver Class Initialized
INFO - 2016-02-10 12:14:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:14:28 --> Controller Class Initialized
INFO - 2016-02-10 12:14:28 --> Model Class Initialized
INFO - 2016-02-10 12:14:28 --> Model Class Initialized
INFO - 2016-02-10 12:14:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:14:28 --> Pagination Class Initialized
INFO - 2016-02-10 15:14:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:14:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:14:28 --> Helper loaded: text_helper
INFO - 2016-02-10 15:14:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:14:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:14:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:14:28 --> Final output sent to browser
DEBUG - 2016-02-10 15:14:28 --> Total execution time: 1.1603
INFO - 2016-02-10 12:15:31 --> Config Class Initialized
INFO - 2016-02-10 12:15:31 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:15:31 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:15:31 --> Utf8 Class Initialized
INFO - 2016-02-10 12:15:31 --> URI Class Initialized
INFO - 2016-02-10 12:15:31 --> Router Class Initialized
INFO - 2016-02-10 12:15:31 --> Output Class Initialized
INFO - 2016-02-10 12:15:31 --> Security Class Initialized
DEBUG - 2016-02-10 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:15:31 --> Input Class Initialized
INFO - 2016-02-10 12:15:31 --> Language Class Initialized
INFO - 2016-02-10 12:15:31 --> Loader Class Initialized
INFO - 2016-02-10 12:15:31 --> Helper loaded: url_helper
INFO - 2016-02-10 12:15:31 --> Helper loaded: file_helper
INFO - 2016-02-10 12:15:31 --> Helper loaded: date_helper
INFO - 2016-02-10 12:15:31 --> Helper loaded: form_helper
INFO - 2016-02-10 12:15:31 --> Database Driver Class Initialized
INFO - 2016-02-10 12:15:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:15:32 --> Controller Class Initialized
INFO - 2016-02-10 12:15:32 --> Model Class Initialized
INFO - 2016-02-10 12:15:32 --> Model Class Initialized
INFO - 2016-02-10 12:15:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:15:32 --> Pagination Class Initialized
INFO - 2016-02-10 15:15:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:15:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:15:32 --> Helper loaded: text_helper
INFO - 2016-02-10 15:15:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:15:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:15:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:15:32 --> Final output sent to browser
DEBUG - 2016-02-10 15:15:32 --> Total execution time: 1.2056
INFO - 2016-02-10 12:15:57 --> Config Class Initialized
INFO - 2016-02-10 12:15:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:15:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:15:57 --> Utf8 Class Initialized
INFO - 2016-02-10 12:15:57 --> URI Class Initialized
INFO - 2016-02-10 12:15:57 --> Router Class Initialized
INFO - 2016-02-10 12:15:57 --> Output Class Initialized
INFO - 2016-02-10 12:15:57 --> Security Class Initialized
DEBUG - 2016-02-10 12:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:15:57 --> Input Class Initialized
INFO - 2016-02-10 12:15:57 --> Language Class Initialized
INFO - 2016-02-10 12:15:57 --> Loader Class Initialized
INFO - 2016-02-10 12:15:57 --> Helper loaded: url_helper
INFO - 2016-02-10 12:15:57 --> Helper loaded: file_helper
INFO - 2016-02-10 12:15:57 --> Helper loaded: date_helper
INFO - 2016-02-10 12:15:57 --> Helper loaded: form_helper
INFO - 2016-02-10 12:15:57 --> Database Driver Class Initialized
INFO - 2016-02-10 12:15:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:15:58 --> Controller Class Initialized
INFO - 2016-02-10 12:15:58 --> Model Class Initialized
INFO - 2016-02-10 12:15:58 --> Model Class Initialized
INFO - 2016-02-10 12:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:15:58 --> Pagination Class Initialized
INFO - 2016-02-10 15:15:58 --> Final output sent to browser
DEBUG - 2016-02-10 15:15:58 --> Total execution time: 1.1261
INFO - 2016-02-10 12:17:41 --> Config Class Initialized
INFO - 2016-02-10 12:17:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:17:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:17:41 --> Utf8 Class Initialized
INFO - 2016-02-10 12:17:41 --> URI Class Initialized
INFO - 2016-02-10 12:17:41 --> Router Class Initialized
INFO - 2016-02-10 12:17:41 --> Output Class Initialized
INFO - 2016-02-10 12:17:41 --> Security Class Initialized
DEBUG - 2016-02-10 12:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:17:41 --> Input Class Initialized
INFO - 2016-02-10 12:17:41 --> Language Class Initialized
INFO - 2016-02-10 12:17:41 --> Loader Class Initialized
INFO - 2016-02-10 12:17:41 --> Helper loaded: url_helper
INFO - 2016-02-10 12:17:41 --> Helper loaded: file_helper
INFO - 2016-02-10 12:17:41 --> Helper loaded: date_helper
INFO - 2016-02-10 12:17:41 --> Helper loaded: form_helper
INFO - 2016-02-10 12:17:41 --> Database Driver Class Initialized
INFO - 2016-02-10 12:17:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:17:42 --> Controller Class Initialized
INFO - 2016-02-10 12:17:42 --> Model Class Initialized
INFO - 2016-02-10 12:17:42 --> Model Class Initialized
INFO - 2016-02-10 12:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:17:42 --> Pagination Class Initialized
INFO - 2016-02-10 15:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:17:42 --> Helper loaded: text_helper
INFO - 2016-02-10 15:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:17:42 --> Final output sent to browser
DEBUG - 2016-02-10 15:17:42 --> Total execution time: 1.1521
INFO - 2016-02-10 12:17:56 --> Config Class Initialized
INFO - 2016-02-10 12:17:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:17:56 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:17:56 --> Utf8 Class Initialized
INFO - 2016-02-10 12:17:56 --> URI Class Initialized
INFO - 2016-02-10 12:17:56 --> Router Class Initialized
INFO - 2016-02-10 12:17:56 --> Output Class Initialized
INFO - 2016-02-10 12:17:56 --> Security Class Initialized
DEBUG - 2016-02-10 12:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:17:56 --> Input Class Initialized
INFO - 2016-02-10 12:17:56 --> Language Class Initialized
INFO - 2016-02-10 12:17:56 --> Loader Class Initialized
INFO - 2016-02-10 12:17:56 --> Helper loaded: url_helper
INFO - 2016-02-10 12:17:56 --> Helper loaded: file_helper
INFO - 2016-02-10 12:17:56 --> Helper loaded: date_helper
INFO - 2016-02-10 12:17:56 --> Helper loaded: form_helper
INFO - 2016-02-10 12:17:56 --> Database Driver Class Initialized
INFO - 2016-02-10 12:17:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:17:57 --> Controller Class Initialized
INFO - 2016-02-10 12:17:57 --> Model Class Initialized
INFO - 2016-02-10 12:17:57 --> Model Class Initialized
INFO - 2016-02-10 12:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:17:57 --> Pagination Class Initialized
INFO - 2016-02-10 15:17:58 --> Final output sent to browser
DEBUG - 2016-02-10 15:17:58 --> Total execution time: 1.1332
INFO - 2016-02-10 12:22:07 --> Config Class Initialized
INFO - 2016-02-10 12:22:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:22:07 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:22:07 --> Utf8 Class Initialized
INFO - 2016-02-10 12:22:07 --> URI Class Initialized
INFO - 2016-02-10 12:22:07 --> Router Class Initialized
INFO - 2016-02-10 12:22:07 --> Output Class Initialized
INFO - 2016-02-10 12:22:07 --> Security Class Initialized
DEBUG - 2016-02-10 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:22:07 --> Input Class Initialized
INFO - 2016-02-10 12:22:07 --> Language Class Initialized
ERROR - 2016-02-10 12:22:07 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 457
INFO - 2016-02-10 12:22:20 --> Config Class Initialized
INFO - 2016-02-10 12:22:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:22:20 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:22:20 --> Utf8 Class Initialized
INFO - 2016-02-10 12:22:20 --> URI Class Initialized
INFO - 2016-02-10 12:22:20 --> Router Class Initialized
INFO - 2016-02-10 12:22:20 --> Output Class Initialized
INFO - 2016-02-10 12:22:20 --> Security Class Initialized
DEBUG - 2016-02-10 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:22:20 --> Input Class Initialized
INFO - 2016-02-10 12:22:20 --> Language Class Initialized
INFO - 2016-02-10 12:22:20 --> Loader Class Initialized
INFO - 2016-02-10 12:22:20 --> Helper loaded: url_helper
INFO - 2016-02-10 12:22:20 --> Helper loaded: file_helper
INFO - 2016-02-10 12:22:20 --> Helper loaded: date_helper
INFO - 2016-02-10 12:22:20 --> Helper loaded: form_helper
INFO - 2016-02-10 12:22:20 --> Database Driver Class Initialized
INFO - 2016-02-10 12:22:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:22:21 --> Controller Class Initialized
INFO - 2016-02-10 12:22:21 --> Model Class Initialized
INFO - 2016-02-10 12:22:21 --> Model Class Initialized
INFO - 2016-02-10 12:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:22:21 --> Pagination Class Initialized
INFO - 2016-02-10 15:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:22:21 --> Helper loaded: text_helper
INFO - 2016-02-10 15:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:22:21 --> Final output sent to browser
DEBUG - 2016-02-10 15:22:21 --> Total execution time: 1.2005
INFO - 2016-02-10 12:22:27 --> Config Class Initialized
INFO - 2016-02-10 12:22:27 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:22:27 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:22:27 --> Utf8 Class Initialized
INFO - 2016-02-10 12:22:27 --> URI Class Initialized
INFO - 2016-02-10 12:22:27 --> Router Class Initialized
INFO - 2016-02-10 12:22:27 --> Output Class Initialized
INFO - 2016-02-10 12:22:27 --> Security Class Initialized
DEBUG - 2016-02-10 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:22:27 --> Input Class Initialized
INFO - 2016-02-10 12:22:27 --> Language Class Initialized
INFO - 2016-02-10 12:22:27 --> Loader Class Initialized
INFO - 2016-02-10 12:22:27 --> Helper loaded: url_helper
INFO - 2016-02-10 12:22:27 --> Helper loaded: file_helper
INFO - 2016-02-10 12:22:27 --> Helper loaded: date_helper
INFO - 2016-02-10 12:22:27 --> Helper loaded: form_helper
INFO - 2016-02-10 12:22:27 --> Database Driver Class Initialized
INFO - 2016-02-10 12:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:22:28 --> Controller Class Initialized
INFO - 2016-02-10 12:22:28 --> Model Class Initialized
INFO - 2016-02-10 12:22:28 --> Model Class Initialized
INFO - 2016-02-10 12:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:22:28 --> Pagination Class Initialized
INFO - 2016-02-10 15:22:28 --> Final output sent to browser
DEBUG - 2016-02-10 15:22:28 --> Total execution time: 1.1267
INFO - 2016-02-10 12:30:37 --> Config Class Initialized
INFO - 2016-02-10 12:30:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:30:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:30:37 --> Utf8 Class Initialized
INFO - 2016-02-10 12:30:37 --> URI Class Initialized
INFO - 2016-02-10 12:30:37 --> Router Class Initialized
INFO - 2016-02-10 12:30:37 --> Output Class Initialized
INFO - 2016-02-10 12:30:37 --> Security Class Initialized
DEBUG - 2016-02-10 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:30:37 --> Input Class Initialized
INFO - 2016-02-10 12:30:37 --> Language Class Initialized
INFO - 2016-02-10 12:30:37 --> Loader Class Initialized
INFO - 2016-02-10 12:30:37 --> Helper loaded: url_helper
INFO - 2016-02-10 12:30:37 --> Helper loaded: file_helper
INFO - 2016-02-10 12:30:37 --> Helper loaded: date_helper
INFO - 2016-02-10 12:30:37 --> Helper loaded: form_helper
INFO - 2016-02-10 12:30:37 --> Database Driver Class Initialized
INFO - 2016-02-10 12:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:30:38 --> Controller Class Initialized
INFO - 2016-02-10 12:30:38 --> Model Class Initialized
INFO - 2016-02-10 12:30:38 --> Model Class Initialized
INFO - 2016-02-10 12:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:30:38 --> Pagination Class Initialized
INFO - 2016-02-10 15:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:30:38 --> Helper loaded: text_helper
INFO - 2016-02-10 15:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:30:38 --> Final output sent to browser
DEBUG - 2016-02-10 15:30:38 --> Total execution time: 1.1737
INFO - 2016-02-10 12:30:40 --> Config Class Initialized
INFO - 2016-02-10 12:30:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:30:40 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:30:40 --> Utf8 Class Initialized
INFO - 2016-02-10 12:30:40 --> URI Class Initialized
INFO - 2016-02-10 12:30:40 --> Router Class Initialized
INFO - 2016-02-10 12:30:40 --> Output Class Initialized
INFO - 2016-02-10 12:30:40 --> Security Class Initialized
DEBUG - 2016-02-10 12:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:30:40 --> Input Class Initialized
INFO - 2016-02-10 12:30:40 --> Language Class Initialized
INFO - 2016-02-10 12:30:40 --> Loader Class Initialized
INFO - 2016-02-10 12:30:40 --> Helper loaded: url_helper
INFO - 2016-02-10 12:30:40 --> Helper loaded: file_helper
INFO - 2016-02-10 12:30:40 --> Helper loaded: date_helper
INFO - 2016-02-10 12:30:40 --> Helper loaded: form_helper
INFO - 2016-02-10 12:30:40 --> Database Driver Class Initialized
INFO - 2016-02-10 12:30:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:30:41 --> Controller Class Initialized
INFO - 2016-02-10 12:30:41 --> Model Class Initialized
INFO - 2016-02-10 12:30:41 --> Model Class Initialized
INFO - 2016-02-10 12:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:30:41 --> Pagination Class Initialized
INFO - 2016-02-10 15:30:41 --> Final output sent to browser
DEBUG - 2016-02-10 15:30:41 --> Total execution time: 1.1514
INFO - 2016-02-10 12:32:01 --> Config Class Initialized
INFO - 2016-02-10 12:32:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:32:01 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:32:01 --> Utf8 Class Initialized
INFO - 2016-02-10 12:32:01 --> URI Class Initialized
INFO - 2016-02-10 12:32:01 --> Router Class Initialized
INFO - 2016-02-10 12:32:01 --> Output Class Initialized
INFO - 2016-02-10 12:32:01 --> Security Class Initialized
DEBUG - 2016-02-10 12:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:32:01 --> Input Class Initialized
INFO - 2016-02-10 12:32:01 --> Language Class Initialized
INFO - 2016-02-10 12:32:01 --> Loader Class Initialized
INFO - 2016-02-10 12:32:01 --> Helper loaded: url_helper
INFO - 2016-02-10 12:32:01 --> Helper loaded: file_helper
INFO - 2016-02-10 12:32:01 --> Helper loaded: date_helper
INFO - 2016-02-10 12:32:01 --> Helper loaded: form_helper
INFO - 2016-02-10 12:32:01 --> Database Driver Class Initialized
INFO - 2016-02-10 12:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:32:02 --> Controller Class Initialized
INFO - 2016-02-10 12:32:02 --> Model Class Initialized
INFO - 2016-02-10 12:32:02 --> Model Class Initialized
INFO - 2016-02-10 12:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:32:02 --> Pagination Class Initialized
INFO - 2016-02-10 15:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:32:02 --> Helper loaded: text_helper
INFO - 2016-02-10 15:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:32:02 --> Final output sent to browser
DEBUG - 2016-02-10 15:32:02 --> Total execution time: 1.1779
INFO - 2016-02-10 12:32:12 --> Config Class Initialized
INFO - 2016-02-10 12:32:12 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:32:12 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:32:12 --> Utf8 Class Initialized
INFO - 2016-02-10 12:32:12 --> URI Class Initialized
INFO - 2016-02-10 12:32:12 --> Router Class Initialized
INFO - 2016-02-10 12:32:12 --> Output Class Initialized
INFO - 2016-02-10 12:32:12 --> Security Class Initialized
DEBUG - 2016-02-10 12:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:32:12 --> Input Class Initialized
INFO - 2016-02-10 12:32:12 --> Language Class Initialized
INFO - 2016-02-10 12:32:12 --> Loader Class Initialized
INFO - 2016-02-10 12:32:12 --> Helper loaded: url_helper
INFO - 2016-02-10 12:32:12 --> Helper loaded: file_helper
INFO - 2016-02-10 12:32:12 --> Helper loaded: date_helper
INFO - 2016-02-10 12:32:12 --> Helper loaded: form_helper
INFO - 2016-02-10 12:32:12 --> Database Driver Class Initialized
INFO - 2016-02-10 12:32:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:32:13 --> Controller Class Initialized
INFO - 2016-02-10 12:32:13 --> Model Class Initialized
INFO - 2016-02-10 12:32:13 --> Model Class Initialized
INFO - 2016-02-10 12:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:32:13 --> Pagination Class Initialized
INFO - 2016-02-10 15:32:13 --> Final output sent to browser
DEBUG - 2016-02-10 15:32:13 --> Total execution time: 1.1490
INFO - 2016-02-10 12:34:47 --> Config Class Initialized
INFO - 2016-02-10 12:34:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:34:47 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:34:47 --> Utf8 Class Initialized
INFO - 2016-02-10 12:34:47 --> URI Class Initialized
INFO - 2016-02-10 12:34:47 --> Router Class Initialized
INFO - 2016-02-10 12:34:47 --> Output Class Initialized
INFO - 2016-02-10 12:34:47 --> Security Class Initialized
DEBUG - 2016-02-10 12:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:34:47 --> Input Class Initialized
INFO - 2016-02-10 12:34:47 --> Language Class Initialized
INFO - 2016-02-10 12:34:47 --> Loader Class Initialized
INFO - 2016-02-10 12:34:47 --> Helper loaded: url_helper
INFO - 2016-02-10 12:34:47 --> Helper loaded: file_helper
INFO - 2016-02-10 12:34:47 --> Helper loaded: date_helper
INFO - 2016-02-10 12:34:47 --> Helper loaded: form_helper
INFO - 2016-02-10 12:34:47 --> Database Driver Class Initialized
INFO - 2016-02-10 12:34:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:34:49 --> Controller Class Initialized
INFO - 2016-02-10 12:34:49 --> Model Class Initialized
INFO - 2016-02-10 12:34:49 --> Model Class Initialized
INFO - 2016-02-10 12:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:34:49 --> Pagination Class Initialized
INFO - 2016-02-10 15:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:34:49 --> Helper loaded: text_helper
INFO - 2016-02-10 15:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:34:49 --> Final output sent to browser
DEBUG - 2016-02-10 15:34:49 --> Total execution time: 1.1898
INFO - 2016-02-10 12:34:50 --> Config Class Initialized
INFO - 2016-02-10 12:34:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:34:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:34:50 --> Utf8 Class Initialized
INFO - 2016-02-10 12:34:50 --> URI Class Initialized
INFO - 2016-02-10 12:34:50 --> Router Class Initialized
INFO - 2016-02-10 12:34:50 --> Output Class Initialized
INFO - 2016-02-10 12:34:50 --> Security Class Initialized
DEBUG - 2016-02-10 12:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:34:50 --> Input Class Initialized
INFO - 2016-02-10 12:34:50 --> Language Class Initialized
INFO - 2016-02-10 12:34:50 --> Loader Class Initialized
INFO - 2016-02-10 12:34:50 --> Helper loaded: url_helper
INFO - 2016-02-10 12:34:50 --> Helper loaded: file_helper
INFO - 2016-02-10 12:34:50 --> Helper loaded: date_helper
INFO - 2016-02-10 12:34:50 --> Helper loaded: form_helper
INFO - 2016-02-10 12:34:50 --> Database Driver Class Initialized
INFO - 2016-02-10 12:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:34:51 --> Controller Class Initialized
INFO - 2016-02-10 12:34:51 --> Model Class Initialized
INFO - 2016-02-10 12:34:51 --> Model Class Initialized
INFO - 2016-02-10 12:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:34:51 --> Pagination Class Initialized
INFO - 2016-02-10 15:34:51 --> Final output sent to browser
DEBUG - 2016-02-10 15:34:51 --> Total execution time: 1.0956
INFO - 2016-02-10 12:34:52 --> Config Class Initialized
INFO - 2016-02-10 12:34:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:34:52 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:34:52 --> Utf8 Class Initialized
INFO - 2016-02-10 12:34:52 --> URI Class Initialized
INFO - 2016-02-10 12:34:52 --> Router Class Initialized
INFO - 2016-02-10 12:34:52 --> Output Class Initialized
INFO - 2016-02-10 12:34:52 --> Security Class Initialized
DEBUG - 2016-02-10 12:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:34:52 --> Input Class Initialized
INFO - 2016-02-10 12:34:52 --> Language Class Initialized
INFO - 2016-02-10 12:34:52 --> Loader Class Initialized
INFO - 2016-02-10 12:34:52 --> Helper loaded: url_helper
INFO - 2016-02-10 12:34:52 --> Helper loaded: file_helper
INFO - 2016-02-10 12:34:52 --> Helper loaded: date_helper
INFO - 2016-02-10 12:34:52 --> Helper loaded: form_helper
INFO - 2016-02-10 12:34:52 --> Database Driver Class Initialized
INFO - 2016-02-10 12:34:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:34:53 --> Controller Class Initialized
INFO - 2016-02-10 12:34:53 --> Model Class Initialized
INFO - 2016-02-10 12:34:53 --> Model Class Initialized
INFO - 2016-02-10 12:34:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:34:53 --> Pagination Class Initialized
INFO - 2016-02-10 15:34:53 --> Final output sent to browser
DEBUG - 2016-02-10 15:34:53 --> Total execution time: 1.1289
INFO - 2016-02-10 12:36:36 --> Config Class Initialized
INFO - 2016-02-10 12:36:36 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:36:36 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:36:36 --> Utf8 Class Initialized
INFO - 2016-02-10 12:36:36 --> URI Class Initialized
INFO - 2016-02-10 12:36:36 --> Router Class Initialized
INFO - 2016-02-10 12:36:36 --> Output Class Initialized
INFO - 2016-02-10 12:36:36 --> Security Class Initialized
DEBUG - 2016-02-10 12:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:36:36 --> Input Class Initialized
INFO - 2016-02-10 12:36:36 --> Language Class Initialized
INFO - 2016-02-10 12:36:36 --> Loader Class Initialized
INFO - 2016-02-10 12:36:36 --> Helper loaded: url_helper
INFO - 2016-02-10 12:36:36 --> Helper loaded: file_helper
INFO - 2016-02-10 12:36:36 --> Helper loaded: date_helper
INFO - 2016-02-10 12:36:36 --> Helper loaded: form_helper
INFO - 2016-02-10 12:36:36 --> Database Driver Class Initialized
INFO - 2016-02-10 12:36:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:36:37 --> Controller Class Initialized
INFO - 2016-02-10 12:36:37 --> Model Class Initialized
INFO - 2016-02-10 12:36:37 --> Model Class Initialized
INFO - 2016-02-10 12:36:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:36:37 --> Pagination Class Initialized
INFO - 2016-02-10 15:36:37 --> Final output sent to browser
DEBUG - 2016-02-10 15:36:37 --> Total execution time: 1.1010
INFO - 2016-02-10 12:37:40 --> Config Class Initialized
INFO - 2016-02-10 12:37:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:37:40 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:37:40 --> Utf8 Class Initialized
INFO - 2016-02-10 12:37:40 --> URI Class Initialized
INFO - 2016-02-10 12:37:40 --> Router Class Initialized
INFO - 2016-02-10 12:37:40 --> Output Class Initialized
INFO - 2016-02-10 12:37:40 --> Security Class Initialized
DEBUG - 2016-02-10 12:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:37:40 --> Input Class Initialized
INFO - 2016-02-10 12:37:40 --> Language Class Initialized
INFO - 2016-02-10 12:37:40 --> Loader Class Initialized
INFO - 2016-02-10 12:37:40 --> Helper loaded: url_helper
INFO - 2016-02-10 12:37:40 --> Helper loaded: file_helper
INFO - 2016-02-10 12:37:40 --> Helper loaded: date_helper
INFO - 2016-02-10 12:37:40 --> Helper loaded: form_helper
INFO - 2016-02-10 12:37:40 --> Database Driver Class Initialized
INFO - 2016-02-10 12:37:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:37:41 --> Controller Class Initialized
INFO - 2016-02-10 12:37:41 --> Model Class Initialized
INFO - 2016-02-10 12:37:41 --> Model Class Initialized
INFO - 2016-02-10 12:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:37:41 --> Pagination Class Initialized
INFO - 2016-02-10 15:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:37:41 --> Helper loaded: text_helper
INFO - 2016-02-10 15:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:37:42 --> Final output sent to browser
DEBUG - 2016-02-10 15:37:42 --> Total execution time: 1.2582
INFO - 2016-02-10 12:37:51 --> Config Class Initialized
INFO - 2016-02-10 12:37:51 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:37:51 --> Utf8 Class Initialized
INFO - 2016-02-10 12:37:51 --> URI Class Initialized
INFO - 2016-02-10 12:37:51 --> Router Class Initialized
INFO - 2016-02-10 12:37:51 --> Output Class Initialized
INFO - 2016-02-10 12:37:51 --> Security Class Initialized
DEBUG - 2016-02-10 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:37:51 --> Input Class Initialized
INFO - 2016-02-10 12:37:51 --> Language Class Initialized
INFO - 2016-02-10 12:37:51 --> Loader Class Initialized
INFO - 2016-02-10 12:37:51 --> Helper loaded: url_helper
INFO - 2016-02-10 12:37:51 --> Helper loaded: file_helper
INFO - 2016-02-10 12:37:51 --> Helper loaded: date_helper
INFO - 2016-02-10 12:37:51 --> Helper loaded: form_helper
INFO - 2016-02-10 12:37:51 --> Database Driver Class Initialized
INFO - 2016-02-10 12:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:37:52 --> Controller Class Initialized
INFO - 2016-02-10 12:37:52 --> Model Class Initialized
INFO - 2016-02-10 12:37:52 --> Model Class Initialized
INFO - 2016-02-10 12:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:37:52 --> Pagination Class Initialized
INFO - 2016-02-10 15:37:52 --> Final output sent to browser
DEBUG - 2016-02-10 15:37:52 --> Total execution time: 1.0970
INFO - 2016-02-10 12:38:00 --> Config Class Initialized
INFO - 2016-02-10 12:38:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:38:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:38:00 --> Utf8 Class Initialized
INFO - 2016-02-10 12:38:00 --> URI Class Initialized
INFO - 2016-02-10 12:38:00 --> Router Class Initialized
INFO - 2016-02-10 12:38:00 --> Output Class Initialized
INFO - 2016-02-10 12:38:00 --> Security Class Initialized
DEBUG - 2016-02-10 12:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:38:00 --> Input Class Initialized
INFO - 2016-02-10 12:38:00 --> Language Class Initialized
INFO - 2016-02-10 12:38:00 --> Loader Class Initialized
INFO - 2016-02-10 12:38:00 --> Helper loaded: url_helper
INFO - 2016-02-10 12:38:00 --> Helper loaded: file_helper
INFO - 2016-02-10 12:38:00 --> Helper loaded: date_helper
INFO - 2016-02-10 12:38:00 --> Helper loaded: form_helper
INFO - 2016-02-10 12:38:00 --> Database Driver Class Initialized
INFO - 2016-02-10 12:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:38:01 --> Controller Class Initialized
INFO - 2016-02-10 12:38:01 --> Model Class Initialized
INFO - 2016-02-10 12:38:01 --> Model Class Initialized
INFO - 2016-02-10 12:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:38:01 --> Pagination Class Initialized
INFO - 2016-02-10 15:38:01 --> Final output sent to browser
DEBUG - 2016-02-10 15:38:01 --> Total execution time: 1.1085
INFO - 2016-02-10 12:38:46 --> Config Class Initialized
INFO - 2016-02-10 12:38:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:38:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:38:46 --> Utf8 Class Initialized
INFO - 2016-02-10 12:38:46 --> URI Class Initialized
INFO - 2016-02-10 12:38:46 --> Router Class Initialized
INFO - 2016-02-10 12:38:46 --> Output Class Initialized
INFO - 2016-02-10 12:38:46 --> Security Class Initialized
DEBUG - 2016-02-10 12:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:38:46 --> Input Class Initialized
INFO - 2016-02-10 12:38:46 --> Language Class Initialized
INFO - 2016-02-10 12:38:46 --> Loader Class Initialized
INFO - 2016-02-10 12:38:46 --> Helper loaded: url_helper
INFO - 2016-02-10 12:38:46 --> Helper loaded: file_helper
INFO - 2016-02-10 12:38:46 --> Helper loaded: date_helper
INFO - 2016-02-10 12:38:46 --> Helper loaded: form_helper
INFO - 2016-02-10 12:38:46 --> Database Driver Class Initialized
INFO - 2016-02-10 12:38:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:38:47 --> Controller Class Initialized
INFO - 2016-02-10 12:38:47 --> Model Class Initialized
INFO - 2016-02-10 12:38:47 --> Model Class Initialized
INFO - 2016-02-10 12:38:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:38:47 --> Pagination Class Initialized
INFO - 2016-02-10 15:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:38:47 --> Helper loaded: text_helper
INFO - 2016-02-10 15:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:38:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:38:47 --> Final output sent to browser
DEBUG - 2016-02-10 15:38:47 --> Total execution time: 1.1399
INFO - 2016-02-10 12:39:24 --> Config Class Initialized
INFO - 2016-02-10 12:39:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:39:24 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:39:24 --> Utf8 Class Initialized
INFO - 2016-02-10 12:39:24 --> URI Class Initialized
INFO - 2016-02-10 12:39:24 --> Router Class Initialized
INFO - 2016-02-10 12:39:24 --> Output Class Initialized
INFO - 2016-02-10 12:39:24 --> Security Class Initialized
DEBUG - 2016-02-10 12:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:39:24 --> Input Class Initialized
INFO - 2016-02-10 12:39:24 --> Language Class Initialized
INFO - 2016-02-10 12:39:24 --> Loader Class Initialized
INFO - 2016-02-10 12:39:24 --> Helper loaded: url_helper
INFO - 2016-02-10 12:39:24 --> Helper loaded: file_helper
INFO - 2016-02-10 12:39:24 --> Helper loaded: date_helper
INFO - 2016-02-10 12:39:24 --> Helper loaded: form_helper
INFO - 2016-02-10 12:39:24 --> Database Driver Class Initialized
INFO - 2016-02-10 12:39:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:39:25 --> Controller Class Initialized
INFO - 2016-02-10 12:39:25 --> Model Class Initialized
INFO - 2016-02-10 12:39:25 --> Model Class Initialized
INFO - 2016-02-10 12:39:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:39:25 --> Pagination Class Initialized
INFO - 2016-02-10 15:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:39:25 --> Helper loaded: text_helper
INFO - 2016-02-10 15:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:39:25 --> Final output sent to browser
DEBUG - 2016-02-10 15:39:25 --> Total execution time: 1.1567
INFO - 2016-02-10 12:39:53 --> Config Class Initialized
INFO - 2016-02-10 12:39:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:39:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:39:53 --> Utf8 Class Initialized
INFO - 2016-02-10 12:39:53 --> URI Class Initialized
INFO - 2016-02-10 12:39:53 --> Router Class Initialized
INFO - 2016-02-10 12:39:53 --> Output Class Initialized
INFO - 2016-02-10 12:39:53 --> Security Class Initialized
DEBUG - 2016-02-10 12:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:39:53 --> Input Class Initialized
INFO - 2016-02-10 12:39:53 --> Language Class Initialized
INFO - 2016-02-10 12:39:53 --> Loader Class Initialized
INFO - 2016-02-10 12:39:53 --> Helper loaded: url_helper
INFO - 2016-02-10 12:39:53 --> Helper loaded: file_helper
INFO - 2016-02-10 12:39:53 --> Helper loaded: date_helper
INFO - 2016-02-10 12:39:53 --> Helper loaded: form_helper
INFO - 2016-02-10 12:39:53 --> Database Driver Class Initialized
INFO - 2016-02-10 12:39:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:39:54 --> Controller Class Initialized
INFO - 2016-02-10 12:39:54 --> Model Class Initialized
INFO - 2016-02-10 12:39:54 --> Model Class Initialized
INFO - 2016-02-10 12:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:39:54 --> Pagination Class Initialized
INFO - 2016-02-10 15:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:39:54 --> Helper loaded: text_helper
INFO - 2016-02-10 15:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:39:54 --> Final output sent to browser
DEBUG - 2016-02-10 15:39:54 --> Total execution time: 1.1896
INFO - 2016-02-10 12:40:26 --> Config Class Initialized
INFO - 2016-02-10 12:40:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:40:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:40:26 --> Utf8 Class Initialized
INFO - 2016-02-10 12:40:26 --> URI Class Initialized
INFO - 2016-02-10 12:40:26 --> Router Class Initialized
INFO - 2016-02-10 12:40:26 --> Output Class Initialized
INFO - 2016-02-10 12:40:26 --> Security Class Initialized
DEBUG - 2016-02-10 12:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:40:26 --> Input Class Initialized
INFO - 2016-02-10 12:40:26 --> Language Class Initialized
INFO - 2016-02-10 12:40:26 --> Loader Class Initialized
INFO - 2016-02-10 12:40:26 --> Helper loaded: url_helper
INFO - 2016-02-10 12:40:26 --> Helper loaded: file_helper
INFO - 2016-02-10 12:40:26 --> Helper loaded: date_helper
INFO - 2016-02-10 12:40:26 --> Helper loaded: form_helper
INFO - 2016-02-10 12:40:26 --> Database Driver Class Initialized
INFO - 2016-02-10 12:40:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:40:27 --> Controller Class Initialized
INFO - 2016-02-10 12:40:27 --> Model Class Initialized
INFO - 2016-02-10 12:40:27 --> Model Class Initialized
INFO - 2016-02-10 12:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:40:27 --> Pagination Class Initialized
INFO - 2016-02-10 15:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:40:27 --> Helper loaded: text_helper
INFO - 2016-02-10 15:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:40:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:40:27 --> Final output sent to browser
DEBUG - 2016-02-10 15:40:27 --> Total execution time: 1.1741
INFO - 2016-02-10 12:41:44 --> Config Class Initialized
INFO - 2016-02-10 12:41:44 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:41:44 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:41:44 --> Utf8 Class Initialized
INFO - 2016-02-10 12:41:44 --> URI Class Initialized
INFO - 2016-02-10 12:41:44 --> Router Class Initialized
INFO - 2016-02-10 12:41:44 --> Output Class Initialized
INFO - 2016-02-10 12:41:44 --> Security Class Initialized
DEBUG - 2016-02-10 12:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:41:44 --> Input Class Initialized
INFO - 2016-02-10 12:41:44 --> Language Class Initialized
INFO - 2016-02-10 12:41:44 --> Loader Class Initialized
INFO - 2016-02-10 12:41:44 --> Helper loaded: url_helper
INFO - 2016-02-10 12:41:44 --> Helper loaded: file_helper
INFO - 2016-02-10 12:41:44 --> Helper loaded: date_helper
INFO - 2016-02-10 12:41:44 --> Helper loaded: form_helper
INFO - 2016-02-10 12:41:44 --> Database Driver Class Initialized
INFO - 2016-02-10 12:41:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:41:45 --> Controller Class Initialized
INFO - 2016-02-10 12:41:45 --> Model Class Initialized
INFO - 2016-02-10 12:41:45 --> Model Class Initialized
INFO - 2016-02-10 12:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:41:45 --> Pagination Class Initialized
INFO - 2016-02-10 15:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:41:45 --> Helper loaded: text_helper
INFO - 2016-02-10 15:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:41:45 --> Final output sent to browser
DEBUG - 2016-02-10 15:41:45 --> Total execution time: 1.1751
INFO - 2016-02-10 12:41:57 --> Config Class Initialized
INFO - 2016-02-10 12:41:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:41:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:41:57 --> Utf8 Class Initialized
INFO - 2016-02-10 12:41:57 --> URI Class Initialized
INFO - 2016-02-10 12:41:57 --> Router Class Initialized
INFO - 2016-02-10 12:41:57 --> Output Class Initialized
INFO - 2016-02-10 12:41:57 --> Security Class Initialized
DEBUG - 2016-02-10 12:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:41:57 --> Input Class Initialized
INFO - 2016-02-10 12:41:57 --> Language Class Initialized
INFO - 2016-02-10 12:41:57 --> Loader Class Initialized
INFO - 2016-02-10 12:41:57 --> Helper loaded: url_helper
INFO - 2016-02-10 12:41:57 --> Helper loaded: file_helper
INFO - 2016-02-10 12:41:57 --> Helper loaded: date_helper
INFO - 2016-02-10 12:41:57 --> Helper loaded: form_helper
INFO - 2016-02-10 12:41:57 --> Database Driver Class Initialized
INFO - 2016-02-10 12:41:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:41:58 --> Controller Class Initialized
INFO - 2016-02-10 12:41:58 --> Model Class Initialized
INFO - 2016-02-10 12:41:58 --> Model Class Initialized
INFO - 2016-02-10 12:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:41:58 --> Pagination Class Initialized
INFO - 2016-02-10 15:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:41:58 --> Helper loaded: text_helper
INFO - 2016-02-10 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:41:59 --> Final output sent to browser
DEBUG - 2016-02-10 15:41:59 --> Total execution time: 1.1637
INFO - 2016-02-10 12:42:00 --> Config Class Initialized
INFO - 2016-02-10 12:42:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:42:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:42:00 --> Utf8 Class Initialized
INFO - 2016-02-10 12:42:00 --> URI Class Initialized
INFO - 2016-02-10 12:42:00 --> Router Class Initialized
INFO - 2016-02-10 12:42:00 --> Output Class Initialized
INFO - 2016-02-10 12:42:00 --> Security Class Initialized
DEBUG - 2016-02-10 12:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:42:00 --> Input Class Initialized
INFO - 2016-02-10 12:42:00 --> Language Class Initialized
INFO - 2016-02-10 12:42:00 --> Loader Class Initialized
INFO - 2016-02-10 12:42:00 --> Helper loaded: url_helper
INFO - 2016-02-10 12:42:00 --> Helper loaded: file_helper
INFO - 2016-02-10 12:42:00 --> Helper loaded: date_helper
INFO - 2016-02-10 12:42:00 --> Helper loaded: form_helper
INFO - 2016-02-10 12:42:00 --> Database Driver Class Initialized
INFO - 2016-02-10 12:42:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:42:01 --> Controller Class Initialized
INFO - 2016-02-10 12:42:01 --> Model Class Initialized
INFO - 2016-02-10 12:42:01 --> Model Class Initialized
INFO - 2016-02-10 12:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:42:01 --> Pagination Class Initialized
INFO - 2016-02-10 15:42:01 --> Final output sent to browser
DEBUG - 2016-02-10 15:42:01 --> Total execution time: 1.1412
INFO - 2016-02-10 12:42:05 --> Config Class Initialized
INFO - 2016-02-10 12:42:05 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:42:05 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:42:05 --> Utf8 Class Initialized
INFO - 2016-02-10 12:42:05 --> URI Class Initialized
INFO - 2016-02-10 12:42:05 --> Router Class Initialized
INFO - 2016-02-10 12:42:05 --> Output Class Initialized
INFO - 2016-02-10 12:42:05 --> Security Class Initialized
DEBUG - 2016-02-10 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:42:05 --> Input Class Initialized
INFO - 2016-02-10 12:42:05 --> Language Class Initialized
INFO - 2016-02-10 12:42:05 --> Loader Class Initialized
INFO - 2016-02-10 12:42:05 --> Helper loaded: url_helper
INFO - 2016-02-10 12:42:05 --> Helper loaded: file_helper
INFO - 2016-02-10 12:42:05 --> Helper loaded: date_helper
INFO - 2016-02-10 12:42:05 --> Helper loaded: form_helper
INFO - 2016-02-10 12:42:05 --> Database Driver Class Initialized
INFO - 2016-02-10 12:42:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:42:06 --> Controller Class Initialized
INFO - 2016-02-10 12:42:06 --> Model Class Initialized
INFO - 2016-02-10 12:42:06 --> Model Class Initialized
INFO - 2016-02-10 12:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:42:06 --> Pagination Class Initialized
INFO - 2016-02-10 15:42:06 --> Final output sent to browser
DEBUG - 2016-02-10 15:42:06 --> Total execution time: 1.1036
INFO - 2016-02-10 12:44:34 --> Config Class Initialized
INFO - 2016-02-10 12:44:34 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:44:34 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:44:34 --> Utf8 Class Initialized
INFO - 2016-02-10 12:44:34 --> URI Class Initialized
INFO - 2016-02-10 12:44:34 --> Router Class Initialized
INFO - 2016-02-10 12:44:34 --> Output Class Initialized
INFO - 2016-02-10 12:44:34 --> Security Class Initialized
DEBUG - 2016-02-10 12:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:44:34 --> Input Class Initialized
INFO - 2016-02-10 12:44:34 --> Language Class Initialized
INFO - 2016-02-10 12:44:34 --> Loader Class Initialized
INFO - 2016-02-10 12:44:34 --> Helper loaded: url_helper
INFO - 2016-02-10 12:44:34 --> Helper loaded: file_helper
INFO - 2016-02-10 12:44:34 --> Helper loaded: date_helper
INFO - 2016-02-10 12:44:34 --> Helper loaded: form_helper
INFO - 2016-02-10 12:44:34 --> Database Driver Class Initialized
INFO - 2016-02-10 12:44:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:44:35 --> Controller Class Initialized
INFO - 2016-02-10 12:44:35 --> Model Class Initialized
INFO - 2016-02-10 12:44:35 --> Model Class Initialized
INFO - 2016-02-10 12:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:44:35 --> Pagination Class Initialized
INFO - 2016-02-10 15:44:35 --> Final output sent to browser
DEBUG - 2016-02-10 15:44:35 --> Total execution time: 1.0996
INFO - 2016-02-10 12:46:10 --> Config Class Initialized
INFO - 2016-02-10 12:46:10 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:10 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:10 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:10 --> URI Class Initialized
INFO - 2016-02-10 12:46:10 --> Router Class Initialized
INFO - 2016-02-10 12:46:10 --> Output Class Initialized
INFO - 2016-02-10 12:46:10 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:10 --> Input Class Initialized
INFO - 2016-02-10 12:46:10 --> Language Class Initialized
INFO - 2016-02-10 12:46:10 --> Loader Class Initialized
INFO - 2016-02-10 12:46:10 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:10 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:10 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:10 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:10 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:11 --> Controller Class Initialized
INFO - 2016-02-10 12:46:11 --> Model Class Initialized
INFO - 2016-02-10 12:46:11 --> Model Class Initialized
INFO - 2016-02-10 12:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:11 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:46:11 --> Helper loaded: text_helper
INFO - 2016-02-10 15:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:46:11 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:11 --> Total execution time: 1.1930
INFO - 2016-02-10 12:46:15 --> Config Class Initialized
INFO - 2016-02-10 12:46:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:15 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:15 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:15 --> URI Class Initialized
INFO - 2016-02-10 12:46:15 --> Router Class Initialized
INFO - 2016-02-10 12:46:15 --> Output Class Initialized
INFO - 2016-02-10 12:46:15 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:15 --> Input Class Initialized
INFO - 2016-02-10 12:46:15 --> Language Class Initialized
INFO - 2016-02-10 12:46:15 --> Loader Class Initialized
INFO - 2016-02-10 12:46:15 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:15 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:15 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:15 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:15 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:16 --> Controller Class Initialized
INFO - 2016-02-10 12:46:16 --> Model Class Initialized
INFO - 2016-02-10 12:46:16 --> Model Class Initialized
INFO - 2016-02-10 12:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:16 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:16 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:16 --> Total execution time: 1.0899
INFO - 2016-02-10 12:46:20 --> Config Class Initialized
INFO - 2016-02-10 12:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:20 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:20 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:20 --> URI Class Initialized
INFO - 2016-02-10 12:46:20 --> Router Class Initialized
INFO - 2016-02-10 12:46:20 --> Output Class Initialized
INFO - 2016-02-10 12:46:20 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:20 --> Input Class Initialized
INFO - 2016-02-10 12:46:20 --> Language Class Initialized
INFO - 2016-02-10 12:46:20 --> Loader Class Initialized
INFO - 2016-02-10 12:46:20 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:20 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:20 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:20 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:20 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:21 --> Controller Class Initialized
INFO - 2016-02-10 12:46:21 --> Model Class Initialized
INFO - 2016-02-10 12:46:21 --> Model Class Initialized
INFO - 2016-02-10 12:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:21 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:21 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:21 --> Total execution time: 1.1596
INFO - 2016-02-10 12:46:33 --> Config Class Initialized
INFO - 2016-02-10 12:46:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:33 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:33 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:33 --> URI Class Initialized
INFO - 2016-02-10 12:46:33 --> Router Class Initialized
INFO - 2016-02-10 12:46:33 --> Output Class Initialized
INFO - 2016-02-10 12:46:33 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:33 --> Input Class Initialized
INFO - 2016-02-10 12:46:33 --> Language Class Initialized
INFO - 2016-02-10 12:46:33 --> Loader Class Initialized
INFO - 2016-02-10 12:46:33 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:33 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:33 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:33 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:33 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:34 --> Controller Class Initialized
INFO - 2016-02-10 12:46:34 --> Model Class Initialized
INFO - 2016-02-10 12:46:34 --> Model Class Initialized
INFO - 2016-02-10 12:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:34 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:46:34 --> Helper loaded: text_helper
INFO - 2016-02-10 15:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:46:34 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:34 --> Total execution time: 1.1492
INFO - 2016-02-10 12:46:35 --> Config Class Initialized
INFO - 2016-02-10 12:46:35 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:35 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:35 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:35 --> URI Class Initialized
INFO - 2016-02-10 12:46:35 --> Router Class Initialized
INFO - 2016-02-10 12:46:35 --> Output Class Initialized
INFO - 2016-02-10 12:46:35 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:35 --> Input Class Initialized
INFO - 2016-02-10 12:46:35 --> Language Class Initialized
INFO - 2016-02-10 12:46:35 --> Loader Class Initialized
INFO - 2016-02-10 12:46:35 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:35 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:35 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:35 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:35 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:36 --> Controller Class Initialized
INFO - 2016-02-10 12:46:36 --> Model Class Initialized
INFO - 2016-02-10 12:46:36 --> Model Class Initialized
INFO - 2016-02-10 12:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:36 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:36 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:36 --> Total execution time: 1.1206
INFO - 2016-02-10 12:46:40 --> Config Class Initialized
INFO - 2016-02-10 12:46:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:46:40 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:46:40 --> Utf8 Class Initialized
INFO - 2016-02-10 12:46:40 --> URI Class Initialized
INFO - 2016-02-10 12:46:40 --> Router Class Initialized
INFO - 2016-02-10 12:46:40 --> Output Class Initialized
INFO - 2016-02-10 12:46:40 --> Security Class Initialized
DEBUG - 2016-02-10 12:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:46:40 --> Input Class Initialized
INFO - 2016-02-10 12:46:40 --> Language Class Initialized
INFO - 2016-02-10 12:46:40 --> Loader Class Initialized
INFO - 2016-02-10 12:46:40 --> Helper loaded: url_helper
INFO - 2016-02-10 12:46:40 --> Helper loaded: file_helper
INFO - 2016-02-10 12:46:40 --> Helper loaded: date_helper
INFO - 2016-02-10 12:46:40 --> Helper loaded: form_helper
INFO - 2016-02-10 12:46:40 --> Database Driver Class Initialized
INFO - 2016-02-10 12:46:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:46:41 --> Controller Class Initialized
INFO - 2016-02-10 12:46:41 --> Model Class Initialized
INFO - 2016-02-10 12:46:41 --> Model Class Initialized
INFO - 2016-02-10 12:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:46:41 --> Pagination Class Initialized
INFO - 2016-02-10 15:46:41 --> Final output sent to browser
DEBUG - 2016-02-10 15:46:41 --> Total execution time: 1.1540
INFO - 2016-02-10 12:47:09 --> Config Class Initialized
INFO - 2016-02-10 12:47:09 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:47:09 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:47:09 --> Utf8 Class Initialized
INFO - 2016-02-10 12:47:09 --> URI Class Initialized
INFO - 2016-02-10 12:47:09 --> Router Class Initialized
INFO - 2016-02-10 12:47:09 --> Output Class Initialized
INFO - 2016-02-10 12:47:09 --> Security Class Initialized
DEBUG - 2016-02-10 12:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:47:09 --> Input Class Initialized
INFO - 2016-02-10 12:47:09 --> Language Class Initialized
INFO - 2016-02-10 12:47:09 --> Loader Class Initialized
INFO - 2016-02-10 12:47:09 --> Helper loaded: url_helper
INFO - 2016-02-10 12:47:09 --> Helper loaded: file_helper
INFO - 2016-02-10 12:47:09 --> Helper loaded: date_helper
INFO - 2016-02-10 12:47:09 --> Helper loaded: form_helper
INFO - 2016-02-10 12:47:09 --> Database Driver Class Initialized
INFO - 2016-02-10 12:47:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:47:10 --> Controller Class Initialized
INFO - 2016-02-10 12:47:10 --> Model Class Initialized
INFO - 2016-02-10 12:47:10 --> Model Class Initialized
INFO - 2016-02-10 12:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:47:10 --> Pagination Class Initialized
INFO - 2016-02-10 15:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:47:10 --> Helper loaded: text_helper
INFO - 2016-02-10 15:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:47:10 --> Final output sent to browser
DEBUG - 2016-02-10 15:47:10 --> Total execution time: 1.1901
INFO - 2016-02-10 12:48:11 --> Config Class Initialized
INFO - 2016-02-10 12:48:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:48:11 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:48:11 --> Utf8 Class Initialized
INFO - 2016-02-10 12:48:11 --> URI Class Initialized
INFO - 2016-02-10 12:48:11 --> Router Class Initialized
INFO - 2016-02-10 12:48:11 --> Output Class Initialized
INFO - 2016-02-10 12:48:11 --> Security Class Initialized
DEBUG - 2016-02-10 12:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:48:11 --> Input Class Initialized
INFO - 2016-02-10 12:48:11 --> Language Class Initialized
INFO - 2016-02-10 12:48:11 --> Loader Class Initialized
INFO - 2016-02-10 12:48:11 --> Helper loaded: url_helper
INFO - 2016-02-10 12:48:11 --> Helper loaded: file_helper
INFO - 2016-02-10 12:48:11 --> Helper loaded: date_helper
INFO - 2016-02-10 12:48:11 --> Helper loaded: form_helper
INFO - 2016-02-10 12:48:11 --> Database Driver Class Initialized
INFO - 2016-02-10 12:48:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:48:12 --> Controller Class Initialized
INFO - 2016-02-10 12:48:12 --> Model Class Initialized
INFO - 2016-02-10 12:48:12 --> Model Class Initialized
INFO - 2016-02-10 12:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:48:12 --> Pagination Class Initialized
INFO - 2016-02-10 15:48:12 --> Final output sent to browser
DEBUG - 2016-02-10 15:48:12 --> Total execution time: 1.1339
INFO - 2016-02-10 12:48:16 --> Config Class Initialized
INFO - 2016-02-10 12:48:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:48:16 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:48:16 --> Utf8 Class Initialized
INFO - 2016-02-10 12:48:16 --> URI Class Initialized
INFO - 2016-02-10 12:48:16 --> Router Class Initialized
INFO - 2016-02-10 12:48:16 --> Output Class Initialized
INFO - 2016-02-10 12:48:16 --> Security Class Initialized
DEBUG - 2016-02-10 12:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:48:16 --> Input Class Initialized
INFO - 2016-02-10 12:48:16 --> Language Class Initialized
INFO - 2016-02-10 12:48:16 --> Loader Class Initialized
INFO - 2016-02-10 12:48:16 --> Helper loaded: url_helper
INFO - 2016-02-10 12:48:16 --> Helper loaded: file_helper
INFO - 2016-02-10 12:48:16 --> Helper loaded: date_helper
INFO - 2016-02-10 12:48:16 --> Helper loaded: form_helper
INFO - 2016-02-10 12:48:16 --> Database Driver Class Initialized
INFO - 2016-02-10 12:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:48:17 --> Controller Class Initialized
INFO - 2016-02-10 12:48:17 --> Model Class Initialized
INFO - 2016-02-10 12:48:17 --> Model Class Initialized
INFO - 2016-02-10 12:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:48:17 --> Pagination Class Initialized
INFO - 2016-02-10 15:48:17 --> Final output sent to browser
DEBUG - 2016-02-10 15:48:17 --> Total execution time: 1.1141
INFO - 2016-02-10 12:49:28 --> Config Class Initialized
INFO - 2016-02-10 12:49:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:49:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:49:28 --> Utf8 Class Initialized
INFO - 2016-02-10 12:49:28 --> URI Class Initialized
INFO - 2016-02-10 12:49:28 --> Router Class Initialized
INFO - 2016-02-10 12:49:28 --> Output Class Initialized
INFO - 2016-02-10 12:49:28 --> Security Class Initialized
DEBUG - 2016-02-10 12:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:49:28 --> Input Class Initialized
INFO - 2016-02-10 12:49:28 --> Language Class Initialized
INFO - 2016-02-10 12:49:28 --> Loader Class Initialized
INFO - 2016-02-10 12:49:28 --> Helper loaded: url_helper
INFO - 2016-02-10 12:49:28 --> Helper loaded: file_helper
INFO - 2016-02-10 12:49:28 --> Helper loaded: date_helper
INFO - 2016-02-10 12:49:28 --> Helper loaded: form_helper
INFO - 2016-02-10 12:49:28 --> Database Driver Class Initialized
INFO - 2016-02-10 12:49:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:49:29 --> Controller Class Initialized
INFO - 2016-02-10 12:49:29 --> Model Class Initialized
INFO - 2016-02-10 12:49:29 --> Model Class Initialized
INFO - 2016-02-10 12:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:49:29 --> Pagination Class Initialized
INFO - 2016-02-10 15:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:49:29 --> Helper loaded: text_helper
INFO - 2016-02-10 15:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:49:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:49:29 --> Final output sent to browser
DEBUG - 2016-02-10 15:49:29 --> Total execution time: 1.1561
INFO - 2016-02-10 12:50:21 --> Config Class Initialized
INFO - 2016-02-10 12:50:21 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:50:21 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:50:21 --> Utf8 Class Initialized
INFO - 2016-02-10 12:50:21 --> URI Class Initialized
INFO - 2016-02-10 12:50:21 --> Router Class Initialized
INFO - 2016-02-10 12:50:21 --> Output Class Initialized
INFO - 2016-02-10 12:50:21 --> Security Class Initialized
DEBUG - 2016-02-10 12:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:50:21 --> Input Class Initialized
INFO - 2016-02-10 12:50:21 --> Language Class Initialized
INFO - 2016-02-10 12:50:21 --> Loader Class Initialized
INFO - 2016-02-10 12:50:21 --> Helper loaded: url_helper
INFO - 2016-02-10 12:50:21 --> Helper loaded: file_helper
INFO - 2016-02-10 12:50:21 --> Helper loaded: date_helper
INFO - 2016-02-10 12:50:21 --> Helper loaded: form_helper
INFO - 2016-02-10 12:50:21 --> Database Driver Class Initialized
INFO - 2016-02-10 12:50:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:50:22 --> Controller Class Initialized
INFO - 2016-02-10 12:50:22 --> Model Class Initialized
INFO - 2016-02-10 12:50:22 --> Model Class Initialized
INFO - 2016-02-10 12:50:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:50:22 --> Pagination Class Initialized
INFO - 2016-02-10 15:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:50:22 --> Helper loaded: text_helper
INFO - 2016-02-10 15:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:50:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:50:22 --> Final output sent to browser
DEBUG - 2016-02-10 15:50:22 --> Total execution time: 1.1929
INFO - 2016-02-10 12:50:25 --> Config Class Initialized
INFO - 2016-02-10 12:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:50:25 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:50:25 --> Utf8 Class Initialized
INFO - 2016-02-10 12:50:25 --> URI Class Initialized
INFO - 2016-02-10 12:50:25 --> Router Class Initialized
INFO - 2016-02-10 12:50:25 --> Output Class Initialized
INFO - 2016-02-10 12:50:25 --> Security Class Initialized
DEBUG - 2016-02-10 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:50:25 --> Input Class Initialized
INFO - 2016-02-10 12:50:25 --> Language Class Initialized
INFO - 2016-02-10 12:50:25 --> Loader Class Initialized
INFO - 2016-02-10 12:50:25 --> Helper loaded: url_helper
INFO - 2016-02-10 12:50:25 --> Helper loaded: file_helper
INFO - 2016-02-10 12:50:25 --> Helper loaded: date_helper
INFO - 2016-02-10 12:50:25 --> Helper loaded: form_helper
INFO - 2016-02-10 12:50:25 --> Database Driver Class Initialized
INFO - 2016-02-10 12:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:50:26 --> Controller Class Initialized
INFO - 2016-02-10 12:50:26 --> Model Class Initialized
INFO - 2016-02-10 12:50:26 --> Model Class Initialized
INFO - 2016-02-10 12:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:50:26 --> Pagination Class Initialized
ERROR - 2016-02-10 15:50:26 --> Query error: Unknown column 'dis_vote' in 'field list' - Invalid query: UPDATE `vote` SET dis_vote = dis_vote + 1
WHERE `board_id` = '48'
INFO - 2016-02-10 15:50:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-10 12:50:54 --> Config Class Initialized
INFO - 2016-02-10 12:50:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:50:54 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:50:54 --> Utf8 Class Initialized
INFO - 2016-02-10 12:50:54 --> URI Class Initialized
INFO - 2016-02-10 12:50:54 --> Router Class Initialized
INFO - 2016-02-10 12:50:54 --> Output Class Initialized
INFO - 2016-02-10 12:50:54 --> Security Class Initialized
DEBUG - 2016-02-10 12:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:50:54 --> Input Class Initialized
INFO - 2016-02-10 12:50:54 --> Language Class Initialized
INFO - 2016-02-10 12:50:54 --> Loader Class Initialized
INFO - 2016-02-10 12:50:54 --> Helper loaded: url_helper
INFO - 2016-02-10 12:50:54 --> Helper loaded: file_helper
INFO - 2016-02-10 12:50:54 --> Helper loaded: date_helper
INFO - 2016-02-10 12:50:54 --> Helper loaded: form_helper
INFO - 2016-02-10 12:50:54 --> Database Driver Class Initialized
INFO - 2016-02-10 12:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:50:55 --> Controller Class Initialized
INFO - 2016-02-10 12:50:55 --> Model Class Initialized
INFO - 2016-02-10 12:50:55 --> Model Class Initialized
INFO - 2016-02-10 12:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:50:55 --> Pagination Class Initialized
INFO - 2016-02-10 15:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:50:55 --> Helper loaded: text_helper
INFO - 2016-02-10 15:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:50:55 --> Final output sent to browser
DEBUG - 2016-02-10 15:50:55 --> Total execution time: 1.1642
INFO - 2016-02-10 12:50:57 --> Config Class Initialized
INFO - 2016-02-10 12:50:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:50:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:50:57 --> Utf8 Class Initialized
INFO - 2016-02-10 12:50:57 --> URI Class Initialized
INFO - 2016-02-10 12:50:57 --> Router Class Initialized
INFO - 2016-02-10 12:50:57 --> Output Class Initialized
INFO - 2016-02-10 12:50:57 --> Security Class Initialized
DEBUG - 2016-02-10 12:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:50:57 --> Input Class Initialized
INFO - 2016-02-10 12:50:57 --> Language Class Initialized
INFO - 2016-02-10 12:50:57 --> Loader Class Initialized
INFO - 2016-02-10 12:50:57 --> Helper loaded: url_helper
INFO - 2016-02-10 12:50:57 --> Helper loaded: file_helper
INFO - 2016-02-10 12:50:57 --> Helper loaded: date_helper
INFO - 2016-02-10 12:50:57 --> Helper loaded: form_helper
INFO - 2016-02-10 12:50:57 --> Database Driver Class Initialized
INFO - 2016-02-10 12:50:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:50:58 --> Controller Class Initialized
INFO - 2016-02-10 12:50:58 --> Model Class Initialized
INFO - 2016-02-10 12:50:58 --> Model Class Initialized
INFO - 2016-02-10 12:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:50:58 --> Pagination Class Initialized
INFO - 2016-02-10 15:50:58 --> Final output sent to browser
DEBUG - 2016-02-10 15:50:58 --> Total execution time: 1.1953
INFO - 2016-02-10 12:55:14 --> Config Class Initialized
INFO - 2016-02-10 12:55:14 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:55:14 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:55:14 --> Utf8 Class Initialized
INFO - 2016-02-10 12:55:14 --> URI Class Initialized
INFO - 2016-02-10 12:55:14 --> Router Class Initialized
INFO - 2016-02-10 12:55:14 --> Output Class Initialized
INFO - 2016-02-10 12:55:14 --> Security Class Initialized
DEBUG - 2016-02-10 12:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:55:14 --> Input Class Initialized
INFO - 2016-02-10 12:55:14 --> Language Class Initialized
INFO - 2016-02-10 12:55:14 --> Loader Class Initialized
INFO - 2016-02-10 12:55:14 --> Helper loaded: url_helper
INFO - 2016-02-10 12:55:14 --> Helper loaded: file_helper
INFO - 2016-02-10 12:55:14 --> Helper loaded: date_helper
INFO - 2016-02-10 12:55:14 --> Helper loaded: form_helper
INFO - 2016-02-10 12:55:14 --> Database Driver Class Initialized
INFO - 2016-02-10 12:55:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:55:15 --> Controller Class Initialized
INFO - 2016-02-10 12:55:15 --> Model Class Initialized
INFO - 2016-02-10 12:55:15 --> Model Class Initialized
INFO - 2016-02-10 12:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:55:15 --> Pagination Class Initialized
INFO - 2016-02-10 15:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:55:15 --> Helper loaded: text_helper
INFO - 2016-02-10 15:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:55:15 --> Final output sent to browser
DEBUG - 2016-02-10 15:55:15 --> Total execution time: 1.1860
INFO - 2016-02-10 12:59:04 --> Config Class Initialized
INFO - 2016-02-10 12:59:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:59:04 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:59:04 --> Utf8 Class Initialized
INFO - 2016-02-10 12:59:04 --> URI Class Initialized
INFO - 2016-02-10 12:59:04 --> Router Class Initialized
INFO - 2016-02-10 12:59:04 --> Output Class Initialized
INFO - 2016-02-10 12:59:04 --> Security Class Initialized
DEBUG - 2016-02-10 12:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:59:04 --> Input Class Initialized
INFO - 2016-02-10 12:59:04 --> Language Class Initialized
INFO - 2016-02-10 12:59:04 --> Loader Class Initialized
INFO - 2016-02-10 12:59:04 --> Helper loaded: url_helper
INFO - 2016-02-10 12:59:04 --> Helper loaded: file_helper
INFO - 2016-02-10 12:59:04 --> Helper loaded: date_helper
INFO - 2016-02-10 12:59:04 --> Helper loaded: form_helper
INFO - 2016-02-10 12:59:04 --> Database Driver Class Initialized
INFO - 2016-02-10 12:59:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:59:05 --> Controller Class Initialized
INFO - 2016-02-10 12:59:05 --> Model Class Initialized
INFO - 2016-02-10 12:59:05 --> Model Class Initialized
INFO - 2016-02-10 12:59:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:59:05 --> Pagination Class Initialized
INFO - 2016-02-10 15:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 15:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 15:59:05 --> Helper loaded: text_helper
INFO - 2016-02-10 15:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 15:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 15:59:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 15:59:05 --> Final output sent to browser
DEBUG - 2016-02-10 15:59:05 --> Total execution time: 1.1835
INFO - 2016-02-10 12:59:07 --> Config Class Initialized
INFO - 2016-02-10 12:59:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 12:59:07 --> UTF-8 Support Enabled
INFO - 2016-02-10 12:59:07 --> Utf8 Class Initialized
INFO - 2016-02-10 12:59:07 --> URI Class Initialized
INFO - 2016-02-10 12:59:07 --> Router Class Initialized
INFO - 2016-02-10 12:59:07 --> Output Class Initialized
INFO - 2016-02-10 12:59:07 --> Security Class Initialized
DEBUG - 2016-02-10 12:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 12:59:07 --> Input Class Initialized
INFO - 2016-02-10 12:59:07 --> Language Class Initialized
INFO - 2016-02-10 12:59:07 --> Loader Class Initialized
INFO - 2016-02-10 12:59:07 --> Helper loaded: url_helper
INFO - 2016-02-10 12:59:07 --> Helper loaded: file_helper
INFO - 2016-02-10 12:59:07 --> Helper loaded: date_helper
INFO - 2016-02-10 12:59:07 --> Helper loaded: form_helper
INFO - 2016-02-10 12:59:07 --> Database Driver Class Initialized
INFO - 2016-02-10 12:59:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 12:59:08 --> Controller Class Initialized
INFO - 2016-02-10 12:59:08 --> Model Class Initialized
INFO - 2016-02-10 12:59:08 --> Model Class Initialized
INFO - 2016-02-10 12:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 12:59:08 --> Pagination Class Initialized
INFO - 2016-02-10 15:59:08 --> Final output sent to browser
DEBUG - 2016-02-10 15:59:08 --> Total execution time: 1.1456
INFO - 2016-02-10 13:01:53 --> Config Class Initialized
INFO - 2016-02-10 13:01:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:01:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:01:53 --> Utf8 Class Initialized
INFO - 2016-02-10 13:01:53 --> URI Class Initialized
INFO - 2016-02-10 13:01:53 --> Router Class Initialized
INFO - 2016-02-10 13:01:53 --> Output Class Initialized
INFO - 2016-02-10 13:01:53 --> Security Class Initialized
DEBUG - 2016-02-10 13:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:01:53 --> Input Class Initialized
INFO - 2016-02-10 13:01:53 --> Language Class Initialized
INFO - 2016-02-10 13:01:53 --> Loader Class Initialized
INFO - 2016-02-10 13:01:53 --> Helper loaded: url_helper
INFO - 2016-02-10 13:01:53 --> Helper loaded: file_helper
INFO - 2016-02-10 13:01:53 --> Helper loaded: date_helper
INFO - 2016-02-10 13:01:53 --> Helper loaded: form_helper
INFO - 2016-02-10 13:01:53 --> Database Driver Class Initialized
INFO - 2016-02-10 13:01:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:01:54 --> Controller Class Initialized
INFO - 2016-02-10 13:01:54 --> Model Class Initialized
INFO - 2016-02-10 13:01:54 --> Model Class Initialized
INFO - 2016-02-10 13:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:01:54 --> Pagination Class Initialized
INFO - 2016-02-10 16:01:54 --> Final output sent to browser
DEBUG - 2016-02-10 16:01:54 --> Total execution time: 1.1254
INFO - 2016-02-10 13:01:56 --> Config Class Initialized
INFO - 2016-02-10 13:01:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:01:56 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:01:56 --> Utf8 Class Initialized
INFO - 2016-02-10 13:01:56 --> URI Class Initialized
INFO - 2016-02-10 13:01:56 --> Router Class Initialized
INFO - 2016-02-10 13:01:56 --> Output Class Initialized
INFO - 2016-02-10 13:01:56 --> Security Class Initialized
DEBUG - 2016-02-10 13:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:01:56 --> Input Class Initialized
INFO - 2016-02-10 13:01:56 --> Language Class Initialized
INFO - 2016-02-10 13:01:56 --> Loader Class Initialized
INFO - 2016-02-10 13:01:56 --> Helper loaded: url_helper
INFO - 2016-02-10 13:01:56 --> Helper loaded: file_helper
INFO - 2016-02-10 13:01:56 --> Helper loaded: date_helper
INFO - 2016-02-10 13:01:56 --> Helper loaded: form_helper
INFO - 2016-02-10 13:01:56 --> Database Driver Class Initialized
INFO - 2016-02-10 13:01:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:01:57 --> Controller Class Initialized
INFO - 2016-02-10 13:01:57 --> Model Class Initialized
INFO - 2016-02-10 13:01:57 --> Model Class Initialized
INFO - 2016-02-10 13:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:01:57 --> Pagination Class Initialized
INFO - 2016-02-10 16:01:57 --> Final output sent to browser
DEBUG - 2016-02-10 16:01:57 --> Total execution time: 1.0972
INFO - 2016-02-10 13:05:59 --> Config Class Initialized
INFO - 2016-02-10 13:05:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:05:59 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:05:59 --> Utf8 Class Initialized
INFO - 2016-02-10 13:05:59 --> URI Class Initialized
INFO - 2016-02-10 13:05:59 --> Router Class Initialized
INFO - 2016-02-10 13:05:59 --> Output Class Initialized
INFO - 2016-02-10 13:05:59 --> Security Class Initialized
DEBUG - 2016-02-10 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:05:59 --> Input Class Initialized
INFO - 2016-02-10 13:05:59 --> Language Class Initialized
INFO - 2016-02-10 13:05:59 --> Loader Class Initialized
INFO - 2016-02-10 13:05:59 --> Helper loaded: url_helper
INFO - 2016-02-10 13:05:59 --> Helper loaded: file_helper
INFO - 2016-02-10 13:05:59 --> Helper loaded: date_helper
INFO - 2016-02-10 13:05:59 --> Helper loaded: form_helper
INFO - 2016-02-10 13:05:59 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:00 --> Controller Class Initialized
INFO - 2016-02-10 13:06:00 --> Model Class Initialized
INFO - 2016-02-10 13:06:00 --> Model Class Initialized
INFO - 2016-02-10 13:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:00 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:06:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:06:00 --> Helper loaded: text_helper
INFO - 2016-02-10 16:06:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:06:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:06:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:06:00 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:00 --> Total execution time: 1.1848
INFO - 2016-02-10 13:06:01 --> Config Class Initialized
INFO - 2016-02-10 13:06:01 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:06:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:06:02 --> Utf8 Class Initialized
INFO - 2016-02-10 13:06:02 --> URI Class Initialized
INFO - 2016-02-10 13:06:02 --> Router Class Initialized
INFO - 2016-02-10 13:06:02 --> Output Class Initialized
INFO - 2016-02-10 13:06:02 --> Security Class Initialized
DEBUG - 2016-02-10 13:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:06:02 --> Input Class Initialized
INFO - 2016-02-10 13:06:02 --> Language Class Initialized
INFO - 2016-02-10 13:06:02 --> Loader Class Initialized
INFO - 2016-02-10 13:06:02 --> Helper loaded: url_helper
INFO - 2016-02-10 13:06:02 --> Helper loaded: file_helper
INFO - 2016-02-10 13:06:02 --> Helper loaded: date_helper
INFO - 2016-02-10 13:06:02 --> Helper loaded: form_helper
INFO - 2016-02-10 13:06:02 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:03 --> Controller Class Initialized
INFO - 2016-02-10 13:06:03 --> Model Class Initialized
INFO - 2016-02-10 13:06:03 --> Model Class Initialized
INFO - 2016-02-10 13:06:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:03 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:03 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:03 --> Total execution time: 1.1695
INFO - 2016-02-10 13:06:04 --> Config Class Initialized
INFO - 2016-02-10 13:06:04 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:06:04 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:06:04 --> Utf8 Class Initialized
INFO - 2016-02-10 13:06:04 --> URI Class Initialized
INFO - 2016-02-10 13:06:04 --> Router Class Initialized
INFO - 2016-02-10 13:06:04 --> Output Class Initialized
INFO - 2016-02-10 13:06:04 --> Security Class Initialized
DEBUG - 2016-02-10 13:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:06:04 --> Input Class Initialized
INFO - 2016-02-10 13:06:04 --> Language Class Initialized
INFO - 2016-02-10 13:06:04 --> Loader Class Initialized
INFO - 2016-02-10 13:06:04 --> Helper loaded: url_helper
INFO - 2016-02-10 13:06:04 --> Helper loaded: file_helper
INFO - 2016-02-10 13:06:04 --> Helper loaded: date_helper
INFO - 2016-02-10 13:06:04 --> Helper loaded: form_helper
INFO - 2016-02-10 13:06:04 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:05 --> Controller Class Initialized
INFO - 2016-02-10 13:06:05 --> Model Class Initialized
INFO - 2016-02-10 13:06:05 --> Model Class Initialized
INFO - 2016-02-10 13:06:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:05 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:05 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:05 --> Total execution time: 1.1275
INFO - 2016-02-10 13:06:10 --> Config Class Initialized
INFO - 2016-02-10 13:06:10 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:06:10 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:06:10 --> Utf8 Class Initialized
INFO - 2016-02-10 13:06:10 --> URI Class Initialized
INFO - 2016-02-10 13:06:10 --> Router Class Initialized
INFO - 2016-02-10 13:06:10 --> Output Class Initialized
INFO - 2016-02-10 13:06:10 --> Security Class Initialized
DEBUG - 2016-02-10 13:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:06:10 --> Input Class Initialized
INFO - 2016-02-10 13:06:10 --> Language Class Initialized
INFO - 2016-02-10 13:06:10 --> Loader Class Initialized
INFO - 2016-02-10 13:06:10 --> Helper loaded: url_helper
INFO - 2016-02-10 13:06:10 --> Helper loaded: file_helper
INFO - 2016-02-10 13:06:10 --> Helper loaded: date_helper
INFO - 2016-02-10 13:06:10 --> Helper loaded: form_helper
INFO - 2016-02-10 13:06:10 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:11 --> Controller Class Initialized
INFO - 2016-02-10 13:06:11 --> Model Class Initialized
INFO - 2016-02-10 13:06:11 --> Model Class Initialized
INFO - 2016-02-10 13:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:11 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:11 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:11 --> Total execution time: 1.1211
INFO - 2016-02-10 13:06:43 --> Config Class Initialized
INFO - 2016-02-10 13:06:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:06:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:06:43 --> Utf8 Class Initialized
INFO - 2016-02-10 13:06:43 --> URI Class Initialized
INFO - 2016-02-10 13:06:43 --> Router Class Initialized
INFO - 2016-02-10 13:06:43 --> Output Class Initialized
INFO - 2016-02-10 13:06:43 --> Security Class Initialized
DEBUG - 2016-02-10 13:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:06:43 --> Input Class Initialized
INFO - 2016-02-10 13:06:43 --> Language Class Initialized
INFO - 2016-02-10 13:06:43 --> Loader Class Initialized
INFO - 2016-02-10 13:06:43 --> Helper loaded: url_helper
INFO - 2016-02-10 13:06:43 --> Helper loaded: file_helper
INFO - 2016-02-10 13:06:43 --> Helper loaded: date_helper
INFO - 2016-02-10 13:06:43 --> Helper loaded: form_helper
INFO - 2016-02-10 13:06:43 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:44 --> Controller Class Initialized
INFO - 2016-02-10 13:06:44 --> Model Class Initialized
INFO - 2016-02-10 13:06:44 --> Model Class Initialized
INFO - 2016-02-10 13:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:44 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:06:44 --> Helper loaded: text_helper
INFO - 2016-02-10 16:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:06:44 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:44 --> Total execution time: 1.1760
INFO - 2016-02-10 13:06:50 --> Config Class Initialized
INFO - 2016-02-10 13:06:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:06:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:06:50 --> Utf8 Class Initialized
INFO - 2016-02-10 13:06:50 --> URI Class Initialized
INFO - 2016-02-10 13:06:50 --> Router Class Initialized
INFO - 2016-02-10 13:06:50 --> Output Class Initialized
INFO - 2016-02-10 13:06:50 --> Security Class Initialized
DEBUG - 2016-02-10 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:06:50 --> Input Class Initialized
INFO - 2016-02-10 13:06:50 --> Language Class Initialized
INFO - 2016-02-10 13:06:50 --> Loader Class Initialized
INFO - 2016-02-10 13:06:50 --> Helper loaded: url_helper
INFO - 2016-02-10 13:06:50 --> Helper loaded: file_helper
INFO - 2016-02-10 13:06:50 --> Helper loaded: date_helper
INFO - 2016-02-10 13:06:50 --> Helper loaded: form_helper
INFO - 2016-02-10 13:06:50 --> Database Driver Class Initialized
INFO - 2016-02-10 13:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:06:51 --> Controller Class Initialized
INFO - 2016-02-10 13:06:51 --> Model Class Initialized
INFO - 2016-02-10 13:06:51 --> Model Class Initialized
INFO - 2016-02-10 13:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:06:51 --> Pagination Class Initialized
INFO - 2016-02-10 16:06:51 --> Final output sent to browser
DEBUG - 2016-02-10 16:06:51 --> Total execution time: 1.1179
INFO - 2016-02-10 13:09:46 --> Config Class Initialized
INFO - 2016-02-10 13:09:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:09:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:09:46 --> Utf8 Class Initialized
INFO - 2016-02-10 13:09:46 --> URI Class Initialized
INFO - 2016-02-10 13:09:46 --> Router Class Initialized
INFO - 2016-02-10 13:09:46 --> Output Class Initialized
INFO - 2016-02-10 13:09:46 --> Security Class Initialized
DEBUG - 2016-02-10 13:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:09:46 --> Input Class Initialized
INFO - 2016-02-10 13:09:46 --> Language Class Initialized
INFO - 2016-02-10 13:09:46 --> Loader Class Initialized
INFO - 2016-02-10 13:09:46 --> Helper loaded: url_helper
INFO - 2016-02-10 13:09:46 --> Helper loaded: file_helper
INFO - 2016-02-10 13:09:46 --> Helper loaded: date_helper
INFO - 2016-02-10 13:09:46 --> Helper loaded: form_helper
INFO - 2016-02-10 13:09:46 --> Database Driver Class Initialized
INFO - 2016-02-10 13:09:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:09:47 --> Controller Class Initialized
INFO - 2016-02-10 13:09:47 --> Model Class Initialized
INFO - 2016-02-10 13:09:47 --> Model Class Initialized
INFO - 2016-02-10 13:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:09:47 --> Pagination Class Initialized
INFO - 2016-02-10 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:09:47 --> Helper loaded: text_helper
INFO - 2016-02-10 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:09:47 --> Final output sent to browser
DEBUG - 2016-02-10 16:09:47 --> Total execution time: 1.1611
INFO - 2016-02-10 13:09:49 --> Config Class Initialized
INFO - 2016-02-10 13:09:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:09:49 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:09:49 --> Utf8 Class Initialized
INFO - 2016-02-10 13:09:49 --> URI Class Initialized
INFO - 2016-02-10 13:09:49 --> Router Class Initialized
INFO - 2016-02-10 13:09:49 --> Output Class Initialized
INFO - 2016-02-10 13:09:49 --> Security Class Initialized
DEBUG - 2016-02-10 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:09:49 --> Input Class Initialized
INFO - 2016-02-10 13:09:49 --> Language Class Initialized
INFO - 2016-02-10 13:09:49 --> Loader Class Initialized
INFO - 2016-02-10 13:09:49 --> Helper loaded: url_helper
INFO - 2016-02-10 13:09:49 --> Helper loaded: file_helper
INFO - 2016-02-10 13:09:49 --> Helper loaded: date_helper
INFO - 2016-02-10 13:09:49 --> Helper loaded: form_helper
INFO - 2016-02-10 13:09:49 --> Database Driver Class Initialized
INFO - 2016-02-10 13:09:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:09:50 --> Controller Class Initialized
INFO - 2016-02-10 13:09:50 --> Model Class Initialized
INFO - 2016-02-10 13:09:50 --> Model Class Initialized
INFO - 2016-02-10 13:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:09:50 --> Pagination Class Initialized
INFO - 2016-02-10 16:09:50 --> Final output sent to browser
DEBUG - 2016-02-10 16:09:50 --> Total execution time: 1.1121
INFO - 2016-02-10 13:11:28 --> Config Class Initialized
INFO - 2016-02-10 13:11:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:11:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:11:28 --> Utf8 Class Initialized
INFO - 2016-02-10 13:11:28 --> URI Class Initialized
INFO - 2016-02-10 13:11:28 --> Router Class Initialized
INFO - 2016-02-10 13:11:28 --> Output Class Initialized
INFO - 2016-02-10 13:11:28 --> Security Class Initialized
DEBUG - 2016-02-10 13:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:11:28 --> Input Class Initialized
INFO - 2016-02-10 13:11:28 --> Language Class Initialized
INFO - 2016-02-10 13:11:28 --> Loader Class Initialized
INFO - 2016-02-10 13:11:28 --> Helper loaded: url_helper
INFO - 2016-02-10 13:11:28 --> Helper loaded: file_helper
INFO - 2016-02-10 13:11:28 --> Helper loaded: date_helper
INFO - 2016-02-10 13:11:28 --> Helper loaded: form_helper
INFO - 2016-02-10 13:11:28 --> Database Driver Class Initialized
INFO - 2016-02-10 13:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:11:29 --> Controller Class Initialized
INFO - 2016-02-10 13:11:29 --> Model Class Initialized
INFO - 2016-02-10 13:11:29 --> Model Class Initialized
INFO - 2016-02-10 13:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:11:29 --> Pagination Class Initialized
INFO - 2016-02-10 16:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:11:29 --> Helper loaded: text_helper
INFO - 2016-02-10 16:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:11:29 --> Final output sent to browser
DEBUG - 2016-02-10 16:11:29 --> Total execution time: 1.1971
INFO - 2016-02-10 13:11:31 --> Config Class Initialized
INFO - 2016-02-10 13:11:31 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:11:31 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:11:31 --> Utf8 Class Initialized
INFO - 2016-02-10 13:11:31 --> URI Class Initialized
INFO - 2016-02-10 13:11:31 --> Router Class Initialized
INFO - 2016-02-10 13:11:31 --> Output Class Initialized
INFO - 2016-02-10 13:11:31 --> Security Class Initialized
DEBUG - 2016-02-10 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:11:31 --> Input Class Initialized
INFO - 2016-02-10 13:11:31 --> Language Class Initialized
INFO - 2016-02-10 13:11:31 --> Loader Class Initialized
INFO - 2016-02-10 13:11:31 --> Helper loaded: url_helper
INFO - 2016-02-10 13:11:31 --> Helper loaded: file_helper
INFO - 2016-02-10 13:11:31 --> Helper loaded: date_helper
INFO - 2016-02-10 13:11:31 --> Helper loaded: form_helper
INFO - 2016-02-10 13:11:31 --> Database Driver Class Initialized
INFO - 2016-02-10 13:11:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:11:32 --> Controller Class Initialized
INFO - 2016-02-10 13:11:32 --> Model Class Initialized
INFO - 2016-02-10 13:11:32 --> Model Class Initialized
INFO - 2016-02-10 13:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:11:32 --> Pagination Class Initialized
INFO - 2016-02-10 16:11:32 --> Final output sent to browser
DEBUG - 2016-02-10 16:11:32 --> Total execution time: 1.1572
INFO - 2016-02-10 13:15:57 --> Config Class Initialized
INFO - 2016-02-10 13:15:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:15:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:15:57 --> Utf8 Class Initialized
INFO - 2016-02-10 13:15:57 --> URI Class Initialized
INFO - 2016-02-10 13:15:57 --> Router Class Initialized
INFO - 2016-02-10 13:15:57 --> Output Class Initialized
INFO - 2016-02-10 13:15:57 --> Security Class Initialized
DEBUG - 2016-02-10 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:15:57 --> Input Class Initialized
INFO - 2016-02-10 13:15:57 --> Language Class Initialized
INFO - 2016-02-10 13:15:57 --> Loader Class Initialized
INFO - 2016-02-10 13:15:57 --> Helper loaded: url_helper
INFO - 2016-02-10 13:15:57 --> Helper loaded: file_helper
INFO - 2016-02-10 13:15:57 --> Helper loaded: date_helper
INFO - 2016-02-10 13:15:57 --> Helper loaded: form_helper
INFO - 2016-02-10 13:15:57 --> Database Driver Class Initialized
INFO - 2016-02-10 13:15:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:15:58 --> Controller Class Initialized
INFO - 2016-02-10 13:15:58 --> Model Class Initialized
INFO - 2016-02-10 13:15:58 --> Model Class Initialized
INFO - 2016-02-10 13:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:15:58 --> Pagination Class Initialized
INFO - 2016-02-10 16:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:15:58 --> Helper loaded: text_helper
INFO - 2016-02-10 16:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:15:58 --> Final output sent to browser
DEBUG - 2016-02-10 16:15:58 --> Total execution time: 1.2519
INFO - 2016-02-10 13:16:00 --> Config Class Initialized
INFO - 2016-02-10 13:16:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:16:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:16:00 --> Utf8 Class Initialized
INFO - 2016-02-10 13:16:00 --> URI Class Initialized
INFO - 2016-02-10 13:16:00 --> Router Class Initialized
INFO - 2016-02-10 13:16:00 --> Output Class Initialized
INFO - 2016-02-10 13:16:00 --> Security Class Initialized
DEBUG - 2016-02-10 13:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:16:00 --> Input Class Initialized
INFO - 2016-02-10 13:16:00 --> Language Class Initialized
INFO - 2016-02-10 13:16:00 --> Loader Class Initialized
INFO - 2016-02-10 13:16:00 --> Helper loaded: url_helper
INFO - 2016-02-10 13:16:00 --> Helper loaded: file_helper
INFO - 2016-02-10 13:16:00 --> Helper loaded: date_helper
INFO - 2016-02-10 13:16:00 --> Helper loaded: form_helper
INFO - 2016-02-10 13:16:00 --> Database Driver Class Initialized
INFO - 2016-02-10 13:16:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:16:01 --> Controller Class Initialized
INFO - 2016-02-10 13:16:01 --> Model Class Initialized
INFO - 2016-02-10 13:16:01 --> Model Class Initialized
INFO - 2016-02-10 13:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:16:01 --> Pagination Class Initialized
INFO - 2016-02-10 16:16:01 --> Final output sent to browser
DEBUG - 2016-02-10 16:16:01 --> Total execution time: 1.1196
INFO - 2016-02-10 13:16:03 --> Config Class Initialized
INFO - 2016-02-10 13:16:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:16:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:16:03 --> Utf8 Class Initialized
INFO - 2016-02-10 13:16:03 --> URI Class Initialized
INFO - 2016-02-10 13:16:03 --> Router Class Initialized
INFO - 2016-02-10 13:16:03 --> Output Class Initialized
INFO - 2016-02-10 13:16:03 --> Security Class Initialized
DEBUG - 2016-02-10 13:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:16:03 --> Input Class Initialized
INFO - 2016-02-10 13:16:03 --> Language Class Initialized
INFO - 2016-02-10 13:16:03 --> Loader Class Initialized
INFO - 2016-02-10 13:16:03 --> Helper loaded: url_helper
INFO - 2016-02-10 13:16:03 --> Helper loaded: file_helper
INFO - 2016-02-10 13:16:03 --> Helper loaded: date_helper
INFO - 2016-02-10 13:16:03 --> Helper loaded: form_helper
INFO - 2016-02-10 13:16:03 --> Database Driver Class Initialized
INFO - 2016-02-10 13:16:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:16:04 --> Controller Class Initialized
INFO - 2016-02-10 13:16:04 --> Model Class Initialized
INFO - 2016-02-10 13:16:04 --> Model Class Initialized
INFO - 2016-02-10 13:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:16:04 --> Pagination Class Initialized
INFO - 2016-02-10 16:16:04 --> Final output sent to browser
DEBUG - 2016-02-10 16:16:04 --> Total execution time: 1.0971
INFO - 2016-02-10 13:16:58 --> Config Class Initialized
INFO - 2016-02-10 13:16:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:16:58 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:16:58 --> Utf8 Class Initialized
INFO - 2016-02-10 13:16:58 --> URI Class Initialized
INFO - 2016-02-10 13:16:58 --> Router Class Initialized
INFO - 2016-02-10 13:16:58 --> Output Class Initialized
INFO - 2016-02-10 13:16:58 --> Security Class Initialized
DEBUG - 2016-02-10 13:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:16:58 --> Input Class Initialized
INFO - 2016-02-10 13:16:58 --> Language Class Initialized
INFO - 2016-02-10 13:16:58 --> Loader Class Initialized
INFO - 2016-02-10 13:16:58 --> Helper loaded: url_helper
INFO - 2016-02-10 13:16:58 --> Helper loaded: file_helper
INFO - 2016-02-10 13:16:58 --> Helper loaded: date_helper
INFO - 2016-02-10 13:16:58 --> Helper loaded: form_helper
INFO - 2016-02-10 13:16:58 --> Database Driver Class Initialized
INFO - 2016-02-10 13:16:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:16:59 --> Controller Class Initialized
INFO - 2016-02-10 13:16:59 --> Model Class Initialized
INFO - 2016-02-10 13:16:59 --> Model Class Initialized
INFO - 2016-02-10 13:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:16:59 --> Pagination Class Initialized
INFO - 2016-02-10 16:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:16:59 --> Helper loaded: text_helper
INFO - 2016-02-10 16:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:16:59 --> Final output sent to browser
DEBUG - 2016-02-10 16:16:59 --> Total execution time: 1.1412
INFO - 2016-02-10 13:17:00 --> Config Class Initialized
INFO - 2016-02-10 13:17:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:17:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:17:00 --> Utf8 Class Initialized
INFO - 2016-02-10 13:17:00 --> URI Class Initialized
INFO - 2016-02-10 13:17:00 --> Router Class Initialized
INFO - 2016-02-10 13:17:00 --> Output Class Initialized
INFO - 2016-02-10 13:17:00 --> Security Class Initialized
DEBUG - 2016-02-10 13:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:17:00 --> Input Class Initialized
INFO - 2016-02-10 13:17:00 --> Language Class Initialized
INFO - 2016-02-10 13:17:00 --> Loader Class Initialized
INFO - 2016-02-10 13:17:00 --> Helper loaded: url_helper
INFO - 2016-02-10 13:17:00 --> Helper loaded: file_helper
INFO - 2016-02-10 13:17:00 --> Helper loaded: date_helper
INFO - 2016-02-10 13:17:00 --> Helper loaded: form_helper
INFO - 2016-02-10 13:17:00 --> Database Driver Class Initialized
INFO - 2016-02-10 13:17:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:17:01 --> Controller Class Initialized
INFO - 2016-02-10 13:17:01 --> Model Class Initialized
INFO - 2016-02-10 13:17:01 --> Model Class Initialized
INFO - 2016-02-10 13:17:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:17:01 --> Pagination Class Initialized
INFO - 2016-02-10 16:17:01 --> Final output sent to browser
DEBUG - 2016-02-10 16:17:01 --> Total execution time: 1.1254
INFO - 2016-02-10 13:17:03 --> Config Class Initialized
INFO - 2016-02-10 13:17:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:17:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:17:03 --> Utf8 Class Initialized
INFO - 2016-02-10 13:17:03 --> URI Class Initialized
INFO - 2016-02-10 13:17:03 --> Router Class Initialized
INFO - 2016-02-10 13:17:03 --> Output Class Initialized
INFO - 2016-02-10 13:17:03 --> Security Class Initialized
DEBUG - 2016-02-10 13:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:17:03 --> Input Class Initialized
INFO - 2016-02-10 13:17:03 --> Language Class Initialized
INFO - 2016-02-10 13:17:03 --> Loader Class Initialized
INFO - 2016-02-10 13:17:03 --> Helper loaded: url_helper
INFO - 2016-02-10 13:17:03 --> Helper loaded: file_helper
INFO - 2016-02-10 13:17:03 --> Helper loaded: date_helper
INFO - 2016-02-10 13:17:03 --> Helper loaded: form_helper
INFO - 2016-02-10 13:17:03 --> Database Driver Class Initialized
INFO - 2016-02-10 13:17:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:17:04 --> Controller Class Initialized
INFO - 2016-02-10 13:17:04 --> Model Class Initialized
INFO - 2016-02-10 13:17:04 --> Model Class Initialized
INFO - 2016-02-10 13:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:17:04 --> Pagination Class Initialized
INFO - 2016-02-10 16:17:04 --> Final output sent to browser
DEBUG - 2016-02-10 16:17:04 --> Total execution time: 1.1486
INFO - 2016-02-10 13:17:41 --> Config Class Initialized
INFO - 2016-02-10 13:17:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:17:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:17:41 --> Utf8 Class Initialized
INFO - 2016-02-10 13:17:41 --> URI Class Initialized
INFO - 2016-02-10 13:17:41 --> Router Class Initialized
INFO - 2016-02-10 13:17:41 --> Output Class Initialized
INFO - 2016-02-10 13:17:41 --> Security Class Initialized
DEBUG - 2016-02-10 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:17:41 --> Input Class Initialized
INFO - 2016-02-10 13:17:41 --> Language Class Initialized
INFO - 2016-02-10 13:17:41 --> Loader Class Initialized
INFO - 2016-02-10 13:17:41 --> Helper loaded: url_helper
INFO - 2016-02-10 13:17:41 --> Helper loaded: file_helper
INFO - 2016-02-10 13:17:41 --> Helper loaded: date_helper
INFO - 2016-02-10 13:17:42 --> Helper loaded: form_helper
INFO - 2016-02-10 13:17:42 --> Database Driver Class Initialized
INFO - 2016-02-10 13:17:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:17:43 --> Controller Class Initialized
INFO - 2016-02-10 13:17:43 --> Model Class Initialized
INFO - 2016-02-10 13:17:43 --> Model Class Initialized
INFO - 2016-02-10 13:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:17:43 --> Pagination Class Initialized
INFO - 2016-02-10 16:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:17:43 --> Helper loaded: text_helper
INFO - 2016-02-10 16:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:17:43 --> Final output sent to browser
DEBUG - 2016-02-10 16:17:43 --> Total execution time: 1.1619
INFO - 2016-02-10 13:20:03 --> Config Class Initialized
INFO - 2016-02-10 13:20:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:20:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:20:03 --> Utf8 Class Initialized
INFO - 2016-02-10 13:20:03 --> URI Class Initialized
INFO - 2016-02-10 13:20:03 --> Router Class Initialized
INFO - 2016-02-10 13:20:03 --> Output Class Initialized
INFO - 2016-02-10 13:20:03 --> Security Class Initialized
DEBUG - 2016-02-10 13:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:20:03 --> Input Class Initialized
INFO - 2016-02-10 13:20:03 --> Language Class Initialized
INFO - 2016-02-10 13:20:03 --> Loader Class Initialized
INFO - 2016-02-10 13:20:03 --> Helper loaded: url_helper
INFO - 2016-02-10 13:20:03 --> Helper loaded: file_helper
INFO - 2016-02-10 13:20:03 --> Helper loaded: date_helper
INFO - 2016-02-10 13:20:03 --> Helper loaded: form_helper
INFO - 2016-02-10 13:20:03 --> Database Driver Class Initialized
INFO - 2016-02-10 13:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:20:04 --> Controller Class Initialized
INFO - 2016-02-10 13:20:04 --> Model Class Initialized
INFO - 2016-02-10 13:20:04 --> Model Class Initialized
INFO - 2016-02-10 13:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:20:04 --> Pagination Class Initialized
INFO - 2016-02-10 16:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:20:04 --> Helper loaded: text_helper
INFO - 2016-02-10 16:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:20:04 --> Final output sent to browser
DEBUG - 2016-02-10 16:20:04 --> Total execution time: 1.2091
INFO - 2016-02-10 13:20:06 --> Config Class Initialized
INFO - 2016-02-10 13:20:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:20:06 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:20:06 --> Utf8 Class Initialized
INFO - 2016-02-10 13:20:06 --> URI Class Initialized
INFO - 2016-02-10 13:20:06 --> Router Class Initialized
INFO - 2016-02-10 13:20:06 --> Output Class Initialized
INFO - 2016-02-10 13:20:06 --> Security Class Initialized
DEBUG - 2016-02-10 13:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:20:06 --> Input Class Initialized
INFO - 2016-02-10 13:20:06 --> Language Class Initialized
INFO - 2016-02-10 13:20:06 --> Loader Class Initialized
INFO - 2016-02-10 13:20:06 --> Helper loaded: url_helper
INFO - 2016-02-10 13:20:06 --> Helper loaded: file_helper
INFO - 2016-02-10 13:20:06 --> Helper loaded: date_helper
INFO - 2016-02-10 13:20:06 --> Helper loaded: form_helper
INFO - 2016-02-10 13:20:06 --> Database Driver Class Initialized
INFO - 2016-02-10 13:20:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:20:07 --> Controller Class Initialized
INFO - 2016-02-10 13:20:07 --> Model Class Initialized
INFO - 2016-02-10 13:20:07 --> Model Class Initialized
INFO - 2016-02-10 13:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:20:07 --> Pagination Class Initialized
INFO - 2016-02-10 16:20:07 --> Final output sent to browser
DEBUG - 2016-02-10 16:20:07 --> Total execution time: 1.1027
INFO - 2016-02-10 13:30:13 --> Config Class Initialized
INFO - 2016-02-10 13:30:13 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:30:13 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:30:13 --> Utf8 Class Initialized
INFO - 2016-02-10 13:30:13 --> URI Class Initialized
INFO - 2016-02-10 13:30:13 --> Router Class Initialized
INFO - 2016-02-10 13:30:13 --> Output Class Initialized
INFO - 2016-02-10 13:30:13 --> Security Class Initialized
DEBUG - 2016-02-10 13:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:30:13 --> Input Class Initialized
INFO - 2016-02-10 13:30:13 --> Language Class Initialized
INFO - 2016-02-10 13:30:13 --> Loader Class Initialized
INFO - 2016-02-10 13:30:13 --> Helper loaded: url_helper
INFO - 2016-02-10 13:30:13 --> Helper loaded: file_helper
INFO - 2016-02-10 13:30:13 --> Helper loaded: date_helper
INFO - 2016-02-10 13:30:13 --> Helper loaded: form_helper
INFO - 2016-02-10 13:30:13 --> Database Driver Class Initialized
INFO - 2016-02-10 13:30:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:30:14 --> Controller Class Initialized
INFO - 2016-02-10 13:30:14 --> Model Class Initialized
INFO - 2016-02-10 13:30:14 --> Model Class Initialized
INFO - 2016-02-10 13:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:30:14 --> Pagination Class Initialized
INFO - 2016-02-10 16:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:30:14 --> Helper loaded: text_helper
INFO - 2016-02-10 16:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:30:14 --> Final output sent to browser
DEBUG - 2016-02-10 16:30:14 --> Total execution time: 1.1658
INFO - 2016-02-10 13:30:15 --> Config Class Initialized
INFO - 2016-02-10 13:30:15 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:30:15 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:30:15 --> Utf8 Class Initialized
INFO - 2016-02-10 13:30:15 --> URI Class Initialized
INFO - 2016-02-10 13:30:15 --> Router Class Initialized
INFO - 2016-02-10 13:30:15 --> Output Class Initialized
INFO - 2016-02-10 13:30:15 --> Security Class Initialized
DEBUG - 2016-02-10 13:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:30:15 --> Input Class Initialized
INFO - 2016-02-10 13:30:15 --> Language Class Initialized
INFO - 2016-02-10 13:30:15 --> Loader Class Initialized
INFO - 2016-02-10 13:30:15 --> Helper loaded: url_helper
INFO - 2016-02-10 13:30:15 --> Helper loaded: file_helper
INFO - 2016-02-10 13:30:15 --> Helper loaded: date_helper
INFO - 2016-02-10 13:30:15 --> Helper loaded: form_helper
INFO - 2016-02-10 13:30:15 --> Database Driver Class Initialized
INFO - 2016-02-10 13:30:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:30:16 --> Controller Class Initialized
INFO - 2016-02-10 13:30:16 --> Model Class Initialized
INFO - 2016-02-10 13:30:16 --> Model Class Initialized
INFO - 2016-02-10 13:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:30:16 --> Pagination Class Initialized
INFO - 2016-02-10 16:30:17 --> Final output sent to browser
DEBUG - 2016-02-10 16:30:17 --> Total execution time: 1.3245
INFO - 2016-02-10 13:30:17 --> Config Class Initialized
INFO - 2016-02-10 13:30:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:30:17 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:30:17 --> Utf8 Class Initialized
INFO - 2016-02-10 13:30:17 --> URI Class Initialized
INFO - 2016-02-10 13:30:17 --> Router Class Initialized
INFO - 2016-02-10 13:30:17 --> Output Class Initialized
INFO - 2016-02-10 13:30:17 --> Security Class Initialized
DEBUG - 2016-02-10 13:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:30:17 --> Input Class Initialized
INFO - 2016-02-10 13:30:17 --> Language Class Initialized
INFO - 2016-02-10 13:30:17 --> Loader Class Initialized
INFO - 2016-02-10 13:30:17 --> Helper loaded: url_helper
INFO - 2016-02-10 13:30:17 --> Helper loaded: file_helper
INFO - 2016-02-10 13:30:17 --> Helper loaded: date_helper
INFO - 2016-02-10 13:30:17 --> Helper loaded: form_helper
INFO - 2016-02-10 13:30:17 --> Database Driver Class Initialized
INFO - 2016-02-10 13:30:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:30:18 --> Controller Class Initialized
INFO - 2016-02-10 13:30:18 --> Model Class Initialized
INFO - 2016-02-10 13:30:18 --> Model Class Initialized
INFO - 2016-02-10 13:30:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:30:18 --> Pagination Class Initialized
INFO - 2016-02-10 16:30:18 --> Final output sent to browser
DEBUG - 2016-02-10 16:30:18 --> Total execution time: 1.1224
INFO - 2016-02-10 13:33:02 --> Config Class Initialized
INFO - 2016-02-10 13:33:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:33:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:33:02 --> Utf8 Class Initialized
INFO - 2016-02-10 13:33:02 --> URI Class Initialized
DEBUG - 2016-02-10 13:33:02 --> No URI present. Default controller set.
INFO - 2016-02-10 13:33:02 --> Router Class Initialized
INFO - 2016-02-10 13:33:02 --> Output Class Initialized
INFO - 2016-02-10 13:33:02 --> Security Class Initialized
DEBUG - 2016-02-10 13:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:33:02 --> Input Class Initialized
INFO - 2016-02-10 13:33:02 --> Language Class Initialized
INFO - 2016-02-10 13:33:02 --> Loader Class Initialized
INFO - 2016-02-10 13:33:02 --> Helper loaded: url_helper
INFO - 2016-02-10 13:33:02 --> Helper loaded: file_helper
INFO - 2016-02-10 13:33:02 --> Helper loaded: date_helper
INFO - 2016-02-10 13:33:02 --> Helper loaded: form_helper
INFO - 2016-02-10 13:33:02 --> Database Driver Class Initialized
INFO - 2016-02-10 13:33:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:33:03 --> Controller Class Initialized
INFO - 2016-02-10 13:33:03 --> Model Class Initialized
INFO - 2016-02-10 13:33:03 --> Model Class Initialized
INFO - 2016-02-10 13:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:33:03 --> Pagination Class Initialized
INFO - 2016-02-10 16:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 16:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:33:03 --> Final output sent to browser
DEBUG - 2016-02-10 16:33:03 --> Total execution time: 1.1164
INFO - 2016-02-10 13:33:06 --> Config Class Initialized
INFO - 2016-02-10 13:33:06 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:33:06 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:33:06 --> Utf8 Class Initialized
INFO - 2016-02-10 13:33:06 --> URI Class Initialized
INFO - 2016-02-10 13:33:06 --> Router Class Initialized
INFO - 2016-02-10 13:33:06 --> Output Class Initialized
INFO - 2016-02-10 13:33:06 --> Security Class Initialized
DEBUG - 2016-02-10 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:33:06 --> Input Class Initialized
INFO - 2016-02-10 13:33:06 --> Language Class Initialized
INFO - 2016-02-10 13:33:06 --> Loader Class Initialized
INFO - 2016-02-10 13:33:06 --> Helper loaded: url_helper
INFO - 2016-02-10 13:33:06 --> Helper loaded: file_helper
INFO - 2016-02-10 13:33:06 --> Helper loaded: date_helper
INFO - 2016-02-10 13:33:06 --> Helper loaded: form_helper
INFO - 2016-02-10 13:33:06 --> Database Driver Class Initialized
INFO - 2016-02-10 13:33:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:33:07 --> Controller Class Initialized
INFO - 2016-02-10 13:33:07 --> Model Class Initialized
INFO - 2016-02-10 13:33:07 --> Model Class Initialized
INFO - 2016-02-10 13:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:33:07 --> Pagination Class Initialized
INFO - 2016-02-10 16:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 16:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 16:33:07 --> Helper loaded: text_helper
INFO - 2016-02-10 16:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 16:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 16:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 16:33:07 --> Final output sent to browser
DEBUG - 2016-02-10 16:33:07 --> Total execution time: 1.1475
INFO - 2016-02-10 13:33:17 --> Config Class Initialized
INFO - 2016-02-10 13:33:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:33:17 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:33:17 --> Utf8 Class Initialized
INFO - 2016-02-10 13:33:17 --> URI Class Initialized
INFO - 2016-02-10 13:33:17 --> Router Class Initialized
INFO - 2016-02-10 13:33:17 --> Output Class Initialized
INFO - 2016-02-10 13:33:17 --> Security Class Initialized
DEBUG - 2016-02-10 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:33:17 --> Input Class Initialized
INFO - 2016-02-10 13:33:17 --> Language Class Initialized
INFO - 2016-02-10 13:33:17 --> Loader Class Initialized
INFO - 2016-02-10 13:33:17 --> Helper loaded: url_helper
INFO - 2016-02-10 13:33:17 --> Helper loaded: file_helper
INFO - 2016-02-10 13:33:17 --> Helper loaded: date_helper
INFO - 2016-02-10 13:33:17 --> Helper loaded: form_helper
INFO - 2016-02-10 13:33:17 --> Database Driver Class Initialized
INFO - 2016-02-10 13:33:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:33:18 --> Controller Class Initialized
INFO - 2016-02-10 13:33:18 --> Model Class Initialized
INFO - 2016-02-10 13:33:18 --> Model Class Initialized
INFO - 2016-02-10 13:33:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:33:18 --> Pagination Class Initialized
INFO - 2016-02-10 16:33:18 --> Final output sent to browser
DEBUG - 2016-02-10 16:33:18 --> Total execution time: 1.1086
INFO - 2016-02-10 13:33:20 --> Config Class Initialized
INFO - 2016-02-10 13:33:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:33:20 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:33:20 --> Utf8 Class Initialized
INFO - 2016-02-10 13:33:20 --> URI Class Initialized
INFO - 2016-02-10 13:33:20 --> Router Class Initialized
INFO - 2016-02-10 13:33:20 --> Output Class Initialized
INFO - 2016-02-10 13:33:20 --> Security Class Initialized
DEBUG - 2016-02-10 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:33:20 --> Input Class Initialized
INFO - 2016-02-10 13:33:20 --> Language Class Initialized
INFO - 2016-02-10 13:33:20 --> Loader Class Initialized
INFO - 2016-02-10 13:33:20 --> Helper loaded: url_helper
INFO - 2016-02-10 13:33:20 --> Helper loaded: file_helper
INFO - 2016-02-10 13:33:20 --> Helper loaded: date_helper
INFO - 2016-02-10 13:33:20 --> Helper loaded: form_helper
INFO - 2016-02-10 13:33:20 --> Database Driver Class Initialized
INFO - 2016-02-10 13:33:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:33:21 --> Controller Class Initialized
INFO - 2016-02-10 13:33:21 --> Model Class Initialized
INFO - 2016-02-10 13:33:21 --> Model Class Initialized
INFO - 2016-02-10 13:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:33:21 --> Pagination Class Initialized
INFO - 2016-02-10 16:33:21 --> Final output sent to browser
DEBUG - 2016-02-10 16:33:21 --> Total execution time: 1.1482
INFO - 2016-02-10 13:33:22 --> Config Class Initialized
INFO - 2016-02-10 13:33:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 13:33:22 --> UTF-8 Support Enabled
INFO - 2016-02-10 13:33:22 --> Utf8 Class Initialized
INFO - 2016-02-10 13:33:22 --> URI Class Initialized
INFO - 2016-02-10 13:33:22 --> Router Class Initialized
INFO - 2016-02-10 13:33:22 --> Output Class Initialized
INFO - 2016-02-10 13:33:22 --> Security Class Initialized
DEBUG - 2016-02-10 13:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 13:33:22 --> Input Class Initialized
INFO - 2016-02-10 13:33:22 --> Language Class Initialized
INFO - 2016-02-10 13:33:22 --> Loader Class Initialized
INFO - 2016-02-10 13:33:22 --> Helper loaded: url_helper
INFO - 2016-02-10 13:33:22 --> Helper loaded: file_helper
INFO - 2016-02-10 13:33:22 --> Helper loaded: date_helper
INFO - 2016-02-10 13:33:22 --> Helper loaded: form_helper
INFO - 2016-02-10 13:33:22 --> Database Driver Class Initialized
INFO - 2016-02-10 13:33:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 13:33:23 --> Controller Class Initialized
INFO - 2016-02-10 13:33:23 --> Model Class Initialized
INFO - 2016-02-10 13:33:23 --> Model Class Initialized
INFO - 2016-02-10 13:33:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 13:33:23 --> Pagination Class Initialized
INFO - 2016-02-10 16:33:24 --> Final output sent to browser
DEBUG - 2016-02-10 16:33:24 --> Total execution time: 1.2551
INFO - 2016-02-10 14:11:28 --> Config Class Initialized
INFO - 2016-02-10 14:11:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:11:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:11:28 --> Utf8 Class Initialized
INFO - 2016-02-10 14:11:28 --> URI Class Initialized
DEBUG - 2016-02-10 14:11:28 --> No URI present. Default controller set.
INFO - 2016-02-10 14:11:28 --> Router Class Initialized
INFO - 2016-02-10 14:11:28 --> Output Class Initialized
INFO - 2016-02-10 14:11:28 --> Security Class Initialized
DEBUG - 2016-02-10 14:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:11:28 --> Input Class Initialized
INFO - 2016-02-10 14:11:28 --> Language Class Initialized
INFO - 2016-02-10 14:11:28 --> Loader Class Initialized
INFO - 2016-02-10 14:11:28 --> Helper loaded: url_helper
INFO - 2016-02-10 14:11:28 --> Helper loaded: file_helper
INFO - 2016-02-10 14:11:28 --> Helper loaded: date_helper
INFO - 2016-02-10 14:11:28 --> Helper loaded: form_helper
INFO - 2016-02-10 14:11:28 --> Database Driver Class Initialized
INFO - 2016-02-10 14:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:11:29 --> Controller Class Initialized
INFO - 2016-02-10 14:11:29 --> Model Class Initialized
INFO - 2016-02-10 14:11:29 --> Model Class Initialized
INFO - 2016-02-10 14:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:11:29 --> Pagination Class Initialized
INFO - 2016-02-10 17:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:11:29 --> Final output sent to browser
DEBUG - 2016-02-10 17:11:29 --> Total execution time: 1.1445
INFO - 2016-02-10 14:11:47 --> Config Class Initialized
INFO - 2016-02-10 14:11:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:11:47 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:11:47 --> Utf8 Class Initialized
INFO - 2016-02-10 14:11:47 --> URI Class Initialized
INFO - 2016-02-10 14:11:47 --> Router Class Initialized
INFO - 2016-02-10 14:11:47 --> Output Class Initialized
INFO - 2016-02-10 14:11:47 --> Security Class Initialized
DEBUG - 2016-02-10 14:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:11:47 --> Input Class Initialized
INFO - 2016-02-10 14:11:47 --> Language Class Initialized
INFO - 2016-02-10 14:11:47 --> Loader Class Initialized
INFO - 2016-02-10 14:11:47 --> Helper loaded: url_helper
INFO - 2016-02-10 14:11:47 --> Helper loaded: file_helper
INFO - 2016-02-10 14:11:47 --> Helper loaded: date_helper
INFO - 2016-02-10 14:11:47 --> Helper loaded: form_helper
INFO - 2016-02-10 14:11:47 --> Database Driver Class Initialized
INFO - 2016-02-10 14:11:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:11:48 --> Controller Class Initialized
INFO - 2016-02-10 14:11:48 --> Model Class Initialized
INFO - 2016-02-10 14:11:48 --> Model Class Initialized
INFO - 2016-02-10 14:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:11:48 --> Pagination Class Initialized
INFO - 2016-02-10 17:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:11:48 --> Helper loaded: text_helper
INFO - 2016-02-10 17:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:11:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:11:48 --> Final output sent to browser
DEBUG - 2016-02-10 17:11:48 --> Total execution time: 1.1732
INFO - 2016-02-10 14:12:03 --> Config Class Initialized
INFO - 2016-02-10 14:12:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:12:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:12:03 --> Utf8 Class Initialized
INFO - 2016-02-10 14:12:03 --> URI Class Initialized
DEBUG - 2016-02-10 14:12:03 --> No URI present. Default controller set.
INFO - 2016-02-10 14:12:03 --> Router Class Initialized
INFO - 2016-02-10 14:12:03 --> Output Class Initialized
INFO - 2016-02-10 14:12:03 --> Security Class Initialized
DEBUG - 2016-02-10 14:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:12:03 --> Input Class Initialized
INFO - 2016-02-10 14:12:03 --> Language Class Initialized
INFO - 2016-02-10 14:12:03 --> Loader Class Initialized
INFO - 2016-02-10 14:12:03 --> Helper loaded: url_helper
INFO - 2016-02-10 14:12:03 --> Helper loaded: file_helper
INFO - 2016-02-10 14:12:03 --> Helper loaded: date_helper
INFO - 2016-02-10 14:12:03 --> Helper loaded: form_helper
INFO - 2016-02-10 14:12:03 --> Database Driver Class Initialized
INFO - 2016-02-10 14:12:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:12:04 --> Controller Class Initialized
INFO - 2016-02-10 14:12:04 --> Model Class Initialized
INFO - 2016-02-10 14:12:04 --> Model Class Initialized
INFO - 2016-02-10 14:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:12:04 --> Pagination Class Initialized
INFO - 2016-02-10 17:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:12:04 --> Final output sent to browser
DEBUG - 2016-02-10 17:12:04 --> Total execution time: 1.1237
INFO - 2016-02-10 14:13:37 --> Config Class Initialized
INFO - 2016-02-10 14:13:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:13:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:13:37 --> Utf8 Class Initialized
INFO - 2016-02-10 14:13:37 --> URI Class Initialized
INFO - 2016-02-10 14:13:37 --> Router Class Initialized
INFO - 2016-02-10 14:13:37 --> Output Class Initialized
INFO - 2016-02-10 14:13:37 --> Security Class Initialized
DEBUG - 2016-02-10 14:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:13:37 --> Input Class Initialized
INFO - 2016-02-10 14:13:37 --> Language Class Initialized
INFO - 2016-02-10 14:13:37 --> Loader Class Initialized
INFO - 2016-02-10 14:13:37 --> Helper loaded: url_helper
INFO - 2016-02-10 14:13:37 --> Helper loaded: file_helper
INFO - 2016-02-10 14:13:37 --> Helper loaded: date_helper
INFO - 2016-02-10 14:13:37 --> Helper loaded: form_helper
INFO - 2016-02-10 14:13:37 --> Database Driver Class Initialized
INFO - 2016-02-10 14:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:13:38 --> Controller Class Initialized
INFO - 2016-02-10 14:13:38 --> Model Class Initialized
INFO - 2016-02-10 14:13:38 --> Model Class Initialized
INFO - 2016-02-10 14:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:13:38 --> Pagination Class Initialized
INFO - 2016-02-10 17:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:13:38 --> Final output sent to browser
DEBUG - 2016-02-10 17:13:38 --> Total execution time: 1.1400
INFO - 2016-02-10 14:13:40 --> Config Class Initialized
INFO - 2016-02-10 14:13:40 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:13:40 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:13:40 --> Utf8 Class Initialized
INFO - 2016-02-10 14:13:40 --> URI Class Initialized
INFO - 2016-02-10 14:13:40 --> Router Class Initialized
INFO - 2016-02-10 14:13:40 --> Output Class Initialized
INFO - 2016-02-10 14:13:40 --> Security Class Initialized
DEBUG - 2016-02-10 14:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:13:40 --> Input Class Initialized
INFO - 2016-02-10 14:13:40 --> Language Class Initialized
INFO - 2016-02-10 14:13:40 --> Loader Class Initialized
INFO - 2016-02-10 14:13:40 --> Helper loaded: url_helper
INFO - 2016-02-10 14:13:40 --> Helper loaded: file_helper
INFO - 2016-02-10 14:13:40 --> Helper loaded: date_helper
INFO - 2016-02-10 14:13:40 --> Helper loaded: form_helper
INFO - 2016-02-10 14:13:40 --> Database Driver Class Initialized
INFO - 2016-02-10 14:13:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:13:41 --> Controller Class Initialized
INFO - 2016-02-10 14:13:41 --> Model Class Initialized
INFO - 2016-02-10 14:13:41 --> Model Class Initialized
INFO - 2016-02-10 14:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:13:41 --> Pagination Class Initialized
INFO - 2016-02-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:13:41 --> Helper loaded: text_helper
INFO - 2016-02-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:13:41 --> Final output sent to browser
DEBUG - 2016-02-10 17:13:41 --> Total execution time: 1.2194
INFO - 2016-02-10 14:13:43 --> Config Class Initialized
INFO - 2016-02-10 14:13:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:13:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:13:43 --> Utf8 Class Initialized
INFO - 2016-02-10 14:13:43 --> URI Class Initialized
INFO - 2016-02-10 14:13:43 --> Router Class Initialized
INFO - 2016-02-10 14:13:43 --> Output Class Initialized
INFO - 2016-02-10 14:13:43 --> Security Class Initialized
DEBUG - 2016-02-10 14:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:13:43 --> Input Class Initialized
INFO - 2016-02-10 14:13:43 --> Language Class Initialized
INFO - 2016-02-10 14:13:43 --> Loader Class Initialized
INFO - 2016-02-10 14:13:43 --> Helper loaded: url_helper
INFO - 2016-02-10 14:13:43 --> Helper loaded: file_helper
INFO - 2016-02-10 14:13:43 --> Helper loaded: date_helper
INFO - 2016-02-10 14:13:43 --> Helper loaded: form_helper
INFO - 2016-02-10 14:13:43 --> Database Driver Class Initialized
INFO - 2016-02-10 14:13:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:13:44 --> Controller Class Initialized
INFO - 2016-02-10 14:13:44 --> Model Class Initialized
INFO - 2016-02-10 14:13:44 --> Model Class Initialized
INFO - 2016-02-10 14:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:13:44 --> Pagination Class Initialized
INFO - 2016-02-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:13:45 --> Final output sent to browser
DEBUG - 2016-02-10 17:13:45 --> Total execution time: 1.1408
INFO - 2016-02-10 14:13:46 --> Config Class Initialized
INFO - 2016-02-10 14:13:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:13:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:13:46 --> Utf8 Class Initialized
INFO - 2016-02-10 14:13:46 --> URI Class Initialized
INFO - 2016-02-10 14:13:46 --> Router Class Initialized
INFO - 2016-02-10 14:13:46 --> Output Class Initialized
INFO - 2016-02-10 14:13:46 --> Security Class Initialized
DEBUG - 2016-02-10 14:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:13:46 --> Input Class Initialized
INFO - 2016-02-10 14:13:46 --> Language Class Initialized
INFO - 2016-02-10 14:13:46 --> Loader Class Initialized
INFO - 2016-02-10 14:13:46 --> Helper loaded: url_helper
INFO - 2016-02-10 14:13:46 --> Helper loaded: file_helper
INFO - 2016-02-10 14:13:46 --> Helper loaded: date_helper
INFO - 2016-02-10 14:13:46 --> Helper loaded: form_helper
INFO - 2016-02-10 14:13:46 --> Database Driver Class Initialized
INFO - 2016-02-10 14:13:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:13:47 --> Controller Class Initialized
INFO - 2016-02-10 14:13:47 --> Model Class Initialized
INFO - 2016-02-10 14:13:47 --> Model Class Initialized
INFO - 2016-02-10 14:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:13:47 --> Pagination Class Initialized
INFO - 2016-02-10 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:13:47 --> Helper loaded: text_helper
INFO - 2016-02-10 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:13:47 --> Final output sent to browser
DEBUG - 2016-02-10 17:13:47 --> Total execution time: 1.1854
INFO - 2016-02-10 14:17:09 --> Config Class Initialized
INFO - 2016-02-10 14:17:09 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:17:09 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:17:09 --> Utf8 Class Initialized
INFO - 2016-02-10 14:17:09 --> URI Class Initialized
INFO - 2016-02-10 14:17:09 --> Router Class Initialized
INFO - 2016-02-10 14:17:09 --> Output Class Initialized
INFO - 2016-02-10 14:17:09 --> Security Class Initialized
DEBUG - 2016-02-10 14:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:17:09 --> Input Class Initialized
INFO - 2016-02-10 14:17:09 --> Language Class Initialized
INFO - 2016-02-10 14:17:09 --> Loader Class Initialized
INFO - 2016-02-10 14:17:09 --> Helper loaded: url_helper
INFO - 2016-02-10 14:17:09 --> Helper loaded: file_helper
INFO - 2016-02-10 14:17:09 --> Helper loaded: date_helper
INFO - 2016-02-10 14:17:09 --> Helper loaded: form_helper
INFO - 2016-02-10 14:17:09 --> Database Driver Class Initialized
INFO - 2016-02-10 14:17:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:17:10 --> Controller Class Initialized
INFO - 2016-02-10 14:17:10 --> Model Class Initialized
INFO - 2016-02-10 14:17:10 --> Model Class Initialized
INFO - 2016-02-10 14:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:17:10 --> Pagination Class Initialized
INFO - 2016-02-10 17:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:17:10 --> Helper loaded: text_helper
INFO - 2016-02-10 17:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:17:10 --> Final output sent to browser
DEBUG - 2016-02-10 17:17:10 --> Total execution time: 1.1473
INFO - 2016-02-10 14:17:11 --> Config Class Initialized
INFO - 2016-02-10 14:17:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:17:11 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:17:11 --> Utf8 Class Initialized
INFO - 2016-02-10 14:17:11 --> URI Class Initialized
DEBUG - 2016-02-10 14:17:11 --> No URI present. Default controller set.
INFO - 2016-02-10 14:17:11 --> Router Class Initialized
INFO - 2016-02-10 14:17:11 --> Output Class Initialized
INFO - 2016-02-10 14:17:11 --> Security Class Initialized
DEBUG - 2016-02-10 14:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:17:11 --> Input Class Initialized
INFO - 2016-02-10 14:17:11 --> Language Class Initialized
INFO - 2016-02-10 14:17:11 --> Loader Class Initialized
INFO - 2016-02-10 14:17:11 --> Helper loaded: url_helper
INFO - 2016-02-10 14:17:11 --> Helper loaded: file_helper
INFO - 2016-02-10 14:17:11 --> Helper loaded: date_helper
INFO - 2016-02-10 14:17:11 --> Helper loaded: form_helper
INFO - 2016-02-10 14:17:11 --> Database Driver Class Initialized
INFO - 2016-02-10 14:17:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:17:12 --> Controller Class Initialized
INFO - 2016-02-10 14:17:12 --> Model Class Initialized
INFO - 2016-02-10 14:17:12 --> Model Class Initialized
INFO - 2016-02-10 14:17:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:17:12 --> Pagination Class Initialized
INFO - 2016-02-10 17:17:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:17:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:17:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-02-10 17:17:13 --> Severity: Error --> Call to undefined method CI_Output::clear_all_cache() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 93
INFO - 2016-02-10 14:17:42 --> Config Class Initialized
INFO - 2016-02-10 14:17:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:17:42 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:17:42 --> Utf8 Class Initialized
INFO - 2016-02-10 14:17:42 --> URI Class Initialized
DEBUG - 2016-02-10 14:17:42 --> No URI present. Default controller set.
INFO - 2016-02-10 14:17:42 --> Router Class Initialized
INFO - 2016-02-10 14:17:42 --> Output Class Initialized
INFO - 2016-02-10 14:17:42 --> Security Class Initialized
DEBUG - 2016-02-10 14:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:17:42 --> Input Class Initialized
INFO - 2016-02-10 14:17:42 --> Language Class Initialized
INFO - 2016-02-10 14:17:42 --> Loader Class Initialized
INFO - 2016-02-10 14:17:42 --> Helper loaded: url_helper
INFO - 2016-02-10 14:17:42 --> Helper loaded: file_helper
INFO - 2016-02-10 14:17:42 --> Helper loaded: date_helper
INFO - 2016-02-10 14:17:42 --> Helper loaded: form_helper
INFO - 2016-02-10 14:17:42 --> Database Driver Class Initialized
INFO - 2016-02-10 14:17:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:17:43 --> Controller Class Initialized
INFO - 2016-02-10 14:17:43 --> Model Class Initialized
INFO - 2016-02-10 14:17:43 --> Model Class Initialized
INFO - 2016-02-10 14:17:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:17:43 --> Pagination Class Initialized
INFO - 2016-02-10 17:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:17:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:17:43 --> Final output sent to browser
DEBUG - 2016-02-10 17:17:43 --> Total execution time: 1.1013
INFO - 2016-02-10 14:41:19 --> Config Class Initialized
INFO - 2016-02-10 14:41:19 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:41:19 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:41:19 --> Utf8 Class Initialized
INFO - 2016-02-10 14:41:19 --> URI Class Initialized
DEBUG - 2016-02-10 14:41:19 --> No URI present. Default controller set.
INFO - 2016-02-10 14:41:19 --> Router Class Initialized
INFO - 2016-02-10 14:41:19 --> Output Class Initialized
INFO - 2016-02-10 14:41:19 --> Security Class Initialized
DEBUG - 2016-02-10 14:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:41:19 --> Input Class Initialized
INFO - 2016-02-10 14:41:19 --> Language Class Initialized
INFO - 2016-02-10 14:41:19 --> Loader Class Initialized
INFO - 2016-02-10 14:41:19 --> Helper loaded: url_helper
INFO - 2016-02-10 14:41:19 --> Helper loaded: file_helper
INFO - 2016-02-10 14:41:19 --> Helper loaded: date_helper
INFO - 2016-02-10 14:41:19 --> Helper loaded: form_helper
INFO - 2016-02-10 14:41:19 --> Database Driver Class Initialized
INFO - 2016-02-10 14:41:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:41:20 --> Controller Class Initialized
INFO - 2016-02-10 14:41:20 --> Model Class Initialized
INFO - 2016-02-10 14:41:20 --> Model Class Initialized
INFO - 2016-02-10 14:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:41:20 --> Pagination Class Initialized
INFO - 2016-02-10 17:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 17:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:41:20 --> Final output sent to browser
DEBUG - 2016-02-10 17:41:20 --> Total execution time: 1.1047
INFO - 2016-02-10 14:41:22 --> Config Class Initialized
INFO - 2016-02-10 14:41:22 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:41:22 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:41:22 --> Utf8 Class Initialized
INFO - 2016-02-10 14:41:22 --> URI Class Initialized
INFO - 2016-02-10 14:41:22 --> Router Class Initialized
INFO - 2016-02-10 14:41:22 --> Output Class Initialized
INFO - 2016-02-10 14:41:22 --> Security Class Initialized
DEBUG - 2016-02-10 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:41:22 --> Input Class Initialized
INFO - 2016-02-10 14:41:22 --> Language Class Initialized
INFO - 2016-02-10 14:41:22 --> Loader Class Initialized
INFO - 2016-02-10 14:41:22 --> Helper loaded: url_helper
INFO - 2016-02-10 14:41:22 --> Helper loaded: file_helper
INFO - 2016-02-10 14:41:22 --> Helper loaded: date_helper
INFO - 2016-02-10 14:41:22 --> Helper loaded: form_helper
INFO - 2016-02-10 14:41:22 --> Database Driver Class Initialized
INFO - 2016-02-10 14:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:41:23 --> Controller Class Initialized
INFO - 2016-02-10 14:41:23 --> Model Class Initialized
INFO - 2016-02-10 14:41:23 --> Model Class Initialized
INFO - 2016-02-10 14:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:41:23 --> Pagination Class Initialized
INFO - 2016-02-10 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:41:23 --> Helper loaded: text_helper
INFO - 2016-02-10 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:41:23 --> Final output sent to browser
DEBUG - 2016-02-10 17:41:23 --> Total execution time: 1.1367
INFO - 2016-02-10 14:49:42 --> Config Class Initialized
INFO - 2016-02-10 14:49:42 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:49:42 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:49:42 --> Utf8 Class Initialized
INFO - 2016-02-10 14:49:42 --> URI Class Initialized
INFO - 2016-02-10 14:49:42 --> Router Class Initialized
INFO - 2016-02-10 14:49:42 --> Output Class Initialized
INFO - 2016-02-10 14:49:42 --> Security Class Initialized
DEBUG - 2016-02-10 14:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:49:42 --> Input Class Initialized
INFO - 2016-02-10 14:49:42 --> Language Class Initialized
INFO - 2016-02-10 14:49:42 --> Loader Class Initialized
INFO - 2016-02-10 14:49:42 --> Helper loaded: url_helper
INFO - 2016-02-10 14:49:42 --> Helper loaded: file_helper
INFO - 2016-02-10 14:49:42 --> Helper loaded: date_helper
INFO - 2016-02-10 14:49:42 --> Helper loaded: form_helper
INFO - 2016-02-10 14:49:42 --> Database Driver Class Initialized
INFO - 2016-02-10 14:49:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:49:43 --> Controller Class Initialized
INFO - 2016-02-10 14:49:43 --> Model Class Initialized
INFO - 2016-02-10 14:49:43 --> Model Class Initialized
INFO - 2016-02-10 14:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:49:43 --> Pagination Class Initialized
INFO - 2016-02-10 17:49:43 --> Final output sent to browser
DEBUG - 2016-02-10 17:49:43 --> Total execution time: 1.1236
INFO - 2016-02-10 14:49:44 --> Config Class Initialized
INFO - 2016-02-10 14:49:44 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:49:44 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:49:44 --> Utf8 Class Initialized
INFO - 2016-02-10 14:49:44 --> URI Class Initialized
INFO - 2016-02-10 14:49:44 --> Router Class Initialized
INFO - 2016-02-10 14:49:44 --> Output Class Initialized
INFO - 2016-02-10 14:49:44 --> Security Class Initialized
DEBUG - 2016-02-10 14:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:49:44 --> Input Class Initialized
INFO - 2016-02-10 14:49:44 --> Language Class Initialized
INFO - 2016-02-10 14:49:44 --> Loader Class Initialized
INFO - 2016-02-10 14:49:44 --> Helper loaded: url_helper
INFO - 2016-02-10 14:49:44 --> Helper loaded: file_helper
INFO - 2016-02-10 14:49:44 --> Helper loaded: date_helper
INFO - 2016-02-10 14:49:44 --> Helper loaded: form_helper
INFO - 2016-02-10 14:49:44 --> Database Driver Class Initialized
INFO - 2016-02-10 14:49:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:49:45 --> Controller Class Initialized
INFO - 2016-02-10 14:49:45 --> Model Class Initialized
INFO - 2016-02-10 14:49:45 --> Model Class Initialized
INFO - 2016-02-10 14:49:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:49:45 --> Pagination Class Initialized
INFO - 2016-02-10 17:49:45 --> Final output sent to browser
DEBUG - 2016-02-10 17:49:45 --> Total execution time: 1.1021
INFO - 2016-02-10 14:49:46 --> Config Class Initialized
INFO - 2016-02-10 14:49:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:49:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:49:46 --> Utf8 Class Initialized
INFO - 2016-02-10 14:49:46 --> URI Class Initialized
INFO - 2016-02-10 14:49:46 --> Router Class Initialized
INFO - 2016-02-10 14:49:46 --> Output Class Initialized
INFO - 2016-02-10 14:49:46 --> Security Class Initialized
DEBUG - 2016-02-10 14:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:49:46 --> Input Class Initialized
INFO - 2016-02-10 14:49:46 --> Language Class Initialized
INFO - 2016-02-10 14:49:46 --> Loader Class Initialized
INFO - 2016-02-10 14:49:46 --> Helper loaded: url_helper
INFO - 2016-02-10 14:49:46 --> Helper loaded: file_helper
INFO - 2016-02-10 14:49:46 --> Helper loaded: date_helper
INFO - 2016-02-10 14:49:46 --> Helper loaded: form_helper
INFO - 2016-02-10 14:49:46 --> Database Driver Class Initialized
INFO - 2016-02-10 14:49:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:49:47 --> Controller Class Initialized
INFO - 2016-02-10 14:49:47 --> Model Class Initialized
INFO - 2016-02-10 14:49:47 --> Model Class Initialized
INFO - 2016-02-10 14:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:49:47 --> Pagination Class Initialized
INFO - 2016-02-10 17:49:47 --> Final output sent to browser
DEBUG - 2016-02-10 17:49:47 --> Total execution time: 1.1256
INFO - 2016-02-10 14:49:48 --> Config Class Initialized
INFO - 2016-02-10 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:49:48 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:49:48 --> Utf8 Class Initialized
INFO - 2016-02-10 14:49:48 --> URI Class Initialized
INFO - 2016-02-10 14:49:48 --> Router Class Initialized
INFO - 2016-02-10 14:49:48 --> Output Class Initialized
INFO - 2016-02-10 14:49:48 --> Security Class Initialized
DEBUG - 2016-02-10 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:49:48 --> Input Class Initialized
INFO - 2016-02-10 14:49:48 --> Language Class Initialized
INFO - 2016-02-10 14:49:48 --> Loader Class Initialized
INFO - 2016-02-10 14:49:48 --> Helper loaded: url_helper
INFO - 2016-02-10 14:49:48 --> Helper loaded: file_helper
INFO - 2016-02-10 14:49:48 --> Helper loaded: date_helper
INFO - 2016-02-10 14:49:48 --> Helper loaded: form_helper
INFO - 2016-02-10 14:49:48 --> Database Driver Class Initialized
INFO - 2016-02-10 14:49:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:49:49 --> Controller Class Initialized
INFO - 2016-02-10 14:49:49 --> Model Class Initialized
INFO - 2016-02-10 14:49:49 --> Model Class Initialized
INFO - 2016-02-10 14:49:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:49:49 --> Pagination Class Initialized
INFO - 2016-02-10 17:49:49 --> Final output sent to browser
DEBUG - 2016-02-10 17:49:49 --> Total execution time: 1.1015
INFO - 2016-02-10 14:49:53 --> Config Class Initialized
INFO - 2016-02-10 14:49:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 14:49:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 14:49:53 --> Utf8 Class Initialized
INFO - 2016-02-10 14:49:53 --> URI Class Initialized
INFO - 2016-02-10 14:49:53 --> Router Class Initialized
INFO - 2016-02-10 14:49:53 --> Output Class Initialized
INFO - 2016-02-10 14:49:53 --> Security Class Initialized
DEBUG - 2016-02-10 14:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 14:49:53 --> Input Class Initialized
INFO - 2016-02-10 14:49:53 --> Language Class Initialized
INFO - 2016-02-10 14:49:53 --> Loader Class Initialized
INFO - 2016-02-10 14:49:53 --> Helper loaded: url_helper
INFO - 2016-02-10 14:49:53 --> Helper loaded: file_helper
INFO - 2016-02-10 14:49:53 --> Helper loaded: date_helper
INFO - 2016-02-10 14:49:53 --> Helper loaded: form_helper
INFO - 2016-02-10 14:49:53 --> Database Driver Class Initialized
INFO - 2016-02-10 14:49:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 14:49:54 --> Controller Class Initialized
INFO - 2016-02-10 14:49:54 --> Model Class Initialized
INFO - 2016-02-10 14:49:54 --> Model Class Initialized
INFO - 2016-02-10 14:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 14:49:54 --> Pagination Class Initialized
INFO - 2016-02-10 17:49:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 17:49:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 17:49:54 --> Helper loaded: text_helper
INFO - 2016-02-10 17:49:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 17:49:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 17:49:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 17:49:54 --> Final output sent to browser
DEBUG - 2016-02-10 17:49:54 --> Total execution time: 1.1733
INFO - 2016-02-10 16:20:08 --> Config Class Initialized
INFO - 2016-02-10 16:20:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:08 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:08 --> URI Class Initialized
DEBUG - 2016-02-10 16:20:08 --> No URI present. Default controller set.
INFO - 2016-02-10 16:20:08 --> Router Class Initialized
INFO - 2016-02-10 16:20:08 --> Output Class Initialized
INFO - 2016-02-10 16:20:08 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:08 --> Input Class Initialized
INFO - 2016-02-10 16:20:08 --> Language Class Initialized
INFO - 2016-02-10 16:20:08 --> Loader Class Initialized
INFO - 2016-02-10 16:20:08 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:08 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:08 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:08 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:08 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:09 --> Controller Class Initialized
INFO - 2016-02-10 16:20:09 --> Model Class Initialized
INFO - 2016-02-10 16:20:09 --> Model Class Initialized
INFO - 2016-02-10 16:20:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:09 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 19:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 19:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 19:20:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 19:20:09 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:09 --> Total execution time: 1.1240
INFO - 2016-02-10 16:20:11 --> Config Class Initialized
INFO - 2016-02-10 16:20:11 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:11 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:11 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:11 --> URI Class Initialized
INFO - 2016-02-10 16:20:11 --> Router Class Initialized
INFO - 2016-02-10 16:20:11 --> Output Class Initialized
INFO - 2016-02-10 16:20:11 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:11 --> Input Class Initialized
INFO - 2016-02-10 16:20:11 --> Language Class Initialized
INFO - 2016-02-10 16:20:11 --> Loader Class Initialized
INFO - 2016-02-10 16:20:11 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:11 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:11 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:11 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:11 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:12 --> Controller Class Initialized
INFO - 2016-02-10 16:20:12 --> Model Class Initialized
INFO - 2016-02-10 16:20:12 --> Model Class Initialized
INFO - 2016-02-10 16:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:12 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 19:20:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 19:20:12 --> Helper loaded: text_helper
INFO - 2016-02-10 19:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 19:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 19:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 19:20:13 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:13 --> Total execution time: 1.1632
INFO - 2016-02-10 16:20:17 --> Config Class Initialized
INFO - 2016-02-10 16:20:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:17 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:17 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:17 --> URI Class Initialized
INFO - 2016-02-10 16:20:17 --> Router Class Initialized
INFO - 2016-02-10 16:20:17 --> Output Class Initialized
INFO - 2016-02-10 16:20:17 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:17 --> Input Class Initialized
INFO - 2016-02-10 16:20:17 --> Language Class Initialized
INFO - 2016-02-10 16:20:17 --> Loader Class Initialized
INFO - 2016-02-10 16:20:17 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:17 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:17 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:17 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:17 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:19 --> Controller Class Initialized
INFO - 2016-02-10 16:20:19 --> Model Class Initialized
INFO - 2016-02-10 16:20:19 --> Model Class Initialized
INFO - 2016-02-10 16:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:19 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:19 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:19 --> Total execution time: 1.1403
INFO - 2016-02-10 16:20:20 --> Config Class Initialized
INFO - 2016-02-10 16:20:20 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:20 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:20 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:20 --> URI Class Initialized
INFO - 2016-02-10 16:20:20 --> Router Class Initialized
INFO - 2016-02-10 16:20:20 --> Output Class Initialized
INFO - 2016-02-10 16:20:20 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:20 --> Input Class Initialized
INFO - 2016-02-10 16:20:20 --> Language Class Initialized
INFO - 2016-02-10 16:20:20 --> Loader Class Initialized
INFO - 2016-02-10 16:20:20 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:20 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:20 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:20 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:20 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:21 --> Controller Class Initialized
INFO - 2016-02-10 16:20:21 --> Model Class Initialized
INFO - 2016-02-10 16:20:21 --> Model Class Initialized
INFO - 2016-02-10 16:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:21 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:21 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:21 --> Total execution time: 1.0946
INFO - 2016-02-10 16:20:37 --> Config Class Initialized
INFO - 2016-02-10 16:20:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:37 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:37 --> URI Class Initialized
INFO - 2016-02-10 16:20:37 --> Router Class Initialized
INFO - 2016-02-10 16:20:37 --> Output Class Initialized
INFO - 2016-02-10 16:20:37 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:37 --> Input Class Initialized
INFO - 2016-02-10 16:20:37 --> Language Class Initialized
INFO - 2016-02-10 16:20:37 --> Loader Class Initialized
INFO - 2016-02-10 16:20:37 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:37 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:37 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:37 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:37 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:38 --> Controller Class Initialized
INFO - 2016-02-10 16:20:38 --> Model Class Initialized
INFO - 2016-02-10 16:20:38 --> Model Class Initialized
INFO - 2016-02-10 16:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:38 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:38 --> Form Validation Class Initialized
INFO - 2016-02-10 19:20:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 19:20:38 --> Model Class Initialized
INFO - 2016-02-10 19:20:38 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:38 --> Total execution time: 1.2569
INFO - 2016-02-10 16:20:57 --> Config Class Initialized
INFO - 2016-02-10 16:20:57 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:20:57 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:20:57 --> Utf8 Class Initialized
INFO - 2016-02-10 16:20:57 --> URI Class Initialized
DEBUG - 2016-02-10 16:20:57 --> No URI present. Default controller set.
INFO - 2016-02-10 16:20:57 --> Router Class Initialized
INFO - 2016-02-10 16:20:57 --> Output Class Initialized
INFO - 2016-02-10 16:20:57 --> Security Class Initialized
DEBUG - 2016-02-10 16:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:20:57 --> Input Class Initialized
INFO - 2016-02-10 16:20:57 --> Language Class Initialized
INFO - 2016-02-10 16:20:57 --> Loader Class Initialized
INFO - 2016-02-10 16:20:57 --> Helper loaded: url_helper
INFO - 2016-02-10 16:20:57 --> Helper loaded: file_helper
INFO - 2016-02-10 16:20:57 --> Helper loaded: date_helper
INFO - 2016-02-10 16:20:57 --> Helper loaded: form_helper
INFO - 2016-02-10 16:20:57 --> Database Driver Class Initialized
INFO - 2016-02-10 16:20:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:20:58 --> Controller Class Initialized
INFO - 2016-02-10 16:20:58 --> Model Class Initialized
INFO - 2016-02-10 16:20:58 --> Model Class Initialized
INFO - 2016-02-10 16:20:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:20:58 --> Pagination Class Initialized
INFO - 2016-02-10 19:20:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 19:20:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 19:20:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 19:20:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 19:20:58 --> Final output sent to browser
DEBUG - 2016-02-10 19:20:58 --> Total execution time: 1.1190
INFO - 2016-02-10 16:21:02 --> Config Class Initialized
INFO - 2016-02-10 16:21:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:21:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:21:02 --> Utf8 Class Initialized
INFO - 2016-02-10 16:21:02 --> URI Class Initialized
INFO - 2016-02-10 16:21:02 --> Router Class Initialized
INFO - 2016-02-10 16:21:02 --> Output Class Initialized
INFO - 2016-02-10 16:21:02 --> Security Class Initialized
DEBUG - 2016-02-10 16:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:21:02 --> Input Class Initialized
INFO - 2016-02-10 16:21:02 --> Language Class Initialized
INFO - 2016-02-10 16:21:02 --> Loader Class Initialized
INFO - 2016-02-10 16:21:02 --> Helper loaded: url_helper
INFO - 2016-02-10 16:21:02 --> Helper loaded: file_helper
INFO - 2016-02-10 16:21:02 --> Helper loaded: date_helper
INFO - 2016-02-10 16:21:02 --> Helper loaded: form_helper
INFO - 2016-02-10 16:21:02 --> Database Driver Class Initialized
INFO - 2016-02-10 16:21:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:21:03 --> Controller Class Initialized
INFO - 2016-02-10 16:21:03 --> Model Class Initialized
INFO - 2016-02-10 16:21:03 --> Model Class Initialized
INFO - 2016-02-10 16:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:21:03 --> Pagination Class Initialized
INFO - 2016-02-10 19:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 19:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 19:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 19:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 19:21:03 --> Final output sent to browser
DEBUG - 2016-02-10 19:21:03 --> Total execution time: 1.0983
INFO - 2016-02-10 16:21:12 --> Config Class Initialized
INFO - 2016-02-10 16:21:12 --> Hooks Class Initialized
DEBUG - 2016-02-10 16:21:12 --> UTF-8 Support Enabled
INFO - 2016-02-10 16:21:12 --> Utf8 Class Initialized
INFO - 2016-02-10 16:21:12 --> URI Class Initialized
INFO - 2016-02-10 16:21:12 --> Router Class Initialized
INFO - 2016-02-10 16:21:12 --> Output Class Initialized
INFO - 2016-02-10 16:21:12 --> Security Class Initialized
DEBUG - 2016-02-10 16:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 16:21:12 --> Input Class Initialized
INFO - 2016-02-10 16:21:12 --> Language Class Initialized
INFO - 2016-02-10 16:21:12 --> Loader Class Initialized
INFO - 2016-02-10 16:21:12 --> Helper loaded: url_helper
INFO - 2016-02-10 16:21:12 --> Helper loaded: file_helper
INFO - 2016-02-10 16:21:12 --> Helper loaded: date_helper
INFO - 2016-02-10 16:21:12 --> Helper loaded: form_helper
INFO - 2016-02-10 16:21:12 --> Database Driver Class Initialized
INFO - 2016-02-10 16:21:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 16:21:13 --> Controller Class Initialized
INFO - 2016-02-10 16:21:13 --> Model Class Initialized
INFO - 2016-02-10 16:21:13 --> Model Class Initialized
INFO - 2016-02-10 16:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 16:21:13 --> Pagination Class Initialized
INFO - 2016-02-10 19:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 19:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 19:21:13 --> Helper loaded: text_helper
INFO - 2016-02-10 19:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-10 19:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 19:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 19:21:13 --> Final output sent to browser
DEBUG - 2016-02-10 19:21:13 --> Total execution time: 1.1552
INFO - 2016-02-10 18:06:26 --> Config Class Initialized
INFO - 2016-02-10 18:06:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 18:06:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 18:06:26 --> Utf8 Class Initialized
INFO - 2016-02-10 18:06:26 --> URI Class Initialized
INFO - 2016-02-10 18:06:26 --> Router Class Initialized
INFO - 2016-02-10 18:06:26 --> Output Class Initialized
INFO - 2016-02-10 18:06:26 --> Security Class Initialized
DEBUG - 2016-02-10 18:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 18:06:26 --> Input Class Initialized
INFO - 2016-02-10 18:06:26 --> Language Class Initialized
INFO - 2016-02-10 18:06:26 --> Loader Class Initialized
INFO - 2016-02-10 18:06:26 --> Helper loaded: url_helper
INFO - 2016-02-10 18:06:26 --> Helper loaded: file_helper
INFO - 2016-02-10 18:06:26 --> Helper loaded: date_helper
INFO - 2016-02-10 18:06:26 --> Helper loaded: form_helper
INFO - 2016-02-10 18:06:26 --> Database Driver Class Initialized
INFO - 2016-02-10 18:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 18:06:27 --> Controller Class Initialized
INFO - 2016-02-10 18:06:27 --> Model Class Initialized
INFO - 2016-02-10 18:06:27 --> Model Class Initialized
INFO - 2016-02-10 18:06:27 --> Form Validation Class Initialized
INFO - 2016-02-10 18:06:27 --> Helper loaded: text_helper
INFO - 2016-02-10 18:06:27 --> Config Class Initialized
INFO - 2016-02-10 18:06:27 --> Hooks Class Initialized
DEBUG - 2016-02-10 18:06:27 --> UTF-8 Support Enabled
INFO - 2016-02-10 18:06:27 --> Utf8 Class Initialized
INFO - 2016-02-10 18:06:27 --> URI Class Initialized
INFO - 2016-02-10 18:06:27 --> Router Class Initialized
INFO - 2016-02-10 18:06:27 --> Output Class Initialized
INFO - 2016-02-10 18:06:27 --> Security Class Initialized
DEBUG - 2016-02-10 18:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 18:06:27 --> Input Class Initialized
INFO - 2016-02-10 18:06:27 --> Language Class Initialized
INFO - 2016-02-10 18:06:27 --> Loader Class Initialized
INFO - 2016-02-10 18:06:27 --> Helper loaded: url_helper
INFO - 2016-02-10 18:06:27 --> Helper loaded: file_helper
INFO - 2016-02-10 18:06:27 --> Helper loaded: date_helper
INFO - 2016-02-10 18:06:27 --> Helper loaded: form_helper
INFO - 2016-02-10 18:06:27 --> Database Driver Class Initialized
INFO - 2016-02-10 18:06:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 18:06:28 --> Controller Class Initialized
INFO - 2016-02-10 18:06:28 --> Model Class Initialized
INFO - 2016-02-10 18:06:28 --> Model Class Initialized
INFO - 2016-02-10 18:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 18:06:28 --> Pagination Class Initialized
INFO - 2016-02-10 21:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-10 21:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:06:28 --> Final output sent to browser
DEBUG - 2016-02-10 21:06:28 --> Total execution time: 1.0994
INFO - 2016-02-10 18:06:30 --> Config Class Initialized
INFO - 2016-02-10 18:06:30 --> Hooks Class Initialized
DEBUG - 2016-02-10 18:06:30 --> UTF-8 Support Enabled
INFO - 2016-02-10 18:06:30 --> Utf8 Class Initialized
INFO - 2016-02-10 18:06:30 --> URI Class Initialized
INFO - 2016-02-10 18:06:30 --> Router Class Initialized
INFO - 2016-02-10 18:06:30 --> Output Class Initialized
INFO - 2016-02-10 18:06:30 --> Security Class Initialized
DEBUG - 2016-02-10 18:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 18:06:30 --> Input Class Initialized
INFO - 2016-02-10 18:06:30 --> Language Class Initialized
INFO - 2016-02-10 18:06:30 --> Loader Class Initialized
INFO - 2016-02-10 18:06:30 --> Helper loaded: url_helper
INFO - 2016-02-10 18:06:30 --> Helper loaded: file_helper
INFO - 2016-02-10 18:06:30 --> Helper loaded: date_helper
INFO - 2016-02-10 18:06:30 --> Helper loaded: form_helper
INFO - 2016-02-10 18:06:30 --> Database Driver Class Initialized
INFO - 2016-02-10 18:06:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 18:06:31 --> Controller Class Initialized
INFO - 2016-02-10 18:06:31 --> Model Class Initialized
INFO - 2016-02-10 18:06:31 --> Model Class Initialized
INFO - 2016-02-10 18:06:31 --> Form Validation Class Initialized
INFO - 2016-02-10 18:06:31 --> Helper loaded: text_helper
INFO - 2016-02-10 18:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 18:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 18:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-10 18:06:31 --> Model Class Initialized
INFO - 2016-02-10 18:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 18:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 18:06:31 --> Final output sent to browser
DEBUG - 2016-02-10 18:06:31 --> Total execution time: 1.1489
INFO - 2016-02-10 18:06:37 --> Config Class Initialized
INFO - 2016-02-10 18:06:37 --> Hooks Class Initialized
DEBUG - 2016-02-10 18:06:37 --> UTF-8 Support Enabled
INFO - 2016-02-10 18:06:37 --> Utf8 Class Initialized
INFO - 2016-02-10 18:06:37 --> URI Class Initialized
INFO - 2016-02-10 18:06:37 --> Router Class Initialized
INFO - 2016-02-10 18:06:37 --> Output Class Initialized
INFO - 2016-02-10 18:06:37 --> Security Class Initialized
DEBUG - 2016-02-10 18:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 18:06:37 --> Input Class Initialized
INFO - 2016-02-10 18:06:37 --> Language Class Initialized
INFO - 2016-02-10 18:06:37 --> Loader Class Initialized
INFO - 2016-02-10 18:06:37 --> Helper loaded: url_helper
INFO - 2016-02-10 18:06:37 --> Helper loaded: file_helper
INFO - 2016-02-10 18:06:37 --> Helper loaded: date_helper
INFO - 2016-02-10 18:06:37 --> Helper loaded: form_helper
INFO - 2016-02-10 18:06:37 --> Database Driver Class Initialized
INFO - 2016-02-10 18:06:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 18:06:38 --> Controller Class Initialized
INFO - 2016-02-10 18:06:38 --> Model Class Initialized
INFO - 2016-02-10 18:06:38 --> Model Class Initialized
INFO - 2016-02-10 18:06:38 --> Form Validation Class Initialized
INFO - 2016-02-10 18:06:38 --> Helper loaded: text_helper
INFO - 2016-02-10 18:06:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-10 18:06:38 --> Final output sent to browser
DEBUG - 2016-02-10 18:06:38 --> Total execution time: 1.0808
INFO - 2016-02-10 18:06:41 --> Config Class Initialized
INFO - 2016-02-10 18:06:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 18:06:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 18:06:41 --> Utf8 Class Initialized
INFO - 2016-02-10 18:06:41 --> URI Class Initialized
INFO - 2016-02-10 18:06:41 --> Router Class Initialized
INFO - 2016-02-10 18:06:41 --> Output Class Initialized
INFO - 2016-02-10 18:06:41 --> Security Class Initialized
DEBUG - 2016-02-10 18:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 18:06:41 --> Input Class Initialized
INFO - 2016-02-10 18:06:41 --> Language Class Initialized
INFO - 2016-02-10 18:06:41 --> Loader Class Initialized
INFO - 2016-02-10 18:06:41 --> Helper loaded: url_helper
INFO - 2016-02-10 18:06:41 --> Helper loaded: file_helper
INFO - 2016-02-10 18:06:41 --> Helper loaded: date_helper
INFO - 2016-02-10 18:06:41 --> Helper loaded: form_helper
INFO - 2016-02-10 18:06:41 --> Database Driver Class Initialized
INFO - 2016-02-10 18:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 18:06:42 --> Controller Class Initialized
INFO - 2016-02-10 18:06:42 --> Model Class Initialized
INFO - 2016-02-10 18:06:42 --> Model Class Initialized
INFO - 2016-02-10 18:06:42 --> Form Validation Class Initialized
INFO - 2016-02-10 18:06:42 --> Helper loaded: text_helper
INFO - 2016-02-10 18:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 18:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 18:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-10 18:06:42 --> Model Class Initialized
INFO - 2016-02-10 18:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 18:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 18:06:42 --> Final output sent to browser
DEBUG - 2016-02-10 18:06:42 --> Total execution time: 1.1264
INFO - 2016-02-10 21:07:54 --> Config Class Initialized
INFO - 2016-02-10 21:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:07:54 --> Utf8 Class Initialized
INFO - 2016-02-10 21:07:54 --> URI Class Initialized
DEBUG - 2016-02-10 21:07:54 --> No URI present. Default controller set.
INFO - 2016-02-10 21:07:54 --> Router Class Initialized
INFO - 2016-02-10 21:07:55 --> Output Class Initialized
INFO - 2016-02-10 21:07:55 --> Security Class Initialized
DEBUG - 2016-02-10 21:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:07:55 --> Input Class Initialized
INFO - 2016-02-10 21:07:55 --> Language Class Initialized
INFO - 2016-02-10 21:07:55 --> Loader Class Initialized
INFO - 2016-02-10 21:07:55 --> Helper loaded: url_helper
INFO - 2016-02-10 21:07:55 --> Helper loaded: file_helper
INFO - 2016-02-10 21:07:55 --> Helper loaded: date_helper
INFO - 2016-02-10 21:07:55 --> Helper loaded: form_helper
INFO - 2016-02-10 21:07:55 --> Database Driver Class Initialized
INFO - 2016-02-10 21:07:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:07:56 --> Controller Class Initialized
INFO - 2016-02-10 21:07:56 --> Model Class Initialized
INFO - 2016-02-10 21:07:56 --> Model Class Initialized
INFO - 2016-02-10 21:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:07:56 --> Pagination Class Initialized
INFO - 2016-02-10 21:07:59 --> Config Class Initialized
INFO - 2016-02-10 21:07:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:07:59 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:07:59 --> Utf8 Class Initialized
INFO - 2016-02-10 21:07:59 --> URI Class Initialized
INFO - 2016-02-10 21:07:59 --> Router Class Initialized
INFO - 2016-02-10 21:07:59 --> Output Class Initialized
INFO - 2016-02-10 21:07:59 --> Security Class Initialized
DEBUG - 2016-02-10 21:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:07:59 --> Input Class Initialized
INFO - 2016-02-10 21:07:59 --> Language Class Initialized
INFO - 2016-02-10 21:07:59 --> Loader Class Initialized
INFO - 2016-02-10 21:07:59 --> Helper loaded: url_helper
INFO - 2016-02-10 21:07:59 --> Helper loaded: file_helper
INFO - 2016-02-10 21:07:59 --> Helper loaded: date_helper
INFO - 2016-02-10 21:07:59 --> Helper loaded: form_helper
INFO - 2016-02-10 21:07:59 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:00 --> Controller Class Initialized
INFO - 2016-02-10 21:08:00 --> Model Class Initialized
INFO - 2016-02-10 21:08:00 --> Model Class Initialized
INFO - 2016-02-10 21:08:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:00 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:02 --> Config Class Initialized
INFO - 2016-02-10 21:08:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:02 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:02 --> URI Class Initialized
INFO - 2016-02-10 21:08:02 --> Router Class Initialized
INFO - 2016-02-10 21:08:02 --> Output Class Initialized
INFO - 2016-02-10 21:08:02 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:02 --> Input Class Initialized
INFO - 2016-02-10 21:08:02 --> Language Class Initialized
INFO - 2016-02-10 21:08:02 --> Loader Class Initialized
INFO - 2016-02-10 21:08:02 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:02 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:02 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:02 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:02 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:03 --> Controller Class Initialized
INFO - 2016-02-10 21:08:03 --> Model Class Initialized
INFO - 2016-02-10 21:08:03 --> Model Class Initialized
INFO - 2016-02-10 21:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:03 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:03 --> Config Class Initialized
INFO - 2016-02-10 21:08:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:03 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:03 --> URI Class Initialized
INFO - 2016-02-10 21:08:03 --> Router Class Initialized
INFO - 2016-02-10 21:08:03 --> Output Class Initialized
INFO - 2016-02-10 21:08:03 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:03 --> Input Class Initialized
INFO - 2016-02-10 21:08:03 --> Language Class Initialized
INFO - 2016-02-10 21:08:03 --> Loader Class Initialized
INFO - 2016-02-10 21:08:03 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:03 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:03 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:03 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:03 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:04 --> Controller Class Initialized
INFO - 2016-02-10 21:08:04 --> Model Class Initialized
INFO - 2016-02-10 21:08:04 --> Model Class Initialized
INFO - 2016-02-10 21:08:04 --> Form Validation Class Initialized
INFO - 2016-02-10 21:08:04 --> Helper loaded: text_helper
INFO - 2016-02-10 21:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:08:04 --> Final output sent to browser
DEBUG - 2016-02-10 21:08:04 --> Total execution time: 1.1105
INFO - 2016-02-10 21:08:08 --> Config Class Initialized
INFO - 2016-02-10 21:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:08 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:08 --> URI Class Initialized
INFO - 2016-02-10 21:08:08 --> Router Class Initialized
INFO - 2016-02-10 21:08:08 --> Output Class Initialized
INFO - 2016-02-10 21:08:08 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:08 --> Input Class Initialized
INFO - 2016-02-10 21:08:08 --> Language Class Initialized
INFO - 2016-02-10 21:08:08 --> Loader Class Initialized
INFO - 2016-02-10 21:08:08 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:08 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:08 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:08 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:08 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:09 --> Controller Class Initialized
INFO - 2016-02-10 21:08:09 --> Model Class Initialized
INFO - 2016-02-10 21:08:09 --> Model Class Initialized
INFO - 2016-02-10 21:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:09 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:09 --> Config Class Initialized
INFO - 2016-02-10 21:08:09 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:09 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:09 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:09 --> URI Class Initialized
INFO - 2016-02-10 21:08:09 --> Router Class Initialized
INFO - 2016-02-10 21:08:09 --> Output Class Initialized
INFO - 2016-02-10 21:08:09 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:09 --> Input Class Initialized
INFO - 2016-02-10 21:08:09 --> Language Class Initialized
INFO - 2016-02-10 21:08:09 --> Loader Class Initialized
INFO - 2016-02-10 21:08:09 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:09 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:09 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:09 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:09 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:10 --> Controller Class Initialized
INFO - 2016-02-10 21:08:10 --> Model Class Initialized
INFO - 2016-02-10 21:08:10 --> Model Class Initialized
INFO - 2016-02-10 21:08:10 --> Form Validation Class Initialized
INFO - 2016-02-10 21:08:10 --> Helper loaded: text_helper
INFO - 2016-02-10 21:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:08:10 --> Final output sent to browser
DEBUG - 2016-02-10 21:08:10 --> Total execution time: 1.1319
INFO - 2016-02-10 21:08:46 --> Config Class Initialized
INFO - 2016-02-10 21:08:46 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:46 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:46 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:46 --> URI Class Initialized
INFO - 2016-02-10 21:08:46 --> Router Class Initialized
INFO - 2016-02-10 21:08:46 --> Output Class Initialized
INFO - 2016-02-10 21:08:46 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:46 --> Input Class Initialized
INFO - 2016-02-10 21:08:46 --> Language Class Initialized
INFO - 2016-02-10 21:08:46 --> Loader Class Initialized
INFO - 2016-02-10 21:08:46 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:46 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:46 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:46 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:46 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:47 --> Controller Class Initialized
INFO - 2016-02-10 21:08:47 --> Model Class Initialized
INFO - 2016-02-10 21:08:47 --> Model Class Initialized
INFO - 2016-02-10 21:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:47 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:49 --> Config Class Initialized
INFO - 2016-02-10 21:08:49 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:49 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:49 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:49 --> URI Class Initialized
INFO - 2016-02-10 21:08:49 --> Router Class Initialized
INFO - 2016-02-10 21:08:49 --> Output Class Initialized
INFO - 2016-02-10 21:08:49 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:49 --> Input Class Initialized
INFO - 2016-02-10 21:08:49 --> Language Class Initialized
INFO - 2016-02-10 21:08:49 --> Loader Class Initialized
INFO - 2016-02-10 21:08:49 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:49 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:49 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:49 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:49 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:50 --> Controller Class Initialized
INFO - 2016-02-10 21:08:50 --> Model Class Initialized
INFO - 2016-02-10 21:08:50 --> Model Class Initialized
INFO - 2016-02-10 21:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:50 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:50 --> Config Class Initialized
INFO - 2016-02-10 21:08:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:50 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:50 --> URI Class Initialized
INFO - 2016-02-10 21:08:50 --> Router Class Initialized
INFO - 2016-02-10 21:08:50 --> Output Class Initialized
INFO - 2016-02-10 21:08:50 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:50 --> Input Class Initialized
INFO - 2016-02-10 21:08:50 --> Language Class Initialized
INFO - 2016-02-10 21:08:50 --> Loader Class Initialized
INFO - 2016-02-10 21:08:50 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:50 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:50 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:50 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:50 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:51 --> Controller Class Initialized
INFO - 2016-02-10 21:08:51 --> Model Class Initialized
INFO - 2016-02-10 21:08:51 --> Model Class Initialized
INFO - 2016-02-10 21:08:51 --> Form Validation Class Initialized
INFO - 2016-02-10 21:08:51 --> Helper loaded: text_helper
INFO - 2016-02-10 21:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:08:51 --> Final output sent to browser
DEBUG - 2016-02-10 21:08:51 --> Total execution time: 1.1116
INFO - 2016-02-10 21:08:51 --> Config Class Initialized
INFO - 2016-02-10 21:08:51 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:51 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:51 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:51 --> URI Class Initialized
INFO - 2016-02-10 21:08:51 --> Router Class Initialized
INFO - 2016-02-10 21:08:51 --> Output Class Initialized
INFO - 2016-02-10 21:08:51 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:51 --> Input Class Initialized
INFO - 2016-02-10 21:08:51 --> Language Class Initialized
INFO - 2016-02-10 21:08:51 --> Loader Class Initialized
INFO - 2016-02-10 21:08:51 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:51 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:51 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:51 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:51 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:52 --> Controller Class Initialized
INFO - 2016-02-10 21:08:52 --> Model Class Initialized
INFO - 2016-02-10 21:08:52 --> Model Class Initialized
INFO - 2016-02-10 21:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:52 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:52 --> Config Class Initialized
INFO - 2016-02-10 21:08:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:52 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:52 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:52 --> URI Class Initialized
INFO - 2016-02-10 21:08:52 --> Router Class Initialized
INFO - 2016-02-10 21:08:52 --> Output Class Initialized
INFO - 2016-02-10 21:08:52 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:52 --> Input Class Initialized
INFO - 2016-02-10 21:08:52 --> Language Class Initialized
INFO - 2016-02-10 21:08:52 --> Loader Class Initialized
INFO - 2016-02-10 21:08:52 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:52 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:52 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:52 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:52 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:53 --> Config Class Initialized
INFO - 2016-02-10 21:08:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:53 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:53 --> URI Class Initialized
DEBUG - 2016-02-10 21:08:53 --> No URI present. Default controller set.
INFO - 2016-02-10 21:08:53 --> Router Class Initialized
INFO - 2016-02-10 21:08:53 --> Output Class Initialized
INFO - 2016-02-10 21:08:53 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:53 --> Input Class Initialized
INFO - 2016-02-10 21:08:53 --> Language Class Initialized
INFO - 2016-02-10 21:08:53 --> Loader Class Initialized
INFO - 2016-02-10 21:08:53 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:53 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:53 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:53 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:53 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:53 --> Controller Class Initialized
INFO - 2016-02-10 21:08:53 --> Model Class Initialized
INFO - 2016-02-10 21:08:53 --> Model Class Initialized
INFO - 2016-02-10 21:08:53 --> Form Validation Class Initialized
INFO - 2016-02-10 21:08:53 --> Helper loaded: text_helper
INFO - 2016-02-10 21:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:08:53 --> Final output sent to browser
DEBUG - 2016-02-10 21:08:53 --> Total execution time: 1.1047
INFO - 2016-02-10 21:08:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:54 --> Controller Class Initialized
INFO - 2016-02-10 21:08:54 --> Model Class Initialized
INFO - 2016-02-10 21:08:54 --> Model Class Initialized
INFO - 2016-02-10 21:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:54 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:55 --> Config Class Initialized
INFO - 2016-02-10 21:08:55 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:55 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:55 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:55 --> URI Class Initialized
INFO - 2016-02-10 21:08:55 --> Router Class Initialized
INFO - 2016-02-10 21:08:55 --> Output Class Initialized
INFO - 2016-02-10 21:08:55 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:55 --> Input Class Initialized
INFO - 2016-02-10 21:08:55 --> Language Class Initialized
INFO - 2016-02-10 21:08:55 --> Loader Class Initialized
INFO - 2016-02-10 21:08:55 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:55 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:55 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:55 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:55 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:57 --> Controller Class Initialized
INFO - 2016-02-10 21:08:57 --> Model Class Initialized
INFO - 2016-02-10 21:08:57 --> Model Class Initialized
INFO - 2016-02-10 21:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:57 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:58 --> Config Class Initialized
INFO - 2016-02-10 21:08:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:58 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:58 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:58 --> URI Class Initialized
INFO - 2016-02-10 21:08:58 --> Router Class Initialized
INFO - 2016-02-10 21:08:58 --> Output Class Initialized
INFO - 2016-02-10 21:08:58 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:58 --> Input Class Initialized
INFO - 2016-02-10 21:08:58 --> Language Class Initialized
INFO - 2016-02-10 21:08:58 --> Loader Class Initialized
INFO - 2016-02-10 21:08:58 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:58 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:58 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:58 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:58 --> Database Driver Class Initialized
INFO - 2016-02-10 21:08:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:08:59 --> Controller Class Initialized
INFO - 2016-02-10 21:08:59 --> Model Class Initialized
INFO - 2016-02-10 21:08:59 --> Model Class Initialized
INFO - 2016-02-10 21:08:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:08:59 --> Pagination Class Initialized
INFO - 2016-02-10 21:08:59 --> Config Class Initialized
INFO - 2016-02-10 21:08:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:08:59 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:08:59 --> Utf8 Class Initialized
INFO - 2016-02-10 21:08:59 --> URI Class Initialized
INFO - 2016-02-10 21:08:59 --> Router Class Initialized
INFO - 2016-02-10 21:08:59 --> Output Class Initialized
INFO - 2016-02-10 21:08:59 --> Security Class Initialized
DEBUG - 2016-02-10 21:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:08:59 --> Input Class Initialized
INFO - 2016-02-10 21:08:59 --> Language Class Initialized
INFO - 2016-02-10 21:08:59 --> Loader Class Initialized
INFO - 2016-02-10 21:08:59 --> Helper loaded: url_helper
INFO - 2016-02-10 21:08:59 --> Helper loaded: file_helper
INFO - 2016-02-10 21:08:59 --> Helper loaded: date_helper
INFO - 2016-02-10 21:08:59 --> Helper loaded: form_helper
INFO - 2016-02-10 21:08:59 --> Database Driver Class Initialized
INFO - 2016-02-10 21:09:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:09:01 --> Controller Class Initialized
INFO - 2016-02-10 21:09:01 --> Model Class Initialized
INFO - 2016-02-10 21:09:01 --> Model Class Initialized
INFO - 2016-02-10 21:09:01 --> Form Validation Class Initialized
INFO - 2016-02-10 21:09:01 --> Helper loaded: text_helper
INFO - 2016-02-10 21:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:09:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:09:01 --> Final output sent to browser
DEBUG - 2016-02-10 21:09:01 --> Total execution time: 1.1116
INFO - 2016-02-10 21:09:24 --> Config Class Initialized
INFO - 2016-02-10 21:09:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:09:24 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:09:24 --> Utf8 Class Initialized
INFO - 2016-02-10 21:09:24 --> URI Class Initialized
INFO - 2016-02-10 21:09:24 --> Router Class Initialized
INFO - 2016-02-10 21:09:24 --> Output Class Initialized
INFO - 2016-02-10 21:09:24 --> Security Class Initialized
DEBUG - 2016-02-10 21:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:09:24 --> Input Class Initialized
INFO - 2016-02-10 21:09:24 --> Language Class Initialized
INFO - 2016-02-10 21:09:24 --> Loader Class Initialized
INFO - 2016-02-10 21:09:24 --> Helper loaded: url_helper
INFO - 2016-02-10 21:09:24 --> Helper loaded: file_helper
INFO - 2016-02-10 21:09:24 --> Helper loaded: date_helper
INFO - 2016-02-10 21:09:24 --> Helper loaded: form_helper
INFO - 2016-02-10 21:09:24 --> Database Driver Class Initialized
INFO - 2016-02-10 21:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:09:25 --> Controller Class Initialized
INFO - 2016-02-10 21:09:25 --> Model Class Initialized
INFO - 2016-02-10 21:09:25 --> Model Class Initialized
INFO - 2016-02-10 21:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:09:25 --> Pagination Class Initialized
INFO - 2016-02-10 21:09:26 --> Config Class Initialized
INFO - 2016-02-10 21:09:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:09:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:09:26 --> Utf8 Class Initialized
INFO - 2016-02-10 21:09:26 --> URI Class Initialized
INFO - 2016-02-10 21:09:26 --> Router Class Initialized
INFO - 2016-02-10 21:09:26 --> Output Class Initialized
INFO - 2016-02-10 21:09:26 --> Security Class Initialized
DEBUG - 2016-02-10 21:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:09:26 --> Input Class Initialized
INFO - 2016-02-10 21:09:26 --> Language Class Initialized
INFO - 2016-02-10 21:09:26 --> Loader Class Initialized
INFO - 2016-02-10 21:09:26 --> Helper loaded: url_helper
INFO - 2016-02-10 21:09:26 --> Helper loaded: file_helper
INFO - 2016-02-10 21:09:26 --> Helper loaded: date_helper
INFO - 2016-02-10 21:09:26 --> Helper loaded: form_helper
INFO - 2016-02-10 21:09:26 --> Database Driver Class Initialized
INFO - 2016-02-10 21:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:09:27 --> Controller Class Initialized
INFO - 2016-02-10 21:09:27 --> Model Class Initialized
INFO - 2016-02-10 21:09:27 --> Model Class Initialized
INFO - 2016-02-10 21:09:27 --> Form Validation Class Initialized
INFO - 2016-02-10 21:09:27 --> Helper loaded: text_helper
INFO - 2016-02-10 21:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:09:27 --> Final output sent to browser
DEBUG - 2016-02-10 21:09:27 --> Total execution time: 1.1054
INFO - 2016-02-10 21:10:55 --> Config Class Initialized
INFO - 2016-02-10 21:10:55 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:10:55 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:10:55 --> Utf8 Class Initialized
INFO - 2016-02-10 21:10:55 --> URI Class Initialized
DEBUG - 2016-02-10 21:10:55 --> No URI present. Default controller set.
INFO - 2016-02-10 21:10:55 --> Router Class Initialized
INFO - 2016-02-10 21:10:55 --> Output Class Initialized
INFO - 2016-02-10 21:10:55 --> Security Class Initialized
DEBUG - 2016-02-10 21:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:10:55 --> Input Class Initialized
INFO - 2016-02-10 21:10:55 --> Language Class Initialized
INFO - 2016-02-10 21:10:55 --> Loader Class Initialized
INFO - 2016-02-10 21:10:55 --> Helper loaded: url_helper
INFO - 2016-02-10 21:10:55 --> Helper loaded: file_helper
INFO - 2016-02-10 21:10:55 --> Helper loaded: date_helper
INFO - 2016-02-10 21:10:55 --> Helper loaded: form_helper
INFO - 2016-02-10 21:10:55 --> Database Driver Class Initialized
INFO - 2016-02-10 21:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:10:56 --> Controller Class Initialized
INFO - 2016-02-10 21:10:56 --> Model Class Initialized
INFO - 2016-02-10 21:10:56 --> Model Class Initialized
INFO - 2016-02-10 21:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:10:56 --> Pagination Class Initialized
INFO - 2016-02-10 21:10:59 --> Config Class Initialized
INFO - 2016-02-10 21:10:59 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:10:59 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:10:59 --> Utf8 Class Initialized
INFO - 2016-02-10 21:10:59 --> URI Class Initialized
INFO - 2016-02-10 21:10:59 --> Router Class Initialized
INFO - 2016-02-10 21:10:59 --> Output Class Initialized
INFO - 2016-02-10 21:10:59 --> Security Class Initialized
DEBUG - 2016-02-10 21:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:10:59 --> Input Class Initialized
INFO - 2016-02-10 21:10:59 --> Language Class Initialized
INFO - 2016-02-10 21:10:59 --> Loader Class Initialized
INFO - 2016-02-10 21:10:59 --> Helper loaded: url_helper
INFO - 2016-02-10 21:10:59 --> Helper loaded: file_helper
INFO - 2016-02-10 21:10:59 --> Helper loaded: date_helper
INFO - 2016-02-10 21:10:59 --> Helper loaded: form_helper
INFO - 2016-02-10 21:10:59 --> Database Driver Class Initialized
INFO - 2016-02-10 21:11:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:11:00 --> Controller Class Initialized
INFO - 2016-02-10 21:11:00 --> Model Class Initialized
INFO - 2016-02-10 21:11:00 --> Model Class Initialized
INFO - 2016-02-10 21:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:11:00 --> Pagination Class Initialized
INFO - 2016-02-10 21:11:02 --> Config Class Initialized
INFO - 2016-02-10 21:11:02 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:11:02 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:11:02 --> Utf8 Class Initialized
INFO - 2016-02-10 21:11:02 --> URI Class Initialized
INFO - 2016-02-10 21:11:02 --> Router Class Initialized
INFO - 2016-02-10 21:11:02 --> Output Class Initialized
INFO - 2016-02-10 21:11:02 --> Security Class Initialized
DEBUG - 2016-02-10 21:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:11:02 --> Input Class Initialized
INFO - 2016-02-10 21:11:02 --> Language Class Initialized
INFO - 2016-02-10 21:11:02 --> Loader Class Initialized
INFO - 2016-02-10 21:11:02 --> Helper loaded: url_helper
INFO - 2016-02-10 21:11:02 --> Helper loaded: file_helper
INFO - 2016-02-10 21:11:02 --> Helper loaded: date_helper
INFO - 2016-02-10 21:11:02 --> Helper loaded: form_helper
INFO - 2016-02-10 21:11:02 --> Database Driver Class Initialized
INFO - 2016-02-10 21:11:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:11:03 --> Controller Class Initialized
INFO - 2016-02-10 21:11:03 --> Model Class Initialized
INFO - 2016-02-10 21:11:03 --> Model Class Initialized
INFO - 2016-02-10 21:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:11:03 --> Pagination Class Initialized
INFO - 2016-02-10 21:11:03 --> Config Class Initialized
INFO - 2016-02-10 21:11:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:11:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:11:03 --> Utf8 Class Initialized
INFO - 2016-02-10 21:11:03 --> URI Class Initialized
INFO - 2016-02-10 21:11:03 --> Router Class Initialized
INFO - 2016-02-10 21:11:03 --> Output Class Initialized
INFO - 2016-02-10 21:11:03 --> Security Class Initialized
DEBUG - 2016-02-10 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:11:03 --> Input Class Initialized
INFO - 2016-02-10 21:11:03 --> Language Class Initialized
INFO - 2016-02-10 21:11:03 --> Loader Class Initialized
INFO - 2016-02-10 21:11:03 --> Helper loaded: url_helper
INFO - 2016-02-10 21:11:03 --> Helper loaded: file_helper
INFO - 2016-02-10 21:11:03 --> Helper loaded: date_helper
INFO - 2016-02-10 21:11:03 --> Helper loaded: form_helper
INFO - 2016-02-10 21:11:03 --> Database Driver Class Initialized
INFO - 2016-02-10 21:11:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:11:04 --> Controller Class Initialized
INFO - 2016-02-10 21:11:04 --> Model Class Initialized
INFO - 2016-02-10 21:11:04 --> Model Class Initialized
INFO - 2016-02-10 21:11:04 --> Form Validation Class Initialized
INFO - 2016-02-10 21:11:04 --> Helper loaded: text_helper
INFO - 2016-02-10 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:11:04 --> Final output sent to browser
DEBUG - 2016-02-10 21:11:04 --> Total execution time: 1.1097
INFO - 2016-02-10 21:11:07 --> Config Class Initialized
INFO - 2016-02-10 21:11:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:11:07 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:11:07 --> Utf8 Class Initialized
INFO - 2016-02-10 21:11:07 --> URI Class Initialized
INFO - 2016-02-10 21:11:07 --> Router Class Initialized
INFO - 2016-02-10 21:11:07 --> Output Class Initialized
INFO - 2016-02-10 21:11:07 --> Security Class Initialized
DEBUG - 2016-02-10 21:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:11:07 --> Input Class Initialized
INFO - 2016-02-10 21:11:07 --> Language Class Initialized
INFO - 2016-02-10 21:11:07 --> Loader Class Initialized
INFO - 2016-02-10 21:11:07 --> Helper loaded: url_helper
INFO - 2016-02-10 21:11:07 --> Helper loaded: file_helper
INFO - 2016-02-10 21:11:07 --> Helper loaded: date_helper
INFO - 2016-02-10 21:11:07 --> Helper loaded: form_helper
INFO - 2016-02-10 21:11:07 --> Database Driver Class Initialized
INFO - 2016-02-10 21:11:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:11:08 --> Controller Class Initialized
INFO - 2016-02-10 21:11:08 --> Model Class Initialized
INFO - 2016-02-10 21:11:08 --> Model Class Initialized
INFO - 2016-02-10 21:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:11:08 --> Pagination Class Initialized
INFO - 2016-02-10 21:11:08 --> Config Class Initialized
INFO - 2016-02-10 21:11:08 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:11:08 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:11:08 --> Utf8 Class Initialized
INFO - 2016-02-10 21:11:08 --> URI Class Initialized
INFO - 2016-02-10 21:11:08 --> Router Class Initialized
INFO - 2016-02-10 21:11:08 --> Output Class Initialized
INFO - 2016-02-10 21:11:08 --> Security Class Initialized
DEBUG - 2016-02-10 21:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:11:08 --> Input Class Initialized
INFO - 2016-02-10 21:11:08 --> Language Class Initialized
INFO - 2016-02-10 21:11:08 --> Loader Class Initialized
INFO - 2016-02-10 21:11:08 --> Helper loaded: url_helper
INFO - 2016-02-10 21:11:08 --> Helper loaded: file_helper
INFO - 2016-02-10 21:11:08 --> Helper loaded: date_helper
INFO - 2016-02-10 21:11:08 --> Helper loaded: form_helper
INFO - 2016-02-10 21:11:08 --> Database Driver Class Initialized
INFO - 2016-02-10 21:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:11:09 --> Controller Class Initialized
INFO - 2016-02-10 21:11:09 --> Model Class Initialized
INFO - 2016-02-10 21:11:09 --> Model Class Initialized
INFO - 2016-02-10 21:11:10 --> Form Validation Class Initialized
INFO - 2016-02-10 21:11:10 --> Helper loaded: text_helper
INFO - 2016-02-10 21:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:11:10 --> Final output sent to browser
DEBUG - 2016-02-10 21:11:10 --> Total execution time: 1.1099
INFO - 2016-02-10 21:21:29 --> Config Class Initialized
INFO - 2016-02-10 21:21:29 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:21:29 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:21:29 --> Utf8 Class Initialized
INFO - 2016-02-10 21:21:29 --> URI Class Initialized
INFO - 2016-02-10 21:21:29 --> Router Class Initialized
INFO - 2016-02-10 21:21:29 --> Output Class Initialized
INFO - 2016-02-10 21:21:29 --> Security Class Initialized
DEBUG - 2016-02-10 21:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:21:29 --> Input Class Initialized
INFO - 2016-02-10 21:21:29 --> Language Class Initialized
INFO - 2016-02-10 21:21:29 --> Loader Class Initialized
INFO - 2016-02-10 21:21:29 --> Helper loaded: url_helper
INFO - 2016-02-10 21:21:29 --> Helper loaded: file_helper
INFO - 2016-02-10 21:21:29 --> Helper loaded: date_helper
INFO - 2016-02-10 21:21:29 --> Helper loaded: form_helper
INFO - 2016-02-10 21:21:29 --> Database Driver Class Initialized
INFO - 2016-02-10 21:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:21:30 --> Controller Class Initialized
INFO - 2016-02-10 21:21:30 --> Model Class Initialized
INFO - 2016-02-10 21:21:30 --> Model Class Initialized
INFO - 2016-02-10 21:21:30 --> Form Validation Class Initialized
INFO - 2016-02-10 21:21:30 --> Helper loaded: text_helper
INFO - 2016-02-10 21:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:21:30 --> Final output sent to browser
DEBUG - 2016-02-10 21:21:30 --> Total execution time: 1.0890
INFO - 2016-02-10 21:21:43 --> Config Class Initialized
INFO - 2016-02-10 21:21:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:21:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:21:43 --> Utf8 Class Initialized
INFO - 2016-02-10 21:21:43 --> URI Class Initialized
DEBUG - 2016-02-10 21:21:43 --> No URI present. Default controller set.
INFO - 2016-02-10 21:21:43 --> Router Class Initialized
INFO - 2016-02-10 21:21:43 --> Output Class Initialized
INFO - 2016-02-10 21:21:43 --> Security Class Initialized
DEBUG - 2016-02-10 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:21:43 --> Input Class Initialized
INFO - 2016-02-10 21:21:43 --> Language Class Initialized
INFO - 2016-02-10 21:21:43 --> Loader Class Initialized
INFO - 2016-02-10 21:21:43 --> Helper loaded: url_helper
INFO - 2016-02-10 21:21:43 --> Helper loaded: file_helper
INFO - 2016-02-10 21:21:43 --> Helper loaded: date_helper
INFO - 2016-02-10 21:21:43 --> Helper loaded: form_helper
INFO - 2016-02-10 21:21:43 --> Database Driver Class Initialized
INFO - 2016-02-10 21:21:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:21:44 --> Controller Class Initialized
INFO - 2016-02-10 21:21:44 --> Model Class Initialized
INFO - 2016-02-10 21:21:44 --> Model Class Initialized
INFO - 2016-02-10 21:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:21:44 --> Pagination Class Initialized
INFO - 2016-02-10 21:21:47 --> Config Class Initialized
INFO - 2016-02-10 21:21:47 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:21:47 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:21:47 --> Utf8 Class Initialized
INFO - 2016-02-10 21:21:47 --> URI Class Initialized
INFO - 2016-02-10 21:21:47 --> Router Class Initialized
INFO - 2016-02-10 21:21:47 --> Output Class Initialized
INFO - 2016-02-10 21:21:47 --> Security Class Initialized
DEBUG - 2016-02-10 21:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:21:47 --> Input Class Initialized
INFO - 2016-02-10 21:21:47 --> Language Class Initialized
INFO - 2016-02-10 21:21:47 --> Loader Class Initialized
INFO - 2016-02-10 21:21:47 --> Helper loaded: url_helper
INFO - 2016-02-10 21:21:47 --> Helper loaded: file_helper
INFO - 2016-02-10 21:21:47 --> Helper loaded: date_helper
INFO - 2016-02-10 21:21:47 --> Helper loaded: form_helper
INFO - 2016-02-10 21:21:47 --> Database Driver Class Initialized
INFO - 2016-02-10 21:21:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:21:48 --> Controller Class Initialized
INFO - 2016-02-10 21:21:48 --> Model Class Initialized
INFO - 2016-02-10 21:21:48 --> Model Class Initialized
INFO - 2016-02-10 21:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:21:48 --> Pagination Class Initialized
INFO - 2016-02-10 21:22:27 --> Config Class Initialized
INFO - 2016-02-10 21:22:27 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:22:27 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:22:27 --> Utf8 Class Initialized
INFO - 2016-02-10 21:22:27 --> URI Class Initialized
INFO - 2016-02-10 21:22:27 --> Router Class Initialized
INFO - 2016-02-10 21:22:27 --> Output Class Initialized
INFO - 2016-02-10 21:22:27 --> Security Class Initialized
DEBUG - 2016-02-10 21:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:22:27 --> Input Class Initialized
INFO - 2016-02-10 21:22:27 --> Language Class Initialized
INFO - 2016-02-10 21:22:27 --> Loader Class Initialized
INFO - 2016-02-10 21:22:27 --> Helper loaded: url_helper
INFO - 2016-02-10 21:22:27 --> Helper loaded: file_helper
INFO - 2016-02-10 21:22:27 --> Helper loaded: date_helper
INFO - 2016-02-10 21:22:27 --> Helper loaded: form_helper
INFO - 2016-02-10 21:22:27 --> Database Driver Class Initialized
INFO - 2016-02-10 21:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:22:28 --> Controller Class Initialized
INFO - 2016-02-10 21:22:28 --> Model Class Initialized
INFO - 2016-02-10 21:22:28 --> Model Class Initialized
INFO - 2016-02-10 21:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:22:28 --> Pagination Class Initialized
INFO - 2016-02-10 21:23:21 --> Config Class Initialized
INFO - 2016-02-10 21:23:21 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:21 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:23:21 --> Utf8 Class Initialized
INFO - 2016-02-10 21:23:21 --> URI Class Initialized
INFO - 2016-02-10 21:23:21 --> Router Class Initialized
INFO - 2016-02-10 21:23:21 --> Output Class Initialized
INFO - 2016-02-10 21:23:21 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:23:21 --> Input Class Initialized
INFO - 2016-02-10 21:23:21 --> Language Class Initialized
INFO - 2016-02-10 21:23:21 --> Loader Class Initialized
INFO - 2016-02-10 21:23:21 --> Helper loaded: url_helper
INFO - 2016-02-10 21:23:21 --> Helper loaded: file_helper
INFO - 2016-02-10 21:23:21 --> Helper loaded: date_helper
INFO - 2016-02-10 21:23:21 --> Helper loaded: form_helper
INFO - 2016-02-10 21:23:21 --> Database Driver Class Initialized
INFO - 2016-02-10 21:23:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:23:22 --> Controller Class Initialized
INFO - 2016-02-10 21:23:22 --> Model Class Initialized
INFO - 2016-02-10 21:23:22 --> Model Class Initialized
INFO - 2016-02-10 21:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:23:22 --> Pagination Class Initialized
INFO - 2016-02-10 21:23:23 --> Config Class Initialized
INFO - 2016-02-10 21:23:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:24 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:23:24 --> Utf8 Class Initialized
INFO - 2016-02-10 21:23:24 --> URI Class Initialized
INFO - 2016-02-10 21:23:24 --> Router Class Initialized
INFO - 2016-02-10 21:23:24 --> Output Class Initialized
INFO - 2016-02-10 21:23:24 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:23:24 --> Input Class Initialized
INFO - 2016-02-10 21:23:24 --> Language Class Initialized
INFO - 2016-02-10 21:23:24 --> Loader Class Initialized
INFO - 2016-02-10 21:23:24 --> Helper loaded: url_helper
INFO - 2016-02-10 21:23:24 --> Helper loaded: file_helper
INFO - 2016-02-10 21:23:24 --> Helper loaded: date_helper
INFO - 2016-02-10 21:23:24 --> Helper loaded: form_helper
INFO - 2016-02-10 21:23:24 --> Database Driver Class Initialized
INFO - 2016-02-10 21:23:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:23:25 --> Controller Class Initialized
INFO - 2016-02-10 21:23:25 --> Model Class Initialized
INFO - 2016-02-10 21:23:25 --> Model Class Initialized
INFO - 2016-02-10 21:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:23:25 --> Pagination Class Initialized
INFO - 2016-02-10 21:23:28 --> Config Class Initialized
INFO - 2016-02-10 21:23:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:23:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:23:28 --> Utf8 Class Initialized
INFO - 2016-02-10 21:23:28 --> URI Class Initialized
INFO - 2016-02-10 21:23:28 --> Router Class Initialized
INFO - 2016-02-10 21:23:28 --> Output Class Initialized
INFO - 2016-02-10 21:23:28 --> Security Class Initialized
DEBUG - 2016-02-10 21:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:23:28 --> Input Class Initialized
INFO - 2016-02-10 21:23:28 --> Language Class Initialized
INFO - 2016-02-10 21:23:28 --> Loader Class Initialized
INFO - 2016-02-10 21:23:28 --> Helper loaded: url_helper
INFO - 2016-02-10 21:23:28 --> Helper loaded: file_helper
INFO - 2016-02-10 21:23:28 --> Helper loaded: date_helper
INFO - 2016-02-10 21:23:28 --> Helper loaded: form_helper
INFO - 2016-02-10 21:23:28 --> Database Driver Class Initialized
INFO - 2016-02-10 21:23:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:23:29 --> Controller Class Initialized
INFO - 2016-02-10 21:23:29 --> Model Class Initialized
INFO - 2016-02-10 21:23:29 --> Model Class Initialized
INFO - 2016-02-10 21:23:29 --> Form Validation Class Initialized
INFO - 2016-02-10 21:23:29 --> Helper loaded: text_helper
INFO - 2016-02-10 21:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:23:29 --> Final output sent to browser
DEBUG - 2016-02-10 21:23:29 --> Total execution time: 1.1020
INFO - 2016-02-10 21:28:26 --> Config Class Initialized
INFO - 2016-02-10 21:28:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:28:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:28:26 --> Utf8 Class Initialized
INFO - 2016-02-10 21:28:26 --> URI Class Initialized
INFO - 2016-02-10 21:28:26 --> Router Class Initialized
INFO - 2016-02-10 21:28:26 --> Output Class Initialized
INFO - 2016-02-10 21:28:26 --> Security Class Initialized
DEBUG - 2016-02-10 21:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:28:26 --> Input Class Initialized
INFO - 2016-02-10 21:28:26 --> Language Class Initialized
INFO - 2016-02-10 21:28:26 --> Loader Class Initialized
INFO - 2016-02-10 21:28:26 --> Helper loaded: url_helper
INFO - 2016-02-10 21:28:26 --> Helper loaded: file_helper
INFO - 2016-02-10 21:28:26 --> Helper loaded: date_helper
INFO - 2016-02-10 21:28:26 --> Helper loaded: form_helper
INFO - 2016-02-10 21:28:27 --> Database Driver Class Initialized
INFO - 2016-02-10 21:28:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:28:28 --> Controller Class Initialized
INFO - 2016-02-10 21:28:28 --> Model Class Initialized
INFO - 2016-02-10 21:28:28 --> Model Class Initialized
INFO - 2016-02-10 21:28:28 --> Form Validation Class Initialized
INFO - 2016-02-10 21:28:28 --> Helper loaded: text_helper
INFO - 2016-02-10 21:28:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:28:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:28:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:28:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:28:28 --> Final output sent to browser
DEBUG - 2016-02-10 21:28:28 --> Total execution time: 1.1070
INFO - 2016-02-10 21:28:48 --> Config Class Initialized
INFO - 2016-02-10 21:28:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:28:48 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:28:48 --> Utf8 Class Initialized
INFO - 2016-02-10 21:28:48 --> URI Class Initialized
INFO - 2016-02-10 21:28:48 --> Router Class Initialized
INFO - 2016-02-10 21:28:48 --> Output Class Initialized
INFO - 2016-02-10 21:28:48 --> Security Class Initialized
DEBUG - 2016-02-10 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:28:48 --> Input Class Initialized
INFO - 2016-02-10 21:28:48 --> Language Class Initialized
INFO - 2016-02-10 21:28:48 --> Loader Class Initialized
INFO - 2016-02-10 21:28:48 --> Helper loaded: url_helper
INFO - 2016-02-10 21:28:48 --> Helper loaded: file_helper
INFO - 2016-02-10 21:28:48 --> Helper loaded: date_helper
INFO - 2016-02-10 21:28:48 --> Helper loaded: form_helper
INFO - 2016-02-10 21:28:48 --> Database Driver Class Initialized
INFO - 2016-02-10 21:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:28:49 --> Controller Class Initialized
INFO - 2016-02-10 21:28:49 --> Model Class Initialized
INFO - 2016-02-10 21:28:49 --> Model Class Initialized
INFO - 2016-02-10 21:28:49 --> Form Validation Class Initialized
INFO - 2016-02-10 21:28:49 --> Helper loaded: text_helper
INFO - 2016-02-10 21:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:28:49 --> Final output sent to browser
DEBUG - 2016-02-10 21:28:49 --> Total execution time: 1.1043
INFO - 2016-02-10 21:29:07 --> Config Class Initialized
INFO - 2016-02-10 21:29:07 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:07 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:29:07 --> Utf8 Class Initialized
INFO - 2016-02-10 21:29:07 --> URI Class Initialized
INFO - 2016-02-10 21:29:08 --> Router Class Initialized
INFO - 2016-02-10 21:29:08 --> Output Class Initialized
INFO - 2016-02-10 21:29:08 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:29:08 --> Input Class Initialized
INFO - 2016-02-10 21:29:08 --> Language Class Initialized
INFO - 2016-02-10 21:29:08 --> Loader Class Initialized
INFO - 2016-02-10 21:29:08 --> Helper loaded: url_helper
INFO - 2016-02-10 21:29:08 --> Helper loaded: file_helper
INFO - 2016-02-10 21:29:08 --> Helper loaded: date_helper
INFO - 2016-02-10 21:29:08 --> Helper loaded: form_helper
INFO - 2016-02-10 21:29:08 --> Database Driver Class Initialized
INFO - 2016-02-10 21:29:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:29:09 --> Controller Class Initialized
INFO - 2016-02-10 21:29:09 --> Model Class Initialized
INFO - 2016-02-10 21:29:09 --> Model Class Initialized
INFO - 2016-02-10 21:29:09 --> Form Validation Class Initialized
INFO - 2016-02-10 21:29:09 --> Helper loaded: text_helper
INFO - 2016-02-10 21:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:29:09 --> Final output sent to browser
DEBUG - 2016-02-10 21:29:09 --> Total execution time: 1.1035
INFO - 2016-02-10 21:29:13 --> Config Class Initialized
INFO - 2016-02-10 21:29:13 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:13 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:29:13 --> Utf8 Class Initialized
INFO - 2016-02-10 21:29:13 --> URI Class Initialized
DEBUG - 2016-02-10 21:29:13 --> No URI present. Default controller set.
INFO - 2016-02-10 21:29:13 --> Router Class Initialized
INFO - 2016-02-10 21:29:13 --> Output Class Initialized
INFO - 2016-02-10 21:29:13 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:29:13 --> Input Class Initialized
INFO - 2016-02-10 21:29:13 --> Language Class Initialized
INFO - 2016-02-10 21:29:13 --> Loader Class Initialized
INFO - 2016-02-10 21:29:13 --> Helper loaded: url_helper
INFO - 2016-02-10 21:29:13 --> Helper loaded: file_helper
INFO - 2016-02-10 21:29:13 --> Helper loaded: date_helper
INFO - 2016-02-10 21:29:13 --> Helper loaded: form_helper
INFO - 2016-02-10 21:29:13 --> Database Driver Class Initialized
INFO - 2016-02-10 21:29:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:29:14 --> Controller Class Initialized
INFO - 2016-02-10 21:29:14 --> Model Class Initialized
INFO - 2016-02-10 21:29:14 --> Model Class Initialized
INFO - 2016-02-10 21:29:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:29:14 --> Pagination Class Initialized
INFO - 2016-02-10 21:29:17 --> Config Class Initialized
INFO - 2016-02-10 21:29:17 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:17 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:29:17 --> Utf8 Class Initialized
INFO - 2016-02-10 21:29:17 --> URI Class Initialized
INFO - 2016-02-10 21:29:17 --> Router Class Initialized
INFO - 2016-02-10 21:29:17 --> Output Class Initialized
INFO - 2016-02-10 21:29:17 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:29:17 --> Input Class Initialized
INFO - 2016-02-10 21:29:17 --> Language Class Initialized
INFO - 2016-02-10 21:29:17 --> Loader Class Initialized
INFO - 2016-02-10 21:29:17 --> Helper loaded: url_helper
INFO - 2016-02-10 21:29:17 --> Helper loaded: file_helper
INFO - 2016-02-10 21:29:17 --> Helper loaded: date_helper
INFO - 2016-02-10 21:29:17 --> Helper loaded: form_helper
INFO - 2016-02-10 21:29:17 --> Database Driver Class Initialized
INFO - 2016-02-10 21:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:29:18 --> Controller Class Initialized
INFO - 2016-02-10 21:29:18 --> Model Class Initialized
INFO - 2016-02-10 21:29:18 --> Model Class Initialized
INFO - 2016-02-10 21:29:18 --> Form Validation Class Initialized
INFO - 2016-02-10 21:29:18 --> Helper loaded: text_helper
INFO - 2016-02-10 21:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-10 21:29:18 --> Model Class Initialized
INFO - 2016-02-10 21:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-10 21:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:29:18 --> Final output sent to browser
DEBUG - 2016-02-10 21:29:18 --> Total execution time: 1.1149
INFO - 2016-02-10 21:29:21 --> Config Class Initialized
INFO - 2016-02-10 21:29:21 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:21 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:29:21 --> Utf8 Class Initialized
INFO - 2016-02-10 21:29:21 --> URI Class Initialized
INFO - 2016-02-10 21:29:21 --> Router Class Initialized
INFO - 2016-02-10 21:29:21 --> Output Class Initialized
INFO - 2016-02-10 21:29:21 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:29:21 --> Input Class Initialized
INFO - 2016-02-10 21:29:21 --> Language Class Initialized
INFO - 2016-02-10 21:29:21 --> Loader Class Initialized
INFO - 2016-02-10 21:29:21 --> Helper loaded: url_helper
INFO - 2016-02-10 21:29:21 --> Helper loaded: file_helper
INFO - 2016-02-10 21:29:21 --> Helper loaded: date_helper
INFO - 2016-02-10 21:29:21 --> Helper loaded: form_helper
INFO - 2016-02-10 21:29:21 --> Database Driver Class Initialized
INFO - 2016-02-10 21:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:29:22 --> Controller Class Initialized
INFO - 2016-02-10 21:29:22 --> Model Class Initialized
INFO - 2016-02-10 21:29:22 --> Model Class Initialized
INFO - 2016-02-10 21:29:22 --> Form Validation Class Initialized
INFO - 2016-02-10 21:29:22 --> Helper loaded: text_helper
INFO - 2016-02-10 21:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:29:22 --> Final output sent to browser
DEBUG - 2016-02-10 21:29:22 --> Total execution time: 1.1142
INFO - 2016-02-10 21:29:26 --> Config Class Initialized
INFO - 2016-02-10 21:29:26 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:29:26 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:29:26 --> Utf8 Class Initialized
INFO - 2016-02-10 21:29:26 --> URI Class Initialized
DEBUG - 2016-02-10 21:29:26 --> No URI present. Default controller set.
INFO - 2016-02-10 21:29:26 --> Router Class Initialized
INFO - 2016-02-10 21:29:26 --> Output Class Initialized
INFO - 2016-02-10 21:29:26 --> Security Class Initialized
DEBUG - 2016-02-10 21:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:29:26 --> Input Class Initialized
INFO - 2016-02-10 21:29:26 --> Language Class Initialized
INFO - 2016-02-10 21:29:26 --> Loader Class Initialized
INFO - 2016-02-10 21:29:26 --> Helper loaded: url_helper
INFO - 2016-02-10 21:29:26 --> Helper loaded: file_helper
INFO - 2016-02-10 21:29:26 --> Helper loaded: date_helper
INFO - 2016-02-10 21:29:26 --> Helper loaded: form_helper
INFO - 2016-02-10 21:29:26 --> Database Driver Class Initialized
INFO - 2016-02-10 21:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:29:27 --> Controller Class Initialized
INFO - 2016-02-10 21:29:27 --> Model Class Initialized
INFO - 2016-02-10 21:29:27 --> Model Class Initialized
INFO - 2016-02-10 21:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:29:27 --> Pagination Class Initialized
INFO - 2016-02-10 21:35:53 --> Config Class Initialized
INFO - 2016-02-10 21:35:53 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:35:53 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:35:53 --> Utf8 Class Initialized
INFO - 2016-02-10 21:35:53 --> URI Class Initialized
INFO - 2016-02-10 21:35:53 --> Router Class Initialized
INFO - 2016-02-10 21:35:53 --> Output Class Initialized
INFO - 2016-02-10 21:35:53 --> Security Class Initialized
DEBUG - 2016-02-10 21:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:35:53 --> Input Class Initialized
INFO - 2016-02-10 21:35:53 --> Language Class Initialized
INFO - 2016-02-10 21:35:53 --> Loader Class Initialized
INFO - 2016-02-10 21:35:53 --> Helper loaded: url_helper
INFO - 2016-02-10 21:35:53 --> Helper loaded: file_helper
INFO - 2016-02-10 21:35:53 --> Helper loaded: date_helper
INFO - 2016-02-10 21:35:53 --> Helper loaded: form_helper
INFO - 2016-02-10 21:35:53 --> Database Driver Class Initialized
INFO - 2016-02-10 21:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:35:54 --> Controller Class Initialized
INFO - 2016-02-10 21:35:54 --> Model Class Initialized
INFO - 2016-02-10 21:35:54 --> Model Class Initialized
INFO - 2016-02-10 21:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:35:54 --> Pagination Class Initialized
INFO - 2016-02-10 21:38:28 --> Config Class Initialized
INFO - 2016-02-10 21:38:28 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:38:28 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:38:28 --> Utf8 Class Initialized
INFO - 2016-02-10 21:38:28 --> URI Class Initialized
INFO - 2016-02-10 21:38:28 --> Router Class Initialized
INFO - 2016-02-10 21:38:28 --> Output Class Initialized
INFO - 2016-02-10 21:38:28 --> Security Class Initialized
DEBUG - 2016-02-10 21:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:38:28 --> Input Class Initialized
INFO - 2016-02-10 21:38:28 --> Language Class Initialized
INFO - 2016-02-10 21:38:28 --> Loader Class Initialized
INFO - 2016-02-10 21:38:28 --> Helper loaded: url_helper
INFO - 2016-02-10 21:38:29 --> Helper loaded: file_helper
INFO - 2016-02-10 21:38:29 --> Helper loaded: date_helper
INFO - 2016-02-10 21:38:29 --> Helper loaded: form_helper
INFO - 2016-02-10 21:38:29 --> Database Driver Class Initialized
INFO - 2016-02-10 21:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:38:30 --> Controller Class Initialized
INFO - 2016-02-10 21:38:30 --> Model Class Initialized
INFO - 2016-02-10 21:38:30 --> Model Class Initialized
INFO - 2016-02-10 21:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:38:30 --> Pagination Class Initialized
INFO - 2016-02-10 21:38:36 --> Config Class Initialized
INFO - 2016-02-10 21:38:36 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:38:36 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:38:36 --> Utf8 Class Initialized
INFO - 2016-02-10 21:38:36 --> URI Class Initialized
INFO - 2016-02-10 21:38:36 --> Router Class Initialized
INFO - 2016-02-10 21:38:36 --> Output Class Initialized
INFO - 2016-02-10 21:38:36 --> Security Class Initialized
DEBUG - 2016-02-10 21:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:38:36 --> Input Class Initialized
INFO - 2016-02-10 21:38:36 --> Language Class Initialized
INFO - 2016-02-10 21:38:36 --> Loader Class Initialized
INFO - 2016-02-10 21:38:36 --> Helper loaded: url_helper
INFO - 2016-02-10 21:38:36 --> Helper loaded: file_helper
INFO - 2016-02-10 21:38:36 --> Helper loaded: date_helper
INFO - 2016-02-10 21:38:36 --> Helper loaded: form_helper
INFO - 2016-02-10 21:38:36 --> Database Driver Class Initialized
INFO - 2016-02-10 21:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:38:37 --> Controller Class Initialized
INFO - 2016-02-10 21:38:37 --> Model Class Initialized
INFO - 2016-02-10 21:38:37 --> Model Class Initialized
INFO - 2016-02-10 21:38:37 --> Form Validation Class Initialized
INFO - 2016-02-10 21:38:37 --> Helper loaded: text_helper
INFO - 2016-02-10 21:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-10 21:38:37 --> Final output sent to browser
DEBUG - 2016-02-10 21:38:37 --> Total execution time: 1.0944
INFO - 2016-02-10 21:39:41 --> Config Class Initialized
INFO - 2016-02-10 21:39:41 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:39:41 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:39:41 --> Utf8 Class Initialized
INFO - 2016-02-10 21:39:41 --> URI Class Initialized
INFO - 2016-02-10 21:39:41 --> Router Class Initialized
INFO - 2016-02-10 21:39:41 --> Output Class Initialized
INFO - 2016-02-10 21:39:41 --> Security Class Initialized
DEBUG - 2016-02-10 21:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:39:41 --> Input Class Initialized
INFO - 2016-02-10 21:39:41 --> Language Class Initialized
INFO - 2016-02-10 21:39:41 --> Loader Class Initialized
INFO - 2016-02-10 21:39:41 --> Helper loaded: url_helper
INFO - 2016-02-10 21:39:41 --> Helper loaded: file_helper
INFO - 2016-02-10 21:39:41 --> Helper loaded: date_helper
INFO - 2016-02-10 21:39:41 --> Helper loaded: form_helper
INFO - 2016-02-10 21:39:41 --> Database Driver Class Initialized
INFO - 2016-02-10 21:39:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:39:42 --> Controller Class Initialized
INFO - 2016-02-10 21:39:42 --> Model Class Initialized
INFO - 2016-02-10 21:39:42 --> Model Class Initialized
INFO - 2016-02-10 21:39:42 --> Form Validation Class Initialized
INFO - 2016-02-10 21:39:42 --> Helper loaded: text_helper
INFO - 2016-02-10 21:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-10 21:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-10 21:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-10 21:39:42 --> Final output sent to browser
DEBUG - 2016-02-10 21:39:42 --> Total execution time: 1.1247
INFO - 2016-02-10 21:39:50 --> Config Class Initialized
INFO - 2016-02-10 21:39:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:39:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:39:50 --> Utf8 Class Initialized
INFO - 2016-02-10 21:39:50 --> URI Class Initialized
INFO - 2016-02-10 21:39:50 --> Router Class Initialized
INFO - 2016-02-10 21:39:50 --> Output Class Initialized
INFO - 2016-02-10 21:39:50 --> Security Class Initialized
DEBUG - 2016-02-10 21:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:39:50 --> Input Class Initialized
INFO - 2016-02-10 21:39:50 --> Language Class Initialized
INFO - 2016-02-10 21:39:50 --> Loader Class Initialized
INFO - 2016-02-10 21:39:50 --> Helper loaded: url_helper
INFO - 2016-02-10 21:39:50 --> Helper loaded: file_helper
INFO - 2016-02-10 21:39:50 --> Helper loaded: date_helper
INFO - 2016-02-10 21:39:50 --> Helper loaded: form_helper
INFO - 2016-02-10 21:39:50 --> Database Driver Class Initialized
INFO - 2016-02-10 21:39:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:39:51 --> Controller Class Initialized
INFO - 2016-02-10 21:39:51 --> Model Class Initialized
INFO - 2016-02-10 21:39:51 --> Model Class Initialized
INFO - 2016-02-10 21:39:51 --> Form Validation Class Initialized
INFO - 2016-02-10 21:39:51 --> Helper loaded: text_helper
INFO - 2016-02-10 21:39:51 --> Config Class Initialized
INFO - 2016-02-10 21:39:51 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:39:51 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:39:51 --> Utf8 Class Initialized
INFO - 2016-02-10 21:39:51 --> URI Class Initialized
INFO - 2016-02-10 21:39:51 --> Router Class Initialized
INFO - 2016-02-10 21:39:51 --> Output Class Initialized
INFO - 2016-02-10 21:39:51 --> Security Class Initialized
DEBUG - 2016-02-10 21:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:39:51 --> Input Class Initialized
INFO - 2016-02-10 21:39:51 --> Language Class Initialized
INFO - 2016-02-10 21:39:51 --> Loader Class Initialized
INFO - 2016-02-10 21:39:51 --> Helper loaded: url_helper
INFO - 2016-02-10 21:39:51 --> Helper loaded: file_helper
INFO - 2016-02-10 21:39:51 --> Helper loaded: date_helper
INFO - 2016-02-10 21:39:51 --> Helper loaded: form_helper
INFO - 2016-02-10 21:39:51 --> Database Driver Class Initialized
INFO - 2016-02-10 21:39:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:39:52 --> Controller Class Initialized
INFO - 2016-02-10 21:39:52 --> Model Class Initialized
INFO - 2016-02-10 21:39:52 --> Model Class Initialized
INFO - 2016-02-10 21:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:39:52 --> Pagination Class Initialized
INFO - 2016-02-10 21:39:54 --> Config Class Initialized
INFO - 2016-02-10 21:39:54 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:39:54 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:39:54 --> Utf8 Class Initialized
INFO - 2016-02-10 21:39:54 --> URI Class Initialized
INFO - 2016-02-10 21:39:54 --> Router Class Initialized
INFO - 2016-02-10 21:39:55 --> Output Class Initialized
INFO - 2016-02-10 21:39:55 --> Security Class Initialized
DEBUG - 2016-02-10 21:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:39:55 --> Input Class Initialized
INFO - 2016-02-10 21:39:55 --> Language Class Initialized
INFO - 2016-02-10 21:39:55 --> Loader Class Initialized
INFO - 2016-02-10 21:39:55 --> Helper loaded: url_helper
INFO - 2016-02-10 21:39:55 --> Helper loaded: file_helper
INFO - 2016-02-10 21:39:55 --> Helper loaded: date_helper
INFO - 2016-02-10 21:39:55 --> Helper loaded: form_helper
INFO - 2016-02-10 21:39:55 --> Database Driver Class Initialized
INFO - 2016-02-10 21:39:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:39:56 --> Controller Class Initialized
INFO - 2016-02-10 21:39:56 --> Model Class Initialized
INFO - 2016-02-10 21:39:56 --> Model Class Initialized
INFO - 2016-02-10 21:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:39:56 --> Pagination Class Initialized
INFO - 2016-02-10 21:39:58 --> Config Class Initialized
INFO - 2016-02-10 21:39:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:39:58 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:39:58 --> Utf8 Class Initialized
INFO - 2016-02-10 21:39:58 --> URI Class Initialized
INFO - 2016-02-10 21:39:58 --> Router Class Initialized
INFO - 2016-02-10 21:39:58 --> Output Class Initialized
INFO - 2016-02-10 21:39:58 --> Security Class Initialized
DEBUG - 2016-02-10 21:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:39:58 --> Input Class Initialized
INFO - 2016-02-10 21:39:58 --> Language Class Initialized
INFO - 2016-02-10 21:39:58 --> Loader Class Initialized
INFO - 2016-02-10 21:39:58 --> Helper loaded: url_helper
INFO - 2016-02-10 21:39:58 --> Helper loaded: file_helper
INFO - 2016-02-10 21:39:58 --> Helper loaded: date_helper
INFO - 2016-02-10 21:39:58 --> Helper loaded: form_helper
INFO - 2016-02-10 21:39:58 --> Database Driver Class Initialized
INFO - 2016-02-10 21:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:39:59 --> Controller Class Initialized
INFO - 2016-02-10 21:39:59 --> Model Class Initialized
INFO - 2016-02-10 21:39:59 --> Model Class Initialized
INFO - 2016-02-10 21:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:39:59 --> Pagination Class Initialized
INFO - 2016-02-10 21:40:48 --> Config Class Initialized
INFO - 2016-02-10 21:40:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:40:48 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:40:48 --> Utf8 Class Initialized
INFO - 2016-02-10 21:40:48 --> URI Class Initialized
DEBUG - 2016-02-10 21:40:48 --> No URI present. Default controller set.
INFO - 2016-02-10 21:40:48 --> Router Class Initialized
INFO - 2016-02-10 21:40:48 --> Output Class Initialized
INFO - 2016-02-10 21:40:48 --> Security Class Initialized
DEBUG - 2016-02-10 21:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:40:48 --> Input Class Initialized
INFO - 2016-02-10 21:40:48 --> Language Class Initialized
INFO - 2016-02-10 21:40:48 --> Loader Class Initialized
INFO - 2016-02-10 21:40:48 --> Helper loaded: url_helper
INFO - 2016-02-10 21:40:48 --> Helper loaded: file_helper
INFO - 2016-02-10 21:40:48 --> Helper loaded: date_helper
INFO - 2016-02-10 21:40:48 --> Helper loaded: form_helper
INFO - 2016-02-10 21:40:48 --> Database Driver Class Initialized
INFO - 2016-02-10 21:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:40:49 --> Controller Class Initialized
INFO - 2016-02-10 21:40:49 --> Model Class Initialized
INFO - 2016-02-10 21:40:49 --> Model Class Initialized
INFO - 2016-02-10 21:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:40:49 --> Pagination Class Initialized
INFO - 2016-02-10 21:45:58 --> Config Class Initialized
INFO - 2016-02-10 21:45:58 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:45:58 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:45:58 --> Utf8 Class Initialized
INFO - 2016-02-10 21:45:58 --> URI Class Initialized
DEBUG - 2016-02-10 21:45:58 --> No URI present. Default controller set.
INFO - 2016-02-10 21:45:58 --> Router Class Initialized
INFO - 2016-02-10 21:45:58 --> Output Class Initialized
INFO - 2016-02-10 21:45:58 --> Security Class Initialized
DEBUG - 2016-02-10 21:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:45:58 --> Input Class Initialized
INFO - 2016-02-10 21:45:58 --> Language Class Initialized
INFO - 2016-02-10 21:45:58 --> Loader Class Initialized
INFO - 2016-02-10 21:45:58 --> Helper loaded: url_helper
INFO - 2016-02-10 21:45:58 --> Helper loaded: file_helper
INFO - 2016-02-10 21:45:58 --> Helper loaded: date_helper
INFO - 2016-02-10 21:45:58 --> Helper loaded: form_helper
INFO - 2016-02-10 21:45:58 --> Database Driver Class Initialized
INFO - 2016-02-10 21:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:45:59 --> Controller Class Initialized
INFO - 2016-02-10 21:45:59 --> Model Class Initialized
INFO - 2016-02-10 21:45:59 --> Model Class Initialized
INFO - 2016-02-10 21:45:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:45:59 --> Pagination Class Initialized
INFO - 2016-02-10 21:46:25 --> Config Class Initialized
INFO - 2016-02-10 21:46:25 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:46:25 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:46:25 --> Utf8 Class Initialized
INFO - 2016-02-10 21:46:25 --> URI Class Initialized
DEBUG - 2016-02-10 21:46:25 --> No URI present. Default controller set.
INFO - 2016-02-10 21:46:25 --> Router Class Initialized
INFO - 2016-02-10 21:46:25 --> Output Class Initialized
INFO - 2016-02-10 21:46:25 --> Security Class Initialized
DEBUG - 2016-02-10 21:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:46:25 --> Input Class Initialized
INFO - 2016-02-10 21:46:25 --> Language Class Initialized
INFO - 2016-02-10 21:46:25 --> Loader Class Initialized
INFO - 2016-02-10 21:46:25 --> Helper loaded: url_helper
INFO - 2016-02-10 21:46:25 --> Helper loaded: file_helper
INFO - 2016-02-10 21:46:25 --> Helper loaded: date_helper
INFO - 2016-02-10 21:46:25 --> Helper loaded: form_helper
INFO - 2016-02-10 21:46:25 --> Database Driver Class Initialized
INFO - 2016-02-10 21:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:46:26 --> Controller Class Initialized
INFO - 2016-02-10 21:46:26 --> Model Class Initialized
INFO - 2016-02-10 21:46:26 --> Model Class Initialized
INFO - 2016-02-10 21:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:46:26 --> Pagination Class Initialized
INFO - 2016-02-10 21:47:24 --> Config Class Initialized
INFO - 2016-02-10 21:47:24 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:24 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:47:24 --> Utf8 Class Initialized
INFO - 2016-02-10 21:47:24 --> URI Class Initialized
INFO - 2016-02-10 21:47:24 --> Router Class Initialized
INFO - 2016-02-10 21:47:24 --> Output Class Initialized
INFO - 2016-02-10 21:47:24 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:47:24 --> Input Class Initialized
INFO - 2016-02-10 21:47:24 --> Language Class Initialized
INFO - 2016-02-10 21:47:24 --> Loader Class Initialized
INFO - 2016-02-10 21:47:24 --> Helper loaded: url_helper
INFO - 2016-02-10 21:47:24 --> Helper loaded: file_helper
INFO - 2016-02-10 21:47:24 --> Helper loaded: date_helper
INFO - 2016-02-10 21:47:24 --> Helper loaded: form_helper
INFO - 2016-02-10 21:47:24 --> Database Driver Class Initialized
INFO - 2016-02-10 21:47:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:47:25 --> Controller Class Initialized
INFO - 2016-02-10 21:47:25 --> Model Class Initialized
INFO - 2016-02-10 21:47:25 --> Model Class Initialized
INFO - 2016-02-10 21:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:47:25 --> Pagination Class Initialized
INFO - 2016-02-10 21:47:33 --> Config Class Initialized
INFO - 2016-02-10 21:47:33 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:33 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:47:33 --> Utf8 Class Initialized
INFO - 2016-02-10 21:47:33 --> URI Class Initialized
INFO - 2016-02-10 21:47:33 --> Router Class Initialized
INFO - 2016-02-10 21:47:33 --> Output Class Initialized
INFO - 2016-02-10 21:47:33 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:47:33 --> Input Class Initialized
INFO - 2016-02-10 21:47:33 --> Language Class Initialized
INFO - 2016-02-10 21:47:33 --> Loader Class Initialized
INFO - 2016-02-10 21:47:33 --> Helper loaded: url_helper
INFO - 2016-02-10 21:47:33 --> Helper loaded: file_helper
INFO - 2016-02-10 21:47:33 --> Helper loaded: date_helper
INFO - 2016-02-10 21:47:33 --> Helper loaded: form_helper
INFO - 2016-02-10 21:47:33 --> Database Driver Class Initialized
INFO - 2016-02-10 21:47:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:47:34 --> Controller Class Initialized
INFO - 2016-02-10 21:47:34 --> Model Class Initialized
INFO - 2016-02-10 21:47:34 --> Model Class Initialized
INFO - 2016-02-10 21:47:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:47:34 --> Pagination Class Initialized
INFO - 2016-02-10 21:47:38 --> Config Class Initialized
INFO - 2016-02-10 21:47:38 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:38 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:47:38 --> Utf8 Class Initialized
INFO - 2016-02-10 21:47:38 --> URI Class Initialized
INFO - 2016-02-10 21:47:38 --> Router Class Initialized
INFO - 2016-02-10 21:47:38 --> Output Class Initialized
INFO - 2016-02-10 21:47:38 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:47:38 --> Input Class Initialized
INFO - 2016-02-10 21:47:38 --> Language Class Initialized
INFO - 2016-02-10 21:47:38 --> Loader Class Initialized
INFO - 2016-02-10 21:47:38 --> Helper loaded: url_helper
INFO - 2016-02-10 21:47:38 --> Helper loaded: file_helper
INFO - 2016-02-10 21:47:38 --> Helper loaded: date_helper
INFO - 2016-02-10 21:47:38 --> Helper loaded: form_helper
INFO - 2016-02-10 21:47:38 --> Database Driver Class Initialized
INFO - 2016-02-10 21:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:47:39 --> Controller Class Initialized
INFO - 2016-02-10 21:47:39 --> Model Class Initialized
INFO - 2016-02-10 21:47:39 --> Model Class Initialized
INFO - 2016-02-10 21:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:47:39 --> Pagination Class Initialized
INFO - 2016-02-10 21:47:43 --> Config Class Initialized
INFO - 2016-02-10 21:47:43 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:47:43 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:47:43 --> Utf8 Class Initialized
INFO - 2016-02-10 21:47:43 --> URI Class Initialized
INFO - 2016-02-10 21:47:43 --> Router Class Initialized
INFO - 2016-02-10 21:47:43 --> Output Class Initialized
INFO - 2016-02-10 21:47:43 --> Security Class Initialized
DEBUG - 2016-02-10 21:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:47:43 --> Input Class Initialized
INFO - 2016-02-10 21:47:43 --> Language Class Initialized
INFO - 2016-02-10 21:47:43 --> Loader Class Initialized
INFO - 2016-02-10 21:47:43 --> Helper loaded: url_helper
INFO - 2016-02-10 21:47:43 --> Helper loaded: file_helper
INFO - 2016-02-10 21:47:43 --> Helper loaded: date_helper
INFO - 2016-02-10 21:47:43 --> Helper loaded: form_helper
INFO - 2016-02-10 21:47:43 --> Database Driver Class Initialized
INFO - 2016-02-10 21:47:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:47:44 --> Controller Class Initialized
INFO - 2016-02-10 21:47:44 --> Model Class Initialized
INFO - 2016-02-10 21:47:44 --> Model Class Initialized
INFO - 2016-02-10 21:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:47:44 --> Pagination Class Initialized
INFO - 2016-02-10 21:49:00 --> Config Class Initialized
INFO - 2016-02-10 21:49:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:49:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:49:00 --> Utf8 Class Initialized
INFO - 2016-02-10 21:49:00 --> URI Class Initialized
INFO - 2016-02-10 21:49:00 --> Router Class Initialized
INFO - 2016-02-10 21:49:00 --> Output Class Initialized
INFO - 2016-02-10 21:49:00 --> Security Class Initialized
DEBUG - 2016-02-10 21:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:49:00 --> Input Class Initialized
INFO - 2016-02-10 21:49:00 --> Language Class Initialized
INFO - 2016-02-10 21:49:00 --> Loader Class Initialized
INFO - 2016-02-10 21:49:00 --> Helper loaded: url_helper
INFO - 2016-02-10 21:49:00 --> Helper loaded: file_helper
INFO - 2016-02-10 21:49:00 --> Helper loaded: date_helper
INFO - 2016-02-10 21:49:00 --> Helper loaded: form_helper
INFO - 2016-02-10 21:49:00 --> Database Driver Class Initialized
INFO - 2016-02-10 21:49:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:49:01 --> Controller Class Initialized
INFO - 2016-02-10 21:49:01 --> Model Class Initialized
INFO - 2016-02-10 21:49:01 --> Model Class Initialized
INFO - 2016-02-10 21:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:49:01 --> Pagination Class Initialized
INFO - 2016-02-10 21:49:52 --> Config Class Initialized
INFO - 2016-02-10 21:49:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:49:52 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:49:52 --> Utf8 Class Initialized
INFO - 2016-02-10 21:49:52 --> URI Class Initialized
INFO - 2016-02-10 21:49:52 --> Router Class Initialized
INFO - 2016-02-10 21:49:52 --> Output Class Initialized
INFO - 2016-02-10 21:49:52 --> Security Class Initialized
DEBUG - 2016-02-10 21:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:49:52 --> Input Class Initialized
INFO - 2016-02-10 21:49:52 --> Language Class Initialized
INFO - 2016-02-10 21:49:52 --> Loader Class Initialized
INFO - 2016-02-10 21:49:52 --> Helper loaded: url_helper
INFO - 2016-02-10 21:49:52 --> Helper loaded: file_helper
INFO - 2016-02-10 21:49:52 --> Helper loaded: date_helper
INFO - 2016-02-10 21:49:52 --> Helper loaded: form_helper
INFO - 2016-02-10 21:49:52 --> Database Driver Class Initialized
INFO - 2016-02-10 21:49:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:49:53 --> Controller Class Initialized
INFO - 2016-02-10 21:49:53 --> Model Class Initialized
INFO - 2016-02-10 21:49:53 --> Model Class Initialized
INFO - 2016-02-10 21:49:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:49:53 --> Pagination Class Initialized
INFO - 2016-02-10 21:50:00 --> Config Class Initialized
INFO - 2016-02-10 21:50:00 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:50:00 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:50:00 --> Utf8 Class Initialized
INFO - 2016-02-10 21:50:00 --> URI Class Initialized
INFO - 2016-02-10 21:50:00 --> Router Class Initialized
INFO - 2016-02-10 21:50:00 --> Output Class Initialized
INFO - 2016-02-10 21:50:00 --> Security Class Initialized
DEBUG - 2016-02-10 21:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:50:00 --> Input Class Initialized
INFO - 2016-02-10 21:50:00 --> Language Class Initialized
INFO - 2016-02-10 21:50:00 --> Loader Class Initialized
INFO - 2016-02-10 21:50:00 --> Helper loaded: url_helper
INFO - 2016-02-10 21:50:00 --> Helper loaded: file_helper
INFO - 2016-02-10 21:50:00 --> Helper loaded: date_helper
INFO - 2016-02-10 21:50:00 --> Helper loaded: form_helper
INFO - 2016-02-10 21:50:00 --> Database Driver Class Initialized
INFO - 2016-02-10 21:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:50:01 --> Controller Class Initialized
INFO - 2016-02-10 21:50:01 --> Model Class Initialized
INFO - 2016-02-10 21:50:01 --> Model Class Initialized
INFO - 2016-02-10 21:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:50:01 --> Pagination Class Initialized
INFO - 2016-02-10 21:50:50 --> Config Class Initialized
INFO - 2016-02-10 21:50:50 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:50:50 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:50:50 --> Utf8 Class Initialized
INFO - 2016-02-10 21:50:50 --> URI Class Initialized
INFO - 2016-02-10 21:50:50 --> Router Class Initialized
INFO - 2016-02-10 21:50:50 --> Output Class Initialized
INFO - 2016-02-10 21:50:50 --> Security Class Initialized
DEBUG - 2016-02-10 21:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:50:51 --> Input Class Initialized
INFO - 2016-02-10 21:50:51 --> Language Class Initialized
INFO - 2016-02-10 21:50:51 --> Loader Class Initialized
INFO - 2016-02-10 21:50:51 --> Helper loaded: url_helper
INFO - 2016-02-10 21:50:51 --> Helper loaded: file_helper
INFO - 2016-02-10 21:50:51 --> Helper loaded: date_helper
INFO - 2016-02-10 21:50:51 --> Helper loaded: form_helper
INFO - 2016-02-10 21:50:51 --> Database Driver Class Initialized
INFO - 2016-02-10 21:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:50:52 --> Controller Class Initialized
INFO - 2016-02-10 21:50:52 --> Model Class Initialized
INFO - 2016-02-10 21:50:52 --> Model Class Initialized
INFO - 2016-02-10 21:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:50:52 --> Pagination Class Initialized
INFO - 2016-02-10 21:51:16 --> Config Class Initialized
INFO - 2016-02-10 21:51:16 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:51:16 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:51:16 --> Utf8 Class Initialized
INFO - 2016-02-10 21:51:16 --> URI Class Initialized
INFO - 2016-02-10 21:51:16 --> Router Class Initialized
INFO - 2016-02-10 21:51:16 --> Output Class Initialized
INFO - 2016-02-10 21:51:16 --> Security Class Initialized
DEBUG - 2016-02-10 21:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:51:16 --> Input Class Initialized
INFO - 2016-02-10 21:51:16 --> Language Class Initialized
INFO - 2016-02-10 21:51:16 --> Loader Class Initialized
INFO - 2016-02-10 21:51:16 --> Helper loaded: url_helper
INFO - 2016-02-10 21:51:16 --> Helper loaded: file_helper
INFO - 2016-02-10 21:51:16 --> Helper loaded: date_helper
INFO - 2016-02-10 21:51:16 --> Helper loaded: form_helper
INFO - 2016-02-10 21:51:16 --> Database Driver Class Initialized
INFO - 2016-02-10 21:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:51:17 --> Controller Class Initialized
INFO - 2016-02-10 21:51:17 --> Model Class Initialized
INFO - 2016-02-10 21:51:17 --> Model Class Initialized
INFO - 2016-02-10 21:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:51:17 --> Pagination Class Initialized
INFO - 2016-02-10 21:51:48 --> Config Class Initialized
INFO - 2016-02-10 21:51:48 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:51:48 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:51:48 --> Utf8 Class Initialized
INFO - 2016-02-10 21:51:48 --> URI Class Initialized
INFO - 2016-02-10 21:51:48 --> Router Class Initialized
INFO - 2016-02-10 21:51:48 --> Output Class Initialized
INFO - 2016-02-10 21:51:48 --> Security Class Initialized
DEBUG - 2016-02-10 21:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:51:48 --> Input Class Initialized
INFO - 2016-02-10 21:51:48 --> Language Class Initialized
INFO - 2016-02-10 21:51:48 --> Loader Class Initialized
INFO - 2016-02-10 21:51:48 --> Helper loaded: url_helper
INFO - 2016-02-10 21:51:48 --> Helper loaded: file_helper
INFO - 2016-02-10 21:51:48 --> Helper loaded: date_helper
INFO - 2016-02-10 21:51:48 --> Helper loaded: form_helper
INFO - 2016-02-10 21:51:48 --> Database Driver Class Initialized
INFO - 2016-02-10 21:51:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:51:49 --> Controller Class Initialized
INFO - 2016-02-10 21:51:49 --> Model Class Initialized
INFO - 2016-02-10 21:51:49 --> Model Class Initialized
INFO - 2016-02-10 21:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:51:49 --> Pagination Class Initialized
INFO - 2016-02-10 21:52:09 --> Config Class Initialized
INFO - 2016-02-10 21:52:09 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:52:09 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:52:09 --> Utf8 Class Initialized
INFO - 2016-02-10 21:52:09 --> URI Class Initialized
INFO - 2016-02-10 21:52:09 --> Router Class Initialized
INFO - 2016-02-10 21:52:09 --> Output Class Initialized
INFO - 2016-02-10 21:52:09 --> Security Class Initialized
DEBUG - 2016-02-10 21:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:52:09 --> Input Class Initialized
INFO - 2016-02-10 21:52:09 --> Language Class Initialized
INFO - 2016-02-10 21:52:09 --> Loader Class Initialized
INFO - 2016-02-10 21:52:09 --> Helper loaded: url_helper
INFO - 2016-02-10 21:52:09 --> Helper loaded: file_helper
INFO - 2016-02-10 21:52:09 --> Helper loaded: date_helper
INFO - 2016-02-10 21:52:09 --> Helper loaded: form_helper
INFO - 2016-02-10 21:52:09 --> Database Driver Class Initialized
INFO - 2016-02-10 21:52:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:52:10 --> Controller Class Initialized
INFO - 2016-02-10 21:52:10 --> Model Class Initialized
INFO - 2016-02-10 21:52:10 --> Model Class Initialized
INFO - 2016-02-10 21:52:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:52:10 --> Pagination Class Initialized
INFO - 2016-02-10 21:52:56 --> Config Class Initialized
INFO - 2016-02-10 21:52:56 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:52:56 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:52:56 --> Utf8 Class Initialized
INFO - 2016-02-10 21:52:56 --> URI Class Initialized
INFO - 2016-02-10 21:52:56 --> Router Class Initialized
INFO - 2016-02-10 21:52:56 --> Output Class Initialized
INFO - 2016-02-10 21:52:56 --> Security Class Initialized
DEBUG - 2016-02-10 21:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:52:56 --> Input Class Initialized
INFO - 2016-02-10 21:52:56 --> Language Class Initialized
INFO - 2016-02-10 21:52:56 --> Loader Class Initialized
INFO - 2016-02-10 21:52:56 --> Helper loaded: url_helper
INFO - 2016-02-10 21:52:56 --> Helper loaded: file_helper
INFO - 2016-02-10 21:52:56 --> Helper loaded: date_helper
INFO - 2016-02-10 21:52:56 --> Helper loaded: form_helper
INFO - 2016-02-10 21:52:56 --> Database Driver Class Initialized
INFO - 2016-02-10 21:52:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:52:57 --> Controller Class Initialized
INFO - 2016-02-10 21:52:57 --> Model Class Initialized
INFO - 2016-02-10 21:52:57 --> Model Class Initialized
INFO - 2016-02-10 21:52:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:52:57 --> Pagination Class Initialized
INFO - 2016-02-10 21:53:52 --> Config Class Initialized
INFO - 2016-02-10 21:53:52 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:53:52 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:53:52 --> Utf8 Class Initialized
INFO - 2016-02-10 21:53:52 --> URI Class Initialized
INFO - 2016-02-10 21:53:52 --> Router Class Initialized
INFO - 2016-02-10 21:53:52 --> Output Class Initialized
INFO - 2016-02-10 21:53:52 --> Security Class Initialized
DEBUG - 2016-02-10 21:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:53:52 --> Input Class Initialized
INFO - 2016-02-10 21:53:52 --> Language Class Initialized
INFO - 2016-02-10 21:53:52 --> Loader Class Initialized
INFO - 2016-02-10 21:53:52 --> Helper loaded: url_helper
INFO - 2016-02-10 21:53:52 --> Helper loaded: file_helper
INFO - 2016-02-10 21:53:52 --> Helper loaded: date_helper
INFO - 2016-02-10 21:53:52 --> Helper loaded: form_helper
INFO - 2016-02-10 21:53:52 --> Database Driver Class Initialized
INFO - 2016-02-10 21:53:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:53:53 --> Controller Class Initialized
INFO - 2016-02-10 21:53:53 --> Model Class Initialized
INFO - 2016-02-10 21:53:53 --> Model Class Initialized
INFO - 2016-02-10 21:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:53:53 --> Pagination Class Initialized
INFO - 2016-02-10 21:54:39 --> Config Class Initialized
INFO - 2016-02-10 21:54:39 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:54:39 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:54:39 --> Utf8 Class Initialized
INFO - 2016-02-10 21:54:39 --> URI Class Initialized
DEBUG - 2016-02-10 21:54:39 --> No URI present. Default controller set.
INFO - 2016-02-10 21:54:39 --> Router Class Initialized
INFO - 2016-02-10 21:54:39 --> Output Class Initialized
INFO - 2016-02-10 21:54:39 --> Security Class Initialized
DEBUG - 2016-02-10 21:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:54:39 --> Input Class Initialized
INFO - 2016-02-10 21:54:39 --> Language Class Initialized
INFO - 2016-02-10 21:54:39 --> Loader Class Initialized
INFO - 2016-02-10 21:54:39 --> Helper loaded: url_helper
INFO - 2016-02-10 21:54:39 --> Helper loaded: file_helper
INFO - 2016-02-10 21:54:39 --> Helper loaded: date_helper
INFO - 2016-02-10 21:54:39 --> Helper loaded: form_helper
INFO - 2016-02-10 21:54:39 --> Database Driver Class Initialized
INFO - 2016-02-10 21:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:54:40 --> Controller Class Initialized
INFO - 2016-02-10 21:54:40 --> Model Class Initialized
INFO - 2016-02-10 21:54:40 --> Model Class Initialized
INFO - 2016-02-10 21:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:54:40 --> Pagination Class Initialized
INFO - 2016-02-10 21:55:03 --> Config Class Initialized
INFO - 2016-02-10 21:55:03 --> Hooks Class Initialized
DEBUG - 2016-02-10 21:55:03 --> UTF-8 Support Enabled
INFO - 2016-02-10 21:55:03 --> Utf8 Class Initialized
INFO - 2016-02-10 21:55:03 --> URI Class Initialized
INFO - 2016-02-10 21:55:03 --> Router Class Initialized
INFO - 2016-02-10 21:55:03 --> Output Class Initialized
INFO - 2016-02-10 21:55:03 --> Security Class Initialized
DEBUG - 2016-02-10 21:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-10 21:55:03 --> Input Class Initialized
INFO - 2016-02-10 21:55:03 --> Language Class Initialized
INFO - 2016-02-10 21:55:03 --> Loader Class Initialized
INFO - 2016-02-10 21:55:03 --> Helper loaded: url_helper
INFO - 2016-02-10 21:55:03 --> Helper loaded: file_helper
INFO - 2016-02-10 21:55:03 --> Helper loaded: date_helper
INFO - 2016-02-10 21:55:03 --> Helper loaded: form_helper
INFO - 2016-02-10 21:55:03 --> Database Driver Class Initialized
INFO - 2016-02-10 21:55:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-10 21:55:04 --> Controller Class Initialized
INFO - 2016-02-10 21:55:04 --> Model Class Initialized
INFO - 2016-02-10 21:55:04 --> Model Class Initialized
INFO - 2016-02-10 21:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-10 21:55:04 --> Pagination Class Initialized
