<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-17 06:26:37 --> Config Class Initialized
INFO - 2016-02-17 06:26:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:26:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:26:37 --> Utf8 Class Initialized
INFO - 2016-02-17 06:26:37 --> URI Class Initialized
DEBUG - 2016-02-17 06:26:37 --> No URI present. Default controller set.
INFO - 2016-02-17 06:26:37 --> Router Class Initialized
INFO - 2016-02-17 06:26:37 --> Output Class Initialized
INFO - 2016-02-17 06:26:37 --> Security Class Initialized
DEBUG - 2016-02-17 06:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:26:37 --> Input Class Initialized
INFO - 2016-02-17 06:26:37 --> Language Class Initialized
INFO - 2016-02-17 06:26:37 --> Loader Class Initialized
INFO - 2016-02-17 06:26:37 --> Helper loaded: url_helper
INFO - 2016-02-17 06:26:37 --> Helper loaded: file_helper
INFO - 2016-02-17 06:26:37 --> Helper loaded: date_helper
INFO - 2016-02-17 06:26:37 --> Helper loaded: form_helper
INFO - 2016-02-17 06:26:37 --> Database Driver Class Initialized
INFO - 2016-02-17 06:26:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:26:38 --> Controller Class Initialized
INFO - 2016-02-17 06:26:38 --> Model Class Initialized
INFO - 2016-02-17 06:26:38 --> Model Class Initialized
INFO - 2016-02-17 06:26:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:26:38 --> Pagination Class Initialized
INFO - 2016-02-17 06:26:38 --> Helper loaded: text_helper
INFO - 2016-02-17 06:26:38 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 09:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:26:38 --> Final output sent to browser
DEBUG - 2016-02-17 09:26:38 --> Total execution time: 1.1265
INFO - 2016-02-17 06:55:13 --> Config Class Initialized
INFO - 2016-02-17 06:55:13 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:13 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:13 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:13 --> URI Class Initialized
DEBUG - 2016-02-17 06:55:13 --> No URI present. Default controller set.
INFO - 2016-02-17 06:55:13 --> Router Class Initialized
INFO - 2016-02-17 06:55:13 --> Output Class Initialized
INFO - 2016-02-17 06:55:13 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:13 --> Input Class Initialized
INFO - 2016-02-17 06:55:13 --> Language Class Initialized
INFO - 2016-02-17 06:55:13 --> Loader Class Initialized
INFO - 2016-02-17 06:55:13 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:13 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:13 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:13 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:13 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:14 --> Controller Class Initialized
INFO - 2016-02-17 06:55:14 --> Model Class Initialized
INFO - 2016-02-17 06:55:14 --> Model Class Initialized
INFO - 2016-02-17 06:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:55:14 --> Pagination Class Initialized
INFO - 2016-02-17 06:55:14 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:14 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 09:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:55:14 --> Final output sent to browser
DEBUG - 2016-02-17 09:55:14 --> Total execution time: 1.1741
INFO - 2016-02-17 06:55:18 --> Config Class Initialized
INFO - 2016-02-17 06:55:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:18 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:18 --> URI Class Initialized
INFO - 2016-02-17 06:55:18 --> Router Class Initialized
INFO - 2016-02-17 06:55:18 --> Output Class Initialized
INFO - 2016-02-17 06:55:18 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:18 --> Input Class Initialized
INFO - 2016-02-17 06:55:18 --> Language Class Initialized
INFO - 2016-02-17 06:55:18 --> Loader Class Initialized
INFO - 2016-02-17 06:55:18 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:18 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:18 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:18 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:18 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:19 --> Controller Class Initialized
INFO - 2016-02-17 06:55:19 --> Model Class Initialized
INFO - 2016-02-17 06:55:19 --> Model Class Initialized
INFO - 2016-02-17 06:55:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:55:19 --> Pagination Class Initialized
INFO - 2016-02-17 06:55:19 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:19 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:55:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:55:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:55:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:55:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:55:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:55:19 --> Final output sent to browser
DEBUG - 2016-02-17 09:55:19 --> Total execution time: 1.3053
INFO - 2016-02-17 06:55:21 --> Config Class Initialized
INFO - 2016-02-17 06:55:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:21 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:21 --> URI Class Initialized
INFO - 2016-02-17 06:55:21 --> Router Class Initialized
INFO - 2016-02-17 06:55:21 --> Output Class Initialized
INFO - 2016-02-17 06:55:21 --> Security Class Initialized
INFO - 2016-02-17 06:55:21 --> Config Class Initialized
DEBUG - 2016-02-17 06:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:21 --> Hooks Class Initialized
INFO - 2016-02-17 06:55:21 --> Input Class Initialized
INFO - 2016-02-17 06:55:21 --> Language Class Initialized
DEBUG - 2016-02-17 06:55:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:21 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:21 --> URI Class Initialized
INFO - 2016-02-17 06:55:21 --> Router Class Initialized
ERROR - 2016-02-17 06:55:21 --> 404 Page Not Found: Jboard/img
INFO - 2016-02-17 06:55:21 --> Output Class Initialized
INFO - 2016-02-17 06:55:21 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:21 --> Input Class Initialized
INFO - 2016-02-17 06:55:21 --> Language Class Initialized
INFO - 2016-02-17 06:55:21 --> Loader Class Initialized
INFO - 2016-02-17 06:55:21 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:21 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:21 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:21 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:21 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:22 --> Controller Class Initialized
INFO - 2016-02-17 06:55:22 --> Model Class Initialized
INFO - 2016-02-17 06:55:22 --> Model Class Initialized
INFO - 2016-02-17 06:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:55:22 --> Pagination Class Initialized
INFO - 2016-02-17 06:55:22 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:22 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:55:22 --> Final output sent to browser
DEBUG - 2016-02-17 09:55:22 --> Total execution time: 1.1238
INFO - 2016-02-17 06:55:39 --> Config Class Initialized
INFO - 2016-02-17 06:55:39 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:39 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:39 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:39 --> URI Class Initialized
INFO - 2016-02-17 06:55:39 --> Router Class Initialized
INFO - 2016-02-17 06:55:39 --> Output Class Initialized
INFO - 2016-02-17 06:55:39 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:39 --> Input Class Initialized
INFO - 2016-02-17 06:55:39 --> Language Class Initialized
INFO - 2016-02-17 06:55:39 --> Loader Class Initialized
INFO - 2016-02-17 06:55:39 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:39 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:39 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:39 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:39 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:40 --> Controller Class Initialized
INFO - 2016-02-17 06:55:40 --> Model Class Initialized
INFO - 2016-02-17 06:55:40 --> Model Class Initialized
INFO - 2016-02-17 06:55:40 --> Form Validation Class Initialized
INFO - 2016-02-17 06:55:40 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:40 --> Config Class Initialized
INFO - 2016-02-17 06:55:40 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:40 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:40 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:40 --> URI Class Initialized
INFO - 2016-02-17 06:55:40 --> Router Class Initialized
INFO - 2016-02-17 06:55:40 --> Output Class Initialized
INFO - 2016-02-17 06:55:40 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:40 --> Input Class Initialized
INFO - 2016-02-17 06:55:40 --> Language Class Initialized
INFO - 2016-02-17 06:55:40 --> Loader Class Initialized
INFO - 2016-02-17 06:55:40 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:40 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:40 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:40 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:40 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:41 --> Controller Class Initialized
INFO - 2016-02-17 06:55:41 --> Model Class Initialized
INFO - 2016-02-17 06:55:41 --> Model Class Initialized
INFO - 2016-02-17 06:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:55:41 --> Pagination Class Initialized
INFO - 2016-02-17 06:55:41 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:41 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:55:41 --> Final output sent to browser
DEBUG - 2016-02-17 09:55:41 --> Total execution time: 1.1674
INFO - 2016-02-17 06:55:44 --> Config Class Initialized
INFO - 2016-02-17 06:55:44 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:44 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:44 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:44 --> URI Class Initialized
INFO - 2016-02-17 06:55:44 --> Router Class Initialized
INFO - 2016-02-17 06:55:44 --> Config Class Initialized
INFO - 2016-02-17 06:55:44 --> Hooks Class Initialized
INFO - 2016-02-17 06:55:44 --> Output Class Initialized
INFO - 2016-02-17 06:55:44 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:44 --> Input Class Initialized
INFO - 2016-02-17 06:55:44 --> Language Class Initialized
ERROR - 2016-02-17 06:55:44 --> 404 Page Not Found: Jboard/img
DEBUG - 2016-02-17 06:55:44 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:44 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:44 --> URI Class Initialized
INFO - 2016-02-17 06:55:44 --> Router Class Initialized
INFO - 2016-02-17 06:55:44 --> Output Class Initialized
INFO - 2016-02-17 06:55:44 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:44 --> Input Class Initialized
INFO - 2016-02-17 06:55:44 --> Language Class Initialized
INFO - 2016-02-17 06:55:44 --> Loader Class Initialized
INFO - 2016-02-17 06:55:44 --> Helper loaded: url_helper
INFO - 2016-02-17 06:55:44 --> Helper loaded: file_helper
INFO - 2016-02-17 06:55:44 --> Helper loaded: date_helper
INFO - 2016-02-17 06:55:44 --> Helper loaded: form_helper
INFO - 2016-02-17 06:55:44 --> Database Driver Class Initialized
INFO - 2016-02-17 06:55:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:55:45 --> Controller Class Initialized
INFO - 2016-02-17 06:55:45 --> Model Class Initialized
INFO - 2016-02-17 06:55:45 --> Model Class Initialized
INFO - 2016-02-17 06:55:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:55:45 --> Pagination Class Initialized
INFO - 2016-02-17 06:55:45 --> Helper loaded: text_helper
INFO - 2016-02-17 06:55:45 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:55:45 --> Final output sent to browser
DEBUG - 2016-02-17 09:55:45 --> Total execution time: 1.1986
INFO - 2016-02-17 06:55:49 --> Config Class Initialized
INFO - 2016-02-17 06:55:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:55:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:55:49 --> Utf8 Class Initialized
INFO - 2016-02-17 06:55:49 --> URI Class Initialized
INFO - 2016-02-17 06:55:49 --> Router Class Initialized
INFO - 2016-02-17 06:55:49 --> Output Class Initialized
INFO - 2016-02-17 06:55:49 --> Security Class Initialized
DEBUG - 2016-02-17 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:55:49 --> Input Class Initialized
INFO - 2016-02-17 06:55:49 --> Language Class Initialized
ERROR - 2016-02-17 06:55:49 --> 404 Page Not Found: Jboard/img
INFO - 2016-02-17 06:56:01 --> Config Class Initialized
INFO - 2016-02-17 06:56:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:56:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:56:01 --> Utf8 Class Initialized
INFO - 2016-02-17 06:56:01 --> URI Class Initialized
INFO - 2016-02-17 06:56:01 --> Router Class Initialized
INFO - 2016-02-17 06:56:01 --> Output Class Initialized
INFO - 2016-02-17 06:56:01 --> Security Class Initialized
DEBUG - 2016-02-17 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:56:01 --> Input Class Initialized
INFO - 2016-02-17 06:56:01 --> Language Class Initialized
INFO - 2016-02-17 06:56:01 --> Loader Class Initialized
INFO - 2016-02-17 06:56:01 --> Helper loaded: url_helper
INFO - 2016-02-17 06:56:01 --> Helper loaded: file_helper
INFO - 2016-02-17 06:56:01 --> Helper loaded: date_helper
INFO - 2016-02-17 06:56:01 --> Helper loaded: form_helper
INFO - 2016-02-17 06:56:01 --> Database Driver Class Initialized
INFO - 2016-02-17 06:56:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:56:02 --> Controller Class Initialized
INFO - 2016-02-17 06:56:02 --> Model Class Initialized
INFO - 2016-02-17 06:56:02 --> Model Class Initialized
INFO - 2016-02-17 06:56:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:56:02 --> Pagination Class Initialized
INFO - 2016-02-17 06:56:02 --> Helper loaded: text_helper
INFO - 2016-02-17 06:56:02 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:56:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:56:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:56:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:56:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:56:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:56:02 --> Final output sent to browser
DEBUG - 2016-02-17 09:56:03 --> Total execution time: 1.1788
INFO - 2016-02-17 06:56:06 --> Config Class Initialized
INFO - 2016-02-17 06:56:06 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:56:06 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:56:06 --> Utf8 Class Initialized
INFO - 2016-02-17 06:56:06 --> Config Class Initialized
INFO - 2016-02-17 06:56:06 --> Hooks Class Initialized
INFO - 2016-02-17 06:56:06 --> URI Class Initialized
INFO - 2016-02-17 06:56:06 --> Router Class Initialized
DEBUG - 2016-02-17 06:56:06 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:56:06 --> Output Class Initialized
INFO - 2016-02-17 06:56:06 --> Utf8 Class Initialized
INFO - 2016-02-17 06:56:06 --> Security Class Initialized
INFO - 2016-02-17 06:56:06 --> URI Class Initialized
DEBUG - 2016-02-17 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:56:06 --> Router Class Initialized
INFO - 2016-02-17 06:56:06 --> Input Class Initialized
INFO - 2016-02-17 06:56:06 --> Language Class Initialized
INFO - 2016-02-17 06:56:06 --> Output Class Initialized
INFO - 2016-02-17 06:56:06 --> Loader Class Initialized
INFO - 2016-02-17 06:56:06 --> Security Class Initialized
INFO - 2016-02-17 06:56:06 --> Helper loaded: url_helper
DEBUG - 2016-02-17 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:56:06 --> Helper loaded: file_helper
INFO - 2016-02-17 06:56:06 --> Input Class Initialized
INFO - 2016-02-17 06:56:06 --> Language Class Initialized
INFO - 2016-02-17 06:56:06 --> Helper loaded: date_helper
INFO - 2016-02-17 06:56:06 --> Loader Class Initialized
INFO - 2016-02-17 06:56:06 --> Helper loaded: form_helper
INFO - 2016-02-17 06:56:06 --> Helper loaded: url_helper
INFO - 2016-02-17 06:56:06 --> Helper loaded: file_helper
INFO - 2016-02-17 06:56:06 --> Database Driver Class Initialized
INFO - 2016-02-17 06:56:06 --> Helper loaded: date_helper
INFO - 2016-02-17 06:56:06 --> Helper loaded: form_helper
INFO - 2016-02-17 06:56:06 --> Database Driver Class Initialized
INFO - 2016-02-17 06:56:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:56:07 --> Controller Class Initialized
INFO - 2016-02-17 06:56:07 --> Model Class Initialized
INFO - 2016-02-17 06:56:07 --> Model Class Initialized
INFO - 2016-02-17 06:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:56:07 --> Pagination Class Initialized
INFO - 2016-02-17 06:56:07 --> Helper loaded: text_helper
INFO - 2016-02-17 06:56:07 --> Helper loaded: cookie_helper
INFO - 2016-02-17 06:56:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:56:08 --> Controller Class Initialized
INFO - 2016-02-17 06:56:08 --> Model Class Initialized
INFO - 2016-02-17 06:56:08 --> Model Class Initialized
INFO - 2016-02-17 06:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:56:08 --> Pagination Class Initialized
INFO - 2016-02-17 06:56:08 --> Helper loaded: text_helper
INFO - 2016-02-17 06:56:08 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-17 09:56:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-17 09:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:56:08 --> Final output sent to browser
DEBUG - 2016-02-17 09:56:08 --> Total execution time: 1.4397
INFO - 2016-02-17 06:57:17 --> Config Class Initialized
INFO - 2016-02-17 06:57:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:17 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:17 --> URI Class Initialized
DEBUG - 2016-02-17 06:57:17 --> No URI present. Default controller set.
INFO - 2016-02-17 06:57:17 --> Router Class Initialized
INFO - 2016-02-17 06:57:17 --> Output Class Initialized
INFO - 2016-02-17 06:57:17 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:17 --> Input Class Initialized
INFO - 2016-02-17 06:57:17 --> Language Class Initialized
INFO - 2016-02-17 06:57:17 --> Loader Class Initialized
INFO - 2016-02-17 06:57:17 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:17 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:17 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:17 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:17 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:18 --> Controller Class Initialized
INFO - 2016-02-17 06:57:18 --> Model Class Initialized
INFO - 2016-02-17 06:57:18 --> Model Class Initialized
INFO - 2016-02-17 06:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:18 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:18 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:18 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 09:57:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:18 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:18 --> Total execution time: 1.0916
INFO - 2016-02-17 06:57:20 --> Config Class Initialized
INFO - 2016-02-17 06:57:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:20 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:20 --> URI Class Initialized
INFO - 2016-02-17 06:57:20 --> Router Class Initialized
INFO - 2016-02-17 06:57:20 --> Output Class Initialized
INFO - 2016-02-17 06:57:20 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:20 --> Input Class Initialized
INFO - 2016-02-17 06:57:20 --> Language Class Initialized
INFO - 2016-02-17 06:57:20 --> Loader Class Initialized
INFO - 2016-02-17 06:57:20 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:20 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:20 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:20 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:20 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:21 --> Controller Class Initialized
INFO - 2016-02-17 06:57:21 --> Model Class Initialized
INFO - 2016-02-17 06:57:21 --> Model Class Initialized
INFO - 2016-02-17 06:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:21 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:21 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:21 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:21 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:21 --> Total execution time: 1.1512
INFO - 2016-02-17 06:57:23 --> Config Class Initialized
INFO - 2016-02-17 06:57:23 --> Config Class Initialized
INFO - 2016-02-17 06:57:23 --> Hooks Class Initialized
INFO - 2016-02-17 06:57:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-17 06:57:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:23 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:23 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:23 --> URI Class Initialized
INFO - 2016-02-17 06:57:23 --> URI Class Initialized
INFO - 2016-02-17 06:57:23 --> Router Class Initialized
INFO - 2016-02-17 06:57:23 --> Router Class Initialized
INFO - 2016-02-17 06:57:23 --> Output Class Initialized
INFO - 2016-02-17 06:57:23 --> Output Class Initialized
INFO - 2016-02-17 06:57:23 --> Security Class Initialized
INFO - 2016-02-17 06:57:23 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-02-17 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:23 --> Input Class Initialized
INFO - 2016-02-17 06:57:23 --> Input Class Initialized
INFO - 2016-02-17 06:57:23 --> Language Class Initialized
INFO - 2016-02-17 06:57:23 --> Language Class Initialized
INFO - 2016-02-17 06:57:23 --> Loader Class Initialized
INFO - 2016-02-17 06:57:23 --> Loader Class Initialized
INFO - 2016-02-17 06:57:23 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:23 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:23 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:23 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:24 --> Controller Class Initialized
INFO - 2016-02-17 06:57:24 --> Model Class Initialized
INFO - 2016-02-17 06:57:24 --> Model Class Initialized
INFO - 2016-02-17 06:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:24 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:24 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 06:57:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:24 --> Controller Class Initialized
INFO - 2016-02-17 06:57:24 --> Model Class Initialized
INFO - 2016-02-17 06:57:24 --> Model Class Initialized
INFO - 2016-02-17 06:57:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:24 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:24 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-17 09:57:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-17 09:57:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:57:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:57:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:24 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:24 --> Total execution time: 1.2819
INFO - 2016-02-17 06:57:30 --> Config Class Initialized
INFO - 2016-02-17 06:57:30 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:30 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:30 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:30 --> URI Class Initialized
INFO - 2016-02-17 06:57:30 --> Router Class Initialized
INFO - 2016-02-17 06:57:30 --> Output Class Initialized
INFO - 2016-02-17 06:57:30 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:30 --> Input Class Initialized
INFO - 2016-02-17 06:57:30 --> Language Class Initialized
INFO - 2016-02-17 06:57:30 --> Loader Class Initialized
INFO - 2016-02-17 06:57:30 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:30 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:30 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:30 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:30 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:31 --> Controller Class Initialized
INFO - 2016-02-17 06:57:31 --> Model Class Initialized
INFO - 2016-02-17 06:57:31 --> Model Class Initialized
INFO - 2016-02-17 06:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:31 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:31 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:31 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-17 09:57:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-17 09:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:32 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:32 --> Total execution time: 1.1224
INFO - 2016-02-17 06:57:37 --> Config Class Initialized
INFO - 2016-02-17 06:57:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:37 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:37 --> URI Class Initialized
DEBUG - 2016-02-17 06:57:37 --> No URI present. Default controller set.
INFO - 2016-02-17 06:57:38 --> Router Class Initialized
INFO - 2016-02-17 06:57:38 --> Output Class Initialized
INFO - 2016-02-17 06:57:38 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:38 --> Input Class Initialized
INFO - 2016-02-17 06:57:38 --> Language Class Initialized
INFO - 2016-02-17 06:57:38 --> Loader Class Initialized
INFO - 2016-02-17 06:57:38 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:38 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:38 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:38 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:38 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:39 --> Controller Class Initialized
INFO - 2016-02-17 06:57:39 --> Model Class Initialized
INFO - 2016-02-17 06:57:39 --> Model Class Initialized
INFO - 2016-02-17 06:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:39 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:39 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:39 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 09:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:39 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:39 --> Total execution time: 1.1149
INFO - 2016-02-17 06:57:41 --> Config Class Initialized
INFO - 2016-02-17 06:57:41 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:41 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:41 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:41 --> URI Class Initialized
INFO - 2016-02-17 06:57:41 --> Router Class Initialized
INFO - 2016-02-17 06:57:41 --> Output Class Initialized
INFO - 2016-02-17 06:57:41 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:41 --> Input Class Initialized
INFO - 2016-02-17 06:57:41 --> Language Class Initialized
INFO - 2016-02-17 06:57:41 --> Loader Class Initialized
INFO - 2016-02-17 06:57:41 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:41 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:41 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:41 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:41 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:42 --> Controller Class Initialized
INFO - 2016-02-17 06:57:42 --> Model Class Initialized
INFO - 2016-02-17 06:57:42 --> Model Class Initialized
INFO - 2016-02-17 06:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:42 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:42 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:42 --> Helper loaded: cookie_helper
INFO - 2016-02-17 09:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 09:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:57:42 --> Final output sent to browser
DEBUG - 2016-02-17 09:57:42 --> Total execution time: 1.1048
INFO - 2016-02-17 06:57:44 --> Config Class Initialized
INFO - 2016-02-17 06:57:44 --> Hooks Class Initialized
DEBUG - 2016-02-17 06:57:44 --> UTF-8 Support Enabled
INFO - 2016-02-17 06:57:44 --> Utf8 Class Initialized
INFO - 2016-02-17 06:57:44 --> URI Class Initialized
INFO - 2016-02-17 06:57:44 --> Router Class Initialized
INFO - 2016-02-17 06:57:44 --> Output Class Initialized
INFO - 2016-02-17 06:57:44 --> Security Class Initialized
DEBUG - 2016-02-17 06:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 06:57:44 --> Input Class Initialized
INFO - 2016-02-17 06:57:44 --> Language Class Initialized
INFO - 2016-02-17 06:57:44 --> Loader Class Initialized
INFO - 2016-02-17 06:57:44 --> Helper loaded: url_helper
INFO - 2016-02-17 06:57:44 --> Helper loaded: file_helper
INFO - 2016-02-17 06:57:44 --> Helper loaded: date_helper
INFO - 2016-02-17 06:57:44 --> Helper loaded: form_helper
INFO - 2016-02-17 06:57:44 --> Database Driver Class Initialized
INFO - 2016-02-17 06:57:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 06:57:45 --> Controller Class Initialized
INFO - 2016-02-17 06:57:45 --> Model Class Initialized
INFO - 2016-02-17 06:57:45 --> Model Class Initialized
INFO - 2016-02-17 06:57:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 06:57:45 --> Pagination Class Initialized
INFO - 2016-02-17 06:57:45 --> Helper loaded: text_helper
INFO - 2016-02-17 06:57:45 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:01:48 --> Config Class Initialized
INFO - 2016-02-17 07:01:48 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:01:48 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:01:48 --> Utf8 Class Initialized
INFO - 2016-02-17 07:01:48 --> URI Class Initialized
INFO - 2016-02-17 07:01:48 --> Router Class Initialized
INFO - 2016-02-17 07:01:48 --> Output Class Initialized
INFO - 2016-02-17 07:01:48 --> Security Class Initialized
DEBUG - 2016-02-17 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:01:48 --> Input Class Initialized
INFO - 2016-02-17 07:01:48 --> Language Class Initialized
INFO - 2016-02-17 07:01:48 --> Loader Class Initialized
INFO - 2016-02-17 07:01:48 --> Helper loaded: url_helper
INFO - 2016-02-17 07:01:48 --> Helper loaded: file_helper
INFO - 2016-02-17 07:01:48 --> Helper loaded: date_helper
INFO - 2016-02-17 07:01:48 --> Helper loaded: form_helper
INFO - 2016-02-17 07:01:48 --> Database Driver Class Initialized
INFO - 2016-02-17 07:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:01:49 --> Controller Class Initialized
INFO - 2016-02-17 07:01:49 --> Model Class Initialized
INFO - 2016-02-17 07:01:49 --> Model Class Initialized
INFO - 2016-02-17 07:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:01:49 --> Pagination Class Initialized
INFO - 2016-02-17 07:01:49 --> Helper loaded: text_helper
INFO - 2016-02-17 07:01:49 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:01:49 --> Final output sent to browser
DEBUG - 2016-02-17 10:01:49 --> Total execution time: 1.1636
INFO - 2016-02-17 07:01:51 --> Config Class Initialized
INFO - 2016-02-17 07:01:51 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:01:51 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:01:51 --> Utf8 Class Initialized
INFO - 2016-02-17 07:01:51 --> URI Class Initialized
INFO - 2016-02-17 07:01:51 --> Router Class Initialized
INFO - 2016-02-17 07:01:51 --> Output Class Initialized
INFO - 2016-02-17 07:01:51 --> Security Class Initialized
DEBUG - 2016-02-17 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:01:51 --> Input Class Initialized
INFO - 2016-02-17 07:01:51 --> Language Class Initialized
INFO - 2016-02-17 07:01:51 --> Loader Class Initialized
INFO - 2016-02-17 07:01:51 --> Helper loaded: url_helper
INFO - 2016-02-17 07:01:51 --> Helper loaded: file_helper
INFO - 2016-02-17 07:01:51 --> Helper loaded: date_helper
INFO - 2016-02-17 07:01:51 --> Helper loaded: form_helper
INFO - 2016-02-17 07:01:51 --> Database Driver Class Initialized
INFO - 2016-02-17 07:01:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:01:52 --> Controller Class Initialized
INFO - 2016-02-17 07:01:52 --> Model Class Initialized
INFO - 2016-02-17 07:01:52 --> Model Class Initialized
INFO - 2016-02-17 07:01:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:01:52 --> Pagination Class Initialized
INFO - 2016-02-17 07:01:52 --> Helper loaded: text_helper
INFO - 2016-02-17 07:01:52 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:02:00 --> Config Class Initialized
INFO - 2016-02-17 07:02:00 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:00 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:00 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:00 --> URI Class Initialized
INFO - 2016-02-17 07:02:00 --> Router Class Initialized
INFO - 2016-02-17 07:02:00 --> Output Class Initialized
INFO - 2016-02-17 07:02:00 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:00 --> Input Class Initialized
INFO - 2016-02-17 07:02:00 --> Language Class Initialized
INFO - 2016-02-17 07:02:00 --> Loader Class Initialized
INFO - 2016-02-17 07:02:00 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:00 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:00 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:00 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:00 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:01 --> Controller Class Initialized
INFO - 2016-02-17 07:02:01 --> Model Class Initialized
INFO - 2016-02-17 07:02:01 --> Model Class Initialized
INFO - 2016-02-17 07:02:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:01 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:01 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:01 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:02:02 --> Config Class Initialized
INFO - 2016-02-17 07:02:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:02 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:02 --> URI Class Initialized
DEBUG - 2016-02-17 07:02:02 --> No URI present. Default controller set.
INFO - 2016-02-17 07:02:02 --> Router Class Initialized
INFO - 2016-02-17 07:02:02 --> Output Class Initialized
INFO - 2016-02-17 07:02:02 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:02 --> Input Class Initialized
INFO - 2016-02-17 07:02:02 --> Language Class Initialized
INFO - 2016-02-17 07:02:02 --> Loader Class Initialized
INFO - 2016-02-17 07:02:02 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:02 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:02 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:02 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:02 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:03 --> Controller Class Initialized
INFO - 2016-02-17 07:02:03 --> Model Class Initialized
INFO - 2016-02-17 07:02:03 --> Model Class Initialized
INFO - 2016-02-17 07:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:03 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:03 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:03 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:02:03 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:03 --> Total execution time: 1.0972
INFO - 2016-02-17 07:02:07 --> Config Class Initialized
INFO - 2016-02-17 07:02:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:07 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:07 --> URI Class Initialized
INFO - 2016-02-17 07:02:07 --> Router Class Initialized
INFO - 2016-02-17 07:02:07 --> Output Class Initialized
INFO - 2016-02-17 07:02:07 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:07 --> Input Class Initialized
INFO - 2016-02-17 07:02:07 --> Language Class Initialized
INFO - 2016-02-17 07:02:07 --> Loader Class Initialized
INFO - 2016-02-17 07:02:07 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:07 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:07 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:07 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:07 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:08 --> Controller Class Initialized
INFO - 2016-02-17 07:02:08 --> Model Class Initialized
INFO - 2016-02-17 07:02:08 --> Model Class Initialized
INFO - 2016-02-17 07:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:08 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:08 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:08 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:02:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:02:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:02:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:02:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:02:08 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:08 --> Total execution time: 1.1652
INFO - 2016-02-17 07:02:10 --> Config Class Initialized
INFO - 2016-02-17 07:02:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:10 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:10 --> URI Class Initialized
INFO - 2016-02-17 07:02:10 --> Router Class Initialized
INFO - 2016-02-17 07:02:10 --> Output Class Initialized
INFO - 2016-02-17 07:02:10 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:10 --> Input Class Initialized
INFO - 2016-02-17 07:02:10 --> Language Class Initialized
INFO - 2016-02-17 07:02:10 --> Loader Class Initialized
INFO - 2016-02-17 07:02:10 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:10 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:10 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:10 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:10 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:11 --> Controller Class Initialized
INFO - 2016-02-17 07:02:11 --> Model Class Initialized
INFO - 2016-02-17 07:02:11 --> Model Class Initialized
INFO - 2016-02-17 07:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:11 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:11 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:11 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:11 --> Total execution time: 1.1440
INFO - 2016-02-17 07:02:36 --> Config Class Initialized
INFO - 2016-02-17 07:02:36 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:36 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:36 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:36 --> URI Class Initialized
DEBUG - 2016-02-17 07:02:36 --> No URI present. Default controller set.
INFO - 2016-02-17 07:02:36 --> Router Class Initialized
INFO - 2016-02-17 07:02:36 --> Output Class Initialized
INFO - 2016-02-17 07:02:36 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:36 --> Input Class Initialized
INFO - 2016-02-17 07:02:36 --> Language Class Initialized
INFO - 2016-02-17 07:02:36 --> Loader Class Initialized
INFO - 2016-02-17 07:02:36 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:36 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:36 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:36 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:36 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:37 --> Controller Class Initialized
INFO - 2016-02-17 07:02:37 --> Model Class Initialized
INFO - 2016-02-17 07:02:37 --> Model Class Initialized
INFO - 2016-02-17 07:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:37 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:37 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:37 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:02:37 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:37 --> Total execution time: 1.1012
INFO - 2016-02-17 07:02:39 --> Config Class Initialized
INFO - 2016-02-17 07:02:39 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:39 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:39 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:39 --> URI Class Initialized
INFO - 2016-02-17 07:02:39 --> Router Class Initialized
INFO - 2016-02-17 07:02:39 --> Output Class Initialized
INFO - 2016-02-17 07:02:39 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:39 --> Input Class Initialized
INFO - 2016-02-17 07:02:39 --> Language Class Initialized
INFO - 2016-02-17 07:02:39 --> Loader Class Initialized
INFO - 2016-02-17 07:02:39 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:39 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:39 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:39 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:39 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:40 --> Controller Class Initialized
INFO - 2016-02-17 07:02:40 --> Model Class Initialized
INFO - 2016-02-17 07:02:40 --> Model Class Initialized
INFO - 2016-02-17 07:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:40 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:40 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:40 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:02:40 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:40 --> Total execution time: 1.2286
INFO - 2016-02-17 07:02:42 --> Config Class Initialized
INFO - 2016-02-17 07:02:42 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:02:42 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:02:42 --> Utf8 Class Initialized
INFO - 2016-02-17 07:02:42 --> URI Class Initialized
INFO - 2016-02-17 07:02:42 --> Router Class Initialized
INFO - 2016-02-17 07:02:42 --> Output Class Initialized
INFO - 2016-02-17 07:02:42 --> Security Class Initialized
DEBUG - 2016-02-17 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:02:42 --> Input Class Initialized
INFO - 2016-02-17 07:02:42 --> Language Class Initialized
INFO - 2016-02-17 07:02:42 --> Loader Class Initialized
INFO - 2016-02-17 07:02:42 --> Helper loaded: url_helper
INFO - 2016-02-17 07:02:42 --> Helper loaded: file_helper
INFO - 2016-02-17 07:02:42 --> Helper loaded: date_helper
INFO - 2016-02-17 07:02:42 --> Helper loaded: form_helper
INFO - 2016-02-17 07:02:42 --> Database Driver Class Initialized
INFO - 2016-02-17 07:02:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:02:43 --> Controller Class Initialized
INFO - 2016-02-17 07:02:43 --> Model Class Initialized
INFO - 2016-02-17 07:02:43 --> Model Class Initialized
INFO - 2016-02-17 07:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:02:43 --> Pagination Class Initialized
INFO - 2016-02-17 07:02:43 --> Helper loaded: text_helper
INFO - 2016-02-17 07:02:43 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:02:43 --> Final output sent to browser
DEBUG - 2016-02-17 10:02:43 --> Total execution time: 1.2275
INFO - 2016-02-17 07:04:04 --> Config Class Initialized
INFO - 2016-02-17 07:04:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:04:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:04:04 --> Utf8 Class Initialized
INFO - 2016-02-17 07:04:04 --> URI Class Initialized
INFO - 2016-02-17 07:04:04 --> Router Class Initialized
INFO - 2016-02-17 07:04:04 --> Output Class Initialized
INFO - 2016-02-17 07:04:04 --> Security Class Initialized
DEBUG - 2016-02-17 07:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:04:04 --> Input Class Initialized
INFO - 2016-02-17 07:04:04 --> Language Class Initialized
INFO - 2016-02-17 07:04:04 --> Loader Class Initialized
INFO - 2016-02-17 07:04:04 --> Helper loaded: url_helper
INFO - 2016-02-17 07:04:04 --> Helper loaded: file_helper
INFO - 2016-02-17 07:04:04 --> Helper loaded: date_helper
INFO - 2016-02-17 07:04:04 --> Helper loaded: form_helper
INFO - 2016-02-17 07:04:04 --> Database Driver Class Initialized
INFO - 2016-02-17 07:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:04:05 --> Controller Class Initialized
INFO - 2016-02-17 07:04:05 --> Model Class Initialized
INFO - 2016-02-17 07:04:05 --> Model Class Initialized
INFO - 2016-02-17 07:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:04:05 --> Pagination Class Initialized
INFO - 2016-02-17 07:04:05 --> Helper loaded: text_helper
INFO - 2016-02-17 07:04:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:04:05 --> Final output sent to browser
DEBUG - 2016-02-17 10:04:05 --> Total execution time: 1.2145
INFO - 2016-02-17 07:04:07 --> Config Class Initialized
INFO - 2016-02-17 07:04:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:04:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:04:07 --> Utf8 Class Initialized
INFO - 2016-02-17 07:04:07 --> URI Class Initialized
INFO - 2016-02-17 07:04:07 --> Router Class Initialized
INFO - 2016-02-17 07:04:07 --> Output Class Initialized
INFO - 2016-02-17 07:04:07 --> Security Class Initialized
DEBUG - 2016-02-17 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:04:07 --> Input Class Initialized
INFO - 2016-02-17 07:04:07 --> Language Class Initialized
INFO - 2016-02-17 07:04:07 --> Loader Class Initialized
INFO - 2016-02-17 07:04:07 --> Helper loaded: url_helper
INFO - 2016-02-17 07:04:07 --> Helper loaded: file_helper
INFO - 2016-02-17 07:04:07 --> Helper loaded: date_helper
INFO - 2016-02-17 07:04:07 --> Helper loaded: form_helper
INFO - 2016-02-17 07:04:07 --> Database Driver Class Initialized
INFO - 2016-02-17 07:04:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:04:08 --> Controller Class Initialized
INFO - 2016-02-17 07:04:08 --> Model Class Initialized
INFO - 2016-02-17 07:04:08 --> Model Class Initialized
INFO - 2016-02-17 07:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:04:08 --> Pagination Class Initialized
INFO - 2016-02-17 07:04:08 --> Helper loaded: text_helper
INFO - 2016-02-17 07:04:08 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:07:29 --> Config Class Initialized
INFO - 2016-02-17 07:07:29 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:07:29 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:07:29 --> Utf8 Class Initialized
INFO - 2016-02-17 07:07:29 --> URI Class Initialized
INFO - 2016-02-17 07:07:29 --> Router Class Initialized
INFO - 2016-02-17 07:07:29 --> Output Class Initialized
INFO - 2016-02-17 07:07:29 --> Security Class Initialized
DEBUG - 2016-02-17 07:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:07:29 --> Input Class Initialized
INFO - 2016-02-17 07:07:29 --> Language Class Initialized
INFO - 2016-02-17 07:07:29 --> Loader Class Initialized
INFO - 2016-02-17 07:07:29 --> Helper loaded: url_helper
INFO - 2016-02-17 07:07:29 --> Helper loaded: file_helper
INFO - 2016-02-17 07:07:29 --> Helper loaded: date_helper
INFO - 2016-02-17 07:07:29 --> Helper loaded: form_helper
INFO - 2016-02-17 07:07:29 --> Database Driver Class Initialized
INFO - 2016-02-17 07:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:07:30 --> Controller Class Initialized
INFO - 2016-02-17 07:07:30 --> Model Class Initialized
INFO - 2016-02-17 07:07:30 --> Model Class Initialized
INFO - 2016-02-17 07:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:07:30 --> Pagination Class Initialized
INFO - 2016-02-17 07:07:30 --> Helper loaded: text_helper
INFO - 2016-02-17 07:07:30 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:07:30 --> Final output sent to browser
DEBUG - 2016-02-17 10:07:30 --> Total execution time: 1.1914
INFO - 2016-02-17 07:07:31 --> Config Class Initialized
INFO - 2016-02-17 07:07:31 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:07:31 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:07:31 --> Utf8 Class Initialized
INFO - 2016-02-17 07:07:31 --> URI Class Initialized
INFO - 2016-02-17 07:07:31 --> Router Class Initialized
INFO - 2016-02-17 07:07:31 --> Output Class Initialized
INFO - 2016-02-17 07:07:31 --> Security Class Initialized
DEBUG - 2016-02-17 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:07:31 --> Input Class Initialized
INFO - 2016-02-17 07:07:31 --> Language Class Initialized
INFO - 2016-02-17 07:07:31 --> Loader Class Initialized
INFO - 2016-02-17 07:07:31 --> Helper loaded: url_helper
INFO - 2016-02-17 07:07:31 --> Helper loaded: file_helper
INFO - 2016-02-17 07:07:31 --> Helper loaded: date_helper
INFO - 2016-02-17 07:07:31 --> Helper loaded: form_helper
INFO - 2016-02-17 07:07:31 --> Database Driver Class Initialized
INFO - 2016-02-17 07:07:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:07:33 --> Controller Class Initialized
INFO - 2016-02-17 07:07:33 --> Model Class Initialized
INFO - 2016-02-17 07:07:33 --> Model Class Initialized
INFO - 2016-02-17 07:07:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:07:33 --> Pagination Class Initialized
INFO - 2016-02-17 07:07:33 --> Helper loaded: text_helper
INFO - 2016-02-17 07:07:33 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:07:43 --> Config Class Initialized
INFO - 2016-02-17 07:07:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:07:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:07:43 --> Utf8 Class Initialized
INFO - 2016-02-17 07:07:43 --> URI Class Initialized
INFO - 2016-02-17 07:07:43 --> Router Class Initialized
INFO - 2016-02-17 07:07:43 --> Output Class Initialized
INFO - 2016-02-17 07:07:43 --> Security Class Initialized
DEBUG - 2016-02-17 07:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:07:43 --> Input Class Initialized
INFO - 2016-02-17 07:07:43 --> Language Class Initialized
INFO - 2016-02-17 07:07:43 --> Loader Class Initialized
INFO - 2016-02-17 07:07:43 --> Helper loaded: url_helper
INFO - 2016-02-17 07:07:43 --> Helper loaded: file_helper
INFO - 2016-02-17 07:07:43 --> Helper loaded: date_helper
INFO - 2016-02-17 07:07:43 --> Helper loaded: form_helper
INFO - 2016-02-17 07:07:43 --> Database Driver Class Initialized
INFO - 2016-02-17 07:07:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:07:45 --> Controller Class Initialized
INFO - 2016-02-17 07:07:45 --> Model Class Initialized
INFO - 2016-02-17 07:07:45 --> Model Class Initialized
INFO - 2016-02-17 07:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:07:45 --> Pagination Class Initialized
INFO - 2016-02-17 07:07:45 --> Helper loaded: text_helper
INFO - 2016-02-17 07:07:45 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:07:45 --> Final output sent to browser
DEBUG - 2016-02-17 10:07:45 --> Total execution time: 1.2799
INFO - 2016-02-17 07:07:46 --> Config Class Initialized
INFO - 2016-02-17 07:07:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:07:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:07:46 --> Utf8 Class Initialized
INFO - 2016-02-17 07:07:46 --> URI Class Initialized
INFO - 2016-02-17 07:07:46 --> Router Class Initialized
INFO - 2016-02-17 07:07:46 --> Output Class Initialized
INFO - 2016-02-17 07:07:46 --> Security Class Initialized
DEBUG - 2016-02-17 07:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:07:46 --> Input Class Initialized
INFO - 2016-02-17 07:07:46 --> Language Class Initialized
INFO - 2016-02-17 07:07:46 --> Loader Class Initialized
INFO - 2016-02-17 07:07:46 --> Helper loaded: url_helper
INFO - 2016-02-17 07:07:46 --> Helper loaded: file_helper
INFO - 2016-02-17 07:07:46 --> Helper loaded: date_helper
INFO - 2016-02-17 07:07:46 --> Helper loaded: form_helper
INFO - 2016-02-17 07:07:46 --> Database Driver Class Initialized
INFO - 2016-02-17 07:07:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:07:47 --> Controller Class Initialized
INFO - 2016-02-17 07:07:47 --> Model Class Initialized
INFO - 2016-02-17 07:07:47 --> Model Class Initialized
INFO - 2016-02-17 07:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:07:47 --> Pagination Class Initialized
INFO - 2016-02-17 07:07:47 --> Helper loaded: text_helper
INFO - 2016-02-17 07:07:47 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:08:52 --> Config Class Initialized
INFO - 2016-02-17 07:08:52 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:08:52 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:08:52 --> Utf8 Class Initialized
INFO - 2016-02-17 07:08:52 --> URI Class Initialized
INFO - 2016-02-17 07:08:52 --> Router Class Initialized
INFO - 2016-02-17 07:08:52 --> Output Class Initialized
INFO - 2016-02-17 07:08:52 --> Security Class Initialized
DEBUG - 2016-02-17 07:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:08:52 --> Input Class Initialized
INFO - 2016-02-17 07:08:52 --> Language Class Initialized
INFO - 2016-02-17 07:08:52 --> Loader Class Initialized
INFO - 2016-02-17 07:08:52 --> Helper loaded: url_helper
INFO - 2016-02-17 07:08:52 --> Helper loaded: file_helper
INFO - 2016-02-17 07:08:52 --> Helper loaded: date_helper
INFO - 2016-02-17 07:08:52 --> Helper loaded: form_helper
INFO - 2016-02-17 07:08:52 --> Database Driver Class Initialized
INFO - 2016-02-17 07:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:08:53 --> Controller Class Initialized
INFO - 2016-02-17 07:08:53 --> Model Class Initialized
INFO - 2016-02-17 07:08:53 --> Model Class Initialized
INFO - 2016-02-17 07:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:08:53 --> Pagination Class Initialized
INFO - 2016-02-17 07:08:53 --> Helper loaded: text_helper
INFO - 2016-02-17 07:08:53 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:08:54 --> Final output sent to browser
DEBUG - 2016-02-17 10:08:54 --> Total execution time: 1.1648
INFO - 2016-02-17 07:08:55 --> Config Class Initialized
INFO - 2016-02-17 07:08:55 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:08:55 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:08:55 --> Utf8 Class Initialized
INFO - 2016-02-17 07:08:55 --> URI Class Initialized
INFO - 2016-02-17 07:08:55 --> Router Class Initialized
INFO - 2016-02-17 07:08:55 --> Output Class Initialized
INFO - 2016-02-17 07:08:55 --> Security Class Initialized
DEBUG - 2016-02-17 07:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:08:55 --> Input Class Initialized
INFO - 2016-02-17 07:08:55 --> Language Class Initialized
INFO - 2016-02-17 07:08:55 --> Loader Class Initialized
INFO - 2016-02-17 07:08:55 --> Helper loaded: url_helper
INFO - 2016-02-17 07:08:55 --> Helper loaded: file_helper
INFO - 2016-02-17 07:08:55 --> Helper loaded: date_helper
INFO - 2016-02-17 07:08:55 --> Helper loaded: form_helper
INFO - 2016-02-17 07:08:55 --> Database Driver Class Initialized
INFO - 2016-02-17 07:08:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:08:56 --> Controller Class Initialized
INFO - 2016-02-17 07:08:56 --> Model Class Initialized
INFO - 2016-02-17 07:08:56 --> Model Class Initialized
INFO - 2016-02-17 07:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:08:56 --> Pagination Class Initialized
INFO - 2016-02-17 07:08:56 --> Helper loaded: text_helper
INFO - 2016-02-17 07:08:56 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:02 --> Config Class Initialized
INFO - 2016-02-17 07:09:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:02 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:02 --> URI Class Initialized
INFO - 2016-02-17 07:09:02 --> Router Class Initialized
INFO - 2016-02-17 07:09:02 --> Output Class Initialized
INFO - 2016-02-17 07:09:02 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:02 --> Input Class Initialized
INFO - 2016-02-17 07:09:02 --> Language Class Initialized
INFO - 2016-02-17 07:09:02 --> Loader Class Initialized
INFO - 2016-02-17 07:09:02 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:02 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:02 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:02 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:02 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:03 --> Controller Class Initialized
INFO - 2016-02-17 07:09:03 --> Model Class Initialized
INFO - 2016-02-17 07:09:03 --> Model Class Initialized
INFO - 2016-02-17 07:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:03 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:03 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:03 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:03 --> Config Class Initialized
INFO - 2016-02-17 07:09:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:03 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:03 --> URI Class Initialized
INFO - 2016-02-17 07:09:03 --> Router Class Initialized
INFO - 2016-02-17 07:09:03 --> Output Class Initialized
INFO - 2016-02-17 07:09:04 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:04 --> Input Class Initialized
INFO - 2016-02-17 07:09:04 --> Language Class Initialized
INFO - 2016-02-17 07:09:04 --> Loader Class Initialized
INFO - 2016-02-17 07:09:04 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:04 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:04 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:04 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:04 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:05 --> Controller Class Initialized
INFO - 2016-02-17 07:09:05 --> Model Class Initialized
INFO - 2016-02-17 07:09:05 --> Model Class Initialized
INFO - 2016-02-17 07:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:05 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:05 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:05 --> Config Class Initialized
INFO - 2016-02-17 07:09:05 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:05 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:05 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:05 --> URI Class Initialized
INFO - 2016-02-17 07:09:05 --> Router Class Initialized
INFO - 2016-02-17 07:09:05 --> Output Class Initialized
INFO - 2016-02-17 07:09:05 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:05 --> Input Class Initialized
INFO - 2016-02-17 07:09:05 --> Language Class Initialized
INFO - 2016-02-17 07:09:05 --> Loader Class Initialized
INFO - 2016-02-17 07:09:05 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:05 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:05 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:05 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:05 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:06 --> Controller Class Initialized
INFO - 2016-02-17 07:09:06 --> Model Class Initialized
INFO - 2016-02-17 07:09:06 --> Model Class Initialized
INFO - 2016-02-17 07:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:06 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:06 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:06 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:07 --> Config Class Initialized
INFO - 2016-02-17 07:09:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:07 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:07 --> URI Class Initialized
INFO - 2016-02-17 07:09:07 --> Router Class Initialized
INFO - 2016-02-17 07:09:07 --> Output Class Initialized
INFO - 2016-02-17 07:09:07 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:07 --> Input Class Initialized
INFO - 2016-02-17 07:09:07 --> Language Class Initialized
INFO - 2016-02-17 07:09:07 --> Loader Class Initialized
INFO - 2016-02-17 07:09:07 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:07 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:07 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:07 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:07 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:08 --> Controller Class Initialized
INFO - 2016-02-17 07:09:08 --> Model Class Initialized
INFO - 2016-02-17 07:09:08 --> Model Class Initialized
INFO - 2016-02-17 07:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:08 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:08 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:08 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:08 --> Config Class Initialized
INFO - 2016-02-17 07:09:08 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:08 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:08 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:08 --> URI Class Initialized
DEBUG - 2016-02-17 07:09:08 --> No URI present. Default controller set.
INFO - 2016-02-17 07:09:08 --> Router Class Initialized
INFO - 2016-02-17 07:09:08 --> Output Class Initialized
INFO - 2016-02-17 07:09:08 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:08 --> Input Class Initialized
INFO - 2016-02-17 07:09:08 --> Language Class Initialized
INFO - 2016-02-17 07:09:08 --> Loader Class Initialized
INFO - 2016-02-17 07:09:08 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:08 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:08 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:08 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:08 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:09 --> Controller Class Initialized
INFO - 2016-02-17 07:09:09 --> Model Class Initialized
INFO - 2016-02-17 07:09:09 --> Model Class Initialized
INFO - 2016-02-17 07:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:09 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:09 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:09 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:09:09 --> Final output sent to browser
DEBUG - 2016-02-17 10:09:09 --> Total execution time: 1.1024
INFO - 2016-02-17 07:09:13 --> Config Class Initialized
INFO - 2016-02-17 07:09:13 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:13 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:13 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:13 --> URI Class Initialized
INFO - 2016-02-17 07:09:13 --> Router Class Initialized
INFO - 2016-02-17 07:09:13 --> Output Class Initialized
INFO - 2016-02-17 07:09:13 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:13 --> Input Class Initialized
INFO - 2016-02-17 07:09:13 --> Language Class Initialized
INFO - 2016-02-17 07:09:13 --> Loader Class Initialized
INFO - 2016-02-17 07:09:13 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:13 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:13 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:13 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:13 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:14 --> Controller Class Initialized
INFO - 2016-02-17 07:09:14 --> Model Class Initialized
INFO - 2016-02-17 07:09:14 --> Model Class Initialized
INFO - 2016-02-17 07:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:14 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:14 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:14 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:09:14 --> Final output sent to browser
DEBUG - 2016-02-17 10:09:14 --> Total execution time: 1.2319
INFO - 2016-02-17 07:09:16 --> Config Class Initialized
INFO - 2016-02-17 07:09:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:16 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:16 --> URI Class Initialized
INFO - 2016-02-17 07:09:16 --> Router Class Initialized
INFO - 2016-02-17 07:09:16 --> Output Class Initialized
INFO - 2016-02-17 07:09:16 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:16 --> Input Class Initialized
INFO - 2016-02-17 07:09:16 --> Language Class Initialized
INFO - 2016-02-17 07:09:16 --> Loader Class Initialized
INFO - 2016-02-17 07:09:16 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:16 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:16 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:16 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:16 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:17 --> Controller Class Initialized
INFO - 2016-02-17 07:09:17 --> Model Class Initialized
INFO - 2016-02-17 07:09:17 --> Model Class Initialized
INFO - 2016-02-17 07:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:17 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:17 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:17 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:09:17 --> Final output sent to browser
DEBUG - 2016-02-17 10:09:17 --> Total execution time: 1.1614
INFO - 2016-02-17 07:09:22 --> Config Class Initialized
INFO - 2016-02-17 07:09:22 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:22 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:22 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:22 --> URI Class Initialized
INFO - 2016-02-17 07:09:22 --> Router Class Initialized
INFO - 2016-02-17 07:09:22 --> Output Class Initialized
INFO - 2016-02-17 07:09:22 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:22 --> Input Class Initialized
INFO - 2016-02-17 07:09:22 --> Language Class Initialized
INFO - 2016-02-17 07:09:22 --> Loader Class Initialized
INFO - 2016-02-17 07:09:22 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:22 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:22 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:22 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:22 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:23 --> Controller Class Initialized
INFO - 2016-02-17 07:09:23 --> Model Class Initialized
INFO - 2016-02-17 07:09:23 --> Model Class Initialized
INFO - 2016-02-17 07:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:23 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:23 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:23 --> Config Class Initialized
INFO - 2016-02-17 07:09:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:23 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:23 --> URI Class Initialized
INFO - 2016-02-17 07:09:23 --> Router Class Initialized
INFO - 2016-02-17 07:09:23 --> Output Class Initialized
INFO - 2016-02-17 07:09:23 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:23 --> Input Class Initialized
INFO - 2016-02-17 07:09:23 --> Language Class Initialized
INFO - 2016-02-17 07:09:23 --> Loader Class Initialized
INFO - 2016-02-17 07:09:23 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:23 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:23 --> Config Class Initialized
INFO - 2016-02-17 07:09:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:23 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:23 --> URI Class Initialized
INFO - 2016-02-17 07:09:23 --> Router Class Initialized
INFO - 2016-02-17 07:09:23 --> Output Class Initialized
INFO - 2016-02-17 07:09:23 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:23 --> Input Class Initialized
INFO - 2016-02-17 07:09:23 --> Language Class Initialized
INFO - 2016-02-17 07:09:23 --> Loader Class Initialized
INFO - 2016-02-17 07:09:23 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:23 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:23 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:24 --> Config Class Initialized
INFO - 2016-02-17 07:09:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:24 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:24 --> URI Class Initialized
INFO - 2016-02-17 07:09:24 --> Router Class Initialized
INFO - 2016-02-17 07:09:24 --> Output Class Initialized
INFO - 2016-02-17 07:09:24 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:24 --> Input Class Initialized
INFO - 2016-02-17 07:09:24 --> Language Class Initialized
INFO - 2016-02-17 07:09:24 --> Loader Class Initialized
INFO - 2016-02-17 07:09:24 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:24 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:24 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:24 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:24 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:24 --> Controller Class Initialized
INFO - 2016-02-17 07:09:24 --> Model Class Initialized
INFO - 2016-02-17 07:09:24 --> Model Class Initialized
INFO - 2016-02-17 07:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:24 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:24 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:25 --> Controller Class Initialized
INFO - 2016-02-17 07:09:25 --> Model Class Initialized
INFO - 2016-02-17 07:09:25 --> Model Class Initialized
INFO - 2016-02-17 07:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:25 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:25 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:25 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:25 --> Controller Class Initialized
INFO - 2016-02-17 07:09:25 --> Model Class Initialized
INFO - 2016-02-17 07:09:25 --> Model Class Initialized
INFO - 2016-02-17 07:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:25 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:25 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:25 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:25 --> Config Class Initialized
INFO - 2016-02-17 07:09:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:25 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:25 --> URI Class Initialized
INFO - 2016-02-17 07:09:25 --> Router Class Initialized
INFO - 2016-02-17 07:09:25 --> Output Class Initialized
INFO - 2016-02-17 07:09:25 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:25 --> Input Class Initialized
INFO - 2016-02-17 07:09:25 --> Language Class Initialized
INFO - 2016-02-17 07:09:25 --> Loader Class Initialized
INFO - 2016-02-17 07:09:25 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:25 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:25 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:25 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:25 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:26 --> Controller Class Initialized
INFO - 2016-02-17 07:09:26 --> Model Class Initialized
INFO - 2016-02-17 07:09:26 --> Model Class Initialized
INFO - 2016-02-17 07:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:26 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:26 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:09:27 --> Config Class Initialized
INFO - 2016-02-17 07:09:27 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:27 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:27 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:27 --> URI Class Initialized
DEBUG - 2016-02-17 07:09:27 --> No URI present. Default controller set.
INFO - 2016-02-17 07:09:27 --> Router Class Initialized
INFO - 2016-02-17 07:09:27 --> Output Class Initialized
INFO - 2016-02-17 07:09:27 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:27 --> Input Class Initialized
INFO - 2016-02-17 07:09:27 --> Language Class Initialized
INFO - 2016-02-17 07:09:27 --> Loader Class Initialized
INFO - 2016-02-17 07:09:27 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:27 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:27 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:27 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:27 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:28 --> Controller Class Initialized
INFO - 2016-02-17 07:09:28 --> Model Class Initialized
INFO - 2016-02-17 07:09:28 --> Model Class Initialized
INFO - 2016-02-17 07:09:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:28 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:28 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:28 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:09:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:09:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:09:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:09:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:09:28 --> Final output sent to browser
DEBUG - 2016-02-17 10:09:28 --> Total execution time: 1.1254
INFO - 2016-02-17 07:09:29 --> Config Class Initialized
INFO - 2016-02-17 07:09:29 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:29 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:29 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:29 --> URI Class Initialized
INFO - 2016-02-17 07:09:29 --> Router Class Initialized
INFO - 2016-02-17 07:09:29 --> Output Class Initialized
INFO - 2016-02-17 07:09:29 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:29 --> Input Class Initialized
INFO - 2016-02-17 07:09:29 --> Language Class Initialized
INFO - 2016-02-17 07:09:29 --> Loader Class Initialized
INFO - 2016-02-17 07:09:29 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:29 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:29 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:29 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:29 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:30 --> Controller Class Initialized
INFO - 2016-02-17 07:09:30 --> Model Class Initialized
INFO - 2016-02-17 07:09:30 --> Model Class Initialized
INFO - 2016-02-17 07:09:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:30 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:30 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:30 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:09:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:09:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:09:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:09:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:09:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:09:30 --> Final output sent to browser
DEBUG - 2016-02-17 10:09:30 --> Total execution time: 1.1395
INFO - 2016-02-17 07:09:32 --> Config Class Initialized
INFO - 2016-02-17 07:09:32 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:09:32 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:09:32 --> Utf8 Class Initialized
INFO - 2016-02-17 07:09:32 --> URI Class Initialized
INFO - 2016-02-17 07:09:32 --> Router Class Initialized
INFO - 2016-02-17 07:09:32 --> Output Class Initialized
INFO - 2016-02-17 07:09:32 --> Security Class Initialized
DEBUG - 2016-02-17 07:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:09:32 --> Input Class Initialized
INFO - 2016-02-17 07:09:32 --> Language Class Initialized
INFO - 2016-02-17 07:09:32 --> Loader Class Initialized
INFO - 2016-02-17 07:09:32 --> Helper loaded: url_helper
INFO - 2016-02-17 07:09:32 --> Helper loaded: file_helper
INFO - 2016-02-17 07:09:32 --> Helper loaded: date_helper
INFO - 2016-02-17 07:09:32 --> Helper loaded: form_helper
INFO - 2016-02-17 07:09:32 --> Database Driver Class Initialized
INFO - 2016-02-17 07:09:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:09:33 --> Controller Class Initialized
INFO - 2016-02-17 07:09:33 --> Model Class Initialized
INFO - 2016-02-17 07:09:33 --> Model Class Initialized
INFO - 2016-02-17 07:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:09:33 --> Pagination Class Initialized
INFO - 2016-02-17 07:09:33 --> Helper loaded: text_helper
INFO - 2016-02-17 07:09:33 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:10:54 --> Config Class Initialized
INFO - 2016-02-17 07:10:54 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:10:54 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:10:54 --> Utf8 Class Initialized
INFO - 2016-02-17 07:10:54 --> URI Class Initialized
INFO - 2016-02-17 07:10:54 --> Router Class Initialized
INFO - 2016-02-17 07:10:54 --> Output Class Initialized
INFO - 2016-02-17 07:10:54 --> Security Class Initialized
DEBUG - 2016-02-17 07:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:10:54 --> Input Class Initialized
INFO - 2016-02-17 07:10:54 --> Language Class Initialized
INFO - 2016-02-17 07:10:54 --> Loader Class Initialized
INFO - 2016-02-17 07:10:54 --> Helper loaded: url_helper
INFO - 2016-02-17 07:10:54 --> Helper loaded: file_helper
INFO - 2016-02-17 07:10:54 --> Helper loaded: date_helper
INFO - 2016-02-17 07:10:54 --> Helper loaded: form_helper
INFO - 2016-02-17 07:10:54 --> Database Driver Class Initialized
INFO - 2016-02-17 07:10:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:10:55 --> Controller Class Initialized
INFO - 2016-02-17 07:10:55 --> Model Class Initialized
INFO - 2016-02-17 07:10:55 --> Model Class Initialized
INFO - 2016-02-17 07:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:10:55 --> Pagination Class Initialized
INFO - 2016-02-17 07:10:55 --> Helper loaded: text_helper
INFO - 2016-02-17 07:10:55 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:10:55 --> Form Validation Class Initialized
INFO - 2016-02-17 10:10:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:10:55 --> Model Class Initialized
INFO - 2016-02-17 10:10:55 --> Final output sent to browser
DEBUG - 2016-02-17 10:10:55 --> Total execution time: 1.2764
INFO - 2016-02-17 07:12:13 --> Config Class Initialized
INFO - 2016-02-17 07:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:12:13 --> Utf8 Class Initialized
INFO - 2016-02-17 07:12:13 --> URI Class Initialized
INFO - 2016-02-17 07:12:13 --> Router Class Initialized
INFO - 2016-02-17 07:12:13 --> Output Class Initialized
INFO - 2016-02-17 07:12:13 --> Security Class Initialized
DEBUG - 2016-02-17 07:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:12:13 --> Input Class Initialized
INFO - 2016-02-17 07:12:13 --> Language Class Initialized
INFO - 2016-02-17 07:12:13 --> Loader Class Initialized
INFO - 2016-02-17 07:12:13 --> Helper loaded: url_helper
INFO - 2016-02-17 07:12:13 --> Helper loaded: file_helper
INFO - 2016-02-17 07:12:13 --> Helper loaded: date_helper
INFO - 2016-02-17 07:12:13 --> Helper loaded: form_helper
INFO - 2016-02-17 07:12:13 --> Database Driver Class Initialized
INFO - 2016-02-17 07:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:12:14 --> Controller Class Initialized
INFO - 2016-02-17 07:12:14 --> Model Class Initialized
INFO - 2016-02-17 07:12:14 --> Model Class Initialized
INFO - 2016-02-17 07:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:12:14 --> Pagination Class Initialized
INFO - 2016-02-17 07:12:14 --> Helper loaded: text_helper
INFO - 2016-02-17 07:12:14 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:12:14 --> Form Validation Class Initialized
INFO - 2016-02-17 10:12:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:12:14 --> Model Class Initialized
INFO - 2016-02-17 10:12:14 --> Final output sent to browser
DEBUG - 2016-02-17 10:12:14 --> Total execution time: 1.1604
INFO - 2016-02-17 07:12:39 --> Config Class Initialized
INFO - 2016-02-17 07:12:39 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:12:39 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:12:39 --> Utf8 Class Initialized
INFO - 2016-02-17 07:12:39 --> URI Class Initialized
DEBUG - 2016-02-17 07:12:39 --> No URI present. Default controller set.
INFO - 2016-02-17 07:12:39 --> Router Class Initialized
INFO - 2016-02-17 07:12:39 --> Output Class Initialized
INFO - 2016-02-17 07:12:39 --> Security Class Initialized
DEBUG - 2016-02-17 07:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:12:39 --> Input Class Initialized
INFO - 2016-02-17 07:12:39 --> Language Class Initialized
INFO - 2016-02-17 07:12:39 --> Loader Class Initialized
INFO - 2016-02-17 07:12:39 --> Helper loaded: url_helper
INFO - 2016-02-17 07:12:39 --> Helper loaded: file_helper
INFO - 2016-02-17 07:12:39 --> Helper loaded: date_helper
INFO - 2016-02-17 07:12:39 --> Helper loaded: form_helper
INFO - 2016-02-17 07:12:39 --> Database Driver Class Initialized
INFO - 2016-02-17 07:12:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:12:40 --> Controller Class Initialized
INFO - 2016-02-17 07:12:40 --> Model Class Initialized
INFO - 2016-02-17 07:12:40 --> Model Class Initialized
INFO - 2016-02-17 07:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:12:40 --> Pagination Class Initialized
INFO - 2016-02-17 07:12:40 --> Helper loaded: text_helper
INFO - 2016-02-17 07:12:40 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:12:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:12:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:12:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:12:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:12:40 --> Final output sent to browser
DEBUG - 2016-02-17 10:12:40 --> Total execution time: 1.0930
INFO - 2016-02-17 07:12:48 --> Config Class Initialized
INFO - 2016-02-17 07:12:48 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:12:48 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:12:48 --> Utf8 Class Initialized
INFO - 2016-02-17 07:12:48 --> URI Class Initialized
DEBUG - 2016-02-17 07:12:48 --> No URI present. Default controller set.
INFO - 2016-02-17 07:12:48 --> Router Class Initialized
INFO - 2016-02-17 07:12:48 --> Output Class Initialized
INFO - 2016-02-17 07:12:48 --> Security Class Initialized
DEBUG - 2016-02-17 07:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:12:48 --> Input Class Initialized
INFO - 2016-02-17 07:12:48 --> Language Class Initialized
INFO - 2016-02-17 07:12:48 --> Loader Class Initialized
INFO - 2016-02-17 07:12:48 --> Helper loaded: url_helper
INFO - 2016-02-17 07:12:48 --> Helper loaded: file_helper
INFO - 2016-02-17 07:12:48 --> Helper loaded: date_helper
INFO - 2016-02-17 07:12:48 --> Helper loaded: form_helper
INFO - 2016-02-17 07:12:48 --> Database Driver Class Initialized
INFO - 2016-02-17 07:12:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:12:49 --> Controller Class Initialized
INFO - 2016-02-17 07:12:49 --> Model Class Initialized
INFO - 2016-02-17 07:12:49 --> Model Class Initialized
INFO - 2016-02-17 07:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:12:49 --> Pagination Class Initialized
INFO - 2016-02-17 07:12:49 --> Helper loaded: text_helper
INFO - 2016-02-17 07:12:49 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:12:49 --> Final output sent to browser
DEBUG - 2016-02-17 10:12:49 --> Total execution time: 1.1268
INFO - 2016-02-17 07:12:52 --> Config Class Initialized
INFO - 2016-02-17 07:12:52 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:12:52 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:12:52 --> Utf8 Class Initialized
INFO - 2016-02-17 07:12:52 --> URI Class Initialized
INFO - 2016-02-17 07:12:52 --> Router Class Initialized
INFO - 2016-02-17 07:12:52 --> Output Class Initialized
INFO - 2016-02-17 07:12:52 --> Security Class Initialized
DEBUG - 2016-02-17 07:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:12:52 --> Input Class Initialized
INFO - 2016-02-17 07:12:52 --> Language Class Initialized
INFO - 2016-02-17 07:12:52 --> Loader Class Initialized
INFO - 2016-02-17 07:12:52 --> Helper loaded: url_helper
INFO - 2016-02-17 07:12:52 --> Helper loaded: file_helper
INFO - 2016-02-17 07:12:52 --> Helper loaded: date_helper
INFO - 2016-02-17 07:12:52 --> Helper loaded: form_helper
INFO - 2016-02-17 07:12:52 --> Database Driver Class Initialized
INFO - 2016-02-17 07:12:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:12:53 --> Controller Class Initialized
INFO - 2016-02-17 07:12:53 --> Model Class Initialized
INFO - 2016-02-17 07:12:53 --> Model Class Initialized
INFO - 2016-02-17 07:12:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:12:53 --> Pagination Class Initialized
INFO - 2016-02-17 07:12:53 --> Helper loaded: text_helper
INFO - 2016-02-17 07:12:53 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:12:53 --> Final output sent to browser
DEBUG - 2016-02-17 10:12:53 --> Total execution time: 1.1929
INFO - 2016-02-17 07:12:56 --> Config Class Initialized
INFO - 2016-02-17 07:12:56 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:12:56 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:12:56 --> Utf8 Class Initialized
INFO - 2016-02-17 07:12:56 --> URI Class Initialized
DEBUG - 2016-02-17 07:12:56 --> No URI present. Default controller set.
INFO - 2016-02-17 07:12:56 --> Router Class Initialized
INFO - 2016-02-17 07:12:56 --> Output Class Initialized
INFO - 2016-02-17 07:12:56 --> Security Class Initialized
DEBUG - 2016-02-17 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:12:56 --> Input Class Initialized
INFO - 2016-02-17 07:12:56 --> Language Class Initialized
INFO - 2016-02-17 07:12:56 --> Loader Class Initialized
INFO - 2016-02-17 07:12:56 --> Helper loaded: url_helper
INFO - 2016-02-17 07:12:56 --> Helper loaded: file_helper
INFO - 2016-02-17 07:12:56 --> Helper loaded: date_helper
INFO - 2016-02-17 07:12:56 --> Helper loaded: form_helper
INFO - 2016-02-17 07:12:56 --> Database Driver Class Initialized
INFO - 2016-02-17 07:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:12:57 --> Controller Class Initialized
INFO - 2016-02-17 07:12:57 --> Model Class Initialized
INFO - 2016-02-17 07:12:57 --> Model Class Initialized
INFO - 2016-02-17 07:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:12:57 --> Pagination Class Initialized
INFO - 2016-02-17 07:12:57 --> Helper loaded: text_helper
INFO - 2016-02-17 07:12:57 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:12:57 --> Final output sent to browser
DEBUG - 2016-02-17 10:12:57 --> Total execution time: 1.1143
INFO - 2016-02-17 07:14:41 --> Config Class Initialized
INFO - 2016-02-17 07:14:41 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:14:41 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:14:41 --> Utf8 Class Initialized
INFO - 2016-02-17 07:14:41 --> URI Class Initialized
INFO - 2016-02-17 07:14:41 --> Router Class Initialized
INFO - 2016-02-17 07:14:41 --> Output Class Initialized
INFO - 2016-02-17 07:14:41 --> Security Class Initialized
DEBUG - 2016-02-17 07:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:14:41 --> Input Class Initialized
INFO - 2016-02-17 07:14:41 --> Language Class Initialized
INFO - 2016-02-17 07:14:41 --> Loader Class Initialized
INFO - 2016-02-17 07:14:41 --> Helper loaded: url_helper
INFO - 2016-02-17 07:14:41 --> Helper loaded: file_helper
INFO - 2016-02-17 07:14:41 --> Helper loaded: date_helper
INFO - 2016-02-17 07:14:41 --> Helper loaded: form_helper
INFO - 2016-02-17 07:14:41 --> Database Driver Class Initialized
INFO - 2016-02-17 07:14:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:14:42 --> Controller Class Initialized
INFO - 2016-02-17 07:14:42 --> Model Class Initialized
INFO - 2016-02-17 07:14:42 --> Model Class Initialized
INFO - 2016-02-17 07:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:14:42 --> Pagination Class Initialized
INFO - 2016-02-17 07:14:42 --> Helper loaded: text_helper
INFO - 2016-02-17 07:14:42 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:14:43 --> Final output sent to browser
DEBUG - 2016-02-17 10:14:43 --> Total execution time: 1.1847
INFO - 2016-02-17 07:15:38 --> Config Class Initialized
INFO - 2016-02-17 07:15:38 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:15:38 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:15:38 --> Utf8 Class Initialized
INFO - 2016-02-17 07:15:38 --> URI Class Initialized
DEBUG - 2016-02-17 07:15:38 --> No URI present. Default controller set.
INFO - 2016-02-17 07:15:38 --> Router Class Initialized
INFO - 2016-02-17 07:15:38 --> Output Class Initialized
INFO - 2016-02-17 07:15:38 --> Security Class Initialized
DEBUG - 2016-02-17 07:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:15:38 --> Input Class Initialized
INFO - 2016-02-17 07:15:38 --> Language Class Initialized
INFO - 2016-02-17 07:15:38 --> Loader Class Initialized
INFO - 2016-02-17 07:15:38 --> Helper loaded: url_helper
INFO - 2016-02-17 07:15:38 --> Helper loaded: file_helper
INFO - 2016-02-17 07:15:38 --> Helper loaded: date_helper
INFO - 2016-02-17 07:15:38 --> Helper loaded: form_helper
INFO - 2016-02-17 07:15:38 --> Database Driver Class Initialized
INFO - 2016-02-17 07:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:15:39 --> Controller Class Initialized
INFO - 2016-02-17 07:15:39 --> Model Class Initialized
INFO - 2016-02-17 07:15:39 --> Model Class Initialized
INFO - 2016-02-17 07:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:15:39 --> Pagination Class Initialized
INFO - 2016-02-17 07:15:39 --> Helper loaded: text_helper
INFO - 2016-02-17 07:15:39 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:15:39 --> Final output sent to browser
DEBUG - 2016-02-17 10:15:39 --> Total execution time: 1.1234
INFO - 2016-02-17 07:15:40 --> Config Class Initialized
INFO - 2016-02-17 07:15:40 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:15:40 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:15:40 --> Utf8 Class Initialized
INFO - 2016-02-17 07:15:40 --> URI Class Initialized
INFO - 2016-02-17 07:15:40 --> Router Class Initialized
INFO - 2016-02-17 07:15:40 --> Output Class Initialized
INFO - 2016-02-17 07:15:40 --> Security Class Initialized
DEBUG - 2016-02-17 07:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:15:40 --> Input Class Initialized
INFO - 2016-02-17 07:15:40 --> Language Class Initialized
INFO - 2016-02-17 07:15:40 --> Loader Class Initialized
INFO - 2016-02-17 07:15:40 --> Helper loaded: url_helper
INFO - 2016-02-17 07:15:40 --> Helper loaded: file_helper
INFO - 2016-02-17 07:15:40 --> Helper loaded: date_helper
INFO - 2016-02-17 07:15:40 --> Helper loaded: form_helper
INFO - 2016-02-17 07:15:40 --> Database Driver Class Initialized
INFO - 2016-02-17 07:15:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:15:41 --> Controller Class Initialized
INFO - 2016-02-17 07:15:41 --> Model Class Initialized
INFO - 2016-02-17 07:15:41 --> Model Class Initialized
INFO - 2016-02-17 07:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:15:41 --> Pagination Class Initialized
INFO - 2016-02-17 07:15:41 --> Helper loaded: text_helper
INFO - 2016-02-17 07:15:41 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:15:41 --> Form Validation Class Initialized
INFO - 2016-02-17 10:15:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-17 10:15:41 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-17 10:15:41 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:15:41 --> Final output sent to browser
DEBUG - 2016-02-17 10:15:41 --> Total execution time: 1.1729
INFO - 2016-02-17 07:21:10 --> Config Class Initialized
INFO - 2016-02-17 07:21:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:21:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:21:10 --> Utf8 Class Initialized
INFO - 2016-02-17 07:21:10 --> URI Class Initialized
DEBUG - 2016-02-17 07:21:10 --> No URI present. Default controller set.
INFO - 2016-02-17 07:21:10 --> Router Class Initialized
INFO - 2016-02-17 07:21:10 --> Output Class Initialized
INFO - 2016-02-17 07:21:10 --> Security Class Initialized
DEBUG - 2016-02-17 07:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:21:10 --> Input Class Initialized
INFO - 2016-02-17 07:21:10 --> Language Class Initialized
INFO - 2016-02-17 07:21:10 --> Loader Class Initialized
INFO - 2016-02-17 07:21:10 --> Helper loaded: url_helper
INFO - 2016-02-17 07:21:10 --> Helper loaded: file_helper
INFO - 2016-02-17 07:21:10 --> Helper loaded: date_helper
INFO - 2016-02-17 07:21:10 --> Helper loaded: form_helper
INFO - 2016-02-17 07:21:10 --> Database Driver Class Initialized
INFO - 2016-02-17 07:21:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:21:11 --> Controller Class Initialized
INFO - 2016-02-17 07:21:11 --> Model Class Initialized
INFO - 2016-02-17 07:21:11 --> Model Class Initialized
INFO - 2016-02-17 07:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:21:11 --> Pagination Class Initialized
INFO - 2016-02-17 07:21:11 --> Helper loaded: text_helper
INFO - 2016-02-17 07:21:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:21:11 --> Final output sent to browser
DEBUG - 2016-02-17 10:21:11 --> Total execution time: 1.1136
INFO - 2016-02-17 07:21:20 --> Config Class Initialized
INFO - 2016-02-17 07:21:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:21:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:21:20 --> Utf8 Class Initialized
INFO - 2016-02-17 07:21:20 --> URI Class Initialized
INFO - 2016-02-17 07:21:20 --> Router Class Initialized
INFO - 2016-02-17 07:21:20 --> Output Class Initialized
INFO - 2016-02-17 07:21:20 --> Security Class Initialized
DEBUG - 2016-02-17 07:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:21:20 --> Input Class Initialized
INFO - 2016-02-17 07:21:20 --> Language Class Initialized
INFO - 2016-02-17 07:21:20 --> Loader Class Initialized
INFO - 2016-02-17 07:21:20 --> Helper loaded: url_helper
INFO - 2016-02-17 07:21:20 --> Helper loaded: file_helper
INFO - 2016-02-17 07:21:20 --> Helper loaded: date_helper
INFO - 2016-02-17 07:21:20 --> Helper loaded: form_helper
INFO - 2016-02-17 07:21:20 --> Database Driver Class Initialized
INFO - 2016-02-17 07:21:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:21:21 --> Controller Class Initialized
INFO - 2016-02-17 07:21:21 --> Model Class Initialized
INFO - 2016-02-17 07:21:21 --> Model Class Initialized
INFO - 2016-02-17 07:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:21:21 --> Pagination Class Initialized
INFO - 2016-02-17 07:21:21 --> Helper loaded: text_helper
INFO - 2016-02-17 07:21:21 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:21:21 --> Form Validation Class Initialized
INFO - 2016-02-17 10:21:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-17 10:21:21 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-17 10:21:21 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:21:21 --> Final output sent to browser
DEBUG - 2016-02-17 10:21:21 --> Total execution time: 1.1294
INFO - 2016-02-17 07:21:41 --> Config Class Initialized
INFO - 2016-02-17 07:21:41 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:21:41 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:21:41 --> Utf8 Class Initialized
INFO - 2016-02-17 07:21:41 --> URI Class Initialized
DEBUG - 2016-02-17 07:21:41 --> No URI present. Default controller set.
INFO - 2016-02-17 07:21:41 --> Router Class Initialized
INFO - 2016-02-17 07:21:41 --> Output Class Initialized
INFO - 2016-02-17 07:21:41 --> Security Class Initialized
DEBUG - 2016-02-17 07:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:21:41 --> Input Class Initialized
INFO - 2016-02-17 07:21:41 --> Language Class Initialized
INFO - 2016-02-17 07:21:41 --> Loader Class Initialized
INFO - 2016-02-17 07:21:41 --> Helper loaded: url_helper
INFO - 2016-02-17 07:21:41 --> Helper loaded: file_helper
INFO - 2016-02-17 07:21:41 --> Helper loaded: date_helper
INFO - 2016-02-17 07:21:41 --> Helper loaded: form_helper
INFO - 2016-02-17 07:21:41 --> Database Driver Class Initialized
INFO - 2016-02-17 07:21:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:21:42 --> Controller Class Initialized
INFO - 2016-02-17 07:21:42 --> Model Class Initialized
INFO - 2016-02-17 07:21:42 --> Model Class Initialized
INFO - 2016-02-17 07:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:21:42 --> Pagination Class Initialized
INFO - 2016-02-17 07:21:42 --> Helper loaded: text_helper
INFO - 2016-02-17 07:21:42 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:21:42 --> Final output sent to browser
DEBUG - 2016-02-17 10:21:42 --> Total execution time: 1.1148
INFO - 2016-02-17 07:21:46 --> Config Class Initialized
INFO - 2016-02-17 07:21:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:21:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:21:46 --> Utf8 Class Initialized
INFO - 2016-02-17 07:21:46 --> URI Class Initialized
INFO - 2016-02-17 07:21:46 --> Router Class Initialized
INFO - 2016-02-17 07:21:46 --> Output Class Initialized
INFO - 2016-02-17 07:21:46 --> Security Class Initialized
DEBUG - 2016-02-17 07:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:21:46 --> Input Class Initialized
INFO - 2016-02-17 07:21:46 --> Language Class Initialized
INFO - 2016-02-17 07:21:46 --> Loader Class Initialized
INFO - 2016-02-17 07:21:46 --> Helper loaded: url_helper
INFO - 2016-02-17 07:21:46 --> Helper loaded: file_helper
INFO - 2016-02-17 07:21:46 --> Helper loaded: date_helper
INFO - 2016-02-17 07:21:46 --> Helper loaded: form_helper
INFO - 2016-02-17 07:21:46 --> Database Driver Class Initialized
INFO - 2016-02-17 07:21:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:21:47 --> Controller Class Initialized
INFO - 2016-02-17 07:21:47 --> Model Class Initialized
INFO - 2016-02-17 07:21:47 --> Model Class Initialized
INFO - 2016-02-17 07:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:21:47 --> Pagination Class Initialized
INFO - 2016-02-17 07:21:47 --> Helper loaded: text_helper
INFO - 2016-02-17 07:21:47 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:21:47 --> Final output sent to browser
DEBUG - 2016-02-17 10:21:47 --> Total execution time: 1.2056
INFO - 2016-02-17 07:22:40 --> Config Class Initialized
INFO - 2016-02-17 07:22:40 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:22:40 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:22:40 --> Utf8 Class Initialized
INFO - 2016-02-17 07:22:40 --> URI Class Initialized
DEBUG - 2016-02-17 07:22:40 --> No URI present. Default controller set.
INFO - 2016-02-17 07:22:40 --> Router Class Initialized
INFO - 2016-02-17 07:22:40 --> Output Class Initialized
INFO - 2016-02-17 07:22:40 --> Security Class Initialized
DEBUG - 2016-02-17 07:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:22:40 --> Input Class Initialized
INFO - 2016-02-17 07:22:40 --> Language Class Initialized
INFO - 2016-02-17 07:22:40 --> Loader Class Initialized
INFO - 2016-02-17 07:22:40 --> Helper loaded: url_helper
INFO - 2016-02-17 07:22:40 --> Helper loaded: file_helper
INFO - 2016-02-17 07:22:40 --> Helper loaded: date_helper
INFO - 2016-02-17 07:22:40 --> Helper loaded: form_helper
INFO - 2016-02-17 07:22:40 --> Database Driver Class Initialized
INFO - 2016-02-17 07:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:22:41 --> Controller Class Initialized
INFO - 2016-02-17 07:22:41 --> Model Class Initialized
INFO - 2016-02-17 07:22:41 --> Model Class Initialized
INFO - 2016-02-17 07:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:22:41 --> Pagination Class Initialized
INFO - 2016-02-17 07:22:41 --> Helper loaded: text_helper
INFO - 2016-02-17 07:22:41 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:22:42 --> Final output sent to browser
DEBUG - 2016-02-17 10:22:42 --> Total execution time: 1.1206
INFO - 2016-02-17 07:22:43 --> Config Class Initialized
INFO - 2016-02-17 07:22:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:22:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:22:44 --> Utf8 Class Initialized
INFO - 2016-02-17 07:22:44 --> URI Class Initialized
INFO - 2016-02-17 07:22:44 --> Router Class Initialized
INFO - 2016-02-17 07:22:44 --> Output Class Initialized
INFO - 2016-02-17 07:22:44 --> Security Class Initialized
DEBUG - 2016-02-17 07:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:22:44 --> Input Class Initialized
INFO - 2016-02-17 07:22:44 --> Language Class Initialized
INFO - 2016-02-17 07:22:44 --> Loader Class Initialized
INFO - 2016-02-17 07:22:44 --> Helper loaded: url_helper
INFO - 2016-02-17 07:22:44 --> Helper loaded: file_helper
INFO - 2016-02-17 07:22:44 --> Helper loaded: date_helper
INFO - 2016-02-17 07:22:44 --> Helper loaded: form_helper
INFO - 2016-02-17 07:22:44 --> Database Driver Class Initialized
INFO - 2016-02-17 07:22:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:22:45 --> Controller Class Initialized
INFO - 2016-02-17 07:22:45 --> Model Class Initialized
INFO - 2016-02-17 07:22:45 --> Model Class Initialized
INFO - 2016-02-17 07:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:22:45 --> Pagination Class Initialized
INFO - 2016-02-17 07:22:45 --> Helper loaded: text_helper
INFO - 2016-02-17 07:22:45 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:22:45 --> Final output sent to browser
DEBUG - 2016-02-17 10:22:45 --> Total execution time: 1.0827
INFO - 2016-02-17 07:23:00 --> Config Class Initialized
INFO - 2016-02-17 07:23:00 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:23:00 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:23:00 --> Utf8 Class Initialized
INFO - 2016-02-17 07:23:00 --> URI Class Initialized
DEBUG - 2016-02-17 07:23:00 --> No URI present. Default controller set.
INFO - 2016-02-17 07:23:00 --> Router Class Initialized
INFO - 2016-02-17 07:23:00 --> Output Class Initialized
INFO - 2016-02-17 07:23:00 --> Security Class Initialized
DEBUG - 2016-02-17 07:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:23:00 --> Input Class Initialized
INFO - 2016-02-17 07:23:00 --> Language Class Initialized
INFO - 2016-02-17 07:23:00 --> Loader Class Initialized
INFO - 2016-02-17 07:23:00 --> Helper loaded: url_helper
INFO - 2016-02-17 07:23:00 --> Helper loaded: file_helper
INFO - 2016-02-17 07:23:00 --> Helper loaded: date_helper
INFO - 2016-02-17 07:23:00 --> Helper loaded: form_helper
INFO - 2016-02-17 07:23:00 --> Database Driver Class Initialized
INFO - 2016-02-17 07:23:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:23:01 --> Controller Class Initialized
INFO - 2016-02-17 07:23:01 --> Model Class Initialized
INFO - 2016-02-17 07:23:01 --> Model Class Initialized
INFO - 2016-02-17 07:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:23:01 --> Pagination Class Initialized
INFO - 2016-02-17 07:23:01 --> Helper loaded: text_helper
INFO - 2016-02-17 07:23:01 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:23:01 --> Final output sent to browser
DEBUG - 2016-02-17 10:23:01 --> Total execution time: 1.1172
INFO - 2016-02-17 07:26:10 --> Config Class Initialized
INFO - 2016-02-17 07:26:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:26:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:26:10 --> Utf8 Class Initialized
INFO - 2016-02-17 07:26:10 --> URI Class Initialized
DEBUG - 2016-02-17 07:26:10 --> No URI present. Default controller set.
INFO - 2016-02-17 07:26:10 --> Router Class Initialized
INFO - 2016-02-17 07:26:10 --> Output Class Initialized
INFO - 2016-02-17 07:26:10 --> Security Class Initialized
DEBUG - 2016-02-17 07:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:26:10 --> Input Class Initialized
INFO - 2016-02-17 07:26:10 --> Language Class Initialized
INFO - 2016-02-17 07:26:10 --> Loader Class Initialized
INFO - 2016-02-17 07:26:10 --> Helper loaded: url_helper
INFO - 2016-02-17 07:26:10 --> Helper loaded: file_helper
INFO - 2016-02-17 07:26:10 --> Helper loaded: date_helper
INFO - 2016-02-17 07:26:10 --> Helper loaded: form_helper
INFO - 2016-02-17 07:26:10 --> Database Driver Class Initialized
INFO - 2016-02-17 07:26:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:26:11 --> Controller Class Initialized
INFO - 2016-02-17 07:26:11 --> Model Class Initialized
INFO - 2016-02-17 07:26:11 --> Model Class Initialized
INFO - 2016-02-17 07:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:26:11 --> Pagination Class Initialized
INFO - 2016-02-17 07:26:11 --> Helper loaded: text_helper
INFO - 2016-02-17 07:26:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:26:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:26:11 --> Final output sent to browser
DEBUG - 2016-02-17 10:26:11 --> Total execution time: 1.1423
INFO - 2016-02-17 07:29:24 --> Config Class Initialized
INFO - 2016-02-17 07:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:29:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:29:24 --> Utf8 Class Initialized
INFO - 2016-02-17 07:29:24 --> URI Class Initialized
DEBUG - 2016-02-17 07:29:24 --> No URI present. Default controller set.
INFO - 2016-02-17 07:29:24 --> Router Class Initialized
INFO - 2016-02-17 07:29:24 --> Output Class Initialized
INFO - 2016-02-17 07:29:24 --> Security Class Initialized
DEBUG - 2016-02-17 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:29:24 --> Input Class Initialized
INFO - 2016-02-17 07:29:24 --> Language Class Initialized
INFO - 2016-02-17 07:29:24 --> Loader Class Initialized
INFO - 2016-02-17 07:29:24 --> Helper loaded: url_helper
INFO - 2016-02-17 07:29:24 --> Helper loaded: file_helper
INFO - 2016-02-17 07:29:24 --> Helper loaded: date_helper
INFO - 2016-02-17 07:29:24 --> Helper loaded: form_helper
INFO - 2016-02-17 07:29:24 --> Database Driver Class Initialized
INFO - 2016-02-17 07:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:29:25 --> Controller Class Initialized
INFO - 2016-02-17 07:29:25 --> Model Class Initialized
INFO - 2016-02-17 07:29:25 --> Model Class Initialized
INFO - 2016-02-17 07:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:29:25 --> Pagination Class Initialized
INFO - 2016-02-17 07:29:25 --> Helper loaded: text_helper
INFO - 2016-02-17 07:29:25 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:29:25 --> Final output sent to browser
DEBUG - 2016-02-17 10:29:25 --> Total execution time: 1.1176
INFO - 2016-02-17 07:29:27 --> Config Class Initialized
INFO - 2016-02-17 07:29:27 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:29:27 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:29:27 --> Utf8 Class Initialized
INFO - 2016-02-17 07:29:27 --> URI Class Initialized
INFO - 2016-02-17 07:29:27 --> Router Class Initialized
INFO - 2016-02-17 07:29:27 --> Output Class Initialized
INFO - 2016-02-17 07:29:27 --> Security Class Initialized
DEBUG - 2016-02-17 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:29:27 --> Input Class Initialized
INFO - 2016-02-17 07:29:27 --> Language Class Initialized
INFO - 2016-02-17 07:29:27 --> Loader Class Initialized
INFO - 2016-02-17 07:29:27 --> Helper loaded: url_helper
INFO - 2016-02-17 07:29:27 --> Helper loaded: file_helper
INFO - 2016-02-17 07:29:27 --> Helper loaded: date_helper
INFO - 2016-02-17 07:29:27 --> Helper loaded: form_helper
INFO - 2016-02-17 07:29:27 --> Database Driver Class Initialized
INFO - 2016-02-17 07:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:29:28 --> Controller Class Initialized
INFO - 2016-02-17 07:29:28 --> Model Class Initialized
INFO - 2016-02-17 07:29:28 --> Model Class Initialized
INFO - 2016-02-17 07:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:29:28 --> Pagination Class Initialized
INFO - 2016-02-17 07:29:28 --> Helper loaded: text_helper
INFO - 2016-02-17 07:29:28 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:29:28 --> Form Validation Class Initialized
INFO - 2016-02-17 10:29:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:29:28 --> Final output sent to browser
DEBUG - 2016-02-17 10:29:28 --> Total execution time: 1.1496
INFO - 2016-02-17 07:30:49 --> Config Class Initialized
INFO - 2016-02-17 07:30:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:30:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:30:49 --> Utf8 Class Initialized
INFO - 2016-02-17 07:30:49 --> URI Class Initialized
DEBUG - 2016-02-17 07:30:49 --> No URI present. Default controller set.
INFO - 2016-02-17 07:30:49 --> Router Class Initialized
INFO - 2016-02-17 07:30:49 --> Output Class Initialized
INFO - 2016-02-17 07:30:49 --> Security Class Initialized
DEBUG - 2016-02-17 07:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:30:49 --> Input Class Initialized
INFO - 2016-02-17 07:30:49 --> Language Class Initialized
INFO - 2016-02-17 07:30:49 --> Loader Class Initialized
INFO - 2016-02-17 07:30:49 --> Helper loaded: url_helper
INFO - 2016-02-17 07:30:49 --> Helper loaded: file_helper
INFO - 2016-02-17 07:30:49 --> Helper loaded: date_helper
INFO - 2016-02-17 07:30:49 --> Helper loaded: form_helper
INFO - 2016-02-17 07:30:49 --> Database Driver Class Initialized
INFO - 2016-02-17 07:30:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:30:50 --> Controller Class Initialized
INFO - 2016-02-17 07:30:50 --> Model Class Initialized
INFO - 2016-02-17 07:30:50 --> Model Class Initialized
INFO - 2016-02-17 07:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:30:50 --> Pagination Class Initialized
INFO - 2016-02-17 07:30:50 --> Helper loaded: text_helper
INFO - 2016-02-17 07:30:50 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:30:50 --> Final output sent to browser
DEBUG - 2016-02-17 10:30:50 --> Total execution time: 1.1064
INFO - 2016-02-17 07:30:51 --> Config Class Initialized
INFO - 2016-02-17 07:30:51 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:30:51 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:30:51 --> Utf8 Class Initialized
INFO - 2016-02-17 07:30:51 --> URI Class Initialized
INFO - 2016-02-17 07:30:51 --> Router Class Initialized
INFO - 2016-02-17 07:30:51 --> Output Class Initialized
INFO - 2016-02-17 07:30:51 --> Security Class Initialized
DEBUG - 2016-02-17 07:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:30:51 --> Input Class Initialized
INFO - 2016-02-17 07:30:51 --> Language Class Initialized
INFO - 2016-02-17 07:30:51 --> Loader Class Initialized
INFO - 2016-02-17 07:30:51 --> Helper loaded: url_helper
INFO - 2016-02-17 07:30:51 --> Helper loaded: file_helper
INFO - 2016-02-17 07:30:51 --> Helper loaded: date_helper
INFO - 2016-02-17 07:30:51 --> Helper loaded: form_helper
INFO - 2016-02-17 07:30:51 --> Database Driver Class Initialized
INFO - 2016-02-17 07:30:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:30:52 --> Controller Class Initialized
INFO - 2016-02-17 07:30:52 --> Model Class Initialized
INFO - 2016-02-17 07:30:52 --> Model Class Initialized
INFO - 2016-02-17 07:30:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:30:52 --> Pagination Class Initialized
INFO - 2016-02-17 07:30:52 --> Helper loaded: text_helper
INFO - 2016-02-17 07:30:52 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:30:52 --> Form Validation Class Initialized
INFO - 2016-02-17 10:30:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:30:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:30:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:30:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:30:52 --> Final output sent to browser
DEBUG - 2016-02-17 10:30:52 --> Total execution time: 1.1300
INFO - 2016-02-17 07:31:00 --> Config Class Initialized
INFO - 2016-02-17 07:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:00 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:00 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:00 --> URI Class Initialized
DEBUG - 2016-02-17 07:31:00 --> No URI present. Default controller set.
INFO - 2016-02-17 07:31:00 --> Router Class Initialized
INFO - 2016-02-17 07:31:00 --> Output Class Initialized
INFO - 2016-02-17 07:31:00 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:00 --> Input Class Initialized
INFO - 2016-02-17 07:31:00 --> Language Class Initialized
INFO - 2016-02-17 07:31:00 --> Loader Class Initialized
INFO - 2016-02-17 07:31:00 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:00 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:00 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:00 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:00 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:01 --> Controller Class Initialized
INFO - 2016-02-17 07:31:01 --> Model Class Initialized
INFO - 2016-02-17 07:31:01 --> Model Class Initialized
INFO - 2016-02-17 07:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:01 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:01 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:01 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:01 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:01 --> Total execution time: 1.1043
INFO - 2016-02-17 07:31:09 --> Config Class Initialized
INFO - 2016-02-17 07:31:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:09 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:09 --> URI Class Initialized
DEBUG - 2016-02-17 07:31:09 --> No URI present. Default controller set.
INFO - 2016-02-17 07:31:09 --> Router Class Initialized
INFO - 2016-02-17 07:31:09 --> Output Class Initialized
INFO - 2016-02-17 07:31:09 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:09 --> Input Class Initialized
INFO - 2016-02-17 07:31:09 --> Language Class Initialized
INFO - 2016-02-17 07:31:09 --> Loader Class Initialized
INFO - 2016-02-17 07:31:09 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:09 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:09 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:09 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:09 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:10 --> Controller Class Initialized
INFO - 2016-02-17 07:31:10 --> Model Class Initialized
INFO - 2016-02-17 07:31:10 --> Model Class Initialized
INFO - 2016-02-17 07:31:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:10 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:10 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:10 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:31:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:10 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:10 --> Total execution time: 1.1007
INFO - 2016-02-17 07:31:15 --> Config Class Initialized
INFO - 2016-02-17 07:31:15 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:15 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:15 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:15 --> URI Class Initialized
DEBUG - 2016-02-17 07:31:15 --> No URI present. Default controller set.
INFO - 2016-02-17 07:31:15 --> Router Class Initialized
INFO - 2016-02-17 07:31:15 --> Output Class Initialized
INFO - 2016-02-17 07:31:15 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:15 --> Input Class Initialized
INFO - 2016-02-17 07:31:15 --> Language Class Initialized
INFO - 2016-02-17 07:31:15 --> Loader Class Initialized
INFO - 2016-02-17 07:31:15 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:15 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:15 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:15 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:15 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:16 --> Controller Class Initialized
INFO - 2016-02-17 07:31:16 --> Model Class Initialized
INFO - 2016-02-17 07:31:16 --> Model Class Initialized
INFO - 2016-02-17 07:31:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:16 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:16 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:16 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:31:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:16 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:16 --> Total execution time: 1.1331
INFO - 2016-02-17 07:31:28 --> Config Class Initialized
INFO - 2016-02-17 07:31:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:28 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:28 --> URI Class Initialized
INFO - 2016-02-17 07:31:28 --> Router Class Initialized
INFO - 2016-02-17 07:31:28 --> Output Class Initialized
INFO - 2016-02-17 07:31:28 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:28 --> Input Class Initialized
INFO - 2016-02-17 07:31:28 --> Language Class Initialized
INFO - 2016-02-17 07:31:28 --> Loader Class Initialized
INFO - 2016-02-17 07:31:28 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:28 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:28 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:28 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:28 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:29 --> Controller Class Initialized
INFO - 2016-02-17 07:31:29 --> Model Class Initialized
INFO - 2016-02-17 07:31:29 --> Model Class Initialized
INFO - 2016-02-17 07:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:29 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:29 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:29 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:29 --> Total execution time: 1.1622
INFO - 2016-02-17 07:31:33 --> Config Class Initialized
INFO - 2016-02-17 07:31:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:33 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:33 --> URI Class Initialized
DEBUG - 2016-02-17 07:31:33 --> No URI present. Default controller set.
INFO - 2016-02-17 07:31:33 --> Router Class Initialized
INFO - 2016-02-17 07:31:33 --> Output Class Initialized
INFO - 2016-02-17 07:31:33 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:33 --> Input Class Initialized
INFO - 2016-02-17 07:31:33 --> Language Class Initialized
INFO - 2016-02-17 07:31:33 --> Loader Class Initialized
INFO - 2016-02-17 07:31:33 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:33 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:33 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:33 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:33 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:34 --> Controller Class Initialized
INFO - 2016-02-17 07:31:34 --> Model Class Initialized
INFO - 2016-02-17 07:31:34 --> Model Class Initialized
INFO - 2016-02-17 07:31:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:34 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:34 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:31:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:34 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:34 --> Total execution time: 1.1017
INFO - 2016-02-17 07:31:36 --> Config Class Initialized
INFO - 2016-02-17 07:31:36 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:31:36 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:31:36 --> Utf8 Class Initialized
INFO - 2016-02-17 07:31:36 --> URI Class Initialized
INFO - 2016-02-17 07:31:36 --> Router Class Initialized
INFO - 2016-02-17 07:31:36 --> Output Class Initialized
INFO - 2016-02-17 07:31:36 --> Security Class Initialized
DEBUG - 2016-02-17 07:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:31:36 --> Input Class Initialized
INFO - 2016-02-17 07:31:36 --> Language Class Initialized
INFO - 2016-02-17 07:31:36 --> Loader Class Initialized
INFO - 2016-02-17 07:31:36 --> Helper loaded: url_helper
INFO - 2016-02-17 07:31:36 --> Helper loaded: file_helper
INFO - 2016-02-17 07:31:36 --> Helper loaded: date_helper
INFO - 2016-02-17 07:31:36 --> Helper loaded: form_helper
INFO - 2016-02-17 07:31:36 --> Database Driver Class Initialized
INFO - 2016-02-17 07:31:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:31:37 --> Controller Class Initialized
INFO - 2016-02-17 07:31:37 --> Model Class Initialized
INFO - 2016-02-17 07:31:37 --> Model Class Initialized
INFO - 2016-02-17 07:31:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:31:37 --> Pagination Class Initialized
INFO - 2016-02-17 07:31:37 --> Helper loaded: text_helper
INFO - 2016-02-17 07:31:37 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:31:37 --> Form Validation Class Initialized
INFO - 2016-02-17 10:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-17 10:31:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:31:37 --> Final output sent to browser
DEBUG - 2016-02-17 10:31:37 --> Total execution time: 1.1176
INFO - 2016-02-17 07:35:07 --> Config Class Initialized
INFO - 2016-02-17 07:35:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:35:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:35:07 --> Utf8 Class Initialized
INFO - 2016-02-17 07:35:07 --> URI Class Initialized
DEBUG - 2016-02-17 07:35:07 --> No URI present. Default controller set.
INFO - 2016-02-17 07:35:07 --> Router Class Initialized
INFO - 2016-02-17 07:35:07 --> Output Class Initialized
INFO - 2016-02-17 07:35:07 --> Security Class Initialized
DEBUG - 2016-02-17 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:35:07 --> Input Class Initialized
INFO - 2016-02-17 07:35:07 --> Language Class Initialized
INFO - 2016-02-17 07:35:07 --> Loader Class Initialized
INFO - 2016-02-17 07:35:07 --> Helper loaded: url_helper
INFO - 2016-02-17 07:35:07 --> Helper loaded: file_helper
INFO - 2016-02-17 07:35:07 --> Helper loaded: date_helper
INFO - 2016-02-17 07:35:07 --> Helper loaded: form_helper
INFO - 2016-02-17 07:35:07 --> Database Driver Class Initialized
INFO - 2016-02-17 07:35:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:35:08 --> Controller Class Initialized
INFO - 2016-02-17 07:35:08 --> Model Class Initialized
INFO - 2016-02-17 07:35:08 --> Model Class Initialized
INFO - 2016-02-17 07:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:35:08 --> Pagination Class Initialized
INFO - 2016-02-17 07:35:08 --> Helper loaded: text_helper
INFO - 2016-02-17 07:35:08 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:35:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:35:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:35:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:35:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:35:08 --> Final output sent to browser
DEBUG - 2016-02-17 10:35:08 --> Total execution time: 1.1216
INFO - 2016-02-17 07:35:11 --> Config Class Initialized
INFO - 2016-02-17 07:35:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:35:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:35:11 --> Utf8 Class Initialized
INFO - 2016-02-17 07:35:11 --> URI Class Initialized
INFO - 2016-02-17 07:35:11 --> Router Class Initialized
INFO - 2016-02-17 07:35:11 --> Output Class Initialized
INFO - 2016-02-17 07:35:11 --> Security Class Initialized
DEBUG - 2016-02-17 07:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:35:11 --> Input Class Initialized
INFO - 2016-02-17 07:35:11 --> Language Class Initialized
INFO - 2016-02-17 07:35:11 --> Loader Class Initialized
INFO - 2016-02-17 07:35:11 --> Helper loaded: url_helper
INFO - 2016-02-17 07:35:11 --> Helper loaded: file_helper
INFO - 2016-02-17 07:35:11 --> Helper loaded: date_helper
INFO - 2016-02-17 07:35:11 --> Helper loaded: form_helper
INFO - 2016-02-17 07:35:11 --> Database Driver Class Initialized
INFO - 2016-02-17 07:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:35:12 --> Controller Class Initialized
INFO - 2016-02-17 07:35:12 --> Model Class Initialized
INFO - 2016-02-17 07:35:12 --> Model Class Initialized
INFO - 2016-02-17 07:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:35:12 --> Pagination Class Initialized
INFO - 2016-02-17 07:35:12 --> Helper loaded: text_helper
INFO - 2016-02-17 07:35:12 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:35:12 --> Form Validation Class Initialized
INFO - 2016-02-17 10:35:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:35:12 --> Final output sent to browser
DEBUG - 2016-02-17 10:35:12 --> Total execution time: 1.2805
INFO - 2016-02-17 07:35:35 --> Config Class Initialized
INFO - 2016-02-17 07:35:35 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:35:35 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:35:35 --> Utf8 Class Initialized
INFO - 2016-02-17 07:35:35 --> URI Class Initialized
INFO - 2016-02-17 07:35:35 --> Router Class Initialized
INFO - 2016-02-17 07:35:35 --> Output Class Initialized
INFO - 2016-02-17 07:35:35 --> Security Class Initialized
DEBUG - 2016-02-17 07:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:35:35 --> Input Class Initialized
INFO - 2016-02-17 07:35:35 --> Language Class Initialized
INFO - 2016-02-17 07:35:35 --> Loader Class Initialized
INFO - 2016-02-17 07:35:35 --> Helper loaded: url_helper
INFO - 2016-02-17 07:35:35 --> Helper loaded: file_helper
INFO - 2016-02-17 07:35:35 --> Helper loaded: date_helper
INFO - 2016-02-17 07:35:35 --> Helper loaded: form_helper
INFO - 2016-02-17 07:35:35 --> Database Driver Class Initialized
INFO - 2016-02-17 07:35:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:35:36 --> Controller Class Initialized
INFO - 2016-02-17 07:35:36 --> Model Class Initialized
INFO - 2016-02-17 07:35:36 --> Model Class Initialized
INFO - 2016-02-17 07:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:35:36 --> Pagination Class Initialized
INFO - 2016-02-17 07:35:36 --> Helper loaded: text_helper
INFO - 2016-02-17 07:35:36 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:35:36 --> Form Validation Class Initialized
INFO - 2016-02-17 10:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:35:36 --> Final output sent to browser
DEBUG - 2016-02-17 10:35:36 --> Total execution time: 1.1401
INFO - 2016-02-17 07:36:18 --> Config Class Initialized
INFO - 2016-02-17 07:36:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:36:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:36:18 --> Utf8 Class Initialized
INFO - 2016-02-17 07:36:18 --> URI Class Initialized
DEBUG - 2016-02-17 07:36:18 --> No URI present. Default controller set.
INFO - 2016-02-17 07:36:18 --> Router Class Initialized
INFO - 2016-02-17 07:36:18 --> Output Class Initialized
INFO - 2016-02-17 07:36:18 --> Security Class Initialized
DEBUG - 2016-02-17 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:36:18 --> Input Class Initialized
INFO - 2016-02-17 07:36:18 --> Language Class Initialized
INFO - 2016-02-17 07:36:18 --> Loader Class Initialized
INFO - 2016-02-17 07:36:18 --> Helper loaded: url_helper
INFO - 2016-02-17 07:36:18 --> Helper loaded: file_helper
INFO - 2016-02-17 07:36:18 --> Helper loaded: date_helper
INFO - 2016-02-17 07:36:18 --> Helper loaded: form_helper
INFO - 2016-02-17 07:36:18 --> Database Driver Class Initialized
INFO - 2016-02-17 07:36:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:36:19 --> Controller Class Initialized
INFO - 2016-02-17 07:36:19 --> Model Class Initialized
INFO - 2016-02-17 07:36:19 --> Model Class Initialized
INFO - 2016-02-17 07:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:36:19 --> Pagination Class Initialized
INFO - 2016-02-17 07:36:19 --> Helper loaded: text_helper
INFO - 2016-02-17 07:36:19 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:36:19 --> Final output sent to browser
DEBUG - 2016-02-17 10:36:19 --> Total execution time: 1.1116
INFO - 2016-02-17 07:36:24 --> Config Class Initialized
INFO - 2016-02-17 07:36:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:36:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:36:24 --> Utf8 Class Initialized
INFO - 2016-02-17 07:36:24 --> URI Class Initialized
INFO - 2016-02-17 07:36:24 --> Router Class Initialized
INFO - 2016-02-17 07:36:24 --> Output Class Initialized
INFO - 2016-02-17 07:36:24 --> Security Class Initialized
DEBUG - 2016-02-17 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:36:24 --> Input Class Initialized
INFO - 2016-02-17 07:36:24 --> Language Class Initialized
INFO - 2016-02-17 07:36:24 --> Loader Class Initialized
INFO - 2016-02-17 07:36:24 --> Helper loaded: url_helper
INFO - 2016-02-17 07:36:24 --> Helper loaded: file_helper
INFO - 2016-02-17 07:36:24 --> Helper loaded: date_helper
INFO - 2016-02-17 07:36:24 --> Helper loaded: form_helper
INFO - 2016-02-17 07:36:24 --> Database Driver Class Initialized
INFO - 2016-02-17 07:36:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:36:25 --> Controller Class Initialized
INFO - 2016-02-17 07:36:25 --> Model Class Initialized
INFO - 2016-02-17 07:36:25 --> Model Class Initialized
INFO - 2016-02-17 07:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:36:25 --> Pagination Class Initialized
INFO - 2016-02-17 07:36:25 --> Helper loaded: text_helper
INFO - 2016-02-17 07:36:25 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:36:25 --> Form Validation Class Initialized
INFO - 2016-02-17 10:36:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:36:25 --> Final output sent to browser
DEBUG - 2016-02-17 10:36:25 --> Total execution time: 1.1245
INFO - 2016-02-17 07:36:38 --> Config Class Initialized
INFO - 2016-02-17 07:36:38 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:36:38 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:36:38 --> Utf8 Class Initialized
INFO - 2016-02-17 07:36:38 --> URI Class Initialized
DEBUG - 2016-02-17 07:36:38 --> No URI present. Default controller set.
INFO - 2016-02-17 07:36:38 --> Router Class Initialized
INFO - 2016-02-17 07:36:38 --> Output Class Initialized
INFO - 2016-02-17 07:36:38 --> Security Class Initialized
DEBUG - 2016-02-17 07:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:36:38 --> Input Class Initialized
INFO - 2016-02-17 07:36:38 --> Language Class Initialized
INFO - 2016-02-17 07:36:38 --> Loader Class Initialized
INFO - 2016-02-17 07:36:38 --> Helper loaded: url_helper
INFO - 2016-02-17 07:36:38 --> Helper loaded: file_helper
INFO - 2016-02-17 07:36:38 --> Helper loaded: date_helper
INFO - 2016-02-17 07:36:38 --> Helper loaded: form_helper
INFO - 2016-02-17 07:36:38 --> Database Driver Class Initialized
INFO - 2016-02-17 07:36:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:36:39 --> Controller Class Initialized
INFO - 2016-02-17 07:36:39 --> Model Class Initialized
INFO - 2016-02-17 07:36:39 --> Model Class Initialized
INFO - 2016-02-17 07:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:36:39 --> Pagination Class Initialized
INFO - 2016-02-17 07:36:39 --> Helper loaded: text_helper
INFO - 2016-02-17 07:36:39 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:36:39 --> Final output sent to browser
DEBUG - 2016-02-17 10:36:39 --> Total execution time: 1.1014
INFO - 2016-02-17 07:36:45 --> Config Class Initialized
INFO - 2016-02-17 07:36:45 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:36:45 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:36:45 --> Utf8 Class Initialized
INFO - 2016-02-17 07:36:45 --> URI Class Initialized
INFO - 2016-02-17 07:36:45 --> Router Class Initialized
INFO - 2016-02-17 07:36:45 --> Output Class Initialized
INFO - 2016-02-17 07:36:45 --> Security Class Initialized
DEBUG - 2016-02-17 07:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:36:45 --> Input Class Initialized
INFO - 2016-02-17 07:36:45 --> Language Class Initialized
INFO - 2016-02-17 07:36:45 --> Loader Class Initialized
INFO - 2016-02-17 07:36:45 --> Helper loaded: url_helper
INFO - 2016-02-17 07:36:45 --> Helper loaded: file_helper
INFO - 2016-02-17 07:36:45 --> Helper loaded: date_helper
INFO - 2016-02-17 07:36:45 --> Helper loaded: form_helper
INFO - 2016-02-17 07:36:45 --> Database Driver Class Initialized
INFO - 2016-02-17 07:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:36:46 --> Controller Class Initialized
INFO - 2016-02-17 07:36:46 --> Model Class Initialized
INFO - 2016-02-17 07:36:46 --> Model Class Initialized
INFO - 2016-02-17 07:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:36:46 --> Pagination Class Initialized
INFO - 2016-02-17 07:36:46 --> Helper loaded: text_helper
INFO - 2016-02-17 07:36:46 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:36:46 --> Form Validation Class Initialized
INFO - 2016-02-17 10:36:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:36:46 --> Final output sent to browser
DEBUG - 2016-02-17 10:36:46 --> Total execution time: 1.1303
INFO - 2016-02-17 07:37:16 --> Config Class Initialized
INFO - 2016-02-17 07:37:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:37:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:37:16 --> Utf8 Class Initialized
INFO - 2016-02-17 07:37:16 --> URI Class Initialized
DEBUG - 2016-02-17 07:37:16 --> No URI present. Default controller set.
INFO - 2016-02-17 07:37:16 --> Router Class Initialized
INFO - 2016-02-17 07:37:16 --> Output Class Initialized
INFO - 2016-02-17 07:37:16 --> Security Class Initialized
DEBUG - 2016-02-17 07:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:37:16 --> Input Class Initialized
INFO - 2016-02-17 07:37:16 --> Language Class Initialized
INFO - 2016-02-17 07:37:16 --> Loader Class Initialized
INFO - 2016-02-17 07:37:16 --> Helper loaded: url_helper
INFO - 2016-02-17 07:37:16 --> Helper loaded: file_helper
INFO - 2016-02-17 07:37:16 --> Helper loaded: date_helper
INFO - 2016-02-17 07:37:16 --> Helper loaded: form_helper
INFO - 2016-02-17 07:37:16 --> Database Driver Class Initialized
INFO - 2016-02-17 07:37:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:37:17 --> Controller Class Initialized
INFO - 2016-02-17 07:37:17 --> Model Class Initialized
INFO - 2016-02-17 07:37:17 --> Model Class Initialized
INFO - 2016-02-17 07:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:37:18 --> Pagination Class Initialized
INFO - 2016-02-17 07:37:18 --> Helper loaded: text_helper
INFO - 2016-02-17 07:37:18 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:37:18 --> Final output sent to browser
DEBUG - 2016-02-17 10:37:18 --> Total execution time: 1.1522
INFO - 2016-02-17 07:37:22 --> Config Class Initialized
INFO - 2016-02-17 07:37:22 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:37:22 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:37:22 --> Utf8 Class Initialized
INFO - 2016-02-17 07:37:22 --> URI Class Initialized
INFO - 2016-02-17 07:37:22 --> Router Class Initialized
INFO - 2016-02-17 07:37:22 --> Output Class Initialized
INFO - 2016-02-17 07:37:22 --> Security Class Initialized
DEBUG - 2016-02-17 07:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:37:22 --> Input Class Initialized
INFO - 2016-02-17 07:37:22 --> Language Class Initialized
INFO - 2016-02-17 07:37:22 --> Loader Class Initialized
INFO - 2016-02-17 07:37:22 --> Helper loaded: url_helper
INFO - 2016-02-17 07:37:23 --> Helper loaded: file_helper
INFO - 2016-02-17 07:37:23 --> Helper loaded: date_helper
INFO - 2016-02-17 07:37:23 --> Helper loaded: form_helper
INFO - 2016-02-17 07:37:23 --> Database Driver Class Initialized
INFO - 2016-02-17 07:37:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:37:24 --> Controller Class Initialized
INFO - 2016-02-17 07:37:24 --> Model Class Initialized
INFO - 2016-02-17 07:37:24 --> Model Class Initialized
INFO - 2016-02-17 07:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:37:24 --> Pagination Class Initialized
INFO - 2016-02-17 07:37:24 --> Helper loaded: text_helper
INFO - 2016-02-17 07:37:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:37:24 --> Form Validation Class Initialized
INFO - 2016-02-17 10:37:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:37:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:37:24 --> Final output sent to browser
DEBUG - 2016-02-17 10:37:24 --> Total execution time: 1.1212
INFO - 2016-02-17 07:38:02 --> Config Class Initialized
INFO - 2016-02-17 07:38:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:38:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:38:02 --> Utf8 Class Initialized
INFO - 2016-02-17 07:38:02 --> URI Class Initialized
DEBUG - 2016-02-17 07:38:02 --> No URI present. Default controller set.
INFO - 2016-02-17 07:38:02 --> Router Class Initialized
INFO - 2016-02-17 07:38:02 --> Output Class Initialized
INFO - 2016-02-17 07:38:02 --> Security Class Initialized
DEBUG - 2016-02-17 07:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:38:02 --> Input Class Initialized
INFO - 2016-02-17 07:38:02 --> Language Class Initialized
INFO - 2016-02-17 07:38:02 --> Loader Class Initialized
INFO - 2016-02-17 07:38:02 --> Helper loaded: url_helper
INFO - 2016-02-17 07:38:02 --> Helper loaded: file_helper
INFO - 2016-02-17 07:38:02 --> Helper loaded: date_helper
INFO - 2016-02-17 07:38:02 --> Helper loaded: form_helper
INFO - 2016-02-17 07:38:02 --> Database Driver Class Initialized
INFO - 2016-02-17 07:38:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:38:03 --> Controller Class Initialized
INFO - 2016-02-17 07:38:03 --> Model Class Initialized
INFO - 2016-02-17 07:38:03 --> Model Class Initialized
INFO - 2016-02-17 07:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:38:03 --> Pagination Class Initialized
INFO - 2016-02-17 07:38:03 --> Helper loaded: text_helper
INFO - 2016-02-17 07:38:03 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:38:03 --> Final output sent to browser
DEBUG - 2016-02-17 10:38:03 --> Total execution time: 1.1412
INFO - 2016-02-17 07:38:05 --> Config Class Initialized
INFO - 2016-02-17 07:38:05 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:38:05 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:38:05 --> Utf8 Class Initialized
INFO - 2016-02-17 07:38:05 --> URI Class Initialized
INFO - 2016-02-17 07:38:05 --> Router Class Initialized
INFO - 2016-02-17 07:38:05 --> Output Class Initialized
INFO - 2016-02-17 07:38:05 --> Security Class Initialized
DEBUG - 2016-02-17 07:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:38:05 --> Input Class Initialized
INFO - 2016-02-17 07:38:05 --> Language Class Initialized
INFO - 2016-02-17 07:38:05 --> Loader Class Initialized
INFO - 2016-02-17 07:38:05 --> Helper loaded: url_helper
INFO - 2016-02-17 07:38:05 --> Helper loaded: file_helper
INFO - 2016-02-17 07:38:05 --> Helper loaded: date_helper
INFO - 2016-02-17 07:38:05 --> Helper loaded: form_helper
INFO - 2016-02-17 07:38:05 --> Database Driver Class Initialized
INFO - 2016-02-17 07:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:38:06 --> Controller Class Initialized
INFO - 2016-02-17 07:38:06 --> Model Class Initialized
INFO - 2016-02-17 07:38:06 --> Model Class Initialized
INFO - 2016-02-17 07:38:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:38:06 --> Pagination Class Initialized
INFO - 2016-02-17 07:38:06 --> Helper loaded: text_helper
INFO - 2016-02-17 07:38:06 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:38:06 --> Form Validation Class Initialized
INFO - 2016-02-17 10:38:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:38:06 --> Final output sent to browser
DEBUG - 2016-02-17 10:38:06 --> Total execution time: 1.1230
INFO - 2016-02-17 07:38:10 --> Config Class Initialized
INFO - 2016-02-17 07:38:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:38:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:38:10 --> Utf8 Class Initialized
INFO - 2016-02-17 07:38:10 --> URI Class Initialized
INFO - 2016-02-17 07:38:10 --> Router Class Initialized
INFO - 2016-02-17 07:38:10 --> Output Class Initialized
INFO - 2016-02-17 07:38:10 --> Security Class Initialized
DEBUG - 2016-02-17 07:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:38:10 --> Input Class Initialized
INFO - 2016-02-17 07:38:10 --> Language Class Initialized
INFO - 2016-02-17 07:38:10 --> Loader Class Initialized
INFO - 2016-02-17 07:38:10 --> Helper loaded: url_helper
INFO - 2016-02-17 07:38:10 --> Helper loaded: file_helper
INFO - 2016-02-17 07:38:10 --> Helper loaded: date_helper
INFO - 2016-02-17 07:38:10 --> Helper loaded: form_helper
INFO - 2016-02-17 07:38:10 --> Database Driver Class Initialized
INFO - 2016-02-17 07:38:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:38:11 --> Controller Class Initialized
INFO - 2016-02-17 07:38:11 --> Model Class Initialized
INFO - 2016-02-17 07:38:11 --> Model Class Initialized
INFO - 2016-02-17 07:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:38:11 --> Pagination Class Initialized
INFO - 2016-02-17 07:38:11 --> Helper loaded: text_helper
INFO - 2016-02-17 07:38:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:38:11 --> Form Validation Class Initialized
INFO - 2016-02-17 10:38:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:38:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:38:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:38:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 10:38:11 --> Final output sent to browser
DEBUG - 2016-02-17 10:38:11 --> Total execution time: 1.0980
INFO - 2016-02-17 07:38:14 --> Config Class Initialized
INFO - 2016-02-17 07:38:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:38:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:38:14 --> Utf8 Class Initialized
INFO - 2016-02-17 07:38:14 --> URI Class Initialized
INFO - 2016-02-17 07:38:14 --> Router Class Initialized
INFO - 2016-02-17 07:38:14 --> Output Class Initialized
INFO - 2016-02-17 07:38:14 --> Security Class Initialized
DEBUG - 2016-02-17 07:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:38:14 --> Input Class Initialized
INFO - 2016-02-17 07:38:14 --> Language Class Initialized
INFO - 2016-02-17 07:38:14 --> Loader Class Initialized
INFO - 2016-02-17 07:38:14 --> Helper loaded: url_helper
INFO - 2016-02-17 07:38:14 --> Helper loaded: file_helper
INFO - 2016-02-17 07:38:14 --> Helper loaded: date_helper
INFO - 2016-02-17 07:38:14 --> Helper loaded: form_helper
INFO - 2016-02-17 07:38:14 --> Database Driver Class Initialized
INFO - 2016-02-17 07:38:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:38:15 --> Controller Class Initialized
INFO - 2016-02-17 07:38:15 --> Model Class Initialized
INFO - 2016-02-17 07:38:15 --> Model Class Initialized
INFO - 2016-02-17 07:38:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:38:15 --> Pagination Class Initialized
INFO - 2016-02-17 07:38:15 --> Helper loaded: text_helper
INFO - 2016-02-17 07:38:15 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:38:15 --> Form Validation Class Initialized
INFO - 2016-02-17 10:38:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:38:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:38:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:38:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:38:15 --> Final output sent to browser
DEBUG - 2016-02-17 10:38:15 --> Total execution time: 1.1453
INFO - 2016-02-17 07:39:04 --> Config Class Initialized
INFO - 2016-02-17 07:39:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:39:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:39:04 --> Utf8 Class Initialized
INFO - 2016-02-17 07:39:04 --> URI Class Initialized
DEBUG - 2016-02-17 07:39:04 --> No URI present. Default controller set.
INFO - 2016-02-17 07:39:04 --> Router Class Initialized
INFO - 2016-02-17 07:39:04 --> Output Class Initialized
INFO - 2016-02-17 07:39:04 --> Security Class Initialized
DEBUG - 2016-02-17 07:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:39:04 --> Input Class Initialized
INFO - 2016-02-17 07:39:04 --> Language Class Initialized
INFO - 2016-02-17 07:39:04 --> Loader Class Initialized
INFO - 2016-02-17 07:39:04 --> Helper loaded: url_helper
INFO - 2016-02-17 07:39:04 --> Helper loaded: file_helper
INFO - 2016-02-17 07:39:04 --> Helper loaded: date_helper
INFO - 2016-02-17 07:39:04 --> Helper loaded: form_helper
INFO - 2016-02-17 07:39:04 --> Database Driver Class Initialized
INFO - 2016-02-17 07:39:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:39:05 --> Controller Class Initialized
INFO - 2016-02-17 07:39:05 --> Model Class Initialized
INFO - 2016-02-17 07:39:05 --> Model Class Initialized
INFO - 2016-02-17 07:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:39:05 --> Pagination Class Initialized
INFO - 2016-02-17 07:39:05 --> Helper loaded: text_helper
INFO - 2016-02-17 07:39:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:39:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:39:05 --> Final output sent to browser
DEBUG - 2016-02-17 10:39:05 --> Total execution time: 1.1529
INFO - 2016-02-17 07:39:09 --> Config Class Initialized
INFO - 2016-02-17 07:39:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:39:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:39:09 --> Utf8 Class Initialized
INFO - 2016-02-17 07:39:09 --> URI Class Initialized
INFO - 2016-02-17 07:39:09 --> Router Class Initialized
INFO - 2016-02-17 07:39:09 --> Output Class Initialized
INFO - 2016-02-17 07:39:09 --> Security Class Initialized
DEBUG - 2016-02-17 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:39:09 --> Input Class Initialized
INFO - 2016-02-17 07:39:09 --> Language Class Initialized
INFO - 2016-02-17 07:39:09 --> Loader Class Initialized
INFO - 2016-02-17 07:39:09 --> Helper loaded: url_helper
INFO - 2016-02-17 07:39:09 --> Helper loaded: file_helper
INFO - 2016-02-17 07:39:09 --> Helper loaded: date_helper
INFO - 2016-02-17 07:39:09 --> Helper loaded: form_helper
INFO - 2016-02-17 07:39:09 --> Database Driver Class Initialized
INFO - 2016-02-17 07:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:39:10 --> Controller Class Initialized
INFO - 2016-02-17 07:39:11 --> Model Class Initialized
INFO - 2016-02-17 07:39:11 --> Model Class Initialized
INFO - 2016-02-17 07:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:39:11 --> Pagination Class Initialized
INFO - 2016-02-17 07:39:11 --> Helper loaded: text_helper
INFO - 2016-02-17 07:39:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:39:11 --> Form Validation Class Initialized
INFO - 2016-02-17 10:39:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:39:11 --> Final output sent to browser
DEBUG - 2016-02-17 10:39:11 --> Total execution time: 1.1405
INFO - 2016-02-17 07:39:21 --> Config Class Initialized
INFO - 2016-02-17 07:39:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:39:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:39:21 --> Utf8 Class Initialized
INFO - 2016-02-17 07:39:21 --> URI Class Initialized
INFO - 2016-02-17 07:39:21 --> Router Class Initialized
INFO - 2016-02-17 07:39:21 --> Output Class Initialized
INFO - 2016-02-17 07:39:21 --> Security Class Initialized
DEBUG - 2016-02-17 07:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:39:21 --> Input Class Initialized
INFO - 2016-02-17 07:39:21 --> Language Class Initialized
INFO - 2016-02-17 07:39:21 --> Loader Class Initialized
INFO - 2016-02-17 07:39:21 --> Helper loaded: url_helper
INFO - 2016-02-17 07:39:21 --> Helper loaded: file_helper
INFO - 2016-02-17 07:39:21 --> Helper loaded: date_helper
INFO - 2016-02-17 07:39:21 --> Helper loaded: form_helper
INFO - 2016-02-17 07:39:21 --> Database Driver Class Initialized
INFO - 2016-02-17 07:39:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:39:22 --> Controller Class Initialized
INFO - 2016-02-17 07:39:22 --> Model Class Initialized
INFO - 2016-02-17 07:39:22 --> Model Class Initialized
INFO - 2016-02-17 07:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:39:22 --> Pagination Class Initialized
INFO - 2016-02-17 07:39:22 --> Helper loaded: text_helper
INFO - 2016-02-17 07:39:22 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:39:22 --> Form Validation Class Initialized
INFO - 2016-02-17 10:39:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:39:22 --> Final output sent to browser
DEBUG - 2016-02-17 10:39:22 --> Total execution time: 1.1656
INFO - 2016-02-17 07:39:33 --> Config Class Initialized
INFO - 2016-02-17 07:39:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:39:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:39:33 --> Utf8 Class Initialized
INFO - 2016-02-17 07:39:33 --> URI Class Initialized
INFO - 2016-02-17 07:39:33 --> Router Class Initialized
INFO - 2016-02-17 07:39:33 --> Output Class Initialized
INFO - 2016-02-17 07:39:33 --> Security Class Initialized
DEBUG - 2016-02-17 07:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:39:33 --> Input Class Initialized
INFO - 2016-02-17 07:39:33 --> Language Class Initialized
INFO - 2016-02-17 07:39:33 --> Loader Class Initialized
INFO - 2016-02-17 07:39:33 --> Helper loaded: url_helper
INFO - 2016-02-17 07:39:33 --> Helper loaded: file_helper
INFO - 2016-02-17 07:39:33 --> Helper loaded: date_helper
INFO - 2016-02-17 07:39:33 --> Helper loaded: form_helper
INFO - 2016-02-17 07:39:33 --> Database Driver Class Initialized
INFO - 2016-02-17 07:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:39:34 --> Controller Class Initialized
INFO - 2016-02-17 07:39:34 --> Model Class Initialized
INFO - 2016-02-17 07:39:34 --> Model Class Initialized
INFO - 2016-02-17 07:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:39:34 --> Pagination Class Initialized
INFO - 2016-02-17 07:39:34 --> Helper loaded: text_helper
INFO - 2016-02-17 07:39:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:39:34 --> Form Validation Class Initialized
INFO - 2016-02-17 10:39:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:39:34 --> Final output sent to browser
DEBUG - 2016-02-17 10:39:34 --> Total execution time: 1.1214
INFO - 2016-02-17 07:41:11 --> Config Class Initialized
INFO - 2016-02-17 07:41:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:41:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:41:11 --> Utf8 Class Initialized
INFO - 2016-02-17 07:41:11 --> URI Class Initialized
DEBUG - 2016-02-17 07:41:11 --> No URI present. Default controller set.
INFO - 2016-02-17 07:41:11 --> Router Class Initialized
INFO - 2016-02-17 07:41:11 --> Output Class Initialized
INFO - 2016-02-17 07:41:11 --> Security Class Initialized
DEBUG - 2016-02-17 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:41:11 --> Input Class Initialized
INFO - 2016-02-17 07:41:11 --> Language Class Initialized
INFO - 2016-02-17 07:41:11 --> Loader Class Initialized
INFO - 2016-02-17 07:41:11 --> Helper loaded: url_helper
INFO - 2016-02-17 07:41:11 --> Helper loaded: file_helper
INFO - 2016-02-17 07:41:11 --> Helper loaded: date_helper
INFO - 2016-02-17 07:41:11 --> Helper loaded: form_helper
INFO - 2016-02-17 07:41:11 --> Database Driver Class Initialized
INFO - 2016-02-17 07:41:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:41:12 --> Controller Class Initialized
INFO - 2016-02-17 07:41:12 --> Model Class Initialized
INFO - 2016-02-17 07:41:12 --> Model Class Initialized
INFO - 2016-02-17 07:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:41:12 --> Pagination Class Initialized
INFO - 2016-02-17 07:41:12 --> Helper loaded: text_helper
INFO - 2016-02-17 07:41:12 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:41:12 --> Final output sent to browser
DEBUG - 2016-02-17 10:41:12 --> Total execution time: 1.1060
INFO - 2016-02-17 07:41:31 --> Config Class Initialized
INFO - 2016-02-17 07:41:31 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:41:31 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:41:31 --> Utf8 Class Initialized
INFO - 2016-02-17 07:41:31 --> URI Class Initialized
DEBUG - 2016-02-17 07:41:31 --> No URI present. Default controller set.
INFO - 2016-02-17 07:41:31 --> Router Class Initialized
INFO - 2016-02-17 07:41:31 --> Output Class Initialized
INFO - 2016-02-17 07:41:31 --> Security Class Initialized
DEBUG - 2016-02-17 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:41:31 --> Input Class Initialized
INFO - 2016-02-17 07:41:31 --> Language Class Initialized
INFO - 2016-02-17 07:41:31 --> Loader Class Initialized
INFO - 2016-02-17 07:41:31 --> Helper loaded: url_helper
INFO - 2016-02-17 07:41:31 --> Helper loaded: file_helper
INFO - 2016-02-17 07:41:31 --> Helper loaded: date_helper
INFO - 2016-02-17 07:41:31 --> Helper loaded: form_helper
INFO - 2016-02-17 07:41:31 --> Database Driver Class Initialized
INFO - 2016-02-17 07:41:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:41:32 --> Controller Class Initialized
INFO - 2016-02-17 07:41:32 --> Model Class Initialized
INFO - 2016-02-17 07:41:32 --> Model Class Initialized
INFO - 2016-02-17 07:41:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:41:32 --> Pagination Class Initialized
INFO - 2016-02-17 07:41:32 --> Helper loaded: text_helper
INFO - 2016-02-17 07:41:32 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:41:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:41:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:41:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:41:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:41:32 --> Final output sent to browser
DEBUG - 2016-02-17 10:41:32 --> Total execution time: 1.1180
INFO - 2016-02-17 07:42:36 --> Config Class Initialized
INFO - 2016-02-17 07:42:36 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:42:36 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:42:36 --> Utf8 Class Initialized
INFO - 2016-02-17 07:42:36 --> URI Class Initialized
INFO - 2016-02-17 07:42:36 --> Router Class Initialized
INFO - 2016-02-17 07:42:36 --> Output Class Initialized
INFO - 2016-02-17 07:42:36 --> Security Class Initialized
DEBUG - 2016-02-17 07:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:42:36 --> Input Class Initialized
INFO - 2016-02-17 07:42:36 --> Language Class Initialized
INFO - 2016-02-17 07:42:36 --> Loader Class Initialized
INFO - 2016-02-17 07:42:36 --> Helper loaded: url_helper
INFO - 2016-02-17 07:42:36 --> Helper loaded: file_helper
INFO - 2016-02-17 07:42:36 --> Helper loaded: date_helper
INFO - 2016-02-17 07:42:36 --> Helper loaded: form_helper
INFO - 2016-02-17 07:42:36 --> Database Driver Class Initialized
INFO - 2016-02-17 07:42:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:42:37 --> Controller Class Initialized
INFO - 2016-02-17 07:42:37 --> Model Class Initialized
INFO - 2016-02-17 07:42:37 --> Model Class Initialized
INFO - 2016-02-17 07:42:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:42:37 --> Pagination Class Initialized
INFO - 2016-02-17 07:42:37 --> Helper loaded: text_helper
INFO - 2016-02-17 07:42:37 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:42:37 --> Form Validation Class Initialized
INFO - 2016-02-17 10:42:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:42:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:42:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:42:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 10:42:37 --> Final output sent to browser
DEBUG - 2016-02-17 10:42:37 --> Total execution time: 1.1270
INFO - 2016-02-17 07:43:33 --> Config Class Initialized
INFO - 2016-02-17 07:43:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:43:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:43:33 --> Utf8 Class Initialized
INFO - 2016-02-17 07:43:33 --> URI Class Initialized
DEBUG - 2016-02-17 07:43:33 --> No URI present. Default controller set.
INFO - 2016-02-17 07:43:33 --> Router Class Initialized
INFO - 2016-02-17 07:43:33 --> Output Class Initialized
INFO - 2016-02-17 07:43:33 --> Security Class Initialized
DEBUG - 2016-02-17 07:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:43:33 --> Input Class Initialized
INFO - 2016-02-17 07:43:33 --> Language Class Initialized
INFO - 2016-02-17 07:43:33 --> Loader Class Initialized
INFO - 2016-02-17 07:43:33 --> Helper loaded: url_helper
INFO - 2016-02-17 07:43:33 --> Helper loaded: file_helper
INFO - 2016-02-17 07:43:33 --> Helper loaded: date_helper
INFO - 2016-02-17 07:43:33 --> Helper loaded: form_helper
INFO - 2016-02-17 07:43:33 --> Database Driver Class Initialized
INFO - 2016-02-17 07:43:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:43:34 --> Controller Class Initialized
INFO - 2016-02-17 07:43:34 --> Model Class Initialized
INFO - 2016-02-17 07:43:34 --> Model Class Initialized
INFO - 2016-02-17 07:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:43:34 --> Pagination Class Initialized
INFO - 2016-02-17 07:43:34 --> Helper loaded: text_helper
INFO - 2016-02-17 07:43:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:43:34 --> Final output sent to browser
DEBUG - 2016-02-17 10:43:34 --> Total execution time: 1.0859
INFO - 2016-02-17 07:43:49 --> Config Class Initialized
INFO - 2016-02-17 07:43:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:43:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:43:49 --> Utf8 Class Initialized
INFO - 2016-02-17 07:43:49 --> URI Class Initialized
DEBUG - 2016-02-17 07:43:49 --> No URI present. Default controller set.
INFO - 2016-02-17 07:43:49 --> Router Class Initialized
INFO - 2016-02-17 07:43:49 --> Output Class Initialized
INFO - 2016-02-17 07:43:49 --> Security Class Initialized
DEBUG - 2016-02-17 07:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:43:49 --> Input Class Initialized
INFO - 2016-02-17 07:43:49 --> Language Class Initialized
INFO - 2016-02-17 07:43:49 --> Loader Class Initialized
INFO - 2016-02-17 07:43:49 --> Helper loaded: url_helper
INFO - 2016-02-17 07:43:49 --> Helper loaded: file_helper
INFO - 2016-02-17 07:43:49 --> Helper loaded: date_helper
INFO - 2016-02-17 07:43:49 --> Helper loaded: form_helper
INFO - 2016-02-17 07:43:49 --> Database Driver Class Initialized
INFO - 2016-02-17 07:43:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:43:50 --> Controller Class Initialized
INFO - 2016-02-17 07:43:50 --> Model Class Initialized
INFO - 2016-02-17 07:43:50 --> Model Class Initialized
INFO - 2016-02-17 07:43:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:43:50 --> Pagination Class Initialized
INFO - 2016-02-17 07:43:50 --> Helper loaded: text_helper
INFO - 2016-02-17 07:43:50 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:43:50 --> Final output sent to browser
DEBUG - 2016-02-17 10:43:50 --> Total execution time: 1.1169
INFO - 2016-02-17 07:45:04 --> Config Class Initialized
INFO - 2016-02-17 07:45:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:45:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:45:04 --> Utf8 Class Initialized
INFO - 2016-02-17 07:45:04 --> URI Class Initialized
DEBUG - 2016-02-17 07:45:04 --> No URI present. Default controller set.
INFO - 2016-02-17 07:45:04 --> Router Class Initialized
INFO - 2016-02-17 07:45:04 --> Output Class Initialized
INFO - 2016-02-17 07:45:04 --> Security Class Initialized
DEBUG - 2016-02-17 07:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:45:04 --> Input Class Initialized
INFO - 2016-02-17 07:45:04 --> Language Class Initialized
INFO - 2016-02-17 07:45:04 --> Loader Class Initialized
INFO - 2016-02-17 07:45:04 --> Helper loaded: url_helper
INFO - 2016-02-17 07:45:04 --> Helper loaded: file_helper
INFO - 2016-02-17 07:45:04 --> Helper loaded: date_helper
INFO - 2016-02-17 07:45:04 --> Helper loaded: form_helper
INFO - 2016-02-17 07:45:04 --> Database Driver Class Initialized
INFO - 2016-02-17 07:45:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:45:05 --> Controller Class Initialized
INFO - 2016-02-17 07:45:05 --> Model Class Initialized
INFO - 2016-02-17 07:45:05 --> Model Class Initialized
INFO - 2016-02-17 07:45:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:45:05 --> Pagination Class Initialized
INFO - 2016-02-17 07:45:05 --> Helper loaded: text_helper
INFO - 2016-02-17 07:45:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:45:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:45:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:45:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:45:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:45:05 --> Final output sent to browser
DEBUG - 2016-02-17 10:45:05 --> Total execution time: 1.1308
INFO - 2016-02-17 07:45:20 --> Config Class Initialized
INFO - 2016-02-17 07:45:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:45:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:45:20 --> Utf8 Class Initialized
INFO - 2016-02-17 07:45:20 --> URI Class Initialized
DEBUG - 2016-02-17 07:45:20 --> No URI present. Default controller set.
INFO - 2016-02-17 07:45:20 --> Router Class Initialized
INFO - 2016-02-17 07:45:20 --> Output Class Initialized
INFO - 2016-02-17 07:45:20 --> Security Class Initialized
DEBUG - 2016-02-17 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:45:20 --> Input Class Initialized
INFO - 2016-02-17 07:45:20 --> Language Class Initialized
INFO - 2016-02-17 07:45:20 --> Loader Class Initialized
INFO - 2016-02-17 07:45:20 --> Helper loaded: url_helper
INFO - 2016-02-17 07:45:20 --> Helper loaded: file_helper
INFO - 2016-02-17 07:45:20 --> Helper loaded: date_helper
INFO - 2016-02-17 07:45:20 --> Helper loaded: form_helper
INFO - 2016-02-17 07:45:20 --> Database Driver Class Initialized
INFO - 2016-02-17 07:45:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:45:21 --> Controller Class Initialized
INFO - 2016-02-17 07:45:21 --> Model Class Initialized
INFO - 2016-02-17 07:45:21 --> Model Class Initialized
INFO - 2016-02-17 07:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:45:21 --> Pagination Class Initialized
INFO - 2016-02-17 07:45:21 --> Helper loaded: text_helper
INFO - 2016-02-17 07:45:21 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:45:21 --> Final output sent to browser
DEBUG - 2016-02-17 10:45:21 --> Total execution time: 1.1329
INFO - 2016-02-17 07:47:04 --> Config Class Initialized
INFO - 2016-02-17 07:47:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:47:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:47:04 --> Utf8 Class Initialized
INFO - 2016-02-17 07:47:04 --> URI Class Initialized
DEBUG - 2016-02-17 07:47:04 --> No URI present. Default controller set.
INFO - 2016-02-17 07:47:04 --> Router Class Initialized
INFO - 2016-02-17 07:47:04 --> Output Class Initialized
INFO - 2016-02-17 07:47:04 --> Security Class Initialized
DEBUG - 2016-02-17 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:47:04 --> Input Class Initialized
INFO - 2016-02-17 07:47:04 --> Language Class Initialized
INFO - 2016-02-17 07:47:04 --> Loader Class Initialized
INFO - 2016-02-17 07:47:04 --> Helper loaded: url_helper
INFO - 2016-02-17 07:47:04 --> Helper loaded: file_helper
INFO - 2016-02-17 07:47:04 --> Helper loaded: date_helper
INFO - 2016-02-17 07:47:04 --> Helper loaded: form_helper
INFO - 2016-02-17 07:47:04 --> Database Driver Class Initialized
INFO - 2016-02-17 07:47:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:47:05 --> Controller Class Initialized
INFO - 2016-02-17 07:47:05 --> Model Class Initialized
INFO - 2016-02-17 07:47:05 --> Model Class Initialized
INFO - 2016-02-17 07:47:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:47:05 --> Pagination Class Initialized
INFO - 2016-02-17 07:47:05 --> Helper loaded: text_helper
INFO - 2016-02-17 07:47:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:47:05 --> Final output sent to browser
DEBUG - 2016-02-17 10:47:05 --> Total execution time: 1.1505
INFO - 2016-02-17 07:54:28 --> Config Class Initialized
INFO - 2016-02-17 07:54:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:54:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:54:28 --> Utf8 Class Initialized
INFO - 2016-02-17 07:54:28 --> URI Class Initialized
INFO - 2016-02-17 07:54:28 --> Router Class Initialized
INFO - 2016-02-17 07:54:28 --> Output Class Initialized
INFO - 2016-02-17 07:54:28 --> Security Class Initialized
DEBUG - 2016-02-17 07:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:54:28 --> Input Class Initialized
INFO - 2016-02-17 07:54:28 --> Language Class Initialized
INFO - 2016-02-17 07:54:28 --> Loader Class Initialized
INFO - 2016-02-17 07:54:28 --> Helper loaded: url_helper
INFO - 2016-02-17 07:54:28 --> Helper loaded: file_helper
INFO - 2016-02-17 07:54:28 --> Helper loaded: date_helper
INFO - 2016-02-17 07:54:28 --> Helper loaded: form_helper
INFO - 2016-02-17 07:54:28 --> Database Driver Class Initialized
INFO - 2016-02-17 07:54:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:54:29 --> Controller Class Initialized
INFO - 2016-02-17 07:54:29 --> Model Class Initialized
INFO - 2016-02-17 07:54:29 --> Model Class Initialized
INFO - 2016-02-17 07:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:54:29 --> Pagination Class Initialized
INFO - 2016-02-17 07:54:29 --> Helper loaded: text_helper
INFO - 2016-02-17 07:54:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:54:29 --> Final output sent to browser
DEBUG - 2016-02-17 10:54:29 --> Total execution time: 1.1422
INFO - 2016-02-17 07:54:30 --> Config Class Initialized
INFO - 2016-02-17 07:54:30 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:54:30 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:54:30 --> Utf8 Class Initialized
INFO - 2016-02-17 07:54:30 --> URI Class Initialized
INFO - 2016-02-17 07:54:30 --> Router Class Initialized
INFO - 2016-02-17 07:54:30 --> Output Class Initialized
INFO - 2016-02-17 07:54:30 --> Security Class Initialized
DEBUG - 2016-02-17 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:54:30 --> Input Class Initialized
INFO - 2016-02-17 07:54:30 --> Language Class Initialized
INFO - 2016-02-17 07:54:30 --> Loader Class Initialized
INFO - 2016-02-17 07:54:30 --> Helper loaded: url_helper
INFO - 2016-02-17 07:54:30 --> Helper loaded: file_helper
INFO - 2016-02-17 07:54:30 --> Helper loaded: date_helper
INFO - 2016-02-17 07:54:30 --> Helper loaded: form_helper
INFO - 2016-02-17 07:54:30 --> Database Driver Class Initialized
INFO - 2016-02-17 07:54:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:54:31 --> Controller Class Initialized
INFO - 2016-02-17 07:54:31 --> Model Class Initialized
INFO - 2016-02-17 07:54:31 --> Model Class Initialized
INFO - 2016-02-17 07:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:54:31 --> Pagination Class Initialized
INFO - 2016-02-17 07:54:31 --> Helper loaded: text_helper
INFO - 2016-02-17 07:54:31 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:54:32 --> Final output sent to browser
DEBUG - 2016-02-17 10:54:32 --> Total execution time: 1.1495
INFO - 2016-02-17 07:54:54 --> Config Class Initialized
INFO - 2016-02-17 07:54:54 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:54:54 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:54:54 --> Utf8 Class Initialized
INFO - 2016-02-17 07:54:54 --> URI Class Initialized
INFO - 2016-02-17 07:54:54 --> Router Class Initialized
INFO - 2016-02-17 07:54:54 --> Output Class Initialized
INFO - 2016-02-17 07:54:54 --> Security Class Initialized
DEBUG - 2016-02-17 07:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:54:54 --> Input Class Initialized
INFO - 2016-02-17 07:54:54 --> Language Class Initialized
INFO - 2016-02-17 07:54:54 --> Loader Class Initialized
INFO - 2016-02-17 07:54:54 --> Helper loaded: url_helper
INFO - 2016-02-17 07:54:54 --> Helper loaded: file_helper
INFO - 2016-02-17 07:54:54 --> Helper loaded: date_helper
INFO - 2016-02-17 07:54:54 --> Helper loaded: form_helper
INFO - 2016-02-17 07:54:54 --> Database Driver Class Initialized
INFO - 2016-02-17 07:54:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:54:55 --> Controller Class Initialized
INFO - 2016-02-17 07:54:55 --> Model Class Initialized
INFO - 2016-02-17 07:54:55 --> Model Class Initialized
INFO - 2016-02-17 07:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:54:55 --> Pagination Class Initialized
INFO - 2016-02-17 07:54:55 --> Helper loaded: text_helper
INFO - 2016-02-17 07:54:55 --> Helper loaded: cookie_helper
INFO - 2016-02-17 07:54:57 --> Config Class Initialized
INFO - 2016-02-17 07:54:57 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:54:57 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:54:57 --> Utf8 Class Initialized
INFO - 2016-02-17 07:54:57 --> URI Class Initialized
DEBUG - 2016-02-17 07:54:57 --> No URI present. Default controller set.
INFO - 2016-02-17 07:54:57 --> Router Class Initialized
INFO - 2016-02-17 07:54:57 --> Output Class Initialized
INFO - 2016-02-17 07:54:57 --> Security Class Initialized
DEBUG - 2016-02-17 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:54:57 --> Input Class Initialized
INFO - 2016-02-17 07:54:57 --> Language Class Initialized
INFO - 2016-02-17 07:54:57 --> Loader Class Initialized
INFO - 2016-02-17 07:54:57 --> Helper loaded: url_helper
INFO - 2016-02-17 07:54:57 --> Helper loaded: file_helper
INFO - 2016-02-17 07:54:57 --> Helper loaded: date_helper
INFO - 2016-02-17 07:54:57 --> Helper loaded: form_helper
INFO - 2016-02-17 07:54:57 --> Database Driver Class Initialized
INFO - 2016-02-17 07:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:54:58 --> Controller Class Initialized
INFO - 2016-02-17 07:54:58 --> Model Class Initialized
INFO - 2016-02-17 07:54:58 --> Model Class Initialized
INFO - 2016-02-17 07:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:54:58 --> Pagination Class Initialized
INFO - 2016-02-17 07:54:58 --> Helper loaded: text_helper
INFO - 2016-02-17 07:54:58 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:54:58 --> Final output sent to browser
DEBUG - 2016-02-17 10:54:58 --> Total execution time: 1.2739
INFO - 2016-02-17 07:55:00 --> Config Class Initialized
INFO - 2016-02-17 07:55:00 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:55:00 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:55:00 --> Utf8 Class Initialized
INFO - 2016-02-17 07:55:00 --> URI Class Initialized
INFO - 2016-02-17 07:55:00 --> Router Class Initialized
INFO - 2016-02-17 07:55:00 --> Output Class Initialized
INFO - 2016-02-17 07:55:00 --> Security Class Initialized
DEBUG - 2016-02-17 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:55:00 --> Input Class Initialized
INFO - 2016-02-17 07:55:00 --> Language Class Initialized
INFO - 2016-02-17 07:55:00 --> Loader Class Initialized
INFO - 2016-02-17 07:55:00 --> Helper loaded: url_helper
INFO - 2016-02-17 07:55:00 --> Helper loaded: file_helper
INFO - 2016-02-17 07:55:00 --> Helper loaded: date_helper
INFO - 2016-02-17 07:55:00 --> Helper loaded: form_helper
INFO - 2016-02-17 07:55:00 --> Database Driver Class Initialized
INFO - 2016-02-17 07:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:55:01 --> Controller Class Initialized
INFO - 2016-02-17 07:55:01 --> Model Class Initialized
INFO - 2016-02-17 07:55:01 --> Model Class Initialized
INFO - 2016-02-17 07:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:55:01 --> Pagination Class Initialized
INFO - 2016-02-17 07:55:01 --> Helper loaded: text_helper
INFO - 2016-02-17 07:55:01 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:55:01 --> Final output sent to browser
DEBUG - 2016-02-17 10:55:01 --> Total execution time: 1.1752
INFO - 2016-02-17 07:55:03 --> Config Class Initialized
INFO - 2016-02-17 07:55:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:55:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:55:03 --> Utf8 Class Initialized
INFO - 2016-02-17 07:55:03 --> URI Class Initialized
DEBUG - 2016-02-17 07:55:03 --> No URI present. Default controller set.
INFO - 2016-02-17 07:55:03 --> Router Class Initialized
INFO - 2016-02-17 07:55:03 --> Output Class Initialized
INFO - 2016-02-17 07:55:03 --> Security Class Initialized
DEBUG - 2016-02-17 07:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:55:03 --> Input Class Initialized
INFO - 2016-02-17 07:55:03 --> Language Class Initialized
INFO - 2016-02-17 07:55:03 --> Loader Class Initialized
INFO - 2016-02-17 07:55:03 --> Helper loaded: url_helper
INFO - 2016-02-17 07:55:03 --> Helper loaded: file_helper
INFO - 2016-02-17 07:55:03 --> Helper loaded: date_helper
INFO - 2016-02-17 07:55:03 --> Helper loaded: form_helper
INFO - 2016-02-17 07:55:03 --> Database Driver Class Initialized
INFO - 2016-02-17 07:55:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:55:04 --> Controller Class Initialized
INFO - 2016-02-17 07:55:04 --> Model Class Initialized
INFO - 2016-02-17 07:55:04 --> Model Class Initialized
INFO - 2016-02-17 07:55:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:55:04 --> Pagination Class Initialized
INFO - 2016-02-17 07:55:04 --> Helper loaded: text_helper
INFO - 2016-02-17 07:55:04 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 10:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:55:04 --> Final output sent to browser
DEBUG - 2016-02-17 10:55:04 --> Total execution time: 1.1105
INFO - 2016-02-17 07:55:06 --> Config Class Initialized
INFO - 2016-02-17 07:55:06 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:55:06 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:55:06 --> Utf8 Class Initialized
INFO - 2016-02-17 07:55:06 --> URI Class Initialized
INFO - 2016-02-17 07:55:06 --> Router Class Initialized
INFO - 2016-02-17 07:55:06 --> Output Class Initialized
INFO - 2016-02-17 07:55:06 --> Security Class Initialized
DEBUG - 2016-02-17 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:55:06 --> Input Class Initialized
INFO - 2016-02-17 07:55:06 --> Language Class Initialized
INFO - 2016-02-17 07:55:06 --> Loader Class Initialized
INFO - 2016-02-17 07:55:06 --> Helper loaded: url_helper
INFO - 2016-02-17 07:55:06 --> Helper loaded: file_helper
INFO - 2016-02-17 07:55:06 --> Helper loaded: date_helper
INFO - 2016-02-17 07:55:06 --> Helper loaded: form_helper
INFO - 2016-02-17 07:55:06 --> Database Driver Class Initialized
INFO - 2016-02-17 07:55:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:55:07 --> Controller Class Initialized
INFO - 2016-02-17 07:55:07 --> Model Class Initialized
INFO - 2016-02-17 07:55:07 --> Model Class Initialized
INFO - 2016-02-17 07:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:55:07 --> Pagination Class Initialized
INFO - 2016-02-17 07:55:07 --> Helper loaded: text_helper
INFO - 2016-02-17 07:55:07 --> Helper loaded: cookie_helper
INFO - 2016-02-17 10:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 10:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:55:07 --> Final output sent to browser
DEBUG - 2016-02-17 10:55:07 --> Total execution time: 1.1231
INFO - 2016-02-17 07:55:09 --> Config Class Initialized
INFO - 2016-02-17 07:55:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 07:55:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 07:55:09 --> Utf8 Class Initialized
INFO - 2016-02-17 07:55:09 --> URI Class Initialized
INFO - 2016-02-17 07:55:09 --> Router Class Initialized
INFO - 2016-02-17 07:55:09 --> Output Class Initialized
INFO - 2016-02-17 07:55:09 --> Security Class Initialized
DEBUG - 2016-02-17 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 07:55:09 --> Input Class Initialized
INFO - 2016-02-17 07:55:09 --> Language Class Initialized
INFO - 2016-02-17 07:55:09 --> Loader Class Initialized
INFO - 2016-02-17 07:55:09 --> Helper loaded: url_helper
INFO - 2016-02-17 07:55:09 --> Helper loaded: file_helper
INFO - 2016-02-17 07:55:09 --> Helper loaded: date_helper
INFO - 2016-02-17 07:55:09 --> Helper loaded: form_helper
INFO - 2016-02-17 07:55:09 --> Database Driver Class Initialized
INFO - 2016-02-17 07:55:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 07:55:10 --> Controller Class Initialized
INFO - 2016-02-17 07:55:10 --> Model Class Initialized
INFO - 2016-02-17 07:55:10 --> Model Class Initialized
INFO - 2016-02-17 07:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 07:55:10 --> Pagination Class Initialized
INFO - 2016-02-17 07:55:10 --> Helper loaded: text_helper
INFO - 2016-02-17 07:55:10 --> Helper loaded: cookie_helper
INFO - 2016-02-17 08:17:27 --> Config Class Initialized
INFO - 2016-02-17 08:17:27 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:17:27 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:17:27 --> Utf8 Class Initialized
INFO - 2016-02-17 08:17:27 --> URI Class Initialized
INFO - 2016-02-17 08:17:27 --> Router Class Initialized
INFO - 2016-02-17 08:17:27 --> Output Class Initialized
INFO - 2016-02-17 08:17:27 --> Security Class Initialized
DEBUG - 2016-02-17 08:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:17:27 --> Input Class Initialized
INFO - 2016-02-17 08:17:27 --> Language Class Initialized
INFO - 2016-02-17 08:17:27 --> Loader Class Initialized
INFO - 2016-02-17 08:17:27 --> Helper loaded: url_helper
INFO - 2016-02-17 08:17:27 --> Helper loaded: file_helper
INFO - 2016-02-17 08:17:27 --> Helper loaded: date_helper
INFO - 2016-02-17 08:17:27 --> Helper loaded: form_helper
INFO - 2016-02-17 08:17:27 --> Database Driver Class Initialized
INFO - 2016-02-17 08:17:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:17:28 --> Controller Class Initialized
INFO - 2016-02-17 08:17:28 --> Model Class Initialized
INFO - 2016-02-17 08:17:28 --> Model Class Initialized
INFO - 2016-02-17 08:17:28 --> Form Validation Class Initialized
INFO - 2016-02-17 08:17:28 --> Helper loaded: text_helper
INFO - 2016-02-17 08:17:28 --> Config Class Initialized
INFO - 2016-02-17 08:17:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:17:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:17:28 --> Utf8 Class Initialized
INFO - 2016-02-17 08:17:28 --> URI Class Initialized
INFO - 2016-02-17 08:17:28 --> Router Class Initialized
INFO - 2016-02-17 08:17:28 --> Output Class Initialized
INFO - 2016-02-17 08:17:28 --> Security Class Initialized
DEBUG - 2016-02-17 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:17:28 --> Input Class Initialized
INFO - 2016-02-17 08:17:28 --> Language Class Initialized
INFO - 2016-02-17 08:17:28 --> Loader Class Initialized
INFO - 2016-02-17 08:17:28 --> Helper loaded: url_helper
INFO - 2016-02-17 08:17:28 --> Helper loaded: file_helper
INFO - 2016-02-17 08:17:28 --> Helper loaded: date_helper
INFO - 2016-02-17 08:17:28 --> Helper loaded: form_helper
INFO - 2016-02-17 08:17:28 --> Database Driver Class Initialized
INFO - 2016-02-17 08:17:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:17:29 --> Controller Class Initialized
INFO - 2016-02-17 08:17:29 --> Model Class Initialized
INFO - 2016-02-17 08:17:29 --> Model Class Initialized
INFO - 2016-02-17 08:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:17:29 --> Pagination Class Initialized
INFO - 2016-02-17 08:17:29 --> Helper loaded: text_helper
INFO - 2016-02-17 08:17:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:17:29 --> Final output sent to browser
DEBUG - 2016-02-17 11:17:29 --> Total execution time: 1.1077
INFO - 2016-02-17 08:17:31 --> Config Class Initialized
INFO - 2016-02-17 08:17:31 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:17:31 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:17:31 --> Utf8 Class Initialized
INFO - 2016-02-17 08:17:31 --> URI Class Initialized
INFO - 2016-02-17 08:17:31 --> Router Class Initialized
INFO - 2016-02-17 08:17:31 --> Output Class Initialized
INFO - 2016-02-17 08:17:31 --> Security Class Initialized
DEBUG - 2016-02-17 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:17:31 --> Input Class Initialized
INFO - 2016-02-17 08:17:31 --> Language Class Initialized
INFO - 2016-02-17 08:17:31 --> Loader Class Initialized
INFO - 2016-02-17 08:17:31 --> Helper loaded: url_helper
INFO - 2016-02-17 08:17:31 --> Helper loaded: file_helper
INFO - 2016-02-17 08:17:31 --> Helper loaded: date_helper
INFO - 2016-02-17 08:17:31 --> Helper loaded: form_helper
INFO - 2016-02-17 08:17:31 --> Database Driver Class Initialized
INFO - 2016-02-17 08:17:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:17:32 --> Controller Class Initialized
INFO - 2016-02-17 08:17:32 --> Model Class Initialized
INFO - 2016-02-17 08:17:32 --> Model Class Initialized
INFO - 2016-02-17 08:17:32 --> Form Validation Class Initialized
INFO - 2016-02-17 08:17:32 --> Helper loaded: text_helper
INFO - 2016-02-17 08:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:17:32 --> Model Class Initialized
INFO - 2016-02-17 08:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:17:32 --> Final output sent to browser
DEBUG - 2016-02-17 08:17:32 --> Total execution time: 1.1051
INFO - 2016-02-17 08:18:11 --> Config Class Initialized
INFO - 2016-02-17 08:18:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:18:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:18:11 --> Utf8 Class Initialized
INFO - 2016-02-17 08:18:11 --> URI Class Initialized
INFO - 2016-02-17 08:18:11 --> Router Class Initialized
INFO - 2016-02-17 08:18:11 --> Output Class Initialized
INFO - 2016-02-17 08:18:11 --> Security Class Initialized
DEBUG - 2016-02-17 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:18:11 --> Input Class Initialized
INFO - 2016-02-17 08:18:11 --> Language Class Initialized
INFO - 2016-02-17 08:18:11 --> Loader Class Initialized
INFO - 2016-02-17 08:18:11 --> Helper loaded: url_helper
INFO - 2016-02-17 08:18:11 --> Helper loaded: file_helper
INFO - 2016-02-17 08:18:11 --> Helper loaded: date_helper
INFO - 2016-02-17 08:18:11 --> Helper loaded: form_helper
INFO - 2016-02-17 08:18:11 --> Database Driver Class Initialized
INFO - 2016-02-17 08:18:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:18:12 --> Controller Class Initialized
INFO - 2016-02-17 08:18:12 --> Model Class Initialized
INFO - 2016-02-17 08:18:12 --> Model Class Initialized
INFO - 2016-02-17 08:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:18:12 --> Pagination Class Initialized
INFO - 2016-02-17 08:18:12 --> Helper loaded: text_helper
INFO - 2016-02-17 08:18:12 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:18:12 --> Final output sent to browser
DEBUG - 2016-02-17 11:18:12 --> Total execution time: 1.1796
INFO - 2016-02-17 08:18:26 --> Config Class Initialized
INFO - 2016-02-17 08:18:26 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:18:26 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:18:26 --> Utf8 Class Initialized
INFO - 2016-02-17 08:18:26 --> URI Class Initialized
INFO - 2016-02-17 08:18:26 --> Router Class Initialized
INFO - 2016-02-17 08:18:26 --> Output Class Initialized
INFO - 2016-02-17 08:18:26 --> Security Class Initialized
DEBUG - 2016-02-17 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:18:26 --> Input Class Initialized
INFO - 2016-02-17 08:18:26 --> Language Class Initialized
INFO - 2016-02-17 08:18:26 --> Loader Class Initialized
INFO - 2016-02-17 08:18:26 --> Helper loaded: url_helper
INFO - 2016-02-17 08:18:26 --> Helper loaded: file_helper
INFO - 2016-02-17 08:18:26 --> Helper loaded: date_helper
INFO - 2016-02-17 08:18:26 --> Helper loaded: form_helper
INFO - 2016-02-17 08:18:26 --> Database Driver Class Initialized
INFO - 2016-02-17 08:18:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:18:27 --> Controller Class Initialized
INFO - 2016-02-17 08:18:27 --> Model Class Initialized
INFO - 2016-02-17 08:18:27 --> Model Class Initialized
INFO - 2016-02-17 08:18:27 --> Form Validation Class Initialized
INFO - 2016-02-17 08:18:27 --> Helper loaded: text_helper
INFO - 2016-02-17 08:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:18:27 --> Model Class Initialized
INFO - 2016-02-17 08:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:18:27 --> Final output sent to browser
DEBUG - 2016-02-17 08:18:27 --> Total execution time: 1.1183
INFO - 2016-02-17 08:34:25 --> Config Class Initialized
INFO - 2016-02-17 08:34:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:34:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:34:25 --> Utf8 Class Initialized
INFO - 2016-02-17 08:34:25 --> URI Class Initialized
DEBUG - 2016-02-17 08:34:25 --> No URI present. Default controller set.
INFO - 2016-02-17 08:34:25 --> Router Class Initialized
INFO - 2016-02-17 08:34:25 --> Output Class Initialized
INFO - 2016-02-17 08:34:25 --> Security Class Initialized
DEBUG - 2016-02-17 08:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:34:25 --> Input Class Initialized
INFO - 2016-02-17 08:34:25 --> Language Class Initialized
INFO - 2016-02-17 08:34:25 --> Loader Class Initialized
INFO - 2016-02-17 08:34:25 --> Helper loaded: url_helper
INFO - 2016-02-17 08:34:25 --> Helper loaded: file_helper
INFO - 2016-02-17 08:34:25 --> Helper loaded: date_helper
INFO - 2016-02-17 08:34:25 --> Helper loaded: form_helper
INFO - 2016-02-17 08:34:25 --> Database Driver Class Initialized
INFO - 2016-02-17 08:34:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:34:26 --> Controller Class Initialized
INFO - 2016-02-17 08:34:26 --> Model Class Initialized
INFO - 2016-02-17 08:34:26 --> Model Class Initialized
INFO - 2016-02-17 08:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:34:26 --> Pagination Class Initialized
INFO - 2016-02-17 08:34:26 --> Helper loaded: text_helper
INFO - 2016-02-17 08:34:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:34:26 --> Final output sent to browser
DEBUG - 2016-02-17 11:34:26 --> Total execution time: 1.1481
INFO - 2016-02-17 08:34:27 --> Config Class Initialized
INFO - 2016-02-17 08:34:27 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:34:27 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:34:27 --> Utf8 Class Initialized
INFO - 2016-02-17 08:34:27 --> URI Class Initialized
INFO - 2016-02-17 08:34:27 --> Router Class Initialized
INFO - 2016-02-17 08:34:27 --> Output Class Initialized
INFO - 2016-02-17 08:34:27 --> Security Class Initialized
DEBUG - 2016-02-17 08:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:34:27 --> Input Class Initialized
INFO - 2016-02-17 08:34:27 --> Language Class Initialized
INFO - 2016-02-17 08:34:27 --> Loader Class Initialized
INFO - 2016-02-17 08:34:27 --> Helper loaded: url_helper
INFO - 2016-02-17 08:34:27 --> Helper loaded: file_helper
INFO - 2016-02-17 08:34:27 --> Helper loaded: date_helper
INFO - 2016-02-17 08:34:27 --> Helper loaded: form_helper
INFO - 2016-02-17 08:34:27 --> Database Driver Class Initialized
INFO - 2016-02-17 08:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:34:28 --> Controller Class Initialized
INFO - 2016-02-17 08:34:28 --> Model Class Initialized
INFO - 2016-02-17 08:34:28 --> Model Class Initialized
INFO - 2016-02-17 08:34:28 --> Form Validation Class Initialized
INFO - 2016-02-17 08:34:28 --> Helper loaded: text_helper
INFO - 2016-02-17 08:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:34:28 --> Model Class Initialized
INFO - 2016-02-17 08:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:34:28 --> Final output sent to browser
DEBUG - 2016-02-17 08:34:28 --> Total execution time: 1.1453
INFO - 2016-02-17 08:35:32 --> Config Class Initialized
INFO - 2016-02-17 08:35:32 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:32 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:32 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:32 --> URI Class Initialized
DEBUG - 2016-02-17 08:35:32 --> No URI present. Default controller set.
INFO - 2016-02-17 08:35:32 --> Router Class Initialized
INFO - 2016-02-17 08:35:32 --> Output Class Initialized
INFO - 2016-02-17 08:35:32 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:32 --> Input Class Initialized
INFO - 2016-02-17 08:35:32 --> Language Class Initialized
INFO - 2016-02-17 08:35:32 --> Loader Class Initialized
INFO - 2016-02-17 08:35:32 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:32 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:32 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:32 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:32 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:33 --> Controller Class Initialized
INFO - 2016-02-17 08:35:33 --> Model Class Initialized
INFO - 2016-02-17 08:35:33 --> Model Class Initialized
INFO - 2016-02-17 08:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:35:33 --> Pagination Class Initialized
INFO - 2016-02-17 08:35:33 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:33 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:35:33 --> Final output sent to browser
DEBUG - 2016-02-17 11:35:33 --> Total execution time: 1.1002
INFO - 2016-02-17 08:35:34 --> Config Class Initialized
INFO - 2016-02-17 08:35:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:34 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:34 --> URI Class Initialized
INFO - 2016-02-17 08:35:34 --> Router Class Initialized
INFO - 2016-02-17 08:35:34 --> Output Class Initialized
INFO - 2016-02-17 08:35:34 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:34 --> Input Class Initialized
INFO - 2016-02-17 08:35:34 --> Language Class Initialized
INFO - 2016-02-17 08:35:34 --> Loader Class Initialized
INFO - 2016-02-17 08:35:34 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:34 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:34 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:34 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:34 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:35 --> Controller Class Initialized
INFO - 2016-02-17 08:35:35 --> Model Class Initialized
INFO - 2016-02-17 08:35:35 --> Model Class Initialized
INFO - 2016-02-17 08:35:35 --> Form Validation Class Initialized
INFO - 2016-02-17 08:35:35 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:35:35 --> Model Class Initialized
INFO - 2016-02-17 08:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:35:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:35:35 --> Final output sent to browser
DEBUG - 2016-02-17 08:35:35 --> Total execution time: 1.1221
INFO - 2016-02-17 08:35:37 --> Config Class Initialized
INFO - 2016-02-17 08:35:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:37 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:37 --> URI Class Initialized
INFO - 2016-02-17 08:35:37 --> Router Class Initialized
INFO - 2016-02-17 08:35:37 --> Output Class Initialized
INFO - 2016-02-17 08:35:37 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:37 --> Input Class Initialized
INFO - 2016-02-17 08:35:37 --> Language Class Initialized
INFO - 2016-02-17 08:35:37 --> Loader Class Initialized
INFO - 2016-02-17 08:35:37 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:37 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:37 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:37 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:37 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:38 --> Controller Class Initialized
INFO - 2016-02-17 08:35:38 --> Model Class Initialized
INFO - 2016-02-17 08:35:38 --> Model Class Initialized
INFO - 2016-02-17 08:35:38 --> Form Validation Class Initialized
INFO - 2016-02-17 08:35:38 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 08:35:38 --> Final output sent to browser
DEBUG - 2016-02-17 08:35:38 --> Total execution time: 1.1060
INFO - 2016-02-17 08:35:42 --> Config Class Initialized
INFO - 2016-02-17 08:35:42 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:42 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:42 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:42 --> URI Class Initialized
INFO - 2016-02-17 08:35:42 --> Router Class Initialized
INFO - 2016-02-17 08:35:42 --> Output Class Initialized
INFO - 2016-02-17 08:35:42 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:42 --> Input Class Initialized
INFO - 2016-02-17 08:35:42 --> Language Class Initialized
INFO - 2016-02-17 08:35:42 --> Loader Class Initialized
INFO - 2016-02-17 08:35:42 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:42 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:42 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:42 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:42 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:43 --> Controller Class Initialized
INFO - 2016-02-17 08:35:43 --> Model Class Initialized
INFO - 2016-02-17 08:35:43 --> Model Class Initialized
INFO - 2016-02-17 08:35:43 --> Form Validation Class Initialized
INFO - 2016-02-17 08:35:43 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:35:43 --> Model Class Initialized
INFO - 2016-02-17 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:35:43 --> Final output sent to browser
DEBUG - 2016-02-17 08:35:43 --> Total execution time: 1.1008
INFO - 2016-02-17 08:35:45 --> Config Class Initialized
INFO - 2016-02-17 08:35:45 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:45 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:45 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:45 --> URI Class Initialized
INFO - 2016-02-17 08:35:45 --> Router Class Initialized
INFO - 2016-02-17 08:35:45 --> Output Class Initialized
INFO - 2016-02-17 08:35:45 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:45 --> Input Class Initialized
INFO - 2016-02-17 08:35:45 --> Language Class Initialized
INFO - 2016-02-17 08:35:45 --> Loader Class Initialized
INFO - 2016-02-17 08:35:45 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:45 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:45 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:45 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:45 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:46 --> Controller Class Initialized
INFO - 2016-02-17 08:35:46 --> Model Class Initialized
INFO - 2016-02-17 08:35:46 --> Model Class Initialized
INFO - 2016-02-17 08:35:46 --> Form Validation Class Initialized
INFO - 2016-02-17 08:35:46 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 08:35:46 --> Final output sent to browser
DEBUG - 2016-02-17 08:35:46 --> Total execution time: 1.1430
INFO - 2016-02-17 08:35:51 --> Config Class Initialized
INFO - 2016-02-17 08:35:51 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:35:51 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:35:51 --> Utf8 Class Initialized
INFO - 2016-02-17 08:35:51 --> URI Class Initialized
INFO - 2016-02-17 08:35:51 --> Router Class Initialized
INFO - 2016-02-17 08:35:51 --> Output Class Initialized
INFO - 2016-02-17 08:35:51 --> Security Class Initialized
DEBUG - 2016-02-17 08:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:35:51 --> Input Class Initialized
INFO - 2016-02-17 08:35:51 --> Language Class Initialized
INFO - 2016-02-17 08:35:51 --> Loader Class Initialized
INFO - 2016-02-17 08:35:51 --> Helper loaded: url_helper
INFO - 2016-02-17 08:35:51 --> Helper loaded: file_helper
INFO - 2016-02-17 08:35:51 --> Helper loaded: date_helper
INFO - 2016-02-17 08:35:51 --> Helper loaded: form_helper
INFO - 2016-02-17 08:35:51 --> Database Driver Class Initialized
INFO - 2016-02-17 08:35:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:35:52 --> Controller Class Initialized
INFO - 2016-02-17 08:35:52 --> Model Class Initialized
INFO - 2016-02-17 08:35:52 --> Model Class Initialized
INFO - 2016-02-17 08:35:52 --> Form Validation Class Initialized
INFO - 2016-02-17 08:35:52 --> Helper loaded: text_helper
INFO - 2016-02-17 08:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 08:35:52 --> Model Class Initialized
INFO - 2016-02-17 08:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 08:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 08:35:52 --> Final output sent to browser
DEBUG - 2016-02-17 08:35:52 --> Total execution time: 1.1015
INFO - 2016-02-17 08:58:02 --> Config Class Initialized
INFO - 2016-02-17 08:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:02 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:02 --> URI Class Initialized
INFO - 2016-02-17 08:58:02 --> Router Class Initialized
INFO - 2016-02-17 08:58:02 --> Output Class Initialized
INFO - 2016-02-17 08:58:02 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:02 --> Input Class Initialized
INFO - 2016-02-17 08:58:02 --> Language Class Initialized
INFO - 2016-02-17 08:58:02 --> Loader Class Initialized
INFO - 2016-02-17 08:58:02 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:02 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:02 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:02 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:02 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:03 --> Controller Class Initialized
INFO - 2016-02-17 08:58:03 --> Model Class Initialized
INFO - 2016-02-17 08:58:03 --> Model Class Initialized
INFO - 2016-02-17 08:58:03 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:03 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:03 --> Config Class Initialized
INFO - 2016-02-17 08:58:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:03 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:03 --> URI Class Initialized
INFO - 2016-02-17 08:58:03 --> Router Class Initialized
INFO - 2016-02-17 08:58:03 --> Output Class Initialized
INFO - 2016-02-17 08:58:03 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:03 --> Input Class Initialized
INFO - 2016-02-17 08:58:03 --> Language Class Initialized
INFO - 2016-02-17 08:58:03 --> Loader Class Initialized
INFO - 2016-02-17 08:58:03 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:03 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:03 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:03 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:03 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:04 --> Controller Class Initialized
INFO - 2016-02-17 08:58:04 --> Model Class Initialized
INFO - 2016-02-17 08:58:04 --> Model Class Initialized
INFO - 2016-02-17 08:58:04 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:04 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-17 08:58:04 --> Final output sent to browser
DEBUG - 2016-02-17 08:58:04 --> Total execution time: 1.1041
INFO - 2016-02-17 08:58:08 --> Config Class Initialized
INFO - 2016-02-17 08:58:08 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:08 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:08 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:08 --> URI Class Initialized
DEBUG - 2016-02-17 08:58:08 --> No URI present. Default controller set.
INFO - 2016-02-17 08:58:08 --> Router Class Initialized
INFO - 2016-02-17 08:58:08 --> Output Class Initialized
INFO - 2016-02-17 08:58:08 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:08 --> Input Class Initialized
INFO - 2016-02-17 08:58:08 --> Language Class Initialized
INFO - 2016-02-17 08:58:08 --> Loader Class Initialized
INFO - 2016-02-17 08:58:08 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:08 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:08 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:08 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:08 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:09 --> Controller Class Initialized
INFO - 2016-02-17 08:58:09 --> Model Class Initialized
INFO - 2016-02-17 08:58:09 --> Model Class Initialized
INFO - 2016-02-17 08:58:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:58:09 --> Pagination Class Initialized
INFO - 2016-02-17 08:58:09 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:09 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:58:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:58:09 --> Final output sent to browser
DEBUG - 2016-02-17 11:58:09 --> Total execution time: 1.0863
INFO - 2016-02-17 08:58:16 --> Config Class Initialized
INFO - 2016-02-17 08:58:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:16 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:16 --> URI Class Initialized
INFO - 2016-02-17 08:58:16 --> Router Class Initialized
INFO - 2016-02-17 08:58:16 --> Output Class Initialized
INFO - 2016-02-17 08:58:16 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:16 --> Input Class Initialized
INFO - 2016-02-17 08:58:16 --> Language Class Initialized
INFO - 2016-02-17 08:58:16 --> Loader Class Initialized
INFO - 2016-02-17 08:58:16 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:16 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:16 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:16 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:16 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:17 --> Controller Class Initialized
INFO - 2016-02-17 08:58:17 --> Model Class Initialized
INFO - 2016-02-17 08:58:17 --> Model Class Initialized
INFO - 2016-02-17 08:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 08:58:17 --> Pagination Class Initialized
INFO - 2016-02-17 08:58:17 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:17 --> Helper loaded: cookie_helper
INFO - 2016-02-17 08:58:17 --> Config Class Initialized
INFO - 2016-02-17 08:58:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:17 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:17 --> URI Class Initialized
INFO - 2016-02-17 08:58:17 --> Router Class Initialized
INFO - 2016-02-17 08:58:17 --> Output Class Initialized
INFO - 2016-02-17 08:58:17 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:17 --> Input Class Initialized
INFO - 2016-02-17 08:58:17 --> Language Class Initialized
INFO - 2016-02-17 08:58:17 --> Loader Class Initialized
INFO - 2016-02-17 08:58:17 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:17 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:17 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:17 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:17 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:18 --> Controller Class Initialized
INFO - 2016-02-17 08:58:18 --> Model Class Initialized
INFO - 2016-02-17 08:58:19 --> Model Class Initialized
INFO - 2016-02-17 08:58:19 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:19 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:58:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:58:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-17 08:58:19 --> Final output sent to browser
DEBUG - 2016-02-17 08:58:19 --> Total execution time: 1.1397
INFO - 2016-02-17 08:58:22 --> Config Class Initialized
INFO - 2016-02-17 08:58:22 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:22 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:22 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:22 --> URI Class Initialized
INFO - 2016-02-17 08:58:22 --> Router Class Initialized
INFO - 2016-02-17 08:58:22 --> Output Class Initialized
INFO - 2016-02-17 08:58:22 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:22 --> Input Class Initialized
INFO - 2016-02-17 08:58:22 --> Language Class Initialized
INFO - 2016-02-17 08:58:22 --> Loader Class Initialized
INFO - 2016-02-17 08:58:22 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:22 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:22 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:22 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:22 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:23 --> Controller Class Initialized
INFO - 2016-02-17 08:58:23 --> Model Class Initialized
INFO - 2016-02-17 08:58:23 --> Model Class Initialized
INFO - 2016-02-17 08:58:23 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:23 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:23 --> Config Class Initialized
INFO - 2016-02-17 08:58:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:23 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:24 --> URI Class Initialized
INFO - 2016-02-17 08:58:24 --> Router Class Initialized
INFO - 2016-02-17 08:58:24 --> Output Class Initialized
INFO - 2016-02-17 08:58:24 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:24 --> Input Class Initialized
INFO - 2016-02-17 08:58:24 --> Language Class Initialized
INFO - 2016-02-17 08:58:24 --> Loader Class Initialized
INFO - 2016-02-17 08:58:24 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:24 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:24 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:24 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:24 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:25 --> Controller Class Initialized
INFO - 2016-02-17 08:58:25 --> Model Class Initialized
INFO - 2016-02-17 08:58:25 --> Model Class Initialized
INFO - 2016-02-17 08:58:25 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:25 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-17 08:58:25 --> Final output sent to browser
DEBUG - 2016-02-17 08:58:25 --> Total execution time: 1.1198
INFO - 2016-02-17 08:58:29 --> Config Class Initialized
INFO - 2016-02-17 08:58:29 --> Hooks Class Initialized
DEBUG - 2016-02-17 08:58:29 --> UTF-8 Support Enabled
INFO - 2016-02-17 08:58:29 --> Utf8 Class Initialized
INFO - 2016-02-17 08:58:29 --> URI Class Initialized
INFO - 2016-02-17 08:58:29 --> Router Class Initialized
INFO - 2016-02-17 08:58:29 --> Output Class Initialized
INFO - 2016-02-17 08:58:29 --> Security Class Initialized
DEBUG - 2016-02-17 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 08:58:29 --> Input Class Initialized
INFO - 2016-02-17 08:58:29 --> Language Class Initialized
INFO - 2016-02-17 08:58:29 --> Loader Class Initialized
INFO - 2016-02-17 08:58:29 --> Helper loaded: url_helper
INFO - 2016-02-17 08:58:29 --> Helper loaded: file_helper
INFO - 2016-02-17 08:58:29 --> Helper loaded: date_helper
INFO - 2016-02-17 08:58:29 --> Helper loaded: form_helper
INFO - 2016-02-17 08:58:29 --> Database Driver Class Initialized
INFO - 2016-02-17 08:58:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 08:58:30 --> Controller Class Initialized
INFO - 2016-02-17 08:58:30 --> Model Class Initialized
INFO - 2016-02-17 08:58:30 --> Model Class Initialized
INFO - 2016-02-17 08:58:30 --> Form Validation Class Initialized
INFO - 2016-02-17 08:58:30 --> Helper loaded: text_helper
INFO - 2016-02-17 08:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 08:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 08:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-17 08:58:30 --> Final output sent to browser
DEBUG - 2016-02-17 08:58:30 --> Total execution time: 1.0806
INFO - 2016-02-17 09:03:53 --> Config Class Initialized
INFO - 2016-02-17 09:03:53 --> Hooks Class Initialized
DEBUG - 2016-02-17 09:03:53 --> UTF-8 Support Enabled
INFO - 2016-02-17 09:03:53 --> Utf8 Class Initialized
INFO - 2016-02-17 09:03:53 --> URI Class Initialized
DEBUG - 2016-02-17 09:03:53 --> No URI present. Default controller set.
INFO - 2016-02-17 09:03:53 --> Router Class Initialized
INFO - 2016-02-17 09:03:53 --> Output Class Initialized
INFO - 2016-02-17 09:03:53 --> Security Class Initialized
DEBUG - 2016-02-17 09:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 09:03:53 --> Input Class Initialized
INFO - 2016-02-17 09:03:53 --> Language Class Initialized
INFO - 2016-02-17 09:03:53 --> Loader Class Initialized
INFO - 2016-02-17 09:03:53 --> Helper loaded: url_helper
INFO - 2016-02-17 09:03:53 --> Helper loaded: file_helper
INFO - 2016-02-17 09:03:53 --> Helper loaded: date_helper
INFO - 2016-02-17 09:03:53 --> Helper loaded: form_helper
INFO - 2016-02-17 09:03:53 --> Database Driver Class Initialized
INFO - 2016-02-17 09:03:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 09:03:54 --> Controller Class Initialized
INFO - 2016-02-17 09:03:54 --> Model Class Initialized
INFO - 2016-02-17 09:03:54 --> Model Class Initialized
INFO - 2016-02-17 09:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 09:03:54 --> Pagination Class Initialized
INFO - 2016-02-17 09:03:54 --> Helper loaded: text_helper
INFO - 2016-02-17 09:03:54 --> Helper loaded: cookie_helper
INFO - 2016-02-17 12:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 12:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 12:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 12:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 12:03:54 --> Final output sent to browser
DEBUG - 2016-02-17 12:03:54 --> Total execution time: 1.1313
INFO - 2016-02-17 09:03:55 --> Config Class Initialized
INFO - 2016-02-17 09:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-17 09:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-17 09:03:55 --> Utf8 Class Initialized
INFO - 2016-02-17 09:03:55 --> URI Class Initialized
INFO - 2016-02-17 09:03:55 --> Router Class Initialized
INFO - 2016-02-17 09:03:55 --> Output Class Initialized
INFO - 2016-02-17 09:03:55 --> Security Class Initialized
DEBUG - 2016-02-17 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 09:03:55 --> Input Class Initialized
INFO - 2016-02-17 09:03:55 --> Language Class Initialized
INFO - 2016-02-17 09:03:55 --> Loader Class Initialized
INFO - 2016-02-17 09:03:55 --> Helper loaded: url_helper
INFO - 2016-02-17 09:03:55 --> Helper loaded: file_helper
INFO - 2016-02-17 09:03:55 --> Helper loaded: date_helper
INFO - 2016-02-17 09:03:55 --> Helper loaded: form_helper
INFO - 2016-02-17 09:03:55 --> Database Driver Class Initialized
INFO - 2016-02-17 09:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 09:03:56 --> Controller Class Initialized
INFO - 2016-02-17 09:03:56 --> Model Class Initialized
INFO - 2016-02-17 09:03:56 --> Model Class Initialized
INFO - 2016-02-17 09:03:56 --> Form Validation Class Initialized
INFO - 2016-02-17 09:03:56 --> Helper loaded: text_helper
INFO - 2016-02-17 09:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 09:03:57 --> Model Class Initialized
INFO - 2016-02-17 09:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:03:57 --> Final output sent to browser
DEBUG - 2016-02-17 09:03:57 --> Total execution time: 1.0840
INFO - 2016-02-17 09:03:58 --> Config Class Initialized
INFO - 2016-02-17 09:03:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 09:03:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 09:03:58 --> Utf8 Class Initialized
INFO - 2016-02-17 09:03:58 --> URI Class Initialized
INFO - 2016-02-17 09:03:59 --> Router Class Initialized
INFO - 2016-02-17 09:03:59 --> Output Class Initialized
INFO - 2016-02-17 09:03:59 --> Security Class Initialized
DEBUG - 2016-02-17 09:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 09:03:59 --> Input Class Initialized
INFO - 2016-02-17 09:03:59 --> Language Class Initialized
INFO - 2016-02-17 09:03:59 --> Loader Class Initialized
INFO - 2016-02-17 09:03:59 --> Helper loaded: url_helper
INFO - 2016-02-17 09:03:59 --> Helper loaded: file_helper
INFO - 2016-02-17 09:03:59 --> Helper loaded: date_helper
INFO - 2016-02-17 09:03:59 --> Helper loaded: form_helper
INFO - 2016-02-17 09:03:59 --> Database Driver Class Initialized
INFO - 2016-02-17 09:04:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 09:04:00 --> Controller Class Initialized
INFO - 2016-02-17 09:04:00 --> Model Class Initialized
INFO - 2016-02-17 09:04:00 --> Model Class Initialized
INFO - 2016-02-17 09:04:00 --> Form Validation Class Initialized
INFO - 2016-02-17 09:04:00 --> Helper loaded: text_helper
INFO - 2016-02-17 09:04:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 09:04:00 --> Final output sent to browser
DEBUG - 2016-02-17 09:04:00 --> Total execution time: 1.0940
INFO - 2016-02-17 09:04:01 --> Config Class Initialized
INFO - 2016-02-17 09:04:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 09:04:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 09:04:01 --> Utf8 Class Initialized
INFO - 2016-02-17 09:04:01 --> URI Class Initialized
INFO - 2016-02-17 09:04:01 --> Router Class Initialized
INFO - 2016-02-17 09:04:01 --> Output Class Initialized
INFO - 2016-02-17 09:04:01 --> Security Class Initialized
DEBUG - 2016-02-17 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 09:04:01 --> Input Class Initialized
INFO - 2016-02-17 09:04:01 --> Language Class Initialized
INFO - 2016-02-17 09:04:01 --> Loader Class Initialized
INFO - 2016-02-17 09:04:01 --> Helper loaded: url_helper
INFO - 2016-02-17 09:04:01 --> Helper loaded: file_helper
INFO - 2016-02-17 09:04:01 --> Helper loaded: date_helper
INFO - 2016-02-17 09:04:01 --> Helper loaded: form_helper
INFO - 2016-02-17 09:04:01 --> Database Driver Class Initialized
INFO - 2016-02-17 09:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 09:04:02 --> Controller Class Initialized
INFO - 2016-02-17 09:04:02 --> Model Class Initialized
INFO - 2016-02-17 09:04:02 --> Model Class Initialized
INFO - 2016-02-17 09:04:02 --> Form Validation Class Initialized
INFO - 2016-02-17 09:04:02 --> Helper loaded: text_helper
INFO - 2016-02-17 09:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 09:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 09:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 09:04:02 --> Model Class Initialized
INFO - 2016-02-17 09:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 09:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 09:04:02 --> Final output sent to browser
DEBUG - 2016-02-17 09:04:02 --> Total execution time: 1.1527
INFO - 2016-02-17 10:20:14 --> Config Class Initialized
INFO - 2016-02-17 10:20:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 10:20:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 10:20:14 --> Utf8 Class Initialized
INFO - 2016-02-17 10:20:14 --> URI Class Initialized
INFO - 2016-02-17 10:20:15 --> Router Class Initialized
INFO - 2016-02-17 10:20:15 --> Output Class Initialized
INFO - 2016-02-17 10:20:15 --> Security Class Initialized
DEBUG - 2016-02-17 10:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 10:20:15 --> Input Class Initialized
INFO - 2016-02-17 10:20:15 --> Language Class Initialized
INFO - 2016-02-17 10:20:15 --> Loader Class Initialized
INFO - 2016-02-17 10:20:15 --> Helper loaded: url_helper
INFO - 2016-02-17 10:20:15 --> Helper loaded: file_helper
INFO - 2016-02-17 10:20:15 --> Helper loaded: date_helper
INFO - 2016-02-17 10:20:15 --> Helper loaded: form_helper
INFO - 2016-02-17 10:20:15 --> Database Driver Class Initialized
INFO - 2016-02-17 10:20:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 10:20:16 --> Controller Class Initialized
INFO - 2016-02-17 10:20:16 --> Model Class Initialized
INFO - 2016-02-17 10:20:16 --> Model Class Initialized
INFO - 2016-02-17 10:20:16 --> Form Validation Class Initialized
INFO - 2016-02-17 10:20:16 --> Helper loaded: text_helper
INFO - 2016-02-17 10:20:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 10:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 10:20:16 --> Final output sent to browser
DEBUG - 2016-02-17 10:20:16 --> Total execution time: 1.2814
INFO - 2016-02-17 10:20:33 --> Config Class Initialized
INFO - 2016-02-17 10:20:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 10:20:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 10:20:33 --> Utf8 Class Initialized
INFO - 2016-02-17 10:20:33 --> URI Class Initialized
INFO - 2016-02-17 10:20:33 --> Router Class Initialized
INFO - 2016-02-17 10:20:33 --> Output Class Initialized
INFO - 2016-02-17 10:20:33 --> Security Class Initialized
DEBUG - 2016-02-17 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 10:20:33 --> Input Class Initialized
INFO - 2016-02-17 10:20:33 --> Language Class Initialized
INFO - 2016-02-17 10:20:33 --> Loader Class Initialized
INFO - 2016-02-17 10:20:33 --> Helper loaded: url_helper
INFO - 2016-02-17 10:20:33 --> Helper loaded: file_helper
INFO - 2016-02-17 10:20:33 --> Helper loaded: date_helper
INFO - 2016-02-17 10:20:33 --> Helper loaded: form_helper
INFO - 2016-02-17 10:20:33 --> Database Driver Class Initialized
INFO - 2016-02-17 10:20:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 10:20:34 --> Controller Class Initialized
INFO - 2016-02-17 10:20:34 --> Model Class Initialized
INFO - 2016-02-17 10:20:34 --> Model Class Initialized
INFO - 2016-02-17 10:20:34 --> Form Validation Class Initialized
INFO - 2016-02-17 10:20:34 --> Helper loaded: text_helper
INFO - 2016-02-17 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 10:20:34 --> Model Class Initialized
INFO - 2016-02-17 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:20:34 --> Final output sent to browser
DEBUG - 2016-02-17 10:20:34 --> Total execution time: 1.1324
INFO - 2016-02-17 10:34:28 --> Config Class Initialized
INFO - 2016-02-17 10:34:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 10:34:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 10:34:28 --> Utf8 Class Initialized
INFO - 2016-02-17 10:34:28 --> URI Class Initialized
DEBUG - 2016-02-17 10:34:28 --> No URI present. Default controller set.
INFO - 2016-02-17 10:34:28 --> Router Class Initialized
INFO - 2016-02-17 10:34:28 --> Output Class Initialized
INFO - 2016-02-17 10:34:28 --> Security Class Initialized
DEBUG - 2016-02-17 10:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 10:34:28 --> Input Class Initialized
INFO - 2016-02-17 10:34:28 --> Language Class Initialized
INFO - 2016-02-17 10:34:28 --> Loader Class Initialized
INFO - 2016-02-17 10:34:28 --> Helper loaded: url_helper
INFO - 2016-02-17 10:34:28 --> Helper loaded: file_helper
INFO - 2016-02-17 10:34:28 --> Helper loaded: date_helper
INFO - 2016-02-17 10:34:28 --> Helper loaded: form_helper
INFO - 2016-02-17 10:34:28 --> Database Driver Class Initialized
INFO - 2016-02-17 10:34:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 10:34:29 --> Controller Class Initialized
INFO - 2016-02-17 10:34:29 --> Model Class Initialized
INFO - 2016-02-17 10:34:29 --> Model Class Initialized
INFO - 2016-02-17 10:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 10:34:29 --> Pagination Class Initialized
INFO - 2016-02-17 10:34:29 --> Helper loaded: text_helper
INFO - 2016-02-17 10:34:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 13:34:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 13:34:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 13:34:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 13:34:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 13:34:30 --> Final output sent to browser
DEBUG - 2016-02-17 13:34:30 --> Total execution time: 1.1112
INFO - 2016-02-17 10:34:30 --> Config Class Initialized
INFO - 2016-02-17 10:34:30 --> Hooks Class Initialized
DEBUG - 2016-02-17 10:34:30 --> UTF-8 Support Enabled
INFO - 2016-02-17 10:34:30 --> Utf8 Class Initialized
INFO - 2016-02-17 10:34:30 --> URI Class Initialized
INFO - 2016-02-17 10:34:30 --> Router Class Initialized
INFO - 2016-02-17 10:34:30 --> Output Class Initialized
INFO - 2016-02-17 10:34:30 --> Security Class Initialized
DEBUG - 2016-02-17 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 10:34:30 --> Input Class Initialized
INFO - 2016-02-17 10:34:30 --> Language Class Initialized
INFO - 2016-02-17 10:34:30 --> Loader Class Initialized
INFO - 2016-02-17 10:34:30 --> Helper loaded: url_helper
INFO - 2016-02-17 10:34:30 --> Helper loaded: file_helper
INFO - 2016-02-17 10:34:30 --> Helper loaded: date_helper
INFO - 2016-02-17 10:34:30 --> Helper loaded: form_helper
INFO - 2016-02-17 10:34:30 --> Database Driver Class Initialized
INFO - 2016-02-17 10:34:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 10:34:31 --> Controller Class Initialized
INFO - 2016-02-17 10:34:31 --> Model Class Initialized
INFO - 2016-02-17 10:34:31 --> Model Class Initialized
INFO - 2016-02-17 10:34:31 --> Form Validation Class Initialized
INFO - 2016-02-17 10:34:31 --> Helper loaded: text_helper
INFO - 2016-02-17 10:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 10:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 10:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 10:34:31 --> Model Class Initialized
INFO - 2016-02-17 10:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 10:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 10:34:31 --> Final output sent to browser
DEBUG - 2016-02-17 10:34:31 --> Total execution time: 1.1226
INFO - 2016-02-17 11:00:14 --> Config Class Initialized
INFO - 2016-02-17 11:00:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:00:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:00:14 --> Utf8 Class Initialized
INFO - 2016-02-17 11:00:14 --> URI Class Initialized
DEBUG - 2016-02-17 11:00:14 --> No URI present. Default controller set.
INFO - 2016-02-17 11:00:14 --> Router Class Initialized
INFO - 2016-02-17 11:00:14 --> Output Class Initialized
INFO - 2016-02-17 11:00:14 --> Security Class Initialized
DEBUG - 2016-02-17 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:00:14 --> Input Class Initialized
INFO - 2016-02-17 11:00:14 --> Language Class Initialized
INFO - 2016-02-17 11:00:14 --> Loader Class Initialized
INFO - 2016-02-17 11:00:14 --> Helper loaded: url_helper
INFO - 2016-02-17 11:00:14 --> Helper loaded: file_helper
INFO - 2016-02-17 11:00:14 --> Helper loaded: date_helper
INFO - 2016-02-17 11:00:14 --> Helper loaded: form_helper
INFO - 2016-02-17 11:00:14 --> Database Driver Class Initialized
INFO - 2016-02-17 11:00:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:00:16 --> Controller Class Initialized
INFO - 2016-02-17 11:00:16 --> Model Class Initialized
INFO - 2016-02-17 11:00:16 --> Model Class Initialized
INFO - 2016-02-17 11:00:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:00:16 --> Pagination Class Initialized
INFO - 2016-02-17 11:00:16 --> Helper loaded: text_helper
INFO - 2016-02-17 11:00:16 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:00:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:00:16 --> Final output sent to browser
DEBUG - 2016-02-17 14:00:16 --> Total execution time: 1.6599
INFO - 2016-02-17 11:00:17 --> Config Class Initialized
INFO - 2016-02-17 11:00:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:00:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:00:17 --> Utf8 Class Initialized
INFO - 2016-02-17 11:00:17 --> URI Class Initialized
INFO - 2016-02-17 11:00:17 --> Router Class Initialized
INFO - 2016-02-17 11:00:17 --> Output Class Initialized
INFO - 2016-02-17 11:00:17 --> Security Class Initialized
DEBUG - 2016-02-17 11:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:00:17 --> Input Class Initialized
INFO - 2016-02-17 11:00:17 --> Language Class Initialized
INFO - 2016-02-17 11:00:17 --> Loader Class Initialized
INFO - 2016-02-17 11:00:17 --> Helper loaded: url_helper
INFO - 2016-02-17 11:00:17 --> Helper loaded: file_helper
INFO - 2016-02-17 11:00:17 --> Helper loaded: date_helper
INFO - 2016-02-17 11:00:17 --> Helper loaded: form_helper
INFO - 2016-02-17 11:00:17 --> Database Driver Class Initialized
INFO - 2016-02-17 11:00:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:00:18 --> Controller Class Initialized
INFO - 2016-02-17 11:00:18 --> Model Class Initialized
ERROR - 2016-02-17 11:00:18 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\user_model.php 57
INFO - 2016-02-17 11:00:34 --> Config Class Initialized
INFO - 2016-02-17 11:00:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:00:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:00:34 --> Utf8 Class Initialized
INFO - 2016-02-17 11:00:34 --> URI Class Initialized
DEBUG - 2016-02-17 11:00:34 --> No URI present. Default controller set.
INFO - 2016-02-17 11:00:34 --> Router Class Initialized
INFO - 2016-02-17 11:00:34 --> Output Class Initialized
INFO - 2016-02-17 11:00:34 --> Security Class Initialized
DEBUG - 2016-02-17 11:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:00:34 --> Input Class Initialized
INFO - 2016-02-17 11:00:34 --> Language Class Initialized
INFO - 2016-02-17 11:00:34 --> Loader Class Initialized
INFO - 2016-02-17 11:00:34 --> Helper loaded: url_helper
INFO - 2016-02-17 11:00:34 --> Helper loaded: file_helper
INFO - 2016-02-17 11:00:34 --> Helper loaded: date_helper
INFO - 2016-02-17 11:00:34 --> Helper loaded: form_helper
INFO - 2016-02-17 11:00:34 --> Database Driver Class Initialized
INFO - 2016-02-17 11:00:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:00:35 --> Controller Class Initialized
INFO - 2016-02-17 11:00:35 --> Model Class Initialized
INFO - 2016-02-17 11:00:35 --> Model Class Initialized
INFO - 2016-02-17 11:00:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:00:35 --> Pagination Class Initialized
INFO - 2016-02-17 11:00:35 --> Helper loaded: text_helper
INFO - 2016-02-17 11:00:35 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:00:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:00:35 --> Final output sent to browser
DEBUG - 2016-02-17 14:00:35 --> Total execution time: 1.1975
INFO - 2016-02-17 11:00:37 --> Config Class Initialized
INFO - 2016-02-17 11:00:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:00:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:00:37 --> Utf8 Class Initialized
INFO - 2016-02-17 11:00:37 --> URI Class Initialized
INFO - 2016-02-17 11:00:37 --> Router Class Initialized
INFO - 2016-02-17 11:00:37 --> Output Class Initialized
INFO - 2016-02-17 11:00:37 --> Security Class Initialized
DEBUG - 2016-02-17 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:00:37 --> Input Class Initialized
INFO - 2016-02-17 11:00:37 --> Language Class Initialized
INFO - 2016-02-17 11:00:37 --> Loader Class Initialized
INFO - 2016-02-17 11:00:37 --> Helper loaded: url_helper
INFO - 2016-02-17 11:00:37 --> Helper loaded: file_helper
INFO - 2016-02-17 11:00:37 --> Helper loaded: date_helper
INFO - 2016-02-17 11:00:37 --> Helper loaded: form_helper
INFO - 2016-02-17 11:00:37 --> Database Driver Class Initialized
INFO - 2016-02-17 11:00:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:00:38 --> Controller Class Initialized
INFO - 2016-02-17 11:00:38 --> Model Class Initialized
INFO - 2016-02-17 11:00:38 --> Model Class Initialized
INFO - 2016-02-17 11:00:38 --> Form Validation Class Initialized
INFO - 2016-02-17 11:00:38 --> Helper loaded: text_helper
INFO - 2016-02-17 11:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:00:38 --> Model Class Initialized
INFO - 2016-02-17 11:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:00:38 --> Final output sent to browser
DEBUG - 2016-02-17 11:00:38 --> Total execution time: 1.1710
INFO - 2016-02-17 11:00:57 --> Config Class Initialized
INFO - 2016-02-17 11:00:57 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:00:57 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:00:57 --> Utf8 Class Initialized
INFO - 2016-02-17 11:00:57 --> URI Class Initialized
INFO - 2016-02-17 11:00:57 --> Router Class Initialized
INFO - 2016-02-17 11:00:57 --> Output Class Initialized
INFO - 2016-02-17 11:00:57 --> Security Class Initialized
DEBUG - 2016-02-17 11:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:00:57 --> Input Class Initialized
INFO - 2016-02-17 11:00:57 --> Language Class Initialized
INFO - 2016-02-17 11:00:57 --> Loader Class Initialized
INFO - 2016-02-17 11:00:57 --> Helper loaded: url_helper
INFO - 2016-02-17 11:00:57 --> Helper loaded: file_helper
INFO - 2016-02-17 11:00:57 --> Helper loaded: date_helper
INFO - 2016-02-17 11:00:57 --> Helper loaded: form_helper
INFO - 2016-02-17 11:00:57 --> Database Driver Class Initialized
INFO - 2016-02-17 11:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:00:58 --> Controller Class Initialized
INFO - 2016-02-17 11:00:58 --> Model Class Initialized
INFO - 2016-02-17 11:00:58 --> Model Class Initialized
INFO - 2016-02-17 11:00:58 --> Form Validation Class Initialized
INFO - 2016-02-17 11:00:58 --> Helper loaded: text_helper
INFO - 2016-02-17 11:00:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:00:58 --> Final output sent to browser
DEBUG - 2016-02-17 11:00:58 --> Total execution time: 1.2293
INFO - 2016-02-17 11:02:21 --> Config Class Initialized
INFO - 2016-02-17 11:02:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:02:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:02:21 --> Utf8 Class Initialized
INFO - 2016-02-17 11:02:21 --> URI Class Initialized
INFO - 2016-02-17 11:02:21 --> Router Class Initialized
INFO - 2016-02-17 11:02:21 --> Output Class Initialized
INFO - 2016-02-17 11:02:21 --> Security Class Initialized
DEBUG - 2016-02-17 11:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:02:21 --> Input Class Initialized
INFO - 2016-02-17 11:02:21 --> Language Class Initialized
INFO - 2016-02-17 11:02:21 --> Loader Class Initialized
INFO - 2016-02-17 11:02:21 --> Helper loaded: url_helper
INFO - 2016-02-17 11:02:21 --> Helper loaded: file_helper
INFO - 2016-02-17 11:02:21 --> Helper loaded: date_helper
INFO - 2016-02-17 11:02:21 --> Helper loaded: form_helper
INFO - 2016-02-17 11:02:21 --> Database Driver Class Initialized
INFO - 2016-02-17 11:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:02:22 --> Controller Class Initialized
INFO - 2016-02-17 11:02:22 --> Model Class Initialized
INFO - 2016-02-17 11:02:22 --> Model Class Initialized
INFO - 2016-02-17 11:02:22 --> Form Validation Class Initialized
INFO - 2016-02-17 11:02:22 --> Helper loaded: text_helper
INFO - 2016-02-17 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:02:22 --> Model Class Initialized
INFO - 2016-02-17 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:02:22 --> Final output sent to browser
DEBUG - 2016-02-17 11:02:22 --> Total execution time: 1.1209
INFO - 2016-02-17 11:02:25 --> Config Class Initialized
INFO - 2016-02-17 11:02:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:02:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:02:25 --> Utf8 Class Initialized
INFO - 2016-02-17 11:02:25 --> URI Class Initialized
INFO - 2016-02-17 11:02:25 --> Router Class Initialized
INFO - 2016-02-17 11:02:25 --> Output Class Initialized
INFO - 2016-02-17 11:02:25 --> Security Class Initialized
DEBUG - 2016-02-17 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:02:25 --> Input Class Initialized
INFO - 2016-02-17 11:02:25 --> Language Class Initialized
INFO - 2016-02-17 11:02:25 --> Loader Class Initialized
INFO - 2016-02-17 11:02:25 --> Helper loaded: url_helper
INFO - 2016-02-17 11:02:25 --> Helper loaded: file_helper
INFO - 2016-02-17 11:02:25 --> Helper loaded: date_helper
INFO - 2016-02-17 11:02:25 --> Helper loaded: form_helper
INFO - 2016-02-17 11:02:25 --> Database Driver Class Initialized
INFO - 2016-02-17 11:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:02:26 --> Controller Class Initialized
INFO - 2016-02-17 11:02:26 --> Model Class Initialized
INFO - 2016-02-17 11:02:26 --> Model Class Initialized
INFO - 2016-02-17 11:02:26 --> Form Validation Class Initialized
INFO - 2016-02-17 11:02:26 --> Helper loaded: text_helper
INFO - 2016-02-17 11:02:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:02:26 --> Final output sent to browser
DEBUG - 2016-02-17 11:02:26 --> Total execution time: 1.0830
INFO - 2016-02-17 11:03:34 --> Config Class Initialized
INFO - 2016-02-17 11:03:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:03:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:03:34 --> Utf8 Class Initialized
INFO - 2016-02-17 11:03:34 --> URI Class Initialized
INFO - 2016-02-17 11:03:34 --> Router Class Initialized
INFO - 2016-02-17 11:03:34 --> Output Class Initialized
INFO - 2016-02-17 11:03:34 --> Security Class Initialized
DEBUG - 2016-02-17 11:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:03:34 --> Input Class Initialized
INFO - 2016-02-17 11:03:34 --> Language Class Initialized
INFO - 2016-02-17 11:03:34 --> Loader Class Initialized
INFO - 2016-02-17 11:03:34 --> Helper loaded: url_helper
INFO - 2016-02-17 11:03:34 --> Helper loaded: file_helper
INFO - 2016-02-17 11:03:34 --> Helper loaded: date_helper
INFO - 2016-02-17 11:03:34 --> Helper loaded: form_helper
INFO - 2016-02-17 11:03:34 --> Database Driver Class Initialized
INFO - 2016-02-17 11:03:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:03:35 --> Controller Class Initialized
INFO - 2016-02-17 11:03:35 --> Model Class Initialized
INFO - 2016-02-17 11:03:35 --> Model Class Initialized
INFO - 2016-02-17 11:03:35 --> Form Validation Class Initialized
INFO - 2016-02-17 11:03:35 --> Helper loaded: text_helper
INFO - 2016-02-17 11:03:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:03:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:03:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:03:35 --> Model Class Initialized
INFO - 2016-02-17 11:03:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:03:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:03:35 --> Final output sent to browser
DEBUG - 2016-02-17 11:03:35 --> Total execution time: 1.1131
INFO - 2016-02-17 11:03:36 --> Config Class Initialized
INFO - 2016-02-17 11:03:36 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:03:36 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:03:36 --> Utf8 Class Initialized
INFO - 2016-02-17 11:03:36 --> URI Class Initialized
INFO - 2016-02-17 11:03:36 --> Router Class Initialized
INFO - 2016-02-17 11:03:36 --> Output Class Initialized
INFO - 2016-02-17 11:03:36 --> Security Class Initialized
DEBUG - 2016-02-17 11:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:03:36 --> Input Class Initialized
INFO - 2016-02-17 11:03:36 --> Language Class Initialized
INFO - 2016-02-17 11:03:36 --> Loader Class Initialized
INFO - 2016-02-17 11:03:36 --> Helper loaded: url_helper
INFO - 2016-02-17 11:03:36 --> Helper loaded: file_helper
INFO - 2016-02-17 11:03:36 --> Helper loaded: date_helper
INFO - 2016-02-17 11:03:36 --> Helper loaded: form_helper
INFO - 2016-02-17 11:03:36 --> Database Driver Class Initialized
INFO - 2016-02-17 11:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:03:37 --> Controller Class Initialized
INFO - 2016-02-17 11:03:37 --> Model Class Initialized
INFO - 2016-02-17 11:03:37 --> Model Class Initialized
INFO - 2016-02-17 11:03:37 --> Form Validation Class Initialized
INFO - 2016-02-17 11:03:37 --> Helper loaded: text_helper
INFO - 2016-02-17 11:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:03:37 --> Final output sent to browser
DEBUG - 2016-02-17 11:03:37 --> Total execution time: 1.2272
INFO - 2016-02-17 11:04:15 --> Config Class Initialized
INFO - 2016-02-17 11:04:15 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:04:15 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:04:15 --> Utf8 Class Initialized
INFO - 2016-02-17 11:04:15 --> URI Class Initialized
INFO - 2016-02-17 11:04:15 --> Router Class Initialized
INFO - 2016-02-17 11:04:15 --> Output Class Initialized
INFO - 2016-02-17 11:04:15 --> Security Class Initialized
DEBUG - 2016-02-17 11:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:04:15 --> Input Class Initialized
INFO - 2016-02-17 11:04:15 --> Language Class Initialized
INFO - 2016-02-17 11:04:15 --> Loader Class Initialized
INFO - 2016-02-17 11:04:15 --> Helper loaded: url_helper
INFO - 2016-02-17 11:04:15 --> Helper loaded: file_helper
INFO - 2016-02-17 11:04:15 --> Helper loaded: date_helper
INFO - 2016-02-17 11:04:15 --> Helper loaded: form_helper
INFO - 2016-02-17 11:04:15 --> Database Driver Class Initialized
INFO - 2016-02-17 11:04:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:04:16 --> Controller Class Initialized
INFO - 2016-02-17 11:04:16 --> Model Class Initialized
INFO - 2016-02-17 11:04:16 --> Model Class Initialized
INFO - 2016-02-17 11:04:16 --> Form Validation Class Initialized
INFO - 2016-02-17 11:04:16 --> Helper loaded: text_helper
INFO - 2016-02-17 11:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:04:16 --> Model Class Initialized
INFO - 2016-02-17 11:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:04:16 --> Final output sent to browser
DEBUG - 2016-02-17 11:04:16 --> Total execution time: 1.1181
INFO - 2016-02-17 11:04:30 --> Config Class Initialized
INFO - 2016-02-17 11:04:30 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:04:30 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:04:30 --> Utf8 Class Initialized
INFO - 2016-02-17 11:04:30 --> URI Class Initialized
INFO - 2016-02-17 11:04:30 --> Router Class Initialized
INFO - 2016-02-17 11:04:30 --> Output Class Initialized
INFO - 2016-02-17 11:04:30 --> Security Class Initialized
DEBUG - 2016-02-17 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:04:30 --> Input Class Initialized
INFO - 2016-02-17 11:04:30 --> Language Class Initialized
INFO - 2016-02-17 11:04:30 --> Loader Class Initialized
INFO - 2016-02-17 11:04:30 --> Helper loaded: url_helper
INFO - 2016-02-17 11:04:30 --> Helper loaded: file_helper
INFO - 2016-02-17 11:04:30 --> Helper loaded: date_helper
INFO - 2016-02-17 11:04:30 --> Helper loaded: form_helper
INFO - 2016-02-17 11:04:30 --> Database Driver Class Initialized
INFO - 2016-02-17 11:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:04:31 --> Controller Class Initialized
INFO - 2016-02-17 11:04:31 --> Model Class Initialized
INFO - 2016-02-17 11:04:31 --> Model Class Initialized
INFO - 2016-02-17 11:04:31 --> Form Validation Class Initialized
INFO - 2016-02-17 11:04:31 --> Helper loaded: text_helper
INFO - 2016-02-17 11:04:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:04:31 --> Final output sent to browser
DEBUG - 2016-02-17 11:04:31 --> Total execution time: 1.1343
INFO - 2016-02-17 11:12:28 --> Config Class Initialized
INFO - 2016-02-17 11:12:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:12:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:12:28 --> Utf8 Class Initialized
INFO - 2016-02-17 11:12:28 --> URI Class Initialized
INFO - 2016-02-17 11:12:28 --> Router Class Initialized
INFO - 2016-02-17 11:12:28 --> Output Class Initialized
INFO - 2016-02-17 11:12:28 --> Security Class Initialized
DEBUG - 2016-02-17 11:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:12:29 --> Input Class Initialized
INFO - 2016-02-17 11:12:29 --> Language Class Initialized
INFO - 2016-02-17 11:12:29 --> Loader Class Initialized
INFO - 2016-02-17 11:12:29 --> Helper loaded: url_helper
INFO - 2016-02-17 11:12:29 --> Helper loaded: file_helper
INFO - 2016-02-17 11:12:29 --> Helper loaded: date_helper
INFO - 2016-02-17 11:12:29 --> Helper loaded: form_helper
INFO - 2016-02-17 11:12:29 --> Database Driver Class Initialized
INFO - 2016-02-17 11:12:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:12:30 --> Controller Class Initialized
INFO - 2016-02-17 11:12:30 --> Model Class Initialized
INFO - 2016-02-17 11:12:30 --> Model Class Initialized
INFO - 2016-02-17 11:12:30 --> Form Validation Class Initialized
INFO - 2016-02-17 11:12:30 --> Helper loaded: text_helper
INFO - 2016-02-17 11:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:12:30 --> Model Class Initialized
INFO - 2016-02-17 11:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:12:30 --> Final output sent to browser
DEBUG - 2016-02-17 11:12:30 --> Total execution time: 1.1363
INFO - 2016-02-17 11:12:32 --> Config Class Initialized
INFO - 2016-02-17 11:12:32 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:12:32 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:12:32 --> Utf8 Class Initialized
INFO - 2016-02-17 11:12:32 --> URI Class Initialized
INFO - 2016-02-17 11:12:32 --> Router Class Initialized
INFO - 2016-02-17 11:12:32 --> Output Class Initialized
INFO - 2016-02-17 11:12:32 --> Security Class Initialized
DEBUG - 2016-02-17 11:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:12:32 --> Input Class Initialized
INFO - 2016-02-17 11:12:32 --> Language Class Initialized
INFO - 2016-02-17 11:12:32 --> Loader Class Initialized
INFO - 2016-02-17 11:12:32 --> Helper loaded: url_helper
INFO - 2016-02-17 11:12:32 --> Helper loaded: file_helper
INFO - 2016-02-17 11:12:32 --> Helper loaded: date_helper
INFO - 2016-02-17 11:12:32 --> Helper loaded: form_helper
INFO - 2016-02-17 11:12:32 --> Database Driver Class Initialized
INFO - 2016-02-17 11:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:12:33 --> Controller Class Initialized
INFO - 2016-02-17 11:12:33 --> Model Class Initialized
INFO - 2016-02-17 11:12:33 --> Model Class Initialized
INFO - 2016-02-17 11:12:33 --> Form Validation Class Initialized
INFO - 2016-02-17 11:12:33 --> Helper loaded: text_helper
INFO - 2016-02-17 11:12:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:12:33 --> Final output sent to browser
DEBUG - 2016-02-17 11:12:33 --> Total execution time: 1.1072
INFO - 2016-02-17 11:13:08 --> Config Class Initialized
INFO - 2016-02-17 11:13:08 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:13:08 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:13:08 --> Utf8 Class Initialized
INFO - 2016-02-17 11:13:08 --> URI Class Initialized
INFO - 2016-02-17 11:13:08 --> Router Class Initialized
INFO - 2016-02-17 11:13:08 --> Output Class Initialized
INFO - 2016-02-17 11:13:08 --> Security Class Initialized
DEBUG - 2016-02-17 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:13:08 --> Input Class Initialized
INFO - 2016-02-17 11:13:08 --> Language Class Initialized
INFO - 2016-02-17 11:13:08 --> Loader Class Initialized
INFO - 2016-02-17 11:13:08 --> Helper loaded: url_helper
INFO - 2016-02-17 11:13:08 --> Helper loaded: file_helper
INFO - 2016-02-17 11:13:08 --> Helper loaded: date_helper
INFO - 2016-02-17 11:13:08 --> Helper loaded: form_helper
INFO - 2016-02-17 11:13:08 --> Database Driver Class Initialized
INFO - 2016-02-17 11:13:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:13:09 --> Controller Class Initialized
INFO - 2016-02-17 11:13:09 --> Model Class Initialized
INFO - 2016-02-17 11:13:09 --> Model Class Initialized
INFO - 2016-02-17 11:13:09 --> Form Validation Class Initialized
INFO - 2016-02-17 11:13:09 --> Helper loaded: text_helper
INFO - 2016-02-17 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:13:09 --> Model Class Initialized
INFO - 2016-02-17 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:13:09 --> Final output sent to browser
DEBUG - 2016-02-17 11:13:09 --> Total execution time: 1.1237
INFO - 2016-02-17 11:13:11 --> Config Class Initialized
INFO - 2016-02-17 11:13:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:13:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:13:11 --> Utf8 Class Initialized
INFO - 2016-02-17 11:13:11 --> URI Class Initialized
INFO - 2016-02-17 11:13:11 --> Router Class Initialized
INFO - 2016-02-17 11:13:11 --> Output Class Initialized
INFO - 2016-02-17 11:13:11 --> Security Class Initialized
DEBUG - 2016-02-17 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:13:11 --> Input Class Initialized
INFO - 2016-02-17 11:13:11 --> Language Class Initialized
INFO - 2016-02-17 11:13:11 --> Loader Class Initialized
INFO - 2016-02-17 11:13:11 --> Helper loaded: url_helper
INFO - 2016-02-17 11:13:11 --> Helper loaded: file_helper
INFO - 2016-02-17 11:13:11 --> Helper loaded: date_helper
INFO - 2016-02-17 11:13:11 --> Helper loaded: form_helper
INFO - 2016-02-17 11:13:11 --> Database Driver Class Initialized
INFO - 2016-02-17 11:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:13:12 --> Controller Class Initialized
INFO - 2016-02-17 11:13:12 --> Model Class Initialized
INFO - 2016-02-17 11:13:12 --> Model Class Initialized
INFO - 2016-02-17 11:13:12 --> Form Validation Class Initialized
INFO - 2016-02-17 11:13:12 --> Helper loaded: text_helper
INFO - 2016-02-17 11:13:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:13:12 --> Final output sent to browser
DEBUG - 2016-02-17 11:13:12 --> Total execution time: 1.1222
INFO - 2016-02-17 11:13:30 --> Config Class Initialized
INFO - 2016-02-17 11:13:30 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:13:30 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:13:30 --> Utf8 Class Initialized
INFO - 2016-02-17 11:13:30 --> URI Class Initialized
INFO - 2016-02-17 11:13:30 --> Router Class Initialized
INFO - 2016-02-17 11:13:30 --> Output Class Initialized
INFO - 2016-02-17 11:13:30 --> Security Class Initialized
DEBUG - 2016-02-17 11:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:13:30 --> Input Class Initialized
INFO - 2016-02-17 11:13:30 --> Language Class Initialized
INFO - 2016-02-17 11:13:30 --> Loader Class Initialized
INFO - 2016-02-17 11:13:30 --> Helper loaded: url_helper
INFO - 2016-02-17 11:13:30 --> Helper loaded: file_helper
INFO - 2016-02-17 11:13:30 --> Helper loaded: date_helper
INFO - 2016-02-17 11:13:30 --> Helper loaded: form_helper
INFO - 2016-02-17 11:13:30 --> Database Driver Class Initialized
INFO - 2016-02-17 11:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:13:31 --> Controller Class Initialized
INFO - 2016-02-17 11:13:31 --> Model Class Initialized
INFO - 2016-02-17 11:13:31 --> Model Class Initialized
INFO - 2016-02-17 11:13:31 --> Form Validation Class Initialized
INFO - 2016-02-17 11:13:31 --> Helper loaded: text_helper
INFO - 2016-02-17 11:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:13:32 --> Model Class Initialized
INFO - 2016-02-17 11:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:13:32 --> Final output sent to browser
DEBUG - 2016-02-17 11:13:32 --> Total execution time: 1.1429
INFO - 2016-02-17 11:13:33 --> Config Class Initialized
INFO - 2016-02-17 11:13:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:13:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:13:33 --> Utf8 Class Initialized
INFO - 2016-02-17 11:13:33 --> URI Class Initialized
INFO - 2016-02-17 11:13:33 --> Router Class Initialized
INFO - 2016-02-17 11:13:33 --> Output Class Initialized
INFO - 2016-02-17 11:13:33 --> Security Class Initialized
DEBUG - 2016-02-17 11:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:13:33 --> Input Class Initialized
INFO - 2016-02-17 11:13:33 --> Language Class Initialized
INFO - 2016-02-17 11:13:33 --> Loader Class Initialized
INFO - 2016-02-17 11:13:33 --> Helper loaded: url_helper
INFO - 2016-02-17 11:13:33 --> Helper loaded: file_helper
INFO - 2016-02-17 11:13:33 --> Helper loaded: date_helper
INFO - 2016-02-17 11:13:33 --> Helper loaded: form_helper
INFO - 2016-02-17 11:13:33 --> Database Driver Class Initialized
INFO - 2016-02-17 11:13:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:13:34 --> Controller Class Initialized
INFO - 2016-02-17 11:13:34 --> Model Class Initialized
INFO - 2016-02-17 11:13:34 --> Model Class Initialized
INFO - 2016-02-17 11:13:34 --> Form Validation Class Initialized
INFO - 2016-02-17 11:13:34 --> Helper loaded: text_helper
INFO - 2016-02-17 11:13:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:13:34 --> Final output sent to browser
DEBUG - 2016-02-17 11:13:34 --> Total execution time: 1.1147
INFO - 2016-02-17 11:13:37 --> Config Class Initialized
INFO - 2016-02-17 11:13:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:13:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:13:37 --> Utf8 Class Initialized
INFO - 2016-02-17 11:13:37 --> URI Class Initialized
INFO - 2016-02-17 11:13:37 --> Router Class Initialized
INFO - 2016-02-17 11:13:37 --> Output Class Initialized
INFO - 2016-02-17 11:13:37 --> Security Class Initialized
DEBUG - 2016-02-17 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:13:37 --> Input Class Initialized
INFO - 2016-02-17 11:13:37 --> Language Class Initialized
INFO - 2016-02-17 11:13:37 --> Loader Class Initialized
INFO - 2016-02-17 11:13:37 --> Helper loaded: url_helper
INFO - 2016-02-17 11:13:37 --> Helper loaded: file_helper
INFO - 2016-02-17 11:13:37 --> Helper loaded: date_helper
INFO - 2016-02-17 11:13:37 --> Helper loaded: form_helper
INFO - 2016-02-17 11:13:37 --> Database Driver Class Initialized
INFO - 2016-02-17 11:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:13:38 --> Controller Class Initialized
INFO - 2016-02-17 11:13:38 --> Model Class Initialized
INFO - 2016-02-17 11:13:38 --> Model Class Initialized
INFO - 2016-02-17 11:13:38 --> Form Validation Class Initialized
INFO - 2016-02-17 11:13:38 --> Helper loaded: text_helper
INFO - 2016-02-17 11:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:13:38 --> Model Class Initialized
INFO - 2016-02-17 11:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:13:38 --> Final output sent to browser
DEBUG - 2016-02-17 11:13:38 --> Total execution time: 1.1008
INFO - 2016-02-17 11:14:17 --> Config Class Initialized
INFO - 2016-02-17 11:14:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:14:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:14:17 --> Utf8 Class Initialized
INFO - 2016-02-17 11:14:17 --> URI Class Initialized
INFO - 2016-02-17 11:14:17 --> Router Class Initialized
INFO - 2016-02-17 11:14:17 --> Output Class Initialized
INFO - 2016-02-17 11:14:17 --> Security Class Initialized
DEBUG - 2016-02-17 11:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:14:17 --> Input Class Initialized
INFO - 2016-02-17 11:14:17 --> Language Class Initialized
INFO - 2016-02-17 11:14:17 --> Loader Class Initialized
INFO - 2016-02-17 11:14:17 --> Helper loaded: url_helper
INFO - 2016-02-17 11:14:17 --> Helper loaded: file_helper
INFO - 2016-02-17 11:14:17 --> Helper loaded: date_helper
INFO - 2016-02-17 11:14:17 --> Helper loaded: form_helper
INFO - 2016-02-17 11:14:17 --> Database Driver Class Initialized
INFO - 2016-02-17 11:14:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:14:18 --> Controller Class Initialized
INFO - 2016-02-17 11:14:18 --> Model Class Initialized
INFO - 2016-02-17 11:14:18 --> Model Class Initialized
INFO - 2016-02-17 11:14:18 --> Form Validation Class Initialized
INFO - 2016-02-17 11:14:18 --> Helper loaded: text_helper
INFO - 2016-02-17 11:14:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:14:18 --> Final output sent to browser
DEBUG - 2016-02-17 11:14:18 --> Total execution time: 1.0910
INFO - 2016-02-17 11:14:20 --> Config Class Initialized
INFO - 2016-02-17 11:14:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:14:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:14:20 --> Utf8 Class Initialized
INFO - 2016-02-17 11:14:20 --> URI Class Initialized
INFO - 2016-02-17 11:14:21 --> Router Class Initialized
INFO - 2016-02-17 11:14:21 --> Output Class Initialized
INFO - 2016-02-17 11:14:21 --> Security Class Initialized
DEBUG - 2016-02-17 11:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:14:21 --> Input Class Initialized
INFO - 2016-02-17 11:14:21 --> Language Class Initialized
INFO - 2016-02-17 11:14:21 --> Loader Class Initialized
INFO - 2016-02-17 11:14:21 --> Helper loaded: url_helper
INFO - 2016-02-17 11:14:21 --> Helper loaded: file_helper
INFO - 2016-02-17 11:14:21 --> Helper loaded: date_helper
INFO - 2016-02-17 11:14:21 --> Helper loaded: form_helper
INFO - 2016-02-17 11:14:21 --> Database Driver Class Initialized
INFO - 2016-02-17 11:14:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:14:22 --> Controller Class Initialized
INFO - 2016-02-17 11:14:22 --> Model Class Initialized
INFO - 2016-02-17 11:14:22 --> Model Class Initialized
INFO - 2016-02-17 11:14:22 --> Form Validation Class Initialized
INFO - 2016-02-17 11:14:22 --> Helper loaded: text_helper
INFO - 2016-02-17 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:14:22 --> Model Class Initialized
INFO - 2016-02-17 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:14:22 --> Final output sent to browser
DEBUG - 2016-02-17 11:14:22 --> Total execution time: 1.1053
INFO - 2016-02-17 11:18:09 --> Config Class Initialized
INFO - 2016-02-17 11:18:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:18:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:18:09 --> Utf8 Class Initialized
INFO - 2016-02-17 11:18:09 --> URI Class Initialized
DEBUG - 2016-02-17 11:18:09 --> No URI present. Default controller set.
INFO - 2016-02-17 11:18:09 --> Router Class Initialized
INFO - 2016-02-17 11:18:09 --> Output Class Initialized
INFO - 2016-02-17 11:18:09 --> Security Class Initialized
DEBUG - 2016-02-17 11:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:18:09 --> Input Class Initialized
INFO - 2016-02-17 11:18:09 --> Language Class Initialized
INFO - 2016-02-17 11:18:09 --> Loader Class Initialized
INFO - 2016-02-17 11:18:09 --> Helper loaded: url_helper
INFO - 2016-02-17 11:18:09 --> Helper loaded: file_helper
INFO - 2016-02-17 11:18:09 --> Helper loaded: date_helper
INFO - 2016-02-17 11:18:09 --> Helper loaded: form_helper
INFO - 2016-02-17 11:18:09 --> Database Driver Class Initialized
INFO - 2016-02-17 11:18:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:18:10 --> Controller Class Initialized
INFO - 2016-02-17 11:18:10 --> Model Class Initialized
INFO - 2016-02-17 11:18:10 --> Model Class Initialized
INFO - 2016-02-17 11:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:18:10 --> Pagination Class Initialized
INFO - 2016-02-17 11:18:10 --> Helper loaded: text_helper
INFO - 2016-02-17 11:18:10 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:18:10 --> Final output sent to browser
DEBUG - 2016-02-17 14:18:10 --> Total execution time: 1.1112
INFO - 2016-02-17 11:18:15 --> Config Class Initialized
INFO - 2016-02-17 11:18:15 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:18:15 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:18:15 --> Utf8 Class Initialized
INFO - 2016-02-17 11:18:15 --> URI Class Initialized
INFO - 2016-02-17 11:18:15 --> Router Class Initialized
INFO - 2016-02-17 11:18:15 --> Output Class Initialized
INFO - 2016-02-17 11:18:15 --> Security Class Initialized
DEBUG - 2016-02-17 11:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:18:15 --> Input Class Initialized
INFO - 2016-02-17 11:18:15 --> Language Class Initialized
INFO - 2016-02-17 11:18:15 --> Loader Class Initialized
INFO - 2016-02-17 11:18:15 --> Helper loaded: url_helper
INFO - 2016-02-17 11:18:15 --> Helper loaded: file_helper
INFO - 2016-02-17 11:18:15 --> Helper loaded: date_helper
INFO - 2016-02-17 11:18:15 --> Helper loaded: form_helper
INFO - 2016-02-17 11:18:15 --> Database Driver Class Initialized
INFO - 2016-02-17 11:18:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:18:16 --> Controller Class Initialized
INFO - 2016-02-17 11:18:16 --> Model Class Initialized
INFO - 2016-02-17 11:18:16 --> Model Class Initialized
INFO - 2016-02-17 11:18:16 --> Form Validation Class Initialized
INFO - 2016-02-17 11:18:16 --> Helper loaded: text_helper
INFO - 2016-02-17 11:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:18:16 --> Model Class Initialized
INFO - 2016-02-17 11:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:18:16 --> Final output sent to browser
DEBUG - 2016-02-17 11:18:16 --> Total execution time: 1.1098
INFO - 2016-02-17 11:18:17 --> Config Class Initialized
INFO - 2016-02-17 11:18:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:18:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:18:17 --> Utf8 Class Initialized
INFO - 2016-02-17 11:18:17 --> URI Class Initialized
INFO - 2016-02-17 11:18:17 --> Router Class Initialized
INFO - 2016-02-17 11:18:17 --> Output Class Initialized
INFO - 2016-02-17 11:18:18 --> Security Class Initialized
DEBUG - 2016-02-17 11:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:18:18 --> Input Class Initialized
INFO - 2016-02-17 11:18:18 --> Language Class Initialized
INFO - 2016-02-17 11:18:18 --> Loader Class Initialized
INFO - 2016-02-17 11:18:18 --> Helper loaded: url_helper
INFO - 2016-02-17 11:18:18 --> Helper loaded: file_helper
INFO - 2016-02-17 11:18:18 --> Helper loaded: date_helper
INFO - 2016-02-17 11:18:18 --> Helper loaded: form_helper
INFO - 2016-02-17 11:18:18 --> Database Driver Class Initialized
INFO - 2016-02-17 11:18:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:18:19 --> Controller Class Initialized
INFO - 2016-02-17 11:18:19 --> Model Class Initialized
INFO - 2016-02-17 11:18:19 --> Model Class Initialized
INFO - 2016-02-17 11:18:19 --> Form Validation Class Initialized
INFO - 2016-02-17 11:18:19 --> Helper loaded: text_helper
INFO - 2016-02-17 11:18:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:18:19 --> Final output sent to browser
DEBUG - 2016-02-17 11:18:19 --> Total execution time: 1.0975
INFO - 2016-02-17 11:18:20 --> Config Class Initialized
INFO - 2016-02-17 11:18:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:18:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:18:20 --> Utf8 Class Initialized
INFO - 2016-02-17 11:18:20 --> URI Class Initialized
INFO - 2016-02-17 11:18:20 --> Router Class Initialized
INFO - 2016-02-17 11:18:20 --> Output Class Initialized
INFO - 2016-02-17 11:18:20 --> Security Class Initialized
DEBUG - 2016-02-17 11:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:18:21 --> Input Class Initialized
INFO - 2016-02-17 11:18:21 --> Language Class Initialized
INFO - 2016-02-17 11:18:21 --> Loader Class Initialized
INFO - 2016-02-17 11:18:21 --> Helper loaded: url_helper
INFO - 2016-02-17 11:18:21 --> Helper loaded: file_helper
INFO - 2016-02-17 11:18:21 --> Helper loaded: date_helper
INFO - 2016-02-17 11:18:21 --> Helper loaded: form_helper
INFO - 2016-02-17 11:18:21 --> Database Driver Class Initialized
INFO - 2016-02-17 11:18:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:18:22 --> Controller Class Initialized
INFO - 2016-02-17 11:18:22 --> Model Class Initialized
INFO - 2016-02-17 11:18:22 --> Model Class Initialized
INFO - 2016-02-17 11:18:22 --> Form Validation Class Initialized
INFO - 2016-02-17 11:18:22 --> Helper loaded: text_helper
INFO - 2016-02-17 11:18:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:18:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:18:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:18:22 --> Model Class Initialized
INFO - 2016-02-17 11:18:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:18:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:18:22 --> Final output sent to browser
DEBUG - 2016-02-17 11:18:22 --> Total execution time: 1.0914
INFO - 2016-02-17 11:24:14 --> Config Class Initialized
INFO - 2016-02-17 11:24:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:24:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:24:14 --> Utf8 Class Initialized
INFO - 2016-02-17 11:24:14 --> URI Class Initialized
DEBUG - 2016-02-17 11:24:14 --> No URI present. Default controller set.
INFO - 2016-02-17 11:24:14 --> Router Class Initialized
INFO - 2016-02-17 11:24:14 --> Output Class Initialized
INFO - 2016-02-17 11:24:14 --> Security Class Initialized
DEBUG - 2016-02-17 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:24:14 --> Input Class Initialized
INFO - 2016-02-17 11:24:14 --> Language Class Initialized
INFO - 2016-02-17 11:24:14 --> Loader Class Initialized
INFO - 2016-02-17 11:24:14 --> Helper loaded: url_helper
INFO - 2016-02-17 11:24:14 --> Helper loaded: file_helper
INFO - 2016-02-17 11:24:14 --> Helper loaded: date_helper
INFO - 2016-02-17 11:24:14 --> Helper loaded: form_helper
INFO - 2016-02-17 11:24:14 --> Database Driver Class Initialized
INFO - 2016-02-17 11:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:24:15 --> Controller Class Initialized
INFO - 2016-02-17 11:24:15 --> Model Class Initialized
INFO - 2016-02-17 11:24:15 --> Model Class Initialized
INFO - 2016-02-17 11:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:24:15 --> Pagination Class Initialized
INFO - 2016-02-17 11:24:15 --> Helper loaded: text_helper
INFO - 2016-02-17 11:24:15 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:24:15 --> Final output sent to browser
DEBUG - 2016-02-17 14:24:15 --> Total execution time: 1.1141
INFO - 2016-02-17 11:24:17 --> Config Class Initialized
INFO - 2016-02-17 11:24:17 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:24:17 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:24:17 --> Utf8 Class Initialized
INFO - 2016-02-17 11:24:17 --> URI Class Initialized
INFO - 2016-02-17 11:24:17 --> Router Class Initialized
INFO - 2016-02-17 11:24:17 --> Output Class Initialized
INFO - 2016-02-17 11:24:17 --> Security Class Initialized
DEBUG - 2016-02-17 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:24:17 --> Input Class Initialized
INFO - 2016-02-17 11:24:17 --> Language Class Initialized
INFO - 2016-02-17 11:24:17 --> Loader Class Initialized
INFO - 2016-02-17 11:24:17 --> Helper loaded: url_helper
INFO - 2016-02-17 11:24:17 --> Helper loaded: file_helper
INFO - 2016-02-17 11:24:17 --> Helper loaded: date_helper
INFO - 2016-02-17 11:24:17 --> Helper loaded: form_helper
INFO - 2016-02-17 11:24:17 --> Database Driver Class Initialized
INFO - 2016-02-17 11:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:24:18 --> Controller Class Initialized
INFO - 2016-02-17 11:24:18 --> Model Class Initialized
INFO - 2016-02-17 11:24:18 --> Model Class Initialized
INFO - 2016-02-17 11:24:18 --> Form Validation Class Initialized
INFO - 2016-02-17 11:24:18 --> Helper loaded: text_helper
INFO - 2016-02-17 11:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:24:18 --> Model Class Initialized
INFO - 2016-02-17 11:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:24:18 --> Final output sent to browser
DEBUG - 2016-02-17 11:24:18 --> Total execution time: 1.0935
INFO - 2016-02-17 11:25:11 --> Config Class Initialized
INFO - 2016-02-17 11:25:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:25:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:25:11 --> Utf8 Class Initialized
INFO - 2016-02-17 11:25:11 --> URI Class Initialized
DEBUG - 2016-02-17 11:25:11 --> No URI present. Default controller set.
INFO - 2016-02-17 11:25:11 --> Router Class Initialized
INFO - 2016-02-17 11:25:11 --> Output Class Initialized
INFO - 2016-02-17 11:25:11 --> Security Class Initialized
DEBUG - 2016-02-17 11:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:25:11 --> Input Class Initialized
INFO - 2016-02-17 11:25:11 --> Language Class Initialized
INFO - 2016-02-17 11:25:11 --> Loader Class Initialized
INFO - 2016-02-17 11:25:11 --> Helper loaded: url_helper
INFO - 2016-02-17 11:25:11 --> Helper loaded: file_helper
INFO - 2016-02-17 11:25:11 --> Helper loaded: date_helper
INFO - 2016-02-17 11:25:11 --> Helper loaded: form_helper
INFO - 2016-02-17 11:25:11 --> Database Driver Class Initialized
INFO - 2016-02-17 11:25:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:25:12 --> Controller Class Initialized
INFO - 2016-02-17 11:25:12 --> Model Class Initialized
INFO - 2016-02-17 11:25:12 --> Model Class Initialized
INFO - 2016-02-17 11:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:25:12 --> Pagination Class Initialized
INFO - 2016-02-17 11:25:12 --> Helper loaded: text_helper
INFO - 2016-02-17 11:25:12 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:25:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:25:12 --> Final output sent to browser
DEBUG - 2016-02-17 14:25:12 --> Total execution time: 1.1372
INFO - 2016-02-17 11:25:13 --> Config Class Initialized
INFO - 2016-02-17 11:25:13 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:25:13 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:25:13 --> Utf8 Class Initialized
INFO - 2016-02-17 11:25:13 --> URI Class Initialized
INFO - 2016-02-17 11:25:13 --> Router Class Initialized
INFO - 2016-02-17 11:25:13 --> Output Class Initialized
INFO - 2016-02-17 11:25:13 --> Security Class Initialized
DEBUG - 2016-02-17 11:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:25:13 --> Input Class Initialized
INFO - 2016-02-17 11:25:13 --> Language Class Initialized
INFO - 2016-02-17 11:25:13 --> Loader Class Initialized
INFO - 2016-02-17 11:25:13 --> Helper loaded: url_helper
INFO - 2016-02-17 11:25:13 --> Helper loaded: file_helper
INFO - 2016-02-17 11:25:13 --> Helper loaded: date_helper
INFO - 2016-02-17 11:25:13 --> Helper loaded: form_helper
INFO - 2016-02-17 11:25:13 --> Database Driver Class Initialized
INFO - 2016-02-17 11:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:25:15 --> Controller Class Initialized
INFO - 2016-02-17 11:25:15 --> Model Class Initialized
INFO - 2016-02-17 11:25:15 --> Model Class Initialized
INFO - 2016-02-17 11:25:15 --> Form Validation Class Initialized
INFO - 2016-02-17 11:25:15 --> Helper loaded: text_helper
INFO - 2016-02-17 11:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:25:15 --> Model Class Initialized
INFO - 2016-02-17 11:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:25:15 --> Final output sent to browser
DEBUG - 2016-02-17 11:25:15 --> Total execution time: 1.1025
INFO - 2016-02-17 11:31:23 --> Config Class Initialized
INFO - 2016-02-17 11:31:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:31:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:31:23 --> Utf8 Class Initialized
INFO - 2016-02-17 11:31:23 --> URI Class Initialized
DEBUG - 2016-02-17 11:31:23 --> No URI present. Default controller set.
INFO - 2016-02-17 11:31:23 --> Router Class Initialized
INFO - 2016-02-17 11:31:23 --> Output Class Initialized
INFO - 2016-02-17 11:31:23 --> Security Class Initialized
DEBUG - 2016-02-17 11:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:31:23 --> Input Class Initialized
INFO - 2016-02-17 11:31:23 --> Language Class Initialized
INFO - 2016-02-17 11:31:23 --> Loader Class Initialized
INFO - 2016-02-17 11:31:23 --> Helper loaded: url_helper
INFO - 2016-02-17 11:31:23 --> Helper loaded: file_helper
INFO - 2016-02-17 11:31:23 --> Helper loaded: date_helper
INFO - 2016-02-17 11:31:23 --> Helper loaded: form_helper
INFO - 2016-02-17 11:31:23 --> Database Driver Class Initialized
INFO - 2016-02-17 11:31:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:31:24 --> Controller Class Initialized
INFO - 2016-02-17 11:31:24 --> Model Class Initialized
INFO - 2016-02-17 11:31:24 --> Model Class Initialized
INFO - 2016-02-17 11:31:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:31:24 --> Pagination Class Initialized
INFO - 2016-02-17 11:31:24 --> Helper loaded: text_helper
INFO - 2016-02-17 11:31:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:31:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:31:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:31:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:31:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:31:24 --> Final output sent to browser
DEBUG - 2016-02-17 14:31:24 --> Total execution time: 1.1228
INFO - 2016-02-17 11:31:25 --> Config Class Initialized
INFO - 2016-02-17 11:31:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:31:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:31:25 --> Utf8 Class Initialized
INFO - 2016-02-17 11:31:25 --> URI Class Initialized
INFO - 2016-02-17 11:31:25 --> Router Class Initialized
INFO - 2016-02-17 11:31:25 --> Output Class Initialized
INFO - 2016-02-17 11:31:25 --> Security Class Initialized
DEBUG - 2016-02-17 11:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:31:25 --> Input Class Initialized
INFO - 2016-02-17 11:31:25 --> Language Class Initialized
INFO - 2016-02-17 11:31:25 --> Loader Class Initialized
INFO - 2016-02-17 11:31:25 --> Helper loaded: url_helper
INFO - 2016-02-17 11:31:25 --> Helper loaded: file_helper
INFO - 2016-02-17 11:31:25 --> Helper loaded: date_helper
INFO - 2016-02-17 11:31:25 --> Helper loaded: form_helper
INFO - 2016-02-17 11:31:25 --> Database Driver Class Initialized
INFO - 2016-02-17 11:31:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:31:26 --> Controller Class Initialized
INFO - 2016-02-17 11:31:26 --> Model Class Initialized
INFO - 2016-02-17 11:31:26 --> Model Class Initialized
INFO - 2016-02-17 11:31:26 --> Form Validation Class Initialized
INFO - 2016-02-17 11:31:26 --> Helper loaded: text_helper
INFO - 2016-02-17 11:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:31:26 --> Model Class Initialized
INFO - 2016-02-17 11:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:31:26 --> Final output sent to browser
DEBUG - 2016-02-17 11:31:26 --> Total execution time: 1.2166
INFO - 2016-02-17 11:31:59 --> Config Class Initialized
INFO - 2016-02-17 11:31:59 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:31:59 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:31:59 --> Utf8 Class Initialized
INFO - 2016-02-17 11:31:59 --> URI Class Initialized
DEBUG - 2016-02-17 11:31:59 --> No URI present. Default controller set.
INFO - 2016-02-17 11:31:59 --> Router Class Initialized
INFO - 2016-02-17 11:31:59 --> Output Class Initialized
INFO - 2016-02-17 11:31:59 --> Security Class Initialized
DEBUG - 2016-02-17 11:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:31:59 --> Input Class Initialized
INFO - 2016-02-17 11:31:59 --> Language Class Initialized
INFO - 2016-02-17 11:31:59 --> Loader Class Initialized
INFO - 2016-02-17 11:31:59 --> Helper loaded: url_helper
INFO - 2016-02-17 11:31:59 --> Helper loaded: file_helper
INFO - 2016-02-17 11:31:59 --> Helper loaded: date_helper
INFO - 2016-02-17 11:31:59 --> Helper loaded: form_helper
INFO - 2016-02-17 11:31:59 --> Database Driver Class Initialized
INFO - 2016-02-17 11:32:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:32:00 --> Controller Class Initialized
INFO - 2016-02-17 11:32:00 --> Model Class Initialized
INFO - 2016-02-17 11:32:00 --> Model Class Initialized
INFO - 2016-02-17 11:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:32:00 --> Pagination Class Initialized
INFO - 2016-02-17 11:32:00 --> Helper loaded: text_helper
INFO - 2016-02-17 11:32:00 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:32:00 --> Final output sent to browser
DEBUG - 2016-02-17 14:32:00 --> Total execution time: 1.1102
INFO - 2016-02-17 11:32:01 --> Config Class Initialized
INFO - 2016-02-17 11:32:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:32:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:32:01 --> Utf8 Class Initialized
INFO - 2016-02-17 11:32:01 --> URI Class Initialized
INFO - 2016-02-17 11:32:01 --> Router Class Initialized
INFO - 2016-02-17 11:32:01 --> Output Class Initialized
INFO - 2016-02-17 11:32:01 --> Security Class Initialized
DEBUG - 2016-02-17 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:32:01 --> Input Class Initialized
INFO - 2016-02-17 11:32:01 --> Language Class Initialized
INFO - 2016-02-17 11:32:01 --> Loader Class Initialized
INFO - 2016-02-17 11:32:01 --> Helper loaded: url_helper
INFO - 2016-02-17 11:32:01 --> Helper loaded: file_helper
INFO - 2016-02-17 11:32:01 --> Helper loaded: date_helper
INFO - 2016-02-17 11:32:01 --> Helper loaded: form_helper
INFO - 2016-02-17 11:32:01 --> Database Driver Class Initialized
INFO - 2016-02-17 11:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:32:02 --> Controller Class Initialized
INFO - 2016-02-17 11:32:02 --> Model Class Initialized
INFO - 2016-02-17 11:32:02 --> Model Class Initialized
INFO - 2016-02-17 11:32:02 --> Form Validation Class Initialized
INFO - 2016-02-17 11:32:02 --> Helper loaded: text_helper
INFO - 2016-02-17 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:32:02 --> Model Class Initialized
INFO - 2016-02-17 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:32:02 --> Final output sent to browser
DEBUG - 2016-02-17 11:32:02 --> Total execution time: 1.1034
INFO - 2016-02-17 11:33:26 --> Config Class Initialized
INFO - 2016-02-17 11:33:26 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:33:26 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:33:26 --> Utf8 Class Initialized
INFO - 2016-02-17 11:33:26 --> URI Class Initialized
DEBUG - 2016-02-17 11:33:26 --> No URI present. Default controller set.
INFO - 2016-02-17 11:33:26 --> Router Class Initialized
INFO - 2016-02-17 11:33:26 --> Output Class Initialized
INFO - 2016-02-17 11:33:26 --> Security Class Initialized
DEBUG - 2016-02-17 11:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:33:26 --> Input Class Initialized
INFO - 2016-02-17 11:33:26 --> Language Class Initialized
INFO - 2016-02-17 11:33:26 --> Loader Class Initialized
INFO - 2016-02-17 11:33:26 --> Helper loaded: url_helper
INFO - 2016-02-17 11:33:26 --> Helper loaded: file_helper
INFO - 2016-02-17 11:33:26 --> Helper loaded: date_helper
INFO - 2016-02-17 11:33:26 --> Helper loaded: form_helper
INFO - 2016-02-17 11:33:26 --> Database Driver Class Initialized
INFO - 2016-02-17 11:33:27 --> Config Class Initialized
INFO - 2016-02-17 11:33:27 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:33:27 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:33:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:33:27 --> Utf8 Class Initialized
INFO - 2016-02-17 11:33:27 --> Controller Class Initialized
INFO - 2016-02-17 11:33:27 --> URI Class Initialized
INFO - 2016-02-17 11:33:27 --> Model Class Initialized
INFO - 2016-02-17 11:33:27 --> Router Class Initialized
INFO - 2016-02-17 11:33:27 --> Model Class Initialized
INFO - 2016-02-17 11:33:27 --> Output Class Initialized
INFO - 2016-02-17 11:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:33:27 --> Security Class Initialized
INFO - 2016-02-17 11:33:27 --> Pagination Class Initialized
INFO - 2016-02-17 11:33:27 --> Helper loaded: text_helper
DEBUG - 2016-02-17 11:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:33:27 --> Helper loaded: cookie_helper
INFO - 2016-02-17 11:33:27 --> Input Class Initialized
INFO - 2016-02-17 14:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:33:27 --> Language Class Initialized
INFO - 2016-02-17 14:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:33:27 --> Loader Class Initialized
INFO - 2016-02-17 14:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:33:27 --> Helper loaded: url_helper
INFO - 2016-02-17 14:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:33:27 --> Helper loaded: file_helper
INFO - 2016-02-17 14:33:27 --> Final output sent to browser
INFO - 2016-02-17 11:33:27 --> Helper loaded: date_helper
DEBUG - 2016-02-17 14:33:27 --> Total execution time: 1.1139
INFO - 2016-02-17 11:33:27 --> Helper loaded: form_helper
INFO - 2016-02-17 11:33:27 --> Database Driver Class Initialized
INFO - 2016-02-17 11:33:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:33:28 --> Controller Class Initialized
INFO - 2016-02-17 11:33:28 --> Model Class Initialized
INFO - 2016-02-17 11:33:28 --> Model Class Initialized
INFO - 2016-02-17 11:33:28 --> Form Validation Class Initialized
INFO - 2016-02-17 11:33:28 --> Helper loaded: text_helper
INFO - 2016-02-17 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:33:28 --> Model Class Initialized
INFO - 2016-02-17 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:33:28 --> Final output sent to browser
DEBUG - 2016-02-17 11:33:28 --> Total execution time: 1.1238
INFO - 2016-02-17 11:33:42 --> Config Class Initialized
INFO - 2016-02-17 11:33:42 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:33:42 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:33:42 --> Utf8 Class Initialized
INFO - 2016-02-17 11:33:42 --> URI Class Initialized
INFO - 2016-02-17 11:33:42 --> Router Class Initialized
INFO - 2016-02-17 11:33:42 --> Output Class Initialized
INFO - 2016-02-17 11:33:42 --> Security Class Initialized
DEBUG - 2016-02-17 11:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:33:42 --> Input Class Initialized
INFO - 2016-02-17 11:33:42 --> Language Class Initialized
INFO - 2016-02-17 11:33:42 --> Loader Class Initialized
INFO - 2016-02-17 11:33:42 --> Helper loaded: url_helper
INFO - 2016-02-17 11:33:42 --> Helper loaded: file_helper
INFO - 2016-02-17 11:33:42 --> Helper loaded: date_helper
INFO - 2016-02-17 11:33:42 --> Helper loaded: form_helper
INFO - 2016-02-17 11:33:42 --> Database Driver Class Initialized
INFO - 2016-02-17 11:33:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:33:43 --> Controller Class Initialized
INFO - 2016-02-17 11:33:43 --> Model Class Initialized
INFO - 2016-02-17 11:33:43 --> Model Class Initialized
INFO - 2016-02-17 11:33:43 --> Form Validation Class Initialized
INFO - 2016-02-17 11:33:43 --> Helper loaded: text_helper
INFO - 2016-02-17 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:33:43 --> Model Class Initialized
INFO - 2016-02-17 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:33:43 --> Final output sent to browser
DEBUG - 2016-02-17 11:33:43 --> Total execution time: 1.1119
INFO - 2016-02-17 11:35:16 --> Config Class Initialized
INFO - 2016-02-17 11:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:35:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:35:16 --> Utf8 Class Initialized
INFO - 2016-02-17 11:35:16 --> URI Class Initialized
DEBUG - 2016-02-17 11:35:16 --> No URI present. Default controller set.
INFO - 2016-02-17 11:35:16 --> Router Class Initialized
INFO - 2016-02-17 11:35:16 --> Output Class Initialized
INFO - 2016-02-17 11:35:16 --> Security Class Initialized
DEBUG - 2016-02-17 11:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:35:16 --> Input Class Initialized
INFO - 2016-02-17 11:35:16 --> Language Class Initialized
INFO - 2016-02-17 11:35:16 --> Loader Class Initialized
INFO - 2016-02-17 11:35:16 --> Helper loaded: url_helper
INFO - 2016-02-17 11:35:16 --> Helper loaded: file_helper
INFO - 2016-02-17 11:35:16 --> Helper loaded: date_helper
INFO - 2016-02-17 11:35:16 --> Helper loaded: form_helper
INFO - 2016-02-17 11:35:16 --> Database Driver Class Initialized
INFO - 2016-02-17 11:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:35:17 --> Controller Class Initialized
INFO - 2016-02-17 11:35:17 --> Model Class Initialized
INFO - 2016-02-17 11:35:17 --> Model Class Initialized
INFO - 2016-02-17 11:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:35:17 --> Pagination Class Initialized
INFO - 2016-02-17 11:35:17 --> Helper loaded: text_helper
INFO - 2016-02-17 11:35:17 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:35:17 --> Final output sent to browser
DEBUG - 2016-02-17 14:35:17 --> Total execution time: 1.1329
INFO - 2016-02-17 11:35:19 --> Config Class Initialized
INFO - 2016-02-17 11:35:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:35:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:35:19 --> Utf8 Class Initialized
INFO - 2016-02-17 11:35:19 --> URI Class Initialized
INFO - 2016-02-17 11:35:19 --> Router Class Initialized
INFO - 2016-02-17 11:35:19 --> Output Class Initialized
INFO - 2016-02-17 11:35:19 --> Security Class Initialized
DEBUG - 2016-02-17 11:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:35:19 --> Input Class Initialized
INFO - 2016-02-17 11:35:19 --> Language Class Initialized
INFO - 2016-02-17 11:35:19 --> Loader Class Initialized
INFO - 2016-02-17 11:35:19 --> Helper loaded: url_helper
INFO - 2016-02-17 11:35:19 --> Helper loaded: file_helper
INFO - 2016-02-17 11:35:19 --> Helper loaded: date_helper
INFO - 2016-02-17 11:35:19 --> Helper loaded: form_helper
INFO - 2016-02-17 11:35:19 --> Database Driver Class Initialized
INFO - 2016-02-17 11:35:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:35:20 --> Controller Class Initialized
INFO - 2016-02-17 11:35:20 --> Model Class Initialized
INFO - 2016-02-17 11:35:20 --> Model Class Initialized
INFO - 2016-02-17 11:35:20 --> Form Validation Class Initialized
INFO - 2016-02-17 11:35:20 --> Helper loaded: text_helper
INFO - 2016-02-17 11:35:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:35:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:35:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:35:20 --> Model Class Initialized
INFO - 2016-02-17 11:35:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:35:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:35:20 --> Final output sent to browser
DEBUG - 2016-02-17 11:35:20 --> Total execution time: 1.0917
INFO - 2016-02-17 11:37:01 --> Config Class Initialized
INFO - 2016-02-17 11:37:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:37:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:37:01 --> Utf8 Class Initialized
INFO - 2016-02-17 11:37:01 --> URI Class Initialized
DEBUG - 2016-02-17 11:37:01 --> No URI present. Default controller set.
INFO - 2016-02-17 11:37:01 --> Router Class Initialized
INFO - 2016-02-17 11:37:01 --> Output Class Initialized
INFO - 2016-02-17 11:37:01 --> Security Class Initialized
DEBUG - 2016-02-17 11:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:37:01 --> Input Class Initialized
INFO - 2016-02-17 11:37:01 --> Language Class Initialized
INFO - 2016-02-17 11:37:01 --> Loader Class Initialized
INFO - 2016-02-17 11:37:01 --> Helper loaded: url_helper
INFO - 2016-02-17 11:37:01 --> Helper loaded: file_helper
INFO - 2016-02-17 11:37:01 --> Helper loaded: date_helper
INFO - 2016-02-17 11:37:01 --> Helper loaded: form_helper
INFO - 2016-02-17 11:37:01 --> Database Driver Class Initialized
INFO - 2016-02-17 11:37:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:37:02 --> Controller Class Initialized
INFO - 2016-02-17 11:37:02 --> Model Class Initialized
INFO - 2016-02-17 11:37:02 --> Model Class Initialized
INFO - 2016-02-17 11:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:37:02 --> Pagination Class Initialized
INFO - 2016-02-17 11:37:02 --> Helper loaded: text_helper
INFO - 2016-02-17 11:37:02 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 14:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 14:37:02 --> Final output sent to browser
DEBUG - 2016-02-17 14:37:02 --> Total execution time: 1.1272
INFO - 2016-02-17 11:37:04 --> Config Class Initialized
INFO - 2016-02-17 11:37:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:37:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:37:04 --> Utf8 Class Initialized
INFO - 2016-02-17 11:37:04 --> URI Class Initialized
INFO - 2016-02-17 11:37:04 --> Router Class Initialized
INFO - 2016-02-17 11:37:04 --> Output Class Initialized
INFO - 2016-02-17 11:37:04 --> Security Class Initialized
DEBUG - 2016-02-17 11:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:37:04 --> Input Class Initialized
INFO - 2016-02-17 11:37:04 --> Language Class Initialized
INFO - 2016-02-17 11:37:04 --> Loader Class Initialized
INFO - 2016-02-17 11:37:04 --> Helper loaded: url_helper
INFO - 2016-02-17 11:37:04 --> Helper loaded: file_helper
INFO - 2016-02-17 11:37:04 --> Helper loaded: date_helper
INFO - 2016-02-17 11:37:04 --> Helper loaded: form_helper
INFO - 2016-02-17 11:37:04 --> Database Driver Class Initialized
INFO - 2016-02-17 11:37:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:37:05 --> Controller Class Initialized
INFO - 2016-02-17 11:37:05 --> Model Class Initialized
INFO - 2016-02-17 11:37:05 --> Model Class Initialized
INFO - 2016-02-17 11:37:05 --> Form Validation Class Initialized
INFO - 2016-02-17 11:37:05 --> Helper loaded: text_helper
INFO - 2016-02-17 11:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:37:05 --> Model Class Initialized
INFO - 2016-02-17 11:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:37:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:37:05 --> Final output sent to browser
DEBUG - 2016-02-17 11:37:05 --> Total execution time: 1.1389
INFO - 2016-02-17 11:37:43 --> Config Class Initialized
INFO - 2016-02-17 11:37:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:37:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:37:43 --> Utf8 Class Initialized
INFO - 2016-02-17 11:37:43 --> URI Class Initialized
DEBUG - 2016-02-17 11:37:43 --> No URI present. Default controller set.
INFO - 2016-02-17 11:37:43 --> Router Class Initialized
INFO - 2016-02-17 11:37:43 --> Output Class Initialized
INFO - 2016-02-17 11:37:43 --> Security Class Initialized
DEBUG - 2016-02-17 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:37:43 --> Input Class Initialized
INFO - 2016-02-17 11:37:43 --> Language Class Initialized
INFO - 2016-02-17 11:37:43 --> Loader Class Initialized
INFO - 2016-02-17 11:37:43 --> Helper loaded: url_helper
INFO - 2016-02-17 11:37:43 --> Helper loaded: file_helper
INFO - 2016-02-17 11:37:43 --> Helper loaded: date_helper
INFO - 2016-02-17 11:37:43 --> Helper loaded: form_helper
INFO - 2016-02-17 11:37:43 --> Database Driver Class Initialized
INFO - 2016-02-17 11:37:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:37:44 --> Controller Class Initialized
INFO - 2016-02-17 11:37:44 --> Model Class Initialized
INFO - 2016-02-17 11:37:44 --> Model Class Initialized
INFO - 2016-02-17 11:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 11:37:44 --> Pagination Class Initialized
INFO - 2016-02-17 11:37:44 --> Helper loaded: text_helper
INFO - 2016-02-17 11:37:44 --> Helper loaded: cookie_helper
INFO - 2016-02-17 14:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 14:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 14:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 11:37:44 --> Config Class Initialized
INFO - 2016-02-17 14:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:37:44 --> Hooks Class Initialized
INFO - 2016-02-17 14:37:44 --> Final output sent to browser
DEBUG - 2016-02-17 11:37:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-17 14:37:44 --> Total execution time: 1.1194
INFO - 2016-02-17 11:37:44 --> Utf8 Class Initialized
INFO - 2016-02-17 11:37:44 --> URI Class Initialized
INFO - 2016-02-17 11:37:44 --> Router Class Initialized
INFO - 2016-02-17 11:37:44 --> Output Class Initialized
INFO - 2016-02-17 11:37:44 --> Security Class Initialized
DEBUG - 2016-02-17 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:37:44 --> Input Class Initialized
INFO - 2016-02-17 11:37:44 --> Language Class Initialized
INFO - 2016-02-17 11:37:44 --> Loader Class Initialized
INFO - 2016-02-17 11:37:44 --> Helper loaded: url_helper
INFO - 2016-02-17 11:37:44 --> Helper loaded: file_helper
INFO - 2016-02-17 11:37:44 --> Helper loaded: date_helper
INFO - 2016-02-17 11:37:44 --> Helper loaded: form_helper
INFO - 2016-02-17 11:37:44 --> Database Driver Class Initialized
INFO - 2016-02-17 11:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:37:45 --> Controller Class Initialized
INFO - 2016-02-17 11:37:45 --> Model Class Initialized
INFO - 2016-02-17 11:37:45 --> Model Class Initialized
INFO - 2016-02-17 11:37:45 --> Form Validation Class Initialized
INFO - 2016-02-17 11:37:45 --> Helper loaded: text_helper
INFO - 2016-02-17 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:37:45 --> Model Class Initialized
INFO - 2016-02-17 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:37:45 --> Final output sent to browser
DEBUG - 2016-02-17 11:37:45 --> Total execution time: 1.1260
INFO - 2016-02-17 11:40:45 --> Config Class Initialized
INFO - 2016-02-17 11:40:45 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:40:45 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:40:45 --> Utf8 Class Initialized
INFO - 2016-02-17 11:40:45 --> URI Class Initialized
INFO - 2016-02-17 11:40:45 --> Router Class Initialized
INFO - 2016-02-17 11:40:45 --> Output Class Initialized
INFO - 2016-02-17 11:40:45 --> Security Class Initialized
DEBUG - 2016-02-17 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:40:45 --> Input Class Initialized
INFO - 2016-02-17 11:40:45 --> Language Class Initialized
INFO - 2016-02-17 11:40:45 --> Loader Class Initialized
INFO - 2016-02-17 11:40:45 --> Helper loaded: url_helper
INFO - 2016-02-17 11:40:45 --> Helper loaded: file_helper
INFO - 2016-02-17 11:40:45 --> Helper loaded: date_helper
INFO - 2016-02-17 11:40:45 --> Helper loaded: form_helper
INFO - 2016-02-17 11:40:45 --> Database Driver Class Initialized
INFO - 2016-02-17 11:40:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:40:46 --> Controller Class Initialized
INFO - 2016-02-17 11:40:46 --> Model Class Initialized
INFO - 2016-02-17 11:40:46 --> Model Class Initialized
INFO - 2016-02-17 11:40:46 --> Form Validation Class Initialized
INFO - 2016-02-17 11:40:46 --> Helper loaded: text_helper
INFO - 2016-02-17 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:40:46 --> Model Class Initialized
INFO - 2016-02-17 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:40:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:40:46 --> Final output sent to browser
DEBUG - 2016-02-17 11:40:46 --> Total execution time: 1.1434
INFO - 2016-02-17 11:54:01 --> Config Class Initialized
INFO - 2016-02-17 11:54:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:54:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:54:01 --> Utf8 Class Initialized
INFO - 2016-02-17 11:54:01 --> URI Class Initialized
INFO - 2016-02-17 11:54:01 --> Router Class Initialized
INFO - 2016-02-17 11:54:01 --> Output Class Initialized
INFO - 2016-02-17 11:54:01 --> Security Class Initialized
DEBUG - 2016-02-17 11:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:54:01 --> Input Class Initialized
INFO - 2016-02-17 11:54:01 --> Language Class Initialized
INFO - 2016-02-17 11:54:01 --> Loader Class Initialized
INFO - 2016-02-17 11:54:01 --> Helper loaded: url_helper
INFO - 2016-02-17 11:54:01 --> Helper loaded: file_helper
INFO - 2016-02-17 11:54:01 --> Helper loaded: date_helper
INFO - 2016-02-17 11:54:01 --> Helper loaded: form_helper
INFO - 2016-02-17 11:54:01 --> Database Driver Class Initialized
INFO - 2016-02-17 11:54:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:54:02 --> Controller Class Initialized
INFO - 2016-02-17 11:54:02 --> Model Class Initialized
INFO - 2016-02-17 11:54:02 --> Model Class Initialized
INFO - 2016-02-17 11:54:02 --> Form Validation Class Initialized
INFO - 2016-02-17 11:54:02 --> Helper loaded: text_helper
INFO - 2016-02-17 11:54:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:54:02 --> Final output sent to browser
DEBUG - 2016-02-17 11:54:02 --> Total execution time: 1.1108
INFO - 2016-02-17 11:54:04 --> Config Class Initialized
INFO - 2016-02-17 11:54:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:54:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:54:04 --> Utf8 Class Initialized
INFO - 2016-02-17 11:54:04 --> URI Class Initialized
INFO - 2016-02-17 11:54:04 --> Router Class Initialized
INFO - 2016-02-17 11:54:04 --> Output Class Initialized
INFO - 2016-02-17 11:54:04 --> Security Class Initialized
DEBUG - 2016-02-17 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:54:04 --> Input Class Initialized
INFO - 2016-02-17 11:54:04 --> Language Class Initialized
INFO - 2016-02-17 11:54:04 --> Loader Class Initialized
INFO - 2016-02-17 11:54:04 --> Helper loaded: url_helper
INFO - 2016-02-17 11:54:04 --> Helper loaded: file_helper
INFO - 2016-02-17 11:54:04 --> Helper loaded: date_helper
INFO - 2016-02-17 11:54:04 --> Helper loaded: form_helper
INFO - 2016-02-17 11:54:04 --> Database Driver Class Initialized
INFO - 2016-02-17 11:54:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:54:05 --> Controller Class Initialized
INFO - 2016-02-17 11:54:05 --> Model Class Initialized
INFO - 2016-02-17 11:54:05 --> Model Class Initialized
INFO - 2016-02-17 11:54:05 --> Form Validation Class Initialized
INFO - 2016-02-17 11:54:05 --> Helper loaded: text_helper
INFO - 2016-02-17 11:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 11:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 11:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 11:54:05 --> Model Class Initialized
INFO - 2016-02-17 11:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 11:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 11:54:05 --> Final output sent to browser
DEBUG - 2016-02-17 11:54:05 --> Total execution time: 1.0918
INFO - 2016-02-17 11:54:49 --> Config Class Initialized
INFO - 2016-02-17 11:54:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 11:54:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 11:54:49 --> Utf8 Class Initialized
INFO - 2016-02-17 11:54:49 --> URI Class Initialized
INFO - 2016-02-17 11:54:49 --> Router Class Initialized
INFO - 2016-02-17 11:54:49 --> Output Class Initialized
INFO - 2016-02-17 11:54:49 --> Security Class Initialized
DEBUG - 2016-02-17 11:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 11:54:49 --> Input Class Initialized
INFO - 2016-02-17 11:54:49 --> Language Class Initialized
INFO - 2016-02-17 11:54:49 --> Loader Class Initialized
INFO - 2016-02-17 11:54:49 --> Helper loaded: url_helper
INFO - 2016-02-17 11:54:49 --> Helper loaded: file_helper
INFO - 2016-02-17 11:54:49 --> Helper loaded: date_helper
INFO - 2016-02-17 11:54:49 --> Helper loaded: form_helper
INFO - 2016-02-17 11:54:49 --> Database Driver Class Initialized
INFO - 2016-02-17 11:54:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 11:54:50 --> Controller Class Initialized
INFO - 2016-02-17 11:54:50 --> Model Class Initialized
INFO - 2016-02-17 11:54:50 --> Model Class Initialized
INFO - 2016-02-17 11:54:50 --> Form Validation Class Initialized
INFO - 2016-02-17 11:54:50 --> Helper loaded: text_helper
INFO - 2016-02-17 11:54:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 11:54:50 --> Final output sent to browser
DEBUG - 2016-02-17 11:54:50 --> Total execution time: 1.1057
INFO - 2016-02-17 12:08:37 --> Config Class Initialized
INFO - 2016-02-17 12:08:37 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:08:37 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:08:37 --> Utf8 Class Initialized
INFO - 2016-02-17 12:08:37 --> URI Class Initialized
INFO - 2016-02-17 12:08:37 --> Router Class Initialized
INFO - 2016-02-17 12:08:37 --> Output Class Initialized
INFO - 2016-02-17 12:08:37 --> Security Class Initialized
DEBUG - 2016-02-17 12:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:08:37 --> Input Class Initialized
INFO - 2016-02-17 12:08:37 --> Language Class Initialized
INFO - 2016-02-17 12:08:37 --> Loader Class Initialized
INFO - 2016-02-17 12:08:37 --> Helper loaded: url_helper
INFO - 2016-02-17 12:08:37 --> Helper loaded: file_helper
INFO - 2016-02-17 12:08:37 --> Helper loaded: date_helper
INFO - 2016-02-17 12:08:37 --> Helper loaded: form_helper
INFO - 2016-02-17 12:08:37 --> Database Driver Class Initialized
INFO - 2016-02-17 12:08:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:08:38 --> Controller Class Initialized
INFO - 2016-02-17 12:08:38 --> Model Class Initialized
INFO - 2016-02-17 12:08:38 --> Model Class Initialized
INFO - 2016-02-17 12:08:38 --> Form Validation Class Initialized
INFO - 2016-02-17 12:08:38 --> Helper loaded: text_helper
INFO - 2016-02-17 12:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 12:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 12:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 12:08:38 --> Model Class Initialized
INFO - 2016-02-17 12:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 12:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 12:08:38 --> Final output sent to browser
DEBUG - 2016-02-17 12:08:38 --> Total execution time: 1.0975
INFO - 2016-02-17 12:08:40 --> Config Class Initialized
INFO - 2016-02-17 12:08:40 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:08:40 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:08:40 --> Utf8 Class Initialized
INFO - 2016-02-17 12:08:40 --> URI Class Initialized
DEBUG - 2016-02-17 12:08:40 --> No URI present. Default controller set.
INFO - 2016-02-17 12:08:40 --> Router Class Initialized
INFO - 2016-02-17 12:08:40 --> Output Class Initialized
INFO - 2016-02-17 12:08:40 --> Security Class Initialized
DEBUG - 2016-02-17 12:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:08:40 --> Input Class Initialized
INFO - 2016-02-17 12:08:40 --> Language Class Initialized
INFO - 2016-02-17 12:08:40 --> Loader Class Initialized
INFO - 2016-02-17 12:08:40 --> Helper loaded: url_helper
INFO - 2016-02-17 12:08:40 --> Helper loaded: file_helper
INFO - 2016-02-17 12:08:40 --> Helper loaded: date_helper
INFO - 2016-02-17 12:08:40 --> Helper loaded: form_helper
INFO - 2016-02-17 12:08:40 --> Database Driver Class Initialized
INFO - 2016-02-17 12:08:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:08:41 --> Controller Class Initialized
INFO - 2016-02-17 12:08:41 --> Model Class Initialized
INFO - 2016-02-17 12:08:41 --> Model Class Initialized
INFO - 2016-02-17 12:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:08:41 --> Pagination Class Initialized
INFO - 2016-02-17 12:08:41 --> Helper loaded: text_helper
INFO - 2016-02-17 12:08:41 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:08:41 --> Final output sent to browser
DEBUG - 2016-02-17 15:08:41 --> Total execution time: 1.1311
INFO - 2016-02-17 12:08:42 --> Config Class Initialized
INFO - 2016-02-17 12:08:42 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:08:42 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:08:42 --> Utf8 Class Initialized
INFO - 2016-02-17 12:08:42 --> URI Class Initialized
INFO - 2016-02-17 12:08:42 --> Router Class Initialized
INFO - 2016-02-17 12:08:42 --> Output Class Initialized
INFO - 2016-02-17 12:08:42 --> Security Class Initialized
DEBUG - 2016-02-17 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:08:42 --> Input Class Initialized
INFO - 2016-02-17 12:08:42 --> Language Class Initialized
INFO - 2016-02-17 12:08:42 --> Loader Class Initialized
INFO - 2016-02-17 12:08:42 --> Helper loaded: url_helper
INFO - 2016-02-17 12:08:42 --> Helper loaded: file_helper
INFO - 2016-02-17 12:08:42 --> Helper loaded: date_helper
INFO - 2016-02-17 12:08:42 --> Helper loaded: form_helper
INFO - 2016-02-17 12:08:42 --> Database Driver Class Initialized
INFO - 2016-02-17 12:08:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:08:43 --> Controller Class Initialized
INFO - 2016-02-17 12:08:43 --> Model Class Initialized
INFO - 2016-02-17 12:08:43 --> Model Class Initialized
INFO - 2016-02-17 12:08:43 --> Form Validation Class Initialized
INFO - 2016-02-17 12:08:43 --> Helper loaded: text_helper
INFO - 2016-02-17 12:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 12:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 12:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 12:08:43 --> Model Class Initialized
INFO - 2016-02-17 12:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 12:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 12:08:43 --> Final output sent to browser
DEBUG - 2016-02-17 12:08:43 --> Total execution time: 1.0891
INFO - 2016-02-17 12:08:44 --> Config Class Initialized
INFO - 2016-02-17 12:08:44 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:08:44 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:08:44 --> Utf8 Class Initialized
INFO - 2016-02-17 12:08:44 --> URI Class Initialized
INFO - 2016-02-17 12:08:44 --> Router Class Initialized
INFO - 2016-02-17 12:08:44 --> Output Class Initialized
INFO - 2016-02-17 12:08:44 --> Security Class Initialized
DEBUG - 2016-02-17 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:08:44 --> Input Class Initialized
INFO - 2016-02-17 12:08:44 --> Language Class Initialized
INFO - 2016-02-17 12:08:44 --> Loader Class Initialized
INFO - 2016-02-17 12:08:44 --> Helper loaded: url_helper
INFO - 2016-02-17 12:08:44 --> Helper loaded: file_helper
INFO - 2016-02-17 12:08:44 --> Helper loaded: date_helper
INFO - 2016-02-17 12:08:44 --> Helper loaded: form_helper
INFO - 2016-02-17 12:08:44 --> Database Driver Class Initialized
INFO - 2016-02-17 12:08:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:08:45 --> Controller Class Initialized
INFO - 2016-02-17 12:08:45 --> Model Class Initialized
INFO - 2016-02-17 12:08:45 --> Model Class Initialized
INFO - 2016-02-17 12:08:45 --> Form Validation Class Initialized
INFO - 2016-02-17 12:08:45 --> Helper loaded: text_helper
INFO - 2016-02-17 12:08:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 12:08:46 --> Final output sent to browser
DEBUG - 2016-02-17 12:08:46 --> Total execution time: 1.0866
INFO - 2016-02-17 12:08:50 --> Config Class Initialized
INFO - 2016-02-17 12:08:50 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:08:50 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:08:50 --> Utf8 Class Initialized
INFO - 2016-02-17 12:08:50 --> URI Class Initialized
INFO - 2016-02-17 12:08:50 --> Router Class Initialized
INFO - 2016-02-17 12:08:50 --> Output Class Initialized
INFO - 2016-02-17 12:08:50 --> Security Class Initialized
DEBUG - 2016-02-17 12:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:08:50 --> Input Class Initialized
INFO - 2016-02-17 12:08:50 --> Language Class Initialized
INFO - 2016-02-17 12:08:50 --> Loader Class Initialized
INFO - 2016-02-17 12:08:50 --> Helper loaded: url_helper
INFO - 2016-02-17 12:08:50 --> Helper loaded: file_helper
INFO - 2016-02-17 12:08:50 --> Helper loaded: date_helper
INFO - 2016-02-17 12:08:50 --> Helper loaded: form_helper
INFO - 2016-02-17 12:08:50 --> Database Driver Class Initialized
INFO - 2016-02-17 12:08:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:08:51 --> Controller Class Initialized
INFO - 2016-02-17 12:08:51 --> Model Class Initialized
INFO - 2016-02-17 12:08:51 --> Model Class Initialized
INFO - 2016-02-17 12:08:51 --> Form Validation Class Initialized
INFO - 2016-02-17 12:08:51 --> Helper loaded: text_helper
INFO - 2016-02-17 12:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 12:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 12:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-17 12:08:51 --> Model Class Initialized
INFO - 2016-02-17 12:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 12:08:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 12:08:51 --> Final output sent to browser
DEBUG - 2016-02-17 12:08:51 --> Total execution time: 1.0986
INFO - 2016-02-17 12:41:25 --> Config Class Initialized
INFO - 2016-02-17 12:41:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:41:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:41:25 --> Utf8 Class Initialized
INFO - 2016-02-17 12:41:25 --> URI Class Initialized
DEBUG - 2016-02-17 12:41:25 --> No URI present. Default controller set.
INFO - 2016-02-17 12:41:25 --> Router Class Initialized
INFO - 2016-02-17 12:41:25 --> Output Class Initialized
INFO - 2016-02-17 12:41:25 --> Security Class Initialized
DEBUG - 2016-02-17 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:41:25 --> Input Class Initialized
INFO - 2016-02-17 12:41:25 --> Language Class Initialized
INFO - 2016-02-17 12:41:25 --> Loader Class Initialized
INFO - 2016-02-17 12:41:25 --> Helper loaded: url_helper
INFO - 2016-02-17 12:41:25 --> Helper loaded: file_helper
INFO - 2016-02-17 12:41:25 --> Helper loaded: date_helper
INFO - 2016-02-17 12:41:25 --> Helper loaded: form_helper
INFO - 2016-02-17 12:41:25 --> Database Driver Class Initialized
INFO - 2016-02-17 12:41:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:41:26 --> Controller Class Initialized
INFO - 2016-02-17 12:41:26 --> Model Class Initialized
INFO - 2016-02-17 12:41:26 --> Model Class Initialized
INFO - 2016-02-17 12:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:41:26 --> Pagination Class Initialized
INFO - 2016-02-17 12:41:26 --> Helper loaded: text_helper
INFO - 2016-02-17 12:41:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:41:26 --> Final output sent to browser
DEBUG - 2016-02-17 15:41:26 --> Total execution time: 1.0857
INFO - 2016-02-17 12:41:28 --> Config Class Initialized
INFO - 2016-02-17 12:41:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:41:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:41:28 --> Utf8 Class Initialized
INFO - 2016-02-17 12:41:28 --> URI Class Initialized
INFO - 2016-02-17 12:41:28 --> Router Class Initialized
INFO - 2016-02-17 12:41:28 --> Output Class Initialized
INFO - 2016-02-17 12:41:28 --> Security Class Initialized
DEBUG - 2016-02-17 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:41:28 --> Input Class Initialized
INFO - 2016-02-17 12:41:28 --> Language Class Initialized
INFO - 2016-02-17 12:41:28 --> Loader Class Initialized
INFO - 2016-02-17 12:41:28 --> Helper loaded: url_helper
INFO - 2016-02-17 12:41:28 --> Helper loaded: file_helper
INFO - 2016-02-17 12:41:28 --> Helper loaded: date_helper
INFO - 2016-02-17 12:41:28 --> Helper loaded: form_helper
INFO - 2016-02-17 12:41:28 --> Database Driver Class Initialized
INFO - 2016-02-17 12:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:41:29 --> Controller Class Initialized
INFO - 2016-02-17 12:41:29 --> Model Class Initialized
INFO - 2016-02-17 12:41:29 --> Model Class Initialized
INFO - 2016-02-17 12:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:41:29 --> Pagination Class Initialized
INFO - 2016-02-17 12:41:29 --> Helper loaded: text_helper
INFO - 2016-02-17 12:41:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 15:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 15:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:41:29 --> Final output sent to browser
DEBUG - 2016-02-17 15:41:29 --> Total execution time: 1.1777
INFO - 2016-02-17 12:41:54 --> Config Class Initialized
INFO - 2016-02-17 12:41:54 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:41:54 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:41:54 --> Utf8 Class Initialized
INFO - 2016-02-17 12:41:54 --> URI Class Initialized
DEBUG - 2016-02-17 12:41:54 --> No URI present. Default controller set.
INFO - 2016-02-17 12:41:54 --> Router Class Initialized
INFO - 2016-02-17 12:41:54 --> Output Class Initialized
INFO - 2016-02-17 12:41:54 --> Security Class Initialized
DEBUG - 2016-02-17 12:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:41:54 --> Input Class Initialized
INFO - 2016-02-17 12:41:54 --> Language Class Initialized
INFO - 2016-02-17 12:41:54 --> Loader Class Initialized
INFO - 2016-02-17 12:41:54 --> Helper loaded: url_helper
INFO - 2016-02-17 12:41:54 --> Helper loaded: file_helper
INFO - 2016-02-17 12:41:54 --> Helper loaded: date_helper
INFO - 2016-02-17 12:41:54 --> Helper loaded: form_helper
INFO - 2016-02-17 12:41:54 --> Database Driver Class Initialized
INFO - 2016-02-17 12:41:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:41:55 --> Controller Class Initialized
INFO - 2016-02-17 12:41:55 --> Model Class Initialized
INFO - 2016-02-17 12:41:55 --> Model Class Initialized
INFO - 2016-02-17 12:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:41:55 --> Pagination Class Initialized
INFO - 2016-02-17 12:41:55 --> Helper loaded: text_helper
INFO - 2016-02-17 12:41:55 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:41:55 --> Final output sent to browser
DEBUG - 2016-02-17 15:41:55 --> Total execution time: 1.1475
INFO - 2016-02-17 12:41:58 --> Config Class Initialized
INFO - 2016-02-17 12:41:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:41:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:41:58 --> Utf8 Class Initialized
INFO - 2016-02-17 12:41:58 --> URI Class Initialized
INFO - 2016-02-17 12:41:58 --> Router Class Initialized
INFO - 2016-02-17 12:41:58 --> Output Class Initialized
INFO - 2016-02-17 12:41:58 --> Security Class Initialized
DEBUG - 2016-02-17 12:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:41:58 --> Input Class Initialized
INFO - 2016-02-17 12:41:58 --> Language Class Initialized
INFO - 2016-02-17 12:41:58 --> Loader Class Initialized
INFO - 2016-02-17 12:41:58 --> Helper loaded: url_helper
INFO - 2016-02-17 12:41:58 --> Helper loaded: file_helper
INFO - 2016-02-17 12:41:58 --> Helper loaded: date_helper
INFO - 2016-02-17 12:41:58 --> Helper loaded: form_helper
INFO - 2016-02-17 12:41:58 --> Database Driver Class Initialized
INFO - 2016-02-17 12:41:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:41:59 --> Controller Class Initialized
INFO - 2016-02-17 12:41:59 --> Model Class Initialized
INFO - 2016-02-17 12:41:59 --> Model Class Initialized
INFO - 2016-02-17 12:41:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:41:59 --> Pagination Class Initialized
INFO - 2016-02-17 12:41:59 --> Helper loaded: text_helper
INFO - 2016-02-17 12:41:59 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 15:41:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:41:59 --> Final output sent to browser
DEBUG - 2016-02-17 15:41:59 --> Total execution time: 1.1247
INFO - 2016-02-17 12:42:55 --> Config Class Initialized
INFO - 2016-02-17 12:42:55 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:42:55 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:42:55 --> Utf8 Class Initialized
INFO - 2016-02-17 12:42:55 --> URI Class Initialized
DEBUG - 2016-02-17 12:42:55 --> No URI present. Default controller set.
INFO - 2016-02-17 12:42:55 --> Router Class Initialized
INFO - 2016-02-17 12:42:55 --> Output Class Initialized
INFO - 2016-02-17 12:42:55 --> Security Class Initialized
DEBUG - 2016-02-17 12:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:42:55 --> Input Class Initialized
INFO - 2016-02-17 12:42:55 --> Language Class Initialized
INFO - 2016-02-17 12:42:55 --> Loader Class Initialized
INFO - 2016-02-17 12:42:55 --> Helper loaded: url_helper
INFO - 2016-02-17 12:42:55 --> Helper loaded: file_helper
INFO - 2016-02-17 12:42:55 --> Helper loaded: date_helper
INFO - 2016-02-17 12:42:55 --> Helper loaded: form_helper
INFO - 2016-02-17 12:42:55 --> Database Driver Class Initialized
INFO - 2016-02-17 12:42:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:42:56 --> Controller Class Initialized
INFO - 2016-02-17 12:42:56 --> Model Class Initialized
INFO - 2016-02-17 12:42:56 --> Model Class Initialized
INFO - 2016-02-17 12:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:42:56 --> Pagination Class Initialized
INFO - 2016-02-17 12:42:56 --> Helper loaded: text_helper
INFO - 2016-02-17 12:42:56 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:42:56 --> Final output sent to browser
DEBUG - 2016-02-17 15:42:56 --> Total execution time: 1.0964
INFO - 2016-02-17 12:43:25 --> Config Class Initialized
INFO - 2016-02-17 12:43:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:43:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:43:25 --> Utf8 Class Initialized
INFO - 2016-02-17 12:43:25 --> URI Class Initialized
DEBUG - 2016-02-17 12:43:25 --> No URI present. Default controller set.
INFO - 2016-02-17 12:43:25 --> Router Class Initialized
INFO - 2016-02-17 12:43:25 --> Output Class Initialized
INFO - 2016-02-17 12:43:25 --> Security Class Initialized
DEBUG - 2016-02-17 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:43:25 --> Input Class Initialized
INFO - 2016-02-17 12:43:25 --> Language Class Initialized
INFO - 2016-02-17 12:43:25 --> Loader Class Initialized
INFO - 2016-02-17 12:43:25 --> Helper loaded: url_helper
INFO - 2016-02-17 12:43:25 --> Helper loaded: file_helper
INFO - 2016-02-17 12:43:25 --> Helper loaded: date_helper
INFO - 2016-02-17 12:43:25 --> Helper loaded: form_helper
INFO - 2016-02-17 12:43:25 --> Database Driver Class Initialized
INFO - 2016-02-17 12:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:43:26 --> Controller Class Initialized
INFO - 2016-02-17 12:43:26 --> Model Class Initialized
INFO - 2016-02-17 12:43:26 --> Model Class Initialized
INFO - 2016-02-17 12:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:43:26 --> Pagination Class Initialized
INFO - 2016-02-17 12:43:26 --> Helper loaded: text_helper
INFO - 2016-02-17 12:43:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:43:26 --> Final output sent to browser
DEBUG - 2016-02-17 15:43:26 --> Total execution time: 1.1485
INFO - 2016-02-17 12:43:31 --> Config Class Initialized
INFO - 2016-02-17 12:43:31 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:43:31 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:43:31 --> Utf8 Class Initialized
INFO - 2016-02-17 12:43:31 --> URI Class Initialized
INFO - 2016-02-17 12:43:31 --> Router Class Initialized
INFO - 2016-02-17 12:43:31 --> Output Class Initialized
INFO - 2016-02-17 12:43:31 --> Security Class Initialized
DEBUG - 2016-02-17 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:43:31 --> Input Class Initialized
INFO - 2016-02-17 12:43:31 --> Language Class Initialized
INFO - 2016-02-17 12:43:31 --> Loader Class Initialized
INFO - 2016-02-17 12:43:31 --> Helper loaded: url_helper
INFO - 2016-02-17 12:43:31 --> Helper loaded: file_helper
INFO - 2016-02-17 12:43:31 --> Helper loaded: date_helper
INFO - 2016-02-17 12:43:31 --> Helper loaded: form_helper
INFO - 2016-02-17 12:43:31 --> Database Driver Class Initialized
INFO - 2016-02-17 12:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:43:32 --> Controller Class Initialized
INFO - 2016-02-17 12:43:32 --> Model Class Initialized
INFO - 2016-02-17 12:43:32 --> Model Class Initialized
INFO - 2016-02-17 12:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:43:32 --> Pagination Class Initialized
INFO - 2016-02-17 12:43:32 --> Helper loaded: text_helper
INFO - 2016-02-17 12:43:32 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 15:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 15:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:43:32 --> Final output sent to browser
DEBUG - 2016-02-17 15:43:32 --> Total execution time: 1.1699
INFO - 2016-02-17 12:54:48 --> Config Class Initialized
INFO - 2016-02-17 12:54:48 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:54:48 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:54:48 --> Utf8 Class Initialized
INFO - 2016-02-17 12:54:48 --> URI Class Initialized
INFO - 2016-02-17 12:54:48 --> Router Class Initialized
INFO - 2016-02-17 12:54:48 --> Output Class Initialized
INFO - 2016-02-17 12:54:48 --> Security Class Initialized
DEBUG - 2016-02-17 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:54:48 --> Input Class Initialized
INFO - 2016-02-17 12:54:48 --> Language Class Initialized
INFO - 2016-02-17 12:54:48 --> Loader Class Initialized
INFO - 2016-02-17 12:54:48 --> Helper loaded: url_helper
INFO - 2016-02-17 12:54:48 --> Helper loaded: file_helper
INFO - 2016-02-17 12:54:48 --> Helper loaded: date_helper
INFO - 2016-02-17 12:54:48 --> Helper loaded: form_helper
INFO - 2016-02-17 12:54:48 --> Database Driver Class Initialized
INFO - 2016-02-17 12:54:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:54:49 --> Controller Class Initialized
INFO - 2016-02-17 12:54:49 --> Model Class Initialized
INFO - 2016-02-17 12:54:49 --> Model Class Initialized
INFO - 2016-02-17 12:54:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:54:49 --> Pagination Class Initialized
INFO - 2016-02-17 12:54:49 --> Helper loaded: text_helper
INFO - 2016-02-17 12:54:49 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:54:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:54:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:54:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 15:54:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 15:54:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:54:49 --> Final output sent to browser
DEBUG - 2016-02-17 15:54:49 --> Total execution time: 1.1821
INFO - 2016-02-17 12:55:45 --> Config Class Initialized
INFO - 2016-02-17 12:55:45 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:55:45 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:55:45 --> Utf8 Class Initialized
INFO - 2016-02-17 12:55:45 --> URI Class Initialized
INFO - 2016-02-17 12:55:45 --> Router Class Initialized
INFO - 2016-02-17 12:55:45 --> Output Class Initialized
INFO - 2016-02-17 12:55:45 --> Security Class Initialized
DEBUG - 2016-02-17 12:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:55:45 --> Input Class Initialized
INFO - 2016-02-17 12:55:45 --> Language Class Initialized
INFO - 2016-02-17 12:55:45 --> Loader Class Initialized
INFO - 2016-02-17 12:55:45 --> Helper loaded: url_helper
INFO - 2016-02-17 12:55:45 --> Helper loaded: file_helper
INFO - 2016-02-17 12:55:45 --> Helper loaded: date_helper
INFO - 2016-02-17 12:55:45 --> Helper loaded: form_helper
INFO - 2016-02-17 12:55:45 --> Database Driver Class Initialized
INFO - 2016-02-17 12:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:55:46 --> Controller Class Initialized
INFO - 2016-02-17 12:55:46 --> Model Class Initialized
INFO - 2016-02-17 12:55:46 --> Model Class Initialized
INFO - 2016-02-17 12:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:55:46 --> Pagination Class Initialized
INFO - 2016-02-17 12:55:46 --> Helper loaded: text_helper
INFO - 2016-02-17 12:55:46 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 15:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 15:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:55:46 --> Final output sent to browser
DEBUG - 2016-02-17 15:55:46 --> Total execution time: 1.1683
INFO - 2016-02-17 12:56:19 --> Config Class Initialized
INFO - 2016-02-17 12:56:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:56:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:56:19 --> Utf8 Class Initialized
INFO - 2016-02-17 12:56:19 --> URI Class Initialized
DEBUG - 2016-02-17 12:56:19 --> No URI present. Default controller set.
INFO - 2016-02-17 12:56:19 --> Router Class Initialized
INFO - 2016-02-17 12:56:19 --> Output Class Initialized
INFO - 2016-02-17 12:56:19 --> Security Class Initialized
DEBUG - 2016-02-17 12:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:56:19 --> Input Class Initialized
INFO - 2016-02-17 12:56:19 --> Language Class Initialized
INFO - 2016-02-17 12:56:19 --> Loader Class Initialized
INFO - 2016-02-17 12:56:19 --> Helper loaded: url_helper
INFO - 2016-02-17 12:56:19 --> Helper loaded: file_helper
INFO - 2016-02-17 12:56:19 --> Helper loaded: date_helper
INFO - 2016-02-17 12:56:19 --> Helper loaded: form_helper
INFO - 2016-02-17 12:56:19 --> Database Driver Class Initialized
INFO - 2016-02-17 12:56:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:56:20 --> Controller Class Initialized
INFO - 2016-02-17 12:56:20 --> Model Class Initialized
INFO - 2016-02-17 12:56:20 --> Model Class Initialized
INFO - 2016-02-17 12:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:56:20 --> Pagination Class Initialized
INFO - 2016-02-17 12:56:20 --> Helper loaded: text_helper
INFO - 2016-02-17 12:56:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:56:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:56:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:56:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:56:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:56:20 --> Final output sent to browser
DEBUG - 2016-02-17 15:56:20 --> Total execution time: 1.0858
INFO - 2016-02-17 12:56:22 --> Config Class Initialized
INFO - 2016-02-17 12:56:22 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:56:22 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:56:22 --> Utf8 Class Initialized
INFO - 2016-02-17 12:56:22 --> URI Class Initialized
INFO - 2016-02-17 12:56:22 --> Router Class Initialized
INFO - 2016-02-17 12:56:22 --> Output Class Initialized
INFO - 2016-02-17 12:56:22 --> Security Class Initialized
DEBUG - 2016-02-17 12:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:56:22 --> Input Class Initialized
INFO - 2016-02-17 12:56:22 --> Language Class Initialized
INFO - 2016-02-17 12:56:22 --> Loader Class Initialized
INFO - 2016-02-17 12:56:22 --> Helper loaded: url_helper
INFO - 2016-02-17 12:56:22 --> Helper loaded: file_helper
INFO - 2016-02-17 12:56:22 --> Helper loaded: date_helper
INFO - 2016-02-17 12:56:22 --> Helper loaded: form_helper
INFO - 2016-02-17 12:56:22 --> Database Driver Class Initialized
INFO - 2016-02-17 12:56:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:56:23 --> Controller Class Initialized
INFO - 2016-02-17 12:56:23 --> Model Class Initialized
INFO - 2016-02-17 12:56:23 --> Model Class Initialized
INFO - 2016-02-17 12:56:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:56:23 --> Pagination Class Initialized
INFO - 2016-02-17 12:56:23 --> Helper loaded: text_helper
INFO - 2016-02-17 12:56:23 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:56:23 --> Form Validation Class Initialized
INFO - 2016-02-17 15:56:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 15:56:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:56:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:56:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 15:56:23 --> Final output sent to browser
DEBUG - 2016-02-17 15:56:23 --> Total execution time: 1.1394
INFO - 2016-02-17 12:56:25 --> Config Class Initialized
INFO - 2016-02-17 12:56:25 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:56:25 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:56:25 --> Utf8 Class Initialized
INFO - 2016-02-17 12:56:25 --> URI Class Initialized
DEBUG - 2016-02-17 12:56:25 --> No URI present. Default controller set.
INFO - 2016-02-17 12:56:25 --> Router Class Initialized
INFO - 2016-02-17 12:56:25 --> Output Class Initialized
INFO - 2016-02-17 12:56:25 --> Security Class Initialized
DEBUG - 2016-02-17 12:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:56:25 --> Input Class Initialized
INFO - 2016-02-17 12:56:25 --> Language Class Initialized
INFO - 2016-02-17 12:56:25 --> Loader Class Initialized
INFO - 2016-02-17 12:56:25 --> Helper loaded: url_helper
INFO - 2016-02-17 12:56:25 --> Helper loaded: file_helper
INFO - 2016-02-17 12:56:25 --> Helper loaded: date_helper
INFO - 2016-02-17 12:56:25 --> Helper loaded: form_helper
INFO - 2016-02-17 12:56:25 --> Database Driver Class Initialized
INFO - 2016-02-17 12:56:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:56:26 --> Controller Class Initialized
INFO - 2016-02-17 12:56:26 --> Model Class Initialized
INFO - 2016-02-17 12:56:26 --> Model Class Initialized
INFO - 2016-02-17 12:56:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:56:26 --> Pagination Class Initialized
INFO - 2016-02-17 12:56:26 --> Helper loaded: text_helper
INFO - 2016-02-17 12:56:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:56:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:56:26 --> Final output sent to browser
DEBUG - 2016-02-17 15:56:26 --> Total execution time: 1.0967
INFO - 2016-02-17 12:56:33 --> Config Class Initialized
INFO - 2016-02-17 12:56:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:56:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:56:33 --> Utf8 Class Initialized
INFO - 2016-02-17 12:56:33 --> URI Class Initialized
DEBUG - 2016-02-17 12:56:33 --> No URI present. Default controller set.
INFO - 2016-02-17 12:56:33 --> Router Class Initialized
INFO - 2016-02-17 12:56:33 --> Output Class Initialized
INFO - 2016-02-17 12:56:33 --> Security Class Initialized
DEBUG - 2016-02-17 12:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:56:33 --> Input Class Initialized
INFO - 2016-02-17 12:56:33 --> Language Class Initialized
INFO - 2016-02-17 12:56:33 --> Loader Class Initialized
INFO - 2016-02-17 12:56:33 --> Helper loaded: url_helper
INFO - 2016-02-17 12:56:33 --> Helper loaded: file_helper
INFO - 2016-02-17 12:56:33 --> Helper loaded: date_helper
INFO - 2016-02-17 12:56:33 --> Helper loaded: form_helper
INFO - 2016-02-17 12:56:33 --> Database Driver Class Initialized
INFO - 2016-02-17 12:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:56:34 --> Controller Class Initialized
INFO - 2016-02-17 12:56:34 --> Model Class Initialized
INFO - 2016-02-17 12:56:34 --> Model Class Initialized
INFO - 2016-02-17 12:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:56:34 --> Pagination Class Initialized
INFO - 2016-02-17 12:56:34 --> Helper loaded: text_helper
INFO - 2016-02-17 12:56:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:56:34 --> Final output sent to browser
DEBUG - 2016-02-17 15:56:34 --> Total execution time: 1.1346
INFO - 2016-02-17 12:58:47 --> Config Class Initialized
INFO - 2016-02-17 12:58:47 --> Hooks Class Initialized
DEBUG - 2016-02-17 12:58:47 --> UTF-8 Support Enabled
INFO - 2016-02-17 12:58:47 --> Utf8 Class Initialized
INFO - 2016-02-17 12:58:47 --> URI Class Initialized
DEBUG - 2016-02-17 12:58:47 --> No URI present. Default controller set.
INFO - 2016-02-17 12:58:47 --> Router Class Initialized
INFO - 2016-02-17 12:58:47 --> Output Class Initialized
INFO - 2016-02-17 12:58:47 --> Security Class Initialized
DEBUG - 2016-02-17 12:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 12:58:47 --> Input Class Initialized
INFO - 2016-02-17 12:58:47 --> Language Class Initialized
INFO - 2016-02-17 12:58:47 --> Loader Class Initialized
INFO - 2016-02-17 12:58:47 --> Helper loaded: url_helper
INFO - 2016-02-17 12:58:47 --> Helper loaded: file_helper
INFO - 2016-02-17 12:58:47 --> Helper loaded: date_helper
INFO - 2016-02-17 12:58:47 --> Helper loaded: form_helper
INFO - 2016-02-17 12:58:47 --> Database Driver Class Initialized
INFO - 2016-02-17 12:58:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 12:58:48 --> Controller Class Initialized
INFO - 2016-02-17 12:58:48 --> Model Class Initialized
INFO - 2016-02-17 12:58:48 --> Model Class Initialized
INFO - 2016-02-17 12:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 12:58:48 --> Pagination Class Initialized
INFO - 2016-02-17 12:58:48 --> Helper loaded: text_helper
INFO - 2016-02-17 12:58:48 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 15:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 15:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 15:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 15:58:48 --> Final output sent to browser
DEBUG - 2016-02-17 15:58:48 --> Total execution time: 1.0958
INFO - 2016-02-17 13:00:19 --> Config Class Initialized
INFO - 2016-02-17 13:00:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:00:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:00:19 --> Utf8 Class Initialized
INFO - 2016-02-17 13:00:19 --> URI Class Initialized
DEBUG - 2016-02-17 13:00:19 --> No URI present. Default controller set.
INFO - 2016-02-17 13:00:19 --> Router Class Initialized
INFO - 2016-02-17 13:00:19 --> Output Class Initialized
INFO - 2016-02-17 13:00:19 --> Security Class Initialized
DEBUG - 2016-02-17 13:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:00:19 --> Input Class Initialized
INFO - 2016-02-17 13:00:19 --> Language Class Initialized
INFO - 2016-02-17 13:00:19 --> Loader Class Initialized
INFO - 2016-02-17 13:00:19 --> Helper loaded: url_helper
INFO - 2016-02-17 13:00:19 --> Helper loaded: file_helper
INFO - 2016-02-17 13:00:19 --> Helper loaded: date_helper
INFO - 2016-02-17 13:00:19 --> Helper loaded: form_helper
INFO - 2016-02-17 13:00:19 --> Database Driver Class Initialized
INFO - 2016-02-17 13:00:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:00:20 --> Controller Class Initialized
INFO - 2016-02-17 13:00:20 --> Model Class Initialized
INFO - 2016-02-17 13:00:20 --> Model Class Initialized
INFO - 2016-02-17 13:00:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:00:20 --> Pagination Class Initialized
INFO - 2016-02-17 13:00:20 --> Helper loaded: text_helper
INFO - 2016-02-17 13:00:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:00:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:00:20 --> Final output sent to browser
DEBUG - 2016-02-17 16:00:21 --> Total execution time: 1.1402
INFO - 2016-02-17 13:00:42 --> Config Class Initialized
INFO - 2016-02-17 13:00:42 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:00:42 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:00:42 --> Utf8 Class Initialized
INFO - 2016-02-17 13:00:42 --> URI Class Initialized
DEBUG - 2016-02-17 13:00:42 --> No URI present. Default controller set.
INFO - 2016-02-17 13:00:42 --> Router Class Initialized
INFO - 2016-02-17 13:00:42 --> Output Class Initialized
INFO - 2016-02-17 13:00:42 --> Security Class Initialized
DEBUG - 2016-02-17 13:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:00:42 --> Input Class Initialized
INFO - 2016-02-17 13:00:42 --> Language Class Initialized
INFO - 2016-02-17 13:00:42 --> Loader Class Initialized
INFO - 2016-02-17 13:00:42 --> Helper loaded: url_helper
INFO - 2016-02-17 13:00:42 --> Helper loaded: file_helper
INFO - 2016-02-17 13:00:42 --> Helper loaded: date_helper
INFO - 2016-02-17 13:00:42 --> Helper loaded: form_helper
INFO - 2016-02-17 13:00:42 --> Database Driver Class Initialized
INFO - 2016-02-17 13:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:00:43 --> Controller Class Initialized
INFO - 2016-02-17 13:00:43 --> Model Class Initialized
INFO - 2016-02-17 13:00:43 --> Model Class Initialized
INFO - 2016-02-17 13:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:00:43 --> Pagination Class Initialized
INFO - 2016-02-17 13:00:43 --> Helper loaded: text_helper
INFO - 2016-02-17 13:00:43 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:00:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:00:43 --> Final output sent to browser
DEBUG - 2016-02-17 16:00:43 --> Total execution time: 1.1064
INFO - 2016-02-17 13:02:20 --> Config Class Initialized
INFO - 2016-02-17 13:02:20 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:02:20 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:02:20 --> Utf8 Class Initialized
INFO - 2016-02-17 13:02:20 --> URI Class Initialized
DEBUG - 2016-02-17 13:02:20 --> No URI present. Default controller set.
INFO - 2016-02-17 13:02:20 --> Router Class Initialized
INFO - 2016-02-17 13:02:20 --> Output Class Initialized
INFO - 2016-02-17 13:02:20 --> Security Class Initialized
DEBUG - 2016-02-17 13:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:02:20 --> Input Class Initialized
INFO - 2016-02-17 13:02:20 --> Language Class Initialized
INFO - 2016-02-17 13:02:20 --> Loader Class Initialized
INFO - 2016-02-17 13:02:20 --> Helper loaded: url_helper
INFO - 2016-02-17 13:02:20 --> Helper loaded: file_helper
INFO - 2016-02-17 13:02:20 --> Helper loaded: date_helper
INFO - 2016-02-17 13:02:20 --> Helper loaded: form_helper
INFO - 2016-02-17 13:02:20 --> Database Driver Class Initialized
INFO - 2016-02-17 13:02:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:02:21 --> Controller Class Initialized
INFO - 2016-02-17 13:02:21 --> Model Class Initialized
INFO - 2016-02-17 13:02:21 --> Model Class Initialized
INFO - 2016-02-17 13:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:02:21 --> Pagination Class Initialized
INFO - 2016-02-17 13:02:21 --> Helper loaded: text_helper
INFO - 2016-02-17 13:02:21 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:02:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:02:21 --> Final output sent to browser
DEBUG - 2016-02-17 16:02:21 --> Total execution time: 1.1581
INFO - 2016-02-17 13:05:35 --> Config Class Initialized
INFO - 2016-02-17 13:05:35 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:05:35 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:05:35 --> Utf8 Class Initialized
INFO - 2016-02-17 13:05:35 --> URI Class Initialized
DEBUG - 2016-02-17 13:05:35 --> No URI present. Default controller set.
INFO - 2016-02-17 13:05:35 --> Router Class Initialized
INFO - 2016-02-17 13:05:35 --> Output Class Initialized
INFO - 2016-02-17 13:05:35 --> Security Class Initialized
DEBUG - 2016-02-17 13:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:05:35 --> Input Class Initialized
INFO - 2016-02-17 13:05:35 --> Language Class Initialized
INFO - 2016-02-17 13:05:35 --> Loader Class Initialized
INFO - 2016-02-17 13:05:35 --> Helper loaded: url_helper
INFO - 2016-02-17 13:05:35 --> Helper loaded: file_helper
INFO - 2016-02-17 13:05:35 --> Helper loaded: date_helper
INFO - 2016-02-17 13:05:35 --> Helper loaded: form_helper
INFO - 2016-02-17 13:05:35 --> Database Driver Class Initialized
INFO - 2016-02-17 13:05:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:05:36 --> Controller Class Initialized
INFO - 2016-02-17 13:05:36 --> Model Class Initialized
INFO - 2016-02-17 13:05:36 --> Model Class Initialized
INFO - 2016-02-17 13:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:05:37 --> Pagination Class Initialized
INFO - 2016-02-17 13:05:37 --> Helper loaded: text_helper
INFO - 2016-02-17 13:05:37 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:05:37 --> Final output sent to browser
DEBUG - 2016-02-17 16:05:37 --> Total execution time: 1.1487
INFO - 2016-02-17 13:05:43 --> Config Class Initialized
INFO - 2016-02-17 13:05:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:05:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:05:43 --> Utf8 Class Initialized
INFO - 2016-02-17 13:05:43 --> URI Class Initialized
INFO - 2016-02-17 13:05:43 --> Router Class Initialized
INFO - 2016-02-17 13:05:43 --> Output Class Initialized
INFO - 2016-02-17 13:05:43 --> Security Class Initialized
DEBUG - 2016-02-17 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:05:43 --> Input Class Initialized
INFO - 2016-02-17 13:05:43 --> Language Class Initialized
INFO - 2016-02-17 13:05:43 --> Loader Class Initialized
INFO - 2016-02-17 13:05:43 --> Helper loaded: url_helper
INFO - 2016-02-17 13:05:43 --> Helper loaded: file_helper
INFO - 2016-02-17 13:05:43 --> Helper loaded: date_helper
INFO - 2016-02-17 13:05:43 --> Helper loaded: form_helper
INFO - 2016-02-17 13:05:43 --> Database Driver Class Initialized
INFO - 2016-02-17 13:05:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:05:44 --> Controller Class Initialized
INFO - 2016-02-17 13:05:44 --> Model Class Initialized
INFO - 2016-02-17 13:05:44 --> Model Class Initialized
INFO - 2016-02-17 13:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:05:44 --> Pagination Class Initialized
INFO - 2016-02-17 13:05:44 --> Helper loaded: text_helper
INFO - 2016-02-17 13:05:44 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:05:44 --> Final output sent to browser
DEBUG - 2016-02-17 16:05:44 --> Total execution time: 1.1974
INFO - 2016-02-17 13:06:09 --> Config Class Initialized
INFO - 2016-02-17 13:06:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:06:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:06:09 --> Utf8 Class Initialized
INFO - 2016-02-17 13:06:09 --> URI Class Initialized
INFO - 2016-02-17 13:06:09 --> Router Class Initialized
INFO - 2016-02-17 13:06:09 --> Output Class Initialized
INFO - 2016-02-17 13:06:09 --> Security Class Initialized
DEBUG - 2016-02-17 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:06:09 --> Input Class Initialized
INFO - 2016-02-17 13:06:09 --> Language Class Initialized
INFO - 2016-02-17 13:06:09 --> Loader Class Initialized
INFO - 2016-02-17 13:06:09 --> Helper loaded: url_helper
INFO - 2016-02-17 13:06:09 --> Helper loaded: file_helper
INFO - 2016-02-17 13:06:09 --> Helper loaded: date_helper
INFO - 2016-02-17 13:06:09 --> Helper loaded: form_helper
INFO - 2016-02-17 13:06:09 --> Database Driver Class Initialized
INFO - 2016-02-17 13:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:06:10 --> Controller Class Initialized
INFO - 2016-02-17 13:06:10 --> Model Class Initialized
INFO - 2016-02-17 13:06:10 --> Model Class Initialized
INFO - 2016-02-17 13:06:10 --> Form Validation Class Initialized
INFO - 2016-02-17 13:06:10 --> Helper loaded: text_helper
ERROR - 2016-02-17 13:06:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-17 13:06:10 --> Config Class Initialized
INFO - 2016-02-17 13:06:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:06:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:06:10 --> Utf8 Class Initialized
INFO - 2016-02-17 13:06:10 --> URI Class Initialized
INFO - 2016-02-17 13:06:10 --> Router Class Initialized
INFO - 2016-02-17 13:06:10 --> Output Class Initialized
INFO - 2016-02-17 13:06:10 --> Security Class Initialized
DEBUG - 2016-02-17 13:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:06:10 --> Input Class Initialized
INFO - 2016-02-17 13:06:10 --> Language Class Initialized
INFO - 2016-02-17 13:06:10 --> Loader Class Initialized
INFO - 2016-02-17 13:06:10 --> Helper loaded: url_helper
INFO - 2016-02-17 13:06:10 --> Helper loaded: file_helper
INFO - 2016-02-17 13:06:10 --> Helper loaded: date_helper
INFO - 2016-02-17 13:06:10 --> Helper loaded: form_helper
INFO - 2016-02-17 13:06:10 --> Database Driver Class Initialized
INFO - 2016-02-17 13:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:06:11 --> Controller Class Initialized
INFO - 2016-02-17 13:06:11 --> Model Class Initialized
INFO - 2016-02-17 13:06:11 --> Model Class Initialized
INFO - 2016-02-17 13:06:11 --> Form Validation Class Initialized
INFO - 2016-02-17 13:06:11 --> Helper loaded: text_helper
INFO - 2016-02-17 13:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-17 13:06:11 --> Final output sent to browser
DEBUG - 2016-02-17 13:06:11 --> Total execution time: 1.1307
INFO - 2016-02-17 13:24:19 --> Config Class Initialized
INFO - 2016-02-17 13:24:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:24:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:24:19 --> Utf8 Class Initialized
INFO - 2016-02-17 13:24:19 --> URI Class Initialized
DEBUG - 2016-02-17 13:24:19 --> No URI present. Default controller set.
INFO - 2016-02-17 13:24:19 --> Router Class Initialized
INFO - 2016-02-17 13:24:19 --> Output Class Initialized
INFO - 2016-02-17 13:24:19 --> Security Class Initialized
DEBUG - 2016-02-17 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:24:19 --> Input Class Initialized
INFO - 2016-02-17 13:24:19 --> Language Class Initialized
INFO - 2016-02-17 13:24:19 --> Loader Class Initialized
INFO - 2016-02-17 13:24:19 --> Helper loaded: url_helper
INFO - 2016-02-17 13:24:19 --> Helper loaded: file_helper
INFO - 2016-02-17 13:24:19 --> Helper loaded: date_helper
INFO - 2016-02-17 13:24:19 --> Helper loaded: form_helper
INFO - 2016-02-17 13:24:19 --> Database Driver Class Initialized
INFO - 2016-02-17 13:24:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:24:20 --> Controller Class Initialized
INFO - 2016-02-17 13:24:20 --> Model Class Initialized
INFO - 2016-02-17 13:24:20 --> Model Class Initialized
INFO - 2016-02-17 13:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:24:20 --> Pagination Class Initialized
INFO - 2016-02-17 13:24:20 --> Helper loaded: text_helper
INFO - 2016-02-17 13:24:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:24:20 --> Final output sent to browser
DEBUG - 2016-02-17 16:24:20 --> Total execution time: 1.1317
INFO - 2016-02-17 13:24:26 --> Config Class Initialized
INFO - 2016-02-17 13:24:26 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:24:26 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:24:26 --> Utf8 Class Initialized
INFO - 2016-02-17 13:24:26 --> URI Class Initialized
DEBUG - 2016-02-17 13:24:26 --> No URI present. Default controller set.
INFO - 2016-02-17 13:24:26 --> Router Class Initialized
INFO - 2016-02-17 13:24:26 --> Output Class Initialized
INFO - 2016-02-17 13:24:26 --> Security Class Initialized
DEBUG - 2016-02-17 13:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:24:26 --> Input Class Initialized
INFO - 2016-02-17 13:24:26 --> Language Class Initialized
INFO - 2016-02-17 13:24:26 --> Loader Class Initialized
INFO - 2016-02-17 13:24:26 --> Helper loaded: url_helper
INFO - 2016-02-17 13:24:26 --> Helper loaded: file_helper
INFO - 2016-02-17 13:24:26 --> Helper loaded: date_helper
INFO - 2016-02-17 13:24:26 --> Helper loaded: form_helper
INFO - 2016-02-17 13:24:26 --> Database Driver Class Initialized
INFO - 2016-02-17 13:24:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:24:27 --> Controller Class Initialized
INFO - 2016-02-17 13:24:27 --> Model Class Initialized
INFO - 2016-02-17 13:24:27 --> Model Class Initialized
INFO - 2016-02-17 13:24:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:24:27 --> Pagination Class Initialized
INFO - 2016-02-17 13:24:27 --> Helper loaded: text_helper
INFO - 2016-02-17 13:24:27 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:24:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:24:27 --> Final output sent to browser
DEBUG - 2016-02-17 16:24:27 --> Total execution time: 1.1877
INFO - 2016-02-17 13:24:48 --> Config Class Initialized
INFO - 2016-02-17 13:24:48 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:24:48 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:24:48 --> Utf8 Class Initialized
INFO - 2016-02-17 13:24:48 --> URI Class Initialized
INFO - 2016-02-17 13:24:48 --> Router Class Initialized
INFO - 2016-02-17 13:24:48 --> Output Class Initialized
INFO - 2016-02-17 13:24:48 --> Security Class Initialized
DEBUG - 2016-02-17 13:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:24:48 --> Input Class Initialized
INFO - 2016-02-17 13:24:48 --> Language Class Initialized
INFO - 2016-02-17 13:24:48 --> Loader Class Initialized
INFO - 2016-02-17 13:24:48 --> Helper loaded: url_helper
INFO - 2016-02-17 13:24:48 --> Helper loaded: file_helper
INFO - 2016-02-17 13:24:48 --> Helper loaded: date_helper
INFO - 2016-02-17 13:24:48 --> Helper loaded: form_helper
INFO - 2016-02-17 13:24:48 --> Database Driver Class Initialized
INFO - 2016-02-17 13:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:24:49 --> Controller Class Initialized
INFO - 2016-02-17 13:24:49 --> Model Class Initialized
INFO - 2016-02-17 13:24:49 --> Model Class Initialized
INFO - 2016-02-17 13:24:49 --> Form Validation Class Initialized
INFO - 2016-02-17 13:24:49 --> Helper loaded: text_helper
INFO - 2016-02-17 13:24:49 --> Final output sent to browser
DEBUG - 2016-02-17 13:24:49 --> Total execution time: 1.1331
INFO - 2016-02-17 13:43:11 --> Config Class Initialized
INFO - 2016-02-17 13:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:43:11 --> Utf8 Class Initialized
INFO - 2016-02-17 13:43:11 --> URI Class Initialized
DEBUG - 2016-02-17 13:43:11 --> No URI present. Default controller set.
INFO - 2016-02-17 13:43:11 --> Router Class Initialized
INFO - 2016-02-17 13:43:11 --> Output Class Initialized
INFO - 2016-02-17 13:43:11 --> Security Class Initialized
DEBUG - 2016-02-17 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:43:11 --> Input Class Initialized
INFO - 2016-02-17 13:43:11 --> Language Class Initialized
INFO - 2016-02-17 13:43:12 --> Loader Class Initialized
INFO - 2016-02-17 13:43:12 --> Helper loaded: url_helper
INFO - 2016-02-17 13:43:12 --> Helper loaded: file_helper
INFO - 2016-02-17 13:43:12 --> Helper loaded: date_helper
INFO - 2016-02-17 13:43:12 --> Helper loaded: form_helper
INFO - 2016-02-17 13:43:12 --> Database Driver Class Initialized
INFO - 2016-02-17 13:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:43:13 --> Controller Class Initialized
INFO - 2016-02-17 13:43:13 --> Model Class Initialized
INFO - 2016-02-17 13:43:13 --> Model Class Initialized
INFO - 2016-02-17 13:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:43:13 --> Pagination Class Initialized
INFO - 2016-02-17 13:43:13 --> Helper loaded: text_helper
INFO - 2016-02-17 13:43:13 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:43:13 --> Final output sent to browser
DEBUG - 2016-02-17 16:43:13 --> Total execution time: 1.1079
INFO - 2016-02-17 13:45:52 --> Config Class Initialized
INFO - 2016-02-17 13:45:52 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:45:52 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:45:52 --> Utf8 Class Initialized
INFO - 2016-02-17 13:45:52 --> URI Class Initialized
DEBUG - 2016-02-17 13:45:52 --> No URI present. Default controller set.
INFO - 2016-02-17 13:45:52 --> Router Class Initialized
INFO - 2016-02-17 13:45:52 --> Output Class Initialized
INFO - 2016-02-17 13:45:52 --> Security Class Initialized
DEBUG - 2016-02-17 13:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:45:52 --> Input Class Initialized
INFO - 2016-02-17 13:45:52 --> Language Class Initialized
INFO - 2016-02-17 13:45:52 --> Loader Class Initialized
INFO - 2016-02-17 13:45:52 --> Helper loaded: url_helper
INFO - 2016-02-17 13:45:52 --> Helper loaded: file_helper
INFO - 2016-02-17 13:45:52 --> Helper loaded: date_helper
INFO - 2016-02-17 13:45:52 --> Helper loaded: form_helper
INFO - 2016-02-17 13:45:52 --> Database Driver Class Initialized
INFO - 2016-02-17 13:45:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:45:53 --> Controller Class Initialized
INFO - 2016-02-17 13:45:53 --> Model Class Initialized
INFO - 2016-02-17 13:45:53 --> Model Class Initialized
INFO - 2016-02-17 13:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:45:53 --> Pagination Class Initialized
INFO - 2016-02-17 13:45:53 --> Helper loaded: text_helper
INFO - 2016-02-17 13:45:53 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:45:53 --> Final output sent to browser
DEBUG - 2016-02-17 16:45:53 --> Total execution time: 1.1647
INFO - 2016-02-17 13:45:57 --> Config Class Initialized
INFO - 2016-02-17 13:45:57 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:45:57 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:45:57 --> Utf8 Class Initialized
INFO - 2016-02-17 13:45:57 --> URI Class Initialized
INFO - 2016-02-17 13:45:57 --> Router Class Initialized
INFO - 2016-02-17 13:45:57 --> Output Class Initialized
INFO - 2016-02-17 13:45:57 --> Security Class Initialized
DEBUG - 2016-02-17 13:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:45:57 --> Input Class Initialized
INFO - 2016-02-17 13:45:57 --> Language Class Initialized
INFO - 2016-02-17 13:45:57 --> Loader Class Initialized
INFO - 2016-02-17 13:45:57 --> Helper loaded: url_helper
INFO - 2016-02-17 13:45:57 --> Helper loaded: file_helper
INFO - 2016-02-17 13:45:57 --> Helper loaded: date_helper
INFO - 2016-02-17 13:45:57 --> Helper loaded: form_helper
INFO - 2016-02-17 13:45:57 --> Database Driver Class Initialized
INFO - 2016-02-17 13:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:45:58 --> Controller Class Initialized
INFO - 2016-02-17 13:45:58 --> Model Class Initialized
INFO - 2016-02-17 13:45:58 --> Model Class Initialized
INFO - 2016-02-17 13:45:58 --> Form Validation Class Initialized
INFO - 2016-02-17 13:45:58 --> Helper loaded: text_helper
INFO - 2016-02-17 13:45:58 --> Final output sent to browser
DEBUG - 2016-02-17 13:45:58 --> Total execution time: 1.0761
INFO - 2016-02-17 13:52:34 --> Config Class Initialized
INFO - 2016-02-17 13:52:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:52:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:52:34 --> Utf8 Class Initialized
INFO - 2016-02-17 13:52:34 --> URI Class Initialized
INFO - 2016-02-17 13:52:34 --> Router Class Initialized
INFO - 2016-02-17 13:52:34 --> Output Class Initialized
INFO - 2016-02-17 13:52:34 --> Security Class Initialized
DEBUG - 2016-02-17 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:52:34 --> Input Class Initialized
INFO - 2016-02-17 13:52:34 --> Language Class Initialized
INFO - 2016-02-17 13:52:34 --> Loader Class Initialized
INFO - 2016-02-17 13:52:34 --> Helper loaded: url_helper
INFO - 2016-02-17 13:52:34 --> Helper loaded: file_helper
INFO - 2016-02-17 13:52:34 --> Helper loaded: date_helper
INFO - 2016-02-17 13:52:34 --> Helper loaded: form_helper
INFO - 2016-02-17 13:52:34 --> Database Driver Class Initialized
INFO - 2016-02-17 13:52:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:52:35 --> Controller Class Initialized
INFO - 2016-02-17 13:52:35 --> Model Class Initialized
INFO - 2016-02-17 13:52:35 --> Model Class Initialized
INFO - 2016-02-17 13:52:35 --> Form Validation Class Initialized
INFO - 2016-02-17 13:52:35 --> Helper loaded: text_helper
ERROR - 2016-02-17 13:52:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-17 13:52:35 --> Final output sent to browser
DEBUG - 2016-02-17 13:52:35 --> Total execution time: 1.1088
INFO - 2016-02-17 13:53:10 --> Config Class Initialized
INFO - 2016-02-17 13:53:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:53:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:53:10 --> Utf8 Class Initialized
INFO - 2016-02-17 13:53:10 --> URI Class Initialized
INFO - 2016-02-17 13:53:10 --> Router Class Initialized
INFO - 2016-02-17 13:53:10 --> Output Class Initialized
INFO - 2016-02-17 13:53:10 --> Security Class Initialized
DEBUG - 2016-02-17 13:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:53:10 --> Input Class Initialized
INFO - 2016-02-17 13:53:10 --> Language Class Initialized
INFO - 2016-02-17 13:53:10 --> Loader Class Initialized
INFO - 2016-02-17 13:53:10 --> Helper loaded: url_helper
INFO - 2016-02-17 13:53:10 --> Helper loaded: file_helper
INFO - 2016-02-17 13:53:10 --> Helper loaded: date_helper
INFO - 2016-02-17 13:53:10 --> Helper loaded: form_helper
INFO - 2016-02-17 13:53:10 --> Database Driver Class Initialized
INFO - 2016-02-17 13:53:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:53:11 --> Controller Class Initialized
INFO - 2016-02-17 13:53:11 --> Model Class Initialized
INFO - 2016-02-17 13:53:11 --> Model Class Initialized
INFO - 2016-02-17 13:53:11 --> Form Validation Class Initialized
INFO - 2016-02-17 13:53:11 --> Helper loaded: text_helper
ERROR - 2016-02-17 13:53:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-17 13:53:11 --> Final output sent to browser
DEBUG - 2016-02-17 13:53:11 --> Total execution time: 1.1094
INFO - 2016-02-17 13:54:49 --> Config Class Initialized
INFO - 2016-02-17 13:54:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:54:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:54:49 --> Utf8 Class Initialized
INFO - 2016-02-17 13:54:49 --> URI Class Initialized
INFO - 2016-02-17 13:54:49 --> Router Class Initialized
INFO - 2016-02-17 13:54:49 --> Output Class Initialized
INFO - 2016-02-17 13:54:49 --> Security Class Initialized
DEBUG - 2016-02-17 13:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:54:49 --> Input Class Initialized
INFO - 2016-02-17 13:54:49 --> Language Class Initialized
INFO - 2016-02-17 13:54:49 --> Loader Class Initialized
INFO - 2016-02-17 13:54:49 --> Helper loaded: url_helper
INFO - 2016-02-17 13:54:49 --> Helper loaded: file_helper
INFO - 2016-02-17 13:54:49 --> Helper loaded: date_helper
INFO - 2016-02-17 13:54:49 --> Helper loaded: form_helper
INFO - 2016-02-17 13:54:50 --> Database Driver Class Initialized
INFO - 2016-02-17 13:54:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:54:51 --> Controller Class Initialized
INFO - 2016-02-17 13:54:51 --> Model Class Initialized
INFO - 2016-02-17 13:54:51 --> Model Class Initialized
INFO - 2016-02-17 13:54:51 --> Form Validation Class Initialized
INFO - 2016-02-17 13:54:51 --> Helper loaded: text_helper
ERROR - 2016-02-17 13:54:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-17 13:54:51 --> Final output sent to browser
DEBUG - 2016-02-17 13:54:51 --> Total execution time: 1.1130
INFO - 2016-02-17 13:55:32 --> Config Class Initialized
INFO - 2016-02-17 13:55:32 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:55:32 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:55:32 --> Utf8 Class Initialized
INFO - 2016-02-17 13:55:32 --> URI Class Initialized
INFO - 2016-02-17 13:55:32 --> Router Class Initialized
INFO - 2016-02-17 13:55:32 --> Output Class Initialized
INFO - 2016-02-17 13:55:32 --> Security Class Initialized
DEBUG - 2016-02-17 13:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:55:32 --> Input Class Initialized
INFO - 2016-02-17 13:55:32 --> Language Class Initialized
INFO - 2016-02-17 13:55:32 --> Loader Class Initialized
INFO - 2016-02-17 13:55:32 --> Helper loaded: url_helper
INFO - 2016-02-17 13:55:32 --> Helper loaded: file_helper
INFO - 2016-02-17 13:55:32 --> Helper loaded: date_helper
INFO - 2016-02-17 13:55:32 --> Helper loaded: form_helper
INFO - 2016-02-17 13:55:32 --> Database Driver Class Initialized
INFO - 2016-02-17 13:55:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:55:33 --> Controller Class Initialized
INFO - 2016-02-17 13:55:33 --> Model Class Initialized
INFO - 2016-02-17 13:55:33 --> Model Class Initialized
INFO - 2016-02-17 13:55:33 --> Form Validation Class Initialized
INFO - 2016-02-17 13:55:33 --> Helper loaded: text_helper
ERROR - 2016-02-17 13:55:33 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-17 13:55:33 --> Final output sent to browser
DEBUG - 2016-02-17 13:55:33 --> Total execution time: 1.1213
INFO - 2016-02-17 13:56:39 --> Config Class Initialized
INFO - 2016-02-17 13:56:39 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:56:39 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:56:39 --> Utf8 Class Initialized
INFO - 2016-02-17 13:56:39 --> URI Class Initialized
DEBUG - 2016-02-17 13:56:39 --> No URI present. Default controller set.
INFO - 2016-02-17 13:56:39 --> Router Class Initialized
INFO - 2016-02-17 13:56:39 --> Output Class Initialized
INFO - 2016-02-17 13:56:39 --> Security Class Initialized
DEBUG - 2016-02-17 13:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:56:39 --> Input Class Initialized
INFO - 2016-02-17 13:56:39 --> Language Class Initialized
INFO - 2016-02-17 13:56:39 --> Loader Class Initialized
INFO - 2016-02-17 13:56:39 --> Helper loaded: url_helper
INFO - 2016-02-17 13:56:39 --> Helper loaded: file_helper
INFO - 2016-02-17 13:56:39 --> Helper loaded: date_helper
INFO - 2016-02-17 13:56:39 --> Helper loaded: form_helper
INFO - 2016-02-17 13:56:39 --> Database Driver Class Initialized
INFO - 2016-02-17 13:56:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:56:40 --> Controller Class Initialized
INFO - 2016-02-17 13:56:40 --> Model Class Initialized
INFO - 2016-02-17 13:56:40 --> Model Class Initialized
INFO - 2016-02-17 13:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:56:40 --> Pagination Class Initialized
INFO - 2016-02-17 13:56:40 --> Helper loaded: text_helper
INFO - 2016-02-17 13:56:40 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:56:40 --> Final output sent to browser
DEBUG - 2016-02-17 16:56:40 --> Total execution time: 1.0980
INFO - 2016-02-17 13:56:46 --> Config Class Initialized
INFO - 2016-02-17 13:56:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:56:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:56:46 --> Utf8 Class Initialized
INFO - 2016-02-17 13:56:46 --> URI Class Initialized
INFO - 2016-02-17 13:56:46 --> Router Class Initialized
INFO - 2016-02-17 13:56:46 --> Output Class Initialized
INFO - 2016-02-17 13:56:46 --> Security Class Initialized
DEBUG - 2016-02-17 13:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:56:46 --> Input Class Initialized
INFO - 2016-02-17 13:56:46 --> Language Class Initialized
INFO - 2016-02-17 13:56:46 --> Loader Class Initialized
INFO - 2016-02-17 13:56:46 --> Helper loaded: url_helper
INFO - 2016-02-17 13:56:46 --> Helper loaded: file_helper
INFO - 2016-02-17 13:56:46 --> Helper loaded: date_helper
INFO - 2016-02-17 13:56:46 --> Helper loaded: form_helper
INFO - 2016-02-17 13:56:46 --> Database Driver Class Initialized
INFO - 2016-02-17 13:56:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:56:47 --> Controller Class Initialized
INFO - 2016-02-17 13:56:47 --> Model Class Initialized
INFO - 2016-02-17 13:56:47 --> Model Class Initialized
INFO - 2016-02-17 13:56:47 --> Form Validation Class Initialized
INFO - 2016-02-17 13:56:47 --> Helper loaded: text_helper
INFO - 2016-02-17 13:56:47 --> Final output sent to browser
DEBUG - 2016-02-17 13:56:47 --> Total execution time: 1.2042
INFO - 2016-02-17 13:57:19 --> Config Class Initialized
INFO - 2016-02-17 13:57:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:57:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:57:19 --> Utf8 Class Initialized
INFO - 2016-02-17 13:57:19 --> URI Class Initialized
DEBUG - 2016-02-17 13:57:19 --> No URI present. Default controller set.
INFO - 2016-02-17 13:57:19 --> Router Class Initialized
INFO - 2016-02-17 13:57:19 --> Output Class Initialized
INFO - 2016-02-17 13:57:19 --> Security Class Initialized
DEBUG - 2016-02-17 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:57:19 --> Input Class Initialized
INFO - 2016-02-17 13:57:19 --> Language Class Initialized
INFO - 2016-02-17 13:57:19 --> Loader Class Initialized
INFO - 2016-02-17 13:57:19 --> Helper loaded: url_helper
INFO - 2016-02-17 13:57:19 --> Helper loaded: file_helper
INFO - 2016-02-17 13:57:19 --> Helper loaded: date_helper
INFO - 2016-02-17 13:57:19 --> Helper loaded: form_helper
INFO - 2016-02-17 13:57:19 --> Database Driver Class Initialized
INFO - 2016-02-17 13:57:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:57:20 --> Controller Class Initialized
INFO - 2016-02-17 13:57:20 --> Model Class Initialized
INFO - 2016-02-17 13:57:20 --> Model Class Initialized
INFO - 2016-02-17 13:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 13:57:20 --> Pagination Class Initialized
INFO - 2016-02-17 13:57:20 --> Helper loaded: text_helper
INFO - 2016-02-17 13:57:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 16:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 16:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 16:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 16:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 16:57:20 --> Final output sent to browser
DEBUG - 2016-02-17 16:57:20 --> Total execution time: 1.1445
INFO - 2016-02-17 13:57:34 --> Config Class Initialized
INFO - 2016-02-17 13:57:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:57:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:57:34 --> Utf8 Class Initialized
INFO - 2016-02-17 13:57:34 --> URI Class Initialized
INFO - 2016-02-17 13:57:34 --> Router Class Initialized
INFO - 2016-02-17 13:57:34 --> Output Class Initialized
INFO - 2016-02-17 13:57:34 --> Security Class Initialized
DEBUG - 2016-02-17 13:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:57:34 --> Input Class Initialized
INFO - 2016-02-17 13:57:34 --> Language Class Initialized
INFO - 2016-02-17 13:57:34 --> Loader Class Initialized
INFO - 2016-02-17 13:57:34 --> Helper loaded: url_helper
INFO - 2016-02-17 13:57:34 --> Helper loaded: file_helper
INFO - 2016-02-17 13:57:34 --> Helper loaded: date_helper
INFO - 2016-02-17 13:57:34 --> Helper loaded: form_helper
INFO - 2016-02-17 13:57:34 --> Database Driver Class Initialized
INFO - 2016-02-17 13:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:57:35 --> Controller Class Initialized
INFO - 2016-02-17 13:57:35 --> Model Class Initialized
INFO - 2016-02-17 13:57:35 --> Model Class Initialized
INFO - 2016-02-17 13:57:35 --> Form Validation Class Initialized
INFO - 2016-02-17 13:57:35 --> Helper loaded: text_helper
INFO - 2016-02-17 13:57:35 --> Final output sent to browser
DEBUG - 2016-02-17 13:57:35 --> Total execution time: 1.1116
INFO - 2016-02-17 13:59:46 --> Config Class Initialized
INFO - 2016-02-17 13:59:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 13:59:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 13:59:46 --> Utf8 Class Initialized
INFO - 2016-02-17 13:59:46 --> URI Class Initialized
INFO - 2016-02-17 13:59:46 --> Router Class Initialized
INFO - 2016-02-17 13:59:46 --> Output Class Initialized
INFO - 2016-02-17 13:59:46 --> Security Class Initialized
DEBUG - 2016-02-17 13:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 13:59:46 --> Input Class Initialized
INFO - 2016-02-17 13:59:46 --> Language Class Initialized
INFO - 2016-02-17 13:59:46 --> Loader Class Initialized
INFO - 2016-02-17 13:59:46 --> Helper loaded: url_helper
INFO - 2016-02-17 13:59:46 --> Helper loaded: file_helper
INFO - 2016-02-17 13:59:46 --> Helper loaded: date_helper
INFO - 2016-02-17 13:59:46 --> Helper loaded: form_helper
INFO - 2016-02-17 13:59:46 --> Database Driver Class Initialized
INFO - 2016-02-17 13:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 13:59:47 --> Controller Class Initialized
INFO - 2016-02-17 13:59:47 --> Model Class Initialized
INFO - 2016-02-17 13:59:47 --> Model Class Initialized
INFO - 2016-02-17 13:59:47 --> Form Validation Class Initialized
INFO - 2016-02-17 13:59:47 --> Helper loaded: text_helper
INFO - 2016-02-17 13:59:47 --> Final output sent to browser
DEBUG - 2016-02-17 13:59:47 --> Total execution time: 1.1628
INFO - 2016-02-17 14:00:59 --> Config Class Initialized
INFO - 2016-02-17 14:00:59 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:00:59 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:00:59 --> Utf8 Class Initialized
INFO - 2016-02-17 14:00:59 --> URI Class Initialized
INFO - 2016-02-17 14:00:59 --> Router Class Initialized
INFO - 2016-02-17 14:00:59 --> Output Class Initialized
INFO - 2016-02-17 14:00:59 --> Security Class Initialized
DEBUG - 2016-02-17 14:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:00:59 --> Input Class Initialized
INFO - 2016-02-17 14:00:59 --> Language Class Initialized
INFO - 2016-02-17 14:00:59 --> Loader Class Initialized
INFO - 2016-02-17 14:00:59 --> Helper loaded: url_helper
INFO - 2016-02-17 14:00:59 --> Helper loaded: file_helper
INFO - 2016-02-17 14:00:59 --> Helper loaded: date_helper
INFO - 2016-02-17 14:00:59 --> Helper loaded: form_helper
INFO - 2016-02-17 14:00:59 --> Database Driver Class Initialized
INFO - 2016-02-17 14:01:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:01:00 --> Controller Class Initialized
INFO - 2016-02-17 14:01:00 --> Model Class Initialized
INFO - 2016-02-17 14:01:00 --> Model Class Initialized
INFO - 2016-02-17 14:01:00 --> Form Validation Class Initialized
INFO - 2016-02-17 14:01:00 --> Helper loaded: text_helper
INFO - 2016-02-17 14:01:00 --> Final output sent to browser
DEBUG - 2016-02-17 14:01:00 --> Total execution time: 1.1181
INFO - 2016-02-17 14:01:39 --> Config Class Initialized
INFO - 2016-02-17 14:01:39 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:01:39 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:01:39 --> Utf8 Class Initialized
INFO - 2016-02-17 14:01:39 --> URI Class Initialized
INFO - 2016-02-17 14:01:39 --> Router Class Initialized
INFO - 2016-02-17 14:01:39 --> Output Class Initialized
INFO - 2016-02-17 14:01:39 --> Security Class Initialized
DEBUG - 2016-02-17 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:01:39 --> Input Class Initialized
INFO - 2016-02-17 14:01:39 --> Language Class Initialized
INFO - 2016-02-17 14:01:39 --> Loader Class Initialized
INFO - 2016-02-17 14:01:39 --> Helper loaded: url_helper
INFO - 2016-02-17 14:01:39 --> Helper loaded: file_helper
INFO - 2016-02-17 14:01:39 --> Helper loaded: date_helper
INFO - 2016-02-17 14:01:39 --> Helper loaded: form_helper
INFO - 2016-02-17 14:01:39 --> Database Driver Class Initialized
INFO - 2016-02-17 14:01:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:01:40 --> Controller Class Initialized
INFO - 2016-02-17 14:01:40 --> Model Class Initialized
INFO - 2016-02-17 14:01:40 --> Model Class Initialized
INFO - 2016-02-17 14:01:40 --> Form Validation Class Initialized
INFO - 2016-02-17 14:01:40 --> Helper loaded: text_helper
INFO - 2016-02-17 14:01:40 --> Final output sent to browser
DEBUG - 2016-02-17 14:01:40 --> Total execution time: 1.1535
INFO - 2016-02-17 14:02:49 --> Config Class Initialized
INFO - 2016-02-17 14:02:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:02:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:02:49 --> Utf8 Class Initialized
INFO - 2016-02-17 14:02:49 --> URI Class Initialized
INFO - 2016-02-17 14:02:49 --> Router Class Initialized
INFO - 2016-02-17 14:02:49 --> Output Class Initialized
INFO - 2016-02-17 14:02:49 --> Security Class Initialized
DEBUG - 2016-02-17 14:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:02:49 --> Input Class Initialized
INFO - 2016-02-17 14:02:49 --> Language Class Initialized
INFO - 2016-02-17 14:02:49 --> Loader Class Initialized
INFO - 2016-02-17 14:02:49 --> Helper loaded: url_helper
INFO - 2016-02-17 14:02:49 --> Helper loaded: file_helper
INFO - 2016-02-17 14:02:49 --> Helper loaded: date_helper
INFO - 2016-02-17 14:02:49 --> Helper loaded: form_helper
INFO - 2016-02-17 14:02:49 --> Database Driver Class Initialized
INFO - 2016-02-17 14:02:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:02:50 --> Controller Class Initialized
INFO - 2016-02-17 14:02:50 --> Model Class Initialized
INFO - 2016-02-17 14:02:50 --> Model Class Initialized
INFO - 2016-02-17 14:02:50 --> Form Validation Class Initialized
INFO - 2016-02-17 14:02:50 --> Helper loaded: text_helper
INFO - 2016-02-17 14:02:50 --> Final output sent to browser
DEBUG - 2016-02-17 14:02:50 --> Total execution time: 1.0954
INFO - 2016-02-17 14:03:11 --> Config Class Initialized
INFO - 2016-02-17 14:03:11 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:03:11 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:03:11 --> Utf8 Class Initialized
INFO - 2016-02-17 14:03:11 --> URI Class Initialized
INFO - 2016-02-17 14:03:11 --> Router Class Initialized
INFO - 2016-02-17 14:03:11 --> Output Class Initialized
INFO - 2016-02-17 14:03:11 --> Security Class Initialized
DEBUG - 2016-02-17 14:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:03:11 --> Input Class Initialized
INFO - 2016-02-17 14:03:11 --> Language Class Initialized
INFO - 2016-02-17 14:03:11 --> Loader Class Initialized
INFO - 2016-02-17 14:03:11 --> Helper loaded: url_helper
INFO - 2016-02-17 14:03:11 --> Helper loaded: file_helper
INFO - 2016-02-17 14:03:11 --> Helper loaded: date_helper
INFO - 2016-02-17 14:03:11 --> Helper loaded: form_helper
INFO - 2016-02-17 14:03:11 --> Database Driver Class Initialized
INFO - 2016-02-17 14:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:03:12 --> Controller Class Initialized
INFO - 2016-02-17 14:03:12 --> Model Class Initialized
INFO - 2016-02-17 14:03:12 --> Model Class Initialized
INFO - 2016-02-17 14:03:12 --> Form Validation Class Initialized
INFO - 2016-02-17 14:03:12 --> Helper loaded: text_helper
INFO - 2016-02-17 14:03:12 --> Final output sent to browser
DEBUG - 2016-02-17 14:03:12 --> Total execution time: 1.0887
INFO - 2016-02-17 14:03:48 --> Config Class Initialized
INFO - 2016-02-17 14:03:48 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:03:48 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:03:48 --> Utf8 Class Initialized
INFO - 2016-02-17 14:03:48 --> URI Class Initialized
DEBUG - 2016-02-17 14:03:48 --> No URI present. Default controller set.
INFO - 2016-02-17 14:03:48 --> Router Class Initialized
INFO - 2016-02-17 14:03:48 --> Output Class Initialized
INFO - 2016-02-17 14:03:48 --> Security Class Initialized
DEBUG - 2016-02-17 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:03:48 --> Input Class Initialized
INFO - 2016-02-17 14:03:48 --> Language Class Initialized
INFO - 2016-02-17 14:03:48 --> Loader Class Initialized
INFO - 2016-02-17 14:03:48 --> Helper loaded: url_helper
INFO - 2016-02-17 14:03:48 --> Helper loaded: file_helper
INFO - 2016-02-17 14:03:48 --> Helper loaded: date_helper
INFO - 2016-02-17 14:03:48 --> Helper loaded: form_helper
INFO - 2016-02-17 14:03:48 --> Database Driver Class Initialized
INFO - 2016-02-17 14:03:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:03:49 --> Controller Class Initialized
INFO - 2016-02-17 14:03:49 --> Model Class Initialized
INFO - 2016-02-17 14:03:49 --> Model Class Initialized
INFO - 2016-02-17 14:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:03:49 --> Pagination Class Initialized
INFO - 2016-02-17 14:03:49 --> Helper loaded: text_helper
INFO - 2016-02-17 14:03:49 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:03:49 --> Final output sent to browser
DEBUG - 2016-02-17 17:03:49 --> Total execution time: 1.1431
INFO - 2016-02-17 14:03:51 --> Config Class Initialized
INFO - 2016-02-17 14:03:51 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:03:51 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:03:51 --> Utf8 Class Initialized
INFO - 2016-02-17 14:03:51 --> URI Class Initialized
INFO - 2016-02-17 14:03:51 --> Router Class Initialized
INFO - 2016-02-17 14:03:51 --> Output Class Initialized
INFO - 2016-02-17 14:03:51 --> Security Class Initialized
DEBUG - 2016-02-17 14:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:03:51 --> Input Class Initialized
INFO - 2016-02-17 14:03:51 --> Language Class Initialized
INFO - 2016-02-17 14:03:51 --> Loader Class Initialized
INFO - 2016-02-17 14:03:51 --> Helper loaded: url_helper
INFO - 2016-02-17 14:03:51 --> Helper loaded: file_helper
INFO - 2016-02-17 14:03:51 --> Helper loaded: date_helper
INFO - 2016-02-17 14:03:51 --> Helper loaded: form_helper
INFO - 2016-02-17 14:03:51 --> Database Driver Class Initialized
INFO - 2016-02-17 14:03:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:03:52 --> Controller Class Initialized
INFO - 2016-02-17 14:03:52 --> Model Class Initialized
INFO - 2016-02-17 14:03:52 --> Model Class Initialized
INFO - 2016-02-17 14:03:52 --> Form Validation Class Initialized
INFO - 2016-02-17 14:03:52 --> Helper loaded: text_helper
INFO - 2016-02-17 14:03:52 --> Final output sent to browser
DEBUG - 2016-02-17 14:03:52 --> Total execution time: 1.1081
INFO - 2016-02-17 14:04:03 --> Config Class Initialized
INFO - 2016-02-17 14:04:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:04:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:04:03 --> Utf8 Class Initialized
INFO - 2016-02-17 14:04:03 --> URI Class Initialized
DEBUG - 2016-02-17 14:04:03 --> No URI present. Default controller set.
INFO - 2016-02-17 14:04:03 --> Router Class Initialized
INFO - 2016-02-17 14:04:03 --> Output Class Initialized
INFO - 2016-02-17 14:04:03 --> Security Class Initialized
DEBUG - 2016-02-17 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:04:03 --> Input Class Initialized
INFO - 2016-02-17 14:04:03 --> Language Class Initialized
INFO - 2016-02-17 14:04:03 --> Loader Class Initialized
INFO - 2016-02-17 14:04:03 --> Helper loaded: url_helper
INFO - 2016-02-17 14:04:03 --> Helper loaded: file_helper
INFO - 2016-02-17 14:04:03 --> Helper loaded: date_helper
INFO - 2016-02-17 14:04:03 --> Helper loaded: form_helper
INFO - 2016-02-17 14:04:03 --> Database Driver Class Initialized
INFO - 2016-02-17 14:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:04:04 --> Controller Class Initialized
INFO - 2016-02-17 14:04:04 --> Model Class Initialized
INFO - 2016-02-17 14:04:04 --> Model Class Initialized
INFO - 2016-02-17 14:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:04:04 --> Pagination Class Initialized
INFO - 2016-02-17 14:04:04 --> Helper loaded: text_helper
INFO - 2016-02-17 14:04:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:04:05 --> Final output sent to browser
DEBUG - 2016-02-17 17:04:05 --> Total execution time: 1.1365
INFO - 2016-02-17 14:04:07 --> Config Class Initialized
INFO - 2016-02-17 14:04:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:04:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:04:07 --> Utf8 Class Initialized
INFO - 2016-02-17 14:04:07 --> URI Class Initialized
INFO - 2016-02-17 14:04:07 --> Router Class Initialized
INFO - 2016-02-17 14:04:07 --> Output Class Initialized
INFO - 2016-02-17 14:04:07 --> Security Class Initialized
DEBUG - 2016-02-17 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:04:07 --> Input Class Initialized
INFO - 2016-02-17 14:04:07 --> Language Class Initialized
INFO - 2016-02-17 14:04:07 --> Loader Class Initialized
INFO - 2016-02-17 14:04:07 --> Helper loaded: url_helper
INFO - 2016-02-17 14:04:07 --> Helper loaded: file_helper
INFO - 2016-02-17 14:04:07 --> Helper loaded: date_helper
INFO - 2016-02-17 14:04:07 --> Helper loaded: form_helper
INFO - 2016-02-17 14:04:07 --> Database Driver Class Initialized
INFO - 2016-02-17 14:04:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:04:08 --> Controller Class Initialized
INFO - 2016-02-17 14:04:08 --> Model Class Initialized
INFO - 2016-02-17 14:04:08 --> Model Class Initialized
INFO - 2016-02-17 14:04:08 --> Form Validation Class Initialized
INFO - 2016-02-17 14:04:08 --> Helper loaded: text_helper
INFO - 2016-02-17 14:04:08 --> Final output sent to browser
DEBUG - 2016-02-17 14:04:08 --> Total execution time: 1.0788
INFO - 2016-02-17 14:05:41 --> Config Class Initialized
INFO - 2016-02-17 14:05:41 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:05:41 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:05:41 --> Utf8 Class Initialized
INFO - 2016-02-17 14:05:41 --> URI Class Initialized
DEBUG - 2016-02-17 14:05:41 --> No URI present. Default controller set.
INFO - 2016-02-17 14:05:41 --> Router Class Initialized
INFO - 2016-02-17 14:05:41 --> Output Class Initialized
INFO - 2016-02-17 14:05:41 --> Security Class Initialized
DEBUG - 2016-02-17 14:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:05:41 --> Input Class Initialized
INFO - 2016-02-17 14:05:41 --> Language Class Initialized
INFO - 2016-02-17 14:05:41 --> Loader Class Initialized
INFO - 2016-02-17 14:05:41 --> Helper loaded: url_helper
INFO - 2016-02-17 14:05:41 --> Helper loaded: file_helper
INFO - 2016-02-17 14:05:41 --> Helper loaded: date_helper
INFO - 2016-02-17 14:05:41 --> Helper loaded: form_helper
INFO - 2016-02-17 14:05:41 --> Database Driver Class Initialized
INFO - 2016-02-17 14:05:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:05:42 --> Controller Class Initialized
INFO - 2016-02-17 14:05:42 --> Model Class Initialized
INFO - 2016-02-17 14:05:42 --> Model Class Initialized
INFO - 2016-02-17 14:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:05:42 --> Pagination Class Initialized
INFO - 2016-02-17 14:05:42 --> Helper loaded: text_helper
INFO - 2016-02-17 14:05:42 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:05:42 --> Final output sent to browser
DEBUG - 2016-02-17 17:05:42 --> Total execution time: 1.1835
INFO - 2016-02-17 14:06:58 --> Config Class Initialized
INFO - 2016-02-17 14:06:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:06:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:06:58 --> Utf8 Class Initialized
INFO - 2016-02-17 14:06:58 --> URI Class Initialized
INFO - 2016-02-17 14:06:58 --> Router Class Initialized
INFO - 2016-02-17 14:06:58 --> Output Class Initialized
INFO - 2016-02-17 14:06:58 --> Security Class Initialized
DEBUG - 2016-02-17 14:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:06:58 --> Input Class Initialized
INFO - 2016-02-17 14:06:58 --> Language Class Initialized
INFO - 2016-02-17 14:06:58 --> Loader Class Initialized
INFO - 2016-02-17 14:06:58 --> Helper loaded: url_helper
INFO - 2016-02-17 14:06:58 --> Helper loaded: file_helper
INFO - 2016-02-17 14:06:58 --> Helper loaded: date_helper
INFO - 2016-02-17 14:06:58 --> Helper loaded: form_helper
INFO - 2016-02-17 14:06:58 --> Database Driver Class Initialized
INFO - 2016-02-17 14:06:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:06:59 --> Controller Class Initialized
INFO - 2016-02-17 14:06:59 --> Model Class Initialized
INFO - 2016-02-17 14:06:59 --> Model Class Initialized
INFO - 2016-02-17 14:06:59 --> Form Validation Class Initialized
INFO - 2016-02-17 14:06:59 --> Helper loaded: text_helper
INFO - 2016-02-17 14:06:59 --> Final output sent to browser
DEBUG - 2016-02-17 14:06:59 --> Total execution time: 1.0999
INFO - 2016-02-17 14:07:02 --> Config Class Initialized
INFO - 2016-02-17 14:07:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:07:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:07:02 --> Utf8 Class Initialized
INFO - 2016-02-17 14:07:02 --> URI Class Initialized
INFO - 2016-02-17 14:07:02 --> Router Class Initialized
INFO - 2016-02-17 14:07:02 --> Output Class Initialized
INFO - 2016-02-17 14:07:02 --> Security Class Initialized
DEBUG - 2016-02-17 14:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:07:02 --> Input Class Initialized
INFO - 2016-02-17 14:07:02 --> Language Class Initialized
INFO - 2016-02-17 14:07:02 --> Loader Class Initialized
INFO - 2016-02-17 14:07:02 --> Helper loaded: url_helper
INFO - 2016-02-17 14:07:02 --> Helper loaded: file_helper
INFO - 2016-02-17 14:07:02 --> Helper loaded: date_helper
INFO - 2016-02-17 14:07:02 --> Helper loaded: form_helper
INFO - 2016-02-17 14:07:02 --> Database Driver Class Initialized
INFO - 2016-02-17 14:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:07:03 --> Controller Class Initialized
INFO - 2016-02-17 14:07:03 --> Model Class Initialized
INFO - 2016-02-17 14:07:03 --> Model Class Initialized
INFO - 2016-02-17 14:07:03 --> Form Validation Class Initialized
INFO - 2016-02-17 14:07:03 --> Helper loaded: text_helper
INFO - 2016-02-17 14:07:03 --> Final output sent to browser
DEBUG - 2016-02-17 14:07:03 --> Total execution time: 1.1014
INFO - 2016-02-17 14:09:58 --> Config Class Initialized
INFO - 2016-02-17 14:09:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:09:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:09:58 --> Utf8 Class Initialized
INFO - 2016-02-17 14:09:58 --> URI Class Initialized
INFO - 2016-02-17 14:09:58 --> Router Class Initialized
INFO - 2016-02-17 14:09:58 --> Output Class Initialized
INFO - 2016-02-17 14:09:58 --> Security Class Initialized
DEBUG - 2016-02-17 14:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:09:58 --> Input Class Initialized
INFO - 2016-02-17 14:09:58 --> Language Class Initialized
INFO - 2016-02-17 14:09:58 --> Loader Class Initialized
INFO - 2016-02-17 14:09:58 --> Helper loaded: url_helper
INFO - 2016-02-17 14:09:58 --> Helper loaded: file_helper
INFO - 2016-02-17 14:09:58 --> Helper loaded: date_helper
INFO - 2016-02-17 14:09:58 --> Helper loaded: form_helper
INFO - 2016-02-17 14:09:58 --> Database Driver Class Initialized
INFO - 2016-02-17 14:09:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:09:59 --> Controller Class Initialized
INFO - 2016-02-17 14:09:59 --> Model Class Initialized
INFO - 2016-02-17 14:09:59 --> Model Class Initialized
INFO - 2016-02-17 14:09:59 --> Form Validation Class Initialized
INFO - 2016-02-17 14:09:59 --> Helper loaded: text_helper
INFO - 2016-02-17 14:09:59 --> Final output sent to browser
DEBUG - 2016-02-17 14:09:59 --> Total execution time: 1.1313
INFO - 2016-02-17 14:10:21 --> Config Class Initialized
INFO - 2016-02-17 14:10:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:10:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:10:21 --> Utf8 Class Initialized
INFO - 2016-02-17 14:10:21 --> URI Class Initialized
INFO - 2016-02-17 14:10:21 --> Router Class Initialized
INFO - 2016-02-17 14:10:21 --> Output Class Initialized
INFO - 2016-02-17 14:10:21 --> Security Class Initialized
DEBUG - 2016-02-17 14:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:10:21 --> Input Class Initialized
INFO - 2016-02-17 14:10:21 --> Language Class Initialized
INFO - 2016-02-17 14:10:21 --> Loader Class Initialized
INFO - 2016-02-17 14:10:21 --> Helper loaded: url_helper
INFO - 2016-02-17 14:10:21 --> Helper loaded: file_helper
INFO - 2016-02-17 14:10:21 --> Helper loaded: date_helper
INFO - 2016-02-17 14:10:21 --> Helper loaded: form_helper
INFO - 2016-02-17 14:10:21 --> Database Driver Class Initialized
INFO - 2016-02-17 14:10:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:10:22 --> Controller Class Initialized
INFO - 2016-02-17 14:10:22 --> Model Class Initialized
INFO - 2016-02-17 14:10:22 --> Model Class Initialized
INFO - 2016-02-17 14:10:22 --> Form Validation Class Initialized
INFO - 2016-02-17 14:10:22 --> Helper loaded: text_helper
INFO - 2016-02-17 14:10:22 --> Final output sent to browser
DEBUG - 2016-02-17 14:10:22 --> Total execution time: 1.0952
INFO - 2016-02-17 14:11:28 --> Config Class Initialized
INFO - 2016-02-17 14:11:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:11:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:11:28 --> Utf8 Class Initialized
INFO - 2016-02-17 14:11:28 --> URI Class Initialized
INFO - 2016-02-17 14:11:28 --> Router Class Initialized
INFO - 2016-02-17 14:11:28 --> Output Class Initialized
INFO - 2016-02-17 14:11:28 --> Security Class Initialized
DEBUG - 2016-02-17 14:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:11:28 --> Input Class Initialized
INFO - 2016-02-17 14:11:28 --> Language Class Initialized
INFO - 2016-02-17 14:11:28 --> Loader Class Initialized
INFO - 2016-02-17 14:11:28 --> Helper loaded: url_helper
INFO - 2016-02-17 14:11:28 --> Helper loaded: file_helper
INFO - 2016-02-17 14:11:28 --> Helper loaded: date_helper
INFO - 2016-02-17 14:11:28 --> Helper loaded: form_helper
INFO - 2016-02-17 14:11:28 --> Database Driver Class Initialized
INFO - 2016-02-17 14:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:11:29 --> Controller Class Initialized
INFO - 2016-02-17 14:11:29 --> Model Class Initialized
INFO - 2016-02-17 14:11:29 --> Model Class Initialized
INFO - 2016-02-17 14:11:29 --> Form Validation Class Initialized
INFO - 2016-02-17 14:11:29 --> Helper loaded: text_helper
INFO - 2016-02-17 14:11:29 --> Final output sent to browser
DEBUG - 2016-02-17 14:11:29 --> Total execution time: 1.1271
INFO - 2016-02-17 14:13:10 --> Config Class Initialized
INFO - 2016-02-17 14:13:10 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:13:10 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:13:10 --> Utf8 Class Initialized
INFO - 2016-02-17 14:13:10 --> URI Class Initialized
DEBUG - 2016-02-17 14:13:10 --> No URI present. Default controller set.
INFO - 2016-02-17 14:13:10 --> Router Class Initialized
INFO - 2016-02-17 14:13:10 --> Output Class Initialized
INFO - 2016-02-17 14:13:10 --> Security Class Initialized
DEBUG - 2016-02-17 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:13:10 --> Input Class Initialized
INFO - 2016-02-17 14:13:10 --> Language Class Initialized
INFO - 2016-02-17 14:13:10 --> Loader Class Initialized
INFO - 2016-02-17 14:13:10 --> Helper loaded: url_helper
INFO - 2016-02-17 14:13:10 --> Helper loaded: file_helper
INFO - 2016-02-17 14:13:10 --> Helper loaded: date_helper
INFO - 2016-02-17 14:13:10 --> Helper loaded: form_helper
INFO - 2016-02-17 14:13:10 --> Database Driver Class Initialized
INFO - 2016-02-17 14:13:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:13:11 --> Controller Class Initialized
INFO - 2016-02-17 14:13:11 --> Model Class Initialized
INFO - 2016-02-17 14:13:11 --> Model Class Initialized
INFO - 2016-02-17 14:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:13:11 --> Pagination Class Initialized
INFO - 2016-02-17 14:13:11 --> Helper loaded: text_helper
INFO - 2016-02-17 14:13:11 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:13:12 --> Final output sent to browser
DEBUG - 2016-02-17 17:13:12 --> Total execution time: 1.2262
INFO - 2016-02-17 14:13:14 --> Config Class Initialized
INFO - 2016-02-17 14:13:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:13:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:13:14 --> Utf8 Class Initialized
INFO - 2016-02-17 14:13:14 --> URI Class Initialized
INFO - 2016-02-17 14:13:14 --> Router Class Initialized
INFO - 2016-02-17 14:13:14 --> Output Class Initialized
INFO - 2016-02-17 14:13:14 --> Security Class Initialized
DEBUG - 2016-02-17 14:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:13:14 --> Input Class Initialized
INFO - 2016-02-17 14:13:14 --> Language Class Initialized
INFO - 2016-02-17 14:13:14 --> Loader Class Initialized
INFO - 2016-02-17 14:13:14 --> Helper loaded: url_helper
INFO - 2016-02-17 14:13:14 --> Helper loaded: file_helper
INFO - 2016-02-17 14:13:14 --> Helper loaded: date_helper
INFO - 2016-02-17 14:13:14 --> Helper loaded: form_helper
INFO - 2016-02-17 14:13:14 --> Database Driver Class Initialized
INFO - 2016-02-17 14:13:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:13:15 --> Controller Class Initialized
INFO - 2016-02-17 14:13:15 --> Model Class Initialized
INFO - 2016-02-17 14:13:15 --> Model Class Initialized
INFO - 2016-02-17 14:13:15 --> Form Validation Class Initialized
INFO - 2016-02-17 14:13:15 --> Helper loaded: text_helper
INFO - 2016-02-17 14:13:15 --> Final output sent to browser
DEBUG - 2016-02-17 14:13:15 --> Total execution time: 1.1198
INFO - 2016-02-17 14:13:18 --> Config Class Initialized
INFO - 2016-02-17 14:13:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:13:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:13:18 --> Utf8 Class Initialized
INFO - 2016-02-17 14:13:18 --> URI Class Initialized
INFO - 2016-02-17 14:13:18 --> Router Class Initialized
INFO - 2016-02-17 14:13:18 --> Output Class Initialized
INFO - 2016-02-17 14:13:18 --> Security Class Initialized
DEBUG - 2016-02-17 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:13:18 --> Input Class Initialized
INFO - 2016-02-17 14:13:18 --> Language Class Initialized
INFO - 2016-02-17 14:13:18 --> Loader Class Initialized
INFO - 2016-02-17 14:13:18 --> Helper loaded: url_helper
INFO - 2016-02-17 14:13:18 --> Helper loaded: file_helper
INFO - 2016-02-17 14:13:18 --> Helper loaded: date_helper
INFO - 2016-02-17 14:13:18 --> Helper loaded: form_helper
INFO - 2016-02-17 14:13:18 --> Database Driver Class Initialized
INFO - 2016-02-17 14:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:13:19 --> Controller Class Initialized
INFO - 2016-02-17 14:13:19 --> Model Class Initialized
INFO - 2016-02-17 14:13:19 --> Model Class Initialized
INFO - 2016-02-17 14:13:19 --> Form Validation Class Initialized
INFO - 2016-02-17 14:13:19 --> Helper loaded: text_helper
INFO - 2016-02-17 14:13:19 --> Final output sent to browser
DEBUG - 2016-02-17 14:13:19 --> Total execution time: 1.1253
INFO - 2016-02-17 14:14:01 --> Config Class Initialized
INFO - 2016-02-17 14:14:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:14:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:14:01 --> Utf8 Class Initialized
INFO - 2016-02-17 14:14:01 --> URI Class Initialized
INFO - 2016-02-17 14:14:01 --> Router Class Initialized
INFO - 2016-02-17 14:14:01 --> Output Class Initialized
INFO - 2016-02-17 14:14:01 --> Security Class Initialized
DEBUG - 2016-02-17 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:14:01 --> Input Class Initialized
INFO - 2016-02-17 14:14:01 --> Language Class Initialized
INFO - 2016-02-17 14:14:01 --> Loader Class Initialized
INFO - 2016-02-17 14:14:01 --> Helper loaded: url_helper
INFO - 2016-02-17 14:14:01 --> Helper loaded: file_helper
INFO - 2016-02-17 14:14:01 --> Helper loaded: date_helper
INFO - 2016-02-17 14:14:01 --> Helper loaded: form_helper
INFO - 2016-02-17 14:14:01 --> Database Driver Class Initialized
INFO - 2016-02-17 14:14:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:14:02 --> Controller Class Initialized
INFO - 2016-02-17 14:14:02 --> Model Class Initialized
INFO - 2016-02-17 14:14:02 --> Model Class Initialized
INFO - 2016-02-17 14:14:02 --> Form Validation Class Initialized
INFO - 2016-02-17 14:14:02 --> Helper loaded: text_helper
INFO - 2016-02-17 14:14:02 --> Final output sent to browser
DEBUG - 2016-02-17 14:14:02 --> Total execution time: 1.1289
INFO - 2016-02-17 14:14:05 --> Config Class Initialized
INFO - 2016-02-17 14:14:05 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:14:05 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:14:05 --> Utf8 Class Initialized
INFO - 2016-02-17 14:14:05 --> URI Class Initialized
INFO - 2016-02-17 14:14:05 --> Router Class Initialized
INFO - 2016-02-17 14:14:05 --> Output Class Initialized
INFO - 2016-02-17 14:14:05 --> Security Class Initialized
DEBUG - 2016-02-17 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:14:05 --> Input Class Initialized
INFO - 2016-02-17 14:14:05 --> Language Class Initialized
INFO - 2016-02-17 14:14:05 --> Loader Class Initialized
INFO - 2016-02-17 14:14:05 --> Helper loaded: url_helper
INFO - 2016-02-17 14:14:05 --> Helper loaded: file_helper
INFO - 2016-02-17 14:14:05 --> Helper loaded: date_helper
INFO - 2016-02-17 14:14:05 --> Helper loaded: form_helper
INFO - 2016-02-17 14:14:05 --> Database Driver Class Initialized
INFO - 2016-02-17 14:14:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:14:06 --> Controller Class Initialized
INFO - 2016-02-17 14:14:06 --> Model Class Initialized
INFO - 2016-02-17 14:14:06 --> Model Class Initialized
INFO - 2016-02-17 14:14:06 --> Form Validation Class Initialized
INFO - 2016-02-17 14:14:06 --> Helper loaded: text_helper
INFO - 2016-02-17 14:14:06 --> Final output sent to browser
DEBUG - 2016-02-17 14:14:06 --> Total execution time: 1.1159
INFO - 2016-02-17 14:16:06 --> Config Class Initialized
INFO - 2016-02-17 14:16:06 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:16:06 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:16:06 --> Utf8 Class Initialized
INFO - 2016-02-17 14:16:06 --> URI Class Initialized
DEBUG - 2016-02-17 14:16:06 --> No URI present. Default controller set.
INFO - 2016-02-17 14:16:06 --> Router Class Initialized
INFO - 2016-02-17 14:16:06 --> Output Class Initialized
INFO - 2016-02-17 14:16:06 --> Security Class Initialized
DEBUG - 2016-02-17 14:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:16:06 --> Input Class Initialized
INFO - 2016-02-17 14:16:06 --> Language Class Initialized
INFO - 2016-02-17 14:16:06 --> Loader Class Initialized
INFO - 2016-02-17 14:16:06 --> Helper loaded: url_helper
INFO - 2016-02-17 14:16:06 --> Helper loaded: file_helper
INFO - 2016-02-17 14:16:06 --> Helper loaded: date_helper
INFO - 2016-02-17 14:16:06 --> Helper loaded: form_helper
INFO - 2016-02-17 14:16:06 --> Database Driver Class Initialized
INFO - 2016-02-17 14:16:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:16:07 --> Controller Class Initialized
INFO - 2016-02-17 14:16:07 --> Model Class Initialized
INFO - 2016-02-17 14:16:07 --> Model Class Initialized
INFO - 2016-02-17 14:16:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:16:07 --> Pagination Class Initialized
INFO - 2016-02-17 14:16:07 --> Helper loaded: text_helper
INFO - 2016-02-17 14:16:07 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:16:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:16:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:16:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:16:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:16:07 --> Final output sent to browser
DEBUG - 2016-02-17 17:16:07 --> Total execution time: 1.2559
INFO - 2016-02-17 14:16:09 --> Config Class Initialized
INFO - 2016-02-17 14:16:09 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:16:09 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:16:09 --> Utf8 Class Initialized
INFO - 2016-02-17 14:16:09 --> URI Class Initialized
INFO - 2016-02-17 14:16:09 --> Router Class Initialized
INFO - 2016-02-17 14:16:09 --> Output Class Initialized
INFO - 2016-02-17 14:16:09 --> Security Class Initialized
DEBUG - 2016-02-17 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:16:09 --> Input Class Initialized
INFO - 2016-02-17 14:16:09 --> Language Class Initialized
INFO - 2016-02-17 14:16:09 --> Loader Class Initialized
INFO - 2016-02-17 14:16:09 --> Helper loaded: url_helper
INFO - 2016-02-17 14:16:09 --> Helper loaded: file_helper
INFO - 2016-02-17 14:16:09 --> Helper loaded: date_helper
INFO - 2016-02-17 14:16:09 --> Helper loaded: form_helper
INFO - 2016-02-17 14:16:09 --> Database Driver Class Initialized
INFO - 2016-02-17 14:16:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:16:10 --> Controller Class Initialized
INFO - 2016-02-17 14:16:10 --> Model Class Initialized
INFO - 2016-02-17 14:16:10 --> Model Class Initialized
INFO - 2016-02-17 14:16:10 --> Form Validation Class Initialized
INFO - 2016-02-17 14:16:10 --> Helper loaded: text_helper
INFO - 2016-02-17 14:16:10 --> Final output sent to browser
DEBUG - 2016-02-17 14:16:10 --> Total execution time: 1.1298
INFO - 2016-02-17 14:16:46 --> Config Class Initialized
INFO - 2016-02-17 14:16:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:16:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:16:46 --> Utf8 Class Initialized
INFO - 2016-02-17 14:16:46 --> URI Class Initialized
INFO - 2016-02-17 14:16:46 --> Router Class Initialized
INFO - 2016-02-17 14:16:46 --> Output Class Initialized
INFO - 2016-02-17 14:16:46 --> Security Class Initialized
DEBUG - 2016-02-17 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:16:46 --> Input Class Initialized
INFO - 2016-02-17 14:16:46 --> Language Class Initialized
INFO - 2016-02-17 14:16:46 --> Loader Class Initialized
INFO - 2016-02-17 14:16:46 --> Helper loaded: url_helper
INFO - 2016-02-17 14:16:46 --> Helper loaded: file_helper
INFO - 2016-02-17 14:16:46 --> Helper loaded: date_helper
INFO - 2016-02-17 14:16:46 --> Helper loaded: form_helper
INFO - 2016-02-17 14:16:46 --> Database Driver Class Initialized
INFO - 2016-02-17 14:16:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:16:47 --> Controller Class Initialized
INFO - 2016-02-17 14:16:47 --> Model Class Initialized
INFO - 2016-02-17 14:16:47 --> Model Class Initialized
INFO - 2016-02-17 14:16:47 --> Form Validation Class Initialized
INFO - 2016-02-17 14:16:47 --> Helper loaded: text_helper
INFO - 2016-02-17 14:16:47 --> Final output sent to browser
DEBUG - 2016-02-17 14:16:47 --> Total execution time: 1.1330
INFO - 2016-02-17 14:20:52 --> Config Class Initialized
INFO - 2016-02-17 14:20:52 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:20:52 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:20:52 --> Utf8 Class Initialized
INFO - 2016-02-17 14:20:52 --> URI Class Initialized
INFO - 2016-02-17 14:20:52 --> Router Class Initialized
INFO - 2016-02-17 14:20:52 --> Output Class Initialized
INFO - 2016-02-17 14:20:52 --> Security Class Initialized
DEBUG - 2016-02-17 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:20:52 --> Input Class Initialized
INFO - 2016-02-17 14:20:52 --> Language Class Initialized
INFO - 2016-02-17 14:20:52 --> Loader Class Initialized
INFO - 2016-02-17 14:20:52 --> Helper loaded: url_helper
INFO - 2016-02-17 14:20:52 --> Helper loaded: file_helper
INFO - 2016-02-17 14:20:52 --> Helper loaded: date_helper
INFO - 2016-02-17 14:20:52 --> Helper loaded: form_helper
INFO - 2016-02-17 14:20:52 --> Database Driver Class Initialized
INFO - 2016-02-17 14:20:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:20:53 --> Controller Class Initialized
INFO - 2016-02-17 14:20:53 --> Model Class Initialized
INFO - 2016-02-17 14:20:53 --> Model Class Initialized
INFO - 2016-02-17 14:20:53 --> Form Validation Class Initialized
INFO - 2016-02-17 14:20:53 --> Helper loaded: text_helper
INFO - 2016-02-17 14:20:53 --> Final output sent to browser
DEBUG - 2016-02-17 14:20:53 --> Total execution time: 1.0851
INFO - 2016-02-17 14:42:50 --> Config Class Initialized
INFO - 2016-02-17 14:42:50 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:42:50 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:42:50 --> Utf8 Class Initialized
INFO - 2016-02-17 14:42:50 --> URI Class Initialized
DEBUG - 2016-02-17 14:42:50 --> No URI present. Default controller set.
INFO - 2016-02-17 14:42:50 --> Router Class Initialized
INFO - 2016-02-17 14:42:50 --> Output Class Initialized
INFO - 2016-02-17 14:42:50 --> Security Class Initialized
DEBUG - 2016-02-17 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:42:50 --> Input Class Initialized
INFO - 2016-02-17 14:42:50 --> Language Class Initialized
INFO - 2016-02-17 14:42:50 --> Loader Class Initialized
INFO - 2016-02-17 14:42:50 --> Helper loaded: url_helper
INFO - 2016-02-17 14:42:50 --> Helper loaded: file_helper
INFO - 2016-02-17 14:42:50 --> Helper loaded: date_helper
INFO - 2016-02-17 14:42:50 --> Helper loaded: form_helper
INFO - 2016-02-17 14:42:50 --> Database Driver Class Initialized
INFO - 2016-02-17 14:42:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:42:51 --> Controller Class Initialized
INFO - 2016-02-17 14:42:51 --> Model Class Initialized
INFO - 2016-02-17 14:42:51 --> Model Class Initialized
INFO - 2016-02-17 14:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:42:51 --> Pagination Class Initialized
INFO - 2016-02-17 14:42:51 --> Helper loaded: text_helper
INFO - 2016-02-17 14:42:51 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:42:51 --> Final output sent to browser
DEBUG - 2016-02-17 17:42:51 --> Total execution time: 1.1809
INFO - 2016-02-17 14:42:57 --> Config Class Initialized
INFO - 2016-02-17 14:42:57 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:42:57 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:42:57 --> Utf8 Class Initialized
INFO - 2016-02-17 14:42:57 --> URI Class Initialized
DEBUG - 2016-02-17 14:42:57 --> No URI present. Default controller set.
INFO - 2016-02-17 14:42:57 --> Router Class Initialized
INFO - 2016-02-17 14:42:57 --> Output Class Initialized
INFO - 2016-02-17 14:42:57 --> Security Class Initialized
DEBUG - 2016-02-17 14:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:42:57 --> Input Class Initialized
INFO - 2016-02-17 14:42:57 --> Language Class Initialized
INFO - 2016-02-17 14:42:57 --> Loader Class Initialized
INFO - 2016-02-17 14:42:57 --> Helper loaded: url_helper
INFO - 2016-02-17 14:42:57 --> Helper loaded: file_helper
INFO - 2016-02-17 14:42:57 --> Helper loaded: date_helper
INFO - 2016-02-17 14:42:57 --> Helper loaded: form_helper
INFO - 2016-02-17 14:42:57 --> Database Driver Class Initialized
INFO - 2016-02-17 14:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:42:58 --> Controller Class Initialized
INFO - 2016-02-17 14:42:58 --> Model Class Initialized
INFO - 2016-02-17 14:42:58 --> Model Class Initialized
INFO - 2016-02-17 14:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:42:58 --> Pagination Class Initialized
INFO - 2016-02-17 14:42:58 --> Helper loaded: text_helper
INFO - 2016-02-17 14:42:58 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:42:58 --> Final output sent to browser
DEBUG - 2016-02-17 17:42:58 --> Total execution time: 1.1438
INFO - 2016-02-17 14:43:04 --> Config Class Initialized
INFO - 2016-02-17 14:43:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:43:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:43:04 --> Utf8 Class Initialized
INFO - 2016-02-17 14:43:04 --> URI Class Initialized
DEBUG - 2016-02-17 14:43:04 --> No URI present. Default controller set.
INFO - 2016-02-17 14:43:04 --> Router Class Initialized
INFO - 2016-02-17 14:43:04 --> Output Class Initialized
INFO - 2016-02-17 14:43:04 --> Security Class Initialized
DEBUG - 2016-02-17 14:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:43:04 --> Input Class Initialized
INFO - 2016-02-17 14:43:04 --> Language Class Initialized
INFO - 2016-02-17 14:43:04 --> Loader Class Initialized
INFO - 2016-02-17 14:43:04 --> Helper loaded: url_helper
INFO - 2016-02-17 14:43:04 --> Helper loaded: file_helper
INFO - 2016-02-17 14:43:04 --> Helper loaded: date_helper
INFO - 2016-02-17 14:43:04 --> Helper loaded: form_helper
INFO - 2016-02-17 14:43:04 --> Database Driver Class Initialized
INFO - 2016-02-17 14:43:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:43:05 --> Controller Class Initialized
INFO - 2016-02-17 14:43:05 --> Model Class Initialized
INFO - 2016-02-17 14:43:05 --> Model Class Initialized
INFO - 2016-02-17 14:43:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:43:05 --> Pagination Class Initialized
INFO - 2016-02-17 14:43:05 --> Helper loaded: text_helper
INFO - 2016-02-17 14:43:05 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:43:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:43:05 --> Final output sent to browser
DEBUG - 2016-02-17 17:43:05 --> Total execution time: 1.1313
INFO - 2016-02-17 14:51:54 --> Config Class Initialized
INFO - 2016-02-17 14:51:54 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:51:54 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:51:54 --> Utf8 Class Initialized
INFO - 2016-02-17 14:51:54 --> URI Class Initialized
DEBUG - 2016-02-17 14:51:54 --> No URI present. Default controller set.
INFO - 2016-02-17 14:51:54 --> Router Class Initialized
INFO - 2016-02-17 14:51:54 --> Output Class Initialized
INFO - 2016-02-17 14:51:54 --> Security Class Initialized
DEBUG - 2016-02-17 14:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:51:54 --> Input Class Initialized
INFO - 2016-02-17 14:51:54 --> Language Class Initialized
INFO - 2016-02-17 14:51:54 --> Loader Class Initialized
INFO - 2016-02-17 14:51:54 --> Helper loaded: url_helper
INFO - 2016-02-17 14:51:54 --> Helper loaded: file_helper
INFO - 2016-02-17 14:51:54 --> Helper loaded: date_helper
INFO - 2016-02-17 14:51:54 --> Helper loaded: form_helper
INFO - 2016-02-17 14:51:54 --> Database Driver Class Initialized
INFO - 2016-02-17 14:51:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:51:56 --> Controller Class Initialized
INFO - 2016-02-17 14:51:56 --> Model Class Initialized
INFO - 2016-02-17 14:51:56 --> Model Class Initialized
INFO - 2016-02-17 14:51:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:51:56 --> Pagination Class Initialized
INFO - 2016-02-17 14:51:56 --> Helper loaded: text_helper
INFO - 2016-02-17 14:51:56 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:51:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:51:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:51:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:51:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:51:56 --> Final output sent to browser
DEBUG - 2016-02-17 17:51:56 --> Total execution time: 1.1446
INFO - 2016-02-17 14:52:01 --> Config Class Initialized
INFO - 2016-02-17 14:52:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:52:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:52:01 --> Utf8 Class Initialized
INFO - 2016-02-17 14:52:01 --> URI Class Initialized
DEBUG - 2016-02-17 14:52:01 --> No URI present. Default controller set.
INFO - 2016-02-17 14:52:01 --> Router Class Initialized
INFO - 2016-02-17 14:52:01 --> Output Class Initialized
INFO - 2016-02-17 14:52:01 --> Security Class Initialized
DEBUG - 2016-02-17 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:52:01 --> Input Class Initialized
INFO - 2016-02-17 14:52:01 --> Language Class Initialized
INFO - 2016-02-17 14:52:01 --> Loader Class Initialized
INFO - 2016-02-17 14:52:01 --> Helper loaded: url_helper
INFO - 2016-02-17 14:52:01 --> Helper loaded: file_helper
INFO - 2016-02-17 14:52:01 --> Helper loaded: date_helper
INFO - 2016-02-17 14:52:01 --> Helper loaded: form_helper
INFO - 2016-02-17 14:52:01 --> Database Driver Class Initialized
INFO - 2016-02-17 14:52:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:52:02 --> Controller Class Initialized
INFO - 2016-02-17 14:52:02 --> Model Class Initialized
INFO - 2016-02-17 14:52:02 --> Model Class Initialized
INFO - 2016-02-17 14:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:52:02 --> Pagination Class Initialized
INFO - 2016-02-17 14:52:02 --> Helper loaded: text_helper
INFO - 2016-02-17 14:52:02 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:52:02 --> Final output sent to browser
DEBUG - 2016-02-17 17:52:02 --> Total execution time: 1.0984
INFO - 2016-02-17 14:52:23 --> Config Class Initialized
INFO - 2016-02-17 14:52:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:52:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:52:23 --> Utf8 Class Initialized
INFO - 2016-02-17 14:52:23 --> URI Class Initialized
DEBUG - 2016-02-17 14:52:23 --> No URI present. Default controller set.
INFO - 2016-02-17 14:52:23 --> Router Class Initialized
INFO - 2016-02-17 14:52:23 --> Output Class Initialized
INFO - 2016-02-17 14:52:23 --> Security Class Initialized
DEBUG - 2016-02-17 14:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:52:23 --> Input Class Initialized
INFO - 2016-02-17 14:52:23 --> Language Class Initialized
INFO - 2016-02-17 14:52:23 --> Loader Class Initialized
INFO - 2016-02-17 14:52:23 --> Helper loaded: url_helper
INFO - 2016-02-17 14:52:23 --> Helper loaded: file_helper
INFO - 2016-02-17 14:52:23 --> Helper loaded: date_helper
INFO - 2016-02-17 14:52:23 --> Helper loaded: form_helper
INFO - 2016-02-17 14:52:23 --> Database Driver Class Initialized
INFO - 2016-02-17 14:52:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:52:24 --> Controller Class Initialized
INFO - 2016-02-17 14:52:24 --> Model Class Initialized
INFO - 2016-02-17 14:52:24 --> Model Class Initialized
INFO - 2016-02-17 14:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:52:24 --> Pagination Class Initialized
INFO - 2016-02-17 14:52:24 --> Helper loaded: text_helper
INFO - 2016-02-17 14:52:24 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:52:24 --> Final output sent to browser
DEBUG - 2016-02-17 17:52:24 --> Total execution time: 1.1613
INFO - 2016-02-17 14:53:01 --> Config Class Initialized
INFO - 2016-02-17 14:53:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:53:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:53:01 --> Utf8 Class Initialized
INFO - 2016-02-17 14:53:01 --> URI Class Initialized
DEBUG - 2016-02-17 14:53:01 --> No URI present. Default controller set.
INFO - 2016-02-17 14:53:01 --> Router Class Initialized
INFO - 2016-02-17 14:53:01 --> Output Class Initialized
INFO - 2016-02-17 14:53:01 --> Security Class Initialized
DEBUG - 2016-02-17 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:53:01 --> Input Class Initialized
INFO - 2016-02-17 14:53:01 --> Language Class Initialized
INFO - 2016-02-17 14:53:01 --> Loader Class Initialized
INFO - 2016-02-17 14:53:01 --> Helper loaded: url_helper
INFO - 2016-02-17 14:53:01 --> Helper loaded: file_helper
INFO - 2016-02-17 14:53:01 --> Helper loaded: date_helper
INFO - 2016-02-17 14:53:01 --> Helper loaded: form_helper
INFO - 2016-02-17 14:53:01 --> Database Driver Class Initialized
INFO - 2016-02-17 14:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:53:02 --> Controller Class Initialized
INFO - 2016-02-17 14:53:02 --> Model Class Initialized
INFO - 2016-02-17 14:53:02 --> Model Class Initialized
INFO - 2016-02-17 14:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:53:02 --> Pagination Class Initialized
INFO - 2016-02-17 14:53:02 --> Helper loaded: text_helper
INFO - 2016-02-17 14:53:02 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:53:02 --> Final output sent to browser
DEBUG - 2016-02-17 17:53:02 --> Total execution time: 1.1391
INFO - 2016-02-17 14:53:49 --> Config Class Initialized
INFO - 2016-02-17 14:53:49 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:53:49 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:53:49 --> Utf8 Class Initialized
INFO - 2016-02-17 14:53:49 --> URI Class Initialized
INFO - 2016-02-17 14:53:49 --> Router Class Initialized
INFO - 2016-02-17 14:53:49 --> Output Class Initialized
INFO - 2016-02-17 14:53:49 --> Security Class Initialized
DEBUG - 2016-02-17 14:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:53:49 --> Input Class Initialized
INFO - 2016-02-17 14:53:49 --> Language Class Initialized
INFO - 2016-02-17 14:53:49 --> Loader Class Initialized
INFO - 2016-02-17 14:53:49 --> Helper loaded: url_helper
INFO - 2016-02-17 14:53:49 --> Helper loaded: file_helper
INFO - 2016-02-17 14:53:49 --> Helper loaded: date_helper
INFO - 2016-02-17 14:53:49 --> Helper loaded: form_helper
INFO - 2016-02-17 14:53:49 --> Database Driver Class Initialized
INFO - 2016-02-17 14:53:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:53:50 --> Controller Class Initialized
INFO - 2016-02-17 14:53:50 --> Model Class Initialized
INFO - 2016-02-17 14:53:50 --> Model Class Initialized
INFO - 2016-02-17 14:53:50 --> Form Validation Class Initialized
INFO - 2016-02-17 14:53:50 --> Helper loaded: text_helper
INFO - 2016-02-17 14:53:50 --> Final output sent to browser
DEBUG - 2016-02-17 14:53:50 --> Total execution time: 1.1208
INFO - 2016-02-17 14:54:33 --> Config Class Initialized
INFO - 2016-02-17 14:54:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:54:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:54:33 --> Utf8 Class Initialized
INFO - 2016-02-17 14:54:33 --> URI Class Initialized
INFO - 2016-02-17 14:54:33 --> Router Class Initialized
INFO - 2016-02-17 14:54:33 --> Output Class Initialized
INFO - 2016-02-17 14:54:33 --> Security Class Initialized
DEBUG - 2016-02-17 14:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:54:33 --> Input Class Initialized
INFO - 2016-02-17 14:54:33 --> Language Class Initialized
INFO - 2016-02-17 14:54:33 --> Loader Class Initialized
INFO - 2016-02-17 14:54:33 --> Helper loaded: url_helper
INFO - 2016-02-17 14:54:33 --> Helper loaded: file_helper
INFO - 2016-02-17 14:54:33 --> Helper loaded: date_helper
INFO - 2016-02-17 14:54:33 --> Helper loaded: form_helper
INFO - 2016-02-17 14:54:33 --> Database Driver Class Initialized
INFO - 2016-02-17 14:54:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:54:34 --> Controller Class Initialized
INFO - 2016-02-17 14:54:34 --> Model Class Initialized
INFO - 2016-02-17 14:54:34 --> Model Class Initialized
INFO - 2016-02-17 14:54:34 --> Form Validation Class Initialized
INFO - 2016-02-17 14:54:34 --> Helper loaded: text_helper
INFO - 2016-02-17 14:54:34 --> Final output sent to browser
DEBUG - 2016-02-17 14:54:34 --> Total execution time: 1.0894
INFO - 2016-02-17 14:57:58 --> Config Class Initialized
INFO - 2016-02-17 14:57:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:57:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:57:58 --> Utf8 Class Initialized
INFO - 2016-02-17 14:57:58 --> URI Class Initialized
INFO - 2016-02-17 14:57:58 --> Router Class Initialized
INFO - 2016-02-17 14:57:58 --> Output Class Initialized
INFO - 2016-02-17 14:57:58 --> Security Class Initialized
DEBUG - 2016-02-17 14:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:57:58 --> Input Class Initialized
INFO - 2016-02-17 14:57:58 --> Language Class Initialized
INFO - 2016-02-17 14:57:58 --> Loader Class Initialized
INFO - 2016-02-17 14:57:58 --> Helper loaded: url_helper
INFO - 2016-02-17 14:57:58 --> Helper loaded: file_helper
INFO - 2016-02-17 14:57:58 --> Helper loaded: date_helper
INFO - 2016-02-17 14:57:58 --> Helper loaded: form_helper
INFO - 2016-02-17 14:57:58 --> Database Driver Class Initialized
INFO - 2016-02-17 14:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:57:59 --> Controller Class Initialized
INFO - 2016-02-17 14:57:59 --> Model Class Initialized
INFO - 2016-02-17 14:57:59 --> Model Class Initialized
INFO - 2016-02-17 14:57:59 --> Form Validation Class Initialized
INFO - 2016-02-17 14:57:59 --> Helper loaded: text_helper
INFO - 2016-02-17 14:57:59 --> Final output sent to browser
DEBUG - 2016-02-17 14:57:59 --> Total execution time: 1.1043
INFO - 2016-02-17 14:58:40 --> Config Class Initialized
INFO - 2016-02-17 14:58:40 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:58:40 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:58:40 --> Utf8 Class Initialized
INFO - 2016-02-17 14:58:40 --> URI Class Initialized
INFO - 2016-02-17 14:58:40 --> Router Class Initialized
INFO - 2016-02-17 14:58:40 --> Output Class Initialized
INFO - 2016-02-17 14:58:40 --> Security Class Initialized
DEBUG - 2016-02-17 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:58:40 --> Input Class Initialized
INFO - 2016-02-17 14:58:40 --> Language Class Initialized
INFO - 2016-02-17 14:58:40 --> Loader Class Initialized
INFO - 2016-02-17 14:58:40 --> Helper loaded: url_helper
INFO - 2016-02-17 14:58:40 --> Helper loaded: file_helper
INFO - 2016-02-17 14:58:40 --> Helper loaded: date_helper
INFO - 2016-02-17 14:58:40 --> Helper loaded: form_helper
INFO - 2016-02-17 14:58:40 --> Database Driver Class Initialized
INFO - 2016-02-17 14:58:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:58:41 --> Controller Class Initialized
INFO - 2016-02-17 14:58:41 --> Model Class Initialized
INFO - 2016-02-17 14:58:41 --> Model Class Initialized
INFO - 2016-02-17 14:58:41 --> Form Validation Class Initialized
INFO - 2016-02-17 14:58:41 --> Helper loaded: text_helper
INFO - 2016-02-17 14:58:41 --> Final output sent to browser
DEBUG - 2016-02-17 14:58:41 --> Total execution time: 1.1134
INFO - 2016-02-17 14:58:43 --> Config Class Initialized
INFO - 2016-02-17 14:58:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:58:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:58:43 --> Utf8 Class Initialized
INFO - 2016-02-17 14:58:43 --> URI Class Initialized
INFO - 2016-02-17 14:58:43 --> Router Class Initialized
INFO - 2016-02-17 14:58:43 --> Output Class Initialized
INFO - 2016-02-17 14:58:43 --> Security Class Initialized
DEBUG - 2016-02-17 14:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:58:43 --> Input Class Initialized
INFO - 2016-02-17 14:58:43 --> Language Class Initialized
INFO - 2016-02-17 14:58:43 --> Loader Class Initialized
INFO - 2016-02-17 14:58:43 --> Helper loaded: url_helper
INFO - 2016-02-17 14:58:43 --> Helper loaded: file_helper
INFO - 2016-02-17 14:58:43 --> Helper loaded: date_helper
INFO - 2016-02-17 14:58:43 --> Helper loaded: form_helper
INFO - 2016-02-17 14:58:43 --> Database Driver Class Initialized
INFO - 2016-02-17 14:58:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:58:44 --> Controller Class Initialized
INFO - 2016-02-17 14:58:44 --> Model Class Initialized
INFO - 2016-02-17 14:58:44 --> Model Class Initialized
INFO - 2016-02-17 14:58:44 --> Form Validation Class Initialized
INFO - 2016-02-17 14:58:44 --> Helper loaded: text_helper
INFO - 2016-02-17 14:58:44 --> Final output sent to browser
DEBUG - 2016-02-17 14:58:44 --> Total execution time: 1.1278
INFO - 2016-02-17 14:59:18 --> Config Class Initialized
INFO - 2016-02-17 14:59:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:18 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:18 --> URI Class Initialized
DEBUG - 2016-02-17 14:59:18 --> No URI present. Default controller set.
INFO - 2016-02-17 14:59:18 --> Router Class Initialized
INFO - 2016-02-17 14:59:18 --> Output Class Initialized
INFO - 2016-02-17 14:59:18 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:18 --> Input Class Initialized
INFO - 2016-02-17 14:59:18 --> Language Class Initialized
INFO - 2016-02-17 14:59:18 --> Loader Class Initialized
INFO - 2016-02-17 14:59:18 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:18 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:18 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:18 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:18 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:19 --> Controller Class Initialized
INFO - 2016-02-17 14:59:19 --> Model Class Initialized
INFO - 2016-02-17 14:59:19 --> Model Class Initialized
INFO - 2016-02-17 14:59:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 14:59:19 --> Pagination Class Initialized
INFO - 2016-02-17 14:59:19 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:19 --> Helper loaded: cookie_helper
INFO - 2016-02-17 17:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 17:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 17:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 17:59:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 17:59:19 --> Final output sent to browser
DEBUG - 2016-02-17 17:59:19 --> Total execution time: 1.1123
INFO - 2016-02-17 14:59:21 --> Config Class Initialized
INFO - 2016-02-17 14:59:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:21 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:21 --> URI Class Initialized
INFO - 2016-02-17 14:59:21 --> Router Class Initialized
INFO - 2016-02-17 14:59:21 --> Output Class Initialized
INFO - 2016-02-17 14:59:21 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:21 --> Input Class Initialized
INFO - 2016-02-17 14:59:21 --> Language Class Initialized
INFO - 2016-02-17 14:59:21 --> Loader Class Initialized
INFO - 2016-02-17 14:59:21 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:21 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:21 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:21 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:22 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:23 --> Controller Class Initialized
INFO - 2016-02-17 14:59:23 --> Model Class Initialized
INFO - 2016-02-17 14:59:23 --> Model Class Initialized
INFO - 2016-02-17 14:59:23 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:23 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:23 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:23 --> Total execution time: 1.1147
INFO - 2016-02-17 14:59:23 --> Config Class Initialized
INFO - 2016-02-17 14:59:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:23 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:23 --> URI Class Initialized
INFO - 2016-02-17 14:59:23 --> Router Class Initialized
INFO - 2016-02-17 14:59:23 --> Output Class Initialized
INFO - 2016-02-17 14:59:23 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:23 --> Input Class Initialized
INFO - 2016-02-17 14:59:23 --> Language Class Initialized
INFO - 2016-02-17 14:59:23 --> Loader Class Initialized
INFO - 2016-02-17 14:59:23 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:23 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:23 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:23 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:23 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:23 --> Config Class Initialized
INFO - 2016-02-17 14:59:23 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:23 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:23 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:23 --> URI Class Initialized
INFO - 2016-02-17 14:59:23 --> Router Class Initialized
INFO - 2016-02-17 14:59:23 --> Output Class Initialized
INFO - 2016-02-17 14:59:23 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:23 --> Input Class Initialized
INFO - 2016-02-17 14:59:23 --> Language Class Initialized
INFO - 2016-02-17 14:59:23 --> Loader Class Initialized
INFO - 2016-02-17 14:59:23 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:24 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:24 --> Config Class Initialized
INFO - 2016-02-17 14:59:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:24 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:24 --> URI Class Initialized
INFO - 2016-02-17 14:59:24 --> Router Class Initialized
INFO - 2016-02-17 14:59:24 --> Output Class Initialized
INFO - 2016-02-17 14:59:24 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:24 --> Input Class Initialized
INFO - 2016-02-17 14:59:24 --> Language Class Initialized
INFO - 2016-02-17 14:59:24 --> Loader Class Initialized
INFO - 2016-02-17 14:59:24 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:24 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:24 --> Config Class Initialized
INFO - 2016-02-17 14:59:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:24 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:24 --> URI Class Initialized
INFO - 2016-02-17 14:59:24 --> Router Class Initialized
INFO - 2016-02-17 14:59:24 --> Output Class Initialized
INFO - 2016-02-17 14:59:24 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:24 --> Input Class Initialized
INFO - 2016-02-17 14:59:24 --> Language Class Initialized
INFO - 2016-02-17 14:59:24 --> Loader Class Initialized
INFO - 2016-02-17 14:59:24 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:24 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:24 --> Config Class Initialized
INFO - 2016-02-17 14:59:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 14:59:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 14:59:24 --> Utf8 Class Initialized
INFO - 2016-02-17 14:59:24 --> URI Class Initialized
INFO - 2016-02-17 14:59:24 --> Router Class Initialized
INFO - 2016-02-17 14:59:24 --> Output Class Initialized
INFO - 2016-02-17 14:59:24 --> Security Class Initialized
DEBUG - 2016-02-17 14:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 14:59:24 --> Input Class Initialized
INFO - 2016-02-17 14:59:24 --> Language Class Initialized
INFO - 2016-02-17 14:59:24 --> Loader Class Initialized
INFO - 2016-02-17 14:59:24 --> Helper loaded: url_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: file_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: date_helper
INFO - 2016-02-17 14:59:24 --> Helper loaded: form_helper
INFO - 2016-02-17 14:59:24 --> Database Driver Class Initialized
INFO - 2016-02-17 14:59:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:24 --> Controller Class Initialized
INFO - 2016-02-17 14:59:24 --> Model Class Initialized
INFO - 2016-02-17 14:59:24 --> Model Class Initialized
INFO - 2016-02-17 14:59:24 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:24 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:24 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:24 --> Total execution time: 1.1251
INFO - 2016-02-17 14:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:25 --> Controller Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:25 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:25 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:25 --> Total execution time: 1.0942
INFO - 2016-02-17 14:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:25 --> Controller Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:25 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:25 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:25 --> Total execution time: 1.1095
INFO - 2016-02-17 14:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:25 --> Controller Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:25 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:25 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:25 --> Total execution time: 1.0735
INFO - 2016-02-17 14:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 14:59:25 --> Controller Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Model Class Initialized
INFO - 2016-02-17 14:59:25 --> Form Validation Class Initialized
INFO - 2016-02-17 14:59:25 --> Helper loaded: text_helper
INFO - 2016-02-17 14:59:25 --> Final output sent to browser
DEBUG - 2016-02-17 14:59:25 --> Total execution time: 1.1453
INFO - 2016-02-17 15:00:58 --> Config Class Initialized
INFO - 2016-02-17 15:00:58 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:00:58 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:00:58 --> Utf8 Class Initialized
INFO - 2016-02-17 15:00:58 --> URI Class Initialized
DEBUG - 2016-02-17 15:00:58 --> No URI present. Default controller set.
INFO - 2016-02-17 15:00:58 --> Router Class Initialized
INFO - 2016-02-17 15:00:58 --> Output Class Initialized
INFO - 2016-02-17 15:00:58 --> Security Class Initialized
DEBUG - 2016-02-17 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:00:58 --> Input Class Initialized
INFO - 2016-02-17 15:00:58 --> Language Class Initialized
INFO - 2016-02-17 15:00:58 --> Loader Class Initialized
INFO - 2016-02-17 15:00:58 --> Helper loaded: url_helper
INFO - 2016-02-17 15:00:58 --> Helper loaded: file_helper
INFO - 2016-02-17 15:00:58 --> Helper loaded: date_helper
INFO - 2016-02-17 15:00:58 --> Helper loaded: form_helper
INFO - 2016-02-17 15:00:58 --> Database Driver Class Initialized
INFO - 2016-02-17 15:00:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:00:59 --> Controller Class Initialized
INFO - 2016-02-17 15:00:59 --> Model Class Initialized
INFO - 2016-02-17 15:00:59 --> Model Class Initialized
INFO - 2016-02-17 15:00:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:00:59 --> Pagination Class Initialized
INFO - 2016-02-17 15:01:00 --> Helper loaded: text_helper
INFO - 2016-02-17 15:01:00 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:01:00 --> Final output sent to browser
DEBUG - 2016-02-17 18:01:00 --> Total execution time: 1.1555
INFO - 2016-02-17 15:02:14 --> Config Class Initialized
INFO - 2016-02-17 15:02:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:02:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:02:14 --> Utf8 Class Initialized
INFO - 2016-02-17 15:02:14 --> URI Class Initialized
DEBUG - 2016-02-17 15:02:14 --> No URI present. Default controller set.
INFO - 2016-02-17 15:02:14 --> Router Class Initialized
INFO - 2016-02-17 15:02:14 --> Output Class Initialized
INFO - 2016-02-17 15:02:14 --> Security Class Initialized
DEBUG - 2016-02-17 15:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:02:14 --> Input Class Initialized
INFO - 2016-02-17 15:02:14 --> Language Class Initialized
INFO - 2016-02-17 15:02:14 --> Loader Class Initialized
INFO - 2016-02-17 15:02:14 --> Helper loaded: url_helper
INFO - 2016-02-17 15:02:14 --> Helper loaded: file_helper
INFO - 2016-02-17 15:02:14 --> Helper loaded: date_helper
INFO - 2016-02-17 15:02:14 --> Helper loaded: form_helper
INFO - 2016-02-17 15:02:14 --> Database Driver Class Initialized
INFO - 2016-02-17 15:02:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:02:16 --> Controller Class Initialized
INFO - 2016-02-17 15:02:16 --> Model Class Initialized
INFO - 2016-02-17 15:02:16 --> Model Class Initialized
INFO - 2016-02-17 15:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:02:16 --> Pagination Class Initialized
INFO - 2016-02-17 15:02:16 --> Helper loaded: text_helper
INFO - 2016-02-17 15:02:16 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:02:16 --> Final output sent to browser
DEBUG - 2016-02-17 18:02:16 --> Total execution time: 1.1370
INFO - 2016-02-17 15:02:18 --> Config Class Initialized
INFO - 2016-02-17 15:02:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:02:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:02:18 --> Utf8 Class Initialized
INFO - 2016-02-17 15:02:18 --> URI Class Initialized
INFO - 2016-02-17 15:02:18 --> Router Class Initialized
INFO - 2016-02-17 15:02:18 --> Output Class Initialized
INFO - 2016-02-17 15:02:18 --> Security Class Initialized
DEBUG - 2016-02-17 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:02:18 --> Input Class Initialized
INFO - 2016-02-17 15:02:18 --> Language Class Initialized
INFO - 2016-02-17 15:02:18 --> Loader Class Initialized
INFO - 2016-02-17 15:02:18 --> Helper loaded: url_helper
INFO - 2016-02-17 15:02:18 --> Helper loaded: file_helper
INFO - 2016-02-17 15:02:18 --> Helper loaded: date_helper
INFO - 2016-02-17 15:02:18 --> Helper loaded: form_helper
INFO - 2016-02-17 15:02:18 --> Database Driver Class Initialized
INFO - 2016-02-17 15:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:02:19 --> Controller Class Initialized
INFO - 2016-02-17 15:02:19 --> Model Class Initialized
INFO - 2016-02-17 15:02:19 --> Model Class Initialized
INFO - 2016-02-17 15:02:19 --> Form Validation Class Initialized
INFO - 2016-02-17 15:02:19 --> Helper loaded: text_helper
INFO - 2016-02-17 15:02:19 --> Final output sent to browser
DEBUG - 2016-02-17 15:02:19 --> Total execution time: 1.1090
INFO - 2016-02-17 15:02:22 --> Config Class Initialized
INFO - 2016-02-17 15:02:22 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:02:22 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:02:22 --> Utf8 Class Initialized
INFO - 2016-02-17 15:02:22 --> URI Class Initialized
DEBUG - 2016-02-17 15:02:22 --> No URI present. Default controller set.
INFO - 2016-02-17 15:02:22 --> Router Class Initialized
INFO - 2016-02-17 15:02:22 --> Output Class Initialized
INFO - 2016-02-17 15:02:22 --> Security Class Initialized
DEBUG - 2016-02-17 15:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:02:22 --> Input Class Initialized
INFO - 2016-02-17 15:02:22 --> Language Class Initialized
INFO - 2016-02-17 15:02:22 --> Loader Class Initialized
INFO - 2016-02-17 15:02:22 --> Helper loaded: url_helper
INFO - 2016-02-17 15:02:22 --> Helper loaded: file_helper
INFO - 2016-02-17 15:02:22 --> Helper loaded: date_helper
INFO - 2016-02-17 15:02:22 --> Helper loaded: form_helper
INFO - 2016-02-17 15:02:22 --> Database Driver Class Initialized
INFO - 2016-02-17 15:02:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:02:23 --> Controller Class Initialized
INFO - 2016-02-17 15:02:23 --> Model Class Initialized
INFO - 2016-02-17 15:02:23 --> Model Class Initialized
INFO - 2016-02-17 15:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:02:23 --> Pagination Class Initialized
INFO - 2016-02-17 15:02:23 --> Helper loaded: text_helper
INFO - 2016-02-17 15:02:23 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:02:23 --> Final output sent to browser
DEBUG - 2016-02-17 18:02:23 --> Total execution time: 1.1331
INFO - 2016-02-17 15:03:41 --> Config Class Initialized
INFO - 2016-02-17 15:03:41 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:03:41 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:03:41 --> Utf8 Class Initialized
INFO - 2016-02-17 15:03:41 --> URI Class Initialized
DEBUG - 2016-02-17 15:03:41 --> No URI present. Default controller set.
INFO - 2016-02-17 15:03:41 --> Router Class Initialized
INFO - 2016-02-17 15:03:41 --> Output Class Initialized
INFO - 2016-02-17 15:03:41 --> Security Class Initialized
DEBUG - 2016-02-17 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:03:41 --> Input Class Initialized
INFO - 2016-02-17 15:03:41 --> Language Class Initialized
INFO - 2016-02-17 15:03:41 --> Loader Class Initialized
INFO - 2016-02-17 15:03:41 --> Helper loaded: url_helper
INFO - 2016-02-17 15:03:41 --> Helper loaded: file_helper
INFO - 2016-02-17 15:03:41 --> Helper loaded: date_helper
INFO - 2016-02-17 15:03:41 --> Helper loaded: form_helper
INFO - 2016-02-17 15:03:41 --> Database Driver Class Initialized
INFO - 2016-02-17 15:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:03:42 --> Controller Class Initialized
INFO - 2016-02-17 15:03:42 --> Model Class Initialized
INFO - 2016-02-17 15:03:42 --> Model Class Initialized
INFO - 2016-02-17 15:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:03:42 --> Pagination Class Initialized
INFO - 2016-02-17 15:03:42 --> Helper loaded: text_helper
INFO - 2016-02-17 15:03:42 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:03:42 --> Final output sent to browser
DEBUG - 2016-02-17 18:03:42 --> Total execution time: 1.1558
INFO - 2016-02-17 15:03:44 --> Config Class Initialized
INFO - 2016-02-17 15:03:44 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:03:44 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:03:44 --> Utf8 Class Initialized
INFO - 2016-02-17 15:03:44 --> URI Class Initialized
INFO - 2016-02-17 15:03:44 --> Router Class Initialized
INFO - 2016-02-17 15:03:44 --> Output Class Initialized
INFO - 2016-02-17 15:03:44 --> Security Class Initialized
DEBUG - 2016-02-17 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:03:44 --> Input Class Initialized
INFO - 2016-02-17 15:03:44 --> Language Class Initialized
INFO - 2016-02-17 15:03:44 --> Loader Class Initialized
INFO - 2016-02-17 15:03:44 --> Helper loaded: url_helper
INFO - 2016-02-17 15:03:44 --> Helper loaded: file_helper
INFO - 2016-02-17 15:03:44 --> Helper loaded: date_helper
INFO - 2016-02-17 15:03:44 --> Helper loaded: form_helper
INFO - 2016-02-17 15:03:44 --> Database Driver Class Initialized
INFO - 2016-02-17 15:03:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:03:45 --> Controller Class Initialized
INFO - 2016-02-17 15:03:45 --> Model Class Initialized
INFO - 2016-02-17 15:03:45 --> Model Class Initialized
INFO - 2016-02-17 15:03:45 --> Form Validation Class Initialized
INFO - 2016-02-17 15:03:45 --> Helper loaded: text_helper
INFO - 2016-02-17 15:03:45 --> Final output sent to browser
DEBUG - 2016-02-17 15:03:45 --> Total execution time: 1.1174
INFO - 2016-02-17 15:03:55 --> Config Class Initialized
INFO - 2016-02-17 15:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:03:55 --> Utf8 Class Initialized
INFO - 2016-02-17 15:03:55 --> URI Class Initialized
DEBUG - 2016-02-17 15:03:55 --> No URI present. Default controller set.
INFO - 2016-02-17 15:03:55 --> Router Class Initialized
INFO - 2016-02-17 15:03:55 --> Output Class Initialized
INFO - 2016-02-17 15:03:55 --> Security Class Initialized
DEBUG - 2016-02-17 15:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:03:55 --> Input Class Initialized
INFO - 2016-02-17 15:03:55 --> Language Class Initialized
INFO - 2016-02-17 15:03:55 --> Loader Class Initialized
INFO - 2016-02-17 15:03:55 --> Helper loaded: url_helper
INFO - 2016-02-17 15:03:55 --> Helper loaded: file_helper
INFO - 2016-02-17 15:03:55 --> Helper loaded: date_helper
INFO - 2016-02-17 15:03:55 --> Helper loaded: form_helper
INFO - 2016-02-17 15:03:55 --> Database Driver Class Initialized
INFO - 2016-02-17 15:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:03:56 --> Controller Class Initialized
INFO - 2016-02-17 15:03:56 --> Model Class Initialized
INFO - 2016-02-17 15:03:56 --> Model Class Initialized
INFO - 2016-02-17 15:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:03:56 --> Pagination Class Initialized
INFO - 2016-02-17 15:03:56 --> Helper loaded: text_helper
INFO - 2016-02-17 15:03:56 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:03:56 --> Final output sent to browser
DEBUG - 2016-02-17 18:03:56 --> Total execution time: 1.1185
INFO - 2016-02-17 15:04:03 --> Config Class Initialized
INFO - 2016-02-17 15:04:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:04:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:04:03 --> Utf8 Class Initialized
INFO - 2016-02-17 15:04:03 --> URI Class Initialized
INFO - 2016-02-17 15:04:03 --> Router Class Initialized
INFO - 2016-02-17 15:04:03 --> Output Class Initialized
INFO - 2016-02-17 15:04:03 --> Security Class Initialized
DEBUG - 2016-02-17 15:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:04:03 --> Input Class Initialized
INFO - 2016-02-17 15:04:03 --> Language Class Initialized
INFO - 2016-02-17 15:04:03 --> Loader Class Initialized
INFO - 2016-02-17 15:04:03 --> Helper loaded: url_helper
INFO - 2016-02-17 15:04:03 --> Helper loaded: file_helper
INFO - 2016-02-17 15:04:03 --> Helper loaded: date_helper
INFO - 2016-02-17 15:04:03 --> Helper loaded: form_helper
INFO - 2016-02-17 15:04:03 --> Database Driver Class Initialized
INFO - 2016-02-17 15:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:04:04 --> Controller Class Initialized
INFO - 2016-02-17 15:04:04 --> Model Class Initialized
INFO - 2016-02-17 15:04:04 --> Model Class Initialized
INFO - 2016-02-17 15:04:04 --> Form Validation Class Initialized
INFO - 2016-02-17 15:04:04 --> Helper loaded: text_helper
INFO - 2016-02-17 15:04:04 --> Final output sent to browser
DEBUG - 2016-02-17 15:04:04 --> Total execution time: 1.0931
INFO - 2016-02-17 15:04:08 --> Config Class Initialized
INFO - 2016-02-17 15:04:08 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:04:08 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:04:08 --> Utf8 Class Initialized
INFO - 2016-02-17 15:04:08 --> URI Class Initialized
DEBUG - 2016-02-17 15:04:08 --> No URI present. Default controller set.
INFO - 2016-02-17 15:04:08 --> Router Class Initialized
INFO - 2016-02-17 15:04:08 --> Output Class Initialized
INFO - 2016-02-17 15:04:08 --> Security Class Initialized
DEBUG - 2016-02-17 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:04:08 --> Input Class Initialized
INFO - 2016-02-17 15:04:08 --> Language Class Initialized
INFO - 2016-02-17 15:04:08 --> Loader Class Initialized
INFO - 2016-02-17 15:04:08 --> Helper loaded: url_helper
INFO - 2016-02-17 15:04:08 --> Helper loaded: file_helper
INFO - 2016-02-17 15:04:08 --> Helper loaded: date_helper
INFO - 2016-02-17 15:04:08 --> Helper loaded: form_helper
INFO - 2016-02-17 15:04:08 --> Database Driver Class Initialized
INFO - 2016-02-17 15:04:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:04:09 --> Controller Class Initialized
INFO - 2016-02-17 15:04:09 --> Model Class Initialized
INFO - 2016-02-17 15:04:09 --> Model Class Initialized
INFO - 2016-02-17 15:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:04:09 --> Pagination Class Initialized
INFO - 2016-02-17 15:04:09 --> Helper loaded: text_helper
INFO - 2016-02-17 15:04:09 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:04:09 --> Final output sent to browser
DEBUG - 2016-02-17 18:04:09 --> Total execution time: 1.1625
INFO - 2016-02-17 15:04:18 --> Config Class Initialized
INFO - 2016-02-17 15:04:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:04:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:04:18 --> Utf8 Class Initialized
INFO - 2016-02-17 15:04:18 --> URI Class Initialized
INFO - 2016-02-17 15:04:18 --> Router Class Initialized
INFO - 2016-02-17 15:04:18 --> Output Class Initialized
INFO - 2016-02-17 15:04:18 --> Security Class Initialized
DEBUG - 2016-02-17 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:04:18 --> Input Class Initialized
INFO - 2016-02-17 15:04:18 --> Language Class Initialized
INFO - 2016-02-17 15:04:18 --> Loader Class Initialized
INFO - 2016-02-17 15:04:18 --> Helper loaded: url_helper
INFO - 2016-02-17 15:04:18 --> Helper loaded: file_helper
INFO - 2016-02-17 15:04:18 --> Helper loaded: date_helper
INFO - 2016-02-17 15:04:18 --> Helper loaded: form_helper
INFO - 2016-02-17 15:04:18 --> Database Driver Class Initialized
INFO - 2016-02-17 15:04:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:04:19 --> Controller Class Initialized
INFO - 2016-02-17 15:04:19 --> Model Class Initialized
INFO - 2016-02-17 15:04:19 --> Model Class Initialized
INFO - 2016-02-17 15:04:19 --> Form Validation Class Initialized
INFO - 2016-02-17 15:04:19 --> Helper loaded: text_helper
INFO - 2016-02-17 15:04:19 --> Config Class Initialized
INFO - 2016-02-17 15:04:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:04:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:04:19 --> Utf8 Class Initialized
INFO - 2016-02-17 15:04:19 --> URI Class Initialized
DEBUG - 2016-02-17 15:04:19 --> No URI present. Default controller set.
INFO - 2016-02-17 15:04:19 --> Router Class Initialized
INFO - 2016-02-17 15:04:19 --> Output Class Initialized
INFO - 2016-02-17 15:04:19 --> Security Class Initialized
DEBUG - 2016-02-17 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:04:19 --> Input Class Initialized
INFO - 2016-02-17 15:04:19 --> Language Class Initialized
INFO - 2016-02-17 15:04:19 --> Loader Class Initialized
INFO - 2016-02-17 15:04:19 --> Helper loaded: url_helper
INFO - 2016-02-17 15:04:19 --> Helper loaded: file_helper
INFO - 2016-02-17 15:04:19 --> Helper loaded: date_helper
INFO - 2016-02-17 15:04:19 --> Helper loaded: form_helper
INFO - 2016-02-17 15:04:19 --> Database Driver Class Initialized
INFO - 2016-02-17 15:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:04:20 --> Controller Class Initialized
INFO - 2016-02-17 15:04:20 --> Model Class Initialized
INFO - 2016-02-17 15:04:20 --> Model Class Initialized
INFO - 2016-02-17 15:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:04:20 --> Pagination Class Initialized
INFO - 2016-02-17 15:04:20 --> Helper loaded: text_helper
INFO - 2016-02-17 15:04:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:04:20 --> Final output sent to browser
DEBUG - 2016-02-17 18:04:20 --> Total execution time: 1.1665
INFO - 2016-02-17 15:07:01 --> Config Class Initialized
INFO - 2016-02-17 15:07:01 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:07:01 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:07:01 --> Utf8 Class Initialized
INFO - 2016-02-17 15:07:01 --> URI Class Initialized
DEBUG - 2016-02-17 15:07:01 --> No URI present. Default controller set.
INFO - 2016-02-17 15:07:01 --> Router Class Initialized
INFO - 2016-02-17 15:07:01 --> Output Class Initialized
INFO - 2016-02-17 15:07:01 --> Security Class Initialized
DEBUG - 2016-02-17 15:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:07:01 --> Input Class Initialized
INFO - 2016-02-17 15:07:01 --> Language Class Initialized
INFO - 2016-02-17 15:07:01 --> Loader Class Initialized
INFO - 2016-02-17 15:07:01 --> Helper loaded: url_helper
INFO - 2016-02-17 15:07:01 --> Helper loaded: file_helper
INFO - 2016-02-17 15:07:01 --> Helper loaded: date_helper
INFO - 2016-02-17 15:07:02 --> Helper loaded: form_helper
INFO - 2016-02-17 15:07:02 --> Database Driver Class Initialized
INFO - 2016-02-17 15:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:07:03 --> Controller Class Initialized
INFO - 2016-02-17 15:07:03 --> Model Class Initialized
INFO - 2016-02-17 15:07:03 --> Model Class Initialized
INFO - 2016-02-17 15:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:07:03 --> Pagination Class Initialized
INFO - 2016-02-17 15:07:03 --> Helper loaded: text_helper
INFO - 2016-02-17 15:07:03 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:07:03 --> Final output sent to browser
DEBUG - 2016-02-17 18:07:03 --> Total execution time: 1.1655
INFO - 2016-02-17 15:07:04 --> Config Class Initialized
INFO - 2016-02-17 15:07:04 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:07:04 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:07:04 --> Utf8 Class Initialized
INFO - 2016-02-17 15:07:04 --> URI Class Initialized
INFO - 2016-02-17 15:07:04 --> Router Class Initialized
INFO - 2016-02-17 15:07:04 --> Output Class Initialized
INFO - 2016-02-17 15:07:04 --> Security Class Initialized
DEBUG - 2016-02-17 15:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:07:04 --> Input Class Initialized
INFO - 2016-02-17 15:07:04 --> Language Class Initialized
INFO - 2016-02-17 15:07:04 --> Loader Class Initialized
INFO - 2016-02-17 15:07:04 --> Helper loaded: url_helper
INFO - 2016-02-17 15:07:04 --> Helper loaded: file_helper
INFO - 2016-02-17 15:07:04 --> Helper loaded: date_helper
INFO - 2016-02-17 15:07:04 --> Helper loaded: form_helper
INFO - 2016-02-17 15:07:04 --> Database Driver Class Initialized
INFO - 2016-02-17 15:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:07:05 --> Controller Class Initialized
INFO - 2016-02-17 15:07:05 --> Model Class Initialized
INFO - 2016-02-17 15:07:05 --> Model Class Initialized
INFO - 2016-02-17 15:07:05 --> Form Validation Class Initialized
INFO - 2016-02-17 15:07:05 --> Helper loaded: text_helper
INFO - 2016-02-17 15:07:05 --> Config Class Initialized
INFO - 2016-02-17 15:07:05 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:07:05 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:07:05 --> Utf8 Class Initialized
INFO - 2016-02-17 15:07:05 --> URI Class Initialized
INFO - 2016-02-17 15:07:05 --> Router Class Initialized
INFO - 2016-02-17 15:07:05 --> Output Class Initialized
INFO - 2016-02-17 15:07:05 --> Security Class Initialized
DEBUG - 2016-02-17 15:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:07:05 --> Input Class Initialized
INFO - 2016-02-17 15:07:05 --> Language Class Initialized
INFO - 2016-02-17 15:07:05 --> Loader Class Initialized
INFO - 2016-02-17 15:07:05 --> Helper loaded: url_helper
INFO - 2016-02-17 15:07:05 --> Helper loaded: file_helper
INFO - 2016-02-17 15:07:05 --> Helper loaded: date_helper
INFO - 2016-02-17 15:07:05 --> Helper loaded: form_helper
INFO - 2016-02-17 15:07:05 --> Database Driver Class Initialized
INFO - 2016-02-17 15:07:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:07:06 --> Controller Class Initialized
INFO - 2016-02-17 15:07:06 --> Model Class Initialized
INFO - 2016-02-17 15:07:06 --> Model Class Initialized
INFO - 2016-02-17 15:07:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:07:06 --> Pagination Class Initialized
INFO - 2016-02-17 15:07:06 --> Helper loaded: text_helper
INFO - 2016-02-17 15:07:06 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:07:06 --> Final output sent to browser
DEBUG - 2016-02-17 18:07:06 --> Total execution time: 1.1658
INFO - 2016-02-17 15:07:16 --> Config Class Initialized
INFO - 2016-02-17 15:07:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:07:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:07:16 --> Utf8 Class Initialized
INFO - 2016-02-17 15:07:16 --> URI Class Initialized
INFO - 2016-02-17 15:07:16 --> Router Class Initialized
INFO - 2016-02-17 15:07:16 --> Output Class Initialized
INFO - 2016-02-17 15:07:16 --> Security Class Initialized
DEBUG - 2016-02-17 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:07:16 --> Input Class Initialized
INFO - 2016-02-17 15:07:16 --> Language Class Initialized
INFO - 2016-02-17 15:07:16 --> Loader Class Initialized
INFO - 2016-02-17 15:07:16 --> Helper loaded: url_helper
INFO - 2016-02-17 15:07:16 --> Helper loaded: file_helper
INFO - 2016-02-17 15:07:16 --> Helper loaded: date_helper
INFO - 2016-02-17 15:07:16 --> Helper loaded: form_helper
INFO - 2016-02-17 15:07:16 --> Database Driver Class Initialized
INFO - 2016-02-17 15:07:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:07:17 --> Controller Class Initialized
INFO - 2016-02-17 15:07:17 --> Model Class Initialized
INFO - 2016-02-17 15:07:17 --> Model Class Initialized
INFO - 2016-02-17 15:07:17 --> Form Validation Class Initialized
INFO - 2016-02-17 15:07:17 --> Helper loaded: text_helper
INFO - 2016-02-17 15:07:17 --> Final output sent to browser
DEBUG - 2016-02-17 15:07:17 --> Total execution time: 1.2101
INFO - 2016-02-17 15:08:26 --> Config Class Initialized
INFO - 2016-02-17 15:08:26 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:08:26 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:08:26 --> Utf8 Class Initialized
INFO - 2016-02-17 15:08:26 --> URI Class Initialized
INFO - 2016-02-17 15:08:26 --> Router Class Initialized
INFO - 2016-02-17 15:08:26 --> Output Class Initialized
INFO - 2016-02-17 15:08:26 --> Security Class Initialized
DEBUG - 2016-02-17 15:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:08:26 --> Input Class Initialized
INFO - 2016-02-17 15:08:26 --> Language Class Initialized
INFO - 2016-02-17 15:08:26 --> Loader Class Initialized
INFO - 2016-02-17 15:08:26 --> Helper loaded: url_helper
INFO - 2016-02-17 15:08:26 --> Helper loaded: file_helper
INFO - 2016-02-17 15:08:26 --> Helper loaded: date_helper
INFO - 2016-02-17 15:08:26 --> Helper loaded: form_helper
INFO - 2016-02-17 15:08:26 --> Database Driver Class Initialized
INFO - 2016-02-17 15:08:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:08:27 --> Controller Class Initialized
INFO - 2016-02-17 15:08:27 --> Model Class Initialized
INFO - 2016-02-17 15:08:27 --> Model Class Initialized
INFO - 2016-02-17 15:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:08:27 --> Pagination Class Initialized
INFO - 2016-02-17 15:08:27 --> Helper loaded: text_helper
INFO - 2016-02-17 15:08:27 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:08:27 --> Final output sent to browser
DEBUG - 2016-02-17 18:08:27 --> Total execution time: 1.1547
INFO - 2016-02-17 15:08:34 --> Config Class Initialized
INFO - 2016-02-17 15:08:34 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:08:34 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:08:34 --> Utf8 Class Initialized
INFO - 2016-02-17 15:08:34 --> URI Class Initialized
INFO - 2016-02-17 15:08:34 --> Router Class Initialized
INFO - 2016-02-17 15:08:34 --> Output Class Initialized
INFO - 2016-02-17 15:08:34 --> Security Class Initialized
DEBUG - 2016-02-17 15:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:08:34 --> Input Class Initialized
INFO - 2016-02-17 15:08:34 --> Language Class Initialized
INFO - 2016-02-17 15:08:34 --> Loader Class Initialized
INFO - 2016-02-17 15:08:34 --> Helper loaded: url_helper
INFO - 2016-02-17 15:08:34 --> Helper loaded: file_helper
INFO - 2016-02-17 15:08:34 --> Helper loaded: date_helper
INFO - 2016-02-17 15:08:34 --> Helper loaded: form_helper
INFO - 2016-02-17 15:08:34 --> Database Driver Class Initialized
INFO - 2016-02-17 15:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:08:35 --> Controller Class Initialized
INFO - 2016-02-17 15:08:35 --> Model Class Initialized
INFO - 2016-02-17 15:08:35 --> Model Class Initialized
INFO - 2016-02-17 15:08:35 --> Form Validation Class Initialized
INFO - 2016-02-17 15:08:35 --> Helper loaded: text_helper
INFO - 2016-02-17 15:08:35 --> Final output sent to browser
DEBUG - 2016-02-17 15:08:35 --> Total execution time: 1.1334
INFO - 2016-02-17 15:11:03 --> Config Class Initialized
INFO - 2016-02-17 15:11:03 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:11:03 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:11:03 --> Utf8 Class Initialized
INFO - 2016-02-17 15:11:03 --> URI Class Initialized
INFO - 2016-02-17 15:11:03 --> Router Class Initialized
INFO - 2016-02-17 15:11:03 --> Output Class Initialized
INFO - 2016-02-17 15:11:03 --> Security Class Initialized
DEBUG - 2016-02-17 15:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:11:03 --> Input Class Initialized
INFO - 2016-02-17 15:11:03 --> Language Class Initialized
INFO - 2016-02-17 15:11:03 --> Loader Class Initialized
INFO - 2016-02-17 15:11:03 --> Helper loaded: url_helper
INFO - 2016-02-17 15:11:03 --> Helper loaded: file_helper
INFO - 2016-02-17 15:11:03 --> Helper loaded: date_helper
INFO - 2016-02-17 15:11:03 --> Helper loaded: form_helper
INFO - 2016-02-17 15:11:03 --> Database Driver Class Initialized
INFO - 2016-02-17 15:11:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:11:04 --> Controller Class Initialized
INFO - 2016-02-17 15:11:04 --> Model Class Initialized
INFO - 2016-02-17 15:11:04 --> Model Class Initialized
INFO - 2016-02-17 15:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:11:04 --> Pagination Class Initialized
INFO - 2016-02-17 15:11:04 --> Helper loaded: text_helper
INFO - 2016-02-17 15:11:04 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:11:04 --> Final output sent to browser
DEBUG - 2016-02-17 18:11:04 --> Total execution time: 1.1365
INFO - 2016-02-17 15:11:07 --> Config Class Initialized
INFO - 2016-02-17 15:11:07 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:11:07 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:11:07 --> Utf8 Class Initialized
INFO - 2016-02-17 15:11:07 --> URI Class Initialized
INFO - 2016-02-17 15:11:07 --> Router Class Initialized
INFO - 2016-02-17 15:11:07 --> Output Class Initialized
INFO - 2016-02-17 15:11:07 --> Security Class Initialized
DEBUG - 2016-02-17 15:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:11:07 --> Input Class Initialized
INFO - 2016-02-17 15:11:07 --> Language Class Initialized
INFO - 2016-02-17 15:11:07 --> Loader Class Initialized
INFO - 2016-02-17 15:11:07 --> Helper loaded: url_helper
INFO - 2016-02-17 15:11:07 --> Helper loaded: file_helper
INFO - 2016-02-17 15:11:07 --> Helper loaded: date_helper
INFO - 2016-02-17 15:11:07 --> Helper loaded: form_helper
INFO - 2016-02-17 15:11:07 --> Database Driver Class Initialized
INFO - 2016-02-17 15:11:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:11:08 --> Controller Class Initialized
INFO - 2016-02-17 15:11:08 --> Model Class Initialized
INFO - 2016-02-17 15:11:08 --> Model Class Initialized
INFO - 2016-02-17 15:11:08 --> Form Validation Class Initialized
INFO - 2016-02-17 15:11:08 --> Helper loaded: text_helper
INFO - 2016-02-17 15:11:08 --> Final output sent to browser
DEBUG - 2016-02-17 15:11:08 --> Total execution time: 1.1279
INFO - 2016-02-17 15:11:33 --> Config Class Initialized
INFO - 2016-02-17 15:11:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:11:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:11:33 --> Utf8 Class Initialized
INFO - 2016-02-17 15:11:33 --> URI Class Initialized
INFO - 2016-02-17 15:11:33 --> Router Class Initialized
INFO - 2016-02-17 15:11:33 --> Output Class Initialized
INFO - 2016-02-17 15:11:33 --> Security Class Initialized
DEBUG - 2016-02-17 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:11:33 --> Input Class Initialized
INFO - 2016-02-17 15:11:33 --> Language Class Initialized
INFO - 2016-02-17 15:11:33 --> Loader Class Initialized
INFO - 2016-02-17 15:11:33 --> Helper loaded: url_helper
INFO - 2016-02-17 15:11:33 --> Helper loaded: file_helper
INFO - 2016-02-17 15:11:33 --> Helper loaded: date_helper
INFO - 2016-02-17 15:11:33 --> Helper loaded: form_helper
INFO - 2016-02-17 15:11:33 --> Database Driver Class Initialized
INFO - 2016-02-17 15:11:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:11:34 --> Controller Class Initialized
INFO - 2016-02-17 15:11:34 --> Model Class Initialized
INFO - 2016-02-17 15:11:34 --> Model Class Initialized
INFO - 2016-02-17 15:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:11:34 --> Pagination Class Initialized
INFO - 2016-02-17 15:11:34 --> Helper loaded: text_helper
INFO - 2016-02-17 15:11:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:11:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:11:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:11:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:11:35 --> Final output sent to browser
DEBUG - 2016-02-17 18:11:35 --> Total execution time: 1.1406
INFO - 2016-02-17 15:11:38 --> Config Class Initialized
INFO - 2016-02-17 15:11:38 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:11:38 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:11:38 --> Utf8 Class Initialized
INFO - 2016-02-17 15:11:38 --> URI Class Initialized
INFO - 2016-02-17 15:11:38 --> Router Class Initialized
INFO - 2016-02-17 15:11:38 --> Output Class Initialized
INFO - 2016-02-17 15:11:38 --> Security Class Initialized
DEBUG - 2016-02-17 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:11:38 --> Input Class Initialized
INFO - 2016-02-17 15:11:38 --> Language Class Initialized
INFO - 2016-02-17 15:11:38 --> Loader Class Initialized
INFO - 2016-02-17 15:11:38 --> Helper loaded: url_helper
INFO - 2016-02-17 15:11:38 --> Helper loaded: file_helper
INFO - 2016-02-17 15:11:38 --> Helper loaded: date_helper
INFO - 2016-02-17 15:11:38 --> Helper loaded: form_helper
INFO - 2016-02-17 15:11:38 --> Database Driver Class Initialized
INFO - 2016-02-17 15:11:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:11:39 --> Controller Class Initialized
INFO - 2016-02-17 15:11:39 --> Model Class Initialized
INFO - 2016-02-17 15:11:39 --> Model Class Initialized
INFO - 2016-02-17 15:11:39 --> Form Validation Class Initialized
INFO - 2016-02-17 15:11:39 --> Helper loaded: text_helper
INFO - 2016-02-17 15:11:39 --> Final output sent to browser
DEBUG - 2016-02-17 15:11:39 --> Total execution time: 1.1168
INFO - 2016-02-17 15:37:00 --> Config Class Initialized
INFO - 2016-02-17 15:37:00 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:00 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:00 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:00 --> URI Class Initialized
INFO - 2016-02-17 15:37:00 --> Router Class Initialized
INFO - 2016-02-17 15:37:00 --> Output Class Initialized
INFO - 2016-02-17 15:37:00 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:00 --> Input Class Initialized
INFO - 2016-02-17 15:37:00 --> Language Class Initialized
INFO - 2016-02-17 15:37:00 --> Loader Class Initialized
INFO - 2016-02-17 15:37:00 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:00 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:00 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:00 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:00 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:01 --> Controller Class Initialized
INFO - 2016-02-17 15:37:01 --> Model Class Initialized
INFO - 2016-02-17 15:37:01 --> Model Class Initialized
INFO - 2016-02-17 15:37:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:37:01 --> Pagination Class Initialized
INFO - 2016-02-17 15:37:01 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:01 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:37:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:37:01 --> Final output sent to browser
DEBUG - 2016-02-17 18:37:01 --> Total execution time: 1.1487
INFO - 2016-02-17 15:37:12 --> Config Class Initialized
INFO - 2016-02-17 15:37:12 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:12 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:12 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:12 --> URI Class Initialized
INFO - 2016-02-17 15:37:12 --> Router Class Initialized
INFO - 2016-02-17 15:37:12 --> Output Class Initialized
INFO - 2016-02-17 15:37:12 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:12 --> Input Class Initialized
INFO - 2016-02-17 15:37:12 --> Language Class Initialized
INFO - 2016-02-17 15:37:12 --> Loader Class Initialized
INFO - 2016-02-17 15:37:12 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:12 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:12 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:12 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:12 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:14 --> Controller Class Initialized
INFO - 2016-02-17 15:37:14 --> Model Class Initialized
INFO - 2016-02-17 15:37:14 --> Model Class Initialized
INFO - 2016-02-17 15:37:14 --> Form Validation Class Initialized
INFO - 2016-02-17 15:37:14 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:14 --> Config Class Initialized
INFO - 2016-02-17 15:37:14 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:14 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:14 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:14 --> URI Class Initialized
INFO - 2016-02-17 15:37:14 --> Router Class Initialized
INFO - 2016-02-17 15:37:14 --> Output Class Initialized
INFO - 2016-02-17 15:37:14 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:14 --> Input Class Initialized
INFO - 2016-02-17 15:37:14 --> Language Class Initialized
INFO - 2016-02-17 15:37:14 --> Loader Class Initialized
INFO - 2016-02-17 15:37:14 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:14 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:14 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:14 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:14 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:15 --> Controller Class Initialized
INFO - 2016-02-17 15:37:15 --> Model Class Initialized
INFO - 2016-02-17 15:37:15 --> Model Class Initialized
INFO - 2016-02-17 15:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:37:15 --> Pagination Class Initialized
INFO - 2016-02-17 15:37:15 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:15 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:37:15 --> Final output sent to browser
DEBUG - 2016-02-17 18:37:15 --> Total execution time: 1.1087
INFO - 2016-02-17 15:37:18 --> Config Class Initialized
INFO - 2016-02-17 15:37:18 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:18 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:18 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:18 --> URI Class Initialized
INFO - 2016-02-17 15:37:18 --> Router Class Initialized
INFO - 2016-02-17 15:37:18 --> Output Class Initialized
INFO - 2016-02-17 15:37:18 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:18 --> Input Class Initialized
INFO - 2016-02-17 15:37:18 --> Language Class Initialized
INFO - 2016-02-17 15:37:18 --> Loader Class Initialized
INFO - 2016-02-17 15:37:18 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:18 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:18 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:18 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:18 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:19 --> Controller Class Initialized
INFO - 2016-02-17 15:37:19 --> Model Class Initialized
INFO - 2016-02-17 15:37:19 --> Model Class Initialized
INFO - 2016-02-17 15:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:37:19 --> Pagination Class Initialized
INFO - 2016-02-17 15:37:19 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:19 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 18:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 18:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:37:19 --> Final output sent to browser
DEBUG - 2016-02-17 18:37:19 --> Total execution time: 1.2082
INFO - 2016-02-17 15:37:21 --> Config Class Initialized
INFO - 2016-02-17 15:37:21 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:21 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:21 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:21 --> URI Class Initialized
INFO - 2016-02-17 15:37:21 --> Router Class Initialized
INFO - 2016-02-17 15:37:21 --> Output Class Initialized
INFO - 2016-02-17 15:37:21 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:21 --> Input Class Initialized
INFO - 2016-02-17 15:37:21 --> Language Class Initialized
INFO - 2016-02-17 15:37:21 --> Loader Class Initialized
INFO - 2016-02-17 15:37:21 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:21 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:21 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:21 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:21 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:22 --> Controller Class Initialized
INFO - 2016-02-17 15:37:22 --> Model Class Initialized
INFO - 2016-02-17 15:37:22 --> Model Class Initialized
INFO - 2016-02-17 15:37:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:37:22 --> Pagination Class Initialized
INFO - 2016-02-17 15:37:22 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:22 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:37:28 --> Config Class Initialized
INFO - 2016-02-17 15:37:28 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:37:28 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:37:28 --> Utf8 Class Initialized
INFO - 2016-02-17 15:37:28 --> URI Class Initialized
INFO - 2016-02-17 15:37:28 --> Router Class Initialized
INFO - 2016-02-17 15:37:28 --> Output Class Initialized
INFO - 2016-02-17 15:37:28 --> Security Class Initialized
DEBUG - 2016-02-17 15:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:37:28 --> Input Class Initialized
INFO - 2016-02-17 15:37:28 --> Language Class Initialized
INFO - 2016-02-17 15:37:28 --> Loader Class Initialized
INFO - 2016-02-17 15:37:28 --> Helper loaded: url_helper
INFO - 2016-02-17 15:37:28 --> Helper loaded: file_helper
INFO - 2016-02-17 15:37:28 --> Helper loaded: date_helper
INFO - 2016-02-17 15:37:28 --> Helper loaded: form_helper
INFO - 2016-02-17 15:37:28 --> Database Driver Class Initialized
INFO - 2016-02-17 15:37:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:37:29 --> Controller Class Initialized
INFO - 2016-02-17 15:37:29 --> Model Class Initialized
INFO - 2016-02-17 15:37:29 --> Model Class Initialized
INFO - 2016-02-17 15:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:37:29 --> Pagination Class Initialized
INFO - 2016-02-17 15:37:29 --> Helper loaded: text_helper
INFO - 2016-02-17 15:37:29 --> Helper loaded: cookie_helper
INFO - 2016-02-17 15:39:16 --> Config Class Initialized
INFO - 2016-02-17 15:39:16 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:39:16 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:39:16 --> Utf8 Class Initialized
INFO - 2016-02-17 15:39:16 --> URI Class Initialized
DEBUG - 2016-02-17 15:39:16 --> No URI present. Default controller set.
INFO - 2016-02-17 15:39:16 --> Router Class Initialized
INFO - 2016-02-17 15:39:16 --> Output Class Initialized
INFO - 2016-02-17 15:39:16 --> Security Class Initialized
DEBUG - 2016-02-17 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:39:16 --> Input Class Initialized
INFO - 2016-02-17 15:39:16 --> Language Class Initialized
INFO - 2016-02-17 15:39:16 --> Loader Class Initialized
INFO - 2016-02-17 15:39:16 --> Helper loaded: url_helper
INFO - 2016-02-17 15:39:16 --> Helper loaded: file_helper
INFO - 2016-02-17 15:39:16 --> Helper loaded: date_helper
INFO - 2016-02-17 15:39:16 --> Helper loaded: form_helper
INFO - 2016-02-17 15:39:16 --> Database Driver Class Initialized
INFO - 2016-02-17 15:39:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:39:17 --> Controller Class Initialized
INFO - 2016-02-17 15:39:17 --> Model Class Initialized
INFO - 2016-02-17 15:39:17 --> Model Class Initialized
INFO - 2016-02-17 15:39:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:39:17 --> Pagination Class Initialized
INFO - 2016-02-17 15:39:17 --> Helper loaded: text_helper
INFO - 2016-02-17 15:39:17 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:39:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:39:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:39:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:39:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:39:17 --> Final output sent to browser
DEBUG - 2016-02-17 18:39:17 --> Total execution time: 1.1309
INFO - 2016-02-17 15:39:24 --> Config Class Initialized
INFO - 2016-02-17 15:39:24 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:39:24 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:39:24 --> Utf8 Class Initialized
INFO - 2016-02-17 15:39:24 --> URI Class Initialized
INFO - 2016-02-17 15:39:25 --> Router Class Initialized
INFO - 2016-02-17 15:39:25 --> Output Class Initialized
INFO - 2016-02-17 15:39:25 --> Security Class Initialized
DEBUG - 2016-02-17 15:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:39:25 --> Input Class Initialized
INFO - 2016-02-17 15:39:25 --> Language Class Initialized
INFO - 2016-02-17 15:39:25 --> Loader Class Initialized
INFO - 2016-02-17 15:39:25 --> Helper loaded: url_helper
INFO - 2016-02-17 15:39:25 --> Helper loaded: file_helper
INFO - 2016-02-17 15:39:25 --> Helper loaded: date_helper
INFO - 2016-02-17 15:39:25 --> Helper loaded: form_helper
INFO - 2016-02-17 15:39:25 --> Database Driver Class Initialized
INFO - 2016-02-17 15:39:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:39:26 --> Controller Class Initialized
INFO - 2016-02-17 15:39:26 --> Model Class Initialized
INFO - 2016-02-17 15:39:26 --> Model Class Initialized
INFO - 2016-02-17 15:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:39:26 --> Pagination Class Initialized
INFO - 2016-02-17 15:39:26 --> Helper loaded: text_helper
INFO - 2016-02-17 15:39:26 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:39:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:39:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:39:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:39:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:39:26 --> Final output sent to browser
DEBUG - 2016-02-17 18:39:26 --> Total execution time: 1.1190
INFO - 2016-02-17 15:40:15 --> Config Class Initialized
INFO - 2016-02-17 15:40:15 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:40:15 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:40:15 --> Utf8 Class Initialized
INFO - 2016-02-17 15:40:15 --> URI Class Initialized
INFO - 2016-02-17 15:40:15 --> Router Class Initialized
INFO - 2016-02-17 15:40:15 --> Output Class Initialized
INFO - 2016-02-17 15:40:15 --> Security Class Initialized
DEBUG - 2016-02-17 15:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:40:15 --> Input Class Initialized
INFO - 2016-02-17 15:40:15 --> Language Class Initialized
INFO - 2016-02-17 15:40:15 --> Loader Class Initialized
INFO - 2016-02-17 15:40:15 --> Helper loaded: url_helper
INFO - 2016-02-17 15:40:15 --> Helper loaded: file_helper
INFO - 2016-02-17 15:40:15 --> Helper loaded: date_helper
INFO - 2016-02-17 15:40:15 --> Helper loaded: form_helper
INFO - 2016-02-17 15:40:15 --> Database Driver Class Initialized
INFO - 2016-02-17 15:40:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:40:16 --> Controller Class Initialized
INFO - 2016-02-17 15:40:16 --> Model Class Initialized
INFO - 2016-02-17 15:40:16 --> Model Class Initialized
INFO - 2016-02-17 15:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:40:16 --> Pagination Class Initialized
INFO - 2016-02-17 15:40:16 --> Helper loaded: text_helper
INFO - 2016-02-17 15:40:16 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:40:16 --> Final output sent to browser
DEBUG - 2016-02-17 18:40:16 --> Total execution time: 1.1532
INFO - 2016-02-17 15:42:43 --> Config Class Initialized
INFO - 2016-02-17 15:42:43 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:42:43 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:42:43 --> Utf8 Class Initialized
INFO - 2016-02-17 15:42:43 --> URI Class Initialized
INFO - 2016-02-17 15:42:43 --> Router Class Initialized
INFO - 2016-02-17 15:42:43 --> Output Class Initialized
INFO - 2016-02-17 15:42:43 --> Security Class Initialized
DEBUG - 2016-02-17 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:42:43 --> Input Class Initialized
INFO - 2016-02-17 15:42:43 --> Language Class Initialized
INFO - 2016-02-17 15:42:43 --> Loader Class Initialized
INFO - 2016-02-17 15:42:43 --> Helper loaded: url_helper
INFO - 2016-02-17 15:42:43 --> Helper loaded: file_helper
INFO - 2016-02-17 15:42:43 --> Helper loaded: date_helper
INFO - 2016-02-17 15:42:43 --> Helper loaded: form_helper
INFO - 2016-02-17 15:42:43 --> Database Driver Class Initialized
INFO - 2016-02-17 15:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:42:44 --> Controller Class Initialized
INFO - 2016-02-17 15:42:44 --> Model Class Initialized
INFO - 2016-02-17 15:42:44 --> Model Class Initialized
INFO - 2016-02-17 15:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:42:44 --> Pagination Class Initialized
INFO - 2016-02-17 15:42:44 --> Helper loaded: text_helper
INFO - 2016-02-17 15:42:44 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:42:44 --> Form Validation Class Initialized
INFO - 2016-02-17 18:42:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 18:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-17 18:42:44 --> Final output sent to browser
DEBUG - 2016-02-17 18:42:44 --> Total execution time: 1.1588
INFO - 2016-02-17 15:42:51 --> Config Class Initialized
INFO - 2016-02-17 15:42:51 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:42:51 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:42:51 --> Utf8 Class Initialized
INFO - 2016-02-17 15:42:51 --> URI Class Initialized
INFO - 2016-02-17 15:42:51 --> Router Class Initialized
INFO - 2016-02-17 15:42:51 --> Output Class Initialized
INFO - 2016-02-17 15:42:51 --> Security Class Initialized
DEBUG - 2016-02-17 15:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:42:51 --> Input Class Initialized
INFO - 2016-02-17 15:42:51 --> Language Class Initialized
INFO - 2016-02-17 15:42:51 --> Loader Class Initialized
INFO - 2016-02-17 15:42:51 --> Helper loaded: url_helper
INFO - 2016-02-17 15:42:51 --> Helper loaded: file_helper
INFO - 2016-02-17 15:42:51 --> Helper loaded: date_helper
INFO - 2016-02-17 15:42:51 --> Helper loaded: form_helper
INFO - 2016-02-17 15:42:51 --> Database Driver Class Initialized
INFO - 2016-02-17 15:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:42:52 --> Controller Class Initialized
INFO - 2016-02-17 15:42:52 --> Model Class Initialized
INFO - 2016-02-17 15:42:52 --> Model Class Initialized
INFO - 2016-02-17 15:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:42:52 --> Pagination Class Initialized
INFO - 2016-02-17 15:42:52 --> Helper loaded: text_helper
INFO - 2016-02-17 15:42:52 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:42:52 --> Form Validation Class Initialized
INFO - 2016-02-17 18:42:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 18:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 18:42:52 --> Final output sent to browser
DEBUG - 2016-02-17 18:42:52 --> Total execution time: 1.1672
INFO - 2016-02-17 15:43:02 --> Config Class Initialized
INFO - 2016-02-17 15:43:02 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:43:02 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:43:02 --> Utf8 Class Initialized
INFO - 2016-02-17 15:43:02 --> URI Class Initialized
INFO - 2016-02-17 15:43:02 --> Router Class Initialized
INFO - 2016-02-17 15:43:02 --> Output Class Initialized
INFO - 2016-02-17 15:43:02 --> Security Class Initialized
DEBUG - 2016-02-17 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:43:02 --> Input Class Initialized
INFO - 2016-02-17 15:43:02 --> Language Class Initialized
INFO - 2016-02-17 15:43:02 --> Loader Class Initialized
INFO - 2016-02-17 15:43:02 --> Helper loaded: url_helper
INFO - 2016-02-17 15:43:02 --> Helper loaded: file_helper
INFO - 2016-02-17 15:43:02 --> Helper loaded: date_helper
INFO - 2016-02-17 15:43:02 --> Helper loaded: form_helper
INFO - 2016-02-17 15:43:02 --> Database Driver Class Initialized
INFO - 2016-02-17 15:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:43:03 --> Controller Class Initialized
INFO - 2016-02-17 15:43:03 --> Model Class Initialized
INFO - 2016-02-17 15:43:03 --> Model Class Initialized
INFO - 2016-02-17 15:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:43:03 --> Pagination Class Initialized
INFO - 2016-02-17 15:43:03 --> Helper loaded: text_helper
INFO - 2016-02-17 15:43:03 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:43:03 --> Form Validation Class Initialized
INFO - 2016-02-17 18:43:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 18:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 18:43:03 --> Final output sent to browser
DEBUG - 2016-02-17 18:43:03 --> Total execution time: 1.1712
INFO - 2016-02-17 15:43:19 --> Config Class Initialized
INFO - 2016-02-17 15:43:19 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:43:19 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:43:19 --> Utf8 Class Initialized
INFO - 2016-02-17 15:43:19 --> URI Class Initialized
INFO - 2016-02-17 15:43:19 --> Router Class Initialized
INFO - 2016-02-17 15:43:19 --> Output Class Initialized
INFO - 2016-02-17 15:43:19 --> Security Class Initialized
DEBUG - 2016-02-17 15:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:43:19 --> Input Class Initialized
INFO - 2016-02-17 15:43:19 --> Language Class Initialized
INFO - 2016-02-17 15:43:19 --> Loader Class Initialized
INFO - 2016-02-17 15:43:19 --> Helper loaded: url_helper
INFO - 2016-02-17 15:43:19 --> Helper loaded: file_helper
INFO - 2016-02-17 15:43:19 --> Helper loaded: date_helper
INFO - 2016-02-17 15:43:19 --> Helper loaded: form_helper
INFO - 2016-02-17 15:43:19 --> Database Driver Class Initialized
INFO - 2016-02-17 15:43:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:43:20 --> Controller Class Initialized
INFO - 2016-02-17 15:43:20 --> Model Class Initialized
INFO - 2016-02-17 15:43:20 --> Model Class Initialized
INFO - 2016-02-17 15:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:43:20 --> Pagination Class Initialized
INFO - 2016-02-17 15:43:20 --> Helper loaded: text_helper
INFO - 2016-02-17 15:43:20 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:43:20 --> Form Validation Class Initialized
INFO - 2016-02-17 18:43:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-17 18:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-17 18:43:21 --> Final output sent to browser
DEBUG - 2016-02-17 18:43:21 --> Total execution time: 1.1912
INFO - 2016-02-17 15:43:57 --> Config Class Initialized
INFO - 2016-02-17 15:43:57 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:43:57 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:43:57 --> Utf8 Class Initialized
INFO - 2016-02-17 15:43:57 --> URI Class Initialized
DEBUG - 2016-02-17 15:43:57 --> No URI present. Default controller set.
INFO - 2016-02-17 15:43:57 --> Router Class Initialized
INFO - 2016-02-17 15:43:57 --> Output Class Initialized
INFO - 2016-02-17 15:43:57 --> Security Class Initialized
DEBUG - 2016-02-17 15:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:43:57 --> Input Class Initialized
INFO - 2016-02-17 15:43:57 --> Language Class Initialized
INFO - 2016-02-17 15:43:57 --> Loader Class Initialized
INFO - 2016-02-17 15:43:57 --> Helper loaded: url_helper
INFO - 2016-02-17 15:43:57 --> Helper loaded: file_helper
INFO - 2016-02-17 15:43:57 --> Helper loaded: date_helper
INFO - 2016-02-17 15:43:57 --> Helper loaded: form_helper
INFO - 2016-02-17 15:43:57 --> Database Driver Class Initialized
INFO - 2016-02-17 15:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:43:58 --> Controller Class Initialized
INFO - 2016-02-17 15:43:58 --> Model Class Initialized
INFO - 2016-02-17 15:43:58 --> Model Class Initialized
INFO - 2016-02-17 15:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:43:58 --> Pagination Class Initialized
INFO - 2016-02-17 15:43:58 --> Helper loaded: text_helper
INFO - 2016-02-17 15:43:58 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:43:58 --> Final output sent to browser
DEBUG - 2016-02-17 18:43:58 --> Total execution time: 1.1248
INFO - 2016-02-17 15:44:59 --> Config Class Initialized
INFO - 2016-02-17 15:44:59 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:44:59 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:44:59 --> Utf8 Class Initialized
INFO - 2016-02-17 15:44:59 --> URI Class Initialized
INFO - 2016-02-17 15:44:59 --> Router Class Initialized
INFO - 2016-02-17 15:44:59 --> Output Class Initialized
INFO - 2016-02-17 15:44:59 --> Security Class Initialized
DEBUG - 2016-02-17 15:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:44:59 --> Input Class Initialized
INFO - 2016-02-17 15:44:59 --> Language Class Initialized
INFO - 2016-02-17 15:44:59 --> Loader Class Initialized
INFO - 2016-02-17 15:44:59 --> Helper loaded: url_helper
INFO - 2016-02-17 15:44:59 --> Helper loaded: file_helper
INFO - 2016-02-17 15:44:59 --> Helper loaded: date_helper
INFO - 2016-02-17 15:44:59 --> Helper loaded: form_helper
INFO - 2016-02-17 15:44:59 --> Database Driver Class Initialized
INFO - 2016-02-17 15:45:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:45:00 --> Controller Class Initialized
INFO - 2016-02-17 15:45:00 --> Model Class Initialized
INFO - 2016-02-17 15:45:00 --> Model Class Initialized
INFO - 2016-02-17 15:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:45:00 --> Pagination Class Initialized
INFO - 2016-02-17 15:45:00 --> Helper loaded: text_helper
INFO - 2016-02-17 15:45:00 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:45:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:45:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:45:00 --> Form Validation Class Initialized
INFO - 2016-02-17 18:45:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-17 18:45:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:45:00 --> Final output sent to browser
DEBUG - 2016-02-17 18:45:00 --> Total execution time: 1.1722
INFO - 2016-02-17 15:45:33 --> Config Class Initialized
INFO - 2016-02-17 15:45:33 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:45:33 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:45:33 --> Utf8 Class Initialized
INFO - 2016-02-17 15:45:33 --> URI Class Initialized
DEBUG - 2016-02-17 15:45:33 --> No URI present. Default controller set.
INFO - 2016-02-17 15:45:33 --> Router Class Initialized
INFO - 2016-02-17 15:45:33 --> Output Class Initialized
INFO - 2016-02-17 15:45:33 --> Security Class Initialized
DEBUG - 2016-02-17 15:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:45:33 --> Input Class Initialized
INFO - 2016-02-17 15:45:33 --> Language Class Initialized
INFO - 2016-02-17 15:45:33 --> Loader Class Initialized
INFO - 2016-02-17 15:45:33 --> Helper loaded: url_helper
INFO - 2016-02-17 15:45:33 --> Helper loaded: file_helper
INFO - 2016-02-17 15:45:33 --> Helper loaded: date_helper
INFO - 2016-02-17 15:45:33 --> Helper loaded: form_helper
INFO - 2016-02-17 15:45:33 --> Database Driver Class Initialized
INFO - 2016-02-17 15:45:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:45:34 --> Controller Class Initialized
INFO - 2016-02-17 15:45:34 --> Model Class Initialized
INFO - 2016-02-17 15:45:34 --> Model Class Initialized
INFO - 2016-02-17 15:45:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:45:34 --> Pagination Class Initialized
INFO - 2016-02-17 15:45:34 --> Helper loaded: text_helper
INFO - 2016-02-17 15:45:34 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:45:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:45:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:45:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-17 18:45:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:45:34 --> Final output sent to browser
DEBUG - 2016-02-17 18:45:34 --> Total execution time: 1.1318
INFO - 2016-02-17 15:47:46 --> Config Class Initialized
INFO - 2016-02-17 15:47:46 --> Hooks Class Initialized
DEBUG - 2016-02-17 15:47:46 --> UTF-8 Support Enabled
INFO - 2016-02-17 15:47:46 --> Utf8 Class Initialized
INFO - 2016-02-17 15:47:46 --> URI Class Initialized
INFO - 2016-02-17 15:47:46 --> Router Class Initialized
INFO - 2016-02-17 15:47:46 --> Output Class Initialized
INFO - 2016-02-17 15:47:46 --> Security Class Initialized
DEBUG - 2016-02-17 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-17 15:47:46 --> Input Class Initialized
INFO - 2016-02-17 15:47:46 --> Language Class Initialized
INFO - 2016-02-17 15:47:46 --> Loader Class Initialized
INFO - 2016-02-17 15:47:46 --> Helper loaded: url_helper
INFO - 2016-02-17 15:47:46 --> Helper loaded: file_helper
INFO - 2016-02-17 15:47:46 --> Helper loaded: date_helper
INFO - 2016-02-17 15:47:46 --> Helper loaded: form_helper
INFO - 2016-02-17 15:47:46 --> Database Driver Class Initialized
INFO - 2016-02-17 15:47:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-17 15:47:47 --> Controller Class Initialized
INFO - 2016-02-17 15:47:47 --> Model Class Initialized
INFO - 2016-02-17 15:47:47 --> Model Class Initialized
INFO - 2016-02-17 15:47:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-17 15:47:47 --> Pagination Class Initialized
INFO - 2016-02-17 15:47:47 --> Helper loaded: text_helper
INFO - 2016-02-17 15:47:47 --> Helper loaded: cookie_helper
INFO - 2016-02-17 18:47:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-17 18:47:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-17 18:47:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-17 18:47:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-17 18:47:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-17 18:47:47 --> Final output sent to browser
DEBUG - 2016-02-17 18:47:47 --> Total execution time: 1.2151
