<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-08 06:12:59 --> Config Class Initialized
INFO - 2016-02-08 06:12:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:12:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:12:59 --> Utf8 Class Initialized
INFO - 2016-02-08 06:12:59 --> URI Class Initialized
DEBUG - 2016-02-08 06:12:59 --> No URI present. Default controller set.
INFO - 2016-02-08 06:12:59 --> Router Class Initialized
INFO - 2016-02-08 06:12:59 --> Output Class Initialized
INFO - 2016-02-08 06:12:59 --> Security Class Initialized
DEBUG - 2016-02-08 06:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:12:59 --> Input Class Initialized
INFO - 2016-02-08 06:12:59 --> Language Class Initialized
INFO - 2016-02-08 06:12:59 --> Loader Class Initialized
INFO - 2016-02-08 06:12:59 --> Helper loaded: url_helper
INFO - 2016-02-08 06:12:59 --> Helper loaded: file_helper
INFO - 2016-02-08 06:12:59 --> Helper loaded: date_helper
INFO - 2016-02-08 06:12:59 --> Helper loaded: form_helper
INFO - 2016-02-08 06:12:59 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:00 --> Controller Class Initialized
INFO - 2016-02-08 06:13:00 --> Model Class Initialized
INFO - 2016-02-08 06:13:00 --> Model Class Initialized
INFO - 2016-02-08 06:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:13:00 --> Pagination Class Initialized
INFO - 2016-02-08 06:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:13:00 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:00 --> Total execution time: 1.1365
INFO - 2016-02-08 06:13:01 --> Config Class Initialized
INFO - 2016-02-08 06:13:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:01 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:01 --> URI Class Initialized
INFO - 2016-02-08 06:13:01 --> Router Class Initialized
INFO - 2016-02-08 06:13:01 --> Output Class Initialized
INFO - 2016-02-08 06:13:01 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:01 --> Input Class Initialized
INFO - 2016-02-08 06:13:01 --> Language Class Initialized
INFO - 2016-02-08 06:13:01 --> Loader Class Initialized
INFO - 2016-02-08 06:13:01 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:01 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:01 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:01 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:01 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:02 --> Controller Class Initialized
INFO - 2016-02-08 06:13:02 --> Model Class Initialized
INFO - 2016-02-08 06:13:02 --> Model Class Initialized
INFO - 2016-02-08 06:13:02 --> Form Validation Class Initialized
INFO - 2016-02-08 06:13:02 --> Helper loaded: text_helper
INFO - 2016-02-08 06:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-08 06:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:13:02 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:02 --> Total execution time: 1.1109
INFO - 2016-02-08 06:13:06 --> Config Class Initialized
INFO - 2016-02-08 06:13:06 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:06 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:06 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:06 --> URI Class Initialized
INFO - 2016-02-08 06:13:06 --> Router Class Initialized
INFO - 2016-02-08 06:13:06 --> Output Class Initialized
INFO - 2016-02-08 06:13:06 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:06 --> Input Class Initialized
INFO - 2016-02-08 06:13:06 --> Language Class Initialized
INFO - 2016-02-08 06:13:06 --> Loader Class Initialized
INFO - 2016-02-08 06:13:06 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:06 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:06 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:06 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:06 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:07 --> Controller Class Initialized
INFO - 2016-02-08 06:13:07 --> Model Class Initialized
INFO - 2016-02-08 06:13:07 --> Model Class Initialized
INFO - 2016-02-08 06:13:07 --> Form Validation Class Initialized
INFO - 2016-02-08 06:13:07 --> Helper loaded: text_helper
INFO - 2016-02-08 06:13:07 --> Config Class Initialized
INFO - 2016-02-08 06:13:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:07 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:07 --> URI Class Initialized
INFO - 2016-02-08 06:13:07 --> Router Class Initialized
INFO - 2016-02-08 06:13:07 --> Output Class Initialized
INFO - 2016-02-08 06:13:07 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:07 --> Input Class Initialized
INFO - 2016-02-08 06:13:07 --> Language Class Initialized
INFO - 2016-02-08 06:13:07 --> Loader Class Initialized
INFO - 2016-02-08 06:13:07 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:07 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:07 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:07 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:07 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:08 --> Controller Class Initialized
INFO - 2016-02-08 06:13:08 --> Model Class Initialized
INFO - 2016-02-08 06:13:08 --> Model Class Initialized
INFO - 2016-02-08 06:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:13:08 --> Pagination Class Initialized
INFO - 2016-02-08 06:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:13:08 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:08 --> Total execution time: 1.1171
INFO - 2016-02-08 06:13:10 --> Config Class Initialized
INFO - 2016-02-08 06:13:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:10 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:10 --> URI Class Initialized
INFO - 2016-02-08 06:13:10 --> Router Class Initialized
INFO - 2016-02-08 06:13:10 --> Output Class Initialized
INFO - 2016-02-08 06:13:10 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:10 --> Input Class Initialized
INFO - 2016-02-08 06:13:10 --> Language Class Initialized
INFO - 2016-02-08 06:13:10 --> Loader Class Initialized
INFO - 2016-02-08 06:13:10 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:10 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:10 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:10 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:10 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:11 --> Controller Class Initialized
INFO - 2016-02-08 06:13:11 --> Model Class Initialized
INFO - 2016-02-08 06:13:11 --> Model Class Initialized
INFO - 2016-02-08 06:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:13:11 --> Pagination Class Initialized
INFO - 2016-02-08 06:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:13:11 --> Helper loaded: text_helper
INFO - 2016-02-08 06:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 06:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 06:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:13:11 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:11 --> Total execution time: 1.1775
INFO - 2016-02-08 06:13:14 --> Config Class Initialized
INFO - 2016-02-08 06:13:14 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:14 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:14 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:14 --> URI Class Initialized
INFO - 2016-02-08 06:13:14 --> Router Class Initialized
INFO - 2016-02-08 06:13:14 --> Output Class Initialized
INFO - 2016-02-08 06:13:14 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:14 --> Input Class Initialized
INFO - 2016-02-08 06:13:14 --> Language Class Initialized
INFO - 2016-02-08 06:13:14 --> Loader Class Initialized
INFO - 2016-02-08 06:13:14 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:14 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:14 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:14 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:14 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:15 --> Controller Class Initialized
INFO - 2016-02-08 06:13:15 --> Model Class Initialized
INFO - 2016-02-08 06:13:15 --> Model Class Initialized
INFO - 2016-02-08 06:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:13:15 --> Pagination Class Initialized
INFO - 2016-02-08 06:13:15 --> Form Validation Class Initialized
INFO - 2016-02-08 06:13:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 06:13:16 --> Model Class Initialized
INFO - 2016-02-08 06:13:16 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:16 --> Total execution time: 1.1801
INFO - 2016-02-08 06:13:38 --> Config Class Initialized
INFO - 2016-02-08 06:13:38 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:13:38 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:13:38 --> Utf8 Class Initialized
INFO - 2016-02-08 06:13:38 --> URI Class Initialized
DEBUG - 2016-02-08 06:13:38 --> No URI present. Default controller set.
INFO - 2016-02-08 06:13:38 --> Router Class Initialized
INFO - 2016-02-08 06:13:38 --> Output Class Initialized
INFO - 2016-02-08 06:13:38 --> Security Class Initialized
DEBUG - 2016-02-08 06:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:13:38 --> Input Class Initialized
INFO - 2016-02-08 06:13:38 --> Language Class Initialized
INFO - 2016-02-08 06:13:38 --> Loader Class Initialized
INFO - 2016-02-08 06:13:38 --> Helper loaded: url_helper
INFO - 2016-02-08 06:13:38 --> Helper loaded: file_helper
INFO - 2016-02-08 06:13:38 --> Helper loaded: date_helper
INFO - 2016-02-08 06:13:38 --> Helper loaded: form_helper
INFO - 2016-02-08 06:13:38 --> Database Driver Class Initialized
INFO - 2016-02-08 06:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:13:39 --> Controller Class Initialized
INFO - 2016-02-08 06:13:39 --> Model Class Initialized
INFO - 2016-02-08 06:13:39 --> Model Class Initialized
INFO - 2016-02-08 06:13:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:13:39 --> Pagination Class Initialized
INFO - 2016-02-08 06:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:13:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:13:39 --> Final output sent to browser
DEBUG - 2016-02-08 06:13:39 --> Total execution time: 1.1242
INFO - 2016-02-08 06:24:03 --> Config Class Initialized
INFO - 2016-02-08 06:24:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:24:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:24:03 --> Utf8 Class Initialized
INFO - 2016-02-08 06:24:03 --> URI Class Initialized
INFO - 2016-02-08 06:24:03 --> Router Class Initialized
INFO - 2016-02-08 06:24:03 --> Output Class Initialized
INFO - 2016-02-08 06:24:03 --> Security Class Initialized
DEBUG - 2016-02-08 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:24:03 --> Input Class Initialized
INFO - 2016-02-08 06:24:03 --> Language Class Initialized
INFO - 2016-02-08 06:24:03 --> Loader Class Initialized
INFO - 2016-02-08 06:24:03 --> Helper loaded: url_helper
INFO - 2016-02-08 06:24:03 --> Helper loaded: file_helper
INFO - 2016-02-08 06:24:03 --> Helper loaded: date_helper
INFO - 2016-02-08 06:24:03 --> Helper loaded: form_helper
INFO - 2016-02-08 06:24:03 --> Database Driver Class Initialized
INFO - 2016-02-08 06:24:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:24:04 --> Controller Class Initialized
INFO - 2016-02-08 06:24:04 --> Model Class Initialized
INFO - 2016-02-08 06:24:04 --> Model Class Initialized
INFO - 2016-02-08 06:24:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:24:04 --> Pagination Class Initialized
INFO - 2016-02-08 06:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:24:04 --> Helper loaded: text_helper
INFO - 2016-02-08 06:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 06:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 06:24:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:24:04 --> Final output sent to browser
DEBUG - 2016-02-08 06:24:04 --> Total execution time: 1.2026
INFO - 2016-02-08 06:24:06 --> Config Class Initialized
INFO - 2016-02-08 06:24:06 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:24:06 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:24:06 --> Utf8 Class Initialized
INFO - 2016-02-08 06:24:06 --> URI Class Initialized
DEBUG - 2016-02-08 06:24:06 --> No URI present. Default controller set.
INFO - 2016-02-08 06:24:06 --> Router Class Initialized
INFO - 2016-02-08 06:24:06 --> Output Class Initialized
INFO - 2016-02-08 06:24:06 --> Security Class Initialized
DEBUG - 2016-02-08 06:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:24:06 --> Input Class Initialized
INFO - 2016-02-08 06:24:06 --> Language Class Initialized
INFO - 2016-02-08 06:24:06 --> Loader Class Initialized
INFO - 2016-02-08 06:24:06 --> Helper loaded: url_helper
INFO - 2016-02-08 06:24:06 --> Helper loaded: file_helper
INFO - 2016-02-08 06:24:06 --> Helper loaded: date_helper
INFO - 2016-02-08 06:24:06 --> Helper loaded: form_helper
INFO - 2016-02-08 06:24:06 --> Database Driver Class Initialized
INFO - 2016-02-08 06:24:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:24:07 --> Controller Class Initialized
INFO - 2016-02-08 06:24:07 --> Model Class Initialized
INFO - 2016-02-08 06:24:07 --> Model Class Initialized
INFO - 2016-02-08 06:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:24:07 --> Pagination Class Initialized
INFO - 2016-02-08 06:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:24:07 --> Final output sent to browser
DEBUG - 2016-02-08 06:24:07 --> Total execution time: 1.1798
INFO - 2016-02-08 06:24:09 --> Config Class Initialized
INFO - 2016-02-08 06:24:09 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:24:09 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:24:09 --> Utf8 Class Initialized
INFO - 2016-02-08 06:24:09 --> URI Class Initialized
DEBUG - 2016-02-08 06:24:09 --> No URI present. Default controller set.
INFO - 2016-02-08 06:24:09 --> Router Class Initialized
INFO - 2016-02-08 06:24:09 --> Output Class Initialized
INFO - 2016-02-08 06:24:09 --> Security Class Initialized
DEBUG - 2016-02-08 06:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:24:09 --> Input Class Initialized
INFO - 2016-02-08 06:24:09 --> Language Class Initialized
INFO - 2016-02-08 06:24:09 --> Loader Class Initialized
INFO - 2016-02-08 06:24:09 --> Helper loaded: url_helper
INFO - 2016-02-08 06:24:09 --> Helper loaded: file_helper
INFO - 2016-02-08 06:24:09 --> Helper loaded: date_helper
INFO - 2016-02-08 06:24:09 --> Helper loaded: form_helper
INFO - 2016-02-08 06:24:09 --> Database Driver Class Initialized
INFO - 2016-02-08 06:24:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:24:10 --> Controller Class Initialized
INFO - 2016-02-08 06:24:10 --> Model Class Initialized
INFO - 2016-02-08 06:24:10 --> Model Class Initialized
INFO - 2016-02-08 06:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:24:10 --> Pagination Class Initialized
INFO - 2016-02-08 06:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:24:10 --> Final output sent to browser
DEBUG - 2016-02-08 06:24:10 --> Total execution time: 1.1674
INFO - 2016-02-08 06:24:11 --> Config Class Initialized
INFO - 2016-02-08 06:24:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:24:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:24:11 --> Utf8 Class Initialized
INFO - 2016-02-08 06:24:11 --> URI Class Initialized
DEBUG - 2016-02-08 06:24:11 --> No URI present. Default controller set.
INFO - 2016-02-08 06:24:11 --> Router Class Initialized
INFO - 2016-02-08 06:24:11 --> Output Class Initialized
INFO - 2016-02-08 06:24:11 --> Security Class Initialized
DEBUG - 2016-02-08 06:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:24:11 --> Input Class Initialized
INFO - 2016-02-08 06:24:11 --> Language Class Initialized
INFO - 2016-02-08 06:24:11 --> Loader Class Initialized
INFO - 2016-02-08 06:24:11 --> Helper loaded: url_helper
INFO - 2016-02-08 06:24:11 --> Helper loaded: file_helper
INFO - 2016-02-08 06:24:11 --> Helper loaded: date_helper
INFO - 2016-02-08 06:24:11 --> Helper loaded: form_helper
INFO - 2016-02-08 06:24:11 --> Database Driver Class Initialized
INFO - 2016-02-08 06:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:24:12 --> Controller Class Initialized
INFO - 2016-02-08 06:24:12 --> Model Class Initialized
INFO - 2016-02-08 06:24:12 --> Model Class Initialized
INFO - 2016-02-08 06:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:24:12 --> Pagination Class Initialized
INFO - 2016-02-08 06:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:24:12 --> Final output sent to browser
DEBUG - 2016-02-08 06:24:12 --> Total execution time: 1.1417
INFO - 2016-02-08 06:25:02 --> Config Class Initialized
INFO - 2016-02-08 06:25:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:02 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:02 --> URI Class Initialized
DEBUG - 2016-02-08 06:25:02 --> No URI present. Default controller set.
INFO - 2016-02-08 06:25:02 --> Router Class Initialized
INFO - 2016-02-08 06:25:02 --> Output Class Initialized
INFO - 2016-02-08 06:25:02 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:02 --> Input Class Initialized
INFO - 2016-02-08 06:25:02 --> Language Class Initialized
INFO - 2016-02-08 06:25:02 --> Loader Class Initialized
INFO - 2016-02-08 06:25:02 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:02 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:02 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:02 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:02 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:03 --> Controller Class Initialized
INFO - 2016-02-08 06:25:03 --> Model Class Initialized
INFO - 2016-02-08 06:25:03 --> Model Class Initialized
INFO - 2016-02-08 06:25:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:03 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:25:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:03 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:03 --> Total execution time: 1.1525
INFO - 2016-02-08 06:25:05 --> Config Class Initialized
INFO - 2016-02-08 06:25:05 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:05 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:05 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:05 --> URI Class Initialized
INFO - 2016-02-08 06:25:05 --> Router Class Initialized
INFO - 2016-02-08 06:25:05 --> Output Class Initialized
INFO - 2016-02-08 06:25:05 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:05 --> Input Class Initialized
INFO - 2016-02-08 06:25:05 --> Language Class Initialized
INFO - 2016-02-08 06:25:05 --> Loader Class Initialized
INFO - 2016-02-08 06:25:05 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:05 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:05 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:05 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:05 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:06 --> Controller Class Initialized
INFO - 2016-02-08 06:25:06 --> Model Class Initialized
INFO - 2016-02-08 06:25:06 --> Model Class Initialized
INFO - 2016-02-08 06:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:06 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:06 --> Helper loaded: text_helper
INFO - 2016-02-08 06:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 06:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 06:25:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:06 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:06 --> Total execution time: 1.1788
INFO - 2016-02-08 06:25:09 --> Config Class Initialized
INFO - 2016-02-08 06:25:09 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:09 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:09 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:09 --> URI Class Initialized
DEBUG - 2016-02-08 06:25:09 --> No URI present. Default controller set.
INFO - 2016-02-08 06:25:09 --> Router Class Initialized
INFO - 2016-02-08 06:25:09 --> Output Class Initialized
INFO - 2016-02-08 06:25:09 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:09 --> Input Class Initialized
INFO - 2016-02-08 06:25:09 --> Language Class Initialized
INFO - 2016-02-08 06:25:09 --> Loader Class Initialized
INFO - 2016-02-08 06:25:09 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:09 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:09 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:09 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:09 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:10 --> Controller Class Initialized
INFO - 2016-02-08 06:25:10 --> Model Class Initialized
INFO - 2016-02-08 06:25:10 --> Model Class Initialized
INFO - 2016-02-08 06:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:10 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:10 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:10 --> Total execution time: 1.1642
INFO - 2016-02-08 06:25:25 --> Config Class Initialized
INFO - 2016-02-08 06:25:25 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:25 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:25 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:25 --> URI Class Initialized
DEBUG - 2016-02-08 06:25:25 --> No URI present. Default controller set.
INFO - 2016-02-08 06:25:25 --> Router Class Initialized
INFO - 2016-02-08 06:25:25 --> Output Class Initialized
INFO - 2016-02-08 06:25:25 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:25 --> Input Class Initialized
INFO - 2016-02-08 06:25:25 --> Language Class Initialized
INFO - 2016-02-08 06:25:25 --> Loader Class Initialized
INFO - 2016-02-08 06:25:25 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:25 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:25 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:25 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:25 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:26 --> Controller Class Initialized
INFO - 2016-02-08 06:25:26 --> Model Class Initialized
INFO - 2016-02-08 06:25:26 --> Model Class Initialized
INFO - 2016-02-08 06:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:26 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:26 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:26 --> Total execution time: 1.1532
INFO - 2016-02-08 06:25:28 --> Config Class Initialized
INFO - 2016-02-08 06:25:28 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:28 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:28 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:28 --> URI Class Initialized
INFO - 2016-02-08 06:25:28 --> Router Class Initialized
INFO - 2016-02-08 06:25:28 --> Output Class Initialized
INFO - 2016-02-08 06:25:28 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:28 --> Input Class Initialized
INFO - 2016-02-08 06:25:28 --> Language Class Initialized
INFO - 2016-02-08 06:25:28 --> Loader Class Initialized
INFO - 2016-02-08 06:25:28 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:28 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:28 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:28 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:28 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:29 --> Controller Class Initialized
INFO - 2016-02-08 06:25:29 --> Model Class Initialized
INFO - 2016-02-08 06:25:29 --> Model Class Initialized
INFO - 2016-02-08 06:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:29 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:29 --> Helper loaded: text_helper
INFO - 2016-02-08 06:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 06:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 06:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:29 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:29 --> Total execution time: 1.1977
INFO - 2016-02-08 06:25:35 --> Config Class Initialized
INFO - 2016-02-08 06:25:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:25:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:25:35 --> Utf8 Class Initialized
INFO - 2016-02-08 06:25:35 --> URI Class Initialized
DEBUG - 2016-02-08 06:25:35 --> No URI present. Default controller set.
INFO - 2016-02-08 06:25:35 --> Router Class Initialized
INFO - 2016-02-08 06:25:35 --> Output Class Initialized
INFO - 2016-02-08 06:25:35 --> Security Class Initialized
DEBUG - 2016-02-08 06:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:25:36 --> Input Class Initialized
INFO - 2016-02-08 06:25:36 --> Language Class Initialized
INFO - 2016-02-08 06:25:36 --> Loader Class Initialized
INFO - 2016-02-08 06:25:36 --> Helper loaded: url_helper
INFO - 2016-02-08 06:25:36 --> Helper loaded: file_helper
INFO - 2016-02-08 06:25:36 --> Helper loaded: date_helper
INFO - 2016-02-08 06:25:36 --> Helper loaded: form_helper
INFO - 2016-02-08 06:25:36 --> Database Driver Class Initialized
INFO - 2016-02-08 06:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:25:37 --> Controller Class Initialized
INFO - 2016-02-08 06:25:37 --> Model Class Initialized
INFO - 2016-02-08 06:25:37 --> Model Class Initialized
INFO - 2016-02-08 06:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:25:37 --> Pagination Class Initialized
INFO - 2016-02-08 06:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:25:37 --> Final output sent to browser
DEBUG - 2016-02-08 06:25:37 --> Total execution time: 1.1911
INFO - 2016-02-08 06:28:44 --> Config Class Initialized
INFO - 2016-02-08 06:28:44 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:28:44 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:28:44 --> Utf8 Class Initialized
INFO - 2016-02-08 06:28:44 --> URI Class Initialized
INFO - 2016-02-08 06:28:44 --> Router Class Initialized
INFO - 2016-02-08 06:28:44 --> Output Class Initialized
INFO - 2016-02-08 06:28:44 --> Security Class Initialized
DEBUG - 2016-02-08 06:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:28:44 --> Input Class Initialized
INFO - 2016-02-08 06:28:44 --> Language Class Initialized
ERROR - 2016-02-08 06:28:44 --> 404 Page Not Found: Delete_cache/index
INFO - 2016-02-08 06:28:48 --> Config Class Initialized
INFO - 2016-02-08 06:28:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:28:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:28:48 --> Utf8 Class Initialized
INFO - 2016-02-08 06:28:48 --> URI Class Initialized
INFO - 2016-02-08 06:28:48 --> Router Class Initialized
INFO - 2016-02-08 06:28:48 --> Output Class Initialized
INFO - 2016-02-08 06:28:48 --> Security Class Initialized
DEBUG - 2016-02-08 06:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:28:48 --> Input Class Initialized
INFO - 2016-02-08 06:28:48 --> Language Class Initialized
ERROR - 2016-02-08 06:28:48 --> 404 Page Not Found: Delete_cache/index
INFO - 2016-02-08 06:28:54 --> Config Class Initialized
INFO - 2016-02-08 06:28:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:28:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:28:54 --> Utf8 Class Initialized
INFO - 2016-02-08 06:28:54 --> URI Class Initialized
DEBUG - 2016-02-08 06:28:54 --> No URI present. Default controller set.
INFO - 2016-02-08 06:28:54 --> Router Class Initialized
INFO - 2016-02-08 06:28:54 --> Output Class Initialized
INFO - 2016-02-08 06:28:54 --> Security Class Initialized
DEBUG - 2016-02-08 06:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:28:54 --> Input Class Initialized
INFO - 2016-02-08 06:28:54 --> Language Class Initialized
INFO - 2016-02-08 06:28:54 --> Loader Class Initialized
INFO - 2016-02-08 06:28:54 --> Helper loaded: url_helper
INFO - 2016-02-08 06:28:54 --> Helper loaded: file_helper
INFO - 2016-02-08 06:28:54 --> Helper loaded: date_helper
INFO - 2016-02-08 06:28:54 --> Helper loaded: form_helper
INFO - 2016-02-08 06:28:54 --> Database Driver Class Initialized
INFO - 2016-02-08 06:28:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:28:55 --> Controller Class Initialized
INFO - 2016-02-08 06:28:55 --> Model Class Initialized
INFO - 2016-02-08 06:28:55 --> Model Class Initialized
INFO - 2016-02-08 06:28:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:28:55 --> Pagination Class Initialized
INFO - 2016-02-08 06:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:28:55 --> Final output sent to browser
DEBUG - 2016-02-08 06:28:55 --> Total execution time: 1.1421
INFO - 2016-02-08 06:34:58 --> Config Class Initialized
INFO - 2016-02-08 06:34:58 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:34:58 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:34:58 --> Utf8 Class Initialized
INFO - 2016-02-08 06:34:58 --> URI Class Initialized
INFO - 2016-02-08 06:34:58 --> Router Class Initialized
INFO - 2016-02-08 06:34:58 --> Output Class Initialized
INFO - 2016-02-08 06:34:58 --> Security Class Initialized
DEBUG - 2016-02-08 06:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:34:58 --> Input Class Initialized
INFO - 2016-02-08 06:34:58 --> Language Class Initialized
INFO - 2016-02-08 06:34:58 --> Loader Class Initialized
INFO - 2016-02-08 06:34:58 --> Helper loaded: url_helper
INFO - 2016-02-08 06:34:58 --> Helper loaded: file_helper
INFO - 2016-02-08 06:34:58 --> Helper loaded: date_helper
INFO - 2016-02-08 06:34:58 --> Helper loaded: form_helper
INFO - 2016-02-08 06:34:58 --> Database Driver Class Initialized
INFO - 2016-02-08 06:34:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:34:59 --> Controller Class Initialized
INFO - 2016-02-08 06:34:59 --> Model Class Initialized
INFO - 2016-02-08 06:34:59 --> Model Class Initialized
INFO - 2016-02-08 06:34:59 --> Form Validation Class Initialized
INFO - 2016-02-08 06:34:59 --> Helper loaded: text_helper
INFO - 2016-02-08 06:34:59 --> Config Class Initialized
INFO - 2016-02-08 06:34:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:34:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:34:59 --> Utf8 Class Initialized
INFO - 2016-02-08 06:34:59 --> URI Class Initialized
INFO - 2016-02-08 06:34:59 --> Router Class Initialized
INFO - 2016-02-08 06:34:59 --> Output Class Initialized
INFO - 2016-02-08 06:34:59 --> Security Class Initialized
DEBUG - 2016-02-08 06:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:34:59 --> Input Class Initialized
INFO - 2016-02-08 06:34:59 --> Language Class Initialized
INFO - 2016-02-08 06:34:59 --> Loader Class Initialized
INFO - 2016-02-08 06:34:59 --> Helper loaded: url_helper
INFO - 2016-02-08 06:34:59 --> Helper loaded: file_helper
INFO - 2016-02-08 06:34:59 --> Helper loaded: date_helper
INFO - 2016-02-08 06:34:59 --> Helper loaded: form_helper
INFO - 2016-02-08 06:34:59 --> Database Driver Class Initialized
INFO - 2016-02-08 06:35:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:35:00 --> Controller Class Initialized
INFO - 2016-02-08 06:35:00 --> Model Class Initialized
INFO - 2016-02-08 06:35:00 --> Model Class Initialized
INFO - 2016-02-08 06:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 06:35:00 --> Pagination Class Initialized
INFO - 2016-02-08 06:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 06:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:35:00 --> Final output sent to browser
DEBUG - 2016-02-08 06:35:00 --> Total execution time: 1.1258
INFO - 2016-02-08 06:35:02 --> Config Class Initialized
INFO - 2016-02-08 06:35:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 06:35:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 06:35:02 --> Utf8 Class Initialized
INFO - 2016-02-08 06:35:02 --> URI Class Initialized
INFO - 2016-02-08 06:35:02 --> Router Class Initialized
INFO - 2016-02-08 06:35:02 --> Output Class Initialized
INFO - 2016-02-08 06:35:02 --> Security Class Initialized
DEBUG - 2016-02-08 06:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 06:35:02 --> Input Class Initialized
INFO - 2016-02-08 06:35:02 --> Language Class Initialized
INFO - 2016-02-08 06:35:02 --> Loader Class Initialized
INFO - 2016-02-08 06:35:02 --> Helper loaded: url_helper
INFO - 2016-02-08 06:35:02 --> Helper loaded: file_helper
INFO - 2016-02-08 06:35:02 --> Helper loaded: date_helper
INFO - 2016-02-08 06:35:02 --> Helper loaded: form_helper
INFO - 2016-02-08 06:35:02 --> Database Driver Class Initialized
INFO - 2016-02-08 06:35:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 06:35:03 --> Controller Class Initialized
INFO - 2016-02-08 06:35:03 --> Model Class Initialized
INFO - 2016-02-08 06:35:03 --> Model Class Initialized
INFO - 2016-02-08 06:35:03 --> Form Validation Class Initialized
INFO - 2016-02-08 06:35:03 --> Helper loaded: text_helper
INFO - 2016-02-08 06:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 06:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 06:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-08 06:35:03 --> Model Class Initialized
INFO - 2016-02-08 06:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 06:35:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 06:35:03 --> Final output sent to browser
DEBUG - 2016-02-08 06:35:03 --> Total execution time: 1.1487
INFO - 2016-02-08 07:46:30 --> Config Class Initialized
INFO - 2016-02-08 07:46:30 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:46:30 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:46:30 --> Utf8 Class Initialized
INFO - 2016-02-08 07:46:30 --> URI Class Initialized
INFO - 2016-02-08 07:46:30 --> Router Class Initialized
INFO - 2016-02-08 07:46:30 --> Output Class Initialized
INFO - 2016-02-08 07:46:30 --> Security Class Initialized
DEBUG - 2016-02-08 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:46:30 --> Input Class Initialized
INFO - 2016-02-08 07:46:30 --> Language Class Initialized
INFO - 2016-02-08 07:46:30 --> Loader Class Initialized
INFO - 2016-02-08 07:46:30 --> Helper loaded: url_helper
INFO - 2016-02-08 07:46:30 --> Helper loaded: file_helper
INFO - 2016-02-08 07:46:30 --> Helper loaded: date_helper
INFO - 2016-02-08 07:46:30 --> Helper loaded: form_helper
INFO - 2016-02-08 07:46:30 --> Database Driver Class Initialized
INFO - 2016-02-08 07:46:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:46:31 --> Controller Class Initialized
INFO - 2016-02-08 07:46:31 --> Model Class Initialized
INFO - 2016-02-08 07:46:31 --> Model Class Initialized
INFO - 2016-02-08 07:46:31 --> Form Validation Class Initialized
INFO - 2016-02-08 07:46:31 --> Helper loaded: text_helper
INFO - 2016-02-08 07:46:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 07:46:31 --> Final output sent to browser
DEBUG - 2016-02-08 07:46:31 --> Total execution time: 1.2683
INFO - 2016-02-08 07:46:33 --> Config Class Initialized
INFO - 2016-02-08 07:46:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:46:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:46:33 --> Utf8 Class Initialized
INFO - 2016-02-08 07:46:33 --> URI Class Initialized
INFO - 2016-02-08 07:46:33 --> Router Class Initialized
INFO - 2016-02-08 07:46:33 --> Output Class Initialized
INFO - 2016-02-08 07:46:33 --> Security Class Initialized
DEBUG - 2016-02-08 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:46:33 --> Input Class Initialized
INFO - 2016-02-08 07:46:33 --> Language Class Initialized
INFO - 2016-02-08 07:46:33 --> Loader Class Initialized
INFO - 2016-02-08 07:46:33 --> Helper loaded: url_helper
INFO - 2016-02-08 07:46:33 --> Helper loaded: file_helper
INFO - 2016-02-08 07:46:33 --> Helper loaded: date_helper
INFO - 2016-02-08 07:46:33 --> Helper loaded: form_helper
INFO - 2016-02-08 07:46:33 --> Database Driver Class Initialized
INFO - 2016-02-08 07:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:46:34 --> Controller Class Initialized
INFO - 2016-02-08 07:46:34 --> Model Class Initialized
INFO - 2016-02-08 07:46:34 --> Model Class Initialized
INFO - 2016-02-08 07:46:34 --> Form Validation Class Initialized
INFO - 2016-02-08 07:46:34 --> Helper loaded: text_helper
INFO - 2016-02-08 07:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 07:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 07:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-08 07:46:34 --> Model Class Initialized
INFO - 2016-02-08 07:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 07:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 07:46:34 --> Final output sent to browser
DEBUG - 2016-02-08 07:46:34 --> Total execution time: 1.1478
INFO - 2016-02-08 07:57:22 --> Config Class Initialized
INFO - 2016-02-08 07:57:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:57:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:57:22 --> Utf8 Class Initialized
INFO - 2016-02-08 07:57:22 --> URI Class Initialized
DEBUG - 2016-02-08 07:57:22 --> No URI present. Default controller set.
INFO - 2016-02-08 07:57:22 --> Router Class Initialized
INFO - 2016-02-08 07:57:22 --> Output Class Initialized
INFO - 2016-02-08 07:57:22 --> Security Class Initialized
DEBUG - 2016-02-08 07:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:57:22 --> Input Class Initialized
INFO - 2016-02-08 07:57:22 --> Language Class Initialized
INFO - 2016-02-08 07:57:22 --> Loader Class Initialized
INFO - 2016-02-08 07:57:22 --> Helper loaded: url_helper
INFO - 2016-02-08 07:57:22 --> Helper loaded: file_helper
INFO - 2016-02-08 07:57:22 --> Helper loaded: date_helper
INFO - 2016-02-08 07:57:22 --> Helper loaded: form_helper
INFO - 2016-02-08 07:57:22 --> Database Driver Class Initialized
INFO - 2016-02-08 07:57:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:57:23 --> Controller Class Initialized
INFO - 2016-02-08 07:57:23 --> Model Class Initialized
INFO - 2016-02-08 07:57:23 --> Model Class Initialized
INFO - 2016-02-08 07:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 07:57:23 --> Pagination Class Initialized
INFO - 2016-02-08 07:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 07:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 07:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 07:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 07:57:23 --> Final output sent to browser
DEBUG - 2016-02-08 07:57:23 --> Total execution time: 1.1202
INFO - 2016-02-08 07:57:25 --> Config Class Initialized
INFO - 2016-02-08 07:57:25 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:57:25 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:57:25 --> Utf8 Class Initialized
INFO - 2016-02-08 07:57:25 --> URI Class Initialized
INFO - 2016-02-08 07:57:25 --> Router Class Initialized
INFO - 2016-02-08 07:57:25 --> Output Class Initialized
INFO - 2016-02-08 07:57:25 --> Security Class Initialized
DEBUG - 2016-02-08 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:57:25 --> Input Class Initialized
INFO - 2016-02-08 07:57:25 --> Language Class Initialized
INFO - 2016-02-08 07:57:25 --> Loader Class Initialized
INFO - 2016-02-08 07:57:25 --> Helper loaded: url_helper
INFO - 2016-02-08 07:57:25 --> Helper loaded: file_helper
INFO - 2016-02-08 07:57:25 --> Helper loaded: date_helper
INFO - 2016-02-08 07:57:25 --> Helper loaded: form_helper
INFO - 2016-02-08 07:57:25 --> Database Driver Class Initialized
INFO - 2016-02-08 07:57:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:57:26 --> Controller Class Initialized
INFO - 2016-02-08 07:57:26 --> Model Class Initialized
INFO - 2016-02-08 07:57:26 --> Model Class Initialized
INFO - 2016-02-08 07:57:26 --> Form Validation Class Initialized
INFO - 2016-02-08 07:57:26 --> Helper loaded: text_helper
INFO - 2016-02-08 07:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 07:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 07:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-08 07:57:26 --> Model Class Initialized
INFO - 2016-02-08 07:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 07:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 07:57:26 --> Final output sent to browser
DEBUG - 2016-02-08 07:57:26 --> Total execution time: 1.1582
INFO - 2016-02-08 07:57:53 --> Config Class Initialized
INFO - 2016-02-08 07:57:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:57:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:57:53 --> Utf8 Class Initialized
INFO - 2016-02-08 07:57:53 --> URI Class Initialized
INFO - 2016-02-08 07:57:53 --> Router Class Initialized
INFO - 2016-02-08 07:57:53 --> Output Class Initialized
INFO - 2016-02-08 07:57:53 --> Security Class Initialized
DEBUG - 2016-02-08 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:57:53 --> Input Class Initialized
INFO - 2016-02-08 07:57:53 --> Language Class Initialized
INFO - 2016-02-08 07:57:53 --> Loader Class Initialized
INFO - 2016-02-08 07:57:53 --> Helper loaded: url_helper
INFO - 2016-02-08 07:57:53 --> Helper loaded: file_helper
INFO - 2016-02-08 07:57:53 --> Helper loaded: date_helper
INFO - 2016-02-08 07:57:53 --> Helper loaded: form_helper
INFO - 2016-02-08 07:57:53 --> Database Driver Class Initialized
INFO - 2016-02-08 07:57:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:57:54 --> Controller Class Initialized
INFO - 2016-02-08 07:57:54 --> Model Class Initialized
INFO - 2016-02-08 07:57:54 --> Model Class Initialized
INFO - 2016-02-08 07:57:54 --> Form Validation Class Initialized
INFO - 2016-02-08 07:57:54 --> Helper loaded: text_helper
INFO - 2016-02-08 07:57:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 07:57:55 --> Final output sent to browser
DEBUG - 2016-02-08 07:57:55 --> Total execution time: 1.3327
INFO - 2016-02-08 07:57:56 --> Config Class Initialized
INFO - 2016-02-08 07:57:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 07:57:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 07:57:56 --> Utf8 Class Initialized
INFO - 2016-02-08 07:57:56 --> URI Class Initialized
INFO - 2016-02-08 07:57:56 --> Router Class Initialized
INFO - 2016-02-08 07:57:56 --> Output Class Initialized
INFO - 2016-02-08 07:57:56 --> Security Class Initialized
DEBUG - 2016-02-08 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 07:57:56 --> Input Class Initialized
INFO - 2016-02-08 07:57:56 --> Language Class Initialized
INFO - 2016-02-08 07:57:56 --> Loader Class Initialized
INFO - 2016-02-08 07:57:56 --> Helper loaded: url_helper
INFO - 2016-02-08 07:57:56 --> Helper loaded: file_helper
INFO - 2016-02-08 07:57:56 --> Helper loaded: date_helper
INFO - 2016-02-08 07:57:56 --> Helper loaded: form_helper
INFO - 2016-02-08 07:57:56 --> Database Driver Class Initialized
INFO - 2016-02-08 07:57:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 07:57:57 --> Controller Class Initialized
INFO - 2016-02-08 07:57:57 --> Model Class Initialized
INFO - 2016-02-08 07:57:57 --> Model Class Initialized
INFO - 2016-02-08 07:57:57 --> Form Validation Class Initialized
INFO - 2016-02-08 07:57:57 --> Helper loaded: text_helper
INFO - 2016-02-08 07:57:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 07:57:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 07:57:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-08 07:57:57 --> Model Class Initialized
INFO - 2016-02-08 07:57:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 07:57:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 07:57:57 --> Final output sent to browser
DEBUG - 2016-02-08 07:57:57 --> Total execution time: 1.1556
INFO - 2016-02-08 08:07:01 --> Config Class Initialized
INFO - 2016-02-08 08:07:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:01 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:01 --> URI Class Initialized
DEBUG - 2016-02-08 08:07:01 --> No URI present. Default controller set.
INFO - 2016-02-08 08:07:01 --> Router Class Initialized
INFO - 2016-02-08 08:07:01 --> Output Class Initialized
INFO - 2016-02-08 08:07:01 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:01 --> Input Class Initialized
INFO - 2016-02-08 08:07:01 --> Language Class Initialized
INFO - 2016-02-08 08:07:01 --> Loader Class Initialized
INFO - 2016-02-08 08:07:01 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:01 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:02 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:02 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:02 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:03 --> Controller Class Initialized
INFO - 2016-02-08 08:07:03 --> Model Class Initialized
INFO - 2016-02-08 08:07:03 --> Model Class Initialized
INFO - 2016-02-08 08:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:03 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:03 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:03 --> Total execution time: 1.1495
INFO - 2016-02-08 08:07:11 --> Config Class Initialized
INFO - 2016-02-08 08:07:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:11 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:11 --> URI Class Initialized
INFO - 2016-02-08 08:07:11 --> Router Class Initialized
INFO - 2016-02-08 08:07:11 --> Output Class Initialized
INFO - 2016-02-08 08:07:11 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:11 --> Input Class Initialized
INFO - 2016-02-08 08:07:11 --> Language Class Initialized
INFO - 2016-02-08 08:07:11 --> Loader Class Initialized
INFO - 2016-02-08 08:07:11 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:11 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:11 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:11 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:11 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:12 --> Controller Class Initialized
INFO - 2016-02-08 08:07:12 --> Model Class Initialized
INFO - 2016-02-08 08:07:12 --> Model Class Initialized
INFO - 2016-02-08 08:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:12 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:12 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:12 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:12 --> Total execution time: 1.1543
INFO - 2016-02-08 08:07:18 --> Config Class Initialized
INFO - 2016-02-08 08:07:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:18 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:18 --> URI Class Initialized
DEBUG - 2016-02-08 08:07:18 --> No URI present. Default controller set.
INFO - 2016-02-08 08:07:18 --> Router Class Initialized
INFO - 2016-02-08 08:07:18 --> Output Class Initialized
INFO - 2016-02-08 08:07:18 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:18 --> Input Class Initialized
INFO - 2016-02-08 08:07:18 --> Language Class Initialized
INFO - 2016-02-08 08:07:18 --> Loader Class Initialized
INFO - 2016-02-08 08:07:18 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:18 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:18 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:18 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:18 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:19 --> Controller Class Initialized
INFO - 2016-02-08 08:07:19 --> Model Class Initialized
INFO - 2016-02-08 08:07:19 --> Model Class Initialized
INFO - 2016-02-08 08:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:19 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:19 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:19 --> Total execution time: 1.1400
INFO - 2016-02-08 08:07:21 --> Config Class Initialized
INFO - 2016-02-08 08:07:21 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:21 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:21 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:21 --> URI Class Initialized
INFO - 2016-02-08 08:07:21 --> Router Class Initialized
INFO - 2016-02-08 08:07:21 --> Output Class Initialized
INFO - 2016-02-08 08:07:21 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:21 --> Input Class Initialized
INFO - 2016-02-08 08:07:21 --> Language Class Initialized
INFO - 2016-02-08 08:07:21 --> Loader Class Initialized
INFO - 2016-02-08 08:07:21 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:21 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:21 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:21 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:21 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:22 --> Controller Class Initialized
INFO - 2016-02-08 08:07:22 --> Model Class Initialized
INFO - 2016-02-08 08:07:22 --> Model Class Initialized
INFO - 2016-02-08 08:07:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:22 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:22 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:22 --> Total execution time: 1.1037
INFO - 2016-02-08 08:07:26 --> Config Class Initialized
INFO - 2016-02-08 08:07:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:26 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:26 --> URI Class Initialized
INFO - 2016-02-08 08:07:26 --> Router Class Initialized
INFO - 2016-02-08 08:07:26 --> Output Class Initialized
INFO - 2016-02-08 08:07:26 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:26 --> Input Class Initialized
INFO - 2016-02-08 08:07:26 --> Language Class Initialized
INFO - 2016-02-08 08:07:26 --> Loader Class Initialized
INFO - 2016-02-08 08:07:26 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:26 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:26 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:26 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:26 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:27 --> Controller Class Initialized
INFO - 2016-02-08 08:07:27 --> Model Class Initialized
INFO - 2016-02-08 08:07:27 --> Model Class Initialized
INFO - 2016-02-08 08:07:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:27 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:27 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:27 --> Total execution time: 1.1333
INFO - 2016-02-08 08:07:30 --> Config Class Initialized
INFO - 2016-02-08 08:07:30 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:30 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:30 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:30 --> URI Class Initialized
INFO - 2016-02-08 08:07:30 --> Router Class Initialized
INFO - 2016-02-08 08:07:30 --> Output Class Initialized
INFO - 2016-02-08 08:07:30 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:30 --> Input Class Initialized
INFO - 2016-02-08 08:07:30 --> Language Class Initialized
INFO - 2016-02-08 08:07:30 --> Loader Class Initialized
INFO - 2016-02-08 08:07:30 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:30 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:30 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:30 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:30 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:31 --> Controller Class Initialized
INFO - 2016-02-08 08:07:31 --> Model Class Initialized
INFO - 2016-02-08 08:07:31 --> Model Class Initialized
INFO - 2016-02-08 08:07:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:31 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:31 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:31 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:31 --> Total execution time: 1.1562
INFO - 2016-02-08 08:07:33 --> Config Class Initialized
INFO - 2016-02-08 08:07:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:33 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:33 --> URI Class Initialized
INFO - 2016-02-08 08:07:33 --> Router Class Initialized
INFO - 2016-02-08 08:07:33 --> Output Class Initialized
INFO - 2016-02-08 08:07:33 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:33 --> Input Class Initialized
INFO - 2016-02-08 08:07:33 --> Language Class Initialized
INFO - 2016-02-08 08:07:33 --> Loader Class Initialized
INFO - 2016-02-08 08:07:33 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:33 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:33 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:33 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:33 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:34 --> Controller Class Initialized
INFO - 2016-02-08 08:07:34 --> Model Class Initialized
INFO - 2016-02-08 08:07:34 --> Model Class Initialized
INFO - 2016-02-08 08:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:34 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:34 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:34 --> Total execution time: 1.1220
INFO - 2016-02-08 08:07:36 --> Config Class Initialized
INFO - 2016-02-08 08:07:36 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:36 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:36 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:36 --> URI Class Initialized
INFO - 2016-02-08 08:07:36 --> Router Class Initialized
INFO - 2016-02-08 08:07:36 --> Output Class Initialized
INFO - 2016-02-08 08:07:36 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:36 --> Input Class Initialized
INFO - 2016-02-08 08:07:36 --> Language Class Initialized
INFO - 2016-02-08 08:07:36 --> Loader Class Initialized
INFO - 2016-02-08 08:07:36 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:36 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:36 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:36 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:36 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:37 --> Controller Class Initialized
INFO - 2016-02-08 08:07:37 --> Model Class Initialized
INFO - 2016-02-08 08:07:37 --> Model Class Initialized
INFO - 2016-02-08 08:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:37 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:37 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:37 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:37 --> Total execution time: 1.1542
INFO - 2016-02-08 08:07:40 --> Config Class Initialized
INFO - 2016-02-08 08:07:40 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:40 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:40 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:40 --> URI Class Initialized
INFO - 2016-02-08 08:07:40 --> Router Class Initialized
INFO - 2016-02-08 08:07:40 --> Output Class Initialized
INFO - 2016-02-08 08:07:40 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:40 --> Input Class Initialized
INFO - 2016-02-08 08:07:40 --> Language Class Initialized
INFO - 2016-02-08 08:07:40 --> Loader Class Initialized
INFO - 2016-02-08 08:07:40 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:40 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:40 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:40 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:40 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:41 --> Controller Class Initialized
INFO - 2016-02-08 08:07:41 --> Model Class Initialized
INFO - 2016-02-08 08:07:41 --> Model Class Initialized
INFO - 2016-02-08 08:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:41 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:41 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:41 --> Total execution time: 1.1145
INFO - 2016-02-08 08:07:43 --> Config Class Initialized
INFO - 2016-02-08 08:07:43 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:43 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:43 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:43 --> URI Class Initialized
INFO - 2016-02-08 08:07:43 --> Router Class Initialized
INFO - 2016-02-08 08:07:43 --> Output Class Initialized
INFO - 2016-02-08 08:07:43 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:43 --> Input Class Initialized
INFO - 2016-02-08 08:07:43 --> Language Class Initialized
INFO - 2016-02-08 08:07:43 --> Loader Class Initialized
INFO - 2016-02-08 08:07:43 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:43 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:43 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:43 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:43 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:44 --> Controller Class Initialized
INFO - 2016-02-08 08:07:44 --> Model Class Initialized
INFO - 2016-02-08 08:07:44 --> Model Class Initialized
INFO - 2016-02-08 08:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:44 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:44 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:44 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:44 --> Total execution time: 1.2003
INFO - 2016-02-08 08:07:47 --> Config Class Initialized
INFO - 2016-02-08 08:07:47 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:47 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:47 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:47 --> URI Class Initialized
INFO - 2016-02-08 08:07:47 --> Router Class Initialized
INFO - 2016-02-08 08:07:47 --> Output Class Initialized
INFO - 2016-02-08 08:07:47 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:47 --> Input Class Initialized
INFO - 2016-02-08 08:07:47 --> Language Class Initialized
INFO - 2016-02-08 08:07:47 --> Loader Class Initialized
INFO - 2016-02-08 08:07:47 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:47 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:47 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:47 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:47 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:48 --> Controller Class Initialized
INFO - 2016-02-08 08:07:48 --> Model Class Initialized
INFO - 2016-02-08 08:07:48 --> Model Class Initialized
INFO - 2016-02-08 08:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:48 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:48 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:48 --> Total execution time: 1.1720
INFO - 2016-02-08 08:07:49 --> Config Class Initialized
INFO - 2016-02-08 08:07:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:49 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:49 --> URI Class Initialized
INFO - 2016-02-08 08:07:49 --> Router Class Initialized
INFO - 2016-02-08 08:07:49 --> Output Class Initialized
INFO - 2016-02-08 08:07:49 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:49 --> Input Class Initialized
INFO - 2016-02-08 08:07:49 --> Language Class Initialized
INFO - 2016-02-08 08:07:49 --> Loader Class Initialized
INFO - 2016-02-08 08:07:49 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:49 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:49 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:49 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:49 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:50 --> Controller Class Initialized
INFO - 2016-02-08 08:07:50 --> Model Class Initialized
INFO - 2016-02-08 08:07:50 --> Model Class Initialized
INFO - 2016-02-08 08:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:50 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:50 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:50 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:50 --> Total execution time: 1.2268
INFO - 2016-02-08 08:07:53 --> Config Class Initialized
INFO - 2016-02-08 08:07:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:53 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:53 --> URI Class Initialized
INFO - 2016-02-08 08:07:53 --> Router Class Initialized
INFO - 2016-02-08 08:07:53 --> Output Class Initialized
INFO - 2016-02-08 08:07:53 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:53 --> Input Class Initialized
INFO - 2016-02-08 08:07:53 --> Language Class Initialized
INFO - 2016-02-08 08:07:53 --> Loader Class Initialized
INFO - 2016-02-08 08:07:53 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:53 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:53 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:53 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:53 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:54 --> Controller Class Initialized
INFO - 2016-02-08 08:07:54 --> Model Class Initialized
INFO - 2016-02-08 08:07:54 --> Model Class Initialized
INFO - 2016-02-08 08:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:54 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:54 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:54 --> Total execution time: 1.1195
INFO - 2016-02-08 08:07:56 --> Config Class Initialized
INFO - 2016-02-08 08:07:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:07:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:07:56 --> Utf8 Class Initialized
INFO - 2016-02-08 08:07:56 --> URI Class Initialized
INFO - 2016-02-08 08:07:56 --> Router Class Initialized
INFO - 2016-02-08 08:07:56 --> Output Class Initialized
INFO - 2016-02-08 08:07:56 --> Security Class Initialized
DEBUG - 2016-02-08 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:07:56 --> Input Class Initialized
INFO - 2016-02-08 08:07:56 --> Language Class Initialized
INFO - 2016-02-08 08:07:56 --> Loader Class Initialized
INFO - 2016-02-08 08:07:56 --> Helper loaded: url_helper
INFO - 2016-02-08 08:07:56 --> Helper loaded: file_helper
INFO - 2016-02-08 08:07:56 --> Helper loaded: date_helper
INFO - 2016-02-08 08:07:56 --> Helper loaded: form_helper
INFO - 2016-02-08 08:07:56 --> Database Driver Class Initialized
INFO - 2016-02-08 08:07:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:07:57 --> Controller Class Initialized
INFO - 2016-02-08 08:07:57 --> Model Class Initialized
INFO - 2016-02-08 08:07:57 --> Model Class Initialized
INFO - 2016-02-08 08:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:07:57 --> Pagination Class Initialized
INFO - 2016-02-08 08:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:07:57 --> Helper loaded: text_helper
INFO - 2016-02-08 08:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:07:57 --> Final output sent to browser
DEBUG - 2016-02-08 08:07:57 --> Total execution time: 1.1428
INFO - 2016-02-08 08:08:01 --> Config Class Initialized
INFO - 2016-02-08 08:08:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:08:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:08:01 --> Utf8 Class Initialized
INFO - 2016-02-08 08:08:01 --> URI Class Initialized
INFO - 2016-02-08 08:08:01 --> Router Class Initialized
INFO - 2016-02-08 08:08:01 --> Output Class Initialized
INFO - 2016-02-08 08:08:01 --> Security Class Initialized
DEBUG - 2016-02-08 08:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:08:01 --> Input Class Initialized
INFO - 2016-02-08 08:08:01 --> Language Class Initialized
INFO - 2016-02-08 08:08:01 --> Loader Class Initialized
INFO - 2016-02-08 08:08:01 --> Helper loaded: url_helper
INFO - 2016-02-08 08:08:01 --> Helper loaded: file_helper
INFO - 2016-02-08 08:08:01 --> Helper loaded: date_helper
INFO - 2016-02-08 08:08:01 --> Helper loaded: form_helper
INFO - 2016-02-08 08:08:01 --> Database Driver Class Initialized
INFO - 2016-02-08 08:08:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:08:02 --> Controller Class Initialized
INFO - 2016-02-08 08:08:02 --> Model Class Initialized
INFO - 2016-02-08 08:08:02 --> Model Class Initialized
INFO - 2016-02-08 08:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:08:02 --> Pagination Class Initialized
INFO - 2016-02-08 08:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:08:02 --> Final output sent to browser
DEBUG - 2016-02-08 08:08:02 --> Total execution time: 1.1340
INFO - 2016-02-08 08:08:03 --> Config Class Initialized
INFO - 2016-02-08 08:08:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:08:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:08:03 --> Utf8 Class Initialized
INFO - 2016-02-08 08:08:03 --> URI Class Initialized
INFO - 2016-02-08 08:08:03 --> Router Class Initialized
INFO - 2016-02-08 08:08:03 --> Output Class Initialized
INFO - 2016-02-08 08:08:03 --> Security Class Initialized
DEBUG - 2016-02-08 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:08:03 --> Input Class Initialized
INFO - 2016-02-08 08:08:03 --> Language Class Initialized
INFO - 2016-02-08 08:08:03 --> Loader Class Initialized
INFO - 2016-02-08 08:08:03 --> Helper loaded: url_helper
INFO - 2016-02-08 08:08:03 --> Helper loaded: file_helper
INFO - 2016-02-08 08:08:03 --> Helper loaded: date_helper
INFO - 2016-02-08 08:08:03 --> Helper loaded: form_helper
INFO - 2016-02-08 08:08:03 --> Database Driver Class Initialized
INFO - 2016-02-08 08:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:08:04 --> Controller Class Initialized
INFO - 2016-02-08 08:08:04 --> Model Class Initialized
INFO - 2016-02-08 08:08:04 --> Model Class Initialized
INFO - 2016-02-08 08:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:08:04 --> Pagination Class Initialized
INFO - 2016-02-08 08:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:08:04 --> Helper loaded: text_helper
INFO - 2016-02-08 08:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:08:04 --> Final output sent to browser
DEBUG - 2016-02-08 08:08:04 --> Total execution time: 1.2920
INFO - 2016-02-08 08:08:07 --> Config Class Initialized
INFO - 2016-02-08 08:08:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:08:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:08:07 --> Utf8 Class Initialized
INFO - 2016-02-08 08:08:07 --> URI Class Initialized
INFO - 2016-02-08 08:08:07 --> Router Class Initialized
INFO - 2016-02-08 08:08:07 --> Output Class Initialized
INFO - 2016-02-08 08:08:07 --> Security Class Initialized
DEBUG - 2016-02-08 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:08:07 --> Input Class Initialized
INFO - 2016-02-08 08:08:07 --> Language Class Initialized
INFO - 2016-02-08 08:08:07 --> Loader Class Initialized
INFO - 2016-02-08 08:08:07 --> Helper loaded: url_helper
INFO - 2016-02-08 08:08:07 --> Helper loaded: file_helper
INFO - 2016-02-08 08:08:07 --> Helper loaded: date_helper
INFO - 2016-02-08 08:08:07 --> Helper loaded: form_helper
INFO - 2016-02-08 08:08:07 --> Database Driver Class Initialized
INFO - 2016-02-08 08:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:08:08 --> Controller Class Initialized
INFO - 2016-02-08 08:08:08 --> Model Class Initialized
INFO - 2016-02-08 08:08:08 --> Model Class Initialized
INFO - 2016-02-08 08:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:08:08 --> Pagination Class Initialized
INFO - 2016-02-08 08:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:08:08 --> Final output sent to browser
DEBUG - 2016-02-08 08:08:08 --> Total execution time: 1.1176
INFO - 2016-02-08 08:08:11 --> Config Class Initialized
INFO - 2016-02-08 08:08:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:08:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:08:11 --> Utf8 Class Initialized
INFO - 2016-02-08 08:08:11 --> URI Class Initialized
INFO - 2016-02-08 08:08:11 --> Router Class Initialized
INFO - 2016-02-08 08:08:11 --> Output Class Initialized
INFO - 2016-02-08 08:08:11 --> Security Class Initialized
DEBUG - 2016-02-08 08:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:08:11 --> Input Class Initialized
INFO - 2016-02-08 08:08:11 --> Language Class Initialized
INFO - 2016-02-08 08:08:11 --> Loader Class Initialized
INFO - 2016-02-08 08:08:11 --> Helper loaded: url_helper
INFO - 2016-02-08 08:08:11 --> Helper loaded: file_helper
INFO - 2016-02-08 08:08:11 --> Helper loaded: date_helper
INFO - 2016-02-08 08:08:11 --> Helper loaded: form_helper
INFO - 2016-02-08 08:08:11 --> Database Driver Class Initialized
INFO - 2016-02-08 08:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:08:12 --> Controller Class Initialized
INFO - 2016-02-08 08:08:12 --> Model Class Initialized
INFO - 2016-02-08 08:08:12 --> Model Class Initialized
INFO - 2016-02-08 08:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:08:12 --> Pagination Class Initialized
INFO - 2016-02-08 08:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:08:12 --> Final output sent to browser
DEBUG - 2016-02-08 08:08:12 --> Total execution time: 1.1178
INFO - 2016-02-08 08:08:14 --> Config Class Initialized
INFO - 2016-02-08 08:08:14 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:08:14 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:08:14 --> Utf8 Class Initialized
INFO - 2016-02-08 08:08:14 --> URI Class Initialized
INFO - 2016-02-08 08:08:14 --> Router Class Initialized
INFO - 2016-02-08 08:08:14 --> Output Class Initialized
INFO - 2016-02-08 08:08:14 --> Security Class Initialized
DEBUG - 2016-02-08 08:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:08:14 --> Input Class Initialized
INFO - 2016-02-08 08:08:14 --> Language Class Initialized
INFO - 2016-02-08 08:08:14 --> Loader Class Initialized
INFO - 2016-02-08 08:08:14 --> Helper loaded: url_helper
INFO - 2016-02-08 08:08:14 --> Helper loaded: file_helper
INFO - 2016-02-08 08:08:14 --> Helper loaded: date_helper
INFO - 2016-02-08 08:08:14 --> Helper loaded: form_helper
INFO - 2016-02-08 08:08:14 --> Database Driver Class Initialized
INFO - 2016-02-08 08:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:08:15 --> Controller Class Initialized
INFO - 2016-02-08 08:08:15 --> Model Class Initialized
INFO - 2016-02-08 08:08:15 --> Model Class Initialized
INFO - 2016-02-08 08:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:08:15 --> Pagination Class Initialized
INFO - 2016-02-08 08:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:08:15 --> Helper loaded: text_helper
INFO - 2016-02-08 08:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:08:15 --> Final output sent to browser
DEBUG - 2016-02-08 08:08:15 --> Total execution time: 1.1596
INFO - 2016-02-08 08:15:39 --> Config Class Initialized
INFO - 2016-02-08 08:15:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:15:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:15:39 --> Utf8 Class Initialized
INFO - 2016-02-08 08:15:39 --> URI Class Initialized
DEBUG - 2016-02-08 08:15:39 --> No URI present. Default controller set.
INFO - 2016-02-08 08:15:39 --> Router Class Initialized
INFO - 2016-02-08 08:15:39 --> Output Class Initialized
INFO - 2016-02-08 08:15:39 --> Security Class Initialized
DEBUG - 2016-02-08 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:15:39 --> Input Class Initialized
INFO - 2016-02-08 08:15:39 --> Language Class Initialized
INFO - 2016-02-08 08:15:39 --> Loader Class Initialized
INFO - 2016-02-08 08:15:39 --> Helper loaded: url_helper
INFO - 2016-02-08 08:15:39 --> Helper loaded: file_helper
INFO - 2016-02-08 08:15:39 --> Helper loaded: date_helper
INFO - 2016-02-08 08:15:39 --> Helper loaded: form_helper
INFO - 2016-02-08 08:15:39 --> Database Driver Class Initialized
INFO - 2016-02-08 08:15:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:15:40 --> Controller Class Initialized
INFO - 2016-02-08 08:15:40 --> Model Class Initialized
INFO - 2016-02-08 08:15:40 --> Model Class Initialized
INFO - 2016-02-08 08:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:15:40 --> Pagination Class Initialized
INFO - 2016-02-08 08:15:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:15:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:15:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:15:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:15:40 --> Final output sent to browser
DEBUG - 2016-02-08 08:15:40 --> Total execution time: 1.1471
INFO - 2016-02-08 08:15:45 --> Config Class Initialized
INFO - 2016-02-08 08:15:45 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:15:45 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:15:45 --> Utf8 Class Initialized
INFO - 2016-02-08 08:15:45 --> URI Class Initialized
INFO - 2016-02-08 08:15:45 --> Router Class Initialized
INFO - 2016-02-08 08:15:45 --> Output Class Initialized
INFO - 2016-02-08 08:15:45 --> Security Class Initialized
DEBUG - 2016-02-08 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:15:45 --> Input Class Initialized
INFO - 2016-02-08 08:15:45 --> Language Class Initialized
INFO - 2016-02-08 08:15:45 --> Loader Class Initialized
INFO - 2016-02-08 08:15:45 --> Helper loaded: url_helper
INFO - 2016-02-08 08:15:45 --> Helper loaded: file_helper
INFO - 2016-02-08 08:15:45 --> Helper loaded: date_helper
INFO - 2016-02-08 08:15:46 --> Helper loaded: form_helper
INFO - 2016-02-08 08:15:46 --> Database Driver Class Initialized
INFO - 2016-02-08 08:15:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:15:47 --> Controller Class Initialized
INFO - 2016-02-08 08:15:47 --> Model Class Initialized
INFO - 2016-02-08 08:15:47 --> Model Class Initialized
INFO - 2016-02-08 08:15:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:15:47 --> Pagination Class Initialized
INFO - 2016-02-08 08:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:15:47 --> Helper loaded: text_helper
INFO - 2016-02-08 08:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:15:47 --> Final output sent to browser
DEBUG - 2016-02-08 08:15:47 --> Total execution time: 1.1840
INFO - 2016-02-08 08:16:11 --> Config Class Initialized
INFO - 2016-02-08 08:16:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:16:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:16:11 --> Utf8 Class Initialized
INFO - 2016-02-08 08:16:11 --> URI Class Initialized
DEBUG - 2016-02-08 08:16:11 --> No URI present. Default controller set.
INFO - 2016-02-08 08:16:11 --> Router Class Initialized
INFO - 2016-02-08 08:16:11 --> Output Class Initialized
INFO - 2016-02-08 08:16:11 --> Security Class Initialized
DEBUG - 2016-02-08 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:16:11 --> Input Class Initialized
INFO - 2016-02-08 08:16:11 --> Language Class Initialized
INFO - 2016-02-08 08:16:11 --> Loader Class Initialized
INFO - 2016-02-08 08:16:11 --> Helper loaded: url_helper
INFO - 2016-02-08 08:16:11 --> Helper loaded: file_helper
INFO - 2016-02-08 08:16:11 --> Helper loaded: date_helper
INFO - 2016-02-08 08:16:11 --> Helper loaded: form_helper
INFO - 2016-02-08 08:16:11 --> Database Driver Class Initialized
INFO - 2016-02-08 08:16:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:16:12 --> Controller Class Initialized
INFO - 2016-02-08 08:16:12 --> Model Class Initialized
INFO - 2016-02-08 08:16:12 --> Model Class Initialized
INFO - 2016-02-08 08:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:16:12 --> Pagination Class Initialized
INFO - 2016-02-08 08:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:16:12 --> Final output sent to browser
DEBUG - 2016-02-08 08:16:12 --> Total execution time: 1.1280
INFO - 2016-02-08 08:17:55 --> Config Class Initialized
INFO - 2016-02-08 08:17:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:17:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:17:55 --> Utf8 Class Initialized
INFO - 2016-02-08 08:17:55 --> URI Class Initialized
INFO - 2016-02-08 08:17:55 --> Router Class Initialized
INFO - 2016-02-08 08:17:55 --> Output Class Initialized
INFO - 2016-02-08 08:17:55 --> Security Class Initialized
DEBUG - 2016-02-08 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:17:55 --> Input Class Initialized
INFO - 2016-02-08 08:17:55 --> Language Class Initialized
INFO - 2016-02-08 08:17:55 --> Loader Class Initialized
INFO - 2016-02-08 08:17:55 --> Helper loaded: url_helper
INFO - 2016-02-08 08:17:55 --> Helper loaded: file_helper
INFO - 2016-02-08 08:17:55 --> Helper loaded: date_helper
INFO - 2016-02-08 08:17:55 --> Helper loaded: form_helper
INFO - 2016-02-08 08:17:55 --> Database Driver Class Initialized
INFO - 2016-02-08 08:17:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:17:56 --> Controller Class Initialized
INFO - 2016-02-08 08:17:56 --> Model Class Initialized
INFO - 2016-02-08 08:17:56 --> Model Class Initialized
INFO - 2016-02-08 08:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:17:56 --> Pagination Class Initialized
INFO - 2016-02-08 08:17:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:17:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:17:56 --> Helper loaded: text_helper
INFO - 2016-02-08 08:17:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:17:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:17:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:17:56 --> Final output sent to browser
DEBUG - 2016-02-08 08:17:56 --> Total execution time: 1.1631
INFO - 2016-02-08 08:18:05 --> Config Class Initialized
INFO - 2016-02-08 08:18:05 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:18:05 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:18:05 --> Utf8 Class Initialized
INFO - 2016-02-08 08:18:05 --> URI Class Initialized
INFO - 2016-02-08 08:18:05 --> Router Class Initialized
INFO - 2016-02-08 08:18:05 --> Output Class Initialized
INFO - 2016-02-08 08:18:05 --> Security Class Initialized
DEBUG - 2016-02-08 08:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:18:05 --> Input Class Initialized
INFO - 2016-02-08 08:18:05 --> Language Class Initialized
INFO - 2016-02-08 08:18:05 --> Loader Class Initialized
INFO - 2016-02-08 08:18:05 --> Helper loaded: url_helper
INFO - 2016-02-08 08:18:05 --> Helper loaded: file_helper
INFO - 2016-02-08 08:18:05 --> Helper loaded: date_helper
INFO - 2016-02-08 08:18:05 --> Helper loaded: form_helper
INFO - 2016-02-08 08:18:05 --> Database Driver Class Initialized
INFO - 2016-02-08 08:18:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:18:06 --> Controller Class Initialized
INFO - 2016-02-08 08:18:06 --> Model Class Initialized
INFO - 2016-02-08 08:18:06 --> Model Class Initialized
INFO - 2016-02-08 08:18:06 --> Form Validation Class Initialized
INFO - 2016-02-08 08:18:06 --> Helper loaded: text_helper
INFO - 2016-02-08 08:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-08 08:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:18:06 --> Final output sent to browser
DEBUG - 2016-02-08 08:18:06 --> Total execution time: 1.1339
INFO - 2016-02-08 08:18:18 --> Config Class Initialized
INFO - 2016-02-08 08:18:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:18:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:18:18 --> Utf8 Class Initialized
INFO - 2016-02-08 08:18:18 --> URI Class Initialized
INFO - 2016-02-08 08:18:18 --> Router Class Initialized
INFO - 2016-02-08 08:18:18 --> Output Class Initialized
INFO - 2016-02-08 08:18:18 --> Security Class Initialized
DEBUG - 2016-02-08 08:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:18:18 --> Input Class Initialized
INFO - 2016-02-08 08:18:18 --> Language Class Initialized
INFO - 2016-02-08 08:18:18 --> Loader Class Initialized
INFO - 2016-02-08 08:18:18 --> Helper loaded: url_helper
INFO - 2016-02-08 08:18:18 --> Helper loaded: file_helper
INFO - 2016-02-08 08:18:18 --> Helper loaded: date_helper
INFO - 2016-02-08 08:18:18 --> Helper loaded: form_helper
INFO - 2016-02-08 08:18:18 --> Database Driver Class Initialized
INFO - 2016-02-08 08:18:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:18:19 --> Controller Class Initialized
INFO - 2016-02-08 08:18:19 --> Model Class Initialized
INFO - 2016-02-08 08:18:19 --> Model Class Initialized
INFO - 2016-02-08 08:18:19 --> Form Validation Class Initialized
INFO - 2016-02-08 08:18:19 --> Helper loaded: text_helper
ERROR - 2016-02-08 08:18:19 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 92
INFO - 2016-02-08 08:18:19 --> Final output sent to browser
DEBUG - 2016-02-08 08:18:19 --> Total execution time: 1.1166
INFO - 2016-02-08 08:23:12 --> Config Class Initialized
INFO - 2016-02-08 08:23:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:12 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:12 --> URI Class Initialized
INFO - 2016-02-08 08:23:12 --> Router Class Initialized
INFO - 2016-02-08 08:23:12 --> Output Class Initialized
INFO - 2016-02-08 08:23:12 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:12 --> Input Class Initialized
INFO - 2016-02-08 08:23:12 --> Language Class Initialized
INFO - 2016-02-08 08:23:12 --> Loader Class Initialized
INFO - 2016-02-08 08:23:12 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:12 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:12 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:12 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:12 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:13 --> Controller Class Initialized
INFO - 2016-02-08 08:23:13 --> Model Class Initialized
INFO - 2016-02-08 08:23:13 --> Model Class Initialized
INFO - 2016-02-08 08:23:13 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:13 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:23:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:23:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-08 08:23:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:23:13 --> Final output sent to browser
DEBUG - 2016-02-08 08:23:13 --> Total execution time: 1.1674
INFO - 2016-02-08 08:23:16 --> Config Class Initialized
INFO - 2016-02-08 08:23:16 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:16 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:16 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:16 --> URI Class Initialized
INFO - 2016-02-08 08:23:16 --> Router Class Initialized
INFO - 2016-02-08 08:23:16 --> Output Class Initialized
INFO - 2016-02-08 08:23:16 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:16 --> Input Class Initialized
INFO - 2016-02-08 08:23:16 --> Language Class Initialized
INFO - 2016-02-08 08:23:16 --> Loader Class Initialized
INFO - 2016-02-08 08:23:16 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:16 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:16 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:16 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:16 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:17 --> Controller Class Initialized
INFO - 2016-02-08 08:23:17 --> Model Class Initialized
INFO - 2016-02-08 08:23:17 --> Model Class Initialized
INFO - 2016-02-08 08:23:17 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:17 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:17 --> Config Class Initialized
INFO - 2016-02-08 08:23:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:17 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:17 --> URI Class Initialized
INFO - 2016-02-08 08:23:17 --> Router Class Initialized
INFO - 2016-02-08 08:23:17 --> Output Class Initialized
INFO - 2016-02-08 08:23:17 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:17 --> Input Class Initialized
INFO - 2016-02-08 08:23:17 --> Language Class Initialized
INFO - 2016-02-08 08:23:17 --> Loader Class Initialized
INFO - 2016-02-08 08:23:17 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:17 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:17 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:17 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:17 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:18 --> Controller Class Initialized
INFO - 2016-02-08 08:23:18 --> Model Class Initialized
INFO - 2016-02-08 08:23:18 --> Model Class Initialized
INFO - 2016-02-08 08:23:18 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:18 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-08 08:23:18 --> Final output sent to browser
DEBUG - 2016-02-08 08:23:18 --> Total execution time: 1.1351
INFO - 2016-02-08 08:23:31 --> Config Class Initialized
INFO - 2016-02-08 08:23:31 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:31 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:31 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:31 --> URI Class Initialized
INFO - 2016-02-08 08:23:31 --> Router Class Initialized
INFO - 2016-02-08 08:23:31 --> Output Class Initialized
INFO - 2016-02-08 08:23:31 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:31 --> Input Class Initialized
INFO - 2016-02-08 08:23:31 --> Language Class Initialized
INFO - 2016-02-08 08:23:31 --> Loader Class Initialized
INFO - 2016-02-08 08:23:31 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:31 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:31 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:31 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:31 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:32 --> Controller Class Initialized
INFO - 2016-02-08 08:23:32 --> Model Class Initialized
INFO - 2016-02-08 08:23:32 --> Model Class Initialized
INFO - 2016-02-08 08:23:32 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:32 --> Helper loaded: text_helper
ERROR - 2016-02-08 08:23:32 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 92
INFO - 2016-02-08 08:23:32 --> Config Class Initialized
INFO - 2016-02-08 08:23:32 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:32 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:32 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:32 --> URI Class Initialized
INFO - 2016-02-08 08:23:32 --> Router Class Initialized
INFO - 2016-02-08 08:23:32 --> Output Class Initialized
INFO - 2016-02-08 08:23:32 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:32 --> Input Class Initialized
INFO - 2016-02-08 08:23:32 --> Language Class Initialized
INFO - 2016-02-08 08:23:32 --> Loader Class Initialized
INFO - 2016-02-08 08:23:32 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:32 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:32 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:32 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:32 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:33 --> Controller Class Initialized
INFO - 2016-02-08 08:23:33 --> Model Class Initialized
INFO - 2016-02-08 08:23:33 --> Model Class Initialized
INFO - 2016-02-08 08:23:33 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:33 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-08 08:23:33 --> Final output sent to browser
DEBUG - 2016-02-08 08:23:33 --> Total execution time: 1.1156
INFO - 2016-02-08 08:23:49 --> Config Class Initialized
INFO - 2016-02-08 08:23:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:49 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:49 --> URI Class Initialized
INFO - 2016-02-08 08:23:49 --> Router Class Initialized
INFO - 2016-02-08 08:23:49 --> Output Class Initialized
INFO - 2016-02-08 08:23:49 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:49 --> Input Class Initialized
INFO - 2016-02-08 08:23:49 --> Language Class Initialized
INFO - 2016-02-08 08:23:49 --> Loader Class Initialized
INFO - 2016-02-08 08:23:49 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:49 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:49 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:49 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:49 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:50 --> Controller Class Initialized
INFO - 2016-02-08 08:23:50 --> Model Class Initialized
INFO - 2016-02-08 08:23:50 --> Model Class Initialized
INFO - 2016-02-08 08:23:50 --> Form Validation Class Initialized
INFO - 2016-02-08 08:23:50 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:50 --> Config Class Initialized
INFO - 2016-02-08 08:23:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:50 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:50 --> URI Class Initialized
INFO - 2016-02-08 08:23:50 --> Router Class Initialized
INFO - 2016-02-08 08:23:50 --> Output Class Initialized
INFO - 2016-02-08 08:23:50 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:50 --> Input Class Initialized
INFO - 2016-02-08 08:23:50 --> Language Class Initialized
INFO - 2016-02-08 08:23:50 --> Loader Class Initialized
INFO - 2016-02-08 08:23:50 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:50 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:50 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:50 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:50 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:51 --> Controller Class Initialized
INFO - 2016-02-08 08:23:51 --> Model Class Initialized
INFO - 2016-02-08 08:23:51 --> Model Class Initialized
INFO - 2016-02-08 08:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:23:51 --> Pagination Class Initialized
INFO - 2016-02-08 08:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:23:51 --> Final output sent to browser
DEBUG - 2016-02-08 08:23:51 --> Total execution time: 1.1030
INFO - 2016-02-08 08:23:54 --> Config Class Initialized
INFO - 2016-02-08 08:23:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:23:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:23:54 --> Utf8 Class Initialized
INFO - 2016-02-08 08:23:54 --> URI Class Initialized
INFO - 2016-02-08 08:23:54 --> Router Class Initialized
INFO - 2016-02-08 08:23:54 --> Output Class Initialized
INFO - 2016-02-08 08:23:54 --> Security Class Initialized
DEBUG - 2016-02-08 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:23:54 --> Input Class Initialized
INFO - 2016-02-08 08:23:54 --> Language Class Initialized
INFO - 2016-02-08 08:23:54 --> Loader Class Initialized
INFO - 2016-02-08 08:23:54 --> Helper loaded: url_helper
INFO - 2016-02-08 08:23:54 --> Helper loaded: file_helper
INFO - 2016-02-08 08:23:54 --> Helper loaded: date_helper
INFO - 2016-02-08 08:23:54 --> Helper loaded: form_helper
INFO - 2016-02-08 08:23:54 --> Database Driver Class Initialized
INFO - 2016-02-08 08:23:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:23:55 --> Controller Class Initialized
INFO - 2016-02-08 08:23:55 --> Model Class Initialized
INFO - 2016-02-08 08:23:55 --> Model Class Initialized
INFO - 2016-02-08 08:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:23:55 --> Pagination Class Initialized
INFO - 2016-02-08 08:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:23:55 --> Helper loaded: text_helper
INFO - 2016-02-08 08:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:23:55 --> Final output sent to browser
DEBUG - 2016-02-08 08:23:55 --> Total execution time: 1.1566
INFO - 2016-02-08 08:24:10 --> Config Class Initialized
INFO - 2016-02-08 08:24:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:24:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:24:10 --> Utf8 Class Initialized
INFO - 2016-02-08 08:24:10 --> URI Class Initialized
INFO - 2016-02-08 08:24:10 --> Router Class Initialized
INFO - 2016-02-08 08:24:10 --> Output Class Initialized
INFO - 2016-02-08 08:24:10 --> Security Class Initialized
DEBUG - 2016-02-08 08:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:24:10 --> Input Class Initialized
INFO - 2016-02-08 08:24:10 --> Language Class Initialized
INFO - 2016-02-08 08:24:10 --> Loader Class Initialized
INFO - 2016-02-08 08:24:10 --> Helper loaded: url_helper
INFO - 2016-02-08 08:24:10 --> Helper loaded: file_helper
INFO - 2016-02-08 08:24:10 --> Helper loaded: date_helper
INFO - 2016-02-08 08:24:10 --> Helper loaded: form_helper
INFO - 2016-02-08 08:24:10 --> Database Driver Class Initialized
INFO - 2016-02-08 08:24:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:24:11 --> Controller Class Initialized
INFO - 2016-02-08 08:24:11 --> Model Class Initialized
INFO - 2016-02-08 08:24:11 --> Model Class Initialized
INFO - 2016-02-08 08:24:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:24:11 --> Pagination Class Initialized
INFO - 2016-02-08 08:24:11 --> Form Validation Class Initialized
INFO - 2016-02-08 08:24:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 08:24:11 --> Model Class Initialized
INFO - 2016-02-08 08:24:11 --> Final output sent to browser
DEBUG - 2016-02-08 08:24:11 --> Total execution time: 1.1999
INFO - 2016-02-08 08:24:22 --> Config Class Initialized
INFO - 2016-02-08 08:24:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:24:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:24:22 --> Utf8 Class Initialized
INFO - 2016-02-08 08:24:22 --> URI Class Initialized
INFO - 2016-02-08 08:24:22 --> Router Class Initialized
INFO - 2016-02-08 08:24:22 --> Output Class Initialized
INFO - 2016-02-08 08:24:22 --> Security Class Initialized
DEBUG - 2016-02-08 08:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:24:22 --> Input Class Initialized
INFO - 2016-02-08 08:24:22 --> Language Class Initialized
INFO - 2016-02-08 08:24:22 --> Loader Class Initialized
INFO - 2016-02-08 08:24:22 --> Helper loaded: url_helper
INFO - 2016-02-08 08:24:22 --> Helper loaded: file_helper
INFO - 2016-02-08 08:24:22 --> Helper loaded: date_helper
INFO - 2016-02-08 08:24:22 --> Helper loaded: form_helper
INFO - 2016-02-08 08:24:22 --> Database Driver Class Initialized
INFO - 2016-02-08 08:24:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:24:23 --> Controller Class Initialized
INFO - 2016-02-08 08:24:23 --> Model Class Initialized
INFO - 2016-02-08 08:24:23 --> Model Class Initialized
INFO - 2016-02-08 08:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:24:23 --> Pagination Class Initialized
INFO - 2016-02-08 08:24:23 --> Form Validation Class Initialized
INFO - 2016-02-08 08:24:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 08:24:23 --> Model Class Initialized
INFO - 2016-02-08 08:24:23 --> Final output sent to browser
DEBUG - 2016-02-08 08:24:23 --> Total execution time: 1.1972
INFO - 2016-02-08 08:24:50 --> Config Class Initialized
INFO - 2016-02-08 08:24:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:24:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:24:50 --> Utf8 Class Initialized
INFO - 2016-02-08 08:24:50 --> URI Class Initialized
INFO - 2016-02-08 08:24:50 --> Router Class Initialized
INFO - 2016-02-08 08:24:50 --> Output Class Initialized
INFO - 2016-02-08 08:24:50 --> Security Class Initialized
DEBUG - 2016-02-08 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:24:50 --> Input Class Initialized
INFO - 2016-02-08 08:24:50 --> Language Class Initialized
INFO - 2016-02-08 08:24:50 --> Loader Class Initialized
INFO - 2016-02-08 08:24:50 --> Helper loaded: url_helper
INFO - 2016-02-08 08:24:50 --> Helper loaded: file_helper
INFO - 2016-02-08 08:24:50 --> Helper loaded: date_helper
INFO - 2016-02-08 08:24:50 --> Helper loaded: form_helper
INFO - 2016-02-08 08:24:50 --> Database Driver Class Initialized
INFO - 2016-02-08 08:24:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:24:51 --> Controller Class Initialized
INFO - 2016-02-08 08:24:51 --> Model Class Initialized
INFO - 2016-02-08 08:24:51 --> Model Class Initialized
INFO - 2016-02-08 08:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:24:51 --> Pagination Class Initialized
INFO - 2016-02-08 08:24:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:24:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:24:51 --> Helper loaded: text_helper
INFO - 2016-02-08 08:24:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:24:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:24:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:24:51 --> Final output sent to browser
DEBUG - 2016-02-08 08:24:51 --> Total execution time: 1.1608
INFO - 2016-02-08 08:27:02 --> Config Class Initialized
INFO - 2016-02-08 08:27:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:27:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:27:02 --> Utf8 Class Initialized
INFO - 2016-02-08 08:27:02 --> URI Class Initialized
DEBUG - 2016-02-08 08:27:02 --> No URI present. Default controller set.
INFO - 2016-02-08 08:27:02 --> Router Class Initialized
INFO - 2016-02-08 08:27:02 --> Output Class Initialized
INFO - 2016-02-08 08:27:02 --> Security Class Initialized
DEBUG - 2016-02-08 08:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:27:02 --> Input Class Initialized
INFO - 2016-02-08 08:27:02 --> Language Class Initialized
INFO - 2016-02-08 08:27:02 --> Loader Class Initialized
INFO - 2016-02-08 08:27:02 --> Helper loaded: url_helper
INFO - 2016-02-08 08:27:02 --> Helper loaded: file_helper
INFO - 2016-02-08 08:27:02 --> Helper loaded: date_helper
INFO - 2016-02-08 08:27:02 --> Helper loaded: form_helper
INFO - 2016-02-08 08:27:02 --> Database Driver Class Initialized
INFO - 2016-02-08 08:27:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:27:03 --> Controller Class Initialized
INFO - 2016-02-08 08:27:03 --> Model Class Initialized
INFO - 2016-02-08 08:27:03 --> Model Class Initialized
INFO - 2016-02-08 08:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:27:03 --> Pagination Class Initialized
INFO - 2016-02-08 08:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:27:03 --> Final output sent to browser
DEBUG - 2016-02-08 08:27:03 --> Total execution time: 1.1520
INFO - 2016-02-08 08:27:05 --> Config Class Initialized
INFO - 2016-02-08 08:27:05 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:27:05 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:27:05 --> Utf8 Class Initialized
INFO - 2016-02-08 08:27:05 --> URI Class Initialized
INFO - 2016-02-08 08:27:05 --> Router Class Initialized
INFO - 2016-02-08 08:27:05 --> Output Class Initialized
INFO - 2016-02-08 08:27:05 --> Security Class Initialized
DEBUG - 2016-02-08 08:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:27:05 --> Input Class Initialized
INFO - 2016-02-08 08:27:05 --> Language Class Initialized
INFO - 2016-02-08 08:27:05 --> Loader Class Initialized
INFO - 2016-02-08 08:27:05 --> Helper loaded: url_helper
INFO - 2016-02-08 08:27:05 --> Helper loaded: file_helper
INFO - 2016-02-08 08:27:05 --> Helper loaded: date_helper
INFO - 2016-02-08 08:27:05 --> Helper loaded: form_helper
INFO - 2016-02-08 08:27:05 --> Database Driver Class Initialized
INFO - 2016-02-08 08:27:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:27:06 --> Controller Class Initialized
INFO - 2016-02-08 08:27:06 --> Model Class Initialized
INFO - 2016-02-08 08:27:06 --> Model Class Initialized
INFO - 2016-02-08 08:27:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:27:06 --> Pagination Class Initialized
INFO - 2016-02-08 08:27:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:27:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:27:06 --> Helper loaded: text_helper
INFO - 2016-02-08 08:27:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:27:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:27:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:27:06 --> Final output sent to browser
DEBUG - 2016-02-08 08:27:06 --> Total execution time: 1.1889
INFO - 2016-02-08 08:27:13 --> Config Class Initialized
INFO - 2016-02-08 08:27:13 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:27:13 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:27:13 --> Utf8 Class Initialized
INFO - 2016-02-08 08:27:13 --> URI Class Initialized
INFO - 2016-02-08 08:27:13 --> Router Class Initialized
INFO - 2016-02-08 08:27:13 --> Output Class Initialized
INFO - 2016-02-08 08:27:13 --> Security Class Initialized
DEBUG - 2016-02-08 08:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:27:13 --> Input Class Initialized
INFO - 2016-02-08 08:27:13 --> Language Class Initialized
INFO - 2016-02-08 08:27:13 --> Loader Class Initialized
INFO - 2016-02-08 08:27:13 --> Helper loaded: url_helper
INFO - 2016-02-08 08:27:13 --> Helper loaded: file_helper
INFO - 2016-02-08 08:27:13 --> Helper loaded: date_helper
INFO - 2016-02-08 08:27:13 --> Helper loaded: form_helper
INFO - 2016-02-08 08:27:13 --> Database Driver Class Initialized
INFO - 2016-02-08 08:27:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:27:14 --> Controller Class Initialized
INFO - 2016-02-08 08:27:14 --> Model Class Initialized
INFO - 2016-02-08 08:27:14 --> Model Class Initialized
INFO - 2016-02-08 08:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:27:14 --> Pagination Class Initialized
INFO - 2016-02-08 08:27:14 --> Form Validation Class Initialized
INFO - 2016-02-08 08:27:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 08:27:14 --> Model Class Initialized
INFO - 2016-02-08 08:27:14 --> Final output sent to browser
DEBUG - 2016-02-08 08:27:14 --> Total execution time: 1.2381
INFO - 2016-02-08 08:27:22 --> Config Class Initialized
INFO - 2016-02-08 08:27:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:27:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:27:22 --> Utf8 Class Initialized
INFO - 2016-02-08 08:27:22 --> URI Class Initialized
INFO - 2016-02-08 08:27:22 --> Router Class Initialized
INFO - 2016-02-08 08:27:22 --> Output Class Initialized
INFO - 2016-02-08 08:27:22 --> Security Class Initialized
DEBUG - 2016-02-08 08:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:27:22 --> Input Class Initialized
INFO - 2016-02-08 08:27:22 --> Language Class Initialized
INFO - 2016-02-08 08:27:22 --> Loader Class Initialized
INFO - 2016-02-08 08:27:22 --> Helper loaded: url_helper
INFO - 2016-02-08 08:27:22 --> Helper loaded: file_helper
INFO - 2016-02-08 08:27:22 --> Helper loaded: date_helper
INFO - 2016-02-08 08:27:22 --> Helper loaded: form_helper
INFO - 2016-02-08 08:27:22 --> Database Driver Class Initialized
INFO - 2016-02-08 08:27:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:27:23 --> Controller Class Initialized
INFO - 2016-02-08 08:27:23 --> Model Class Initialized
INFO - 2016-02-08 08:27:23 --> Model Class Initialized
INFO - 2016-02-08 08:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:27:23 --> Pagination Class Initialized
INFO - 2016-02-08 08:27:23 --> Form Validation Class Initialized
INFO - 2016-02-08 08:27:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 08:27:23 --> Model Class Initialized
INFO - 2016-02-08 08:27:23 --> Final output sent to browser
DEBUG - 2016-02-08 08:27:23 --> Total execution time: 1.2309
INFO - 2016-02-08 08:28:55 --> Config Class Initialized
INFO - 2016-02-08 08:28:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:28:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:28:55 --> Utf8 Class Initialized
INFO - 2016-02-08 08:28:55 --> URI Class Initialized
DEBUG - 2016-02-08 08:28:55 --> No URI present. Default controller set.
INFO - 2016-02-08 08:28:55 --> Router Class Initialized
INFO - 2016-02-08 08:28:55 --> Output Class Initialized
INFO - 2016-02-08 08:28:55 --> Security Class Initialized
DEBUG - 2016-02-08 08:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:28:55 --> Input Class Initialized
INFO - 2016-02-08 08:28:55 --> Language Class Initialized
INFO - 2016-02-08 08:28:56 --> Loader Class Initialized
INFO - 2016-02-08 08:28:56 --> Helper loaded: url_helper
INFO - 2016-02-08 08:28:56 --> Helper loaded: file_helper
INFO - 2016-02-08 08:28:56 --> Helper loaded: date_helper
INFO - 2016-02-08 08:28:56 --> Helper loaded: form_helper
INFO - 2016-02-08 08:28:56 --> Database Driver Class Initialized
INFO - 2016-02-08 08:28:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:28:57 --> Controller Class Initialized
INFO - 2016-02-08 08:28:57 --> Model Class Initialized
INFO - 2016-02-08 08:28:57 --> Model Class Initialized
INFO - 2016-02-08 08:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:28:57 --> Pagination Class Initialized
INFO - 2016-02-08 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:28:57 --> Final output sent to browser
DEBUG - 2016-02-08 08:28:57 --> Total execution time: 1.1360
INFO - 2016-02-08 08:28:59 --> Config Class Initialized
INFO - 2016-02-08 08:28:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:28:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:28:59 --> Utf8 Class Initialized
INFO - 2016-02-08 08:28:59 --> URI Class Initialized
INFO - 2016-02-08 08:28:59 --> Router Class Initialized
INFO - 2016-02-08 08:28:59 --> Output Class Initialized
INFO - 2016-02-08 08:28:59 --> Security Class Initialized
DEBUG - 2016-02-08 08:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:28:59 --> Input Class Initialized
INFO - 2016-02-08 08:28:59 --> Language Class Initialized
INFO - 2016-02-08 08:28:59 --> Loader Class Initialized
INFO - 2016-02-08 08:28:59 --> Helper loaded: url_helper
INFO - 2016-02-08 08:28:59 --> Helper loaded: file_helper
INFO - 2016-02-08 08:28:59 --> Helper loaded: date_helper
INFO - 2016-02-08 08:28:59 --> Helper loaded: form_helper
INFO - 2016-02-08 08:28:59 --> Database Driver Class Initialized
INFO - 2016-02-08 08:29:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:29:00 --> Controller Class Initialized
INFO - 2016-02-08 08:29:00 --> Model Class Initialized
INFO - 2016-02-08 08:29:00 --> Model Class Initialized
INFO - 2016-02-08 08:29:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:29:00 --> Pagination Class Initialized
INFO - 2016-02-08 08:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:29:00 --> Helper loaded: text_helper
INFO - 2016-02-08 08:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:29:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:29:00 --> Final output sent to browser
DEBUG - 2016-02-08 08:29:00 --> Total execution time: 1.1714
INFO - 2016-02-08 08:39:49 --> Config Class Initialized
INFO - 2016-02-08 08:39:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:39:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:39:49 --> Utf8 Class Initialized
INFO - 2016-02-08 08:39:49 --> URI Class Initialized
INFO - 2016-02-08 08:39:49 --> Router Class Initialized
INFO - 2016-02-08 08:39:49 --> Output Class Initialized
INFO - 2016-02-08 08:39:49 --> Security Class Initialized
DEBUG - 2016-02-08 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:39:49 --> Input Class Initialized
INFO - 2016-02-08 08:39:49 --> Language Class Initialized
INFO - 2016-02-08 08:39:49 --> Loader Class Initialized
INFO - 2016-02-08 08:39:49 --> Helper loaded: url_helper
INFO - 2016-02-08 08:39:49 --> Helper loaded: file_helper
INFO - 2016-02-08 08:39:49 --> Helper loaded: date_helper
INFO - 2016-02-08 08:39:49 --> Helper loaded: form_helper
INFO - 2016-02-08 08:39:49 --> Database Driver Class Initialized
INFO - 2016-02-08 08:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:39:50 --> Controller Class Initialized
INFO - 2016-02-08 08:39:50 --> Model Class Initialized
INFO - 2016-02-08 08:39:50 --> Model Class Initialized
INFO - 2016-02-08 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:39:50 --> Pagination Class Initialized
INFO - 2016-02-08 08:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:39:50 --> Helper loaded: text_helper
INFO - 2016-02-08 08:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:39:50 --> Final output sent to browser
DEBUG - 2016-02-08 08:39:50 --> Total execution time: 1.1472
INFO - 2016-02-08 08:46:56 --> Config Class Initialized
INFO - 2016-02-08 08:46:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:46:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:46:56 --> Utf8 Class Initialized
INFO - 2016-02-08 08:46:56 --> URI Class Initialized
INFO - 2016-02-08 08:46:56 --> Router Class Initialized
INFO - 2016-02-08 08:46:56 --> Output Class Initialized
INFO - 2016-02-08 08:46:56 --> Security Class Initialized
DEBUG - 2016-02-08 08:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:46:56 --> Input Class Initialized
INFO - 2016-02-08 08:46:56 --> Language Class Initialized
INFO - 2016-02-08 08:46:56 --> Loader Class Initialized
INFO - 2016-02-08 08:46:56 --> Helper loaded: url_helper
INFO - 2016-02-08 08:46:56 --> Helper loaded: file_helper
INFO - 2016-02-08 08:46:56 --> Helper loaded: date_helper
INFO - 2016-02-08 08:46:56 --> Helper loaded: form_helper
INFO - 2016-02-08 08:46:56 --> Database Driver Class Initialized
INFO - 2016-02-08 08:46:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:46:57 --> Controller Class Initialized
INFO - 2016-02-08 08:46:57 --> Model Class Initialized
INFO - 2016-02-08 08:46:57 --> Model Class Initialized
INFO - 2016-02-08 08:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:46:57 --> Pagination Class Initialized
INFO - 2016-02-08 08:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:46:57 --> Helper loaded: text_helper
INFO - 2016-02-08 08:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:46:57 --> Final output sent to browser
DEBUG - 2016-02-08 08:46:57 --> Total execution time: 1.1462
INFO - 2016-02-08 08:50:47 --> Config Class Initialized
INFO - 2016-02-08 08:50:47 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:50:47 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:50:47 --> Utf8 Class Initialized
INFO - 2016-02-08 08:50:47 --> URI Class Initialized
INFO - 2016-02-08 08:50:47 --> Router Class Initialized
INFO - 2016-02-08 08:50:47 --> Output Class Initialized
INFO - 2016-02-08 08:50:47 --> Security Class Initialized
DEBUG - 2016-02-08 08:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:50:47 --> Input Class Initialized
INFO - 2016-02-08 08:50:47 --> Language Class Initialized
INFO - 2016-02-08 08:50:47 --> Loader Class Initialized
INFO - 2016-02-08 08:50:47 --> Helper loaded: url_helper
INFO - 2016-02-08 08:50:47 --> Helper loaded: file_helper
INFO - 2016-02-08 08:50:47 --> Helper loaded: date_helper
INFO - 2016-02-08 08:50:47 --> Helper loaded: form_helper
INFO - 2016-02-08 08:50:47 --> Database Driver Class Initialized
INFO - 2016-02-08 08:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:50:48 --> Controller Class Initialized
INFO - 2016-02-08 08:50:48 --> Model Class Initialized
INFO - 2016-02-08 08:50:48 --> Model Class Initialized
INFO - 2016-02-08 08:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:50:48 --> Pagination Class Initialized
INFO - 2016-02-08 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:50:48 --> Helper loaded: text_helper
INFO - 2016-02-08 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:50:48 --> Final output sent to browser
DEBUG - 2016-02-08 08:50:48 --> Total execution time: 1.1800
INFO - 2016-02-08 08:52:08 --> Config Class Initialized
INFO - 2016-02-08 08:52:08 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:52:08 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:52:08 --> Utf8 Class Initialized
INFO - 2016-02-08 08:52:08 --> URI Class Initialized
INFO - 2016-02-08 08:52:08 --> Router Class Initialized
INFO - 2016-02-08 08:52:08 --> Output Class Initialized
INFO - 2016-02-08 08:52:08 --> Security Class Initialized
DEBUG - 2016-02-08 08:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:52:08 --> Input Class Initialized
INFO - 2016-02-08 08:52:08 --> Language Class Initialized
INFO - 2016-02-08 08:52:08 --> Loader Class Initialized
INFO - 2016-02-08 08:52:08 --> Helper loaded: url_helper
INFO - 2016-02-08 08:52:08 --> Helper loaded: file_helper
INFO - 2016-02-08 08:52:08 --> Helper loaded: date_helper
INFO - 2016-02-08 08:52:08 --> Helper loaded: form_helper
INFO - 2016-02-08 08:52:08 --> Database Driver Class Initialized
INFO - 2016-02-08 08:52:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:52:09 --> Controller Class Initialized
INFO - 2016-02-08 08:52:09 --> Model Class Initialized
INFO - 2016-02-08 08:52:09 --> Model Class Initialized
INFO - 2016-02-08 08:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:52:09 --> Pagination Class Initialized
INFO - 2016-02-08 08:52:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:52:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:52:09 --> Helper loaded: text_helper
INFO - 2016-02-08 08:52:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:52:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:52:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:52:09 --> Final output sent to browser
DEBUG - 2016-02-08 08:52:09 --> Total execution time: 1.1450
INFO - 2016-02-08 08:52:39 --> Config Class Initialized
INFO - 2016-02-08 08:52:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:52:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:52:39 --> Utf8 Class Initialized
INFO - 2016-02-08 08:52:39 --> URI Class Initialized
INFO - 2016-02-08 08:52:39 --> Router Class Initialized
INFO - 2016-02-08 08:52:39 --> Output Class Initialized
INFO - 2016-02-08 08:52:39 --> Security Class Initialized
DEBUG - 2016-02-08 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:52:39 --> Input Class Initialized
INFO - 2016-02-08 08:52:39 --> Language Class Initialized
INFO - 2016-02-08 08:52:39 --> Loader Class Initialized
INFO - 2016-02-08 08:52:39 --> Helper loaded: url_helper
INFO - 2016-02-08 08:52:39 --> Helper loaded: file_helper
INFO - 2016-02-08 08:52:39 --> Helper loaded: date_helper
INFO - 2016-02-08 08:52:39 --> Helper loaded: form_helper
INFO - 2016-02-08 08:52:39 --> Database Driver Class Initialized
INFO - 2016-02-08 08:52:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:52:40 --> Controller Class Initialized
INFO - 2016-02-08 08:52:40 --> Model Class Initialized
INFO - 2016-02-08 08:52:40 --> Model Class Initialized
INFO - 2016-02-08 08:52:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:52:40 --> Pagination Class Initialized
INFO - 2016-02-08 08:52:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:52:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:52:40 --> Helper loaded: text_helper
INFO - 2016-02-08 08:52:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:52:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:52:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:52:40 --> Final output sent to browser
DEBUG - 2016-02-08 08:52:40 --> Total execution time: 1.2543
INFO - 2016-02-08 08:53:01 --> Config Class Initialized
INFO - 2016-02-08 08:53:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:53:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:53:01 --> Utf8 Class Initialized
INFO - 2016-02-08 08:53:01 --> URI Class Initialized
INFO - 2016-02-08 08:53:01 --> Router Class Initialized
INFO - 2016-02-08 08:53:01 --> Output Class Initialized
INFO - 2016-02-08 08:53:01 --> Security Class Initialized
DEBUG - 2016-02-08 08:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:53:01 --> Input Class Initialized
INFO - 2016-02-08 08:53:01 --> Language Class Initialized
INFO - 2016-02-08 08:53:01 --> Loader Class Initialized
INFO - 2016-02-08 08:53:01 --> Helper loaded: url_helper
INFO - 2016-02-08 08:53:01 --> Helper loaded: file_helper
INFO - 2016-02-08 08:53:01 --> Helper loaded: date_helper
INFO - 2016-02-08 08:53:01 --> Helper loaded: form_helper
INFO - 2016-02-08 08:53:01 --> Database Driver Class Initialized
INFO - 2016-02-08 08:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:53:02 --> Controller Class Initialized
INFO - 2016-02-08 08:53:02 --> Model Class Initialized
INFO - 2016-02-08 08:53:02 --> Model Class Initialized
INFO - 2016-02-08 08:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:53:02 --> Pagination Class Initialized
INFO - 2016-02-08 08:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:53:02 --> Helper loaded: text_helper
INFO - 2016-02-08 08:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:53:02 --> Final output sent to browser
DEBUG - 2016-02-08 08:53:02 --> Total execution time: 1.1528
INFO - 2016-02-08 08:53:50 --> Config Class Initialized
INFO - 2016-02-08 08:53:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 08:53:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 08:53:50 --> Utf8 Class Initialized
INFO - 2016-02-08 08:53:50 --> URI Class Initialized
INFO - 2016-02-08 08:53:50 --> Router Class Initialized
INFO - 2016-02-08 08:53:50 --> Output Class Initialized
INFO - 2016-02-08 08:53:50 --> Security Class Initialized
DEBUG - 2016-02-08 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 08:53:50 --> Input Class Initialized
INFO - 2016-02-08 08:53:50 --> Language Class Initialized
INFO - 2016-02-08 08:53:50 --> Loader Class Initialized
INFO - 2016-02-08 08:53:50 --> Helper loaded: url_helper
INFO - 2016-02-08 08:53:50 --> Helper loaded: file_helper
INFO - 2016-02-08 08:53:50 --> Helper loaded: date_helper
INFO - 2016-02-08 08:53:50 --> Helper loaded: form_helper
INFO - 2016-02-08 08:53:50 --> Database Driver Class Initialized
INFO - 2016-02-08 08:53:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 08:53:51 --> Controller Class Initialized
INFO - 2016-02-08 08:53:51 --> Model Class Initialized
INFO - 2016-02-08 08:53:51 --> Model Class Initialized
INFO - 2016-02-08 08:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 08:53:51 --> Pagination Class Initialized
INFO - 2016-02-08 08:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 08:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 08:53:51 --> Helper loaded: text_helper
INFO - 2016-02-08 08:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 08:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 08:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 08:53:51 --> Final output sent to browser
DEBUG - 2016-02-08 08:53:51 --> Total execution time: 1.3217
INFO - 2016-02-08 09:28:16 --> Config Class Initialized
INFO - 2016-02-08 09:28:16 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:28:16 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:28:16 --> Utf8 Class Initialized
INFO - 2016-02-08 09:28:16 --> URI Class Initialized
INFO - 2016-02-08 09:28:16 --> Router Class Initialized
INFO - 2016-02-08 09:28:16 --> Output Class Initialized
INFO - 2016-02-08 09:28:16 --> Security Class Initialized
DEBUG - 2016-02-08 09:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:28:16 --> Input Class Initialized
INFO - 2016-02-08 09:28:16 --> Language Class Initialized
INFO - 2016-02-08 09:28:16 --> Loader Class Initialized
INFO - 2016-02-08 09:28:16 --> Helper loaded: url_helper
INFO - 2016-02-08 09:28:16 --> Helper loaded: file_helper
INFO - 2016-02-08 09:28:16 --> Helper loaded: date_helper
INFO - 2016-02-08 09:28:16 --> Helper loaded: form_helper
INFO - 2016-02-08 09:28:16 --> Database Driver Class Initialized
INFO - 2016-02-08 09:28:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:28:17 --> Controller Class Initialized
INFO - 2016-02-08 09:28:17 --> Model Class Initialized
INFO - 2016-02-08 09:28:17 --> Model Class Initialized
INFO - 2016-02-08 09:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:28:17 --> Pagination Class Initialized
INFO - 2016-02-08 09:28:17 --> Form Validation Class Initialized
INFO - 2016-02-08 09:28:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:28:17 --> Model Class Initialized
INFO - 2016-02-08 09:28:17 --> Final output sent to browser
DEBUG - 2016-02-08 09:28:17 --> Total execution time: 1.1678
INFO - 2016-02-08 09:29:34 --> Config Class Initialized
INFO - 2016-02-08 09:29:34 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:29:34 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:29:34 --> Utf8 Class Initialized
INFO - 2016-02-08 09:29:34 --> URI Class Initialized
INFO - 2016-02-08 09:29:34 --> Router Class Initialized
INFO - 2016-02-08 09:29:34 --> Output Class Initialized
INFO - 2016-02-08 09:29:34 --> Security Class Initialized
DEBUG - 2016-02-08 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:29:34 --> Input Class Initialized
INFO - 2016-02-08 09:29:34 --> Language Class Initialized
INFO - 2016-02-08 09:29:34 --> Loader Class Initialized
INFO - 2016-02-08 09:29:34 --> Helper loaded: url_helper
INFO - 2016-02-08 09:29:34 --> Helper loaded: file_helper
INFO - 2016-02-08 09:29:34 --> Helper loaded: date_helper
INFO - 2016-02-08 09:29:34 --> Helper loaded: form_helper
INFO - 2016-02-08 09:29:34 --> Database Driver Class Initialized
INFO - 2016-02-08 09:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:29:35 --> Controller Class Initialized
INFO - 2016-02-08 09:29:35 --> Model Class Initialized
INFO - 2016-02-08 09:29:35 --> Model Class Initialized
INFO - 2016-02-08 09:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:29:35 --> Pagination Class Initialized
INFO - 2016-02-08 09:29:35 --> Form Validation Class Initialized
INFO - 2016-02-08 09:29:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:29:35 --> Model Class Initialized
INFO - 2016-02-08 09:29:35 --> Final output sent to browser
DEBUG - 2016-02-08 09:29:35 --> Total execution time: 1.1989
INFO - 2016-02-08 09:29:39 --> Config Class Initialized
INFO - 2016-02-08 09:29:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:29:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:29:39 --> Utf8 Class Initialized
INFO - 2016-02-08 09:29:39 --> URI Class Initialized
INFO - 2016-02-08 09:29:39 --> Router Class Initialized
INFO - 2016-02-08 09:29:39 --> Output Class Initialized
INFO - 2016-02-08 09:29:39 --> Security Class Initialized
DEBUG - 2016-02-08 09:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:29:39 --> Input Class Initialized
INFO - 2016-02-08 09:29:39 --> Language Class Initialized
INFO - 2016-02-08 09:29:39 --> Loader Class Initialized
INFO - 2016-02-08 09:29:39 --> Helper loaded: url_helper
INFO - 2016-02-08 09:29:39 --> Helper loaded: file_helper
INFO - 2016-02-08 09:29:39 --> Helper loaded: date_helper
INFO - 2016-02-08 09:29:39 --> Helper loaded: form_helper
INFO - 2016-02-08 09:29:39 --> Database Driver Class Initialized
INFO - 2016-02-08 09:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:29:40 --> Controller Class Initialized
INFO - 2016-02-08 09:29:40 --> Model Class Initialized
INFO - 2016-02-08 09:29:40 --> Model Class Initialized
INFO - 2016-02-08 09:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:29:40 --> Pagination Class Initialized
INFO - 2016-02-08 09:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:29:40 --> Helper loaded: text_helper
INFO - 2016-02-08 09:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:29:40 --> Final output sent to browser
DEBUG - 2016-02-08 09:29:40 --> Total execution time: 1.1486
INFO - 2016-02-08 09:32:40 --> Config Class Initialized
INFO - 2016-02-08 09:32:40 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:32:40 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:32:40 --> Utf8 Class Initialized
INFO - 2016-02-08 09:32:40 --> URI Class Initialized
INFO - 2016-02-08 09:32:40 --> Router Class Initialized
INFO - 2016-02-08 09:32:40 --> Output Class Initialized
INFO - 2016-02-08 09:32:40 --> Security Class Initialized
DEBUG - 2016-02-08 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:32:40 --> Input Class Initialized
INFO - 2016-02-08 09:32:40 --> Language Class Initialized
INFO - 2016-02-08 09:32:40 --> Loader Class Initialized
INFO - 2016-02-08 09:32:40 --> Helper loaded: url_helper
INFO - 2016-02-08 09:32:40 --> Helper loaded: file_helper
INFO - 2016-02-08 09:32:40 --> Helper loaded: date_helper
INFO - 2016-02-08 09:32:40 --> Helper loaded: form_helper
INFO - 2016-02-08 09:32:40 --> Database Driver Class Initialized
INFO - 2016-02-08 09:32:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:32:41 --> Controller Class Initialized
INFO - 2016-02-08 09:32:41 --> Model Class Initialized
INFO - 2016-02-08 09:32:41 --> Model Class Initialized
INFO - 2016-02-08 09:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:32:41 --> Pagination Class Initialized
INFO - 2016-02-08 09:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:32:41 --> Helper loaded: text_helper
INFO - 2016-02-08 09:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:32:41 --> Final output sent to browser
DEBUG - 2016-02-08 09:32:41 --> Total execution time: 1.1821
INFO - 2016-02-08 09:32:48 --> Config Class Initialized
INFO - 2016-02-08 09:32:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:32:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:32:48 --> Utf8 Class Initialized
INFO - 2016-02-08 09:32:48 --> URI Class Initialized
INFO - 2016-02-08 09:32:48 --> Router Class Initialized
INFO - 2016-02-08 09:32:48 --> Output Class Initialized
INFO - 2016-02-08 09:32:48 --> Security Class Initialized
DEBUG - 2016-02-08 09:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:32:48 --> Input Class Initialized
INFO - 2016-02-08 09:32:48 --> Language Class Initialized
INFO - 2016-02-08 09:32:48 --> Loader Class Initialized
INFO - 2016-02-08 09:32:48 --> Helper loaded: url_helper
INFO - 2016-02-08 09:32:48 --> Helper loaded: file_helper
INFO - 2016-02-08 09:32:48 --> Helper loaded: date_helper
INFO - 2016-02-08 09:32:48 --> Helper loaded: form_helper
INFO - 2016-02-08 09:32:48 --> Database Driver Class Initialized
INFO - 2016-02-08 09:32:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:32:49 --> Controller Class Initialized
INFO - 2016-02-08 09:32:49 --> Model Class Initialized
INFO - 2016-02-08 09:32:49 --> Model Class Initialized
INFO - 2016-02-08 09:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:32:49 --> Pagination Class Initialized
INFO - 2016-02-08 09:32:49 --> Form Validation Class Initialized
INFO - 2016-02-08 09:32:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:32:49 --> Model Class Initialized
INFO - 2016-02-08 09:32:49 --> Final output sent to browser
DEBUG - 2016-02-08 09:32:49 --> Total execution time: 1.1759
INFO - 2016-02-08 09:32:54 --> Config Class Initialized
INFO - 2016-02-08 09:32:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:32:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:32:54 --> Utf8 Class Initialized
INFO - 2016-02-08 09:32:54 --> URI Class Initialized
INFO - 2016-02-08 09:32:54 --> Router Class Initialized
INFO - 2016-02-08 09:32:54 --> Output Class Initialized
INFO - 2016-02-08 09:32:54 --> Security Class Initialized
DEBUG - 2016-02-08 09:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:32:54 --> Input Class Initialized
INFO - 2016-02-08 09:32:54 --> Language Class Initialized
INFO - 2016-02-08 09:32:54 --> Loader Class Initialized
INFO - 2016-02-08 09:32:54 --> Helper loaded: url_helper
INFO - 2016-02-08 09:32:54 --> Helper loaded: file_helper
INFO - 2016-02-08 09:32:54 --> Helper loaded: date_helper
INFO - 2016-02-08 09:32:54 --> Helper loaded: form_helper
INFO - 2016-02-08 09:32:54 --> Database Driver Class Initialized
INFO - 2016-02-08 09:32:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:32:55 --> Controller Class Initialized
INFO - 2016-02-08 09:32:55 --> Model Class Initialized
INFO - 2016-02-08 09:32:55 --> Model Class Initialized
INFO - 2016-02-08 09:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:32:55 --> Pagination Class Initialized
INFO - 2016-02-08 09:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:32:55 --> Helper loaded: text_helper
INFO - 2016-02-08 09:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:32:55 --> Final output sent to browser
DEBUG - 2016-02-08 09:32:55 --> Total execution time: 1.1503
INFO - 2016-02-08 09:33:23 --> Config Class Initialized
INFO - 2016-02-08 09:33:23 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:33:23 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:33:23 --> Utf8 Class Initialized
INFO - 2016-02-08 09:33:23 --> URI Class Initialized
INFO - 2016-02-08 09:33:23 --> Router Class Initialized
INFO - 2016-02-08 09:33:23 --> Output Class Initialized
INFO - 2016-02-08 09:33:23 --> Security Class Initialized
DEBUG - 2016-02-08 09:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:33:23 --> Input Class Initialized
INFO - 2016-02-08 09:33:23 --> Language Class Initialized
INFO - 2016-02-08 09:33:23 --> Loader Class Initialized
INFO - 2016-02-08 09:33:23 --> Helper loaded: url_helper
INFO - 2016-02-08 09:33:23 --> Helper loaded: file_helper
INFO - 2016-02-08 09:33:23 --> Helper loaded: date_helper
INFO - 2016-02-08 09:33:23 --> Helper loaded: form_helper
INFO - 2016-02-08 09:33:23 --> Database Driver Class Initialized
INFO - 2016-02-08 09:33:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:33:24 --> Controller Class Initialized
INFO - 2016-02-08 09:33:24 --> Model Class Initialized
INFO - 2016-02-08 09:33:24 --> Model Class Initialized
INFO - 2016-02-08 09:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:33:24 --> Pagination Class Initialized
INFO - 2016-02-08 09:33:24 --> Form Validation Class Initialized
INFO - 2016-02-08 09:33:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:33:24 --> Model Class Initialized
INFO - 2016-02-08 09:33:24 --> Final output sent to browser
DEBUG - 2016-02-08 09:33:24 --> Total execution time: 1.2102
INFO - 2016-02-08 09:34:36 --> Config Class Initialized
INFO - 2016-02-08 09:34:36 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:34:36 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:34:36 --> Utf8 Class Initialized
INFO - 2016-02-08 09:34:36 --> URI Class Initialized
INFO - 2016-02-08 09:34:36 --> Router Class Initialized
INFO - 2016-02-08 09:34:36 --> Output Class Initialized
INFO - 2016-02-08 09:34:36 --> Security Class Initialized
DEBUG - 2016-02-08 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:34:36 --> Input Class Initialized
INFO - 2016-02-08 09:34:36 --> Language Class Initialized
INFO - 2016-02-08 09:34:36 --> Loader Class Initialized
INFO - 2016-02-08 09:34:36 --> Helper loaded: url_helper
INFO - 2016-02-08 09:34:36 --> Helper loaded: file_helper
INFO - 2016-02-08 09:34:36 --> Helper loaded: date_helper
INFO - 2016-02-08 09:34:36 --> Helper loaded: form_helper
INFO - 2016-02-08 09:34:36 --> Database Driver Class Initialized
INFO - 2016-02-08 09:34:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:34:37 --> Controller Class Initialized
INFO - 2016-02-08 09:34:37 --> Model Class Initialized
INFO - 2016-02-08 09:34:37 --> Model Class Initialized
INFO - 2016-02-08 09:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:34:37 --> Pagination Class Initialized
INFO - 2016-02-08 09:34:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:34:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:34:37 --> Helper loaded: text_helper
INFO - 2016-02-08 09:34:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:34:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:34:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:34:37 --> Final output sent to browser
DEBUG - 2016-02-08 09:34:37 --> Total execution time: 1.2087
INFO - 2016-02-08 09:34:46 --> Config Class Initialized
INFO - 2016-02-08 09:34:46 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:34:46 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:34:46 --> Utf8 Class Initialized
INFO - 2016-02-08 09:34:46 --> URI Class Initialized
INFO - 2016-02-08 09:34:46 --> Router Class Initialized
INFO - 2016-02-08 09:34:46 --> Output Class Initialized
INFO - 2016-02-08 09:34:46 --> Security Class Initialized
DEBUG - 2016-02-08 09:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:34:46 --> Input Class Initialized
INFO - 2016-02-08 09:34:46 --> Language Class Initialized
INFO - 2016-02-08 09:34:46 --> Loader Class Initialized
INFO - 2016-02-08 09:34:46 --> Helper loaded: url_helper
INFO - 2016-02-08 09:34:46 --> Helper loaded: file_helper
INFO - 2016-02-08 09:34:46 --> Helper loaded: date_helper
INFO - 2016-02-08 09:34:46 --> Helper loaded: form_helper
INFO - 2016-02-08 09:34:46 --> Database Driver Class Initialized
INFO - 2016-02-08 09:34:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:34:47 --> Controller Class Initialized
INFO - 2016-02-08 09:34:47 --> Model Class Initialized
INFO - 2016-02-08 09:34:47 --> Model Class Initialized
INFO - 2016-02-08 09:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:34:47 --> Pagination Class Initialized
INFO - 2016-02-08 09:34:47 --> Form Validation Class Initialized
INFO - 2016-02-08 09:34:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:34:47 --> Model Class Initialized
INFO - 2016-02-08 09:34:47 --> Final output sent to browser
DEBUG - 2016-02-08 09:34:47 --> Total execution time: 1.2472
INFO - 2016-02-08 09:35:19 --> Config Class Initialized
INFO - 2016-02-08 09:35:19 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:35:19 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:35:19 --> Utf8 Class Initialized
INFO - 2016-02-08 09:35:19 --> URI Class Initialized
INFO - 2016-02-08 09:35:19 --> Router Class Initialized
INFO - 2016-02-08 09:35:19 --> Output Class Initialized
INFO - 2016-02-08 09:35:19 --> Security Class Initialized
DEBUG - 2016-02-08 09:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:35:19 --> Input Class Initialized
INFO - 2016-02-08 09:35:19 --> Language Class Initialized
INFO - 2016-02-08 09:35:19 --> Loader Class Initialized
INFO - 2016-02-08 09:35:19 --> Helper loaded: url_helper
INFO - 2016-02-08 09:35:19 --> Helper loaded: file_helper
INFO - 2016-02-08 09:35:19 --> Helper loaded: date_helper
INFO - 2016-02-08 09:35:19 --> Helper loaded: form_helper
INFO - 2016-02-08 09:35:19 --> Database Driver Class Initialized
INFO - 2016-02-08 09:35:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:35:20 --> Controller Class Initialized
INFO - 2016-02-08 09:35:20 --> Model Class Initialized
INFO - 2016-02-08 09:35:20 --> Model Class Initialized
INFO - 2016-02-08 09:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:35:20 --> Pagination Class Initialized
INFO - 2016-02-08 09:35:20 --> Form Validation Class Initialized
INFO - 2016-02-08 09:35:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:35:20 --> Model Class Initialized
INFO - 2016-02-08 09:35:20 --> Final output sent to browser
DEBUG - 2016-02-08 09:35:20 --> Total execution time: 1.2056
INFO - 2016-02-08 09:37:27 --> Config Class Initialized
INFO - 2016-02-08 09:37:27 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:37:27 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:37:27 --> Utf8 Class Initialized
INFO - 2016-02-08 09:37:27 --> URI Class Initialized
INFO - 2016-02-08 09:37:27 --> Router Class Initialized
INFO - 2016-02-08 09:37:27 --> Output Class Initialized
INFO - 2016-02-08 09:37:27 --> Security Class Initialized
DEBUG - 2016-02-08 09:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:37:27 --> Input Class Initialized
INFO - 2016-02-08 09:37:27 --> Language Class Initialized
INFO - 2016-02-08 09:37:27 --> Loader Class Initialized
INFO - 2016-02-08 09:37:27 --> Helper loaded: url_helper
INFO - 2016-02-08 09:37:27 --> Helper loaded: file_helper
INFO - 2016-02-08 09:37:27 --> Helper loaded: date_helper
INFO - 2016-02-08 09:37:27 --> Helper loaded: form_helper
INFO - 2016-02-08 09:37:27 --> Database Driver Class Initialized
INFO - 2016-02-08 09:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:37:28 --> Controller Class Initialized
INFO - 2016-02-08 09:37:28 --> Model Class Initialized
INFO - 2016-02-08 09:37:28 --> Model Class Initialized
INFO - 2016-02-08 09:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:37:28 --> Pagination Class Initialized
INFO - 2016-02-08 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:37:28 --> Helper loaded: text_helper
INFO - 2016-02-08 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:37:28 --> Final output sent to browser
DEBUG - 2016-02-08 09:37:28 --> Total execution time: 1.1689
INFO - 2016-02-08 09:37:43 --> Config Class Initialized
INFO - 2016-02-08 09:37:43 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:37:43 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:37:43 --> Utf8 Class Initialized
INFO - 2016-02-08 09:37:43 --> URI Class Initialized
INFO - 2016-02-08 09:37:43 --> Router Class Initialized
INFO - 2016-02-08 09:37:43 --> Output Class Initialized
INFO - 2016-02-08 09:37:43 --> Security Class Initialized
DEBUG - 2016-02-08 09:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:37:43 --> Input Class Initialized
INFO - 2016-02-08 09:37:43 --> Language Class Initialized
INFO - 2016-02-08 09:37:43 --> Loader Class Initialized
INFO - 2016-02-08 09:37:43 --> Helper loaded: url_helper
INFO - 2016-02-08 09:37:43 --> Helper loaded: file_helper
INFO - 2016-02-08 09:37:43 --> Helper loaded: date_helper
INFO - 2016-02-08 09:37:43 --> Helper loaded: form_helper
INFO - 2016-02-08 09:37:43 --> Database Driver Class Initialized
INFO - 2016-02-08 09:37:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:37:44 --> Controller Class Initialized
INFO - 2016-02-08 09:37:44 --> Model Class Initialized
INFO - 2016-02-08 09:37:44 --> Model Class Initialized
INFO - 2016-02-08 09:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:37:44 --> Pagination Class Initialized
INFO - 2016-02-08 09:37:44 --> Form Validation Class Initialized
INFO - 2016-02-08 09:37:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:37:44 --> Model Class Initialized
INFO - 2016-02-08 09:37:44 --> Final output sent to browser
DEBUG - 2016-02-08 09:37:44 --> Total execution time: 1.1627
INFO - 2016-02-08 09:38:53 --> Config Class Initialized
INFO - 2016-02-08 09:38:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:38:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:38:53 --> Utf8 Class Initialized
INFO - 2016-02-08 09:38:53 --> URI Class Initialized
INFO - 2016-02-08 09:38:53 --> Router Class Initialized
INFO - 2016-02-08 09:38:53 --> Output Class Initialized
INFO - 2016-02-08 09:38:53 --> Security Class Initialized
DEBUG - 2016-02-08 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:38:53 --> Input Class Initialized
INFO - 2016-02-08 09:38:53 --> Language Class Initialized
INFO - 2016-02-08 09:38:53 --> Loader Class Initialized
INFO - 2016-02-08 09:38:53 --> Helper loaded: url_helper
INFO - 2016-02-08 09:38:53 --> Helper loaded: file_helper
INFO - 2016-02-08 09:38:53 --> Helper loaded: date_helper
INFO - 2016-02-08 09:38:53 --> Helper loaded: form_helper
INFO - 2016-02-08 09:38:53 --> Database Driver Class Initialized
INFO - 2016-02-08 09:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:38:54 --> Controller Class Initialized
INFO - 2016-02-08 09:38:54 --> Model Class Initialized
INFO - 2016-02-08 09:38:54 --> Model Class Initialized
INFO - 2016-02-08 09:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:38:54 --> Pagination Class Initialized
INFO - 2016-02-08 09:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:38:54 --> Helper loaded: text_helper
INFO - 2016-02-08 09:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:38:54 --> Final output sent to browser
DEBUG - 2016-02-08 09:38:54 --> Total execution time: 1.1484
INFO - 2016-02-08 09:39:35 --> Config Class Initialized
INFO - 2016-02-08 09:39:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:39:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:39:35 --> Utf8 Class Initialized
INFO - 2016-02-08 09:39:35 --> URI Class Initialized
INFO - 2016-02-08 09:39:35 --> Router Class Initialized
INFO - 2016-02-08 09:39:35 --> Output Class Initialized
INFO - 2016-02-08 09:39:35 --> Security Class Initialized
DEBUG - 2016-02-08 09:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:39:35 --> Input Class Initialized
INFO - 2016-02-08 09:39:35 --> Language Class Initialized
INFO - 2016-02-08 09:39:35 --> Loader Class Initialized
INFO - 2016-02-08 09:39:35 --> Helper loaded: url_helper
INFO - 2016-02-08 09:39:35 --> Helper loaded: file_helper
INFO - 2016-02-08 09:39:35 --> Helper loaded: date_helper
INFO - 2016-02-08 09:39:35 --> Helper loaded: form_helper
INFO - 2016-02-08 09:39:35 --> Database Driver Class Initialized
INFO - 2016-02-08 09:39:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:39:36 --> Controller Class Initialized
INFO - 2016-02-08 09:39:36 --> Model Class Initialized
INFO - 2016-02-08 09:39:36 --> Model Class Initialized
INFO - 2016-02-08 09:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:39:36 --> Pagination Class Initialized
INFO - 2016-02-08 09:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:39:36 --> Helper loaded: text_helper
INFO - 2016-02-08 09:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:39:36 --> Final output sent to browser
DEBUG - 2016-02-08 09:39:36 --> Total execution time: 1.1596
INFO - 2016-02-08 09:39:51 --> Config Class Initialized
INFO - 2016-02-08 09:39:51 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:39:51 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:39:51 --> Utf8 Class Initialized
INFO - 2016-02-08 09:39:51 --> URI Class Initialized
INFO - 2016-02-08 09:39:51 --> Router Class Initialized
INFO - 2016-02-08 09:39:51 --> Output Class Initialized
INFO - 2016-02-08 09:39:51 --> Security Class Initialized
DEBUG - 2016-02-08 09:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:39:51 --> Input Class Initialized
INFO - 2016-02-08 09:39:51 --> Language Class Initialized
INFO - 2016-02-08 09:39:51 --> Loader Class Initialized
INFO - 2016-02-08 09:39:51 --> Helper loaded: url_helper
INFO - 2016-02-08 09:39:51 --> Helper loaded: file_helper
INFO - 2016-02-08 09:39:51 --> Helper loaded: date_helper
INFO - 2016-02-08 09:39:51 --> Helper loaded: form_helper
INFO - 2016-02-08 09:39:51 --> Database Driver Class Initialized
INFO - 2016-02-08 09:39:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:39:52 --> Controller Class Initialized
INFO - 2016-02-08 09:39:52 --> Model Class Initialized
INFO - 2016-02-08 09:39:52 --> Model Class Initialized
INFO - 2016-02-08 09:39:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:39:52 --> Pagination Class Initialized
INFO - 2016-02-08 09:39:52 --> Form Validation Class Initialized
INFO - 2016-02-08 09:39:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:39:52 --> Model Class Initialized
INFO - 2016-02-08 09:39:52 --> Final output sent to browser
DEBUG - 2016-02-08 09:39:52 --> Total execution time: 1.2437
INFO - 2016-02-08 09:49:30 --> Config Class Initialized
INFO - 2016-02-08 09:49:30 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:49:30 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:49:30 --> Utf8 Class Initialized
INFO - 2016-02-08 09:49:30 --> URI Class Initialized
INFO - 2016-02-08 09:49:30 --> Router Class Initialized
INFO - 2016-02-08 09:49:30 --> Output Class Initialized
INFO - 2016-02-08 09:49:30 --> Security Class Initialized
DEBUG - 2016-02-08 09:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:49:30 --> Input Class Initialized
INFO - 2016-02-08 09:49:30 --> Language Class Initialized
INFO - 2016-02-08 09:49:30 --> Loader Class Initialized
INFO - 2016-02-08 09:49:30 --> Helper loaded: url_helper
INFO - 2016-02-08 09:49:30 --> Helper loaded: file_helper
INFO - 2016-02-08 09:49:30 --> Helper loaded: date_helper
INFO - 2016-02-08 09:49:30 --> Helper loaded: form_helper
INFO - 2016-02-08 09:49:30 --> Database Driver Class Initialized
INFO - 2016-02-08 09:49:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:49:31 --> Controller Class Initialized
INFO - 2016-02-08 09:49:31 --> Model Class Initialized
INFO - 2016-02-08 09:49:31 --> Model Class Initialized
INFO - 2016-02-08 09:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:49:31 --> Pagination Class Initialized
INFO - 2016-02-08 09:49:31 --> Form Validation Class Initialized
INFO - 2016-02-08 09:49:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:49:31 --> Model Class Initialized
INFO - 2016-02-08 09:49:31 --> Final output sent to browser
DEBUG - 2016-02-08 09:49:31 --> Total execution time: 1.2132
INFO - 2016-02-08 09:49:40 --> Config Class Initialized
INFO - 2016-02-08 09:49:40 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:49:40 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:49:40 --> Utf8 Class Initialized
INFO - 2016-02-08 09:49:40 --> URI Class Initialized
INFO - 2016-02-08 09:49:40 --> Router Class Initialized
INFO - 2016-02-08 09:49:40 --> Output Class Initialized
INFO - 2016-02-08 09:49:40 --> Security Class Initialized
DEBUG - 2016-02-08 09:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:49:40 --> Input Class Initialized
INFO - 2016-02-08 09:49:40 --> Language Class Initialized
INFO - 2016-02-08 09:49:40 --> Loader Class Initialized
INFO - 2016-02-08 09:49:40 --> Helper loaded: url_helper
INFO - 2016-02-08 09:49:40 --> Helper loaded: file_helper
INFO - 2016-02-08 09:49:40 --> Helper loaded: date_helper
INFO - 2016-02-08 09:49:40 --> Helper loaded: form_helper
INFO - 2016-02-08 09:49:40 --> Database Driver Class Initialized
INFO - 2016-02-08 09:49:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:49:41 --> Controller Class Initialized
INFO - 2016-02-08 09:49:41 --> Model Class Initialized
INFO - 2016-02-08 09:49:41 --> Model Class Initialized
INFO - 2016-02-08 09:49:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:49:41 --> Pagination Class Initialized
INFO - 2016-02-08 09:49:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:49:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:49:41 --> Helper loaded: text_helper
INFO - 2016-02-08 09:49:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:49:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:49:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:49:41 --> Final output sent to browser
DEBUG - 2016-02-08 09:49:41 --> Total execution time: 1.2214
INFO - 2016-02-08 09:52:15 --> Config Class Initialized
INFO - 2016-02-08 09:52:15 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:52:15 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:52:15 --> Utf8 Class Initialized
INFO - 2016-02-08 09:52:15 --> URI Class Initialized
INFO - 2016-02-08 09:52:15 --> Router Class Initialized
INFO - 2016-02-08 09:52:15 --> Output Class Initialized
INFO - 2016-02-08 09:52:15 --> Security Class Initialized
DEBUG - 2016-02-08 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:52:15 --> Input Class Initialized
INFO - 2016-02-08 09:52:15 --> Language Class Initialized
INFO - 2016-02-08 09:52:15 --> Loader Class Initialized
INFO - 2016-02-08 09:52:15 --> Helper loaded: url_helper
INFO - 2016-02-08 09:52:15 --> Helper loaded: file_helper
INFO - 2016-02-08 09:52:15 --> Helper loaded: date_helper
INFO - 2016-02-08 09:52:15 --> Helper loaded: form_helper
INFO - 2016-02-08 09:52:15 --> Database Driver Class Initialized
INFO - 2016-02-08 09:52:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:52:16 --> Controller Class Initialized
INFO - 2016-02-08 09:52:16 --> Model Class Initialized
INFO - 2016-02-08 09:52:16 --> Model Class Initialized
INFO - 2016-02-08 09:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:52:16 --> Pagination Class Initialized
INFO - 2016-02-08 09:52:16 --> Form Validation Class Initialized
INFO - 2016-02-08 09:52:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:52:16 --> Model Class Initialized
INFO - 2016-02-08 09:52:16 --> Final output sent to browser
DEBUG - 2016-02-08 09:52:16 --> Total execution time: 1.2473
INFO - 2016-02-08 09:52:23 --> Config Class Initialized
INFO - 2016-02-08 09:52:23 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:52:23 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:52:23 --> Utf8 Class Initialized
INFO - 2016-02-08 09:52:23 --> URI Class Initialized
INFO - 2016-02-08 09:52:23 --> Router Class Initialized
INFO - 2016-02-08 09:52:23 --> Output Class Initialized
INFO - 2016-02-08 09:52:23 --> Security Class Initialized
DEBUG - 2016-02-08 09:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:52:23 --> Input Class Initialized
INFO - 2016-02-08 09:52:23 --> Language Class Initialized
INFO - 2016-02-08 09:52:23 --> Loader Class Initialized
INFO - 2016-02-08 09:52:23 --> Helper loaded: url_helper
INFO - 2016-02-08 09:52:23 --> Helper loaded: file_helper
INFO - 2016-02-08 09:52:23 --> Helper loaded: date_helper
INFO - 2016-02-08 09:52:23 --> Helper loaded: form_helper
INFO - 2016-02-08 09:52:23 --> Database Driver Class Initialized
INFO - 2016-02-08 09:52:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:52:24 --> Controller Class Initialized
INFO - 2016-02-08 09:52:24 --> Model Class Initialized
INFO - 2016-02-08 09:52:24 --> Model Class Initialized
INFO - 2016-02-08 09:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:52:24 --> Pagination Class Initialized
INFO - 2016-02-08 09:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:52:24 --> Helper loaded: text_helper
INFO - 2016-02-08 09:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:52:24 --> Final output sent to browser
DEBUG - 2016-02-08 09:52:24 --> Total execution time: 1.1615
INFO - 2016-02-08 09:53:30 --> Config Class Initialized
INFO - 2016-02-08 09:53:30 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:53:30 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:53:30 --> Utf8 Class Initialized
INFO - 2016-02-08 09:53:30 --> URI Class Initialized
INFO - 2016-02-08 09:53:30 --> Router Class Initialized
INFO - 2016-02-08 09:53:30 --> Output Class Initialized
INFO - 2016-02-08 09:53:30 --> Security Class Initialized
DEBUG - 2016-02-08 09:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:53:30 --> Input Class Initialized
INFO - 2016-02-08 09:53:30 --> Language Class Initialized
INFO - 2016-02-08 09:53:30 --> Loader Class Initialized
INFO - 2016-02-08 09:53:30 --> Helper loaded: url_helper
INFO - 2016-02-08 09:53:30 --> Helper loaded: file_helper
INFO - 2016-02-08 09:53:30 --> Helper loaded: date_helper
INFO - 2016-02-08 09:53:30 --> Helper loaded: form_helper
INFO - 2016-02-08 09:53:30 --> Database Driver Class Initialized
INFO - 2016-02-08 09:53:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:53:31 --> Controller Class Initialized
INFO - 2016-02-08 09:53:31 --> Model Class Initialized
INFO - 2016-02-08 09:53:31 --> Model Class Initialized
INFO - 2016-02-08 09:53:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:53:31 --> Pagination Class Initialized
INFO - 2016-02-08 09:53:31 --> Form Validation Class Initialized
INFO - 2016-02-08 09:53:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:53:31 --> Model Class Initialized
INFO - 2016-02-08 09:53:31 --> Final output sent to browser
DEBUG - 2016-02-08 09:53:31 --> Total execution time: 1.1718
INFO - 2016-02-08 09:53:59 --> Config Class Initialized
INFO - 2016-02-08 09:53:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:53:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:53:59 --> Utf8 Class Initialized
INFO - 2016-02-08 09:53:59 --> URI Class Initialized
INFO - 2016-02-08 09:53:59 --> Router Class Initialized
INFO - 2016-02-08 09:53:59 --> Output Class Initialized
INFO - 2016-02-08 09:53:59 --> Security Class Initialized
DEBUG - 2016-02-08 09:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:53:59 --> Input Class Initialized
INFO - 2016-02-08 09:53:59 --> Language Class Initialized
INFO - 2016-02-08 09:53:59 --> Loader Class Initialized
INFO - 2016-02-08 09:53:59 --> Helper loaded: url_helper
INFO - 2016-02-08 09:53:59 --> Helper loaded: file_helper
INFO - 2016-02-08 09:53:59 --> Helper loaded: date_helper
INFO - 2016-02-08 09:53:59 --> Helper loaded: form_helper
INFO - 2016-02-08 09:53:59 --> Database Driver Class Initialized
INFO - 2016-02-08 09:54:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:54:00 --> Controller Class Initialized
INFO - 2016-02-08 09:54:00 --> Model Class Initialized
INFO - 2016-02-08 09:54:00 --> Model Class Initialized
INFO - 2016-02-08 09:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:54:00 --> Pagination Class Initialized
INFO - 2016-02-08 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:54:00 --> Helper loaded: text_helper
INFO - 2016-02-08 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:54:00 --> Final output sent to browser
DEBUG - 2016-02-08 09:54:00 --> Total execution time: 1.1896
INFO - 2016-02-08 09:54:06 --> Config Class Initialized
INFO - 2016-02-08 09:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:54:06 --> Utf8 Class Initialized
INFO - 2016-02-08 09:54:06 --> URI Class Initialized
INFO - 2016-02-08 09:54:06 --> Router Class Initialized
INFO - 2016-02-08 09:54:06 --> Output Class Initialized
INFO - 2016-02-08 09:54:06 --> Security Class Initialized
DEBUG - 2016-02-08 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:54:06 --> Input Class Initialized
INFO - 2016-02-08 09:54:06 --> Language Class Initialized
INFO - 2016-02-08 09:54:06 --> Loader Class Initialized
INFO - 2016-02-08 09:54:06 --> Helper loaded: url_helper
INFO - 2016-02-08 09:54:06 --> Helper loaded: file_helper
INFO - 2016-02-08 09:54:06 --> Helper loaded: date_helper
INFO - 2016-02-08 09:54:06 --> Helper loaded: form_helper
INFO - 2016-02-08 09:54:06 --> Database Driver Class Initialized
INFO - 2016-02-08 09:54:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:54:07 --> Controller Class Initialized
INFO - 2016-02-08 09:54:07 --> Model Class Initialized
INFO - 2016-02-08 09:54:07 --> Model Class Initialized
INFO - 2016-02-08 09:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:54:07 --> Pagination Class Initialized
INFO - 2016-02-08 09:54:07 --> Form Validation Class Initialized
INFO - 2016-02-08 09:54:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:54:07 --> Model Class Initialized
INFO - 2016-02-08 09:54:07 --> Final output sent to browser
DEBUG - 2016-02-08 09:54:07 --> Total execution time: 1.1960
INFO - 2016-02-08 09:55:02 --> Config Class Initialized
INFO - 2016-02-08 09:55:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:55:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:55:02 --> Utf8 Class Initialized
INFO - 2016-02-08 09:55:02 --> URI Class Initialized
INFO - 2016-02-08 09:55:02 --> Router Class Initialized
INFO - 2016-02-08 09:55:02 --> Output Class Initialized
INFO - 2016-02-08 09:55:02 --> Security Class Initialized
DEBUG - 2016-02-08 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:55:02 --> Input Class Initialized
INFO - 2016-02-08 09:55:02 --> Language Class Initialized
INFO - 2016-02-08 09:55:02 --> Loader Class Initialized
INFO - 2016-02-08 09:55:02 --> Helper loaded: url_helper
INFO - 2016-02-08 09:55:02 --> Helper loaded: file_helper
INFO - 2016-02-08 09:55:02 --> Helper loaded: date_helper
INFO - 2016-02-08 09:55:02 --> Helper loaded: form_helper
INFO - 2016-02-08 09:55:02 --> Database Driver Class Initialized
INFO - 2016-02-08 09:55:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:55:03 --> Controller Class Initialized
INFO - 2016-02-08 09:55:03 --> Model Class Initialized
INFO - 2016-02-08 09:55:03 --> Model Class Initialized
INFO - 2016-02-08 09:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:55:03 --> Pagination Class Initialized
INFO - 2016-02-08 09:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:55:03 --> Helper loaded: text_helper
INFO - 2016-02-08 09:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:55:03 --> Final output sent to browser
DEBUG - 2016-02-08 09:55:03 --> Total execution time: 1.1724
INFO - 2016-02-08 09:55:09 --> Config Class Initialized
INFO - 2016-02-08 09:55:09 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:55:09 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:55:09 --> Utf8 Class Initialized
INFO - 2016-02-08 09:55:09 --> URI Class Initialized
INFO - 2016-02-08 09:55:09 --> Router Class Initialized
INFO - 2016-02-08 09:55:09 --> Output Class Initialized
INFO - 2016-02-08 09:55:09 --> Security Class Initialized
DEBUG - 2016-02-08 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:55:09 --> Input Class Initialized
INFO - 2016-02-08 09:55:09 --> Language Class Initialized
INFO - 2016-02-08 09:55:09 --> Loader Class Initialized
INFO - 2016-02-08 09:55:09 --> Helper loaded: url_helper
INFO - 2016-02-08 09:55:09 --> Helper loaded: file_helper
INFO - 2016-02-08 09:55:09 --> Helper loaded: date_helper
INFO - 2016-02-08 09:55:09 --> Helper loaded: form_helper
INFO - 2016-02-08 09:55:09 --> Database Driver Class Initialized
INFO - 2016-02-08 09:55:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:55:10 --> Controller Class Initialized
INFO - 2016-02-08 09:55:10 --> Model Class Initialized
INFO - 2016-02-08 09:55:10 --> Model Class Initialized
INFO - 2016-02-08 09:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:55:10 --> Pagination Class Initialized
INFO - 2016-02-08 09:55:10 --> Form Validation Class Initialized
INFO - 2016-02-08 09:55:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:55:10 --> Model Class Initialized
INFO - 2016-02-08 09:55:10 --> Final output sent to browser
DEBUG - 2016-02-08 09:55:10 --> Total execution time: 1.1668
INFO - 2016-02-08 09:56:03 --> Config Class Initialized
INFO - 2016-02-08 09:56:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:56:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:56:03 --> Utf8 Class Initialized
INFO - 2016-02-08 09:56:03 --> URI Class Initialized
INFO - 2016-02-08 09:56:03 --> Router Class Initialized
INFO - 2016-02-08 09:56:03 --> Output Class Initialized
INFO - 2016-02-08 09:56:03 --> Security Class Initialized
DEBUG - 2016-02-08 09:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:56:03 --> Input Class Initialized
INFO - 2016-02-08 09:56:03 --> Language Class Initialized
INFO - 2016-02-08 09:56:03 --> Loader Class Initialized
INFO - 2016-02-08 09:56:03 --> Helper loaded: url_helper
INFO - 2016-02-08 09:56:03 --> Helper loaded: file_helper
INFO - 2016-02-08 09:56:03 --> Helper loaded: date_helper
INFO - 2016-02-08 09:56:03 --> Helper loaded: form_helper
INFO - 2016-02-08 09:56:03 --> Database Driver Class Initialized
INFO - 2016-02-08 09:56:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:56:04 --> Controller Class Initialized
INFO - 2016-02-08 09:56:04 --> Model Class Initialized
INFO - 2016-02-08 09:56:04 --> Model Class Initialized
INFO - 2016-02-08 09:56:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:56:04 --> Pagination Class Initialized
INFO - 2016-02-08 09:56:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:56:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:56:04 --> Helper loaded: text_helper
INFO - 2016-02-08 09:56:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:56:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:56:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:56:04 --> Final output sent to browser
DEBUG - 2016-02-08 09:56:04 --> Total execution time: 1.1565
INFO - 2016-02-08 09:56:12 --> Config Class Initialized
INFO - 2016-02-08 09:56:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:56:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:56:12 --> Utf8 Class Initialized
INFO - 2016-02-08 09:56:12 --> URI Class Initialized
INFO - 2016-02-08 09:56:12 --> Router Class Initialized
INFO - 2016-02-08 09:56:12 --> Output Class Initialized
INFO - 2016-02-08 09:56:12 --> Security Class Initialized
DEBUG - 2016-02-08 09:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:56:12 --> Input Class Initialized
INFO - 2016-02-08 09:56:12 --> Language Class Initialized
INFO - 2016-02-08 09:56:12 --> Loader Class Initialized
INFO - 2016-02-08 09:56:12 --> Helper loaded: url_helper
INFO - 2016-02-08 09:56:12 --> Helper loaded: file_helper
INFO - 2016-02-08 09:56:12 --> Helper loaded: date_helper
INFO - 2016-02-08 09:56:12 --> Helper loaded: form_helper
INFO - 2016-02-08 09:56:12 --> Database Driver Class Initialized
INFO - 2016-02-08 09:56:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:56:13 --> Controller Class Initialized
INFO - 2016-02-08 09:56:13 --> Model Class Initialized
INFO - 2016-02-08 09:56:13 --> Model Class Initialized
INFO - 2016-02-08 09:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:56:13 --> Pagination Class Initialized
INFO - 2016-02-08 09:56:13 --> Form Validation Class Initialized
INFO - 2016-02-08 09:56:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:56:13 --> Model Class Initialized
INFO - 2016-02-08 09:56:13 --> Final output sent to browser
DEBUG - 2016-02-08 09:56:13 --> Total execution time: 1.1918
INFO - 2016-02-08 09:57:00 --> Config Class Initialized
INFO - 2016-02-08 09:57:00 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:57:00 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:57:00 --> Utf8 Class Initialized
INFO - 2016-02-08 09:57:00 --> URI Class Initialized
INFO - 2016-02-08 09:57:00 --> Router Class Initialized
INFO - 2016-02-08 09:57:00 --> Output Class Initialized
INFO - 2016-02-08 09:57:00 --> Security Class Initialized
DEBUG - 2016-02-08 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:57:00 --> Input Class Initialized
INFO - 2016-02-08 09:57:00 --> Language Class Initialized
INFO - 2016-02-08 09:57:00 --> Loader Class Initialized
INFO - 2016-02-08 09:57:00 --> Helper loaded: url_helper
INFO - 2016-02-08 09:57:00 --> Helper loaded: file_helper
INFO - 2016-02-08 09:57:00 --> Helper loaded: date_helper
INFO - 2016-02-08 09:57:00 --> Helper loaded: form_helper
INFO - 2016-02-08 09:57:00 --> Database Driver Class Initialized
INFO - 2016-02-08 09:57:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:57:01 --> Controller Class Initialized
INFO - 2016-02-08 09:57:01 --> Model Class Initialized
INFO - 2016-02-08 09:57:01 --> Model Class Initialized
INFO - 2016-02-08 09:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:57:01 --> Pagination Class Initialized
INFO - 2016-02-08 09:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 09:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 09:57:01 --> Helper loaded: text_helper
INFO - 2016-02-08 09:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 09:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 09:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 09:57:01 --> Final output sent to browser
DEBUG - 2016-02-08 09:57:01 --> Total execution time: 1.1801
INFO - 2016-02-08 09:57:07 --> Config Class Initialized
INFO - 2016-02-08 09:57:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 09:57:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 09:57:07 --> Utf8 Class Initialized
INFO - 2016-02-08 09:57:07 --> URI Class Initialized
INFO - 2016-02-08 09:57:07 --> Router Class Initialized
INFO - 2016-02-08 09:57:07 --> Output Class Initialized
INFO - 2016-02-08 09:57:07 --> Security Class Initialized
DEBUG - 2016-02-08 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 09:57:07 --> Input Class Initialized
INFO - 2016-02-08 09:57:07 --> Language Class Initialized
INFO - 2016-02-08 09:57:07 --> Loader Class Initialized
INFO - 2016-02-08 09:57:07 --> Helper loaded: url_helper
INFO - 2016-02-08 09:57:07 --> Helper loaded: file_helper
INFO - 2016-02-08 09:57:07 --> Helper loaded: date_helper
INFO - 2016-02-08 09:57:07 --> Helper loaded: form_helper
INFO - 2016-02-08 09:57:07 --> Database Driver Class Initialized
INFO - 2016-02-08 09:57:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 09:57:08 --> Controller Class Initialized
INFO - 2016-02-08 09:57:08 --> Model Class Initialized
INFO - 2016-02-08 09:57:08 --> Model Class Initialized
INFO - 2016-02-08 09:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 09:57:08 --> Pagination Class Initialized
INFO - 2016-02-08 09:57:08 --> Form Validation Class Initialized
INFO - 2016-02-08 09:57:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 09:57:08 --> Model Class Initialized
INFO - 2016-02-08 09:57:08 --> Final output sent to browser
DEBUG - 2016-02-08 09:57:08 --> Total execution time: 1.1657
INFO - 2016-02-08 10:00:33 --> Config Class Initialized
INFO - 2016-02-08 10:00:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:00:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:00:33 --> Utf8 Class Initialized
INFO - 2016-02-08 10:00:33 --> URI Class Initialized
INFO - 2016-02-08 10:00:33 --> Router Class Initialized
INFO - 2016-02-08 10:00:33 --> Output Class Initialized
INFO - 2016-02-08 10:00:33 --> Security Class Initialized
DEBUG - 2016-02-08 10:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:00:33 --> Input Class Initialized
INFO - 2016-02-08 10:00:33 --> Language Class Initialized
INFO - 2016-02-08 10:00:33 --> Loader Class Initialized
INFO - 2016-02-08 10:00:33 --> Helper loaded: url_helper
INFO - 2016-02-08 10:00:33 --> Helper loaded: file_helper
INFO - 2016-02-08 10:00:33 --> Helper loaded: date_helper
INFO - 2016-02-08 10:00:33 --> Helper loaded: form_helper
INFO - 2016-02-08 10:00:33 --> Database Driver Class Initialized
INFO - 2016-02-08 10:00:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:00:34 --> Controller Class Initialized
INFO - 2016-02-08 10:00:34 --> Model Class Initialized
INFO - 2016-02-08 10:00:34 --> Model Class Initialized
INFO - 2016-02-08 10:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:00:34 --> Pagination Class Initialized
INFO - 2016-02-08 10:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:00:34 --> Helper loaded: text_helper
INFO - 2016-02-08 10:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:00:34 --> Final output sent to browser
DEBUG - 2016-02-08 10:00:34 --> Total execution time: 1.2409
INFO - 2016-02-08 10:00:42 --> Config Class Initialized
INFO - 2016-02-08 10:00:42 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:00:42 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:00:42 --> Utf8 Class Initialized
INFO - 2016-02-08 10:00:42 --> URI Class Initialized
INFO - 2016-02-08 10:00:42 --> Router Class Initialized
INFO - 2016-02-08 10:00:42 --> Output Class Initialized
INFO - 2016-02-08 10:00:42 --> Security Class Initialized
DEBUG - 2016-02-08 10:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:00:42 --> Input Class Initialized
INFO - 2016-02-08 10:00:42 --> Language Class Initialized
INFO - 2016-02-08 10:00:42 --> Loader Class Initialized
INFO - 2016-02-08 10:00:42 --> Helper loaded: url_helper
INFO - 2016-02-08 10:00:42 --> Helper loaded: file_helper
INFO - 2016-02-08 10:00:42 --> Helper loaded: date_helper
INFO - 2016-02-08 10:00:42 --> Helper loaded: form_helper
INFO - 2016-02-08 10:00:42 --> Database Driver Class Initialized
INFO - 2016-02-08 10:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:00:43 --> Controller Class Initialized
INFO - 2016-02-08 10:00:43 --> Model Class Initialized
INFO - 2016-02-08 10:00:43 --> Model Class Initialized
INFO - 2016-02-08 10:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:00:43 --> Pagination Class Initialized
INFO - 2016-02-08 10:00:43 --> Form Validation Class Initialized
INFO - 2016-02-08 10:00:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:00:43 --> Model Class Initialized
INFO - 2016-02-08 10:00:43 --> Final output sent to browser
DEBUG - 2016-02-08 10:00:43 --> Total execution time: 1.1767
INFO - 2016-02-08 10:01:28 --> Config Class Initialized
INFO - 2016-02-08 10:01:28 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:01:28 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:01:28 --> Utf8 Class Initialized
INFO - 2016-02-08 10:01:28 --> URI Class Initialized
INFO - 2016-02-08 10:01:28 --> Router Class Initialized
INFO - 2016-02-08 10:01:28 --> Output Class Initialized
INFO - 2016-02-08 10:01:28 --> Security Class Initialized
DEBUG - 2016-02-08 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:01:28 --> Input Class Initialized
INFO - 2016-02-08 10:01:28 --> Language Class Initialized
INFO - 2016-02-08 10:01:28 --> Loader Class Initialized
INFO - 2016-02-08 10:01:28 --> Helper loaded: url_helper
INFO - 2016-02-08 10:01:28 --> Helper loaded: file_helper
INFO - 2016-02-08 10:01:28 --> Helper loaded: date_helper
INFO - 2016-02-08 10:01:28 --> Helper loaded: form_helper
INFO - 2016-02-08 10:01:28 --> Database Driver Class Initialized
INFO - 2016-02-08 10:01:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:01:29 --> Controller Class Initialized
INFO - 2016-02-08 10:01:29 --> Model Class Initialized
INFO - 2016-02-08 10:01:29 --> Model Class Initialized
INFO - 2016-02-08 10:01:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:01:29 --> Pagination Class Initialized
INFO - 2016-02-08 10:01:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:01:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:01:29 --> Helper loaded: text_helper
INFO - 2016-02-08 10:01:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:01:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:01:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:01:29 --> Final output sent to browser
DEBUG - 2016-02-08 10:01:29 --> Total execution time: 1.3428
INFO - 2016-02-08 10:01:35 --> Config Class Initialized
INFO - 2016-02-08 10:01:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:01:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:01:35 --> Utf8 Class Initialized
INFO - 2016-02-08 10:01:35 --> URI Class Initialized
INFO - 2016-02-08 10:01:35 --> Router Class Initialized
INFO - 2016-02-08 10:01:35 --> Output Class Initialized
INFO - 2016-02-08 10:01:35 --> Security Class Initialized
DEBUG - 2016-02-08 10:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:01:35 --> Input Class Initialized
INFO - 2016-02-08 10:01:35 --> Language Class Initialized
INFO - 2016-02-08 10:01:35 --> Loader Class Initialized
INFO - 2016-02-08 10:01:35 --> Helper loaded: url_helper
INFO - 2016-02-08 10:01:35 --> Helper loaded: file_helper
INFO - 2016-02-08 10:01:35 --> Helper loaded: date_helper
INFO - 2016-02-08 10:01:35 --> Helper loaded: form_helper
INFO - 2016-02-08 10:01:35 --> Database Driver Class Initialized
INFO - 2016-02-08 10:01:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:01:36 --> Controller Class Initialized
INFO - 2016-02-08 10:01:36 --> Model Class Initialized
INFO - 2016-02-08 10:01:36 --> Model Class Initialized
INFO - 2016-02-08 10:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:01:36 --> Pagination Class Initialized
INFO - 2016-02-08 10:01:36 --> Form Validation Class Initialized
INFO - 2016-02-08 10:01:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:01:36 --> Model Class Initialized
INFO - 2016-02-08 10:01:36 --> Final output sent to browser
DEBUG - 2016-02-08 10:01:36 --> Total execution time: 1.2570
INFO - 2016-02-08 10:02:09 --> Config Class Initialized
INFO - 2016-02-08 10:02:09 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:02:09 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:02:09 --> Utf8 Class Initialized
INFO - 2016-02-08 10:02:09 --> URI Class Initialized
INFO - 2016-02-08 10:02:09 --> Router Class Initialized
INFO - 2016-02-08 10:02:09 --> Output Class Initialized
INFO - 2016-02-08 10:02:09 --> Security Class Initialized
DEBUG - 2016-02-08 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:02:09 --> Input Class Initialized
INFO - 2016-02-08 10:02:09 --> Language Class Initialized
INFO - 2016-02-08 10:02:09 --> Loader Class Initialized
INFO - 2016-02-08 10:02:09 --> Helper loaded: url_helper
INFO - 2016-02-08 10:02:09 --> Helper loaded: file_helper
INFO - 2016-02-08 10:02:09 --> Helper loaded: date_helper
INFO - 2016-02-08 10:02:09 --> Helper loaded: form_helper
INFO - 2016-02-08 10:02:09 --> Database Driver Class Initialized
INFO - 2016-02-08 10:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:02:10 --> Controller Class Initialized
INFO - 2016-02-08 10:02:10 --> Model Class Initialized
INFO - 2016-02-08 10:02:10 --> Model Class Initialized
INFO - 2016-02-08 10:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:02:10 --> Pagination Class Initialized
INFO - 2016-02-08 10:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:02:10 --> Helper loaded: text_helper
INFO - 2016-02-08 10:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:02:10 --> Final output sent to browser
DEBUG - 2016-02-08 10:02:10 --> Total execution time: 1.1571
INFO - 2016-02-08 10:02:18 --> Config Class Initialized
INFO - 2016-02-08 10:02:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:02:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:02:18 --> Utf8 Class Initialized
INFO - 2016-02-08 10:02:18 --> URI Class Initialized
INFO - 2016-02-08 10:02:18 --> Router Class Initialized
INFO - 2016-02-08 10:02:18 --> Output Class Initialized
INFO - 2016-02-08 10:02:18 --> Security Class Initialized
DEBUG - 2016-02-08 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:02:18 --> Input Class Initialized
INFO - 2016-02-08 10:02:18 --> Language Class Initialized
INFO - 2016-02-08 10:02:18 --> Loader Class Initialized
INFO - 2016-02-08 10:02:18 --> Helper loaded: url_helper
INFO - 2016-02-08 10:02:18 --> Helper loaded: file_helper
INFO - 2016-02-08 10:02:18 --> Helper loaded: date_helper
INFO - 2016-02-08 10:02:18 --> Helper loaded: form_helper
INFO - 2016-02-08 10:02:18 --> Database Driver Class Initialized
INFO - 2016-02-08 10:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:02:19 --> Controller Class Initialized
INFO - 2016-02-08 10:02:19 --> Model Class Initialized
INFO - 2016-02-08 10:02:19 --> Model Class Initialized
INFO - 2016-02-08 10:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:02:19 --> Pagination Class Initialized
INFO - 2016-02-08 10:02:19 --> Form Validation Class Initialized
INFO - 2016-02-08 10:02:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:02:19 --> Model Class Initialized
INFO - 2016-02-08 10:02:19 --> Final output sent to browser
DEBUG - 2016-02-08 10:02:19 --> Total execution time: 1.2191
INFO - 2016-02-08 10:02:41 --> Config Class Initialized
INFO - 2016-02-08 10:02:41 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:02:41 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:02:41 --> Utf8 Class Initialized
INFO - 2016-02-08 10:02:41 --> URI Class Initialized
INFO - 2016-02-08 10:02:41 --> Router Class Initialized
INFO - 2016-02-08 10:02:41 --> Output Class Initialized
INFO - 2016-02-08 10:02:41 --> Security Class Initialized
DEBUG - 2016-02-08 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:02:41 --> Input Class Initialized
INFO - 2016-02-08 10:02:41 --> Language Class Initialized
INFO - 2016-02-08 10:02:41 --> Loader Class Initialized
INFO - 2016-02-08 10:02:41 --> Helper loaded: url_helper
INFO - 2016-02-08 10:02:41 --> Helper loaded: file_helper
INFO - 2016-02-08 10:02:41 --> Helper loaded: date_helper
INFO - 2016-02-08 10:02:41 --> Helper loaded: form_helper
INFO - 2016-02-08 10:02:41 --> Database Driver Class Initialized
INFO - 2016-02-08 10:02:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:02:42 --> Controller Class Initialized
INFO - 2016-02-08 10:02:42 --> Model Class Initialized
INFO - 2016-02-08 10:02:42 --> Model Class Initialized
INFO - 2016-02-08 10:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:02:42 --> Pagination Class Initialized
INFO - 2016-02-08 10:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:02:42 --> Helper loaded: text_helper
INFO - 2016-02-08 10:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:02:42 --> Final output sent to browser
DEBUG - 2016-02-08 10:02:42 --> Total execution time: 1.1707
INFO - 2016-02-08 10:03:03 --> Config Class Initialized
INFO - 2016-02-08 10:03:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:03:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:03:03 --> Utf8 Class Initialized
INFO - 2016-02-08 10:03:03 --> URI Class Initialized
INFO - 2016-02-08 10:03:03 --> Router Class Initialized
INFO - 2016-02-08 10:03:03 --> Output Class Initialized
INFO - 2016-02-08 10:03:03 --> Security Class Initialized
DEBUG - 2016-02-08 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:03:03 --> Input Class Initialized
INFO - 2016-02-08 10:03:03 --> Language Class Initialized
INFO - 2016-02-08 10:03:03 --> Loader Class Initialized
INFO - 2016-02-08 10:03:03 --> Helper loaded: url_helper
INFO - 2016-02-08 10:03:03 --> Helper loaded: file_helper
INFO - 2016-02-08 10:03:03 --> Helper loaded: date_helper
INFO - 2016-02-08 10:03:03 --> Helper loaded: form_helper
INFO - 2016-02-08 10:03:03 --> Database Driver Class Initialized
INFO - 2016-02-08 10:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:03:04 --> Controller Class Initialized
INFO - 2016-02-08 10:03:04 --> Model Class Initialized
INFO - 2016-02-08 10:03:04 --> Model Class Initialized
INFO - 2016-02-08 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:03:04 --> Pagination Class Initialized
INFO - 2016-02-08 10:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:03:04 --> Helper loaded: text_helper
INFO - 2016-02-08 10:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:03:04 --> Final output sent to browser
DEBUG - 2016-02-08 10:03:04 --> Total execution time: 1.1857
INFO - 2016-02-08 10:03:17 --> Config Class Initialized
INFO - 2016-02-08 10:03:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:03:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:03:17 --> Utf8 Class Initialized
INFO - 2016-02-08 10:03:17 --> URI Class Initialized
INFO - 2016-02-08 10:03:17 --> Router Class Initialized
INFO - 2016-02-08 10:03:17 --> Output Class Initialized
INFO - 2016-02-08 10:03:17 --> Security Class Initialized
DEBUG - 2016-02-08 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:03:17 --> Input Class Initialized
INFO - 2016-02-08 10:03:17 --> Language Class Initialized
INFO - 2016-02-08 10:03:17 --> Loader Class Initialized
INFO - 2016-02-08 10:03:17 --> Helper loaded: url_helper
INFO - 2016-02-08 10:03:17 --> Helper loaded: file_helper
INFO - 2016-02-08 10:03:17 --> Helper loaded: date_helper
INFO - 2016-02-08 10:03:17 --> Helper loaded: form_helper
INFO - 2016-02-08 10:03:17 --> Database Driver Class Initialized
INFO - 2016-02-08 10:03:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:03:18 --> Controller Class Initialized
INFO - 2016-02-08 10:03:18 --> Model Class Initialized
INFO - 2016-02-08 10:03:18 --> Model Class Initialized
INFO - 2016-02-08 10:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:03:18 --> Pagination Class Initialized
INFO - 2016-02-08 10:03:18 --> Form Validation Class Initialized
INFO - 2016-02-08 10:03:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:03:18 --> Model Class Initialized
INFO - 2016-02-08 10:03:18 --> Final output sent to browser
DEBUG - 2016-02-08 10:03:18 --> Total execution time: 1.1771
INFO - 2016-02-08 10:03:49 --> Config Class Initialized
INFO - 2016-02-08 10:03:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:03:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:03:49 --> Utf8 Class Initialized
INFO - 2016-02-08 10:03:49 --> URI Class Initialized
INFO - 2016-02-08 10:03:49 --> Router Class Initialized
INFO - 2016-02-08 10:03:49 --> Output Class Initialized
INFO - 2016-02-08 10:03:49 --> Security Class Initialized
DEBUG - 2016-02-08 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:03:49 --> Input Class Initialized
INFO - 2016-02-08 10:03:49 --> Language Class Initialized
INFO - 2016-02-08 10:03:49 --> Loader Class Initialized
INFO - 2016-02-08 10:03:49 --> Helper loaded: url_helper
INFO - 2016-02-08 10:03:49 --> Helper loaded: file_helper
INFO - 2016-02-08 10:03:49 --> Helper loaded: date_helper
INFO - 2016-02-08 10:03:49 --> Helper loaded: form_helper
INFO - 2016-02-08 10:03:49 --> Database Driver Class Initialized
INFO - 2016-02-08 10:03:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:03:50 --> Controller Class Initialized
INFO - 2016-02-08 10:03:50 --> Model Class Initialized
INFO - 2016-02-08 10:03:50 --> Model Class Initialized
INFO - 2016-02-08 10:03:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:03:50 --> Pagination Class Initialized
INFO - 2016-02-08 10:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:03:50 --> Helper loaded: text_helper
INFO - 2016-02-08 10:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:03:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:03:50 --> Final output sent to browser
DEBUG - 2016-02-08 10:03:50 --> Total execution time: 1.1898
INFO - 2016-02-08 10:03:56 --> Config Class Initialized
INFO - 2016-02-08 10:03:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:03:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:03:56 --> Utf8 Class Initialized
INFO - 2016-02-08 10:03:56 --> URI Class Initialized
INFO - 2016-02-08 10:03:56 --> Router Class Initialized
INFO - 2016-02-08 10:03:56 --> Output Class Initialized
INFO - 2016-02-08 10:03:56 --> Security Class Initialized
DEBUG - 2016-02-08 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:03:56 --> Input Class Initialized
INFO - 2016-02-08 10:03:56 --> Language Class Initialized
INFO - 2016-02-08 10:03:56 --> Loader Class Initialized
INFO - 2016-02-08 10:03:56 --> Helper loaded: url_helper
INFO - 2016-02-08 10:03:56 --> Helper loaded: file_helper
INFO - 2016-02-08 10:03:56 --> Helper loaded: date_helper
INFO - 2016-02-08 10:03:56 --> Helper loaded: form_helper
INFO - 2016-02-08 10:03:56 --> Database Driver Class Initialized
INFO - 2016-02-08 10:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:03:57 --> Controller Class Initialized
INFO - 2016-02-08 10:03:57 --> Model Class Initialized
INFO - 2016-02-08 10:03:57 --> Model Class Initialized
INFO - 2016-02-08 10:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:03:57 --> Pagination Class Initialized
INFO - 2016-02-08 10:03:57 --> Form Validation Class Initialized
INFO - 2016-02-08 10:03:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:03:57 --> Model Class Initialized
INFO - 2016-02-08 10:03:57 --> Final output sent to browser
DEBUG - 2016-02-08 10:03:57 --> Total execution time: 1.1904
INFO - 2016-02-08 10:05:44 --> Config Class Initialized
INFO - 2016-02-08 10:05:44 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:05:44 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:05:44 --> Utf8 Class Initialized
INFO - 2016-02-08 10:05:44 --> URI Class Initialized
INFO - 2016-02-08 10:05:44 --> Router Class Initialized
INFO - 2016-02-08 10:05:44 --> Output Class Initialized
INFO - 2016-02-08 10:05:44 --> Security Class Initialized
DEBUG - 2016-02-08 10:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:05:44 --> Input Class Initialized
INFO - 2016-02-08 10:05:44 --> Language Class Initialized
INFO - 2016-02-08 10:05:44 --> Loader Class Initialized
INFO - 2016-02-08 10:05:44 --> Helper loaded: url_helper
INFO - 2016-02-08 10:05:44 --> Helper loaded: file_helper
INFO - 2016-02-08 10:05:44 --> Helper loaded: date_helper
INFO - 2016-02-08 10:05:44 --> Helper loaded: form_helper
INFO - 2016-02-08 10:05:44 --> Database Driver Class Initialized
INFO - 2016-02-08 10:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:05:45 --> Controller Class Initialized
INFO - 2016-02-08 10:05:45 --> Model Class Initialized
INFO - 2016-02-08 10:05:45 --> Model Class Initialized
INFO - 2016-02-08 10:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:05:45 --> Pagination Class Initialized
INFO - 2016-02-08 10:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:05:45 --> Helper loaded: text_helper
INFO - 2016-02-08 10:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:05:45 --> Final output sent to browser
DEBUG - 2016-02-08 10:05:45 --> Total execution time: 1.1571
INFO - 2016-02-08 10:05:51 --> Config Class Initialized
INFO - 2016-02-08 10:05:51 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:05:51 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:05:51 --> Utf8 Class Initialized
INFO - 2016-02-08 10:05:51 --> URI Class Initialized
INFO - 2016-02-08 10:05:51 --> Router Class Initialized
INFO - 2016-02-08 10:05:51 --> Output Class Initialized
INFO - 2016-02-08 10:05:51 --> Security Class Initialized
DEBUG - 2016-02-08 10:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:05:51 --> Input Class Initialized
INFO - 2016-02-08 10:05:51 --> Language Class Initialized
INFO - 2016-02-08 10:05:51 --> Loader Class Initialized
INFO - 2016-02-08 10:05:51 --> Helper loaded: url_helper
INFO - 2016-02-08 10:05:51 --> Helper loaded: file_helper
INFO - 2016-02-08 10:05:51 --> Helper loaded: date_helper
INFO - 2016-02-08 10:05:51 --> Helper loaded: form_helper
INFO - 2016-02-08 10:05:51 --> Database Driver Class Initialized
INFO - 2016-02-08 10:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:05:52 --> Controller Class Initialized
INFO - 2016-02-08 10:05:52 --> Model Class Initialized
INFO - 2016-02-08 10:05:52 --> Model Class Initialized
INFO - 2016-02-08 10:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:05:52 --> Pagination Class Initialized
INFO - 2016-02-08 10:05:52 --> Form Validation Class Initialized
INFO - 2016-02-08 10:05:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:05:52 --> Model Class Initialized
INFO - 2016-02-08 10:05:52 --> Final output sent to browser
DEBUG - 2016-02-08 10:05:52 --> Total execution time: 1.1781
INFO - 2016-02-08 10:06:27 --> Config Class Initialized
INFO - 2016-02-08 10:06:27 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:06:27 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:06:27 --> Utf8 Class Initialized
INFO - 2016-02-08 10:06:27 --> URI Class Initialized
INFO - 2016-02-08 10:06:27 --> Router Class Initialized
INFO - 2016-02-08 10:06:27 --> Output Class Initialized
INFO - 2016-02-08 10:06:27 --> Security Class Initialized
DEBUG - 2016-02-08 10:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:06:27 --> Input Class Initialized
INFO - 2016-02-08 10:06:27 --> Language Class Initialized
INFO - 2016-02-08 10:06:27 --> Loader Class Initialized
INFO - 2016-02-08 10:06:27 --> Helper loaded: url_helper
INFO - 2016-02-08 10:06:27 --> Helper loaded: file_helper
INFO - 2016-02-08 10:06:27 --> Helper loaded: date_helper
INFO - 2016-02-08 10:06:27 --> Helper loaded: form_helper
INFO - 2016-02-08 10:06:27 --> Database Driver Class Initialized
INFO - 2016-02-08 10:06:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:06:28 --> Controller Class Initialized
INFO - 2016-02-08 10:06:28 --> Model Class Initialized
INFO - 2016-02-08 10:06:28 --> Model Class Initialized
INFO - 2016-02-08 10:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:06:28 --> Pagination Class Initialized
INFO - 2016-02-08 10:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:06:28 --> Helper loaded: text_helper
INFO - 2016-02-08 10:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:06:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:06:28 --> Final output sent to browser
DEBUG - 2016-02-08 10:06:28 --> Total execution time: 1.2006
INFO - 2016-02-08 10:06:33 --> Config Class Initialized
INFO - 2016-02-08 10:06:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:06:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:06:33 --> Utf8 Class Initialized
INFO - 2016-02-08 10:06:33 --> URI Class Initialized
INFO - 2016-02-08 10:06:33 --> Router Class Initialized
INFO - 2016-02-08 10:06:33 --> Output Class Initialized
INFO - 2016-02-08 10:06:33 --> Security Class Initialized
DEBUG - 2016-02-08 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:06:33 --> Input Class Initialized
INFO - 2016-02-08 10:06:33 --> Language Class Initialized
INFO - 2016-02-08 10:06:33 --> Loader Class Initialized
INFO - 2016-02-08 10:06:33 --> Helper loaded: url_helper
INFO - 2016-02-08 10:06:33 --> Helper loaded: file_helper
INFO - 2016-02-08 10:06:33 --> Helper loaded: date_helper
INFO - 2016-02-08 10:06:33 --> Helper loaded: form_helper
INFO - 2016-02-08 10:06:33 --> Database Driver Class Initialized
INFO - 2016-02-08 10:06:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:06:34 --> Controller Class Initialized
INFO - 2016-02-08 10:06:34 --> Model Class Initialized
INFO - 2016-02-08 10:06:34 --> Model Class Initialized
INFO - 2016-02-08 10:06:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:06:34 --> Pagination Class Initialized
INFO - 2016-02-08 10:06:34 --> Form Validation Class Initialized
INFO - 2016-02-08 10:06:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:06:34 --> Model Class Initialized
INFO - 2016-02-08 10:06:34 --> Final output sent to browser
DEBUG - 2016-02-08 10:06:34 --> Total execution time: 1.2072
INFO - 2016-02-08 10:07:22 --> Config Class Initialized
INFO - 2016-02-08 10:07:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:07:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:07:22 --> Utf8 Class Initialized
INFO - 2016-02-08 10:07:22 --> URI Class Initialized
INFO - 2016-02-08 10:07:22 --> Router Class Initialized
INFO - 2016-02-08 10:07:22 --> Output Class Initialized
INFO - 2016-02-08 10:07:22 --> Security Class Initialized
DEBUG - 2016-02-08 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:07:22 --> Input Class Initialized
INFO - 2016-02-08 10:07:22 --> Language Class Initialized
INFO - 2016-02-08 10:07:22 --> Loader Class Initialized
INFO - 2016-02-08 10:07:22 --> Helper loaded: url_helper
INFO - 2016-02-08 10:07:22 --> Helper loaded: file_helper
INFO - 2016-02-08 10:07:22 --> Helper loaded: date_helper
INFO - 2016-02-08 10:07:22 --> Helper loaded: form_helper
INFO - 2016-02-08 10:07:22 --> Database Driver Class Initialized
INFO - 2016-02-08 10:07:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:07:23 --> Controller Class Initialized
INFO - 2016-02-08 10:07:23 --> Model Class Initialized
INFO - 2016-02-08 10:07:23 --> Model Class Initialized
INFO - 2016-02-08 10:07:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:07:23 --> Pagination Class Initialized
INFO - 2016-02-08 10:07:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:07:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:07:23 --> Helper loaded: text_helper
INFO - 2016-02-08 10:07:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:07:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:07:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:07:23 --> Final output sent to browser
DEBUG - 2016-02-08 10:07:23 --> Total execution time: 1.1558
INFO - 2016-02-08 10:07:29 --> Config Class Initialized
INFO - 2016-02-08 10:07:29 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:07:29 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:07:29 --> Utf8 Class Initialized
INFO - 2016-02-08 10:07:29 --> URI Class Initialized
INFO - 2016-02-08 10:07:29 --> Router Class Initialized
INFO - 2016-02-08 10:07:29 --> Output Class Initialized
INFO - 2016-02-08 10:07:29 --> Security Class Initialized
DEBUG - 2016-02-08 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:07:29 --> Input Class Initialized
INFO - 2016-02-08 10:07:29 --> Language Class Initialized
INFO - 2016-02-08 10:07:29 --> Loader Class Initialized
INFO - 2016-02-08 10:07:29 --> Helper loaded: url_helper
INFO - 2016-02-08 10:07:29 --> Helper loaded: file_helper
INFO - 2016-02-08 10:07:29 --> Helper loaded: date_helper
INFO - 2016-02-08 10:07:29 --> Helper loaded: form_helper
INFO - 2016-02-08 10:07:29 --> Database Driver Class Initialized
INFO - 2016-02-08 10:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:07:30 --> Controller Class Initialized
INFO - 2016-02-08 10:07:30 --> Model Class Initialized
INFO - 2016-02-08 10:07:30 --> Model Class Initialized
INFO - 2016-02-08 10:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:07:30 --> Pagination Class Initialized
INFO - 2016-02-08 10:07:30 --> Form Validation Class Initialized
INFO - 2016-02-08 10:07:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:07:30 --> Model Class Initialized
INFO - 2016-02-08 10:07:30 --> Final output sent to browser
DEBUG - 2016-02-08 10:07:30 --> Total execution time: 1.1935
INFO - 2016-02-08 10:10:11 --> Config Class Initialized
INFO - 2016-02-08 10:10:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:10:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:10:11 --> Utf8 Class Initialized
INFO - 2016-02-08 10:10:11 --> URI Class Initialized
INFO - 2016-02-08 10:10:11 --> Router Class Initialized
INFO - 2016-02-08 10:10:11 --> Output Class Initialized
INFO - 2016-02-08 10:10:11 --> Security Class Initialized
DEBUG - 2016-02-08 10:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:10:11 --> Input Class Initialized
INFO - 2016-02-08 10:10:11 --> Language Class Initialized
INFO - 2016-02-08 10:10:11 --> Loader Class Initialized
INFO - 2016-02-08 10:10:11 --> Helper loaded: url_helper
INFO - 2016-02-08 10:10:11 --> Helper loaded: file_helper
INFO - 2016-02-08 10:10:11 --> Helper loaded: date_helper
INFO - 2016-02-08 10:10:11 --> Helper loaded: form_helper
INFO - 2016-02-08 10:10:11 --> Database Driver Class Initialized
INFO - 2016-02-08 10:10:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:10:12 --> Controller Class Initialized
INFO - 2016-02-08 10:10:12 --> Model Class Initialized
INFO - 2016-02-08 10:10:12 --> Model Class Initialized
INFO - 2016-02-08 10:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:10:12 --> Pagination Class Initialized
INFO - 2016-02-08 10:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:10:12 --> Helper loaded: text_helper
INFO - 2016-02-08 10:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:10:12 --> Final output sent to browser
DEBUG - 2016-02-08 10:10:12 --> Total execution time: 1.1856
INFO - 2016-02-08 10:10:18 --> Config Class Initialized
INFO - 2016-02-08 10:10:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:10:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:10:18 --> Utf8 Class Initialized
INFO - 2016-02-08 10:10:18 --> URI Class Initialized
INFO - 2016-02-08 10:10:18 --> Router Class Initialized
INFO - 2016-02-08 10:10:18 --> Output Class Initialized
INFO - 2016-02-08 10:10:18 --> Security Class Initialized
DEBUG - 2016-02-08 10:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:10:18 --> Input Class Initialized
INFO - 2016-02-08 10:10:18 --> Language Class Initialized
INFO - 2016-02-08 10:10:18 --> Loader Class Initialized
INFO - 2016-02-08 10:10:18 --> Helper loaded: url_helper
INFO - 2016-02-08 10:10:18 --> Helper loaded: file_helper
INFO - 2016-02-08 10:10:18 --> Helper loaded: date_helper
INFO - 2016-02-08 10:10:18 --> Helper loaded: form_helper
INFO - 2016-02-08 10:10:18 --> Database Driver Class Initialized
INFO - 2016-02-08 10:10:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:10:19 --> Controller Class Initialized
INFO - 2016-02-08 10:10:19 --> Model Class Initialized
INFO - 2016-02-08 10:10:19 --> Model Class Initialized
INFO - 2016-02-08 10:10:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:10:19 --> Pagination Class Initialized
INFO - 2016-02-08 10:10:19 --> Form Validation Class Initialized
INFO - 2016-02-08 10:10:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:10:19 --> Model Class Initialized
INFO - 2016-02-08 10:10:19 --> Final output sent to browser
DEBUG - 2016-02-08 10:10:19 --> Total execution time: 1.1812
INFO - 2016-02-08 10:21:33 --> Config Class Initialized
INFO - 2016-02-08 10:21:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:21:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:21:33 --> Utf8 Class Initialized
INFO - 2016-02-08 10:21:33 --> URI Class Initialized
INFO - 2016-02-08 10:21:33 --> Router Class Initialized
INFO - 2016-02-08 10:21:33 --> Output Class Initialized
INFO - 2016-02-08 10:21:33 --> Security Class Initialized
DEBUG - 2016-02-08 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:21:33 --> Input Class Initialized
INFO - 2016-02-08 10:21:33 --> Language Class Initialized
INFO - 2016-02-08 10:21:33 --> Loader Class Initialized
INFO - 2016-02-08 10:21:33 --> Helper loaded: url_helper
INFO - 2016-02-08 10:21:33 --> Helper loaded: file_helper
INFO - 2016-02-08 10:21:33 --> Helper loaded: date_helper
INFO - 2016-02-08 10:21:33 --> Helper loaded: form_helper
INFO - 2016-02-08 10:21:33 --> Database Driver Class Initialized
INFO - 2016-02-08 10:21:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:21:34 --> Controller Class Initialized
INFO - 2016-02-08 10:21:34 --> Model Class Initialized
INFO - 2016-02-08 10:21:34 --> Model Class Initialized
INFO - 2016-02-08 10:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:21:34 --> Pagination Class Initialized
INFO - 2016-02-08 10:21:34 --> Form Validation Class Initialized
INFO - 2016-02-08 10:21:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:21:34 --> Model Class Initialized
INFO - 2016-02-08 10:21:34 --> Final output sent to browser
DEBUG - 2016-02-08 10:21:34 --> Total execution time: 1.1550
INFO - 2016-02-08 10:21:35 --> Config Class Initialized
INFO - 2016-02-08 10:21:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:21:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:21:35 --> Utf8 Class Initialized
INFO - 2016-02-08 10:21:35 --> URI Class Initialized
INFO - 2016-02-08 10:21:35 --> Router Class Initialized
INFO - 2016-02-08 10:21:35 --> Output Class Initialized
INFO - 2016-02-08 10:21:35 --> Security Class Initialized
DEBUG - 2016-02-08 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:21:35 --> Input Class Initialized
INFO - 2016-02-08 10:21:35 --> Language Class Initialized
INFO - 2016-02-08 10:21:35 --> Loader Class Initialized
INFO - 2016-02-08 10:21:35 --> Helper loaded: url_helper
INFO - 2016-02-08 10:21:35 --> Helper loaded: file_helper
INFO - 2016-02-08 10:21:35 --> Helper loaded: date_helper
INFO - 2016-02-08 10:21:35 --> Helper loaded: form_helper
INFO - 2016-02-08 10:21:35 --> Database Driver Class Initialized
INFO - 2016-02-08 10:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:21:36 --> Controller Class Initialized
INFO - 2016-02-08 10:21:36 --> Model Class Initialized
INFO - 2016-02-08 10:21:36 --> Model Class Initialized
INFO - 2016-02-08 10:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:21:36 --> Pagination Class Initialized
INFO - 2016-02-08 10:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:21:36 --> Helper loaded: text_helper
INFO - 2016-02-08 10:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:21:36 --> Final output sent to browser
DEBUG - 2016-02-08 10:21:36 --> Total execution time: 1.1650
INFO - 2016-02-08 10:29:17 --> Config Class Initialized
INFO - 2016-02-08 10:29:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:29:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:29:17 --> Utf8 Class Initialized
INFO - 2016-02-08 10:29:17 --> URI Class Initialized
INFO - 2016-02-08 10:29:17 --> Router Class Initialized
INFO - 2016-02-08 10:29:17 --> Output Class Initialized
INFO - 2016-02-08 10:29:17 --> Security Class Initialized
DEBUG - 2016-02-08 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:29:17 --> Input Class Initialized
INFO - 2016-02-08 10:29:17 --> Language Class Initialized
INFO - 2016-02-08 10:29:17 --> Loader Class Initialized
INFO - 2016-02-08 10:29:17 --> Helper loaded: url_helper
INFO - 2016-02-08 10:29:17 --> Helper loaded: file_helper
INFO - 2016-02-08 10:29:17 --> Helper loaded: date_helper
INFO - 2016-02-08 10:29:17 --> Helper loaded: form_helper
INFO - 2016-02-08 10:29:17 --> Database Driver Class Initialized
INFO - 2016-02-08 10:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:29:18 --> Controller Class Initialized
INFO - 2016-02-08 10:29:18 --> Model Class Initialized
INFO - 2016-02-08 10:29:18 --> Model Class Initialized
INFO - 2016-02-08 10:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:29:18 --> Pagination Class Initialized
INFO - 2016-02-08 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:29:18 --> Helper loaded: text_helper
INFO - 2016-02-08 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:29:18 --> Final output sent to browser
DEBUG - 2016-02-08 10:29:18 --> Total execution time: 1.1742
INFO - 2016-02-08 10:29:23 --> Config Class Initialized
INFO - 2016-02-08 10:29:23 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:29:23 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:29:23 --> Utf8 Class Initialized
INFO - 2016-02-08 10:29:23 --> URI Class Initialized
INFO - 2016-02-08 10:29:23 --> Router Class Initialized
INFO - 2016-02-08 10:29:23 --> Output Class Initialized
INFO - 2016-02-08 10:29:23 --> Security Class Initialized
DEBUG - 2016-02-08 10:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:29:23 --> Input Class Initialized
INFO - 2016-02-08 10:29:23 --> Language Class Initialized
INFO - 2016-02-08 10:29:23 --> Loader Class Initialized
INFO - 2016-02-08 10:29:23 --> Helper loaded: url_helper
INFO - 2016-02-08 10:29:23 --> Helper loaded: file_helper
INFO - 2016-02-08 10:29:23 --> Helper loaded: date_helper
INFO - 2016-02-08 10:29:23 --> Helper loaded: form_helper
INFO - 2016-02-08 10:29:23 --> Database Driver Class Initialized
INFO - 2016-02-08 10:29:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:29:24 --> Controller Class Initialized
INFO - 2016-02-08 10:29:24 --> Model Class Initialized
INFO - 2016-02-08 10:29:24 --> Model Class Initialized
INFO - 2016-02-08 10:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:29:24 --> Pagination Class Initialized
INFO - 2016-02-08 10:29:24 --> Form Validation Class Initialized
INFO - 2016-02-08 10:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:29:24 --> Model Class Initialized
INFO - 2016-02-08 10:29:25 --> Final output sent to browser
DEBUG - 2016-02-08 10:29:25 --> Total execution time: 1.3715
INFO - 2016-02-08 10:30:28 --> Config Class Initialized
INFO - 2016-02-08 10:30:28 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:30:28 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:30:28 --> Utf8 Class Initialized
INFO - 2016-02-08 10:30:28 --> URI Class Initialized
INFO - 2016-02-08 10:30:28 --> Router Class Initialized
INFO - 2016-02-08 10:30:28 --> Output Class Initialized
INFO - 2016-02-08 10:30:28 --> Security Class Initialized
DEBUG - 2016-02-08 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:30:28 --> Input Class Initialized
INFO - 2016-02-08 10:30:28 --> Language Class Initialized
INFO - 2016-02-08 10:30:28 --> Loader Class Initialized
INFO - 2016-02-08 10:30:28 --> Helper loaded: url_helper
INFO - 2016-02-08 10:30:28 --> Helper loaded: file_helper
INFO - 2016-02-08 10:30:28 --> Helper loaded: date_helper
INFO - 2016-02-08 10:30:28 --> Helper loaded: form_helper
INFO - 2016-02-08 10:30:28 --> Database Driver Class Initialized
INFO - 2016-02-08 10:30:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:30:29 --> Controller Class Initialized
INFO - 2016-02-08 10:30:29 --> Model Class Initialized
INFO - 2016-02-08 10:30:29 --> Model Class Initialized
INFO - 2016-02-08 10:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:30:29 --> Pagination Class Initialized
INFO - 2016-02-08 10:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:30:29 --> Helper loaded: text_helper
INFO - 2016-02-08 10:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:30:29 --> Final output sent to browser
DEBUG - 2016-02-08 10:30:29 --> Total execution time: 1.2007
INFO - 2016-02-08 10:30:34 --> Config Class Initialized
INFO - 2016-02-08 10:30:34 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:30:34 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:30:34 --> Utf8 Class Initialized
INFO - 2016-02-08 10:30:34 --> URI Class Initialized
INFO - 2016-02-08 10:30:34 --> Router Class Initialized
INFO - 2016-02-08 10:30:34 --> Output Class Initialized
INFO - 2016-02-08 10:30:34 --> Security Class Initialized
DEBUG - 2016-02-08 10:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:30:34 --> Input Class Initialized
INFO - 2016-02-08 10:30:34 --> Language Class Initialized
INFO - 2016-02-08 10:30:34 --> Loader Class Initialized
INFO - 2016-02-08 10:30:34 --> Helper loaded: url_helper
INFO - 2016-02-08 10:30:34 --> Helper loaded: file_helper
INFO - 2016-02-08 10:30:34 --> Helper loaded: date_helper
INFO - 2016-02-08 10:30:34 --> Helper loaded: form_helper
INFO - 2016-02-08 10:30:34 --> Database Driver Class Initialized
INFO - 2016-02-08 10:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:30:35 --> Controller Class Initialized
INFO - 2016-02-08 10:30:35 --> Model Class Initialized
INFO - 2016-02-08 10:30:35 --> Model Class Initialized
INFO - 2016-02-08 10:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:30:35 --> Pagination Class Initialized
INFO - 2016-02-08 10:30:35 --> Form Validation Class Initialized
INFO - 2016-02-08 10:30:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:30:35 --> Model Class Initialized
INFO - 2016-02-08 10:30:35 --> Final output sent to browser
DEBUG - 2016-02-08 10:30:35 --> Total execution time: 1.1849
INFO - 2016-02-08 10:31:11 --> Config Class Initialized
INFO - 2016-02-08 10:31:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:31:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:31:11 --> Utf8 Class Initialized
INFO - 2016-02-08 10:31:11 --> URI Class Initialized
INFO - 2016-02-08 10:31:11 --> Router Class Initialized
INFO - 2016-02-08 10:31:11 --> Output Class Initialized
INFO - 2016-02-08 10:31:11 --> Security Class Initialized
DEBUG - 2016-02-08 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:31:11 --> Input Class Initialized
INFO - 2016-02-08 10:31:11 --> Language Class Initialized
INFO - 2016-02-08 10:31:11 --> Loader Class Initialized
INFO - 2016-02-08 10:31:11 --> Helper loaded: url_helper
INFO - 2016-02-08 10:31:11 --> Helper loaded: file_helper
INFO - 2016-02-08 10:31:11 --> Helper loaded: date_helper
INFO - 2016-02-08 10:31:11 --> Helper loaded: form_helper
INFO - 2016-02-08 10:31:11 --> Database Driver Class Initialized
INFO - 2016-02-08 10:31:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:31:12 --> Controller Class Initialized
INFO - 2016-02-08 10:31:12 --> Model Class Initialized
INFO - 2016-02-08 10:31:12 --> Model Class Initialized
INFO - 2016-02-08 10:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:31:12 --> Pagination Class Initialized
INFO - 2016-02-08 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:31:12 --> Helper loaded: text_helper
INFO - 2016-02-08 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:31:12 --> Final output sent to browser
DEBUG - 2016-02-08 10:31:12 --> Total execution time: 1.1590
INFO - 2016-02-08 10:31:18 --> Config Class Initialized
INFO - 2016-02-08 10:31:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:31:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:31:18 --> Utf8 Class Initialized
INFO - 2016-02-08 10:31:18 --> URI Class Initialized
INFO - 2016-02-08 10:31:18 --> Router Class Initialized
INFO - 2016-02-08 10:31:18 --> Output Class Initialized
INFO - 2016-02-08 10:31:18 --> Security Class Initialized
DEBUG - 2016-02-08 10:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:31:18 --> Input Class Initialized
INFO - 2016-02-08 10:31:18 --> Language Class Initialized
INFO - 2016-02-08 10:31:18 --> Loader Class Initialized
INFO - 2016-02-08 10:31:18 --> Helper loaded: url_helper
INFO - 2016-02-08 10:31:18 --> Helper loaded: file_helper
INFO - 2016-02-08 10:31:18 --> Helper loaded: date_helper
INFO - 2016-02-08 10:31:18 --> Helper loaded: form_helper
INFO - 2016-02-08 10:31:18 --> Database Driver Class Initialized
INFO - 2016-02-08 10:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:31:19 --> Controller Class Initialized
INFO - 2016-02-08 10:31:19 --> Model Class Initialized
INFO - 2016-02-08 10:31:19 --> Model Class Initialized
INFO - 2016-02-08 10:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:31:19 --> Pagination Class Initialized
INFO - 2016-02-08 10:31:19 --> Form Validation Class Initialized
INFO - 2016-02-08 10:31:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:31:19 --> Model Class Initialized
INFO - 2016-02-08 10:31:19 --> Final output sent to browser
DEBUG - 2016-02-08 10:31:19 --> Total execution time: 1.2054
INFO - 2016-02-08 10:36:56 --> Config Class Initialized
INFO - 2016-02-08 10:36:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:36:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:36:56 --> Utf8 Class Initialized
INFO - 2016-02-08 10:36:56 --> URI Class Initialized
INFO - 2016-02-08 10:36:56 --> Router Class Initialized
INFO - 2016-02-08 10:36:56 --> Output Class Initialized
INFO - 2016-02-08 10:36:56 --> Security Class Initialized
DEBUG - 2016-02-08 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:36:56 --> Input Class Initialized
INFO - 2016-02-08 10:36:56 --> Language Class Initialized
INFO - 2016-02-08 10:36:56 --> Loader Class Initialized
INFO - 2016-02-08 10:36:56 --> Helper loaded: url_helper
INFO - 2016-02-08 10:36:56 --> Helper loaded: file_helper
INFO - 2016-02-08 10:36:56 --> Helper loaded: date_helper
INFO - 2016-02-08 10:36:56 --> Helper loaded: form_helper
INFO - 2016-02-08 10:36:56 --> Database Driver Class Initialized
INFO - 2016-02-08 10:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:36:57 --> Controller Class Initialized
INFO - 2016-02-08 10:36:57 --> Model Class Initialized
INFO - 2016-02-08 10:36:57 --> Model Class Initialized
INFO - 2016-02-08 10:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:36:57 --> Pagination Class Initialized
INFO - 2016-02-08 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:36:57 --> Helper loaded: text_helper
INFO - 2016-02-08 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:36:57 --> Final output sent to browser
DEBUG - 2016-02-08 10:36:57 --> Total execution time: 1.1828
INFO - 2016-02-08 10:37:05 --> Config Class Initialized
INFO - 2016-02-08 10:37:05 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:37:05 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:37:05 --> Utf8 Class Initialized
INFO - 2016-02-08 10:37:05 --> URI Class Initialized
INFO - 2016-02-08 10:37:05 --> Router Class Initialized
INFO - 2016-02-08 10:37:05 --> Output Class Initialized
INFO - 2016-02-08 10:37:05 --> Security Class Initialized
DEBUG - 2016-02-08 10:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:37:05 --> Input Class Initialized
INFO - 2016-02-08 10:37:05 --> Language Class Initialized
INFO - 2016-02-08 10:37:05 --> Loader Class Initialized
INFO - 2016-02-08 10:37:05 --> Helper loaded: url_helper
INFO - 2016-02-08 10:37:05 --> Helper loaded: file_helper
INFO - 2016-02-08 10:37:05 --> Helper loaded: date_helper
INFO - 2016-02-08 10:37:05 --> Helper loaded: form_helper
INFO - 2016-02-08 10:37:05 --> Database Driver Class Initialized
INFO - 2016-02-08 10:37:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:37:06 --> Controller Class Initialized
INFO - 2016-02-08 10:37:06 --> Model Class Initialized
INFO - 2016-02-08 10:37:06 --> Model Class Initialized
INFO - 2016-02-08 10:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:37:06 --> Pagination Class Initialized
INFO - 2016-02-08 10:37:06 --> Form Validation Class Initialized
INFO - 2016-02-08 10:37:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:37:06 --> Model Class Initialized
INFO - 2016-02-08 10:37:06 --> Final output sent to browser
DEBUG - 2016-02-08 10:37:06 --> Total execution time: 1.2796
INFO - 2016-02-08 10:37:54 --> Config Class Initialized
INFO - 2016-02-08 10:37:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:37:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:37:54 --> Utf8 Class Initialized
INFO - 2016-02-08 10:37:54 --> URI Class Initialized
INFO - 2016-02-08 10:37:54 --> Router Class Initialized
INFO - 2016-02-08 10:37:54 --> Output Class Initialized
INFO - 2016-02-08 10:37:54 --> Security Class Initialized
DEBUG - 2016-02-08 10:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:37:54 --> Input Class Initialized
INFO - 2016-02-08 10:37:54 --> Language Class Initialized
INFO - 2016-02-08 10:37:54 --> Loader Class Initialized
INFO - 2016-02-08 10:37:54 --> Helper loaded: url_helper
INFO - 2016-02-08 10:37:54 --> Helper loaded: file_helper
INFO - 2016-02-08 10:37:54 --> Helper loaded: date_helper
INFO - 2016-02-08 10:37:54 --> Helper loaded: form_helper
INFO - 2016-02-08 10:37:54 --> Database Driver Class Initialized
INFO - 2016-02-08 10:37:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:37:55 --> Controller Class Initialized
INFO - 2016-02-08 10:37:55 --> Model Class Initialized
INFO - 2016-02-08 10:37:55 --> Model Class Initialized
INFO - 2016-02-08 10:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:37:55 --> Pagination Class Initialized
INFO - 2016-02-08 10:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:37:55 --> Helper loaded: text_helper
INFO - 2016-02-08 10:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:37:55 --> Final output sent to browser
DEBUG - 2016-02-08 10:37:55 --> Total execution time: 1.1689
INFO - 2016-02-08 10:47:18 --> Config Class Initialized
INFO - 2016-02-08 10:47:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:47:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:47:18 --> Utf8 Class Initialized
INFO - 2016-02-08 10:47:18 --> URI Class Initialized
INFO - 2016-02-08 10:47:18 --> Router Class Initialized
INFO - 2016-02-08 10:47:18 --> Output Class Initialized
INFO - 2016-02-08 10:47:18 --> Security Class Initialized
DEBUG - 2016-02-08 10:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:47:18 --> Input Class Initialized
INFO - 2016-02-08 10:47:18 --> Language Class Initialized
INFO - 2016-02-08 10:47:18 --> Loader Class Initialized
INFO - 2016-02-08 10:47:18 --> Helper loaded: url_helper
INFO - 2016-02-08 10:47:18 --> Helper loaded: file_helper
INFO - 2016-02-08 10:47:18 --> Helper loaded: date_helper
INFO - 2016-02-08 10:47:18 --> Helper loaded: form_helper
INFO - 2016-02-08 10:47:18 --> Database Driver Class Initialized
INFO - 2016-02-08 10:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:47:19 --> Controller Class Initialized
INFO - 2016-02-08 10:47:19 --> Model Class Initialized
INFO - 2016-02-08 10:47:19 --> Model Class Initialized
INFO - 2016-02-08 10:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:47:19 --> Pagination Class Initialized
INFO - 2016-02-08 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:47:19 --> Helper loaded: text_helper
INFO - 2016-02-08 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:47:19 --> Final output sent to browser
DEBUG - 2016-02-08 10:47:19 --> Total execution time: 1.1846
INFO - 2016-02-08 10:47:50 --> Config Class Initialized
INFO - 2016-02-08 10:47:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:47:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:47:50 --> Utf8 Class Initialized
INFO - 2016-02-08 10:47:50 --> URI Class Initialized
INFO - 2016-02-08 10:47:50 --> Router Class Initialized
INFO - 2016-02-08 10:47:50 --> Output Class Initialized
INFO - 2016-02-08 10:47:50 --> Security Class Initialized
DEBUG - 2016-02-08 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:47:50 --> Input Class Initialized
INFO - 2016-02-08 10:47:50 --> Language Class Initialized
INFO - 2016-02-08 10:47:50 --> Loader Class Initialized
INFO - 2016-02-08 10:47:50 --> Helper loaded: url_helper
INFO - 2016-02-08 10:47:50 --> Helper loaded: file_helper
INFO - 2016-02-08 10:47:50 --> Helper loaded: date_helper
INFO - 2016-02-08 10:47:50 --> Helper loaded: form_helper
INFO - 2016-02-08 10:47:50 --> Database Driver Class Initialized
INFO - 2016-02-08 10:47:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:47:51 --> Controller Class Initialized
INFO - 2016-02-08 10:47:51 --> Model Class Initialized
INFO - 2016-02-08 10:47:51 --> Model Class Initialized
INFO - 2016-02-08 10:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:47:51 --> Pagination Class Initialized
INFO - 2016-02-08 10:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:47:51 --> Helper loaded: text_helper
INFO - 2016-02-08 10:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:47:51 --> Final output sent to browser
DEBUG - 2016-02-08 10:47:51 --> Total execution time: 1.1499
INFO - 2016-02-08 10:49:08 --> Config Class Initialized
INFO - 2016-02-08 10:49:08 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:49:08 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:49:08 --> Utf8 Class Initialized
INFO - 2016-02-08 10:49:08 --> URI Class Initialized
INFO - 2016-02-08 10:49:08 --> Router Class Initialized
INFO - 2016-02-08 10:49:08 --> Output Class Initialized
INFO - 2016-02-08 10:49:08 --> Security Class Initialized
DEBUG - 2016-02-08 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:49:08 --> Input Class Initialized
INFO - 2016-02-08 10:49:08 --> Language Class Initialized
INFO - 2016-02-08 10:49:08 --> Loader Class Initialized
INFO - 2016-02-08 10:49:08 --> Helper loaded: url_helper
INFO - 2016-02-08 10:49:08 --> Helper loaded: file_helper
INFO - 2016-02-08 10:49:08 --> Helper loaded: date_helper
INFO - 2016-02-08 10:49:08 --> Helper loaded: form_helper
INFO - 2016-02-08 10:49:08 --> Database Driver Class Initialized
INFO - 2016-02-08 10:49:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:49:10 --> Controller Class Initialized
INFO - 2016-02-08 10:49:10 --> Model Class Initialized
INFO - 2016-02-08 10:49:10 --> Model Class Initialized
INFO - 2016-02-08 10:49:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:49:10 --> Pagination Class Initialized
INFO - 2016-02-08 10:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:49:10 --> Helper loaded: text_helper
INFO - 2016-02-08 10:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:49:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:49:10 --> Final output sent to browser
DEBUG - 2016-02-08 10:49:10 --> Total execution time: 1.2035
INFO - 2016-02-08 10:49:17 --> Config Class Initialized
INFO - 2016-02-08 10:49:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:49:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:49:17 --> Utf8 Class Initialized
INFO - 2016-02-08 10:49:17 --> URI Class Initialized
INFO - 2016-02-08 10:49:17 --> Router Class Initialized
INFO - 2016-02-08 10:49:17 --> Output Class Initialized
INFO - 2016-02-08 10:49:17 --> Security Class Initialized
DEBUG - 2016-02-08 10:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:49:17 --> Input Class Initialized
INFO - 2016-02-08 10:49:17 --> Language Class Initialized
INFO - 2016-02-08 10:49:17 --> Loader Class Initialized
INFO - 2016-02-08 10:49:17 --> Helper loaded: url_helper
INFO - 2016-02-08 10:49:17 --> Helper loaded: file_helper
INFO - 2016-02-08 10:49:17 --> Helper loaded: date_helper
INFO - 2016-02-08 10:49:17 --> Helper loaded: form_helper
INFO - 2016-02-08 10:49:17 --> Database Driver Class Initialized
INFO - 2016-02-08 10:49:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:49:18 --> Controller Class Initialized
INFO - 2016-02-08 10:49:18 --> Model Class Initialized
INFO - 2016-02-08 10:49:18 --> Model Class Initialized
INFO - 2016-02-08 10:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:49:18 --> Pagination Class Initialized
INFO - 2016-02-08 10:49:18 --> Form Validation Class Initialized
INFO - 2016-02-08 10:49:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:49:18 --> Model Class Initialized
INFO - 2016-02-08 10:49:18 --> Final output sent to browser
DEBUG - 2016-02-08 10:49:18 --> Total execution time: 1.1901
INFO - 2016-02-08 10:50:48 --> Config Class Initialized
INFO - 2016-02-08 10:50:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:50:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:50:48 --> Utf8 Class Initialized
INFO - 2016-02-08 10:50:48 --> URI Class Initialized
INFO - 2016-02-08 10:50:48 --> Router Class Initialized
INFO - 2016-02-08 10:50:48 --> Output Class Initialized
INFO - 2016-02-08 10:50:48 --> Security Class Initialized
DEBUG - 2016-02-08 10:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:50:48 --> Input Class Initialized
INFO - 2016-02-08 10:50:48 --> Language Class Initialized
INFO - 2016-02-08 10:50:48 --> Loader Class Initialized
INFO - 2016-02-08 10:50:48 --> Helper loaded: url_helper
INFO - 2016-02-08 10:50:49 --> Helper loaded: file_helper
INFO - 2016-02-08 10:50:49 --> Helper loaded: date_helper
INFO - 2016-02-08 10:50:49 --> Helper loaded: form_helper
INFO - 2016-02-08 10:50:49 --> Database Driver Class Initialized
INFO - 2016-02-08 10:50:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:50:50 --> Controller Class Initialized
INFO - 2016-02-08 10:50:50 --> Model Class Initialized
INFO - 2016-02-08 10:50:50 --> Model Class Initialized
INFO - 2016-02-08 10:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:50:50 --> Pagination Class Initialized
INFO - 2016-02-08 10:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:50:50 --> Helper loaded: text_helper
INFO - 2016-02-08 10:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:50:50 --> Final output sent to browser
DEBUG - 2016-02-08 10:50:50 --> Total execution time: 1.1566
INFO - 2016-02-08 10:50:55 --> Config Class Initialized
INFO - 2016-02-08 10:50:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:50:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:50:55 --> Utf8 Class Initialized
INFO - 2016-02-08 10:50:55 --> URI Class Initialized
INFO - 2016-02-08 10:50:55 --> Router Class Initialized
INFO - 2016-02-08 10:50:55 --> Output Class Initialized
INFO - 2016-02-08 10:50:55 --> Security Class Initialized
DEBUG - 2016-02-08 10:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:50:55 --> Input Class Initialized
INFO - 2016-02-08 10:50:55 --> Language Class Initialized
INFO - 2016-02-08 10:50:55 --> Loader Class Initialized
INFO - 2016-02-08 10:50:55 --> Helper loaded: url_helper
INFO - 2016-02-08 10:50:55 --> Helper loaded: file_helper
INFO - 2016-02-08 10:50:55 --> Helper loaded: date_helper
INFO - 2016-02-08 10:50:55 --> Helper loaded: form_helper
INFO - 2016-02-08 10:50:55 --> Database Driver Class Initialized
INFO - 2016-02-08 10:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:50:56 --> Controller Class Initialized
INFO - 2016-02-08 10:50:56 --> Model Class Initialized
INFO - 2016-02-08 10:50:56 --> Model Class Initialized
INFO - 2016-02-08 10:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:50:56 --> Pagination Class Initialized
INFO - 2016-02-08 10:50:56 --> Form Validation Class Initialized
INFO - 2016-02-08 10:50:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:50:56 --> Model Class Initialized
INFO - 2016-02-08 10:50:56 --> Final output sent to browser
DEBUG - 2016-02-08 10:50:56 --> Total execution time: 1.1693
INFO - 2016-02-08 10:53:24 --> Config Class Initialized
INFO - 2016-02-08 10:53:24 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:53:24 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:53:24 --> Utf8 Class Initialized
INFO - 2016-02-08 10:53:24 --> URI Class Initialized
INFO - 2016-02-08 10:53:24 --> Router Class Initialized
INFO - 2016-02-08 10:53:24 --> Output Class Initialized
INFO - 2016-02-08 10:53:24 --> Security Class Initialized
DEBUG - 2016-02-08 10:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:53:24 --> Input Class Initialized
INFO - 2016-02-08 10:53:24 --> Language Class Initialized
INFO - 2016-02-08 10:53:24 --> Loader Class Initialized
INFO - 2016-02-08 10:53:24 --> Helper loaded: url_helper
INFO - 2016-02-08 10:53:24 --> Helper loaded: file_helper
INFO - 2016-02-08 10:53:24 --> Helper loaded: date_helper
INFO - 2016-02-08 10:53:24 --> Helper loaded: form_helper
INFO - 2016-02-08 10:53:24 --> Database Driver Class Initialized
INFO - 2016-02-08 10:53:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:53:25 --> Controller Class Initialized
INFO - 2016-02-08 10:53:25 --> Model Class Initialized
INFO - 2016-02-08 10:53:25 --> Model Class Initialized
INFO - 2016-02-08 10:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:53:25 --> Pagination Class Initialized
INFO - 2016-02-08 10:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:53:25 --> Helper loaded: text_helper
INFO - 2016-02-08 10:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:53:25 --> Final output sent to browser
DEBUG - 2016-02-08 10:53:25 --> Total execution time: 1.1666
INFO - 2016-02-08 10:53:31 --> Config Class Initialized
INFO - 2016-02-08 10:53:31 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:53:31 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:53:31 --> Utf8 Class Initialized
INFO - 2016-02-08 10:53:31 --> URI Class Initialized
INFO - 2016-02-08 10:53:31 --> Router Class Initialized
INFO - 2016-02-08 10:53:31 --> Output Class Initialized
INFO - 2016-02-08 10:53:31 --> Security Class Initialized
DEBUG - 2016-02-08 10:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:53:31 --> Input Class Initialized
INFO - 2016-02-08 10:53:31 --> Language Class Initialized
INFO - 2016-02-08 10:53:31 --> Loader Class Initialized
INFO - 2016-02-08 10:53:31 --> Helper loaded: url_helper
INFO - 2016-02-08 10:53:31 --> Helper loaded: file_helper
INFO - 2016-02-08 10:53:31 --> Helper loaded: date_helper
INFO - 2016-02-08 10:53:31 --> Helper loaded: form_helper
INFO - 2016-02-08 10:53:31 --> Database Driver Class Initialized
INFO - 2016-02-08 10:53:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:53:32 --> Controller Class Initialized
INFO - 2016-02-08 10:53:32 --> Model Class Initialized
INFO - 2016-02-08 10:53:32 --> Model Class Initialized
INFO - 2016-02-08 10:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:53:32 --> Pagination Class Initialized
INFO - 2016-02-08 10:53:32 --> Form Validation Class Initialized
INFO - 2016-02-08 10:53:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:53:32 --> Model Class Initialized
INFO - 2016-02-08 10:53:32 --> Final output sent to browser
DEBUG - 2016-02-08 10:53:32 --> Total execution time: 1.2273
INFO - 2016-02-08 10:55:15 --> Config Class Initialized
INFO - 2016-02-08 10:55:15 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:55:15 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:55:15 --> Utf8 Class Initialized
INFO - 2016-02-08 10:55:15 --> URI Class Initialized
INFO - 2016-02-08 10:55:15 --> Router Class Initialized
INFO - 2016-02-08 10:55:15 --> Output Class Initialized
INFO - 2016-02-08 10:55:15 --> Security Class Initialized
DEBUG - 2016-02-08 10:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:55:15 --> Input Class Initialized
INFO - 2016-02-08 10:55:15 --> Language Class Initialized
INFO - 2016-02-08 10:55:15 --> Loader Class Initialized
INFO - 2016-02-08 10:55:15 --> Helper loaded: url_helper
INFO - 2016-02-08 10:55:15 --> Helper loaded: file_helper
INFO - 2016-02-08 10:55:15 --> Helper loaded: date_helper
INFO - 2016-02-08 10:55:15 --> Helper loaded: form_helper
INFO - 2016-02-08 10:55:15 --> Database Driver Class Initialized
INFO - 2016-02-08 10:55:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:55:16 --> Controller Class Initialized
INFO - 2016-02-08 10:55:16 --> Model Class Initialized
INFO - 2016-02-08 10:55:16 --> Model Class Initialized
INFO - 2016-02-08 10:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:55:16 --> Pagination Class Initialized
INFO - 2016-02-08 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:55:16 --> Helper loaded: text_helper
INFO - 2016-02-08 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:55:16 --> Final output sent to browser
DEBUG - 2016-02-08 10:55:16 --> Total execution time: 1.2233
INFO - 2016-02-08 10:55:26 --> Config Class Initialized
INFO - 2016-02-08 10:55:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:55:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:55:26 --> Utf8 Class Initialized
INFO - 2016-02-08 10:55:26 --> URI Class Initialized
INFO - 2016-02-08 10:55:26 --> Router Class Initialized
INFO - 2016-02-08 10:55:26 --> Output Class Initialized
INFO - 2016-02-08 10:55:26 --> Security Class Initialized
DEBUG - 2016-02-08 10:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:55:26 --> Input Class Initialized
INFO - 2016-02-08 10:55:26 --> Language Class Initialized
INFO - 2016-02-08 10:55:26 --> Loader Class Initialized
INFO - 2016-02-08 10:55:26 --> Helper loaded: url_helper
INFO - 2016-02-08 10:55:26 --> Helper loaded: file_helper
INFO - 2016-02-08 10:55:26 --> Helper loaded: date_helper
INFO - 2016-02-08 10:55:26 --> Helper loaded: form_helper
INFO - 2016-02-08 10:55:26 --> Database Driver Class Initialized
INFO - 2016-02-08 10:55:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:55:28 --> Controller Class Initialized
INFO - 2016-02-08 10:55:28 --> Model Class Initialized
INFO - 2016-02-08 10:55:28 --> Model Class Initialized
INFO - 2016-02-08 10:55:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:55:28 --> Pagination Class Initialized
INFO - 2016-02-08 10:55:28 --> Form Validation Class Initialized
INFO - 2016-02-08 10:55:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:55:28 --> Model Class Initialized
INFO - 2016-02-08 10:55:28 --> Final output sent to browser
DEBUG - 2016-02-08 10:55:28 --> Total execution time: 1.1781
INFO - 2016-02-08 10:56:12 --> Config Class Initialized
INFO - 2016-02-08 10:56:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:56:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:56:12 --> Utf8 Class Initialized
INFO - 2016-02-08 10:56:12 --> URI Class Initialized
INFO - 2016-02-08 10:56:12 --> Router Class Initialized
INFO - 2016-02-08 10:56:12 --> Output Class Initialized
INFO - 2016-02-08 10:56:12 --> Security Class Initialized
DEBUG - 2016-02-08 10:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:56:12 --> Input Class Initialized
INFO - 2016-02-08 10:56:12 --> Language Class Initialized
INFO - 2016-02-08 10:56:12 --> Loader Class Initialized
INFO - 2016-02-08 10:56:12 --> Helper loaded: url_helper
INFO - 2016-02-08 10:56:12 --> Helper loaded: file_helper
INFO - 2016-02-08 10:56:12 --> Helper loaded: date_helper
INFO - 2016-02-08 10:56:12 --> Helper loaded: form_helper
INFO - 2016-02-08 10:56:12 --> Database Driver Class Initialized
INFO - 2016-02-08 10:56:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:56:13 --> Controller Class Initialized
INFO - 2016-02-08 10:56:13 --> Model Class Initialized
INFO - 2016-02-08 10:56:13 --> Model Class Initialized
INFO - 2016-02-08 10:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:56:13 --> Pagination Class Initialized
INFO - 2016-02-08 10:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:56:13 --> Helper loaded: text_helper
INFO - 2016-02-08 10:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:56:13 --> Final output sent to browser
DEBUG - 2016-02-08 10:56:13 --> Total execution time: 1.1814
INFO - 2016-02-08 10:56:19 --> Config Class Initialized
INFO - 2016-02-08 10:56:19 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:56:19 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:56:19 --> Utf8 Class Initialized
INFO - 2016-02-08 10:56:19 --> URI Class Initialized
INFO - 2016-02-08 10:56:19 --> Router Class Initialized
INFO - 2016-02-08 10:56:19 --> Output Class Initialized
INFO - 2016-02-08 10:56:19 --> Security Class Initialized
DEBUG - 2016-02-08 10:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:56:19 --> Input Class Initialized
INFO - 2016-02-08 10:56:19 --> Language Class Initialized
INFO - 2016-02-08 10:56:19 --> Loader Class Initialized
INFO - 2016-02-08 10:56:19 --> Helper loaded: url_helper
INFO - 2016-02-08 10:56:19 --> Helper loaded: file_helper
INFO - 2016-02-08 10:56:19 --> Helper loaded: date_helper
INFO - 2016-02-08 10:56:19 --> Helper loaded: form_helper
INFO - 2016-02-08 10:56:19 --> Database Driver Class Initialized
INFO - 2016-02-08 10:56:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:56:20 --> Controller Class Initialized
INFO - 2016-02-08 10:56:20 --> Model Class Initialized
INFO - 2016-02-08 10:56:20 --> Model Class Initialized
INFO - 2016-02-08 10:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:56:20 --> Pagination Class Initialized
INFO - 2016-02-08 10:56:20 --> Form Validation Class Initialized
INFO - 2016-02-08 10:56:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:56:20 --> Model Class Initialized
INFO - 2016-02-08 10:56:20 --> Final output sent to browser
DEBUG - 2016-02-08 10:56:20 --> Total execution time: 1.1566
INFO - 2016-02-08 10:57:00 --> Config Class Initialized
INFO - 2016-02-08 10:57:00 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:57:00 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:57:00 --> Utf8 Class Initialized
INFO - 2016-02-08 10:57:00 --> URI Class Initialized
INFO - 2016-02-08 10:57:00 --> Router Class Initialized
INFO - 2016-02-08 10:57:00 --> Output Class Initialized
INFO - 2016-02-08 10:57:00 --> Security Class Initialized
DEBUG - 2016-02-08 10:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:57:00 --> Input Class Initialized
INFO - 2016-02-08 10:57:00 --> Language Class Initialized
INFO - 2016-02-08 10:57:00 --> Loader Class Initialized
INFO - 2016-02-08 10:57:00 --> Helper loaded: url_helper
INFO - 2016-02-08 10:57:00 --> Helper loaded: file_helper
INFO - 2016-02-08 10:57:00 --> Helper loaded: date_helper
INFO - 2016-02-08 10:57:00 --> Helper loaded: form_helper
INFO - 2016-02-08 10:57:00 --> Database Driver Class Initialized
INFO - 2016-02-08 10:57:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:57:01 --> Controller Class Initialized
INFO - 2016-02-08 10:57:01 --> Model Class Initialized
INFO - 2016-02-08 10:57:01 --> Model Class Initialized
INFO - 2016-02-08 10:57:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:57:01 --> Pagination Class Initialized
INFO - 2016-02-08 10:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:57:01 --> Helper loaded: text_helper
INFO - 2016-02-08 10:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:57:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:57:01 --> Final output sent to browser
DEBUG - 2016-02-08 10:57:01 --> Total execution time: 1.1762
INFO - 2016-02-08 10:57:08 --> Config Class Initialized
INFO - 2016-02-08 10:57:08 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:57:08 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:57:08 --> Utf8 Class Initialized
INFO - 2016-02-08 10:57:08 --> URI Class Initialized
INFO - 2016-02-08 10:57:08 --> Router Class Initialized
INFO - 2016-02-08 10:57:08 --> Output Class Initialized
INFO - 2016-02-08 10:57:08 --> Security Class Initialized
DEBUG - 2016-02-08 10:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:57:08 --> Input Class Initialized
INFO - 2016-02-08 10:57:08 --> Language Class Initialized
INFO - 2016-02-08 10:57:08 --> Loader Class Initialized
INFO - 2016-02-08 10:57:08 --> Helper loaded: url_helper
INFO - 2016-02-08 10:57:08 --> Helper loaded: file_helper
INFO - 2016-02-08 10:57:08 --> Helper loaded: date_helper
INFO - 2016-02-08 10:57:08 --> Helper loaded: form_helper
INFO - 2016-02-08 10:57:08 --> Database Driver Class Initialized
INFO - 2016-02-08 10:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:57:09 --> Controller Class Initialized
INFO - 2016-02-08 10:57:09 --> Model Class Initialized
INFO - 2016-02-08 10:57:09 --> Model Class Initialized
INFO - 2016-02-08 10:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:57:09 --> Pagination Class Initialized
INFO - 2016-02-08 10:57:09 --> Form Validation Class Initialized
INFO - 2016-02-08 10:57:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:57:10 --> Model Class Initialized
INFO - 2016-02-08 10:57:10 --> Final output sent to browser
DEBUG - 2016-02-08 10:57:10 --> Total execution time: 1.2878
INFO - 2016-02-08 10:58:10 --> Config Class Initialized
INFO - 2016-02-08 10:58:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:58:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:58:10 --> Utf8 Class Initialized
INFO - 2016-02-08 10:58:10 --> URI Class Initialized
INFO - 2016-02-08 10:58:10 --> Router Class Initialized
INFO - 2016-02-08 10:58:10 --> Output Class Initialized
INFO - 2016-02-08 10:58:10 --> Security Class Initialized
DEBUG - 2016-02-08 10:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:58:10 --> Input Class Initialized
INFO - 2016-02-08 10:58:10 --> Language Class Initialized
INFO - 2016-02-08 10:58:10 --> Loader Class Initialized
INFO - 2016-02-08 10:58:10 --> Helper loaded: url_helper
INFO - 2016-02-08 10:58:10 --> Helper loaded: file_helper
INFO - 2016-02-08 10:58:10 --> Helper loaded: date_helper
INFO - 2016-02-08 10:58:10 --> Helper loaded: form_helper
INFO - 2016-02-08 10:58:10 --> Database Driver Class Initialized
INFO - 2016-02-08 10:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:58:11 --> Controller Class Initialized
INFO - 2016-02-08 10:58:11 --> Model Class Initialized
INFO - 2016-02-08 10:58:11 --> Model Class Initialized
INFO - 2016-02-08 10:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:58:11 --> Pagination Class Initialized
INFO - 2016-02-08 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:58:11 --> Helper loaded: text_helper
INFO - 2016-02-08 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:58:11 --> Final output sent to browser
DEBUG - 2016-02-08 10:58:11 --> Total execution time: 1.2810
INFO - 2016-02-08 10:58:52 --> Config Class Initialized
INFO - 2016-02-08 10:58:52 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:58:52 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:58:52 --> Utf8 Class Initialized
INFO - 2016-02-08 10:58:52 --> URI Class Initialized
INFO - 2016-02-08 10:58:52 --> Router Class Initialized
INFO - 2016-02-08 10:58:52 --> Output Class Initialized
INFO - 2016-02-08 10:58:52 --> Security Class Initialized
DEBUG - 2016-02-08 10:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:58:52 --> Input Class Initialized
INFO - 2016-02-08 10:58:52 --> Language Class Initialized
INFO - 2016-02-08 10:58:52 --> Loader Class Initialized
INFO - 2016-02-08 10:58:52 --> Helper loaded: url_helper
INFO - 2016-02-08 10:58:52 --> Helper loaded: file_helper
INFO - 2016-02-08 10:58:52 --> Helper loaded: date_helper
INFO - 2016-02-08 10:58:52 --> Helper loaded: form_helper
INFO - 2016-02-08 10:58:52 --> Database Driver Class Initialized
INFO - 2016-02-08 10:58:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:58:53 --> Controller Class Initialized
INFO - 2016-02-08 10:58:53 --> Model Class Initialized
INFO - 2016-02-08 10:58:53 --> Model Class Initialized
INFO - 2016-02-08 10:58:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:58:53 --> Pagination Class Initialized
INFO - 2016-02-08 10:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 10:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 10:58:53 --> Helper loaded: text_helper
INFO - 2016-02-08 10:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 10:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 10:58:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 10:58:53 --> Final output sent to browser
DEBUG - 2016-02-08 10:58:53 --> Total execution time: 1.1759
INFO - 2016-02-08 10:58:59 --> Config Class Initialized
INFO - 2016-02-08 10:58:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 10:58:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 10:58:59 --> Utf8 Class Initialized
INFO - 2016-02-08 10:58:59 --> URI Class Initialized
INFO - 2016-02-08 10:58:59 --> Router Class Initialized
INFO - 2016-02-08 10:58:59 --> Output Class Initialized
INFO - 2016-02-08 10:58:59 --> Security Class Initialized
DEBUG - 2016-02-08 10:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 10:58:59 --> Input Class Initialized
INFO - 2016-02-08 10:58:59 --> Language Class Initialized
INFO - 2016-02-08 10:58:59 --> Loader Class Initialized
INFO - 2016-02-08 10:58:59 --> Helper loaded: url_helper
INFO - 2016-02-08 10:58:59 --> Helper loaded: file_helper
INFO - 2016-02-08 10:58:59 --> Helper loaded: date_helper
INFO - 2016-02-08 10:58:59 --> Helper loaded: form_helper
INFO - 2016-02-08 10:58:59 --> Database Driver Class Initialized
INFO - 2016-02-08 10:59:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 10:59:00 --> Controller Class Initialized
INFO - 2016-02-08 10:59:00 --> Model Class Initialized
INFO - 2016-02-08 10:59:00 --> Model Class Initialized
INFO - 2016-02-08 10:59:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 10:59:00 --> Pagination Class Initialized
INFO - 2016-02-08 10:59:00 --> Form Validation Class Initialized
INFO - 2016-02-08 10:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 10:59:00 --> Model Class Initialized
INFO - 2016-02-08 10:59:00 --> Final output sent to browser
DEBUG - 2016-02-08 10:59:00 --> Total execution time: 1.1803
INFO - 2016-02-08 11:02:19 --> Config Class Initialized
INFO - 2016-02-08 11:02:19 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:02:19 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:02:19 --> Utf8 Class Initialized
INFO - 2016-02-08 11:02:19 --> URI Class Initialized
INFO - 2016-02-08 11:02:19 --> Router Class Initialized
INFO - 2016-02-08 11:02:19 --> Output Class Initialized
INFO - 2016-02-08 11:02:19 --> Security Class Initialized
DEBUG - 2016-02-08 11:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:02:19 --> Input Class Initialized
INFO - 2016-02-08 11:02:19 --> Language Class Initialized
INFO - 2016-02-08 11:02:19 --> Loader Class Initialized
INFO - 2016-02-08 11:02:19 --> Helper loaded: url_helper
INFO - 2016-02-08 11:02:19 --> Helper loaded: file_helper
INFO - 2016-02-08 11:02:19 --> Helper loaded: date_helper
INFO - 2016-02-08 11:02:19 --> Helper loaded: form_helper
INFO - 2016-02-08 11:02:19 --> Database Driver Class Initialized
INFO - 2016-02-08 11:02:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:02:20 --> Controller Class Initialized
INFO - 2016-02-08 11:02:20 --> Model Class Initialized
INFO - 2016-02-08 11:02:20 --> Model Class Initialized
INFO - 2016-02-08 11:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:02:20 --> Pagination Class Initialized
INFO - 2016-02-08 11:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:02:20 --> Helper loaded: text_helper
INFO - 2016-02-08 11:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:02:20 --> Final output sent to browser
DEBUG - 2016-02-08 11:02:20 --> Total execution time: 1.2019
INFO - 2016-02-08 11:02:32 --> Config Class Initialized
INFO - 2016-02-08 11:02:32 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:02:32 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:02:32 --> Utf8 Class Initialized
INFO - 2016-02-08 11:02:32 --> URI Class Initialized
INFO - 2016-02-08 11:02:32 --> Router Class Initialized
INFO - 2016-02-08 11:02:32 --> Output Class Initialized
INFO - 2016-02-08 11:02:32 --> Security Class Initialized
DEBUG - 2016-02-08 11:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:02:32 --> Input Class Initialized
INFO - 2016-02-08 11:02:32 --> Language Class Initialized
INFO - 2016-02-08 11:02:32 --> Loader Class Initialized
INFO - 2016-02-08 11:02:32 --> Helper loaded: url_helper
INFO - 2016-02-08 11:02:32 --> Helper loaded: file_helper
INFO - 2016-02-08 11:02:32 --> Helper loaded: date_helper
INFO - 2016-02-08 11:02:32 --> Helper loaded: form_helper
INFO - 2016-02-08 11:02:32 --> Database Driver Class Initialized
INFO - 2016-02-08 11:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:02:33 --> Controller Class Initialized
INFO - 2016-02-08 11:02:33 --> Model Class Initialized
INFO - 2016-02-08 11:02:33 --> Model Class Initialized
INFO - 2016-02-08 11:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:02:33 --> Pagination Class Initialized
INFO - 2016-02-08 11:02:33 --> Form Validation Class Initialized
INFO - 2016-02-08 11:02:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:02:33 --> Model Class Initialized
INFO - 2016-02-08 11:02:33 --> Final output sent to browser
DEBUG - 2016-02-08 11:02:33 --> Total execution time: 1.1649
INFO - 2016-02-08 11:03:37 --> Config Class Initialized
INFO - 2016-02-08 11:03:37 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:03:37 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:03:37 --> Utf8 Class Initialized
INFO - 2016-02-08 11:03:37 --> URI Class Initialized
INFO - 2016-02-08 11:03:37 --> Router Class Initialized
INFO - 2016-02-08 11:03:37 --> Output Class Initialized
INFO - 2016-02-08 11:03:37 --> Security Class Initialized
DEBUG - 2016-02-08 11:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:03:37 --> Input Class Initialized
INFO - 2016-02-08 11:03:37 --> Language Class Initialized
ERROR - 2016-02-08 11:03:37 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 212
INFO - 2016-02-08 11:03:45 --> Config Class Initialized
INFO - 2016-02-08 11:03:45 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:03:45 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:03:45 --> Utf8 Class Initialized
INFO - 2016-02-08 11:03:45 --> URI Class Initialized
INFO - 2016-02-08 11:03:45 --> Router Class Initialized
INFO - 2016-02-08 11:03:45 --> Output Class Initialized
INFO - 2016-02-08 11:03:45 --> Security Class Initialized
DEBUG - 2016-02-08 11:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:03:45 --> Input Class Initialized
INFO - 2016-02-08 11:03:45 --> Language Class Initialized
INFO - 2016-02-08 11:03:45 --> Loader Class Initialized
INFO - 2016-02-08 11:03:45 --> Helper loaded: url_helper
INFO - 2016-02-08 11:03:45 --> Helper loaded: file_helper
INFO - 2016-02-08 11:03:45 --> Helper loaded: date_helper
INFO - 2016-02-08 11:03:45 --> Helper loaded: form_helper
INFO - 2016-02-08 11:03:45 --> Database Driver Class Initialized
INFO - 2016-02-08 11:03:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:03:46 --> Controller Class Initialized
INFO - 2016-02-08 11:03:46 --> Model Class Initialized
INFO - 2016-02-08 11:03:46 --> Model Class Initialized
INFO - 2016-02-08 11:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:03:46 --> Pagination Class Initialized
INFO - 2016-02-08 11:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:03:46 --> Helper loaded: text_helper
INFO - 2016-02-08 11:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:03:46 --> Final output sent to browser
DEBUG - 2016-02-08 11:03:46 --> Total execution time: 1.1688
INFO - 2016-02-08 11:03:53 --> Config Class Initialized
INFO - 2016-02-08 11:03:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:03:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:03:53 --> Utf8 Class Initialized
INFO - 2016-02-08 11:03:53 --> URI Class Initialized
INFO - 2016-02-08 11:03:53 --> Router Class Initialized
INFO - 2016-02-08 11:03:53 --> Output Class Initialized
INFO - 2016-02-08 11:03:53 --> Security Class Initialized
DEBUG - 2016-02-08 11:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:03:53 --> Input Class Initialized
INFO - 2016-02-08 11:03:53 --> Language Class Initialized
INFO - 2016-02-08 11:03:53 --> Loader Class Initialized
INFO - 2016-02-08 11:03:53 --> Helper loaded: url_helper
INFO - 2016-02-08 11:03:53 --> Helper loaded: file_helper
INFO - 2016-02-08 11:03:53 --> Helper loaded: date_helper
INFO - 2016-02-08 11:03:53 --> Helper loaded: form_helper
INFO - 2016-02-08 11:03:53 --> Database Driver Class Initialized
INFO - 2016-02-08 11:03:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:03:54 --> Controller Class Initialized
INFO - 2016-02-08 11:03:54 --> Model Class Initialized
INFO - 2016-02-08 11:03:54 --> Model Class Initialized
INFO - 2016-02-08 11:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:03:54 --> Pagination Class Initialized
INFO - 2016-02-08 11:03:54 --> Form Validation Class Initialized
INFO - 2016-02-08 11:03:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:03:54 --> Model Class Initialized
ERROR - 2016-02-08 11:03:55 --> Severity: Notice --> Undefined variable: json_data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 214
INFO - 2016-02-08 11:03:55 --> Final output sent to browser
DEBUG - 2016-02-08 11:03:55 --> Total execution time: 1.4433
INFO - 2016-02-08 11:04:39 --> Config Class Initialized
INFO - 2016-02-08 11:04:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:04:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:04:39 --> Utf8 Class Initialized
INFO - 2016-02-08 11:04:39 --> URI Class Initialized
INFO - 2016-02-08 11:04:39 --> Router Class Initialized
INFO - 2016-02-08 11:04:39 --> Output Class Initialized
INFO - 2016-02-08 11:04:39 --> Security Class Initialized
DEBUG - 2016-02-08 11:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:04:39 --> Input Class Initialized
INFO - 2016-02-08 11:04:39 --> Language Class Initialized
INFO - 2016-02-08 11:04:39 --> Loader Class Initialized
INFO - 2016-02-08 11:04:39 --> Helper loaded: url_helper
INFO - 2016-02-08 11:04:39 --> Helper loaded: file_helper
INFO - 2016-02-08 11:04:39 --> Helper loaded: date_helper
INFO - 2016-02-08 11:04:39 --> Helper loaded: form_helper
INFO - 2016-02-08 11:04:39 --> Database Driver Class Initialized
INFO - 2016-02-08 11:04:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:04:40 --> Controller Class Initialized
INFO - 2016-02-08 11:04:40 --> Model Class Initialized
INFO - 2016-02-08 11:04:40 --> Model Class Initialized
INFO - 2016-02-08 11:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:04:40 --> Pagination Class Initialized
INFO - 2016-02-08 11:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:04:40 --> Helper loaded: text_helper
INFO - 2016-02-08 11:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:04:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:04:40 --> Final output sent to browser
DEBUG - 2016-02-08 11:04:40 --> Total execution time: 1.1810
INFO - 2016-02-08 11:04:48 --> Config Class Initialized
INFO - 2016-02-08 11:04:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:04:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:04:48 --> Utf8 Class Initialized
INFO - 2016-02-08 11:04:48 --> URI Class Initialized
INFO - 2016-02-08 11:04:48 --> Router Class Initialized
INFO - 2016-02-08 11:04:48 --> Output Class Initialized
INFO - 2016-02-08 11:04:48 --> Security Class Initialized
DEBUG - 2016-02-08 11:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:04:48 --> Input Class Initialized
INFO - 2016-02-08 11:04:48 --> Language Class Initialized
INFO - 2016-02-08 11:04:48 --> Loader Class Initialized
INFO - 2016-02-08 11:04:48 --> Helper loaded: url_helper
INFO - 2016-02-08 11:04:48 --> Helper loaded: file_helper
INFO - 2016-02-08 11:04:48 --> Helper loaded: date_helper
INFO - 2016-02-08 11:04:48 --> Helper loaded: form_helper
INFO - 2016-02-08 11:04:48 --> Database Driver Class Initialized
INFO - 2016-02-08 11:04:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:04:49 --> Controller Class Initialized
INFO - 2016-02-08 11:04:49 --> Model Class Initialized
INFO - 2016-02-08 11:04:49 --> Model Class Initialized
INFO - 2016-02-08 11:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:04:49 --> Pagination Class Initialized
INFO - 2016-02-08 11:04:49 --> Form Validation Class Initialized
INFO - 2016-02-08 11:04:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:04:49 --> Model Class Initialized
ERROR - 2016-02-08 11:04:49 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 214
INFO - 2016-02-08 11:04:49 --> Final output sent to browser
DEBUG - 2016-02-08 11:04:49 --> Total execution time: 1.4527
INFO - 2016-02-08 11:19:36 --> Config Class Initialized
INFO - 2016-02-08 11:19:36 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:19:36 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:19:36 --> Utf8 Class Initialized
INFO - 2016-02-08 11:19:36 --> URI Class Initialized
INFO - 2016-02-08 11:19:36 --> Router Class Initialized
INFO - 2016-02-08 11:19:36 --> Output Class Initialized
INFO - 2016-02-08 11:19:36 --> Security Class Initialized
DEBUG - 2016-02-08 11:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:19:36 --> Input Class Initialized
INFO - 2016-02-08 11:19:36 --> Language Class Initialized
INFO - 2016-02-08 11:19:36 --> Loader Class Initialized
INFO - 2016-02-08 11:19:36 --> Helper loaded: url_helper
INFO - 2016-02-08 11:19:36 --> Helper loaded: file_helper
INFO - 2016-02-08 11:19:36 --> Helper loaded: date_helper
INFO - 2016-02-08 11:19:36 --> Helper loaded: form_helper
INFO - 2016-02-08 11:19:36 --> Database Driver Class Initialized
INFO - 2016-02-08 11:19:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:19:37 --> Controller Class Initialized
INFO - 2016-02-08 11:19:37 --> Model Class Initialized
INFO - 2016-02-08 11:19:37 --> Model Class Initialized
INFO - 2016-02-08 11:19:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:19:37 --> Pagination Class Initialized
INFO - 2016-02-08 11:19:37 --> Form Validation Class Initialized
INFO - 2016-02-08 11:19:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:19:37 --> Final output sent to browser
DEBUG - 2016-02-08 11:19:37 --> Total execution time: 1.1113
INFO - 2016-02-08 11:19:38 --> Config Class Initialized
INFO - 2016-02-08 11:19:38 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:19:38 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:19:38 --> Utf8 Class Initialized
INFO - 2016-02-08 11:19:38 --> URI Class Initialized
INFO - 2016-02-08 11:19:38 --> Router Class Initialized
INFO - 2016-02-08 11:19:38 --> Output Class Initialized
INFO - 2016-02-08 11:19:38 --> Security Class Initialized
DEBUG - 2016-02-08 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:19:38 --> Input Class Initialized
INFO - 2016-02-08 11:19:38 --> Language Class Initialized
INFO - 2016-02-08 11:19:38 --> Loader Class Initialized
INFO - 2016-02-08 11:19:38 --> Helper loaded: url_helper
INFO - 2016-02-08 11:19:38 --> Helper loaded: file_helper
INFO - 2016-02-08 11:19:38 --> Helper loaded: date_helper
INFO - 2016-02-08 11:19:38 --> Helper loaded: form_helper
INFO - 2016-02-08 11:19:38 --> Database Driver Class Initialized
INFO - 2016-02-08 11:19:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:19:39 --> Controller Class Initialized
INFO - 2016-02-08 11:19:39 --> Model Class Initialized
INFO - 2016-02-08 11:19:39 --> Model Class Initialized
INFO - 2016-02-08 11:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:19:39 --> Pagination Class Initialized
INFO - 2016-02-08 11:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:19:39 --> Helper loaded: text_helper
INFO - 2016-02-08 11:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:19:39 --> Final output sent to browser
DEBUG - 2016-02-08 11:19:39 --> Total execution time: 1.2053
INFO - 2016-02-08 11:19:42 --> Config Class Initialized
INFO - 2016-02-08 11:19:42 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:19:42 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:19:42 --> Utf8 Class Initialized
INFO - 2016-02-08 11:19:42 --> URI Class Initialized
INFO - 2016-02-08 11:19:42 --> Router Class Initialized
INFO - 2016-02-08 11:19:42 --> Output Class Initialized
INFO - 2016-02-08 11:19:42 --> Security Class Initialized
DEBUG - 2016-02-08 11:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:19:42 --> Input Class Initialized
INFO - 2016-02-08 11:19:42 --> Language Class Initialized
INFO - 2016-02-08 11:19:42 --> Loader Class Initialized
INFO - 2016-02-08 11:19:42 --> Helper loaded: url_helper
INFO - 2016-02-08 11:19:42 --> Helper loaded: file_helper
INFO - 2016-02-08 11:19:42 --> Helper loaded: date_helper
INFO - 2016-02-08 11:19:42 --> Helper loaded: form_helper
INFO - 2016-02-08 11:19:42 --> Database Driver Class Initialized
INFO - 2016-02-08 11:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:19:43 --> Controller Class Initialized
INFO - 2016-02-08 11:19:43 --> Model Class Initialized
INFO - 2016-02-08 11:19:43 --> Model Class Initialized
INFO - 2016-02-08 11:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:19:43 --> Pagination Class Initialized
INFO - 2016-02-08 11:19:43 --> Form Validation Class Initialized
INFO - 2016-02-08 11:19:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:19:43 --> Final output sent to browser
DEBUG - 2016-02-08 11:19:43 --> Total execution time: 1.1180
INFO - 2016-02-08 11:19:44 --> Config Class Initialized
INFO - 2016-02-08 11:19:44 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:19:44 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:19:44 --> Utf8 Class Initialized
INFO - 2016-02-08 11:19:44 --> URI Class Initialized
INFO - 2016-02-08 11:19:44 --> Router Class Initialized
INFO - 2016-02-08 11:19:44 --> Output Class Initialized
INFO - 2016-02-08 11:19:44 --> Security Class Initialized
DEBUG - 2016-02-08 11:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:19:44 --> Input Class Initialized
INFO - 2016-02-08 11:19:44 --> Language Class Initialized
INFO - 2016-02-08 11:19:44 --> Loader Class Initialized
INFO - 2016-02-08 11:19:44 --> Helper loaded: url_helper
INFO - 2016-02-08 11:19:44 --> Helper loaded: file_helper
INFO - 2016-02-08 11:19:44 --> Helper loaded: date_helper
INFO - 2016-02-08 11:19:44 --> Helper loaded: form_helper
INFO - 2016-02-08 11:19:44 --> Database Driver Class Initialized
INFO - 2016-02-08 11:19:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:19:45 --> Controller Class Initialized
INFO - 2016-02-08 11:19:45 --> Model Class Initialized
INFO - 2016-02-08 11:19:45 --> Model Class Initialized
INFO - 2016-02-08 11:19:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:19:45 --> Pagination Class Initialized
INFO - 2016-02-08 11:19:45 --> Form Validation Class Initialized
INFO - 2016-02-08 11:19:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:19:45 --> Final output sent to browser
DEBUG - 2016-02-08 11:19:45 --> Total execution time: 1.1135
INFO - 2016-02-08 11:20:48 --> Config Class Initialized
INFO - 2016-02-08 11:20:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:20:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:20:48 --> Utf8 Class Initialized
INFO - 2016-02-08 11:20:48 --> URI Class Initialized
INFO - 2016-02-08 11:20:48 --> Router Class Initialized
INFO - 2016-02-08 11:20:48 --> Output Class Initialized
INFO - 2016-02-08 11:20:48 --> Security Class Initialized
DEBUG - 2016-02-08 11:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:20:48 --> Input Class Initialized
INFO - 2016-02-08 11:20:48 --> Language Class Initialized
INFO - 2016-02-08 11:20:48 --> Loader Class Initialized
INFO - 2016-02-08 11:20:48 --> Helper loaded: url_helper
INFO - 2016-02-08 11:20:48 --> Helper loaded: file_helper
INFO - 2016-02-08 11:20:48 --> Helper loaded: date_helper
INFO - 2016-02-08 11:20:48 --> Helper loaded: form_helper
INFO - 2016-02-08 11:20:48 --> Database Driver Class Initialized
INFO - 2016-02-08 11:20:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:20:49 --> Controller Class Initialized
INFO - 2016-02-08 11:20:49 --> Model Class Initialized
INFO - 2016-02-08 11:20:49 --> Model Class Initialized
INFO - 2016-02-08 11:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:20:49 --> Pagination Class Initialized
INFO - 2016-02-08 11:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:20:49 --> Helper loaded: text_helper
INFO - 2016-02-08 11:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:20:49 --> Final output sent to browser
DEBUG - 2016-02-08 11:20:49 --> Total execution time: 1.2014
INFO - 2016-02-08 11:21:31 --> Config Class Initialized
INFO - 2016-02-08 11:21:31 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:21:31 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:21:31 --> Utf8 Class Initialized
INFO - 2016-02-08 11:21:31 --> URI Class Initialized
INFO - 2016-02-08 11:21:31 --> Router Class Initialized
INFO - 2016-02-08 11:21:31 --> Output Class Initialized
INFO - 2016-02-08 11:21:31 --> Security Class Initialized
DEBUG - 2016-02-08 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:21:31 --> Input Class Initialized
INFO - 2016-02-08 11:21:31 --> Language Class Initialized
INFO - 2016-02-08 11:21:32 --> Loader Class Initialized
INFO - 2016-02-08 11:21:32 --> Helper loaded: url_helper
INFO - 2016-02-08 11:21:32 --> Helper loaded: file_helper
INFO - 2016-02-08 11:21:32 --> Helper loaded: date_helper
INFO - 2016-02-08 11:21:32 --> Helper loaded: form_helper
INFO - 2016-02-08 11:21:32 --> Database Driver Class Initialized
INFO - 2016-02-08 11:21:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:21:33 --> Controller Class Initialized
INFO - 2016-02-08 11:21:33 --> Model Class Initialized
INFO - 2016-02-08 11:21:33 --> Model Class Initialized
INFO - 2016-02-08 11:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:21:33 --> Pagination Class Initialized
INFO - 2016-02-08 11:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:21:33 --> Helper loaded: text_helper
INFO - 2016-02-08 11:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:21:33 --> Final output sent to browser
DEBUG - 2016-02-08 11:21:33 --> Total execution time: 1.2344
INFO - 2016-02-08 11:21:34 --> Config Class Initialized
INFO - 2016-02-08 11:21:34 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:21:34 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:21:34 --> Utf8 Class Initialized
INFO - 2016-02-08 11:21:34 --> URI Class Initialized
INFO - 2016-02-08 11:21:34 --> Router Class Initialized
INFO - 2016-02-08 11:21:34 --> Output Class Initialized
INFO - 2016-02-08 11:21:34 --> Security Class Initialized
DEBUG - 2016-02-08 11:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:21:34 --> Input Class Initialized
INFO - 2016-02-08 11:21:34 --> Language Class Initialized
INFO - 2016-02-08 11:21:34 --> Loader Class Initialized
INFO - 2016-02-08 11:21:34 --> Helper loaded: url_helper
INFO - 2016-02-08 11:21:34 --> Helper loaded: file_helper
INFO - 2016-02-08 11:21:34 --> Helper loaded: date_helper
INFO - 2016-02-08 11:21:34 --> Helper loaded: form_helper
INFO - 2016-02-08 11:21:34 --> Database Driver Class Initialized
INFO - 2016-02-08 11:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:21:35 --> Controller Class Initialized
INFO - 2016-02-08 11:21:35 --> Model Class Initialized
INFO - 2016-02-08 11:21:35 --> Model Class Initialized
INFO - 2016-02-08 11:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:21:35 --> Pagination Class Initialized
INFO - 2016-02-08 11:21:35 --> Form Validation Class Initialized
INFO - 2016-02-08 11:21:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:21:35 --> Final output sent to browser
DEBUG - 2016-02-08 11:21:35 --> Total execution time: 1.1305
INFO - 2016-02-08 11:22:43 --> Config Class Initialized
INFO - 2016-02-08 11:22:43 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:22:43 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:22:43 --> Utf8 Class Initialized
INFO - 2016-02-08 11:22:43 --> URI Class Initialized
INFO - 2016-02-08 11:22:43 --> Router Class Initialized
INFO - 2016-02-08 11:22:43 --> Output Class Initialized
INFO - 2016-02-08 11:22:43 --> Security Class Initialized
DEBUG - 2016-02-08 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:22:43 --> Input Class Initialized
INFO - 2016-02-08 11:22:43 --> Language Class Initialized
INFO - 2016-02-08 11:22:43 --> Loader Class Initialized
INFO - 2016-02-08 11:22:43 --> Helper loaded: url_helper
INFO - 2016-02-08 11:22:43 --> Helper loaded: file_helper
INFO - 2016-02-08 11:22:43 --> Helper loaded: date_helper
INFO - 2016-02-08 11:22:43 --> Helper loaded: form_helper
INFO - 2016-02-08 11:22:43 --> Database Driver Class Initialized
INFO - 2016-02-08 11:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:22:44 --> Controller Class Initialized
INFO - 2016-02-08 11:22:44 --> Model Class Initialized
INFO - 2016-02-08 11:22:44 --> Model Class Initialized
INFO - 2016-02-08 11:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:22:44 --> Pagination Class Initialized
INFO - 2016-02-08 11:22:44 --> Form Validation Class Initialized
INFO - 2016-02-08 11:22:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:22:44 --> Final output sent to browser
DEBUG - 2016-02-08 11:22:44 --> Total execution time: 1.1338
INFO - 2016-02-08 11:22:47 --> Config Class Initialized
INFO - 2016-02-08 11:22:47 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:22:47 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:22:47 --> Utf8 Class Initialized
INFO - 2016-02-08 11:22:47 --> URI Class Initialized
INFO - 2016-02-08 11:22:47 --> Router Class Initialized
INFO - 2016-02-08 11:22:47 --> Output Class Initialized
INFO - 2016-02-08 11:22:47 --> Security Class Initialized
DEBUG - 2016-02-08 11:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:22:47 --> Input Class Initialized
INFO - 2016-02-08 11:22:47 --> Language Class Initialized
INFO - 2016-02-08 11:22:47 --> Loader Class Initialized
INFO - 2016-02-08 11:22:47 --> Helper loaded: url_helper
INFO - 2016-02-08 11:22:47 --> Helper loaded: file_helper
INFO - 2016-02-08 11:22:47 --> Helper loaded: date_helper
INFO - 2016-02-08 11:22:47 --> Helper loaded: form_helper
INFO - 2016-02-08 11:22:47 --> Database Driver Class Initialized
INFO - 2016-02-08 11:22:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:22:48 --> Controller Class Initialized
INFO - 2016-02-08 11:22:48 --> Model Class Initialized
INFO - 2016-02-08 11:22:48 --> Model Class Initialized
INFO - 2016-02-08 11:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:22:48 --> Pagination Class Initialized
INFO - 2016-02-08 11:22:48 --> Form Validation Class Initialized
INFO - 2016-02-08 11:22:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:22:48 --> Final output sent to browser
DEBUG - 2016-02-08 11:22:48 --> Total execution time: 1.0939
INFO - 2016-02-08 11:24:56 --> Config Class Initialized
INFO - 2016-02-08 11:24:57 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:24:57 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:24:57 --> Utf8 Class Initialized
INFO - 2016-02-08 11:24:57 --> URI Class Initialized
INFO - 2016-02-08 11:24:57 --> Router Class Initialized
INFO - 2016-02-08 11:24:57 --> Output Class Initialized
INFO - 2016-02-08 11:24:57 --> Security Class Initialized
DEBUG - 2016-02-08 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:24:57 --> Input Class Initialized
INFO - 2016-02-08 11:24:57 --> Language Class Initialized
INFO - 2016-02-08 11:24:57 --> Loader Class Initialized
INFO - 2016-02-08 11:24:57 --> Helper loaded: url_helper
INFO - 2016-02-08 11:24:57 --> Helper loaded: file_helper
INFO - 2016-02-08 11:24:57 --> Helper loaded: date_helper
INFO - 2016-02-08 11:24:57 --> Helper loaded: form_helper
INFO - 2016-02-08 11:24:57 --> Database Driver Class Initialized
INFO - 2016-02-08 11:24:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:24:58 --> Controller Class Initialized
INFO - 2016-02-08 11:24:58 --> Model Class Initialized
INFO - 2016-02-08 11:24:58 --> Model Class Initialized
INFO - 2016-02-08 11:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:24:58 --> Pagination Class Initialized
INFO - 2016-02-08 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:24:58 --> Helper loaded: text_helper
INFO - 2016-02-08 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:24:58 --> Final output sent to browser
DEBUG - 2016-02-08 11:24:58 --> Total execution time: 1.2033
INFO - 2016-02-08 11:24:59 --> Config Class Initialized
INFO - 2016-02-08 11:24:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:24:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:24:59 --> Utf8 Class Initialized
INFO - 2016-02-08 11:24:59 --> URI Class Initialized
INFO - 2016-02-08 11:24:59 --> Router Class Initialized
INFO - 2016-02-08 11:24:59 --> Output Class Initialized
INFO - 2016-02-08 11:24:59 --> Security Class Initialized
DEBUG - 2016-02-08 11:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:24:59 --> Input Class Initialized
INFO - 2016-02-08 11:24:59 --> Language Class Initialized
INFO - 2016-02-08 11:24:59 --> Loader Class Initialized
INFO - 2016-02-08 11:24:59 --> Helper loaded: url_helper
INFO - 2016-02-08 11:24:59 --> Helper loaded: file_helper
INFO - 2016-02-08 11:24:59 --> Helper loaded: date_helper
INFO - 2016-02-08 11:24:59 --> Helper loaded: form_helper
INFO - 2016-02-08 11:24:59 --> Database Driver Class Initialized
INFO - 2016-02-08 11:25:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:25:00 --> Controller Class Initialized
INFO - 2016-02-08 11:25:00 --> Model Class Initialized
INFO - 2016-02-08 11:25:00 --> Model Class Initialized
INFO - 2016-02-08 11:25:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:25:00 --> Pagination Class Initialized
INFO - 2016-02-08 11:25:01 --> Form Validation Class Initialized
INFO - 2016-02-08 11:25:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:25:01 --> Final output sent to browser
DEBUG - 2016-02-08 11:25:01 --> Total execution time: 1.1229
INFO - 2016-02-08 11:26:55 --> Config Class Initialized
INFO - 2016-02-08 11:26:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:26:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:26:55 --> Utf8 Class Initialized
INFO - 2016-02-08 11:26:55 --> URI Class Initialized
INFO - 2016-02-08 11:26:55 --> Router Class Initialized
INFO - 2016-02-08 11:26:55 --> Output Class Initialized
INFO - 2016-02-08 11:26:55 --> Security Class Initialized
DEBUG - 2016-02-08 11:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:26:55 --> Input Class Initialized
INFO - 2016-02-08 11:26:55 --> Language Class Initialized
INFO - 2016-02-08 11:26:55 --> Loader Class Initialized
INFO - 2016-02-08 11:26:55 --> Helper loaded: url_helper
INFO - 2016-02-08 11:26:55 --> Helper loaded: file_helper
INFO - 2016-02-08 11:26:55 --> Helper loaded: date_helper
INFO - 2016-02-08 11:26:55 --> Helper loaded: form_helper
INFO - 2016-02-08 11:26:55 --> Database Driver Class Initialized
INFO - 2016-02-08 11:26:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:26:56 --> Controller Class Initialized
INFO - 2016-02-08 11:26:56 --> Model Class Initialized
INFO - 2016-02-08 11:26:56 --> Model Class Initialized
INFO - 2016-02-08 11:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:26:56 --> Pagination Class Initialized
INFO - 2016-02-08 11:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:26:56 --> Helper loaded: text_helper
INFO - 2016-02-08 11:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:26:56 --> Final output sent to browser
DEBUG - 2016-02-08 11:26:56 --> Total execution time: 1.1336
INFO - 2016-02-08 11:27:00 --> Config Class Initialized
INFO - 2016-02-08 11:27:00 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:27:00 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:27:00 --> Utf8 Class Initialized
INFO - 2016-02-08 11:27:00 --> URI Class Initialized
INFO - 2016-02-08 11:27:00 --> Router Class Initialized
INFO - 2016-02-08 11:27:00 --> Output Class Initialized
INFO - 2016-02-08 11:27:00 --> Security Class Initialized
DEBUG - 2016-02-08 11:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:27:00 --> Input Class Initialized
INFO - 2016-02-08 11:27:00 --> Language Class Initialized
INFO - 2016-02-08 11:27:00 --> Loader Class Initialized
INFO - 2016-02-08 11:27:00 --> Helper loaded: url_helper
INFO - 2016-02-08 11:27:00 --> Helper loaded: file_helper
INFO - 2016-02-08 11:27:00 --> Helper loaded: date_helper
INFO - 2016-02-08 11:27:00 --> Helper loaded: form_helper
INFO - 2016-02-08 11:27:00 --> Database Driver Class Initialized
INFO - 2016-02-08 11:27:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:27:01 --> Controller Class Initialized
INFO - 2016-02-08 11:27:01 --> Model Class Initialized
INFO - 2016-02-08 11:27:01 --> Model Class Initialized
INFO - 2016-02-08 11:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:27:01 --> Pagination Class Initialized
INFO - 2016-02-08 11:27:01 --> Form Validation Class Initialized
INFO - 2016-02-08 11:27:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:27:01 --> Final output sent to browser
DEBUG - 2016-02-08 11:27:01 --> Total execution time: 1.1183
INFO - 2016-02-08 11:27:07 --> Config Class Initialized
INFO - 2016-02-08 11:27:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:27:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:27:07 --> Utf8 Class Initialized
INFO - 2016-02-08 11:27:07 --> URI Class Initialized
INFO - 2016-02-08 11:27:07 --> Router Class Initialized
INFO - 2016-02-08 11:27:07 --> Output Class Initialized
INFO - 2016-02-08 11:27:07 --> Security Class Initialized
DEBUG - 2016-02-08 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:27:07 --> Input Class Initialized
INFO - 2016-02-08 11:27:07 --> Language Class Initialized
INFO - 2016-02-08 11:27:07 --> Loader Class Initialized
INFO - 2016-02-08 11:27:07 --> Helper loaded: url_helper
INFO - 2016-02-08 11:27:07 --> Helper loaded: file_helper
INFO - 2016-02-08 11:27:07 --> Helper loaded: date_helper
INFO - 2016-02-08 11:27:07 --> Helper loaded: form_helper
INFO - 2016-02-08 11:27:07 --> Database Driver Class Initialized
INFO - 2016-02-08 11:27:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:27:08 --> Controller Class Initialized
INFO - 2016-02-08 11:27:08 --> Model Class Initialized
INFO - 2016-02-08 11:27:08 --> Model Class Initialized
INFO - 2016-02-08 11:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:27:08 --> Pagination Class Initialized
INFO - 2016-02-08 11:27:08 --> Form Validation Class Initialized
INFO - 2016-02-08 11:27:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:27:08 --> Final output sent to browser
DEBUG - 2016-02-08 11:27:08 --> Total execution time: 1.1129
INFO - 2016-02-08 11:29:26 --> Config Class Initialized
INFO - 2016-02-08 11:29:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:29:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:29:26 --> Utf8 Class Initialized
INFO - 2016-02-08 11:29:26 --> URI Class Initialized
INFO - 2016-02-08 11:29:26 --> Router Class Initialized
INFO - 2016-02-08 11:29:26 --> Output Class Initialized
INFO - 2016-02-08 11:29:26 --> Security Class Initialized
DEBUG - 2016-02-08 11:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:29:26 --> Input Class Initialized
INFO - 2016-02-08 11:29:26 --> Language Class Initialized
INFO - 2016-02-08 11:29:26 --> Loader Class Initialized
INFO - 2016-02-08 11:29:26 --> Helper loaded: url_helper
INFO - 2016-02-08 11:29:26 --> Helper loaded: file_helper
INFO - 2016-02-08 11:29:26 --> Helper loaded: date_helper
INFO - 2016-02-08 11:29:26 --> Helper loaded: form_helper
INFO - 2016-02-08 11:29:26 --> Database Driver Class Initialized
INFO - 2016-02-08 11:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:29:27 --> Controller Class Initialized
INFO - 2016-02-08 11:29:27 --> Model Class Initialized
INFO - 2016-02-08 11:29:27 --> Model Class Initialized
INFO - 2016-02-08 11:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:29:27 --> Pagination Class Initialized
INFO - 2016-02-08 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:29:27 --> Helper loaded: text_helper
INFO - 2016-02-08 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:29:27 --> Final output sent to browser
DEBUG - 2016-02-08 11:29:27 --> Total execution time: 1.1992
INFO - 2016-02-08 11:29:35 --> Config Class Initialized
INFO - 2016-02-08 11:29:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:29:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:29:35 --> Utf8 Class Initialized
INFO - 2016-02-08 11:29:35 --> URI Class Initialized
INFO - 2016-02-08 11:29:35 --> Router Class Initialized
INFO - 2016-02-08 11:29:35 --> Output Class Initialized
INFO - 2016-02-08 11:29:35 --> Security Class Initialized
DEBUG - 2016-02-08 11:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:29:35 --> Input Class Initialized
INFO - 2016-02-08 11:29:35 --> Language Class Initialized
INFO - 2016-02-08 11:29:35 --> Loader Class Initialized
INFO - 2016-02-08 11:29:35 --> Helper loaded: url_helper
INFO - 2016-02-08 11:29:35 --> Helper loaded: file_helper
INFO - 2016-02-08 11:29:35 --> Helper loaded: date_helper
INFO - 2016-02-08 11:29:35 --> Helper loaded: form_helper
INFO - 2016-02-08 11:29:35 --> Database Driver Class Initialized
INFO - 2016-02-08 11:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:29:36 --> Controller Class Initialized
INFO - 2016-02-08 11:29:36 --> Model Class Initialized
INFO - 2016-02-08 11:29:36 --> Model Class Initialized
INFO - 2016-02-08 11:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:29:36 --> Pagination Class Initialized
INFO - 2016-02-08 11:29:36 --> Form Validation Class Initialized
INFO - 2016-02-08 11:29:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:29:36 --> Model Class Initialized
ERROR - 2016-02-08 11:29:37 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 214
INFO - 2016-02-08 11:29:37 --> Final output sent to browser
DEBUG - 2016-02-08 11:29:37 --> Total execution time: 1.2024
INFO - 2016-02-08 11:32:24 --> Config Class Initialized
INFO - 2016-02-08 11:32:24 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:32:24 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:32:24 --> Utf8 Class Initialized
INFO - 2016-02-08 11:32:24 --> URI Class Initialized
INFO - 2016-02-08 11:32:24 --> Router Class Initialized
INFO - 2016-02-08 11:32:24 --> Output Class Initialized
INFO - 2016-02-08 11:32:24 --> Security Class Initialized
DEBUG - 2016-02-08 11:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:32:24 --> Input Class Initialized
INFO - 2016-02-08 11:32:24 --> Language Class Initialized
ERROR - 2016-02-08 11:32:24 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
INFO - 2016-02-08 11:36:06 --> Config Class Initialized
INFO - 2016-02-08 11:36:06 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:36:06 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:36:06 --> Utf8 Class Initialized
INFO - 2016-02-08 11:36:06 --> URI Class Initialized
INFO - 2016-02-08 11:36:06 --> Router Class Initialized
INFO - 2016-02-08 11:36:06 --> Output Class Initialized
INFO - 2016-02-08 11:36:06 --> Security Class Initialized
DEBUG - 2016-02-08 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:36:06 --> Input Class Initialized
INFO - 2016-02-08 11:36:06 --> Language Class Initialized
ERROR - 2016-02-08 11:36:06 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
INFO - 2016-02-08 11:36:08 --> Config Class Initialized
INFO - 2016-02-08 11:36:08 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:36:08 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:36:08 --> Utf8 Class Initialized
INFO - 2016-02-08 11:36:08 --> URI Class Initialized
INFO - 2016-02-08 11:36:08 --> Router Class Initialized
INFO - 2016-02-08 11:36:08 --> Output Class Initialized
INFO - 2016-02-08 11:36:08 --> Security Class Initialized
DEBUG - 2016-02-08 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:36:08 --> Input Class Initialized
INFO - 2016-02-08 11:36:08 --> Language Class Initialized
ERROR - 2016-02-08 11:36:08 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
INFO - 2016-02-08 11:37:26 --> Config Class Initialized
INFO - 2016-02-08 11:37:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:37:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:37:26 --> Utf8 Class Initialized
INFO - 2016-02-08 11:37:26 --> URI Class Initialized
INFO - 2016-02-08 11:37:26 --> Router Class Initialized
INFO - 2016-02-08 11:37:26 --> Output Class Initialized
INFO - 2016-02-08 11:37:26 --> Security Class Initialized
DEBUG - 2016-02-08 11:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:37:26 --> Input Class Initialized
INFO - 2016-02-08 11:37:26 --> Language Class Initialized
ERROR - 2016-02-08 11:37:26 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
INFO - 2016-02-08 11:37:39 --> Config Class Initialized
INFO - 2016-02-08 11:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:37:39 --> Utf8 Class Initialized
INFO - 2016-02-08 11:37:39 --> URI Class Initialized
INFO - 2016-02-08 11:37:39 --> Router Class Initialized
INFO - 2016-02-08 11:37:39 --> Output Class Initialized
INFO - 2016-02-08 11:37:39 --> Security Class Initialized
DEBUG - 2016-02-08 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:37:39 --> Input Class Initialized
INFO - 2016-02-08 11:37:39 --> Language Class Initialized
ERROR - 2016-02-08 11:37:39 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 219
INFO - 2016-02-08 11:45:17 --> Config Class Initialized
INFO - 2016-02-08 11:45:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:45:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:45:17 --> Utf8 Class Initialized
INFO - 2016-02-08 11:45:17 --> URI Class Initialized
INFO - 2016-02-08 11:45:17 --> Router Class Initialized
INFO - 2016-02-08 11:45:17 --> Output Class Initialized
INFO - 2016-02-08 11:45:17 --> Security Class Initialized
DEBUG - 2016-02-08 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:45:17 --> Input Class Initialized
INFO - 2016-02-08 11:45:17 --> Language Class Initialized
INFO - 2016-02-08 11:45:17 --> Loader Class Initialized
INFO - 2016-02-08 11:45:17 --> Helper loaded: url_helper
INFO - 2016-02-08 11:45:17 --> Helper loaded: file_helper
INFO - 2016-02-08 11:45:17 --> Helper loaded: date_helper
INFO - 2016-02-08 11:45:17 --> Helper loaded: form_helper
INFO - 2016-02-08 11:45:17 --> Database Driver Class Initialized
INFO - 2016-02-08 11:45:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:45:19 --> Controller Class Initialized
INFO - 2016-02-08 11:45:19 --> Model Class Initialized
INFO - 2016-02-08 11:45:19 --> Model Class Initialized
INFO - 2016-02-08 11:45:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:45:19 --> Pagination Class Initialized
INFO - 2016-02-08 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:45:19 --> Helper loaded: text_helper
INFO - 2016-02-08 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:45:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:45:19 --> Final output sent to browser
DEBUG - 2016-02-08 11:45:19 --> Total execution time: 1.2604
INFO - 2016-02-08 11:45:32 --> Config Class Initialized
INFO - 2016-02-08 11:45:32 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:45:32 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:45:32 --> Utf8 Class Initialized
INFO - 2016-02-08 11:45:32 --> URI Class Initialized
INFO - 2016-02-08 11:45:32 --> Router Class Initialized
INFO - 2016-02-08 11:45:32 --> Output Class Initialized
INFO - 2016-02-08 11:45:32 --> Security Class Initialized
DEBUG - 2016-02-08 11:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:45:32 --> Input Class Initialized
INFO - 2016-02-08 11:45:32 --> Language Class Initialized
INFO - 2016-02-08 11:45:32 --> Loader Class Initialized
INFO - 2016-02-08 11:45:32 --> Helper loaded: url_helper
INFO - 2016-02-08 11:45:32 --> Helper loaded: file_helper
INFO - 2016-02-08 11:45:32 --> Helper loaded: date_helper
INFO - 2016-02-08 11:45:32 --> Helper loaded: form_helper
INFO - 2016-02-08 11:45:32 --> Database Driver Class Initialized
INFO - 2016-02-08 11:45:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:45:33 --> Controller Class Initialized
INFO - 2016-02-08 11:45:33 --> Model Class Initialized
INFO - 2016-02-08 11:45:33 --> Model Class Initialized
INFO - 2016-02-08 11:45:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:45:33 --> Pagination Class Initialized
INFO - 2016-02-08 11:45:33 --> Form Validation Class Initialized
INFO - 2016-02-08 11:45:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:45:33 --> Model Class Initialized
INFO - 2016-02-08 11:45:33 --> Final output sent to browser
DEBUG - 2016-02-08 11:45:33 --> Total execution time: 1.2121
INFO - 2016-02-08 11:47:45 --> Config Class Initialized
INFO - 2016-02-08 11:47:45 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:47:45 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:47:45 --> Utf8 Class Initialized
INFO - 2016-02-08 11:47:45 --> URI Class Initialized
INFO - 2016-02-08 11:47:45 --> Router Class Initialized
INFO - 2016-02-08 11:47:45 --> Output Class Initialized
INFO - 2016-02-08 11:47:45 --> Security Class Initialized
DEBUG - 2016-02-08 11:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:47:45 --> Input Class Initialized
INFO - 2016-02-08 11:47:45 --> Language Class Initialized
INFO - 2016-02-08 11:47:45 --> Loader Class Initialized
INFO - 2016-02-08 11:47:45 --> Helper loaded: url_helper
INFO - 2016-02-08 11:47:45 --> Helper loaded: file_helper
INFO - 2016-02-08 11:47:45 --> Helper loaded: date_helper
INFO - 2016-02-08 11:47:45 --> Helper loaded: form_helper
INFO - 2016-02-08 11:47:45 --> Database Driver Class Initialized
INFO - 2016-02-08 11:47:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:47:46 --> Controller Class Initialized
INFO - 2016-02-08 11:47:46 --> Model Class Initialized
INFO - 2016-02-08 11:47:46 --> Model Class Initialized
INFO - 2016-02-08 11:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:47:46 --> Pagination Class Initialized
INFO - 2016-02-08 11:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:47:46 --> Helper loaded: text_helper
INFO - 2016-02-08 11:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:47:46 --> Final output sent to browser
DEBUG - 2016-02-08 11:47:46 --> Total execution time: 1.1920
INFO - 2016-02-08 11:47:51 --> Config Class Initialized
INFO - 2016-02-08 11:47:51 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:47:51 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:47:51 --> Utf8 Class Initialized
INFO - 2016-02-08 11:47:51 --> URI Class Initialized
INFO - 2016-02-08 11:47:51 --> Router Class Initialized
INFO - 2016-02-08 11:47:51 --> Output Class Initialized
INFO - 2016-02-08 11:47:51 --> Security Class Initialized
DEBUG - 2016-02-08 11:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:47:51 --> Input Class Initialized
INFO - 2016-02-08 11:47:51 --> Language Class Initialized
INFO - 2016-02-08 11:47:51 --> Loader Class Initialized
INFO - 2016-02-08 11:47:51 --> Helper loaded: url_helper
INFO - 2016-02-08 11:47:51 --> Helper loaded: file_helper
INFO - 2016-02-08 11:47:51 --> Helper loaded: date_helper
INFO - 2016-02-08 11:47:51 --> Helper loaded: form_helper
INFO - 2016-02-08 11:47:51 --> Database Driver Class Initialized
INFO - 2016-02-08 11:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:47:52 --> Controller Class Initialized
INFO - 2016-02-08 11:47:52 --> Model Class Initialized
INFO - 2016-02-08 11:47:52 --> Model Class Initialized
INFO - 2016-02-08 11:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:47:52 --> Pagination Class Initialized
INFO - 2016-02-08 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:47:52 --> Helper loaded: text_helper
INFO - 2016-02-08 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:47:52 --> Final output sent to browser
DEBUG - 2016-02-08 11:47:52 --> Total execution time: 1.2015
INFO - 2016-02-08 11:47:57 --> Config Class Initialized
INFO - 2016-02-08 11:47:57 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:47:57 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:47:57 --> Utf8 Class Initialized
INFO - 2016-02-08 11:47:57 --> URI Class Initialized
INFO - 2016-02-08 11:47:57 --> Router Class Initialized
INFO - 2016-02-08 11:47:57 --> Output Class Initialized
INFO - 2016-02-08 11:47:57 --> Security Class Initialized
DEBUG - 2016-02-08 11:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:47:57 --> Input Class Initialized
INFO - 2016-02-08 11:47:57 --> Language Class Initialized
INFO - 2016-02-08 11:47:57 --> Loader Class Initialized
INFO - 2016-02-08 11:47:57 --> Helper loaded: url_helper
INFO - 2016-02-08 11:47:57 --> Helper loaded: file_helper
INFO - 2016-02-08 11:47:57 --> Helper loaded: date_helper
INFO - 2016-02-08 11:47:57 --> Helper loaded: form_helper
INFO - 2016-02-08 11:47:57 --> Database Driver Class Initialized
INFO - 2016-02-08 11:47:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:47:58 --> Controller Class Initialized
INFO - 2016-02-08 11:47:58 --> Model Class Initialized
INFO - 2016-02-08 11:47:58 --> Model Class Initialized
INFO - 2016-02-08 11:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:47:58 --> Pagination Class Initialized
INFO - 2016-02-08 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:47:58 --> Helper loaded: text_helper
INFO - 2016-02-08 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:47:58 --> Final output sent to browser
DEBUG - 2016-02-08 11:47:58 --> Total execution time: 1.1766
INFO - 2016-02-08 11:48:59 --> Config Class Initialized
INFO - 2016-02-08 11:48:59 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:48:59 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:48:59 --> Utf8 Class Initialized
INFO - 2016-02-08 11:48:59 --> URI Class Initialized
INFO - 2016-02-08 11:48:59 --> Router Class Initialized
INFO - 2016-02-08 11:48:59 --> Output Class Initialized
INFO - 2016-02-08 11:48:59 --> Security Class Initialized
DEBUG - 2016-02-08 11:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:48:59 --> Input Class Initialized
INFO - 2016-02-08 11:48:59 --> Language Class Initialized
INFO - 2016-02-08 11:48:59 --> Loader Class Initialized
INFO - 2016-02-08 11:48:59 --> Helper loaded: url_helper
INFO - 2016-02-08 11:48:59 --> Helper loaded: file_helper
INFO - 2016-02-08 11:48:59 --> Helper loaded: date_helper
INFO - 2016-02-08 11:48:59 --> Helper loaded: form_helper
INFO - 2016-02-08 11:48:59 --> Database Driver Class Initialized
INFO - 2016-02-08 11:49:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:49:00 --> Controller Class Initialized
INFO - 2016-02-08 11:49:00 --> Model Class Initialized
INFO - 2016-02-08 11:49:00 --> Model Class Initialized
INFO - 2016-02-08 11:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:49:00 --> Pagination Class Initialized
INFO - 2016-02-08 11:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:49:00 --> Helper loaded: text_helper
INFO - 2016-02-08 11:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:49:01 --> Final output sent to browser
DEBUG - 2016-02-08 11:49:01 --> Total execution time: 1.2960
INFO - 2016-02-08 11:49:03 --> Config Class Initialized
INFO - 2016-02-08 11:49:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:49:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:49:03 --> Utf8 Class Initialized
INFO - 2016-02-08 11:49:03 --> URI Class Initialized
INFO - 2016-02-08 11:49:03 --> Router Class Initialized
INFO - 2016-02-08 11:49:03 --> Output Class Initialized
INFO - 2016-02-08 11:49:03 --> Security Class Initialized
DEBUG - 2016-02-08 11:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:49:03 --> Input Class Initialized
INFO - 2016-02-08 11:49:03 --> Language Class Initialized
INFO - 2016-02-08 11:49:03 --> Loader Class Initialized
INFO - 2016-02-08 11:49:03 --> Helper loaded: url_helper
INFO - 2016-02-08 11:49:03 --> Helper loaded: file_helper
INFO - 2016-02-08 11:49:03 --> Helper loaded: date_helper
INFO - 2016-02-08 11:49:03 --> Helper loaded: form_helper
INFO - 2016-02-08 11:49:03 --> Database Driver Class Initialized
INFO - 2016-02-08 11:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:49:04 --> Controller Class Initialized
INFO - 2016-02-08 11:49:04 --> Model Class Initialized
INFO - 2016-02-08 11:49:04 --> Model Class Initialized
INFO - 2016-02-08 11:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:49:04 --> Pagination Class Initialized
INFO - 2016-02-08 11:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:49:04 --> Helper loaded: text_helper
INFO - 2016-02-08 11:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:49:04 --> Final output sent to browser
DEBUG - 2016-02-08 11:49:04 --> Total execution time: 1.1714
INFO - 2016-02-08 11:49:18 --> Config Class Initialized
INFO - 2016-02-08 11:49:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:49:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:49:18 --> Utf8 Class Initialized
INFO - 2016-02-08 11:49:18 --> URI Class Initialized
INFO - 2016-02-08 11:49:18 --> Router Class Initialized
INFO - 2016-02-08 11:49:18 --> Output Class Initialized
INFO - 2016-02-08 11:49:18 --> Security Class Initialized
DEBUG - 2016-02-08 11:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:49:18 --> Input Class Initialized
INFO - 2016-02-08 11:49:18 --> Language Class Initialized
INFO - 2016-02-08 11:49:18 --> Loader Class Initialized
INFO - 2016-02-08 11:49:18 --> Helper loaded: url_helper
INFO - 2016-02-08 11:49:18 --> Helper loaded: file_helper
INFO - 2016-02-08 11:49:18 --> Helper loaded: date_helper
INFO - 2016-02-08 11:49:18 --> Helper loaded: form_helper
INFO - 2016-02-08 11:49:18 --> Database Driver Class Initialized
INFO - 2016-02-08 11:49:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:49:19 --> Controller Class Initialized
INFO - 2016-02-08 11:49:19 --> Model Class Initialized
INFO - 2016-02-08 11:49:19 --> Model Class Initialized
INFO - 2016-02-08 11:49:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:49:19 --> Pagination Class Initialized
INFO - 2016-02-08 11:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:49:19 --> Helper loaded: text_helper
INFO - 2016-02-08 11:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:49:19 --> Final output sent to browser
DEBUG - 2016-02-08 11:49:19 --> Total execution time: 1.1782
INFO - 2016-02-08 11:49:21 --> Config Class Initialized
INFO - 2016-02-08 11:49:21 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:49:21 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:49:21 --> Utf8 Class Initialized
INFO - 2016-02-08 11:49:21 --> URI Class Initialized
INFO - 2016-02-08 11:49:21 --> Router Class Initialized
INFO - 2016-02-08 11:49:21 --> Output Class Initialized
INFO - 2016-02-08 11:49:21 --> Security Class Initialized
DEBUG - 2016-02-08 11:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:49:21 --> Input Class Initialized
INFO - 2016-02-08 11:49:21 --> Language Class Initialized
INFO - 2016-02-08 11:49:21 --> Loader Class Initialized
INFO - 2016-02-08 11:49:21 --> Helper loaded: url_helper
INFO - 2016-02-08 11:49:21 --> Helper loaded: file_helper
INFO - 2016-02-08 11:49:21 --> Helper loaded: date_helper
INFO - 2016-02-08 11:49:21 --> Helper loaded: form_helper
INFO - 2016-02-08 11:49:21 --> Database Driver Class Initialized
INFO - 2016-02-08 11:49:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:49:22 --> Controller Class Initialized
INFO - 2016-02-08 11:49:22 --> Model Class Initialized
INFO - 2016-02-08 11:49:22 --> Model Class Initialized
INFO - 2016-02-08 11:49:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:49:22 --> Pagination Class Initialized
INFO - 2016-02-08 11:49:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:49:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:49:22 --> Helper loaded: text_helper
INFO - 2016-02-08 11:49:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:49:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:49:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:49:22 --> Final output sent to browser
DEBUG - 2016-02-08 11:49:22 --> Total execution time: 1.1645
INFO - 2016-02-08 11:49:30 --> Config Class Initialized
INFO - 2016-02-08 11:49:30 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:49:30 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:49:30 --> Utf8 Class Initialized
INFO - 2016-02-08 11:49:30 --> URI Class Initialized
INFO - 2016-02-08 11:49:30 --> Router Class Initialized
INFO - 2016-02-08 11:49:30 --> Output Class Initialized
INFO - 2016-02-08 11:49:30 --> Security Class Initialized
DEBUG - 2016-02-08 11:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:49:30 --> Input Class Initialized
INFO - 2016-02-08 11:49:30 --> Language Class Initialized
INFO - 2016-02-08 11:49:30 --> Loader Class Initialized
INFO - 2016-02-08 11:49:30 --> Helper loaded: url_helper
INFO - 2016-02-08 11:49:30 --> Helper loaded: file_helper
INFO - 2016-02-08 11:49:30 --> Helper loaded: date_helper
INFO - 2016-02-08 11:49:30 --> Helper loaded: form_helper
INFO - 2016-02-08 11:49:30 --> Database Driver Class Initialized
INFO - 2016-02-08 11:49:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:49:31 --> Controller Class Initialized
INFO - 2016-02-08 11:49:31 --> Model Class Initialized
INFO - 2016-02-08 11:49:31 --> Model Class Initialized
INFO - 2016-02-08 11:49:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:49:31 --> Pagination Class Initialized
INFO - 2016-02-08 11:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:49:31 --> Helper loaded: text_helper
INFO - 2016-02-08 11:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:49:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:49:31 --> Final output sent to browser
DEBUG - 2016-02-08 11:49:31 --> Total execution time: 1.1636
INFO - 2016-02-08 11:51:26 --> Config Class Initialized
INFO - 2016-02-08 11:51:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:51:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:51:26 --> Utf8 Class Initialized
INFO - 2016-02-08 11:51:26 --> URI Class Initialized
INFO - 2016-02-08 11:51:26 --> Router Class Initialized
INFO - 2016-02-08 11:51:26 --> Output Class Initialized
INFO - 2016-02-08 11:51:26 --> Security Class Initialized
DEBUG - 2016-02-08 11:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:51:26 --> Input Class Initialized
INFO - 2016-02-08 11:51:26 --> Language Class Initialized
INFO - 2016-02-08 11:51:26 --> Loader Class Initialized
INFO - 2016-02-08 11:51:26 --> Helper loaded: url_helper
INFO - 2016-02-08 11:51:26 --> Helper loaded: file_helper
INFO - 2016-02-08 11:51:26 --> Helper loaded: date_helper
INFO - 2016-02-08 11:51:26 --> Helper loaded: form_helper
INFO - 2016-02-08 11:51:26 --> Database Driver Class Initialized
INFO - 2016-02-08 11:51:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:51:27 --> Controller Class Initialized
INFO - 2016-02-08 11:51:27 --> Model Class Initialized
INFO - 2016-02-08 11:51:27 --> Model Class Initialized
INFO - 2016-02-08 11:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:51:27 --> Pagination Class Initialized
INFO - 2016-02-08 11:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:51:27 --> Helper loaded: text_helper
INFO - 2016-02-08 11:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:51:27 --> Final output sent to browser
DEBUG - 2016-02-08 11:51:27 --> Total execution time: 1.1974
INFO - 2016-02-08 11:52:15 --> Config Class Initialized
INFO - 2016-02-08 11:52:15 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:52:15 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:52:15 --> Utf8 Class Initialized
INFO - 2016-02-08 11:52:15 --> URI Class Initialized
INFO - 2016-02-08 11:52:15 --> Router Class Initialized
INFO - 2016-02-08 11:52:15 --> Output Class Initialized
INFO - 2016-02-08 11:52:15 --> Security Class Initialized
DEBUG - 2016-02-08 11:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:52:15 --> Input Class Initialized
INFO - 2016-02-08 11:52:15 --> Language Class Initialized
INFO - 2016-02-08 11:52:15 --> Loader Class Initialized
INFO - 2016-02-08 11:52:15 --> Helper loaded: url_helper
INFO - 2016-02-08 11:52:15 --> Helper loaded: file_helper
INFO - 2016-02-08 11:52:15 --> Helper loaded: date_helper
INFO - 2016-02-08 11:52:15 --> Helper loaded: form_helper
INFO - 2016-02-08 11:52:15 --> Database Driver Class Initialized
INFO - 2016-02-08 11:52:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:52:16 --> Controller Class Initialized
INFO - 2016-02-08 11:52:16 --> Model Class Initialized
INFO - 2016-02-08 11:52:16 --> Model Class Initialized
INFO - 2016-02-08 11:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:52:16 --> Pagination Class Initialized
INFO - 2016-02-08 11:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:52:16 --> Helper loaded: text_helper
INFO - 2016-02-08 11:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:52:16 --> Final output sent to browser
DEBUG - 2016-02-08 11:52:16 --> Total execution time: 1.1813
INFO - 2016-02-08 11:52:41 --> Config Class Initialized
INFO - 2016-02-08 11:52:41 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:52:41 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:52:41 --> Utf8 Class Initialized
INFO - 2016-02-08 11:52:41 --> URI Class Initialized
INFO - 2016-02-08 11:52:41 --> Router Class Initialized
INFO - 2016-02-08 11:52:41 --> Output Class Initialized
INFO - 2016-02-08 11:52:41 --> Security Class Initialized
DEBUG - 2016-02-08 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:52:41 --> Input Class Initialized
INFO - 2016-02-08 11:52:41 --> Language Class Initialized
INFO - 2016-02-08 11:52:41 --> Loader Class Initialized
INFO - 2016-02-08 11:52:41 --> Helper loaded: url_helper
INFO - 2016-02-08 11:52:41 --> Helper loaded: file_helper
INFO - 2016-02-08 11:52:41 --> Helper loaded: date_helper
INFO - 2016-02-08 11:52:41 --> Helper loaded: form_helper
INFO - 2016-02-08 11:52:41 --> Database Driver Class Initialized
INFO - 2016-02-08 11:52:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:52:42 --> Controller Class Initialized
INFO - 2016-02-08 11:52:42 --> Model Class Initialized
INFO - 2016-02-08 11:52:42 --> Model Class Initialized
INFO - 2016-02-08 11:52:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:52:42 --> Pagination Class Initialized
INFO - 2016-02-08 11:52:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:52:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:52:42 --> Helper loaded: text_helper
INFO - 2016-02-08 11:52:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:52:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:52:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:52:42 --> Final output sent to browser
DEBUG - 2016-02-08 11:52:42 --> Total execution time: 1.1891
INFO - 2016-02-08 11:52:52 --> Config Class Initialized
INFO - 2016-02-08 11:52:52 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:52:52 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:52:52 --> Utf8 Class Initialized
INFO - 2016-02-08 11:52:52 --> URI Class Initialized
INFO - 2016-02-08 11:52:52 --> Router Class Initialized
INFO - 2016-02-08 11:52:52 --> Output Class Initialized
INFO - 2016-02-08 11:52:52 --> Security Class Initialized
DEBUG - 2016-02-08 11:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:52:52 --> Input Class Initialized
INFO - 2016-02-08 11:52:52 --> Language Class Initialized
INFO - 2016-02-08 11:52:52 --> Loader Class Initialized
INFO - 2016-02-08 11:52:52 --> Helper loaded: url_helper
INFO - 2016-02-08 11:52:52 --> Helper loaded: file_helper
INFO - 2016-02-08 11:52:52 --> Helper loaded: date_helper
INFO - 2016-02-08 11:52:52 --> Helper loaded: form_helper
INFO - 2016-02-08 11:52:52 --> Database Driver Class Initialized
INFO - 2016-02-08 11:52:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:52:53 --> Controller Class Initialized
INFO - 2016-02-08 11:52:53 --> Model Class Initialized
INFO - 2016-02-08 11:52:53 --> Model Class Initialized
INFO - 2016-02-08 11:52:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:52:53 --> Pagination Class Initialized
INFO - 2016-02-08 11:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:52:53 --> Helper loaded: text_helper
INFO - 2016-02-08 11:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:52:53 --> Final output sent to browser
DEBUG - 2016-02-08 11:52:53 --> Total execution time: 1.1497
INFO - 2016-02-08 11:53:24 --> Config Class Initialized
INFO - 2016-02-08 11:53:24 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:53:24 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:53:24 --> Utf8 Class Initialized
INFO - 2016-02-08 11:53:24 --> URI Class Initialized
INFO - 2016-02-08 11:53:24 --> Router Class Initialized
INFO - 2016-02-08 11:53:24 --> Output Class Initialized
INFO - 2016-02-08 11:53:24 --> Security Class Initialized
DEBUG - 2016-02-08 11:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:53:24 --> Input Class Initialized
INFO - 2016-02-08 11:53:24 --> Language Class Initialized
INFO - 2016-02-08 11:53:24 --> Loader Class Initialized
INFO - 2016-02-08 11:53:24 --> Helper loaded: url_helper
INFO - 2016-02-08 11:53:24 --> Helper loaded: file_helper
INFO - 2016-02-08 11:53:24 --> Helper loaded: date_helper
INFO - 2016-02-08 11:53:24 --> Helper loaded: form_helper
INFO - 2016-02-08 11:53:24 --> Database Driver Class Initialized
INFO - 2016-02-08 11:53:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:53:25 --> Controller Class Initialized
INFO - 2016-02-08 11:53:25 --> Model Class Initialized
INFO - 2016-02-08 11:53:25 --> Model Class Initialized
INFO - 2016-02-08 11:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:53:25 --> Pagination Class Initialized
INFO - 2016-02-08 11:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:53:25 --> Helper loaded: text_helper
INFO - 2016-02-08 11:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:53:25 --> Final output sent to browser
DEBUG - 2016-02-08 11:53:25 --> Total execution time: 1.1889
INFO - 2016-02-08 11:53:29 --> Config Class Initialized
INFO - 2016-02-08 11:53:29 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:53:29 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:53:29 --> Utf8 Class Initialized
INFO - 2016-02-08 11:53:29 --> URI Class Initialized
INFO - 2016-02-08 11:53:29 --> Router Class Initialized
INFO - 2016-02-08 11:53:29 --> Output Class Initialized
INFO - 2016-02-08 11:53:29 --> Security Class Initialized
DEBUG - 2016-02-08 11:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:53:29 --> Input Class Initialized
INFO - 2016-02-08 11:53:29 --> Language Class Initialized
INFO - 2016-02-08 11:53:29 --> Loader Class Initialized
INFO - 2016-02-08 11:53:29 --> Helper loaded: url_helper
INFO - 2016-02-08 11:53:29 --> Helper loaded: file_helper
INFO - 2016-02-08 11:53:29 --> Helper loaded: date_helper
INFO - 2016-02-08 11:53:29 --> Helper loaded: form_helper
INFO - 2016-02-08 11:53:29 --> Database Driver Class Initialized
INFO - 2016-02-08 11:53:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:53:30 --> Controller Class Initialized
INFO - 2016-02-08 11:53:30 --> Model Class Initialized
INFO - 2016-02-08 11:53:30 --> Model Class Initialized
INFO - 2016-02-08 11:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:53:30 --> Pagination Class Initialized
INFO - 2016-02-08 11:53:30 --> Form Validation Class Initialized
INFO - 2016-02-08 11:53:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:53:30 --> Final output sent to browser
DEBUG - 2016-02-08 11:53:30 --> Total execution time: 1.1333
INFO - 2016-02-08 11:53:53 --> Config Class Initialized
INFO - 2016-02-08 11:53:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:53:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:53:53 --> Utf8 Class Initialized
INFO - 2016-02-08 11:53:53 --> URI Class Initialized
INFO - 2016-02-08 11:53:53 --> Router Class Initialized
INFO - 2016-02-08 11:53:53 --> Output Class Initialized
INFO - 2016-02-08 11:53:53 --> Security Class Initialized
DEBUG - 2016-02-08 11:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:53:53 --> Input Class Initialized
INFO - 2016-02-08 11:53:53 --> Language Class Initialized
INFO - 2016-02-08 11:53:53 --> Loader Class Initialized
INFO - 2016-02-08 11:53:53 --> Helper loaded: url_helper
INFO - 2016-02-08 11:53:53 --> Helper loaded: file_helper
INFO - 2016-02-08 11:53:53 --> Helper loaded: date_helper
INFO - 2016-02-08 11:53:53 --> Helper loaded: form_helper
INFO - 2016-02-08 11:53:53 --> Database Driver Class Initialized
INFO - 2016-02-08 11:53:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:53:54 --> Controller Class Initialized
INFO - 2016-02-08 11:53:54 --> Model Class Initialized
INFO - 2016-02-08 11:53:54 --> Model Class Initialized
INFO - 2016-02-08 11:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:53:54 --> Pagination Class Initialized
INFO - 2016-02-08 11:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:53:54 --> Helper loaded: text_helper
INFO - 2016-02-08 11:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:53:54 --> Final output sent to browser
DEBUG - 2016-02-08 11:53:54 --> Total execution time: 1.1400
INFO - 2016-02-08 11:53:56 --> Config Class Initialized
INFO - 2016-02-08 11:53:56 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:53:56 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:53:56 --> Utf8 Class Initialized
INFO - 2016-02-08 11:53:56 --> URI Class Initialized
INFO - 2016-02-08 11:53:56 --> Router Class Initialized
INFO - 2016-02-08 11:53:56 --> Output Class Initialized
INFO - 2016-02-08 11:53:56 --> Security Class Initialized
DEBUG - 2016-02-08 11:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:53:56 --> Input Class Initialized
INFO - 2016-02-08 11:53:56 --> Language Class Initialized
INFO - 2016-02-08 11:53:56 --> Loader Class Initialized
INFO - 2016-02-08 11:53:56 --> Helper loaded: url_helper
INFO - 2016-02-08 11:53:56 --> Helper loaded: file_helper
INFO - 2016-02-08 11:53:56 --> Helper loaded: date_helper
INFO - 2016-02-08 11:53:56 --> Helper loaded: form_helper
INFO - 2016-02-08 11:53:56 --> Database Driver Class Initialized
INFO - 2016-02-08 11:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:53:57 --> Controller Class Initialized
INFO - 2016-02-08 11:53:57 --> Model Class Initialized
INFO - 2016-02-08 11:53:57 --> Model Class Initialized
INFO - 2016-02-08 11:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:53:57 --> Pagination Class Initialized
INFO - 2016-02-08 11:53:57 --> Form Validation Class Initialized
INFO - 2016-02-08 11:53:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:53:57 --> Final output sent to browser
DEBUG - 2016-02-08 11:53:57 --> Total execution time: 1.1258
INFO - 2016-02-08 11:55:45 --> Config Class Initialized
INFO - 2016-02-08 11:55:45 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:55:45 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:55:45 --> Utf8 Class Initialized
INFO - 2016-02-08 11:55:45 --> URI Class Initialized
INFO - 2016-02-08 11:55:45 --> Router Class Initialized
INFO - 2016-02-08 11:55:45 --> Output Class Initialized
INFO - 2016-02-08 11:55:45 --> Security Class Initialized
DEBUG - 2016-02-08 11:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:55:45 --> Input Class Initialized
INFO - 2016-02-08 11:55:45 --> Language Class Initialized
INFO - 2016-02-08 11:55:45 --> Loader Class Initialized
INFO - 2016-02-08 11:55:45 --> Helper loaded: url_helper
INFO - 2016-02-08 11:55:45 --> Helper loaded: file_helper
INFO - 2016-02-08 11:55:45 --> Helper loaded: date_helper
INFO - 2016-02-08 11:55:45 --> Helper loaded: form_helper
INFO - 2016-02-08 11:55:45 --> Database Driver Class Initialized
INFO - 2016-02-08 11:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:55:46 --> Controller Class Initialized
INFO - 2016-02-08 11:55:46 --> Model Class Initialized
INFO - 2016-02-08 11:55:46 --> Model Class Initialized
INFO - 2016-02-08 11:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:55:46 --> Pagination Class Initialized
INFO - 2016-02-08 11:55:46 --> Form Validation Class Initialized
INFO - 2016-02-08 11:55:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:55:46 --> Model Class Initialized
INFO - 2016-02-08 11:55:47 --> Final output sent to browser
DEBUG - 2016-02-08 11:55:47 --> Total execution time: 1.2002
INFO - 2016-02-08 11:56:33 --> Config Class Initialized
INFO - 2016-02-08 11:56:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:56:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:56:33 --> Utf8 Class Initialized
INFO - 2016-02-08 11:56:33 --> URI Class Initialized
INFO - 2016-02-08 11:56:33 --> Router Class Initialized
INFO - 2016-02-08 11:56:33 --> Output Class Initialized
INFO - 2016-02-08 11:56:33 --> Security Class Initialized
DEBUG - 2016-02-08 11:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:56:33 --> Input Class Initialized
INFO - 2016-02-08 11:56:33 --> Language Class Initialized
INFO - 2016-02-08 11:56:33 --> Loader Class Initialized
INFO - 2016-02-08 11:56:33 --> Helper loaded: url_helper
INFO - 2016-02-08 11:56:33 --> Helper loaded: file_helper
INFO - 2016-02-08 11:56:33 --> Helper loaded: date_helper
INFO - 2016-02-08 11:56:33 --> Helper loaded: form_helper
INFO - 2016-02-08 11:56:33 --> Database Driver Class Initialized
INFO - 2016-02-08 11:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:56:34 --> Controller Class Initialized
INFO - 2016-02-08 11:56:34 --> Model Class Initialized
INFO - 2016-02-08 11:56:34 --> Model Class Initialized
INFO - 2016-02-08 11:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:56:34 --> Pagination Class Initialized
INFO - 2016-02-08 11:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:56:34 --> Helper loaded: text_helper
INFO - 2016-02-08 11:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:56:34 --> Final output sent to browser
DEBUG - 2016-02-08 11:56:34 --> Total execution time: 1.1567
INFO - 2016-02-08 11:56:40 --> Config Class Initialized
INFO - 2016-02-08 11:56:40 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:56:40 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:56:40 --> Utf8 Class Initialized
INFO - 2016-02-08 11:56:40 --> URI Class Initialized
INFO - 2016-02-08 11:56:40 --> Router Class Initialized
INFO - 2016-02-08 11:56:40 --> Output Class Initialized
INFO - 2016-02-08 11:56:40 --> Security Class Initialized
DEBUG - 2016-02-08 11:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:56:40 --> Input Class Initialized
INFO - 2016-02-08 11:56:40 --> Language Class Initialized
INFO - 2016-02-08 11:56:40 --> Loader Class Initialized
INFO - 2016-02-08 11:56:40 --> Helper loaded: url_helper
INFO - 2016-02-08 11:56:40 --> Helper loaded: file_helper
INFO - 2016-02-08 11:56:40 --> Helper loaded: date_helper
INFO - 2016-02-08 11:56:40 --> Helper loaded: form_helper
INFO - 2016-02-08 11:56:40 --> Database Driver Class Initialized
INFO - 2016-02-08 11:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:56:41 --> Controller Class Initialized
INFO - 2016-02-08 11:56:41 --> Model Class Initialized
INFO - 2016-02-08 11:56:41 --> Model Class Initialized
INFO - 2016-02-08 11:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:56:41 --> Pagination Class Initialized
INFO - 2016-02-08 11:56:41 --> Form Validation Class Initialized
INFO - 2016-02-08 11:56:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:56:41 --> Model Class Initialized
ERROR - 2016-02-08 11:56:41 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-08 11:56:41 --> Final output sent to browser
DEBUG - 2016-02-08 11:56:41 --> Total execution time: 1.3066
INFO - 2016-02-08 11:56:48 --> Config Class Initialized
INFO - 2016-02-08 11:56:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:56:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:56:48 --> Utf8 Class Initialized
INFO - 2016-02-08 11:56:48 --> URI Class Initialized
INFO - 2016-02-08 11:56:48 --> Router Class Initialized
INFO - 2016-02-08 11:56:48 --> Output Class Initialized
INFO - 2016-02-08 11:56:48 --> Security Class Initialized
DEBUG - 2016-02-08 11:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:56:48 --> Input Class Initialized
INFO - 2016-02-08 11:56:48 --> Language Class Initialized
INFO - 2016-02-08 11:56:48 --> Loader Class Initialized
INFO - 2016-02-08 11:56:48 --> Helper loaded: url_helper
INFO - 2016-02-08 11:56:48 --> Helper loaded: file_helper
INFO - 2016-02-08 11:56:48 --> Helper loaded: date_helper
INFO - 2016-02-08 11:56:48 --> Helper loaded: form_helper
INFO - 2016-02-08 11:56:48 --> Database Driver Class Initialized
INFO - 2016-02-08 11:56:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:56:49 --> Controller Class Initialized
INFO - 2016-02-08 11:56:49 --> Model Class Initialized
INFO - 2016-02-08 11:56:49 --> Model Class Initialized
INFO - 2016-02-08 11:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:56:49 --> Pagination Class Initialized
INFO - 2016-02-08 11:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 11:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 11:56:49 --> Helper loaded: text_helper
INFO - 2016-02-08 11:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 11:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 11:56:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 11:56:49 --> Final output sent to browser
DEBUG - 2016-02-08 11:56:49 --> Total execution time: 1.2026
INFO - 2016-02-08 11:56:54 --> Config Class Initialized
INFO - 2016-02-08 11:56:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 11:56:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 11:56:54 --> Utf8 Class Initialized
INFO - 2016-02-08 11:56:54 --> URI Class Initialized
INFO - 2016-02-08 11:56:54 --> Router Class Initialized
INFO - 2016-02-08 11:56:54 --> Output Class Initialized
INFO - 2016-02-08 11:56:54 --> Security Class Initialized
DEBUG - 2016-02-08 11:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 11:56:54 --> Input Class Initialized
INFO - 2016-02-08 11:56:54 --> Language Class Initialized
INFO - 2016-02-08 11:56:54 --> Loader Class Initialized
INFO - 2016-02-08 11:56:54 --> Helper loaded: url_helper
INFO - 2016-02-08 11:56:54 --> Helper loaded: file_helper
INFO - 2016-02-08 11:56:54 --> Helper loaded: date_helper
INFO - 2016-02-08 11:56:54 --> Helper loaded: form_helper
INFO - 2016-02-08 11:56:54 --> Database Driver Class Initialized
INFO - 2016-02-08 11:56:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 11:56:55 --> Controller Class Initialized
INFO - 2016-02-08 11:56:55 --> Model Class Initialized
INFO - 2016-02-08 11:56:55 --> Model Class Initialized
INFO - 2016-02-08 11:56:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 11:56:55 --> Pagination Class Initialized
INFO - 2016-02-08 11:56:55 --> Form Validation Class Initialized
INFO - 2016-02-08 11:56:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 11:56:55 --> Model Class Initialized
ERROR - 2016-02-08 11:56:55 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-08 11:56:55 --> Final output sent to browser
DEBUG - 2016-02-08 11:56:55 --> Total execution time: 1.2033
INFO - 2016-02-08 12:00:20 --> Config Class Initialized
INFO - 2016-02-08 12:00:20 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:00:20 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:00:20 --> Utf8 Class Initialized
INFO - 2016-02-08 12:00:20 --> URI Class Initialized
INFO - 2016-02-08 12:00:20 --> Router Class Initialized
INFO - 2016-02-08 12:00:20 --> Output Class Initialized
INFO - 2016-02-08 12:00:20 --> Security Class Initialized
DEBUG - 2016-02-08 12:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:00:20 --> Input Class Initialized
INFO - 2016-02-08 12:00:20 --> Language Class Initialized
ERROR - 2016-02-08 12:00:20 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 218
INFO - 2016-02-08 12:00:46 --> Config Class Initialized
INFO - 2016-02-08 12:00:46 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:00:46 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:00:46 --> Utf8 Class Initialized
INFO - 2016-02-08 12:00:46 --> URI Class Initialized
INFO - 2016-02-08 12:00:46 --> Router Class Initialized
INFO - 2016-02-08 12:00:46 --> Output Class Initialized
INFO - 2016-02-08 12:00:46 --> Security Class Initialized
DEBUG - 2016-02-08 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:00:46 --> Input Class Initialized
INFO - 2016-02-08 12:00:46 --> Language Class Initialized
INFO - 2016-02-08 12:00:46 --> Loader Class Initialized
INFO - 2016-02-08 12:00:46 --> Helper loaded: url_helper
INFO - 2016-02-08 12:00:46 --> Helper loaded: file_helper
INFO - 2016-02-08 12:00:46 --> Helper loaded: date_helper
INFO - 2016-02-08 12:00:46 --> Helper loaded: form_helper
INFO - 2016-02-08 12:00:46 --> Database Driver Class Initialized
INFO - 2016-02-08 12:00:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:00:47 --> Controller Class Initialized
INFO - 2016-02-08 12:00:47 --> Model Class Initialized
INFO - 2016-02-08 12:00:47 --> Model Class Initialized
INFO - 2016-02-08 12:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:00:47 --> Pagination Class Initialized
INFO - 2016-02-08 12:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:00:47 --> Helper loaded: text_helper
INFO - 2016-02-08 12:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:00:47 --> Final output sent to browser
DEBUG - 2016-02-08 12:00:47 --> Total execution time: 1.1591
INFO - 2016-02-08 12:00:53 --> Config Class Initialized
INFO - 2016-02-08 12:00:53 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:00:53 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:00:53 --> Utf8 Class Initialized
INFO - 2016-02-08 12:00:53 --> URI Class Initialized
INFO - 2016-02-08 12:00:53 --> Router Class Initialized
INFO - 2016-02-08 12:00:53 --> Output Class Initialized
INFO - 2016-02-08 12:00:53 --> Security Class Initialized
DEBUG - 2016-02-08 12:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:00:53 --> Input Class Initialized
INFO - 2016-02-08 12:00:53 --> Language Class Initialized
INFO - 2016-02-08 12:00:53 --> Loader Class Initialized
INFO - 2016-02-08 12:00:53 --> Helper loaded: url_helper
INFO - 2016-02-08 12:00:53 --> Helper loaded: file_helper
INFO - 2016-02-08 12:00:53 --> Helper loaded: date_helper
INFO - 2016-02-08 12:00:53 --> Helper loaded: form_helper
INFO - 2016-02-08 12:00:53 --> Database Driver Class Initialized
INFO - 2016-02-08 12:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:00:54 --> Controller Class Initialized
INFO - 2016-02-08 12:00:54 --> Model Class Initialized
INFO - 2016-02-08 12:00:54 --> Model Class Initialized
INFO - 2016-02-08 12:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:00:54 --> Pagination Class Initialized
INFO - 2016-02-08 12:00:54 --> Form Validation Class Initialized
INFO - 2016-02-08 12:00:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:00:54 --> Model Class Initialized
ERROR - 2016-02-08 12:00:54 --> Severity: Notice --> Undefined variable: set_output C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
ERROR - 2016-02-08 12:00:54 --> Severity: Error --> Function name must be a string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
INFO - 2016-02-08 12:01:02 --> Config Class Initialized
INFO - 2016-02-08 12:01:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:01:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:01:02 --> Utf8 Class Initialized
INFO - 2016-02-08 12:01:02 --> URI Class Initialized
INFO - 2016-02-08 12:01:02 --> Router Class Initialized
INFO - 2016-02-08 12:01:02 --> Output Class Initialized
INFO - 2016-02-08 12:01:02 --> Security Class Initialized
DEBUG - 2016-02-08 12:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:01:02 --> Input Class Initialized
INFO - 2016-02-08 12:01:02 --> Language Class Initialized
INFO - 2016-02-08 12:01:02 --> Loader Class Initialized
INFO - 2016-02-08 12:01:02 --> Helper loaded: url_helper
INFO - 2016-02-08 12:01:02 --> Helper loaded: file_helper
INFO - 2016-02-08 12:01:02 --> Helper loaded: date_helper
INFO - 2016-02-08 12:01:02 --> Helper loaded: form_helper
INFO - 2016-02-08 12:01:02 --> Database Driver Class Initialized
INFO - 2016-02-08 12:01:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:01:03 --> Controller Class Initialized
INFO - 2016-02-08 12:01:03 --> Model Class Initialized
INFO - 2016-02-08 12:01:03 --> Model Class Initialized
INFO - 2016-02-08 12:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:01:03 --> Pagination Class Initialized
INFO - 2016-02-08 12:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:01:03 --> Helper loaded: text_helper
INFO - 2016-02-08 12:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:01:03 --> Final output sent to browser
DEBUG - 2016-02-08 12:01:03 --> Total execution time: 1.1700
INFO - 2016-02-08 12:01:10 --> Config Class Initialized
INFO - 2016-02-08 12:01:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:01:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:01:10 --> Utf8 Class Initialized
INFO - 2016-02-08 12:01:10 --> URI Class Initialized
INFO - 2016-02-08 12:01:10 --> Router Class Initialized
INFO - 2016-02-08 12:01:10 --> Output Class Initialized
INFO - 2016-02-08 12:01:10 --> Security Class Initialized
DEBUG - 2016-02-08 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:01:10 --> Input Class Initialized
INFO - 2016-02-08 12:01:10 --> Language Class Initialized
INFO - 2016-02-08 12:01:10 --> Loader Class Initialized
INFO - 2016-02-08 12:01:10 --> Helper loaded: url_helper
INFO - 2016-02-08 12:01:10 --> Helper loaded: file_helper
INFO - 2016-02-08 12:01:10 --> Helper loaded: date_helper
INFO - 2016-02-08 12:01:10 --> Helper loaded: form_helper
INFO - 2016-02-08 12:01:10 --> Database Driver Class Initialized
INFO - 2016-02-08 12:01:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:01:11 --> Controller Class Initialized
INFO - 2016-02-08 12:01:11 --> Model Class Initialized
INFO - 2016-02-08 12:01:11 --> Model Class Initialized
INFO - 2016-02-08 12:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:01:11 --> Pagination Class Initialized
INFO - 2016-02-08 12:01:11 --> Form Validation Class Initialized
INFO - 2016-02-08 12:01:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:01:11 --> Model Class Initialized
ERROR - 2016-02-08 12:01:11 --> Severity: Notice --> Undefined variable: set_output C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
ERROR - 2016-02-08 12:01:11 --> Severity: Error --> Function name must be a string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
INFO - 2016-02-08 12:01:46 --> Config Class Initialized
INFO - 2016-02-08 12:01:46 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:01:46 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:01:46 --> Utf8 Class Initialized
INFO - 2016-02-08 12:01:46 --> URI Class Initialized
INFO - 2016-02-08 12:01:46 --> Router Class Initialized
INFO - 2016-02-08 12:01:46 --> Output Class Initialized
INFO - 2016-02-08 12:01:46 --> Security Class Initialized
DEBUG - 2016-02-08 12:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:01:46 --> Input Class Initialized
INFO - 2016-02-08 12:01:46 --> Language Class Initialized
INFO - 2016-02-08 12:01:46 --> Loader Class Initialized
INFO - 2016-02-08 12:01:46 --> Helper loaded: url_helper
INFO - 2016-02-08 12:01:46 --> Helper loaded: file_helper
INFO - 2016-02-08 12:01:46 --> Helper loaded: date_helper
INFO - 2016-02-08 12:01:46 --> Helper loaded: form_helper
INFO - 2016-02-08 12:01:46 --> Database Driver Class Initialized
INFO - 2016-02-08 12:01:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:01:47 --> Controller Class Initialized
INFO - 2016-02-08 12:01:47 --> Model Class Initialized
INFO - 2016-02-08 12:01:47 --> Model Class Initialized
INFO - 2016-02-08 12:01:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:01:47 --> Pagination Class Initialized
INFO - 2016-02-08 12:01:47 --> Form Validation Class Initialized
INFO - 2016-02-08 12:01:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:01:47 --> Model Class Initialized
ERROR - 2016-02-08 12:01:48 --> Severity: Error --> Call to undefined function set_output() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
INFO - 2016-02-08 12:02:17 --> Config Class Initialized
INFO - 2016-02-08 12:02:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:02:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:02:17 --> Utf8 Class Initialized
INFO - 2016-02-08 12:02:17 --> URI Class Initialized
INFO - 2016-02-08 12:02:17 --> Router Class Initialized
INFO - 2016-02-08 12:02:17 --> Output Class Initialized
INFO - 2016-02-08 12:02:17 --> Security Class Initialized
DEBUG - 2016-02-08 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:02:17 --> Input Class Initialized
INFO - 2016-02-08 12:02:17 --> Language Class Initialized
ERROR - 2016-02-08 12:02:17 --> Severity: Parsing Error --> syntax error, unexpected 'set_output' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 216
INFO - 2016-02-08 12:02:48 --> Config Class Initialized
INFO - 2016-02-08 12:02:48 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:02:48 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:02:48 --> Utf8 Class Initialized
INFO - 2016-02-08 12:02:48 --> URI Class Initialized
INFO - 2016-02-08 12:02:48 --> Router Class Initialized
INFO - 2016-02-08 12:02:48 --> Output Class Initialized
INFO - 2016-02-08 12:02:48 --> Security Class Initialized
DEBUG - 2016-02-08 12:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:02:48 --> Input Class Initialized
INFO - 2016-02-08 12:02:48 --> Language Class Initialized
INFO - 2016-02-08 12:02:48 --> Loader Class Initialized
INFO - 2016-02-08 12:02:48 --> Helper loaded: url_helper
INFO - 2016-02-08 12:02:48 --> Helper loaded: file_helper
INFO - 2016-02-08 12:02:48 --> Helper loaded: date_helper
INFO - 2016-02-08 12:02:48 --> Helper loaded: form_helper
INFO - 2016-02-08 12:02:48 --> Database Driver Class Initialized
INFO - 2016-02-08 12:02:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:02:49 --> Controller Class Initialized
INFO - 2016-02-08 12:02:49 --> Model Class Initialized
INFO - 2016-02-08 12:02:49 --> Model Class Initialized
INFO - 2016-02-08 12:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:02:49 --> Pagination Class Initialized
INFO - 2016-02-08 12:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:02:49 --> Helper loaded: text_helper
INFO - 2016-02-08 12:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:02:49 --> Final output sent to browser
DEBUG - 2016-02-08 12:02:49 --> Total execution time: 1.1632
INFO - 2016-02-08 12:02:55 --> Config Class Initialized
INFO - 2016-02-08 12:02:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:02:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:02:55 --> Utf8 Class Initialized
INFO - 2016-02-08 12:02:55 --> URI Class Initialized
INFO - 2016-02-08 12:02:55 --> Router Class Initialized
INFO - 2016-02-08 12:02:55 --> Output Class Initialized
INFO - 2016-02-08 12:02:55 --> Security Class Initialized
DEBUG - 2016-02-08 12:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:02:55 --> Input Class Initialized
INFO - 2016-02-08 12:02:55 --> Language Class Initialized
INFO - 2016-02-08 12:02:55 --> Loader Class Initialized
INFO - 2016-02-08 12:02:55 --> Helper loaded: url_helper
INFO - 2016-02-08 12:02:55 --> Helper loaded: file_helper
INFO - 2016-02-08 12:02:55 --> Helper loaded: date_helper
INFO - 2016-02-08 12:02:55 --> Helper loaded: form_helper
INFO - 2016-02-08 12:02:55 --> Database Driver Class Initialized
INFO - 2016-02-08 12:02:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:02:56 --> Controller Class Initialized
INFO - 2016-02-08 12:02:56 --> Model Class Initialized
INFO - 2016-02-08 12:02:56 --> Model Class Initialized
INFO - 2016-02-08 12:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:02:56 --> Pagination Class Initialized
INFO - 2016-02-08 12:02:56 --> Form Validation Class Initialized
INFO - 2016-02-08 12:02:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:02:56 --> Model Class Initialized
INFO - 2016-02-08 12:02:56 --> Final output sent to browser
DEBUG - 2016-02-08 12:02:56 --> Total execution time: 1.1763
INFO - 2016-02-08 12:03:01 --> Config Class Initialized
INFO - 2016-02-08 12:03:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:01 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:01 --> URI Class Initialized
INFO - 2016-02-08 12:03:01 --> Router Class Initialized
INFO - 2016-02-08 12:03:01 --> Output Class Initialized
INFO - 2016-02-08 12:03:01 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:01 --> Input Class Initialized
INFO - 2016-02-08 12:03:01 --> Language Class Initialized
INFO - 2016-02-08 12:03:01 --> Loader Class Initialized
INFO - 2016-02-08 12:03:01 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:01 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:01 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:01 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:01 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:02 --> Controller Class Initialized
INFO - 2016-02-08 12:03:02 --> Model Class Initialized
INFO - 2016-02-08 12:03:02 --> Model Class Initialized
INFO - 2016-02-08 12:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:02 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:02 --> Form Validation Class Initialized
INFO - 2016-02-08 12:03:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:03:02 --> Model Class Initialized
INFO - 2016-02-08 12:03:02 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:02 --> Total execution time: 1.1596
INFO - 2016-02-08 12:03:07 --> Config Class Initialized
INFO - 2016-02-08 12:03:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:07 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:07 --> URI Class Initialized
INFO - 2016-02-08 12:03:07 --> Router Class Initialized
INFO - 2016-02-08 12:03:07 --> Output Class Initialized
INFO - 2016-02-08 12:03:07 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:07 --> Input Class Initialized
INFO - 2016-02-08 12:03:07 --> Language Class Initialized
INFO - 2016-02-08 12:03:07 --> Loader Class Initialized
INFO - 2016-02-08 12:03:07 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:07 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:07 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:07 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:07 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:08 --> Controller Class Initialized
INFO - 2016-02-08 12:03:08 --> Model Class Initialized
INFO - 2016-02-08 12:03:08 --> Model Class Initialized
INFO - 2016-02-08 12:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:08 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:08 --> Form Validation Class Initialized
INFO - 2016-02-08 12:03:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:03:08 --> Model Class Initialized
INFO - 2016-02-08 12:03:08 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:08 --> Total execution time: 1.1755
INFO - 2016-02-08 12:03:12 --> Config Class Initialized
INFO - 2016-02-08 12:03:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:12 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:12 --> URI Class Initialized
INFO - 2016-02-08 12:03:12 --> Router Class Initialized
INFO - 2016-02-08 12:03:12 --> Output Class Initialized
INFO - 2016-02-08 12:03:12 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:12 --> Input Class Initialized
INFO - 2016-02-08 12:03:12 --> Language Class Initialized
INFO - 2016-02-08 12:03:12 --> Loader Class Initialized
INFO - 2016-02-08 12:03:12 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:12 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:12 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:12 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:12 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:13 --> Config Class Initialized
INFO - 2016-02-08 12:03:13 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:13 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:13 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:13 --> URI Class Initialized
INFO - 2016-02-08 12:03:13 --> Router Class Initialized
INFO - 2016-02-08 12:03:13 --> Output Class Initialized
INFO - 2016-02-08 12:03:13 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:13 --> Input Class Initialized
INFO - 2016-02-08 12:03:13 --> Language Class Initialized
INFO - 2016-02-08 12:03:13 --> Loader Class Initialized
INFO - 2016-02-08 12:03:13 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:13 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:13 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:13 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:13 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:13 --> Controller Class Initialized
INFO - 2016-02-08 12:03:13 --> Model Class Initialized
INFO - 2016-02-08 12:03:13 --> Model Class Initialized
INFO - 2016-02-08 12:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:13 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:13 --> Form Validation Class Initialized
INFO - 2016-02-08 12:03:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:03:13 --> Model Class Initialized
INFO - 2016-02-08 12:03:14 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:14 --> Total execution time: 1.1850
INFO - 2016-02-08 12:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:14 --> Controller Class Initialized
INFO - 2016-02-08 12:03:14 --> Model Class Initialized
INFO - 2016-02-08 12:03:14 --> Model Class Initialized
INFO - 2016-02-08 12:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:14 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:14 --> Form Validation Class Initialized
INFO - 2016-02-08 12:03:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:03:14 --> Model Class Initialized
INFO - 2016-02-08 12:03:14 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:14 --> Total execution time: 1.2100
INFO - 2016-02-08 12:03:14 --> Config Class Initialized
INFO - 2016-02-08 12:03:14 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:14 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:14 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:14 --> URI Class Initialized
INFO - 2016-02-08 12:03:14 --> Router Class Initialized
INFO - 2016-02-08 12:03:14 --> Output Class Initialized
INFO - 2016-02-08 12:03:14 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:14 --> Input Class Initialized
INFO - 2016-02-08 12:03:14 --> Language Class Initialized
INFO - 2016-02-08 12:03:14 --> Loader Class Initialized
INFO - 2016-02-08 12:03:14 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:14 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:14 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:14 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:14 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:15 --> Controller Class Initialized
INFO - 2016-02-08 12:03:15 --> Model Class Initialized
INFO - 2016-02-08 12:03:15 --> Model Class Initialized
INFO - 2016-02-08 12:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:15 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:03:15 --> Helper loaded: text_helper
INFO - 2016-02-08 12:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:03:15 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:15 --> Total execution time: 1.1534
INFO - 2016-02-08 12:03:22 --> Config Class Initialized
INFO - 2016-02-08 12:03:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:03:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:03:22 --> Utf8 Class Initialized
INFO - 2016-02-08 12:03:22 --> URI Class Initialized
INFO - 2016-02-08 12:03:22 --> Router Class Initialized
INFO - 2016-02-08 12:03:22 --> Output Class Initialized
INFO - 2016-02-08 12:03:22 --> Security Class Initialized
DEBUG - 2016-02-08 12:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:03:22 --> Input Class Initialized
INFO - 2016-02-08 12:03:22 --> Language Class Initialized
INFO - 2016-02-08 12:03:22 --> Loader Class Initialized
INFO - 2016-02-08 12:03:22 --> Helper loaded: url_helper
INFO - 2016-02-08 12:03:22 --> Helper loaded: file_helper
INFO - 2016-02-08 12:03:22 --> Helper loaded: date_helper
INFO - 2016-02-08 12:03:22 --> Helper loaded: form_helper
INFO - 2016-02-08 12:03:23 --> Database Driver Class Initialized
INFO - 2016-02-08 12:03:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:03:24 --> Controller Class Initialized
INFO - 2016-02-08 12:03:24 --> Model Class Initialized
INFO - 2016-02-08 12:03:24 --> Model Class Initialized
INFO - 2016-02-08 12:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:03:24 --> Pagination Class Initialized
INFO - 2016-02-08 12:03:24 --> Form Validation Class Initialized
INFO - 2016-02-08 12:03:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:03:24 --> Model Class Initialized
INFO - 2016-02-08 12:03:24 --> Final output sent to browser
DEBUG - 2016-02-08 12:03:24 --> Total execution time: 1.2132
INFO - 2016-02-08 12:04:52 --> Config Class Initialized
INFO - 2016-02-08 12:04:52 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:04:52 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:04:52 --> Utf8 Class Initialized
INFO - 2016-02-08 12:04:52 --> URI Class Initialized
INFO - 2016-02-08 12:04:52 --> Router Class Initialized
INFO - 2016-02-08 12:04:52 --> Output Class Initialized
INFO - 2016-02-08 12:04:52 --> Security Class Initialized
DEBUG - 2016-02-08 12:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:04:52 --> Input Class Initialized
INFO - 2016-02-08 12:04:52 --> Language Class Initialized
INFO - 2016-02-08 12:04:52 --> Loader Class Initialized
INFO - 2016-02-08 12:04:52 --> Helper loaded: url_helper
INFO - 2016-02-08 12:04:52 --> Helper loaded: file_helper
INFO - 2016-02-08 12:04:52 --> Helper loaded: date_helper
INFO - 2016-02-08 12:04:52 --> Helper loaded: form_helper
INFO - 2016-02-08 12:04:52 --> Database Driver Class Initialized
INFO - 2016-02-08 12:04:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:04:53 --> Controller Class Initialized
INFO - 2016-02-08 12:04:53 --> Model Class Initialized
INFO - 2016-02-08 12:04:53 --> Model Class Initialized
INFO - 2016-02-08 12:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:04:53 --> Pagination Class Initialized
INFO - 2016-02-08 12:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:04:53 --> Helper loaded: text_helper
INFO - 2016-02-08 12:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:04:53 --> Final output sent to browser
DEBUG - 2016-02-08 12:04:53 --> Total execution time: 1.1851
INFO - 2016-02-08 12:05:54 --> Config Class Initialized
INFO - 2016-02-08 12:05:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:05:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:05:54 --> Utf8 Class Initialized
INFO - 2016-02-08 12:05:54 --> URI Class Initialized
INFO - 2016-02-08 12:05:54 --> Router Class Initialized
INFO - 2016-02-08 12:05:54 --> Output Class Initialized
INFO - 2016-02-08 12:05:54 --> Security Class Initialized
DEBUG - 2016-02-08 12:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:05:54 --> Input Class Initialized
INFO - 2016-02-08 12:05:54 --> Language Class Initialized
INFO - 2016-02-08 12:05:54 --> Loader Class Initialized
INFO - 2016-02-08 12:05:54 --> Helper loaded: url_helper
INFO - 2016-02-08 12:05:54 --> Helper loaded: file_helper
INFO - 2016-02-08 12:05:54 --> Helper loaded: date_helper
INFO - 2016-02-08 12:05:54 --> Helper loaded: form_helper
INFO - 2016-02-08 12:05:54 --> Database Driver Class Initialized
INFO - 2016-02-08 12:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:05:55 --> Controller Class Initialized
INFO - 2016-02-08 12:05:55 --> Model Class Initialized
INFO - 2016-02-08 12:05:55 --> Model Class Initialized
INFO - 2016-02-08 12:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:05:55 --> Pagination Class Initialized
INFO - 2016-02-08 12:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:05:55 --> Helper loaded: text_helper
INFO - 2016-02-08 12:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:05:55 --> Final output sent to browser
DEBUG - 2016-02-08 12:05:55 --> Total execution time: 1.1600
INFO - 2016-02-08 12:06:03 --> Config Class Initialized
INFO - 2016-02-08 12:06:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:06:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:06:03 --> Utf8 Class Initialized
INFO - 2016-02-08 12:06:03 --> URI Class Initialized
INFO - 2016-02-08 12:06:03 --> Router Class Initialized
INFO - 2016-02-08 12:06:03 --> Output Class Initialized
INFO - 2016-02-08 12:06:03 --> Security Class Initialized
DEBUG - 2016-02-08 12:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:06:03 --> Input Class Initialized
INFO - 2016-02-08 12:06:03 --> Language Class Initialized
INFO - 2016-02-08 12:06:03 --> Loader Class Initialized
INFO - 2016-02-08 12:06:03 --> Helper loaded: url_helper
INFO - 2016-02-08 12:06:03 --> Helper loaded: file_helper
INFO - 2016-02-08 12:06:03 --> Helper loaded: date_helper
INFO - 2016-02-08 12:06:03 --> Helper loaded: form_helper
INFO - 2016-02-08 12:06:03 --> Database Driver Class Initialized
INFO - 2016-02-08 12:06:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:06:04 --> Controller Class Initialized
INFO - 2016-02-08 12:06:04 --> Model Class Initialized
INFO - 2016-02-08 12:06:04 --> Model Class Initialized
INFO - 2016-02-08 12:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:06:04 --> Pagination Class Initialized
INFO - 2016-02-08 12:06:04 --> Form Validation Class Initialized
INFO - 2016-02-08 12:06:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:06:04 --> Model Class Initialized
INFO - 2016-02-08 12:06:04 --> Final output sent to browser
DEBUG - 2016-02-08 12:06:04 --> Total execution time: 1.1992
INFO - 2016-02-08 12:06:43 --> Config Class Initialized
INFO - 2016-02-08 12:06:43 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:06:43 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:06:43 --> Utf8 Class Initialized
INFO - 2016-02-08 12:06:43 --> URI Class Initialized
INFO - 2016-02-08 12:06:43 --> Router Class Initialized
INFO - 2016-02-08 12:06:43 --> Output Class Initialized
INFO - 2016-02-08 12:06:43 --> Security Class Initialized
DEBUG - 2016-02-08 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:06:43 --> Input Class Initialized
INFO - 2016-02-08 12:06:43 --> Language Class Initialized
INFO - 2016-02-08 12:06:43 --> Loader Class Initialized
INFO - 2016-02-08 12:06:43 --> Helper loaded: url_helper
INFO - 2016-02-08 12:06:43 --> Helper loaded: file_helper
INFO - 2016-02-08 12:06:43 --> Helper loaded: date_helper
INFO - 2016-02-08 12:06:43 --> Helper loaded: form_helper
INFO - 2016-02-08 12:06:43 --> Database Driver Class Initialized
INFO - 2016-02-08 12:06:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:06:44 --> Controller Class Initialized
INFO - 2016-02-08 12:06:44 --> Model Class Initialized
INFO - 2016-02-08 12:06:44 --> Model Class Initialized
INFO - 2016-02-08 12:06:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:06:44 --> Pagination Class Initialized
INFO - 2016-02-08 12:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:06:44 --> Helper loaded: text_helper
INFO - 2016-02-08 12:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:06:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:06:44 --> Final output sent to browser
DEBUG - 2016-02-08 12:06:44 --> Total execution time: 1.2003
INFO - 2016-02-08 12:06:49 --> Config Class Initialized
INFO - 2016-02-08 12:06:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:06:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:06:49 --> Utf8 Class Initialized
INFO - 2016-02-08 12:06:49 --> URI Class Initialized
INFO - 2016-02-08 12:06:49 --> Router Class Initialized
INFO - 2016-02-08 12:06:49 --> Output Class Initialized
INFO - 2016-02-08 12:06:49 --> Security Class Initialized
DEBUG - 2016-02-08 12:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:06:49 --> Input Class Initialized
INFO - 2016-02-08 12:06:49 --> Language Class Initialized
INFO - 2016-02-08 12:06:49 --> Loader Class Initialized
INFO - 2016-02-08 12:06:49 --> Helper loaded: url_helper
INFO - 2016-02-08 12:06:49 --> Helper loaded: file_helper
INFO - 2016-02-08 12:06:49 --> Helper loaded: date_helper
INFO - 2016-02-08 12:06:49 --> Helper loaded: form_helper
INFO - 2016-02-08 12:06:49 --> Database Driver Class Initialized
INFO - 2016-02-08 12:06:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:06:50 --> Controller Class Initialized
INFO - 2016-02-08 12:06:50 --> Model Class Initialized
INFO - 2016-02-08 12:06:50 --> Model Class Initialized
INFO - 2016-02-08 12:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:06:50 --> Pagination Class Initialized
INFO - 2016-02-08 12:06:50 --> Form Validation Class Initialized
INFO - 2016-02-08 12:06:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:06:50 --> Model Class Initialized
INFO - 2016-02-08 12:06:51 --> Final output sent to browser
DEBUG - 2016-02-08 12:06:51 --> Total execution time: 1.1800
INFO - 2016-02-08 12:07:04 --> Config Class Initialized
INFO - 2016-02-08 12:07:04 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:07:04 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:07:04 --> Utf8 Class Initialized
INFO - 2016-02-08 12:07:04 --> URI Class Initialized
INFO - 2016-02-08 12:07:04 --> Router Class Initialized
INFO - 2016-02-08 12:07:04 --> Output Class Initialized
INFO - 2016-02-08 12:07:04 --> Security Class Initialized
DEBUG - 2016-02-08 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:07:04 --> Input Class Initialized
INFO - 2016-02-08 12:07:04 --> Language Class Initialized
INFO - 2016-02-08 12:07:04 --> Loader Class Initialized
INFO - 2016-02-08 12:07:04 --> Helper loaded: url_helper
INFO - 2016-02-08 12:07:04 --> Helper loaded: file_helper
INFO - 2016-02-08 12:07:04 --> Helper loaded: date_helper
INFO - 2016-02-08 12:07:04 --> Helper loaded: form_helper
INFO - 2016-02-08 12:07:04 --> Database Driver Class Initialized
INFO - 2016-02-08 12:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:07:05 --> Controller Class Initialized
INFO - 2016-02-08 12:07:05 --> Model Class Initialized
INFO - 2016-02-08 12:07:05 --> Model Class Initialized
INFO - 2016-02-08 12:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:07:05 --> Pagination Class Initialized
INFO - 2016-02-08 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:07:05 --> Helper loaded: text_helper
INFO - 2016-02-08 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:07:05 --> Final output sent to browser
DEBUG - 2016-02-08 12:07:05 --> Total execution time: 1.2227
INFO - 2016-02-08 12:07:10 --> Config Class Initialized
INFO - 2016-02-08 12:07:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:07:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:07:10 --> Utf8 Class Initialized
INFO - 2016-02-08 12:07:10 --> URI Class Initialized
INFO - 2016-02-08 12:07:10 --> Router Class Initialized
INFO - 2016-02-08 12:07:10 --> Output Class Initialized
INFO - 2016-02-08 12:07:10 --> Security Class Initialized
DEBUG - 2016-02-08 12:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:07:10 --> Input Class Initialized
INFO - 2016-02-08 12:07:10 --> Language Class Initialized
INFO - 2016-02-08 12:07:10 --> Loader Class Initialized
INFO - 2016-02-08 12:07:10 --> Helper loaded: url_helper
INFO - 2016-02-08 12:07:10 --> Helper loaded: file_helper
INFO - 2016-02-08 12:07:10 --> Helper loaded: date_helper
INFO - 2016-02-08 12:07:10 --> Helper loaded: form_helper
INFO - 2016-02-08 12:07:10 --> Database Driver Class Initialized
INFO - 2016-02-08 12:07:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:07:11 --> Controller Class Initialized
INFO - 2016-02-08 12:07:11 --> Model Class Initialized
INFO - 2016-02-08 12:07:11 --> Model Class Initialized
INFO - 2016-02-08 12:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:07:11 --> Pagination Class Initialized
INFO - 2016-02-08 12:07:11 --> Form Validation Class Initialized
INFO - 2016-02-08 12:07:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:07:11 --> Model Class Initialized
INFO - 2016-02-08 12:07:11 --> Final output sent to browser
DEBUG - 2016-02-08 12:07:11 --> Total execution time: 1.1877
INFO - 2016-02-08 12:27:17 --> Config Class Initialized
INFO - 2016-02-08 12:27:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:27:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:27:17 --> Utf8 Class Initialized
INFO - 2016-02-08 12:27:17 --> URI Class Initialized
INFO - 2016-02-08 12:27:17 --> Router Class Initialized
INFO - 2016-02-08 12:27:17 --> Output Class Initialized
INFO - 2016-02-08 12:27:17 --> Security Class Initialized
DEBUG - 2016-02-08 12:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:27:17 --> Input Class Initialized
INFO - 2016-02-08 12:27:17 --> Language Class Initialized
INFO - 2016-02-08 12:27:17 --> Loader Class Initialized
INFO - 2016-02-08 12:27:17 --> Helper loaded: url_helper
INFO - 2016-02-08 12:27:17 --> Helper loaded: file_helper
INFO - 2016-02-08 12:27:17 --> Helper loaded: date_helper
INFO - 2016-02-08 12:27:17 --> Helper loaded: form_helper
INFO - 2016-02-08 12:27:17 --> Database Driver Class Initialized
INFO - 2016-02-08 12:27:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:27:18 --> Controller Class Initialized
INFO - 2016-02-08 12:27:18 --> Model Class Initialized
INFO - 2016-02-08 12:27:18 --> Model Class Initialized
INFO - 2016-02-08 12:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:27:19 --> Pagination Class Initialized
INFO - 2016-02-08 12:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:27:19 --> Helper loaded: text_helper
INFO - 2016-02-08 12:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:27:19 --> Final output sent to browser
DEBUG - 2016-02-08 12:27:19 --> Total execution time: 1.2758
INFO - 2016-02-08 12:27:25 --> Config Class Initialized
INFO - 2016-02-08 12:27:25 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:27:25 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:27:25 --> Utf8 Class Initialized
INFO - 2016-02-08 12:27:25 --> URI Class Initialized
INFO - 2016-02-08 12:27:25 --> Router Class Initialized
INFO - 2016-02-08 12:27:25 --> Output Class Initialized
INFO - 2016-02-08 12:27:25 --> Security Class Initialized
DEBUG - 2016-02-08 12:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:27:25 --> Input Class Initialized
INFO - 2016-02-08 12:27:25 --> Language Class Initialized
INFO - 2016-02-08 12:27:25 --> Loader Class Initialized
INFO - 2016-02-08 12:27:25 --> Helper loaded: url_helper
INFO - 2016-02-08 12:27:25 --> Helper loaded: file_helper
INFO - 2016-02-08 12:27:25 --> Helper loaded: date_helper
INFO - 2016-02-08 12:27:25 --> Helper loaded: form_helper
INFO - 2016-02-08 12:27:25 --> Database Driver Class Initialized
INFO - 2016-02-08 12:27:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:27:26 --> Controller Class Initialized
INFO - 2016-02-08 12:27:26 --> Model Class Initialized
INFO - 2016-02-08 12:27:26 --> Model Class Initialized
INFO - 2016-02-08 12:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:27:26 --> Pagination Class Initialized
INFO - 2016-02-08 12:27:26 --> Form Validation Class Initialized
INFO - 2016-02-08 12:27:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:27:26 --> Model Class Initialized
INFO - 2016-02-08 12:27:26 --> Final output sent to browser
DEBUG - 2016-02-08 12:27:26 --> Total execution time: 1.1881
INFO - 2016-02-08 12:27:42 --> Config Class Initialized
INFO - 2016-02-08 12:27:42 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:27:42 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:27:42 --> Utf8 Class Initialized
INFO - 2016-02-08 12:27:42 --> URI Class Initialized
INFO - 2016-02-08 12:27:42 --> Router Class Initialized
INFO - 2016-02-08 12:27:42 --> Output Class Initialized
INFO - 2016-02-08 12:27:42 --> Security Class Initialized
DEBUG - 2016-02-08 12:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:27:42 --> Input Class Initialized
INFO - 2016-02-08 12:27:42 --> Language Class Initialized
INFO - 2016-02-08 12:27:42 --> Loader Class Initialized
INFO - 2016-02-08 12:27:42 --> Helper loaded: url_helper
INFO - 2016-02-08 12:27:42 --> Helper loaded: file_helper
INFO - 2016-02-08 12:27:42 --> Helper loaded: date_helper
INFO - 2016-02-08 12:27:42 --> Helper loaded: form_helper
INFO - 2016-02-08 12:27:42 --> Database Driver Class Initialized
INFO - 2016-02-08 12:27:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:27:43 --> Controller Class Initialized
INFO - 2016-02-08 12:27:43 --> Model Class Initialized
INFO - 2016-02-08 12:27:43 --> Model Class Initialized
INFO - 2016-02-08 12:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:27:43 --> Pagination Class Initialized
INFO - 2016-02-08 12:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:27:43 --> Helper loaded: text_helper
INFO - 2016-02-08 12:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:27:43 --> Final output sent to browser
DEBUG - 2016-02-08 12:27:43 --> Total execution time: 1.2043
INFO - 2016-02-08 12:27:51 --> Config Class Initialized
INFO - 2016-02-08 12:27:51 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:27:51 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:27:51 --> Utf8 Class Initialized
INFO - 2016-02-08 12:27:51 --> URI Class Initialized
INFO - 2016-02-08 12:27:51 --> Router Class Initialized
INFO - 2016-02-08 12:27:51 --> Output Class Initialized
INFO - 2016-02-08 12:27:51 --> Security Class Initialized
DEBUG - 2016-02-08 12:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:27:51 --> Input Class Initialized
INFO - 2016-02-08 12:27:51 --> Language Class Initialized
INFO - 2016-02-08 12:27:51 --> Loader Class Initialized
INFO - 2016-02-08 12:27:51 --> Helper loaded: url_helper
INFO - 2016-02-08 12:27:51 --> Helper loaded: file_helper
INFO - 2016-02-08 12:27:51 --> Helper loaded: date_helper
INFO - 2016-02-08 12:27:51 --> Helper loaded: form_helper
INFO - 2016-02-08 12:27:51 --> Database Driver Class Initialized
INFO - 2016-02-08 12:27:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:27:52 --> Controller Class Initialized
INFO - 2016-02-08 12:27:52 --> Model Class Initialized
INFO - 2016-02-08 12:27:52 --> Model Class Initialized
INFO - 2016-02-08 12:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:27:52 --> Pagination Class Initialized
INFO - 2016-02-08 12:27:52 --> Form Validation Class Initialized
INFO - 2016-02-08 12:27:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:27:52 --> Model Class Initialized
INFO - 2016-02-08 12:27:52 --> Final output sent to browser
DEBUG - 2016-02-08 12:27:52 --> Total execution time: 1.1774
INFO - 2016-02-08 12:33:10 --> Config Class Initialized
INFO - 2016-02-08 12:33:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:33:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:33:10 --> Utf8 Class Initialized
INFO - 2016-02-08 12:33:10 --> URI Class Initialized
INFO - 2016-02-08 12:33:10 --> Router Class Initialized
INFO - 2016-02-08 12:33:10 --> Output Class Initialized
INFO - 2016-02-08 12:33:10 --> Security Class Initialized
DEBUG - 2016-02-08 12:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:33:10 --> Input Class Initialized
INFO - 2016-02-08 12:33:10 --> Language Class Initialized
INFO - 2016-02-08 12:33:10 --> Loader Class Initialized
INFO - 2016-02-08 12:33:10 --> Helper loaded: url_helper
INFO - 2016-02-08 12:33:10 --> Helper loaded: file_helper
INFO - 2016-02-08 12:33:10 --> Helper loaded: date_helper
INFO - 2016-02-08 12:33:10 --> Helper loaded: form_helper
INFO - 2016-02-08 12:33:10 --> Database Driver Class Initialized
INFO - 2016-02-08 12:33:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:33:11 --> Controller Class Initialized
INFO - 2016-02-08 12:33:11 --> Model Class Initialized
INFO - 2016-02-08 12:33:11 --> Model Class Initialized
INFO - 2016-02-08 12:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:33:11 --> Pagination Class Initialized
INFO - 2016-02-08 12:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:33:11 --> Helper loaded: text_helper
INFO - 2016-02-08 12:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:33:11 --> Final output sent to browser
DEBUG - 2016-02-08 12:33:11 --> Total execution time: 1.1966
INFO - 2016-02-08 12:33:39 --> Config Class Initialized
INFO - 2016-02-08 12:33:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:33:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:33:39 --> Utf8 Class Initialized
INFO - 2016-02-08 12:33:39 --> URI Class Initialized
INFO - 2016-02-08 12:33:39 --> Router Class Initialized
INFO - 2016-02-08 12:33:39 --> Output Class Initialized
INFO - 2016-02-08 12:33:39 --> Security Class Initialized
DEBUG - 2016-02-08 12:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:33:39 --> Input Class Initialized
INFO - 2016-02-08 12:33:39 --> Language Class Initialized
INFO - 2016-02-08 12:33:39 --> Loader Class Initialized
INFO - 2016-02-08 12:33:39 --> Helper loaded: url_helper
INFO - 2016-02-08 12:33:39 --> Helper loaded: file_helper
INFO - 2016-02-08 12:33:39 --> Helper loaded: date_helper
INFO - 2016-02-08 12:33:39 --> Helper loaded: form_helper
INFO - 2016-02-08 12:33:39 --> Database Driver Class Initialized
INFO - 2016-02-08 12:33:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:33:40 --> Controller Class Initialized
INFO - 2016-02-08 12:33:40 --> Model Class Initialized
INFO - 2016-02-08 12:33:40 --> Model Class Initialized
INFO - 2016-02-08 12:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:33:40 --> Pagination Class Initialized
INFO - 2016-02-08 12:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:33:40 --> Helper loaded: text_helper
INFO - 2016-02-08 12:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:33:40 --> Final output sent to browser
DEBUG - 2016-02-08 12:33:40 --> Total execution time: 1.2018
INFO - 2016-02-08 12:34:12 --> Config Class Initialized
INFO - 2016-02-08 12:34:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:34:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:34:12 --> Utf8 Class Initialized
INFO - 2016-02-08 12:34:12 --> URI Class Initialized
INFO - 2016-02-08 12:34:12 --> Router Class Initialized
INFO - 2016-02-08 12:34:12 --> Output Class Initialized
INFO - 2016-02-08 12:34:12 --> Security Class Initialized
DEBUG - 2016-02-08 12:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:34:12 --> Input Class Initialized
INFO - 2016-02-08 12:34:12 --> Language Class Initialized
INFO - 2016-02-08 12:34:12 --> Loader Class Initialized
INFO - 2016-02-08 12:34:12 --> Helper loaded: url_helper
INFO - 2016-02-08 12:34:12 --> Helper loaded: file_helper
INFO - 2016-02-08 12:34:12 --> Helper loaded: date_helper
INFO - 2016-02-08 12:34:12 --> Helper loaded: form_helper
INFO - 2016-02-08 12:34:12 --> Database Driver Class Initialized
INFO - 2016-02-08 12:34:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:34:13 --> Controller Class Initialized
INFO - 2016-02-08 12:34:13 --> Model Class Initialized
INFO - 2016-02-08 12:34:13 --> Model Class Initialized
INFO - 2016-02-08 12:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:34:13 --> Pagination Class Initialized
INFO - 2016-02-08 12:34:13 --> Form Validation Class Initialized
INFO - 2016-02-08 12:34:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:34:13 --> Model Class Initialized
INFO - 2016-02-08 12:34:13 --> Final output sent to browser
DEBUG - 2016-02-08 12:34:13 --> Total execution time: 1.1922
INFO - 2016-02-08 12:36:17 --> Config Class Initialized
INFO - 2016-02-08 12:36:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:36:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:36:17 --> Utf8 Class Initialized
INFO - 2016-02-08 12:36:17 --> URI Class Initialized
INFO - 2016-02-08 12:36:17 --> Router Class Initialized
INFO - 2016-02-08 12:36:17 --> Output Class Initialized
INFO - 2016-02-08 12:36:17 --> Security Class Initialized
DEBUG - 2016-02-08 12:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:36:17 --> Input Class Initialized
INFO - 2016-02-08 12:36:17 --> Language Class Initialized
INFO - 2016-02-08 12:36:17 --> Loader Class Initialized
INFO - 2016-02-08 12:36:17 --> Helper loaded: url_helper
INFO - 2016-02-08 12:36:17 --> Helper loaded: file_helper
INFO - 2016-02-08 12:36:17 --> Helper loaded: date_helper
INFO - 2016-02-08 12:36:17 --> Helper loaded: form_helper
INFO - 2016-02-08 12:36:17 --> Database Driver Class Initialized
INFO - 2016-02-08 12:36:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:36:18 --> Controller Class Initialized
INFO - 2016-02-08 12:36:18 --> Model Class Initialized
INFO - 2016-02-08 12:36:18 --> Model Class Initialized
INFO - 2016-02-08 12:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:36:18 --> Pagination Class Initialized
INFO - 2016-02-08 12:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 12:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 12:36:18 --> Helper loaded: text_helper
INFO - 2016-02-08 12:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 12:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 12:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 12:36:18 --> Final output sent to browser
DEBUG - 2016-02-08 12:36:18 --> Total execution time: 1.1927
INFO - 2016-02-08 12:36:25 --> Config Class Initialized
INFO - 2016-02-08 12:36:25 --> Hooks Class Initialized
DEBUG - 2016-02-08 12:36:25 --> UTF-8 Support Enabled
INFO - 2016-02-08 12:36:25 --> Utf8 Class Initialized
INFO - 2016-02-08 12:36:25 --> URI Class Initialized
INFO - 2016-02-08 12:36:25 --> Router Class Initialized
INFO - 2016-02-08 12:36:25 --> Output Class Initialized
INFO - 2016-02-08 12:36:25 --> Security Class Initialized
DEBUG - 2016-02-08 12:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 12:36:25 --> Input Class Initialized
INFO - 2016-02-08 12:36:25 --> Language Class Initialized
INFO - 2016-02-08 12:36:25 --> Loader Class Initialized
INFO - 2016-02-08 12:36:25 --> Helper loaded: url_helper
INFO - 2016-02-08 12:36:25 --> Helper loaded: file_helper
INFO - 2016-02-08 12:36:25 --> Helper loaded: date_helper
INFO - 2016-02-08 12:36:25 --> Helper loaded: form_helper
INFO - 2016-02-08 12:36:25 --> Database Driver Class Initialized
INFO - 2016-02-08 12:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 12:36:26 --> Controller Class Initialized
INFO - 2016-02-08 12:36:26 --> Model Class Initialized
INFO - 2016-02-08 12:36:26 --> Model Class Initialized
INFO - 2016-02-08 12:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 12:36:27 --> Pagination Class Initialized
INFO - 2016-02-08 12:36:27 --> Form Validation Class Initialized
INFO - 2016-02-08 12:36:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 12:36:27 --> Model Class Initialized
INFO - 2016-02-08 12:36:27 --> Final output sent to browser
DEBUG - 2016-02-08 12:36:27 --> Total execution time: 1.2046
INFO - 2016-02-08 13:02:22 --> Config Class Initialized
INFO - 2016-02-08 13:02:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:02:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:02:22 --> Utf8 Class Initialized
INFO - 2016-02-08 13:02:22 --> URI Class Initialized
INFO - 2016-02-08 13:02:22 --> Router Class Initialized
INFO - 2016-02-08 13:02:22 --> Output Class Initialized
INFO - 2016-02-08 13:02:22 --> Security Class Initialized
DEBUG - 2016-02-08 13:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:02:22 --> Input Class Initialized
INFO - 2016-02-08 13:02:22 --> Language Class Initialized
INFO - 2016-02-08 13:02:22 --> Loader Class Initialized
INFO - 2016-02-08 13:02:22 --> Helper loaded: url_helper
INFO - 2016-02-08 13:02:22 --> Helper loaded: file_helper
INFO - 2016-02-08 13:02:22 --> Helper loaded: date_helper
INFO - 2016-02-08 13:02:22 --> Helper loaded: form_helper
INFO - 2016-02-08 13:02:22 --> Database Driver Class Initialized
INFO - 2016-02-08 13:02:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:02:23 --> Controller Class Initialized
INFO - 2016-02-08 13:02:23 --> Model Class Initialized
INFO - 2016-02-08 13:02:23 --> Model Class Initialized
INFO - 2016-02-08 13:02:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:02:23 --> Pagination Class Initialized
INFO - 2016-02-08 13:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:02:23 --> Helper loaded: text_helper
INFO - 2016-02-08 13:02:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:02:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:02:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:02:24 --> Final output sent to browser
DEBUG - 2016-02-08 13:02:24 --> Total execution time: 1.1810
INFO - 2016-02-08 13:02:32 --> Config Class Initialized
INFO - 2016-02-08 13:02:32 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:02:32 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:02:32 --> Utf8 Class Initialized
INFO - 2016-02-08 13:02:32 --> URI Class Initialized
INFO - 2016-02-08 13:02:32 --> Router Class Initialized
INFO - 2016-02-08 13:02:32 --> Output Class Initialized
INFO - 2016-02-08 13:02:32 --> Security Class Initialized
DEBUG - 2016-02-08 13:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:02:32 --> Input Class Initialized
INFO - 2016-02-08 13:02:32 --> Language Class Initialized
INFO - 2016-02-08 13:02:32 --> Loader Class Initialized
INFO - 2016-02-08 13:02:32 --> Helper loaded: url_helper
INFO - 2016-02-08 13:02:32 --> Helper loaded: file_helper
INFO - 2016-02-08 13:02:32 --> Helper loaded: date_helper
INFO - 2016-02-08 13:02:32 --> Helper loaded: form_helper
INFO - 2016-02-08 13:02:32 --> Database Driver Class Initialized
INFO - 2016-02-08 13:02:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:02:33 --> Controller Class Initialized
INFO - 2016-02-08 13:02:33 --> Model Class Initialized
INFO - 2016-02-08 13:02:33 --> Model Class Initialized
INFO - 2016-02-08 13:02:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:02:33 --> Pagination Class Initialized
INFO - 2016-02-08 13:02:33 --> Form Validation Class Initialized
INFO - 2016-02-08 13:02:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:02:33 --> Model Class Initialized
INFO - 2016-02-08 13:02:33 --> Final output sent to browser
DEBUG - 2016-02-08 13:02:33 --> Total execution time: 1.1650
INFO - 2016-02-08 13:03:24 --> Config Class Initialized
INFO - 2016-02-08 13:03:24 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:03:24 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:03:24 --> Utf8 Class Initialized
INFO - 2016-02-08 13:03:24 --> URI Class Initialized
INFO - 2016-02-08 13:03:24 --> Router Class Initialized
INFO - 2016-02-08 13:03:24 --> Output Class Initialized
INFO - 2016-02-08 13:03:24 --> Security Class Initialized
DEBUG - 2016-02-08 13:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:03:24 --> Input Class Initialized
INFO - 2016-02-08 13:03:24 --> Language Class Initialized
INFO - 2016-02-08 13:03:24 --> Loader Class Initialized
INFO - 2016-02-08 13:03:24 --> Helper loaded: url_helper
INFO - 2016-02-08 13:03:24 --> Helper loaded: file_helper
INFO - 2016-02-08 13:03:24 --> Helper loaded: date_helper
INFO - 2016-02-08 13:03:24 --> Helper loaded: form_helper
INFO - 2016-02-08 13:03:24 --> Database Driver Class Initialized
INFO - 2016-02-08 13:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:03:25 --> Controller Class Initialized
INFO - 2016-02-08 13:03:25 --> Model Class Initialized
INFO - 2016-02-08 13:03:25 --> Model Class Initialized
INFO - 2016-02-08 13:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:03:25 --> Pagination Class Initialized
INFO - 2016-02-08 13:03:25 --> Form Validation Class Initialized
INFO - 2016-02-08 13:03:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:03:25 --> Model Class Initialized
INFO - 2016-02-08 13:03:25 --> Final output sent to browser
DEBUG - 2016-02-08 13:03:25 --> Total execution time: 1.2115
INFO - 2016-02-08 13:03:28 --> Config Class Initialized
INFO - 2016-02-08 13:03:28 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:03:29 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:03:29 --> Utf8 Class Initialized
INFO - 2016-02-08 13:03:29 --> URI Class Initialized
INFO - 2016-02-08 13:03:29 --> Router Class Initialized
INFO - 2016-02-08 13:03:29 --> Output Class Initialized
INFO - 2016-02-08 13:03:29 --> Security Class Initialized
DEBUG - 2016-02-08 13:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:03:29 --> Input Class Initialized
INFO - 2016-02-08 13:03:29 --> Language Class Initialized
INFO - 2016-02-08 13:03:29 --> Loader Class Initialized
INFO - 2016-02-08 13:03:29 --> Helper loaded: url_helper
INFO - 2016-02-08 13:03:29 --> Helper loaded: file_helper
INFO - 2016-02-08 13:03:29 --> Helper loaded: date_helper
INFO - 2016-02-08 13:03:29 --> Helper loaded: form_helper
INFO - 2016-02-08 13:03:29 --> Database Driver Class Initialized
INFO - 2016-02-08 13:03:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:03:30 --> Controller Class Initialized
INFO - 2016-02-08 13:03:30 --> Model Class Initialized
INFO - 2016-02-08 13:03:30 --> Model Class Initialized
INFO - 2016-02-08 13:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:03:30 --> Pagination Class Initialized
INFO - 2016-02-08 13:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:03:30 --> Helper loaded: text_helper
INFO - 2016-02-08 13:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:03:30 --> Final output sent to browser
DEBUG - 2016-02-08 13:03:30 --> Total execution time: 1.1916
INFO - 2016-02-08 13:19:06 --> Config Class Initialized
INFO - 2016-02-08 13:19:06 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:19:06 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:19:06 --> Utf8 Class Initialized
INFO - 2016-02-08 13:19:06 --> URI Class Initialized
INFO - 2016-02-08 13:19:06 --> Router Class Initialized
INFO - 2016-02-08 13:19:06 --> Output Class Initialized
INFO - 2016-02-08 13:19:06 --> Security Class Initialized
DEBUG - 2016-02-08 13:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:19:06 --> Input Class Initialized
INFO - 2016-02-08 13:19:06 --> Language Class Initialized
INFO - 2016-02-08 13:19:06 --> Loader Class Initialized
INFO - 2016-02-08 13:19:06 --> Helper loaded: url_helper
INFO - 2016-02-08 13:19:06 --> Helper loaded: file_helper
INFO - 2016-02-08 13:19:06 --> Helper loaded: date_helper
INFO - 2016-02-08 13:19:06 --> Helper loaded: form_helper
INFO - 2016-02-08 13:19:06 --> Database Driver Class Initialized
INFO - 2016-02-08 13:19:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:19:07 --> Controller Class Initialized
INFO - 2016-02-08 13:19:07 --> Model Class Initialized
INFO - 2016-02-08 13:19:07 --> Model Class Initialized
INFO - 2016-02-08 13:19:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:19:07 --> Pagination Class Initialized
INFO - 2016-02-08 13:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:19:08 --> Helper loaded: text_helper
INFO - 2016-02-08 13:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:19:08 --> Final output sent to browser
DEBUG - 2016-02-08 13:19:08 --> Total execution time: 1.1872
INFO - 2016-02-08 13:19:14 --> Config Class Initialized
INFO - 2016-02-08 13:19:14 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:19:14 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:19:14 --> Utf8 Class Initialized
INFO - 2016-02-08 13:19:14 --> URI Class Initialized
INFO - 2016-02-08 13:19:14 --> Router Class Initialized
INFO - 2016-02-08 13:19:14 --> Output Class Initialized
INFO - 2016-02-08 13:19:14 --> Security Class Initialized
DEBUG - 2016-02-08 13:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:19:14 --> Input Class Initialized
INFO - 2016-02-08 13:19:14 --> Language Class Initialized
INFO - 2016-02-08 13:19:14 --> Loader Class Initialized
INFO - 2016-02-08 13:19:14 --> Helper loaded: url_helper
INFO - 2016-02-08 13:19:14 --> Helper loaded: file_helper
INFO - 2016-02-08 13:19:14 --> Helper loaded: date_helper
INFO - 2016-02-08 13:19:14 --> Helper loaded: form_helper
INFO - 2016-02-08 13:19:14 --> Database Driver Class Initialized
INFO - 2016-02-08 13:19:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:19:15 --> Controller Class Initialized
INFO - 2016-02-08 13:19:15 --> Model Class Initialized
INFO - 2016-02-08 13:19:15 --> Model Class Initialized
INFO - 2016-02-08 13:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:19:15 --> Pagination Class Initialized
INFO - 2016-02-08 13:19:15 --> Form Validation Class Initialized
INFO - 2016-02-08 13:19:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:19:15 --> Model Class Initialized
INFO - 2016-02-08 13:19:15 --> Final output sent to browser
DEBUG - 2016-02-08 13:19:15 --> Total execution time: 1.1907
INFO - 2016-02-08 13:19:28 --> Config Class Initialized
INFO - 2016-02-08 13:19:28 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:19:28 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:19:28 --> Utf8 Class Initialized
INFO - 2016-02-08 13:19:28 --> URI Class Initialized
INFO - 2016-02-08 13:19:28 --> Router Class Initialized
INFO - 2016-02-08 13:19:28 --> Output Class Initialized
INFO - 2016-02-08 13:19:28 --> Security Class Initialized
DEBUG - 2016-02-08 13:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:19:28 --> Input Class Initialized
INFO - 2016-02-08 13:19:28 --> Language Class Initialized
INFO - 2016-02-08 13:19:28 --> Loader Class Initialized
INFO - 2016-02-08 13:19:28 --> Helper loaded: url_helper
INFO - 2016-02-08 13:19:28 --> Helper loaded: file_helper
INFO - 2016-02-08 13:19:28 --> Helper loaded: date_helper
INFO - 2016-02-08 13:19:28 --> Helper loaded: form_helper
INFO - 2016-02-08 13:19:28 --> Database Driver Class Initialized
INFO - 2016-02-08 13:19:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:19:29 --> Controller Class Initialized
INFO - 2016-02-08 13:19:29 --> Model Class Initialized
INFO - 2016-02-08 13:19:29 --> Model Class Initialized
INFO - 2016-02-08 13:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:19:29 --> Pagination Class Initialized
INFO - 2016-02-08 13:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:19:29 --> Helper loaded: text_helper
INFO - 2016-02-08 13:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:19:29 --> Final output sent to browser
DEBUG - 2016-02-08 13:19:29 --> Total execution time: 1.1528
INFO - 2016-02-08 13:22:18 --> Config Class Initialized
INFO - 2016-02-08 13:22:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:22:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:22:18 --> Utf8 Class Initialized
INFO - 2016-02-08 13:22:18 --> URI Class Initialized
INFO - 2016-02-08 13:22:18 --> Router Class Initialized
INFO - 2016-02-08 13:22:18 --> Output Class Initialized
INFO - 2016-02-08 13:22:18 --> Security Class Initialized
DEBUG - 2016-02-08 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:22:18 --> Input Class Initialized
INFO - 2016-02-08 13:22:18 --> Language Class Initialized
INFO - 2016-02-08 13:22:18 --> Loader Class Initialized
INFO - 2016-02-08 13:22:18 --> Helper loaded: url_helper
INFO - 2016-02-08 13:22:18 --> Helper loaded: file_helper
INFO - 2016-02-08 13:22:18 --> Helper loaded: date_helper
INFO - 2016-02-08 13:22:18 --> Helper loaded: form_helper
INFO - 2016-02-08 13:22:18 --> Database Driver Class Initialized
INFO - 2016-02-08 13:22:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:22:20 --> Controller Class Initialized
INFO - 2016-02-08 13:22:20 --> Model Class Initialized
INFO - 2016-02-08 13:22:20 --> Model Class Initialized
INFO - 2016-02-08 13:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:22:20 --> Pagination Class Initialized
INFO - 2016-02-08 13:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:22:20 --> Helper loaded: text_helper
INFO - 2016-02-08 13:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:22:20 --> Final output sent to browser
DEBUG - 2016-02-08 13:22:20 --> Total execution time: 1.2342
INFO - 2016-02-08 13:22:35 --> Config Class Initialized
INFO - 2016-02-08 13:22:35 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:22:35 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:22:35 --> Utf8 Class Initialized
INFO - 2016-02-08 13:22:35 --> URI Class Initialized
INFO - 2016-02-08 13:22:35 --> Router Class Initialized
INFO - 2016-02-08 13:22:35 --> Output Class Initialized
INFO - 2016-02-08 13:22:35 --> Security Class Initialized
DEBUG - 2016-02-08 13:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:22:35 --> Input Class Initialized
INFO - 2016-02-08 13:22:35 --> Language Class Initialized
INFO - 2016-02-08 13:22:35 --> Loader Class Initialized
INFO - 2016-02-08 13:22:35 --> Helper loaded: url_helper
INFO - 2016-02-08 13:22:35 --> Helper loaded: file_helper
INFO - 2016-02-08 13:22:35 --> Helper loaded: date_helper
INFO - 2016-02-08 13:22:35 --> Helper loaded: form_helper
INFO - 2016-02-08 13:22:35 --> Database Driver Class Initialized
INFO - 2016-02-08 13:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:22:36 --> Controller Class Initialized
INFO - 2016-02-08 13:22:36 --> Model Class Initialized
INFO - 2016-02-08 13:22:36 --> Model Class Initialized
INFO - 2016-02-08 13:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:22:36 --> Pagination Class Initialized
INFO - 2016-02-08 13:22:36 --> Form Validation Class Initialized
INFO - 2016-02-08 13:22:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:22:36 --> Model Class Initialized
ERROR - 2016-02-08 13:22:36 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 218
INFO - 2016-02-08 13:22:36 --> Final output sent to browser
DEBUG - 2016-02-08 13:22:36 --> Total execution time: 1.2302
INFO - 2016-02-08 13:22:54 --> Config Class Initialized
INFO - 2016-02-08 13:22:54 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:22:54 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:22:54 --> Utf8 Class Initialized
INFO - 2016-02-08 13:22:54 --> URI Class Initialized
INFO - 2016-02-08 13:22:54 --> Router Class Initialized
INFO - 2016-02-08 13:22:54 --> Output Class Initialized
INFO - 2016-02-08 13:22:54 --> Security Class Initialized
DEBUG - 2016-02-08 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:22:54 --> Input Class Initialized
INFO - 2016-02-08 13:22:54 --> Language Class Initialized
INFO - 2016-02-08 13:22:54 --> Loader Class Initialized
INFO - 2016-02-08 13:22:54 --> Helper loaded: url_helper
INFO - 2016-02-08 13:22:54 --> Helper loaded: file_helper
INFO - 2016-02-08 13:22:54 --> Helper loaded: date_helper
INFO - 2016-02-08 13:22:54 --> Helper loaded: form_helper
INFO - 2016-02-08 13:22:54 --> Database Driver Class Initialized
INFO - 2016-02-08 13:22:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:22:55 --> Controller Class Initialized
INFO - 2016-02-08 13:22:55 --> Model Class Initialized
INFO - 2016-02-08 13:22:55 --> Model Class Initialized
INFO - 2016-02-08 13:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:22:55 --> Pagination Class Initialized
INFO - 2016-02-08 13:22:55 --> Form Validation Class Initialized
INFO - 2016-02-08 13:22:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:22:55 --> Model Class Initialized
ERROR - 2016-02-08 13:22:56 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 218
INFO - 2016-02-08 13:22:56 --> Final output sent to browser
DEBUG - 2016-02-08 13:22:56 --> Total execution time: 1.2719
INFO - 2016-02-08 13:23:52 --> Config Class Initialized
INFO - 2016-02-08 13:23:52 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:23:52 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:23:52 --> Utf8 Class Initialized
INFO - 2016-02-08 13:23:52 --> URI Class Initialized
INFO - 2016-02-08 13:23:52 --> Router Class Initialized
INFO - 2016-02-08 13:23:52 --> Output Class Initialized
INFO - 2016-02-08 13:23:52 --> Security Class Initialized
DEBUG - 2016-02-08 13:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:23:52 --> Input Class Initialized
INFO - 2016-02-08 13:23:52 --> Language Class Initialized
INFO - 2016-02-08 13:23:52 --> Loader Class Initialized
INFO - 2016-02-08 13:23:52 --> Helper loaded: url_helper
INFO - 2016-02-08 13:23:52 --> Helper loaded: file_helper
INFO - 2016-02-08 13:23:52 --> Helper loaded: date_helper
INFO - 2016-02-08 13:23:52 --> Helper loaded: form_helper
INFO - 2016-02-08 13:23:52 --> Database Driver Class Initialized
INFO - 2016-02-08 13:23:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:23:53 --> Controller Class Initialized
INFO - 2016-02-08 13:23:53 --> Model Class Initialized
INFO - 2016-02-08 13:23:53 --> Model Class Initialized
INFO - 2016-02-08 13:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:23:53 --> Pagination Class Initialized
INFO - 2016-02-08 13:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:23:53 --> Helper loaded: text_helper
INFO - 2016-02-08 13:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:23:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:23:53 --> Final output sent to browser
DEBUG - 2016-02-08 13:23:53 --> Total execution time: 1.1938
INFO - 2016-02-08 13:24:01 --> Config Class Initialized
INFO - 2016-02-08 13:24:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:24:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:24:01 --> Utf8 Class Initialized
INFO - 2016-02-08 13:24:01 --> URI Class Initialized
INFO - 2016-02-08 13:24:01 --> Router Class Initialized
INFO - 2016-02-08 13:24:01 --> Output Class Initialized
INFO - 2016-02-08 13:24:01 --> Security Class Initialized
DEBUG - 2016-02-08 13:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:24:01 --> Input Class Initialized
INFO - 2016-02-08 13:24:01 --> Language Class Initialized
INFO - 2016-02-08 13:24:01 --> Loader Class Initialized
INFO - 2016-02-08 13:24:01 --> Helper loaded: url_helper
INFO - 2016-02-08 13:24:01 --> Helper loaded: file_helper
INFO - 2016-02-08 13:24:01 --> Helper loaded: date_helper
INFO - 2016-02-08 13:24:01 --> Helper loaded: form_helper
INFO - 2016-02-08 13:24:01 --> Database Driver Class Initialized
INFO - 2016-02-08 13:24:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:24:02 --> Controller Class Initialized
INFO - 2016-02-08 13:24:02 --> Model Class Initialized
INFO - 2016-02-08 13:24:02 --> Model Class Initialized
INFO - 2016-02-08 13:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:24:02 --> Pagination Class Initialized
INFO - 2016-02-08 13:24:02 --> Form Validation Class Initialized
INFO - 2016-02-08 13:24:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:24:02 --> Model Class Initialized
INFO - 2016-02-08 13:24:02 --> Final output sent to browser
DEBUG - 2016-02-08 13:24:02 --> Total execution time: 1.1851
INFO - 2016-02-08 13:25:34 --> Config Class Initialized
INFO - 2016-02-08 13:25:34 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:25:34 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:25:34 --> Utf8 Class Initialized
INFO - 2016-02-08 13:25:34 --> URI Class Initialized
INFO - 2016-02-08 13:25:34 --> Router Class Initialized
INFO - 2016-02-08 13:25:34 --> Output Class Initialized
INFO - 2016-02-08 13:25:34 --> Security Class Initialized
DEBUG - 2016-02-08 13:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:25:34 --> Input Class Initialized
INFO - 2016-02-08 13:25:34 --> Language Class Initialized
INFO - 2016-02-08 13:25:34 --> Loader Class Initialized
INFO - 2016-02-08 13:25:34 --> Helper loaded: url_helper
INFO - 2016-02-08 13:25:34 --> Helper loaded: file_helper
INFO - 2016-02-08 13:25:34 --> Helper loaded: date_helper
INFO - 2016-02-08 13:25:34 --> Helper loaded: form_helper
INFO - 2016-02-08 13:25:34 --> Database Driver Class Initialized
INFO - 2016-02-08 13:25:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:25:35 --> Controller Class Initialized
INFO - 2016-02-08 13:25:35 --> Model Class Initialized
INFO - 2016-02-08 13:25:35 --> Model Class Initialized
INFO - 2016-02-08 13:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:25:35 --> Pagination Class Initialized
INFO - 2016-02-08 13:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:25:35 --> Helper loaded: text_helper
INFO - 2016-02-08 13:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:25:35 --> Final output sent to browser
DEBUG - 2016-02-08 13:25:35 --> Total execution time: 1.1791
INFO - 2016-02-08 13:26:11 --> Config Class Initialized
INFO - 2016-02-08 13:26:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:26:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:26:11 --> Utf8 Class Initialized
INFO - 2016-02-08 13:26:11 --> URI Class Initialized
INFO - 2016-02-08 13:26:11 --> Router Class Initialized
INFO - 2016-02-08 13:26:11 --> Output Class Initialized
INFO - 2016-02-08 13:26:11 --> Security Class Initialized
DEBUG - 2016-02-08 13:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:26:11 --> Input Class Initialized
INFO - 2016-02-08 13:26:11 --> Language Class Initialized
INFO - 2016-02-08 13:26:11 --> Loader Class Initialized
INFO - 2016-02-08 13:26:11 --> Helper loaded: url_helper
INFO - 2016-02-08 13:26:11 --> Helper loaded: file_helper
INFO - 2016-02-08 13:26:11 --> Helper loaded: date_helper
INFO - 2016-02-08 13:26:11 --> Helper loaded: form_helper
INFO - 2016-02-08 13:26:11 --> Database Driver Class Initialized
INFO - 2016-02-08 13:26:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:26:12 --> Controller Class Initialized
INFO - 2016-02-08 13:26:12 --> Model Class Initialized
INFO - 2016-02-08 13:26:12 --> Model Class Initialized
INFO - 2016-02-08 13:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:26:12 --> Pagination Class Initialized
INFO - 2016-02-08 13:26:12 --> Form Validation Class Initialized
INFO - 2016-02-08 13:26:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:26:12 --> Model Class Initialized
INFO - 2016-02-08 13:26:12 --> Final output sent to browser
DEBUG - 2016-02-08 13:26:12 --> Total execution time: 1.1801
INFO - 2016-02-08 13:27:50 --> Config Class Initialized
INFO - 2016-02-08 13:27:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:27:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:27:50 --> Utf8 Class Initialized
INFO - 2016-02-08 13:27:50 --> URI Class Initialized
INFO - 2016-02-08 13:27:50 --> Router Class Initialized
INFO - 2016-02-08 13:27:50 --> Output Class Initialized
INFO - 2016-02-08 13:27:50 --> Security Class Initialized
DEBUG - 2016-02-08 13:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:27:50 --> Input Class Initialized
INFO - 2016-02-08 13:27:50 --> Language Class Initialized
INFO - 2016-02-08 13:27:50 --> Loader Class Initialized
INFO - 2016-02-08 13:27:50 --> Helper loaded: url_helper
INFO - 2016-02-08 13:27:50 --> Helper loaded: file_helper
INFO - 2016-02-08 13:27:50 --> Helper loaded: date_helper
INFO - 2016-02-08 13:27:50 --> Helper loaded: form_helper
INFO - 2016-02-08 13:27:50 --> Database Driver Class Initialized
INFO - 2016-02-08 13:27:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:27:51 --> Controller Class Initialized
INFO - 2016-02-08 13:27:51 --> Model Class Initialized
INFO - 2016-02-08 13:27:51 --> Model Class Initialized
INFO - 2016-02-08 13:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:27:51 --> Pagination Class Initialized
INFO - 2016-02-08 13:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:27:51 --> Helper loaded: text_helper
INFO - 2016-02-08 13:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:27:51 --> Final output sent to browser
DEBUG - 2016-02-08 13:27:51 --> Total execution time: 1.2067
INFO - 2016-02-08 13:28:03 --> Config Class Initialized
INFO - 2016-02-08 13:28:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:28:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:28:03 --> Utf8 Class Initialized
INFO - 2016-02-08 13:28:03 --> URI Class Initialized
INFO - 2016-02-08 13:28:03 --> Router Class Initialized
INFO - 2016-02-08 13:28:03 --> Output Class Initialized
INFO - 2016-02-08 13:28:03 --> Security Class Initialized
DEBUG - 2016-02-08 13:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:28:03 --> Input Class Initialized
INFO - 2016-02-08 13:28:03 --> Language Class Initialized
INFO - 2016-02-08 13:28:03 --> Loader Class Initialized
INFO - 2016-02-08 13:28:03 --> Helper loaded: url_helper
INFO - 2016-02-08 13:28:03 --> Helper loaded: file_helper
INFO - 2016-02-08 13:28:04 --> Helper loaded: date_helper
INFO - 2016-02-08 13:28:04 --> Helper loaded: form_helper
INFO - 2016-02-08 13:28:04 --> Database Driver Class Initialized
INFO - 2016-02-08 13:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:28:05 --> Controller Class Initialized
INFO - 2016-02-08 13:28:05 --> Model Class Initialized
INFO - 2016-02-08 13:28:05 --> Model Class Initialized
INFO - 2016-02-08 13:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:28:05 --> Pagination Class Initialized
INFO - 2016-02-08 13:28:05 --> Form Validation Class Initialized
INFO - 2016-02-08 13:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:28:05 --> Model Class Initialized
INFO - 2016-02-08 13:28:05 --> Final output sent to browser
DEBUG - 2016-02-08 13:28:05 --> Total execution time: 1.1847
INFO - 2016-02-08 13:29:24 --> Config Class Initialized
INFO - 2016-02-08 13:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:29:24 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:29:24 --> Utf8 Class Initialized
INFO - 2016-02-08 13:29:24 --> URI Class Initialized
INFO - 2016-02-08 13:29:24 --> Router Class Initialized
INFO - 2016-02-08 13:29:24 --> Output Class Initialized
INFO - 2016-02-08 13:29:24 --> Security Class Initialized
DEBUG - 2016-02-08 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:29:24 --> Input Class Initialized
INFO - 2016-02-08 13:29:24 --> Language Class Initialized
INFO - 2016-02-08 13:29:24 --> Loader Class Initialized
INFO - 2016-02-08 13:29:24 --> Helper loaded: url_helper
INFO - 2016-02-08 13:29:24 --> Helper loaded: file_helper
INFO - 2016-02-08 13:29:24 --> Helper loaded: date_helper
INFO - 2016-02-08 13:29:24 --> Helper loaded: form_helper
INFO - 2016-02-08 13:29:24 --> Database Driver Class Initialized
INFO - 2016-02-08 13:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:29:25 --> Controller Class Initialized
INFO - 2016-02-08 13:29:25 --> Model Class Initialized
INFO - 2016-02-08 13:29:25 --> Model Class Initialized
INFO - 2016-02-08 13:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:29:25 --> Pagination Class Initialized
INFO - 2016-02-08 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:29:25 --> Helper loaded: text_helper
INFO - 2016-02-08 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:29:25 --> Final output sent to browser
DEBUG - 2016-02-08 13:29:25 --> Total execution time: 1.2327
INFO - 2016-02-08 13:29:38 --> Config Class Initialized
INFO - 2016-02-08 13:29:38 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:29:38 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:29:38 --> Utf8 Class Initialized
INFO - 2016-02-08 13:29:38 --> URI Class Initialized
INFO - 2016-02-08 13:29:38 --> Router Class Initialized
INFO - 2016-02-08 13:29:38 --> Output Class Initialized
INFO - 2016-02-08 13:29:38 --> Security Class Initialized
DEBUG - 2016-02-08 13:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:29:38 --> Input Class Initialized
INFO - 2016-02-08 13:29:38 --> Language Class Initialized
INFO - 2016-02-08 13:29:38 --> Loader Class Initialized
INFO - 2016-02-08 13:29:38 --> Helper loaded: url_helper
INFO - 2016-02-08 13:29:38 --> Helper loaded: file_helper
INFO - 2016-02-08 13:29:38 --> Helper loaded: date_helper
INFO - 2016-02-08 13:29:38 --> Helper loaded: form_helper
INFO - 2016-02-08 13:29:38 --> Database Driver Class Initialized
INFO - 2016-02-08 13:29:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:29:39 --> Controller Class Initialized
INFO - 2016-02-08 13:29:39 --> Model Class Initialized
INFO - 2016-02-08 13:29:39 --> Model Class Initialized
INFO - 2016-02-08 13:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:29:39 --> Pagination Class Initialized
INFO - 2016-02-08 13:29:39 --> Form Validation Class Initialized
INFO - 2016-02-08 13:29:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-08 13:29:39 --> Severity: Error --> Call to undefined method Jboard::now() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 197
INFO - 2016-02-08 13:35:55 --> Config Class Initialized
INFO - 2016-02-08 13:35:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:35:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:35:55 --> Utf8 Class Initialized
INFO - 2016-02-08 13:35:55 --> URI Class Initialized
INFO - 2016-02-08 13:35:55 --> Router Class Initialized
INFO - 2016-02-08 13:35:55 --> Output Class Initialized
INFO - 2016-02-08 13:35:55 --> Security Class Initialized
DEBUG - 2016-02-08 13:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:35:55 --> Input Class Initialized
INFO - 2016-02-08 13:35:55 --> Language Class Initialized
INFO - 2016-02-08 13:35:55 --> Loader Class Initialized
INFO - 2016-02-08 13:35:55 --> Helper loaded: url_helper
INFO - 2016-02-08 13:35:55 --> Helper loaded: file_helper
INFO - 2016-02-08 13:35:55 --> Helper loaded: date_helper
INFO - 2016-02-08 13:35:55 --> Helper loaded: form_helper
INFO - 2016-02-08 13:35:55 --> Database Driver Class Initialized
INFO - 2016-02-08 13:35:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:35:56 --> Controller Class Initialized
INFO - 2016-02-08 13:35:56 --> Model Class Initialized
INFO - 2016-02-08 13:35:56 --> Model Class Initialized
INFO - 2016-02-08 13:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:35:56 --> Pagination Class Initialized
INFO - 2016-02-08 13:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:35:56 --> Helper loaded: text_helper
INFO - 2016-02-08 13:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:35:56 --> Final output sent to browser
DEBUG - 2016-02-08 13:35:56 --> Total execution time: 1.2013
INFO - 2016-02-08 13:36:01 --> Config Class Initialized
INFO - 2016-02-08 13:36:01 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:36:01 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:36:01 --> Utf8 Class Initialized
INFO - 2016-02-08 13:36:01 --> URI Class Initialized
INFO - 2016-02-08 13:36:01 --> Router Class Initialized
INFO - 2016-02-08 13:36:01 --> Output Class Initialized
INFO - 2016-02-08 13:36:01 --> Security Class Initialized
DEBUG - 2016-02-08 13:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:36:01 --> Input Class Initialized
INFO - 2016-02-08 13:36:01 --> Language Class Initialized
INFO - 2016-02-08 13:36:01 --> Loader Class Initialized
INFO - 2016-02-08 13:36:01 --> Helper loaded: url_helper
INFO - 2016-02-08 13:36:01 --> Helper loaded: file_helper
INFO - 2016-02-08 13:36:01 --> Helper loaded: date_helper
INFO - 2016-02-08 13:36:01 --> Helper loaded: form_helper
INFO - 2016-02-08 13:36:01 --> Database Driver Class Initialized
INFO - 2016-02-08 13:36:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:36:02 --> Controller Class Initialized
INFO - 2016-02-08 13:36:02 --> Model Class Initialized
INFO - 2016-02-08 13:36:02 --> Model Class Initialized
INFO - 2016-02-08 13:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:36:02 --> Pagination Class Initialized
INFO - 2016-02-08 13:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:36:02 --> Helper loaded: text_helper
INFO - 2016-02-08 13:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:36:02 --> Final output sent to browser
DEBUG - 2016-02-08 13:36:02 --> Total execution time: 1.2135
INFO - 2016-02-08 13:36:07 --> Config Class Initialized
INFO - 2016-02-08 13:36:07 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:36:07 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:36:07 --> Utf8 Class Initialized
INFO - 2016-02-08 13:36:07 --> URI Class Initialized
INFO - 2016-02-08 13:36:07 --> Router Class Initialized
INFO - 2016-02-08 13:36:07 --> Output Class Initialized
INFO - 2016-02-08 13:36:07 --> Security Class Initialized
DEBUG - 2016-02-08 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:36:07 --> Input Class Initialized
INFO - 2016-02-08 13:36:07 --> Language Class Initialized
INFO - 2016-02-08 13:36:07 --> Loader Class Initialized
INFO - 2016-02-08 13:36:08 --> Helper loaded: url_helper
INFO - 2016-02-08 13:36:08 --> Helper loaded: file_helper
INFO - 2016-02-08 13:36:08 --> Helper loaded: date_helper
INFO - 2016-02-08 13:36:08 --> Helper loaded: form_helper
INFO - 2016-02-08 13:36:08 --> Database Driver Class Initialized
INFO - 2016-02-08 13:36:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:36:09 --> Controller Class Initialized
INFO - 2016-02-08 13:36:09 --> Model Class Initialized
INFO - 2016-02-08 13:36:09 --> Model Class Initialized
INFO - 2016-02-08 13:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:36:09 --> Pagination Class Initialized
INFO - 2016-02-08 13:36:09 --> Form Validation Class Initialized
INFO - 2016-02-08 13:36:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-08 13:36:09 --> Severity: Error --> Call to undefined method Jboard::date() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 197
INFO - 2016-02-08 13:36:26 --> Config Class Initialized
INFO - 2016-02-08 13:36:26 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:36:26 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:36:26 --> Utf8 Class Initialized
INFO - 2016-02-08 13:36:26 --> URI Class Initialized
INFO - 2016-02-08 13:36:26 --> Router Class Initialized
INFO - 2016-02-08 13:36:26 --> Output Class Initialized
INFO - 2016-02-08 13:36:26 --> Security Class Initialized
DEBUG - 2016-02-08 13:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:36:26 --> Input Class Initialized
INFO - 2016-02-08 13:36:26 --> Language Class Initialized
INFO - 2016-02-08 13:36:26 --> Loader Class Initialized
INFO - 2016-02-08 13:36:26 --> Helper loaded: url_helper
INFO - 2016-02-08 13:36:26 --> Helper loaded: file_helper
INFO - 2016-02-08 13:36:26 --> Helper loaded: date_helper
INFO - 2016-02-08 13:36:26 --> Helper loaded: form_helper
INFO - 2016-02-08 13:36:26 --> Database Driver Class Initialized
INFO - 2016-02-08 13:36:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:36:28 --> Controller Class Initialized
INFO - 2016-02-08 13:36:28 --> Model Class Initialized
INFO - 2016-02-08 13:36:28 --> Model Class Initialized
INFO - 2016-02-08 13:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:36:28 --> Pagination Class Initialized
INFO - 2016-02-08 13:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:36:28 --> Helper loaded: text_helper
INFO - 2016-02-08 13:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:36:28 --> Final output sent to browser
DEBUG - 2016-02-08 13:36:28 --> Total execution time: 1.1888
INFO - 2016-02-08 13:36:33 --> Config Class Initialized
INFO - 2016-02-08 13:36:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:36:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:36:33 --> Utf8 Class Initialized
INFO - 2016-02-08 13:36:33 --> URI Class Initialized
INFO - 2016-02-08 13:36:33 --> Router Class Initialized
INFO - 2016-02-08 13:36:33 --> Output Class Initialized
INFO - 2016-02-08 13:36:33 --> Security Class Initialized
DEBUG - 2016-02-08 13:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:36:33 --> Input Class Initialized
INFO - 2016-02-08 13:36:33 --> Language Class Initialized
INFO - 2016-02-08 13:36:33 --> Loader Class Initialized
INFO - 2016-02-08 13:36:33 --> Helper loaded: url_helper
INFO - 2016-02-08 13:36:33 --> Helper loaded: file_helper
INFO - 2016-02-08 13:36:33 --> Helper loaded: date_helper
INFO - 2016-02-08 13:36:33 --> Helper loaded: form_helper
INFO - 2016-02-08 13:36:33 --> Database Driver Class Initialized
INFO - 2016-02-08 13:36:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:36:34 --> Controller Class Initialized
INFO - 2016-02-08 13:36:34 --> Model Class Initialized
INFO - 2016-02-08 13:36:34 --> Model Class Initialized
INFO - 2016-02-08 13:36:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:36:34 --> Pagination Class Initialized
INFO - 2016-02-08 13:36:34 --> Form Validation Class Initialized
INFO - 2016-02-08 13:36:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-08 13:36:34 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 197
INFO - 2016-02-08 13:36:34 --> Model Class Initialized
INFO - 2016-02-08 13:36:35 --> Final output sent to browser
DEBUG - 2016-02-08 13:36:35 --> Total execution time: 1.2287
INFO - 2016-02-08 13:39:33 --> Config Class Initialized
INFO - 2016-02-08 13:39:33 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:39:33 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:39:33 --> Utf8 Class Initialized
INFO - 2016-02-08 13:39:33 --> URI Class Initialized
INFO - 2016-02-08 13:39:33 --> Router Class Initialized
INFO - 2016-02-08 13:39:33 --> Output Class Initialized
INFO - 2016-02-08 13:39:33 --> Security Class Initialized
DEBUG - 2016-02-08 13:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:39:33 --> Input Class Initialized
INFO - 2016-02-08 13:39:33 --> Language Class Initialized
INFO - 2016-02-08 13:39:33 --> Loader Class Initialized
INFO - 2016-02-08 13:39:33 --> Helper loaded: url_helper
INFO - 2016-02-08 13:39:33 --> Helper loaded: file_helper
INFO - 2016-02-08 13:39:33 --> Helper loaded: date_helper
INFO - 2016-02-08 13:39:33 --> Helper loaded: form_helper
INFO - 2016-02-08 13:39:33 --> Database Driver Class Initialized
INFO - 2016-02-08 13:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:39:34 --> Controller Class Initialized
INFO - 2016-02-08 13:39:34 --> Model Class Initialized
INFO - 2016-02-08 13:39:34 --> Model Class Initialized
INFO - 2016-02-08 13:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:39:34 --> Pagination Class Initialized
INFO - 2016-02-08 13:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:39:34 --> Helper loaded: text_helper
INFO - 2016-02-08 13:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:39:34 --> Final output sent to browser
DEBUG - 2016-02-08 13:39:34 --> Total execution time: 1.1901
INFO - 2016-02-08 13:39:42 --> Config Class Initialized
INFO - 2016-02-08 13:39:42 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:39:42 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:39:42 --> Utf8 Class Initialized
INFO - 2016-02-08 13:39:42 --> URI Class Initialized
INFO - 2016-02-08 13:39:42 --> Router Class Initialized
INFO - 2016-02-08 13:39:42 --> Output Class Initialized
INFO - 2016-02-08 13:39:42 --> Security Class Initialized
DEBUG - 2016-02-08 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:39:42 --> Input Class Initialized
INFO - 2016-02-08 13:39:42 --> Language Class Initialized
INFO - 2016-02-08 13:39:42 --> Loader Class Initialized
INFO - 2016-02-08 13:39:42 --> Helper loaded: url_helper
INFO - 2016-02-08 13:39:42 --> Helper loaded: file_helper
INFO - 2016-02-08 13:39:42 --> Helper loaded: date_helper
INFO - 2016-02-08 13:39:42 --> Helper loaded: form_helper
INFO - 2016-02-08 13:39:42 --> Database Driver Class Initialized
INFO - 2016-02-08 13:39:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:39:43 --> Controller Class Initialized
INFO - 2016-02-08 13:39:43 --> Model Class Initialized
INFO - 2016-02-08 13:39:43 --> Model Class Initialized
INFO - 2016-02-08 13:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:39:43 --> Pagination Class Initialized
INFO - 2016-02-08 13:39:43 --> Form Validation Class Initialized
INFO - 2016-02-08 13:39:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:39:43 --> Model Class Initialized
INFO - 2016-02-08 13:39:43 --> Final output sent to browser
DEBUG - 2016-02-08 13:39:43 --> Total execution time: 1.1460
INFO - 2016-02-08 13:43:11 --> Config Class Initialized
INFO - 2016-02-08 13:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:43:11 --> Utf8 Class Initialized
INFO - 2016-02-08 13:43:11 --> URI Class Initialized
INFO - 2016-02-08 13:43:11 --> Router Class Initialized
INFO - 2016-02-08 13:43:11 --> Output Class Initialized
INFO - 2016-02-08 13:43:11 --> Security Class Initialized
DEBUG - 2016-02-08 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:43:11 --> Input Class Initialized
INFO - 2016-02-08 13:43:11 --> Language Class Initialized
INFO - 2016-02-08 13:43:11 --> Loader Class Initialized
INFO - 2016-02-08 13:43:11 --> Helper loaded: url_helper
INFO - 2016-02-08 13:43:11 --> Helper loaded: file_helper
INFO - 2016-02-08 13:43:11 --> Helper loaded: date_helper
INFO - 2016-02-08 13:43:11 --> Helper loaded: form_helper
INFO - 2016-02-08 13:43:11 --> Database Driver Class Initialized
INFO - 2016-02-08 13:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:43:12 --> Controller Class Initialized
INFO - 2016-02-08 13:43:12 --> Model Class Initialized
INFO - 2016-02-08 13:43:12 --> Model Class Initialized
INFO - 2016-02-08 13:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:43:12 --> Pagination Class Initialized
INFO - 2016-02-08 13:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:43:12 --> Helper loaded: text_helper
INFO - 2016-02-08 13:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:43:12 --> Final output sent to browser
DEBUG - 2016-02-08 13:43:12 --> Total execution time: 1.1886
INFO - 2016-02-08 13:43:18 --> Config Class Initialized
INFO - 2016-02-08 13:43:18 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:43:18 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:43:18 --> Utf8 Class Initialized
INFO - 2016-02-08 13:43:18 --> URI Class Initialized
INFO - 2016-02-08 13:43:18 --> Router Class Initialized
INFO - 2016-02-08 13:43:18 --> Output Class Initialized
INFO - 2016-02-08 13:43:18 --> Security Class Initialized
DEBUG - 2016-02-08 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:43:18 --> Input Class Initialized
INFO - 2016-02-08 13:43:18 --> Language Class Initialized
INFO - 2016-02-08 13:43:18 --> Loader Class Initialized
INFO - 2016-02-08 13:43:18 --> Helper loaded: url_helper
INFO - 2016-02-08 13:43:18 --> Helper loaded: file_helper
INFO - 2016-02-08 13:43:18 --> Helper loaded: date_helper
INFO - 2016-02-08 13:43:18 --> Helper loaded: form_helper
INFO - 2016-02-08 13:43:18 --> Database Driver Class Initialized
INFO - 2016-02-08 13:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:43:19 --> Controller Class Initialized
INFO - 2016-02-08 13:43:19 --> Model Class Initialized
INFO - 2016-02-08 13:43:19 --> Model Class Initialized
INFO - 2016-02-08 13:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:43:20 --> Pagination Class Initialized
INFO - 2016-02-08 13:43:20 --> Form Validation Class Initialized
INFO - 2016-02-08 13:43:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-08 13:43:20 --> Severity: Notice --> Undefined variable: time C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 197
ERROR - 2016-02-08 13:43:20 --> Severity: Error --> Call to a member function time() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 197
INFO - 2016-02-08 13:44:39 --> Config Class Initialized
INFO - 2016-02-08 13:44:39 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:44:39 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:44:39 --> Utf8 Class Initialized
INFO - 2016-02-08 13:44:39 --> URI Class Initialized
INFO - 2016-02-08 13:44:39 --> Router Class Initialized
INFO - 2016-02-08 13:44:39 --> Output Class Initialized
INFO - 2016-02-08 13:44:39 --> Security Class Initialized
DEBUG - 2016-02-08 13:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:44:39 --> Input Class Initialized
INFO - 2016-02-08 13:44:39 --> Language Class Initialized
INFO - 2016-02-08 13:44:39 --> Loader Class Initialized
INFO - 2016-02-08 13:44:39 --> Helper loaded: url_helper
INFO - 2016-02-08 13:44:39 --> Helper loaded: file_helper
INFO - 2016-02-08 13:44:39 --> Helper loaded: date_helper
INFO - 2016-02-08 13:44:39 --> Helper loaded: form_helper
INFO - 2016-02-08 13:44:39 --> Database Driver Class Initialized
INFO - 2016-02-08 13:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:44:40 --> Controller Class Initialized
INFO - 2016-02-08 13:44:40 --> Model Class Initialized
INFO - 2016-02-08 13:44:40 --> Model Class Initialized
INFO - 2016-02-08 13:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:44:40 --> Pagination Class Initialized
INFO - 2016-02-08 13:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:44:40 --> Helper loaded: text_helper
INFO - 2016-02-08 13:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:44:40 --> Final output sent to browser
DEBUG - 2016-02-08 13:44:40 --> Total execution time: 1.2320
INFO - 2016-02-08 13:44:46 --> Config Class Initialized
INFO - 2016-02-08 13:44:46 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:44:46 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:44:46 --> Utf8 Class Initialized
INFO - 2016-02-08 13:44:46 --> URI Class Initialized
INFO - 2016-02-08 13:44:46 --> Router Class Initialized
INFO - 2016-02-08 13:44:46 --> Output Class Initialized
INFO - 2016-02-08 13:44:46 --> Security Class Initialized
DEBUG - 2016-02-08 13:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:44:46 --> Input Class Initialized
INFO - 2016-02-08 13:44:46 --> Language Class Initialized
INFO - 2016-02-08 13:44:46 --> Loader Class Initialized
INFO - 2016-02-08 13:44:46 --> Helper loaded: url_helper
INFO - 2016-02-08 13:44:46 --> Helper loaded: file_helper
INFO - 2016-02-08 13:44:46 --> Helper loaded: date_helper
INFO - 2016-02-08 13:44:46 --> Helper loaded: form_helper
INFO - 2016-02-08 13:44:46 --> Database Driver Class Initialized
INFO - 2016-02-08 13:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:44:47 --> Controller Class Initialized
INFO - 2016-02-08 13:44:47 --> Model Class Initialized
INFO - 2016-02-08 13:44:47 --> Model Class Initialized
INFO - 2016-02-08 13:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:44:47 --> Pagination Class Initialized
INFO - 2016-02-08 13:44:47 --> Form Validation Class Initialized
INFO - 2016-02-08 13:44:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:44:47 --> Model Class Initialized
INFO - 2016-02-08 13:44:47 --> Final output sent to browser
DEBUG - 2016-02-08 13:44:47 --> Total execution time: 1.1992
INFO - 2016-02-08 13:45:22 --> Config Class Initialized
INFO - 2016-02-08 13:45:22 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:45:22 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:45:22 --> Utf8 Class Initialized
INFO - 2016-02-08 13:45:22 --> URI Class Initialized
INFO - 2016-02-08 13:45:22 --> Router Class Initialized
INFO - 2016-02-08 13:45:22 --> Output Class Initialized
INFO - 2016-02-08 13:45:22 --> Security Class Initialized
DEBUG - 2016-02-08 13:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:45:22 --> Input Class Initialized
INFO - 2016-02-08 13:45:22 --> Language Class Initialized
INFO - 2016-02-08 13:45:22 --> Loader Class Initialized
INFO - 2016-02-08 13:45:22 --> Helper loaded: url_helper
INFO - 2016-02-08 13:45:22 --> Helper loaded: file_helper
INFO - 2016-02-08 13:45:22 --> Helper loaded: date_helper
INFO - 2016-02-08 13:45:22 --> Helper loaded: form_helper
INFO - 2016-02-08 13:45:22 --> Database Driver Class Initialized
INFO - 2016-02-08 13:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:45:23 --> Controller Class Initialized
INFO - 2016-02-08 13:45:23 --> Model Class Initialized
INFO - 2016-02-08 13:45:23 --> Model Class Initialized
INFO - 2016-02-08 13:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:45:23 --> Pagination Class Initialized
INFO - 2016-02-08 13:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:45:24 --> Helper loaded: text_helper
INFO - 2016-02-08 13:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:45:24 --> Final output sent to browser
DEBUG - 2016-02-08 13:45:24 --> Total execution time: 1.2075
INFO - 2016-02-08 13:45:29 --> Config Class Initialized
INFO - 2016-02-08 13:45:29 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:45:29 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:45:29 --> Utf8 Class Initialized
INFO - 2016-02-08 13:45:29 --> URI Class Initialized
INFO - 2016-02-08 13:45:29 --> Router Class Initialized
INFO - 2016-02-08 13:45:29 --> Output Class Initialized
INFO - 2016-02-08 13:45:29 --> Security Class Initialized
DEBUG - 2016-02-08 13:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:45:29 --> Input Class Initialized
INFO - 2016-02-08 13:45:29 --> Language Class Initialized
INFO - 2016-02-08 13:45:29 --> Loader Class Initialized
INFO - 2016-02-08 13:45:29 --> Helper loaded: url_helper
INFO - 2016-02-08 13:45:29 --> Helper loaded: file_helper
INFO - 2016-02-08 13:45:29 --> Helper loaded: date_helper
INFO - 2016-02-08 13:45:29 --> Helper loaded: form_helper
INFO - 2016-02-08 13:45:29 --> Database Driver Class Initialized
INFO - 2016-02-08 13:45:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:45:30 --> Controller Class Initialized
INFO - 2016-02-08 13:45:30 --> Model Class Initialized
INFO - 2016-02-08 13:45:30 --> Model Class Initialized
INFO - 2016-02-08 13:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:45:30 --> Pagination Class Initialized
ERROR - 2016-02-08 13:45:30 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 178
INFO - 2016-02-08 13:45:30 --> Form Validation Class Initialized
INFO - 2016-02-08 13:45:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:45:30 --> Model Class Initialized
INFO - 2016-02-08 13:45:30 --> Final output sent to browser
DEBUG - 2016-02-08 13:45:30 --> Total execution time: 1.2125
INFO - 2016-02-08 13:47:03 --> Config Class Initialized
INFO - 2016-02-08 13:47:03 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:47:03 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:47:03 --> Utf8 Class Initialized
INFO - 2016-02-08 13:47:03 --> URI Class Initialized
INFO - 2016-02-08 13:47:03 --> Router Class Initialized
INFO - 2016-02-08 13:47:03 --> Output Class Initialized
INFO - 2016-02-08 13:47:03 --> Security Class Initialized
DEBUG - 2016-02-08 13:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:47:03 --> Input Class Initialized
INFO - 2016-02-08 13:47:03 --> Language Class Initialized
INFO - 2016-02-08 13:47:03 --> Loader Class Initialized
INFO - 2016-02-08 13:47:03 --> Helper loaded: url_helper
INFO - 2016-02-08 13:47:03 --> Helper loaded: file_helper
INFO - 2016-02-08 13:47:03 --> Helper loaded: date_helper
INFO - 2016-02-08 13:47:03 --> Helper loaded: form_helper
INFO - 2016-02-08 13:47:03 --> Database Driver Class Initialized
INFO - 2016-02-08 13:47:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:47:04 --> Controller Class Initialized
INFO - 2016-02-08 13:47:04 --> Model Class Initialized
INFO - 2016-02-08 13:47:04 --> Model Class Initialized
INFO - 2016-02-08 13:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:47:04 --> Pagination Class Initialized
INFO - 2016-02-08 13:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:47:04 --> Helper loaded: text_helper
INFO - 2016-02-08 13:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:47:04 --> Final output sent to browser
DEBUG - 2016-02-08 13:47:04 --> Total execution time: 1.1768
INFO - 2016-02-08 13:47:10 --> Config Class Initialized
INFO - 2016-02-08 13:47:10 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:47:10 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:47:10 --> Utf8 Class Initialized
INFO - 2016-02-08 13:47:10 --> URI Class Initialized
INFO - 2016-02-08 13:47:10 --> Router Class Initialized
INFO - 2016-02-08 13:47:10 --> Output Class Initialized
INFO - 2016-02-08 13:47:10 --> Security Class Initialized
DEBUG - 2016-02-08 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:47:10 --> Input Class Initialized
INFO - 2016-02-08 13:47:10 --> Language Class Initialized
INFO - 2016-02-08 13:47:10 --> Loader Class Initialized
INFO - 2016-02-08 13:47:10 --> Helper loaded: url_helper
INFO - 2016-02-08 13:47:10 --> Helper loaded: file_helper
INFO - 2016-02-08 13:47:10 --> Helper loaded: date_helper
INFO - 2016-02-08 13:47:10 --> Helper loaded: form_helper
INFO - 2016-02-08 13:47:10 --> Database Driver Class Initialized
INFO - 2016-02-08 13:47:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:47:12 --> Controller Class Initialized
INFO - 2016-02-08 13:47:12 --> Model Class Initialized
INFO - 2016-02-08 13:47:12 --> Model Class Initialized
INFO - 2016-02-08 13:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:47:12 --> Pagination Class Initialized
INFO - 2016-02-08 13:47:12 --> Form Validation Class Initialized
INFO - 2016-02-08 13:47:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:47:12 --> Model Class Initialized
INFO - 2016-02-08 13:47:12 --> Final output sent to browser
DEBUG - 2016-02-08 13:47:12 --> Total execution time: 1.2001
INFO - 2016-02-08 13:48:17 --> Config Class Initialized
INFO - 2016-02-08 13:48:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:48:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:48:17 --> Utf8 Class Initialized
INFO - 2016-02-08 13:48:17 --> URI Class Initialized
INFO - 2016-02-08 13:48:17 --> Router Class Initialized
INFO - 2016-02-08 13:48:17 --> Output Class Initialized
INFO - 2016-02-08 13:48:17 --> Security Class Initialized
DEBUG - 2016-02-08 13:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:48:17 --> Input Class Initialized
INFO - 2016-02-08 13:48:17 --> Language Class Initialized
INFO - 2016-02-08 13:48:17 --> Loader Class Initialized
INFO - 2016-02-08 13:48:17 --> Helper loaded: url_helper
INFO - 2016-02-08 13:48:17 --> Helper loaded: file_helper
INFO - 2016-02-08 13:48:17 --> Helper loaded: date_helper
INFO - 2016-02-08 13:48:17 --> Helper loaded: form_helper
INFO - 2016-02-08 13:48:17 --> Database Driver Class Initialized
INFO - 2016-02-08 13:48:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:48:18 --> Controller Class Initialized
INFO - 2016-02-08 13:48:18 --> Model Class Initialized
INFO - 2016-02-08 13:48:18 --> Model Class Initialized
INFO - 2016-02-08 13:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:48:18 --> Pagination Class Initialized
INFO - 2016-02-08 13:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:48:18 --> Helper loaded: text_helper
INFO - 2016-02-08 13:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:48:18 --> Final output sent to browser
DEBUG - 2016-02-08 13:48:18 --> Total execution time: 1.1920
INFO - 2016-02-08 13:48:23 --> Config Class Initialized
INFO - 2016-02-08 13:48:23 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:48:23 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:48:23 --> Utf8 Class Initialized
INFO - 2016-02-08 13:48:23 --> URI Class Initialized
INFO - 2016-02-08 13:48:23 --> Router Class Initialized
INFO - 2016-02-08 13:48:23 --> Output Class Initialized
INFO - 2016-02-08 13:48:23 --> Security Class Initialized
DEBUG - 2016-02-08 13:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:48:23 --> Input Class Initialized
INFO - 2016-02-08 13:48:23 --> Language Class Initialized
INFO - 2016-02-08 13:48:23 --> Loader Class Initialized
INFO - 2016-02-08 13:48:23 --> Helper loaded: url_helper
INFO - 2016-02-08 13:48:23 --> Helper loaded: file_helper
INFO - 2016-02-08 13:48:23 --> Helper loaded: date_helper
INFO - 2016-02-08 13:48:23 --> Helper loaded: form_helper
INFO - 2016-02-08 13:48:23 --> Database Driver Class Initialized
INFO - 2016-02-08 13:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:48:24 --> Controller Class Initialized
INFO - 2016-02-08 13:48:24 --> Model Class Initialized
INFO - 2016-02-08 13:48:24 --> Model Class Initialized
INFO - 2016-02-08 13:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:48:24 --> Pagination Class Initialized
INFO - 2016-02-08 13:48:24 --> Form Validation Class Initialized
INFO - 2016-02-08 13:48:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:48:24 --> Model Class Initialized
INFO - 2016-02-08 13:48:24 --> Final output sent to browser
DEBUG - 2016-02-08 13:48:24 --> Total execution time: 1.2422
INFO - 2016-02-08 13:48:31 --> Config Class Initialized
INFO - 2016-02-08 13:48:31 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:48:31 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:48:31 --> Utf8 Class Initialized
INFO - 2016-02-08 13:48:31 --> URI Class Initialized
INFO - 2016-02-08 13:48:31 --> Router Class Initialized
INFO - 2016-02-08 13:48:31 --> Output Class Initialized
INFO - 2016-02-08 13:48:31 --> Security Class Initialized
DEBUG - 2016-02-08 13:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:48:31 --> Input Class Initialized
INFO - 2016-02-08 13:48:31 --> Language Class Initialized
INFO - 2016-02-08 13:48:31 --> Loader Class Initialized
INFO - 2016-02-08 13:48:31 --> Helper loaded: url_helper
INFO - 2016-02-08 13:48:31 --> Helper loaded: file_helper
INFO - 2016-02-08 13:48:31 --> Helper loaded: date_helper
INFO - 2016-02-08 13:48:31 --> Helper loaded: form_helper
INFO - 2016-02-08 13:48:31 --> Database Driver Class Initialized
INFO - 2016-02-08 13:48:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:48:32 --> Controller Class Initialized
INFO - 2016-02-08 13:48:32 --> Model Class Initialized
INFO - 2016-02-08 13:48:32 --> Model Class Initialized
INFO - 2016-02-08 13:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:48:32 --> Pagination Class Initialized
INFO - 2016-02-08 13:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 13:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 13:48:32 --> Helper loaded: text_helper
INFO - 2016-02-08 13:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 13:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 13:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 13:48:32 --> Final output sent to browser
DEBUG - 2016-02-08 13:48:32 --> Total execution time: 1.2381
INFO - 2016-02-08 13:48:37 --> Config Class Initialized
INFO - 2016-02-08 13:48:37 --> Hooks Class Initialized
DEBUG - 2016-02-08 13:48:37 --> UTF-8 Support Enabled
INFO - 2016-02-08 13:48:37 --> Utf8 Class Initialized
INFO - 2016-02-08 13:48:37 --> URI Class Initialized
INFO - 2016-02-08 13:48:37 --> Router Class Initialized
INFO - 2016-02-08 13:48:37 --> Output Class Initialized
INFO - 2016-02-08 13:48:37 --> Security Class Initialized
DEBUG - 2016-02-08 13:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 13:48:37 --> Input Class Initialized
INFO - 2016-02-08 13:48:37 --> Language Class Initialized
INFO - 2016-02-08 13:48:37 --> Loader Class Initialized
INFO - 2016-02-08 13:48:37 --> Helper loaded: url_helper
INFO - 2016-02-08 13:48:37 --> Helper loaded: file_helper
INFO - 2016-02-08 13:48:37 --> Helper loaded: date_helper
INFO - 2016-02-08 13:48:37 --> Helper loaded: form_helper
INFO - 2016-02-08 13:48:37 --> Database Driver Class Initialized
INFO - 2016-02-08 13:48:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 13:48:38 --> Controller Class Initialized
INFO - 2016-02-08 13:48:38 --> Model Class Initialized
INFO - 2016-02-08 13:48:38 --> Model Class Initialized
INFO - 2016-02-08 13:48:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 13:48:38 --> Pagination Class Initialized
INFO - 2016-02-08 13:48:38 --> Form Validation Class Initialized
INFO - 2016-02-08 13:48:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-08 13:48:38 --> Model Class Initialized
INFO - 2016-02-08 13:48:38 --> Final output sent to browser
DEBUG - 2016-02-08 13:48:38 --> Total execution time: 1.1701
INFO - 2016-02-08 18:16:50 --> Config Class Initialized
INFO - 2016-02-08 18:16:50 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:16:50 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:16:50 --> Utf8 Class Initialized
INFO - 2016-02-08 18:16:50 --> URI Class Initialized
DEBUG - 2016-02-08 18:16:50 --> No URI present. Default controller set.
INFO - 2016-02-08 18:16:50 --> Router Class Initialized
INFO - 2016-02-08 18:16:50 --> Output Class Initialized
INFO - 2016-02-08 18:16:50 --> Security Class Initialized
DEBUG - 2016-02-08 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:16:50 --> Input Class Initialized
INFO - 2016-02-08 18:16:50 --> Language Class Initialized
INFO - 2016-02-08 18:16:50 --> Loader Class Initialized
INFO - 2016-02-08 18:16:50 --> Helper loaded: url_helper
INFO - 2016-02-08 18:16:50 --> Helper loaded: file_helper
INFO - 2016-02-08 18:16:50 --> Helper loaded: date_helper
INFO - 2016-02-08 18:16:50 --> Helper loaded: form_helper
INFO - 2016-02-08 18:16:50 --> Database Driver Class Initialized
INFO - 2016-02-08 18:16:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:16:51 --> Controller Class Initialized
INFO - 2016-02-08 18:16:51 --> Model Class Initialized
INFO - 2016-02-08 18:16:51 --> Model Class Initialized
INFO - 2016-02-08 18:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:16:51 --> Pagination Class Initialized
INFO - 2016-02-08 18:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 18:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:16:51 --> Final output sent to browser
DEBUG - 2016-02-08 18:16:51 --> Total execution time: 1.1574
INFO - 2016-02-08 18:17:12 --> Config Class Initialized
INFO - 2016-02-08 18:17:12 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:17:12 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:17:12 --> Utf8 Class Initialized
INFO - 2016-02-08 18:17:13 --> URI Class Initialized
INFO - 2016-02-08 18:17:13 --> Router Class Initialized
INFO - 2016-02-08 18:17:13 --> Output Class Initialized
INFO - 2016-02-08 18:17:13 --> Security Class Initialized
DEBUG - 2016-02-08 18:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:17:13 --> Input Class Initialized
INFO - 2016-02-08 18:17:13 --> Language Class Initialized
INFO - 2016-02-08 18:17:13 --> Loader Class Initialized
INFO - 2016-02-08 18:17:13 --> Helper loaded: url_helper
INFO - 2016-02-08 18:17:13 --> Helper loaded: file_helper
INFO - 2016-02-08 18:17:13 --> Helper loaded: date_helper
INFO - 2016-02-08 18:17:13 --> Helper loaded: form_helper
INFO - 2016-02-08 18:17:13 --> Database Driver Class Initialized
INFO - 2016-02-08 18:17:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:17:14 --> Controller Class Initialized
INFO - 2016-02-08 18:17:14 --> Model Class Initialized
INFO - 2016-02-08 18:17:14 --> Model Class Initialized
INFO - 2016-02-08 18:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:17:14 --> Pagination Class Initialized
INFO - 2016-02-08 18:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:17:14 --> Helper loaded: text_helper
INFO - 2016-02-08 18:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:17:14 --> Final output sent to browser
DEBUG - 2016-02-08 18:17:14 --> Total execution time: 1.2237
INFO - 2016-02-08 18:22:49 --> Config Class Initialized
INFO - 2016-02-08 18:22:49 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:22:49 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:22:49 --> Utf8 Class Initialized
INFO - 2016-02-08 18:22:49 --> URI Class Initialized
DEBUG - 2016-02-08 18:22:49 --> No URI present. Default controller set.
INFO - 2016-02-08 18:22:49 --> Router Class Initialized
INFO - 2016-02-08 18:22:49 --> Output Class Initialized
INFO - 2016-02-08 18:22:49 --> Security Class Initialized
DEBUG - 2016-02-08 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:22:49 --> Input Class Initialized
INFO - 2016-02-08 18:22:49 --> Language Class Initialized
INFO - 2016-02-08 18:22:49 --> Loader Class Initialized
INFO - 2016-02-08 18:22:49 --> Helper loaded: url_helper
INFO - 2016-02-08 18:22:49 --> Helper loaded: file_helper
INFO - 2016-02-08 18:22:49 --> Helper loaded: date_helper
INFO - 2016-02-08 18:22:49 --> Helper loaded: form_helper
INFO - 2016-02-08 18:22:49 --> Database Driver Class Initialized
INFO - 2016-02-08 18:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:22:50 --> Controller Class Initialized
INFO - 2016-02-08 18:22:50 --> Model Class Initialized
INFO - 2016-02-08 18:22:50 --> Model Class Initialized
INFO - 2016-02-08 18:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:22:51 --> Pagination Class Initialized
INFO - 2016-02-08 18:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 18:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:22:51 --> Final output sent to browser
DEBUG - 2016-02-08 18:22:51 --> Total execution time: 1.1542
INFO - 2016-02-08 18:22:52 --> Config Class Initialized
INFO - 2016-02-08 18:22:52 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:22:52 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:22:52 --> Utf8 Class Initialized
INFO - 2016-02-08 18:22:52 --> URI Class Initialized
INFO - 2016-02-08 18:22:52 --> Router Class Initialized
INFO - 2016-02-08 18:22:52 --> Output Class Initialized
INFO - 2016-02-08 18:22:52 --> Security Class Initialized
DEBUG - 2016-02-08 18:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:22:52 --> Input Class Initialized
INFO - 2016-02-08 18:22:52 --> Language Class Initialized
INFO - 2016-02-08 18:22:52 --> Loader Class Initialized
INFO - 2016-02-08 18:22:52 --> Helper loaded: url_helper
INFO - 2016-02-08 18:22:52 --> Helper loaded: file_helper
INFO - 2016-02-08 18:22:52 --> Helper loaded: date_helper
INFO - 2016-02-08 18:22:52 --> Helper loaded: form_helper
INFO - 2016-02-08 18:22:52 --> Database Driver Class Initialized
INFO - 2016-02-08 18:22:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:22:53 --> Controller Class Initialized
INFO - 2016-02-08 18:22:53 --> Model Class Initialized
INFO - 2016-02-08 18:22:53 --> Model Class Initialized
INFO - 2016-02-08 18:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:22:53 --> Pagination Class Initialized
INFO - 2016-02-08 18:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:22:53 --> Helper loaded: text_helper
INFO - 2016-02-08 18:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:22:53 --> Final output sent to browser
DEBUG - 2016-02-08 18:22:53 --> Total execution time: 1.1761
INFO - 2016-02-08 18:23:02 --> Config Class Initialized
INFO - 2016-02-08 18:23:02 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:02 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:02 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:02 --> URI Class Initialized
INFO - 2016-02-08 18:23:02 --> Router Class Initialized
INFO - 2016-02-08 18:23:02 --> Output Class Initialized
INFO - 2016-02-08 18:23:02 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:02 --> Input Class Initialized
INFO - 2016-02-08 18:23:02 --> Language Class Initialized
INFO - 2016-02-08 18:23:02 --> Loader Class Initialized
INFO - 2016-02-08 18:23:02 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:02 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:02 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:02 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:02 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:03 --> Controller Class Initialized
INFO - 2016-02-08 18:23:03 --> Model Class Initialized
INFO - 2016-02-08 18:23:03 --> Model Class Initialized
INFO - 2016-02-08 18:23:03 --> Form Validation Class Initialized
INFO - 2016-02-08 18:23:03 --> Helper loaded: text_helper
INFO - 2016-02-08 18:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-08 18:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:23:03 --> Final output sent to browser
DEBUG - 2016-02-08 18:23:03 --> Total execution time: 1.1772
INFO - 2016-02-08 18:23:16 --> Config Class Initialized
INFO - 2016-02-08 18:23:16 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:16 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:16 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:16 --> URI Class Initialized
INFO - 2016-02-08 18:23:16 --> Router Class Initialized
INFO - 2016-02-08 18:23:16 --> Output Class Initialized
INFO - 2016-02-08 18:23:16 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:16 --> Input Class Initialized
INFO - 2016-02-08 18:23:16 --> Language Class Initialized
INFO - 2016-02-08 18:23:16 --> Loader Class Initialized
INFO - 2016-02-08 18:23:16 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:16 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:16 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:16 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:16 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:17 --> Controller Class Initialized
INFO - 2016-02-08 18:23:17 --> Model Class Initialized
INFO - 2016-02-08 18:23:17 --> Model Class Initialized
INFO - 2016-02-08 18:23:17 --> Form Validation Class Initialized
INFO - 2016-02-08 18:23:17 --> Helper loaded: text_helper
INFO - 2016-02-08 18:23:17 --> Config Class Initialized
INFO - 2016-02-08 18:23:17 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:17 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:17 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:17 --> URI Class Initialized
INFO - 2016-02-08 18:23:17 --> Router Class Initialized
INFO - 2016-02-08 18:23:17 --> Output Class Initialized
INFO - 2016-02-08 18:23:17 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:17 --> Input Class Initialized
INFO - 2016-02-08 18:23:17 --> Language Class Initialized
INFO - 2016-02-08 18:23:17 --> Loader Class Initialized
INFO - 2016-02-08 18:23:17 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:17 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:17 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:17 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:17 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:18 --> Controller Class Initialized
INFO - 2016-02-08 18:23:18 --> Model Class Initialized
INFO - 2016-02-08 18:23:18 --> Model Class Initialized
INFO - 2016-02-08 18:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:23:18 --> Pagination Class Initialized
INFO - 2016-02-08 18:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-08 18:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:23:18 --> Final output sent to browser
DEBUG - 2016-02-08 18:23:18 --> Total execution time: 1.1396
INFO - 2016-02-08 18:23:20 --> Config Class Initialized
INFO - 2016-02-08 18:23:20 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:20 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:20 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:20 --> URI Class Initialized
INFO - 2016-02-08 18:23:20 --> Router Class Initialized
INFO - 2016-02-08 18:23:20 --> Output Class Initialized
INFO - 2016-02-08 18:23:20 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:20 --> Input Class Initialized
INFO - 2016-02-08 18:23:20 --> Language Class Initialized
INFO - 2016-02-08 18:23:20 --> Loader Class Initialized
INFO - 2016-02-08 18:23:20 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:20 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:20 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:20 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:20 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:21 --> Controller Class Initialized
INFO - 2016-02-08 18:23:21 --> Model Class Initialized
INFO - 2016-02-08 18:23:21 --> Model Class Initialized
INFO - 2016-02-08 18:23:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:23:21 --> Pagination Class Initialized
INFO - 2016-02-08 18:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:23:21 --> Helper loaded: text_helper
INFO - 2016-02-08 18:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:23:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:23:21 --> Final output sent to browser
DEBUG - 2016-02-08 18:23:21 --> Total execution time: 1.1571
INFO - 2016-02-08 18:23:32 --> Config Class Initialized
INFO - 2016-02-08 18:23:32 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:32 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:32 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:32 --> URI Class Initialized
INFO - 2016-02-08 18:23:32 --> Router Class Initialized
INFO - 2016-02-08 18:23:32 --> Output Class Initialized
INFO - 2016-02-08 18:23:32 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:32 --> Input Class Initialized
INFO - 2016-02-08 18:23:32 --> Language Class Initialized
INFO - 2016-02-08 18:23:32 --> Loader Class Initialized
INFO - 2016-02-08 18:23:32 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:32 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:32 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:32 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:32 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:33 --> Controller Class Initialized
INFO - 2016-02-08 18:23:33 --> Model Class Initialized
INFO - 2016-02-08 18:23:33 --> Model Class Initialized
INFO - 2016-02-08 18:23:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:23:34 --> Pagination Class Initialized
INFO - 2016-02-08 18:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:23:34 --> Helper loaded: text_helper
INFO - 2016-02-08 18:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:23:34 --> Final output sent to browser
DEBUG - 2016-02-08 18:23:34 --> Total execution time: 1.2440
INFO - 2016-02-08 18:23:55 --> Config Class Initialized
INFO - 2016-02-08 18:23:55 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:23:55 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:23:55 --> Utf8 Class Initialized
INFO - 2016-02-08 18:23:55 --> URI Class Initialized
INFO - 2016-02-08 18:23:55 --> Router Class Initialized
INFO - 2016-02-08 18:23:55 --> Output Class Initialized
INFO - 2016-02-08 18:23:55 --> Security Class Initialized
DEBUG - 2016-02-08 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:23:55 --> Input Class Initialized
INFO - 2016-02-08 18:23:55 --> Language Class Initialized
INFO - 2016-02-08 18:23:55 --> Loader Class Initialized
INFO - 2016-02-08 18:23:55 --> Helper loaded: url_helper
INFO - 2016-02-08 18:23:55 --> Helper loaded: file_helper
INFO - 2016-02-08 18:23:55 --> Helper loaded: date_helper
INFO - 2016-02-08 18:23:55 --> Helper loaded: form_helper
INFO - 2016-02-08 18:23:55 --> Database Driver Class Initialized
INFO - 2016-02-08 18:23:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:23:56 --> Controller Class Initialized
INFO - 2016-02-08 18:23:56 --> Model Class Initialized
INFO - 2016-02-08 18:23:56 --> Model Class Initialized
INFO - 2016-02-08 18:23:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:23:56 --> Pagination Class Initialized
INFO - 2016-02-08 18:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:23:56 --> Helper loaded: text_helper
INFO - 2016-02-08 18:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:23:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:23:56 --> Final output sent to browser
DEBUG - 2016-02-08 18:23:56 --> Total execution time: 1.2348
INFO - 2016-02-08 18:24:08 --> Config Class Initialized
INFO - 2016-02-08 18:24:08 --> Hooks Class Initialized
DEBUG - 2016-02-08 18:24:08 --> UTF-8 Support Enabled
INFO - 2016-02-08 18:24:08 --> Utf8 Class Initialized
INFO - 2016-02-08 18:24:08 --> URI Class Initialized
INFO - 2016-02-08 18:24:08 --> Router Class Initialized
INFO - 2016-02-08 18:24:08 --> Output Class Initialized
INFO - 2016-02-08 18:24:08 --> Security Class Initialized
DEBUG - 2016-02-08 18:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-08 18:24:08 --> Input Class Initialized
INFO - 2016-02-08 18:24:08 --> Language Class Initialized
INFO - 2016-02-08 18:24:08 --> Loader Class Initialized
INFO - 2016-02-08 18:24:08 --> Helper loaded: url_helper
INFO - 2016-02-08 18:24:08 --> Helper loaded: file_helper
INFO - 2016-02-08 18:24:08 --> Helper loaded: date_helper
INFO - 2016-02-08 18:24:08 --> Helper loaded: form_helper
INFO - 2016-02-08 18:24:08 --> Database Driver Class Initialized
INFO - 2016-02-08 18:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-08 18:24:09 --> Controller Class Initialized
INFO - 2016-02-08 18:24:09 --> Model Class Initialized
INFO - 2016-02-08 18:24:09 --> Model Class Initialized
INFO - 2016-02-08 18:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-08 18:24:09 --> Pagination Class Initialized
INFO - 2016-02-08 18:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-08 18:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-08 18:24:09 --> Helper loaded: text_helper
INFO - 2016-02-08 18:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-08 18:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-08 18:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-08 18:24:09 --> Final output sent to browser
DEBUG - 2016-02-08 18:24:09 --> Total execution time: 1.1988
