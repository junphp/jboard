<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-12 07:31:01 --> Config Class Initialized
INFO - 2016-03-12 07:31:01 --> Hooks Class Initialized
DEBUG - 2016-03-12 07:31:01 --> UTF-8 Support Enabled
INFO - 2016-03-12 07:31:01 --> Utf8 Class Initialized
INFO - 2016-03-12 07:31:01 --> URI Class Initialized
DEBUG - 2016-03-12 07:31:01 --> No URI present. Default controller set.
INFO - 2016-03-12 07:31:01 --> Router Class Initialized
INFO - 2016-03-12 07:31:01 --> Output Class Initialized
INFO - 2016-03-12 07:31:01 --> Security Class Initialized
DEBUG - 2016-03-12 07:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-12 07:31:01 --> Input Class Initialized
INFO - 2016-03-12 07:31:01 --> Language Class Initialized
INFO - 2016-03-12 07:31:01 --> Loader Class Initialized
INFO - 2016-03-12 07:31:01 --> Helper loaded: url_helper
INFO - 2016-03-12 07:31:01 --> Helper loaded: file_helper
INFO - 2016-03-12 07:31:01 --> Helper loaded: date_helper
INFO - 2016-03-12 07:31:01 --> Helper loaded: form_helper
INFO - 2016-03-12 07:31:01 --> Database Driver Class Initialized
INFO - 2016-03-12 07:31:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-12 07:31:03 --> Controller Class Initialized
INFO - 2016-03-12 07:31:03 --> Model Class Initialized
INFO - 2016-03-12 07:31:03 --> Model Class Initialized
INFO - 2016-03-12 07:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-12 07:31:03 --> Pagination Class Initialized
INFO - 2016-03-12 07:31:03 --> Helper loaded: text_helper
INFO - 2016-03-12 07:31:03 --> Helper loaded: cookie_helper
INFO - 2016-03-12 10:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-12 10:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-12 10:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-12 10:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-12 10:31:03 --> Final output sent to browser
DEBUG - 2016-03-12 10:31:03 --> Total execution time: 2.0563
