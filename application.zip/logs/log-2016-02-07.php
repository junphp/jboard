<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-07 08:19:26 --> Config Class Initialized
INFO - 2016-02-07 08:19:26 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:19:26 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:19:26 --> Utf8 Class Initialized
INFO - 2016-02-07 08:19:26 --> URI Class Initialized
DEBUG - 2016-02-07 08:19:26 --> No URI present. Default controller set.
INFO - 2016-02-07 08:19:26 --> Router Class Initialized
INFO - 2016-02-07 08:19:26 --> Output Class Initialized
INFO - 2016-02-07 08:19:26 --> Security Class Initialized
DEBUG - 2016-02-07 08:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:19:26 --> Input Class Initialized
INFO - 2016-02-07 08:19:26 --> Language Class Initialized
INFO - 2016-02-07 08:19:26 --> Loader Class Initialized
INFO - 2016-02-07 08:19:26 --> Helper loaded: url_helper
INFO - 2016-02-07 08:19:26 --> Helper loaded: file_helper
INFO - 2016-02-07 08:19:26 --> Helper loaded: date_helper
INFO - 2016-02-07 08:19:26 --> Helper loaded: form_helper
INFO - 2016-02-07 08:19:26 --> Database Driver Class Initialized
INFO - 2016-02-07 08:19:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:19:27 --> Controller Class Initialized
INFO - 2016-02-07 08:19:27 --> Model Class Initialized
INFO - 2016-02-07 08:19:27 --> Model Class Initialized
INFO - 2016-02-07 08:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:19:27 --> Pagination Class Initialized
INFO - 2016-02-07 08:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:19:27 --> Final output sent to browser
DEBUG - 2016-02-07 08:19:27 --> Total execution time: 1.0918
INFO - 2016-02-07 08:19:29 --> Config Class Initialized
INFO - 2016-02-07 08:19:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:19:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:19:29 --> Utf8 Class Initialized
INFO - 2016-02-07 08:19:29 --> URI Class Initialized
INFO - 2016-02-07 08:19:29 --> Router Class Initialized
INFO - 2016-02-07 08:19:29 --> Output Class Initialized
INFO - 2016-02-07 08:19:29 --> Security Class Initialized
DEBUG - 2016-02-07 08:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:19:29 --> Input Class Initialized
INFO - 2016-02-07 08:19:29 --> Language Class Initialized
INFO - 2016-02-07 08:19:29 --> Loader Class Initialized
INFO - 2016-02-07 08:19:29 --> Helper loaded: url_helper
INFO - 2016-02-07 08:19:29 --> Helper loaded: file_helper
INFO - 2016-02-07 08:19:29 --> Helper loaded: date_helper
INFO - 2016-02-07 08:19:29 --> Helper loaded: form_helper
INFO - 2016-02-07 08:19:29 --> Database Driver Class Initialized
INFO - 2016-02-07 08:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:19:30 --> Controller Class Initialized
INFO - 2016-02-07 08:19:30 --> Model Class Initialized
INFO - 2016-02-07 08:19:30 --> Model Class Initialized
INFO - 2016-02-07 08:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:19:30 --> Pagination Class Initialized
INFO - 2016-02-07 08:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:19:30 --> Helper loaded: text_helper
INFO - 2016-02-07 08:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:19:31 --> Final output sent to browser
DEBUG - 2016-02-07 08:19:31 --> Total execution time: 1.1281
INFO - 2016-02-07 08:27:39 --> Config Class Initialized
INFO - 2016-02-07 08:27:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:27:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:27:39 --> Utf8 Class Initialized
INFO - 2016-02-07 08:27:39 --> URI Class Initialized
DEBUG - 2016-02-07 08:27:39 --> No URI present. Default controller set.
INFO - 2016-02-07 08:27:39 --> Router Class Initialized
INFO - 2016-02-07 08:27:39 --> Output Class Initialized
INFO - 2016-02-07 08:27:39 --> Security Class Initialized
DEBUG - 2016-02-07 08:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:27:39 --> Input Class Initialized
INFO - 2016-02-07 08:27:39 --> Language Class Initialized
INFO - 2016-02-07 08:27:39 --> Loader Class Initialized
INFO - 2016-02-07 08:27:39 --> Helper loaded: url_helper
INFO - 2016-02-07 08:27:39 --> Helper loaded: file_helper
INFO - 2016-02-07 08:27:39 --> Helper loaded: date_helper
INFO - 2016-02-07 08:27:39 --> Helper loaded: form_helper
INFO - 2016-02-07 08:27:39 --> Database Driver Class Initialized
INFO - 2016-02-07 08:27:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:27:40 --> Controller Class Initialized
INFO - 2016-02-07 08:27:40 --> Model Class Initialized
INFO - 2016-02-07 08:27:40 --> Model Class Initialized
INFO - 2016-02-07 08:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:27:40 --> Pagination Class Initialized
INFO - 2016-02-07 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:27:40 --> Final output sent to browser
DEBUG - 2016-02-07 08:27:40 --> Total execution time: 1.0815
INFO - 2016-02-07 08:27:42 --> Config Class Initialized
INFO - 2016-02-07 08:27:42 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:27:42 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:27:42 --> Utf8 Class Initialized
INFO - 2016-02-07 08:27:42 --> URI Class Initialized
INFO - 2016-02-07 08:27:42 --> Router Class Initialized
INFO - 2016-02-07 08:27:42 --> Output Class Initialized
INFO - 2016-02-07 08:27:42 --> Security Class Initialized
DEBUG - 2016-02-07 08:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:27:42 --> Input Class Initialized
INFO - 2016-02-07 08:27:42 --> Language Class Initialized
INFO - 2016-02-07 08:27:42 --> Loader Class Initialized
INFO - 2016-02-07 08:27:42 --> Helper loaded: url_helper
INFO - 2016-02-07 08:27:42 --> Helper loaded: file_helper
INFO - 2016-02-07 08:27:42 --> Helper loaded: date_helper
INFO - 2016-02-07 08:27:42 --> Helper loaded: form_helper
INFO - 2016-02-07 08:27:42 --> Database Driver Class Initialized
INFO - 2016-02-07 08:27:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:27:43 --> Controller Class Initialized
INFO - 2016-02-07 08:27:43 --> Model Class Initialized
INFO - 2016-02-07 08:27:43 --> Model Class Initialized
INFO - 2016-02-07 08:27:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:27:43 --> Pagination Class Initialized
INFO - 2016-02-07 08:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:27:43 --> Helper loaded: text_helper
INFO - 2016-02-07 08:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:27:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:27:43 --> Final output sent to browser
DEBUG - 2016-02-07 08:27:43 --> Total execution time: 1.2375
INFO - 2016-02-07 08:27:51 --> Config Class Initialized
INFO - 2016-02-07 08:27:51 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:27:51 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:27:51 --> Utf8 Class Initialized
INFO - 2016-02-07 08:27:51 --> URI Class Initialized
INFO - 2016-02-07 08:27:51 --> Router Class Initialized
INFO - 2016-02-07 08:27:51 --> Output Class Initialized
INFO - 2016-02-07 08:27:51 --> Security Class Initialized
DEBUG - 2016-02-07 08:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:27:51 --> Input Class Initialized
INFO - 2016-02-07 08:27:51 --> Language Class Initialized
INFO - 2016-02-07 08:27:51 --> Loader Class Initialized
INFO - 2016-02-07 08:27:51 --> Helper loaded: url_helper
INFO - 2016-02-07 08:27:51 --> Helper loaded: file_helper
INFO - 2016-02-07 08:27:51 --> Helper loaded: date_helper
INFO - 2016-02-07 08:27:51 --> Helper loaded: form_helper
INFO - 2016-02-07 08:27:51 --> Database Driver Class Initialized
INFO - 2016-02-07 08:27:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:27:52 --> Controller Class Initialized
INFO - 2016-02-07 08:27:52 --> Model Class Initialized
INFO - 2016-02-07 08:27:52 --> Model Class Initialized
INFO - 2016-02-07 08:27:52 --> Form Validation Class Initialized
INFO - 2016-02-07 08:27:52 --> Helper loaded: text_helper
INFO - 2016-02-07 08:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-07 08:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:27:52 --> Final output sent to browser
DEBUG - 2016-02-07 08:27:52 --> Total execution time: 1.2131
INFO - 2016-02-07 08:27:57 --> Config Class Initialized
INFO - 2016-02-07 08:27:57 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:27:57 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:27:57 --> Utf8 Class Initialized
INFO - 2016-02-07 08:27:57 --> URI Class Initialized
INFO - 2016-02-07 08:27:57 --> Router Class Initialized
INFO - 2016-02-07 08:27:57 --> Output Class Initialized
INFO - 2016-02-07 08:27:57 --> Security Class Initialized
DEBUG - 2016-02-07 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:27:57 --> Input Class Initialized
INFO - 2016-02-07 08:27:57 --> Language Class Initialized
INFO - 2016-02-07 08:27:57 --> Loader Class Initialized
INFO - 2016-02-07 08:27:57 --> Helper loaded: url_helper
INFO - 2016-02-07 08:27:57 --> Helper loaded: file_helper
INFO - 2016-02-07 08:27:57 --> Helper loaded: date_helper
INFO - 2016-02-07 08:27:57 --> Helper loaded: form_helper
INFO - 2016-02-07 08:27:57 --> Database Driver Class Initialized
INFO - 2016-02-07 08:27:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:27:58 --> Controller Class Initialized
INFO - 2016-02-07 08:27:58 --> Model Class Initialized
INFO - 2016-02-07 08:27:58 --> Model Class Initialized
INFO - 2016-02-07 08:27:58 --> Form Validation Class Initialized
INFO - 2016-02-07 08:27:58 --> Helper loaded: text_helper
INFO - 2016-02-07 08:27:58 --> Config Class Initialized
INFO - 2016-02-07 08:27:58 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:27:58 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:27:58 --> Utf8 Class Initialized
INFO - 2016-02-07 08:27:58 --> URI Class Initialized
INFO - 2016-02-07 08:27:58 --> Router Class Initialized
INFO - 2016-02-07 08:27:58 --> Output Class Initialized
INFO - 2016-02-07 08:27:58 --> Security Class Initialized
DEBUG - 2016-02-07 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:27:58 --> Input Class Initialized
INFO - 2016-02-07 08:27:58 --> Language Class Initialized
INFO - 2016-02-07 08:27:58 --> Loader Class Initialized
INFO - 2016-02-07 08:27:58 --> Helper loaded: url_helper
INFO - 2016-02-07 08:27:58 --> Helper loaded: file_helper
INFO - 2016-02-07 08:27:58 --> Helper loaded: date_helper
INFO - 2016-02-07 08:27:58 --> Helper loaded: form_helper
INFO - 2016-02-07 08:27:58 --> Database Driver Class Initialized
INFO - 2016-02-07 08:27:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:27:59 --> Controller Class Initialized
INFO - 2016-02-07 08:27:59 --> Model Class Initialized
INFO - 2016-02-07 08:27:59 --> Model Class Initialized
INFO - 2016-02-07 08:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:27:59 --> Pagination Class Initialized
INFO - 2016-02-07 08:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:27:59 --> Final output sent to browser
DEBUG - 2016-02-07 08:27:59 --> Total execution time: 1.0909
INFO - 2016-02-07 08:28:02 --> Config Class Initialized
INFO - 2016-02-07 08:28:02 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:28:02 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:28:02 --> Utf8 Class Initialized
INFO - 2016-02-07 08:28:02 --> URI Class Initialized
INFO - 2016-02-07 08:28:02 --> Router Class Initialized
INFO - 2016-02-07 08:28:02 --> Output Class Initialized
INFO - 2016-02-07 08:28:02 --> Security Class Initialized
DEBUG - 2016-02-07 08:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:28:02 --> Input Class Initialized
INFO - 2016-02-07 08:28:02 --> Language Class Initialized
INFO - 2016-02-07 08:28:02 --> Loader Class Initialized
INFO - 2016-02-07 08:28:02 --> Helper loaded: url_helper
INFO - 2016-02-07 08:28:02 --> Helper loaded: file_helper
INFO - 2016-02-07 08:28:02 --> Helper loaded: date_helper
INFO - 2016-02-07 08:28:02 --> Helper loaded: form_helper
INFO - 2016-02-07 08:28:02 --> Database Driver Class Initialized
INFO - 2016-02-07 08:28:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:28:03 --> Controller Class Initialized
INFO - 2016-02-07 08:28:03 --> Model Class Initialized
INFO - 2016-02-07 08:28:03 --> Model Class Initialized
INFO - 2016-02-07 08:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:28:03 --> Pagination Class Initialized
INFO - 2016-02-07 08:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:28:03 --> Helper loaded: text_helper
INFO - 2016-02-07 08:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:28:03 --> Final output sent to browser
DEBUG - 2016-02-07 08:28:03 --> Total execution time: 1.1741
INFO - 2016-02-07 08:28:11 --> Config Class Initialized
INFO - 2016-02-07 08:28:11 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:28:11 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:28:11 --> Utf8 Class Initialized
INFO - 2016-02-07 08:28:11 --> URI Class Initialized
INFO - 2016-02-07 08:28:11 --> Router Class Initialized
INFO - 2016-02-07 08:28:11 --> Output Class Initialized
INFO - 2016-02-07 08:28:11 --> Security Class Initialized
DEBUG - 2016-02-07 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:28:11 --> Input Class Initialized
INFO - 2016-02-07 08:28:11 --> Language Class Initialized
INFO - 2016-02-07 08:28:11 --> Loader Class Initialized
INFO - 2016-02-07 08:28:11 --> Helper loaded: url_helper
INFO - 2016-02-07 08:28:11 --> Helper loaded: file_helper
INFO - 2016-02-07 08:28:11 --> Helper loaded: date_helper
INFO - 2016-02-07 08:28:11 --> Helper loaded: form_helper
INFO - 2016-02-07 08:28:11 --> Database Driver Class Initialized
INFO - 2016-02-07 08:28:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:28:12 --> Controller Class Initialized
INFO - 2016-02-07 08:28:12 --> Model Class Initialized
INFO - 2016-02-07 08:28:12 --> Model Class Initialized
INFO - 2016-02-07 08:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:28:12 --> Pagination Class Initialized
INFO - 2016-02-07 08:28:12 --> Form Validation Class Initialized
INFO - 2016-02-07 08:28:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:28:12 --> Model Class Initialized
INFO - 2016-02-07 08:28:12 --> Final output sent to browser
DEBUG - 2016-02-07 08:28:12 --> Total execution time: 1.2062
INFO - 2016-02-07 08:28:37 --> Config Class Initialized
INFO - 2016-02-07 08:28:37 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:28:37 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:28:37 --> Utf8 Class Initialized
INFO - 2016-02-07 08:28:37 --> URI Class Initialized
INFO - 2016-02-07 08:28:37 --> Router Class Initialized
INFO - 2016-02-07 08:28:37 --> Output Class Initialized
INFO - 2016-02-07 08:28:37 --> Security Class Initialized
DEBUG - 2016-02-07 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:28:37 --> Input Class Initialized
INFO - 2016-02-07 08:28:37 --> Language Class Initialized
INFO - 2016-02-07 08:28:37 --> Loader Class Initialized
INFO - 2016-02-07 08:28:37 --> Helper loaded: url_helper
INFO - 2016-02-07 08:28:37 --> Helper loaded: file_helper
INFO - 2016-02-07 08:28:37 --> Helper loaded: date_helper
INFO - 2016-02-07 08:28:37 --> Helper loaded: form_helper
INFO - 2016-02-07 08:28:37 --> Database Driver Class Initialized
INFO - 2016-02-07 08:28:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:28:38 --> Controller Class Initialized
INFO - 2016-02-07 08:28:38 --> Model Class Initialized
INFO - 2016-02-07 08:28:38 --> Model Class Initialized
INFO - 2016-02-07 08:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:28:38 --> Pagination Class Initialized
INFO - 2016-02-07 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:28:38 --> Helper loaded: text_helper
INFO - 2016-02-07 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:28:38 --> Final output sent to browser
DEBUG - 2016-02-07 08:28:38 --> Total execution time: 1.1443
INFO - 2016-02-07 08:28:53 --> Config Class Initialized
INFO - 2016-02-07 08:28:53 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:28:53 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:28:53 --> Utf8 Class Initialized
INFO - 2016-02-07 08:28:53 --> URI Class Initialized
INFO - 2016-02-07 08:28:53 --> Router Class Initialized
INFO - 2016-02-07 08:28:53 --> Output Class Initialized
INFO - 2016-02-07 08:28:53 --> Security Class Initialized
DEBUG - 2016-02-07 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:28:53 --> Input Class Initialized
INFO - 2016-02-07 08:28:53 --> Language Class Initialized
INFO - 2016-02-07 08:28:53 --> Loader Class Initialized
INFO - 2016-02-07 08:28:53 --> Helper loaded: url_helper
INFO - 2016-02-07 08:28:53 --> Helper loaded: file_helper
INFO - 2016-02-07 08:28:53 --> Helper loaded: date_helper
INFO - 2016-02-07 08:28:53 --> Helper loaded: form_helper
INFO - 2016-02-07 08:28:53 --> Database Driver Class Initialized
INFO - 2016-02-07 08:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:28:54 --> Controller Class Initialized
INFO - 2016-02-07 08:28:54 --> Model Class Initialized
INFO - 2016-02-07 08:28:54 --> Model Class Initialized
INFO - 2016-02-07 08:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:28:54 --> Pagination Class Initialized
INFO - 2016-02-07 08:28:54 --> Form Validation Class Initialized
INFO - 2016-02-07 08:28:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:28:54 --> Model Class Initialized
INFO - 2016-02-07 08:28:54 --> Final output sent to browser
DEBUG - 2016-02-07 08:28:54 --> Total execution time: 1.1848
INFO - 2016-02-07 08:33:21 --> Config Class Initialized
INFO - 2016-02-07 08:33:21 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:33:21 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:33:21 --> Utf8 Class Initialized
INFO - 2016-02-07 08:33:21 --> URI Class Initialized
DEBUG - 2016-02-07 08:33:21 --> No URI present. Default controller set.
INFO - 2016-02-07 08:33:21 --> Router Class Initialized
INFO - 2016-02-07 08:33:21 --> Output Class Initialized
INFO - 2016-02-07 08:33:21 --> Security Class Initialized
DEBUG - 2016-02-07 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:33:21 --> Input Class Initialized
INFO - 2016-02-07 08:33:21 --> Language Class Initialized
INFO - 2016-02-07 08:33:21 --> Loader Class Initialized
INFO - 2016-02-07 08:33:21 --> Helper loaded: url_helper
INFO - 2016-02-07 08:33:21 --> Helper loaded: file_helper
INFO - 2016-02-07 08:33:21 --> Helper loaded: date_helper
INFO - 2016-02-07 08:33:21 --> Helper loaded: form_helper
INFO - 2016-02-07 08:33:21 --> Database Driver Class Initialized
INFO - 2016-02-07 08:33:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:33:22 --> Controller Class Initialized
INFO - 2016-02-07 08:33:22 --> Model Class Initialized
INFO - 2016-02-07 08:33:22 --> Model Class Initialized
INFO - 2016-02-07 08:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:33:22 --> Pagination Class Initialized
INFO - 2016-02-07 08:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:33:22 --> Final output sent to browser
DEBUG - 2016-02-07 08:33:22 --> Total execution time: 1.1054
INFO - 2016-02-07 08:33:24 --> Config Class Initialized
INFO - 2016-02-07 08:33:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:33:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:33:24 --> Utf8 Class Initialized
INFO - 2016-02-07 08:33:24 --> URI Class Initialized
INFO - 2016-02-07 08:33:24 --> Router Class Initialized
INFO - 2016-02-07 08:33:24 --> Output Class Initialized
INFO - 2016-02-07 08:33:24 --> Security Class Initialized
DEBUG - 2016-02-07 08:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:33:24 --> Input Class Initialized
INFO - 2016-02-07 08:33:24 --> Language Class Initialized
INFO - 2016-02-07 08:33:24 --> Loader Class Initialized
INFO - 2016-02-07 08:33:24 --> Helper loaded: url_helper
INFO - 2016-02-07 08:33:24 --> Helper loaded: file_helper
INFO - 2016-02-07 08:33:24 --> Helper loaded: date_helper
INFO - 2016-02-07 08:33:24 --> Helper loaded: form_helper
INFO - 2016-02-07 08:33:24 --> Database Driver Class Initialized
INFO - 2016-02-07 08:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:33:25 --> Controller Class Initialized
INFO - 2016-02-07 08:33:25 --> Model Class Initialized
INFO - 2016-02-07 08:33:25 --> Model Class Initialized
INFO - 2016-02-07 08:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:33:25 --> Pagination Class Initialized
INFO - 2016-02-07 08:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:33:25 --> Helper loaded: text_helper
INFO - 2016-02-07 08:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:33:25 --> Final output sent to browser
DEBUG - 2016-02-07 08:33:25 --> Total execution time: 1.1415
INFO - 2016-02-07 08:33:35 --> Config Class Initialized
INFO - 2016-02-07 08:33:35 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:33:35 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:33:35 --> Utf8 Class Initialized
INFO - 2016-02-07 08:33:35 --> URI Class Initialized
INFO - 2016-02-07 08:33:35 --> Router Class Initialized
INFO - 2016-02-07 08:33:35 --> Output Class Initialized
INFO - 2016-02-07 08:33:35 --> Security Class Initialized
DEBUG - 2016-02-07 08:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:33:35 --> Input Class Initialized
INFO - 2016-02-07 08:33:35 --> Language Class Initialized
INFO - 2016-02-07 08:33:35 --> Loader Class Initialized
INFO - 2016-02-07 08:33:35 --> Helper loaded: url_helper
INFO - 2016-02-07 08:33:35 --> Helper loaded: file_helper
INFO - 2016-02-07 08:33:35 --> Helper loaded: date_helper
INFO - 2016-02-07 08:33:35 --> Helper loaded: form_helper
INFO - 2016-02-07 08:33:35 --> Database Driver Class Initialized
INFO - 2016-02-07 08:33:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:33:36 --> Controller Class Initialized
INFO - 2016-02-07 08:33:36 --> Model Class Initialized
INFO - 2016-02-07 08:33:36 --> Model Class Initialized
INFO - 2016-02-07 08:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:33:36 --> Pagination Class Initialized
INFO - 2016-02-07 08:33:36 --> Form Validation Class Initialized
INFO - 2016-02-07 08:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:33:36 --> Model Class Initialized
INFO - 2016-02-07 08:33:36 --> Final output sent to browser
DEBUG - 2016-02-07 08:33:36 --> Total execution time: 1.1944
INFO - 2016-02-07 08:36:09 --> Config Class Initialized
INFO - 2016-02-07 08:36:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:36:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:36:09 --> Utf8 Class Initialized
INFO - 2016-02-07 08:36:09 --> URI Class Initialized
INFO - 2016-02-07 08:36:09 --> Router Class Initialized
INFO - 2016-02-07 08:36:09 --> Output Class Initialized
INFO - 2016-02-07 08:36:09 --> Security Class Initialized
DEBUG - 2016-02-07 08:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:36:09 --> Input Class Initialized
INFO - 2016-02-07 08:36:09 --> Language Class Initialized
INFO - 2016-02-07 08:36:09 --> Loader Class Initialized
INFO - 2016-02-07 08:36:09 --> Helper loaded: url_helper
INFO - 2016-02-07 08:36:09 --> Helper loaded: file_helper
INFO - 2016-02-07 08:36:09 --> Helper loaded: date_helper
INFO - 2016-02-07 08:36:09 --> Helper loaded: form_helper
INFO - 2016-02-07 08:36:09 --> Database Driver Class Initialized
INFO - 2016-02-07 08:36:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:36:10 --> Controller Class Initialized
INFO - 2016-02-07 08:36:10 --> Model Class Initialized
INFO - 2016-02-07 08:36:10 --> Model Class Initialized
INFO - 2016-02-07 08:36:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:36:10 --> Pagination Class Initialized
INFO - 2016-02-07 08:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:36:10 --> Helper loaded: text_helper
INFO - 2016-02-07 08:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:36:10 --> Final output sent to browser
DEBUG - 2016-02-07 08:36:10 --> Total execution time: 1.1422
INFO - 2016-02-07 08:40:52 --> Config Class Initialized
INFO - 2016-02-07 08:40:52 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:40:52 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:40:52 --> Utf8 Class Initialized
INFO - 2016-02-07 08:40:52 --> URI Class Initialized
INFO - 2016-02-07 08:40:52 --> Router Class Initialized
INFO - 2016-02-07 08:40:52 --> Output Class Initialized
INFO - 2016-02-07 08:40:52 --> Security Class Initialized
DEBUG - 2016-02-07 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:40:52 --> Input Class Initialized
INFO - 2016-02-07 08:40:52 --> Language Class Initialized
INFO - 2016-02-07 08:40:52 --> Loader Class Initialized
INFO - 2016-02-07 08:40:52 --> Helper loaded: url_helper
INFO - 2016-02-07 08:40:52 --> Helper loaded: file_helper
INFO - 2016-02-07 08:40:52 --> Helper loaded: date_helper
INFO - 2016-02-07 08:40:52 --> Helper loaded: form_helper
INFO - 2016-02-07 08:40:52 --> Database Driver Class Initialized
INFO - 2016-02-07 08:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:40:53 --> Controller Class Initialized
INFO - 2016-02-07 08:40:53 --> Model Class Initialized
INFO - 2016-02-07 08:40:53 --> Model Class Initialized
INFO - 2016-02-07 08:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:40:53 --> Pagination Class Initialized
INFO - 2016-02-07 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:40:53 --> Helper loaded: text_helper
INFO - 2016-02-07 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:40:53 --> Final output sent to browser
DEBUG - 2016-02-07 08:40:53 --> Total execution time: 1.2619
INFO - 2016-02-07 08:41:05 --> Config Class Initialized
INFO - 2016-02-07 08:41:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:41:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:41:05 --> Utf8 Class Initialized
INFO - 2016-02-07 08:41:05 --> URI Class Initialized
INFO - 2016-02-07 08:41:05 --> Router Class Initialized
INFO - 2016-02-07 08:41:05 --> Output Class Initialized
INFO - 2016-02-07 08:41:05 --> Security Class Initialized
DEBUG - 2016-02-07 08:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:41:05 --> Input Class Initialized
INFO - 2016-02-07 08:41:05 --> Language Class Initialized
INFO - 2016-02-07 08:41:05 --> Loader Class Initialized
INFO - 2016-02-07 08:41:05 --> Helper loaded: url_helper
INFO - 2016-02-07 08:41:05 --> Helper loaded: file_helper
INFO - 2016-02-07 08:41:05 --> Helper loaded: date_helper
INFO - 2016-02-07 08:41:05 --> Helper loaded: form_helper
INFO - 2016-02-07 08:41:05 --> Database Driver Class Initialized
INFO - 2016-02-07 08:41:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:41:06 --> Controller Class Initialized
INFO - 2016-02-07 08:41:06 --> Model Class Initialized
INFO - 2016-02-07 08:41:06 --> Model Class Initialized
INFO - 2016-02-07 08:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:41:06 --> Pagination Class Initialized
INFO - 2016-02-07 08:41:06 --> Form Validation Class Initialized
INFO - 2016-02-07 08:41:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:41:06 --> Model Class Initialized
INFO - 2016-02-07 08:41:07 --> Final output sent to browser
DEBUG - 2016-02-07 08:41:07 --> Total execution time: 1.2185
INFO - 2016-02-07 08:41:46 --> Config Class Initialized
INFO - 2016-02-07 08:41:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:41:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:41:46 --> Utf8 Class Initialized
INFO - 2016-02-07 08:41:46 --> URI Class Initialized
INFO - 2016-02-07 08:41:46 --> Router Class Initialized
INFO - 2016-02-07 08:41:46 --> Output Class Initialized
INFO - 2016-02-07 08:41:46 --> Security Class Initialized
DEBUG - 2016-02-07 08:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:41:46 --> Input Class Initialized
INFO - 2016-02-07 08:41:46 --> Language Class Initialized
INFO - 2016-02-07 08:41:46 --> Loader Class Initialized
INFO - 2016-02-07 08:41:46 --> Helper loaded: url_helper
INFO - 2016-02-07 08:41:46 --> Helper loaded: file_helper
INFO - 2016-02-07 08:41:46 --> Helper loaded: date_helper
INFO - 2016-02-07 08:41:46 --> Helper loaded: form_helper
INFO - 2016-02-07 08:41:46 --> Database Driver Class Initialized
INFO - 2016-02-07 08:41:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:41:47 --> Controller Class Initialized
INFO - 2016-02-07 08:41:47 --> Model Class Initialized
INFO - 2016-02-07 08:41:47 --> Model Class Initialized
INFO - 2016-02-07 08:41:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:41:47 --> Pagination Class Initialized
INFO - 2016-02-07 08:41:47 --> Form Validation Class Initialized
INFO - 2016-02-07 08:41:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:41:47 --> Model Class Initialized
INFO - 2016-02-07 08:41:47 --> Final output sent to browser
DEBUG - 2016-02-07 08:41:47 --> Total execution time: 1.1864
INFO - 2016-02-07 08:43:28 --> Config Class Initialized
INFO - 2016-02-07 08:43:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:43:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:43:28 --> Utf8 Class Initialized
INFO - 2016-02-07 08:43:28 --> URI Class Initialized
DEBUG - 2016-02-07 08:43:28 --> No URI present. Default controller set.
INFO - 2016-02-07 08:43:28 --> Router Class Initialized
INFO - 2016-02-07 08:43:28 --> Output Class Initialized
INFO - 2016-02-07 08:43:28 --> Security Class Initialized
DEBUG - 2016-02-07 08:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:43:28 --> Input Class Initialized
INFO - 2016-02-07 08:43:28 --> Language Class Initialized
INFO - 2016-02-07 08:43:28 --> Loader Class Initialized
INFO - 2016-02-07 08:43:28 --> Helper loaded: url_helper
INFO - 2016-02-07 08:43:28 --> Helper loaded: file_helper
INFO - 2016-02-07 08:43:28 --> Helper loaded: date_helper
INFO - 2016-02-07 08:43:28 --> Helper loaded: form_helper
INFO - 2016-02-07 08:43:28 --> Database Driver Class Initialized
INFO - 2016-02-07 08:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:43:29 --> Controller Class Initialized
INFO - 2016-02-07 08:43:29 --> Model Class Initialized
INFO - 2016-02-07 08:43:29 --> Model Class Initialized
INFO - 2016-02-07 08:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:43:29 --> Pagination Class Initialized
INFO - 2016-02-07 08:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:43:29 --> Final output sent to browser
DEBUG - 2016-02-07 08:43:29 --> Total execution time: 1.1098
INFO - 2016-02-07 08:43:32 --> Config Class Initialized
INFO - 2016-02-07 08:43:32 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:43:32 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:43:32 --> Utf8 Class Initialized
INFO - 2016-02-07 08:43:32 --> URI Class Initialized
INFO - 2016-02-07 08:43:32 --> Router Class Initialized
INFO - 2016-02-07 08:43:32 --> Output Class Initialized
INFO - 2016-02-07 08:43:32 --> Security Class Initialized
DEBUG - 2016-02-07 08:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:43:32 --> Input Class Initialized
INFO - 2016-02-07 08:43:32 --> Language Class Initialized
INFO - 2016-02-07 08:43:32 --> Loader Class Initialized
INFO - 2016-02-07 08:43:32 --> Helper loaded: url_helper
INFO - 2016-02-07 08:43:32 --> Helper loaded: file_helper
INFO - 2016-02-07 08:43:32 --> Helper loaded: date_helper
INFO - 2016-02-07 08:43:32 --> Helper loaded: form_helper
INFO - 2016-02-07 08:43:32 --> Database Driver Class Initialized
INFO - 2016-02-07 08:43:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:43:33 --> Controller Class Initialized
INFO - 2016-02-07 08:43:33 --> Model Class Initialized
INFO - 2016-02-07 08:43:33 --> Model Class Initialized
INFO - 2016-02-07 08:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:43:33 --> Pagination Class Initialized
INFO - 2016-02-07 08:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:43:33 --> Helper loaded: text_helper
INFO - 2016-02-07 08:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:43:33 --> Final output sent to browser
DEBUG - 2016-02-07 08:43:33 --> Total execution time: 1.1444
INFO - 2016-02-07 08:43:39 --> Config Class Initialized
INFO - 2016-02-07 08:43:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:43:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:43:39 --> Utf8 Class Initialized
INFO - 2016-02-07 08:43:39 --> URI Class Initialized
INFO - 2016-02-07 08:43:39 --> Router Class Initialized
INFO - 2016-02-07 08:43:39 --> Output Class Initialized
INFO - 2016-02-07 08:43:39 --> Security Class Initialized
DEBUG - 2016-02-07 08:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:43:39 --> Input Class Initialized
INFO - 2016-02-07 08:43:39 --> Language Class Initialized
INFO - 2016-02-07 08:43:39 --> Loader Class Initialized
INFO - 2016-02-07 08:43:39 --> Helper loaded: url_helper
INFO - 2016-02-07 08:43:39 --> Helper loaded: file_helper
INFO - 2016-02-07 08:43:39 --> Helper loaded: date_helper
INFO - 2016-02-07 08:43:39 --> Helper loaded: form_helper
INFO - 2016-02-07 08:43:39 --> Database Driver Class Initialized
INFO - 2016-02-07 08:43:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:43:40 --> Controller Class Initialized
INFO - 2016-02-07 08:43:40 --> Model Class Initialized
INFO - 2016-02-07 08:43:40 --> Model Class Initialized
INFO - 2016-02-07 08:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:43:40 --> Pagination Class Initialized
INFO - 2016-02-07 08:43:40 --> Form Validation Class Initialized
INFO - 2016-02-07 08:43:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:43:40 --> Model Class Initialized
INFO - 2016-02-07 08:43:40 --> Final output sent to browser
DEBUG - 2016-02-07 08:43:40 --> Total execution time: 1.1675
INFO - 2016-02-07 08:46:42 --> Config Class Initialized
INFO - 2016-02-07 08:46:42 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:46:42 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:46:42 --> Utf8 Class Initialized
INFO - 2016-02-07 08:46:43 --> URI Class Initialized
DEBUG - 2016-02-07 08:46:43 --> No URI present. Default controller set.
INFO - 2016-02-07 08:46:43 --> Router Class Initialized
INFO - 2016-02-07 08:46:43 --> Output Class Initialized
INFO - 2016-02-07 08:46:43 --> Security Class Initialized
DEBUG - 2016-02-07 08:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:46:43 --> Input Class Initialized
INFO - 2016-02-07 08:46:43 --> Language Class Initialized
INFO - 2016-02-07 08:46:43 --> Loader Class Initialized
INFO - 2016-02-07 08:46:43 --> Helper loaded: url_helper
INFO - 2016-02-07 08:46:43 --> Helper loaded: file_helper
INFO - 2016-02-07 08:46:43 --> Helper loaded: date_helper
INFO - 2016-02-07 08:46:43 --> Helper loaded: form_helper
INFO - 2016-02-07 08:46:43 --> Database Driver Class Initialized
INFO - 2016-02-07 08:46:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:46:44 --> Controller Class Initialized
INFO - 2016-02-07 08:46:44 --> Model Class Initialized
INFO - 2016-02-07 08:46:44 --> Model Class Initialized
INFO - 2016-02-07 08:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:46:44 --> Pagination Class Initialized
INFO - 2016-02-07 08:46:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:46:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:46:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 08:46:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:46:44 --> Final output sent to browser
DEBUG - 2016-02-07 08:46:44 --> Total execution time: 1.1319
INFO - 2016-02-07 08:46:46 --> Config Class Initialized
INFO - 2016-02-07 08:46:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:46:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:46:46 --> Utf8 Class Initialized
INFO - 2016-02-07 08:46:46 --> URI Class Initialized
INFO - 2016-02-07 08:46:46 --> Router Class Initialized
INFO - 2016-02-07 08:46:46 --> Output Class Initialized
INFO - 2016-02-07 08:46:46 --> Security Class Initialized
DEBUG - 2016-02-07 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:46:46 --> Input Class Initialized
INFO - 2016-02-07 08:46:46 --> Language Class Initialized
INFO - 2016-02-07 08:46:46 --> Loader Class Initialized
INFO - 2016-02-07 08:46:46 --> Helper loaded: url_helper
INFO - 2016-02-07 08:46:46 --> Helper loaded: file_helper
INFO - 2016-02-07 08:46:46 --> Helper loaded: date_helper
INFO - 2016-02-07 08:46:46 --> Helper loaded: form_helper
INFO - 2016-02-07 08:46:46 --> Database Driver Class Initialized
INFO - 2016-02-07 08:46:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:46:47 --> Controller Class Initialized
INFO - 2016-02-07 08:46:47 --> Model Class Initialized
INFO - 2016-02-07 08:46:47 --> Model Class Initialized
INFO - 2016-02-07 08:46:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:46:47 --> Pagination Class Initialized
INFO - 2016-02-07 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:46:47 --> Helper loaded: text_helper
INFO - 2016-02-07 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:46:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:46:47 --> Final output sent to browser
DEBUG - 2016-02-07 08:46:47 --> Total execution time: 1.1909
INFO - 2016-02-07 08:46:55 --> Config Class Initialized
INFO - 2016-02-07 08:46:55 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:46:55 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:46:55 --> Utf8 Class Initialized
INFO - 2016-02-07 08:46:55 --> URI Class Initialized
INFO - 2016-02-07 08:46:55 --> Router Class Initialized
INFO - 2016-02-07 08:46:55 --> Output Class Initialized
INFO - 2016-02-07 08:46:55 --> Security Class Initialized
DEBUG - 2016-02-07 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:46:55 --> Input Class Initialized
INFO - 2016-02-07 08:46:55 --> Language Class Initialized
INFO - 2016-02-07 08:46:55 --> Loader Class Initialized
INFO - 2016-02-07 08:46:55 --> Helper loaded: url_helper
INFO - 2016-02-07 08:46:55 --> Helper loaded: file_helper
INFO - 2016-02-07 08:46:55 --> Helper loaded: date_helper
INFO - 2016-02-07 08:46:55 --> Helper loaded: form_helper
INFO - 2016-02-07 08:46:55 --> Database Driver Class Initialized
INFO - 2016-02-07 08:46:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:46:56 --> Controller Class Initialized
INFO - 2016-02-07 08:46:56 --> Model Class Initialized
INFO - 2016-02-07 08:46:56 --> Model Class Initialized
INFO - 2016-02-07 08:46:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:46:56 --> Pagination Class Initialized
INFO - 2016-02-07 08:46:56 --> Form Validation Class Initialized
INFO - 2016-02-07 08:46:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:46:56 --> Model Class Initialized
INFO - 2016-02-07 08:46:56 --> Final output sent to browser
DEBUG - 2016-02-07 08:46:56 --> Total execution time: 1.1904
INFO - 2016-02-07 08:47:01 --> Config Class Initialized
INFO - 2016-02-07 08:47:01 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:47:01 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:47:01 --> Utf8 Class Initialized
INFO - 2016-02-07 08:47:01 --> URI Class Initialized
INFO - 2016-02-07 08:47:01 --> Router Class Initialized
INFO - 2016-02-07 08:47:01 --> Output Class Initialized
INFO - 2016-02-07 08:47:01 --> Security Class Initialized
DEBUG - 2016-02-07 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:47:01 --> Input Class Initialized
INFO - 2016-02-07 08:47:01 --> Language Class Initialized
INFO - 2016-02-07 08:47:01 --> Loader Class Initialized
INFO - 2016-02-07 08:47:01 --> Helper loaded: url_helper
INFO - 2016-02-07 08:47:01 --> Helper loaded: file_helper
INFO - 2016-02-07 08:47:01 --> Helper loaded: date_helper
INFO - 2016-02-07 08:47:01 --> Helper loaded: form_helper
INFO - 2016-02-07 08:47:01 --> Database Driver Class Initialized
INFO - 2016-02-07 08:47:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:47:02 --> Controller Class Initialized
INFO - 2016-02-07 08:47:02 --> Model Class Initialized
INFO - 2016-02-07 08:47:02 --> Model Class Initialized
INFO - 2016-02-07 08:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:47:02 --> Pagination Class Initialized
INFO - 2016-02-07 08:47:02 --> Form Validation Class Initialized
INFO - 2016-02-07 08:47:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:47:02 --> Model Class Initialized
INFO - 2016-02-07 08:47:02 --> Final output sent to browser
DEBUG - 2016-02-07 08:47:02 --> Total execution time: 1.1829
INFO - 2016-02-07 08:47:02 --> Config Class Initialized
INFO - 2016-02-07 08:47:02 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:47:02 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:47:02 --> Utf8 Class Initialized
INFO - 2016-02-07 08:47:02 --> URI Class Initialized
INFO - 2016-02-07 08:47:02 --> Router Class Initialized
INFO - 2016-02-07 08:47:02 --> Output Class Initialized
INFO - 2016-02-07 08:47:02 --> Security Class Initialized
DEBUG - 2016-02-07 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:47:02 --> Input Class Initialized
INFO - 2016-02-07 08:47:02 --> Language Class Initialized
INFO - 2016-02-07 08:47:02 --> Loader Class Initialized
INFO - 2016-02-07 08:47:02 --> Helper loaded: url_helper
INFO - 2016-02-07 08:47:02 --> Helper loaded: file_helper
INFO - 2016-02-07 08:47:02 --> Helper loaded: date_helper
INFO - 2016-02-07 08:47:02 --> Helper loaded: form_helper
INFO - 2016-02-07 08:47:02 --> Database Driver Class Initialized
INFO - 2016-02-07 08:47:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:47:03 --> Controller Class Initialized
INFO - 2016-02-07 08:47:03 --> Model Class Initialized
INFO - 2016-02-07 08:47:03 --> Model Class Initialized
INFO - 2016-02-07 08:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:47:03 --> Pagination Class Initialized
INFO - 2016-02-07 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 08:47:03 --> Helper loaded: text_helper
INFO - 2016-02-07 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 08:47:03 --> Final output sent to browser
DEBUG - 2016-02-07 08:47:03 --> Total execution time: 1.1451
INFO - 2016-02-07 08:47:23 --> Config Class Initialized
INFO - 2016-02-07 08:47:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 08:47:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 08:47:23 --> Utf8 Class Initialized
INFO - 2016-02-07 08:47:23 --> URI Class Initialized
INFO - 2016-02-07 08:47:23 --> Router Class Initialized
INFO - 2016-02-07 08:47:23 --> Output Class Initialized
INFO - 2016-02-07 08:47:23 --> Security Class Initialized
DEBUG - 2016-02-07 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 08:47:23 --> Input Class Initialized
INFO - 2016-02-07 08:47:23 --> Language Class Initialized
INFO - 2016-02-07 08:47:23 --> Loader Class Initialized
INFO - 2016-02-07 08:47:23 --> Helper loaded: url_helper
INFO - 2016-02-07 08:47:23 --> Helper loaded: file_helper
INFO - 2016-02-07 08:47:23 --> Helper loaded: date_helper
INFO - 2016-02-07 08:47:23 --> Helper loaded: form_helper
INFO - 2016-02-07 08:47:23 --> Database Driver Class Initialized
INFO - 2016-02-07 08:47:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 08:47:24 --> Controller Class Initialized
INFO - 2016-02-07 08:47:24 --> Model Class Initialized
INFO - 2016-02-07 08:47:24 --> Model Class Initialized
INFO - 2016-02-07 08:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 08:47:24 --> Pagination Class Initialized
INFO - 2016-02-07 08:47:24 --> Form Validation Class Initialized
INFO - 2016-02-07 08:47:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 08:47:24 --> Model Class Initialized
INFO - 2016-02-07 08:47:24 --> Final output sent to browser
DEBUG - 2016-02-07 08:47:24 --> Total execution time: 1.2375
INFO - 2016-02-07 09:40:07 --> Config Class Initialized
INFO - 2016-02-07 09:40:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:40:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:40:07 --> Utf8 Class Initialized
INFO - 2016-02-07 09:40:07 --> URI Class Initialized
DEBUG - 2016-02-07 09:40:07 --> No URI present. Default controller set.
INFO - 2016-02-07 09:40:07 --> Router Class Initialized
INFO - 2016-02-07 09:40:07 --> Output Class Initialized
INFO - 2016-02-07 09:40:07 --> Security Class Initialized
DEBUG - 2016-02-07 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:40:07 --> Input Class Initialized
INFO - 2016-02-07 09:40:07 --> Language Class Initialized
INFO - 2016-02-07 09:40:07 --> Loader Class Initialized
INFO - 2016-02-07 09:40:07 --> Helper loaded: url_helper
INFO - 2016-02-07 09:40:07 --> Helper loaded: file_helper
INFO - 2016-02-07 09:40:07 --> Helper loaded: date_helper
INFO - 2016-02-07 09:40:07 --> Helper loaded: form_helper
INFO - 2016-02-07 09:40:07 --> Database Driver Class Initialized
INFO - 2016-02-07 09:40:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:40:08 --> Controller Class Initialized
INFO - 2016-02-07 09:40:08 --> Model Class Initialized
INFO - 2016-02-07 09:40:08 --> Model Class Initialized
INFO - 2016-02-07 09:40:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:40:08 --> Pagination Class Initialized
INFO - 2016-02-07 09:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 09:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:40:08 --> Final output sent to browser
DEBUG - 2016-02-07 09:40:08 --> Total execution time: 1.4895
INFO - 2016-02-07 09:40:10 --> Config Class Initialized
INFO - 2016-02-07 09:40:10 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:40:10 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:40:10 --> Utf8 Class Initialized
INFO - 2016-02-07 09:40:10 --> URI Class Initialized
INFO - 2016-02-07 09:40:10 --> Router Class Initialized
INFO - 2016-02-07 09:40:10 --> Output Class Initialized
INFO - 2016-02-07 09:40:10 --> Security Class Initialized
DEBUG - 2016-02-07 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:40:10 --> Input Class Initialized
INFO - 2016-02-07 09:40:10 --> Language Class Initialized
INFO - 2016-02-07 09:40:10 --> Loader Class Initialized
INFO - 2016-02-07 09:40:10 --> Helper loaded: url_helper
INFO - 2016-02-07 09:40:10 --> Helper loaded: file_helper
INFO - 2016-02-07 09:40:10 --> Helper loaded: date_helper
INFO - 2016-02-07 09:40:11 --> Helper loaded: form_helper
INFO - 2016-02-07 09:40:11 --> Database Driver Class Initialized
INFO - 2016-02-07 09:40:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:40:12 --> Controller Class Initialized
INFO - 2016-02-07 09:40:12 --> Model Class Initialized
INFO - 2016-02-07 09:40:12 --> Model Class Initialized
INFO - 2016-02-07 09:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:40:12 --> Pagination Class Initialized
INFO - 2016-02-07 09:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:40:12 --> Helper loaded: text_helper
INFO - 2016-02-07 09:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 09:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 09:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:40:12 --> Final output sent to browser
DEBUG - 2016-02-07 09:40:12 --> Total execution time: 1.2150
INFO - 2016-02-07 09:40:23 --> Config Class Initialized
INFO - 2016-02-07 09:40:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:40:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:40:23 --> Utf8 Class Initialized
INFO - 2016-02-07 09:40:23 --> URI Class Initialized
INFO - 2016-02-07 09:40:23 --> Router Class Initialized
INFO - 2016-02-07 09:40:23 --> Output Class Initialized
INFO - 2016-02-07 09:40:23 --> Security Class Initialized
DEBUG - 2016-02-07 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:40:23 --> Input Class Initialized
INFO - 2016-02-07 09:40:23 --> Language Class Initialized
INFO - 2016-02-07 09:40:23 --> Loader Class Initialized
INFO - 2016-02-07 09:40:23 --> Helper loaded: url_helper
INFO - 2016-02-07 09:40:23 --> Helper loaded: file_helper
INFO - 2016-02-07 09:40:23 --> Helper loaded: date_helper
INFO - 2016-02-07 09:40:23 --> Helper loaded: form_helper
INFO - 2016-02-07 09:40:23 --> Database Driver Class Initialized
INFO - 2016-02-07 09:40:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:40:24 --> Controller Class Initialized
INFO - 2016-02-07 09:40:24 --> Model Class Initialized
INFO - 2016-02-07 09:40:24 --> Model Class Initialized
INFO - 2016-02-07 09:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:40:24 --> Pagination Class Initialized
INFO - 2016-02-07 09:40:24 --> Form Validation Class Initialized
INFO - 2016-02-07 09:40:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 09:40:24 --> Final output sent to browser
DEBUG - 2016-02-07 09:40:24 --> Total execution time: 1.1612
INFO - 2016-02-07 09:49:39 --> Config Class Initialized
INFO - 2016-02-07 09:49:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:49:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:49:39 --> Utf8 Class Initialized
INFO - 2016-02-07 09:49:39 --> URI Class Initialized
INFO - 2016-02-07 09:49:39 --> Router Class Initialized
INFO - 2016-02-07 09:49:39 --> Output Class Initialized
INFO - 2016-02-07 09:49:39 --> Security Class Initialized
DEBUG - 2016-02-07 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:49:39 --> Input Class Initialized
INFO - 2016-02-07 09:49:39 --> Language Class Initialized
INFO - 2016-02-07 09:49:39 --> Loader Class Initialized
INFO - 2016-02-07 09:49:39 --> Helper loaded: url_helper
INFO - 2016-02-07 09:49:39 --> Helper loaded: file_helper
INFO - 2016-02-07 09:49:39 --> Helper loaded: date_helper
INFO - 2016-02-07 09:49:39 --> Helper loaded: form_helper
INFO - 2016-02-07 09:49:39 --> Database Driver Class Initialized
INFO - 2016-02-07 09:49:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:49:40 --> Controller Class Initialized
INFO - 2016-02-07 09:49:40 --> Model Class Initialized
INFO - 2016-02-07 09:49:40 --> Model Class Initialized
INFO - 2016-02-07 09:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:49:40 --> Pagination Class Initialized
INFO - 2016-02-07 09:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:49:40 --> Helper loaded: text_helper
INFO - 2016-02-07 09:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 09:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 09:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:49:40 --> Final output sent to browser
DEBUG - 2016-02-07 09:49:40 --> Total execution time: 1.2068
INFO - 2016-02-07 09:49:53 --> Config Class Initialized
INFO - 2016-02-07 09:49:53 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:49:53 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:49:53 --> Utf8 Class Initialized
INFO - 2016-02-07 09:49:53 --> URI Class Initialized
INFO - 2016-02-07 09:49:53 --> Router Class Initialized
INFO - 2016-02-07 09:49:53 --> Output Class Initialized
INFO - 2016-02-07 09:49:53 --> Security Class Initialized
DEBUG - 2016-02-07 09:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:49:53 --> Input Class Initialized
INFO - 2016-02-07 09:49:53 --> Language Class Initialized
INFO - 2016-02-07 09:49:53 --> Loader Class Initialized
INFO - 2016-02-07 09:49:53 --> Helper loaded: url_helper
INFO - 2016-02-07 09:49:53 --> Helper loaded: file_helper
INFO - 2016-02-07 09:49:53 --> Helper loaded: date_helper
INFO - 2016-02-07 09:49:53 --> Helper loaded: form_helper
INFO - 2016-02-07 09:49:53 --> Database Driver Class Initialized
INFO - 2016-02-07 09:49:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:49:54 --> Controller Class Initialized
INFO - 2016-02-07 09:49:54 --> Model Class Initialized
INFO - 2016-02-07 09:49:54 --> Model Class Initialized
INFO - 2016-02-07 09:49:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:49:54 --> Pagination Class Initialized
INFO - 2016-02-07 09:49:54 --> Form Validation Class Initialized
INFO - 2016-02-07 09:49:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 09:49:54 --> Model Class Initialized
INFO - 2016-02-07 09:49:54 --> Final output sent to browser
DEBUG - 2016-02-07 09:49:54 --> Total execution time: 1.2119
INFO - 2016-02-07 09:50:45 --> Config Class Initialized
INFO - 2016-02-07 09:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:50:45 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:50:45 --> Utf8 Class Initialized
INFO - 2016-02-07 09:50:45 --> URI Class Initialized
DEBUG - 2016-02-07 09:50:45 --> No URI present. Default controller set.
INFO - 2016-02-07 09:50:45 --> Router Class Initialized
INFO - 2016-02-07 09:50:45 --> Output Class Initialized
INFO - 2016-02-07 09:50:45 --> Security Class Initialized
DEBUG - 2016-02-07 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:50:45 --> Input Class Initialized
INFO - 2016-02-07 09:50:45 --> Language Class Initialized
INFO - 2016-02-07 09:50:45 --> Loader Class Initialized
INFO - 2016-02-07 09:50:45 --> Helper loaded: url_helper
INFO - 2016-02-07 09:50:45 --> Helper loaded: file_helper
INFO - 2016-02-07 09:50:45 --> Helper loaded: date_helper
INFO - 2016-02-07 09:50:45 --> Helper loaded: form_helper
INFO - 2016-02-07 09:50:45 --> Database Driver Class Initialized
INFO - 2016-02-07 09:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:50:46 --> Controller Class Initialized
INFO - 2016-02-07 09:50:46 --> Model Class Initialized
INFO - 2016-02-07 09:50:46 --> Model Class Initialized
INFO - 2016-02-07 09:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:50:46 --> Pagination Class Initialized
INFO - 2016-02-07 09:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 09:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:50:46 --> Final output sent to browser
DEBUG - 2016-02-07 09:50:46 --> Total execution time: 1.1470
INFO - 2016-02-07 09:50:48 --> Config Class Initialized
INFO - 2016-02-07 09:50:48 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:50:48 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:50:48 --> Utf8 Class Initialized
INFO - 2016-02-07 09:50:48 --> URI Class Initialized
INFO - 2016-02-07 09:50:48 --> Router Class Initialized
INFO - 2016-02-07 09:50:48 --> Output Class Initialized
INFO - 2016-02-07 09:50:48 --> Security Class Initialized
DEBUG - 2016-02-07 09:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:50:48 --> Input Class Initialized
INFO - 2016-02-07 09:50:48 --> Language Class Initialized
INFO - 2016-02-07 09:50:48 --> Loader Class Initialized
INFO - 2016-02-07 09:50:48 --> Helper loaded: url_helper
INFO - 2016-02-07 09:50:48 --> Helper loaded: file_helper
INFO - 2016-02-07 09:50:48 --> Helper loaded: date_helper
INFO - 2016-02-07 09:50:48 --> Helper loaded: form_helper
INFO - 2016-02-07 09:50:48 --> Database Driver Class Initialized
INFO - 2016-02-07 09:50:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:50:49 --> Controller Class Initialized
INFO - 2016-02-07 09:50:49 --> Model Class Initialized
INFO - 2016-02-07 09:50:49 --> Model Class Initialized
INFO - 2016-02-07 09:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:50:49 --> Pagination Class Initialized
INFO - 2016-02-07 09:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:50:49 --> Helper loaded: text_helper
INFO - 2016-02-07 09:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 09:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 09:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:50:49 --> Final output sent to browser
DEBUG - 2016-02-07 09:50:49 --> Total execution time: 1.3194
INFO - 2016-02-07 09:51:01 --> Config Class Initialized
INFO - 2016-02-07 09:51:01 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:51:01 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:51:01 --> Utf8 Class Initialized
INFO - 2016-02-07 09:51:01 --> URI Class Initialized
INFO - 2016-02-07 09:51:01 --> Router Class Initialized
INFO - 2016-02-07 09:51:01 --> Output Class Initialized
INFO - 2016-02-07 09:51:01 --> Security Class Initialized
DEBUG - 2016-02-07 09:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:51:01 --> Input Class Initialized
INFO - 2016-02-07 09:51:01 --> Language Class Initialized
INFO - 2016-02-07 09:51:01 --> Loader Class Initialized
INFO - 2016-02-07 09:51:01 --> Helper loaded: url_helper
INFO - 2016-02-07 09:51:01 --> Helper loaded: file_helper
INFO - 2016-02-07 09:51:01 --> Helper loaded: date_helper
INFO - 2016-02-07 09:51:01 --> Helper loaded: form_helper
INFO - 2016-02-07 09:51:01 --> Database Driver Class Initialized
INFO - 2016-02-07 09:51:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:51:02 --> Controller Class Initialized
INFO - 2016-02-07 09:51:02 --> Model Class Initialized
INFO - 2016-02-07 09:51:02 --> Model Class Initialized
INFO - 2016-02-07 09:51:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:51:02 --> Pagination Class Initialized
INFO - 2016-02-07 09:51:02 --> Form Validation Class Initialized
INFO - 2016-02-07 09:51:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 09:51:02 --> Model Class Initialized
INFO - 2016-02-07 09:51:02 --> Final output sent to browser
DEBUG - 2016-02-07 09:51:02 --> Total execution time: 1.2346
INFO - 2016-02-07 09:53:27 --> Config Class Initialized
INFO - 2016-02-07 09:53:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:53:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:53:27 --> Utf8 Class Initialized
INFO - 2016-02-07 09:53:27 --> URI Class Initialized
INFO - 2016-02-07 09:53:27 --> Router Class Initialized
INFO - 2016-02-07 09:53:27 --> Output Class Initialized
INFO - 2016-02-07 09:53:27 --> Security Class Initialized
DEBUG - 2016-02-07 09:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:53:27 --> Input Class Initialized
INFO - 2016-02-07 09:53:27 --> Language Class Initialized
INFO - 2016-02-07 09:53:27 --> Loader Class Initialized
INFO - 2016-02-07 09:53:27 --> Helper loaded: url_helper
INFO - 2016-02-07 09:53:27 --> Helper loaded: file_helper
INFO - 2016-02-07 09:53:27 --> Helper loaded: date_helper
INFO - 2016-02-07 09:53:27 --> Helper loaded: form_helper
INFO - 2016-02-07 09:53:27 --> Database Driver Class Initialized
INFO - 2016-02-07 09:53:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:53:28 --> Controller Class Initialized
INFO - 2016-02-07 09:53:28 --> Model Class Initialized
INFO - 2016-02-07 09:53:28 --> Model Class Initialized
INFO - 2016-02-07 09:53:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:53:28 --> Pagination Class Initialized
INFO - 2016-02-07 09:53:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 09:53:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 09:53:28 --> Helper loaded: text_helper
INFO - 2016-02-07 09:53:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 09:53:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 09:53:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 09:53:28 --> Final output sent to browser
DEBUG - 2016-02-07 09:53:28 --> Total execution time: 1.4687
INFO - 2016-02-07 09:53:40 --> Config Class Initialized
INFO - 2016-02-07 09:53:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:53:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:53:40 --> Utf8 Class Initialized
INFO - 2016-02-07 09:53:40 --> URI Class Initialized
INFO - 2016-02-07 09:53:40 --> Router Class Initialized
INFO - 2016-02-07 09:53:40 --> Output Class Initialized
INFO - 2016-02-07 09:53:40 --> Security Class Initialized
DEBUG - 2016-02-07 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:53:40 --> Input Class Initialized
INFO - 2016-02-07 09:53:40 --> Language Class Initialized
INFO - 2016-02-07 09:53:40 --> Loader Class Initialized
INFO - 2016-02-07 09:53:40 --> Helper loaded: url_helper
INFO - 2016-02-07 09:53:40 --> Helper loaded: file_helper
INFO - 2016-02-07 09:53:40 --> Helper loaded: date_helper
INFO - 2016-02-07 09:53:40 --> Helper loaded: form_helper
INFO - 2016-02-07 09:53:40 --> Database Driver Class Initialized
INFO - 2016-02-07 09:53:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:53:41 --> Controller Class Initialized
INFO - 2016-02-07 09:53:41 --> Model Class Initialized
INFO - 2016-02-07 09:53:41 --> Model Class Initialized
INFO - 2016-02-07 09:53:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:53:41 --> Pagination Class Initialized
INFO - 2016-02-07 09:53:41 --> Form Validation Class Initialized
INFO - 2016-02-07 09:53:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 09:53:41 --> Model Class Initialized
INFO - 2016-02-07 09:53:41 --> Final output sent to browser
DEBUG - 2016-02-07 09:53:41 --> Total execution time: 1.2461
INFO - 2016-02-07 09:53:58 --> Config Class Initialized
INFO - 2016-02-07 09:53:58 --> Hooks Class Initialized
DEBUG - 2016-02-07 09:53:58 --> UTF-8 Support Enabled
INFO - 2016-02-07 09:53:58 --> Utf8 Class Initialized
INFO - 2016-02-07 09:53:58 --> URI Class Initialized
INFO - 2016-02-07 09:53:58 --> Router Class Initialized
INFO - 2016-02-07 09:53:58 --> Output Class Initialized
INFO - 2016-02-07 09:53:58 --> Security Class Initialized
DEBUG - 2016-02-07 09:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 09:53:58 --> Input Class Initialized
INFO - 2016-02-07 09:53:58 --> Language Class Initialized
INFO - 2016-02-07 09:53:58 --> Loader Class Initialized
INFO - 2016-02-07 09:53:58 --> Helper loaded: url_helper
INFO - 2016-02-07 09:53:58 --> Helper loaded: file_helper
INFO - 2016-02-07 09:53:58 --> Helper loaded: date_helper
INFO - 2016-02-07 09:53:58 --> Helper loaded: form_helper
INFO - 2016-02-07 09:53:58 --> Database Driver Class Initialized
INFO - 2016-02-07 09:53:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 09:53:59 --> Controller Class Initialized
INFO - 2016-02-07 09:53:59 --> Model Class Initialized
INFO - 2016-02-07 09:53:59 --> Model Class Initialized
INFO - 2016-02-07 09:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 09:53:59 --> Pagination Class Initialized
INFO - 2016-02-07 09:53:59 --> Form Validation Class Initialized
INFO - 2016-02-07 09:53:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 09:53:59 --> Model Class Initialized
INFO - 2016-02-07 09:53:59 --> Final output sent to browser
DEBUG - 2016-02-07 09:53:59 --> Total execution time: 1.2063
INFO - 2016-02-07 10:01:53 --> Config Class Initialized
INFO - 2016-02-07 10:01:53 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:01:53 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:01:53 --> Utf8 Class Initialized
INFO - 2016-02-07 10:01:53 --> URI Class Initialized
DEBUG - 2016-02-07 10:01:53 --> No URI present. Default controller set.
INFO - 2016-02-07 10:01:53 --> Router Class Initialized
INFO - 2016-02-07 10:01:53 --> Output Class Initialized
INFO - 2016-02-07 10:01:53 --> Security Class Initialized
DEBUG - 2016-02-07 10:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:01:53 --> Input Class Initialized
INFO - 2016-02-07 10:01:53 --> Language Class Initialized
ERROR - 2016-02-07 10:01:53 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 215
INFO - 2016-02-07 10:02:09 --> Config Class Initialized
INFO - 2016-02-07 10:02:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:02:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:02:09 --> Utf8 Class Initialized
INFO - 2016-02-07 10:02:09 --> URI Class Initialized
DEBUG - 2016-02-07 10:02:09 --> No URI present. Default controller set.
INFO - 2016-02-07 10:02:09 --> Router Class Initialized
INFO - 2016-02-07 10:02:09 --> Output Class Initialized
INFO - 2016-02-07 10:02:09 --> Security Class Initialized
DEBUG - 2016-02-07 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:02:09 --> Input Class Initialized
INFO - 2016-02-07 10:02:09 --> Language Class Initialized
ERROR - 2016-02-07 10:02:09 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 495
INFO - 2016-02-07 10:02:47 --> Config Class Initialized
INFO - 2016-02-07 10:02:47 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:02:47 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:02:47 --> Utf8 Class Initialized
INFO - 2016-02-07 10:02:47 --> URI Class Initialized
DEBUG - 2016-02-07 10:02:47 --> No URI present. Default controller set.
INFO - 2016-02-07 10:02:47 --> Router Class Initialized
INFO - 2016-02-07 10:02:47 --> Output Class Initialized
INFO - 2016-02-07 10:02:47 --> Security Class Initialized
DEBUG - 2016-02-07 10:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:02:47 --> Input Class Initialized
INFO - 2016-02-07 10:02:47 --> Language Class Initialized
INFO - 2016-02-07 10:02:47 --> Loader Class Initialized
INFO - 2016-02-07 10:02:47 --> Helper loaded: url_helper
INFO - 2016-02-07 10:02:47 --> Helper loaded: file_helper
INFO - 2016-02-07 10:02:47 --> Helper loaded: date_helper
INFO - 2016-02-07 10:02:47 --> Helper loaded: form_helper
INFO - 2016-02-07 10:02:47 --> Database Driver Class Initialized
INFO - 2016-02-07 10:02:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:02:48 --> Controller Class Initialized
INFO - 2016-02-07 10:02:48 --> Model Class Initialized
INFO - 2016-02-07 10:02:48 --> Model Class Initialized
INFO - 2016-02-07 10:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:02:48 --> Pagination Class Initialized
INFO - 2016-02-07 10:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:02:48 --> Final output sent to browser
DEBUG - 2016-02-07 10:02:48 --> Total execution time: 1.2125
INFO - 2016-02-07 10:02:50 --> Config Class Initialized
INFO - 2016-02-07 10:02:50 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:02:50 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:02:50 --> Utf8 Class Initialized
INFO - 2016-02-07 10:02:50 --> URI Class Initialized
DEBUG - 2016-02-07 10:02:50 --> No URI present. Default controller set.
INFO - 2016-02-07 10:02:50 --> Router Class Initialized
INFO - 2016-02-07 10:02:50 --> Output Class Initialized
INFO - 2016-02-07 10:02:50 --> Security Class Initialized
DEBUG - 2016-02-07 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:02:50 --> Input Class Initialized
INFO - 2016-02-07 10:02:50 --> Language Class Initialized
INFO - 2016-02-07 10:02:50 --> Loader Class Initialized
INFO - 2016-02-07 10:02:50 --> Helper loaded: url_helper
INFO - 2016-02-07 10:02:50 --> Helper loaded: file_helper
INFO - 2016-02-07 10:02:50 --> Helper loaded: date_helper
INFO - 2016-02-07 10:02:50 --> Helper loaded: form_helper
INFO - 2016-02-07 10:02:50 --> Database Driver Class Initialized
INFO - 2016-02-07 10:02:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:02:51 --> Controller Class Initialized
INFO - 2016-02-07 10:02:51 --> Model Class Initialized
INFO - 2016-02-07 10:02:51 --> Model Class Initialized
INFO - 2016-02-07 10:02:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:02:51 --> Pagination Class Initialized
INFO - 2016-02-07 10:02:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:02:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:02:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:02:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:02:51 --> Final output sent to browser
DEBUG - 2016-02-07 10:02:51 --> Total execution time: 1.1327
INFO - 2016-02-07 10:02:52 --> Config Class Initialized
INFO - 2016-02-07 10:02:52 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:02:52 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:02:52 --> Utf8 Class Initialized
INFO - 2016-02-07 10:02:52 --> URI Class Initialized
INFO - 2016-02-07 10:02:52 --> Router Class Initialized
INFO - 2016-02-07 10:02:52 --> Output Class Initialized
INFO - 2016-02-07 10:02:52 --> Security Class Initialized
DEBUG - 2016-02-07 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:02:52 --> Input Class Initialized
INFO - 2016-02-07 10:02:52 --> Language Class Initialized
INFO - 2016-02-07 10:02:53 --> Loader Class Initialized
INFO - 2016-02-07 10:02:53 --> Helper loaded: url_helper
INFO - 2016-02-07 10:02:53 --> Helper loaded: file_helper
INFO - 2016-02-07 10:02:53 --> Helper loaded: date_helper
INFO - 2016-02-07 10:02:53 --> Helper loaded: form_helper
INFO - 2016-02-07 10:02:53 --> Database Driver Class Initialized
INFO - 2016-02-07 10:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:02:54 --> Controller Class Initialized
INFO - 2016-02-07 10:02:54 --> Model Class Initialized
INFO - 2016-02-07 10:02:54 --> Model Class Initialized
INFO - 2016-02-07 10:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:02:54 --> Pagination Class Initialized
INFO - 2016-02-07 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:02:54 --> Helper loaded: text_helper
INFO - 2016-02-07 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:02:54 --> Final output sent to browser
DEBUG - 2016-02-07 10:02:54 --> Total execution time: 1.2172
INFO - 2016-02-07 10:03:02 --> Config Class Initialized
INFO - 2016-02-07 10:03:02 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:03:02 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:03:02 --> Utf8 Class Initialized
INFO - 2016-02-07 10:03:02 --> URI Class Initialized
INFO - 2016-02-07 10:03:02 --> Router Class Initialized
INFO - 2016-02-07 10:03:02 --> Output Class Initialized
INFO - 2016-02-07 10:03:02 --> Security Class Initialized
DEBUG - 2016-02-07 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:03:02 --> Input Class Initialized
INFO - 2016-02-07 10:03:02 --> Language Class Initialized
INFO - 2016-02-07 10:03:02 --> Loader Class Initialized
INFO - 2016-02-07 10:03:02 --> Helper loaded: url_helper
INFO - 2016-02-07 10:03:02 --> Helper loaded: file_helper
INFO - 2016-02-07 10:03:02 --> Helper loaded: date_helper
INFO - 2016-02-07 10:03:02 --> Helper loaded: form_helper
INFO - 2016-02-07 10:03:02 --> Database Driver Class Initialized
INFO - 2016-02-07 10:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:03:04 --> Controller Class Initialized
INFO - 2016-02-07 10:03:04 --> Model Class Initialized
INFO - 2016-02-07 10:03:04 --> Model Class Initialized
INFO - 2016-02-07 10:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:03:04 --> Pagination Class Initialized
INFO - 2016-02-07 10:03:04 --> Form Validation Class Initialized
INFO - 2016-02-07 10:03:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:03:04 --> Model Class Initialized
INFO - 2016-02-07 10:03:04 --> Final output sent to browser
DEBUG - 2016-02-07 10:03:04 --> Total execution time: 1.1970
INFO - 2016-02-07 10:07:36 --> Config Class Initialized
INFO - 2016-02-07 10:07:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:07:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:07:36 --> Utf8 Class Initialized
INFO - 2016-02-07 10:07:36 --> URI Class Initialized
DEBUG - 2016-02-07 10:07:36 --> No URI present. Default controller set.
INFO - 2016-02-07 10:07:36 --> Router Class Initialized
INFO - 2016-02-07 10:07:36 --> Output Class Initialized
INFO - 2016-02-07 10:07:36 --> Security Class Initialized
DEBUG - 2016-02-07 10:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:07:36 --> Input Class Initialized
INFO - 2016-02-07 10:07:36 --> Language Class Initialized
INFO - 2016-02-07 10:07:36 --> Loader Class Initialized
INFO - 2016-02-07 10:07:36 --> Helper loaded: url_helper
INFO - 2016-02-07 10:07:36 --> Helper loaded: file_helper
INFO - 2016-02-07 10:07:36 --> Helper loaded: date_helper
INFO - 2016-02-07 10:07:36 --> Helper loaded: form_helper
INFO - 2016-02-07 10:07:36 --> Database Driver Class Initialized
INFO - 2016-02-07 10:07:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:07:37 --> Controller Class Initialized
INFO - 2016-02-07 10:07:37 --> Model Class Initialized
INFO - 2016-02-07 10:07:37 --> Model Class Initialized
INFO - 2016-02-07 10:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:07:37 --> Pagination Class Initialized
INFO - 2016-02-07 10:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:07:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:07:37 --> Final output sent to browser
DEBUG - 2016-02-07 10:07:37 --> Total execution time: 1.1327
INFO - 2016-02-07 10:07:41 --> Config Class Initialized
INFO - 2016-02-07 10:07:41 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:07:41 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:07:41 --> Utf8 Class Initialized
INFO - 2016-02-07 10:07:41 --> URI Class Initialized
INFO - 2016-02-07 10:07:41 --> Router Class Initialized
INFO - 2016-02-07 10:07:41 --> Output Class Initialized
INFO - 2016-02-07 10:07:41 --> Security Class Initialized
DEBUG - 2016-02-07 10:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:07:41 --> Input Class Initialized
INFO - 2016-02-07 10:07:41 --> Language Class Initialized
INFO - 2016-02-07 10:07:41 --> Loader Class Initialized
INFO - 2016-02-07 10:07:41 --> Helper loaded: url_helper
INFO - 2016-02-07 10:07:41 --> Helper loaded: file_helper
INFO - 2016-02-07 10:07:41 --> Helper loaded: date_helper
INFO - 2016-02-07 10:07:41 --> Helper loaded: form_helper
INFO - 2016-02-07 10:07:41 --> Database Driver Class Initialized
INFO - 2016-02-07 10:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:07:42 --> Controller Class Initialized
INFO - 2016-02-07 10:07:42 --> Model Class Initialized
INFO - 2016-02-07 10:07:42 --> Model Class Initialized
INFO - 2016-02-07 10:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:07:42 --> Pagination Class Initialized
INFO - 2016-02-07 10:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:07:42 --> Helper loaded: text_helper
INFO - 2016-02-07 10:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:07:42 --> Final output sent to browser
DEBUG - 2016-02-07 10:07:42 --> Total execution time: 1.2445
INFO - 2016-02-07 10:07:47 --> Config Class Initialized
INFO - 2016-02-07 10:07:47 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:07:47 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:07:47 --> Utf8 Class Initialized
INFO - 2016-02-07 10:07:47 --> URI Class Initialized
INFO - 2016-02-07 10:07:47 --> Router Class Initialized
INFO - 2016-02-07 10:07:47 --> Output Class Initialized
INFO - 2016-02-07 10:07:47 --> Security Class Initialized
DEBUG - 2016-02-07 10:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:07:47 --> Input Class Initialized
INFO - 2016-02-07 10:07:47 --> Language Class Initialized
INFO - 2016-02-07 10:07:47 --> Loader Class Initialized
INFO - 2016-02-07 10:07:47 --> Helper loaded: url_helper
INFO - 2016-02-07 10:07:47 --> Helper loaded: file_helper
INFO - 2016-02-07 10:07:47 --> Helper loaded: date_helper
INFO - 2016-02-07 10:07:47 --> Helper loaded: form_helper
INFO - 2016-02-07 10:07:47 --> Database Driver Class Initialized
INFO - 2016-02-07 10:07:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:07:48 --> Controller Class Initialized
INFO - 2016-02-07 10:07:48 --> Model Class Initialized
INFO - 2016-02-07 10:07:48 --> Model Class Initialized
INFO - 2016-02-07 10:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:07:48 --> Pagination Class Initialized
INFO - 2016-02-07 10:07:48 --> Form Validation Class Initialized
INFO - 2016-02-07 10:07:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:07:48 --> Model Class Initialized
INFO - 2016-02-07 10:07:48 --> Final output sent to browser
DEBUG - 2016-02-07 10:07:48 --> Total execution time: 1.2103
INFO - 2016-02-07 10:08:04 --> Config Class Initialized
INFO - 2016-02-07 10:08:04 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:08:04 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:08:04 --> Utf8 Class Initialized
INFO - 2016-02-07 10:08:04 --> URI Class Initialized
INFO - 2016-02-07 10:08:04 --> Router Class Initialized
INFO - 2016-02-07 10:08:04 --> Output Class Initialized
INFO - 2016-02-07 10:08:04 --> Security Class Initialized
DEBUG - 2016-02-07 10:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:08:04 --> Input Class Initialized
INFO - 2016-02-07 10:08:04 --> Language Class Initialized
INFO - 2016-02-07 10:08:04 --> Loader Class Initialized
INFO - 2016-02-07 10:08:04 --> Helper loaded: url_helper
INFO - 2016-02-07 10:08:04 --> Helper loaded: file_helper
INFO - 2016-02-07 10:08:04 --> Helper loaded: date_helper
INFO - 2016-02-07 10:08:04 --> Helper loaded: form_helper
INFO - 2016-02-07 10:08:04 --> Database Driver Class Initialized
INFO - 2016-02-07 10:08:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:08:05 --> Controller Class Initialized
INFO - 2016-02-07 10:08:05 --> Model Class Initialized
INFO - 2016-02-07 10:08:05 --> Model Class Initialized
INFO - 2016-02-07 10:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:08:05 --> Pagination Class Initialized
INFO - 2016-02-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:08:05 --> Helper loaded: text_helper
INFO - 2016-02-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:08:05 --> Final output sent to browser
DEBUG - 2016-02-07 10:08:05 --> Total execution time: 1.2380
INFO - 2016-02-07 10:08:08 --> Config Class Initialized
INFO - 2016-02-07 10:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:08:08 --> Utf8 Class Initialized
INFO - 2016-02-07 10:08:08 --> URI Class Initialized
INFO - 2016-02-07 10:08:08 --> Router Class Initialized
INFO - 2016-02-07 10:08:08 --> Output Class Initialized
INFO - 2016-02-07 10:08:08 --> Security Class Initialized
DEBUG - 2016-02-07 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:08:08 --> Input Class Initialized
INFO - 2016-02-07 10:08:08 --> Language Class Initialized
INFO - 2016-02-07 10:08:08 --> Loader Class Initialized
INFO - 2016-02-07 10:08:08 --> Helper loaded: url_helper
INFO - 2016-02-07 10:08:08 --> Helper loaded: file_helper
INFO - 2016-02-07 10:08:08 --> Helper loaded: date_helper
INFO - 2016-02-07 10:08:08 --> Helper loaded: form_helper
INFO - 2016-02-07 10:08:08 --> Database Driver Class Initialized
INFO - 2016-02-07 10:08:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:08:09 --> Controller Class Initialized
INFO - 2016-02-07 10:08:09 --> Model Class Initialized
INFO - 2016-02-07 10:08:09 --> Model Class Initialized
INFO - 2016-02-07 10:08:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:08:09 --> Pagination Class Initialized
INFO - 2016-02-07 10:08:09 --> Form Validation Class Initialized
INFO - 2016-02-07 10:08:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:08:09 --> Model Class Initialized
INFO - 2016-02-07 10:08:09 --> Final output sent to browser
DEBUG - 2016-02-07 10:08:09 --> Total execution time: 1.1922
INFO - 2016-02-07 10:08:25 --> Config Class Initialized
INFO - 2016-02-07 10:08:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:08:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:08:25 --> Utf8 Class Initialized
INFO - 2016-02-07 10:08:25 --> URI Class Initialized
INFO - 2016-02-07 10:08:25 --> Router Class Initialized
INFO - 2016-02-07 10:08:25 --> Output Class Initialized
INFO - 2016-02-07 10:08:25 --> Security Class Initialized
DEBUG - 2016-02-07 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:08:25 --> Input Class Initialized
INFO - 2016-02-07 10:08:25 --> Language Class Initialized
INFO - 2016-02-07 10:08:25 --> Loader Class Initialized
INFO - 2016-02-07 10:08:25 --> Helper loaded: url_helper
INFO - 2016-02-07 10:08:25 --> Helper loaded: file_helper
INFO - 2016-02-07 10:08:25 --> Helper loaded: date_helper
INFO - 2016-02-07 10:08:25 --> Helper loaded: form_helper
INFO - 2016-02-07 10:08:25 --> Database Driver Class Initialized
INFO - 2016-02-07 10:08:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:08:26 --> Controller Class Initialized
INFO - 2016-02-07 10:08:26 --> Model Class Initialized
INFO - 2016-02-07 10:08:26 --> Model Class Initialized
INFO - 2016-02-07 10:08:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:08:26 --> Pagination Class Initialized
INFO - 2016-02-07 10:08:26 --> Form Validation Class Initialized
INFO - 2016-02-07 10:08:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:08:26 --> Model Class Initialized
INFO - 2016-02-07 10:08:26 --> Final output sent to browser
DEBUG - 2016-02-07 10:08:26 --> Total execution time: 1.2498
INFO - 2016-02-07 10:08:36 --> Config Class Initialized
INFO - 2016-02-07 10:08:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:08:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:08:36 --> Utf8 Class Initialized
INFO - 2016-02-07 10:08:36 --> URI Class Initialized
INFO - 2016-02-07 10:08:36 --> Router Class Initialized
INFO - 2016-02-07 10:08:36 --> Output Class Initialized
INFO - 2016-02-07 10:08:36 --> Security Class Initialized
DEBUG - 2016-02-07 10:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:08:36 --> Input Class Initialized
INFO - 2016-02-07 10:08:36 --> Language Class Initialized
INFO - 2016-02-07 10:08:36 --> Loader Class Initialized
INFO - 2016-02-07 10:08:36 --> Helper loaded: url_helper
INFO - 2016-02-07 10:08:36 --> Helper loaded: file_helper
INFO - 2016-02-07 10:08:36 --> Helper loaded: date_helper
INFO - 2016-02-07 10:08:36 --> Helper loaded: form_helper
INFO - 2016-02-07 10:08:36 --> Database Driver Class Initialized
INFO - 2016-02-07 10:08:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:08:37 --> Controller Class Initialized
INFO - 2016-02-07 10:08:37 --> Model Class Initialized
INFO - 2016-02-07 10:08:37 --> Model Class Initialized
INFO - 2016-02-07 10:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:08:37 --> Pagination Class Initialized
INFO - 2016-02-07 10:08:37 --> Form Validation Class Initialized
INFO - 2016-02-07 10:08:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:08:37 --> Model Class Initialized
INFO - 2016-02-07 10:08:37 --> Final output sent to browser
DEBUG - 2016-02-07 10:08:37 --> Total execution time: 1.1694
INFO - 2016-02-07 10:13:59 --> Config Class Initialized
INFO - 2016-02-07 10:13:59 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:13:59 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:13:59 --> Utf8 Class Initialized
INFO - 2016-02-07 10:13:59 --> URI Class Initialized
INFO - 2016-02-07 10:13:59 --> Router Class Initialized
INFO - 2016-02-07 10:13:59 --> Output Class Initialized
INFO - 2016-02-07 10:13:59 --> Security Class Initialized
DEBUG - 2016-02-07 10:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:13:59 --> Input Class Initialized
INFO - 2016-02-07 10:13:59 --> Language Class Initialized
INFO - 2016-02-07 10:13:59 --> Loader Class Initialized
INFO - 2016-02-07 10:13:59 --> Helper loaded: url_helper
INFO - 2016-02-07 10:13:59 --> Helper loaded: file_helper
INFO - 2016-02-07 10:13:59 --> Helper loaded: date_helper
INFO - 2016-02-07 10:13:59 --> Helper loaded: form_helper
INFO - 2016-02-07 10:13:59 --> Database Driver Class Initialized
INFO - 2016-02-07 10:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:14:00 --> Controller Class Initialized
INFO - 2016-02-07 10:14:00 --> Model Class Initialized
INFO - 2016-02-07 10:14:00 --> Model Class Initialized
INFO - 2016-02-07 10:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:14:00 --> Pagination Class Initialized
INFO - 2016-02-07 10:14:00 --> Form Validation Class Initialized
INFO - 2016-02-07 10:14:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:14:00 --> Model Class Initialized
INFO - 2016-02-07 10:14:00 --> Final output sent to browser
DEBUG - 2016-02-07 10:14:00 --> Total execution time: 1.2067
INFO - 2016-02-07 10:14:06 --> Config Class Initialized
INFO - 2016-02-07 10:14:06 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:14:06 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:14:06 --> Utf8 Class Initialized
INFO - 2016-02-07 10:14:06 --> URI Class Initialized
INFO - 2016-02-07 10:14:06 --> Router Class Initialized
INFO - 2016-02-07 10:14:06 --> Output Class Initialized
INFO - 2016-02-07 10:14:06 --> Security Class Initialized
DEBUG - 2016-02-07 10:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:14:06 --> Input Class Initialized
INFO - 2016-02-07 10:14:06 --> Language Class Initialized
INFO - 2016-02-07 10:14:06 --> Loader Class Initialized
INFO - 2016-02-07 10:14:06 --> Helper loaded: url_helper
INFO - 2016-02-07 10:14:06 --> Helper loaded: file_helper
INFO - 2016-02-07 10:14:06 --> Helper loaded: date_helper
INFO - 2016-02-07 10:14:06 --> Helper loaded: form_helper
INFO - 2016-02-07 10:14:06 --> Database Driver Class Initialized
INFO - 2016-02-07 10:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:14:07 --> Controller Class Initialized
INFO - 2016-02-07 10:14:07 --> Model Class Initialized
INFO - 2016-02-07 10:14:07 --> Model Class Initialized
INFO - 2016-02-07 10:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:14:07 --> Pagination Class Initialized
INFO - 2016-02-07 10:14:07 --> Form Validation Class Initialized
INFO - 2016-02-07 10:14:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:14:07 --> Model Class Initialized
INFO - 2016-02-07 10:14:07 --> Final output sent to browser
DEBUG - 2016-02-07 10:14:07 --> Total execution time: 1.2718
INFO - 2016-02-07 10:20:06 --> Config Class Initialized
INFO - 2016-02-07 10:20:06 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:20:06 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:20:06 --> Utf8 Class Initialized
INFO - 2016-02-07 10:20:06 --> URI Class Initialized
DEBUG - 2016-02-07 10:20:06 --> No URI present. Default controller set.
INFO - 2016-02-07 10:20:06 --> Router Class Initialized
INFO - 2016-02-07 10:20:06 --> Output Class Initialized
INFO - 2016-02-07 10:20:06 --> Security Class Initialized
DEBUG - 2016-02-07 10:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:20:06 --> Input Class Initialized
INFO - 2016-02-07 10:20:06 --> Language Class Initialized
INFO - 2016-02-07 10:20:06 --> Loader Class Initialized
INFO - 2016-02-07 10:20:06 --> Helper loaded: url_helper
INFO - 2016-02-07 10:20:06 --> Helper loaded: file_helper
INFO - 2016-02-07 10:20:06 --> Helper loaded: date_helper
INFO - 2016-02-07 10:20:06 --> Helper loaded: form_helper
INFO - 2016-02-07 10:20:06 --> Database Driver Class Initialized
INFO - 2016-02-07 10:20:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:20:07 --> Controller Class Initialized
INFO - 2016-02-07 10:20:07 --> Model Class Initialized
INFO - 2016-02-07 10:20:07 --> Model Class Initialized
INFO - 2016-02-07 10:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:20:07 --> Pagination Class Initialized
INFO - 2016-02-07 10:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:20:07 --> Final output sent to browser
DEBUG - 2016-02-07 10:20:07 --> Total execution time: 1.1643
INFO - 2016-02-07 10:20:10 --> Config Class Initialized
INFO - 2016-02-07 10:20:10 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:20:10 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:20:10 --> Utf8 Class Initialized
INFO - 2016-02-07 10:20:10 --> URI Class Initialized
INFO - 2016-02-07 10:20:10 --> Router Class Initialized
INFO - 2016-02-07 10:20:10 --> Output Class Initialized
INFO - 2016-02-07 10:20:10 --> Security Class Initialized
DEBUG - 2016-02-07 10:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:20:10 --> Input Class Initialized
INFO - 2016-02-07 10:20:10 --> Language Class Initialized
INFO - 2016-02-07 10:20:10 --> Loader Class Initialized
INFO - 2016-02-07 10:20:10 --> Helper loaded: url_helper
INFO - 2016-02-07 10:20:10 --> Helper loaded: file_helper
INFO - 2016-02-07 10:20:10 --> Helper loaded: date_helper
INFO - 2016-02-07 10:20:10 --> Helper loaded: form_helper
INFO - 2016-02-07 10:20:10 --> Database Driver Class Initialized
INFO - 2016-02-07 10:20:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:20:11 --> Controller Class Initialized
INFO - 2016-02-07 10:20:11 --> Model Class Initialized
INFO - 2016-02-07 10:20:11 --> Model Class Initialized
INFO - 2016-02-07 10:20:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:20:11 --> Pagination Class Initialized
INFO - 2016-02-07 10:20:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:20:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:20:11 --> Helper loaded: text_helper
INFO - 2016-02-07 10:20:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:20:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:20:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:20:11 --> Final output sent to browser
DEBUG - 2016-02-07 10:20:11 --> Total execution time: 1.1892
INFO - 2016-02-07 10:20:21 --> Config Class Initialized
INFO - 2016-02-07 10:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:20:21 --> Utf8 Class Initialized
INFO - 2016-02-07 10:20:21 --> URI Class Initialized
INFO - 2016-02-07 10:20:21 --> Router Class Initialized
INFO - 2016-02-07 10:20:21 --> Output Class Initialized
INFO - 2016-02-07 10:20:21 --> Security Class Initialized
DEBUG - 2016-02-07 10:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:20:21 --> Input Class Initialized
INFO - 2016-02-07 10:20:21 --> Language Class Initialized
INFO - 2016-02-07 10:20:21 --> Loader Class Initialized
INFO - 2016-02-07 10:20:21 --> Helper loaded: url_helper
INFO - 2016-02-07 10:20:21 --> Helper loaded: file_helper
INFO - 2016-02-07 10:20:21 --> Helper loaded: date_helper
INFO - 2016-02-07 10:20:21 --> Helper loaded: form_helper
INFO - 2016-02-07 10:20:21 --> Database Driver Class Initialized
INFO - 2016-02-07 10:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:20:22 --> Controller Class Initialized
INFO - 2016-02-07 10:20:22 --> Model Class Initialized
INFO - 2016-02-07 10:20:22 --> Model Class Initialized
INFO - 2016-02-07 10:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:20:22 --> Pagination Class Initialized
INFO - 2016-02-07 10:20:22 --> Form Validation Class Initialized
INFO - 2016-02-07 10:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:20:22 --> Model Class Initialized
INFO - 2016-02-07 10:20:22 --> Final output sent to browser
DEBUG - 2016-02-07 10:20:22 --> Total execution time: 1.1915
INFO - 2016-02-07 10:21:58 --> Config Class Initialized
INFO - 2016-02-07 10:21:58 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:21:58 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:21:58 --> Utf8 Class Initialized
INFO - 2016-02-07 10:21:58 --> URI Class Initialized
DEBUG - 2016-02-07 10:21:58 --> No URI present. Default controller set.
INFO - 2016-02-07 10:21:58 --> Router Class Initialized
INFO - 2016-02-07 10:21:58 --> Output Class Initialized
INFO - 2016-02-07 10:21:58 --> Security Class Initialized
DEBUG - 2016-02-07 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:21:58 --> Input Class Initialized
INFO - 2016-02-07 10:21:58 --> Language Class Initialized
INFO - 2016-02-07 10:21:58 --> Loader Class Initialized
INFO - 2016-02-07 10:21:58 --> Helper loaded: url_helper
INFO - 2016-02-07 10:21:58 --> Helper loaded: file_helper
INFO - 2016-02-07 10:21:58 --> Helper loaded: date_helper
INFO - 2016-02-07 10:21:58 --> Helper loaded: form_helper
INFO - 2016-02-07 10:21:58 --> Database Driver Class Initialized
INFO - 2016-02-07 10:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:21:59 --> Controller Class Initialized
INFO - 2016-02-07 10:21:59 --> Model Class Initialized
INFO - 2016-02-07 10:21:59 --> Model Class Initialized
INFO - 2016-02-07 10:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:21:59 --> Pagination Class Initialized
INFO - 2016-02-07 10:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:22:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:22:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:22:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:22:00 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:00 --> Total execution time: 1.1746
INFO - 2016-02-07 10:22:01 --> Config Class Initialized
INFO - 2016-02-07 10:22:01 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:22:01 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:22:01 --> Utf8 Class Initialized
INFO - 2016-02-07 10:22:01 --> URI Class Initialized
INFO - 2016-02-07 10:22:01 --> Router Class Initialized
INFO - 2016-02-07 10:22:01 --> Output Class Initialized
INFO - 2016-02-07 10:22:01 --> Security Class Initialized
DEBUG - 2016-02-07 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:22:01 --> Input Class Initialized
INFO - 2016-02-07 10:22:01 --> Language Class Initialized
INFO - 2016-02-07 10:22:01 --> Loader Class Initialized
INFO - 2016-02-07 10:22:01 --> Helper loaded: url_helper
INFO - 2016-02-07 10:22:01 --> Helper loaded: file_helper
INFO - 2016-02-07 10:22:01 --> Helper loaded: date_helper
INFO - 2016-02-07 10:22:01 --> Helper loaded: form_helper
INFO - 2016-02-07 10:22:01 --> Database Driver Class Initialized
INFO - 2016-02-07 10:22:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:22:02 --> Controller Class Initialized
INFO - 2016-02-07 10:22:02 --> Model Class Initialized
INFO - 2016-02-07 10:22:02 --> Model Class Initialized
INFO - 2016-02-07 10:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:22:02 --> Pagination Class Initialized
INFO - 2016-02-07 10:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:22:02 --> Helper loaded: text_helper
INFO - 2016-02-07 10:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:22:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:22:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:22:03 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:03 --> Total execution time: 1.2493
INFO - 2016-02-07 10:22:08 --> Config Class Initialized
INFO - 2016-02-07 10:22:08 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:22:08 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:22:08 --> Utf8 Class Initialized
INFO - 2016-02-07 10:22:08 --> URI Class Initialized
INFO - 2016-02-07 10:22:08 --> Router Class Initialized
INFO - 2016-02-07 10:22:08 --> Output Class Initialized
INFO - 2016-02-07 10:22:08 --> Security Class Initialized
DEBUG - 2016-02-07 10:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:22:08 --> Input Class Initialized
INFO - 2016-02-07 10:22:08 --> Language Class Initialized
INFO - 2016-02-07 10:22:08 --> Loader Class Initialized
INFO - 2016-02-07 10:22:08 --> Helper loaded: url_helper
INFO - 2016-02-07 10:22:08 --> Helper loaded: file_helper
INFO - 2016-02-07 10:22:08 --> Helper loaded: date_helper
INFO - 2016-02-07 10:22:08 --> Helper loaded: form_helper
INFO - 2016-02-07 10:22:08 --> Database Driver Class Initialized
INFO - 2016-02-07 10:22:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:22:09 --> Controller Class Initialized
INFO - 2016-02-07 10:22:09 --> Model Class Initialized
INFO - 2016-02-07 10:22:09 --> Model Class Initialized
INFO - 2016-02-07 10:22:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:22:09 --> Pagination Class Initialized
INFO - 2016-02-07 10:22:09 --> Form Validation Class Initialized
INFO - 2016-02-07 10:22:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:22:09 --> Model Class Initialized
INFO - 2016-02-07 10:22:09 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:09 --> Total execution time: 1.1832
INFO - 2016-02-07 10:22:45 --> Config Class Initialized
INFO - 2016-02-07 10:22:45 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:22:45 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:22:45 --> Utf8 Class Initialized
INFO - 2016-02-07 10:22:45 --> URI Class Initialized
DEBUG - 2016-02-07 10:22:45 --> No URI present. Default controller set.
INFO - 2016-02-07 10:22:45 --> Router Class Initialized
INFO - 2016-02-07 10:22:45 --> Output Class Initialized
INFO - 2016-02-07 10:22:45 --> Security Class Initialized
DEBUG - 2016-02-07 10:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:22:45 --> Input Class Initialized
INFO - 2016-02-07 10:22:45 --> Language Class Initialized
INFO - 2016-02-07 10:22:45 --> Loader Class Initialized
INFO - 2016-02-07 10:22:45 --> Helper loaded: url_helper
INFO - 2016-02-07 10:22:45 --> Helper loaded: file_helper
INFO - 2016-02-07 10:22:45 --> Helper loaded: date_helper
INFO - 2016-02-07 10:22:45 --> Helper loaded: form_helper
INFO - 2016-02-07 10:22:45 --> Database Driver Class Initialized
INFO - 2016-02-07 10:22:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:22:46 --> Controller Class Initialized
INFO - 2016-02-07 10:22:46 --> Model Class Initialized
INFO - 2016-02-07 10:22:46 --> Model Class Initialized
INFO - 2016-02-07 10:22:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:22:46 --> Pagination Class Initialized
INFO - 2016-02-07 10:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:22:46 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:46 --> Total execution time: 1.1114
INFO - 2016-02-07 10:22:48 --> Config Class Initialized
INFO - 2016-02-07 10:22:48 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:22:48 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:22:48 --> Utf8 Class Initialized
INFO - 2016-02-07 10:22:48 --> URI Class Initialized
INFO - 2016-02-07 10:22:48 --> Router Class Initialized
INFO - 2016-02-07 10:22:48 --> Output Class Initialized
INFO - 2016-02-07 10:22:48 --> Security Class Initialized
DEBUG - 2016-02-07 10:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:22:48 --> Input Class Initialized
INFO - 2016-02-07 10:22:48 --> Language Class Initialized
INFO - 2016-02-07 10:22:48 --> Loader Class Initialized
INFO - 2016-02-07 10:22:48 --> Helper loaded: url_helper
INFO - 2016-02-07 10:22:48 --> Helper loaded: file_helper
INFO - 2016-02-07 10:22:48 --> Helper loaded: date_helper
INFO - 2016-02-07 10:22:48 --> Helper loaded: form_helper
INFO - 2016-02-07 10:22:48 --> Database Driver Class Initialized
INFO - 2016-02-07 10:22:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:22:50 --> Controller Class Initialized
INFO - 2016-02-07 10:22:50 --> Model Class Initialized
INFO - 2016-02-07 10:22:50 --> Model Class Initialized
INFO - 2016-02-07 10:22:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:22:50 --> Pagination Class Initialized
INFO - 2016-02-07 10:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:22:50 --> Helper loaded: text_helper
INFO - 2016-02-07 10:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:22:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:22:50 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:50 --> Total execution time: 1.3774
INFO - 2016-02-07 10:22:54 --> Config Class Initialized
INFO - 2016-02-07 10:22:54 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:22:54 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:22:54 --> Utf8 Class Initialized
INFO - 2016-02-07 10:22:54 --> URI Class Initialized
INFO - 2016-02-07 10:22:54 --> Router Class Initialized
INFO - 2016-02-07 10:22:54 --> Output Class Initialized
INFO - 2016-02-07 10:22:54 --> Security Class Initialized
DEBUG - 2016-02-07 10:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:22:54 --> Input Class Initialized
INFO - 2016-02-07 10:22:54 --> Language Class Initialized
INFO - 2016-02-07 10:22:54 --> Loader Class Initialized
INFO - 2016-02-07 10:22:54 --> Helper loaded: url_helper
INFO - 2016-02-07 10:22:54 --> Helper loaded: file_helper
INFO - 2016-02-07 10:22:54 --> Helper loaded: date_helper
INFO - 2016-02-07 10:22:54 --> Helper loaded: form_helper
INFO - 2016-02-07 10:22:54 --> Database Driver Class Initialized
INFO - 2016-02-07 10:22:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:22:55 --> Controller Class Initialized
INFO - 2016-02-07 10:22:55 --> Model Class Initialized
INFO - 2016-02-07 10:22:55 --> Model Class Initialized
INFO - 2016-02-07 10:22:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:22:55 --> Pagination Class Initialized
INFO - 2016-02-07 10:22:55 --> Form Validation Class Initialized
INFO - 2016-02-07 10:22:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:22:55 --> Model Class Initialized
INFO - 2016-02-07 10:22:55 --> Final output sent to browser
DEBUG - 2016-02-07 10:22:55 --> Total execution time: 1.2406
INFO - 2016-02-07 10:24:07 --> Config Class Initialized
INFO - 2016-02-07 10:24:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:24:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:24:07 --> Utf8 Class Initialized
INFO - 2016-02-07 10:24:07 --> URI Class Initialized
DEBUG - 2016-02-07 10:24:07 --> No URI present. Default controller set.
INFO - 2016-02-07 10:24:07 --> Router Class Initialized
INFO - 2016-02-07 10:24:07 --> Output Class Initialized
INFO - 2016-02-07 10:24:07 --> Security Class Initialized
DEBUG - 2016-02-07 10:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:24:07 --> Input Class Initialized
INFO - 2016-02-07 10:24:07 --> Language Class Initialized
INFO - 2016-02-07 10:24:07 --> Loader Class Initialized
INFO - 2016-02-07 10:24:07 --> Helper loaded: url_helper
INFO - 2016-02-07 10:24:07 --> Helper loaded: file_helper
INFO - 2016-02-07 10:24:07 --> Helper loaded: date_helper
INFO - 2016-02-07 10:24:07 --> Helper loaded: form_helper
INFO - 2016-02-07 10:24:07 --> Database Driver Class Initialized
INFO - 2016-02-07 10:24:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:24:08 --> Controller Class Initialized
INFO - 2016-02-07 10:24:08 --> Model Class Initialized
INFO - 2016-02-07 10:24:08 --> Model Class Initialized
INFO - 2016-02-07 10:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:24:08 --> Pagination Class Initialized
INFO - 2016-02-07 10:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:24:08 --> Final output sent to browser
DEBUG - 2016-02-07 10:24:08 --> Total execution time: 1.1655
INFO - 2016-02-07 10:24:12 --> Config Class Initialized
INFO - 2016-02-07 10:24:12 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:24:12 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:24:12 --> Utf8 Class Initialized
INFO - 2016-02-07 10:24:12 --> URI Class Initialized
INFO - 2016-02-07 10:24:12 --> Router Class Initialized
INFO - 2016-02-07 10:24:12 --> Output Class Initialized
INFO - 2016-02-07 10:24:12 --> Security Class Initialized
DEBUG - 2016-02-07 10:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:24:12 --> Input Class Initialized
INFO - 2016-02-07 10:24:12 --> Language Class Initialized
INFO - 2016-02-07 10:24:12 --> Loader Class Initialized
INFO - 2016-02-07 10:24:12 --> Helper loaded: url_helper
INFO - 2016-02-07 10:24:12 --> Helper loaded: file_helper
INFO - 2016-02-07 10:24:12 --> Helper loaded: date_helper
INFO - 2016-02-07 10:24:12 --> Helper loaded: form_helper
INFO - 2016-02-07 10:24:12 --> Database Driver Class Initialized
INFO - 2016-02-07 10:24:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:24:13 --> Controller Class Initialized
INFO - 2016-02-07 10:24:13 --> Model Class Initialized
INFO - 2016-02-07 10:24:13 --> Model Class Initialized
INFO - 2016-02-07 10:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:24:13 --> Pagination Class Initialized
INFO - 2016-02-07 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:24:13 --> Helper loaded: text_helper
INFO - 2016-02-07 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:24:13 --> Final output sent to browser
DEBUG - 2016-02-07 10:24:13 --> Total execution time: 1.1764
INFO - 2016-02-07 10:24:19 --> Config Class Initialized
INFO - 2016-02-07 10:24:19 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:24:19 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:24:19 --> Utf8 Class Initialized
INFO - 2016-02-07 10:24:19 --> URI Class Initialized
INFO - 2016-02-07 10:24:19 --> Router Class Initialized
INFO - 2016-02-07 10:24:19 --> Output Class Initialized
INFO - 2016-02-07 10:24:19 --> Security Class Initialized
DEBUG - 2016-02-07 10:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:24:19 --> Input Class Initialized
INFO - 2016-02-07 10:24:19 --> Language Class Initialized
INFO - 2016-02-07 10:24:19 --> Loader Class Initialized
INFO - 2016-02-07 10:24:19 --> Helper loaded: url_helper
INFO - 2016-02-07 10:24:19 --> Helper loaded: file_helper
INFO - 2016-02-07 10:24:19 --> Helper loaded: date_helper
INFO - 2016-02-07 10:24:19 --> Helper loaded: form_helper
INFO - 2016-02-07 10:24:19 --> Database Driver Class Initialized
INFO - 2016-02-07 10:24:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:24:20 --> Controller Class Initialized
INFO - 2016-02-07 10:24:20 --> Model Class Initialized
INFO - 2016-02-07 10:24:20 --> Model Class Initialized
INFO - 2016-02-07 10:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:24:20 --> Pagination Class Initialized
INFO - 2016-02-07 10:24:20 --> Form Validation Class Initialized
INFO - 2016-02-07 10:24:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:24:20 --> Model Class Initialized
INFO - 2016-02-07 10:24:20 --> Final output sent to browser
DEBUG - 2016-02-07 10:24:20 --> Total execution time: 1.2471
INFO - 2016-02-07 10:24:48 --> Config Class Initialized
INFO - 2016-02-07 10:24:48 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:24:48 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:24:48 --> Utf8 Class Initialized
INFO - 2016-02-07 10:24:48 --> URI Class Initialized
INFO - 2016-02-07 10:24:48 --> Router Class Initialized
INFO - 2016-02-07 10:24:48 --> Output Class Initialized
INFO - 2016-02-07 10:24:48 --> Security Class Initialized
DEBUG - 2016-02-07 10:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:24:48 --> Input Class Initialized
INFO - 2016-02-07 10:24:48 --> Language Class Initialized
INFO - 2016-02-07 10:24:48 --> Loader Class Initialized
INFO - 2016-02-07 10:24:48 --> Helper loaded: url_helper
INFO - 2016-02-07 10:24:48 --> Helper loaded: file_helper
INFO - 2016-02-07 10:24:48 --> Helper loaded: date_helper
INFO - 2016-02-07 10:24:48 --> Helper loaded: form_helper
INFO - 2016-02-07 10:24:48 --> Database Driver Class Initialized
INFO - 2016-02-07 10:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:24:49 --> Controller Class Initialized
INFO - 2016-02-07 10:24:49 --> Model Class Initialized
INFO - 2016-02-07 10:24:49 --> Model Class Initialized
INFO - 2016-02-07 10:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:24:49 --> Pagination Class Initialized
INFO - 2016-02-07 10:24:49 --> Form Validation Class Initialized
INFO - 2016-02-07 10:24:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:24:49 --> Model Class Initialized
INFO - 2016-02-07 10:24:49 --> Final output sent to browser
DEBUG - 2016-02-07 10:24:49 --> Total execution time: 1.2122
INFO - 2016-02-07 10:30:31 --> Config Class Initialized
INFO - 2016-02-07 10:30:31 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:30:31 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:30:31 --> Utf8 Class Initialized
INFO - 2016-02-07 10:30:31 --> URI Class Initialized
DEBUG - 2016-02-07 10:30:31 --> No URI present. Default controller set.
INFO - 2016-02-07 10:30:31 --> Router Class Initialized
INFO - 2016-02-07 10:30:31 --> Output Class Initialized
INFO - 2016-02-07 10:30:31 --> Security Class Initialized
DEBUG - 2016-02-07 10:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:30:31 --> Input Class Initialized
INFO - 2016-02-07 10:30:31 --> Language Class Initialized
INFO - 2016-02-07 10:30:31 --> Loader Class Initialized
INFO - 2016-02-07 10:30:31 --> Helper loaded: url_helper
INFO - 2016-02-07 10:30:31 --> Helper loaded: file_helper
INFO - 2016-02-07 10:30:31 --> Helper loaded: date_helper
INFO - 2016-02-07 10:30:31 --> Helper loaded: form_helper
INFO - 2016-02-07 10:30:31 --> Database Driver Class Initialized
INFO - 2016-02-07 10:30:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:30:33 --> Controller Class Initialized
INFO - 2016-02-07 10:30:33 --> Model Class Initialized
INFO - 2016-02-07 10:30:33 --> Model Class Initialized
INFO - 2016-02-07 10:30:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:30:33 --> Pagination Class Initialized
INFO - 2016-02-07 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:30:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:30:33 --> Final output sent to browser
DEBUG - 2016-02-07 10:30:33 --> Total execution time: 1.1347
INFO - 2016-02-07 10:30:35 --> Config Class Initialized
INFO - 2016-02-07 10:30:35 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:30:35 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:30:35 --> Utf8 Class Initialized
INFO - 2016-02-07 10:30:35 --> URI Class Initialized
INFO - 2016-02-07 10:30:35 --> Router Class Initialized
INFO - 2016-02-07 10:30:35 --> Output Class Initialized
INFO - 2016-02-07 10:30:35 --> Security Class Initialized
DEBUG - 2016-02-07 10:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:30:35 --> Input Class Initialized
INFO - 2016-02-07 10:30:35 --> Language Class Initialized
INFO - 2016-02-07 10:30:35 --> Loader Class Initialized
INFO - 2016-02-07 10:30:35 --> Helper loaded: url_helper
INFO - 2016-02-07 10:30:35 --> Helper loaded: file_helper
INFO - 2016-02-07 10:30:35 --> Helper loaded: date_helper
INFO - 2016-02-07 10:30:35 --> Helper loaded: form_helper
INFO - 2016-02-07 10:30:35 --> Database Driver Class Initialized
INFO - 2016-02-07 10:30:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:30:36 --> Controller Class Initialized
INFO - 2016-02-07 10:30:36 --> Model Class Initialized
INFO - 2016-02-07 10:30:36 --> Model Class Initialized
INFO - 2016-02-07 10:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:30:36 --> Pagination Class Initialized
INFO - 2016-02-07 10:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:30:36 --> Helper loaded: text_helper
INFO - 2016-02-07 10:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:30:36 --> Final output sent to browser
DEBUG - 2016-02-07 10:30:36 --> Total execution time: 1.1841
INFO - 2016-02-07 10:30:40 --> Config Class Initialized
INFO - 2016-02-07 10:30:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:30:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:30:40 --> Utf8 Class Initialized
INFO - 2016-02-07 10:30:40 --> URI Class Initialized
INFO - 2016-02-07 10:30:40 --> Router Class Initialized
INFO - 2016-02-07 10:30:40 --> Output Class Initialized
INFO - 2016-02-07 10:30:40 --> Security Class Initialized
DEBUG - 2016-02-07 10:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:30:40 --> Input Class Initialized
INFO - 2016-02-07 10:30:40 --> Language Class Initialized
INFO - 2016-02-07 10:30:40 --> Loader Class Initialized
INFO - 2016-02-07 10:30:40 --> Helper loaded: url_helper
INFO - 2016-02-07 10:30:40 --> Helper loaded: file_helper
INFO - 2016-02-07 10:30:40 --> Helper loaded: date_helper
INFO - 2016-02-07 10:30:40 --> Helper loaded: form_helper
INFO - 2016-02-07 10:30:40 --> Database Driver Class Initialized
INFO - 2016-02-07 10:30:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:30:41 --> Controller Class Initialized
INFO - 2016-02-07 10:30:41 --> Model Class Initialized
INFO - 2016-02-07 10:30:41 --> Model Class Initialized
INFO - 2016-02-07 10:30:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:30:41 --> Pagination Class Initialized
INFO - 2016-02-07 10:30:41 --> Form Validation Class Initialized
INFO - 2016-02-07 10:30:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:30:41 --> Model Class Initialized
INFO - 2016-02-07 10:30:41 --> Final output sent to browser
DEBUG - 2016-02-07 10:30:41 --> Total execution time: 1.1597
INFO - 2016-02-07 10:32:34 --> Config Class Initialized
INFO - 2016-02-07 10:32:34 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:32:34 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:32:34 --> Utf8 Class Initialized
INFO - 2016-02-07 10:32:34 --> URI Class Initialized
DEBUG - 2016-02-07 10:32:34 --> No URI present. Default controller set.
INFO - 2016-02-07 10:32:34 --> Router Class Initialized
INFO - 2016-02-07 10:32:34 --> Output Class Initialized
INFO - 2016-02-07 10:32:34 --> Security Class Initialized
DEBUG - 2016-02-07 10:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:32:34 --> Input Class Initialized
INFO - 2016-02-07 10:32:34 --> Language Class Initialized
INFO - 2016-02-07 10:32:34 --> Loader Class Initialized
INFO - 2016-02-07 10:32:34 --> Helper loaded: url_helper
INFO - 2016-02-07 10:32:34 --> Helper loaded: file_helper
INFO - 2016-02-07 10:32:34 --> Helper loaded: date_helper
INFO - 2016-02-07 10:32:34 --> Helper loaded: form_helper
INFO - 2016-02-07 10:32:34 --> Database Driver Class Initialized
INFO - 2016-02-07 10:32:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:32:35 --> Controller Class Initialized
INFO - 2016-02-07 10:32:35 --> Model Class Initialized
INFO - 2016-02-07 10:32:35 --> Model Class Initialized
INFO - 2016-02-07 10:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:32:35 --> Pagination Class Initialized
INFO - 2016-02-07 10:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:32:35 --> Final output sent to browser
DEBUG - 2016-02-07 10:32:35 --> Total execution time: 1.1532
INFO - 2016-02-07 10:32:38 --> Config Class Initialized
INFO - 2016-02-07 10:32:38 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:32:38 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:32:38 --> Utf8 Class Initialized
INFO - 2016-02-07 10:32:38 --> URI Class Initialized
INFO - 2016-02-07 10:32:38 --> Router Class Initialized
INFO - 2016-02-07 10:32:38 --> Output Class Initialized
INFO - 2016-02-07 10:32:38 --> Security Class Initialized
DEBUG - 2016-02-07 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:32:38 --> Input Class Initialized
INFO - 2016-02-07 10:32:38 --> Language Class Initialized
INFO - 2016-02-07 10:32:38 --> Loader Class Initialized
INFO - 2016-02-07 10:32:38 --> Helper loaded: url_helper
INFO - 2016-02-07 10:32:38 --> Helper loaded: file_helper
INFO - 2016-02-07 10:32:38 --> Helper loaded: date_helper
INFO - 2016-02-07 10:32:38 --> Helper loaded: form_helper
INFO - 2016-02-07 10:32:38 --> Database Driver Class Initialized
INFO - 2016-02-07 10:32:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:32:39 --> Controller Class Initialized
INFO - 2016-02-07 10:32:39 --> Model Class Initialized
INFO - 2016-02-07 10:32:39 --> Model Class Initialized
INFO - 2016-02-07 10:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:32:39 --> Pagination Class Initialized
INFO - 2016-02-07 10:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:32:39 --> Helper loaded: text_helper
INFO - 2016-02-07 10:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:32:39 --> Final output sent to browser
DEBUG - 2016-02-07 10:32:39 --> Total execution time: 1.1617
INFO - 2016-02-07 10:32:43 --> Config Class Initialized
INFO - 2016-02-07 10:32:43 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:32:43 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:32:43 --> Utf8 Class Initialized
INFO - 2016-02-07 10:32:43 --> URI Class Initialized
INFO - 2016-02-07 10:32:43 --> Router Class Initialized
INFO - 2016-02-07 10:32:43 --> Output Class Initialized
INFO - 2016-02-07 10:32:43 --> Security Class Initialized
DEBUG - 2016-02-07 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:32:43 --> Input Class Initialized
INFO - 2016-02-07 10:32:43 --> Language Class Initialized
INFO - 2016-02-07 10:32:43 --> Loader Class Initialized
INFO - 2016-02-07 10:32:43 --> Helper loaded: url_helper
INFO - 2016-02-07 10:32:43 --> Helper loaded: file_helper
INFO - 2016-02-07 10:32:43 --> Helper loaded: date_helper
INFO - 2016-02-07 10:32:43 --> Helper loaded: form_helper
INFO - 2016-02-07 10:32:43 --> Database Driver Class Initialized
INFO - 2016-02-07 10:32:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:32:44 --> Controller Class Initialized
INFO - 2016-02-07 10:32:44 --> Model Class Initialized
INFO - 2016-02-07 10:32:44 --> Model Class Initialized
INFO - 2016-02-07 10:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:32:44 --> Pagination Class Initialized
INFO - 2016-02-07 10:32:44 --> Form Validation Class Initialized
INFO - 2016-02-07 10:32:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:32:44 --> Model Class Initialized
INFO - 2016-02-07 10:32:44 --> Final output sent to browser
DEBUG - 2016-02-07 10:32:44 --> Total execution time: 1.3504
INFO - 2016-02-07 10:34:12 --> Config Class Initialized
INFO - 2016-02-07 10:34:12 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:34:12 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:34:12 --> Utf8 Class Initialized
INFO - 2016-02-07 10:34:12 --> URI Class Initialized
DEBUG - 2016-02-07 10:34:12 --> No URI present. Default controller set.
INFO - 2016-02-07 10:34:12 --> Router Class Initialized
INFO - 2016-02-07 10:34:12 --> Output Class Initialized
INFO - 2016-02-07 10:34:12 --> Security Class Initialized
DEBUG - 2016-02-07 10:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:34:12 --> Input Class Initialized
INFO - 2016-02-07 10:34:12 --> Language Class Initialized
INFO - 2016-02-07 10:34:12 --> Loader Class Initialized
INFO - 2016-02-07 10:34:12 --> Helper loaded: url_helper
INFO - 2016-02-07 10:34:12 --> Helper loaded: file_helper
INFO - 2016-02-07 10:34:12 --> Helper loaded: date_helper
INFO - 2016-02-07 10:34:12 --> Helper loaded: form_helper
INFO - 2016-02-07 10:34:12 --> Database Driver Class Initialized
INFO - 2016-02-07 10:34:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:34:13 --> Controller Class Initialized
INFO - 2016-02-07 10:34:13 --> Model Class Initialized
INFO - 2016-02-07 10:34:13 --> Model Class Initialized
INFO - 2016-02-07 10:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:34:13 --> Pagination Class Initialized
INFO - 2016-02-07 10:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:34:13 --> Final output sent to browser
DEBUG - 2016-02-07 10:34:13 --> Total execution time: 1.1589
INFO - 2016-02-07 10:34:18 --> Config Class Initialized
INFO - 2016-02-07 10:34:18 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:34:18 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:34:18 --> Utf8 Class Initialized
INFO - 2016-02-07 10:34:18 --> URI Class Initialized
INFO - 2016-02-07 10:34:18 --> Router Class Initialized
INFO - 2016-02-07 10:34:18 --> Output Class Initialized
INFO - 2016-02-07 10:34:18 --> Security Class Initialized
DEBUG - 2016-02-07 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:34:18 --> Input Class Initialized
INFO - 2016-02-07 10:34:18 --> Language Class Initialized
INFO - 2016-02-07 10:34:18 --> Loader Class Initialized
INFO - 2016-02-07 10:34:18 --> Helper loaded: url_helper
INFO - 2016-02-07 10:34:18 --> Helper loaded: file_helper
INFO - 2016-02-07 10:34:18 --> Helper loaded: date_helper
INFO - 2016-02-07 10:34:18 --> Helper loaded: form_helper
INFO - 2016-02-07 10:34:18 --> Database Driver Class Initialized
INFO - 2016-02-07 10:34:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:34:19 --> Controller Class Initialized
INFO - 2016-02-07 10:34:19 --> Model Class Initialized
INFO - 2016-02-07 10:34:19 --> Model Class Initialized
INFO - 2016-02-07 10:34:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:34:19 --> Pagination Class Initialized
INFO - 2016-02-07 10:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:34:19 --> Helper loaded: text_helper
INFO - 2016-02-07 10:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:34:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:34:19 --> Final output sent to browser
DEBUG - 2016-02-07 10:34:19 --> Total execution time: 1.2108
INFO - 2016-02-07 10:34:25 --> Config Class Initialized
INFO - 2016-02-07 10:34:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:34:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:34:25 --> Utf8 Class Initialized
INFO - 2016-02-07 10:34:25 --> URI Class Initialized
INFO - 2016-02-07 10:34:25 --> Router Class Initialized
INFO - 2016-02-07 10:34:25 --> Output Class Initialized
INFO - 2016-02-07 10:34:25 --> Security Class Initialized
DEBUG - 2016-02-07 10:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:34:25 --> Input Class Initialized
INFO - 2016-02-07 10:34:25 --> Language Class Initialized
INFO - 2016-02-07 10:34:25 --> Loader Class Initialized
INFO - 2016-02-07 10:34:25 --> Helper loaded: url_helper
INFO - 2016-02-07 10:34:25 --> Helper loaded: file_helper
INFO - 2016-02-07 10:34:25 --> Helper loaded: date_helper
INFO - 2016-02-07 10:34:25 --> Helper loaded: form_helper
INFO - 2016-02-07 10:34:25 --> Database Driver Class Initialized
INFO - 2016-02-07 10:34:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:34:26 --> Controller Class Initialized
INFO - 2016-02-07 10:34:26 --> Model Class Initialized
INFO - 2016-02-07 10:34:26 --> Model Class Initialized
INFO - 2016-02-07 10:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:34:26 --> Pagination Class Initialized
INFO - 2016-02-07 10:34:26 --> Form Validation Class Initialized
INFO - 2016-02-07 10:34:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:34:26 --> Model Class Initialized
INFO - 2016-02-07 10:34:26 --> Final output sent to browser
DEBUG - 2016-02-07 10:34:26 --> Total execution time: 1.2395
INFO - 2016-02-07 10:35:09 --> Config Class Initialized
INFO - 2016-02-07 10:35:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:35:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:35:09 --> Utf8 Class Initialized
INFO - 2016-02-07 10:35:09 --> URI Class Initialized
DEBUG - 2016-02-07 10:35:09 --> No URI present. Default controller set.
INFO - 2016-02-07 10:35:09 --> Router Class Initialized
INFO - 2016-02-07 10:35:09 --> Output Class Initialized
INFO - 2016-02-07 10:35:09 --> Security Class Initialized
DEBUG - 2016-02-07 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:35:09 --> Input Class Initialized
INFO - 2016-02-07 10:35:09 --> Language Class Initialized
INFO - 2016-02-07 10:35:09 --> Loader Class Initialized
INFO - 2016-02-07 10:35:09 --> Helper loaded: url_helper
INFO - 2016-02-07 10:35:09 --> Helper loaded: file_helper
INFO - 2016-02-07 10:35:09 --> Helper loaded: date_helper
INFO - 2016-02-07 10:35:09 --> Helper loaded: form_helper
INFO - 2016-02-07 10:35:09 --> Database Driver Class Initialized
INFO - 2016-02-07 10:35:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:35:10 --> Controller Class Initialized
INFO - 2016-02-07 10:35:10 --> Model Class Initialized
INFO - 2016-02-07 10:35:10 --> Model Class Initialized
INFO - 2016-02-07 10:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:35:10 --> Pagination Class Initialized
INFO - 2016-02-07 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:35:10 --> Final output sent to browser
DEBUG - 2016-02-07 10:35:10 --> Total execution time: 1.1692
INFO - 2016-02-07 10:35:12 --> Config Class Initialized
INFO - 2016-02-07 10:35:12 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:35:12 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:35:12 --> Utf8 Class Initialized
INFO - 2016-02-07 10:35:12 --> URI Class Initialized
INFO - 2016-02-07 10:35:12 --> Router Class Initialized
INFO - 2016-02-07 10:35:12 --> Output Class Initialized
INFO - 2016-02-07 10:35:12 --> Security Class Initialized
DEBUG - 2016-02-07 10:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:35:12 --> Input Class Initialized
INFO - 2016-02-07 10:35:12 --> Language Class Initialized
INFO - 2016-02-07 10:35:12 --> Loader Class Initialized
INFO - 2016-02-07 10:35:12 --> Helper loaded: url_helper
INFO - 2016-02-07 10:35:12 --> Helper loaded: file_helper
INFO - 2016-02-07 10:35:12 --> Helper loaded: date_helper
INFO - 2016-02-07 10:35:12 --> Helper loaded: form_helper
INFO - 2016-02-07 10:35:12 --> Database Driver Class Initialized
INFO - 2016-02-07 10:35:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:35:13 --> Controller Class Initialized
INFO - 2016-02-07 10:35:13 --> Model Class Initialized
INFO - 2016-02-07 10:35:13 --> Model Class Initialized
INFO - 2016-02-07 10:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:35:13 --> Pagination Class Initialized
INFO - 2016-02-07 10:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:35:13 --> Helper loaded: text_helper
INFO - 2016-02-07 10:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:35:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:35:13 --> Final output sent to browser
DEBUG - 2016-02-07 10:35:13 --> Total execution time: 1.1695
INFO - 2016-02-07 10:35:18 --> Config Class Initialized
INFO - 2016-02-07 10:35:18 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:35:18 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:35:18 --> Utf8 Class Initialized
INFO - 2016-02-07 10:35:18 --> URI Class Initialized
INFO - 2016-02-07 10:35:18 --> Router Class Initialized
INFO - 2016-02-07 10:35:18 --> Output Class Initialized
INFO - 2016-02-07 10:35:18 --> Security Class Initialized
DEBUG - 2016-02-07 10:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:35:18 --> Input Class Initialized
INFO - 2016-02-07 10:35:18 --> Language Class Initialized
INFO - 2016-02-07 10:35:18 --> Loader Class Initialized
INFO - 2016-02-07 10:35:18 --> Helper loaded: url_helper
INFO - 2016-02-07 10:35:18 --> Helper loaded: file_helper
INFO - 2016-02-07 10:35:18 --> Helper loaded: date_helper
INFO - 2016-02-07 10:35:18 --> Helper loaded: form_helper
INFO - 2016-02-07 10:35:18 --> Database Driver Class Initialized
INFO - 2016-02-07 10:35:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:35:19 --> Controller Class Initialized
INFO - 2016-02-07 10:35:19 --> Model Class Initialized
INFO - 2016-02-07 10:35:19 --> Model Class Initialized
INFO - 2016-02-07 10:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:35:19 --> Pagination Class Initialized
INFO - 2016-02-07 10:35:19 --> Form Validation Class Initialized
INFO - 2016-02-07 10:35:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:35:19 --> Model Class Initialized
INFO - 2016-02-07 10:35:20 --> Final output sent to browser
DEBUG - 2016-02-07 10:35:20 --> Total execution time: 1.2093
INFO - 2016-02-07 10:47:13 --> Config Class Initialized
INFO - 2016-02-07 10:47:13 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:47:13 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:47:13 --> Utf8 Class Initialized
INFO - 2016-02-07 10:47:13 --> URI Class Initialized
DEBUG - 2016-02-07 10:47:13 --> No URI present. Default controller set.
INFO - 2016-02-07 10:47:13 --> Router Class Initialized
INFO - 2016-02-07 10:47:13 --> Output Class Initialized
INFO - 2016-02-07 10:47:13 --> Security Class Initialized
DEBUG - 2016-02-07 10:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:47:13 --> Input Class Initialized
INFO - 2016-02-07 10:47:13 --> Language Class Initialized
INFO - 2016-02-07 10:47:13 --> Loader Class Initialized
INFO - 2016-02-07 10:47:13 --> Helper loaded: url_helper
INFO - 2016-02-07 10:47:13 --> Helper loaded: file_helper
INFO - 2016-02-07 10:47:13 --> Helper loaded: date_helper
INFO - 2016-02-07 10:47:13 --> Helper loaded: form_helper
INFO - 2016-02-07 10:47:13 --> Database Driver Class Initialized
INFO - 2016-02-07 10:47:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:47:14 --> Controller Class Initialized
INFO - 2016-02-07 10:47:14 --> Model Class Initialized
INFO - 2016-02-07 10:47:14 --> Model Class Initialized
INFO - 2016-02-07 10:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:47:14 --> Pagination Class Initialized
INFO - 2016-02-07 10:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:47:14 --> Final output sent to browser
DEBUG - 2016-02-07 10:47:14 --> Total execution time: 1.1654
INFO - 2016-02-07 10:47:17 --> Config Class Initialized
INFO - 2016-02-07 10:47:17 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:47:17 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:47:17 --> Utf8 Class Initialized
INFO - 2016-02-07 10:47:17 --> URI Class Initialized
INFO - 2016-02-07 10:47:17 --> Router Class Initialized
INFO - 2016-02-07 10:47:17 --> Output Class Initialized
INFO - 2016-02-07 10:47:17 --> Security Class Initialized
DEBUG - 2016-02-07 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:47:17 --> Input Class Initialized
INFO - 2016-02-07 10:47:17 --> Language Class Initialized
INFO - 2016-02-07 10:47:17 --> Loader Class Initialized
INFO - 2016-02-07 10:47:17 --> Helper loaded: url_helper
INFO - 2016-02-07 10:47:17 --> Helper loaded: file_helper
INFO - 2016-02-07 10:47:17 --> Helper loaded: date_helper
INFO - 2016-02-07 10:47:17 --> Helper loaded: form_helper
INFO - 2016-02-07 10:47:17 --> Database Driver Class Initialized
INFO - 2016-02-07 10:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:47:19 --> Controller Class Initialized
INFO - 2016-02-07 10:47:19 --> Model Class Initialized
INFO - 2016-02-07 10:47:19 --> Model Class Initialized
INFO - 2016-02-07 10:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:47:19 --> Pagination Class Initialized
INFO - 2016-02-07 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:47:19 --> Helper loaded: text_helper
INFO - 2016-02-07 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:47:19 --> Final output sent to browser
DEBUG - 2016-02-07 10:47:19 --> Total execution time: 1.2091
INFO - 2016-02-07 10:47:23 --> Config Class Initialized
INFO - 2016-02-07 10:47:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:47:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:47:24 --> Utf8 Class Initialized
INFO - 2016-02-07 10:47:24 --> URI Class Initialized
INFO - 2016-02-07 10:47:24 --> Router Class Initialized
INFO - 2016-02-07 10:47:24 --> Output Class Initialized
INFO - 2016-02-07 10:47:24 --> Security Class Initialized
DEBUG - 2016-02-07 10:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:47:24 --> Input Class Initialized
INFO - 2016-02-07 10:47:24 --> Language Class Initialized
INFO - 2016-02-07 10:47:24 --> Loader Class Initialized
INFO - 2016-02-07 10:47:24 --> Helper loaded: url_helper
INFO - 2016-02-07 10:47:24 --> Helper loaded: file_helper
INFO - 2016-02-07 10:47:24 --> Helper loaded: date_helper
INFO - 2016-02-07 10:47:24 --> Helper loaded: form_helper
INFO - 2016-02-07 10:47:24 --> Database Driver Class Initialized
INFO - 2016-02-07 10:47:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:47:25 --> Controller Class Initialized
INFO - 2016-02-07 10:47:25 --> Model Class Initialized
INFO - 2016-02-07 10:47:25 --> Model Class Initialized
INFO - 2016-02-07 10:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:47:25 --> Pagination Class Initialized
INFO - 2016-02-07 10:47:25 --> Form Validation Class Initialized
INFO - 2016-02-07 10:47:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:47:25 --> Model Class Initialized
INFO - 2016-02-07 10:47:25 --> Final output sent to browser
DEBUG - 2016-02-07 10:47:25 --> Total execution time: 1.1720
INFO - 2016-02-07 10:55:50 --> Config Class Initialized
INFO - 2016-02-07 10:55:50 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:55:50 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:55:50 --> Utf8 Class Initialized
INFO - 2016-02-07 10:55:50 --> URI Class Initialized
DEBUG - 2016-02-07 10:55:50 --> No URI present. Default controller set.
INFO - 2016-02-07 10:55:50 --> Router Class Initialized
INFO - 2016-02-07 10:55:50 --> Output Class Initialized
INFO - 2016-02-07 10:55:50 --> Security Class Initialized
DEBUG - 2016-02-07 10:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:55:50 --> Input Class Initialized
INFO - 2016-02-07 10:55:50 --> Language Class Initialized
INFO - 2016-02-07 10:55:50 --> Loader Class Initialized
INFO - 2016-02-07 10:55:50 --> Helper loaded: url_helper
INFO - 2016-02-07 10:55:50 --> Helper loaded: file_helper
INFO - 2016-02-07 10:55:50 --> Helper loaded: date_helper
INFO - 2016-02-07 10:55:50 --> Helper loaded: form_helper
INFO - 2016-02-07 10:55:50 --> Database Driver Class Initialized
INFO - 2016-02-07 10:55:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:55:51 --> Controller Class Initialized
INFO - 2016-02-07 10:55:51 --> Model Class Initialized
INFO - 2016-02-07 10:55:51 --> Model Class Initialized
INFO - 2016-02-07 10:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:55:51 --> Pagination Class Initialized
INFO - 2016-02-07 10:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:55:51 --> Final output sent to browser
DEBUG - 2016-02-07 10:55:51 --> Total execution time: 1.1371
INFO - 2016-02-07 10:55:55 --> Config Class Initialized
INFO - 2016-02-07 10:55:55 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:55:55 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:55:55 --> Utf8 Class Initialized
INFO - 2016-02-07 10:55:55 --> URI Class Initialized
INFO - 2016-02-07 10:55:55 --> Router Class Initialized
INFO - 2016-02-07 10:55:55 --> Output Class Initialized
INFO - 2016-02-07 10:55:55 --> Security Class Initialized
DEBUG - 2016-02-07 10:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:55:55 --> Input Class Initialized
INFO - 2016-02-07 10:55:55 --> Language Class Initialized
INFO - 2016-02-07 10:55:55 --> Loader Class Initialized
INFO - 2016-02-07 10:55:55 --> Helper loaded: url_helper
INFO - 2016-02-07 10:55:55 --> Helper loaded: file_helper
INFO - 2016-02-07 10:55:55 --> Helper loaded: date_helper
INFO - 2016-02-07 10:55:55 --> Helper loaded: form_helper
INFO - 2016-02-07 10:55:55 --> Database Driver Class Initialized
INFO - 2016-02-07 10:55:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:55:56 --> Controller Class Initialized
INFO - 2016-02-07 10:55:56 --> Model Class Initialized
INFO - 2016-02-07 10:55:56 --> Model Class Initialized
INFO - 2016-02-07 10:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:55:56 --> Pagination Class Initialized
INFO - 2016-02-07 10:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:55:56 --> Helper loaded: text_helper
INFO - 2016-02-07 10:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:55:56 --> Final output sent to browser
DEBUG - 2016-02-07 10:55:56 --> Total execution time: 1.2260
INFO - 2016-02-07 10:56:00 --> Config Class Initialized
INFO - 2016-02-07 10:56:00 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:56:00 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:56:00 --> Utf8 Class Initialized
INFO - 2016-02-07 10:56:00 --> URI Class Initialized
DEBUG - 2016-02-07 10:56:00 --> No URI present. Default controller set.
INFO - 2016-02-07 10:56:00 --> Router Class Initialized
INFO - 2016-02-07 10:56:00 --> Output Class Initialized
INFO - 2016-02-07 10:56:00 --> Security Class Initialized
DEBUG - 2016-02-07 10:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:56:00 --> Input Class Initialized
INFO - 2016-02-07 10:56:00 --> Language Class Initialized
INFO - 2016-02-07 10:56:00 --> Loader Class Initialized
INFO - 2016-02-07 10:56:00 --> Helper loaded: url_helper
INFO - 2016-02-07 10:56:00 --> Helper loaded: file_helper
INFO - 2016-02-07 10:56:00 --> Helper loaded: date_helper
INFO - 2016-02-07 10:56:00 --> Helper loaded: form_helper
INFO - 2016-02-07 10:56:00 --> Database Driver Class Initialized
INFO - 2016-02-07 10:56:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:56:01 --> Controller Class Initialized
INFO - 2016-02-07 10:56:01 --> Model Class Initialized
INFO - 2016-02-07 10:56:01 --> Model Class Initialized
INFO - 2016-02-07 10:56:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:56:01 --> Pagination Class Initialized
INFO - 2016-02-07 10:56:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:56:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:56:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 10:56:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:56:01 --> Final output sent to browser
DEBUG - 2016-02-07 10:56:01 --> Total execution time: 1.1578
INFO - 2016-02-07 10:56:07 --> Config Class Initialized
INFO - 2016-02-07 10:56:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:56:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:56:07 --> Utf8 Class Initialized
INFO - 2016-02-07 10:56:07 --> URI Class Initialized
INFO - 2016-02-07 10:56:07 --> Router Class Initialized
INFO - 2016-02-07 10:56:07 --> Output Class Initialized
INFO - 2016-02-07 10:56:07 --> Security Class Initialized
DEBUG - 2016-02-07 10:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:56:07 --> Input Class Initialized
INFO - 2016-02-07 10:56:07 --> Language Class Initialized
INFO - 2016-02-07 10:56:07 --> Loader Class Initialized
INFO - 2016-02-07 10:56:07 --> Helper loaded: url_helper
INFO - 2016-02-07 10:56:07 --> Helper loaded: file_helper
INFO - 2016-02-07 10:56:07 --> Helper loaded: date_helper
INFO - 2016-02-07 10:56:07 --> Helper loaded: form_helper
INFO - 2016-02-07 10:56:07 --> Database Driver Class Initialized
INFO - 2016-02-07 10:56:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:56:08 --> Controller Class Initialized
INFO - 2016-02-07 10:56:08 --> Model Class Initialized
INFO - 2016-02-07 10:56:08 --> Model Class Initialized
INFO - 2016-02-07 10:56:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:56:08 --> Pagination Class Initialized
INFO - 2016-02-07 10:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 10:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 10:56:08 --> Helper loaded: text_helper
INFO - 2016-02-07 10:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 10:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 10:56:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 10:56:08 --> Final output sent to browser
DEBUG - 2016-02-07 10:56:08 --> Total execution time: 1.1589
INFO - 2016-02-07 10:56:17 --> Config Class Initialized
INFO - 2016-02-07 10:56:17 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:56:17 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:56:17 --> Utf8 Class Initialized
INFO - 2016-02-07 10:56:17 --> URI Class Initialized
INFO - 2016-02-07 10:56:17 --> Router Class Initialized
INFO - 2016-02-07 10:56:17 --> Output Class Initialized
INFO - 2016-02-07 10:56:17 --> Security Class Initialized
DEBUG - 2016-02-07 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:56:17 --> Input Class Initialized
INFO - 2016-02-07 10:56:17 --> Language Class Initialized
INFO - 2016-02-07 10:56:17 --> Loader Class Initialized
INFO - 2016-02-07 10:56:17 --> Helper loaded: url_helper
INFO - 2016-02-07 10:56:17 --> Helper loaded: file_helper
INFO - 2016-02-07 10:56:17 --> Helper loaded: date_helper
INFO - 2016-02-07 10:56:17 --> Helper loaded: form_helper
INFO - 2016-02-07 10:56:17 --> Database Driver Class Initialized
INFO - 2016-02-07 10:56:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:56:18 --> Controller Class Initialized
INFO - 2016-02-07 10:56:18 --> Model Class Initialized
INFO - 2016-02-07 10:56:18 --> Model Class Initialized
INFO - 2016-02-07 10:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:56:18 --> Pagination Class Initialized
INFO - 2016-02-07 10:56:18 --> Form Validation Class Initialized
INFO - 2016-02-07 10:56:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:56:18 --> Model Class Initialized
INFO - 2016-02-07 10:56:18 --> Final output sent to browser
DEBUG - 2016-02-07 10:56:18 --> Total execution time: 1.1884
INFO - 2016-02-07 10:56:24 --> Config Class Initialized
INFO - 2016-02-07 10:56:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 10:56:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 10:56:24 --> Utf8 Class Initialized
INFO - 2016-02-07 10:56:24 --> URI Class Initialized
INFO - 2016-02-07 10:56:24 --> Router Class Initialized
INFO - 2016-02-07 10:56:24 --> Output Class Initialized
INFO - 2016-02-07 10:56:24 --> Security Class Initialized
DEBUG - 2016-02-07 10:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 10:56:24 --> Input Class Initialized
INFO - 2016-02-07 10:56:24 --> Language Class Initialized
INFO - 2016-02-07 10:56:24 --> Loader Class Initialized
INFO - 2016-02-07 10:56:24 --> Helper loaded: url_helper
INFO - 2016-02-07 10:56:24 --> Helper loaded: file_helper
INFO - 2016-02-07 10:56:24 --> Helper loaded: date_helper
INFO - 2016-02-07 10:56:24 --> Helper loaded: form_helper
INFO - 2016-02-07 10:56:24 --> Database Driver Class Initialized
INFO - 2016-02-07 10:56:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 10:56:25 --> Controller Class Initialized
INFO - 2016-02-07 10:56:25 --> Model Class Initialized
INFO - 2016-02-07 10:56:25 --> Model Class Initialized
INFO - 2016-02-07 10:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 10:56:25 --> Pagination Class Initialized
INFO - 2016-02-07 10:56:25 --> Form Validation Class Initialized
INFO - 2016-02-07 10:56:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 10:56:25 --> Model Class Initialized
INFO - 2016-02-07 10:56:25 --> Final output sent to browser
DEBUG - 2016-02-07 10:56:25 --> Total execution time: 1.2570
INFO - 2016-02-07 11:00:00 --> Config Class Initialized
INFO - 2016-02-07 11:00:00 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:00:00 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:00:00 --> Utf8 Class Initialized
INFO - 2016-02-07 11:00:00 --> URI Class Initialized
INFO - 2016-02-07 11:00:00 --> Router Class Initialized
INFO - 2016-02-07 11:00:00 --> Output Class Initialized
INFO - 2016-02-07 11:00:00 --> Security Class Initialized
DEBUG - 2016-02-07 11:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:00:00 --> Input Class Initialized
INFO - 2016-02-07 11:00:00 --> Language Class Initialized
INFO - 2016-02-07 11:00:00 --> Loader Class Initialized
INFO - 2016-02-07 11:00:00 --> Helper loaded: url_helper
INFO - 2016-02-07 11:00:00 --> Helper loaded: file_helper
INFO - 2016-02-07 11:00:00 --> Helper loaded: date_helper
INFO - 2016-02-07 11:00:00 --> Helper loaded: form_helper
INFO - 2016-02-07 11:00:00 --> Database Driver Class Initialized
INFO - 2016-02-07 11:00:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:00:01 --> Controller Class Initialized
INFO - 2016-02-07 11:00:01 --> Model Class Initialized
INFO - 2016-02-07 11:00:01 --> Model Class Initialized
INFO - 2016-02-07 11:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:00:01 --> Pagination Class Initialized
INFO - 2016-02-07 11:00:01 --> Form Validation Class Initialized
INFO - 2016-02-07 11:00:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:00:01 --> Model Class Initialized
INFO - 2016-02-07 11:00:01 --> Final output sent to browser
DEBUG - 2016-02-07 11:00:01 --> Total execution time: 1.2408
INFO - 2016-02-07 11:01:44 --> Config Class Initialized
INFO - 2016-02-07 11:01:44 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:01:44 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:01:44 --> Utf8 Class Initialized
INFO - 2016-02-07 11:01:44 --> URI Class Initialized
DEBUG - 2016-02-07 11:01:44 --> No URI present. Default controller set.
INFO - 2016-02-07 11:01:44 --> Router Class Initialized
INFO - 2016-02-07 11:01:44 --> Output Class Initialized
INFO - 2016-02-07 11:01:44 --> Security Class Initialized
DEBUG - 2016-02-07 11:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:01:44 --> Input Class Initialized
INFO - 2016-02-07 11:01:44 --> Language Class Initialized
INFO - 2016-02-07 11:01:44 --> Loader Class Initialized
INFO - 2016-02-07 11:01:44 --> Helper loaded: url_helper
INFO - 2016-02-07 11:01:44 --> Helper loaded: file_helper
INFO - 2016-02-07 11:01:44 --> Helper loaded: date_helper
INFO - 2016-02-07 11:01:44 --> Helper loaded: form_helper
INFO - 2016-02-07 11:01:44 --> Database Driver Class Initialized
INFO - 2016-02-07 11:01:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:01:45 --> Controller Class Initialized
INFO - 2016-02-07 11:01:45 --> Model Class Initialized
INFO - 2016-02-07 11:01:45 --> Model Class Initialized
INFO - 2016-02-07 11:01:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:01:45 --> Pagination Class Initialized
INFO - 2016-02-07 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:01:45 --> Final output sent to browser
DEBUG - 2016-02-07 11:01:45 --> Total execution time: 1.1422
INFO - 2016-02-07 11:01:49 --> Config Class Initialized
INFO - 2016-02-07 11:01:49 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:01:49 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:01:49 --> Utf8 Class Initialized
INFO - 2016-02-07 11:01:49 --> URI Class Initialized
INFO - 2016-02-07 11:01:49 --> Router Class Initialized
INFO - 2016-02-07 11:01:49 --> Output Class Initialized
INFO - 2016-02-07 11:01:49 --> Security Class Initialized
DEBUG - 2016-02-07 11:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:01:49 --> Input Class Initialized
INFO - 2016-02-07 11:01:49 --> Language Class Initialized
INFO - 2016-02-07 11:01:49 --> Loader Class Initialized
INFO - 2016-02-07 11:01:49 --> Helper loaded: url_helper
INFO - 2016-02-07 11:01:49 --> Helper loaded: file_helper
INFO - 2016-02-07 11:01:49 --> Helper loaded: date_helper
INFO - 2016-02-07 11:01:49 --> Helper loaded: form_helper
INFO - 2016-02-07 11:01:49 --> Database Driver Class Initialized
INFO - 2016-02-07 11:01:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:01:51 --> Controller Class Initialized
INFO - 2016-02-07 11:01:51 --> Model Class Initialized
INFO - 2016-02-07 11:01:51 --> Model Class Initialized
INFO - 2016-02-07 11:01:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:01:51 --> Pagination Class Initialized
INFO - 2016-02-07 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:01:51 --> Helper loaded: text_helper
INFO - 2016-02-07 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:01:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:01:51 --> Final output sent to browser
DEBUG - 2016-02-07 11:01:51 --> Total execution time: 1.1980
INFO - 2016-02-07 11:01:55 --> Config Class Initialized
INFO - 2016-02-07 11:01:55 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:01:55 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:01:55 --> Utf8 Class Initialized
INFO - 2016-02-07 11:01:55 --> URI Class Initialized
INFO - 2016-02-07 11:01:55 --> Router Class Initialized
INFO - 2016-02-07 11:01:55 --> Output Class Initialized
INFO - 2016-02-07 11:01:55 --> Security Class Initialized
DEBUG - 2016-02-07 11:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:01:55 --> Input Class Initialized
INFO - 2016-02-07 11:01:55 --> Language Class Initialized
INFO - 2016-02-07 11:01:55 --> Loader Class Initialized
INFO - 2016-02-07 11:01:55 --> Helper loaded: url_helper
INFO - 2016-02-07 11:01:55 --> Helper loaded: file_helper
INFO - 2016-02-07 11:01:55 --> Helper loaded: date_helper
INFO - 2016-02-07 11:01:55 --> Helper loaded: form_helper
INFO - 2016-02-07 11:01:55 --> Database Driver Class Initialized
INFO - 2016-02-07 11:01:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:01:56 --> Controller Class Initialized
INFO - 2016-02-07 11:01:56 --> Model Class Initialized
INFO - 2016-02-07 11:01:56 --> Model Class Initialized
INFO - 2016-02-07 11:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:01:56 --> Pagination Class Initialized
INFO - 2016-02-07 11:01:56 --> Form Validation Class Initialized
INFO - 2016-02-07 11:01:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:01:56 --> Model Class Initialized
INFO - 2016-02-07 11:01:56 --> Final output sent to browser
DEBUG - 2016-02-07 11:01:56 --> Total execution time: 1.1783
INFO - 2016-02-07 11:03:03 --> Config Class Initialized
INFO - 2016-02-07 11:03:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:03:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:03:03 --> Utf8 Class Initialized
INFO - 2016-02-07 11:03:03 --> URI Class Initialized
DEBUG - 2016-02-07 11:03:03 --> No URI present. Default controller set.
INFO - 2016-02-07 11:03:03 --> Router Class Initialized
INFO - 2016-02-07 11:03:03 --> Output Class Initialized
INFO - 2016-02-07 11:03:03 --> Security Class Initialized
DEBUG - 2016-02-07 11:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:03:03 --> Input Class Initialized
INFO - 2016-02-07 11:03:03 --> Language Class Initialized
INFO - 2016-02-07 11:03:03 --> Loader Class Initialized
INFO - 2016-02-07 11:03:03 --> Helper loaded: url_helper
INFO - 2016-02-07 11:03:03 --> Helper loaded: file_helper
INFO - 2016-02-07 11:03:03 --> Helper loaded: date_helper
INFO - 2016-02-07 11:03:03 --> Helper loaded: form_helper
INFO - 2016-02-07 11:03:03 --> Database Driver Class Initialized
INFO - 2016-02-07 11:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:03:04 --> Controller Class Initialized
INFO - 2016-02-07 11:03:04 --> Model Class Initialized
INFO - 2016-02-07 11:03:04 --> Model Class Initialized
INFO - 2016-02-07 11:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:03:04 --> Pagination Class Initialized
INFO - 2016-02-07 11:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:03:04 --> Final output sent to browser
DEBUG - 2016-02-07 11:03:04 --> Total execution time: 1.1582
INFO - 2016-02-07 11:03:06 --> Config Class Initialized
INFO - 2016-02-07 11:03:06 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:03:06 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:03:06 --> Utf8 Class Initialized
INFO - 2016-02-07 11:03:06 --> URI Class Initialized
INFO - 2016-02-07 11:03:06 --> Router Class Initialized
INFO - 2016-02-07 11:03:06 --> Output Class Initialized
INFO - 2016-02-07 11:03:06 --> Security Class Initialized
DEBUG - 2016-02-07 11:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:03:06 --> Input Class Initialized
INFO - 2016-02-07 11:03:06 --> Language Class Initialized
INFO - 2016-02-07 11:03:06 --> Loader Class Initialized
INFO - 2016-02-07 11:03:06 --> Helper loaded: url_helper
INFO - 2016-02-07 11:03:06 --> Helper loaded: file_helper
INFO - 2016-02-07 11:03:06 --> Helper loaded: date_helper
INFO - 2016-02-07 11:03:06 --> Helper loaded: form_helper
INFO - 2016-02-07 11:03:06 --> Database Driver Class Initialized
INFO - 2016-02-07 11:03:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:03:07 --> Controller Class Initialized
INFO - 2016-02-07 11:03:07 --> Model Class Initialized
INFO - 2016-02-07 11:03:07 --> Model Class Initialized
INFO - 2016-02-07 11:03:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:03:07 --> Pagination Class Initialized
INFO - 2016-02-07 11:03:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:03:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:03:07 --> Helper loaded: text_helper
INFO - 2016-02-07 11:03:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:03:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:03:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:03:07 --> Final output sent to browser
DEBUG - 2016-02-07 11:03:07 --> Total execution time: 1.2021
INFO - 2016-02-07 11:03:17 --> Config Class Initialized
INFO - 2016-02-07 11:03:17 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:03:17 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:03:17 --> Utf8 Class Initialized
INFO - 2016-02-07 11:03:17 --> URI Class Initialized
INFO - 2016-02-07 11:03:17 --> Router Class Initialized
INFO - 2016-02-07 11:03:17 --> Output Class Initialized
INFO - 2016-02-07 11:03:17 --> Security Class Initialized
DEBUG - 2016-02-07 11:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:03:17 --> Input Class Initialized
INFO - 2016-02-07 11:03:17 --> Language Class Initialized
INFO - 2016-02-07 11:03:17 --> Loader Class Initialized
INFO - 2016-02-07 11:03:17 --> Helper loaded: url_helper
INFO - 2016-02-07 11:03:17 --> Helper loaded: file_helper
INFO - 2016-02-07 11:03:17 --> Helper loaded: date_helper
INFO - 2016-02-07 11:03:17 --> Helper loaded: form_helper
INFO - 2016-02-07 11:03:17 --> Database Driver Class Initialized
INFO - 2016-02-07 11:03:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:03:18 --> Controller Class Initialized
INFO - 2016-02-07 11:03:18 --> Model Class Initialized
INFO - 2016-02-07 11:03:18 --> Model Class Initialized
INFO - 2016-02-07 11:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:03:18 --> Pagination Class Initialized
INFO - 2016-02-07 11:03:18 --> Form Validation Class Initialized
INFO - 2016-02-07 11:03:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:03:18 --> Model Class Initialized
INFO - 2016-02-07 11:03:18 --> Final output sent to browser
DEBUG - 2016-02-07 11:03:18 --> Total execution time: 1.1957
INFO - 2016-02-07 11:21:40 --> Config Class Initialized
INFO - 2016-02-07 11:21:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:21:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:21:40 --> Utf8 Class Initialized
INFO - 2016-02-07 11:21:40 --> URI Class Initialized
INFO - 2016-02-07 11:21:40 --> Router Class Initialized
INFO - 2016-02-07 11:21:40 --> Output Class Initialized
INFO - 2016-02-07 11:21:40 --> Security Class Initialized
DEBUG - 2016-02-07 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:21:40 --> Input Class Initialized
INFO - 2016-02-07 11:21:40 --> Language Class Initialized
INFO - 2016-02-07 11:21:40 --> Loader Class Initialized
INFO - 2016-02-07 11:21:40 --> Helper loaded: url_helper
INFO - 2016-02-07 11:21:40 --> Helper loaded: file_helper
INFO - 2016-02-07 11:21:40 --> Helper loaded: date_helper
INFO - 2016-02-07 11:21:40 --> Helper loaded: form_helper
INFO - 2016-02-07 11:21:40 --> Database Driver Class Initialized
INFO - 2016-02-07 11:21:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:21:41 --> Controller Class Initialized
INFO - 2016-02-07 11:21:41 --> Model Class Initialized
INFO - 2016-02-07 11:21:41 --> Model Class Initialized
INFO - 2016-02-07 11:21:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:21:41 --> Pagination Class Initialized
INFO - 2016-02-07 11:21:41 --> Form Validation Class Initialized
INFO - 2016-02-07 11:21:41 --> Final output sent to browser
DEBUG - 2016-02-07 11:21:41 --> Total execution time: 1.1503
INFO - 2016-02-07 11:28:09 --> Config Class Initialized
INFO - 2016-02-07 11:28:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:28:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:28:09 --> Utf8 Class Initialized
INFO - 2016-02-07 11:28:09 --> URI Class Initialized
DEBUG - 2016-02-07 11:28:09 --> No URI present. Default controller set.
INFO - 2016-02-07 11:28:09 --> Router Class Initialized
INFO - 2016-02-07 11:28:09 --> Output Class Initialized
INFO - 2016-02-07 11:28:09 --> Security Class Initialized
DEBUG - 2016-02-07 11:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:28:09 --> Input Class Initialized
INFO - 2016-02-07 11:28:09 --> Language Class Initialized
INFO - 2016-02-07 11:28:09 --> Loader Class Initialized
INFO - 2016-02-07 11:28:09 --> Helper loaded: url_helper
INFO - 2016-02-07 11:28:09 --> Helper loaded: file_helper
INFO - 2016-02-07 11:28:09 --> Helper loaded: date_helper
INFO - 2016-02-07 11:28:09 --> Helper loaded: form_helper
INFO - 2016-02-07 11:28:09 --> Database Driver Class Initialized
INFO - 2016-02-07 11:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:28:10 --> Controller Class Initialized
INFO - 2016-02-07 11:28:10 --> Model Class Initialized
INFO - 2016-02-07 11:28:10 --> Model Class Initialized
INFO - 2016-02-07 11:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:28:10 --> Pagination Class Initialized
INFO - 2016-02-07 11:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:28:10 --> Final output sent to browser
DEBUG - 2016-02-07 11:28:10 --> Total execution time: 1.1485
INFO - 2016-02-07 11:28:45 --> Config Class Initialized
INFO - 2016-02-07 11:28:45 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:28:45 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:28:45 --> Utf8 Class Initialized
INFO - 2016-02-07 11:28:45 --> URI Class Initialized
DEBUG - 2016-02-07 11:28:45 --> No URI present. Default controller set.
INFO - 2016-02-07 11:28:45 --> Router Class Initialized
INFO - 2016-02-07 11:28:45 --> Output Class Initialized
INFO - 2016-02-07 11:28:45 --> Security Class Initialized
DEBUG - 2016-02-07 11:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:28:45 --> Input Class Initialized
INFO - 2016-02-07 11:28:45 --> Language Class Initialized
INFO - 2016-02-07 11:28:45 --> Loader Class Initialized
INFO - 2016-02-07 11:28:45 --> Helper loaded: url_helper
INFO - 2016-02-07 11:28:45 --> Helper loaded: file_helper
INFO - 2016-02-07 11:28:45 --> Helper loaded: date_helper
INFO - 2016-02-07 11:28:45 --> Helper loaded: form_helper
INFO - 2016-02-07 11:28:45 --> Database Driver Class Initialized
INFO - 2016-02-07 11:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:28:46 --> Controller Class Initialized
INFO - 2016-02-07 11:28:46 --> Model Class Initialized
INFO - 2016-02-07 11:28:46 --> Model Class Initialized
INFO - 2016-02-07 11:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:28:46 --> Pagination Class Initialized
INFO - 2016-02-07 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:28:46 --> Final output sent to browser
DEBUG - 2016-02-07 11:28:46 --> Total execution time: 1.1511
INFO - 2016-02-07 11:28:57 --> Config Class Initialized
INFO - 2016-02-07 11:28:57 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:28:57 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:28:57 --> Utf8 Class Initialized
INFO - 2016-02-07 11:28:57 --> URI Class Initialized
INFO - 2016-02-07 11:28:57 --> Router Class Initialized
INFO - 2016-02-07 11:28:57 --> Output Class Initialized
INFO - 2016-02-07 11:28:57 --> Security Class Initialized
DEBUG - 2016-02-07 11:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:28:57 --> Input Class Initialized
INFO - 2016-02-07 11:28:57 --> Language Class Initialized
INFO - 2016-02-07 11:28:57 --> Loader Class Initialized
INFO - 2016-02-07 11:28:57 --> Helper loaded: url_helper
INFO - 2016-02-07 11:28:57 --> Helper loaded: file_helper
INFO - 2016-02-07 11:28:57 --> Helper loaded: date_helper
INFO - 2016-02-07 11:28:57 --> Helper loaded: form_helper
INFO - 2016-02-07 11:28:57 --> Database Driver Class Initialized
INFO - 2016-02-07 11:28:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:28:58 --> Controller Class Initialized
INFO - 2016-02-07 11:28:58 --> Model Class Initialized
INFO - 2016-02-07 11:28:58 --> Model Class Initialized
INFO - 2016-02-07 11:28:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:28:58 --> Pagination Class Initialized
INFO - 2016-02-07 11:28:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:28:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:28:58 --> Helper loaded: text_helper
INFO - 2016-02-07 11:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:28:59 --> Final output sent to browser
DEBUG - 2016-02-07 11:28:59 --> Total execution time: 1.2364
INFO - 2016-02-07 11:29:05 --> Config Class Initialized
INFO - 2016-02-07 11:29:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:29:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:29:05 --> Utf8 Class Initialized
INFO - 2016-02-07 11:29:05 --> URI Class Initialized
INFO - 2016-02-07 11:29:05 --> Router Class Initialized
INFO - 2016-02-07 11:29:05 --> Output Class Initialized
INFO - 2016-02-07 11:29:05 --> Security Class Initialized
DEBUG - 2016-02-07 11:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:29:05 --> Input Class Initialized
INFO - 2016-02-07 11:29:05 --> Language Class Initialized
INFO - 2016-02-07 11:29:05 --> Loader Class Initialized
INFO - 2016-02-07 11:29:05 --> Helper loaded: url_helper
INFO - 2016-02-07 11:29:05 --> Helper loaded: file_helper
INFO - 2016-02-07 11:29:05 --> Helper loaded: date_helper
INFO - 2016-02-07 11:29:05 --> Helper loaded: form_helper
INFO - 2016-02-07 11:29:05 --> Database Driver Class Initialized
INFO - 2016-02-07 11:29:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:29:06 --> Controller Class Initialized
INFO - 2016-02-07 11:29:06 --> Model Class Initialized
INFO - 2016-02-07 11:29:06 --> Model Class Initialized
INFO - 2016-02-07 11:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:29:06 --> Pagination Class Initialized
INFO - 2016-02-07 11:29:06 --> Form Validation Class Initialized
INFO - 2016-02-07 11:29:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:29:06 --> Model Class Initialized
INFO - 2016-02-07 11:29:06 --> Final output sent to browser
DEBUG - 2016-02-07 11:29:06 --> Total execution time: 1.4148
INFO - 2016-02-07 11:29:25 --> Config Class Initialized
INFO - 2016-02-07 11:29:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:29:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:29:25 --> Utf8 Class Initialized
INFO - 2016-02-07 11:29:25 --> URI Class Initialized
INFO - 2016-02-07 11:29:25 --> Router Class Initialized
INFO - 2016-02-07 11:29:25 --> Output Class Initialized
INFO - 2016-02-07 11:29:25 --> Security Class Initialized
DEBUG - 2016-02-07 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:29:25 --> Input Class Initialized
INFO - 2016-02-07 11:29:25 --> Language Class Initialized
INFO - 2016-02-07 11:29:25 --> Loader Class Initialized
INFO - 2016-02-07 11:29:25 --> Helper loaded: url_helper
INFO - 2016-02-07 11:29:25 --> Helper loaded: file_helper
INFO - 2016-02-07 11:29:25 --> Helper loaded: date_helper
INFO - 2016-02-07 11:29:25 --> Helper loaded: form_helper
INFO - 2016-02-07 11:29:25 --> Database Driver Class Initialized
INFO - 2016-02-07 11:29:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:29:26 --> Controller Class Initialized
INFO - 2016-02-07 11:29:26 --> Model Class Initialized
INFO - 2016-02-07 11:29:26 --> Model Class Initialized
INFO - 2016-02-07 11:29:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:29:26 --> Pagination Class Initialized
INFO - 2016-02-07 11:29:26 --> Form Validation Class Initialized
INFO - 2016-02-07 11:29:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:29:26 --> Model Class Initialized
INFO - 2016-02-07 11:29:26 --> Final output sent to browser
DEBUG - 2016-02-07 11:29:26 --> Total execution time: 1.2124
INFO - 2016-02-07 11:30:27 --> Config Class Initialized
INFO - 2016-02-07 11:30:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:30:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:30:27 --> Utf8 Class Initialized
INFO - 2016-02-07 11:30:27 --> URI Class Initialized
DEBUG - 2016-02-07 11:30:27 --> No URI present. Default controller set.
INFO - 2016-02-07 11:30:27 --> Router Class Initialized
INFO - 2016-02-07 11:30:27 --> Output Class Initialized
INFO - 2016-02-07 11:30:27 --> Security Class Initialized
DEBUG - 2016-02-07 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:30:27 --> Input Class Initialized
INFO - 2016-02-07 11:30:27 --> Language Class Initialized
INFO - 2016-02-07 11:30:27 --> Loader Class Initialized
INFO - 2016-02-07 11:30:27 --> Helper loaded: url_helper
INFO - 2016-02-07 11:30:27 --> Helper loaded: file_helper
INFO - 2016-02-07 11:30:27 --> Helper loaded: date_helper
INFO - 2016-02-07 11:30:27 --> Helper loaded: form_helper
INFO - 2016-02-07 11:30:27 --> Database Driver Class Initialized
INFO - 2016-02-07 11:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:30:28 --> Controller Class Initialized
INFO - 2016-02-07 11:30:28 --> Model Class Initialized
INFO - 2016-02-07 11:30:28 --> Model Class Initialized
INFO - 2016-02-07 11:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:30:28 --> Pagination Class Initialized
INFO - 2016-02-07 11:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:30:28 --> Final output sent to browser
DEBUG - 2016-02-07 11:30:28 --> Total execution time: 1.1502
INFO - 2016-02-07 11:30:30 --> Config Class Initialized
INFO - 2016-02-07 11:30:30 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:30:30 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:30:30 --> Utf8 Class Initialized
INFO - 2016-02-07 11:30:30 --> URI Class Initialized
INFO - 2016-02-07 11:30:30 --> Router Class Initialized
INFO - 2016-02-07 11:30:30 --> Output Class Initialized
INFO - 2016-02-07 11:30:30 --> Security Class Initialized
DEBUG - 2016-02-07 11:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:30:30 --> Input Class Initialized
INFO - 2016-02-07 11:30:30 --> Language Class Initialized
INFO - 2016-02-07 11:30:30 --> Loader Class Initialized
INFO - 2016-02-07 11:30:30 --> Helper loaded: url_helper
INFO - 2016-02-07 11:30:30 --> Helper loaded: file_helper
INFO - 2016-02-07 11:30:30 --> Helper loaded: date_helper
INFO - 2016-02-07 11:30:30 --> Helper loaded: form_helper
INFO - 2016-02-07 11:30:30 --> Database Driver Class Initialized
INFO - 2016-02-07 11:30:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:30:31 --> Controller Class Initialized
INFO - 2016-02-07 11:30:31 --> Model Class Initialized
INFO - 2016-02-07 11:30:31 --> Model Class Initialized
INFO - 2016-02-07 11:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:30:31 --> Pagination Class Initialized
INFO - 2016-02-07 11:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:30:31 --> Helper loaded: text_helper
INFO - 2016-02-07 11:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:30:31 --> Final output sent to browser
DEBUG - 2016-02-07 11:30:31 --> Total execution time: 1.1890
INFO - 2016-02-07 11:30:38 --> Config Class Initialized
INFO - 2016-02-07 11:30:38 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:30:38 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:30:38 --> Utf8 Class Initialized
INFO - 2016-02-07 11:30:38 --> URI Class Initialized
INFO - 2016-02-07 11:30:38 --> Router Class Initialized
INFO - 2016-02-07 11:30:38 --> Output Class Initialized
INFO - 2016-02-07 11:30:38 --> Security Class Initialized
DEBUG - 2016-02-07 11:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:30:38 --> Input Class Initialized
INFO - 2016-02-07 11:30:38 --> Language Class Initialized
INFO - 2016-02-07 11:30:38 --> Loader Class Initialized
INFO - 2016-02-07 11:30:38 --> Helper loaded: url_helper
INFO - 2016-02-07 11:30:38 --> Helper loaded: file_helper
INFO - 2016-02-07 11:30:38 --> Helper loaded: date_helper
INFO - 2016-02-07 11:30:38 --> Helper loaded: form_helper
INFO - 2016-02-07 11:30:38 --> Database Driver Class Initialized
INFO - 2016-02-07 11:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:30:39 --> Controller Class Initialized
INFO - 2016-02-07 11:30:39 --> Model Class Initialized
INFO - 2016-02-07 11:30:39 --> Model Class Initialized
INFO - 2016-02-07 11:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:30:39 --> Pagination Class Initialized
INFO - 2016-02-07 11:30:39 --> Form Validation Class Initialized
INFO - 2016-02-07 11:30:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:30:39 --> Model Class Initialized
INFO - 2016-02-07 11:30:39 --> Final output sent to browser
DEBUG - 2016-02-07 11:30:39 --> Total execution time: 1.2442
INFO - 2016-02-07 11:32:26 --> Config Class Initialized
INFO - 2016-02-07 11:32:26 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:32:26 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:32:26 --> Utf8 Class Initialized
INFO - 2016-02-07 11:32:26 --> URI Class Initialized
DEBUG - 2016-02-07 11:32:26 --> No URI present. Default controller set.
INFO - 2016-02-07 11:32:26 --> Router Class Initialized
INFO - 2016-02-07 11:32:26 --> Output Class Initialized
INFO - 2016-02-07 11:32:26 --> Security Class Initialized
DEBUG - 2016-02-07 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:32:26 --> Input Class Initialized
INFO - 2016-02-07 11:32:26 --> Language Class Initialized
INFO - 2016-02-07 11:32:26 --> Loader Class Initialized
INFO - 2016-02-07 11:32:26 --> Helper loaded: url_helper
INFO - 2016-02-07 11:32:26 --> Helper loaded: file_helper
INFO - 2016-02-07 11:32:26 --> Helper loaded: date_helper
INFO - 2016-02-07 11:32:26 --> Helper loaded: form_helper
INFO - 2016-02-07 11:32:26 --> Database Driver Class Initialized
INFO - 2016-02-07 11:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:32:27 --> Controller Class Initialized
INFO - 2016-02-07 11:32:27 --> Model Class Initialized
INFO - 2016-02-07 11:32:27 --> Model Class Initialized
INFO - 2016-02-07 11:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:32:27 --> Pagination Class Initialized
INFO - 2016-02-07 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:32:27 --> Final output sent to browser
DEBUG - 2016-02-07 11:32:27 --> Total execution time: 1.1068
INFO - 2016-02-07 11:32:28 --> Config Class Initialized
INFO - 2016-02-07 11:32:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:32:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:32:28 --> Utf8 Class Initialized
INFO - 2016-02-07 11:32:28 --> URI Class Initialized
INFO - 2016-02-07 11:32:28 --> Router Class Initialized
INFO - 2016-02-07 11:32:28 --> Output Class Initialized
INFO - 2016-02-07 11:32:28 --> Security Class Initialized
DEBUG - 2016-02-07 11:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:32:28 --> Input Class Initialized
INFO - 2016-02-07 11:32:28 --> Language Class Initialized
INFO - 2016-02-07 11:32:28 --> Loader Class Initialized
INFO - 2016-02-07 11:32:28 --> Helper loaded: url_helper
INFO - 2016-02-07 11:32:28 --> Helper loaded: file_helper
INFO - 2016-02-07 11:32:28 --> Helper loaded: date_helper
INFO - 2016-02-07 11:32:28 --> Helper loaded: form_helper
INFO - 2016-02-07 11:32:28 --> Database Driver Class Initialized
INFO - 2016-02-07 11:32:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:32:29 --> Controller Class Initialized
INFO - 2016-02-07 11:32:29 --> Model Class Initialized
INFO - 2016-02-07 11:32:29 --> Model Class Initialized
INFO - 2016-02-07 11:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:32:29 --> Pagination Class Initialized
INFO - 2016-02-07 11:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:32:29 --> Helper loaded: text_helper
INFO - 2016-02-07 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:32:30 --> Final output sent to browser
DEBUG - 2016-02-07 11:32:30 --> Total execution time: 1.1666
INFO - 2016-02-07 11:32:36 --> Config Class Initialized
INFO - 2016-02-07 11:32:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:32:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:32:36 --> Utf8 Class Initialized
INFO - 2016-02-07 11:32:36 --> URI Class Initialized
INFO - 2016-02-07 11:32:36 --> Router Class Initialized
INFO - 2016-02-07 11:32:36 --> Output Class Initialized
INFO - 2016-02-07 11:32:36 --> Security Class Initialized
DEBUG - 2016-02-07 11:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:32:36 --> Input Class Initialized
INFO - 2016-02-07 11:32:36 --> Language Class Initialized
INFO - 2016-02-07 11:32:36 --> Loader Class Initialized
INFO - 2016-02-07 11:32:36 --> Helper loaded: url_helper
INFO - 2016-02-07 11:32:36 --> Helper loaded: file_helper
INFO - 2016-02-07 11:32:36 --> Helper loaded: date_helper
INFO - 2016-02-07 11:32:36 --> Helper loaded: form_helper
INFO - 2016-02-07 11:32:36 --> Database Driver Class Initialized
INFO - 2016-02-07 11:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:32:37 --> Controller Class Initialized
INFO - 2016-02-07 11:32:37 --> Model Class Initialized
INFO - 2016-02-07 11:32:37 --> Model Class Initialized
INFO - 2016-02-07 11:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:32:37 --> Pagination Class Initialized
INFO - 2016-02-07 11:32:37 --> Form Validation Class Initialized
INFO - 2016-02-07 11:32:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:32:37 --> Model Class Initialized
INFO - 2016-02-07 11:32:37 --> Final output sent to browser
DEBUG - 2016-02-07 11:32:37 --> Total execution time: 1.2318
INFO - 2016-02-07 11:33:38 --> Config Class Initialized
INFO - 2016-02-07 11:33:38 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:33:38 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:33:38 --> Utf8 Class Initialized
INFO - 2016-02-07 11:33:38 --> URI Class Initialized
INFO - 2016-02-07 11:33:38 --> Router Class Initialized
INFO - 2016-02-07 11:33:38 --> Output Class Initialized
INFO - 2016-02-07 11:33:38 --> Security Class Initialized
DEBUG - 2016-02-07 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:33:38 --> Input Class Initialized
INFO - 2016-02-07 11:33:38 --> Language Class Initialized
INFO - 2016-02-07 11:33:38 --> Loader Class Initialized
INFO - 2016-02-07 11:33:38 --> Helper loaded: url_helper
INFO - 2016-02-07 11:33:38 --> Helper loaded: file_helper
INFO - 2016-02-07 11:33:38 --> Helper loaded: date_helper
INFO - 2016-02-07 11:33:38 --> Helper loaded: form_helper
INFO - 2016-02-07 11:33:38 --> Database Driver Class Initialized
INFO - 2016-02-07 11:33:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:33:39 --> Controller Class Initialized
INFO - 2016-02-07 11:33:39 --> Model Class Initialized
INFO - 2016-02-07 11:33:39 --> Model Class Initialized
INFO - 2016-02-07 11:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:33:39 --> Pagination Class Initialized
INFO - 2016-02-07 11:33:39 --> Form Validation Class Initialized
INFO - 2016-02-07 11:33:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:33:39 --> Model Class Initialized
INFO - 2016-02-07 11:33:39 --> Final output sent to browser
DEBUG - 2016-02-07 11:33:39 --> Total execution time: 1.2167
INFO - 2016-02-07 11:34:56 --> Config Class Initialized
INFO - 2016-02-07 11:34:56 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:34:56 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:34:56 --> Utf8 Class Initialized
INFO - 2016-02-07 11:34:56 --> URI Class Initialized
DEBUG - 2016-02-07 11:34:56 --> No URI present. Default controller set.
INFO - 2016-02-07 11:34:56 --> Router Class Initialized
INFO - 2016-02-07 11:34:56 --> Output Class Initialized
INFO - 2016-02-07 11:34:56 --> Security Class Initialized
DEBUG - 2016-02-07 11:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:34:56 --> Input Class Initialized
INFO - 2016-02-07 11:34:56 --> Language Class Initialized
INFO - 2016-02-07 11:34:56 --> Loader Class Initialized
INFO - 2016-02-07 11:34:56 --> Helper loaded: url_helper
INFO - 2016-02-07 11:34:56 --> Helper loaded: file_helper
INFO - 2016-02-07 11:34:56 --> Helper loaded: date_helper
INFO - 2016-02-07 11:34:56 --> Helper loaded: form_helper
INFO - 2016-02-07 11:34:56 --> Database Driver Class Initialized
INFO - 2016-02-07 11:34:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:34:57 --> Controller Class Initialized
INFO - 2016-02-07 11:34:57 --> Model Class Initialized
INFO - 2016-02-07 11:34:57 --> Model Class Initialized
INFO - 2016-02-07 11:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:34:57 --> Pagination Class Initialized
INFO - 2016-02-07 11:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:34:57 --> Final output sent to browser
DEBUG - 2016-02-07 11:34:57 --> Total execution time: 1.1535
INFO - 2016-02-07 11:35:00 --> Config Class Initialized
INFO - 2016-02-07 11:35:00 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:35:00 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:35:00 --> Utf8 Class Initialized
INFO - 2016-02-07 11:35:00 --> URI Class Initialized
INFO - 2016-02-07 11:35:00 --> Router Class Initialized
INFO - 2016-02-07 11:35:00 --> Output Class Initialized
INFO - 2016-02-07 11:35:00 --> Security Class Initialized
DEBUG - 2016-02-07 11:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:35:00 --> Input Class Initialized
INFO - 2016-02-07 11:35:00 --> Language Class Initialized
INFO - 2016-02-07 11:35:00 --> Loader Class Initialized
INFO - 2016-02-07 11:35:00 --> Helper loaded: url_helper
INFO - 2016-02-07 11:35:00 --> Helper loaded: file_helper
INFO - 2016-02-07 11:35:00 --> Helper loaded: date_helper
INFO - 2016-02-07 11:35:00 --> Helper loaded: form_helper
INFO - 2016-02-07 11:35:00 --> Database Driver Class Initialized
INFO - 2016-02-07 11:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:35:01 --> Controller Class Initialized
INFO - 2016-02-07 11:35:01 --> Model Class Initialized
INFO - 2016-02-07 11:35:01 --> Model Class Initialized
INFO - 2016-02-07 11:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:35:01 --> Pagination Class Initialized
INFO - 2016-02-07 11:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:35:01 --> Helper loaded: text_helper
INFO - 2016-02-07 11:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:35:01 --> Final output sent to browser
DEBUG - 2016-02-07 11:35:01 --> Total execution time: 1.1972
INFO - 2016-02-07 11:35:08 --> Config Class Initialized
INFO - 2016-02-07 11:35:08 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:35:08 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:35:08 --> Utf8 Class Initialized
INFO - 2016-02-07 11:35:08 --> URI Class Initialized
INFO - 2016-02-07 11:35:08 --> Router Class Initialized
INFO - 2016-02-07 11:35:08 --> Output Class Initialized
INFO - 2016-02-07 11:35:08 --> Security Class Initialized
DEBUG - 2016-02-07 11:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:35:08 --> Input Class Initialized
INFO - 2016-02-07 11:35:08 --> Language Class Initialized
INFO - 2016-02-07 11:35:08 --> Loader Class Initialized
INFO - 2016-02-07 11:35:08 --> Helper loaded: url_helper
INFO - 2016-02-07 11:35:08 --> Helper loaded: file_helper
INFO - 2016-02-07 11:35:08 --> Helper loaded: date_helper
INFO - 2016-02-07 11:35:08 --> Helper loaded: form_helper
INFO - 2016-02-07 11:35:08 --> Database Driver Class Initialized
INFO - 2016-02-07 11:35:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:35:09 --> Controller Class Initialized
INFO - 2016-02-07 11:35:09 --> Model Class Initialized
INFO - 2016-02-07 11:35:09 --> Model Class Initialized
INFO - 2016-02-07 11:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:35:09 --> Pagination Class Initialized
INFO - 2016-02-07 11:35:09 --> Form Validation Class Initialized
INFO - 2016-02-07 11:35:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:35:09 --> Model Class Initialized
INFO - 2016-02-07 11:35:09 --> Final output sent to browser
DEBUG - 2016-02-07 11:35:09 --> Total execution time: 1.1873
INFO - 2016-02-07 11:41:09 --> Config Class Initialized
INFO - 2016-02-07 11:41:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:41:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:41:09 --> Utf8 Class Initialized
INFO - 2016-02-07 11:41:09 --> URI Class Initialized
DEBUG - 2016-02-07 11:41:09 --> No URI present. Default controller set.
INFO - 2016-02-07 11:41:09 --> Router Class Initialized
INFO - 2016-02-07 11:41:09 --> Output Class Initialized
INFO - 2016-02-07 11:41:09 --> Security Class Initialized
DEBUG - 2016-02-07 11:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:41:09 --> Input Class Initialized
INFO - 2016-02-07 11:41:09 --> Language Class Initialized
INFO - 2016-02-07 11:41:09 --> Loader Class Initialized
INFO - 2016-02-07 11:41:09 --> Helper loaded: url_helper
INFO - 2016-02-07 11:41:09 --> Helper loaded: file_helper
INFO - 2016-02-07 11:41:09 --> Helper loaded: date_helper
INFO - 2016-02-07 11:41:09 --> Helper loaded: form_helper
INFO - 2016-02-07 11:41:09 --> Database Driver Class Initialized
INFO - 2016-02-07 11:41:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:41:11 --> Controller Class Initialized
INFO - 2016-02-07 11:41:11 --> Model Class Initialized
INFO - 2016-02-07 11:41:11 --> Model Class Initialized
INFO - 2016-02-07 11:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:41:11 --> Pagination Class Initialized
INFO - 2016-02-07 11:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:41:11 --> Final output sent to browser
DEBUG - 2016-02-07 11:41:11 --> Total execution time: 1.1587
INFO - 2016-02-07 11:41:13 --> Config Class Initialized
INFO - 2016-02-07 11:41:13 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:41:13 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:41:13 --> Utf8 Class Initialized
INFO - 2016-02-07 11:41:13 --> URI Class Initialized
INFO - 2016-02-07 11:41:13 --> Router Class Initialized
INFO - 2016-02-07 11:41:13 --> Output Class Initialized
INFO - 2016-02-07 11:41:13 --> Security Class Initialized
DEBUG - 2016-02-07 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:41:13 --> Input Class Initialized
INFO - 2016-02-07 11:41:13 --> Language Class Initialized
INFO - 2016-02-07 11:41:13 --> Loader Class Initialized
INFO - 2016-02-07 11:41:13 --> Helper loaded: url_helper
INFO - 2016-02-07 11:41:13 --> Helper loaded: file_helper
INFO - 2016-02-07 11:41:13 --> Helper loaded: date_helper
INFO - 2016-02-07 11:41:13 --> Helper loaded: form_helper
INFO - 2016-02-07 11:41:13 --> Database Driver Class Initialized
INFO - 2016-02-07 11:41:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:41:14 --> Controller Class Initialized
INFO - 2016-02-07 11:41:14 --> Model Class Initialized
INFO - 2016-02-07 11:41:14 --> Model Class Initialized
INFO - 2016-02-07 11:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:41:14 --> Pagination Class Initialized
INFO - 2016-02-07 11:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:41:14 --> Helper loaded: text_helper
INFO - 2016-02-07 11:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:41:14 --> Final output sent to browser
DEBUG - 2016-02-07 11:41:14 --> Total execution time: 1.1828
INFO - 2016-02-07 11:41:23 --> Config Class Initialized
INFO - 2016-02-07 11:41:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:41:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:41:23 --> Utf8 Class Initialized
INFO - 2016-02-07 11:41:23 --> URI Class Initialized
INFO - 2016-02-07 11:41:23 --> Router Class Initialized
INFO - 2016-02-07 11:41:23 --> Output Class Initialized
INFO - 2016-02-07 11:41:23 --> Security Class Initialized
DEBUG - 2016-02-07 11:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:41:23 --> Input Class Initialized
INFO - 2016-02-07 11:41:23 --> Language Class Initialized
INFO - 2016-02-07 11:41:23 --> Loader Class Initialized
INFO - 2016-02-07 11:41:23 --> Helper loaded: url_helper
INFO - 2016-02-07 11:41:23 --> Helper loaded: file_helper
INFO - 2016-02-07 11:41:23 --> Helper loaded: date_helper
INFO - 2016-02-07 11:41:23 --> Helper loaded: form_helper
INFO - 2016-02-07 11:41:23 --> Database Driver Class Initialized
INFO - 2016-02-07 11:41:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:41:24 --> Controller Class Initialized
INFO - 2016-02-07 11:41:24 --> Model Class Initialized
INFO - 2016-02-07 11:41:24 --> Model Class Initialized
INFO - 2016-02-07 11:41:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:41:24 --> Pagination Class Initialized
INFO - 2016-02-07 11:41:24 --> Form Validation Class Initialized
INFO - 2016-02-07 11:41:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:41:24 --> Model Class Initialized
INFO - 2016-02-07 11:41:24 --> Final output sent to browser
DEBUG - 2016-02-07 11:41:24 --> Total execution time: 1.2167
INFO - 2016-02-07 11:43:29 --> Config Class Initialized
INFO - 2016-02-07 11:43:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:43:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:43:29 --> Utf8 Class Initialized
INFO - 2016-02-07 11:43:29 --> URI Class Initialized
INFO - 2016-02-07 11:43:29 --> Router Class Initialized
INFO - 2016-02-07 11:43:29 --> Output Class Initialized
INFO - 2016-02-07 11:43:29 --> Security Class Initialized
DEBUG - 2016-02-07 11:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:43:29 --> Input Class Initialized
INFO - 2016-02-07 11:43:29 --> Language Class Initialized
INFO - 2016-02-07 11:43:29 --> Loader Class Initialized
INFO - 2016-02-07 11:43:29 --> Helper loaded: url_helper
INFO - 2016-02-07 11:43:29 --> Helper loaded: file_helper
INFO - 2016-02-07 11:43:29 --> Helper loaded: date_helper
INFO - 2016-02-07 11:43:29 --> Helper loaded: form_helper
INFO - 2016-02-07 11:43:30 --> Database Driver Class Initialized
INFO - 2016-02-07 11:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:43:31 --> Controller Class Initialized
INFO - 2016-02-07 11:43:31 --> Model Class Initialized
INFO - 2016-02-07 11:43:31 --> Model Class Initialized
INFO - 2016-02-07 11:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:43:31 --> Pagination Class Initialized
INFO - 2016-02-07 11:43:31 --> Form Validation Class Initialized
INFO - 2016-02-07 11:43:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:43:31 --> Model Class Initialized
INFO - 2016-02-07 11:43:31 --> Final output sent to browser
DEBUG - 2016-02-07 11:43:31 --> Total execution time: 1.1880
INFO - 2016-02-07 11:44:03 --> Config Class Initialized
INFO - 2016-02-07 11:44:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:44:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:44:03 --> Utf8 Class Initialized
INFO - 2016-02-07 11:44:03 --> URI Class Initialized
INFO - 2016-02-07 11:44:03 --> Router Class Initialized
INFO - 2016-02-07 11:44:03 --> Output Class Initialized
INFO - 2016-02-07 11:44:03 --> Security Class Initialized
DEBUG - 2016-02-07 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:44:03 --> Input Class Initialized
INFO - 2016-02-07 11:44:03 --> Language Class Initialized
INFO - 2016-02-07 11:44:03 --> Loader Class Initialized
INFO - 2016-02-07 11:44:03 --> Helper loaded: url_helper
INFO - 2016-02-07 11:44:03 --> Helper loaded: file_helper
INFO - 2016-02-07 11:44:03 --> Helper loaded: date_helper
INFO - 2016-02-07 11:44:03 --> Helper loaded: form_helper
INFO - 2016-02-07 11:44:03 --> Database Driver Class Initialized
INFO - 2016-02-07 11:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:44:04 --> Controller Class Initialized
INFO - 2016-02-07 11:44:04 --> Model Class Initialized
INFO - 2016-02-07 11:44:04 --> Model Class Initialized
INFO - 2016-02-07 11:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:44:04 --> Pagination Class Initialized
INFO - 2016-02-07 11:44:04 --> Form Validation Class Initialized
INFO - 2016-02-07 11:44:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:44:04 --> Model Class Initialized
INFO - 2016-02-07 11:44:04 --> Final output sent to browser
DEBUG - 2016-02-07 11:44:04 --> Total execution time: 1.2025
INFO - 2016-02-07 11:47:13 --> Config Class Initialized
INFO - 2016-02-07 11:47:13 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:47:13 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:47:13 --> Utf8 Class Initialized
INFO - 2016-02-07 11:47:13 --> URI Class Initialized
INFO - 2016-02-07 11:47:13 --> Router Class Initialized
INFO - 2016-02-07 11:47:13 --> Output Class Initialized
INFO - 2016-02-07 11:47:13 --> Security Class Initialized
DEBUG - 2016-02-07 11:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:47:13 --> Input Class Initialized
INFO - 2016-02-07 11:47:13 --> Language Class Initialized
INFO - 2016-02-07 11:47:13 --> Loader Class Initialized
INFO - 2016-02-07 11:47:13 --> Helper loaded: url_helper
INFO - 2016-02-07 11:47:13 --> Helper loaded: file_helper
INFO - 2016-02-07 11:47:13 --> Helper loaded: date_helper
INFO - 2016-02-07 11:47:13 --> Helper loaded: form_helper
INFO - 2016-02-07 11:47:13 --> Database Driver Class Initialized
INFO - 2016-02-07 11:47:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:47:14 --> Controller Class Initialized
INFO - 2016-02-07 11:47:14 --> Model Class Initialized
INFO - 2016-02-07 11:47:14 --> Model Class Initialized
INFO - 2016-02-07 11:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:47:14 --> Pagination Class Initialized
INFO - 2016-02-07 11:47:14 --> Form Validation Class Initialized
INFO - 2016-02-07 11:47:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:47:14 --> Model Class Initialized
ERROR - 2016-02-07 11:47:14 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
ERROR - 2016-02-07 11:47:14 --> Severity: Error --> Cannot use object of type stdClass as array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 212
INFO - 2016-02-07 11:47:56 --> Config Class Initialized
INFO - 2016-02-07 11:47:56 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:47:56 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:47:56 --> Utf8 Class Initialized
INFO - 2016-02-07 11:47:56 --> URI Class Initialized
INFO - 2016-02-07 11:47:56 --> Router Class Initialized
INFO - 2016-02-07 11:47:56 --> Output Class Initialized
INFO - 2016-02-07 11:47:56 --> Security Class Initialized
DEBUG - 2016-02-07 11:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:47:56 --> Input Class Initialized
INFO - 2016-02-07 11:47:56 --> Language Class Initialized
INFO - 2016-02-07 11:47:56 --> Loader Class Initialized
INFO - 2016-02-07 11:47:56 --> Helper loaded: url_helper
INFO - 2016-02-07 11:47:56 --> Helper loaded: file_helper
INFO - 2016-02-07 11:47:56 --> Helper loaded: date_helper
INFO - 2016-02-07 11:47:56 --> Helper loaded: form_helper
INFO - 2016-02-07 11:47:56 --> Database Driver Class Initialized
INFO - 2016-02-07 11:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:47:57 --> Controller Class Initialized
INFO - 2016-02-07 11:47:57 --> Model Class Initialized
INFO - 2016-02-07 11:47:57 --> Model Class Initialized
INFO - 2016-02-07 11:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:47:57 --> Pagination Class Initialized
INFO - 2016-02-07 11:47:57 --> Form Validation Class Initialized
INFO - 2016-02-07 11:47:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:47:57 --> Model Class Initialized
ERROR - 2016-02-07 11:47:57 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
ERROR - 2016-02-07 11:47:57 --> Severity: Error --> Cannot use object of type stdClass as array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 212
INFO - 2016-02-07 11:49:03 --> Config Class Initialized
INFO - 2016-02-07 11:49:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:49:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:49:03 --> Utf8 Class Initialized
INFO - 2016-02-07 11:49:03 --> URI Class Initialized
INFO - 2016-02-07 11:49:03 --> Router Class Initialized
INFO - 2016-02-07 11:49:03 --> Output Class Initialized
INFO - 2016-02-07 11:49:03 --> Security Class Initialized
DEBUG - 2016-02-07 11:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:49:03 --> Input Class Initialized
INFO - 2016-02-07 11:49:03 --> Language Class Initialized
INFO - 2016-02-07 11:49:03 --> Loader Class Initialized
INFO - 2016-02-07 11:49:03 --> Helper loaded: url_helper
INFO - 2016-02-07 11:49:03 --> Helper loaded: file_helper
INFO - 2016-02-07 11:49:03 --> Helper loaded: date_helper
INFO - 2016-02-07 11:49:03 --> Helper loaded: form_helper
INFO - 2016-02-07 11:49:03 --> Database Driver Class Initialized
INFO - 2016-02-07 11:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:49:04 --> Controller Class Initialized
INFO - 2016-02-07 11:49:04 --> Model Class Initialized
INFO - 2016-02-07 11:49:04 --> Model Class Initialized
INFO - 2016-02-07 11:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:49:04 --> Pagination Class Initialized
INFO - 2016-02-07 11:49:04 --> Form Validation Class Initialized
INFO - 2016-02-07 11:49:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:49:04 --> Model Class Initialized
ERROR - 2016-02-07 11:49:04 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 210
ERROR - 2016-02-07 11:49:04 --> Severity: Error --> Cannot use object of type stdClass as array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 212
INFO - 2016-02-07 11:49:56 --> Config Class Initialized
INFO - 2016-02-07 11:49:56 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:49:56 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:49:56 --> Utf8 Class Initialized
INFO - 2016-02-07 11:49:56 --> URI Class Initialized
INFO - 2016-02-07 11:49:56 --> Router Class Initialized
INFO - 2016-02-07 11:49:56 --> Output Class Initialized
INFO - 2016-02-07 11:49:56 --> Security Class Initialized
DEBUG - 2016-02-07 11:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:49:56 --> Input Class Initialized
INFO - 2016-02-07 11:49:56 --> Language Class Initialized
INFO - 2016-02-07 11:49:56 --> Loader Class Initialized
INFO - 2016-02-07 11:49:56 --> Helper loaded: url_helper
INFO - 2016-02-07 11:49:56 --> Helper loaded: file_helper
INFO - 2016-02-07 11:49:56 --> Helper loaded: date_helper
INFO - 2016-02-07 11:49:56 --> Helper loaded: form_helper
INFO - 2016-02-07 11:49:56 --> Database Driver Class Initialized
INFO - 2016-02-07 11:49:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:49:57 --> Controller Class Initialized
INFO - 2016-02-07 11:49:57 --> Model Class Initialized
INFO - 2016-02-07 11:49:57 --> Model Class Initialized
INFO - 2016-02-07 11:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:49:57 --> Pagination Class Initialized
INFO - 2016-02-07 11:49:57 --> Form Validation Class Initialized
INFO - 2016-02-07 11:49:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:49:57 --> Model Class Initialized
ERROR - 2016-02-07 11:49:57 --> Severity: Notice --> Undefined index: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 213
INFO - 2016-02-07 11:49:57 --> Final output sent to browser
DEBUG - 2016-02-07 11:49:57 --> Total execution time: 1.2801
INFO - 2016-02-07 11:51:05 --> Config Class Initialized
INFO - 2016-02-07 11:51:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:51:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:51:05 --> Utf8 Class Initialized
INFO - 2016-02-07 11:51:05 --> URI Class Initialized
INFO - 2016-02-07 11:51:05 --> Router Class Initialized
INFO - 2016-02-07 11:51:05 --> Output Class Initialized
INFO - 2016-02-07 11:51:05 --> Security Class Initialized
DEBUG - 2016-02-07 11:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:51:05 --> Input Class Initialized
INFO - 2016-02-07 11:51:05 --> Language Class Initialized
INFO - 2016-02-07 11:51:05 --> Loader Class Initialized
INFO - 2016-02-07 11:51:05 --> Helper loaded: url_helper
INFO - 2016-02-07 11:51:05 --> Helper loaded: file_helper
INFO - 2016-02-07 11:51:05 --> Helper loaded: date_helper
INFO - 2016-02-07 11:51:05 --> Helper loaded: form_helper
INFO - 2016-02-07 11:51:05 --> Database Driver Class Initialized
INFO - 2016-02-07 11:51:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:51:06 --> Controller Class Initialized
INFO - 2016-02-07 11:51:06 --> Model Class Initialized
INFO - 2016-02-07 11:51:06 --> Model Class Initialized
INFO - 2016-02-07 11:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:51:06 --> Pagination Class Initialized
INFO - 2016-02-07 11:51:06 --> Form Validation Class Initialized
INFO - 2016-02-07 11:51:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:51:06 --> Model Class Initialized
INFO - 2016-02-07 11:51:06 --> Final output sent to browser
DEBUG - 2016-02-07 11:51:06 --> Total execution time: 1.2549
INFO - 2016-02-07 11:51:58 --> Config Class Initialized
INFO - 2016-02-07 11:51:58 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:51:58 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:51:58 --> Utf8 Class Initialized
INFO - 2016-02-07 11:51:58 --> URI Class Initialized
INFO - 2016-02-07 11:51:58 --> Router Class Initialized
INFO - 2016-02-07 11:51:58 --> Output Class Initialized
INFO - 2016-02-07 11:51:58 --> Security Class Initialized
DEBUG - 2016-02-07 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:51:58 --> Input Class Initialized
INFO - 2016-02-07 11:51:58 --> Language Class Initialized
INFO - 2016-02-07 11:51:58 --> Loader Class Initialized
INFO - 2016-02-07 11:51:58 --> Helper loaded: url_helper
INFO - 2016-02-07 11:51:58 --> Helper loaded: file_helper
INFO - 2016-02-07 11:51:58 --> Helper loaded: date_helper
INFO - 2016-02-07 11:51:58 --> Helper loaded: form_helper
INFO - 2016-02-07 11:51:58 --> Database Driver Class Initialized
INFO - 2016-02-07 11:51:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:51:59 --> Controller Class Initialized
INFO - 2016-02-07 11:51:59 --> Model Class Initialized
INFO - 2016-02-07 11:51:59 --> Model Class Initialized
INFO - 2016-02-07 11:51:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:51:59 --> Pagination Class Initialized
INFO - 2016-02-07 11:51:59 --> Form Validation Class Initialized
INFO - 2016-02-07 11:51:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:51:59 --> Model Class Initialized
INFO - 2016-02-07 11:51:59 --> Final output sent to browser
DEBUG - 2016-02-07 11:51:59 --> Total execution time: 1.2475
INFO - 2016-02-07 11:53:01 --> Config Class Initialized
INFO - 2016-02-07 11:53:01 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:53:01 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:53:01 --> Utf8 Class Initialized
INFO - 2016-02-07 11:53:01 --> URI Class Initialized
DEBUG - 2016-02-07 11:53:01 --> No URI present. Default controller set.
INFO - 2016-02-07 11:53:01 --> Router Class Initialized
INFO - 2016-02-07 11:53:01 --> Output Class Initialized
INFO - 2016-02-07 11:53:01 --> Security Class Initialized
DEBUG - 2016-02-07 11:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:53:01 --> Input Class Initialized
INFO - 2016-02-07 11:53:01 --> Language Class Initialized
INFO - 2016-02-07 11:53:01 --> Loader Class Initialized
INFO - 2016-02-07 11:53:01 --> Helper loaded: url_helper
INFO - 2016-02-07 11:53:01 --> Helper loaded: file_helper
INFO - 2016-02-07 11:53:01 --> Helper loaded: date_helper
INFO - 2016-02-07 11:53:01 --> Helper loaded: form_helper
INFO - 2016-02-07 11:53:01 --> Database Driver Class Initialized
INFO - 2016-02-07 11:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:53:02 --> Controller Class Initialized
INFO - 2016-02-07 11:53:02 --> Model Class Initialized
INFO - 2016-02-07 11:53:02 --> Model Class Initialized
INFO - 2016-02-07 11:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:53:02 --> Pagination Class Initialized
INFO - 2016-02-07 11:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 11:53:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:53:02 --> Final output sent to browser
DEBUG - 2016-02-07 11:53:02 --> Total execution time: 1.1420
INFO - 2016-02-07 11:53:05 --> Config Class Initialized
INFO - 2016-02-07 11:53:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:53:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:53:05 --> Utf8 Class Initialized
INFO - 2016-02-07 11:53:05 --> URI Class Initialized
INFO - 2016-02-07 11:53:05 --> Router Class Initialized
INFO - 2016-02-07 11:53:05 --> Output Class Initialized
INFO - 2016-02-07 11:53:05 --> Security Class Initialized
DEBUG - 2016-02-07 11:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:53:05 --> Input Class Initialized
INFO - 2016-02-07 11:53:05 --> Language Class Initialized
INFO - 2016-02-07 11:53:05 --> Loader Class Initialized
INFO - 2016-02-07 11:53:05 --> Helper loaded: url_helper
INFO - 2016-02-07 11:53:05 --> Helper loaded: file_helper
INFO - 2016-02-07 11:53:05 --> Helper loaded: date_helper
INFO - 2016-02-07 11:53:05 --> Helper loaded: form_helper
INFO - 2016-02-07 11:53:05 --> Database Driver Class Initialized
INFO - 2016-02-07 11:53:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:53:06 --> Controller Class Initialized
INFO - 2016-02-07 11:53:06 --> Model Class Initialized
INFO - 2016-02-07 11:53:06 --> Model Class Initialized
INFO - 2016-02-07 11:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:53:06 --> Pagination Class Initialized
INFO - 2016-02-07 11:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 11:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 11:53:06 --> Helper loaded: text_helper
INFO - 2016-02-07 11:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 11:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 11:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 11:53:06 --> Final output sent to browser
DEBUG - 2016-02-07 11:53:06 --> Total execution time: 1.1958
INFO - 2016-02-07 11:53:15 --> Config Class Initialized
INFO - 2016-02-07 11:53:15 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:53:15 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:53:15 --> Utf8 Class Initialized
INFO - 2016-02-07 11:53:15 --> URI Class Initialized
INFO - 2016-02-07 11:53:15 --> Router Class Initialized
INFO - 2016-02-07 11:53:15 --> Output Class Initialized
INFO - 2016-02-07 11:53:15 --> Security Class Initialized
DEBUG - 2016-02-07 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:53:15 --> Input Class Initialized
INFO - 2016-02-07 11:53:15 --> Language Class Initialized
INFO - 2016-02-07 11:53:15 --> Loader Class Initialized
INFO - 2016-02-07 11:53:15 --> Helper loaded: url_helper
INFO - 2016-02-07 11:53:15 --> Helper loaded: file_helper
INFO - 2016-02-07 11:53:15 --> Helper loaded: date_helper
INFO - 2016-02-07 11:53:15 --> Helper loaded: form_helper
INFO - 2016-02-07 11:53:15 --> Database Driver Class Initialized
INFO - 2016-02-07 11:53:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:53:16 --> Controller Class Initialized
INFO - 2016-02-07 11:53:16 --> Model Class Initialized
INFO - 2016-02-07 11:53:16 --> Model Class Initialized
INFO - 2016-02-07 11:53:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:53:16 --> Pagination Class Initialized
INFO - 2016-02-07 11:53:16 --> Form Validation Class Initialized
INFO - 2016-02-07 11:53:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:53:16 --> Model Class Initialized
INFO - 2016-02-07 11:53:16 --> Final output sent to browser
DEBUG - 2016-02-07 11:53:16 --> Total execution time: 1.2104
INFO - 2016-02-07 11:54:39 --> Config Class Initialized
INFO - 2016-02-07 11:54:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 11:54:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 11:54:39 --> Utf8 Class Initialized
INFO - 2016-02-07 11:54:39 --> URI Class Initialized
INFO - 2016-02-07 11:54:39 --> Router Class Initialized
INFO - 2016-02-07 11:54:39 --> Output Class Initialized
INFO - 2016-02-07 11:54:39 --> Security Class Initialized
DEBUG - 2016-02-07 11:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 11:54:39 --> Input Class Initialized
INFO - 2016-02-07 11:54:39 --> Language Class Initialized
INFO - 2016-02-07 11:54:39 --> Loader Class Initialized
INFO - 2016-02-07 11:54:39 --> Helper loaded: url_helper
INFO - 2016-02-07 11:54:39 --> Helper loaded: file_helper
INFO - 2016-02-07 11:54:39 --> Helper loaded: date_helper
INFO - 2016-02-07 11:54:39 --> Helper loaded: form_helper
INFO - 2016-02-07 11:54:39 --> Database Driver Class Initialized
INFO - 2016-02-07 11:54:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 11:54:40 --> Controller Class Initialized
INFO - 2016-02-07 11:54:40 --> Model Class Initialized
INFO - 2016-02-07 11:54:40 --> Model Class Initialized
INFO - 2016-02-07 11:54:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 11:54:40 --> Pagination Class Initialized
INFO - 2016-02-07 11:54:40 --> Form Validation Class Initialized
INFO - 2016-02-07 11:54:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 11:54:40 --> Model Class Initialized
INFO - 2016-02-07 11:54:40 --> Final output sent to browser
DEBUG - 2016-02-07 11:54:40 --> Total execution time: 1.2340
INFO - 2016-02-07 12:23:35 --> Config Class Initialized
INFO - 2016-02-07 12:23:35 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:23:35 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:23:35 --> Utf8 Class Initialized
INFO - 2016-02-07 12:23:35 --> URI Class Initialized
DEBUG - 2016-02-07 12:23:35 --> No URI present. Default controller set.
INFO - 2016-02-07 12:23:35 --> Router Class Initialized
INFO - 2016-02-07 12:23:35 --> Output Class Initialized
INFO - 2016-02-07 12:23:35 --> Security Class Initialized
DEBUG - 2016-02-07 12:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:23:35 --> Input Class Initialized
INFO - 2016-02-07 12:23:35 --> Language Class Initialized
INFO - 2016-02-07 12:23:35 --> Loader Class Initialized
INFO - 2016-02-07 12:23:35 --> Helper loaded: url_helper
INFO - 2016-02-07 12:23:35 --> Helper loaded: file_helper
INFO - 2016-02-07 12:23:35 --> Helper loaded: date_helper
INFO - 2016-02-07 12:23:35 --> Helper loaded: form_helper
INFO - 2016-02-07 12:23:35 --> Database Driver Class Initialized
INFO - 2016-02-07 12:23:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:23:36 --> Controller Class Initialized
INFO - 2016-02-07 12:23:36 --> Model Class Initialized
INFO - 2016-02-07 12:23:36 --> Model Class Initialized
INFO - 2016-02-07 12:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:23:36 --> Pagination Class Initialized
INFO - 2016-02-07 12:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 12:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:23:36 --> Final output sent to browser
DEBUG - 2016-02-07 12:23:36 --> Total execution time: 1.1783
INFO - 2016-02-07 12:23:39 --> Config Class Initialized
INFO - 2016-02-07 12:23:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:23:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:23:39 --> Utf8 Class Initialized
INFO - 2016-02-07 12:23:39 --> URI Class Initialized
INFO - 2016-02-07 12:23:39 --> Router Class Initialized
INFO - 2016-02-07 12:23:39 --> Output Class Initialized
INFO - 2016-02-07 12:23:39 --> Security Class Initialized
DEBUG - 2016-02-07 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:23:39 --> Input Class Initialized
INFO - 2016-02-07 12:23:39 --> Language Class Initialized
INFO - 2016-02-07 12:23:39 --> Loader Class Initialized
INFO - 2016-02-07 12:23:39 --> Helper loaded: url_helper
INFO - 2016-02-07 12:23:39 --> Helper loaded: file_helper
INFO - 2016-02-07 12:23:39 --> Helper loaded: date_helper
INFO - 2016-02-07 12:23:39 --> Helper loaded: form_helper
INFO - 2016-02-07 12:23:39 --> Database Driver Class Initialized
INFO - 2016-02-07 12:23:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:23:40 --> Controller Class Initialized
INFO - 2016-02-07 12:23:40 --> Model Class Initialized
INFO - 2016-02-07 12:23:40 --> Model Class Initialized
INFO - 2016-02-07 12:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:23:40 --> Pagination Class Initialized
INFO - 2016-02-07 12:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:23:40 --> Helper loaded: text_helper
INFO - 2016-02-07 12:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:23:40 --> Final output sent to browser
DEBUG - 2016-02-07 12:23:40 --> Total execution time: 1.1991
INFO - 2016-02-07 12:23:44 --> Config Class Initialized
INFO - 2016-02-07 12:23:44 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:23:44 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:23:44 --> Utf8 Class Initialized
INFO - 2016-02-07 12:23:44 --> URI Class Initialized
INFO - 2016-02-07 12:23:44 --> Router Class Initialized
INFO - 2016-02-07 12:23:44 --> Output Class Initialized
INFO - 2016-02-07 12:23:44 --> Security Class Initialized
DEBUG - 2016-02-07 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:23:44 --> Input Class Initialized
INFO - 2016-02-07 12:23:44 --> Language Class Initialized
INFO - 2016-02-07 12:23:44 --> Loader Class Initialized
INFO - 2016-02-07 12:23:44 --> Helper loaded: url_helper
INFO - 2016-02-07 12:23:44 --> Helper loaded: file_helper
INFO - 2016-02-07 12:23:44 --> Helper loaded: date_helper
INFO - 2016-02-07 12:23:44 --> Helper loaded: form_helper
INFO - 2016-02-07 12:23:44 --> Database Driver Class Initialized
INFO - 2016-02-07 12:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:23:45 --> Controller Class Initialized
INFO - 2016-02-07 12:23:45 --> Model Class Initialized
INFO - 2016-02-07 12:23:45 --> Model Class Initialized
INFO - 2016-02-07 12:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:23:45 --> Pagination Class Initialized
INFO - 2016-02-07 12:23:45 --> Form Validation Class Initialized
INFO - 2016-02-07 12:23:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:23:45 --> Model Class Initialized
INFO - 2016-02-07 12:23:46 --> Final output sent to browser
DEBUG - 2016-02-07 12:23:46 --> Total execution time: 1.2819
INFO - 2016-02-07 12:27:19 --> Config Class Initialized
INFO - 2016-02-07 12:27:19 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:27:19 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:27:19 --> Utf8 Class Initialized
INFO - 2016-02-07 12:27:19 --> URI Class Initialized
DEBUG - 2016-02-07 12:27:19 --> No URI present. Default controller set.
INFO - 2016-02-07 12:27:19 --> Router Class Initialized
INFO - 2016-02-07 12:27:19 --> Output Class Initialized
INFO - 2016-02-07 12:27:19 --> Security Class Initialized
DEBUG - 2016-02-07 12:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:27:19 --> Input Class Initialized
INFO - 2016-02-07 12:27:19 --> Language Class Initialized
INFO - 2016-02-07 12:27:19 --> Loader Class Initialized
INFO - 2016-02-07 12:27:19 --> Helper loaded: url_helper
INFO - 2016-02-07 12:27:19 --> Helper loaded: file_helper
INFO - 2016-02-07 12:27:19 --> Helper loaded: date_helper
INFO - 2016-02-07 12:27:19 --> Helper loaded: form_helper
INFO - 2016-02-07 12:27:19 --> Database Driver Class Initialized
INFO - 2016-02-07 12:27:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:27:20 --> Controller Class Initialized
INFO - 2016-02-07 12:27:20 --> Model Class Initialized
INFO - 2016-02-07 12:27:20 --> Model Class Initialized
INFO - 2016-02-07 12:27:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:27:20 --> Pagination Class Initialized
INFO - 2016-02-07 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:27:20 --> Final output sent to browser
DEBUG - 2016-02-07 12:27:20 --> Total execution time: 1.1525
INFO - 2016-02-07 12:27:24 --> Config Class Initialized
INFO - 2016-02-07 12:27:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:27:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:27:24 --> Utf8 Class Initialized
INFO - 2016-02-07 12:27:24 --> URI Class Initialized
INFO - 2016-02-07 12:27:24 --> Router Class Initialized
INFO - 2016-02-07 12:27:24 --> Output Class Initialized
INFO - 2016-02-07 12:27:24 --> Security Class Initialized
DEBUG - 2016-02-07 12:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:27:24 --> Input Class Initialized
INFO - 2016-02-07 12:27:24 --> Language Class Initialized
INFO - 2016-02-07 12:27:24 --> Loader Class Initialized
INFO - 2016-02-07 12:27:24 --> Helper loaded: url_helper
INFO - 2016-02-07 12:27:24 --> Helper loaded: file_helper
INFO - 2016-02-07 12:27:24 --> Helper loaded: date_helper
INFO - 2016-02-07 12:27:24 --> Helper loaded: form_helper
INFO - 2016-02-07 12:27:24 --> Database Driver Class Initialized
INFO - 2016-02-07 12:27:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:27:25 --> Controller Class Initialized
INFO - 2016-02-07 12:27:25 --> Model Class Initialized
INFO - 2016-02-07 12:27:25 --> Model Class Initialized
INFO - 2016-02-07 12:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:27:25 --> Pagination Class Initialized
INFO - 2016-02-07 12:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:27:25 --> Helper loaded: text_helper
INFO - 2016-02-07 12:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:27:25 --> Final output sent to browser
DEBUG - 2016-02-07 12:27:25 --> Total execution time: 1.1997
INFO - 2016-02-07 12:27:35 --> Config Class Initialized
INFO - 2016-02-07 12:27:35 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:27:35 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:27:35 --> Utf8 Class Initialized
INFO - 2016-02-07 12:27:35 --> URI Class Initialized
INFO - 2016-02-07 12:27:35 --> Router Class Initialized
INFO - 2016-02-07 12:27:35 --> Output Class Initialized
INFO - 2016-02-07 12:27:35 --> Security Class Initialized
DEBUG - 2016-02-07 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:27:35 --> Input Class Initialized
INFO - 2016-02-07 12:27:35 --> Language Class Initialized
INFO - 2016-02-07 12:27:35 --> Loader Class Initialized
INFO - 2016-02-07 12:27:35 --> Helper loaded: url_helper
INFO - 2016-02-07 12:27:35 --> Helper loaded: file_helper
INFO - 2016-02-07 12:27:35 --> Helper loaded: date_helper
INFO - 2016-02-07 12:27:35 --> Helper loaded: form_helper
INFO - 2016-02-07 12:27:35 --> Database Driver Class Initialized
INFO - 2016-02-07 12:27:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:27:36 --> Controller Class Initialized
INFO - 2016-02-07 12:27:36 --> Model Class Initialized
INFO - 2016-02-07 12:27:36 --> Model Class Initialized
INFO - 2016-02-07 12:27:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:27:36 --> Pagination Class Initialized
INFO - 2016-02-07 12:27:36 --> Form Validation Class Initialized
INFO - 2016-02-07 12:27:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:27:36 --> Model Class Initialized
INFO - 2016-02-07 12:27:36 --> Final output sent to browser
DEBUG - 2016-02-07 12:27:36 --> Total execution time: 1.1790
INFO - 2016-02-07 12:28:57 --> Config Class Initialized
INFO - 2016-02-07 12:28:57 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:28:57 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:28:57 --> Utf8 Class Initialized
INFO - 2016-02-07 12:28:57 --> URI Class Initialized
INFO - 2016-02-07 12:28:57 --> Router Class Initialized
INFO - 2016-02-07 12:28:57 --> Output Class Initialized
INFO - 2016-02-07 12:28:57 --> Security Class Initialized
DEBUG - 2016-02-07 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:28:57 --> Input Class Initialized
INFO - 2016-02-07 12:28:57 --> Language Class Initialized
INFO - 2016-02-07 12:28:57 --> Loader Class Initialized
INFO - 2016-02-07 12:28:57 --> Helper loaded: url_helper
INFO - 2016-02-07 12:28:57 --> Helper loaded: file_helper
INFO - 2016-02-07 12:28:57 --> Helper loaded: date_helper
INFO - 2016-02-07 12:28:57 --> Helper loaded: form_helper
INFO - 2016-02-07 12:28:57 --> Database Driver Class Initialized
INFO - 2016-02-07 12:28:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:28:58 --> Controller Class Initialized
INFO - 2016-02-07 12:28:59 --> Model Class Initialized
INFO - 2016-02-07 12:28:59 --> Model Class Initialized
INFO - 2016-02-07 12:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:28:59 --> Pagination Class Initialized
INFO - 2016-02-07 12:28:59 --> Form Validation Class Initialized
INFO - 2016-02-07 12:28:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:28:59 --> Model Class Initialized
INFO - 2016-02-07 12:28:59 --> Final output sent to browser
DEBUG - 2016-02-07 12:28:59 --> Total execution time: 1.2083
INFO - 2016-02-07 12:34:28 --> Config Class Initialized
INFO - 2016-02-07 12:34:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:34:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:34:28 --> Utf8 Class Initialized
INFO - 2016-02-07 12:34:28 --> URI Class Initialized
INFO - 2016-02-07 12:34:28 --> Router Class Initialized
INFO - 2016-02-07 12:34:28 --> Output Class Initialized
INFO - 2016-02-07 12:34:28 --> Security Class Initialized
DEBUG - 2016-02-07 12:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:34:28 --> Input Class Initialized
INFO - 2016-02-07 12:34:28 --> Language Class Initialized
INFO - 2016-02-07 12:34:28 --> Loader Class Initialized
INFO - 2016-02-07 12:34:28 --> Helper loaded: url_helper
INFO - 2016-02-07 12:34:28 --> Helper loaded: file_helper
INFO - 2016-02-07 12:34:28 --> Helper loaded: date_helper
INFO - 2016-02-07 12:34:28 --> Helper loaded: form_helper
INFO - 2016-02-07 12:34:28 --> Database Driver Class Initialized
INFO - 2016-02-07 12:34:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:34:29 --> Controller Class Initialized
INFO - 2016-02-07 12:34:29 --> Model Class Initialized
INFO - 2016-02-07 12:34:29 --> Model Class Initialized
INFO - 2016-02-07 12:34:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:34:29 --> Pagination Class Initialized
INFO - 2016-02-07 12:34:29 --> Form Validation Class Initialized
INFO - 2016-02-07 12:34:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:34:29 --> Model Class Initialized
INFO - 2016-02-07 12:34:29 --> Final output sent to browser
DEBUG - 2016-02-07 12:34:29 --> Total execution time: 1.2016
INFO - 2016-02-07 12:38:21 --> Config Class Initialized
INFO - 2016-02-07 12:38:21 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:38:21 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:38:21 --> Utf8 Class Initialized
INFO - 2016-02-07 12:38:21 --> URI Class Initialized
DEBUG - 2016-02-07 12:38:21 --> No URI present. Default controller set.
INFO - 2016-02-07 12:38:21 --> Router Class Initialized
INFO - 2016-02-07 12:38:21 --> Output Class Initialized
INFO - 2016-02-07 12:38:21 --> Security Class Initialized
DEBUG - 2016-02-07 12:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:38:21 --> Input Class Initialized
INFO - 2016-02-07 12:38:21 --> Language Class Initialized
INFO - 2016-02-07 12:38:21 --> Loader Class Initialized
INFO - 2016-02-07 12:38:21 --> Helper loaded: url_helper
INFO - 2016-02-07 12:38:21 --> Helper loaded: file_helper
INFO - 2016-02-07 12:38:21 --> Helper loaded: date_helper
INFO - 2016-02-07 12:38:21 --> Helper loaded: form_helper
INFO - 2016-02-07 12:38:21 --> Database Driver Class Initialized
INFO - 2016-02-07 12:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:38:22 --> Controller Class Initialized
INFO - 2016-02-07 12:38:22 --> Model Class Initialized
INFO - 2016-02-07 12:38:22 --> Model Class Initialized
INFO - 2016-02-07 12:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:38:22 --> Pagination Class Initialized
INFO - 2016-02-07 12:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 12:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:38:22 --> Final output sent to browser
DEBUG - 2016-02-07 12:38:22 --> Total execution time: 1.1244
INFO - 2016-02-07 12:38:23 --> Config Class Initialized
INFO - 2016-02-07 12:38:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:38:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:38:23 --> Utf8 Class Initialized
INFO - 2016-02-07 12:38:23 --> URI Class Initialized
INFO - 2016-02-07 12:38:23 --> Router Class Initialized
INFO - 2016-02-07 12:38:23 --> Output Class Initialized
INFO - 2016-02-07 12:38:23 --> Security Class Initialized
DEBUG - 2016-02-07 12:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:38:23 --> Input Class Initialized
INFO - 2016-02-07 12:38:23 --> Language Class Initialized
INFO - 2016-02-07 12:38:23 --> Loader Class Initialized
INFO - 2016-02-07 12:38:23 --> Helper loaded: url_helper
INFO - 2016-02-07 12:38:23 --> Helper loaded: file_helper
INFO - 2016-02-07 12:38:23 --> Helper loaded: date_helper
INFO - 2016-02-07 12:38:23 --> Helper loaded: form_helper
INFO - 2016-02-07 12:38:23 --> Database Driver Class Initialized
INFO - 2016-02-07 12:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:38:24 --> Controller Class Initialized
INFO - 2016-02-07 12:38:24 --> Model Class Initialized
INFO - 2016-02-07 12:38:24 --> Model Class Initialized
INFO - 2016-02-07 12:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:38:24 --> Pagination Class Initialized
INFO - 2016-02-07 12:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:38:24 --> Helper loaded: text_helper
INFO - 2016-02-07 12:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:38:24 --> Final output sent to browser
DEBUG - 2016-02-07 12:38:24 --> Total execution time: 1.1837
INFO - 2016-02-07 12:38:40 --> Config Class Initialized
INFO - 2016-02-07 12:38:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:38:40 --> Utf8 Class Initialized
INFO - 2016-02-07 12:38:40 --> URI Class Initialized
INFO - 2016-02-07 12:38:40 --> Router Class Initialized
INFO - 2016-02-07 12:38:40 --> Output Class Initialized
INFO - 2016-02-07 12:38:40 --> Security Class Initialized
DEBUG - 2016-02-07 12:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:38:40 --> Input Class Initialized
INFO - 2016-02-07 12:38:40 --> Language Class Initialized
INFO - 2016-02-07 12:38:40 --> Loader Class Initialized
INFO - 2016-02-07 12:38:40 --> Helper loaded: url_helper
INFO - 2016-02-07 12:38:40 --> Helper loaded: file_helper
INFO - 2016-02-07 12:38:40 --> Helper loaded: date_helper
INFO - 2016-02-07 12:38:40 --> Helper loaded: form_helper
INFO - 2016-02-07 12:38:40 --> Database Driver Class Initialized
INFO - 2016-02-07 12:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:38:41 --> Controller Class Initialized
INFO - 2016-02-07 12:38:41 --> Model Class Initialized
INFO - 2016-02-07 12:38:41 --> Model Class Initialized
INFO - 2016-02-07 12:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:38:41 --> Pagination Class Initialized
INFO - 2016-02-07 12:38:41 --> Form Validation Class Initialized
INFO - 2016-02-07 12:38:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:38:41 --> Model Class Initialized
INFO - 2016-02-07 12:38:41 --> Final output sent to browser
DEBUG - 2016-02-07 12:38:41 --> Total execution time: 1.1971
INFO - 2016-02-07 12:46:04 --> Config Class Initialized
INFO - 2016-02-07 12:46:04 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:46:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:46:05 --> Utf8 Class Initialized
INFO - 2016-02-07 12:46:05 --> URI Class Initialized
DEBUG - 2016-02-07 12:46:05 --> No URI present. Default controller set.
INFO - 2016-02-07 12:46:05 --> Router Class Initialized
INFO - 2016-02-07 12:46:05 --> Output Class Initialized
INFO - 2016-02-07 12:46:05 --> Security Class Initialized
DEBUG - 2016-02-07 12:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:46:05 --> Input Class Initialized
INFO - 2016-02-07 12:46:05 --> Language Class Initialized
INFO - 2016-02-07 12:46:05 --> Loader Class Initialized
INFO - 2016-02-07 12:46:05 --> Helper loaded: url_helper
INFO - 2016-02-07 12:46:05 --> Helper loaded: file_helper
INFO - 2016-02-07 12:46:05 --> Helper loaded: date_helper
INFO - 2016-02-07 12:46:05 --> Helper loaded: form_helper
INFO - 2016-02-07 12:46:05 --> Database Driver Class Initialized
INFO - 2016-02-07 12:46:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:46:06 --> Controller Class Initialized
INFO - 2016-02-07 12:46:06 --> Model Class Initialized
INFO - 2016-02-07 12:46:06 --> Model Class Initialized
INFO - 2016-02-07 12:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:46:06 --> Pagination Class Initialized
INFO - 2016-02-07 12:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 12:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:46:06 --> Final output sent to browser
DEBUG - 2016-02-07 12:46:06 --> Total execution time: 1.1484
INFO - 2016-02-07 12:46:07 --> Config Class Initialized
INFO - 2016-02-07 12:46:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:46:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:46:07 --> Utf8 Class Initialized
INFO - 2016-02-07 12:46:07 --> URI Class Initialized
INFO - 2016-02-07 12:46:07 --> Router Class Initialized
INFO - 2016-02-07 12:46:07 --> Output Class Initialized
INFO - 2016-02-07 12:46:07 --> Security Class Initialized
DEBUG - 2016-02-07 12:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:46:08 --> Input Class Initialized
INFO - 2016-02-07 12:46:08 --> Language Class Initialized
INFO - 2016-02-07 12:46:08 --> Loader Class Initialized
INFO - 2016-02-07 12:46:08 --> Helper loaded: url_helper
INFO - 2016-02-07 12:46:08 --> Helper loaded: file_helper
INFO - 2016-02-07 12:46:08 --> Helper loaded: date_helper
INFO - 2016-02-07 12:46:08 --> Helper loaded: form_helper
INFO - 2016-02-07 12:46:08 --> Database Driver Class Initialized
INFO - 2016-02-07 12:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:46:09 --> Controller Class Initialized
INFO - 2016-02-07 12:46:09 --> Model Class Initialized
INFO - 2016-02-07 12:46:09 --> Model Class Initialized
INFO - 2016-02-07 12:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:46:09 --> Pagination Class Initialized
INFO - 2016-02-07 12:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:46:09 --> Helper loaded: text_helper
INFO - 2016-02-07 12:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:46:09 --> Final output sent to browser
DEBUG - 2016-02-07 12:46:09 --> Total execution time: 1.2046
INFO - 2016-02-07 12:46:16 --> Config Class Initialized
INFO - 2016-02-07 12:46:16 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:46:16 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:46:16 --> Utf8 Class Initialized
INFO - 2016-02-07 12:46:16 --> URI Class Initialized
INFO - 2016-02-07 12:46:16 --> Router Class Initialized
INFO - 2016-02-07 12:46:16 --> Output Class Initialized
INFO - 2016-02-07 12:46:16 --> Security Class Initialized
DEBUG - 2016-02-07 12:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:46:16 --> Input Class Initialized
INFO - 2016-02-07 12:46:16 --> Language Class Initialized
INFO - 2016-02-07 12:46:16 --> Loader Class Initialized
INFO - 2016-02-07 12:46:16 --> Helper loaded: url_helper
INFO - 2016-02-07 12:46:16 --> Helper loaded: file_helper
INFO - 2016-02-07 12:46:16 --> Helper loaded: date_helper
INFO - 2016-02-07 12:46:16 --> Helper loaded: form_helper
INFO - 2016-02-07 12:46:16 --> Database Driver Class Initialized
INFO - 2016-02-07 12:46:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:46:17 --> Controller Class Initialized
INFO - 2016-02-07 12:46:17 --> Model Class Initialized
INFO - 2016-02-07 12:46:17 --> Model Class Initialized
INFO - 2016-02-07 12:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:46:17 --> Pagination Class Initialized
INFO - 2016-02-07 12:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:46:17 --> Helper loaded: text_helper
INFO - 2016-02-07 12:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:46:17 --> Final output sent to browser
DEBUG - 2016-02-07 12:46:17 --> Total execution time: 1.2042
INFO - 2016-02-07 12:50:33 --> Config Class Initialized
INFO - 2016-02-07 12:50:33 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:50:33 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:50:33 --> Utf8 Class Initialized
INFO - 2016-02-07 12:50:33 --> URI Class Initialized
DEBUG - 2016-02-07 12:50:33 --> No URI present. Default controller set.
INFO - 2016-02-07 12:50:33 --> Router Class Initialized
INFO - 2016-02-07 12:50:33 --> Output Class Initialized
INFO - 2016-02-07 12:50:33 --> Security Class Initialized
DEBUG - 2016-02-07 12:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:50:33 --> Input Class Initialized
INFO - 2016-02-07 12:50:33 --> Language Class Initialized
INFO - 2016-02-07 12:50:33 --> Loader Class Initialized
INFO - 2016-02-07 12:50:33 --> Helper loaded: url_helper
INFO - 2016-02-07 12:50:33 --> Helper loaded: file_helper
INFO - 2016-02-07 12:50:33 --> Helper loaded: date_helper
INFO - 2016-02-07 12:50:33 --> Helper loaded: form_helper
INFO - 2016-02-07 12:50:33 --> Database Driver Class Initialized
INFO - 2016-02-07 12:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:50:34 --> Controller Class Initialized
INFO - 2016-02-07 12:50:34 --> Model Class Initialized
INFO - 2016-02-07 12:50:34 --> Model Class Initialized
INFO - 2016-02-07 12:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:50:34 --> Pagination Class Initialized
INFO - 2016-02-07 12:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 12:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:50:34 --> Final output sent to browser
DEBUG - 2016-02-07 12:50:34 --> Total execution time: 1.1153
INFO - 2016-02-07 12:50:36 --> Config Class Initialized
INFO - 2016-02-07 12:50:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:50:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:50:36 --> Utf8 Class Initialized
INFO - 2016-02-07 12:50:36 --> URI Class Initialized
INFO - 2016-02-07 12:50:36 --> Router Class Initialized
INFO - 2016-02-07 12:50:36 --> Output Class Initialized
INFO - 2016-02-07 12:50:36 --> Security Class Initialized
DEBUG - 2016-02-07 12:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:50:36 --> Input Class Initialized
INFO - 2016-02-07 12:50:36 --> Language Class Initialized
INFO - 2016-02-07 12:50:36 --> Loader Class Initialized
INFO - 2016-02-07 12:50:36 --> Helper loaded: url_helper
INFO - 2016-02-07 12:50:36 --> Helper loaded: file_helper
INFO - 2016-02-07 12:50:36 --> Helper loaded: date_helper
INFO - 2016-02-07 12:50:36 --> Helper loaded: form_helper
INFO - 2016-02-07 12:50:36 --> Database Driver Class Initialized
INFO - 2016-02-07 12:50:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:50:37 --> Controller Class Initialized
INFO - 2016-02-07 12:50:37 --> Model Class Initialized
INFO - 2016-02-07 12:50:37 --> Model Class Initialized
INFO - 2016-02-07 12:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:50:37 --> Pagination Class Initialized
INFO - 2016-02-07 12:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 12:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 12:50:37 --> Helper loaded: text_helper
INFO - 2016-02-07 12:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 12:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 12:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 12:50:37 --> Final output sent to browser
DEBUG - 2016-02-07 12:50:37 --> Total execution time: 1.1978
INFO - 2016-02-07 12:50:43 --> Config Class Initialized
INFO - 2016-02-07 12:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-07 12:50:43 --> UTF-8 Support Enabled
INFO - 2016-02-07 12:50:43 --> Utf8 Class Initialized
INFO - 2016-02-07 12:50:43 --> URI Class Initialized
INFO - 2016-02-07 12:50:43 --> Router Class Initialized
INFO - 2016-02-07 12:50:43 --> Output Class Initialized
INFO - 2016-02-07 12:50:43 --> Security Class Initialized
DEBUG - 2016-02-07 12:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 12:50:43 --> Input Class Initialized
INFO - 2016-02-07 12:50:43 --> Language Class Initialized
INFO - 2016-02-07 12:50:43 --> Loader Class Initialized
INFO - 2016-02-07 12:50:43 --> Helper loaded: url_helper
INFO - 2016-02-07 12:50:43 --> Helper loaded: file_helper
INFO - 2016-02-07 12:50:43 --> Helper loaded: date_helper
INFO - 2016-02-07 12:50:43 --> Helper loaded: form_helper
INFO - 2016-02-07 12:50:43 --> Database Driver Class Initialized
INFO - 2016-02-07 12:50:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 12:50:44 --> Controller Class Initialized
INFO - 2016-02-07 12:50:44 --> Model Class Initialized
INFO - 2016-02-07 12:50:44 --> Model Class Initialized
INFO - 2016-02-07 12:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 12:50:44 --> Pagination Class Initialized
INFO - 2016-02-07 12:50:44 --> Form Validation Class Initialized
INFO - 2016-02-07 12:50:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 12:50:44 --> Model Class Initialized
INFO - 2016-02-07 12:50:44 --> Final output sent to browser
DEBUG - 2016-02-07 12:50:44 --> Total execution time: 1.1800
INFO - 2016-02-07 13:03:05 --> Config Class Initialized
INFO - 2016-02-07 13:03:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:03:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:03:05 --> Utf8 Class Initialized
INFO - 2016-02-07 13:03:05 --> URI Class Initialized
DEBUG - 2016-02-07 13:03:05 --> No URI present. Default controller set.
INFO - 2016-02-07 13:03:05 --> Router Class Initialized
INFO - 2016-02-07 13:03:05 --> Output Class Initialized
INFO - 2016-02-07 13:03:05 --> Security Class Initialized
DEBUG - 2016-02-07 13:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:03:05 --> Input Class Initialized
INFO - 2016-02-07 13:03:05 --> Language Class Initialized
INFO - 2016-02-07 13:03:05 --> Loader Class Initialized
INFO - 2016-02-07 13:03:05 --> Helper loaded: url_helper
INFO - 2016-02-07 13:03:05 --> Helper loaded: file_helper
INFO - 2016-02-07 13:03:05 --> Helper loaded: date_helper
INFO - 2016-02-07 13:03:05 --> Helper loaded: form_helper
INFO - 2016-02-07 13:03:05 --> Database Driver Class Initialized
INFO - 2016-02-07 13:03:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:03:06 --> Controller Class Initialized
INFO - 2016-02-07 13:03:06 --> Model Class Initialized
INFO - 2016-02-07 13:03:06 --> Model Class Initialized
INFO - 2016-02-07 13:03:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:03:06 --> Pagination Class Initialized
INFO - 2016-02-07 13:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 13:03:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:03:06 --> Final output sent to browser
DEBUG - 2016-02-07 13:03:06 --> Total execution time: 1.1363
INFO - 2016-02-07 13:03:08 --> Config Class Initialized
INFO - 2016-02-07 13:03:08 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:03:08 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:03:08 --> Utf8 Class Initialized
INFO - 2016-02-07 13:03:08 --> URI Class Initialized
INFO - 2016-02-07 13:03:08 --> Router Class Initialized
INFO - 2016-02-07 13:03:08 --> Output Class Initialized
INFO - 2016-02-07 13:03:08 --> Security Class Initialized
DEBUG - 2016-02-07 13:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:03:08 --> Input Class Initialized
INFO - 2016-02-07 13:03:08 --> Language Class Initialized
INFO - 2016-02-07 13:03:08 --> Loader Class Initialized
INFO - 2016-02-07 13:03:08 --> Helper loaded: url_helper
INFO - 2016-02-07 13:03:08 --> Helper loaded: file_helper
INFO - 2016-02-07 13:03:08 --> Helper loaded: date_helper
INFO - 2016-02-07 13:03:08 --> Helper loaded: form_helper
INFO - 2016-02-07 13:03:08 --> Database Driver Class Initialized
INFO - 2016-02-07 13:03:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:03:09 --> Controller Class Initialized
INFO - 2016-02-07 13:03:09 --> Model Class Initialized
INFO - 2016-02-07 13:03:09 --> Model Class Initialized
INFO - 2016-02-07 13:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:03:09 --> Pagination Class Initialized
INFO - 2016-02-07 13:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:03:09 --> Helper loaded: text_helper
INFO - 2016-02-07 13:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:03:09 --> Final output sent to browser
DEBUG - 2016-02-07 13:03:09 --> Total execution time: 1.2020
INFO - 2016-02-07 13:05:55 --> Config Class Initialized
INFO - 2016-02-07 13:05:55 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:05:55 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:05:56 --> Utf8 Class Initialized
INFO - 2016-02-07 13:05:56 --> URI Class Initialized
INFO - 2016-02-07 13:05:56 --> Router Class Initialized
INFO - 2016-02-07 13:05:56 --> Output Class Initialized
INFO - 2016-02-07 13:05:56 --> Security Class Initialized
DEBUG - 2016-02-07 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:05:56 --> Input Class Initialized
INFO - 2016-02-07 13:05:56 --> Language Class Initialized
INFO - 2016-02-07 13:05:56 --> Loader Class Initialized
INFO - 2016-02-07 13:05:56 --> Helper loaded: url_helper
INFO - 2016-02-07 13:05:56 --> Helper loaded: file_helper
INFO - 2016-02-07 13:05:56 --> Helper loaded: date_helper
INFO - 2016-02-07 13:05:56 --> Helper loaded: form_helper
INFO - 2016-02-07 13:05:56 --> Database Driver Class Initialized
INFO - 2016-02-07 13:05:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:05:57 --> Controller Class Initialized
INFO - 2016-02-07 13:05:57 --> Model Class Initialized
INFO - 2016-02-07 13:05:57 --> Model Class Initialized
INFO - 2016-02-07 13:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:05:57 --> Pagination Class Initialized
INFO - 2016-02-07 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:05:57 --> Helper loaded: text_helper
INFO - 2016-02-07 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:05:57 --> Final output sent to browser
DEBUG - 2016-02-07 13:05:57 --> Total execution time: 1.1886
INFO - 2016-02-07 13:06:19 --> Config Class Initialized
INFO - 2016-02-07 13:06:19 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:06:19 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:06:19 --> Utf8 Class Initialized
INFO - 2016-02-07 13:06:19 --> URI Class Initialized
INFO - 2016-02-07 13:06:19 --> Router Class Initialized
INFO - 2016-02-07 13:06:19 --> Output Class Initialized
INFO - 2016-02-07 13:06:19 --> Security Class Initialized
DEBUG - 2016-02-07 13:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:06:19 --> Input Class Initialized
INFO - 2016-02-07 13:06:19 --> Language Class Initialized
INFO - 2016-02-07 13:06:19 --> Loader Class Initialized
INFO - 2016-02-07 13:06:19 --> Helper loaded: url_helper
INFO - 2016-02-07 13:06:19 --> Helper loaded: file_helper
INFO - 2016-02-07 13:06:19 --> Helper loaded: date_helper
INFO - 2016-02-07 13:06:19 --> Helper loaded: form_helper
INFO - 2016-02-07 13:06:19 --> Database Driver Class Initialized
INFO - 2016-02-07 13:06:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:06:20 --> Controller Class Initialized
INFO - 2016-02-07 13:06:20 --> Model Class Initialized
INFO - 2016-02-07 13:06:20 --> Model Class Initialized
INFO - 2016-02-07 13:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:06:20 --> Pagination Class Initialized
INFO - 2016-02-07 13:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:06:20 --> Helper loaded: text_helper
INFO - 2016-02-07 13:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:06:20 --> Final output sent to browser
DEBUG - 2016-02-07 13:06:20 --> Total execution time: 1.2299
INFO - 2016-02-07 13:06:27 --> Config Class Initialized
INFO - 2016-02-07 13:06:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:06:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:06:27 --> Utf8 Class Initialized
INFO - 2016-02-07 13:06:27 --> URI Class Initialized
INFO - 2016-02-07 13:06:27 --> Router Class Initialized
INFO - 2016-02-07 13:06:27 --> Output Class Initialized
INFO - 2016-02-07 13:06:27 --> Security Class Initialized
DEBUG - 2016-02-07 13:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:06:27 --> Input Class Initialized
INFO - 2016-02-07 13:06:27 --> Language Class Initialized
INFO - 2016-02-07 13:06:27 --> Loader Class Initialized
INFO - 2016-02-07 13:06:27 --> Helper loaded: url_helper
INFO - 2016-02-07 13:06:27 --> Helper loaded: file_helper
INFO - 2016-02-07 13:06:27 --> Helper loaded: date_helper
INFO - 2016-02-07 13:06:27 --> Helper loaded: form_helper
INFO - 2016-02-07 13:06:27 --> Database Driver Class Initialized
INFO - 2016-02-07 13:06:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:06:28 --> Controller Class Initialized
INFO - 2016-02-07 13:06:28 --> Model Class Initialized
INFO - 2016-02-07 13:06:28 --> Model Class Initialized
INFO - 2016-02-07 13:06:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:06:28 --> Pagination Class Initialized
INFO - 2016-02-07 13:06:28 --> Form Validation Class Initialized
INFO - 2016-02-07 13:06:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:06:28 --> Model Class Initialized
INFO - 2016-02-07 13:06:28 --> Final output sent to browser
DEBUG - 2016-02-07 13:06:28 --> Total execution time: 1.2013
INFO - 2016-02-07 13:07:07 --> Config Class Initialized
INFO - 2016-02-07 13:07:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:07:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:07:07 --> Utf8 Class Initialized
INFO - 2016-02-07 13:07:07 --> URI Class Initialized
INFO - 2016-02-07 13:07:07 --> Router Class Initialized
INFO - 2016-02-07 13:07:07 --> Output Class Initialized
INFO - 2016-02-07 13:07:07 --> Security Class Initialized
DEBUG - 2016-02-07 13:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:07:07 --> Input Class Initialized
INFO - 2016-02-07 13:07:07 --> Language Class Initialized
INFO - 2016-02-07 13:07:07 --> Loader Class Initialized
INFO - 2016-02-07 13:07:07 --> Helper loaded: url_helper
INFO - 2016-02-07 13:07:07 --> Helper loaded: file_helper
INFO - 2016-02-07 13:07:07 --> Helper loaded: date_helper
INFO - 2016-02-07 13:07:07 --> Helper loaded: form_helper
INFO - 2016-02-07 13:07:07 --> Database Driver Class Initialized
INFO - 2016-02-07 13:07:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:07:08 --> Controller Class Initialized
INFO - 2016-02-07 13:07:08 --> Model Class Initialized
INFO - 2016-02-07 13:07:08 --> Model Class Initialized
INFO - 2016-02-07 13:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:07:08 --> Pagination Class Initialized
INFO - 2016-02-07 13:07:08 --> Form Validation Class Initialized
INFO - 2016-02-07 13:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:07:08 --> Model Class Initialized
INFO - 2016-02-07 13:07:08 --> Final output sent to browser
DEBUG - 2016-02-07 13:07:08 --> Total execution time: 1.2076
INFO - 2016-02-07 13:08:11 --> Config Class Initialized
INFO - 2016-02-07 13:08:11 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:08:11 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:08:11 --> Utf8 Class Initialized
INFO - 2016-02-07 13:08:11 --> URI Class Initialized
DEBUG - 2016-02-07 13:08:11 --> No URI present. Default controller set.
INFO - 2016-02-07 13:08:11 --> Router Class Initialized
INFO - 2016-02-07 13:08:11 --> Output Class Initialized
INFO - 2016-02-07 13:08:11 --> Security Class Initialized
DEBUG - 2016-02-07 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:08:11 --> Input Class Initialized
INFO - 2016-02-07 13:08:11 --> Language Class Initialized
INFO - 2016-02-07 13:08:11 --> Loader Class Initialized
INFO - 2016-02-07 13:08:11 --> Helper loaded: url_helper
INFO - 2016-02-07 13:08:11 --> Helper loaded: file_helper
INFO - 2016-02-07 13:08:11 --> Helper loaded: date_helper
INFO - 2016-02-07 13:08:11 --> Helper loaded: form_helper
INFO - 2016-02-07 13:08:11 --> Database Driver Class Initialized
INFO - 2016-02-07 13:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:08:12 --> Controller Class Initialized
INFO - 2016-02-07 13:08:12 --> Model Class Initialized
INFO - 2016-02-07 13:08:12 --> Model Class Initialized
INFO - 2016-02-07 13:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:08:12 --> Pagination Class Initialized
INFO - 2016-02-07 13:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 13:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:08:12 --> Final output sent to browser
DEBUG - 2016-02-07 13:08:12 --> Total execution time: 1.1529
INFO - 2016-02-07 13:08:15 --> Config Class Initialized
INFO - 2016-02-07 13:08:15 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:08:15 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:08:15 --> Utf8 Class Initialized
INFO - 2016-02-07 13:08:15 --> URI Class Initialized
INFO - 2016-02-07 13:08:15 --> Router Class Initialized
INFO - 2016-02-07 13:08:15 --> Output Class Initialized
INFO - 2016-02-07 13:08:15 --> Security Class Initialized
DEBUG - 2016-02-07 13:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:08:15 --> Input Class Initialized
INFO - 2016-02-07 13:08:15 --> Language Class Initialized
INFO - 2016-02-07 13:08:15 --> Loader Class Initialized
INFO - 2016-02-07 13:08:15 --> Helper loaded: url_helper
INFO - 2016-02-07 13:08:15 --> Helper loaded: file_helper
INFO - 2016-02-07 13:08:15 --> Helper loaded: date_helper
INFO - 2016-02-07 13:08:15 --> Helper loaded: form_helper
INFO - 2016-02-07 13:08:15 --> Database Driver Class Initialized
INFO - 2016-02-07 13:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:08:16 --> Controller Class Initialized
INFO - 2016-02-07 13:08:16 --> Model Class Initialized
INFO - 2016-02-07 13:08:16 --> Model Class Initialized
INFO - 2016-02-07 13:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:08:16 --> Pagination Class Initialized
INFO - 2016-02-07 13:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:08:16 --> Helper loaded: text_helper
INFO - 2016-02-07 13:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:08:16 --> Final output sent to browser
DEBUG - 2016-02-07 13:08:16 --> Total execution time: 1.1648
INFO - 2016-02-07 13:08:27 --> Config Class Initialized
INFO - 2016-02-07 13:08:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:08:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:08:27 --> Utf8 Class Initialized
INFO - 2016-02-07 13:08:27 --> URI Class Initialized
INFO - 2016-02-07 13:08:27 --> Router Class Initialized
INFO - 2016-02-07 13:08:27 --> Output Class Initialized
INFO - 2016-02-07 13:08:27 --> Security Class Initialized
DEBUG - 2016-02-07 13:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:08:27 --> Input Class Initialized
INFO - 2016-02-07 13:08:27 --> Language Class Initialized
INFO - 2016-02-07 13:08:27 --> Loader Class Initialized
INFO - 2016-02-07 13:08:27 --> Helper loaded: url_helper
INFO - 2016-02-07 13:08:27 --> Helper loaded: file_helper
INFO - 2016-02-07 13:08:27 --> Helper loaded: date_helper
INFO - 2016-02-07 13:08:27 --> Helper loaded: form_helper
INFO - 2016-02-07 13:08:27 --> Database Driver Class Initialized
INFO - 2016-02-07 13:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:08:28 --> Controller Class Initialized
INFO - 2016-02-07 13:08:28 --> Model Class Initialized
INFO - 2016-02-07 13:08:28 --> Model Class Initialized
INFO - 2016-02-07 13:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:08:28 --> Pagination Class Initialized
INFO - 2016-02-07 13:08:28 --> Form Validation Class Initialized
INFO - 2016-02-07 13:08:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:08:28 --> Model Class Initialized
INFO - 2016-02-07 13:08:28 --> Final output sent to browser
DEBUG - 2016-02-07 13:08:28 --> Total execution time: 1.2574
INFO - 2016-02-07 13:09:13 --> Config Class Initialized
INFO - 2016-02-07 13:09:13 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:09:13 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:09:13 --> Utf8 Class Initialized
INFO - 2016-02-07 13:09:13 --> URI Class Initialized
DEBUG - 2016-02-07 13:09:13 --> No URI present. Default controller set.
INFO - 2016-02-07 13:09:13 --> Router Class Initialized
INFO - 2016-02-07 13:09:13 --> Output Class Initialized
INFO - 2016-02-07 13:09:13 --> Security Class Initialized
DEBUG - 2016-02-07 13:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:09:13 --> Input Class Initialized
INFO - 2016-02-07 13:09:13 --> Language Class Initialized
INFO - 2016-02-07 13:09:13 --> Loader Class Initialized
INFO - 2016-02-07 13:09:13 --> Helper loaded: url_helper
INFO - 2016-02-07 13:09:13 --> Helper loaded: file_helper
INFO - 2016-02-07 13:09:13 --> Helper loaded: date_helper
INFO - 2016-02-07 13:09:13 --> Helper loaded: form_helper
INFO - 2016-02-07 13:09:13 --> Database Driver Class Initialized
INFO - 2016-02-07 13:09:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:09:14 --> Controller Class Initialized
INFO - 2016-02-07 13:09:14 --> Model Class Initialized
INFO - 2016-02-07 13:09:14 --> Model Class Initialized
INFO - 2016-02-07 13:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:09:14 --> Pagination Class Initialized
INFO - 2016-02-07 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:09:14 --> Final output sent to browser
DEBUG - 2016-02-07 13:09:14 --> Total execution time: 1.1501
INFO - 2016-02-07 13:09:17 --> Config Class Initialized
INFO - 2016-02-07 13:09:17 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:09:17 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:09:17 --> Utf8 Class Initialized
INFO - 2016-02-07 13:09:17 --> URI Class Initialized
INFO - 2016-02-07 13:09:17 --> Router Class Initialized
INFO - 2016-02-07 13:09:17 --> Output Class Initialized
INFO - 2016-02-07 13:09:17 --> Security Class Initialized
DEBUG - 2016-02-07 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:09:17 --> Input Class Initialized
INFO - 2016-02-07 13:09:17 --> Language Class Initialized
INFO - 2016-02-07 13:09:17 --> Loader Class Initialized
INFO - 2016-02-07 13:09:17 --> Helper loaded: url_helper
INFO - 2016-02-07 13:09:17 --> Helper loaded: file_helper
INFO - 2016-02-07 13:09:17 --> Helper loaded: date_helper
INFO - 2016-02-07 13:09:17 --> Helper loaded: form_helper
INFO - 2016-02-07 13:09:17 --> Database Driver Class Initialized
INFO - 2016-02-07 13:09:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:09:18 --> Controller Class Initialized
INFO - 2016-02-07 13:09:18 --> Model Class Initialized
INFO - 2016-02-07 13:09:18 --> Model Class Initialized
INFO - 2016-02-07 13:09:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:09:18 --> Pagination Class Initialized
INFO - 2016-02-07 13:09:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:09:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:09:18 --> Helper loaded: text_helper
INFO - 2016-02-07 13:09:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:09:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:09:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:09:18 --> Final output sent to browser
DEBUG - 2016-02-07 13:09:18 --> Total execution time: 1.2969
INFO - 2016-02-07 13:09:25 --> Config Class Initialized
INFO - 2016-02-07 13:09:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:09:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:09:25 --> Utf8 Class Initialized
INFO - 2016-02-07 13:09:25 --> URI Class Initialized
INFO - 2016-02-07 13:09:25 --> Router Class Initialized
INFO - 2016-02-07 13:09:25 --> Output Class Initialized
INFO - 2016-02-07 13:09:25 --> Security Class Initialized
DEBUG - 2016-02-07 13:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:09:25 --> Input Class Initialized
INFO - 2016-02-07 13:09:25 --> Language Class Initialized
INFO - 2016-02-07 13:09:25 --> Loader Class Initialized
INFO - 2016-02-07 13:09:25 --> Helper loaded: url_helper
INFO - 2016-02-07 13:09:25 --> Helper loaded: file_helper
INFO - 2016-02-07 13:09:25 --> Helper loaded: date_helper
INFO - 2016-02-07 13:09:25 --> Helper loaded: form_helper
INFO - 2016-02-07 13:09:25 --> Database Driver Class Initialized
INFO - 2016-02-07 13:09:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:09:26 --> Controller Class Initialized
INFO - 2016-02-07 13:09:26 --> Model Class Initialized
INFO - 2016-02-07 13:09:26 --> Model Class Initialized
INFO - 2016-02-07 13:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:09:27 --> Pagination Class Initialized
INFO - 2016-02-07 13:09:27 --> Form Validation Class Initialized
INFO - 2016-02-07 13:09:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:09:27 --> Model Class Initialized
INFO - 2016-02-07 13:09:27 --> Final output sent to browser
DEBUG - 2016-02-07 13:09:27 --> Total execution time: 1.3944
INFO - 2016-02-07 13:10:25 --> Config Class Initialized
INFO - 2016-02-07 13:10:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:10:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:10:25 --> Utf8 Class Initialized
INFO - 2016-02-07 13:10:25 --> URI Class Initialized
DEBUG - 2016-02-07 13:10:25 --> No URI present. Default controller set.
INFO - 2016-02-07 13:10:25 --> Router Class Initialized
INFO - 2016-02-07 13:10:25 --> Output Class Initialized
INFO - 2016-02-07 13:10:25 --> Security Class Initialized
DEBUG - 2016-02-07 13:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:10:25 --> Input Class Initialized
INFO - 2016-02-07 13:10:25 --> Language Class Initialized
INFO - 2016-02-07 13:10:25 --> Loader Class Initialized
INFO - 2016-02-07 13:10:25 --> Helper loaded: url_helper
INFO - 2016-02-07 13:10:25 --> Helper loaded: file_helper
INFO - 2016-02-07 13:10:25 --> Helper loaded: date_helper
INFO - 2016-02-07 13:10:25 --> Helper loaded: form_helper
INFO - 2016-02-07 13:10:25 --> Database Driver Class Initialized
INFO - 2016-02-07 13:10:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:10:26 --> Controller Class Initialized
INFO - 2016-02-07 13:10:26 --> Model Class Initialized
INFO - 2016-02-07 13:10:26 --> Model Class Initialized
INFO - 2016-02-07 13:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:10:26 --> Pagination Class Initialized
INFO - 2016-02-07 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:10:26 --> Final output sent to browser
DEBUG - 2016-02-07 13:10:26 --> Total execution time: 1.1317
INFO - 2016-02-07 13:10:29 --> Config Class Initialized
INFO - 2016-02-07 13:10:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:10:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:10:29 --> Utf8 Class Initialized
INFO - 2016-02-07 13:10:29 --> URI Class Initialized
INFO - 2016-02-07 13:10:29 --> Router Class Initialized
INFO - 2016-02-07 13:10:29 --> Output Class Initialized
INFO - 2016-02-07 13:10:29 --> Security Class Initialized
DEBUG - 2016-02-07 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:10:29 --> Input Class Initialized
INFO - 2016-02-07 13:10:29 --> Language Class Initialized
INFO - 2016-02-07 13:10:29 --> Loader Class Initialized
INFO - 2016-02-07 13:10:29 --> Helper loaded: url_helper
INFO - 2016-02-07 13:10:29 --> Helper loaded: file_helper
INFO - 2016-02-07 13:10:29 --> Helper loaded: date_helper
INFO - 2016-02-07 13:10:29 --> Helper loaded: form_helper
INFO - 2016-02-07 13:10:29 --> Database Driver Class Initialized
INFO - 2016-02-07 13:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:10:30 --> Controller Class Initialized
INFO - 2016-02-07 13:10:30 --> Model Class Initialized
INFO - 2016-02-07 13:10:30 --> Model Class Initialized
INFO - 2016-02-07 13:10:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:10:30 --> Pagination Class Initialized
INFO - 2016-02-07 13:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:10:30 --> Helper loaded: text_helper
INFO - 2016-02-07 13:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 13:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 13:10:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:10:30 --> Final output sent to browser
DEBUG - 2016-02-07 13:10:30 --> Total execution time: 1.1579
INFO - 2016-02-07 13:10:45 --> Config Class Initialized
INFO - 2016-02-07 13:10:45 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:10:45 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:10:45 --> Utf8 Class Initialized
INFO - 2016-02-07 13:10:45 --> URI Class Initialized
INFO - 2016-02-07 13:10:45 --> Router Class Initialized
INFO - 2016-02-07 13:10:45 --> Output Class Initialized
INFO - 2016-02-07 13:10:45 --> Security Class Initialized
DEBUG - 2016-02-07 13:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:10:45 --> Input Class Initialized
INFO - 2016-02-07 13:10:45 --> Language Class Initialized
INFO - 2016-02-07 13:10:45 --> Loader Class Initialized
INFO - 2016-02-07 13:10:45 --> Helper loaded: url_helper
INFO - 2016-02-07 13:10:45 --> Helper loaded: file_helper
INFO - 2016-02-07 13:10:45 --> Helper loaded: date_helper
INFO - 2016-02-07 13:10:45 --> Helper loaded: form_helper
INFO - 2016-02-07 13:10:45 --> Database Driver Class Initialized
INFO - 2016-02-07 13:10:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:10:46 --> Controller Class Initialized
INFO - 2016-02-07 13:10:46 --> Model Class Initialized
INFO - 2016-02-07 13:10:46 --> Model Class Initialized
INFO - 2016-02-07 13:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:10:46 --> Pagination Class Initialized
INFO - 2016-02-07 13:10:46 --> Form Validation Class Initialized
INFO - 2016-02-07 13:10:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:10:46 --> Model Class Initialized
INFO - 2016-02-07 13:10:47 --> Final output sent to browser
DEBUG - 2016-02-07 13:10:47 --> Total execution time: 1.1622
INFO - 2016-02-07 13:13:21 --> Config Class Initialized
INFO - 2016-02-07 13:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:13:21 --> Utf8 Class Initialized
INFO - 2016-02-07 13:13:21 --> URI Class Initialized
INFO - 2016-02-07 13:13:21 --> Router Class Initialized
INFO - 2016-02-07 13:13:21 --> Output Class Initialized
INFO - 2016-02-07 13:13:21 --> Security Class Initialized
DEBUG - 2016-02-07 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:13:21 --> Input Class Initialized
INFO - 2016-02-07 13:13:21 --> Language Class Initialized
INFO - 2016-02-07 13:13:21 --> Loader Class Initialized
INFO - 2016-02-07 13:13:21 --> Helper loaded: url_helper
INFO - 2016-02-07 13:13:21 --> Helper loaded: file_helper
INFO - 2016-02-07 13:13:21 --> Helper loaded: date_helper
INFO - 2016-02-07 13:13:21 --> Helper loaded: form_helper
INFO - 2016-02-07 13:13:21 --> Database Driver Class Initialized
INFO - 2016-02-07 13:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:13:22 --> Controller Class Initialized
INFO - 2016-02-07 13:13:22 --> Model Class Initialized
INFO - 2016-02-07 13:13:22 --> Model Class Initialized
INFO - 2016-02-07 13:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:13:22 --> Pagination Class Initialized
INFO - 2016-02-07 13:13:22 --> Form Validation Class Initialized
INFO - 2016-02-07 13:13:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 13:13:22 --> Model Class Initialized
INFO - 2016-02-07 13:13:22 --> Final output sent to browser
DEBUG - 2016-02-07 13:13:22 --> Total execution time: 1.1863
INFO - 2016-02-07 13:32:22 --> Config Class Initialized
INFO - 2016-02-07 13:32:22 --> Hooks Class Initialized
DEBUG - 2016-02-07 13:32:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 13:32:23 --> Utf8 Class Initialized
INFO - 2016-02-07 13:32:23 --> URI Class Initialized
DEBUG - 2016-02-07 13:32:23 --> No URI present. Default controller set.
INFO - 2016-02-07 13:32:23 --> Router Class Initialized
INFO - 2016-02-07 13:32:23 --> Output Class Initialized
INFO - 2016-02-07 13:32:23 --> Security Class Initialized
DEBUG - 2016-02-07 13:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 13:32:23 --> Input Class Initialized
INFO - 2016-02-07 13:32:23 --> Language Class Initialized
INFO - 2016-02-07 13:32:23 --> Loader Class Initialized
INFO - 2016-02-07 13:32:23 --> Helper loaded: url_helper
INFO - 2016-02-07 13:32:23 --> Helper loaded: file_helper
INFO - 2016-02-07 13:32:23 --> Helper loaded: date_helper
INFO - 2016-02-07 13:32:23 --> Helper loaded: form_helper
INFO - 2016-02-07 13:32:23 --> Database Driver Class Initialized
INFO - 2016-02-07 13:32:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 13:32:24 --> Controller Class Initialized
INFO - 2016-02-07 13:32:24 --> Model Class Initialized
INFO - 2016-02-07 13:32:24 --> Model Class Initialized
INFO - 2016-02-07 13:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 13:32:24 --> Pagination Class Initialized
INFO - 2016-02-07 13:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 13:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 13:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 13:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 13:32:24 --> Final output sent to browser
DEBUG - 2016-02-07 13:32:24 --> Total execution time: 1.4032
INFO - 2016-02-07 14:07:42 --> Config Class Initialized
INFO - 2016-02-07 14:07:42 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:07:42 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:07:42 --> Utf8 Class Initialized
INFO - 2016-02-07 14:07:42 --> URI Class Initialized
DEBUG - 2016-02-07 14:07:42 --> No URI present. Default controller set.
INFO - 2016-02-07 14:07:42 --> Router Class Initialized
INFO - 2016-02-07 14:07:42 --> Output Class Initialized
INFO - 2016-02-07 14:07:42 --> Security Class Initialized
DEBUG - 2016-02-07 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:07:42 --> Input Class Initialized
INFO - 2016-02-07 14:07:42 --> Language Class Initialized
INFO - 2016-02-07 14:07:42 --> Loader Class Initialized
INFO - 2016-02-07 14:07:42 --> Helper loaded: url_helper
INFO - 2016-02-07 14:07:42 --> Helper loaded: file_helper
INFO - 2016-02-07 14:07:42 --> Helper loaded: date_helper
INFO - 2016-02-07 14:07:42 --> Helper loaded: form_helper
INFO - 2016-02-07 14:07:42 --> Database Driver Class Initialized
INFO - 2016-02-07 14:07:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:07:43 --> Controller Class Initialized
INFO - 2016-02-07 14:07:43 --> Model Class Initialized
INFO - 2016-02-07 14:07:43 --> Model Class Initialized
INFO - 2016-02-07 14:07:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:07:43 --> Pagination Class Initialized
INFO - 2016-02-07 14:07:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:07:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:07:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:07:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:07:43 --> Final output sent to browser
DEBUG - 2016-02-07 14:07:43 --> Total execution time: 1.1080
INFO - 2016-02-07 14:07:48 --> Config Class Initialized
INFO - 2016-02-07 14:07:48 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:07:48 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:07:48 --> Utf8 Class Initialized
INFO - 2016-02-07 14:07:48 --> URI Class Initialized
DEBUG - 2016-02-07 14:07:48 --> No URI present. Default controller set.
INFO - 2016-02-07 14:07:48 --> Router Class Initialized
INFO - 2016-02-07 14:07:48 --> Output Class Initialized
INFO - 2016-02-07 14:07:48 --> Security Class Initialized
DEBUG - 2016-02-07 14:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:07:48 --> Input Class Initialized
INFO - 2016-02-07 14:07:48 --> Language Class Initialized
INFO - 2016-02-07 14:07:48 --> Loader Class Initialized
INFO - 2016-02-07 14:07:48 --> Helper loaded: url_helper
INFO - 2016-02-07 14:07:48 --> Helper loaded: file_helper
INFO - 2016-02-07 14:07:48 --> Helper loaded: date_helper
INFO - 2016-02-07 14:07:48 --> Helper loaded: form_helper
INFO - 2016-02-07 14:07:48 --> Database Driver Class Initialized
INFO - 2016-02-07 14:07:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:07:49 --> Controller Class Initialized
INFO - 2016-02-07 14:07:49 --> Model Class Initialized
INFO - 2016-02-07 14:07:49 --> Model Class Initialized
INFO - 2016-02-07 14:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:07:49 --> Pagination Class Initialized
INFO - 2016-02-07 14:07:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:07:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:07:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:07:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:07:49 --> Final output sent to browser
DEBUG - 2016-02-07 14:07:49 --> Total execution time: 1.1449
INFO - 2016-02-07 14:07:54 --> Config Class Initialized
INFO - 2016-02-07 14:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:07:54 --> Utf8 Class Initialized
INFO - 2016-02-07 14:07:54 --> URI Class Initialized
INFO - 2016-02-07 14:07:54 --> Router Class Initialized
INFO - 2016-02-07 14:07:54 --> Output Class Initialized
INFO - 2016-02-07 14:07:54 --> Security Class Initialized
DEBUG - 2016-02-07 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:07:54 --> Input Class Initialized
INFO - 2016-02-07 14:07:54 --> Language Class Initialized
INFO - 2016-02-07 14:07:54 --> Loader Class Initialized
INFO - 2016-02-07 14:07:54 --> Helper loaded: url_helper
INFO - 2016-02-07 14:07:54 --> Helper loaded: file_helper
INFO - 2016-02-07 14:07:54 --> Helper loaded: date_helper
INFO - 2016-02-07 14:07:54 --> Helper loaded: form_helper
INFO - 2016-02-07 14:07:54 --> Database Driver Class Initialized
INFO - 2016-02-07 14:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:07:55 --> Controller Class Initialized
INFO - 2016-02-07 14:07:55 --> Model Class Initialized
INFO - 2016-02-07 14:07:55 --> Model Class Initialized
INFO - 2016-02-07 14:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:07:55 --> Pagination Class Initialized
INFO - 2016-02-07 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:07:55 --> Helper loaded: text_helper
INFO - 2016-02-07 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:07:55 --> Final output sent to browser
DEBUG - 2016-02-07 14:07:55 --> Total execution time: 1.2646
INFO - 2016-02-07 14:08:04 --> Config Class Initialized
INFO - 2016-02-07 14:08:04 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:08:04 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:08:04 --> Utf8 Class Initialized
INFO - 2016-02-07 14:08:04 --> URI Class Initialized
INFO - 2016-02-07 14:08:04 --> Router Class Initialized
INFO - 2016-02-07 14:08:04 --> Output Class Initialized
INFO - 2016-02-07 14:08:04 --> Security Class Initialized
DEBUG - 2016-02-07 14:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:08:04 --> Input Class Initialized
INFO - 2016-02-07 14:08:04 --> Language Class Initialized
INFO - 2016-02-07 14:08:04 --> Loader Class Initialized
INFO - 2016-02-07 14:08:04 --> Helper loaded: url_helper
INFO - 2016-02-07 14:08:04 --> Helper loaded: file_helper
INFO - 2016-02-07 14:08:04 --> Helper loaded: date_helper
INFO - 2016-02-07 14:08:04 --> Helper loaded: form_helper
INFO - 2016-02-07 14:08:04 --> Database Driver Class Initialized
INFO - 2016-02-07 14:08:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:08:05 --> Controller Class Initialized
INFO - 2016-02-07 14:08:05 --> Model Class Initialized
INFO - 2016-02-07 14:08:05 --> Model Class Initialized
INFO - 2016-02-07 14:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:08:05 --> Pagination Class Initialized
INFO - 2016-02-07 14:08:05 --> Form Validation Class Initialized
INFO - 2016-02-07 14:08:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 14:08:05 --> Model Class Initialized
INFO - 2016-02-07 14:08:05 --> Final output sent to browser
DEBUG - 2016-02-07 14:08:05 --> Total execution time: 1.1780
INFO - 2016-02-07 14:24:20 --> Config Class Initialized
INFO - 2016-02-07 14:24:20 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:24:20 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:24:20 --> Utf8 Class Initialized
INFO - 2016-02-07 14:24:20 --> URI Class Initialized
DEBUG - 2016-02-07 14:24:20 --> No URI present. Default controller set.
INFO - 2016-02-07 14:24:20 --> Router Class Initialized
INFO - 2016-02-07 14:24:20 --> Output Class Initialized
INFO - 2016-02-07 14:24:20 --> Security Class Initialized
DEBUG - 2016-02-07 14:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:24:20 --> Input Class Initialized
INFO - 2016-02-07 14:24:20 --> Language Class Initialized
INFO - 2016-02-07 14:24:20 --> Loader Class Initialized
INFO - 2016-02-07 14:24:20 --> Helper loaded: url_helper
INFO - 2016-02-07 14:24:20 --> Helper loaded: file_helper
INFO - 2016-02-07 14:24:20 --> Helper loaded: date_helper
INFO - 2016-02-07 14:24:20 --> Helper loaded: form_helper
INFO - 2016-02-07 14:24:20 --> Database Driver Class Initialized
INFO - 2016-02-07 14:24:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:24:21 --> Controller Class Initialized
INFO - 2016-02-07 14:24:21 --> Model Class Initialized
INFO - 2016-02-07 14:24:21 --> Model Class Initialized
INFO - 2016-02-07 14:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:24:21 --> Pagination Class Initialized
INFO - 2016-02-07 14:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:24:21 --> Final output sent to browser
DEBUG - 2016-02-07 14:24:21 --> Total execution time: 1.1434
INFO - 2016-02-07 14:24:23 --> Config Class Initialized
INFO - 2016-02-07 14:24:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:24:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:24:23 --> Utf8 Class Initialized
INFO - 2016-02-07 14:24:23 --> URI Class Initialized
INFO - 2016-02-07 14:24:23 --> Router Class Initialized
INFO - 2016-02-07 14:24:23 --> Output Class Initialized
INFO - 2016-02-07 14:24:23 --> Security Class Initialized
DEBUG - 2016-02-07 14:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:24:23 --> Input Class Initialized
INFO - 2016-02-07 14:24:23 --> Language Class Initialized
INFO - 2016-02-07 14:24:23 --> Loader Class Initialized
INFO - 2016-02-07 14:24:23 --> Helper loaded: url_helper
INFO - 2016-02-07 14:24:23 --> Helper loaded: file_helper
INFO - 2016-02-07 14:24:23 --> Helper loaded: date_helper
INFO - 2016-02-07 14:24:23 --> Helper loaded: form_helper
INFO - 2016-02-07 14:24:23 --> Database Driver Class Initialized
INFO - 2016-02-07 14:24:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:24:24 --> Controller Class Initialized
INFO - 2016-02-07 14:24:24 --> Model Class Initialized
INFO - 2016-02-07 14:24:24 --> Model Class Initialized
INFO - 2016-02-07 14:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:24:24 --> Pagination Class Initialized
INFO - 2016-02-07 14:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:24:24 --> Helper loaded: text_helper
INFO - 2016-02-07 14:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 14:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 14:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:24:24 --> Final output sent to browser
DEBUG - 2016-02-07 14:24:24 --> Total execution time: 1.1979
INFO - 2016-02-07 14:24:31 --> Config Class Initialized
INFO - 2016-02-07 14:24:31 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:24:31 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:24:31 --> Utf8 Class Initialized
INFO - 2016-02-07 14:24:31 --> URI Class Initialized
INFO - 2016-02-07 14:24:31 --> Router Class Initialized
INFO - 2016-02-07 14:24:31 --> Output Class Initialized
INFO - 2016-02-07 14:24:31 --> Security Class Initialized
DEBUG - 2016-02-07 14:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:24:31 --> Input Class Initialized
INFO - 2016-02-07 14:24:31 --> Language Class Initialized
INFO - 2016-02-07 14:24:31 --> Loader Class Initialized
INFO - 2016-02-07 14:24:31 --> Helper loaded: url_helper
INFO - 2016-02-07 14:24:31 --> Helper loaded: file_helper
INFO - 2016-02-07 14:24:31 --> Helper loaded: date_helper
INFO - 2016-02-07 14:24:31 --> Helper loaded: form_helper
INFO - 2016-02-07 14:24:31 --> Database Driver Class Initialized
INFO - 2016-02-07 14:24:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:24:32 --> Controller Class Initialized
INFO - 2016-02-07 14:24:32 --> Model Class Initialized
INFO - 2016-02-07 14:24:32 --> Model Class Initialized
INFO - 2016-02-07 14:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:24:32 --> Pagination Class Initialized
INFO - 2016-02-07 14:24:32 --> Form Validation Class Initialized
INFO - 2016-02-07 14:24:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 14:24:32 --> Model Class Initialized
INFO - 2016-02-07 14:24:32 --> Final output sent to browser
DEBUG - 2016-02-07 14:24:32 --> Total execution time: 1.1588
INFO - 2016-02-07 14:26:52 --> Config Class Initialized
INFO - 2016-02-07 14:26:52 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:26:52 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:26:52 --> Utf8 Class Initialized
INFO - 2016-02-07 14:26:52 --> URI Class Initialized
DEBUG - 2016-02-07 14:26:52 --> No URI present. Default controller set.
INFO - 2016-02-07 14:26:52 --> Router Class Initialized
INFO - 2016-02-07 14:26:52 --> Output Class Initialized
INFO - 2016-02-07 14:26:52 --> Security Class Initialized
DEBUG - 2016-02-07 14:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:26:52 --> Input Class Initialized
INFO - 2016-02-07 14:26:52 --> Language Class Initialized
INFO - 2016-02-07 14:26:52 --> Loader Class Initialized
INFO - 2016-02-07 14:26:52 --> Helper loaded: url_helper
INFO - 2016-02-07 14:26:52 --> Helper loaded: file_helper
INFO - 2016-02-07 14:26:52 --> Helper loaded: date_helper
INFO - 2016-02-07 14:26:52 --> Helper loaded: form_helper
INFO - 2016-02-07 14:26:52 --> Database Driver Class Initialized
INFO - 2016-02-07 14:26:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:26:54 --> Controller Class Initialized
INFO - 2016-02-07 14:26:54 --> Model Class Initialized
INFO - 2016-02-07 14:26:54 --> Model Class Initialized
INFO - 2016-02-07 14:26:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:26:54 --> Pagination Class Initialized
INFO - 2016-02-07 14:26:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:26:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:26:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:26:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:26:54 --> Final output sent to browser
DEBUG - 2016-02-07 14:26:54 --> Total execution time: 1.1453
INFO - 2016-02-07 14:26:55 --> Config Class Initialized
INFO - 2016-02-07 14:26:55 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:26:55 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:26:55 --> Utf8 Class Initialized
INFO - 2016-02-07 14:26:55 --> URI Class Initialized
INFO - 2016-02-07 14:26:55 --> Router Class Initialized
INFO - 2016-02-07 14:26:55 --> Output Class Initialized
INFO - 2016-02-07 14:26:55 --> Security Class Initialized
DEBUG - 2016-02-07 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:26:55 --> Input Class Initialized
INFO - 2016-02-07 14:26:55 --> Language Class Initialized
INFO - 2016-02-07 14:26:55 --> Loader Class Initialized
INFO - 2016-02-07 14:26:55 --> Helper loaded: url_helper
INFO - 2016-02-07 14:26:55 --> Helper loaded: file_helper
INFO - 2016-02-07 14:26:55 --> Helper loaded: date_helper
INFO - 2016-02-07 14:26:55 --> Helper loaded: form_helper
INFO - 2016-02-07 14:26:55 --> Database Driver Class Initialized
INFO - 2016-02-07 14:26:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:26:56 --> Controller Class Initialized
INFO - 2016-02-07 14:26:56 --> Model Class Initialized
INFO - 2016-02-07 14:26:56 --> Model Class Initialized
INFO - 2016-02-07 14:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:26:56 --> Pagination Class Initialized
INFO - 2016-02-07 14:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:26:56 --> Helper loaded: text_helper
INFO - 2016-02-07 14:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 14:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 14:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:26:56 --> Final output sent to browser
DEBUG - 2016-02-07 14:26:56 --> Total execution time: 1.1772
INFO - 2016-02-07 14:27:04 --> Config Class Initialized
INFO - 2016-02-07 14:27:04 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:27:04 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:27:04 --> Utf8 Class Initialized
INFO - 2016-02-07 14:27:04 --> URI Class Initialized
INFO - 2016-02-07 14:27:04 --> Router Class Initialized
INFO - 2016-02-07 14:27:04 --> Output Class Initialized
INFO - 2016-02-07 14:27:04 --> Security Class Initialized
DEBUG - 2016-02-07 14:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:27:04 --> Input Class Initialized
INFO - 2016-02-07 14:27:04 --> Language Class Initialized
INFO - 2016-02-07 14:27:04 --> Loader Class Initialized
INFO - 2016-02-07 14:27:04 --> Helper loaded: url_helper
INFO - 2016-02-07 14:27:04 --> Helper loaded: file_helper
INFO - 2016-02-07 14:27:04 --> Helper loaded: date_helper
INFO - 2016-02-07 14:27:04 --> Helper loaded: form_helper
INFO - 2016-02-07 14:27:04 --> Database Driver Class Initialized
INFO - 2016-02-07 14:27:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:27:05 --> Controller Class Initialized
INFO - 2016-02-07 14:27:05 --> Model Class Initialized
INFO - 2016-02-07 14:27:05 --> Model Class Initialized
INFO - 2016-02-07 14:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:27:05 --> Pagination Class Initialized
INFO - 2016-02-07 14:27:05 --> Form Validation Class Initialized
INFO - 2016-02-07 14:27:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 14:27:05 --> Model Class Initialized
INFO - 2016-02-07 14:27:05 --> Final output sent to browser
DEBUG - 2016-02-07 14:27:05 --> Total execution time: 1.2265
INFO - 2016-02-07 14:28:26 --> Config Class Initialized
INFO - 2016-02-07 14:28:26 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:28:26 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:28:26 --> Utf8 Class Initialized
INFO - 2016-02-07 14:28:26 --> URI Class Initialized
DEBUG - 2016-02-07 14:28:26 --> No URI present. Default controller set.
INFO - 2016-02-07 14:28:26 --> Router Class Initialized
INFO - 2016-02-07 14:28:26 --> Output Class Initialized
INFO - 2016-02-07 14:28:26 --> Security Class Initialized
DEBUG - 2016-02-07 14:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:28:26 --> Input Class Initialized
INFO - 2016-02-07 14:28:26 --> Language Class Initialized
INFO - 2016-02-07 14:28:26 --> Loader Class Initialized
INFO - 2016-02-07 14:28:26 --> Helper loaded: url_helper
INFO - 2016-02-07 14:28:26 --> Helper loaded: file_helper
INFO - 2016-02-07 14:28:26 --> Helper loaded: date_helper
INFO - 2016-02-07 14:28:26 --> Helper loaded: form_helper
INFO - 2016-02-07 14:28:26 --> Database Driver Class Initialized
INFO - 2016-02-07 14:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:28:27 --> Controller Class Initialized
INFO - 2016-02-07 14:28:27 --> Model Class Initialized
INFO - 2016-02-07 14:28:27 --> Model Class Initialized
INFO - 2016-02-07 14:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:28:27 --> Pagination Class Initialized
INFO - 2016-02-07 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:28:27 --> Final output sent to browser
DEBUG - 2016-02-07 14:28:27 --> Total execution time: 1.1096
INFO - 2016-02-07 14:28:29 --> Config Class Initialized
INFO - 2016-02-07 14:28:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:28:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:28:29 --> Utf8 Class Initialized
INFO - 2016-02-07 14:28:29 --> URI Class Initialized
INFO - 2016-02-07 14:28:29 --> Router Class Initialized
INFO - 2016-02-07 14:28:29 --> Output Class Initialized
INFO - 2016-02-07 14:28:29 --> Security Class Initialized
DEBUG - 2016-02-07 14:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:28:29 --> Input Class Initialized
INFO - 2016-02-07 14:28:29 --> Language Class Initialized
INFO - 2016-02-07 14:28:29 --> Loader Class Initialized
INFO - 2016-02-07 14:28:29 --> Helper loaded: url_helper
INFO - 2016-02-07 14:28:29 --> Helper loaded: file_helper
INFO - 2016-02-07 14:28:29 --> Helper loaded: date_helper
INFO - 2016-02-07 14:28:29 --> Helper loaded: form_helper
INFO - 2016-02-07 14:28:29 --> Database Driver Class Initialized
INFO - 2016-02-07 14:28:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:28:30 --> Controller Class Initialized
INFO - 2016-02-07 14:28:30 --> Model Class Initialized
INFO - 2016-02-07 14:28:30 --> Model Class Initialized
INFO - 2016-02-07 14:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:28:30 --> Pagination Class Initialized
INFO - 2016-02-07 14:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:28:30 --> Helper loaded: text_helper
INFO - 2016-02-07 14:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 14:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 14:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:28:30 --> Final output sent to browser
DEBUG - 2016-02-07 14:28:30 --> Total execution time: 1.1877
INFO - 2016-02-07 14:28:46 --> Config Class Initialized
INFO - 2016-02-07 14:28:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:28:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:28:46 --> Utf8 Class Initialized
INFO - 2016-02-07 14:28:46 --> URI Class Initialized
INFO - 2016-02-07 14:28:46 --> Router Class Initialized
INFO - 2016-02-07 14:28:46 --> Output Class Initialized
INFO - 2016-02-07 14:28:46 --> Security Class Initialized
DEBUG - 2016-02-07 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:28:46 --> Input Class Initialized
INFO - 2016-02-07 14:28:46 --> Language Class Initialized
INFO - 2016-02-07 14:28:46 --> Loader Class Initialized
INFO - 2016-02-07 14:28:46 --> Helper loaded: url_helper
INFO - 2016-02-07 14:28:46 --> Helper loaded: file_helper
INFO - 2016-02-07 14:28:46 --> Helper loaded: date_helper
INFO - 2016-02-07 14:28:46 --> Helper loaded: form_helper
INFO - 2016-02-07 14:28:46 --> Database Driver Class Initialized
INFO - 2016-02-07 14:28:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:28:47 --> Controller Class Initialized
INFO - 2016-02-07 14:28:47 --> Model Class Initialized
INFO - 2016-02-07 14:28:47 --> Model Class Initialized
INFO - 2016-02-07 14:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:28:47 --> Pagination Class Initialized
INFO - 2016-02-07 14:28:47 --> Form Validation Class Initialized
INFO - 2016-02-07 14:28:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 14:28:47 --> Model Class Initialized
INFO - 2016-02-07 14:28:47 --> Final output sent to browser
DEBUG - 2016-02-07 14:28:47 --> Total execution time: 1.2040
INFO - 2016-02-07 14:29:42 --> Config Class Initialized
INFO - 2016-02-07 14:29:42 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:29:42 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:29:42 --> Utf8 Class Initialized
INFO - 2016-02-07 14:29:42 --> URI Class Initialized
DEBUG - 2016-02-07 14:29:42 --> No URI present. Default controller set.
INFO - 2016-02-07 14:29:42 --> Router Class Initialized
INFO - 2016-02-07 14:29:42 --> Output Class Initialized
INFO - 2016-02-07 14:29:42 --> Security Class Initialized
DEBUG - 2016-02-07 14:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:29:42 --> Input Class Initialized
INFO - 2016-02-07 14:29:42 --> Language Class Initialized
INFO - 2016-02-07 14:29:42 --> Loader Class Initialized
INFO - 2016-02-07 14:29:42 --> Helper loaded: url_helper
INFO - 2016-02-07 14:29:42 --> Helper loaded: file_helper
INFO - 2016-02-07 14:29:42 --> Helper loaded: date_helper
INFO - 2016-02-07 14:29:42 --> Helper loaded: form_helper
INFO - 2016-02-07 14:29:42 --> Database Driver Class Initialized
INFO - 2016-02-07 14:29:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:29:43 --> Controller Class Initialized
INFO - 2016-02-07 14:29:43 --> Model Class Initialized
INFO - 2016-02-07 14:29:43 --> Model Class Initialized
INFO - 2016-02-07 14:29:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:29:43 --> Pagination Class Initialized
INFO - 2016-02-07 14:29:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:29:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:29:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 14:29:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:29:43 --> Final output sent to browser
DEBUG - 2016-02-07 14:29:43 --> Total execution time: 1.1465
INFO - 2016-02-07 14:29:46 --> Config Class Initialized
INFO - 2016-02-07 14:29:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:29:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:29:46 --> Utf8 Class Initialized
INFO - 2016-02-07 14:29:46 --> URI Class Initialized
INFO - 2016-02-07 14:29:46 --> Router Class Initialized
INFO - 2016-02-07 14:29:46 --> Output Class Initialized
INFO - 2016-02-07 14:29:46 --> Security Class Initialized
DEBUG - 2016-02-07 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:29:46 --> Input Class Initialized
INFO - 2016-02-07 14:29:46 --> Language Class Initialized
INFO - 2016-02-07 14:29:46 --> Loader Class Initialized
INFO - 2016-02-07 14:29:46 --> Helper loaded: url_helper
INFO - 2016-02-07 14:29:46 --> Helper loaded: file_helper
INFO - 2016-02-07 14:29:46 --> Helper loaded: date_helper
INFO - 2016-02-07 14:29:46 --> Helper loaded: form_helper
INFO - 2016-02-07 14:29:46 --> Database Driver Class Initialized
INFO - 2016-02-07 14:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:29:47 --> Controller Class Initialized
INFO - 2016-02-07 14:29:47 --> Model Class Initialized
INFO - 2016-02-07 14:29:47 --> Model Class Initialized
INFO - 2016-02-07 14:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:29:47 --> Pagination Class Initialized
INFO - 2016-02-07 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 14:29:47 --> Helper loaded: text_helper
INFO - 2016-02-07 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 14:29:47 --> Final output sent to browser
DEBUG - 2016-02-07 14:29:47 --> Total execution time: 1.1944
INFO - 2016-02-07 14:29:54 --> Config Class Initialized
INFO - 2016-02-07 14:29:54 --> Hooks Class Initialized
DEBUG - 2016-02-07 14:29:54 --> UTF-8 Support Enabled
INFO - 2016-02-07 14:29:54 --> Utf8 Class Initialized
INFO - 2016-02-07 14:29:54 --> URI Class Initialized
INFO - 2016-02-07 14:29:54 --> Router Class Initialized
INFO - 2016-02-07 14:29:54 --> Output Class Initialized
INFO - 2016-02-07 14:29:54 --> Security Class Initialized
DEBUG - 2016-02-07 14:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 14:29:54 --> Input Class Initialized
INFO - 2016-02-07 14:29:54 --> Language Class Initialized
INFO - 2016-02-07 14:29:54 --> Loader Class Initialized
INFO - 2016-02-07 14:29:54 --> Helper loaded: url_helper
INFO - 2016-02-07 14:29:54 --> Helper loaded: file_helper
INFO - 2016-02-07 14:29:54 --> Helper loaded: date_helper
INFO - 2016-02-07 14:29:54 --> Helper loaded: form_helper
INFO - 2016-02-07 14:29:54 --> Database Driver Class Initialized
INFO - 2016-02-07 14:29:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 14:29:55 --> Controller Class Initialized
INFO - 2016-02-07 14:29:55 --> Model Class Initialized
INFO - 2016-02-07 14:29:55 --> Model Class Initialized
INFO - 2016-02-07 14:29:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 14:29:55 --> Pagination Class Initialized
INFO - 2016-02-07 14:29:55 --> Form Validation Class Initialized
INFO - 2016-02-07 14:29:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 14:29:55 --> Model Class Initialized
INFO - 2016-02-07 14:29:55 --> Final output sent to browser
DEBUG - 2016-02-07 14:29:55 --> Total execution time: 1.2066
INFO - 2016-02-07 15:14:39 --> Config Class Initialized
INFO - 2016-02-07 15:14:39 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:14:39 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:14:39 --> Utf8 Class Initialized
INFO - 2016-02-07 15:14:39 --> URI Class Initialized
DEBUG - 2016-02-07 15:14:39 --> No URI present. Default controller set.
INFO - 2016-02-07 15:14:39 --> Router Class Initialized
INFO - 2016-02-07 15:14:39 --> Output Class Initialized
INFO - 2016-02-07 15:14:39 --> Security Class Initialized
DEBUG - 2016-02-07 15:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:14:39 --> Input Class Initialized
INFO - 2016-02-07 15:14:39 --> Language Class Initialized
INFO - 2016-02-07 15:14:39 --> Loader Class Initialized
INFO - 2016-02-07 15:14:39 --> Helper loaded: url_helper
INFO - 2016-02-07 15:14:39 --> Helper loaded: file_helper
INFO - 2016-02-07 15:14:39 --> Helper loaded: date_helper
INFO - 2016-02-07 15:14:39 --> Helper loaded: form_helper
INFO - 2016-02-07 15:14:39 --> Database Driver Class Initialized
INFO - 2016-02-07 15:14:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:14:40 --> Controller Class Initialized
INFO - 2016-02-07 15:14:40 --> Model Class Initialized
INFO - 2016-02-07 15:14:40 --> Model Class Initialized
INFO - 2016-02-07 15:14:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:14:40 --> Pagination Class Initialized
INFO - 2016-02-07 15:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:14:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:14:40 --> Final output sent to browser
DEBUG - 2016-02-07 15:14:40 --> Total execution time: 1.1359
INFO - 2016-02-07 15:15:14 --> Config Class Initialized
INFO - 2016-02-07 15:15:14 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:14 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:14 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:14 --> URI Class Initialized
DEBUG - 2016-02-07 15:15:14 --> No URI present. Default controller set.
INFO - 2016-02-07 15:15:14 --> Router Class Initialized
INFO - 2016-02-07 15:15:14 --> Output Class Initialized
INFO - 2016-02-07 15:15:14 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:14 --> Input Class Initialized
INFO - 2016-02-07 15:15:14 --> Language Class Initialized
INFO - 2016-02-07 15:15:14 --> Loader Class Initialized
INFO - 2016-02-07 15:15:14 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:14 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:14 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:14 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:14 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:15 --> Controller Class Initialized
INFO - 2016-02-07 15:15:15 --> Model Class Initialized
INFO - 2016-02-07 15:15:15 --> Model Class Initialized
INFO - 2016-02-07 15:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:15 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:15 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:15 --> Total execution time: 1.1605
INFO - 2016-02-07 15:15:19 --> Config Class Initialized
INFO - 2016-02-07 15:15:19 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:19 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:19 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:19 --> URI Class Initialized
INFO - 2016-02-07 15:15:19 --> Router Class Initialized
INFO - 2016-02-07 15:15:19 --> Output Class Initialized
INFO - 2016-02-07 15:15:19 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:19 --> Input Class Initialized
INFO - 2016-02-07 15:15:19 --> Language Class Initialized
INFO - 2016-02-07 15:15:19 --> Loader Class Initialized
INFO - 2016-02-07 15:15:19 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:19 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:19 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:19 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:19 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:20 --> Controller Class Initialized
INFO - 2016-02-07 15:15:20 --> Model Class Initialized
INFO - 2016-02-07 15:15:20 --> Model Class Initialized
INFO - 2016-02-07 15:15:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:20 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:15:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:20 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:20 --> Total execution time: 1.1434
INFO - 2016-02-07 15:15:24 --> Config Class Initialized
INFO - 2016-02-07 15:15:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:24 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:24 --> URI Class Initialized
INFO - 2016-02-07 15:15:24 --> Router Class Initialized
INFO - 2016-02-07 15:15:24 --> Output Class Initialized
INFO - 2016-02-07 15:15:24 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:24 --> Input Class Initialized
INFO - 2016-02-07 15:15:24 --> Language Class Initialized
INFO - 2016-02-07 15:15:24 --> Loader Class Initialized
INFO - 2016-02-07 15:15:24 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:24 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:24 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:24 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:24 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:25 --> Controller Class Initialized
INFO - 2016-02-07 15:15:25 --> Model Class Initialized
INFO - 2016-02-07 15:15:25 --> Model Class Initialized
INFO - 2016-02-07 15:15:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:25 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:15:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:25 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:25 --> Total execution time: 1.1426
INFO - 2016-02-07 15:15:28 --> Config Class Initialized
INFO - 2016-02-07 15:15:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:28 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:28 --> URI Class Initialized
INFO - 2016-02-07 15:15:28 --> Router Class Initialized
INFO - 2016-02-07 15:15:28 --> Output Class Initialized
INFO - 2016-02-07 15:15:28 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:28 --> Input Class Initialized
INFO - 2016-02-07 15:15:28 --> Language Class Initialized
INFO - 2016-02-07 15:15:28 --> Loader Class Initialized
INFO - 2016-02-07 15:15:28 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:28 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:28 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:28 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:28 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:29 --> Controller Class Initialized
INFO - 2016-02-07 15:15:29 --> Model Class Initialized
INFO - 2016-02-07 15:15:29 --> Model Class Initialized
INFO - 2016-02-07 15:15:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:29 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:15:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:29 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:29 --> Total execution time: 1.1033
INFO - 2016-02-07 15:15:33 --> Config Class Initialized
INFO - 2016-02-07 15:15:33 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:33 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:33 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:33 --> URI Class Initialized
DEBUG - 2016-02-07 15:15:33 --> No URI present. Default controller set.
INFO - 2016-02-07 15:15:33 --> Router Class Initialized
INFO - 2016-02-07 15:15:33 --> Output Class Initialized
INFO - 2016-02-07 15:15:33 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:33 --> Input Class Initialized
INFO - 2016-02-07 15:15:33 --> Language Class Initialized
INFO - 2016-02-07 15:15:33 --> Loader Class Initialized
INFO - 2016-02-07 15:15:33 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:33 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:33 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:33 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:33 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:34 --> Controller Class Initialized
INFO - 2016-02-07 15:15:34 --> Model Class Initialized
INFO - 2016-02-07 15:15:34 --> Model Class Initialized
INFO - 2016-02-07 15:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:34 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:34 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:34 --> Total execution time: 1.1269
INFO - 2016-02-07 15:15:36 --> Config Class Initialized
INFO - 2016-02-07 15:15:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:15:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:15:36 --> Utf8 Class Initialized
INFO - 2016-02-07 15:15:36 --> URI Class Initialized
INFO - 2016-02-07 15:15:36 --> Router Class Initialized
INFO - 2016-02-07 15:15:36 --> Output Class Initialized
INFO - 2016-02-07 15:15:36 --> Security Class Initialized
DEBUG - 2016-02-07 15:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:15:36 --> Input Class Initialized
INFO - 2016-02-07 15:15:36 --> Language Class Initialized
INFO - 2016-02-07 15:15:36 --> Loader Class Initialized
INFO - 2016-02-07 15:15:36 --> Helper loaded: url_helper
INFO - 2016-02-07 15:15:36 --> Helper loaded: file_helper
INFO - 2016-02-07 15:15:36 --> Helper loaded: date_helper
INFO - 2016-02-07 15:15:36 --> Helper loaded: form_helper
INFO - 2016-02-07 15:15:36 --> Database Driver Class Initialized
INFO - 2016-02-07 15:15:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:15:37 --> Controller Class Initialized
INFO - 2016-02-07 15:15:37 --> Model Class Initialized
INFO - 2016-02-07 15:15:37 --> Model Class Initialized
INFO - 2016-02-07 15:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:15:37 --> Pagination Class Initialized
INFO - 2016-02-07 15:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:15:37 --> Helper loaded: text_helper
INFO - 2016-02-07 15:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:15:38 --> Final output sent to browser
DEBUG - 2016-02-07 15:15:38 --> Total execution time: 1.2214
INFO - 2016-02-07 15:16:41 --> Config Class Initialized
INFO - 2016-02-07 15:16:41 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:16:41 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:16:41 --> Utf8 Class Initialized
INFO - 2016-02-07 15:16:41 --> URI Class Initialized
DEBUG - 2016-02-07 15:16:41 --> No URI present. Default controller set.
INFO - 2016-02-07 15:16:41 --> Router Class Initialized
INFO - 2016-02-07 15:16:41 --> Output Class Initialized
INFO - 2016-02-07 15:16:41 --> Security Class Initialized
DEBUG - 2016-02-07 15:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:16:41 --> Input Class Initialized
INFO - 2016-02-07 15:16:41 --> Language Class Initialized
INFO - 2016-02-07 15:16:41 --> Loader Class Initialized
INFO - 2016-02-07 15:16:41 --> Helper loaded: url_helper
INFO - 2016-02-07 15:16:41 --> Helper loaded: file_helper
INFO - 2016-02-07 15:16:41 --> Helper loaded: date_helper
INFO - 2016-02-07 15:16:41 --> Helper loaded: form_helper
INFO - 2016-02-07 15:16:41 --> Database Driver Class Initialized
INFO - 2016-02-07 15:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:16:42 --> Controller Class Initialized
INFO - 2016-02-07 15:16:42 --> Model Class Initialized
INFO - 2016-02-07 15:16:42 --> Model Class Initialized
INFO - 2016-02-07 15:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:16:42 --> Pagination Class Initialized
INFO - 2016-02-07 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:16:42 --> Final output sent to browser
DEBUG - 2016-02-07 15:16:42 --> Total execution time: 1.1209
INFO - 2016-02-07 15:16:44 --> Config Class Initialized
INFO - 2016-02-07 15:16:44 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:16:44 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:16:44 --> Utf8 Class Initialized
INFO - 2016-02-07 15:16:44 --> URI Class Initialized
INFO - 2016-02-07 15:16:44 --> Router Class Initialized
INFO - 2016-02-07 15:16:44 --> Output Class Initialized
INFO - 2016-02-07 15:16:44 --> Security Class Initialized
DEBUG - 2016-02-07 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:16:44 --> Input Class Initialized
INFO - 2016-02-07 15:16:44 --> Language Class Initialized
INFO - 2016-02-07 15:16:44 --> Loader Class Initialized
INFO - 2016-02-07 15:16:44 --> Helper loaded: url_helper
INFO - 2016-02-07 15:16:44 --> Helper loaded: file_helper
INFO - 2016-02-07 15:16:44 --> Helper loaded: date_helper
INFO - 2016-02-07 15:16:44 --> Helper loaded: form_helper
INFO - 2016-02-07 15:16:44 --> Database Driver Class Initialized
INFO - 2016-02-07 15:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:16:45 --> Controller Class Initialized
INFO - 2016-02-07 15:16:45 --> Model Class Initialized
INFO - 2016-02-07 15:16:45 --> Model Class Initialized
INFO - 2016-02-07 15:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:16:45 --> Pagination Class Initialized
INFO - 2016-02-07 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:16:45 --> Helper loaded: text_helper
INFO - 2016-02-07 15:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:16:46 --> Final output sent to browser
DEBUG - 2016-02-07 15:16:46 --> Total execution time: 1.2781
INFO - 2016-02-07 15:17:09 --> Config Class Initialized
INFO - 2016-02-07 15:17:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:17:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:17:09 --> Utf8 Class Initialized
INFO - 2016-02-07 15:17:09 --> URI Class Initialized
DEBUG - 2016-02-07 15:17:09 --> No URI present. Default controller set.
INFO - 2016-02-07 15:17:09 --> Router Class Initialized
INFO - 2016-02-07 15:17:09 --> Output Class Initialized
INFO - 2016-02-07 15:17:09 --> Security Class Initialized
DEBUG - 2016-02-07 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:17:09 --> Input Class Initialized
INFO - 2016-02-07 15:17:09 --> Language Class Initialized
INFO - 2016-02-07 15:17:09 --> Loader Class Initialized
INFO - 2016-02-07 15:17:09 --> Helper loaded: url_helper
INFO - 2016-02-07 15:17:09 --> Helper loaded: file_helper
INFO - 2016-02-07 15:17:09 --> Helper loaded: date_helper
INFO - 2016-02-07 15:17:09 --> Helper loaded: form_helper
INFO - 2016-02-07 15:17:09 --> Database Driver Class Initialized
INFO - 2016-02-07 15:17:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:17:10 --> Controller Class Initialized
INFO - 2016-02-07 15:17:10 --> Model Class Initialized
INFO - 2016-02-07 15:17:10 --> Model Class Initialized
INFO - 2016-02-07 15:17:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:17:10 --> Pagination Class Initialized
INFO - 2016-02-07 15:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:17:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:17:10 --> Final output sent to browser
DEBUG - 2016-02-07 15:17:10 --> Total execution time: 1.1311
INFO - 2016-02-07 15:17:27 --> Config Class Initialized
INFO - 2016-02-07 15:17:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:17:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:17:27 --> Utf8 Class Initialized
INFO - 2016-02-07 15:17:27 --> URI Class Initialized
INFO - 2016-02-07 15:17:27 --> Router Class Initialized
INFO - 2016-02-07 15:17:27 --> Output Class Initialized
INFO - 2016-02-07 15:17:27 --> Security Class Initialized
DEBUG - 2016-02-07 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:17:27 --> Input Class Initialized
INFO - 2016-02-07 15:17:27 --> Language Class Initialized
INFO - 2016-02-07 15:17:27 --> Loader Class Initialized
INFO - 2016-02-07 15:17:27 --> Helper loaded: url_helper
INFO - 2016-02-07 15:17:28 --> Helper loaded: file_helper
INFO - 2016-02-07 15:17:28 --> Helper loaded: date_helper
INFO - 2016-02-07 15:17:28 --> Helper loaded: form_helper
INFO - 2016-02-07 15:17:28 --> Database Driver Class Initialized
INFO - 2016-02-07 15:17:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:17:29 --> Controller Class Initialized
INFO - 2016-02-07 15:17:29 --> Model Class Initialized
INFO - 2016-02-07 15:17:29 --> Model Class Initialized
INFO - 2016-02-07 15:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:17:29 --> Pagination Class Initialized
INFO - 2016-02-07 15:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:17:29 --> Helper loaded: text_helper
INFO - 2016-02-07 15:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:17:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:17:29 --> Final output sent to browser
DEBUG - 2016-02-07 15:17:29 --> Total execution time: 1.1956
INFO - 2016-02-07 15:17:56 --> Config Class Initialized
INFO - 2016-02-07 15:17:56 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:17:56 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:17:56 --> Utf8 Class Initialized
INFO - 2016-02-07 15:17:56 --> URI Class Initialized
INFO - 2016-02-07 15:17:56 --> Router Class Initialized
INFO - 2016-02-07 15:17:56 --> Output Class Initialized
INFO - 2016-02-07 15:17:56 --> Security Class Initialized
DEBUG - 2016-02-07 15:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:17:56 --> Input Class Initialized
INFO - 2016-02-07 15:17:56 --> Language Class Initialized
INFO - 2016-02-07 15:17:56 --> Loader Class Initialized
INFO - 2016-02-07 15:17:56 --> Helper loaded: url_helper
INFO - 2016-02-07 15:17:56 --> Helper loaded: file_helper
INFO - 2016-02-07 15:17:56 --> Helper loaded: date_helper
INFO - 2016-02-07 15:17:56 --> Helper loaded: form_helper
INFO - 2016-02-07 15:17:56 --> Database Driver Class Initialized
INFO - 2016-02-07 15:17:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:17:57 --> Controller Class Initialized
INFO - 2016-02-07 15:17:57 --> Model Class Initialized
INFO - 2016-02-07 15:17:57 --> Model Class Initialized
INFO - 2016-02-07 15:17:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:17:57 --> Pagination Class Initialized
INFO - 2016-02-07 15:17:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:17:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:17:57 --> Helper loaded: text_helper
INFO - 2016-02-07 15:17:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:17:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:17:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:17:57 --> Final output sent to browser
DEBUG - 2016-02-07 15:17:57 --> Total execution time: 1.1436
INFO - 2016-02-07 15:18:12 --> Config Class Initialized
INFO - 2016-02-07 15:18:12 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:18:12 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:18:12 --> Utf8 Class Initialized
INFO - 2016-02-07 15:18:12 --> URI Class Initialized
INFO - 2016-02-07 15:18:12 --> Router Class Initialized
INFO - 2016-02-07 15:18:12 --> Output Class Initialized
INFO - 2016-02-07 15:18:12 --> Security Class Initialized
DEBUG - 2016-02-07 15:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:18:12 --> Input Class Initialized
INFO - 2016-02-07 15:18:12 --> Language Class Initialized
INFO - 2016-02-07 15:18:13 --> Loader Class Initialized
INFO - 2016-02-07 15:18:13 --> Helper loaded: url_helper
INFO - 2016-02-07 15:18:13 --> Helper loaded: file_helper
INFO - 2016-02-07 15:18:13 --> Helper loaded: date_helper
INFO - 2016-02-07 15:18:13 --> Helper loaded: form_helper
INFO - 2016-02-07 15:18:13 --> Database Driver Class Initialized
INFO - 2016-02-07 15:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:18:14 --> Controller Class Initialized
INFO - 2016-02-07 15:18:14 --> Model Class Initialized
INFO - 2016-02-07 15:18:14 --> Model Class Initialized
INFO - 2016-02-07 15:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:18:14 --> Pagination Class Initialized
INFO - 2016-02-07 15:18:14 --> Form Validation Class Initialized
INFO - 2016-02-07 15:18:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 15:18:14 --> Model Class Initialized
INFO - 2016-02-07 15:18:14 --> Final output sent to browser
DEBUG - 2016-02-07 15:18:14 --> Total execution time: 1.2024
INFO - 2016-02-07 15:40:59 --> Config Class Initialized
INFO - 2016-02-07 15:40:59 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:40:59 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:40:59 --> Utf8 Class Initialized
INFO - 2016-02-07 15:40:59 --> URI Class Initialized
DEBUG - 2016-02-07 15:40:59 --> No URI present. Default controller set.
INFO - 2016-02-07 15:40:59 --> Router Class Initialized
INFO - 2016-02-07 15:40:59 --> Output Class Initialized
INFO - 2016-02-07 15:40:59 --> Security Class Initialized
DEBUG - 2016-02-07 15:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:40:59 --> Input Class Initialized
INFO - 2016-02-07 15:40:59 --> Language Class Initialized
INFO - 2016-02-07 15:40:59 --> Loader Class Initialized
INFO - 2016-02-07 15:40:59 --> Helper loaded: url_helper
INFO - 2016-02-07 15:40:59 --> Helper loaded: file_helper
INFO - 2016-02-07 15:40:59 --> Helper loaded: date_helper
INFO - 2016-02-07 15:40:59 --> Helper loaded: form_helper
INFO - 2016-02-07 15:40:59 --> Database Driver Class Initialized
INFO - 2016-02-07 15:41:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:41:00 --> Controller Class Initialized
INFO - 2016-02-07 15:41:00 --> Model Class Initialized
INFO - 2016-02-07 15:41:00 --> Model Class Initialized
INFO - 2016-02-07 15:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:41:00 --> Pagination Class Initialized
INFO - 2016-02-07 15:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 15:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:41:00 --> Final output sent to browser
DEBUG - 2016-02-07 15:41:00 --> Total execution time: 1.1594
INFO - 2016-02-07 15:41:01 --> Config Class Initialized
INFO - 2016-02-07 15:41:01 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:41:01 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:41:01 --> Utf8 Class Initialized
INFO - 2016-02-07 15:41:01 --> URI Class Initialized
INFO - 2016-02-07 15:41:01 --> Router Class Initialized
INFO - 2016-02-07 15:41:01 --> Output Class Initialized
INFO - 2016-02-07 15:41:01 --> Security Class Initialized
DEBUG - 2016-02-07 15:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:41:01 --> Input Class Initialized
INFO - 2016-02-07 15:41:01 --> Language Class Initialized
INFO - 2016-02-07 15:41:02 --> Loader Class Initialized
INFO - 2016-02-07 15:41:02 --> Helper loaded: url_helper
INFO - 2016-02-07 15:41:02 --> Helper loaded: file_helper
INFO - 2016-02-07 15:41:02 --> Helper loaded: date_helper
INFO - 2016-02-07 15:41:02 --> Helper loaded: form_helper
INFO - 2016-02-07 15:41:02 --> Database Driver Class Initialized
INFO - 2016-02-07 15:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:41:03 --> Controller Class Initialized
INFO - 2016-02-07 15:41:03 --> Model Class Initialized
INFO - 2016-02-07 15:41:03 --> Model Class Initialized
INFO - 2016-02-07 15:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:41:03 --> Pagination Class Initialized
INFO - 2016-02-07 15:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:41:03 --> Helper loaded: text_helper
INFO - 2016-02-07 15:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:41:03 --> Final output sent to browser
DEBUG - 2016-02-07 15:41:03 --> Total execution time: 1.2009
INFO - 2016-02-07 15:41:10 --> Config Class Initialized
INFO - 2016-02-07 15:41:10 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:41:10 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:41:10 --> Utf8 Class Initialized
INFO - 2016-02-07 15:41:10 --> URI Class Initialized
INFO - 2016-02-07 15:41:10 --> Router Class Initialized
INFO - 2016-02-07 15:41:10 --> Output Class Initialized
INFO - 2016-02-07 15:41:10 --> Security Class Initialized
DEBUG - 2016-02-07 15:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:41:10 --> Input Class Initialized
INFO - 2016-02-07 15:41:10 --> Language Class Initialized
INFO - 2016-02-07 15:41:10 --> Loader Class Initialized
INFO - 2016-02-07 15:41:10 --> Helper loaded: url_helper
INFO - 2016-02-07 15:41:10 --> Helper loaded: file_helper
INFO - 2016-02-07 15:41:10 --> Helper loaded: date_helper
INFO - 2016-02-07 15:41:10 --> Helper loaded: form_helper
INFO - 2016-02-07 15:41:10 --> Database Driver Class Initialized
INFO - 2016-02-07 15:41:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:41:11 --> Controller Class Initialized
INFO - 2016-02-07 15:41:12 --> Model Class Initialized
INFO - 2016-02-07 15:41:12 --> Model Class Initialized
INFO - 2016-02-07 15:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:41:12 --> Pagination Class Initialized
INFO - 2016-02-07 15:41:12 --> Form Validation Class Initialized
INFO - 2016-02-07 15:41:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 15:41:12 --> Model Class Initialized
INFO - 2016-02-07 15:41:12 --> Final output sent to browser
DEBUG - 2016-02-07 15:41:12 --> Total execution time: 1.2125
INFO - 2016-02-07 15:41:24 --> Config Class Initialized
INFO - 2016-02-07 15:41:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 15:41:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 15:41:24 --> Utf8 Class Initialized
INFO - 2016-02-07 15:41:24 --> URI Class Initialized
INFO - 2016-02-07 15:41:24 --> Router Class Initialized
INFO - 2016-02-07 15:41:24 --> Output Class Initialized
INFO - 2016-02-07 15:41:24 --> Security Class Initialized
DEBUG - 2016-02-07 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 15:41:24 --> Input Class Initialized
INFO - 2016-02-07 15:41:24 --> Language Class Initialized
INFO - 2016-02-07 15:41:24 --> Loader Class Initialized
INFO - 2016-02-07 15:41:24 --> Helper loaded: url_helper
INFO - 2016-02-07 15:41:24 --> Helper loaded: file_helper
INFO - 2016-02-07 15:41:24 --> Helper loaded: date_helper
INFO - 2016-02-07 15:41:24 --> Helper loaded: form_helper
INFO - 2016-02-07 15:41:24 --> Database Driver Class Initialized
INFO - 2016-02-07 15:41:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 15:41:25 --> Controller Class Initialized
INFO - 2016-02-07 15:41:25 --> Model Class Initialized
INFO - 2016-02-07 15:41:25 --> Model Class Initialized
INFO - 2016-02-07 15:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 15:41:25 --> Pagination Class Initialized
INFO - 2016-02-07 15:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 15:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 15:41:25 --> Helper loaded: text_helper
INFO - 2016-02-07 15:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 15:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 15:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 15:41:25 --> Final output sent to browser
DEBUG - 2016-02-07 15:41:25 --> Total execution time: 1.2259
INFO - 2016-02-07 16:34:03 --> Config Class Initialized
INFO - 2016-02-07 16:34:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:34:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:34:03 --> Utf8 Class Initialized
INFO - 2016-02-07 16:34:03 --> URI Class Initialized
DEBUG - 2016-02-07 16:34:03 --> No URI present. Default controller set.
INFO - 2016-02-07 16:34:03 --> Router Class Initialized
INFO - 2016-02-07 16:34:03 --> Output Class Initialized
INFO - 2016-02-07 16:34:03 --> Security Class Initialized
DEBUG - 2016-02-07 16:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:34:03 --> Input Class Initialized
INFO - 2016-02-07 16:34:03 --> Language Class Initialized
INFO - 2016-02-07 16:34:03 --> Loader Class Initialized
INFO - 2016-02-07 16:34:03 --> Helper loaded: url_helper
INFO - 2016-02-07 16:34:03 --> Helper loaded: file_helper
INFO - 2016-02-07 16:34:03 --> Helper loaded: date_helper
INFO - 2016-02-07 16:34:03 --> Helper loaded: form_helper
INFO - 2016-02-07 16:34:03 --> Database Driver Class Initialized
INFO - 2016-02-07 16:34:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:34:04 --> Controller Class Initialized
INFO - 2016-02-07 16:34:04 --> Model Class Initialized
INFO - 2016-02-07 16:34:04 --> Model Class Initialized
INFO - 2016-02-07 16:34:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:34:04 --> Pagination Class Initialized
INFO - 2016-02-07 16:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:34:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:34:04 --> Final output sent to browser
DEBUG - 2016-02-07 16:34:04 --> Total execution time: 1.1029
INFO - 2016-02-07 16:35:32 --> Config Class Initialized
INFO - 2016-02-07 16:35:33 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:35:33 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:35:33 --> Utf8 Class Initialized
INFO - 2016-02-07 16:35:33 --> URI Class Initialized
DEBUG - 2016-02-07 16:35:33 --> No URI present. Default controller set.
INFO - 2016-02-07 16:35:33 --> Router Class Initialized
INFO - 2016-02-07 16:35:33 --> Output Class Initialized
INFO - 2016-02-07 16:35:33 --> Security Class Initialized
DEBUG - 2016-02-07 16:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:35:33 --> Input Class Initialized
INFO - 2016-02-07 16:35:33 --> Language Class Initialized
INFO - 2016-02-07 16:35:33 --> Loader Class Initialized
INFO - 2016-02-07 16:35:33 --> Helper loaded: url_helper
INFO - 2016-02-07 16:35:33 --> Helper loaded: file_helper
INFO - 2016-02-07 16:35:33 --> Helper loaded: date_helper
INFO - 2016-02-07 16:35:33 --> Helper loaded: form_helper
INFO - 2016-02-07 16:35:33 --> Database Driver Class Initialized
INFO - 2016-02-07 16:35:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:35:34 --> Controller Class Initialized
INFO - 2016-02-07 16:35:34 --> Model Class Initialized
INFO - 2016-02-07 16:35:34 --> Model Class Initialized
INFO - 2016-02-07 16:35:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:35:34 --> Pagination Class Initialized
INFO - 2016-02-07 16:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:35:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:35:34 --> Final output sent to browser
DEBUG - 2016-02-07 16:35:34 --> Total execution time: 1.1265
INFO - 2016-02-07 16:39:12 --> Config Class Initialized
INFO - 2016-02-07 16:39:12 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:39:12 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:39:12 --> Utf8 Class Initialized
INFO - 2016-02-07 16:39:12 --> URI Class Initialized
DEBUG - 2016-02-07 16:39:12 --> No URI present. Default controller set.
INFO - 2016-02-07 16:39:12 --> Router Class Initialized
INFO - 2016-02-07 16:39:12 --> Output Class Initialized
INFO - 2016-02-07 16:39:12 --> Security Class Initialized
DEBUG - 2016-02-07 16:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:39:12 --> Input Class Initialized
INFO - 2016-02-07 16:39:12 --> Language Class Initialized
INFO - 2016-02-07 16:39:12 --> Loader Class Initialized
INFO - 2016-02-07 16:39:12 --> Helper loaded: url_helper
INFO - 2016-02-07 16:39:12 --> Helper loaded: file_helper
INFO - 2016-02-07 16:39:12 --> Helper loaded: date_helper
INFO - 2016-02-07 16:39:12 --> Helper loaded: form_helper
INFO - 2016-02-07 16:39:12 --> Database Driver Class Initialized
INFO - 2016-02-07 16:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:39:13 --> Controller Class Initialized
INFO - 2016-02-07 16:39:13 --> Model Class Initialized
INFO - 2016-02-07 16:39:14 --> Model Class Initialized
INFO - 2016-02-07 16:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:39:14 --> Pagination Class Initialized
INFO - 2016-02-07 16:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:39:14 --> Final output sent to browser
DEBUG - 2016-02-07 16:39:14 --> Total execution time: 1.1657
INFO - 2016-02-07 16:39:49 --> Config Class Initialized
INFO - 2016-02-07 16:39:49 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:39:49 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:39:49 --> Utf8 Class Initialized
INFO - 2016-02-07 16:39:49 --> URI Class Initialized
DEBUG - 2016-02-07 16:39:49 --> No URI present. Default controller set.
INFO - 2016-02-07 16:39:49 --> Router Class Initialized
INFO - 2016-02-07 16:39:49 --> Output Class Initialized
INFO - 2016-02-07 16:39:49 --> Security Class Initialized
DEBUG - 2016-02-07 16:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:39:49 --> Input Class Initialized
INFO - 2016-02-07 16:39:49 --> Language Class Initialized
INFO - 2016-02-07 16:39:49 --> Loader Class Initialized
INFO - 2016-02-07 16:39:49 --> Helper loaded: url_helper
INFO - 2016-02-07 16:39:49 --> Helper loaded: file_helper
INFO - 2016-02-07 16:39:49 --> Helper loaded: date_helper
INFO - 2016-02-07 16:39:49 --> Helper loaded: form_helper
INFO - 2016-02-07 16:39:49 --> Database Driver Class Initialized
INFO - 2016-02-07 16:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:39:50 --> Controller Class Initialized
INFO - 2016-02-07 16:39:50 --> Model Class Initialized
INFO - 2016-02-07 16:39:50 --> Model Class Initialized
INFO - 2016-02-07 16:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:39:50 --> Pagination Class Initialized
INFO - 2016-02-07 16:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:39:50 --> Final output sent to browser
DEBUG - 2016-02-07 16:39:50 --> Total execution time: 1.1751
INFO - 2016-02-07 16:40:14 --> Config Class Initialized
INFO - 2016-02-07 16:40:14 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:40:14 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:40:14 --> Utf8 Class Initialized
INFO - 2016-02-07 16:40:14 --> URI Class Initialized
DEBUG - 2016-02-07 16:40:14 --> No URI present. Default controller set.
INFO - 2016-02-07 16:40:14 --> Router Class Initialized
INFO - 2016-02-07 16:40:14 --> Output Class Initialized
INFO - 2016-02-07 16:40:14 --> Security Class Initialized
DEBUG - 2016-02-07 16:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:40:14 --> Input Class Initialized
INFO - 2016-02-07 16:40:14 --> Language Class Initialized
INFO - 2016-02-07 16:40:14 --> Loader Class Initialized
INFO - 2016-02-07 16:40:14 --> Helper loaded: url_helper
INFO - 2016-02-07 16:40:14 --> Helper loaded: file_helper
INFO - 2016-02-07 16:40:14 --> Helper loaded: date_helper
INFO - 2016-02-07 16:40:14 --> Helper loaded: form_helper
INFO - 2016-02-07 16:40:14 --> Database Driver Class Initialized
INFO - 2016-02-07 16:40:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:40:15 --> Controller Class Initialized
INFO - 2016-02-07 16:40:15 --> Model Class Initialized
INFO - 2016-02-07 16:40:15 --> Model Class Initialized
INFO - 2016-02-07 16:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:40:15 --> Pagination Class Initialized
INFO - 2016-02-07 16:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:40:15 --> Final output sent to browser
DEBUG - 2016-02-07 16:40:15 --> Total execution time: 1.1587
INFO - 2016-02-07 16:46:56 --> Config Class Initialized
INFO - 2016-02-07 16:46:56 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:46:56 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:46:56 --> Utf8 Class Initialized
INFO - 2016-02-07 16:46:56 --> URI Class Initialized
INFO - 2016-02-07 16:46:56 --> Router Class Initialized
INFO - 2016-02-07 16:46:56 --> Output Class Initialized
INFO - 2016-02-07 16:46:56 --> Security Class Initialized
DEBUG - 2016-02-07 16:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:46:56 --> Input Class Initialized
INFO - 2016-02-07 16:46:56 --> Language Class Initialized
INFO - 2016-02-07 16:46:56 --> Loader Class Initialized
INFO - 2016-02-07 16:46:56 --> Helper loaded: url_helper
INFO - 2016-02-07 16:46:56 --> Helper loaded: file_helper
INFO - 2016-02-07 16:46:56 --> Helper loaded: date_helper
INFO - 2016-02-07 16:46:56 --> Helper loaded: form_helper
INFO - 2016-02-07 16:46:56 --> Database Driver Class Initialized
INFO - 2016-02-07 16:46:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:46:57 --> Controller Class Initialized
INFO - 2016-02-07 16:46:57 --> Model Class Initialized
INFO - 2016-02-07 16:46:57 --> Model Class Initialized
INFO - 2016-02-07 16:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:46:57 --> Pagination Class Initialized
INFO - 2016-02-07 16:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:46:57 --> Final output sent to browser
DEBUG - 2016-02-07 16:46:57 --> Total execution time: 1.1679
INFO - 2016-02-07 16:50:20 --> Config Class Initialized
INFO - 2016-02-07 16:50:20 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:50:20 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:50:20 --> Utf8 Class Initialized
INFO - 2016-02-07 16:50:20 --> URI Class Initialized
INFO - 2016-02-07 16:50:20 --> Router Class Initialized
INFO - 2016-02-07 16:50:20 --> Output Class Initialized
INFO - 2016-02-07 16:50:20 --> Security Class Initialized
DEBUG - 2016-02-07 16:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:50:20 --> Input Class Initialized
INFO - 2016-02-07 16:50:20 --> Language Class Initialized
INFO - 2016-02-07 16:50:20 --> Loader Class Initialized
INFO - 2016-02-07 16:50:20 --> Helper loaded: url_helper
INFO - 2016-02-07 16:50:20 --> Helper loaded: file_helper
INFO - 2016-02-07 16:50:20 --> Helper loaded: date_helper
INFO - 2016-02-07 16:50:20 --> Helper loaded: form_helper
INFO - 2016-02-07 16:50:20 --> Database Driver Class Initialized
INFO - 2016-02-07 16:50:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:50:21 --> Controller Class Initialized
INFO - 2016-02-07 16:50:21 --> Model Class Initialized
INFO - 2016-02-07 16:50:21 --> Model Class Initialized
INFO - 2016-02-07 16:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:50:21 --> Pagination Class Initialized
INFO - 2016-02-07 16:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:50:21 --> Final output sent to browser
DEBUG - 2016-02-07 16:50:21 --> Total execution time: 1.1498
INFO - 2016-02-07 16:50:24 --> Config Class Initialized
INFO - 2016-02-07 16:50:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:50:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:50:24 --> Utf8 Class Initialized
INFO - 2016-02-07 16:50:24 --> URI Class Initialized
INFO - 2016-02-07 16:50:24 --> Router Class Initialized
INFO - 2016-02-07 16:50:24 --> Output Class Initialized
INFO - 2016-02-07 16:50:24 --> Security Class Initialized
DEBUG - 2016-02-07 16:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:50:24 --> Input Class Initialized
INFO - 2016-02-07 16:50:24 --> Language Class Initialized
INFO - 2016-02-07 16:50:24 --> Loader Class Initialized
INFO - 2016-02-07 16:50:24 --> Helper loaded: url_helper
INFO - 2016-02-07 16:50:24 --> Helper loaded: file_helper
INFO - 2016-02-07 16:50:24 --> Helper loaded: date_helper
INFO - 2016-02-07 16:50:24 --> Helper loaded: form_helper
INFO - 2016-02-07 16:50:24 --> Database Driver Class Initialized
INFO - 2016-02-07 16:50:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:50:25 --> Controller Class Initialized
INFO - 2016-02-07 16:50:25 --> Model Class Initialized
INFO - 2016-02-07 16:50:25 --> Model Class Initialized
INFO - 2016-02-07 16:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:50:25 --> Pagination Class Initialized
INFO - 2016-02-07 16:50:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:50:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:50:25 --> Helper loaded: text_helper
INFO - 2016-02-07 16:50:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 16:50:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 16:50:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:50:25 --> Final output sent to browser
DEBUG - 2016-02-07 16:50:25 --> Total execution time: 1.1799
INFO - 2016-02-07 16:50:33 --> Config Class Initialized
INFO - 2016-02-07 16:50:33 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:50:33 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:50:33 --> Utf8 Class Initialized
INFO - 2016-02-07 16:50:33 --> URI Class Initialized
DEBUG - 2016-02-07 16:50:33 --> No URI present. Default controller set.
INFO - 2016-02-07 16:50:33 --> Router Class Initialized
INFO - 2016-02-07 16:50:33 --> Output Class Initialized
INFO - 2016-02-07 16:50:33 --> Security Class Initialized
DEBUG - 2016-02-07 16:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:50:33 --> Input Class Initialized
INFO - 2016-02-07 16:50:33 --> Language Class Initialized
INFO - 2016-02-07 16:50:33 --> Loader Class Initialized
INFO - 2016-02-07 16:50:33 --> Helper loaded: url_helper
INFO - 2016-02-07 16:50:33 --> Helper loaded: file_helper
INFO - 2016-02-07 16:50:33 --> Helper loaded: date_helper
INFO - 2016-02-07 16:50:33 --> Helper loaded: form_helper
INFO - 2016-02-07 16:50:33 --> Database Driver Class Initialized
INFO - 2016-02-07 16:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:50:34 --> Controller Class Initialized
INFO - 2016-02-07 16:50:34 --> Model Class Initialized
INFO - 2016-02-07 16:50:34 --> Model Class Initialized
INFO - 2016-02-07 16:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:50:34 --> Pagination Class Initialized
INFO - 2016-02-07 16:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:50:34 --> Final output sent to browser
DEBUG - 2016-02-07 16:50:34 --> Total execution time: 1.1296
INFO - 2016-02-07 16:50:41 --> Config Class Initialized
INFO - 2016-02-07 16:50:41 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:50:41 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:50:41 --> Utf8 Class Initialized
INFO - 2016-02-07 16:50:41 --> URI Class Initialized
INFO - 2016-02-07 16:50:41 --> Router Class Initialized
INFO - 2016-02-07 16:50:41 --> Output Class Initialized
INFO - 2016-02-07 16:50:41 --> Security Class Initialized
DEBUG - 2016-02-07 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:50:41 --> Input Class Initialized
INFO - 2016-02-07 16:50:41 --> Language Class Initialized
INFO - 2016-02-07 16:50:41 --> Loader Class Initialized
INFO - 2016-02-07 16:50:41 --> Helper loaded: url_helper
INFO - 2016-02-07 16:50:41 --> Helper loaded: file_helper
INFO - 2016-02-07 16:50:41 --> Helper loaded: date_helper
INFO - 2016-02-07 16:50:41 --> Helper loaded: form_helper
INFO - 2016-02-07 16:50:41 --> Database Driver Class Initialized
INFO - 2016-02-07 16:50:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:50:42 --> Controller Class Initialized
INFO - 2016-02-07 16:50:42 --> Model Class Initialized
INFO - 2016-02-07 16:50:42 --> Model Class Initialized
INFO - 2016-02-07 16:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:50:42 --> Pagination Class Initialized
INFO - 2016-02-07 16:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:50:42 --> Helper loaded: text_helper
INFO - 2016-02-07 16:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 16:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 16:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:50:42 --> Final output sent to browser
DEBUG - 2016-02-07 16:50:42 --> Total execution time: 1.1606
INFO - 2016-02-07 16:50:49 --> Config Class Initialized
INFO - 2016-02-07 16:50:49 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:50:49 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:50:49 --> Utf8 Class Initialized
INFO - 2016-02-07 16:50:49 --> URI Class Initialized
DEBUG - 2016-02-07 16:50:49 --> No URI present. Default controller set.
INFO - 2016-02-07 16:50:49 --> Router Class Initialized
INFO - 2016-02-07 16:50:49 --> Output Class Initialized
INFO - 2016-02-07 16:50:49 --> Security Class Initialized
DEBUG - 2016-02-07 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:50:49 --> Input Class Initialized
INFO - 2016-02-07 16:50:49 --> Language Class Initialized
INFO - 2016-02-07 16:50:49 --> Loader Class Initialized
INFO - 2016-02-07 16:50:49 --> Helper loaded: url_helper
INFO - 2016-02-07 16:50:49 --> Helper loaded: file_helper
INFO - 2016-02-07 16:50:49 --> Helper loaded: date_helper
INFO - 2016-02-07 16:50:49 --> Helper loaded: form_helper
INFO - 2016-02-07 16:50:49 --> Database Driver Class Initialized
INFO - 2016-02-07 16:50:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:50:50 --> Controller Class Initialized
INFO - 2016-02-07 16:50:50 --> Model Class Initialized
INFO - 2016-02-07 16:50:50 --> Model Class Initialized
INFO - 2016-02-07 16:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:50:50 --> Pagination Class Initialized
INFO - 2016-02-07 16:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:50:50 --> Final output sent to browser
DEBUG - 2016-02-07 16:50:50 --> Total execution time: 1.0958
INFO - 2016-02-07 16:51:45 --> Config Class Initialized
INFO - 2016-02-07 16:51:45 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:51:45 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:51:45 --> Utf8 Class Initialized
INFO - 2016-02-07 16:51:45 --> URI Class Initialized
DEBUG - 2016-02-07 16:51:45 --> No URI present. Default controller set.
INFO - 2016-02-07 16:51:45 --> Router Class Initialized
INFO - 2016-02-07 16:51:45 --> Output Class Initialized
INFO - 2016-02-07 16:51:45 --> Security Class Initialized
DEBUG - 2016-02-07 16:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:51:45 --> Input Class Initialized
INFO - 2016-02-07 16:51:45 --> Language Class Initialized
INFO - 2016-02-07 16:51:45 --> Loader Class Initialized
INFO - 2016-02-07 16:51:45 --> Helper loaded: url_helper
INFO - 2016-02-07 16:51:45 --> Helper loaded: file_helper
INFO - 2016-02-07 16:51:45 --> Helper loaded: date_helper
INFO - 2016-02-07 16:51:45 --> Helper loaded: form_helper
INFO - 2016-02-07 16:51:45 --> Database Driver Class Initialized
INFO - 2016-02-07 16:51:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:51:46 --> Controller Class Initialized
INFO - 2016-02-07 16:51:46 --> Model Class Initialized
INFO - 2016-02-07 16:51:46 --> Model Class Initialized
INFO - 2016-02-07 16:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:51:46 --> Pagination Class Initialized
INFO - 2016-02-07 16:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:51:46 --> Final output sent to browser
DEBUG - 2016-02-07 16:51:46 --> Total execution time: 1.1503
INFO - 2016-02-07 16:51:54 --> Config Class Initialized
INFO - 2016-02-07 16:51:54 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:51:54 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:51:54 --> Utf8 Class Initialized
INFO - 2016-02-07 16:51:54 --> URI Class Initialized
INFO - 2016-02-07 16:51:54 --> Router Class Initialized
INFO - 2016-02-07 16:51:54 --> Output Class Initialized
INFO - 2016-02-07 16:51:54 --> Security Class Initialized
DEBUG - 2016-02-07 16:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:51:54 --> Input Class Initialized
INFO - 2016-02-07 16:51:54 --> Language Class Initialized
INFO - 2016-02-07 16:51:54 --> Loader Class Initialized
INFO - 2016-02-07 16:51:54 --> Helper loaded: url_helper
INFO - 2016-02-07 16:51:54 --> Helper loaded: file_helper
INFO - 2016-02-07 16:51:54 --> Helper loaded: date_helper
INFO - 2016-02-07 16:51:54 --> Helper loaded: form_helper
INFO - 2016-02-07 16:51:54 --> Database Driver Class Initialized
INFO - 2016-02-07 16:51:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:51:55 --> Controller Class Initialized
INFO - 2016-02-07 16:51:55 --> Model Class Initialized
INFO - 2016-02-07 16:51:55 --> Model Class Initialized
INFO - 2016-02-07 16:51:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:51:55 --> Pagination Class Initialized
INFO - 2016-02-07 16:51:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:51:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:51:55 --> Helper loaded: text_helper
INFO - 2016-02-07 16:51:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 16:51:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 16:51:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:51:55 --> Final output sent to browser
DEBUG - 2016-02-07 16:51:55 --> Total execution time: 1.1427
INFO - 2016-02-07 16:52:17 --> Config Class Initialized
INFO - 2016-02-07 16:52:17 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:52:17 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:52:17 --> Utf8 Class Initialized
INFO - 2016-02-07 16:52:17 --> URI Class Initialized
DEBUG - 2016-02-07 16:52:17 --> No URI present. Default controller set.
INFO - 2016-02-07 16:52:17 --> Router Class Initialized
INFO - 2016-02-07 16:52:17 --> Output Class Initialized
INFO - 2016-02-07 16:52:17 --> Security Class Initialized
DEBUG - 2016-02-07 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:52:17 --> Input Class Initialized
INFO - 2016-02-07 16:52:17 --> Language Class Initialized
INFO - 2016-02-07 16:52:17 --> Loader Class Initialized
INFO - 2016-02-07 16:52:17 --> Helper loaded: url_helper
INFO - 2016-02-07 16:52:17 --> Helper loaded: file_helper
INFO - 2016-02-07 16:52:17 --> Helper loaded: date_helper
INFO - 2016-02-07 16:52:17 --> Helper loaded: form_helper
INFO - 2016-02-07 16:52:17 --> Database Driver Class Initialized
INFO - 2016-02-07 16:52:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:52:18 --> Controller Class Initialized
INFO - 2016-02-07 16:52:18 --> Model Class Initialized
INFO - 2016-02-07 16:52:18 --> Model Class Initialized
INFO - 2016-02-07 16:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:52:18 --> Pagination Class Initialized
INFO - 2016-02-07 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:52:18 --> Final output sent to browser
DEBUG - 2016-02-07 16:52:18 --> Total execution time: 1.1382
INFO - 2016-02-07 16:52:22 --> Config Class Initialized
INFO - 2016-02-07 16:52:22 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:52:22 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:52:22 --> Utf8 Class Initialized
INFO - 2016-02-07 16:52:22 --> URI Class Initialized
INFO - 2016-02-07 16:52:22 --> Router Class Initialized
INFO - 2016-02-07 16:52:22 --> Output Class Initialized
INFO - 2016-02-07 16:52:22 --> Security Class Initialized
DEBUG - 2016-02-07 16:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:52:22 --> Input Class Initialized
INFO - 2016-02-07 16:52:22 --> Language Class Initialized
INFO - 2016-02-07 16:52:22 --> Loader Class Initialized
INFO - 2016-02-07 16:52:23 --> Helper loaded: url_helper
INFO - 2016-02-07 16:52:23 --> Helper loaded: file_helper
INFO - 2016-02-07 16:52:23 --> Helper loaded: date_helper
INFO - 2016-02-07 16:52:23 --> Helper loaded: form_helper
INFO - 2016-02-07 16:52:23 --> Database Driver Class Initialized
INFO - 2016-02-07 16:52:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:52:24 --> Controller Class Initialized
INFO - 2016-02-07 16:52:24 --> Model Class Initialized
INFO - 2016-02-07 16:52:24 --> Model Class Initialized
INFO - 2016-02-07 16:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:52:24 --> Pagination Class Initialized
INFO - 2016-02-07 16:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:52:24 --> Final output sent to browser
DEBUG - 2016-02-07 16:52:24 --> Total execution time: 1.1283
INFO - 2016-02-07 16:52:27 --> Config Class Initialized
INFO - 2016-02-07 16:52:27 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:52:27 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:52:27 --> Utf8 Class Initialized
INFO - 2016-02-07 16:52:27 --> URI Class Initialized
INFO - 2016-02-07 16:52:27 --> Router Class Initialized
INFO - 2016-02-07 16:52:27 --> Output Class Initialized
INFO - 2016-02-07 16:52:27 --> Security Class Initialized
DEBUG - 2016-02-07 16:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:52:27 --> Input Class Initialized
INFO - 2016-02-07 16:52:27 --> Language Class Initialized
INFO - 2016-02-07 16:52:27 --> Loader Class Initialized
INFO - 2016-02-07 16:52:27 --> Helper loaded: url_helper
INFO - 2016-02-07 16:52:27 --> Helper loaded: file_helper
INFO - 2016-02-07 16:52:27 --> Helper loaded: date_helper
INFO - 2016-02-07 16:52:27 --> Helper loaded: form_helper
INFO - 2016-02-07 16:52:27 --> Database Driver Class Initialized
INFO - 2016-02-07 16:52:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:52:28 --> Controller Class Initialized
INFO - 2016-02-07 16:52:28 --> Model Class Initialized
INFO - 2016-02-07 16:52:28 --> Model Class Initialized
INFO - 2016-02-07 16:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:52:29 --> Pagination Class Initialized
INFO - 2016-02-07 16:52:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:52:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:52:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:52:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:52:29 --> Final output sent to browser
DEBUG - 2016-02-07 16:52:29 --> Total execution time: 1.1213
INFO - 2016-02-07 16:53:00 --> Config Class Initialized
INFO - 2016-02-07 16:53:00 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:53:00 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:53:00 --> Utf8 Class Initialized
INFO - 2016-02-07 16:53:00 --> URI Class Initialized
INFO - 2016-02-07 16:53:00 --> Router Class Initialized
INFO - 2016-02-07 16:53:00 --> Output Class Initialized
INFO - 2016-02-07 16:53:00 --> Security Class Initialized
DEBUG - 2016-02-07 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:53:00 --> Input Class Initialized
INFO - 2016-02-07 16:53:00 --> Language Class Initialized
INFO - 2016-02-07 16:53:00 --> Loader Class Initialized
INFO - 2016-02-07 16:53:00 --> Helper loaded: url_helper
INFO - 2016-02-07 16:53:00 --> Helper loaded: file_helper
INFO - 2016-02-07 16:53:00 --> Helper loaded: date_helper
INFO - 2016-02-07 16:53:00 --> Helper loaded: form_helper
INFO - 2016-02-07 16:53:00 --> Database Driver Class Initialized
INFO - 2016-02-07 16:53:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:53:01 --> Controller Class Initialized
INFO - 2016-02-07 16:53:01 --> Model Class Initialized
INFO - 2016-02-07 16:53:01 --> Model Class Initialized
INFO - 2016-02-07 16:53:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:53:01 --> Pagination Class Initialized
INFO - 2016-02-07 16:53:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:53:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:53:01 --> Form Validation Class Initialized
INFO - 2016-02-07 16:53:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-07 16:53:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:53:01 --> Final output sent to browser
DEBUG - 2016-02-07 16:53:01 --> Total execution time: 1.1663
INFO - 2016-02-07 16:53:22 --> Config Class Initialized
INFO - 2016-02-07 16:53:22 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:53:22 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:53:22 --> Utf8 Class Initialized
INFO - 2016-02-07 16:53:22 --> URI Class Initialized
DEBUG - 2016-02-07 16:53:22 --> No URI present. Default controller set.
INFO - 2016-02-07 16:53:22 --> Router Class Initialized
INFO - 2016-02-07 16:53:22 --> Output Class Initialized
INFO - 2016-02-07 16:53:22 --> Security Class Initialized
DEBUG - 2016-02-07 16:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:53:22 --> Input Class Initialized
INFO - 2016-02-07 16:53:22 --> Language Class Initialized
INFO - 2016-02-07 16:53:22 --> Loader Class Initialized
INFO - 2016-02-07 16:53:22 --> Helper loaded: url_helper
INFO - 2016-02-07 16:53:22 --> Helper loaded: file_helper
INFO - 2016-02-07 16:53:22 --> Helper loaded: date_helper
INFO - 2016-02-07 16:53:22 --> Helper loaded: form_helper
INFO - 2016-02-07 16:53:22 --> Database Driver Class Initialized
INFO - 2016-02-07 16:53:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:53:23 --> Controller Class Initialized
INFO - 2016-02-07 16:53:23 --> Model Class Initialized
INFO - 2016-02-07 16:53:23 --> Model Class Initialized
INFO - 2016-02-07 16:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:53:23 --> Pagination Class Initialized
INFO - 2016-02-07 16:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 16:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:53:23 --> Final output sent to browser
DEBUG - 2016-02-07 16:53:23 --> Total execution time: 1.1528
INFO - 2016-02-07 16:56:32 --> Config Class Initialized
INFO - 2016-02-07 16:56:32 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:56:32 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:56:32 --> Utf8 Class Initialized
INFO - 2016-02-07 16:56:32 --> URI Class Initialized
INFO - 2016-02-07 16:56:32 --> Router Class Initialized
INFO - 2016-02-07 16:56:32 --> Output Class Initialized
INFO - 2016-02-07 16:56:32 --> Security Class Initialized
DEBUG - 2016-02-07 16:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:56:32 --> Input Class Initialized
INFO - 2016-02-07 16:56:32 --> Language Class Initialized
INFO - 2016-02-07 16:56:32 --> Loader Class Initialized
INFO - 2016-02-07 16:56:32 --> Helper loaded: url_helper
INFO - 2016-02-07 16:56:32 --> Helper loaded: file_helper
INFO - 2016-02-07 16:56:32 --> Helper loaded: date_helper
INFO - 2016-02-07 16:56:32 --> Helper loaded: form_helper
INFO - 2016-02-07 16:56:32 --> Database Driver Class Initialized
INFO - 2016-02-07 16:56:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:56:33 --> Controller Class Initialized
INFO - 2016-02-07 16:56:33 --> Model Class Initialized
INFO - 2016-02-07 16:56:33 --> Model Class Initialized
INFO - 2016-02-07 16:56:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:56:33 --> Pagination Class Initialized
INFO - 2016-02-07 16:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 16:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 16:56:33 --> Helper loaded: text_helper
INFO - 2016-02-07 16:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 16:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 16:56:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 16:56:33 --> Final output sent to browser
DEBUG - 2016-02-07 16:56:33 --> Total execution time: 1.2030
INFO - 2016-02-07 16:56:40 --> Config Class Initialized
INFO - 2016-02-07 16:56:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 16:56:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 16:56:40 --> Utf8 Class Initialized
INFO - 2016-02-07 16:56:40 --> URI Class Initialized
INFO - 2016-02-07 16:56:40 --> Router Class Initialized
INFO - 2016-02-07 16:56:40 --> Output Class Initialized
INFO - 2016-02-07 16:56:40 --> Security Class Initialized
DEBUG - 2016-02-07 16:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 16:56:40 --> Input Class Initialized
INFO - 2016-02-07 16:56:40 --> Language Class Initialized
INFO - 2016-02-07 16:56:40 --> Loader Class Initialized
INFO - 2016-02-07 16:56:40 --> Helper loaded: url_helper
INFO - 2016-02-07 16:56:40 --> Helper loaded: file_helper
INFO - 2016-02-07 16:56:40 --> Helper loaded: date_helper
INFO - 2016-02-07 16:56:40 --> Helper loaded: form_helper
INFO - 2016-02-07 16:56:40 --> Database Driver Class Initialized
INFO - 2016-02-07 16:56:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 16:56:41 --> Controller Class Initialized
INFO - 2016-02-07 16:56:41 --> Model Class Initialized
INFO - 2016-02-07 16:56:41 --> Model Class Initialized
INFO - 2016-02-07 16:56:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 16:56:41 --> Pagination Class Initialized
INFO - 2016-02-07 16:56:41 --> Form Validation Class Initialized
INFO - 2016-02-07 16:56:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 16:56:41 --> Model Class Initialized
INFO - 2016-02-07 16:56:41 --> Final output sent to browser
DEBUG - 2016-02-07 16:56:41 --> Total execution time: 1.2017
INFO - 2016-02-07 17:07:07 --> Config Class Initialized
INFO - 2016-02-07 17:07:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 17:07:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 17:07:07 --> Utf8 Class Initialized
INFO - 2016-02-07 17:07:07 --> URI Class Initialized
DEBUG - 2016-02-07 17:07:07 --> No URI present. Default controller set.
INFO - 2016-02-07 17:07:07 --> Router Class Initialized
INFO - 2016-02-07 17:07:07 --> Output Class Initialized
INFO - 2016-02-07 17:07:07 --> Security Class Initialized
DEBUG - 2016-02-07 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 17:07:07 --> Input Class Initialized
INFO - 2016-02-07 17:07:07 --> Language Class Initialized
INFO - 2016-02-07 17:07:07 --> Loader Class Initialized
INFO - 2016-02-07 17:07:07 --> Helper loaded: url_helper
INFO - 2016-02-07 17:07:07 --> Helper loaded: file_helper
INFO - 2016-02-07 17:07:07 --> Helper loaded: date_helper
INFO - 2016-02-07 17:07:07 --> Helper loaded: form_helper
INFO - 2016-02-07 17:07:07 --> Database Driver Class Initialized
INFO - 2016-02-07 17:07:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 17:07:08 --> Controller Class Initialized
INFO - 2016-02-07 17:07:08 --> Model Class Initialized
INFO - 2016-02-07 17:07:08 --> Model Class Initialized
INFO - 2016-02-07 17:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 17:07:08 --> Pagination Class Initialized
INFO - 2016-02-07 17:07:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 17:07:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 17:07:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 17:07:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 17:07:08 --> Final output sent to browser
DEBUG - 2016-02-07 17:07:08 --> Total execution time: 1.1481
INFO - 2016-02-07 17:07:11 --> Config Class Initialized
INFO - 2016-02-07 17:07:11 --> Hooks Class Initialized
DEBUG - 2016-02-07 17:07:11 --> UTF-8 Support Enabled
INFO - 2016-02-07 17:07:11 --> Utf8 Class Initialized
INFO - 2016-02-07 17:07:11 --> URI Class Initialized
INFO - 2016-02-07 17:07:11 --> Router Class Initialized
INFO - 2016-02-07 17:07:11 --> Output Class Initialized
INFO - 2016-02-07 17:07:11 --> Security Class Initialized
DEBUG - 2016-02-07 17:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 17:07:11 --> Input Class Initialized
INFO - 2016-02-07 17:07:11 --> Language Class Initialized
INFO - 2016-02-07 17:07:11 --> Loader Class Initialized
INFO - 2016-02-07 17:07:11 --> Helper loaded: url_helper
INFO - 2016-02-07 17:07:11 --> Helper loaded: file_helper
INFO - 2016-02-07 17:07:11 --> Helper loaded: date_helper
INFO - 2016-02-07 17:07:11 --> Helper loaded: form_helper
INFO - 2016-02-07 17:07:11 --> Database Driver Class Initialized
INFO - 2016-02-07 17:07:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 17:07:12 --> Controller Class Initialized
INFO - 2016-02-07 17:07:12 --> Model Class Initialized
INFO - 2016-02-07 17:07:12 --> Model Class Initialized
INFO - 2016-02-07 17:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 17:07:12 --> Pagination Class Initialized
INFO - 2016-02-07 17:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 17:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 17:07:12 --> Helper loaded: text_helper
INFO - 2016-02-07 17:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 17:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 17:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 17:07:12 --> Final output sent to browser
DEBUG - 2016-02-07 17:07:12 --> Total execution time: 1.1680
INFO - 2016-02-07 17:07:32 --> Config Class Initialized
INFO - 2016-02-07 17:07:32 --> Hooks Class Initialized
DEBUG - 2016-02-07 17:07:32 --> UTF-8 Support Enabled
INFO - 2016-02-07 17:07:32 --> Utf8 Class Initialized
INFO - 2016-02-07 17:07:32 --> URI Class Initialized
INFO - 2016-02-07 17:07:32 --> Router Class Initialized
INFO - 2016-02-07 17:07:32 --> Output Class Initialized
INFO - 2016-02-07 17:07:32 --> Security Class Initialized
DEBUG - 2016-02-07 17:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 17:07:32 --> Input Class Initialized
INFO - 2016-02-07 17:07:32 --> Language Class Initialized
INFO - 2016-02-07 17:07:33 --> Loader Class Initialized
INFO - 2016-02-07 17:07:33 --> Helper loaded: url_helper
INFO - 2016-02-07 17:07:33 --> Helper loaded: file_helper
INFO - 2016-02-07 17:07:33 --> Helper loaded: date_helper
INFO - 2016-02-07 17:07:33 --> Helper loaded: form_helper
INFO - 2016-02-07 17:07:33 --> Database Driver Class Initialized
INFO - 2016-02-07 17:07:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 17:07:34 --> Controller Class Initialized
INFO - 2016-02-07 17:07:34 --> Model Class Initialized
INFO - 2016-02-07 17:07:34 --> Model Class Initialized
INFO - 2016-02-07 17:07:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 17:07:34 --> Pagination Class Initialized
INFO - 2016-02-07 17:07:34 --> Form Validation Class Initialized
INFO - 2016-02-07 17:07:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 17:07:34 --> Model Class Initialized
INFO - 2016-02-07 17:07:34 --> Final output sent to browser
DEBUG - 2016-02-07 17:07:34 --> Total execution time: 1.2017
INFO - 2016-02-07 22:13:24 --> Config Class Initialized
INFO - 2016-02-07 22:13:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:24 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:24 --> URI Class Initialized
DEBUG - 2016-02-07 22:13:24 --> No URI present. Default controller set.
INFO - 2016-02-07 22:13:24 --> Router Class Initialized
INFO - 2016-02-07 22:13:24 --> Output Class Initialized
INFO - 2016-02-07 22:13:24 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:24 --> Input Class Initialized
INFO - 2016-02-07 22:13:24 --> Language Class Initialized
INFO - 2016-02-07 22:13:24 --> Loader Class Initialized
INFO - 2016-02-07 22:13:24 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:24 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:24 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:24 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:24 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:25 --> Controller Class Initialized
INFO - 2016-02-07 22:13:25 --> Model Class Initialized
INFO - 2016-02-07 22:13:25 --> Model Class Initialized
INFO - 2016-02-07 22:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:13:25 --> Pagination Class Initialized
INFO - 2016-02-07 22:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 22:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:13:25 --> Final output sent to browser
DEBUG - 2016-02-07 22:13:25 --> Total execution time: 1.1458
INFO - 2016-02-07 22:13:34 --> Config Class Initialized
INFO - 2016-02-07 22:13:34 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:34 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:34 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:34 --> URI Class Initialized
INFO - 2016-02-07 22:13:34 --> Router Class Initialized
INFO - 2016-02-07 22:13:34 --> Output Class Initialized
INFO - 2016-02-07 22:13:34 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:34 --> Input Class Initialized
INFO - 2016-02-07 22:13:34 --> Language Class Initialized
INFO - 2016-02-07 22:13:34 --> Loader Class Initialized
INFO - 2016-02-07 22:13:34 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:34 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:34 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:34 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:34 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:35 --> Controller Class Initialized
INFO - 2016-02-07 22:13:35 --> Model Class Initialized
INFO - 2016-02-07 22:13:35 --> Model Class Initialized
INFO - 2016-02-07 22:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:13:35 --> Pagination Class Initialized
INFO - 2016-02-07 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:13:35 --> Helper loaded: text_helper
INFO - 2016-02-07 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:13:35 --> Final output sent to browser
DEBUG - 2016-02-07 22:13:35 --> Total execution time: 1.1866
INFO - 2016-02-07 22:13:40 --> Config Class Initialized
INFO - 2016-02-07 22:13:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:40 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:40 --> URI Class Initialized
INFO - 2016-02-07 22:13:40 --> Router Class Initialized
INFO - 2016-02-07 22:13:40 --> Output Class Initialized
INFO - 2016-02-07 22:13:40 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:40 --> Input Class Initialized
INFO - 2016-02-07 22:13:40 --> Language Class Initialized
INFO - 2016-02-07 22:13:40 --> Loader Class Initialized
INFO - 2016-02-07 22:13:40 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:40 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:40 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:40 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:40 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:41 --> Controller Class Initialized
INFO - 2016-02-07 22:13:41 --> Model Class Initialized
INFO - 2016-02-07 22:13:41 --> Model Class Initialized
INFO - 2016-02-07 22:13:41 --> Form Validation Class Initialized
INFO - 2016-02-07 22:13:41 --> Helper loaded: text_helper
INFO - 2016-02-07 22:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-07 22:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:13:41 --> Final output sent to browser
DEBUG - 2016-02-07 22:13:41 --> Total execution time: 1.1724
INFO - 2016-02-07 22:13:49 --> Config Class Initialized
INFO - 2016-02-07 22:13:49 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:49 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:49 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:49 --> URI Class Initialized
INFO - 2016-02-07 22:13:49 --> Router Class Initialized
INFO - 2016-02-07 22:13:49 --> Output Class Initialized
INFO - 2016-02-07 22:13:49 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:49 --> Input Class Initialized
INFO - 2016-02-07 22:13:49 --> Language Class Initialized
INFO - 2016-02-07 22:13:49 --> Loader Class Initialized
INFO - 2016-02-07 22:13:49 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:49 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:49 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:49 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:49 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:50 --> Controller Class Initialized
INFO - 2016-02-07 22:13:50 --> Model Class Initialized
INFO - 2016-02-07 22:13:50 --> Model Class Initialized
INFO - 2016-02-07 22:13:50 --> Form Validation Class Initialized
INFO - 2016-02-07 22:13:50 --> Helper loaded: text_helper
INFO - 2016-02-07 22:13:50 --> Config Class Initialized
INFO - 2016-02-07 22:13:50 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:50 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:50 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:50 --> URI Class Initialized
INFO - 2016-02-07 22:13:50 --> Router Class Initialized
INFO - 2016-02-07 22:13:50 --> Output Class Initialized
INFO - 2016-02-07 22:13:50 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:50 --> Input Class Initialized
INFO - 2016-02-07 22:13:50 --> Language Class Initialized
INFO - 2016-02-07 22:13:50 --> Loader Class Initialized
INFO - 2016-02-07 22:13:50 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:50 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:50 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:50 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:50 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:51 --> Controller Class Initialized
INFO - 2016-02-07 22:13:51 --> Model Class Initialized
INFO - 2016-02-07 22:13:51 --> Model Class Initialized
INFO - 2016-02-07 22:13:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:13:51 --> Pagination Class Initialized
INFO - 2016-02-07 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 22:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:13:51 --> Final output sent to browser
DEBUG - 2016-02-07 22:13:51 --> Total execution time: 1.1449
INFO - 2016-02-07 22:13:54 --> Config Class Initialized
INFO - 2016-02-07 22:13:54 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:13:54 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:13:54 --> Utf8 Class Initialized
INFO - 2016-02-07 22:13:54 --> URI Class Initialized
INFO - 2016-02-07 22:13:54 --> Router Class Initialized
INFO - 2016-02-07 22:13:54 --> Output Class Initialized
INFO - 2016-02-07 22:13:54 --> Security Class Initialized
DEBUG - 2016-02-07 22:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:13:54 --> Input Class Initialized
INFO - 2016-02-07 22:13:54 --> Language Class Initialized
INFO - 2016-02-07 22:13:54 --> Loader Class Initialized
INFO - 2016-02-07 22:13:54 --> Helper loaded: url_helper
INFO - 2016-02-07 22:13:54 --> Helper loaded: file_helper
INFO - 2016-02-07 22:13:54 --> Helper loaded: date_helper
INFO - 2016-02-07 22:13:54 --> Helper loaded: form_helper
INFO - 2016-02-07 22:13:54 --> Database Driver Class Initialized
INFO - 2016-02-07 22:13:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:13:55 --> Controller Class Initialized
INFO - 2016-02-07 22:13:55 --> Model Class Initialized
INFO - 2016-02-07 22:13:55 --> Model Class Initialized
INFO - 2016-02-07 22:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:13:55 --> Pagination Class Initialized
INFO - 2016-02-07 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:13:55 --> Helper loaded: text_helper
INFO - 2016-02-07 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:13:55 --> Final output sent to browser
DEBUG - 2016-02-07 22:13:55 --> Total execution time: 1.1775
INFO - 2016-02-07 22:14:06 --> Config Class Initialized
INFO - 2016-02-07 22:14:06 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:14:06 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:14:06 --> Utf8 Class Initialized
INFO - 2016-02-07 22:14:06 --> URI Class Initialized
INFO - 2016-02-07 22:14:06 --> Router Class Initialized
INFO - 2016-02-07 22:14:06 --> Output Class Initialized
INFO - 2016-02-07 22:14:06 --> Security Class Initialized
DEBUG - 2016-02-07 22:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:14:06 --> Input Class Initialized
INFO - 2016-02-07 22:14:06 --> Language Class Initialized
INFO - 2016-02-07 22:14:06 --> Loader Class Initialized
INFO - 2016-02-07 22:14:06 --> Helper loaded: url_helper
INFO - 2016-02-07 22:14:06 --> Helper loaded: file_helper
INFO - 2016-02-07 22:14:06 --> Helper loaded: date_helper
INFO - 2016-02-07 22:14:06 --> Helper loaded: form_helper
INFO - 2016-02-07 22:14:06 --> Database Driver Class Initialized
INFO - 2016-02-07 22:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:14:07 --> Controller Class Initialized
INFO - 2016-02-07 22:14:07 --> Model Class Initialized
INFO - 2016-02-07 22:14:07 --> Model Class Initialized
INFO - 2016-02-07 22:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:14:07 --> Pagination Class Initialized
INFO - 2016-02-07 22:14:07 --> Form Validation Class Initialized
INFO - 2016-02-07 22:14:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 22:14:07 --> Model Class Initialized
INFO - 2016-02-07 22:14:07 --> Final output sent to browser
DEBUG - 2016-02-07 22:14:07 --> Total execution time: 1.1848
INFO - 2016-02-07 22:15:15 --> Config Class Initialized
INFO - 2016-02-07 22:15:15 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:15:15 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:15:15 --> Utf8 Class Initialized
INFO - 2016-02-07 22:15:15 --> URI Class Initialized
DEBUG - 2016-02-07 22:15:15 --> No URI present. Default controller set.
INFO - 2016-02-07 22:15:15 --> Router Class Initialized
INFO - 2016-02-07 22:15:15 --> Output Class Initialized
INFO - 2016-02-07 22:15:15 --> Security Class Initialized
DEBUG - 2016-02-07 22:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:15:15 --> Input Class Initialized
INFO - 2016-02-07 22:15:15 --> Language Class Initialized
INFO - 2016-02-07 22:15:15 --> Loader Class Initialized
INFO - 2016-02-07 22:15:15 --> Helper loaded: url_helper
INFO - 2016-02-07 22:15:15 --> Helper loaded: file_helper
INFO - 2016-02-07 22:15:15 --> Helper loaded: date_helper
INFO - 2016-02-07 22:15:15 --> Helper loaded: form_helper
INFO - 2016-02-07 22:15:15 --> Database Driver Class Initialized
INFO - 2016-02-07 22:15:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:15:16 --> Controller Class Initialized
INFO - 2016-02-07 22:15:16 --> Model Class Initialized
INFO - 2016-02-07 22:15:16 --> Model Class Initialized
INFO - 2016-02-07 22:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:15:16 --> Pagination Class Initialized
INFO - 2016-02-07 22:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 22:15:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:15:16 --> Final output sent to browser
DEBUG - 2016-02-07 22:15:16 --> Total execution time: 1.1689
INFO - 2016-02-07 22:15:18 --> Config Class Initialized
INFO - 2016-02-07 22:15:18 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:15:18 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:15:18 --> Utf8 Class Initialized
INFO - 2016-02-07 22:15:18 --> URI Class Initialized
INFO - 2016-02-07 22:15:18 --> Router Class Initialized
INFO - 2016-02-07 22:15:18 --> Output Class Initialized
INFO - 2016-02-07 22:15:18 --> Security Class Initialized
DEBUG - 2016-02-07 22:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:15:18 --> Input Class Initialized
INFO - 2016-02-07 22:15:18 --> Language Class Initialized
INFO - 2016-02-07 22:15:18 --> Loader Class Initialized
INFO - 2016-02-07 22:15:18 --> Helper loaded: url_helper
INFO - 2016-02-07 22:15:18 --> Helper loaded: file_helper
INFO - 2016-02-07 22:15:18 --> Helper loaded: date_helper
INFO - 2016-02-07 22:15:18 --> Helper loaded: form_helper
INFO - 2016-02-07 22:15:18 --> Database Driver Class Initialized
INFO - 2016-02-07 22:15:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:15:19 --> Controller Class Initialized
INFO - 2016-02-07 22:15:19 --> Model Class Initialized
INFO - 2016-02-07 22:15:19 --> Model Class Initialized
INFO - 2016-02-07 22:15:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:15:19 --> Pagination Class Initialized
INFO - 2016-02-07 22:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:15:19 --> Helper loaded: text_helper
INFO - 2016-02-07 22:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:15:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:15:19 --> Final output sent to browser
DEBUG - 2016-02-07 22:15:19 --> Total execution time: 1.1799
INFO - 2016-02-07 22:15:29 --> Config Class Initialized
INFO - 2016-02-07 22:15:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:15:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:15:29 --> Utf8 Class Initialized
INFO - 2016-02-07 22:15:29 --> URI Class Initialized
INFO - 2016-02-07 22:15:29 --> Router Class Initialized
INFO - 2016-02-07 22:15:29 --> Output Class Initialized
INFO - 2016-02-07 22:15:29 --> Security Class Initialized
DEBUG - 2016-02-07 22:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:15:29 --> Input Class Initialized
INFO - 2016-02-07 22:15:29 --> Language Class Initialized
INFO - 2016-02-07 22:15:29 --> Loader Class Initialized
INFO - 2016-02-07 22:15:29 --> Helper loaded: url_helper
INFO - 2016-02-07 22:15:29 --> Helper loaded: file_helper
INFO - 2016-02-07 22:15:29 --> Helper loaded: date_helper
INFO - 2016-02-07 22:15:29 --> Helper loaded: form_helper
INFO - 2016-02-07 22:15:29 --> Database Driver Class Initialized
INFO - 2016-02-07 22:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:15:30 --> Controller Class Initialized
INFO - 2016-02-07 22:15:30 --> Model Class Initialized
INFO - 2016-02-07 22:15:30 --> Model Class Initialized
INFO - 2016-02-07 22:15:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:15:30 --> Pagination Class Initialized
INFO - 2016-02-07 22:15:30 --> Form Validation Class Initialized
INFO - 2016-02-07 22:15:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-07 22:15:30 --> Model Class Initialized
INFO - 2016-02-07 22:15:31 --> Final output sent to browser
DEBUG - 2016-02-07 22:15:31 --> Total execution time: 1.2421
INFO - 2016-02-07 22:38:28 --> Config Class Initialized
INFO - 2016-02-07 22:38:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:38:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:38:28 --> Utf8 Class Initialized
INFO - 2016-02-07 22:38:28 --> URI Class Initialized
DEBUG - 2016-02-07 22:38:28 --> No URI present. Default controller set.
INFO - 2016-02-07 22:38:28 --> Router Class Initialized
INFO - 2016-02-07 22:38:28 --> Output Class Initialized
INFO - 2016-02-07 22:38:28 --> Security Class Initialized
DEBUG - 2016-02-07 22:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:38:28 --> Input Class Initialized
INFO - 2016-02-07 22:38:28 --> Language Class Initialized
INFO - 2016-02-07 22:38:28 --> Loader Class Initialized
INFO - 2016-02-07 22:38:28 --> Helper loaded: url_helper
INFO - 2016-02-07 22:38:28 --> Helper loaded: file_helper
INFO - 2016-02-07 22:38:28 --> Helper loaded: date_helper
INFO - 2016-02-07 22:38:28 --> Helper loaded: form_helper
INFO - 2016-02-07 22:38:28 --> Database Driver Class Initialized
INFO - 2016-02-07 22:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:38:29 --> Controller Class Initialized
INFO - 2016-02-07 22:38:29 --> Model Class Initialized
INFO - 2016-02-07 22:38:29 --> Model Class Initialized
INFO - 2016-02-07 22:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:38:29 --> Pagination Class Initialized
INFO - 2016-02-07 22:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 22:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:38:29 --> Final output sent to browser
DEBUG - 2016-02-07 22:38:29 --> Total execution time: 1.1424
INFO - 2016-02-07 22:38:36 --> Config Class Initialized
INFO - 2016-02-07 22:38:36 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:38:36 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:38:36 --> Utf8 Class Initialized
INFO - 2016-02-07 22:38:36 --> URI Class Initialized
INFO - 2016-02-07 22:38:36 --> Router Class Initialized
INFO - 2016-02-07 22:38:36 --> Output Class Initialized
INFO - 2016-02-07 22:38:36 --> Security Class Initialized
DEBUG - 2016-02-07 22:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:38:36 --> Input Class Initialized
INFO - 2016-02-07 22:38:36 --> Language Class Initialized
INFO - 2016-02-07 22:38:36 --> Loader Class Initialized
INFO - 2016-02-07 22:38:36 --> Helper loaded: url_helper
INFO - 2016-02-07 22:38:36 --> Helper loaded: file_helper
INFO - 2016-02-07 22:38:36 --> Helper loaded: date_helper
INFO - 2016-02-07 22:38:36 --> Helper loaded: form_helper
INFO - 2016-02-07 22:38:36 --> Database Driver Class Initialized
INFO - 2016-02-07 22:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:38:37 --> Controller Class Initialized
INFO - 2016-02-07 22:38:37 --> Model Class Initialized
INFO - 2016-02-07 22:38:37 --> Model Class Initialized
INFO - 2016-02-07 22:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:38:37 --> Pagination Class Initialized
INFO - 2016-02-07 22:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 22:38:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:38:37 --> Final output sent to browser
DEBUG - 2016-02-07 22:38:37 --> Total execution time: 1.1364
INFO - 2016-02-07 22:38:40 --> Config Class Initialized
INFO - 2016-02-07 22:38:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:38:40 --> Utf8 Class Initialized
INFO - 2016-02-07 22:38:40 --> URI Class Initialized
INFO - 2016-02-07 22:38:40 --> Router Class Initialized
INFO - 2016-02-07 22:38:40 --> Output Class Initialized
INFO - 2016-02-07 22:38:40 --> Security Class Initialized
DEBUG - 2016-02-07 22:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:38:40 --> Input Class Initialized
INFO - 2016-02-07 22:38:40 --> Language Class Initialized
INFO - 2016-02-07 22:38:40 --> Loader Class Initialized
INFO - 2016-02-07 22:38:40 --> Helper loaded: url_helper
INFO - 2016-02-07 22:38:40 --> Helper loaded: file_helper
INFO - 2016-02-07 22:38:40 --> Helper loaded: date_helper
INFO - 2016-02-07 22:38:40 --> Helper loaded: form_helper
INFO - 2016-02-07 22:38:40 --> Database Driver Class Initialized
INFO - 2016-02-07 22:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:38:41 --> Controller Class Initialized
INFO - 2016-02-07 22:38:41 --> Model Class Initialized
INFO - 2016-02-07 22:38:41 --> Model Class Initialized
INFO - 2016-02-07 22:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:38:41 --> Pagination Class Initialized
INFO - 2016-02-07 22:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:38:41 --> Helper loaded: text_helper
INFO - 2016-02-07 22:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:38:41 --> Final output sent to browser
DEBUG - 2016-02-07 22:38:41 --> Total execution time: 1.2540
INFO - 2016-02-07 22:40:11 --> Config Class Initialized
INFO - 2016-02-07 22:40:11 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:40:11 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:40:11 --> Utf8 Class Initialized
INFO - 2016-02-07 22:40:11 --> URI Class Initialized
INFO - 2016-02-07 22:40:11 --> Router Class Initialized
INFO - 2016-02-07 22:40:11 --> Output Class Initialized
INFO - 2016-02-07 22:40:11 --> Security Class Initialized
DEBUG - 2016-02-07 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:40:11 --> Input Class Initialized
INFO - 2016-02-07 22:40:11 --> Language Class Initialized
INFO - 2016-02-07 22:40:11 --> Loader Class Initialized
INFO - 2016-02-07 22:40:11 --> Helper loaded: url_helper
INFO - 2016-02-07 22:40:11 --> Helper loaded: file_helper
INFO - 2016-02-07 22:40:11 --> Helper loaded: date_helper
INFO - 2016-02-07 22:40:11 --> Helper loaded: form_helper
INFO - 2016-02-07 22:40:11 --> Database Driver Class Initialized
INFO - 2016-02-07 22:40:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:40:12 --> Controller Class Initialized
INFO - 2016-02-07 22:40:12 --> Model Class Initialized
INFO - 2016-02-07 22:40:12 --> Model Class Initialized
INFO - 2016-02-07 22:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:40:12 --> Pagination Class Initialized
INFO - 2016-02-07 22:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:40:12 --> Helper loaded: text_helper
INFO - 2016-02-07 22:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:40:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:40:12 --> Final output sent to browser
DEBUG - 2016-02-07 22:40:12 --> Total execution time: 1.1935
INFO - 2016-02-07 22:40:59 --> Config Class Initialized
INFO - 2016-02-07 22:40:59 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:40:59 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:40:59 --> Utf8 Class Initialized
INFO - 2016-02-07 22:40:59 --> URI Class Initialized
INFO - 2016-02-07 22:40:59 --> Router Class Initialized
INFO - 2016-02-07 22:40:59 --> Output Class Initialized
INFO - 2016-02-07 22:40:59 --> Security Class Initialized
DEBUG - 2016-02-07 22:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:40:59 --> Input Class Initialized
INFO - 2016-02-07 22:40:59 --> Language Class Initialized
INFO - 2016-02-07 22:40:59 --> Loader Class Initialized
INFO - 2016-02-07 22:40:59 --> Helper loaded: url_helper
INFO - 2016-02-07 22:40:59 --> Helper loaded: file_helper
INFO - 2016-02-07 22:40:59 --> Helper loaded: date_helper
INFO - 2016-02-07 22:40:59 --> Helper loaded: form_helper
INFO - 2016-02-07 22:40:59 --> Database Driver Class Initialized
INFO - 2016-02-07 22:41:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:41:00 --> Controller Class Initialized
INFO - 2016-02-07 22:41:00 --> Model Class Initialized
INFO - 2016-02-07 22:41:00 --> Model Class Initialized
INFO - 2016-02-07 22:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:41:00 --> Pagination Class Initialized
INFO - 2016-02-07 22:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:41:00 --> Helper loaded: text_helper
INFO - 2016-02-07 22:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:41:00 --> Final output sent to browser
DEBUG - 2016-02-07 22:41:00 --> Total execution time: 1.1687
INFO - 2016-02-07 22:41:57 --> Config Class Initialized
INFO - 2016-02-07 22:41:57 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:41:57 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:41:57 --> Utf8 Class Initialized
INFO - 2016-02-07 22:41:57 --> URI Class Initialized
INFO - 2016-02-07 22:41:57 --> Router Class Initialized
INFO - 2016-02-07 22:41:57 --> Output Class Initialized
INFO - 2016-02-07 22:41:57 --> Security Class Initialized
DEBUG - 2016-02-07 22:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:41:57 --> Input Class Initialized
INFO - 2016-02-07 22:41:57 --> Language Class Initialized
INFO - 2016-02-07 22:41:57 --> Loader Class Initialized
INFO - 2016-02-07 22:41:57 --> Helper loaded: url_helper
INFO - 2016-02-07 22:41:57 --> Helper loaded: file_helper
INFO - 2016-02-07 22:41:57 --> Helper loaded: date_helper
INFO - 2016-02-07 22:41:57 --> Helper loaded: form_helper
INFO - 2016-02-07 22:41:57 --> Database Driver Class Initialized
INFO - 2016-02-07 22:41:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:41:58 --> Controller Class Initialized
INFO - 2016-02-07 22:41:58 --> Model Class Initialized
INFO - 2016-02-07 22:41:58 --> Model Class Initialized
INFO - 2016-02-07 22:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:41:58 --> Pagination Class Initialized
INFO - 2016-02-07 22:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:41:58 --> Helper loaded: text_helper
INFO - 2016-02-07 22:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:41:58 --> Final output sent to browser
DEBUG - 2016-02-07 22:41:58 --> Total execution time: 1.2728
INFO - 2016-02-07 22:42:05 --> Config Class Initialized
INFO - 2016-02-07 22:42:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:42:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:42:05 --> Utf8 Class Initialized
INFO - 2016-02-07 22:42:05 --> URI Class Initialized
INFO - 2016-02-07 22:42:05 --> Router Class Initialized
INFO - 2016-02-07 22:42:05 --> Output Class Initialized
INFO - 2016-02-07 22:42:05 --> Security Class Initialized
DEBUG - 2016-02-07 22:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:42:05 --> Input Class Initialized
INFO - 2016-02-07 22:42:05 --> Language Class Initialized
INFO - 2016-02-07 22:42:05 --> Loader Class Initialized
INFO - 2016-02-07 22:42:05 --> Helper loaded: url_helper
INFO - 2016-02-07 22:42:05 --> Helper loaded: file_helper
INFO - 2016-02-07 22:42:05 --> Helper loaded: date_helper
INFO - 2016-02-07 22:42:05 --> Helper loaded: form_helper
INFO - 2016-02-07 22:42:05 --> Database Driver Class Initialized
INFO - 2016-02-07 22:42:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:42:06 --> Controller Class Initialized
INFO - 2016-02-07 22:42:06 --> Model Class Initialized
INFO - 2016-02-07 22:42:06 --> Model Class Initialized
INFO - 2016-02-07 22:42:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:42:06 --> Pagination Class Initialized
INFO - 2016-02-07 22:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:42:06 --> Helper loaded: text_helper
INFO - 2016-02-07 22:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:42:06 --> Final output sent to browser
DEBUG - 2016-02-07 22:42:06 --> Total execution time: 1.1895
INFO - 2016-02-07 22:43:09 --> Config Class Initialized
INFO - 2016-02-07 22:43:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:43:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:43:09 --> Utf8 Class Initialized
INFO - 2016-02-07 22:43:09 --> URI Class Initialized
INFO - 2016-02-07 22:43:09 --> Router Class Initialized
INFO - 2016-02-07 22:43:09 --> Output Class Initialized
INFO - 2016-02-07 22:43:09 --> Security Class Initialized
DEBUG - 2016-02-07 22:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:43:09 --> Input Class Initialized
INFO - 2016-02-07 22:43:09 --> Language Class Initialized
INFO - 2016-02-07 22:43:09 --> Loader Class Initialized
INFO - 2016-02-07 22:43:09 --> Helper loaded: url_helper
INFO - 2016-02-07 22:43:09 --> Helper loaded: file_helper
INFO - 2016-02-07 22:43:09 --> Helper loaded: date_helper
INFO - 2016-02-07 22:43:09 --> Helper loaded: form_helper
INFO - 2016-02-07 22:43:09 --> Database Driver Class Initialized
INFO - 2016-02-07 22:43:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:43:10 --> Controller Class Initialized
INFO - 2016-02-07 22:43:10 --> Model Class Initialized
INFO - 2016-02-07 22:43:10 --> Model Class Initialized
INFO - 2016-02-07 22:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:43:10 --> Pagination Class Initialized
INFO - 2016-02-07 22:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:43:10 --> Helper loaded: text_helper
INFO - 2016-02-07 22:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:43:10 --> Final output sent to browser
DEBUG - 2016-02-07 22:43:10 --> Total execution time: 1.2067
INFO - 2016-02-07 22:44:13 --> Config Class Initialized
INFO - 2016-02-07 22:44:13 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:44:13 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:44:13 --> Utf8 Class Initialized
INFO - 2016-02-07 22:44:13 --> URI Class Initialized
INFO - 2016-02-07 22:44:13 --> Router Class Initialized
INFO - 2016-02-07 22:44:13 --> Output Class Initialized
INFO - 2016-02-07 22:44:13 --> Security Class Initialized
DEBUG - 2016-02-07 22:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:44:13 --> Input Class Initialized
INFO - 2016-02-07 22:44:13 --> Language Class Initialized
INFO - 2016-02-07 22:44:13 --> Loader Class Initialized
INFO - 2016-02-07 22:44:13 --> Helper loaded: url_helper
INFO - 2016-02-07 22:44:13 --> Helper loaded: file_helper
INFO - 2016-02-07 22:44:13 --> Helper loaded: date_helper
INFO - 2016-02-07 22:44:13 --> Helper loaded: form_helper
INFO - 2016-02-07 22:44:13 --> Database Driver Class Initialized
INFO - 2016-02-07 22:44:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:44:14 --> Controller Class Initialized
INFO - 2016-02-07 22:44:14 --> Model Class Initialized
INFO - 2016-02-07 22:44:14 --> Model Class Initialized
INFO - 2016-02-07 22:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:44:14 --> Pagination Class Initialized
INFO - 2016-02-07 22:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:44:14 --> Helper loaded: text_helper
INFO - 2016-02-07 22:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:44:14 --> Final output sent to browser
DEBUG - 2016-02-07 22:44:14 --> Total execution time: 1.1961
INFO - 2016-02-07 22:48:08 --> Config Class Initialized
INFO - 2016-02-07 22:48:08 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:48:08 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:48:08 --> Utf8 Class Initialized
INFO - 2016-02-07 22:48:08 --> URI Class Initialized
INFO - 2016-02-07 22:48:08 --> Router Class Initialized
INFO - 2016-02-07 22:48:08 --> Output Class Initialized
INFO - 2016-02-07 22:48:08 --> Security Class Initialized
DEBUG - 2016-02-07 22:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:48:08 --> Input Class Initialized
INFO - 2016-02-07 22:48:08 --> Language Class Initialized
INFO - 2016-02-07 22:48:08 --> Loader Class Initialized
INFO - 2016-02-07 22:48:08 --> Helper loaded: url_helper
INFO - 2016-02-07 22:48:08 --> Helper loaded: file_helper
INFO - 2016-02-07 22:48:08 --> Helper loaded: date_helper
INFO - 2016-02-07 22:48:08 --> Helper loaded: form_helper
INFO - 2016-02-07 22:48:08 --> Database Driver Class Initialized
INFO - 2016-02-07 22:48:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:48:09 --> Controller Class Initialized
INFO - 2016-02-07 22:48:09 --> Model Class Initialized
INFO - 2016-02-07 22:48:09 --> Model Class Initialized
INFO - 2016-02-07 22:48:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:48:09 --> Pagination Class Initialized
INFO - 2016-02-07 22:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:48:09 --> Helper loaded: text_helper
INFO - 2016-02-07 22:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:48:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:48:09 --> Final output sent to browser
DEBUG - 2016-02-07 22:48:09 --> Total execution time: 1.2901
INFO - 2016-02-07 22:49:03 --> Config Class Initialized
INFO - 2016-02-07 22:49:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:49:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:49:03 --> Utf8 Class Initialized
INFO - 2016-02-07 22:49:03 --> URI Class Initialized
INFO - 2016-02-07 22:49:03 --> Router Class Initialized
INFO - 2016-02-07 22:49:03 --> Output Class Initialized
INFO - 2016-02-07 22:49:03 --> Security Class Initialized
DEBUG - 2016-02-07 22:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:49:03 --> Input Class Initialized
INFO - 2016-02-07 22:49:03 --> Language Class Initialized
INFO - 2016-02-07 22:49:03 --> Loader Class Initialized
INFO - 2016-02-07 22:49:03 --> Helper loaded: url_helper
INFO - 2016-02-07 22:49:03 --> Helper loaded: file_helper
INFO - 2016-02-07 22:49:03 --> Helper loaded: date_helper
INFO - 2016-02-07 22:49:03 --> Helper loaded: form_helper
INFO - 2016-02-07 22:49:03 --> Database Driver Class Initialized
INFO - 2016-02-07 22:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:49:04 --> Controller Class Initialized
INFO - 2016-02-07 22:49:04 --> Model Class Initialized
INFO - 2016-02-07 22:49:04 --> Model Class Initialized
INFO - 2016-02-07 22:49:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:49:04 --> Pagination Class Initialized
INFO - 2016-02-07 22:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:49:04 --> Helper loaded: text_helper
INFO - 2016-02-07 22:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:49:04 --> Final output sent to browser
DEBUG - 2016-02-07 22:49:04 --> Total execution time: 1.2102
INFO - 2016-02-07 22:49:38 --> Config Class Initialized
INFO - 2016-02-07 22:49:38 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:49:38 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:49:38 --> Utf8 Class Initialized
INFO - 2016-02-07 22:49:38 --> URI Class Initialized
INFO - 2016-02-07 22:49:38 --> Router Class Initialized
INFO - 2016-02-07 22:49:38 --> Output Class Initialized
INFO - 2016-02-07 22:49:38 --> Security Class Initialized
DEBUG - 2016-02-07 22:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:49:38 --> Input Class Initialized
INFO - 2016-02-07 22:49:38 --> Language Class Initialized
INFO - 2016-02-07 22:49:38 --> Loader Class Initialized
INFO - 2016-02-07 22:49:38 --> Helper loaded: url_helper
INFO - 2016-02-07 22:49:38 --> Helper loaded: file_helper
INFO - 2016-02-07 22:49:38 --> Helper loaded: date_helper
INFO - 2016-02-07 22:49:38 --> Helper loaded: form_helper
INFO - 2016-02-07 22:49:38 --> Database Driver Class Initialized
INFO - 2016-02-07 22:49:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:49:40 --> Controller Class Initialized
INFO - 2016-02-07 22:49:40 --> Model Class Initialized
INFO - 2016-02-07 22:49:40 --> Model Class Initialized
INFO - 2016-02-07 22:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:49:40 --> Pagination Class Initialized
INFO - 2016-02-07 22:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:49:40 --> Helper loaded: text_helper
INFO - 2016-02-07 22:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:49:40 --> Final output sent to browser
DEBUG - 2016-02-07 22:49:40 --> Total execution time: 1.2245
INFO - 2016-02-07 22:50:00 --> Config Class Initialized
INFO - 2016-02-07 22:50:00 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:50:00 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:50:00 --> Utf8 Class Initialized
INFO - 2016-02-07 22:50:00 --> URI Class Initialized
INFO - 2016-02-07 22:50:00 --> Router Class Initialized
INFO - 2016-02-07 22:50:00 --> Output Class Initialized
INFO - 2016-02-07 22:50:00 --> Security Class Initialized
DEBUG - 2016-02-07 22:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:50:00 --> Input Class Initialized
INFO - 2016-02-07 22:50:00 --> Language Class Initialized
INFO - 2016-02-07 22:50:00 --> Loader Class Initialized
INFO - 2016-02-07 22:50:00 --> Helper loaded: url_helper
INFO - 2016-02-07 22:50:00 --> Helper loaded: file_helper
INFO - 2016-02-07 22:50:00 --> Helper loaded: date_helper
INFO - 2016-02-07 22:50:00 --> Helper loaded: form_helper
INFO - 2016-02-07 22:50:00 --> Database Driver Class Initialized
INFO - 2016-02-07 22:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:50:01 --> Controller Class Initialized
INFO - 2016-02-07 22:50:01 --> Model Class Initialized
INFO - 2016-02-07 22:50:01 --> Model Class Initialized
INFO - 2016-02-07 22:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:50:01 --> Pagination Class Initialized
INFO - 2016-02-07 22:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:50:01 --> Helper loaded: text_helper
INFO - 2016-02-07 22:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:50:01 --> Final output sent to browser
DEBUG - 2016-02-07 22:50:01 --> Total execution time: 1.1621
INFO - 2016-02-07 22:50:25 --> Config Class Initialized
INFO - 2016-02-07 22:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:50:25 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:50:25 --> Utf8 Class Initialized
INFO - 2016-02-07 22:50:25 --> URI Class Initialized
INFO - 2016-02-07 22:50:25 --> Router Class Initialized
INFO - 2016-02-07 22:50:25 --> Output Class Initialized
INFO - 2016-02-07 22:50:25 --> Security Class Initialized
DEBUG - 2016-02-07 22:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:50:25 --> Input Class Initialized
INFO - 2016-02-07 22:50:25 --> Language Class Initialized
INFO - 2016-02-07 22:50:25 --> Loader Class Initialized
INFO - 2016-02-07 22:50:25 --> Helper loaded: url_helper
INFO - 2016-02-07 22:50:25 --> Helper loaded: file_helper
INFO - 2016-02-07 22:50:25 --> Helper loaded: date_helper
INFO - 2016-02-07 22:50:25 --> Helper loaded: form_helper
INFO - 2016-02-07 22:50:25 --> Database Driver Class Initialized
INFO - 2016-02-07 22:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:50:26 --> Controller Class Initialized
INFO - 2016-02-07 22:50:26 --> Model Class Initialized
INFO - 2016-02-07 22:50:26 --> Model Class Initialized
INFO - 2016-02-07 22:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:50:26 --> Pagination Class Initialized
INFO - 2016-02-07 22:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:50:26 --> Helper loaded: text_helper
INFO - 2016-02-07 22:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:50:26 --> Final output sent to browser
DEBUG - 2016-02-07 22:50:26 --> Total execution time: 1.2344
INFO - 2016-02-07 22:54:29 --> Config Class Initialized
INFO - 2016-02-07 22:54:29 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:54:29 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:54:29 --> Utf8 Class Initialized
INFO - 2016-02-07 22:54:29 --> URI Class Initialized
INFO - 2016-02-07 22:54:29 --> Router Class Initialized
INFO - 2016-02-07 22:54:29 --> Output Class Initialized
INFO - 2016-02-07 22:54:29 --> Security Class Initialized
DEBUG - 2016-02-07 22:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:54:29 --> Input Class Initialized
INFO - 2016-02-07 22:54:29 --> Language Class Initialized
INFO - 2016-02-07 22:54:29 --> Loader Class Initialized
INFO - 2016-02-07 22:54:29 --> Helper loaded: url_helper
INFO - 2016-02-07 22:54:29 --> Helper loaded: file_helper
INFO - 2016-02-07 22:54:29 --> Helper loaded: date_helper
INFO - 2016-02-07 22:54:29 --> Helper loaded: form_helper
INFO - 2016-02-07 22:54:29 --> Database Driver Class Initialized
INFO - 2016-02-07 22:54:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:54:30 --> Controller Class Initialized
INFO - 2016-02-07 22:54:30 --> Model Class Initialized
INFO - 2016-02-07 22:54:30 --> Model Class Initialized
INFO - 2016-02-07 22:54:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:54:30 --> Pagination Class Initialized
INFO - 2016-02-07 22:54:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:54:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:54:30 --> Helper loaded: text_helper
INFO - 2016-02-07 22:54:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:54:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:54:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:54:30 --> Final output sent to browser
DEBUG - 2016-02-07 22:54:30 --> Total execution time: 1.1698
INFO - 2016-02-07 22:57:19 --> Config Class Initialized
INFO - 2016-02-07 22:57:19 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:57:19 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:57:19 --> Utf8 Class Initialized
INFO - 2016-02-07 22:57:19 --> URI Class Initialized
INFO - 2016-02-07 22:57:19 --> Router Class Initialized
INFO - 2016-02-07 22:57:19 --> Output Class Initialized
INFO - 2016-02-07 22:57:19 --> Security Class Initialized
DEBUG - 2016-02-07 22:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:57:19 --> Input Class Initialized
INFO - 2016-02-07 22:57:19 --> Language Class Initialized
INFO - 2016-02-07 22:57:19 --> Loader Class Initialized
INFO - 2016-02-07 22:57:19 --> Helper loaded: url_helper
INFO - 2016-02-07 22:57:19 --> Helper loaded: file_helper
INFO - 2016-02-07 22:57:19 --> Helper loaded: date_helper
INFO - 2016-02-07 22:57:19 --> Helper loaded: form_helper
INFO - 2016-02-07 22:57:19 --> Database Driver Class Initialized
INFO - 2016-02-07 22:57:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:57:20 --> Controller Class Initialized
INFO - 2016-02-07 22:57:20 --> Model Class Initialized
INFO - 2016-02-07 22:57:20 --> Model Class Initialized
INFO - 2016-02-07 22:57:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:57:20 --> Pagination Class Initialized
INFO - 2016-02-07 22:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:57:20 --> Helper loaded: text_helper
INFO - 2016-02-07 22:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:57:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:57:20 --> Final output sent to browser
DEBUG - 2016-02-07 22:57:20 --> Total execution time: 1.2079
INFO - 2016-02-07 22:58:46 --> Config Class Initialized
INFO - 2016-02-07 22:58:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:58:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:58:46 --> Utf8 Class Initialized
INFO - 2016-02-07 22:58:46 --> URI Class Initialized
INFO - 2016-02-07 22:58:46 --> Router Class Initialized
INFO - 2016-02-07 22:58:46 --> Output Class Initialized
INFO - 2016-02-07 22:58:46 --> Security Class Initialized
DEBUG - 2016-02-07 22:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:58:46 --> Input Class Initialized
INFO - 2016-02-07 22:58:46 --> Language Class Initialized
INFO - 2016-02-07 22:58:46 --> Loader Class Initialized
INFO - 2016-02-07 22:58:46 --> Helper loaded: url_helper
INFO - 2016-02-07 22:58:46 --> Helper loaded: file_helper
INFO - 2016-02-07 22:58:46 --> Helper loaded: date_helper
INFO - 2016-02-07 22:58:46 --> Helper loaded: form_helper
INFO - 2016-02-07 22:58:46 --> Database Driver Class Initialized
INFO - 2016-02-07 22:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:58:47 --> Controller Class Initialized
INFO - 2016-02-07 22:58:47 --> Model Class Initialized
INFO - 2016-02-07 22:58:47 --> Model Class Initialized
INFO - 2016-02-07 22:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:58:47 --> Pagination Class Initialized
INFO - 2016-02-07 22:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:58:47 --> Helper loaded: text_helper
INFO - 2016-02-07 22:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:58:47 --> Final output sent to browser
DEBUG - 2016-02-07 22:58:47 --> Total execution time: 1.2181
INFO - 2016-02-07 22:59:09 --> Config Class Initialized
INFO - 2016-02-07 22:59:09 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:59:09 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:59:09 --> Utf8 Class Initialized
INFO - 2016-02-07 22:59:09 --> URI Class Initialized
INFO - 2016-02-07 22:59:09 --> Router Class Initialized
INFO - 2016-02-07 22:59:09 --> Output Class Initialized
INFO - 2016-02-07 22:59:09 --> Security Class Initialized
DEBUG - 2016-02-07 22:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:59:09 --> Input Class Initialized
INFO - 2016-02-07 22:59:09 --> Language Class Initialized
INFO - 2016-02-07 22:59:09 --> Loader Class Initialized
INFO - 2016-02-07 22:59:09 --> Helper loaded: url_helper
INFO - 2016-02-07 22:59:09 --> Helper loaded: file_helper
INFO - 2016-02-07 22:59:09 --> Helper loaded: date_helper
INFO - 2016-02-07 22:59:09 --> Helper loaded: form_helper
INFO - 2016-02-07 22:59:09 --> Database Driver Class Initialized
INFO - 2016-02-07 22:59:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:59:10 --> Controller Class Initialized
INFO - 2016-02-07 22:59:10 --> Model Class Initialized
INFO - 2016-02-07 22:59:10 --> Model Class Initialized
INFO - 2016-02-07 22:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:59:10 --> Pagination Class Initialized
INFO - 2016-02-07 22:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:59:10 --> Helper loaded: text_helper
INFO - 2016-02-07 22:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:59:10 --> Final output sent to browser
DEBUG - 2016-02-07 22:59:10 --> Total execution time: 1.2379
INFO - 2016-02-07 22:59:44 --> Config Class Initialized
INFO - 2016-02-07 22:59:44 --> Hooks Class Initialized
DEBUG - 2016-02-07 22:59:44 --> UTF-8 Support Enabled
INFO - 2016-02-07 22:59:44 --> Utf8 Class Initialized
INFO - 2016-02-07 22:59:44 --> URI Class Initialized
INFO - 2016-02-07 22:59:44 --> Router Class Initialized
INFO - 2016-02-07 22:59:44 --> Output Class Initialized
INFO - 2016-02-07 22:59:44 --> Security Class Initialized
DEBUG - 2016-02-07 22:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 22:59:44 --> Input Class Initialized
INFO - 2016-02-07 22:59:44 --> Language Class Initialized
INFO - 2016-02-07 22:59:44 --> Loader Class Initialized
INFO - 2016-02-07 22:59:44 --> Helper loaded: url_helper
INFO - 2016-02-07 22:59:44 --> Helper loaded: file_helper
INFO - 2016-02-07 22:59:44 --> Helper loaded: date_helper
INFO - 2016-02-07 22:59:44 --> Helper loaded: form_helper
INFO - 2016-02-07 22:59:44 --> Database Driver Class Initialized
INFO - 2016-02-07 22:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 22:59:45 --> Controller Class Initialized
INFO - 2016-02-07 22:59:45 --> Model Class Initialized
INFO - 2016-02-07 22:59:45 --> Model Class Initialized
INFO - 2016-02-07 22:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 22:59:45 --> Pagination Class Initialized
INFO - 2016-02-07 22:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 22:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 22:59:45 --> Helper loaded: text_helper
INFO - 2016-02-07 22:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 22:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 22:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 22:59:45 --> Final output sent to browser
DEBUG - 2016-02-07 22:59:45 --> Total execution time: 1.3118
INFO - 2016-02-07 23:00:07 --> Config Class Initialized
INFO - 2016-02-07 23:00:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:00:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:00:07 --> Utf8 Class Initialized
INFO - 2016-02-07 23:00:07 --> URI Class Initialized
INFO - 2016-02-07 23:00:07 --> Router Class Initialized
INFO - 2016-02-07 23:00:07 --> Output Class Initialized
INFO - 2016-02-07 23:00:07 --> Security Class Initialized
DEBUG - 2016-02-07 23:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:00:07 --> Input Class Initialized
INFO - 2016-02-07 23:00:07 --> Language Class Initialized
INFO - 2016-02-07 23:00:07 --> Loader Class Initialized
INFO - 2016-02-07 23:00:07 --> Helper loaded: url_helper
INFO - 2016-02-07 23:00:07 --> Helper loaded: file_helper
INFO - 2016-02-07 23:00:07 --> Helper loaded: date_helper
INFO - 2016-02-07 23:00:07 --> Helper loaded: form_helper
INFO - 2016-02-07 23:00:07 --> Database Driver Class Initialized
INFO - 2016-02-07 23:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:00:08 --> Controller Class Initialized
INFO - 2016-02-07 23:00:08 --> Model Class Initialized
INFO - 2016-02-07 23:00:08 --> Model Class Initialized
INFO - 2016-02-07 23:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:00:08 --> Pagination Class Initialized
INFO - 2016-02-07 23:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:00:08 --> Helper loaded: text_helper
INFO - 2016-02-07 23:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:00:08 --> Final output sent to browser
DEBUG - 2016-02-07 23:00:08 --> Total execution time: 1.3055
INFO - 2016-02-07 23:00:35 --> Config Class Initialized
INFO - 2016-02-07 23:00:35 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:00:35 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:00:35 --> Utf8 Class Initialized
INFO - 2016-02-07 23:00:35 --> URI Class Initialized
INFO - 2016-02-07 23:00:35 --> Router Class Initialized
INFO - 2016-02-07 23:00:35 --> Output Class Initialized
INFO - 2016-02-07 23:00:35 --> Security Class Initialized
DEBUG - 2016-02-07 23:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:00:35 --> Input Class Initialized
INFO - 2016-02-07 23:00:35 --> Language Class Initialized
INFO - 2016-02-07 23:00:35 --> Loader Class Initialized
INFO - 2016-02-07 23:00:35 --> Helper loaded: url_helper
INFO - 2016-02-07 23:00:35 --> Helper loaded: file_helper
INFO - 2016-02-07 23:00:35 --> Helper loaded: date_helper
INFO - 2016-02-07 23:00:35 --> Helper loaded: form_helper
INFO - 2016-02-07 23:00:35 --> Database Driver Class Initialized
INFO - 2016-02-07 23:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:00:36 --> Controller Class Initialized
INFO - 2016-02-07 23:00:36 --> Model Class Initialized
INFO - 2016-02-07 23:00:36 --> Model Class Initialized
INFO - 2016-02-07 23:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:00:36 --> Pagination Class Initialized
INFO - 2016-02-07 23:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:00:36 --> Helper loaded: text_helper
INFO - 2016-02-07 23:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:00:36 --> Final output sent to browser
DEBUG - 2016-02-07 23:00:36 --> Total execution time: 1.1825
INFO - 2016-02-07 23:01:07 --> Config Class Initialized
INFO - 2016-02-07 23:01:07 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:01:07 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:01:07 --> Utf8 Class Initialized
INFO - 2016-02-07 23:01:07 --> URI Class Initialized
INFO - 2016-02-07 23:01:07 --> Router Class Initialized
INFO - 2016-02-07 23:01:07 --> Output Class Initialized
INFO - 2016-02-07 23:01:07 --> Security Class Initialized
DEBUG - 2016-02-07 23:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:01:07 --> Input Class Initialized
INFO - 2016-02-07 23:01:07 --> Language Class Initialized
INFO - 2016-02-07 23:01:07 --> Loader Class Initialized
INFO - 2016-02-07 23:01:07 --> Helper loaded: url_helper
INFO - 2016-02-07 23:01:07 --> Helper loaded: file_helper
INFO - 2016-02-07 23:01:07 --> Helper loaded: date_helper
INFO - 2016-02-07 23:01:07 --> Helper loaded: form_helper
INFO - 2016-02-07 23:01:07 --> Database Driver Class Initialized
INFO - 2016-02-07 23:01:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:01:08 --> Controller Class Initialized
INFO - 2016-02-07 23:01:08 --> Model Class Initialized
INFO - 2016-02-07 23:01:08 --> Model Class Initialized
INFO - 2016-02-07 23:01:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:01:08 --> Pagination Class Initialized
INFO - 2016-02-07 23:01:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:01:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:01:08 --> Helper loaded: text_helper
INFO - 2016-02-07 23:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:01:09 --> Final output sent to browser
DEBUG - 2016-02-07 23:01:09 --> Total execution time: 1.2287
INFO - 2016-02-07 23:01:52 --> Config Class Initialized
INFO - 2016-02-07 23:01:52 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:01:52 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:01:52 --> Utf8 Class Initialized
INFO - 2016-02-07 23:01:52 --> URI Class Initialized
INFO - 2016-02-07 23:01:52 --> Router Class Initialized
INFO - 2016-02-07 23:01:52 --> Output Class Initialized
INFO - 2016-02-07 23:01:52 --> Security Class Initialized
DEBUG - 2016-02-07 23:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:01:52 --> Input Class Initialized
INFO - 2016-02-07 23:01:52 --> Language Class Initialized
INFO - 2016-02-07 23:01:52 --> Loader Class Initialized
INFO - 2016-02-07 23:01:52 --> Helper loaded: url_helper
INFO - 2016-02-07 23:01:52 --> Helper loaded: file_helper
INFO - 2016-02-07 23:01:52 --> Helper loaded: date_helper
INFO - 2016-02-07 23:01:52 --> Helper loaded: form_helper
INFO - 2016-02-07 23:01:52 --> Database Driver Class Initialized
INFO - 2016-02-07 23:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:01:53 --> Controller Class Initialized
INFO - 2016-02-07 23:01:53 --> Model Class Initialized
INFO - 2016-02-07 23:01:53 --> Model Class Initialized
INFO - 2016-02-07 23:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:01:53 --> Pagination Class Initialized
INFO - 2016-02-07 23:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:01:53 --> Helper loaded: text_helper
INFO - 2016-02-07 23:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:01:53 --> Final output sent to browser
DEBUG - 2016-02-07 23:01:53 --> Total execution time: 1.2575
INFO - 2016-02-07 23:02:06 --> Config Class Initialized
INFO - 2016-02-07 23:02:06 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:02:06 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:02:06 --> Utf8 Class Initialized
INFO - 2016-02-07 23:02:06 --> URI Class Initialized
DEBUG - 2016-02-07 23:02:06 --> No URI present. Default controller set.
INFO - 2016-02-07 23:02:06 --> Router Class Initialized
INFO - 2016-02-07 23:02:06 --> Output Class Initialized
INFO - 2016-02-07 23:02:06 --> Security Class Initialized
DEBUG - 2016-02-07 23:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:02:06 --> Input Class Initialized
INFO - 2016-02-07 23:02:06 --> Language Class Initialized
INFO - 2016-02-07 23:02:06 --> Loader Class Initialized
INFO - 2016-02-07 23:02:06 --> Helper loaded: url_helper
INFO - 2016-02-07 23:02:06 --> Helper loaded: file_helper
INFO - 2016-02-07 23:02:06 --> Helper loaded: date_helper
INFO - 2016-02-07 23:02:06 --> Helper loaded: form_helper
INFO - 2016-02-07 23:02:06 --> Database Driver Class Initialized
INFO - 2016-02-07 23:02:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:02:07 --> Controller Class Initialized
INFO - 2016-02-07 23:02:07 --> Model Class Initialized
INFO - 2016-02-07 23:02:07 --> Model Class Initialized
INFO - 2016-02-07 23:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:02:07 --> Pagination Class Initialized
INFO - 2016-02-07 23:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:02:07 --> Final output sent to browser
DEBUG - 2016-02-07 23:02:07 --> Total execution time: 1.1538
INFO - 2016-02-07 23:03:03 --> Config Class Initialized
INFO - 2016-02-07 23:03:03 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:03:03 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:03:03 --> Utf8 Class Initialized
INFO - 2016-02-07 23:03:03 --> URI Class Initialized
DEBUG - 2016-02-07 23:03:03 --> No URI present. Default controller set.
INFO - 2016-02-07 23:03:03 --> Router Class Initialized
INFO - 2016-02-07 23:03:03 --> Output Class Initialized
INFO - 2016-02-07 23:03:03 --> Security Class Initialized
DEBUG - 2016-02-07 23:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:03:03 --> Input Class Initialized
INFO - 2016-02-07 23:03:03 --> Language Class Initialized
INFO - 2016-02-07 23:03:03 --> Loader Class Initialized
INFO - 2016-02-07 23:03:03 --> Helper loaded: url_helper
INFO - 2016-02-07 23:03:03 --> Helper loaded: file_helper
INFO - 2016-02-07 23:03:03 --> Helper loaded: date_helper
INFO - 2016-02-07 23:03:03 --> Helper loaded: form_helper
INFO - 2016-02-07 23:03:03 --> Database Driver Class Initialized
INFO - 2016-02-07 23:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:03:04 --> Controller Class Initialized
INFO - 2016-02-07 23:03:04 --> Model Class Initialized
INFO - 2016-02-07 23:03:04 --> Model Class Initialized
INFO - 2016-02-07 23:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:03:04 --> Pagination Class Initialized
INFO - 2016-02-07 23:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:03:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:03:04 --> Final output sent to browser
DEBUG - 2016-02-07 23:03:04 --> Total execution time: 1.1548
INFO - 2016-02-07 23:03:14 --> Config Class Initialized
INFO - 2016-02-07 23:03:14 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:03:14 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:03:14 --> Utf8 Class Initialized
INFO - 2016-02-07 23:03:14 --> URI Class Initialized
DEBUG - 2016-02-07 23:03:14 --> No URI present. Default controller set.
INFO - 2016-02-07 23:03:14 --> Router Class Initialized
INFO - 2016-02-07 23:03:14 --> Output Class Initialized
INFO - 2016-02-07 23:03:14 --> Security Class Initialized
DEBUG - 2016-02-07 23:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:03:14 --> Input Class Initialized
INFO - 2016-02-07 23:03:14 --> Language Class Initialized
INFO - 2016-02-07 23:03:14 --> Loader Class Initialized
INFO - 2016-02-07 23:03:14 --> Helper loaded: url_helper
INFO - 2016-02-07 23:03:14 --> Helper loaded: file_helper
INFO - 2016-02-07 23:03:14 --> Helper loaded: date_helper
INFO - 2016-02-07 23:03:14 --> Helper loaded: form_helper
INFO - 2016-02-07 23:03:14 --> Database Driver Class Initialized
INFO - 2016-02-07 23:03:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:03:15 --> Controller Class Initialized
INFO - 2016-02-07 23:03:15 --> Model Class Initialized
INFO - 2016-02-07 23:03:15 --> Model Class Initialized
INFO - 2016-02-07 23:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:03:15 --> Pagination Class Initialized
INFO - 2016-02-07 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:03:15 --> Final output sent to browser
DEBUG - 2016-02-07 23:03:15 --> Total execution time: 1.1277
INFO - 2016-02-07 23:03:22 --> Config Class Initialized
INFO - 2016-02-07 23:03:22 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:03:22 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:03:22 --> Utf8 Class Initialized
INFO - 2016-02-07 23:03:22 --> URI Class Initialized
INFO - 2016-02-07 23:03:22 --> Router Class Initialized
INFO - 2016-02-07 23:03:22 --> Output Class Initialized
INFO - 2016-02-07 23:03:22 --> Security Class Initialized
DEBUG - 2016-02-07 23:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:03:22 --> Input Class Initialized
INFO - 2016-02-07 23:03:22 --> Language Class Initialized
INFO - 2016-02-07 23:03:22 --> Loader Class Initialized
INFO - 2016-02-07 23:03:22 --> Helper loaded: url_helper
INFO - 2016-02-07 23:03:22 --> Helper loaded: file_helper
INFO - 2016-02-07 23:03:22 --> Helper loaded: date_helper
INFO - 2016-02-07 23:03:22 --> Helper loaded: form_helper
INFO - 2016-02-07 23:03:22 --> Database Driver Class Initialized
INFO - 2016-02-07 23:03:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:03:23 --> Controller Class Initialized
INFO - 2016-02-07 23:03:23 --> Model Class Initialized
INFO - 2016-02-07 23:03:23 --> Model Class Initialized
INFO - 2016-02-07 23:03:23 --> Form Validation Class Initialized
INFO - 2016-02-07 23:03:23 --> Helper loaded: text_helper
INFO - 2016-02-07 23:03:24 --> Config Class Initialized
INFO - 2016-02-07 23:03:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:03:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:03:24 --> Utf8 Class Initialized
INFO - 2016-02-07 23:03:24 --> URI Class Initialized
INFO - 2016-02-07 23:03:24 --> Router Class Initialized
INFO - 2016-02-07 23:03:24 --> Output Class Initialized
INFO - 2016-02-07 23:03:24 --> Security Class Initialized
DEBUG - 2016-02-07 23:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:03:24 --> Input Class Initialized
INFO - 2016-02-07 23:03:24 --> Language Class Initialized
INFO - 2016-02-07 23:03:24 --> Loader Class Initialized
INFO - 2016-02-07 23:03:24 --> Helper loaded: url_helper
INFO - 2016-02-07 23:03:24 --> Helper loaded: file_helper
INFO - 2016-02-07 23:03:24 --> Helper loaded: date_helper
INFO - 2016-02-07 23:03:24 --> Helper loaded: form_helper
INFO - 2016-02-07 23:03:24 --> Database Driver Class Initialized
INFO - 2016-02-07 23:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:03:25 --> Controller Class Initialized
INFO - 2016-02-07 23:03:25 --> Model Class Initialized
INFO - 2016-02-07 23:03:25 --> Model Class Initialized
INFO - 2016-02-07 23:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:03:25 --> Pagination Class Initialized
INFO - 2016-02-07 23:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:03:25 --> Final output sent to browser
DEBUG - 2016-02-07 23:03:25 --> Total execution time: 1.1634
INFO - 2016-02-07 23:04:05 --> Config Class Initialized
INFO - 2016-02-07 23:04:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:05 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:05 --> URI Class Initialized
DEBUG - 2016-02-07 23:04:05 --> No URI present. Default controller set.
INFO - 2016-02-07 23:04:05 --> Router Class Initialized
INFO - 2016-02-07 23:04:05 --> Output Class Initialized
INFO - 2016-02-07 23:04:05 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:05 --> Input Class Initialized
INFO - 2016-02-07 23:04:05 --> Language Class Initialized
INFO - 2016-02-07 23:04:05 --> Loader Class Initialized
INFO - 2016-02-07 23:04:05 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:05 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:05 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:05 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:05 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:06 --> Controller Class Initialized
INFO - 2016-02-07 23:04:06 --> Model Class Initialized
INFO - 2016-02-07 23:04:06 --> Model Class Initialized
INFO - 2016-02-07 23:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:06 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:07 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:07 --> Total execution time: 1.1579
INFO - 2016-02-07 23:04:11 --> Config Class Initialized
INFO - 2016-02-07 23:04:11 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:11 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:11 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:11 --> URI Class Initialized
INFO - 2016-02-07 23:04:11 --> Router Class Initialized
INFO - 2016-02-07 23:04:11 --> Output Class Initialized
INFO - 2016-02-07 23:04:11 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:11 --> Input Class Initialized
INFO - 2016-02-07 23:04:11 --> Language Class Initialized
INFO - 2016-02-07 23:04:11 --> Loader Class Initialized
INFO - 2016-02-07 23:04:11 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:11 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:11 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:11 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:11 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:12 --> Controller Class Initialized
INFO - 2016-02-07 23:04:12 --> Model Class Initialized
INFO - 2016-02-07 23:04:13 --> Model Class Initialized
INFO - 2016-02-07 23:04:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:13 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:13 --> Helper loaded: text_helper
INFO - 2016-02-07 23:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:13 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:13 --> Total execution time: 1.1887
INFO - 2016-02-07 23:04:16 --> Config Class Initialized
INFO - 2016-02-07 23:04:16 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:16 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:16 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:16 --> URI Class Initialized
INFO - 2016-02-07 23:04:16 --> Router Class Initialized
INFO - 2016-02-07 23:04:16 --> Output Class Initialized
INFO - 2016-02-07 23:04:16 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:16 --> Input Class Initialized
INFO - 2016-02-07 23:04:16 --> Language Class Initialized
INFO - 2016-02-07 23:04:16 --> Loader Class Initialized
INFO - 2016-02-07 23:04:16 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:16 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:16 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:16 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:16 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:17 --> Controller Class Initialized
INFO - 2016-02-07 23:04:17 --> Model Class Initialized
INFO - 2016-02-07 23:04:17 --> Model Class Initialized
INFO - 2016-02-07 23:04:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:17 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:17 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:17 --> Total execution time: 1.0912
INFO - 2016-02-07 23:04:20 --> Config Class Initialized
INFO - 2016-02-07 23:04:20 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:20 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:20 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:20 --> URI Class Initialized
INFO - 2016-02-07 23:04:20 --> Router Class Initialized
INFO - 2016-02-07 23:04:20 --> Output Class Initialized
INFO - 2016-02-07 23:04:20 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:20 --> Input Class Initialized
INFO - 2016-02-07 23:04:20 --> Language Class Initialized
INFO - 2016-02-07 23:04:20 --> Loader Class Initialized
INFO - 2016-02-07 23:04:20 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:20 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:20 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:20 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:20 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:21 --> Controller Class Initialized
INFO - 2016-02-07 23:04:21 --> Model Class Initialized
INFO - 2016-02-07 23:04:21 --> Model Class Initialized
INFO - 2016-02-07 23:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:21 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:21 --> Helper loaded: text_helper
INFO - 2016-02-07 23:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:21 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:21 --> Total execution time: 1.1975
INFO - 2016-02-07 23:04:23 --> Config Class Initialized
INFO - 2016-02-07 23:04:23 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:23 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:23 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:23 --> URI Class Initialized
INFO - 2016-02-07 23:04:23 --> Router Class Initialized
INFO - 2016-02-07 23:04:23 --> Output Class Initialized
INFO - 2016-02-07 23:04:23 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:23 --> Input Class Initialized
INFO - 2016-02-07 23:04:23 --> Language Class Initialized
INFO - 2016-02-07 23:04:23 --> Loader Class Initialized
INFO - 2016-02-07 23:04:23 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:23 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:23 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:23 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:23 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:24 --> Controller Class Initialized
INFO - 2016-02-07 23:04:24 --> Model Class Initialized
INFO - 2016-02-07 23:04:24 --> Model Class Initialized
INFO - 2016-02-07 23:04:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:24 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:24 --> Config Class Initialized
INFO - 2016-02-07 23:04:24 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:24 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:24 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:24 --> URI Class Initialized
INFO - 2016-02-07 23:04:24 --> Router Class Initialized
INFO - 2016-02-07 23:04:24 --> Output Class Initialized
INFO - 2016-02-07 23:04:24 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:24 --> Input Class Initialized
INFO - 2016-02-07 23:04:24 --> Language Class Initialized
INFO - 2016-02-07 23:04:24 --> Loader Class Initialized
INFO - 2016-02-07 23:04:24 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:24 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:24 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:24 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:24 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:25 --> Controller Class Initialized
INFO - 2016-02-07 23:04:25 --> Model Class Initialized
INFO - 2016-02-07 23:04:25 --> Model Class Initialized
INFO - 2016-02-07 23:04:25 --> Form Validation Class Initialized
INFO - 2016-02-07 23:04:25 --> Helper loaded: text_helper
INFO - 2016-02-07 23:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-07 23:04:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:25 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:25 --> Total execution time: 1.1642
INFO - 2016-02-07 23:04:28 --> Config Class Initialized
INFO - 2016-02-07 23:04:28 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:04:28 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:04:28 --> Utf8 Class Initialized
INFO - 2016-02-07 23:04:28 --> URI Class Initialized
DEBUG - 2016-02-07 23:04:28 --> No URI present. Default controller set.
INFO - 2016-02-07 23:04:28 --> Router Class Initialized
INFO - 2016-02-07 23:04:28 --> Output Class Initialized
INFO - 2016-02-07 23:04:28 --> Security Class Initialized
DEBUG - 2016-02-07 23:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:04:28 --> Input Class Initialized
INFO - 2016-02-07 23:04:28 --> Language Class Initialized
INFO - 2016-02-07 23:04:28 --> Loader Class Initialized
INFO - 2016-02-07 23:04:28 --> Helper loaded: url_helper
INFO - 2016-02-07 23:04:28 --> Helper loaded: file_helper
INFO - 2016-02-07 23:04:28 --> Helper loaded: date_helper
INFO - 2016-02-07 23:04:28 --> Helper loaded: form_helper
INFO - 2016-02-07 23:04:28 --> Database Driver Class Initialized
INFO - 2016-02-07 23:04:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:04:29 --> Controller Class Initialized
INFO - 2016-02-07 23:04:29 --> Model Class Initialized
INFO - 2016-02-07 23:04:29 --> Model Class Initialized
INFO - 2016-02-07 23:04:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:04:29 --> Pagination Class Initialized
INFO - 2016-02-07 23:04:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:04:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:04:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:04:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:04:29 --> Final output sent to browser
DEBUG - 2016-02-07 23:04:29 --> Total execution time: 1.1516
INFO - 2016-02-07 23:22:40 --> Config Class Initialized
INFO - 2016-02-07 23:22:40 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:22:40 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:22:40 --> Utf8 Class Initialized
INFO - 2016-02-07 23:22:40 --> URI Class Initialized
DEBUG - 2016-02-07 23:22:40 --> No URI present. Default controller set.
INFO - 2016-02-07 23:22:40 --> Router Class Initialized
INFO - 2016-02-07 23:22:40 --> Output Class Initialized
INFO - 2016-02-07 23:22:40 --> Security Class Initialized
DEBUG - 2016-02-07 23:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:22:40 --> Input Class Initialized
INFO - 2016-02-07 23:22:40 --> Language Class Initialized
INFO - 2016-02-07 23:22:40 --> Loader Class Initialized
INFO - 2016-02-07 23:22:40 --> Helper loaded: url_helper
INFO - 2016-02-07 23:22:40 --> Helper loaded: file_helper
INFO - 2016-02-07 23:22:40 --> Helper loaded: date_helper
INFO - 2016-02-07 23:22:40 --> Helper loaded: form_helper
INFO - 2016-02-07 23:22:40 --> Database Driver Class Initialized
INFO - 2016-02-07 23:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:22:41 --> Controller Class Initialized
INFO - 2016-02-07 23:22:41 --> Model Class Initialized
INFO - 2016-02-07 23:22:41 --> Model Class Initialized
INFO - 2016-02-07 23:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:22:41 --> Pagination Class Initialized
INFO - 2016-02-07 23:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:22:41 --> Final output sent to browser
DEBUG - 2016-02-07 23:22:41 --> Total execution time: 1.1199
INFO - 2016-02-07 23:22:46 --> Config Class Initialized
INFO - 2016-02-07 23:22:46 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:22:46 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:22:46 --> Utf8 Class Initialized
INFO - 2016-02-07 23:22:46 --> URI Class Initialized
INFO - 2016-02-07 23:22:46 --> Router Class Initialized
INFO - 2016-02-07 23:22:46 --> Output Class Initialized
INFO - 2016-02-07 23:22:46 --> Security Class Initialized
DEBUG - 2016-02-07 23:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:22:46 --> Input Class Initialized
INFO - 2016-02-07 23:22:46 --> Language Class Initialized
INFO - 2016-02-07 23:22:46 --> Loader Class Initialized
INFO - 2016-02-07 23:22:46 --> Helper loaded: url_helper
INFO - 2016-02-07 23:22:46 --> Helper loaded: file_helper
INFO - 2016-02-07 23:22:46 --> Helper loaded: date_helper
INFO - 2016-02-07 23:22:46 --> Helper loaded: form_helper
INFO - 2016-02-07 23:22:46 --> Database Driver Class Initialized
INFO - 2016-02-07 23:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:22:47 --> Controller Class Initialized
INFO - 2016-02-07 23:22:47 --> Model Class Initialized
INFO - 2016-02-07 23:22:47 --> Model Class Initialized
INFO - 2016-02-07 23:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:22:47 --> Pagination Class Initialized
INFO - 2016-02-07 23:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:22:47 --> Helper loaded: text_helper
INFO - 2016-02-07 23:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:22:47 --> Final output sent to browser
DEBUG - 2016-02-07 23:22:47 --> Total execution time: 1.1867
INFO - 2016-02-07 23:23:05 --> Config Class Initialized
INFO - 2016-02-07 23:23:05 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:23:05 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:23:05 --> Utf8 Class Initialized
INFO - 2016-02-07 23:23:05 --> URI Class Initialized
INFO - 2016-02-07 23:23:05 --> Router Class Initialized
INFO - 2016-02-07 23:23:05 --> Output Class Initialized
INFO - 2016-02-07 23:23:05 --> Security Class Initialized
DEBUG - 2016-02-07 23:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:23:05 --> Input Class Initialized
INFO - 2016-02-07 23:23:05 --> Language Class Initialized
INFO - 2016-02-07 23:23:05 --> Loader Class Initialized
INFO - 2016-02-07 23:23:05 --> Helper loaded: url_helper
INFO - 2016-02-07 23:23:05 --> Helper loaded: file_helper
INFO - 2016-02-07 23:23:05 --> Helper loaded: date_helper
INFO - 2016-02-07 23:23:05 --> Helper loaded: form_helper
INFO - 2016-02-07 23:23:05 --> Database Driver Class Initialized
INFO - 2016-02-07 23:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:23:06 --> Controller Class Initialized
INFO - 2016-02-07 23:23:06 --> Model Class Initialized
INFO - 2016-02-07 23:23:06 --> Model Class Initialized
INFO - 2016-02-07 23:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:23:06 --> Pagination Class Initialized
INFO - 2016-02-07 23:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:23:06 --> Helper loaded: text_helper
INFO - 2016-02-07 23:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-07 23:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-07 23:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:23:06 --> Final output sent to browser
DEBUG - 2016-02-07 23:23:06 --> Total execution time: 1.1940
INFO - 2016-02-07 23:23:37 --> Config Class Initialized
INFO - 2016-02-07 23:23:37 --> Hooks Class Initialized
DEBUG - 2016-02-07 23:23:37 --> UTF-8 Support Enabled
INFO - 2016-02-07 23:23:37 --> Utf8 Class Initialized
INFO - 2016-02-07 23:23:37 --> URI Class Initialized
DEBUG - 2016-02-07 23:23:37 --> No URI present. Default controller set.
INFO - 2016-02-07 23:23:37 --> Router Class Initialized
INFO - 2016-02-07 23:23:37 --> Output Class Initialized
INFO - 2016-02-07 23:23:37 --> Security Class Initialized
DEBUG - 2016-02-07 23:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-07 23:23:37 --> Input Class Initialized
INFO - 2016-02-07 23:23:37 --> Language Class Initialized
INFO - 2016-02-07 23:23:37 --> Loader Class Initialized
INFO - 2016-02-07 23:23:37 --> Helper loaded: url_helper
INFO - 2016-02-07 23:23:37 --> Helper loaded: file_helper
INFO - 2016-02-07 23:23:37 --> Helper loaded: date_helper
INFO - 2016-02-07 23:23:37 --> Helper loaded: form_helper
INFO - 2016-02-07 23:23:37 --> Database Driver Class Initialized
INFO - 2016-02-07 23:23:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-07 23:23:38 --> Controller Class Initialized
INFO - 2016-02-07 23:23:38 --> Model Class Initialized
INFO - 2016-02-07 23:23:38 --> Model Class Initialized
INFO - 2016-02-07 23:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-07 23:23:38 --> Pagination Class Initialized
INFO - 2016-02-07 23:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-07 23:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-07 23:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-07 23:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-07 23:23:38 --> Final output sent to browser
DEBUG - 2016-02-07 23:23:38 --> Total execution time: 1.1302
