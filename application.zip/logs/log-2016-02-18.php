<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-18 06:33:37 --> Config Class Initialized
INFO - 2016-02-18 06:33:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:33:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:33:37 --> Utf8 Class Initialized
INFO - 2016-02-18 06:33:37 --> URI Class Initialized
DEBUG - 2016-02-18 06:33:37 --> No URI present. Default controller set.
INFO - 2016-02-18 06:33:37 --> Router Class Initialized
INFO - 2016-02-18 06:33:37 --> Output Class Initialized
INFO - 2016-02-18 06:33:37 --> Security Class Initialized
DEBUG - 2016-02-18 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:33:37 --> Input Class Initialized
INFO - 2016-02-18 06:33:37 --> Language Class Initialized
INFO - 2016-02-18 06:33:37 --> Loader Class Initialized
INFO - 2016-02-18 06:33:37 --> Helper loaded: url_helper
INFO - 2016-02-18 06:33:37 --> Helper loaded: file_helper
INFO - 2016-02-18 06:33:37 --> Helper loaded: date_helper
INFO - 2016-02-18 06:33:37 --> Helper loaded: form_helper
INFO - 2016-02-18 06:33:37 --> Database Driver Class Initialized
INFO - 2016-02-18 06:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:33:38 --> Controller Class Initialized
INFO - 2016-02-18 06:33:38 --> Model Class Initialized
INFO - 2016-02-18 06:33:38 --> Model Class Initialized
INFO - 2016-02-18 06:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:33:38 --> Pagination Class Initialized
INFO - 2016-02-18 06:33:38 --> Helper loaded: text_helper
INFO - 2016-02-18 06:33:38 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:33:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:33:38 --> Final output sent to browser
DEBUG - 2016-02-18 09:33:38 --> Total execution time: 1.1153
INFO - 2016-02-18 06:34:40 --> Config Class Initialized
INFO - 2016-02-18 06:34:40 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:34:40 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:34:40 --> Utf8 Class Initialized
INFO - 2016-02-18 06:34:40 --> URI Class Initialized
DEBUG - 2016-02-18 06:34:40 --> No URI present. Default controller set.
INFO - 2016-02-18 06:34:40 --> Router Class Initialized
INFO - 2016-02-18 06:34:40 --> Output Class Initialized
INFO - 2016-02-18 06:34:40 --> Security Class Initialized
DEBUG - 2016-02-18 06:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:34:40 --> Input Class Initialized
INFO - 2016-02-18 06:34:40 --> Language Class Initialized
INFO - 2016-02-18 06:34:40 --> Loader Class Initialized
INFO - 2016-02-18 06:34:40 --> Helper loaded: url_helper
INFO - 2016-02-18 06:34:40 --> Helper loaded: file_helper
INFO - 2016-02-18 06:34:40 --> Helper loaded: date_helper
INFO - 2016-02-18 06:34:40 --> Helper loaded: form_helper
INFO - 2016-02-18 06:34:40 --> Database Driver Class Initialized
INFO - 2016-02-18 06:34:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:34:41 --> Controller Class Initialized
INFO - 2016-02-18 06:34:41 --> Model Class Initialized
INFO - 2016-02-18 06:34:41 --> Model Class Initialized
INFO - 2016-02-18 06:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:34:41 --> Pagination Class Initialized
INFO - 2016-02-18 06:34:41 --> Helper loaded: text_helper
INFO - 2016-02-18 06:34:41 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:34:41 --> Final output sent to browser
DEBUG - 2016-02-18 09:34:41 --> Total execution time: 1.1114
INFO - 2016-02-18 06:34:43 --> Config Class Initialized
INFO - 2016-02-18 06:34:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:34:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:34:43 --> Utf8 Class Initialized
INFO - 2016-02-18 06:34:43 --> URI Class Initialized
INFO - 2016-02-18 06:34:43 --> Router Class Initialized
INFO - 2016-02-18 06:34:43 --> Output Class Initialized
INFO - 2016-02-18 06:34:43 --> Security Class Initialized
DEBUG - 2016-02-18 06:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:34:43 --> Input Class Initialized
INFO - 2016-02-18 06:34:43 --> Language Class Initialized
INFO - 2016-02-18 06:34:43 --> Loader Class Initialized
INFO - 2016-02-18 06:34:43 --> Helper loaded: url_helper
INFO - 2016-02-18 06:34:43 --> Helper loaded: file_helper
INFO - 2016-02-18 06:34:43 --> Helper loaded: date_helper
INFO - 2016-02-18 06:34:43 --> Helper loaded: form_helper
INFO - 2016-02-18 06:34:43 --> Database Driver Class Initialized
INFO - 2016-02-18 06:34:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:34:44 --> Controller Class Initialized
INFO - 2016-02-18 06:34:44 --> Model Class Initialized
INFO - 2016-02-18 06:34:44 --> Model Class Initialized
INFO - 2016-02-18 06:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:34:44 --> Pagination Class Initialized
INFO - 2016-02-18 06:34:44 --> Helper loaded: text_helper
INFO - 2016-02-18 06:34:44 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:34:44 --> Final output sent to browser
DEBUG - 2016-02-18 09:34:44 --> Total execution time: 1.1725
INFO - 2016-02-18 06:34:47 --> Config Class Initialized
INFO - 2016-02-18 06:34:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:34:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:34:47 --> Utf8 Class Initialized
INFO - 2016-02-18 06:34:47 --> URI Class Initialized
DEBUG - 2016-02-18 06:34:47 --> No URI present. Default controller set.
INFO - 2016-02-18 06:34:47 --> Router Class Initialized
INFO - 2016-02-18 06:34:47 --> Output Class Initialized
INFO - 2016-02-18 06:34:47 --> Security Class Initialized
DEBUG - 2016-02-18 06:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:34:47 --> Input Class Initialized
INFO - 2016-02-18 06:34:47 --> Language Class Initialized
INFO - 2016-02-18 06:34:47 --> Loader Class Initialized
INFO - 2016-02-18 06:34:47 --> Helper loaded: url_helper
INFO - 2016-02-18 06:34:47 --> Helper loaded: file_helper
INFO - 2016-02-18 06:34:47 --> Helper loaded: date_helper
INFO - 2016-02-18 06:34:47 --> Helper loaded: form_helper
INFO - 2016-02-18 06:34:47 --> Database Driver Class Initialized
INFO - 2016-02-18 06:34:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:34:48 --> Controller Class Initialized
INFO - 2016-02-18 06:34:48 --> Model Class Initialized
INFO - 2016-02-18 06:34:48 --> Model Class Initialized
INFO - 2016-02-18 06:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:34:48 --> Pagination Class Initialized
INFO - 2016-02-18 06:34:48 --> Helper loaded: text_helper
INFO - 2016-02-18 06:34:48 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:34:48 --> Final output sent to browser
DEBUG - 2016-02-18 09:34:48 --> Total execution time: 1.0988
INFO - 2016-02-18 06:34:49 --> Config Class Initialized
INFO - 2016-02-18 06:34:49 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:34:49 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:34:49 --> Utf8 Class Initialized
INFO - 2016-02-18 06:34:49 --> URI Class Initialized
INFO - 2016-02-18 06:34:49 --> Router Class Initialized
INFO - 2016-02-18 06:34:49 --> Output Class Initialized
INFO - 2016-02-18 06:34:49 --> Security Class Initialized
DEBUG - 2016-02-18 06:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:34:49 --> Input Class Initialized
INFO - 2016-02-18 06:34:49 --> Language Class Initialized
INFO - 2016-02-18 06:34:49 --> Loader Class Initialized
INFO - 2016-02-18 06:34:49 --> Helper loaded: url_helper
INFO - 2016-02-18 06:34:49 --> Helper loaded: file_helper
INFO - 2016-02-18 06:34:49 --> Helper loaded: date_helper
INFO - 2016-02-18 06:34:49 --> Helper loaded: form_helper
INFO - 2016-02-18 06:34:49 --> Database Driver Class Initialized
INFO - 2016-02-18 06:34:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:34:51 --> Controller Class Initialized
INFO - 2016-02-18 06:34:51 --> Model Class Initialized
INFO - 2016-02-18 06:34:51 --> Model Class Initialized
INFO - 2016-02-18 06:34:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:34:51 --> Pagination Class Initialized
INFO - 2016-02-18 06:34:51 --> Helper loaded: text_helper
INFO - 2016-02-18 06:34:51 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:34:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:34:51 --> Final output sent to browser
DEBUG - 2016-02-18 09:34:51 --> Total execution time: 1.1237
INFO - 2016-02-18 06:36:08 --> Config Class Initialized
INFO - 2016-02-18 06:36:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:08 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:08 --> URI Class Initialized
INFO - 2016-02-18 06:36:08 --> Router Class Initialized
INFO - 2016-02-18 06:36:08 --> Output Class Initialized
INFO - 2016-02-18 06:36:08 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:08 --> Input Class Initialized
INFO - 2016-02-18 06:36:08 --> Language Class Initialized
INFO - 2016-02-18 06:36:08 --> Loader Class Initialized
INFO - 2016-02-18 06:36:08 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:08 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:08 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:08 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:08 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:09 --> Controller Class Initialized
INFO - 2016-02-18 06:36:09 --> Model Class Initialized
INFO - 2016-02-18 06:36:09 --> Model Class Initialized
INFO - 2016-02-18 06:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:10 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:10 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:10 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:10 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:10 --> Total execution time: 1.4684
INFO - 2016-02-18 06:36:12 --> Config Class Initialized
INFO - 2016-02-18 06:36:12 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:12 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:12 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:12 --> URI Class Initialized
INFO - 2016-02-18 06:36:12 --> Router Class Initialized
INFO - 2016-02-18 06:36:12 --> Output Class Initialized
INFO - 2016-02-18 06:36:12 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:12 --> Input Class Initialized
INFO - 2016-02-18 06:36:12 --> Language Class Initialized
INFO - 2016-02-18 06:36:12 --> Loader Class Initialized
INFO - 2016-02-18 06:36:12 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:12 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:12 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:12 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:12 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:13 --> Controller Class Initialized
INFO - 2016-02-18 06:36:13 --> Model Class Initialized
INFO - 2016-02-18 06:36:13 --> Model Class Initialized
INFO - 2016-02-18 06:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:13 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:13 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:13 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:13 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:13 --> Total execution time: 1.1842
INFO - 2016-02-18 06:36:14 --> Config Class Initialized
INFO - 2016-02-18 06:36:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:14 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:14 --> URI Class Initialized
INFO - 2016-02-18 06:36:14 --> Router Class Initialized
INFO - 2016-02-18 06:36:14 --> Output Class Initialized
INFO - 2016-02-18 06:36:14 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:14 --> Input Class Initialized
INFO - 2016-02-18 06:36:14 --> Language Class Initialized
INFO - 2016-02-18 06:36:14 --> Loader Class Initialized
INFO - 2016-02-18 06:36:14 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:14 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:14 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:14 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:14 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:15 --> Controller Class Initialized
INFO - 2016-02-18 06:36:15 --> Model Class Initialized
INFO - 2016-02-18 06:36:15 --> Model Class Initialized
INFO - 2016-02-18 06:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:15 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:15 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:15 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:15 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:15 --> Total execution time: 1.1852
INFO - 2016-02-18 06:36:17 --> Config Class Initialized
INFO - 2016-02-18 06:36:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:17 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:17 --> URI Class Initialized
INFO - 2016-02-18 06:36:17 --> Router Class Initialized
INFO - 2016-02-18 06:36:17 --> Output Class Initialized
INFO - 2016-02-18 06:36:17 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:17 --> Input Class Initialized
INFO - 2016-02-18 06:36:17 --> Language Class Initialized
INFO - 2016-02-18 06:36:17 --> Loader Class Initialized
INFO - 2016-02-18 06:36:17 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:17 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:17 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:17 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:17 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:18 --> Controller Class Initialized
INFO - 2016-02-18 06:36:18 --> Model Class Initialized
INFO - 2016-02-18 06:36:18 --> Model Class Initialized
INFO - 2016-02-18 06:36:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:18 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:18 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:18 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:18 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:18 --> Total execution time: 1.1645
INFO - 2016-02-18 06:36:19 --> Config Class Initialized
INFO - 2016-02-18 06:36:19 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:19 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:19 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:19 --> URI Class Initialized
INFO - 2016-02-18 06:36:19 --> Router Class Initialized
INFO - 2016-02-18 06:36:19 --> Output Class Initialized
INFO - 2016-02-18 06:36:19 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:19 --> Input Class Initialized
INFO - 2016-02-18 06:36:19 --> Language Class Initialized
INFO - 2016-02-18 06:36:19 --> Loader Class Initialized
INFO - 2016-02-18 06:36:19 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:19 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:19 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:19 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:19 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:20 --> Controller Class Initialized
INFO - 2016-02-18 06:36:20 --> Model Class Initialized
INFO - 2016-02-18 06:36:20 --> Model Class Initialized
INFO - 2016-02-18 06:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:20 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:20 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:20 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:21 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:21 --> Total execution time: 1.1747
INFO - 2016-02-18 06:36:22 --> Config Class Initialized
INFO - 2016-02-18 06:36:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:22 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:22 --> URI Class Initialized
DEBUG - 2016-02-18 06:36:22 --> No URI present. Default controller set.
INFO - 2016-02-18 06:36:22 --> Router Class Initialized
INFO - 2016-02-18 06:36:22 --> Output Class Initialized
INFO - 2016-02-18 06:36:22 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:22 --> Input Class Initialized
INFO - 2016-02-18 06:36:22 --> Language Class Initialized
INFO - 2016-02-18 06:36:22 --> Loader Class Initialized
INFO - 2016-02-18 06:36:22 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:22 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:22 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:22 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:22 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:23 --> Controller Class Initialized
INFO - 2016-02-18 06:36:23 --> Model Class Initialized
INFO - 2016-02-18 06:36:23 --> Model Class Initialized
INFO - 2016-02-18 06:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:23 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:23 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:23 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:23 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:23 --> Total execution time: 1.1052
INFO - 2016-02-18 06:36:24 --> Config Class Initialized
INFO - 2016-02-18 06:36:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:36:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:36:24 --> Utf8 Class Initialized
INFO - 2016-02-18 06:36:24 --> URI Class Initialized
INFO - 2016-02-18 06:36:24 --> Router Class Initialized
INFO - 2016-02-18 06:36:24 --> Output Class Initialized
INFO - 2016-02-18 06:36:24 --> Security Class Initialized
DEBUG - 2016-02-18 06:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:36:24 --> Input Class Initialized
INFO - 2016-02-18 06:36:24 --> Language Class Initialized
INFO - 2016-02-18 06:36:24 --> Loader Class Initialized
INFO - 2016-02-18 06:36:24 --> Helper loaded: url_helper
INFO - 2016-02-18 06:36:24 --> Helper loaded: file_helper
INFO - 2016-02-18 06:36:24 --> Helper loaded: date_helper
INFO - 2016-02-18 06:36:24 --> Helper loaded: form_helper
INFO - 2016-02-18 06:36:24 --> Database Driver Class Initialized
INFO - 2016-02-18 06:36:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:36:25 --> Controller Class Initialized
INFO - 2016-02-18 06:36:25 --> Model Class Initialized
INFO - 2016-02-18 06:36:25 --> Model Class Initialized
INFO - 2016-02-18 06:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:36:25 --> Pagination Class Initialized
INFO - 2016-02-18 06:36:25 --> Helper loaded: text_helper
INFO - 2016-02-18 06:36:25 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:36:25 --> Final output sent to browser
DEBUG - 2016-02-18 09:36:25 --> Total execution time: 1.1930
INFO - 2016-02-18 06:37:27 --> Config Class Initialized
INFO - 2016-02-18 06:37:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:37:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:37:27 --> Utf8 Class Initialized
INFO - 2016-02-18 06:37:27 --> URI Class Initialized
DEBUG - 2016-02-18 06:37:27 --> No URI present. Default controller set.
INFO - 2016-02-18 06:37:27 --> Router Class Initialized
INFO - 2016-02-18 06:37:27 --> Output Class Initialized
INFO - 2016-02-18 06:37:27 --> Security Class Initialized
DEBUG - 2016-02-18 06:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:37:27 --> Input Class Initialized
INFO - 2016-02-18 06:37:27 --> Language Class Initialized
INFO - 2016-02-18 06:37:27 --> Loader Class Initialized
INFO - 2016-02-18 06:37:27 --> Helper loaded: url_helper
INFO - 2016-02-18 06:37:27 --> Helper loaded: file_helper
INFO - 2016-02-18 06:37:27 --> Helper loaded: date_helper
INFO - 2016-02-18 06:37:27 --> Helper loaded: form_helper
INFO - 2016-02-18 06:37:27 --> Database Driver Class Initialized
INFO - 2016-02-18 06:37:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:37:28 --> Controller Class Initialized
INFO - 2016-02-18 06:37:28 --> Model Class Initialized
INFO - 2016-02-18 06:37:28 --> Model Class Initialized
INFO - 2016-02-18 06:37:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:37:28 --> Pagination Class Initialized
INFO - 2016-02-18 06:37:28 --> Helper loaded: text_helper
INFO - 2016-02-18 06:37:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:37:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:37:28 --> Final output sent to browser
DEBUG - 2016-02-18 09:37:28 --> Total execution time: 1.1525
INFO - 2016-02-18 06:37:30 --> Config Class Initialized
INFO - 2016-02-18 06:37:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:37:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:37:30 --> Utf8 Class Initialized
INFO - 2016-02-18 06:37:30 --> URI Class Initialized
INFO - 2016-02-18 06:37:30 --> Router Class Initialized
INFO - 2016-02-18 06:37:30 --> Output Class Initialized
INFO - 2016-02-18 06:37:30 --> Security Class Initialized
DEBUG - 2016-02-18 06:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:37:30 --> Input Class Initialized
INFO - 2016-02-18 06:37:30 --> Language Class Initialized
INFO - 2016-02-18 06:37:30 --> Loader Class Initialized
INFO - 2016-02-18 06:37:30 --> Helper loaded: url_helper
INFO - 2016-02-18 06:37:30 --> Helper loaded: file_helper
INFO - 2016-02-18 06:37:30 --> Helper loaded: date_helper
INFO - 2016-02-18 06:37:30 --> Helper loaded: form_helper
INFO - 2016-02-18 06:37:30 --> Database Driver Class Initialized
INFO - 2016-02-18 06:37:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:37:31 --> Controller Class Initialized
INFO - 2016-02-18 06:37:31 --> Model Class Initialized
INFO - 2016-02-18 06:37:31 --> Model Class Initialized
INFO - 2016-02-18 06:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:37:31 --> Pagination Class Initialized
INFO - 2016-02-18 06:37:31 --> Helper loaded: text_helper
INFO - 2016-02-18 06:37:31 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:37:31 --> Final output sent to browser
DEBUG - 2016-02-18 09:37:31 --> Total execution time: 1.2129
INFO - 2016-02-18 06:37:34 --> Config Class Initialized
INFO - 2016-02-18 06:37:34 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:37:34 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:37:34 --> Utf8 Class Initialized
INFO - 2016-02-18 06:37:34 --> URI Class Initialized
INFO - 2016-02-18 06:37:34 --> Router Class Initialized
INFO - 2016-02-18 06:37:34 --> Output Class Initialized
INFO - 2016-02-18 06:37:34 --> Security Class Initialized
DEBUG - 2016-02-18 06:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:37:34 --> Input Class Initialized
INFO - 2016-02-18 06:37:34 --> Language Class Initialized
INFO - 2016-02-18 06:37:34 --> Loader Class Initialized
INFO - 2016-02-18 06:37:34 --> Helper loaded: url_helper
INFO - 2016-02-18 06:37:34 --> Helper loaded: file_helper
INFO - 2016-02-18 06:37:34 --> Helper loaded: date_helper
INFO - 2016-02-18 06:37:34 --> Helper loaded: form_helper
INFO - 2016-02-18 06:37:34 --> Database Driver Class Initialized
INFO - 2016-02-18 06:37:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:37:35 --> Controller Class Initialized
INFO - 2016-02-18 06:37:35 --> Model Class Initialized
INFO - 2016-02-18 06:37:35 --> Model Class Initialized
INFO - 2016-02-18 06:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:37:35 --> Pagination Class Initialized
INFO - 2016-02-18 06:37:35 --> Helper loaded: text_helper
INFO - 2016-02-18 06:37:35 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:37:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:37:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:37:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:37:36 --> Final output sent to browser
DEBUG - 2016-02-18 09:37:36 --> Total execution time: 1.2047
INFO - 2016-02-18 06:37:39 --> Config Class Initialized
INFO - 2016-02-18 06:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:37:39 --> Utf8 Class Initialized
INFO - 2016-02-18 06:37:39 --> URI Class Initialized
INFO - 2016-02-18 06:37:39 --> Router Class Initialized
INFO - 2016-02-18 06:37:39 --> Output Class Initialized
INFO - 2016-02-18 06:37:39 --> Security Class Initialized
DEBUG - 2016-02-18 06:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:37:39 --> Input Class Initialized
INFO - 2016-02-18 06:37:39 --> Language Class Initialized
INFO - 2016-02-18 06:37:39 --> Loader Class Initialized
INFO - 2016-02-18 06:37:39 --> Helper loaded: url_helper
INFO - 2016-02-18 06:37:39 --> Helper loaded: file_helper
INFO - 2016-02-18 06:37:39 --> Helper loaded: date_helper
INFO - 2016-02-18 06:37:39 --> Helper loaded: form_helper
INFO - 2016-02-18 06:37:39 --> Database Driver Class Initialized
INFO - 2016-02-18 06:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:37:40 --> Controller Class Initialized
INFO - 2016-02-18 06:37:40 --> Model Class Initialized
INFO - 2016-02-18 06:37:40 --> Model Class Initialized
INFO - 2016-02-18 06:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:37:41 --> Pagination Class Initialized
INFO - 2016-02-18 06:37:41 --> Helper loaded: text_helper
INFO - 2016-02-18 06:37:41 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:37:41 --> Final output sent to browser
DEBUG - 2016-02-18 09:37:41 --> Total execution time: 1.1380
INFO - 2016-02-18 06:37:54 --> Config Class Initialized
INFO - 2016-02-18 06:37:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:37:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:37:54 --> Utf8 Class Initialized
INFO - 2016-02-18 06:37:54 --> URI Class Initialized
INFO - 2016-02-18 06:37:54 --> Router Class Initialized
INFO - 2016-02-18 06:37:54 --> Output Class Initialized
INFO - 2016-02-18 06:37:54 --> Security Class Initialized
DEBUG - 2016-02-18 06:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:37:54 --> Input Class Initialized
INFO - 2016-02-18 06:37:54 --> Language Class Initialized
INFO - 2016-02-18 06:37:54 --> Loader Class Initialized
INFO - 2016-02-18 06:37:54 --> Helper loaded: url_helper
INFO - 2016-02-18 06:37:54 --> Helper loaded: file_helper
INFO - 2016-02-18 06:37:54 --> Helper loaded: date_helper
INFO - 2016-02-18 06:37:54 --> Helper loaded: form_helper
INFO - 2016-02-18 06:37:54 --> Database Driver Class Initialized
INFO - 2016-02-18 06:37:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:37:55 --> Controller Class Initialized
INFO - 2016-02-18 06:37:55 --> Model Class Initialized
INFO - 2016-02-18 06:37:55 --> Model Class Initialized
INFO - 2016-02-18 06:37:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:37:55 --> Pagination Class Initialized
INFO - 2016-02-18 06:37:55 --> Helper loaded: text_helper
INFO - 2016-02-18 06:37:55 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:37:55 --> Form Validation Class Initialized
INFO - 2016-02-18 09:37:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 09:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:37:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_empty_value.php
INFO - 2016-02-18 09:37:55 --> Final output sent to browser
DEBUG - 2016-02-18 09:37:55 --> Total execution time: 1.1577
INFO - 2016-02-18 06:38:34 --> Config Class Initialized
INFO - 2016-02-18 06:38:34 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:38:34 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:38:34 --> Utf8 Class Initialized
INFO - 2016-02-18 06:38:34 --> URI Class Initialized
DEBUG - 2016-02-18 06:38:34 --> No URI present. Default controller set.
INFO - 2016-02-18 06:38:34 --> Router Class Initialized
INFO - 2016-02-18 06:38:34 --> Output Class Initialized
INFO - 2016-02-18 06:38:34 --> Security Class Initialized
DEBUG - 2016-02-18 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:38:34 --> Input Class Initialized
INFO - 2016-02-18 06:38:34 --> Language Class Initialized
INFO - 2016-02-18 06:38:34 --> Loader Class Initialized
INFO - 2016-02-18 06:38:34 --> Helper loaded: url_helper
INFO - 2016-02-18 06:38:34 --> Helper loaded: file_helper
INFO - 2016-02-18 06:38:34 --> Helper loaded: date_helper
INFO - 2016-02-18 06:38:34 --> Helper loaded: form_helper
INFO - 2016-02-18 06:38:34 --> Database Driver Class Initialized
INFO - 2016-02-18 06:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:38:35 --> Controller Class Initialized
INFO - 2016-02-18 06:38:35 --> Model Class Initialized
INFO - 2016-02-18 06:38:36 --> Model Class Initialized
INFO - 2016-02-18 06:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:38:36 --> Pagination Class Initialized
INFO - 2016-02-18 06:38:36 --> Helper loaded: text_helper
INFO - 2016-02-18 06:38:36 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:38:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:38:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:38:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:38:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:38:36 --> Final output sent to browser
DEBUG - 2016-02-18 09:38:36 --> Total execution time: 1.1311
INFO - 2016-02-18 06:41:08 --> Config Class Initialized
INFO - 2016-02-18 06:41:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:08 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:08 --> URI Class Initialized
DEBUG - 2016-02-18 06:41:08 --> No URI present. Default controller set.
INFO - 2016-02-18 06:41:08 --> Router Class Initialized
INFO - 2016-02-18 06:41:08 --> Output Class Initialized
INFO - 2016-02-18 06:41:08 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:08 --> Input Class Initialized
INFO - 2016-02-18 06:41:08 --> Language Class Initialized
INFO - 2016-02-18 06:41:08 --> Loader Class Initialized
INFO - 2016-02-18 06:41:08 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:08 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:08 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:08 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:08 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:09 --> Controller Class Initialized
INFO - 2016-02-18 06:41:09 --> Model Class Initialized
INFO - 2016-02-18 06:41:09 --> Model Class Initialized
INFO - 2016-02-18 06:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:41:09 --> Pagination Class Initialized
INFO - 2016-02-18 06:41:09 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:09 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:41:09 --> Final output sent to browser
DEBUG - 2016-02-18 09:41:09 --> Total execution time: 1.1530
INFO - 2016-02-18 06:41:10 --> Config Class Initialized
INFO - 2016-02-18 06:41:10 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:10 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:10 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:10 --> URI Class Initialized
INFO - 2016-02-18 06:41:10 --> Router Class Initialized
INFO - 2016-02-18 06:41:10 --> Output Class Initialized
INFO - 2016-02-18 06:41:10 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:10 --> Input Class Initialized
INFO - 2016-02-18 06:41:10 --> Language Class Initialized
INFO - 2016-02-18 06:41:10 --> Loader Class Initialized
INFO - 2016-02-18 06:41:10 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:10 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:10 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:10 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:10 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:11 --> Controller Class Initialized
INFO - 2016-02-18 06:41:11 --> Model Class Initialized
INFO - 2016-02-18 06:41:11 --> Model Class Initialized
INFO - 2016-02-18 06:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:41:11 --> Pagination Class Initialized
INFO - 2016-02-18 06:41:11 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:11 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:41:11 --> Final output sent to browser
DEBUG - 2016-02-18 09:41:11 --> Total execution time: 1.1791
INFO - 2016-02-18 06:41:14 --> Config Class Initialized
INFO - 2016-02-18 06:41:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:14 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:14 --> URI Class Initialized
INFO - 2016-02-18 06:41:14 --> Router Class Initialized
INFO - 2016-02-18 06:41:14 --> Output Class Initialized
INFO - 2016-02-18 06:41:14 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:14 --> Input Class Initialized
INFO - 2016-02-18 06:41:14 --> Language Class Initialized
INFO - 2016-02-18 06:41:14 --> Loader Class Initialized
INFO - 2016-02-18 06:41:14 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:14 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:14 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:14 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:14 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:15 --> Controller Class Initialized
INFO - 2016-02-18 06:41:15 --> Model Class Initialized
INFO - 2016-02-18 06:41:15 --> Model Class Initialized
INFO - 2016-02-18 06:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:41:15 --> Pagination Class Initialized
INFO - 2016-02-18 06:41:15 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:15 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:41:16 --> Final output sent to browser
DEBUG - 2016-02-18 09:41:16 --> Total execution time: 1.2067
INFO - 2016-02-18 06:41:21 --> Config Class Initialized
INFO - 2016-02-18 06:41:21 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:21 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:21 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:21 --> URI Class Initialized
INFO - 2016-02-18 06:41:21 --> Router Class Initialized
INFO - 2016-02-18 06:41:21 --> Output Class Initialized
INFO - 2016-02-18 06:41:21 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:21 --> Input Class Initialized
INFO - 2016-02-18 06:41:21 --> Language Class Initialized
INFO - 2016-02-18 06:41:21 --> Loader Class Initialized
INFO - 2016-02-18 06:41:21 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:21 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:21 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:21 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:21 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:22 --> Controller Class Initialized
INFO - 2016-02-18 06:41:22 --> Model Class Initialized
INFO - 2016-02-18 06:41:22 --> Model Class Initialized
INFO - 2016-02-18 06:41:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:41:22 --> Pagination Class Initialized
INFO - 2016-02-18 06:41:22 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:22 --> Helper loaded: cookie_helper
INFO - 2016-02-18 06:41:22 --> Config Class Initialized
INFO - 2016-02-18 06:41:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:22 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:22 --> URI Class Initialized
INFO - 2016-02-18 06:41:22 --> Router Class Initialized
INFO - 2016-02-18 06:41:22 --> Output Class Initialized
INFO - 2016-02-18 06:41:22 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:22 --> Input Class Initialized
INFO - 2016-02-18 06:41:22 --> Language Class Initialized
INFO - 2016-02-18 06:41:22 --> Loader Class Initialized
INFO - 2016-02-18 06:41:22 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:22 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:22 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:22 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:22 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:23 --> Controller Class Initialized
INFO - 2016-02-18 06:41:23 --> Model Class Initialized
INFO - 2016-02-18 06:41:23 --> Model Class Initialized
INFO - 2016-02-18 06:41:23 --> Form Validation Class Initialized
INFO - 2016-02-18 06:41:23 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-18 06:41:23 --> Final output sent to browser
DEBUG - 2016-02-18 06:41:23 --> Total execution time: 1.1304
INFO - 2016-02-18 06:41:30 --> Config Class Initialized
INFO - 2016-02-18 06:41:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:30 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:30 --> URI Class Initialized
INFO - 2016-02-18 06:41:30 --> Router Class Initialized
INFO - 2016-02-18 06:41:30 --> Output Class Initialized
INFO - 2016-02-18 06:41:30 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:30 --> Input Class Initialized
INFO - 2016-02-18 06:41:30 --> Language Class Initialized
INFO - 2016-02-18 06:41:30 --> Loader Class Initialized
INFO - 2016-02-18 06:41:30 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:30 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:30 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:30 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:30 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:31 --> Controller Class Initialized
INFO - 2016-02-18 06:41:31 --> Model Class Initialized
INFO - 2016-02-18 06:41:31 --> Model Class Initialized
INFO - 2016-02-18 06:41:31 --> Form Validation Class Initialized
INFO - 2016-02-18 06:41:31 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:31 --> Final output sent to browser
DEBUG - 2016-02-18 06:41:31 --> Total execution time: 1.1471
INFO - 2016-02-18 06:41:32 --> Config Class Initialized
INFO - 2016-02-18 06:41:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:32 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:32 --> URI Class Initialized
INFO - 2016-02-18 06:41:32 --> Router Class Initialized
INFO - 2016-02-18 06:41:32 --> Output Class Initialized
INFO - 2016-02-18 06:41:32 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:32 --> Input Class Initialized
INFO - 2016-02-18 06:41:32 --> Language Class Initialized
INFO - 2016-02-18 06:41:32 --> Loader Class Initialized
INFO - 2016-02-18 06:41:32 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:32 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:32 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:32 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:32 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:34 --> Controller Class Initialized
INFO - 2016-02-18 06:41:34 --> Model Class Initialized
INFO - 2016-02-18 06:41:34 --> Model Class Initialized
INFO - 2016-02-18 06:41:34 --> Form Validation Class Initialized
INFO - 2016-02-18 06:41:34 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-18 06:41:34 --> Final output sent to browser
DEBUG - 2016-02-18 06:41:34 --> Total execution time: 1.1425
INFO - 2016-02-18 06:41:47 --> Config Class Initialized
INFO - 2016-02-18 06:41:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:41:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:41:47 --> Utf8 Class Initialized
INFO - 2016-02-18 06:41:47 --> URI Class Initialized
DEBUG - 2016-02-18 06:41:47 --> No URI present. Default controller set.
INFO - 2016-02-18 06:41:47 --> Router Class Initialized
INFO - 2016-02-18 06:41:47 --> Output Class Initialized
INFO - 2016-02-18 06:41:47 --> Security Class Initialized
DEBUG - 2016-02-18 06:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:41:47 --> Input Class Initialized
INFO - 2016-02-18 06:41:47 --> Language Class Initialized
INFO - 2016-02-18 06:41:47 --> Loader Class Initialized
INFO - 2016-02-18 06:41:47 --> Helper loaded: url_helper
INFO - 2016-02-18 06:41:47 --> Helper loaded: file_helper
INFO - 2016-02-18 06:41:47 --> Helper loaded: date_helper
INFO - 2016-02-18 06:41:47 --> Helper loaded: form_helper
INFO - 2016-02-18 06:41:47 --> Database Driver Class Initialized
INFO - 2016-02-18 06:41:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:41:48 --> Controller Class Initialized
INFO - 2016-02-18 06:41:48 --> Model Class Initialized
INFO - 2016-02-18 06:41:48 --> Model Class Initialized
INFO - 2016-02-18 06:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:41:48 --> Pagination Class Initialized
INFO - 2016-02-18 06:41:48 --> Helper loaded: text_helper
INFO - 2016-02-18 06:41:48 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:41:48 --> Final output sent to browser
DEBUG - 2016-02-18 09:41:48 --> Total execution time: 1.1689
INFO - 2016-02-18 06:42:05 --> Config Class Initialized
INFO - 2016-02-18 06:42:05 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:42:05 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:42:05 --> Utf8 Class Initialized
INFO - 2016-02-18 06:42:05 --> URI Class Initialized
INFO - 2016-02-18 06:42:05 --> Router Class Initialized
INFO - 2016-02-18 06:42:05 --> Output Class Initialized
INFO - 2016-02-18 06:42:05 --> Security Class Initialized
DEBUG - 2016-02-18 06:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:42:05 --> Input Class Initialized
INFO - 2016-02-18 06:42:05 --> Language Class Initialized
INFO - 2016-02-18 06:42:05 --> Loader Class Initialized
INFO - 2016-02-18 06:42:05 --> Helper loaded: url_helper
INFO - 2016-02-18 06:42:05 --> Helper loaded: file_helper
INFO - 2016-02-18 06:42:05 --> Helper loaded: date_helper
INFO - 2016-02-18 06:42:05 --> Helper loaded: form_helper
INFO - 2016-02-18 06:42:05 --> Database Driver Class Initialized
INFO - 2016-02-18 06:42:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:42:06 --> Controller Class Initialized
INFO - 2016-02-18 06:42:06 --> Model Class Initialized
INFO - 2016-02-18 06:42:06 --> Model Class Initialized
INFO - 2016-02-18 06:42:06 --> Form Validation Class Initialized
INFO - 2016-02-18 06:42:06 --> Helper loaded: text_helper
INFO - 2016-02-18 06:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:42:06 --> Model Class Initialized
INFO - 2016-02-18 06:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:42:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:42:06 --> Final output sent to browser
DEBUG - 2016-02-18 06:42:06 --> Total execution time: 1.1494
INFO - 2016-02-18 06:43:59 --> Config Class Initialized
INFO - 2016-02-18 06:43:59 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:43:59 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:43:59 --> Utf8 Class Initialized
INFO - 2016-02-18 06:43:59 --> URI Class Initialized
DEBUG - 2016-02-18 06:43:59 --> No URI present. Default controller set.
INFO - 2016-02-18 06:43:59 --> Router Class Initialized
INFO - 2016-02-18 06:43:59 --> Output Class Initialized
INFO - 2016-02-18 06:43:59 --> Security Class Initialized
DEBUG - 2016-02-18 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:43:59 --> Input Class Initialized
INFO - 2016-02-18 06:43:59 --> Language Class Initialized
INFO - 2016-02-18 06:43:59 --> Loader Class Initialized
INFO - 2016-02-18 06:43:59 --> Helper loaded: url_helper
INFO - 2016-02-18 06:43:59 --> Helper loaded: file_helper
INFO - 2016-02-18 06:43:59 --> Helper loaded: date_helper
INFO - 2016-02-18 06:43:59 --> Helper loaded: form_helper
INFO - 2016-02-18 06:43:59 --> Database Driver Class Initialized
INFO - 2016-02-18 06:44:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:44:00 --> Controller Class Initialized
INFO - 2016-02-18 06:44:00 --> Model Class Initialized
INFO - 2016-02-18 06:44:00 --> Model Class Initialized
INFO - 2016-02-18 06:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:44:01 --> Pagination Class Initialized
INFO - 2016-02-18 06:44:01 --> Helper loaded: text_helper
INFO - 2016-02-18 06:44:01 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:44:01 --> Final output sent to browser
DEBUG - 2016-02-18 09:44:01 --> Total execution time: 1.1469
INFO - 2016-02-18 06:44:11 --> Config Class Initialized
INFO - 2016-02-18 06:44:11 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:44:11 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:44:11 --> Utf8 Class Initialized
INFO - 2016-02-18 06:44:11 --> URI Class Initialized
INFO - 2016-02-18 06:44:11 --> Router Class Initialized
INFO - 2016-02-18 06:44:11 --> Output Class Initialized
INFO - 2016-02-18 06:44:11 --> Security Class Initialized
DEBUG - 2016-02-18 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:44:11 --> Input Class Initialized
INFO - 2016-02-18 06:44:11 --> Language Class Initialized
INFO - 2016-02-18 06:44:11 --> Loader Class Initialized
INFO - 2016-02-18 06:44:11 --> Helper loaded: url_helper
INFO - 2016-02-18 06:44:11 --> Helper loaded: file_helper
INFO - 2016-02-18 06:44:11 --> Helper loaded: date_helper
INFO - 2016-02-18 06:44:11 --> Helper loaded: form_helper
INFO - 2016-02-18 06:44:11 --> Database Driver Class Initialized
INFO - 2016-02-18 06:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:44:12 --> Controller Class Initialized
INFO - 2016-02-18 06:44:12 --> Model Class Initialized
INFO - 2016-02-18 06:44:13 --> Model Class Initialized
INFO - 2016-02-18 06:44:13 --> Form Validation Class Initialized
INFO - 2016-02-18 06:44:13 --> Helper loaded: text_helper
INFO - 2016-02-18 06:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:44:13 --> Model Class Initialized
INFO - 2016-02-18 06:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:44:13 --> Final output sent to browser
DEBUG - 2016-02-18 06:44:13 --> Total execution time: 1.1498
INFO - 2016-02-18 06:44:17 --> Config Class Initialized
INFO - 2016-02-18 06:44:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:44:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:44:17 --> Utf8 Class Initialized
INFO - 2016-02-18 06:44:17 --> URI Class Initialized
INFO - 2016-02-18 06:44:17 --> Router Class Initialized
INFO - 2016-02-18 06:44:17 --> Output Class Initialized
INFO - 2016-02-18 06:44:17 --> Security Class Initialized
DEBUG - 2016-02-18 06:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:44:17 --> Input Class Initialized
INFO - 2016-02-18 06:44:17 --> Language Class Initialized
INFO - 2016-02-18 06:44:17 --> Loader Class Initialized
INFO - 2016-02-18 06:44:17 --> Helper loaded: url_helper
INFO - 2016-02-18 06:44:17 --> Helper loaded: file_helper
INFO - 2016-02-18 06:44:17 --> Helper loaded: date_helper
INFO - 2016-02-18 06:44:17 --> Helper loaded: form_helper
INFO - 2016-02-18 06:44:17 --> Database Driver Class Initialized
INFO - 2016-02-18 06:44:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:44:18 --> Controller Class Initialized
INFO - 2016-02-18 06:44:18 --> Model Class Initialized
INFO - 2016-02-18 06:44:18 --> Model Class Initialized
INFO - 2016-02-18 06:44:18 --> Form Validation Class Initialized
INFO - 2016-02-18 06:44:18 --> Helper loaded: text_helper
INFO - 2016-02-18 06:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:44:18 --> Model Class Initialized
INFO - 2016-02-18 06:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:44:18 --> Final output sent to browser
DEBUG - 2016-02-18 06:44:18 --> Total execution time: 1.1337
INFO - 2016-02-18 06:49:49 --> Config Class Initialized
INFO - 2016-02-18 06:49:49 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:49:49 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:49:49 --> Utf8 Class Initialized
INFO - 2016-02-18 06:49:49 --> URI Class Initialized
INFO - 2016-02-18 06:49:49 --> Router Class Initialized
INFO - 2016-02-18 06:49:49 --> Output Class Initialized
INFO - 2016-02-18 06:49:49 --> Security Class Initialized
DEBUG - 2016-02-18 06:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:49:49 --> Input Class Initialized
INFO - 2016-02-18 06:49:49 --> Language Class Initialized
INFO - 2016-02-18 06:49:49 --> Loader Class Initialized
INFO - 2016-02-18 06:49:50 --> Helper loaded: url_helper
INFO - 2016-02-18 06:49:50 --> Helper loaded: file_helper
INFO - 2016-02-18 06:49:50 --> Helper loaded: date_helper
INFO - 2016-02-18 06:49:50 --> Helper loaded: form_helper
INFO - 2016-02-18 06:49:50 --> Database Driver Class Initialized
INFO - 2016-02-18 06:49:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:49:51 --> Controller Class Initialized
INFO - 2016-02-18 06:49:51 --> Model Class Initialized
INFO - 2016-02-18 06:49:51 --> Model Class Initialized
INFO - 2016-02-18 06:49:51 --> Form Validation Class Initialized
INFO - 2016-02-18 06:49:51 --> Helper loaded: text_helper
INFO - 2016-02-18 06:49:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 06:49:51 --> Final output sent to browser
DEBUG - 2016-02-18 06:49:51 --> Total execution time: 1.0926
INFO - 2016-02-18 06:50:11 --> Config Class Initialized
INFO - 2016-02-18 06:50:11 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:11 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:11 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:11 --> URI Class Initialized
INFO - 2016-02-18 06:50:11 --> Router Class Initialized
INFO - 2016-02-18 06:50:11 --> Output Class Initialized
INFO - 2016-02-18 06:50:11 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:11 --> Input Class Initialized
INFO - 2016-02-18 06:50:11 --> Language Class Initialized
INFO - 2016-02-18 06:50:11 --> Loader Class Initialized
INFO - 2016-02-18 06:50:11 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:11 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:11 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:11 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:11 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:12 --> Controller Class Initialized
INFO - 2016-02-18 06:50:12 --> Model Class Initialized
INFO - 2016-02-18 06:50:12 --> Model Class Initialized
INFO - 2016-02-18 06:50:12 --> Form Validation Class Initialized
INFO - 2016-02-18 06:50:12 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:50:12 --> Model Class Initialized
INFO - 2016-02-18 06:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:50:12 --> Final output sent to browser
DEBUG - 2016-02-18 06:50:12 --> Total execution time: 1.1488
INFO - 2016-02-18 06:50:25 --> Config Class Initialized
INFO - 2016-02-18 06:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:25 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:25 --> URI Class Initialized
DEBUG - 2016-02-18 06:50:25 --> No URI present. Default controller set.
INFO - 2016-02-18 06:50:25 --> Router Class Initialized
INFO - 2016-02-18 06:50:25 --> Output Class Initialized
INFO - 2016-02-18 06:50:25 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:25 --> Input Class Initialized
INFO - 2016-02-18 06:50:25 --> Language Class Initialized
INFO - 2016-02-18 06:50:25 --> Loader Class Initialized
INFO - 2016-02-18 06:50:25 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:25 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:25 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:25 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:25 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:26 --> Controller Class Initialized
INFO - 2016-02-18 06:50:26 --> Model Class Initialized
INFO - 2016-02-18 06:50:26 --> Model Class Initialized
INFO - 2016-02-18 06:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:50:26 --> Pagination Class Initialized
INFO - 2016-02-18 06:50:26 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:26 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:50:26 --> Final output sent to browser
DEBUG - 2016-02-18 09:50:26 --> Total execution time: 1.1784
INFO - 2016-02-18 06:50:27 --> Config Class Initialized
INFO - 2016-02-18 06:50:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:27 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:27 --> URI Class Initialized
INFO - 2016-02-18 06:50:27 --> Router Class Initialized
INFO - 2016-02-18 06:50:27 --> Output Class Initialized
INFO - 2016-02-18 06:50:27 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:27 --> Input Class Initialized
INFO - 2016-02-18 06:50:27 --> Language Class Initialized
INFO - 2016-02-18 06:50:27 --> Loader Class Initialized
INFO - 2016-02-18 06:50:27 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:27 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:27 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:27 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:28 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:29 --> Controller Class Initialized
INFO - 2016-02-18 06:50:29 --> Model Class Initialized
INFO - 2016-02-18 06:50:29 --> Model Class Initialized
INFO - 2016-02-18 06:50:29 --> Form Validation Class Initialized
INFO - 2016-02-18 06:50:29 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:50:29 --> Model Class Initialized
INFO - 2016-02-18 06:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:50:29 --> Final output sent to browser
DEBUG - 2016-02-18 06:50:29 --> Total execution time: 1.1226
INFO - 2016-02-18 06:50:30 --> Config Class Initialized
INFO - 2016-02-18 06:50:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:30 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:30 --> URI Class Initialized
INFO - 2016-02-18 06:50:30 --> Router Class Initialized
INFO - 2016-02-18 06:50:30 --> Output Class Initialized
INFO - 2016-02-18 06:50:30 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:30 --> Input Class Initialized
INFO - 2016-02-18 06:50:30 --> Language Class Initialized
INFO - 2016-02-18 06:50:30 --> Loader Class Initialized
INFO - 2016-02-18 06:50:30 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:30 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:30 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:30 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:30 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:31 --> Controller Class Initialized
INFO - 2016-02-18 06:50:31 --> Model Class Initialized
INFO - 2016-02-18 06:50:31 --> Model Class Initialized
INFO - 2016-02-18 06:50:31 --> Form Validation Class Initialized
INFO - 2016-02-18 06:50:31 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 06:50:31 --> Final output sent to browser
DEBUG - 2016-02-18 06:50:31 --> Total execution time: 1.0991
INFO - 2016-02-18 06:50:51 --> Config Class Initialized
INFO - 2016-02-18 06:50:51 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:51 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:51 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:51 --> URI Class Initialized
INFO - 2016-02-18 06:50:51 --> Router Class Initialized
INFO - 2016-02-18 06:50:51 --> Output Class Initialized
INFO - 2016-02-18 06:50:51 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:51 --> Input Class Initialized
INFO - 2016-02-18 06:50:51 --> Language Class Initialized
INFO - 2016-02-18 06:50:51 --> Loader Class Initialized
INFO - 2016-02-18 06:50:51 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:51 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:51 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:51 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:51 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:52 --> Controller Class Initialized
INFO - 2016-02-18 06:50:52 --> Model Class Initialized
INFO - 2016-02-18 06:50:52 --> Model Class Initialized
INFO - 2016-02-18 06:50:52 --> Form Validation Class Initialized
INFO - 2016-02-18 06:50:52 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:50:52 --> Model Class Initialized
INFO - 2016-02-18 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:50:52 --> Final output sent to browser
DEBUG - 2016-02-18 06:50:52 --> Total execution time: 1.0960
INFO - 2016-02-18 06:50:54 --> Config Class Initialized
INFO - 2016-02-18 06:50:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:54 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:54 --> URI Class Initialized
DEBUG - 2016-02-18 06:50:54 --> No URI present. Default controller set.
INFO - 2016-02-18 06:50:54 --> Router Class Initialized
INFO - 2016-02-18 06:50:54 --> Output Class Initialized
INFO - 2016-02-18 06:50:54 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:54 --> Input Class Initialized
INFO - 2016-02-18 06:50:54 --> Language Class Initialized
INFO - 2016-02-18 06:50:54 --> Loader Class Initialized
INFO - 2016-02-18 06:50:54 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:54 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:54 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:54 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:54 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:55 --> Controller Class Initialized
INFO - 2016-02-18 06:50:55 --> Model Class Initialized
INFO - 2016-02-18 06:50:55 --> Model Class Initialized
INFO - 2016-02-18 06:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:50:55 --> Pagination Class Initialized
INFO - 2016-02-18 06:50:55 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:55 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:50:55 --> Final output sent to browser
DEBUG - 2016-02-18 09:50:55 --> Total execution time: 1.1439
INFO - 2016-02-18 06:50:56 --> Config Class Initialized
INFO - 2016-02-18 06:50:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:56 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:56 --> URI Class Initialized
INFO - 2016-02-18 06:50:56 --> Router Class Initialized
INFO - 2016-02-18 06:50:56 --> Output Class Initialized
INFO - 2016-02-18 06:50:56 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:56 --> Input Class Initialized
INFO - 2016-02-18 06:50:56 --> Language Class Initialized
INFO - 2016-02-18 06:50:56 --> Loader Class Initialized
INFO - 2016-02-18 06:50:56 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:56 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:56 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:56 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:56 --> Database Driver Class Initialized
INFO - 2016-02-18 06:50:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:50:57 --> Controller Class Initialized
INFO - 2016-02-18 06:50:57 --> Model Class Initialized
INFO - 2016-02-18 06:50:57 --> Model Class Initialized
INFO - 2016-02-18 06:50:57 --> Form Validation Class Initialized
INFO - 2016-02-18 06:50:57 --> Helper loaded: text_helper
INFO - 2016-02-18 06:50:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:50:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:50:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:50:57 --> Model Class Initialized
INFO - 2016-02-18 06:50:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:50:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:50:57 --> Final output sent to browser
DEBUG - 2016-02-18 06:50:57 --> Total execution time: 1.1768
INFO - 2016-02-18 06:50:58 --> Config Class Initialized
INFO - 2016-02-18 06:50:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:50:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:50:58 --> Utf8 Class Initialized
INFO - 2016-02-18 06:50:58 --> URI Class Initialized
INFO - 2016-02-18 06:50:58 --> Router Class Initialized
INFO - 2016-02-18 06:50:58 --> Output Class Initialized
INFO - 2016-02-18 06:50:59 --> Security Class Initialized
DEBUG - 2016-02-18 06:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:50:59 --> Input Class Initialized
INFO - 2016-02-18 06:50:59 --> Language Class Initialized
INFO - 2016-02-18 06:50:59 --> Loader Class Initialized
INFO - 2016-02-18 06:50:59 --> Helper loaded: url_helper
INFO - 2016-02-18 06:50:59 --> Helper loaded: file_helper
INFO - 2016-02-18 06:50:59 --> Helper loaded: date_helper
INFO - 2016-02-18 06:50:59 --> Helper loaded: form_helper
INFO - 2016-02-18 06:50:59 --> Database Driver Class Initialized
INFO - 2016-02-18 06:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:51:00 --> Controller Class Initialized
INFO - 2016-02-18 06:51:00 --> Model Class Initialized
INFO - 2016-02-18 06:51:00 --> Model Class Initialized
INFO - 2016-02-18 06:51:00 --> Form Validation Class Initialized
INFO - 2016-02-18 06:51:00 --> Helper loaded: text_helper
INFO - 2016-02-18 06:51:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 06:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:51:00 --> Final output sent to browser
DEBUG - 2016-02-18 06:51:00 --> Total execution time: 1.1301
INFO - 2016-02-18 06:51:58 --> Config Class Initialized
INFO - 2016-02-18 06:51:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:51:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:51:58 --> Utf8 Class Initialized
INFO - 2016-02-18 06:51:58 --> URI Class Initialized
INFO - 2016-02-18 06:51:58 --> Router Class Initialized
INFO - 2016-02-18 06:51:58 --> Output Class Initialized
INFO - 2016-02-18 06:51:58 --> Security Class Initialized
DEBUG - 2016-02-18 06:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:51:58 --> Input Class Initialized
INFO - 2016-02-18 06:51:58 --> Language Class Initialized
INFO - 2016-02-18 06:51:58 --> Loader Class Initialized
INFO - 2016-02-18 06:51:58 --> Helper loaded: url_helper
INFO - 2016-02-18 06:51:58 --> Helper loaded: file_helper
INFO - 2016-02-18 06:51:58 --> Helper loaded: date_helper
INFO - 2016-02-18 06:51:58 --> Helper loaded: form_helper
INFO - 2016-02-18 06:51:58 --> Database Driver Class Initialized
INFO - 2016-02-18 06:51:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:51:59 --> Controller Class Initialized
INFO - 2016-02-18 06:51:59 --> Model Class Initialized
INFO - 2016-02-18 06:51:59 --> Model Class Initialized
INFO - 2016-02-18 06:51:59 --> Form Validation Class Initialized
INFO - 2016-02-18 06:51:59 --> Helper loaded: text_helper
INFO - 2016-02-18 06:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:51:59 --> Model Class Initialized
INFO - 2016-02-18 06:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:51:59 --> Final output sent to browser
DEBUG - 2016-02-18 06:51:59 --> Total execution time: 1.1621
INFO - 2016-02-18 06:52:01 --> Config Class Initialized
INFO - 2016-02-18 06:52:01 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:01 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:01 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:01 --> URI Class Initialized
DEBUG - 2016-02-18 06:52:01 --> No URI present. Default controller set.
INFO - 2016-02-18 06:52:01 --> Router Class Initialized
INFO - 2016-02-18 06:52:01 --> Output Class Initialized
INFO - 2016-02-18 06:52:01 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:01 --> Input Class Initialized
INFO - 2016-02-18 06:52:01 --> Language Class Initialized
INFO - 2016-02-18 06:52:01 --> Loader Class Initialized
INFO - 2016-02-18 06:52:01 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:01 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:01 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:01 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:01 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:02 --> Controller Class Initialized
INFO - 2016-02-18 06:52:02 --> Model Class Initialized
INFO - 2016-02-18 06:52:02 --> Model Class Initialized
INFO - 2016-02-18 06:52:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:52:02 --> Pagination Class Initialized
INFO - 2016-02-18 06:52:02 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:02 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:52:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:52:02 --> Final output sent to browser
DEBUG - 2016-02-18 09:52:02 --> Total execution time: 1.1413
INFO - 2016-02-18 06:52:03 --> Config Class Initialized
INFO - 2016-02-18 06:52:03 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:03 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:03 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:03 --> URI Class Initialized
INFO - 2016-02-18 06:52:03 --> Router Class Initialized
INFO - 2016-02-18 06:52:03 --> Output Class Initialized
INFO - 2016-02-18 06:52:03 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:03 --> Input Class Initialized
INFO - 2016-02-18 06:52:03 --> Language Class Initialized
INFO - 2016-02-18 06:52:03 --> Loader Class Initialized
INFO - 2016-02-18 06:52:03 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:03 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:03 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:03 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:03 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:04 --> Controller Class Initialized
INFO - 2016-02-18 06:52:04 --> Model Class Initialized
INFO - 2016-02-18 06:52:04 --> Model Class Initialized
INFO - 2016-02-18 06:52:04 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:04 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:52:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:52:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:52:04 --> Model Class Initialized
INFO - 2016-02-18 06:52:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:52:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:52:04 --> Final output sent to browser
DEBUG - 2016-02-18 06:52:04 --> Total execution time: 1.1348
INFO - 2016-02-18 06:52:05 --> Config Class Initialized
INFO - 2016-02-18 06:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:05 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:05 --> URI Class Initialized
INFO - 2016-02-18 06:52:05 --> Router Class Initialized
INFO - 2016-02-18 06:52:05 --> Output Class Initialized
INFO - 2016-02-18 06:52:05 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:05 --> Input Class Initialized
INFO - 2016-02-18 06:52:05 --> Language Class Initialized
INFO - 2016-02-18 06:52:05 --> Loader Class Initialized
INFO - 2016-02-18 06:52:05 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:05 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:05 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:05 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:05 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:06 --> Controller Class Initialized
INFO - 2016-02-18 06:52:06 --> Model Class Initialized
INFO - 2016-02-18 06:52:06 --> Model Class Initialized
INFO - 2016-02-18 06:52:06 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:06 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 06:52:06 --> Config Class Initialized
INFO - 2016-02-18 06:52:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:06 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:06 --> URI Class Initialized
INFO - 2016-02-18 06:52:06 --> Router Class Initialized
INFO - 2016-02-18 06:52:06 --> Output Class Initialized
INFO - 2016-02-18 06:52:06 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:06 --> Input Class Initialized
INFO - 2016-02-18 06:52:06 --> Language Class Initialized
INFO - 2016-02-18 06:52:06 --> Loader Class Initialized
INFO - 2016-02-18 06:52:06 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:06 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:06 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:06 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:06 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:07 --> Controller Class Initialized
INFO - 2016-02-18 06:52:07 --> Model Class Initialized
INFO - 2016-02-18 06:52:07 --> Model Class Initialized
INFO - 2016-02-18 06:52:07 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:07 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:52:07 --> Model Class Initialized
INFO - 2016-02-18 06:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:52:07 --> Final output sent to browser
DEBUG - 2016-02-18 06:52:07 --> Total execution time: 1.1462
INFO - 2016-02-18 06:52:42 --> Config Class Initialized
INFO - 2016-02-18 06:52:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:42 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:42 --> URI Class Initialized
DEBUG - 2016-02-18 06:52:42 --> No URI present. Default controller set.
INFO - 2016-02-18 06:52:42 --> Router Class Initialized
INFO - 2016-02-18 06:52:42 --> Output Class Initialized
INFO - 2016-02-18 06:52:42 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:42 --> Input Class Initialized
INFO - 2016-02-18 06:52:42 --> Language Class Initialized
INFO - 2016-02-18 06:52:42 --> Loader Class Initialized
INFO - 2016-02-18 06:52:42 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:42 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:42 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:42 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:42 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:43 --> Controller Class Initialized
INFO - 2016-02-18 06:52:43 --> Model Class Initialized
INFO - 2016-02-18 06:52:43 --> Model Class Initialized
INFO - 2016-02-18 06:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:52:43 --> Pagination Class Initialized
INFO - 2016-02-18 06:52:43 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:43 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:52:43 --> Final output sent to browser
DEBUG - 2016-02-18 09:52:43 --> Total execution time: 1.1236
INFO - 2016-02-18 06:52:44 --> Config Class Initialized
INFO - 2016-02-18 06:52:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:44 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:44 --> URI Class Initialized
INFO - 2016-02-18 06:52:44 --> Router Class Initialized
INFO - 2016-02-18 06:52:44 --> Output Class Initialized
INFO - 2016-02-18 06:52:44 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:44 --> Input Class Initialized
INFO - 2016-02-18 06:52:44 --> Language Class Initialized
INFO - 2016-02-18 06:52:44 --> Loader Class Initialized
INFO - 2016-02-18 06:52:44 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:44 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:44 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:44 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:44 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:45 --> Controller Class Initialized
INFO - 2016-02-18 06:52:45 --> Model Class Initialized
INFO - 2016-02-18 06:52:45 --> Model Class Initialized
INFO - 2016-02-18 06:52:45 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:45 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:52:45 --> Model Class Initialized
INFO - 2016-02-18 06:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:52:45 --> Final output sent to browser
DEBUG - 2016-02-18 06:52:45 --> Total execution time: 1.1545
INFO - 2016-02-18 06:52:50 --> Config Class Initialized
INFO - 2016-02-18 06:52:50 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:50 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:50 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:50 --> URI Class Initialized
INFO - 2016-02-18 06:52:50 --> Router Class Initialized
INFO - 2016-02-18 06:52:50 --> Output Class Initialized
INFO - 2016-02-18 06:52:50 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:50 --> Input Class Initialized
INFO - 2016-02-18 06:52:50 --> Language Class Initialized
INFO - 2016-02-18 06:52:50 --> Loader Class Initialized
INFO - 2016-02-18 06:52:50 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:50 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:50 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:50 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:50 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:51 --> Controller Class Initialized
INFO - 2016-02-18 06:52:51 --> Model Class Initialized
INFO - 2016-02-18 06:52:51 --> Model Class Initialized
INFO - 2016-02-18 06:52:51 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:51 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 06:52:51 --> Config Class Initialized
INFO - 2016-02-18 06:52:51 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:52:51 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:52:51 --> Utf8 Class Initialized
INFO - 2016-02-18 06:52:51 --> URI Class Initialized
INFO - 2016-02-18 06:52:51 --> Router Class Initialized
INFO - 2016-02-18 06:52:51 --> Output Class Initialized
INFO - 2016-02-18 06:52:51 --> Security Class Initialized
DEBUG - 2016-02-18 06:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:52:51 --> Input Class Initialized
INFO - 2016-02-18 06:52:51 --> Language Class Initialized
INFO - 2016-02-18 06:52:51 --> Loader Class Initialized
INFO - 2016-02-18 06:52:52 --> Helper loaded: url_helper
INFO - 2016-02-18 06:52:52 --> Helper loaded: file_helper
INFO - 2016-02-18 06:52:52 --> Helper loaded: date_helper
INFO - 2016-02-18 06:52:52 --> Helper loaded: form_helper
INFO - 2016-02-18 06:52:52 --> Database Driver Class Initialized
INFO - 2016-02-18 06:52:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:52:53 --> Controller Class Initialized
INFO - 2016-02-18 06:52:53 --> Model Class Initialized
INFO - 2016-02-18 06:52:53 --> Model Class Initialized
INFO - 2016-02-18 06:52:53 --> Form Validation Class Initialized
INFO - 2016-02-18 06:52:53 --> Helper loaded: text_helper
INFO - 2016-02-18 06:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:52:53 --> Model Class Initialized
INFO - 2016-02-18 06:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:52:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:52:53 --> Final output sent to browser
DEBUG - 2016-02-18 06:52:53 --> Total execution time: 1.2100
INFO - 2016-02-18 06:54:21 --> Config Class Initialized
INFO - 2016-02-18 06:54:21 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:54:21 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:54:21 --> Utf8 Class Initialized
INFO - 2016-02-18 06:54:21 --> URI Class Initialized
DEBUG - 2016-02-18 06:54:21 --> No URI present. Default controller set.
INFO - 2016-02-18 06:54:21 --> Router Class Initialized
INFO - 2016-02-18 06:54:21 --> Output Class Initialized
INFO - 2016-02-18 06:54:21 --> Security Class Initialized
DEBUG - 2016-02-18 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:54:21 --> Input Class Initialized
INFO - 2016-02-18 06:54:21 --> Language Class Initialized
INFO - 2016-02-18 06:54:21 --> Loader Class Initialized
INFO - 2016-02-18 06:54:21 --> Helper loaded: url_helper
INFO - 2016-02-18 06:54:21 --> Helper loaded: file_helper
INFO - 2016-02-18 06:54:21 --> Helper loaded: date_helper
INFO - 2016-02-18 06:54:21 --> Helper loaded: form_helper
INFO - 2016-02-18 06:54:21 --> Database Driver Class Initialized
INFO - 2016-02-18 06:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:54:23 --> Controller Class Initialized
INFO - 2016-02-18 06:54:23 --> Model Class Initialized
INFO - 2016-02-18 06:54:23 --> Model Class Initialized
INFO - 2016-02-18 06:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:54:23 --> Pagination Class Initialized
INFO - 2016-02-18 06:54:23 --> Helper loaded: text_helper
INFO - 2016-02-18 06:54:23 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:54:23 --> Final output sent to browser
DEBUG - 2016-02-18 09:54:23 --> Total execution time: 1.1553
INFO - 2016-02-18 06:54:23 --> Config Class Initialized
INFO - 2016-02-18 06:54:23 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:54:23 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:54:23 --> Utf8 Class Initialized
INFO - 2016-02-18 06:54:23 --> URI Class Initialized
INFO - 2016-02-18 06:54:23 --> Router Class Initialized
INFO - 2016-02-18 06:54:23 --> Output Class Initialized
INFO - 2016-02-18 06:54:23 --> Security Class Initialized
DEBUG - 2016-02-18 06:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:54:23 --> Input Class Initialized
INFO - 2016-02-18 06:54:23 --> Language Class Initialized
INFO - 2016-02-18 06:54:23 --> Loader Class Initialized
INFO - 2016-02-18 06:54:23 --> Helper loaded: url_helper
INFO - 2016-02-18 06:54:23 --> Helper loaded: file_helper
INFO - 2016-02-18 06:54:23 --> Helper loaded: date_helper
INFO - 2016-02-18 06:54:23 --> Helper loaded: form_helper
INFO - 2016-02-18 06:54:23 --> Database Driver Class Initialized
INFO - 2016-02-18 06:54:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:54:24 --> Controller Class Initialized
INFO - 2016-02-18 06:54:24 --> Model Class Initialized
INFO - 2016-02-18 06:54:24 --> Model Class Initialized
INFO - 2016-02-18 06:54:24 --> Form Validation Class Initialized
INFO - 2016-02-18 06:54:24 --> Helper loaded: text_helper
INFO - 2016-02-18 06:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:54:24 --> Model Class Initialized
INFO - 2016-02-18 06:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:54:24 --> Final output sent to browser
DEBUG - 2016-02-18 06:54:24 --> Total execution time: 1.1450
INFO - 2016-02-18 06:55:00 --> Config Class Initialized
INFO - 2016-02-18 06:55:00 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:55:00 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:55:00 --> Utf8 Class Initialized
INFO - 2016-02-18 06:55:00 --> URI Class Initialized
INFO - 2016-02-18 06:55:00 --> Router Class Initialized
INFO - 2016-02-18 06:55:00 --> Output Class Initialized
INFO - 2016-02-18 06:55:00 --> Security Class Initialized
DEBUG - 2016-02-18 06:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:55:00 --> Input Class Initialized
INFO - 2016-02-18 06:55:00 --> Language Class Initialized
INFO - 2016-02-18 06:55:00 --> Loader Class Initialized
INFO - 2016-02-18 06:55:00 --> Helper loaded: url_helper
INFO - 2016-02-18 06:55:00 --> Helper loaded: file_helper
INFO - 2016-02-18 06:55:00 --> Helper loaded: date_helper
INFO - 2016-02-18 06:55:00 --> Helper loaded: form_helper
INFO - 2016-02-18 06:55:00 --> Database Driver Class Initialized
INFO - 2016-02-18 06:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:55:01 --> Controller Class Initialized
INFO - 2016-02-18 06:55:01 --> Model Class Initialized
INFO - 2016-02-18 06:55:01 --> Model Class Initialized
INFO - 2016-02-18 06:55:01 --> Form Validation Class Initialized
INFO - 2016-02-18 06:55:01 --> Helper loaded: text_helper
INFO - 2016-02-18 06:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:55:01 --> Model Class Initialized
INFO - 2016-02-18 06:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:55:01 --> Final output sent to browser
DEBUG - 2016-02-18 06:55:01 --> Total execution time: 1.1265
INFO - 2016-02-18 06:55:06 --> Config Class Initialized
INFO - 2016-02-18 06:55:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:55:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:55:06 --> Utf8 Class Initialized
INFO - 2016-02-18 06:55:06 --> URI Class Initialized
INFO - 2016-02-18 06:55:06 --> Router Class Initialized
INFO - 2016-02-18 06:55:06 --> Output Class Initialized
INFO - 2016-02-18 06:55:06 --> Security Class Initialized
DEBUG - 2016-02-18 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:55:06 --> Input Class Initialized
INFO - 2016-02-18 06:55:06 --> Language Class Initialized
INFO - 2016-02-18 06:55:06 --> Loader Class Initialized
INFO - 2016-02-18 06:55:06 --> Helper loaded: url_helper
INFO - 2016-02-18 06:55:06 --> Helper loaded: file_helper
INFO - 2016-02-18 06:55:06 --> Helper loaded: date_helper
INFO - 2016-02-18 06:55:06 --> Helper loaded: form_helper
INFO - 2016-02-18 06:55:06 --> Database Driver Class Initialized
INFO - 2016-02-18 06:55:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:55:07 --> Controller Class Initialized
INFO - 2016-02-18 06:55:07 --> Model Class Initialized
INFO - 2016-02-18 06:55:07 --> Model Class Initialized
INFO - 2016-02-18 06:55:07 --> Form Validation Class Initialized
INFO - 2016-02-18 06:55:07 --> Helper loaded: text_helper
INFO - 2016-02-18 06:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:55:07 --> Model Class Initialized
INFO - 2016-02-18 06:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:55:07 --> Final output sent to browser
DEBUG - 2016-02-18 06:55:07 --> Total execution time: 1.1483
INFO - 2016-02-18 06:55:56 --> Config Class Initialized
INFO - 2016-02-18 06:55:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:55:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:55:56 --> Utf8 Class Initialized
INFO - 2016-02-18 06:55:56 --> URI Class Initialized
DEBUG - 2016-02-18 06:55:56 --> No URI present. Default controller set.
INFO - 2016-02-18 06:55:56 --> Router Class Initialized
INFO - 2016-02-18 06:55:56 --> Output Class Initialized
INFO - 2016-02-18 06:55:56 --> Security Class Initialized
DEBUG - 2016-02-18 06:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:55:56 --> Input Class Initialized
INFO - 2016-02-18 06:55:56 --> Language Class Initialized
INFO - 2016-02-18 06:55:56 --> Loader Class Initialized
INFO - 2016-02-18 06:55:56 --> Helper loaded: url_helper
INFO - 2016-02-18 06:55:56 --> Helper loaded: file_helper
INFO - 2016-02-18 06:55:56 --> Helper loaded: date_helper
INFO - 2016-02-18 06:55:56 --> Helper loaded: form_helper
INFO - 2016-02-18 06:55:56 --> Database Driver Class Initialized
INFO - 2016-02-18 06:55:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:55:57 --> Controller Class Initialized
INFO - 2016-02-18 06:55:57 --> Model Class Initialized
INFO - 2016-02-18 06:55:57 --> Model Class Initialized
INFO - 2016-02-18 06:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:55:57 --> Pagination Class Initialized
INFO - 2016-02-18 06:55:57 --> Helper loaded: text_helper
INFO - 2016-02-18 06:55:57 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:55:57 --> Final output sent to browser
DEBUG - 2016-02-18 09:55:57 --> Total execution time: 1.1514
INFO - 2016-02-18 06:55:59 --> Config Class Initialized
INFO - 2016-02-18 06:55:59 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:55:59 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:55:59 --> Utf8 Class Initialized
INFO - 2016-02-18 06:55:59 --> URI Class Initialized
INFO - 2016-02-18 06:55:59 --> Router Class Initialized
INFO - 2016-02-18 06:55:59 --> Output Class Initialized
INFO - 2016-02-18 06:55:59 --> Security Class Initialized
DEBUG - 2016-02-18 06:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:55:59 --> Input Class Initialized
INFO - 2016-02-18 06:55:59 --> Language Class Initialized
INFO - 2016-02-18 06:55:59 --> Loader Class Initialized
INFO - 2016-02-18 06:55:59 --> Helper loaded: url_helper
INFO - 2016-02-18 06:55:59 --> Helper loaded: file_helper
INFO - 2016-02-18 06:55:59 --> Helper loaded: date_helper
INFO - 2016-02-18 06:55:59 --> Helper loaded: form_helper
INFO - 2016-02-18 06:55:59 --> Database Driver Class Initialized
INFO - 2016-02-18 06:56:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:56:00 --> Controller Class Initialized
INFO - 2016-02-18 06:56:00 --> Model Class Initialized
INFO - 2016-02-18 06:56:00 --> Model Class Initialized
INFO - 2016-02-18 06:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:56:00 --> Pagination Class Initialized
INFO - 2016-02-18 06:56:00 --> Helper loaded: text_helper
INFO - 2016-02-18 06:56:00 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 09:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 09:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:56:00 --> Final output sent to browser
DEBUG - 2016-02-18 09:56:00 --> Total execution time: 1.1679
INFO - 2016-02-18 06:56:06 --> Config Class Initialized
INFO - 2016-02-18 06:56:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:56:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:56:06 --> Utf8 Class Initialized
INFO - 2016-02-18 06:56:06 --> URI Class Initialized
DEBUG - 2016-02-18 06:56:06 --> No URI present. Default controller set.
INFO - 2016-02-18 06:56:06 --> Router Class Initialized
INFO - 2016-02-18 06:56:06 --> Output Class Initialized
INFO - 2016-02-18 06:56:06 --> Security Class Initialized
DEBUG - 2016-02-18 06:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:56:06 --> Input Class Initialized
INFO - 2016-02-18 06:56:06 --> Language Class Initialized
INFO - 2016-02-18 06:56:06 --> Loader Class Initialized
INFO - 2016-02-18 06:56:06 --> Helper loaded: url_helper
INFO - 2016-02-18 06:56:06 --> Helper loaded: file_helper
INFO - 2016-02-18 06:56:06 --> Helper loaded: date_helper
INFO - 2016-02-18 06:56:06 --> Helper loaded: form_helper
INFO - 2016-02-18 06:56:06 --> Database Driver Class Initialized
INFO - 2016-02-18 06:56:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:56:07 --> Controller Class Initialized
INFO - 2016-02-18 06:56:07 --> Model Class Initialized
INFO - 2016-02-18 06:56:07 --> Model Class Initialized
INFO - 2016-02-18 06:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:56:07 --> Pagination Class Initialized
INFO - 2016-02-18 06:56:07 --> Helper loaded: text_helper
INFO - 2016-02-18 06:56:07 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:56:07 --> Final output sent to browser
DEBUG - 2016-02-18 09:56:07 --> Total execution time: 1.2953
INFO - 2016-02-18 06:56:13 --> Config Class Initialized
INFO - 2016-02-18 06:56:13 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:56:13 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:56:13 --> Utf8 Class Initialized
INFO - 2016-02-18 06:56:13 --> URI Class Initialized
INFO - 2016-02-18 06:56:13 --> Router Class Initialized
INFO - 2016-02-18 06:56:13 --> Output Class Initialized
INFO - 2016-02-18 06:56:13 --> Security Class Initialized
DEBUG - 2016-02-18 06:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:56:13 --> Input Class Initialized
INFO - 2016-02-18 06:56:13 --> Language Class Initialized
INFO - 2016-02-18 06:56:13 --> Loader Class Initialized
INFO - 2016-02-18 06:56:13 --> Helper loaded: url_helper
INFO - 2016-02-18 06:56:13 --> Helper loaded: file_helper
INFO - 2016-02-18 06:56:13 --> Helper loaded: date_helper
INFO - 2016-02-18 06:56:13 --> Helper loaded: form_helper
INFO - 2016-02-18 06:56:13 --> Database Driver Class Initialized
INFO - 2016-02-18 06:56:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:56:14 --> Controller Class Initialized
INFO - 2016-02-18 06:56:14 --> Model Class Initialized
INFO - 2016-02-18 06:56:14 --> Model Class Initialized
INFO - 2016-02-18 06:56:14 --> Form Validation Class Initialized
INFO - 2016-02-18 06:56:14 --> Helper loaded: text_helper
INFO - 2016-02-18 06:56:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 06:56:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 06:56:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 06:56:14 --> Model Class Initialized
INFO - 2016-02-18 06:56:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 06:56:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 06:56:14 --> Final output sent to browser
DEBUG - 2016-02-18 06:56:14 --> Total execution time: 1.1233
INFO - 2016-02-18 06:58:19 --> Config Class Initialized
INFO - 2016-02-18 06:58:19 --> Hooks Class Initialized
DEBUG - 2016-02-18 06:58:19 --> UTF-8 Support Enabled
INFO - 2016-02-18 06:58:19 --> Utf8 Class Initialized
INFO - 2016-02-18 06:58:19 --> URI Class Initialized
DEBUG - 2016-02-18 06:58:19 --> No URI present. Default controller set.
INFO - 2016-02-18 06:58:19 --> Router Class Initialized
INFO - 2016-02-18 06:58:19 --> Output Class Initialized
INFO - 2016-02-18 06:58:19 --> Security Class Initialized
DEBUG - 2016-02-18 06:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 06:58:19 --> Input Class Initialized
INFO - 2016-02-18 06:58:19 --> Language Class Initialized
INFO - 2016-02-18 06:58:19 --> Loader Class Initialized
INFO - 2016-02-18 06:58:19 --> Helper loaded: url_helper
INFO - 2016-02-18 06:58:19 --> Helper loaded: file_helper
INFO - 2016-02-18 06:58:19 --> Helper loaded: date_helper
INFO - 2016-02-18 06:58:19 --> Helper loaded: form_helper
INFO - 2016-02-18 06:58:19 --> Database Driver Class Initialized
INFO - 2016-02-18 06:58:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 06:58:20 --> Controller Class Initialized
INFO - 2016-02-18 06:58:20 --> Model Class Initialized
INFO - 2016-02-18 06:58:20 --> Model Class Initialized
INFO - 2016-02-18 06:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 06:58:20 --> Pagination Class Initialized
INFO - 2016-02-18 06:58:20 --> Helper loaded: text_helper
INFO - 2016-02-18 06:58:20 --> Helper loaded: cookie_helper
INFO - 2016-02-18 09:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 09:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 09:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 09:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 09:58:20 --> Final output sent to browser
DEBUG - 2016-02-18 09:58:20 --> Total execution time: 1.0797
INFO - 2016-02-18 07:08:18 --> Config Class Initialized
INFO - 2016-02-18 07:08:18 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:08:18 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:08:18 --> Utf8 Class Initialized
INFO - 2016-02-18 07:08:18 --> URI Class Initialized
INFO - 2016-02-18 07:08:18 --> Router Class Initialized
INFO - 2016-02-18 07:08:18 --> Output Class Initialized
INFO - 2016-02-18 07:08:18 --> Security Class Initialized
DEBUG - 2016-02-18 07:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:08:18 --> Input Class Initialized
INFO - 2016-02-18 07:08:18 --> Language Class Initialized
ERROR - 2016-02-18 07:08:18 --> 404 Page Not Found: Auth/auth
INFO - 2016-02-18 07:09:02 --> Config Class Initialized
INFO - 2016-02-18 07:09:02 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:02 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:02 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:02 --> URI Class Initialized
INFO - 2016-02-18 07:09:02 --> Router Class Initialized
INFO - 2016-02-18 07:09:02 --> Output Class Initialized
INFO - 2016-02-18 07:09:02 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:02 --> Input Class Initialized
INFO - 2016-02-18 07:09:02 --> Language Class Initialized
INFO - 2016-02-18 07:09:02 --> Loader Class Initialized
INFO - 2016-02-18 07:09:02 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:02 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:02 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:02 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:02 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:03 --> Controller Class Initialized
INFO - 2016-02-18 07:09:03 --> Model Class Initialized
INFO - 2016-02-18 07:09:03 --> Model Class Initialized
INFO - 2016-02-18 07:09:03 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:03 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:03 --> Model Class Initialized
INFO - 2016-02-18 07:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:03 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:03 --> Total execution time: 1.1320
INFO - 2016-02-18 07:09:06 --> Config Class Initialized
INFO - 2016-02-18 07:09:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:06 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:06 --> URI Class Initialized
DEBUG - 2016-02-18 07:09:06 --> No URI present. Default controller set.
INFO - 2016-02-18 07:09:06 --> Router Class Initialized
INFO - 2016-02-18 07:09:06 --> Output Class Initialized
INFO - 2016-02-18 07:09:06 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:06 --> Input Class Initialized
INFO - 2016-02-18 07:09:06 --> Language Class Initialized
INFO - 2016-02-18 07:09:06 --> Loader Class Initialized
INFO - 2016-02-18 07:09:06 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:06 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:06 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:06 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:06 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:07 --> Controller Class Initialized
INFO - 2016-02-18 07:09:07 --> Model Class Initialized
INFO - 2016-02-18 07:09:07 --> Model Class Initialized
INFO - 2016-02-18 07:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 07:09:07 --> Pagination Class Initialized
INFO - 2016-02-18 07:09:07 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:07 --> Helper loaded: cookie_helper
INFO - 2016-02-18 10:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 10:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 10:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 10:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 10:09:07 --> Final output sent to browser
DEBUG - 2016-02-18 10:09:07 --> Total execution time: 1.1507
INFO - 2016-02-18 07:09:08 --> Config Class Initialized
INFO - 2016-02-18 07:09:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:08 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:08 --> URI Class Initialized
INFO - 2016-02-18 07:09:08 --> Router Class Initialized
INFO - 2016-02-18 07:09:08 --> Output Class Initialized
INFO - 2016-02-18 07:09:08 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:08 --> Input Class Initialized
INFO - 2016-02-18 07:09:08 --> Language Class Initialized
INFO - 2016-02-18 07:09:08 --> Loader Class Initialized
INFO - 2016-02-18 07:09:08 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:08 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:08 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:08 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:08 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:09 --> Controller Class Initialized
INFO - 2016-02-18 07:09:09 --> Model Class Initialized
INFO - 2016-02-18 07:09:09 --> Model Class Initialized
INFO - 2016-02-18 07:09:09 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:09 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:09 --> Model Class Initialized
INFO - 2016-02-18 07:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:09 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:09 --> Total execution time: 1.1476
INFO - 2016-02-18 07:09:12 --> Config Class Initialized
INFO - 2016-02-18 07:09:12 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:12 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:12 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:12 --> URI Class Initialized
INFO - 2016-02-18 07:09:12 --> Router Class Initialized
INFO - 2016-02-18 07:09:12 --> Output Class Initialized
INFO - 2016-02-18 07:09:12 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:12 --> Input Class Initialized
INFO - 2016-02-18 07:09:12 --> Language Class Initialized
ERROR - 2016-02-18 07:09:12 --> 404 Page Not Found: Auth/auth
INFO - 2016-02-18 07:09:37 --> Config Class Initialized
INFO - 2016-02-18 07:09:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:37 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:37 --> URI Class Initialized
INFO - 2016-02-18 07:09:37 --> Router Class Initialized
INFO - 2016-02-18 07:09:37 --> Output Class Initialized
INFO - 2016-02-18 07:09:37 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:37 --> Input Class Initialized
INFO - 2016-02-18 07:09:37 --> Language Class Initialized
INFO - 2016-02-18 07:09:37 --> Loader Class Initialized
INFO - 2016-02-18 07:09:37 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:37 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:37 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:37 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:37 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:38 --> Controller Class Initialized
INFO - 2016-02-18 07:09:38 --> Model Class Initialized
INFO - 2016-02-18 07:09:38 --> Model Class Initialized
INFO - 2016-02-18 07:09:38 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:38 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:38 --> Model Class Initialized
INFO - 2016-02-18 07:09:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:38 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:38 --> Total execution time: 1.1414
INFO - 2016-02-18 07:09:50 --> Config Class Initialized
INFO - 2016-02-18 07:09:50 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:50 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:50 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:50 --> URI Class Initialized
DEBUG - 2016-02-18 07:09:50 --> No URI present. Default controller set.
INFO - 2016-02-18 07:09:50 --> Router Class Initialized
INFO - 2016-02-18 07:09:50 --> Output Class Initialized
INFO - 2016-02-18 07:09:50 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:50 --> Input Class Initialized
INFO - 2016-02-18 07:09:50 --> Language Class Initialized
INFO - 2016-02-18 07:09:50 --> Loader Class Initialized
INFO - 2016-02-18 07:09:50 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:50 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:50 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:50 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:50 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:51 --> Controller Class Initialized
INFO - 2016-02-18 07:09:51 --> Model Class Initialized
INFO - 2016-02-18 07:09:51 --> Model Class Initialized
INFO - 2016-02-18 07:09:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 07:09:51 --> Pagination Class Initialized
INFO - 2016-02-18 07:09:51 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:51 --> Helper loaded: cookie_helper
INFO - 2016-02-18 10:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 10:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 10:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 10:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 10:09:51 --> Final output sent to browser
DEBUG - 2016-02-18 10:09:51 --> Total execution time: 1.1630
INFO - 2016-02-18 07:09:52 --> Config Class Initialized
INFO - 2016-02-18 07:09:52 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:52 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:52 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:52 --> URI Class Initialized
INFO - 2016-02-18 07:09:52 --> Router Class Initialized
INFO - 2016-02-18 07:09:52 --> Output Class Initialized
INFO - 2016-02-18 07:09:52 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:52 --> Input Class Initialized
INFO - 2016-02-18 07:09:52 --> Language Class Initialized
INFO - 2016-02-18 07:09:52 --> Loader Class Initialized
INFO - 2016-02-18 07:09:52 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:52 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:52 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:52 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:52 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:53 --> Controller Class Initialized
INFO - 2016-02-18 07:09:53 --> Model Class Initialized
INFO - 2016-02-18 07:09:53 --> Model Class Initialized
INFO - 2016-02-18 07:09:53 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:53 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:53 --> Model Class Initialized
INFO - 2016-02-18 07:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:53 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:53 --> Total execution time: 1.1408
INFO - 2016-02-18 07:09:54 --> Config Class Initialized
INFO - 2016-02-18 07:09:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:54 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:54 --> URI Class Initialized
INFO - 2016-02-18 07:09:54 --> Router Class Initialized
INFO - 2016-02-18 07:09:54 --> Output Class Initialized
INFO - 2016-02-18 07:09:54 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:54 --> Input Class Initialized
INFO - 2016-02-18 07:09:54 --> Language Class Initialized
INFO - 2016-02-18 07:09:54 --> Loader Class Initialized
INFO - 2016-02-18 07:09:54 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:54 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:54 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:54 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:54 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:55 --> Controller Class Initialized
INFO - 2016-02-18 07:09:55 --> Model Class Initialized
INFO - 2016-02-18 07:09:55 --> Model Class Initialized
INFO - 2016-02-18 07:09:55 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:55 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:55 --> Model Class Initialized
INFO - 2016-02-18 07:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:55 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:55 --> Total execution time: 1.1427
INFO - 2016-02-18 07:09:56 --> Config Class Initialized
INFO - 2016-02-18 07:09:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:09:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:09:56 --> Utf8 Class Initialized
INFO - 2016-02-18 07:09:56 --> URI Class Initialized
INFO - 2016-02-18 07:09:56 --> Router Class Initialized
INFO - 2016-02-18 07:09:56 --> Output Class Initialized
INFO - 2016-02-18 07:09:56 --> Security Class Initialized
DEBUG - 2016-02-18 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:09:56 --> Input Class Initialized
INFO - 2016-02-18 07:09:56 --> Language Class Initialized
INFO - 2016-02-18 07:09:56 --> Loader Class Initialized
INFO - 2016-02-18 07:09:56 --> Helper loaded: url_helper
INFO - 2016-02-18 07:09:56 --> Helper loaded: file_helper
INFO - 2016-02-18 07:09:56 --> Helper loaded: date_helper
INFO - 2016-02-18 07:09:56 --> Helper loaded: form_helper
INFO - 2016-02-18 07:09:56 --> Database Driver Class Initialized
INFO - 2016-02-18 07:09:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:09:57 --> Controller Class Initialized
INFO - 2016-02-18 07:09:57 --> Model Class Initialized
INFO - 2016-02-18 07:09:57 --> Model Class Initialized
INFO - 2016-02-18 07:09:57 --> Form Validation Class Initialized
INFO - 2016-02-18 07:09:57 --> Helper loaded: text_helper
INFO - 2016-02-18 07:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:09:57 --> Model Class Initialized
INFO - 2016-02-18 07:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:09:57 --> Final output sent to browser
DEBUG - 2016-02-18 07:09:57 --> Total execution time: 1.1228
INFO - 2016-02-18 07:10:17 --> Config Class Initialized
INFO - 2016-02-18 07:10:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:17 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:17 --> URI Class Initialized
DEBUG - 2016-02-18 07:10:17 --> No URI present. Default controller set.
INFO - 2016-02-18 07:10:17 --> Router Class Initialized
INFO - 2016-02-18 07:10:17 --> Output Class Initialized
INFO - 2016-02-18 07:10:17 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:17 --> Input Class Initialized
INFO - 2016-02-18 07:10:17 --> Language Class Initialized
INFO - 2016-02-18 07:10:17 --> Loader Class Initialized
INFO - 2016-02-18 07:10:17 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:17 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:17 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:17 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:17 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:18 --> Controller Class Initialized
INFO - 2016-02-18 07:10:18 --> Model Class Initialized
INFO - 2016-02-18 07:10:18 --> Model Class Initialized
INFO - 2016-02-18 07:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 07:10:18 --> Pagination Class Initialized
INFO - 2016-02-18 07:10:18 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:18 --> Helper loaded: cookie_helper
INFO - 2016-02-18 10:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 10:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 10:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 10:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 10:10:18 --> Final output sent to browser
DEBUG - 2016-02-18 10:10:18 --> Total execution time: 1.1485
INFO - 2016-02-18 07:10:19 --> Config Class Initialized
INFO - 2016-02-18 07:10:19 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:19 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:19 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:19 --> URI Class Initialized
INFO - 2016-02-18 07:10:19 --> Router Class Initialized
INFO - 2016-02-18 07:10:19 --> Output Class Initialized
INFO - 2016-02-18 07:10:19 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:19 --> Input Class Initialized
INFO - 2016-02-18 07:10:19 --> Language Class Initialized
INFO - 2016-02-18 07:10:19 --> Loader Class Initialized
INFO - 2016-02-18 07:10:19 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:19 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:19 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:19 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:19 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:20 --> Controller Class Initialized
INFO - 2016-02-18 07:10:20 --> Model Class Initialized
INFO - 2016-02-18 07:10:20 --> Model Class Initialized
INFO - 2016-02-18 07:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 07:10:20 --> Pagination Class Initialized
INFO - 2016-02-18 07:10:20 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:20 --> Helper loaded: cookie_helper
INFO - 2016-02-18 10:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 10:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 10:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 10:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 10:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 10:10:20 --> Final output sent to browser
DEBUG - 2016-02-18 10:10:20 --> Total execution time: 1.1892
INFO - 2016-02-18 07:10:22 --> Config Class Initialized
INFO - 2016-02-18 07:10:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:22 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:22 --> URI Class Initialized
INFO - 2016-02-18 07:10:22 --> Router Class Initialized
INFO - 2016-02-18 07:10:22 --> Output Class Initialized
INFO - 2016-02-18 07:10:22 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:22 --> Input Class Initialized
INFO - 2016-02-18 07:10:22 --> Language Class Initialized
INFO - 2016-02-18 07:10:22 --> Loader Class Initialized
INFO - 2016-02-18 07:10:22 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:22 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:22 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:22 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:22 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:23 --> Controller Class Initialized
INFO - 2016-02-18 07:10:23 --> Model Class Initialized
INFO - 2016-02-18 07:10:23 --> Model Class Initialized
INFO - 2016-02-18 07:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 07:10:23 --> Pagination Class Initialized
INFO - 2016-02-18 07:10:23 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:23 --> Helper loaded: cookie_helper
INFO - 2016-02-18 10:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 10:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 10:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 10:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 10:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 10:10:23 --> Final output sent to browser
DEBUG - 2016-02-18 10:10:23 --> Total execution time: 1.2025
INFO - 2016-02-18 07:10:24 --> Config Class Initialized
INFO - 2016-02-18 07:10:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:24 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:24 --> URI Class Initialized
INFO - 2016-02-18 07:10:24 --> Router Class Initialized
INFO - 2016-02-18 07:10:24 --> Output Class Initialized
INFO - 2016-02-18 07:10:24 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:24 --> Input Class Initialized
INFO - 2016-02-18 07:10:24 --> Language Class Initialized
INFO - 2016-02-18 07:10:24 --> Loader Class Initialized
INFO - 2016-02-18 07:10:24 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:24 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:24 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:24 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:24 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:25 --> Controller Class Initialized
INFO - 2016-02-18 07:10:25 --> Model Class Initialized
INFO - 2016-02-18 07:10:25 --> Model Class Initialized
INFO - 2016-02-18 07:10:25 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:25 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:10:25 --> Model Class Initialized
INFO - 2016-02-18 07:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:10:25 --> Final output sent to browser
DEBUG - 2016-02-18 07:10:25 --> Total execution time: 1.1346
INFO - 2016-02-18 07:10:26 --> Config Class Initialized
INFO - 2016-02-18 07:10:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:26 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:26 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:26 --> URI Class Initialized
INFO - 2016-02-18 07:10:26 --> Router Class Initialized
INFO - 2016-02-18 07:10:26 --> Output Class Initialized
INFO - 2016-02-18 07:10:26 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:26 --> Input Class Initialized
INFO - 2016-02-18 07:10:26 --> Language Class Initialized
INFO - 2016-02-18 07:10:26 --> Loader Class Initialized
INFO - 2016-02-18 07:10:26 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:26 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:26 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:26 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:26 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:27 --> Controller Class Initialized
INFO - 2016-02-18 07:10:27 --> Model Class Initialized
INFO - 2016-02-18 07:10:27 --> Model Class Initialized
INFO - 2016-02-18 07:10:27 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:27 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:10:27 --> Model Class Initialized
INFO - 2016-02-18 07:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:10:27 --> Final output sent to browser
DEBUG - 2016-02-18 07:10:27 --> Total execution time: 1.1665
INFO - 2016-02-18 07:10:29 --> Config Class Initialized
INFO - 2016-02-18 07:10:29 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:29 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:29 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:29 --> URI Class Initialized
INFO - 2016-02-18 07:10:29 --> Router Class Initialized
INFO - 2016-02-18 07:10:29 --> Output Class Initialized
INFO - 2016-02-18 07:10:29 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:29 --> Input Class Initialized
INFO - 2016-02-18 07:10:29 --> Language Class Initialized
INFO - 2016-02-18 07:10:29 --> Loader Class Initialized
INFO - 2016-02-18 07:10:29 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:29 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:29 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:29 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:29 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:30 --> Controller Class Initialized
INFO - 2016-02-18 07:10:30 --> Model Class Initialized
INFO - 2016-02-18 07:10:30 --> Model Class Initialized
INFO - 2016-02-18 07:10:30 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:30 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:10:30 --> Config Class Initialized
INFO - 2016-02-18 07:10:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:30 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:30 --> URI Class Initialized
INFO - 2016-02-18 07:10:30 --> Router Class Initialized
INFO - 2016-02-18 07:10:30 --> Output Class Initialized
INFO - 2016-02-18 07:10:30 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:30 --> Input Class Initialized
INFO - 2016-02-18 07:10:30 --> Language Class Initialized
INFO - 2016-02-18 07:10:30 --> Loader Class Initialized
INFO - 2016-02-18 07:10:30 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:30 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:30 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:30 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:30 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:31 --> Controller Class Initialized
INFO - 2016-02-18 07:10:31 --> Model Class Initialized
INFO - 2016-02-18 07:10:31 --> Model Class Initialized
INFO - 2016-02-18 07:10:31 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:31 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:10:31 --> Model Class Initialized
INFO - 2016-02-18 07:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:10:31 --> Final output sent to browser
DEBUG - 2016-02-18 07:10:31 --> Total execution time: 1.1485
INFO - 2016-02-18 07:10:41 --> Config Class Initialized
INFO - 2016-02-18 07:10:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:41 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:41 --> URI Class Initialized
INFO - 2016-02-18 07:10:41 --> Router Class Initialized
INFO - 2016-02-18 07:10:41 --> Output Class Initialized
INFO - 2016-02-18 07:10:41 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:41 --> Input Class Initialized
INFO - 2016-02-18 07:10:41 --> Language Class Initialized
INFO - 2016-02-18 07:10:41 --> Loader Class Initialized
INFO - 2016-02-18 07:10:41 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:41 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:41 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:41 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:41 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:42 --> Controller Class Initialized
INFO - 2016-02-18 07:10:42 --> Model Class Initialized
INFO - 2016-02-18 07:10:42 --> Model Class Initialized
INFO - 2016-02-18 07:10:42 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:42 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:10:42 --> Config Class Initialized
INFO - 2016-02-18 07:10:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:10:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:10:42 --> Utf8 Class Initialized
INFO - 2016-02-18 07:10:42 --> URI Class Initialized
INFO - 2016-02-18 07:10:42 --> Router Class Initialized
INFO - 2016-02-18 07:10:42 --> Output Class Initialized
INFO - 2016-02-18 07:10:42 --> Security Class Initialized
DEBUG - 2016-02-18 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:10:42 --> Input Class Initialized
INFO - 2016-02-18 07:10:42 --> Language Class Initialized
INFO - 2016-02-18 07:10:42 --> Loader Class Initialized
INFO - 2016-02-18 07:10:42 --> Helper loaded: url_helper
INFO - 2016-02-18 07:10:42 --> Helper loaded: file_helper
INFO - 2016-02-18 07:10:42 --> Helper loaded: date_helper
INFO - 2016-02-18 07:10:42 --> Helper loaded: form_helper
INFO - 2016-02-18 07:10:42 --> Database Driver Class Initialized
INFO - 2016-02-18 07:10:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:10:43 --> Controller Class Initialized
INFO - 2016-02-18 07:10:43 --> Model Class Initialized
INFO - 2016-02-18 07:10:43 --> Model Class Initialized
INFO - 2016-02-18 07:10:43 --> Form Validation Class Initialized
INFO - 2016-02-18 07:10:43 --> Helper loaded: text_helper
INFO - 2016-02-18 07:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:10:43 --> Model Class Initialized
INFO - 2016-02-18 07:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:10:43 --> Final output sent to browser
DEBUG - 2016-02-18 07:10:43 --> Total execution time: 1.1450
INFO - 2016-02-18 07:14:16 --> Config Class Initialized
INFO - 2016-02-18 07:14:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:14:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:14:16 --> Utf8 Class Initialized
INFO - 2016-02-18 07:14:16 --> URI Class Initialized
INFO - 2016-02-18 07:14:16 --> Router Class Initialized
INFO - 2016-02-18 07:14:16 --> Output Class Initialized
INFO - 2016-02-18 07:14:16 --> Security Class Initialized
DEBUG - 2016-02-18 07:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:14:16 --> Input Class Initialized
INFO - 2016-02-18 07:14:16 --> Language Class Initialized
INFO - 2016-02-18 07:14:16 --> Loader Class Initialized
INFO - 2016-02-18 07:14:16 --> Helper loaded: url_helper
INFO - 2016-02-18 07:14:16 --> Helper loaded: file_helper
INFO - 2016-02-18 07:14:16 --> Helper loaded: date_helper
INFO - 2016-02-18 07:14:16 --> Helper loaded: form_helper
INFO - 2016-02-18 07:14:16 --> Database Driver Class Initialized
INFO - 2016-02-18 07:14:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:14:17 --> Controller Class Initialized
INFO - 2016-02-18 07:14:17 --> Model Class Initialized
INFO - 2016-02-18 07:14:17 --> Model Class Initialized
INFO - 2016-02-18 07:14:17 --> Form Validation Class Initialized
INFO - 2016-02-18 07:14:17 --> Helper loaded: text_helper
INFO - 2016-02-18 07:14:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:14:17 --> Config Class Initialized
INFO - 2016-02-18 07:14:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:14:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:14:17 --> Utf8 Class Initialized
INFO - 2016-02-18 07:14:17 --> URI Class Initialized
INFO - 2016-02-18 07:14:17 --> Router Class Initialized
INFO - 2016-02-18 07:14:17 --> Output Class Initialized
INFO - 2016-02-18 07:14:17 --> Security Class Initialized
DEBUG - 2016-02-18 07:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:14:17 --> Input Class Initialized
INFO - 2016-02-18 07:14:17 --> Language Class Initialized
INFO - 2016-02-18 07:14:17 --> Loader Class Initialized
INFO - 2016-02-18 07:14:17 --> Helper loaded: url_helper
INFO - 2016-02-18 07:14:17 --> Helper loaded: file_helper
INFO - 2016-02-18 07:14:17 --> Helper loaded: date_helper
INFO - 2016-02-18 07:14:17 --> Helper loaded: form_helper
INFO - 2016-02-18 07:14:17 --> Database Driver Class Initialized
INFO - 2016-02-18 07:14:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:14:18 --> Controller Class Initialized
INFO - 2016-02-18 07:14:18 --> Model Class Initialized
INFO - 2016-02-18 07:14:18 --> Model Class Initialized
INFO - 2016-02-18 07:14:18 --> Form Validation Class Initialized
INFO - 2016-02-18 07:14:18 --> Helper loaded: text_helper
INFO - 2016-02-18 07:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:14:18 --> Model Class Initialized
INFO - 2016-02-18 07:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:14:18 --> Final output sent to browser
DEBUG - 2016-02-18 07:14:18 --> Total execution time: 1.1485
INFO - 2016-02-18 07:14:20 --> Config Class Initialized
INFO - 2016-02-18 07:14:20 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:14:20 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:14:20 --> Utf8 Class Initialized
INFO - 2016-02-18 07:14:20 --> URI Class Initialized
INFO - 2016-02-18 07:14:20 --> Router Class Initialized
INFO - 2016-02-18 07:14:20 --> Output Class Initialized
INFO - 2016-02-18 07:14:20 --> Security Class Initialized
DEBUG - 2016-02-18 07:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:14:20 --> Input Class Initialized
INFO - 2016-02-18 07:14:20 --> Language Class Initialized
INFO - 2016-02-18 07:14:20 --> Loader Class Initialized
INFO - 2016-02-18 07:14:20 --> Helper loaded: url_helper
INFO - 2016-02-18 07:14:20 --> Helper loaded: file_helper
INFO - 2016-02-18 07:14:20 --> Helper loaded: date_helper
INFO - 2016-02-18 07:14:20 --> Helper loaded: form_helper
INFO - 2016-02-18 07:14:20 --> Database Driver Class Initialized
INFO - 2016-02-18 07:14:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:14:22 --> Controller Class Initialized
INFO - 2016-02-18 07:14:22 --> Model Class Initialized
INFO - 2016-02-18 07:14:22 --> Model Class Initialized
INFO - 2016-02-18 07:14:22 --> Form Validation Class Initialized
INFO - 2016-02-18 07:14:22 --> Helper loaded: text_helper
INFO - 2016-02-18 07:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:14:22 --> Model Class Initialized
INFO - 2016-02-18 07:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:14:22 --> Final output sent to browser
DEBUG - 2016-02-18 07:14:22 --> Total execution time: 1.1550
INFO - 2016-02-18 07:14:24 --> Config Class Initialized
INFO - 2016-02-18 07:14:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:14:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:14:24 --> Utf8 Class Initialized
INFO - 2016-02-18 07:14:24 --> URI Class Initialized
INFO - 2016-02-18 07:14:24 --> Router Class Initialized
INFO - 2016-02-18 07:14:24 --> Output Class Initialized
INFO - 2016-02-18 07:14:24 --> Security Class Initialized
DEBUG - 2016-02-18 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:14:24 --> Input Class Initialized
INFO - 2016-02-18 07:14:24 --> Language Class Initialized
INFO - 2016-02-18 07:14:24 --> Loader Class Initialized
INFO - 2016-02-18 07:14:24 --> Helper loaded: url_helper
INFO - 2016-02-18 07:14:24 --> Helper loaded: file_helper
INFO - 2016-02-18 07:14:24 --> Helper loaded: date_helper
INFO - 2016-02-18 07:14:24 --> Helper loaded: form_helper
INFO - 2016-02-18 07:14:24 --> Database Driver Class Initialized
INFO - 2016-02-18 07:14:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:14:25 --> Controller Class Initialized
INFO - 2016-02-18 07:14:25 --> Model Class Initialized
INFO - 2016-02-18 07:14:25 --> Model Class Initialized
INFO - 2016-02-18 07:14:25 --> Form Validation Class Initialized
INFO - 2016-02-18 07:14:25 --> Helper loaded: text_helper
INFO - 2016-02-18 07:14:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:14:25 --> Config Class Initialized
INFO - 2016-02-18 07:14:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:14:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:14:25 --> Utf8 Class Initialized
INFO - 2016-02-18 07:14:25 --> URI Class Initialized
INFO - 2016-02-18 07:14:25 --> Router Class Initialized
INFO - 2016-02-18 07:14:25 --> Output Class Initialized
INFO - 2016-02-18 07:14:25 --> Security Class Initialized
DEBUG - 2016-02-18 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:14:25 --> Input Class Initialized
INFO - 2016-02-18 07:14:25 --> Language Class Initialized
INFO - 2016-02-18 07:14:25 --> Loader Class Initialized
INFO - 2016-02-18 07:14:25 --> Helper loaded: url_helper
INFO - 2016-02-18 07:14:25 --> Helper loaded: file_helper
INFO - 2016-02-18 07:14:25 --> Helper loaded: date_helper
INFO - 2016-02-18 07:14:25 --> Helper loaded: form_helper
INFO - 2016-02-18 07:14:25 --> Database Driver Class Initialized
INFO - 2016-02-18 07:14:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:14:26 --> Controller Class Initialized
INFO - 2016-02-18 07:14:26 --> Model Class Initialized
INFO - 2016-02-18 07:14:26 --> Model Class Initialized
INFO - 2016-02-18 07:14:26 --> Form Validation Class Initialized
INFO - 2016-02-18 07:14:26 --> Helper loaded: text_helper
INFO - 2016-02-18 07:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:14:26 --> Model Class Initialized
INFO - 2016-02-18 07:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:14:26 --> Final output sent to browser
DEBUG - 2016-02-18 07:14:26 --> Total execution time: 1.1691
INFO - 2016-02-18 07:15:30 --> Config Class Initialized
INFO - 2016-02-18 07:15:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:15:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:15:30 --> Utf8 Class Initialized
INFO - 2016-02-18 07:15:30 --> URI Class Initialized
INFO - 2016-02-18 07:15:30 --> Router Class Initialized
INFO - 2016-02-18 07:15:30 --> Output Class Initialized
INFO - 2016-02-18 07:15:30 --> Security Class Initialized
DEBUG - 2016-02-18 07:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:15:30 --> Input Class Initialized
INFO - 2016-02-18 07:15:30 --> Language Class Initialized
INFO - 2016-02-18 07:15:30 --> Loader Class Initialized
INFO - 2016-02-18 07:15:30 --> Helper loaded: url_helper
INFO - 2016-02-18 07:15:30 --> Helper loaded: file_helper
INFO - 2016-02-18 07:15:30 --> Helper loaded: date_helper
INFO - 2016-02-18 07:15:30 --> Helper loaded: form_helper
INFO - 2016-02-18 07:15:30 --> Database Driver Class Initialized
INFO - 2016-02-18 07:15:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:15:31 --> Controller Class Initialized
INFO - 2016-02-18 07:15:31 --> Model Class Initialized
INFO - 2016-02-18 07:15:31 --> Model Class Initialized
INFO - 2016-02-18 07:15:31 --> Form Validation Class Initialized
INFO - 2016-02-18 07:15:31 --> Helper loaded: text_helper
INFO - 2016-02-18 07:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:15:31 --> Model Class Initialized
INFO - 2016-02-18 07:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:15:31 --> Final output sent to browser
DEBUG - 2016-02-18 07:15:31 --> Total execution time: 1.1316
INFO - 2016-02-18 07:15:32 --> Config Class Initialized
INFO - 2016-02-18 07:15:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:15:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:15:32 --> Utf8 Class Initialized
INFO - 2016-02-18 07:15:32 --> URI Class Initialized
INFO - 2016-02-18 07:15:32 --> Router Class Initialized
INFO - 2016-02-18 07:15:32 --> Output Class Initialized
INFO - 2016-02-18 07:15:32 --> Security Class Initialized
DEBUG - 2016-02-18 07:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:15:32 --> Input Class Initialized
INFO - 2016-02-18 07:15:32 --> Language Class Initialized
INFO - 2016-02-18 07:15:32 --> Loader Class Initialized
INFO - 2016-02-18 07:15:32 --> Helper loaded: url_helper
INFO - 2016-02-18 07:15:32 --> Helper loaded: file_helper
INFO - 2016-02-18 07:15:32 --> Helper loaded: date_helper
INFO - 2016-02-18 07:15:32 --> Helper loaded: form_helper
INFO - 2016-02-18 07:15:32 --> Database Driver Class Initialized
INFO - 2016-02-18 07:15:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:15:33 --> Controller Class Initialized
INFO - 2016-02-18 07:15:33 --> Model Class Initialized
INFO - 2016-02-18 07:15:33 --> Model Class Initialized
INFO - 2016-02-18 07:15:33 --> Form Validation Class Initialized
INFO - 2016-02-18 07:15:33 --> Helper loaded: text_helper
INFO - 2016-02-18 07:15:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:15:34 --> Config Class Initialized
INFO - 2016-02-18 07:15:34 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:15:34 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:15:34 --> Utf8 Class Initialized
INFO - 2016-02-18 07:15:34 --> URI Class Initialized
INFO - 2016-02-18 07:15:34 --> Router Class Initialized
INFO - 2016-02-18 07:15:34 --> Output Class Initialized
INFO - 2016-02-18 07:15:34 --> Security Class Initialized
DEBUG - 2016-02-18 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:15:34 --> Input Class Initialized
INFO - 2016-02-18 07:15:34 --> Language Class Initialized
INFO - 2016-02-18 07:15:34 --> Loader Class Initialized
INFO - 2016-02-18 07:15:34 --> Helper loaded: url_helper
INFO - 2016-02-18 07:15:34 --> Helper loaded: file_helper
INFO - 2016-02-18 07:15:34 --> Helper loaded: date_helper
INFO - 2016-02-18 07:15:34 --> Helper loaded: form_helper
INFO - 2016-02-18 07:15:34 --> Database Driver Class Initialized
INFO - 2016-02-18 07:15:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:15:35 --> Controller Class Initialized
INFO - 2016-02-18 07:15:35 --> Model Class Initialized
INFO - 2016-02-18 07:15:35 --> Model Class Initialized
INFO - 2016-02-18 07:15:35 --> Form Validation Class Initialized
INFO - 2016-02-18 07:15:35 --> Helper loaded: text_helper
INFO - 2016-02-18 07:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:15:35 --> Model Class Initialized
INFO - 2016-02-18 07:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:15:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:15:35 --> Final output sent to browser
DEBUG - 2016-02-18 07:15:35 --> Total execution time: 1.1729
INFO - 2016-02-18 07:15:44 --> Config Class Initialized
INFO - 2016-02-18 07:15:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:15:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:15:44 --> Utf8 Class Initialized
INFO - 2016-02-18 07:15:44 --> URI Class Initialized
INFO - 2016-02-18 07:15:44 --> Router Class Initialized
INFO - 2016-02-18 07:15:44 --> Output Class Initialized
INFO - 2016-02-18 07:15:44 --> Security Class Initialized
DEBUG - 2016-02-18 07:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:15:44 --> Input Class Initialized
INFO - 2016-02-18 07:15:44 --> Language Class Initialized
INFO - 2016-02-18 07:15:44 --> Loader Class Initialized
INFO - 2016-02-18 07:15:44 --> Helper loaded: url_helper
INFO - 2016-02-18 07:15:44 --> Helper loaded: file_helper
INFO - 2016-02-18 07:15:44 --> Helper loaded: date_helper
INFO - 2016-02-18 07:15:44 --> Helper loaded: form_helper
INFO - 2016-02-18 07:15:44 --> Database Driver Class Initialized
INFO - 2016-02-18 07:15:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:15:45 --> Controller Class Initialized
INFO - 2016-02-18 07:15:45 --> Model Class Initialized
INFO - 2016-02-18 07:15:45 --> Model Class Initialized
INFO - 2016-02-18 07:15:45 --> Form Validation Class Initialized
INFO - 2016-02-18 07:15:45 --> Helper loaded: text_helper
INFO - 2016-02-18 07:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:15:45 --> Model Class Initialized
INFO - 2016-02-18 07:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:15:45 --> Final output sent to browser
DEBUG - 2016-02-18 07:15:45 --> Total execution time: 1.1467
INFO - 2016-02-18 07:15:46 --> Config Class Initialized
INFO - 2016-02-18 07:15:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:15:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:15:46 --> Utf8 Class Initialized
INFO - 2016-02-18 07:15:46 --> URI Class Initialized
INFO - 2016-02-18 07:15:46 --> Router Class Initialized
INFO - 2016-02-18 07:15:46 --> Output Class Initialized
INFO - 2016-02-18 07:15:46 --> Security Class Initialized
DEBUG - 2016-02-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:15:46 --> Input Class Initialized
INFO - 2016-02-18 07:15:46 --> Language Class Initialized
INFO - 2016-02-18 07:15:46 --> Loader Class Initialized
INFO - 2016-02-18 07:15:46 --> Helper loaded: url_helper
INFO - 2016-02-18 07:15:46 --> Helper loaded: file_helper
INFO - 2016-02-18 07:15:46 --> Helper loaded: date_helper
INFO - 2016-02-18 07:15:46 --> Helper loaded: form_helper
INFO - 2016-02-18 07:15:46 --> Database Driver Class Initialized
INFO - 2016-02-18 07:15:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:15:47 --> Controller Class Initialized
INFO - 2016-02-18 07:15:47 --> Model Class Initialized
INFO - 2016-02-18 07:15:47 --> Model Class Initialized
INFO - 2016-02-18 07:15:47 --> Form Validation Class Initialized
INFO - 2016-02-18 07:15:47 --> Helper loaded: text_helper
INFO - 2016-02-18 07:15:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:15:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:15:47 --> Final output sent to browser
DEBUG - 2016-02-18 07:15:47 --> Total execution time: 1.1300
INFO - 2016-02-18 07:16:53 --> Config Class Initialized
INFO - 2016-02-18 07:16:53 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:16:53 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:16:53 --> Utf8 Class Initialized
INFO - 2016-02-18 07:16:53 --> URI Class Initialized
INFO - 2016-02-18 07:16:53 --> Router Class Initialized
INFO - 2016-02-18 07:16:53 --> Output Class Initialized
INFO - 2016-02-18 07:16:53 --> Security Class Initialized
DEBUG - 2016-02-18 07:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:16:53 --> Input Class Initialized
INFO - 2016-02-18 07:16:53 --> Language Class Initialized
INFO - 2016-02-18 07:16:53 --> Loader Class Initialized
INFO - 2016-02-18 07:16:53 --> Helper loaded: url_helper
INFO - 2016-02-18 07:16:53 --> Helper loaded: file_helper
INFO - 2016-02-18 07:16:53 --> Helper loaded: date_helper
INFO - 2016-02-18 07:16:53 --> Helper loaded: form_helper
INFO - 2016-02-18 07:16:53 --> Database Driver Class Initialized
INFO - 2016-02-18 07:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:16:54 --> Controller Class Initialized
INFO - 2016-02-18 07:16:54 --> Model Class Initialized
INFO - 2016-02-18 07:16:54 --> Model Class Initialized
INFO - 2016-02-18 07:16:54 --> Form Validation Class Initialized
INFO - 2016-02-18 07:16:54 --> Helper loaded: text_helper
INFO - 2016-02-18 07:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:16:54 --> Model Class Initialized
INFO - 2016-02-18 07:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:16:54 --> Final output sent to browser
DEBUG - 2016-02-18 07:16:54 --> Total execution time: 1.1448
INFO - 2016-02-18 07:17:00 --> Config Class Initialized
INFO - 2016-02-18 07:17:00 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:17:00 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:17:00 --> Utf8 Class Initialized
INFO - 2016-02-18 07:17:00 --> URI Class Initialized
INFO - 2016-02-18 07:17:00 --> Router Class Initialized
INFO - 2016-02-18 07:17:00 --> Output Class Initialized
INFO - 2016-02-18 07:17:00 --> Security Class Initialized
DEBUG - 2016-02-18 07:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:17:00 --> Input Class Initialized
INFO - 2016-02-18 07:17:00 --> Language Class Initialized
INFO - 2016-02-18 07:17:00 --> Loader Class Initialized
INFO - 2016-02-18 07:17:00 --> Helper loaded: url_helper
INFO - 2016-02-18 07:17:00 --> Helper loaded: file_helper
INFO - 2016-02-18 07:17:00 --> Helper loaded: date_helper
INFO - 2016-02-18 07:17:00 --> Helper loaded: form_helper
INFO - 2016-02-18 07:17:00 --> Database Driver Class Initialized
INFO - 2016-02-18 07:17:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:17:01 --> Controller Class Initialized
INFO - 2016-02-18 07:17:01 --> Model Class Initialized
INFO - 2016-02-18 07:17:01 --> Model Class Initialized
INFO - 2016-02-18 07:17:01 --> Form Validation Class Initialized
INFO - 2016-02-18 07:17:01 --> Helper loaded: text_helper
INFO - 2016-02-18 07:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:17:01 --> Model Class Initialized
INFO - 2016-02-18 07:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:17:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:17:01 --> Final output sent to browser
DEBUG - 2016-02-18 07:17:01 --> Total execution time: 1.1538
INFO - 2016-02-18 07:17:02 --> Config Class Initialized
INFO - 2016-02-18 07:17:02 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:17:02 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:17:02 --> Utf8 Class Initialized
INFO - 2016-02-18 07:17:02 --> URI Class Initialized
INFO - 2016-02-18 07:17:02 --> Router Class Initialized
INFO - 2016-02-18 07:17:02 --> Output Class Initialized
INFO - 2016-02-18 07:17:02 --> Security Class Initialized
DEBUG - 2016-02-18 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:17:02 --> Input Class Initialized
INFO - 2016-02-18 07:17:02 --> Language Class Initialized
INFO - 2016-02-18 07:17:02 --> Loader Class Initialized
INFO - 2016-02-18 07:17:02 --> Helper loaded: url_helper
INFO - 2016-02-18 07:17:02 --> Helper loaded: file_helper
INFO - 2016-02-18 07:17:02 --> Helper loaded: date_helper
INFO - 2016-02-18 07:17:02 --> Helper loaded: form_helper
INFO - 2016-02-18 07:17:02 --> Database Driver Class Initialized
INFO - 2016-02-18 07:17:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:17:03 --> Controller Class Initialized
INFO - 2016-02-18 07:17:03 --> Model Class Initialized
INFO - 2016-02-18 07:17:03 --> Model Class Initialized
INFO - 2016-02-18 07:17:03 --> Form Validation Class Initialized
INFO - 2016-02-18 07:17:03 --> Helper loaded: text_helper
INFO - 2016-02-18 07:17:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:17:03 --> Final output sent to browser
DEBUG - 2016-02-18 07:17:03 --> Total execution time: 1.1508
INFO - 2016-02-18 07:17:39 --> Config Class Initialized
INFO - 2016-02-18 07:17:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:17:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:17:39 --> Utf8 Class Initialized
INFO - 2016-02-18 07:17:39 --> URI Class Initialized
INFO - 2016-02-18 07:17:39 --> Router Class Initialized
INFO - 2016-02-18 07:17:39 --> Output Class Initialized
INFO - 2016-02-18 07:17:39 --> Security Class Initialized
DEBUG - 2016-02-18 07:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:17:39 --> Input Class Initialized
INFO - 2016-02-18 07:17:39 --> Language Class Initialized
INFO - 2016-02-18 07:17:39 --> Loader Class Initialized
INFO - 2016-02-18 07:17:39 --> Helper loaded: url_helper
INFO - 2016-02-18 07:17:39 --> Helper loaded: file_helper
INFO - 2016-02-18 07:17:39 --> Helper loaded: date_helper
INFO - 2016-02-18 07:17:39 --> Helper loaded: form_helper
INFO - 2016-02-18 07:17:39 --> Database Driver Class Initialized
INFO - 2016-02-18 07:17:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:17:40 --> Controller Class Initialized
INFO - 2016-02-18 07:17:40 --> Model Class Initialized
INFO - 2016-02-18 07:17:40 --> Model Class Initialized
INFO - 2016-02-18 07:17:40 --> Form Validation Class Initialized
INFO - 2016-02-18 07:17:40 --> Helper loaded: text_helper
INFO - 2016-02-18 07:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:17:40 --> Model Class Initialized
INFO - 2016-02-18 07:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:17:40 --> Final output sent to browser
DEBUG - 2016-02-18 07:17:40 --> Total execution time: 1.1477
INFO - 2016-02-18 07:17:43 --> Config Class Initialized
INFO - 2016-02-18 07:17:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:17:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:17:43 --> Utf8 Class Initialized
INFO - 2016-02-18 07:17:43 --> URI Class Initialized
INFO - 2016-02-18 07:17:43 --> Router Class Initialized
INFO - 2016-02-18 07:17:43 --> Output Class Initialized
INFO - 2016-02-18 07:17:43 --> Security Class Initialized
DEBUG - 2016-02-18 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:17:43 --> Input Class Initialized
INFO - 2016-02-18 07:17:43 --> Language Class Initialized
INFO - 2016-02-18 07:17:43 --> Loader Class Initialized
INFO - 2016-02-18 07:17:43 --> Helper loaded: url_helper
INFO - 2016-02-18 07:17:43 --> Helper loaded: file_helper
INFO - 2016-02-18 07:17:43 --> Helper loaded: date_helper
INFO - 2016-02-18 07:17:43 --> Helper loaded: form_helper
INFO - 2016-02-18 07:17:43 --> Database Driver Class Initialized
INFO - 2016-02-18 07:17:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:17:44 --> Controller Class Initialized
INFO - 2016-02-18 07:17:44 --> Model Class Initialized
INFO - 2016-02-18 07:17:44 --> Model Class Initialized
INFO - 2016-02-18 07:17:44 --> Form Validation Class Initialized
INFO - 2016-02-18 07:17:44 --> Helper loaded: text_helper
INFO - 2016-02-18 07:17:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:17:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:17:44 --> Final output sent to browser
DEBUG - 2016-02-18 07:17:44 --> Total execution time: 1.1609
INFO - 2016-02-18 07:18:33 --> Config Class Initialized
INFO - 2016-02-18 07:18:33 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:18:33 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:18:33 --> Utf8 Class Initialized
INFO - 2016-02-18 07:18:33 --> URI Class Initialized
INFO - 2016-02-18 07:18:33 --> Router Class Initialized
INFO - 2016-02-18 07:18:33 --> Output Class Initialized
INFO - 2016-02-18 07:18:33 --> Security Class Initialized
DEBUG - 2016-02-18 07:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:18:33 --> Input Class Initialized
INFO - 2016-02-18 07:18:33 --> Language Class Initialized
INFO - 2016-02-18 07:18:33 --> Loader Class Initialized
INFO - 2016-02-18 07:18:33 --> Helper loaded: url_helper
INFO - 2016-02-18 07:18:33 --> Helper loaded: file_helper
INFO - 2016-02-18 07:18:33 --> Helper loaded: date_helper
INFO - 2016-02-18 07:18:33 --> Helper loaded: form_helper
INFO - 2016-02-18 07:18:33 --> Database Driver Class Initialized
INFO - 2016-02-18 07:18:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:18:34 --> Controller Class Initialized
INFO - 2016-02-18 07:18:34 --> Model Class Initialized
INFO - 2016-02-18 07:18:34 --> Model Class Initialized
INFO - 2016-02-18 07:18:34 --> Form Validation Class Initialized
INFO - 2016-02-18 07:18:34 --> Helper loaded: text_helper
INFO - 2016-02-18 07:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:18:34 --> Model Class Initialized
INFO - 2016-02-18 07:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:18:34 --> Final output sent to browser
DEBUG - 2016-02-18 07:18:34 --> Total execution time: 1.1844
INFO - 2016-02-18 07:18:35 --> Config Class Initialized
INFO - 2016-02-18 07:18:35 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:18:35 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:18:35 --> Utf8 Class Initialized
INFO - 2016-02-18 07:18:35 --> URI Class Initialized
INFO - 2016-02-18 07:18:35 --> Router Class Initialized
INFO - 2016-02-18 07:18:35 --> Output Class Initialized
INFO - 2016-02-18 07:18:35 --> Security Class Initialized
DEBUG - 2016-02-18 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:18:35 --> Input Class Initialized
INFO - 2016-02-18 07:18:35 --> Language Class Initialized
INFO - 2016-02-18 07:18:35 --> Loader Class Initialized
INFO - 2016-02-18 07:18:35 --> Helper loaded: url_helper
INFO - 2016-02-18 07:18:35 --> Helper loaded: file_helper
INFO - 2016-02-18 07:18:35 --> Helper loaded: date_helper
INFO - 2016-02-18 07:18:35 --> Helper loaded: form_helper
INFO - 2016-02-18 07:18:35 --> Database Driver Class Initialized
INFO - 2016-02-18 07:18:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:18:36 --> Controller Class Initialized
INFO - 2016-02-18 07:18:36 --> Model Class Initialized
INFO - 2016-02-18 07:18:36 --> Model Class Initialized
INFO - 2016-02-18 07:18:36 --> Form Validation Class Initialized
INFO - 2016-02-18 07:18:36 --> Helper loaded: text_helper
INFO - 2016-02-18 07:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:18:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:18:36 --> Final output sent to browser
DEBUG - 2016-02-18 07:18:36 --> Total execution time: 1.1080
INFO - 2016-02-18 07:18:41 --> Config Class Initialized
INFO - 2016-02-18 07:18:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:18:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:18:41 --> Utf8 Class Initialized
INFO - 2016-02-18 07:18:41 --> URI Class Initialized
INFO - 2016-02-18 07:18:41 --> Router Class Initialized
INFO - 2016-02-18 07:18:41 --> Output Class Initialized
INFO - 2016-02-18 07:18:41 --> Security Class Initialized
DEBUG - 2016-02-18 07:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:18:41 --> Input Class Initialized
INFO - 2016-02-18 07:18:41 --> Language Class Initialized
INFO - 2016-02-18 07:18:41 --> Loader Class Initialized
INFO - 2016-02-18 07:18:41 --> Helper loaded: url_helper
INFO - 2016-02-18 07:18:41 --> Helper loaded: file_helper
INFO - 2016-02-18 07:18:41 --> Helper loaded: date_helper
INFO - 2016-02-18 07:18:41 --> Helper loaded: form_helper
INFO - 2016-02-18 07:18:41 --> Database Driver Class Initialized
INFO - 2016-02-18 07:18:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:18:42 --> Controller Class Initialized
INFO - 2016-02-18 07:18:42 --> Model Class Initialized
INFO - 2016-02-18 07:18:42 --> Model Class Initialized
INFO - 2016-02-18 07:18:42 --> Form Validation Class Initialized
INFO - 2016-02-18 07:18:42 --> Helper loaded: text_helper
INFO - 2016-02-18 07:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:18:42 --> Model Class Initialized
INFO - 2016-02-18 07:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:18:42 --> Final output sent to browser
DEBUG - 2016-02-18 07:18:42 --> Total execution time: 1.1532
INFO - 2016-02-18 07:18:51 --> Config Class Initialized
INFO - 2016-02-18 07:18:51 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:18:51 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:18:51 --> Utf8 Class Initialized
INFO - 2016-02-18 07:18:51 --> URI Class Initialized
INFO - 2016-02-18 07:18:51 --> Router Class Initialized
INFO - 2016-02-18 07:18:51 --> Output Class Initialized
INFO - 2016-02-18 07:18:51 --> Security Class Initialized
DEBUG - 2016-02-18 07:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:18:51 --> Input Class Initialized
INFO - 2016-02-18 07:18:51 --> Language Class Initialized
INFO - 2016-02-18 07:18:51 --> Loader Class Initialized
INFO - 2016-02-18 07:18:51 --> Helper loaded: url_helper
INFO - 2016-02-18 07:18:51 --> Helper loaded: file_helper
INFO - 2016-02-18 07:18:51 --> Helper loaded: date_helper
INFO - 2016-02-18 07:18:51 --> Helper loaded: form_helper
INFO - 2016-02-18 07:18:51 --> Database Driver Class Initialized
INFO - 2016-02-18 07:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:18:52 --> Controller Class Initialized
INFO - 2016-02-18 07:18:52 --> Model Class Initialized
INFO - 2016-02-18 07:18:52 --> Model Class Initialized
INFO - 2016-02-18 07:18:52 --> Form Validation Class Initialized
INFO - 2016-02-18 07:18:52 --> Helper loaded: text_helper
INFO - 2016-02-18 07:18:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:18:52 --> Final output sent to browser
DEBUG - 2016-02-18 07:18:52 --> Total execution time: 1.2251
INFO - 2016-02-18 07:22:43 --> Config Class Initialized
INFO - 2016-02-18 07:22:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:22:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:22:43 --> Utf8 Class Initialized
INFO - 2016-02-18 07:22:43 --> URI Class Initialized
INFO - 2016-02-18 07:22:43 --> Router Class Initialized
INFO - 2016-02-18 07:22:43 --> Output Class Initialized
INFO - 2016-02-18 07:22:43 --> Security Class Initialized
DEBUG - 2016-02-18 07:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:22:43 --> Input Class Initialized
INFO - 2016-02-18 07:22:43 --> Language Class Initialized
INFO - 2016-02-18 07:22:43 --> Loader Class Initialized
INFO - 2016-02-18 07:22:43 --> Helper loaded: url_helper
INFO - 2016-02-18 07:22:43 --> Helper loaded: file_helper
INFO - 2016-02-18 07:22:43 --> Helper loaded: date_helper
INFO - 2016-02-18 07:22:43 --> Helper loaded: form_helper
INFO - 2016-02-18 07:22:43 --> Database Driver Class Initialized
INFO - 2016-02-18 07:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:22:44 --> Controller Class Initialized
INFO - 2016-02-18 07:22:44 --> Model Class Initialized
INFO - 2016-02-18 07:22:44 --> Model Class Initialized
INFO - 2016-02-18 07:22:44 --> Form Validation Class Initialized
INFO - 2016-02-18 07:22:44 --> Helper loaded: text_helper
INFO - 2016-02-18 07:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 07:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 07:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:22:44 --> Model Class Initialized
INFO - 2016-02-18 07:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 07:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 07:22:44 --> Final output sent to browser
DEBUG - 2016-02-18 07:22:44 --> Total execution time: 1.1328
INFO - 2016-02-18 07:22:46 --> Config Class Initialized
INFO - 2016-02-18 07:22:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:22:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:22:46 --> Utf8 Class Initialized
INFO - 2016-02-18 07:22:46 --> URI Class Initialized
INFO - 2016-02-18 07:22:46 --> Router Class Initialized
INFO - 2016-02-18 07:22:46 --> Output Class Initialized
INFO - 2016-02-18 07:22:46 --> Security Class Initialized
DEBUG - 2016-02-18 07:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:22:46 --> Input Class Initialized
INFO - 2016-02-18 07:22:46 --> Language Class Initialized
INFO - 2016-02-18 07:22:46 --> Loader Class Initialized
INFO - 2016-02-18 07:22:46 --> Helper loaded: url_helper
INFO - 2016-02-18 07:22:46 --> Helper loaded: file_helper
INFO - 2016-02-18 07:22:46 --> Helper loaded: date_helper
INFO - 2016-02-18 07:22:46 --> Helper loaded: form_helper
INFO - 2016-02-18 07:22:46 --> Database Driver Class Initialized
INFO - 2016-02-18 07:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:22:47 --> Controller Class Initialized
INFO - 2016-02-18 07:22:47 --> Model Class Initialized
INFO - 2016-02-18 07:22:47 --> Model Class Initialized
INFO - 2016-02-18 07:22:47 --> Form Validation Class Initialized
INFO - 2016-02-18 07:22:47 --> Helper loaded: text_helper
INFO - 2016-02-18 07:22:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:22:47 --> Final output sent to browser
DEBUG - 2016-02-18 07:22:47 --> Total execution time: 1.1189
INFO - 2016-02-18 07:23:08 --> Config Class Initialized
INFO - 2016-02-18 07:23:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:23:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:23:08 --> Utf8 Class Initialized
INFO - 2016-02-18 07:23:08 --> URI Class Initialized
INFO - 2016-02-18 07:23:08 --> Router Class Initialized
INFO - 2016-02-18 07:23:08 --> Output Class Initialized
INFO - 2016-02-18 07:23:08 --> Security Class Initialized
DEBUG - 2016-02-18 07:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:23:08 --> Input Class Initialized
INFO - 2016-02-18 07:23:08 --> Language Class Initialized
INFO - 2016-02-18 07:23:08 --> Loader Class Initialized
INFO - 2016-02-18 07:23:08 --> Helper loaded: url_helper
INFO - 2016-02-18 07:23:08 --> Helper loaded: file_helper
INFO - 2016-02-18 07:23:08 --> Helper loaded: date_helper
INFO - 2016-02-18 07:23:08 --> Helper loaded: form_helper
INFO - 2016-02-18 07:23:09 --> Database Driver Class Initialized
INFO - 2016-02-18 07:23:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:23:10 --> Controller Class Initialized
INFO - 2016-02-18 07:23:10 --> Model Class Initialized
INFO - 2016-02-18 07:23:10 --> Model Class Initialized
INFO - 2016-02-18 07:23:10 --> Form Validation Class Initialized
INFO - 2016-02-18 07:23:10 --> Helper loaded: text_helper
INFO - 2016-02-18 07:23:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:23:10 --> Final output sent to browser
DEBUG - 2016-02-18 07:23:10 --> Total execution time: 1.1334
INFO - 2016-02-18 07:23:19 --> Config Class Initialized
INFO - 2016-02-18 07:23:19 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:23:19 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:23:19 --> Utf8 Class Initialized
INFO - 2016-02-18 07:23:19 --> URI Class Initialized
INFO - 2016-02-18 07:23:19 --> Router Class Initialized
INFO - 2016-02-18 07:23:19 --> Output Class Initialized
INFO - 2016-02-18 07:23:19 --> Security Class Initialized
DEBUG - 2016-02-18 07:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:23:19 --> Input Class Initialized
INFO - 2016-02-18 07:23:19 --> Language Class Initialized
INFO - 2016-02-18 07:23:19 --> Loader Class Initialized
INFO - 2016-02-18 07:23:19 --> Helper loaded: url_helper
INFO - 2016-02-18 07:23:19 --> Helper loaded: file_helper
INFO - 2016-02-18 07:23:19 --> Helper loaded: date_helper
INFO - 2016-02-18 07:23:19 --> Helper loaded: form_helper
INFO - 2016-02-18 07:23:19 --> Database Driver Class Initialized
INFO - 2016-02-18 07:23:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:23:20 --> Controller Class Initialized
INFO - 2016-02-18 07:23:20 --> Model Class Initialized
INFO - 2016-02-18 07:23:20 --> Model Class Initialized
INFO - 2016-02-18 07:23:20 --> Form Validation Class Initialized
INFO - 2016-02-18 07:23:20 --> Helper loaded: text_helper
INFO - 2016-02-18 07:23:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:23:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:23:20 --> Final output sent to browser
DEBUG - 2016-02-18 07:23:20 --> Total execution time: 1.1557
INFO - 2016-02-18 07:23:37 --> Config Class Initialized
INFO - 2016-02-18 07:23:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 07:23:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 07:23:37 --> Utf8 Class Initialized
INFO - 2016-02-18 07:23:37 --> URI Class Initialized
INFO - 2016-02-18 07:23:37 --> Router Class Initialized
INFO - 2016-02-18 07:23:37 --> Output Class Initialized
INFO - 2016-02-18 07:23:37 --> Security Class Initialized
DEBUG - 2016-02-18 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 07:23:38 --> Input Class Initialized
INFO - 2016-02-18 07:23:38 --> Language Class Initialized
INFO - 2016-02-18 07:23:38 --> Loader Class Initialized
INFO - 2016-02-18 07:23:38 --> Helper loaded: url_helper
INFO - 2016-02-18 07:23:38 --> Helper loaded: file_helper
INFO - 2016-02-18 07:23:38 --> Helper loaded: date_helper
INFO - 2016-02-18 07:23:38 --> Helper loaded: form_helper
INFO - 2016-02-18 07:23:38 --> Database Driver Class Initialized
INFO - 2016-02-18 07:23:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 07:23:39 --> Controller Class Initialized
INFO - 2016-02-18 07:23:39 --> Model Class Initialized
INFO - 2016-02-18 07:23:39 --> Model Class Initialized
INFO - 2016-02-18 07:23:39 --> Form Validation Class Initialized
INFO - 2016-02-18 07:23:39 --> Helper loaded: text_helper
INFO - 2016-02-18 07:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 07:23:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 07:23:39 --> Final output sent to browser
DEBUG - 2016-02-18 07:23:39 --> Total execution time: 1.1372
INFO - 2016-02-18 08:06:11 --> Config Class Initialized
INFO - 2016-02-18 08:06:11 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:06:11 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:06:11 --> Utf8 Class Initialized
INFO - 2016-02-18 08:06:11 --> URI Class Initialized
DEBUG - 2016-02-18 08:06:11 --> No URI present. Default controller set.
INFO - 2016-02-18 08:06:11 --> Router Class Initialized
INFO - 2016-02-18 08:06:11 --> Output Class Initialized
INFO - 2016-02-18 08:06:11 --> Security Class Initialized
DEBUG - 2016-02-18 08:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:06:11 --> Input Class Initialized
INFO - 2016-02-18 08:06:11 --> Language Class Initialized
INFO - 2016-02-18 08:06:11 --> Loader Class Initialized
INFO - 2016-02-18 08:06:11 --> Helper loaded: url_helper
INFO - 2016-02-18 08:06:11 --> Helper loaded: file_helper
INFO - 2016-02-18 08:06:11 --> Helper loaded: date_helper
INFO - 2016-02-18 08:06:11 --> Helper loaded: form_helper
INFO - 2016-02-18 08:06:11 --> Database Driver Class Initialized
INFO - 2016-02-18 08:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:06:12 --> Controller Class Initialized
INFO - 2016-02-18 08:06:12 --> Model Class Initialized
INFO - 2016-02-18 08:06:12 --> Model Class Initialized
INFO - 2016-02-18 08:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:06:12 --> Pagination Class Initialized
INFO - 2016-02-18 08:06:12 --> Helper loaded: text_helper
INFO - 2016-02-18 08:06:12 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:06:12 --> Final output sent to browser
DEBUG - 2016-02-18 11:06:12 --> Total execution time: 1.1344
INFO - 2016-02-18 08:06:13 --> Config Class Initialized
INFO - 2016-02-18 08:06:13 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:06:13 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:06:13 --> Utf8 Class Initialized
INFO - 2016-02-18 08:06:13 --> URI Class Initialized
INFO - 2016-02-18 08:06:13 --> Router Class Initialized
INFO - 2016-02-18 08:06:13 --> Output Class Initialized
INFO - 2016-02-18 08:06:13 --> Security Class Initialized
DEBUG - 2016-02-18 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:06:13 --> Input Class Initialized
INFO - 2016-02-18 08:06:13 --> Language Class Initialized
INFO - 2016-02-18 08:06:13 --> Loader Class Initialized
INFO - 2016-02-18 08:06:13 --> Helper loaded: url_helper
INFO - 2016-02-18 08:06:13 --> Helper loaded: file_helper
INFO - 2016-02-18 08:06:13 --> Helper loaded: date_helper
INFO - 2016-02-18 08:06:13 --> Helper loaded: form_helper
INFO - 2016-02-18 08:06:13 --> Database Driver Class Initialized
INFO - 2016-02-18 08:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:06:14 --> Controller Class Initialized
INFO - 2016-02-18 08:06:14 --> Model Class Initialized
INFO - 2016-02-18 08:06:14 --> Model Class Initialized
INFO - 2016-02-18 08:06:14 --> Form Validation Class Initialized
INFO - 2016-02-18 08:06:14 --> Helper loaded: text_helper
INFO - 2016-02-18 08:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:06:14 --> Model Class Initialized
INFO - 2016-02-18 08:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:06:14 --> Final output sent to browser
DEBUG - 2016-02-18 08:06:14 --> Total execution time: 1.1209
INFO - 2016-02-18 08:06:45 --> Config Class Initialized
INFO - 2016-02-18 08:06:45 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:06:45 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:06:45 --> Utf8 Class Initialized
INFO - 2016-02-18 08:06:45 --> URI Class Initialized
INFO - 2016-02-18 08:06:45 --> Router Class Initialized
INFO - 2016-02-18 08:06:45 --> Output Class Initialized
INFO - 2016-02-18 08:06:45 --> Security Class Initialized
DEBUG - 2016-02-18 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:06:45 --> Input Class Initialized
INFO - 2016-02-18 08:06:45 --> Language Class Initialized
INFO - 2016-02-18 08:06:45 --> Loader Class Initialized
INFO - 2016-02-18 08:06:45 --> Helper loaded: url_helper
INFO - 2016-02-18 08:06:45 --> Helper loaded: file_helper
INFO - 2016-02-18 08:06:45 --> Helper loaded: date_helper
INFO - 2016-02-18 08:06:45 --> Helper loaded: form_helper
INFO - 2016-02-18 08:06:45 --> Database Driver Class Initialized
INFO - 2016-02-18 08:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:06:46 --> Controller Class Initialized
INFO - 2016-02-18 08:06:46 --> Model Class Initialized
INFO - 2016-02-18 08:06:46 --> Model Class Initialized
INFO - 2016-02-18 08:06:46 --> Form Validation Class Initialized
INFO - 2016-02-18 08:06:46 --> Helper loaded: text_helper
INFO - 2016-02-18 08:06:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:06:46 --> Final output sent to browser
DEBUG - 2016-02-18 08:06:46 --> Total execution time: 1.1597
INFO - 2016-02-18 08:10:26 --> Config Class Initialized
INFO - 2016-02-18 08:10:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:10:26 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:10:26 --> Utf8 Class Initialized
INFO - 2016-02-18 08:10:26 --> URI Class Initialized
DEBUG - 2016-02-18 08:10:26 --> No URI present. Default controller set.
INFO - 2016-02-18 08:10:26 --> Router Class Initialized
INFO - 2016-02-18 08:10:26 --> Output Class Initialized
INFO - 2016-02-18 08:10:26 --> Security Class Initialized
DEBUG - 2016-02-18 08:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:10:26 --> Input Class Initialized
INFO - 2016-02-18 08:10:26 --> Language Class Initialized
INFO - 2016-02-18 08:10:26 --> Loader Class Initialized
INFO - 2016-02-18 08:10:26 --> Helper loaded: url_helper
INFO - 2016-02-18 08:10:26 --> Helper loaded: file_helper
INFO - 2016-02-18 08:10:26 --> Helper loaded: date_helper
INFO - 2016-02-18 08:10:26 --> Helper loaded: form_helper
INFO - 2016-02-18 08:10:26 --> Database Driver Class Initialized
INFO - 2016-02-18 08:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:10:27 --> Controller Class Initialized
INFO - 2016-02-18 08:10:27 --> Model Class Initialized
INFO - 2016-02-18 08:10:27 --> Model Class Initialized
INFO - 2016-02-18 08:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:10:27 --> Pagination Class Initialized
INFO - 2016-02-18 08:10:27 --> Helper loaded: text_helper
INFO - 2016-02-18 08:10:27 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:10:27 --> Final output sent to browser
DEBUG - 2016-02-18 11:10:27 --> Total execution time: 1.1741
INFO - 2016-02-18 08:10:30 --> Config Class Initialized
INFO - 2016-02-18 08:10:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:10:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:10:30 --> Utf8 Class Initialized
INFO - 2016-02-18 08:10:30 --> URI Class Initialized
INFO - 2016-02-18 08:10:30 --> Router Class Initialized
INFO - 2016-02-18 08:10:30 --> Output Class Initialized
INFO - 2016-02-18 08:10:30 --> Security Class Initialized
DEBUG - 2016-02-18 08:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:10:30 --> Input Class Initialized
INFO - 2016-02-18 08:10:30 --> Language Class Initialized
INFO - 2016-02-18 08:10:30 --> Loader Class Initialized
INFO - 2016-02-18 08:10:30 --> Helper loaded: url_helper
INFO - 2016-02-18 08:10:30 --> Helper loaded: file_helper
INFO - 2016-02-18 08:10:30 --> Helper loaded: date_helper
INFO - 2016-02-18 08:10:30 --> Helper loaded: form_helper
INFO - 2016-02-18 08:10:30 --> Database Driver Class Initialized
INFO - 2016-02-18 08:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:10:31 --> Controller Class Initialized
INFO - 2016-02-18 08:10:31 --> Model Class Initialized
INFO - 2016-02-18 08:10:31 --> Model Class Initialized
INFO - 2016-02-18 08:10:31 --> Form Validation Class Initialized
INFO - 2016-02-18 08:10:31 --> Helper loaded: text_helper
INFO - 2016-02-18 08:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:10:31 --> Model Class Initialized
INFO - 2016-02-18 08:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:10:31 --> Final output sent to browser
DEBUG - 2016-02-18 08:10:31 --> Total execution time: 1.1659
INFO - 2016-02-18 08:10:47 --> Config Class Initialized
INFO - 2016-02-18 08:10:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:10:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:10:47 --> Utf8 Class Initialized
INFO - 2016-02-18 08:10:47 --> URI Class Initialized
INFO - 2016-02-18 08:10:47 --> Router Class Initialized
INFO - 2016-02-18 08:10:47 --> Output Class Initialized
INFO - 2016-02-18 08:10:47 --> Security Class Initialized
DEBUG - 2016-02-18 08:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:10:47 --> Input Class Initialized
INFO - 2016-02-18 08:10:47 --> Language Class Initialized
INFO - 2016-02-18 08:10:47 --> Loader Class Initialized
INFO - 2016-02-18 08:10:47 --> Helper loaded: url_helper
INFO - 2016-02-18 08:10:47 --> Helper loaded: file_helper
INFO - 2016-02-18 08:10:47 --> Helper loaded: date_helper
INFO - 2016-02-18 08:10:47 --> Helper loaded: form_helper
INFO - 2016-02-18 08:10:47 --> Database Driver Class Initialized
INFO - 2016-02-18 08:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:10:48 --> Controller Class Initialized
INFO - 2016-02-18 08:10:48 --> Model Class Initialized
INFO - 2016-02-18 08:10:48 --> Model Class Initialized
INFO - 2016-02-18 08:10:48 --> Form Validation Class Initialized
INFO - 2016-02-18 08:10:48 --> Helper loaded: text_helper
INFO - 2016-02-18 08:10:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:10:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:10:48 --> Final output sent to browser
DEBUG - 2016-02-18 08:10:48 --> Total execution time: 1.1242
INFO - 2016-02-18 08:10:56 --> Config Class Initialized
INFO - 2016-02-18 08:10:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:10:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:10:56 --> Utf8 Class Initialized
INFO - 2016-02-18 08:10:56 --> URI Class Initialized
DEBUG - 2016-02-18 08:10:56 --> No URI present. Default controller set.
INFO - 2016-02-18 08:10:56 --> Router Class Initialized
INFO - 2016-02-18 08:10:56 --> Output Class Initialized
INFO - 2016-02-18 08:10:56 --> Security Class Initialized
DEBUG - 2016-02-18 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:10:56 --> Input Class Initialized
INFO - 2016-02-18 08:10:56 --> Language Class Initialized
INFO - 2016-02-18 08:10:56 --> Loader Class Initialized
INFO - 2016-02-18 08:10:56 --> Helper loaded: url_helper
INFO - 2016-02-18 08:10:56 --> Helper loaded: file_helper
INFO - 2016-02-18 08:10:56 --> Helper loaded: date_helper
INFO - 2016-02-18 08:10:56 --> Helper loaded: form_helper
INFO - 2016-02-18 08:10:56 --> Database Driver Class Initialized
INFO - 2016-02-18 08:10:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:10:57 --> Controller Class Initialized
INFO - 2016-02-18 08:10:57 --> Model Class Initialized
INFO - 2016-02-18 08:10:57 --> Model Class Initialized
INFO - 2016-02-18 08:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:10:57 --> Pagination Class Initialized
INFO - 2016-02-18 08:10:57 --> Helper loaded: text_helper
INFO - 2016-02-18 08:10:57 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:10:57 --> Final output sent to browser
DEBUG - 2016-02-18 11:10:57 --> Total execution time: 1.1208
INFO - 2016-02-18 08:12:17 --> Config Class Initialized
INFO - 2016-02-18 08:12:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:12:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:12:17 --> Utf8 Class Initialized
INFO - 2016-02-18 08:12:17 --> URI Class Initialized
INFO - 2016-02-18 08:12:17 --> Router Class Initialized
INFO - 2016-02-18 08:12:17 --> Output Class Initialized
INFO - 2016-02-18 08:12:17 --> Security Class Initialized
DEBUG - 2016-02-18 08:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:12:17 --> Input Class Initialized
INFO - 2016-02-18 08:12:17 --> Language Class Initialized
INFO - 2016-02-18 08:12:17 --> Loader Class Initialized
INFO - 2016-02-18 08:12:17 --> Helper loaded: url_helper
INFO - 2016-02-18 08:12:17 --> Helper loaded: file_helper
INFO - 2016-02-18 08:12:17 --> Helper loaded: date_helper
INFO - 2016-02-18 08:12:17 --> Helper loaded: form_helper
INFO - 2016-02-18 08:12:17 --> Database Driver Class Initialized
INFO - 2016-02-18 08:12:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:12:18 --> Controller Class Initialized
INFO - 2016-02-18 08:12:18 --> Model Class Initialized
INFO - 2016-02-18 08:12:18 --> Model Class Initialized
INFO - 2016-02-18 08:12:18 --> Form Validation Class Initialized
INFO - 2016-02-18 08:12:18 --> Helper loaded: text_helper
INFO - 2016-02-18 08:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:12:18 --> Model Class Initialized
INFO - 2016-02-18 08:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:12:18 --> Final output sent to browser
DEBUG - 2016-02-18 08:12:18 --> Total execution time: 1.1571
INFO - 2016-02-18 08:12:37 --> Config Class Initialized
INFO - 2016-02-18 08:12:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:12:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:12:37 --> Utf8 Class Initialized
INFO - 2016-02-18 08:12:37 --> URI Class Initialized
INFO - 2016-02-18 08:12:37 --> Router Class Initialized
INFO - 2016-02-18 08:12:37 --> Output Class Initialized
INFO - 2016-02-18 08:12:37 --> Security Class Initialized
DEBUG - 2016-02-18 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:12:37 --> Input Class Initialized
INFO - 2016-02-18 08:12:37 --> Language Class Initialized
INFO - 2016-02-18 08:12:37 --> Loader Class Initialized
INFO - 2016-02-18 08:12:37 --> Helper loaded: url_helper
INFO - 2016-02-18 08:12:37 --> Helper loaded: file_helper
INFO - 2016-02-18 08:12:37 --> Helper loaded: date_helper
INFO - 2016-02-18 08:12:37 --> Helper loaded: form_helper
INFO - 2016-02-18 08:12:37 --> Database Driver Class Initialized
INFO - 2016-02-18 08:12:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:12:38 --> Controller Class Initialized
INFO - 2016-02-18 08:12:38 --> Model Class Initialized
INFO - 2016-02-18 08:12:38 --> Model Class Initialized
INFO - 2016-02-18 08:12:38 --> Form Validation Class Initialized
INFO - 2016-02-18 08:12:38 --> Helper loaded: text_helper
INFO - 2016-02-18 08:12:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:12:38 --> Config Class Initialized
INFO - 2016-02-18 08:12:38 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:12:38 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:12:38 --> Utf8 Class Initialized
INFO - 2016-02-18 08:12:38 --> URI Class Initialized
INFO - 2016-02-18 08:12:38 --> Router Class Initialized
INFO - 2016-02-18 08:12:38 --> Output Class Initialized
INFO - 2016-02-18 08:12:38 --> Security Class Initialized
DEBUG - 2016-02-18 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:12:38 --> Input Class Initialized
INFO - 2016-02-18 08:12:38 --> Language Class Initialized
INFO - 2016-02-18 08:12:38 --> Loader Class Initialized
INFO - 2016-02-18 08:12:38 --> Helper loaded: url_helper
INFO - 2016-02-18 08:12:38 --> Helper loaded: file_helper
INFO - 2016-02-18 08:12:38 --> Helper loaded: date_helper
INFO - 2016-02-18 08:12:38 --> Helper loaded: form_helper
INFO - 2016-02-18 08:12:38 --> Database Driver Class Initialized
INFO - 2016-02-18 08:12:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:12:39 --> Controller Class Initialized
INFO - 2016-02-18 08:12:39 --> Model Class Initialized
INFO - 2016-02-18 08:12:39 --> Model Class Initialized
INFO - 2016-02-18 08:12:39 --> Form Validation Class Initialized
INFO - 2016-02-18 08:12:39 --> Helper loaded: text_helper
INFO - 2016-02-18 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-18 08:12:39 --> Final output sent to browser
DEBUG - 2016-02-18 08:12:39 --> Total execution time: 1.1600
INFO - 2016-02-18 08:13:33 --> Config Class Initialized
INFO - 2016-02-18 08:13:33 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:13:33 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:13:33 --> Utf8 Class Initialized
INFO - 2016-02-18 08:13:33 --> URI Class Initialized
DEBUG - 2016-02-18 08:13:33 --> No URI present. Default controller set.
INFO - 2016-02-18 08:13:33 --> Router Class Initialized
INFO - 2016-02-18 08:13:33 --> Output Class Initialized
INFO - 2016-02-18 08:13:33 --> Security Class Initialized
DEBUG - 2016-02-18 08:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:13:33 --> Input Class Initialized
INFO - 2016-02-18 08:13:33 --> Language Class Initialized
INFO - 2016-02-18 08:13:33 --> Loader Class Initialized
INFO - 2016-02-18 08:13:33 --> Helper loaded: url_helper
INFO - 2016-02-18 08:13:33 --> Helper loaded: file_helper
INFO - 2016-02-18 08:13:33 --> Helper loaded: date_helper
INFO - 2016-02-18 08:13:33 --> Helper loaded: form_helper
INFO - 2016-02-18 08:13:33 --> Database Driver Class Initialized
INFO - 2016-02-18 08:13:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:13:34 --> Controller Class Initialized
INFO - 2016-02-18 08:13:34 --> Model Class Initialized
INFO - 2016-02-18 08:13:34 --> Model Class Initialized
INFO - 2016-02-18 08:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:13:34 --> Pagination Class Initialized
INFO - 2016-02-18 08:13:34 --> Helper loaded: text_helper
INFO - 2016-02-18 08:13:35 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:13:35 --> Final output sent to browser
DEBUG - 2016-02-18 11:13:35 --> Total execution time: 1.1385
INFO - 2016-02-18 08:13:35 --> Config Class Initialized
INFO - 2016-02-18 08:13:35 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:13:35 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:13:35 --> Utf8 Class Initialized
INFO - 2016-02-18 08:13:35 --> URI Class Initialized
INFO - 2016-02-18 08:13:35 --> Router Class Initialized
INFO - 2016-02-18 08:13:35 --> Output Class Initialized
INFO - 2016-02-18 08:13:35 --> Security Class Initialized
DEBUG - 2016-02-18 08:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:13:35 --> Input Class Initialized
INFO - 2016-02-18 08:13:35 --> Language Class Initialized
INFO - 2016-02-18 08:13:35 --> Loader Class Initialized
INFO - 2016-02-18 08:13:35 --> Helper loaded: url_helper
INFO - 2016-02-18 08:13:35 --> Helper loaded: file_helper
INFO - 2016-02-18 08:13:35 --> Helper loaded: date_helper
INFO - 2016-02-18 08:13:35 --> Helper loaded: form_helper
INFO - 2016-02-18 08:13:35 --> Database Driver Class Initialized
INFO - 2016-02-18 08:13:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:13:37 --> Controller Class Initialized
INFO - 2016-02-18 08:13:37 --> Model Class Initialized
INFO - 2016-02-18 08:13:37 --> Model Class Initialized
INFO - 2016-02-18 08:13:37 --> Form Validation Class Initialized
INFO - 2016-02-18 08:13:37 --> Helper loaded: text_helper
INFO - 2016-02-18 08:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:13:37 --> Model Class Initialized
INFO - 2016-02-18 08:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:13:37 --> Final output sent to browser
DEBUG - 2016-02-18 08:13:37 --> Total execution time: 1.1644
INFO - 2016-02-18 08:13:52 --> Config Class Initialized
INFO - 2016-02-18 08:13:52 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:13:52 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:13:52 --> Utf8 Class Initialized
INFO - 2016-02-18 08:13:52 --> URI Class Initialized
INFO - 2016-02-18 08:13:52 --> Router Class Initialized
INFO - 2016-02-18 08:13:52 --> Output Class Initialized
INFO - 2016-02-18 08:13:52 --> Security Class Initialized
DEBUG - 2016-02-18 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:13:52 --> Input Class Initialized
INFO - 2016-02-18 08:13:52 --> Language Class Initialized
INFO - 2016-02-18 08:13:52 --> Loader Class Initialized
INFO - 2016-02-18 08:13:52 --> Helper loaded: url_helper
INFO - 2016-02-18 08:13:52 --> Helper loaded: file_helper
INFO - 2016-02-18 08:13:52 --> Helper loaded: date_helper
INFO - 2016-02-18 08:13:52 --> Helper loaded: form_helper
INFO - 2016-02-18 08:13:52 --> Database Driver Class Initialized
INFO - 2016-02-18 08:13:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:13:53 --> Controller Class Initialized
INFO - 2016-02-18 08:13:53 --> Model Class Initialized
INFO - 2016-02-18 08:13:53 --> Model Class Initialized
INFO - 2016-02-18 08:13:53 --> Form Validation Class Initialized
INFO - 2016-02-18 08:13:53 --> Helper loaded: text_helper
INFO - 2016-02-18 08:13:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-18 08:13:54 --> Query error: Duplicate entry 'gom3572@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('babara@hotmail.com', 'gom3572@hotmail.com', '$2y$10$XgeuqSIwqfBoA2OEVjJVluJHI1Eu13gBSVEzKnheMUH02nZQKMmEq', NOW())
INFO - 2016-02-18 08:13:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-18 08:15:05 --> Config Class Initialized
INFO - 2016-02-18 08:15:05 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:15:05 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:15:05 --> Utf8 Class Initialized
INFO - 2016-02-18 08:15:05 --> URI Class Initialized
INFO - 2016-02-18 08:15:05 --> Router Class Initialized
INFO - 2016-02-18 08:15:05 --> Output Class Initialized
INFO - 2016-02-18 08:15:05 --> Security Class Initialized
DEBUG - 2016-02-18 08:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:15:05 --> Input Class Initialized
INFO - 2016-02-18 08:15:05 --> Language Class Initialized
INFO - 2016-02-18 08:15:05 --> Loader Class Initialized
INFO - 2016-02-18 08:15:05 --> Helper loaded: url_helper
INFO - 2016-02-18 08:15:05 --> Helper loaded: file_helper
INFO - 2016-02-18 08:15:05 --> Helper loaded: date_helper
INFO - 2016-02-18 08:15:05 --> Helper loaded: form_helper
INFO - 2016-02-18 08:15:05 --> Database Driver Class Initialized
INFO - 2016-02-18 08:15:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:15:06 --> Controller Class Initialized
INFO - 2016-02-18 08:15:06 --> Model Class Initialized
INFO - 2016-02-18 08:15:06 --> Model Class Initialized
INFO - 2016-02-18 08:15:06 --> Form Validation Class Initialized
INFO - 2016-02-18 08:15:07 --> Helper loaded: text_helper
INFO - 2016-02-18 08:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:15:07 --> Model Class Initialized
INFO - 2016-02-18 08:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:15:07 --> Final output sent to browser
DEBUG - 2016-02-18 08:15:07 --> Total execution time: 1.1303
INFO - 2016-02-18 08:15:16 --> Config Class Initialized
INFO - 2016-02-18 08:15:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:15:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:15:16 --> Utf8 Class Initialized
INFO - 2016-02-18 08:15:16 --> URI Class Initialized
INFO - 2016-02-18 08:15:16 --> Router Class Initialized
INFO - 2016-02-18 08:15:16 --> Output Class Initialized
INFO - 2016-02-18 08:15:16 --> Security Class Initialized
DEBUG - 2016-02-18 08:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:15:16 --> Input Class Initialized
INFO - 2016-02-18 08:15:16 --> Language Class Initialized
INFO - 2016-02-18 08:15:16 --> Loader Class Initialized
INFO - 2016-02-18 08:15:16 --> Helper loaded: url_helper
INFO - 2016-02-18 08:15:16 --> Helper loaded: file_helper
INFO - 2016-02-18 08:15:16 --> Helper loaded: date_helper
INFO - 2016-02-18 08:15:16 --> Helper loaded: form_helper
INFO - 2016-02-18 08:15:16 --> Database Driver Class Initialized
INFO - 2016-02-18 08:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:15:17 --> Controller Class Initialized
INFO - 2016-02-18 08:15:17 --> Model Class Initialized
INFO - 2016-02-18 08:15:17 --> Model Class Initialized
INFO - 2016-02-18 08:15:17 --> Form Validation Class Initialized
INFO - 2016-02-18 08:15:17 --> Helper loaded: text_helper
INFO - 2016-02-18 08:15:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-18 08:15:18 --> Query error: Duplicate entry 'gom3572@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('babara@hotmail.com', 'gom3572@hotmail.com', '$2y$10$5tAEhtDy0TOXa7gP9cdZfeDZJTpTn.ocIYu6kdZHElVBh.iIE9Rky', NOW())
INFO - 2016-02-18 08:15:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-18 08:17:33 --> Config Class Initialized
INFO - 2016-02-18 08:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:17:33 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:17:33 --> Utf8 Class Initialized
INFO - 2016-02-18 08:17:33 --> URI Class Initialized
INFO - 2016-02-18 08:17:33 --> Router Class Initialized
INFO - 2016-02-18 08:17:33 --> Output Class Initialized
INFO - 2016-02-18 08:17:33 --> Security Class Initialized
DEBUG - 2016-02-18 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:17:33 --> Input Class Initialized
INFO - 2016-02-18 08:17:33 --> Language Class Initialized
INFO - 2016-02-18 08:17:33 --> Loader Class Initialized
INFO - 2016-02-18 08:17:33 --> Helper loaded: url_helper
INFO - 2016-02-18 08:17:33 --> Helper loaded: file_helper
INFO - 2016-02-18 08:17:33 --> Helper loaded: date_helper
INFO - 2016-02-18 08:17:33 --> Helper loaded: form_helper
INFO - 2016-02-18 08:17:33 --> Database Driver Class Initialized
INFO - 2016-02-18 08:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:17:34 --> Controller Class Initialized
INFO - 2016-02-18 08:17:34 --> Model Class Initialized
INFO - 2016-02-18 08:17:34 --> Model Class Initialized
INFO - 2016-02-18 08:17:34 --> Form Validation Class Initialized
INFO - 2016-02-18 08:17:34 --> Helper loaded: text_helper
INFO - 2016-02-18 08:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:17:34 --> Model Class Initialized
INFO - 2016-02-18 08:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:17:34 --> Final output sent to browser
DEBUG - 2016-02-18 08:17:34 --> Total execution time: 1.1280
INFO - 2016-02-18 08:18:50 --> Config Class Initialized
INFO - 2016-02-18 08:18:50 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:18:50 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:18:50 --> Utf8 Class Initialized
INFO - 2016-02-18 08:18:50 --> URI Class Initialized
DEBUG - 2016-02-18 08:18:50 --> No URI present. Default controller set.
INFO - 2016-02-18 08:18:50 --> Router Class Initialized
INFO - 2016-02-18 08:18:50 --> Output Class Initialized
INFO - 2016-02-18 08:18:50 --> Security Class Initialized
DEBUG - 2016-02-18 08:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:18:50 --> Input Class Initialized
INFO - 2016-02-18 08:18:50 --> Language Class Initialized
INFO - 2016-02-18 08:18:50 --> Loader Class Initialized
INFO - 2016-02-18 08:18:50 --> Helper loaded: url_helper
INFO - 2016-02-18 08:18:50 --> Helper loaded: file_helper
INFO - 2016-02-18 08:18:51 --> Helper loaded: date_helper
INFO - 2016-02-18 08:18:51 --> Helper loaded: form_helper
INFO - 2016-02-18 08:18:51 --> Database Driver Class Initialized
INFO - 2016-02-18 08:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:18:52 --> Controller Class Initialized
INFO - 2016-02-18 08:18:52 --> Model Class Initialized
INFO - 2016-02-18 08:18:52 --> Model Class Initialized
INFO - 2016-02-18 08:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:18:52 --> Pagination Class Initialized
INFO - 2016-02-18 08:18:52 --> Helper loaded: text_helper
INFO - 2016-02-18 08:18:52 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:18:52 --> Final output sent to browser
DEBUG - 2016-02-18 11:18:52 --> Total execution time: 1.1520
INFO - 2016-02-18 08:18:53 --> Config Class Initialized
INFO - 2016-02-18 08:18:53 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:18:53 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:18:53 --> Utf8 Class Initialized
INFO - 2016-02-18 08:18:53 --> URI Class Initialized
INFO - 2016-02-18 08:18:53 --> Router Class Initialized
INFO - 2016-02-18 08:18:53 --> Output Class Initialized
INFO - 2016-02-18 08:18:53 --> Security Class Initialized
DEBUG - 2016-02-18 08:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:18:53 --> Input Class Initialized
INFO - 2016-02-18 08:18:53 --> Language Class Initialized
INFO - 2016-02-18 08:18:53 --> Loader Class Initialized
INFO - 2016-02-18 08:18:53 --> Helper loaded: url_helper
INFO - 2016-02-18 08:18:53 --> Helper loaded: file_helper
INFO - 2016-02-18 08:18:53 --> Helper loaded: date_helper
INFO - 2016-02-18 08:18:53 --> Helper loaded: form_helper
INFO - 2016-02-18 08:18:53 --> Database Driver Class Initialized
INFO - 2016-02-18 08:18:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:18:55 --> Controller Class Initialized
INFO - 2016-02-18 08:18:55 --> Model Class Initialized
INFO - 2016-02-18 08:18:55 --> Model Class Initialized
INFO - 2016-02-18 08:18:55 --> Form Validation Class Initialized
INFO - 2016-02-18 08:18:55 --> Helper loaded: text_helper
INFO - 2016-02-18 08:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:18:55 --> Model Class Initialized
INFO - 2016-02-18 08:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:18:55 --> Final output sent to browser
DEBUG - 2016-02-18 08:18:55 --> Total execution time: 1.1556
INFO - 2016-02-18 08:19:14 --> Config Class Initialized
INFO - 2016-02-18 08:19:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:19:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:19:14 --> Utf8 Class Initialized
INFO - 2016-02-18 08:19:14 --> URI Class Initialized
INFO - 2016-02-18 08:19:14 --> Router Class Initialized
INFO - 2016-02-18 08:19:14 --> Output Class Initialized
INFO - 2016-02-18 08:19:14 --> Security Class Initialized
DEBUG - 2016-02-18 08:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:19:14 --> Input Class Initialized
INFO - 2016-02-18 08:19:14 --> Language Class Initialized
INFO - 2016-02-18 08:19:14 --> Loader Class Initialized
INFO - 2016-02-18 08:19:14 --> Helper loaded: url_helper
INFO - 2016-02-18 08:19:14 --> Helper loaded: file_helper
INFO - 2016-02-18 08:19:14 --> Helper loaded: date_helper
INFO - 2016-02-18 08:19:14 --> Helper loaded: form_helper
INFO - 2016-02-18 08:19:14 --> Database Driver Class Initialized
INFO - 2016-02-18 08:19:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:19:15 --> Controller Class Initialized
INFO - 2016-02-18 08:19:15 --> Model Class Initialized
INFO - 2016-02-18 08:19:15 --> Model Class Initialized
INFO - 2016-02-18 08:19:15 --> Form Validation Class Initialized
INFO - 2016-02-18 08:19:15 --> Helper loaded: text_helper
INFO - 2016-02-18 08:19:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:19:15 --> Config Class Initialized
INFO - 2016-02-18 08:19:15 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:19:15 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:19:15 --> Utf8 Class Initialized
INFO - 2016-02-18 08:19:15 --> URI Class Initialized
INFO - 2016-02-18 08:19:15 --> Router Class Initialized
INFO - 2016-02-18 08:19:15 --> Output Class Initialized
INFO - 2016-02-18 08:19:15 --> Security Class Initialized
DEBUG - 2016-02-18 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:19:15 --> Input Class Initialized
INFO - 2016-02-18 08:19:15 --> Language Class Initialized
INFO - 2016-02-18 08:19:15 --> Loader Class Initialized
INFO - 2016-02-18 08:19:15 --> Helper loaded: url_helper
INFO - 2016-02-18 08:19:15 --> Helper loaded: file_helper
INFO - 2016-02-18 08:19:15 --> Helper loaded: date_helper
INFO - 2016-02-18 08:19:15 --> Helper loaded: form_helper
INFO - 2016-02-18 08:19:15 --> Database Driver Class Initialized
INFO - 2016-02-18 08:19:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:19:16 --> Controller Class Initialized
INFO - 2016-02-18 08:19:16 --> Model Class Initialized
INFO - 2016-02-18 08:19:16 --> Model Class Initialized
INFO - 2016-02-18 08:19:16 --> Form Validation Class Initialized
INFO - 2016-02-18 08:19:16 --> Helper loaded: text_helper
INFO - 2016-02-18 08:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:19:16 --> Model Class Initialized
INFO - 2016-02-18 08:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:19:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:19:16 --> Final output sent to browser
DEBUG - 2016-02-18 08:19:16 --> Total execution time: 1.1555
INFO - 2016-02-18 08:19:39 --> Config Class Initialized
INFO - 2016-02-18 08:19:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:19:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:19:39 --> Utf8 Class Initialized
INFO - 2016-02-18 08:19:39 --> URI Class Initialized
DEBUG - 2016-02-18 08:19:39 --> No URI present. Default controller set.
INFO - 2016-02-18 08:19:39 --> Router Class Initialized
INFO - 2016-02-18 08:19:39 --> Output Class Initialized
INFO - 2016-02-18 08:19:39 --> Security Class Initialized
DEBUG - 2016-02-18 08:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:19:39 --> Input Class Initialized
INFO - 2016-02-18 08:19:39 --> Language Class Initialized
INFO - 2016-02-18 08:19:39 --> Loader Class Initialized
INFO - 2016-02-18 08:19:39 --> Helper loaded: url_helper
INFO - 2016-02-18 08:19:39 --> Helper loaded: file_helper
INFO - 2016-02-18 08:19:39 --> Helper loaded: date_helper
INFO - 2016-02-18 08:19:39 --> Helper loaded: form_helper
INFO - 2016-02-18 08:19:39 --> Database Driver Class Initialized
INFO - 2016-02-18 08:19:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:19:40 --> Controller Class Initialized
INFO - 2016-02-18 08:19:40 --> Model Class Initialized
INFO - 2016-02-18 08:19:40 --> Model Class Initialized
INFO - 2016-02-18 08:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:19:40 --> Pagination Class Initialized
INFO - 2016-02-18 08:19:40 --> Helper loaded: text_helper
INFO - 2016-02-18 08:19:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:19:40 --> Final output sent to browser
DEBUG - 2016-02-18 11:19:40 --> Total execution time: 1.1286
INFO - 2016-02-18 08:23:11 --> Config Class Initialized
INFO - 2016-02-18 08:23:11 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:23:11 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:23:11 --> Utf8 Class Initialized
INFO - 2016-02-18 08:23:11 --> URI Class Initialized
DEBUG - 2016-02-18 08:23:11 --> No URI present. Default controller set.
INFO - 2016-02-18 08:23:11 --> Router Class Initialized
INFO - 2016-02-18 08:23:11 --> Output Class Initialized
INFO - 2016-02-18 08:23:11 --> Security Class Initialized
DEBUG - 2016-02-18 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:23:11 --> Input Class Initialized
INFO - 2016-02-18 08:23:11 --> Language Class Initialized
INFO - 2016-02-18 08:23:11 --> Loader Class Initialized
INFO - 2016-02-18 08:23:11 --> Helper loaded: url_helper
INFO - 2016-02-18 08:23:11 --> Helper loaded: file_helper
INFO - 2016-02-18 08:23:11 --> Helper loaded: date_helper
INFO - 2016-02-18 08:23:11 --> Helper loaded: form_helper
INFO - 2016-02-18 08:23:11 --> Database Driver Class Initialized
INFO - 2016-02-18 08:23:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:23:12 --> Controller Class Initialized
INFO - 2016-02-18 08:23:12 --> Model Class Initialized
INFO - 2016-02-18 08:23:12 --> Model Class Initialized
INFO - 2016-02-18 08:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:23:12 --> Pagination Class Initialized
INFO - 2016-02-18 08:23:12 --> Helper loaded: text_helper
INFO - 2016-02-18 08:23:12 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:23:12 --> Final output sent to browser
DEBUG - 2016-02-18 11:23:12 --> Total execution time: 1.1541
INFO - 2016-02-18 08:23:12 --> Config Class Initialized
INFO - 2016-02-18 08:23:12 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:23:12 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:23:12 --> Utf8 Class Initialized
INFO - 2016-02-18 08:23:12 --> URI Class Initialized
INFO - 2016-02-18 08:23:12 --> Router Class Initialized
INFO - 2016-02-18 08:23:12 --> Output Class Initialized
INFO - 2016-02-18 08:23:12 --> Security Class Initialized
DEBUG - 2016-02-18 08:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:23:12 --> Input Class Initialized
INFO - 2016-02-18 08:23:12 --> Language Class Initialized
INFO - 2016-02-18 08:23:12 --> Loader Class Initialized
INFO - 2016-02-18 08:23:12 --> Helper loaded: url_helper
INFO - 2016-02-18 08:23:12 --> Helper loaded: file_helper
INFO - 2016-02-18 08:23:12 --> Helper loaded: date_helper
INFO - 2016-02-18 08:23:12 --> Helper loaded: form_helper
INFO - 2016-02-18 08:23:12 --> Database Driver Class Initialized
INFO - 2016-02-18 08:23:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:23:13 --> Controller Class Initialized
INFO - 2016-02-18 08:23:13 --> Model Class Initialized
INFO - 2016-02-18 08:23:13 --> Model Class Initialized
INFO - 2016-02-18 08:23:14 --> Form Validation Class Initialized
INFO - 2016-02-18 08:23:14 --> Helper loaded: text_helper
INFO - 2016-02-18 08:23:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:23:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:23:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:23:14 --> Model Class Initialized
INFO - 2016-02-18 08:23:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:23:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:23:14 --> Final output sent to browser
DEBUG - 2016-02-18 08:23:14 --> Total execution time: 1.1741
INFO - 2016-02-18 08:23:31 --> Config Class Initialized
INFO - 2016-02-18 08:23:31 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:23:31 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:23:31 --> Utf8 Class Initialized
INFO - 2016-02-18 08:23:31 --> URI Class Initialized
INFO - 2016-02-18 08:23:31 --> Router Class Initialized
INFO - 2016-02-18 08:23:31 --> Output Class Initialized
INFO - 2016-02-18 08:23:31 --> Security Class Initialized
DEBUG - 2016-02-18 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:23:31 --> Input Class Initialized
INFO - 2016-02-18 08:23:31 --> Language Class Initialized
INFO - 2016-02-18 08:23:31 --> Loader Class Initialized
INFO - 2016-02-18 08:23:31 --> Helper loaded: url_helper
INFO - 2016-02-18 08:23:31 --> Helper loaded: file_helper
INFO - 2016-02-18 08:23:31 --> Helper loaded: date_helper
INFO - 2016-02-18 08:23:31 --> Helper loaded: form_helper
INFO - 2016-02-18 08:23:31 --> Database Driver Class Initialized
INFO - 2016-02-18 08:23:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:23:32 --> Controller Class Initialized
INFO - 2016-02-18 08:23:32 --> Model Class Initialized
INFO - 2016-02-18 08:23:32 --> Model Class Initialized
INFO - 2016-02-18 08:23:32 --> Form Validation Class Initialized
INFO - 2016-02-18 08:23:32 --> Helper loaded: text_helper
INFO - 2016-02-18 08:23:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-18 08:23:32 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 72
INFO - 2016-02-18 08:23:32 --> Config Class Initialized
INFO - 2016-02-18 08:23:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:23:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:23:32 --> Utf8 Class Initialized
INFO - 2016-02-18 08:23:32 --> URI Class Initialized
INFO - 2016-02-18 08:23:32 --> Router Class Initialized
INFO - 2016-02-18 08:23:32 --> Output Class Initialized
INFO - 2016-02-18 08:23:32 --> Security Class Initialized
DEBUG - 2016-02-18 08:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:23:32 --> Input Class Initialized
INFO - 2016-02-18 08:23:32 --> Language Class Initialized
ERROR - 2016-02-18 08:23:32 --> 404 Page Not Found: Auth/resister_viewArray
INFO - 2016-02-18 08:23:48 --> Config Class Initialized
INFO - 2016-02-18 08:23:48 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:23:48 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:23:48 --> Utf8 Class Initialized
INFO - 2016-02-18 08:23:48 --> URI Class Initialized
INFO - 2016-02-18 08:23:48 --> Router Class Initialized
INFO - 2016-02-18 08:23:48 --> Output Class Initialized
INFO - 2016-02-18 08:23:48 --> Security Class Initialized
DEBUG - 2016-02-18 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:23:48 --> Input Class Initialized
INFO - 2016-02-18 08:23:48 --> Language Class Initialized
INFO - 2016-02-18 08:23:48 --> Loader Class Initialized
INFO - 2016-02-18 08:23:48 --> Helper loaded: url_helper
INFO - 2016-02-18 08:23:48 --> Helper loaded: file_helper
INFO - 2016-02-18 08:23:48 --> Helper loaded: date_helper
INFO - 2016-02-18 08:23:48 --> Helper loaded: form_helper
INFO - 2016-02-18 08:23:48 --> Database Driver Class Initialized
INFO - 2016-02-18 08:23:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:23:49 --> Controller Class Initialized
INFO - 2016-02-18 08:23:49 --> Model Class Initialized
INFO - 2016-02-18 08:23:49 --> Model Class Initialized
INFO - 2016-02-18 08:23:49 --> Form Validation Class Initialized
INFO - 2016-02-18 08:23:49 --> Helper loaded: text_helper
INFO - 2016-02-18 08:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:23:49 --> Model Class Initialized
INFO - 2016-02-18 08:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:23:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:23:49 --> Final output sent to browser
DEBUG - 2016-02-18 08:23:49 --> Total execution time: 1.1426
INFO - 2016-02-18 08:24:01 --> Config Class Initialized
INFO - 2016-02-18 08:24:01 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:24:01 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:24:01 --> Utf8 Class Initialized
INFO - 2016-02-18 08:24:01 --> URI Class Initialized
INFO - 2016-02-18 08:24:01 --> Router Class Initialized
INFO - 2016-02-18 08:24:01 --> Output Class Initialized
INFO - 2016-02-18 08:24:01 --> Security Class Initialized
DEBUG - 2016-02-18 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:24:01 --> Input Class Initialized
INFO - 2016-02-18 08:24:01 --> Language Class Initialized
INFO - 2016-02-18 08:24:01 --> Loader Class Initialized
INFO - 2016-02-18 08:24:01 --> Helper loaded: url_helper
INFO - 2016-02-18 08:24:01 --> Helper loaded: file_helper
INFO - 2016-02-18 08:24:01 --> Helper loaded: date_helper
INFO - 2016-02-18 08:24:01 --> Helper loaded: form_helper
INFO - 2016-02-18 08:24:01 --> Database Driver Class Initialized
INFO - 2016-02-18 08:24:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:24:02 --> Controller Class Initialized
INFO - 2016-02-18 08:24:02 --> Model Class Initialized
INFO - 2016-02-18 08:24:02 --> Model Class Initialized
INFO - 2016-02-18 08:24:02 --> Form Validation Class Initialized
INFO - 2016-02-18 08:24:02 --> Helper loaded: text_helper
INFO - 2016-02-18 08:24:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:24:02 --> Config Class Initialized
INFO - 2016-02-18 08:24:02 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:24:02 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:24:02 --> Utf8 Class Initialized
INFO - 2016-02-18 08:24:02 --> URI Class Initialized
INFO - 2016-02-18 08:24:02 --> Router Class Initialized
INFO - 2016-02-18 08:24:02 --> Output Class Initialized
INFO - 2016-02-18 08:24:02 --> Security Class Initialized
DEBUG - 2016-02-18 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:24:02 --> Input Class Initialized
INFO - 2016-02-18 08:24:02 --> Language Class Initialized
INFO - 2016-02-18 08:24:02 --> Loader Class Initialized
INFO - 2016-02-18 08:24:02 --> Helper loaded: url_helper
INFO - 2016-02-18 08:24:02 --> Helper loaded: file_helper
INFO - 2016-02-18 08:24:02 --> Helper loaded: date_helper
INFO - 2016-02-18 08:24:02 --> Helper loaded: form_helper
INFO - 2016-02-18 08:24:02 --> Database Driver Class Initialized
INFO - 2016-02-18 08:24:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:24:03 --> Controller Class Initialized
INFO - 2016-02-18 08:24:03 --> Model Class Initialized
INFO - 2016-02-18 08:24:03 --> Model Class Initialized
INFO - 2016-02-18 08:24:03 --> Form Validation Class Initialized
INFO - 2016-02-18 08:24:03 --> Helper loaded: text_helper
INFO - 2016-02-18 08:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:24:03 --> Model Class Initialized
INFO - 2016-02-18 08:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:24:03 --> Final output sent to browser
DEBUG - 2016-02-18 08:24:03 --> Total execution time: 1.1468
INFO - 2016-02-18 08:25:30 --> Config Class Initialized
INFO - 2016-02-18 08:25:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:25:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:25:30 --> Utf8 Class Initialized
INFO - 2016-02-18 08:25:30 --> URI Class Initialized
INFO - 2016-02-18 08:25:30 --> Router Class Initialized
INFO - 2016-02-18 08:25:30 --> Output Class Initialized
INFO - 2016-02-18 08:25:30 --> Security Class Initialized
DEBUG - 2016-02-18 08:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:25:30 --> Input Class Initialized
INFO - 2016-02-18 08:25:30 --> Language Class Initialized
INFO - 2016-02-18 08:25:30 --> Loader Class Initialized
INFO - 2016-02-18 08:25:30 --> Helper loaded: url_helper
INFO - 2016-02-18 08:25:30 --> Helper loaded: file_helper
INFO - 2016-02-18 08:25:30 --> Helper loaded: date_helper
INFO - 2016-02-18 08:25:30 --> Helper loaded: form_helper
INFO - 2016-02-18 08:25:30 --> Database Driver Class Initialized
INFO - 2016-02-18 08:25:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:25:31 --> Controller Class Initialized
INFO - 2016-02-18 08:25:31 --> Model Class Initialized
INFO - 2016-02-18 08:25:31 --> Model Class Initialized
INFO - 2016-02-18 08:25:31 --> Form Validation Class Initialized
INFO - 2016-02-18 08:25:31 --> Helper loaded: text_helper
INFO - 2016-02-18 08:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:25:31 --> Model Class Initialized
INFO - 2016-02-18 08:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:25:31 --> Final output sent to browser
DEBUG - 2016-02-18 08:25:31 --> Total execution time: 1.1116
INFO - 2016-02-18 08:25:41 --> Config Class Initialized
INFO - 2016-02-18 08:25:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:25:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:25:41 --> Utf8 Class Initialized
INFO - 2016-02-18 08:25:41 --> URI Class Initialized
INFO - 2016-02-18 08:25:41 --> Router Class Initialized
INFO - 2016-02-18 08:25:41 --> Output Class Initialized
INFO - 2016-02-18 08:25:41 --> Security Class Initialized
DEBUG - 2016-02-18 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:25:41 --> Input Class Initialized
INFO - 2016-02-18 08:25:41 --> Language Class Initialized
INFO - 2016-02-18 08:25:41 --> Loader Class Initialized
INFO - 2016-02-18 08:25:41 --> Helper loaded: url_helper
INFO - 2016-02-18 08:25:41 --> Helper loaded: file_helper
INFO - 2016-02-18 08:25:41 --> Helper loaded: date_helper
INFO - 2016-02-18 08:25:41 --> Helper loaded: form_helper
INFO - 2016-02-18 08:25:41 --> Database Driver Class Initialized
INFO - 2016-02-18 08:25:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:25:42 --> Controller Class Initialized
INFO - 2016-02-18 08:25:42 --> Model Class Initialized
INFO - 2016-02-18 08:25:42 --> Model Class Initialized
INFO - 2016-02-18 08:25:42 --> Form Validation Class Initialized
INFO - 2016-02-18 08:25:42 --> Helper loaded: text_helper
INFO - 2016-02-18 08:25:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:25:42 --> Final output sent to browser
DEBUG - 2016-02-18 08:25:42 --> Total execution time: 1.1482
INFO - 2016-02-18 08:29:17 --> Config Class Initialized
INFO - 2016-02-18 08:29:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:29:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:29:17 --> Utf8 Class Initialized
INFO - 2016-02-18 08:29:17 --> URI Class Initialized
INFO - 2016-02-18 08:29:17 --> Router Class Initialized
INFO - 2016-02-18 08:29:17 --> Output Class Initialized
INFO - 2016-02-18 08:29:17 --> Security Class Initialized
DEBUG - 2016-02-18 08:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:29:17 --> Input Class Initialized
INFO - 2016-02-18 08:29:17 --> Language Class Initialized
INFO - 2016-02-18 08:29:17 --> Loader Class Initialized
INFO - 2016-02-18 08:29:17 --> Helper loaded: url_helper
INFO - 2016-02-18 08:29:17 --> Helper loaded: file_helper
INFO - 2016-02-18 08:29:17 --> Helper loaded: date_helper
INFO - 2016-02-18 08:29:17 --> Helper loaded: form_helper
INFO - 2016-02-18 08:29:17 --> Database Driver Class Initialized
INFO - 2016-02-18 08:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:29:18 --> Controller Class Initialized
INFO - 2016-02-18 08:29:18 --> Model Class Initialized
INFO - 2016-02-18 08:29:18 --> Model Class Initialized
INFO - 2016-02-18 08:29:18 --> Form Validation Class Initialized
INFO - 2016-02-18 08:29:18 --> Helper loaded: text_helper
INFO - 2016-02-18 08:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:29:18 --> Model Class Initialized
INFO - 2016-02-18 08:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:29:18 --> Final output sent to browser
DEBUG - 2016-02-18 08:29:18 --> Total execution time: 1.1423
INFO - 2016-02-18 08:30:20 --> Config Class Initialized
INFO - 2016-02-18 08:30:20 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:20 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:20 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:20 --> URI Class Initialized
DEBUG - 2016-02-18 08:30:20 --> No URI present. Default controller set.
INFO - 2016-02-18 08:30:20 --> Router Class Initialized
INFO - 2016-02-18 08:30:20 --> Output Class Initialized
INFO - 2016-02-18 08:30:20 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:20 --> Input Class Initialized
INFO - 2016-02-18 08:30:20 --> Language Class Initialized
INFO - 2016-02-18 08:30:20 --> Loader Class Initialized
INFO - 2016-02-18 08:30:20 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:20 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:20 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:20 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:20 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:21 --> Controller Class Initialized
INFO - 2016-02-18 08:30:21 --> Model Class Initialized
INFO - 2016-02-18 08:30:21 --> Model Class Initialized
INFO - 2016-02-18 08:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:30:21 --> Pagination Class Initialized
INFO - 2016-02-18 08:30:21 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:21 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:30:21 --> Final output sent to browser
DEBUG - 2016-02-18 11:30:21 --> Total execution time: 1.1803
INFO - 2016-02-18 08:30:24 --> Config Class Initialized
INFO - 2016-02-18 08:30:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:24 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:24 --> URI Class Initialized
INFO - 2016-02-18 08:30:24 --> Router Class Initialized
INFO - 2016-02-18 08:30:24 --> Output Class Initialized
INFO - 2016-02-18 08:30:24 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:24 --> Input Class Initialized
INFO - 2016-02-18 08:30:24 --> Language Class Initialized
INFO - 2016-02-18 08:30:24 --> Loader Class Initialized
INFO - 2016-02-18 08:30:24 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:24 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:24 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:24 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:24 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:25 --> Controller Class Initialized
INFO - 2016-02-18 08:30:25 --> Model Class Initialized
INFO - 2016-02-18 08:30:25 --> Model Class Initialized
INFO - 2016-02-18 08:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:30:25 --> Pagination Class Initialized
INFO - 2016-02-18 08:30:25 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:25 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:30:25 --> Final output sent to browser
DEBUG - 2016-02-18 11:30:25 --> Total execution time: 1.2426
INFO - 2016-02-18 08:30:28 --> Config Class Initialized
INFO - 2016-02-18 08:30:28 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:28 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:28 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:28 --> URI Class Initialized
INFO - 2016-02-18 08:30:28 --> Router Class Initialized
INFO - 2016-02-18 08:30:29 --> Output Class Initialized
INFO - 2016-02-18 08:30:29 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:29 --> Input Class Initialized
INFO - 2016-02-18 08:30:29 --> Language Class Initialized
INFO - 2016-02-18 08:30:29 --> Loader Class Initialized
INFO - 2016-02-18 08:30:29 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:29 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:29 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:29 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:29 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:30 --> Controller Class Initialized
INFO - 2016-02-18 08:30:30 --> Model Class Initialized
INFO - 2016-02-18 08:30:30 --> Model Class Initialized
INFO - 2016-02-18 08:30:30 --> Form Validation Class Initialized
INFO - 2016-02-18 08:30:30 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:30:30 --> Model Class Initialized
INFO - 2016-02-18 08:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:30:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:30:30 --> Final output sent to browser
DEBUG - 2016-02-18 08:30:30 --> Total execution time: 1.1455
INFO - 2016-02-18 08:30:47 --> Config Class Initialized
INFO - 2016-02-18 08:30:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:47 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:47 --> URI Class Initialized
INFO - 2016-02-18 08:30:47 --> Router Class Initialized
INFO - 2016-02-18 08:30:47 --> Output Class Initialized
INFO - 2016-02-18 08:30:47 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:47 --> Input Class Initialized
INFO - 2016-02-18 08:30:47 --> Language Class Initialized
INFO - 2016-02-18 08:30:47 --> Loader Class Initialized
INFO - 2016-02-18 08:30:47 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:47 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:47 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:47 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:47 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:48 --> Controller Class Initialized
INFO - 2016-02-18 08:30:48 --> Model Class Initialized
INFO - 2016-02-18 08:30:48 --> Model Class Initialized
INFO - 2016-02-18 08:30:48 --> Form Validation Class Initialized
INFO - 2016-02-18 08:30:48 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:30:49 --> Config Class Initialized
INFO - 2016-02-18 08:30:49 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:49 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:49 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:49 --> URI Class Initialized
INFO - 2016-02-18 08:30:49 --> Router Class Initialized
INFO - 2016-02-18 08:30:49 --> Output Class Initialized
INFO - 2016-02-18 08:30:49 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:49 --> Input Class Initialized
INFO - 2016-02-18 08:30:49 --> Language Class Initialized
INFO - 2016-02-18 08:30:49 --> Loader Class Initialized
INFO - 2016-02-18 08:30:49 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:49 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:49 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:49 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:49 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:50 --> Controller Class Initialized
INFO - 2016-02-18 08:30:50 --> Model Class Initialized
INFO - 2016-02-18 08:30:50 --> Model Class Initialized
INFO - 2016-02-18 08:30:50 --> Form Validation Class Initialized
INFO - 2016-02-18 08:30:50 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-18 08:30:50 --> Final output sent to browser
DEBUG - 2016-02-18 08:30:50 --> Total execution time: 1.1451
INFO - 2016-02-18 08:30:57 --> Config Class Initialized
INFO - 2016-02-18 08:30:57 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:30:57 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:30:57 --> Utf8 Class Initialized
INFO - 2016-02-18 08:30:57 --> URI Class Initialized
DEBUG - 2016-02-18 08:30:57 --> No URI present. Default controller set.
INFO - 2016-02-18 08:30:57 --> Router Class Initialized
INFO - 2016-02-18 08:30:57 --> Output Class Initialized
INFO - 2016-02-18 08:30:57 --> Security Class Initialized
DEBUG - 2016-02-18 08:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:30:57 --> Input Class Initialized
INFO - 2016-02-18 08:30:57 --> Language Class Initialized
INFO - 2016-02-18 08:30:57 --> Loader Class Initialized
INFO - 2016-02-18 08:30:57 --> Helper loaded: url_helper
INFO - 2016-02-18 08:30:57 --> Helper loaded: file_helper
INFO - 2016-02-18 08:30:57 --> Helper loaded: date_helper
INFO - 2016-02-18 08:30:57 --> Helper loaded: form_helper
INFO - 2016-02-18 08:30:57 --> Database Driver Class Initialized
INFO - 2016-02-18 08:30:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:30:58 --> Controller Class Initialized
INFO - 2016-02-18 08:30:58 --> Model Class Initialized
INFO - 2016-02-18 08:30:58 --> Model Class Initialized
INFO - 2016-02-18 08:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:30:58 --> Pagination Class Initialized
INFO - 2016-02-18 08:30:58 --> Helper loaded: text_helper
INFO - 2016-02-18 08:30:58 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:30:58 --> Final output sent to browser
DEBUG - 2016-02-18 11:30:58 --> Total execution time: 1.1492
INFO - 2016-02-18 08:31:00 --> Config Class Initialized
INFO - 2016-02-18 08:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:31:00 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:31:00 --> Utf8 Class Initialized
INFO - 2016-02-18 08:31:00 --> URI Class Initialized
INFO - 2016-02-18 08:31:00 --> Router Class Initialized
INFO - 2016-02-18 08:31:00 --> Output Class Initialized
INFO - 2016-02-18 08:31:00 --> Security Class Initialized
DEBUG - 2016-02-18 08:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:31:00 --> Input Class Initialized
INFO - 2016-02-18 08:31:00 --> Language Class Initialized
INFO - 2016-02-18 08:31:00 --> Loader Class Initialized
INFO - 2016-02-18 08:31:00 --> Helper loaded: url_helper
INFO - 2016-02-18 08:31:00 --> Helper loaded: file_helper
INFO - 2016-02-18 08:31:00 --> Helper loaded: date_helper
INFO - 2016-02-18 08:31:00 --> Helper loaded: form_helper
INFO - 2016-02-18 08:31:00 --> Database Driver Class Initialized
INFO - 2016-02-18 08:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:31:01 --> Controller Class Initialized
INFO - 2016-02-18 08:31:01 --> Model Class Initialized
INFO - 2016-02-18 08:31:01 --> Model Class Initialized
INFO - 2016-02-18 08:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:31:01 --> Pagination Class Initialized
INFO - 2016-02-18 08:31:01 --> Helper loaded: text_helper
INFO - 2016-02-18 08:31:01 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:31:01 --> Final output sent to browser
DEBUG - 2016-02-18 11:31:01 --> Total execution time: 1.1414
INFO - 2016-02-18 08:31:04 --> Config Class Initialized
INFO - 2016-02-18 08:31:04 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:31:04 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:31:04 --> Utf8 Class Initialized
INFO - 2016-02-18 08:31:04 --> URI Class Initialized
INFO - 2016-02-18 08:31:04 --> Router Class Initialized
INFO - 2016-02-18 08:31:04 --> Output Class Initialized
INFO - 2016-02-18 08:31:04 --> Security Class Initialized
DEBUG - 2016-02-18 08:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:31:04 --> Input Class Initialized
INFO - 2016-02-18 08:31:04 --> Language Class Initialized
INFO - 2016-02-18 08:31:04 --> Loader Class Initialized
INFO - 2016-02-18 08:31:04 --> Helper loaded: url_helper
INFO - 2016-02-18 08:31:04 --> Helper loaded: file_helper
INFO - 2016-02-18 08:31:04 --> Helper loaded: date_helper
INFO - 2016-02-18 08:31:04 --> Helper loaded: form_helper
INFO - 2016-02-18 08:31:04 --> Database Driver Class Initialized
INFO - 2016-02-18 08:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:31:05 --> Controller Class Initialized
INFO - 2016-02-18 08:31:05 --> Model Class Initialized
INFO - 2016-02-18 08:31:05 --> Model Class Initialized
INFO - 2016-02-18 08:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:31:05 --> Pagination Class Initialized
INFO - 2016-02-18 08:31:05 --> Helper loaded: text_helper
INFO - 2016-02-18 08:31:05 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 11:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 11:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:31:05 --> Final output sent to browser
DEBUG - 2016-02-18 11:31:05 --> Total execution time: 1.1514
INFO - 2016-02-18 08:31:06 --> Config Class Initialized
INFO - 2016-02-18 08:31:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:31:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:31:06 --> Utf8 Class Initialized
INFO - 2016-02-18 08:31:06 --> URI Class Initialized
INFO - 2016-02-18 08:31:06 --> Router Class Initialized
INFO - 2016-02-18 08:31:06 --> Output Class Initialized
INFO - 2016-02-18 08:31:06 --> Security Class Initialized
DEBUG - 2016-02-18 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:31:06 --> Input Class Initialized
INFO - 2016-02-18 08:31:06 --> Language Class Initialized
INFO - 2016-02-18 08:31:06 --> Loader Class Initialized
INFO - 2016-02-18 08:31:06 --> Helper loaded: url_helper
INFO - 2016-02-18 08:31:06 --> Helper loaded: file_helper
INFO - 2016-02-18 08:31:06 --> Helper loaded: date_helper
INFO - 2016-02-18 08:31:06 --> Helper loaded: form_helper
INFO - 2016-02-18 08:31:06 --> Database Driver Class Initialized
INFO - 2016-02-18 08:31:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:31:07 --> Controller Class Initialized
INFO - 2016-02-18 08:31:07 --> Model Class Initialized
INFO - 2016-02-18 08:31:07 --> Model Class Initialized
INFO - 2016-02-18 08:31:07 --> Form Validation Class Initialized
INFO - 2016-02-18 08:31:07 --> Helper loaded: text_helper
INFO - 2016-02-18 08:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:31:07 --> Model Class Initialized
INFO - 2016-02-18 08:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:31:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:31:07 --> Final output sent to browser
DEBUG - 2016-02-18 08:31:07 --> Total execution time: 1.1634
INFO - 2016-02-18 08:31:21 --> Config Class Initialized
INFO - 2016-02-18 08:31:21 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:31:21 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:31:21 --> Utf8 Class Initialized
INFO - 2016-02-18 08:31:21 --> URI Class Initialized
INFO - 2016-02-18 08:31:21 --> Router Class Initialized
INFO - 2016-02-18 08:31:21 --> Output Class Initialized
INFO - 2016-02-18 08:31:21 --> Security Class Initialized
DEBUG - 2016-02-18 08:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:31:21 --> Input Class Initialized
INFO - 2016-02-18 08:31:21 --> Language Class Initialized
INFO - 2016-02-18 08:31:21 --> Loader Class Initialized
INFO - 2016-02-18 08:31:21 --> Helper loaded: url_helper
INFO - 2016-02-18 08:31:21 --> Helper loaded: file_helper
INFO - 2016-02-18 08:31:21 --> Helper loaded: date_helper
INFO - 2016-02-18 08:31:21 --> Helper loaded: form_helper
INFO - 2016-02-18 08:31:21 --> Database Driver Class Initialized
INFO - 2016-02-18 08:31:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:31:22 --> Controller Class Initialized
INFO - 2016-02-18 08:31:22 --> Model Class Initialized
INFO - 2016-02-18 08:31:22 --> Model Class Initialized
INFO - 2016-02-18 08:31:22 --> Form Validation Class Initialized
INFO - 2016-02-18 08:31:22 --> Helper loaded: text_helper
INFO - 2016-02-18 08:31:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 08:31:23 --> Config Class Initialized
INFO - 2016-02-18 08:31:23 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:31:23 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:31:23 --> Utf8 Class Initialized
INFO - 2016-02-18 08:31:23 --> URI Class Initialized
INFO - 2016-02-18 08:31:23 --> Router Class Initialized
INFO - 2016-02-18 08:31:23 --> Output Class Initialized
INFO - 2016-02-18 08:31:23 --> Security Class Initialized
DEBUG - 2016-02-18 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:31:23 --> Input Class Initialized
INFO - 2016-02-18 08:31:23 --> Language Class Initialized
INFO - 2016-02-18 08:31:23 --> Loader Class Initialized
INFO - 2016-02-18 08:31:23 --> Helper loaded: url_helper
INFO - 2016-02-18 08:31:23 --> Helper loaded: file_helper
INFO - 2016-02-18 08:31:23 --> Helper loaded: date_helper
INFO - 2016-02-18 08:31:23 --> Helper loaded: form_helper
INFO - 2016-02-18 08:31:23 --> Database Driver Class Initialized
INFO - 2016-02-18 08:31:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:31:24 --> Controller Class Initialized
INFO - 2016-02-18 08:31:24 --> Model Class Initialized
INFO - 2016-02-18 08:31:24 --> Model Class Initialized
INFO - 2016-02-18 08:31:24 --> Form Validation Class Initialized
INFO - 2016-02-18 08:31:24 --> Helper loaded: text_helper
INFO - 2016-02-18 08:31:24 --> Final output sent to browser
DEBUG - 2016-02-18 08:31:24 --> Total execution time: 1.1223
INFO - 2016-02-18 08:37:16 --> Config Class Initialized
INFO - 2016-02-18 08:37:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:37:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:37:16 --> Utf8 Class Initialized
INFO - 2016-02-18 08:37:16 --> URI Class Initialized
INFO - 2016-02-18 08:37:16 --> Router Class Initialized
INFO - 2016-02-18 08:37:16 --> Output Class Initialized
INFO - 2016-02-18 08:37:16 --> Security Class Initialized
DEBUG - 2016-02-18 08:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:37:16 --> Input Class Initialized
INFO - 2016-02-18 08:37:16 --> Language Class Initialized
INFO - 2016-02-18 08:37:16 --> Loader Class Initialized
INFO - 2016-02-18 08:37:16 --> Helper loaded: url_helper
INFO - 2016-02-18 08:37:16 --> Helper loaded: file_helper
INFO - 2016-02-18 08:37:16 --> Helper loaded: date_helper
INFO - 2016-02-18 08:37:16 --> Helper loaded: form_helper
INFO - 2016-02-18 08:37:16 --> Database Driver Class Initialized
INFO - 2016-02-18 08:37:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:37:17 --> Controller Class Initialized
INFO - 2016-02-18 08:37:17 --> Model Class Initialized
INFO - 2016-02-18 08:37:17 --> Model Class Initialized
INFO - 2016-02-18 08:37:17 --> Form Validation Class Initialized
INFO - 2016-02-18 08:37:17 --> Helper loaded: text_helper
INFO - 2016-02-18 08:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 08:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 08:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 08:37:17 --> Model Class Initialized
INFO - 2016-02-18 08:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 08:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 08:37:17 --> Final output sent to browser
DEBUG - 2016-02-18 08:37:17 --> Total execution time: 1.1384
INFO - 2016-02-18 08:44:18 --> Config Class Initialized
INFO - 2016-02-18 08:44:18 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:44:18 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:44:18 --> Utf8 Class Initialized
INFO - 2016-02-18 08:44:18 --> URI Class Initialized
DEBUG - 2016-02-18 08:44:18 --> No URI present. Default controller set.
INFO - 2016-02-18 08:44:18 --> Router Class Initialized
INFO - 2016-02-18 08:44:18 --> Output Class Initialized
INFO - 2016-02-18 08:44:18 --> Security Class Initialized
DEBUG - 2016-02-18 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:44:18 --> Input Class Initialized
INFO - 2016-02-18 08:44:18 --> Language Class Initialized
INFO - 2016-02-18 08:44:18 --> Loader Class Initialized
INFO - 2016-02-18 08:44:18 --> Helper loaded: url_helper
INFO - 2016-02-18 08:44:18 --> Helper loaded: file_helper
INFO - 2016-02-18 08:44:18 --> Helper loaded: date_helper
INFO - 2016-02-18 08:44:18 --> Helper loaded: form_helper
INFO - 2016-02-18 08:44:18 --> Database Driver Class Initialized
INFO - 2016-02-18 08:44:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:44:19 --> Controller Class Initialized
INFO - 2016-02-18 08:44:19 --> Model Class Initialized
INFO - 2016-02-18 08:44:19 --> Model Class Initialized
INFO - 2016-02-18 08:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:44:19 --> Pagination Class Initialized
INFO - 2016-02-18 08:44:19 --> Helper loaded: text_helper
INFO - 2016-02-18 08:44:19 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:44:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:44:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:44:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:44:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:44:19 --> Final output sent to browser
DEBUG - 2016-02-18 11:44:19 --> Total execution time: 1.1586
INFO - 2016-02-18 08:44:44 --> Config Class Initialized
INFO - 2016-02-18 08:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:44:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:44:44 --> Utf8 Class Initialized
INFO - 2016-02-18 08:44:44 --> URI Class Initialized
DEBUG - 2016-02-18 08:44:44 --> No URI present. Default controller set.
INFO - 2016-02-18 08:44:44 --> Router Class Initialized
INFO - 2016-02-18 08:44:44 --> Output Class Initialized
INFO - 2016-02-18 08:44:44 --> Security Class Initialized
DEBUG - 2016-02-18 08:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:44:44 --> Input Class Initialized
INFO - 2016-02-18 08:44:44 --> Language Class Initialized
INFO - 2016-02-18 08:44:44 --> Loader Class Initialized
INFO - 2016-02-18 08:44:44 --> Helper loaded: url_helper
INFO - 2016-02-18 08:44:44 --> Helper loaded: file_helper
INFO - 2016-02-18 08:44:44 --> Helper loaded: date_helper
INFO - 2016-02-18 08:44:44 --> Helper loaded: form_helper
INFO - 2016-02-18 08:44:44 --> Database Driver Class Initialized
INFO - 2016-02-18 08:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:44:45 --> Controller Class Initialized
INFO - 2016-02-18 08:44:45 --> Model Class Initialized
INFO - 2016-02-18 08:44:45 --> Model Class Initialized
INFO - 2016-02-18 08:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:44:45 --> Pagination Class Initialized
INFO - 2016-02-18 08:44:45 --> Helper loaded: text_helper
INFO - 2016-02-18 08:44:45 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:44:45 --> Final output sent to browser
DEBUG - 2016-02-18 11:44:45 --> Total execution time: 1.1949
INFO - 2016-02-18 08:44:54 --> Config Class Initialized
INFO - 2016-02-18 08:44:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:44:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:44:54 --> Utf8 Class Initialized
INFO - 2016-02-18 08:44:54 --> URI Class Initialized
DEBUG - 2016-02-18 08:44:54 --> No URI present. Default controller set.
INFO - 2016-02-18 08:44:54 --> Router Class Initialized
INFO - 2016-02-18 08:44:54 --> Output Class Initialized
INFO - 2016-02-18 08:44:54 --> Security Class Initialized
DEBUG - 2016-02-18 08:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:44:54 --> Input Class Initialized
INFO - 2016-02-18 08:44:54 --> Language Class Initialized
INFO - 2016-02-18 08:44:54 --> Loader Class Initialized
INFO - 2016-02-18 08:44:54 --> Helper loaded: url_helper
INFO - 2016-02-18 08:44:54 --> Helper loaded: file_helper
INFO - 2016-02-18 08:44:54 --> Helper loaded: date_helper
INFO - 2016-02-18 08:44:54 --> Helper loaded: form_helper
INFO - 2016-02-18 08:44:54 --> Database Driver Class Initialized
INFO - 2016-02-18 08:44:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:44:55 --> Controller Class Initialized
INFO - 2016-02-18 08:44:55 --> Model Class Initialized
INFO - 2016-02-18 08:44:55 --> Model Class Initialized
INFO - 2016-02-18 08:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:44:55 --> Pagination Class Initialized
INFO - 2016-02-18 08:44:55 --> Helper loaded: text_helper
INFO - 2016-02-18 08:44:55 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:44:55 --> Final output sent to browser
DEBUG - 2016-02-18 11:44:55 --> Total execution time: 1.1800
INFO - 2016-02-18 08:51:23 --> Config Class Initialized
INFO - 2016-02-18 08:51:23 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:51:23 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:51:23 --> Utf8 Class Initialized
INFO - 2016-02-18 08:51:23 --> URI Class Initialized
DEBUG - 2016-02-18 08:51:23 --> No URI present. Default controller set.
INFO - 2016-02-18 08:51:23 --> Router Class Initialized
INFO - 2016-02-18 08:51:23 --> Output Class Initialized
INFO - 2016-02-18 08:51:23 --> Security Class Initialized
DEBUG - 2016-02-18 08:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:51:23 --> Input Class Initialized
INFO - 2016-02-18 08:51:23 --> Language Class Initialized
INFO - 2016-02-18 08:51:23 --> Loader Class Initialized
INFO - 2016-02-18 08:51:23 --> Helper loaded: url_helper
INFO - 2016-02-18 08:51:23 --> Helper loaded: file_helper
INFO - 2016-02-18 08:51:23 --> Helper loaded: date_helper
INFO - 2016-02-18 08:51:23 --> Helper loaded: form_helper
INFO - 2016-02-18 08:51:23 --> Database Driver Class Initialized
INFO - 2016-02-18 08:51:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:51:24 --> Controller Class Initialized
INFO - 2016-02-18 08:51:24 --> Model Class Initialized
INFO - 2016-02-18 08:51:24 --> Model Class Initialized
INFO - 2016-02-18 08:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:51:24 --> Pagination Class Initialized
INFO - 2016-02-18 08:51:24 --> Helper loaded: text_helper
INFO - 2016-02-18 08:51:24 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:51:24 --> Final output sent to browser
DEBUG - 2016-02-18 11:51:24 --> Total execution time: 1.1258
INFO - 2016-02-18 08:54:27 --> Config Class Initialized
INFO - 2016-02-18 08:54:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 08:54:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 08:54:27 --> Utf8 Class Initialized
INFO - 2016-02-18 08:54:27 --> URI Class Initialized
DEBUG - 2016-02-18 08:54:27 --> No URI present. Default controller set.
INFO - 2016-02-18 08:54:27 --> Router Class Initialized
INFO - 2016-02-18 08:54:27 --> Output Class Initialized
INFO - 2016-02-18 08:54:27 --> Security Class Initialized
DEBUG - 2016-02-18 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 08:54:27 --> Input Class Initialized
INFO - 2016-02-18 08:54:27 --> Language Class Initialized
INFO - 2016-02-18 08:54:27 --> Loader Class Initialized
INFO - 2016-02-18 08:54:27 --> Helper loaded: url_helper
INFO - 2016-02-18 08:54:27 --> Helper loaded: file_helper
INFO - 2016-02-18 08:54:27 --> Helper loaded: date_helper
INFO - 2016-02-18 08:54:27 --> Helper loaded: form_helper
INFO - 2016-02-18 08:54:27 --> Database Driver Class Initialized
INFO - 2016-02-18 08:54:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 08:54:28 --> Controller Class Initialized
INFO - 2016-02-18 08:54:28 --> Model Class Initialized
INFO - 2016-02-18 08:54:28 --> Model Class Initialized
INFO - 2016-02-18 08:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 08:54:28 --> Pagination Class Initialized
INFO - 2016-02-18 08:54:28 --> Helper loaded: text_helper
INFO - 2016-02-18 08:54:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 11:54:28 --> Final output sent to browser
DEBUG - 2016-02-18 11:54:28 --> Total execution time: 1.1409
INFO - 2016-02-18 09:01:06 --> Config Class Initialized
INFO - 2016-02-18 09:01:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 09:01:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 09:01:06 --> Utf8 Class Initialized
INFO - 2016-02-18 09:01:06 --> URI Class Initialized
DEBUG - 2016-02-18 09:01:06 --> No URI present. Default controller set.
INFO - 2016-02-18 09:01:06 --> Router Class Initialized
INFO - 2016-02-18 09:01:06 --> Output Class Initialized
INFO - 2016-02-18 09:01:06 --> Security Class Initialized
DEBUG - 2016-02-18 09:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 09:01:06 --> Input Class Initialized
INFO - 2016-02-18 09:01:06 --> Language Class Initialized
INFO - 2016-02-18 09:01:06 --> Loader Class Initialized
INFO - 2016-02-18 09:01:06 --> Helper loaded: url_helper
INFO - 2016-02-18 09:01:06 --> Helper loaded: file_helper
INFO - 2016-02-18 09:01:06 --> Helper loaded: date_helper
INFO - 2016-02-18 09:01:06 --> Helper loaded: form_helper
INFO - 2016-02-18 09:01:06 --> Database Driver Class Initialized
INFO - 2016-02-18 09:01:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 09:01:07 --> Controller Class Initialized
INFO - 2016-02-18 09:01:07 --> Model Class Initialized
INFO - 2016-02-18 09:01:07 --> Model Class Initialized
INFO - 2016-02-18 09:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 09:01:07 --> Pagination Class Initialized
INFO - 2016-02-18 09:01:07 --> Helper loaded: text_helper
INFO - 2016-02-18 09:01:07 --> Helper loaded: cookie_helper
INFO - 2016-02-18 12:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 12:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 12:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 12:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 12:01:07 --> Final output sent to browser
DEBUG - 2016-02-18 12:01:07 --> Total execution time: 1.1374
INFO - 2016-02-18 09:01:16 --> Config Class Initialized
INFO - 2016-02-18 09:01:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 09:01:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 09:01:16 --> Utf8 Class Initialized
INFO - 2016-02-18 09:01:16 --> URI Class Initialized
DEBUG - 2016-02-18 09:01:16 --> No URI present. Default controller set.
INFO - 2016-02-18 09:01:16 --> Router Class Initialized
INFO - 2016-02-18 09:01:16 --> Output Class Initialized
INFO - 2016-02-18 09:01:16 --> Security Class Initialized
DEBUG - 2016-02-18 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 09:01:16 --> Input Class Initialized
INFO - 2016-02-18 09:01:16 --> Language Class Initialized
INFO - 2016-02-18 09:01:16 --> Loader Class Initialized
INFO - 2016-02-18 09:01:16 --> Helper loaded: url_helper
INFO - 2016-02-18 09:01:16 --> Helper loaded: file_helper
INFO - 2016-02-18 09:01:16 --> Helper loaded: date_helper
INFO - 2016-02-18 09:01:16 --> Helper loaded: form_helper
INFO - 2016-02-18 09:01:17 --> Database Driver Class Initialized
INFO - 2016-02-18 09:01:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 09:01:18 --> Controller Class Initialized
INFO - 2016-02-18 09:01:18 --> Model Class Initialized
INFO - 2016-02-18 09:01:18 --> Model Class Initialized
INFO - 2016-02-18 09:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 09:01:18 --> Pagination Class Initialized
INFO - 2016-02-18 09:01:18 --> Helper loaded: text_helper
INFO - 2016-02-18 09:01:18 --> Helper loaded: cookie_helper
INFO - 2016-02-18 12:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 12:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 12:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 12:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 12:01:18 --> Final output sent to browser
DEBUG - 2016-02-18 12:01:18 --> Total execution time: 1.1602
INFO - 2016-02-18 09:01:32 --> Config Class Initialized
INFO - 2016-02-18 09:01:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 09:01:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 09:01:32 --> Utf8 Class Initialized
INFO - 2016-02-18 09:01:32 --> URI Class Initialized
DEBUG - 2016-02-18 09:01:32 --> No URI present. Default controller set.
INFO - 2016-02-18 09:01:32 --> Router Class Initialized
INFO - 2016-02-18 09:01:32 --> Output Class Initialized
INFO - 2016-02-18 09:01:32 --> Security Class Initialized
DEBUG - 2016-02-18 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 09:01:32 --> Input Class Initialized
INFO - 2016-02-18 09:01:32 --> Language Class Initialized
INFO - 2016-02-18 09:01:32 --> Loader Class Initialized
INFO - 2016-02-18 09:01:32 --> Helper loaded: url_helper
INFO - 2016-02-18 09:01:32 --> Helper loaded: file_helper
INFO - 2016-02-18 09:01:32 --> Helper loaded: date_helper
INFO - 2016-02-18 09:01:32 --> Helper loaded: form_helper
INFO - 2016-02-18 09:01:32 --> Database Driver Class Initialized
INFO - 2016-02-18 09:01:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 09:01:33 --> Controller Class Initialized
INFO - 2016-02-18 09:01:33 --> Model Class Initialized
INFO - 2016-02-18 09:01:33 --> Model Class Initialized
INFO - 2016-02-18 09:01:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 09:01:33 --> Pagination Class Initialized
INFO - 2016-02-18 09:01:33 --> Helper loaded: text_helper
INFO - 2016-02-18 09:01:33 --> Helper loaded: cookie_helper
INFO - 2016-02-18 12:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 12:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 12:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 12:01:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 12:01:33 --> Final output sent to browser
DEBUG - 2016-02-18 12:01:33 --> Total execution time: 1.2590
INFO - 2016-02-18 10:22:53 --> Config Class Initialized
INFO - 2016-02-18 10:22:53 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:22:53 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:22:53 --> Utf8 Class Initialized
INFO - 2016-02-18 10:22:53 --> URI Class Initialized
DEBUG - 2016-02-18 10:22:53 --> No URI present. Default controller set.
INFO - 2016-02-18 10:22:53 --> Router Class Initialized
INFO - 2016-02-18 10:22:53 --> Output Class Initialized
INFO - 2016-02-18 10:22:53 --> Security Class Initialized
DEBUG - 2016-02-18 10:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:22:53 --> Input Class Initialized
INFO - 2016-02-18 10:22:53 --> Language Class Initialized
INFO - 2016-02-18 10:22:53 --> Loader Class Initialized
INFO - 2016-02-18 10:22:53 --> Helper loaded: url_helper
INFO - 2016-02-18 10:22:53 --> Helper loaded: file_helper
INFO - 2016-02-18 10:22:53 --> Helper loaded: date_helper
INFO - 2016-02-18 10:22:53 --> Helper loaded: form_helper
INFO - 2016-02-18 10:22:53 --> Database Driver Class Initialized
INFO - 2016-02-18 10:22:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:22:54 --> Controller Class Initialized
INFO - 2016-02-18 10:22:54 --> Model Class Initialized
INFO - 2016-02-18 10:22:54 --> Model Class Initialized
INFO - 2016-02-18 10:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:22:54 --> Pagination Class Initialized
INFO - 2016-02-18 10:22:54 --> Helper loaded: text_helper
INFO - 2016-02-18 10:22:54 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:22:54 --> Final output sent to browser
DEBUG - 2016-02-18 13:22:54 --> Total execution time: 1.1745
INFO - 2016-02-18 10:23:04 --> Config Class Initialized
INFO - 2016-02-18 10:23:04 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:23:04 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:23:04 --> Utf8 Class Initialized
INFO - 2016-02-18 10:23:04 --> URI Class Initialized
DEBUG - 2016-02-18 10:23:04 --> No URI present. Default controller set.
INFO - 2016-02-18 10:23:04 --> Router Class Initialized
INFO - 2016-02-18 10:23:04 --> Output Class Initialized
INFO - 2016-02-18 10:23:04 --> Security Class Initialized
DEBUG - 2016-02-18 10:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:23:04 --> Input Class Initialized
INFO - 2016-02-18 10:23:04 --> Language Class Initialized
INFO - 2016-02-18 10:23:04 --> Loader Class Initialized
INFO - 2016-02-18 10:23:04 --> Helper loaded: url_helper
INFO - 2016-02-18 10:23:04 --> Helper loaded: file_helper
INFO - 2016-02-18 10:23:04 --> Helper loaded: date_helper
INFO - 2016-02-18 10:23:04 --> Helper loaded: form_helper
INFO - 2016-02-18 10:23:04 --> Database Driver Class Initialized
INFO - 2016-02-18 10:23:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:23:05 --> Controller Class Initialized
INFO - 2016-02-18 10:23:05 --> Model Class Initialized
INFO - 2016-02-18 10:23:05 --> Model Class Initialized
INFO - 2016-02-18 10:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:23:05 --> Pagination Class Initialized
INFO - 2016-02-18 10:23:05 --> Helper loaded: text_helper
INFO - 2016-02-18 10:23:05 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:23:05 --> Final output sent to browser
DEBUG - 2016-02-18 13:23:05 --> Total execution time: 1.1324
INFO - 2016-02-18 10:30:52 --> Config Class Initialized
INFO - 2016-02-18 10:30:52 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:30:52 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:30:52 --> Utf8 Class Initialized
INFO - 2016-02-18 10:30:52 --> URI Class Initialized
DEBUG - 2016-02-18 10:30:52 --> No URI present. Default controller set.
INFO - 2016-02-18 10:30:52 --> Router Class Initialized
INFO - 2016-02-18 10:30:52 --> Output Class Initialized
INFO - 2016-02-18 10:30:52 --> Security Class Initialized
DEBUG - 2016-02-18 10:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:30:52 --> Input Class Initialized
INFO - 2016-02-18 10:30:52 --> Language Class Initialized
INFO - 2016-02-18 10:30:52 --> Loader Class Initialized
INFO - 2016-02-18 10:30:52 --> Helper loaded: url_helper
INFO - 2016-02-18 10:30:52 --> Helper loaded: file_helper
INFO - 2016-02-18 10:30:52 --> Helper loaded: date_helper
INFO - 2016-02-18 10:30:52 --> Helper loaded: form_helper
INFO - 2016-02-18 10:30:52 --> Database Driver Class Initialized
INFO - 2016-02-18 10:30:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:30:53 --> Controller Class Initialized
INFO - 2016-02-18 10:30:53 --> Model Class Initialized
INFO - 2016-02-18 10:30:53 --> Model Class Initialized
INFO - 2016-02-18 10:30:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:30:53 --> Pagination Class Initialized
INFO - 2016-02-18 10:30:53 --> Helper loaded: text_helper
INFO - 2016-02-18 10:30:53 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:30:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:30:53 --> Final output sent to browser
DEBUG - 2016-02-18 13:30:53 --> Total execution time: 1.1625
INFO - 2016-02-18 10:41:08 --> Config Class Initialized
INFO - 2016-02-18 10:41:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:41:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:41:08 --> Utf8 Class Initialized
INFO - 2016-02-18 10:41:08 --> URI Class Initialized
DEBUG - 2016-02-18 10:41:08 --> No URI present. Default controller set.
INFO - 2016-02-18 10:41:08 --> Router Class Initialized
INFO - 2016-02-18 10:41:08 --> Output Class Initialized
INFO - 2016-02-18 10:41:08 --> Security Class Initialized
DEBUG - 2016-02-18 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:41:08 --> Input Class Initialized
INFO - 2016-02-18 10:41:08 --> Language Class Initialized
INFO - 2016-02-18 10:41:08 --> Loader Class Initialized
INFO - 2016-02-18 10:41:08 --> Helper loaded: url_helper
INFO - 2016-02-18 10:41:08 --> Helper loaded: file_helper
INFO - 2016-02-18 10:41:08 --> Helper loaded: date_helper
INFO - 2016-02-18 10:41:08 --> Helper loaded: form_helper
INFO - 2016-02-18 10:41:08 --> Database Driver Class Initialized
INFO - 2016-02-18 10:41:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:41:09 --> Controller Class Initialized
INFO - 2016-02-18 10:41:09 --> Model Class Initialized
INFO - 2016-02-18 10:41:09 --> Model Class Initialized
INFO - 2016-02-18 10:41:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:41:09 --> Pagination Class Initialized
INFO - 2016-02-18 10:41:09 --> Helper loaded: text_helper
INFO - 2016-02-18 10:41:09 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:41:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:41:09 --> Final output sent to browser
DEBUG - 2016-02-18 13:41:09 --> Total execution time: 1.1199
INFO - 2016-02-18 10:42:14 --> Config Class Initialized
INFO - 2016-02-18 10:42:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:42:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:42:14 --> Utf8 Class Initialized
INFO - 2016-02-18 10:42:14 --> URI Class Initialized
DEBUG - 2016-02-18 10:42:14 --> No URI present. Default controller set.
INFO - 2016-02-18 10:42:14 --> Router Class Initialized
INFO - 2016-02-18 10:42:14 --> Output Class Initialized
INFO - 2016-02-18 10:42:14 --> Security Class Initialized
DEBUG - 2016-02-18 10:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:42:14 --> Input Class Initialized
INFO - 2016-02-18 10:42:14 --> Language Class Initialized
INFO - 2016-02-18 10:42:14 --> Loader Class Initialized
INFO - 2016-02-18 10:42:14 --> Helper loaded: url_helper
INFO - 2016-02-18 10:42:14 --> Helper loaded: file_helper
INFO - 2016-02-18 10:42:14 --> Helper loaded: date_helper
INFO - 2016-02-18 10:42:14 --> Helper loaded: form_helper
INFO - 2016-02-18 10:42:14 --> Database Driver Class Initialized
INFO - 2016-02-18 10:42:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:42:15 --> Controller Class Initialized
INFO - 2016-02-18 10:42:16 --> Model Class Initialized
INFO - 2016-02-18 10:42:16 --> Model Class Initialized
INFO - 2016-02-18 10:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:42:16 --> Pagination Class Initialized
INFO - 2016-02-18 10:42:16 --> Helper loaded: text_helper
INFO - 2016-02-18 10:42:16 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:42:16 --> Final output sent to browser
DEBUG - 2016-02-18 13:42:16 --> Total execution time: 1.1520
INFO - 2016-02-18 10:44:14 --> Config Class Initialized
INFO - 2016-02-18 10:44:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:44:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:44:14 --> Utf8 Class Initialized
INFO - 2016-02-18 10:44:14 --> URI Class Initialized
DEBUG - 2016-02-18 10:44:14 --> No URI present. Default controller set.
INFO - 2016-02-18 10:44:14 --> Router Class Initialized
INFO - 2016-02-18 10:44:14 --> Output Class Initialized
INFO - 2016-02-18 10:44:14 --> Security Class Initialized
DEBUG - 2016-02-18 10:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:44:14 --> Input Class Initialized
INFO - 2016-02-18 10:44:14 --> Language Class Initialized
INFO - 2016-02-18 10:44:14 --> Loader Class Initialized
INFO - 2016-02-18 10:44:14 --> Helper loaded: url_helper
INFO - 2016-02-18 10:44:14 --> Helper loaded: file_helper
INFO - 2016-02-18 10:44:14 --> Helper loaded: date_helper
INFO - 2016-02-18 10:44:14 --> Helper loaded: form_helper
INFO - 2016-02-18 10:44:14 --> Database Driver Class Initialized
INFO - 2016-02-18 10:44:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:44:15 --> Controller Class Initialized
INFO - 2016-02-18 10:44:15 --> Model Class Initialized
INFO - 2016-02-18 10:44:15 --> Model Class Initialized
INFO - 2016-02-18 10:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:44:15 --> Pagination Class Initialized
INFO - 2016-02-18 10:44:15 --> Helper loaded: text_helper
INFO - 2016-02-18 10:44:15 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:44:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:44:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:44:16 --> Final output sent to browser
DEBUG - 2016-02-18 13:44:16 --> Total execution time: 1.1316
INFO - 2016-02-18 10:46:37 --> Config Class Initialized
INFO - 2016-02-18 10:46:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:46:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:46:37 --> Utf8 Class Initialized
INFO - 2016-02-18 10:46:37 --> URI Class Initialized
DEBUG - 2016-02-18 10:46:37 --> No URI present. Default controller set.
INFO - 2016-02-18 10:46:37 --> Router Class Initialized
INFO - 2016-02-18 10:46:37 --> Output Class Initialized
INFO - 2016-02-18 10:46:37 --> Security Class Initialized
DEBUG - 2016-02-18 10:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:46:37 --> Input Class Initialized
INFO - 2016-02-18 10:46:37 --> Language Class Initialized
INFO - 2016-02-18 10:46:37 --> Loader Class Initialized
INFO - 2016-02-18 10:46:37 --> Helper loaded: url_helper
INFO - 2016-02-18 10:46:37 --> Helper loaded: file_helper
INFO - 2016-02-18 10:46:37 --> Helper loaded: date_helper
INFO - 2016-02-18 10:46:37 --> Helper loaded: form_helper
INFO - 2016-02-18 10:46:37 --> Database Driver Class Initialized
INFO - 2016-02-18 10:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:46:38 --> Controller Class Initialized
INFO - 2016-02-18 10:46:38 --> Model Class Initialized
INFO - 2016-02-18 10:46:38 --> Model Class Initialized
INFO - 2016-02-18 10:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:46:38 --> Pagination Class Initialized
INFO - 2016-02-18 10:46:38 --> Helper loaded: text_helper
INFO - 2016-02-18 10:46:38 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:46:38 --> Final output sent to browser
DEBUG - 2016-02-18 13:46:38 --> Total execution time: 1.1742
INFO - 2016-02-18 10:47:31 --> Config Class Initialized
INFO - 2016-02-18 10:47:31 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:47:31 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:47:31 --> Utf8 Class Initialized
INFO - 2016-02-18 10:47:31 --> URI Class Initialized
DEBUG - 2016-02-18 10:47:31 --> No URI present. Default controller set.
INFO - 2016-02-18 10:47:31 --> Router Class Initialized
INFO - 2016-02-18 10:47:31 --> Output Class Initialized
INFO - 2016-02-18 10:47:31 --> Security Class Initialized
DEBUG - 2016-02-18 10:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:47:31 --> Input Class Initialized
INFO - 2016-02-18 10:47:31 --> Language Class Initialized
INFO - 2016-02-18 10:47:31 --> Loader Class Initialized
INFO - 2016-02-18 10:47:31 --> Helper loaded: url_helper
INFO - 2016-02-18 10:47:31 --> Helper loaded: file_helper
INFO - 2016-02-18 10:47:31 --> Helper loaded: date_helper
INFO - 2016-02-18 10:47:31 --> Helper loaded: form_helper
INFO - 2016-02-18 10:47:31 --> Database Driver Class Initialized
INFO - 2016-02-18 10:47:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:47:32 --> Controller Class Initialized
INFO - 2016-02-18 10:47:32 --> Model Class Initialized
INFO - 2016-02-18 10:47:32 --> Model Class Initialized
INFO - 2016-02-18 10:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:47:32 --> Pagination Class Initialized
INFO - 2016-02-18 10:47:32 --> Helper loaded: text_helper
INFO - 2016-02-18 10:47:32 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:47:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:47:32 --> Final output sent to browser
DEBUG - 2016-02-18 13:47:32 --> Total execution time: 1.1337
INFO - 2016-02-18 10:49:15 --> Config Class Initialized
INFO - 2016-02-18 10:49:15 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:49:15 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:49:15 --> Utf8 Class Initialized
INFO - 2016-02-18 10:49:15 --> URI Class Initialized
DEBUG - 2016-02-18 10:49:15 --> No URI present. Default controller set.
INFO - 2016-02-18 10:49:15 --> Router Class Initialized
INFO - 2016-02-18 10:49:15 --> Output Class Initialized
INFO - 2016-02-18 10:49:15 --> Security Class Initialized
DEBUG - 2016-02-18 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:49:15 --> Input Class Initialized
INFO - 2016-02-18 10:49:15 --> Language Class Initialized
INFO - 2016-02-18 10:49:15 --> Loader Class Initialized
INFO - 2016-02-18 10:49:15 --> Helper loaded: url_helper
INFO - 2016-02-18 10:49:15 --> Helper loaded: file_helper
INFO - 2016-02-18 10:49:15 --> Helper loaded: date_helper
INFO - 2016-02-18 10:49:15 --> Helper loaded: form_helper
INFO - 2016-02-18 10:49:15 --> Database Driver Class Initialized
INFO - 2016-02-18 10:49:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:49:16 --> Controller Class Initialized
INFO - 2016-02-18 10:49:16 --> Model Class Initialized
INFO - 2016-02-18 10:49:16 --> Model Class Initialized
INFO - 2016-02-18 10:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:49:16 --> Pagination Class Initialized
INFO - 2016-02-18 10:49:16 --> Helper loaded: text_helper
INFO - 2016-02-18 10:49:16 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:49:16 --> Final output sent to browser
DEBUG - 2016-02-18 13:49:16 --> Total execution time: 1.1933
INFO - 2016-02-18 10:49:43 --> Config Class Initialized
INFO - 2016-02-18 10:49:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:49:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:49:43 --> Utf8 Class Initialized
INFO - 2016-02-18 10:49:43 --> URI Class Initialized
DEBUG - 2016-02-18 10:49:43 --> No URI present. Default controller set.
INFO - 2016-02-18 10:49:43 --> Router Class Initialized
INFO - 2016-02-18 10:49:43 --> Output Class Initialized
INFO - 2016-02-18 10:49:43 --> Security Class Initialized
DEBUG - 2016-02-18 10:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:49:43 --> Input Class Initialized
INFO - 2016-02-18 10:49:43 --> Language Class Initialized
INFO - 2016-02-18 10:49:43 --> Loader Class Initialized
INFO - 2016-02-18 10:49:43 --> Helper loaded: url_helper
INFO - 2016-02-18 10:49:43 --> Helper loaded: file_helper
INFO - 2016-02-18 10:49:43 --> Helper loaded: date_helper
INFO - 2016-02-18 10:49:43 --> Helper loaded: form_helper
INFO - 2016-02-18 10:49:43 --> Database Driver Class Initialized
INFO - 2016-02-18 10:49:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:49:44 --> Controller Class Initialized
INFO - 2016-02-18 10:49:44 --> Model Class Initialized
INFO - 2016-02-18 10:49:44 --> Model Class Initialized
INFO - 2016-02-18 10:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:49:44 --> Pagination Class Initialized
INFO - 2016-02-18 10:49:44 --> Helper loaded: text_helper
INFO - 2016-02-18 10:49:44 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:49:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:49:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:49:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:49:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:49:44 --> Final output sent to browser
DEBUG - 2016-02-18 13:49:44 --> Total execution time: 1.1371
INFO - 2016-02-18 10:52:25 --> Config Class Initialized
INFO - 2016-02-18 10:52:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:52:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:52:25 --> Utf8 Class Initialized
INFO - 2016-02-18 10:52:25 --> URI Class Initialized
DEBUG - 2016-02-18 10:52:25 --> No URI present. Default controller set.
INFO - 2016-02-18 10:52:25 --> Router Class Initialized
INFO - 2016-02-18 10:52:25 --> Output Class Initialized
INFO - 2016-02-18 10:52:25 --> Security Class Initialized
DEBUG - 2016-02-18 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:52:25 --> Input Class Initialized
INFO - 2016-02-18 10:52:25 --> Language Class Initialized
INFO - 2016-02-18 10:52:25 --> Loader Class Initialized
INFO - 2016-02-18 10:52:25 --> Helper loaded: url_helper
INFO - 2016-02-18 10:52:25 --> Helper loaded: file_helper
INFO - 2016-02-18 10:52:25 --> Helper loaded: date_helper
INFO - 2016-02-18 10:52:25 --> Helper loaded: form_helper
INFO - 2016-02-18 10:52:25 --> Database Driver Class Initialized
INFO - 2016-02-18 10:52:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:52:26 --> Controller Class Initialized
INFO - 2016-02-18 10:52:26 --> Model Class Initialized
INFO - 2016-02-18 10:52:26 --> Model Class Initialized
INFO - 2016-02-18 10:52:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:52:26 --> Pagination Class Initialized
INFO - 2016-02-18 10:52:26 --> Helper loaded: text_helper
INFO - 2016-02-18 10:52:26 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:52:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:52:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:52:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:52:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:52:26 --> Final output sent to browser
DEBUG - 2016-02-18 13:52:26 --> Total execution time: 1.1688
INFO - 2016-02-18 10:52:53 --> Config Class Initialized
INFO - 2016-02-18 10:52:53 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:52:53 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:52:53 --> Utf8 Class Initialized
INFO - 2016-02-18 10:52:53 --> URI Class Initialized
DEBUG - 2016-02-18 10:52:53 --> No URI present. Default controller set.
INFO - 2016-02-18 10:52:53 --> Router Class Initialized
INFO - 2016-02-18 10:52:53 --> Output Class Initialized
INFO - 2016-02-18 10:52:53 --> Security Class Initialized
DEBUG - 2016-02-18 10:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:52:53 --> Input Class Initialized
INFO - 2016-02-18 10:52:53 --> Language Class Initialized
INFO - 2016-02-18 10:52:53 --> Loader Class Initialized
INFO - 2016-02-18 10:52:53 --> Helper loaded: url_helper
INFO - 2016-02-18 10:52:53 --> Helper loaded: file_helper
INFO - 2016-02-18 10:52:53 --> Helper loaded: date_helper
INFO - 2016-02-18 10:52:53 --> Helper loaded: form_helper
INFO - 2016-02-18 10:52:53 --> Database Driver Class Initialized
INFO - 2016-02-18 10:52:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:52:54 --> Controller Class Initialized
INFO - 2016-02-18 10:52:54 --> Model Class Initialized
INFO - 2016-02-18 10:52:54 --> Model Class Initialized
INFO - 2016-02-18 10:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:52:54 --> Pagination Class Initialized
INFO - 2016-02-18 10:52:54 --> Helper loaded: text_helper
INFO - 2016-02-18 10:52:54 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:52:54 --> Final output sent to browser
DEBUG - 2016-02-18 13:52:54 --> Total execution time: 1.1590
INFO - 2016-02-18 10:56:46 --> Config Class Initialized
INFO - 2016-02-18 10:56:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:56:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:56:46 --> Utf8 Class Initialized
INFO - 2016-02-18 10:56:46 --> URI Class Initialized
DEBUG - 2016-02-18 10:56:46 --> No URI present. Default controller set.
INFO - 2016-02-18 10:56:46 --> Router Class Initialized
INFO - 2016-02-18 10:56:46 --> Output Class Initialized
INFO - 2016-02-18 10:56:46 --> Security Class Initialized
DEBUG - 2016-02-18 10:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:56:46 --> Input Class Initialized
INFO - 2016-02-18 10:56:46 --> Language Class Initialized
INFO - 2016-02-18 10:56:46 --> Loader Class Initialized
INFO - 2016-02-18 10:56:46 --> Helper loaded: url_helper
INFO - 2016-02-18 10:56:46 --> Helper loaded: file_helper
INFO - 2016-02-18 10:56:46 --> Helper loaded: date_helper
INFO - 2016-02-18 10:56:46 --> Helper loaded: form_helper
INFO - 2016-02-18 10:56:46 --> Database Driver Class Initialized
INFO - 2016-02-18 10:56:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:56:47 --> Controller Class Initialized
INFO - 2016-02-18 10:56:47 --> Model Class Initialized
INFO - 2016-02-18 10:56:47 --> Model Class Initialized
INFO - 2016-02-18 10:56:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:56:47 --> Pagination Class Initialized
INFO - 2016-02-18 10:56:47 --> Helper loaded: text_helper
INFO - 2016-02-18 10:56:47 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:56:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:56:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:56:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:56:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:56:47 --> Final output sent to browser
DEBUG - 2016-02-18 13:56:47 --> Total execution time: 1.1297
INFO - 2016-02-18 10:57:13 --> Config Class Initialized
INFO - 2016-02-18 10:57:13 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:57:13 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:57:13 --> Utf8 Class Initialized
INFO - 2016-02-18 10:57:13 --> URI Class Initialized
DEBUG - 2016-02-18 10:57:13 --> No URI present. Default controller set.
INFO - 2016-02-18 10:57:13 --> Router Class Initialized
INFO - 2016-02-18 10:57:13 --> Output Class Initialized
INFO - 2016-02-18 10:57:13 --> Security Class Initialized
DEBUG - 2016-02-18 10:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:57:13 --> Input Class Initialized
INFO - 2016-02-18 10:57:13 --> Language Class Initialized
INFO - 2016-02-18 10:57:13 --> Loader Class Initialized
INFO - 2016-02-18 10:57:13 --> Helper loaded: url_helper
INFO - 2016-02-18 10:57:13 --> Helper loaded: file_helper
INFO - 2016-02-18 10:57:13 --> Helper loaded: date_helper
INFO - 2016-02-18 10:57:13 --> Helper loaded: form_helper
INFO - 2016-02-18 10:57:13 --> Database Driver Class Initialized
INFO - 2016-02-18 10:57:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:57:14 --> Controller Class Initialized
INFO - 2016-02-18 10:57:14 --> Model Class Initialized
INFO - 2016-02-18 10:57:14 --> Model Class Initialized
INFO - 2016-02-18 10:57:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:57:14 --> Pagination Class Initialized
INFO - 2016-02-18 10:57:14 --> Helper loaded: text_helper
INFO - 2016-02-18 10:57:14 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:57:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:57:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:57:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:57:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:57:14 --> Final output sent to browser
DEBUG - 2016-02-18 13:57:14 --> Total execution time: 1.1564
INFO - 2016-02-18 10:57:46 --> Config Class Initialized
INFO - 2016-02-18 10:57:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:57:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:57:46 --> Utf8 Class Initialized
INFO - 2016-02-18 10:57:46 --> URI Class Initialized
DEBUG - 2016-02-18 10:57:46 --> No URI present. Default controller set.
INFO - 2016-02-18 10:57:46 --> Router Class Initialized
INFO - 2016-02-18 10:57:46 --> Output Class Initialized
INFO - 2016-02-18 10:57:46 --> Security Class Initialized
DEBUG - 2016-02-18 10:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:57:46 --> Input Class Initialized
INFO - 2016-02-18 10:57:46 --> Language Class Initialized
INFO - 2016-02-18 10:57:46 --> Loader Class Initialized
INFO - 2016-02-18 10:57:46 --> Helper loaded: url_helper
INFO - 2016-02-18 10:57:46 --> Helper loaded: file_helper
INFO - 2016-02-18 10:57:46 --> Helper loaded: date_helper
INFO - 2016-02-18 10:57:46 --> Helper loaded: form_helper
INFO - 2016-02-18 10:57:46 --> Database Driver Class Initialized
INFO - 2016-02-18 10:57:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:57:47 --> Controller Class Initialized
INFO - 2016-02-18 10:57:47 --> Model Class Initialized
INFO - 2016-02-18 10:57:47 --> Model Class Initialized
INFO - 2016-02-18 10:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:57:47 --> Pagination Class Initialized
INFO - 2016-02-18 10:57:47 --> Helper loaded: text_helper
INFO - 2016-02-18 10:57:47 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:57:47 --> Final output sent to browser
DEBUG - 2016-02-18 13:57:47 --> Total execution time: 1.1682
INFO - 2016-02-18 10:59:56 --> Config Class Initialized
INFO - 2016-02-18 10:59:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 10:59:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 10:59:56 --> Utf8 Class Initialized
INFO - 2016-02-18 10:59:56 --> URI Class Initialized
DEBUG - 2016-02-18 10:59:56 --> No URI present. Default controller set.
INFO - 2016-02-18 10:59:56 --> Router Class Initialized
INFO - 2016-02-18 10:59:56 --> Output Class Initialized
INFO - 2016-02-18 10:59:56 --> Security Class Initialized
DEBUG - 2016-02-18 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 10:59:56 --> Input Class Initialized
INFO - 2016-02-18 10:59:56 --> Language Class Initialized
INFO - 2016-02-18 10:59:56 --> Loader Class Initialized
INFO - 2016-02-18 10:59:56 --> Helper loaded: url_helper
INFO - 2016-02-18 10:59:56 --> Helper loaded: file_helper
INFO - 2016-02-18 10:59:56 --> Helper loaded: date_helper
INFO - 2016-02-18 10:59:56 --> Helper loaded: form_helper
INFO - 2016-02-18 10:59:56 --> Database Driver Class Initialized
INFO - 2016-02-18 10:59:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 10:59:57 --> Controller Class Initialized
INFO - 2016-02-18 10:59:57 --> Model Class Initialized
INFO - 2016-02-18 10:59:57 --> Model Class Initialized
INFO - 2016-02-18 10:59:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 10:59:57 --> Pagination Class Initialized
INFO - 2016-02-18 10:59:57 --> Helper loaded: text_helper
INFO - 2016-02-18 10:59:57 --> Helper loaded: cookie_helper
INFO - 2016-02-18 13:59:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 13:59:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 13:59:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 13:59:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 13:59:57 --> Final output sent to browser
DEBUG - 2016-02-18 13:59:57 --> Total execution time: 1.1277
INFO - 2016-02-18 11:00:12 --> Config Class Initialized
INFO - 2016-02-18 11:00:12 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:00:12 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:00:12 --> Utf8 Class Initialized
INFO - 2016-02-18 11:00:12 --> URI Class Initialized
INFO - 2016-02-18 11:00:12 --> Router Class Initialized
INFO - 2016-02-18 11:00:12 --> Output Class Initialized
INFO - 2016-02-18 11:00:12 --> Security Class Initialized
DEBUG - 2016-02-18 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:00:12 --> Input Class Initialized
INFO - 2016-02-18 11:00:12 --> Language Class Initialized
INFO - 2016-02-18 11:00:12 --> Loader Class Initialized
INFO - 2016-02-18 11:00:12 --> Helper loaded: url_helper
INFO - 2016-02-18 11:00:12 --> Helper loaded: file_helper
INFO - 2016-02-18 11:00:12 --> Helper loaded: date_helper
INFO - 2016-02-18 11:00:12 --> Helper loaded: form_helper
INFO - 2016-02-18 11:00:12 --> Database Driver Class Initialized
INFO - 2016-02-18 11:00:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:00:13 --> Controller Class Initialized
INFO - 2016-02-18 11:00:13 --> Model Class Initialized
INFO - 2016-02-18 11:00:13 --> Model Class Initialized
INFO - 2016-02-18 11:00:13 --> Form Validation Class Initialized
INFO - 2016-02-18 11:00:13 --> Helper loaded: text_helper
INFO - 2016-02-18 11:00:14 --> Config Class Initialized
INFO - 2016-02-18 11:00:14 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:00:14 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:00:14 --> Utf8 Class Initialized
INFO - 2016-02-18 11:00:14 --> URI Class Initialized
DEBUG - 2016-02-18 11:00:14 --> No URI present. Default controller set.
INFO - 2016-02-18 11:00:14 --> Router Class Initialized
INFO - 2016-02-18 11:00:14 --> Output Class Initialized
INFO - 2016-02-18 11:00:14 --> Security Class Initialized
DEBUG - 2016-02-18 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:00:14 --> Input Class Initialized
INFO - 2016-02-18 11:00:14 --> Language Class Initialized
INFO - 2016-02-18 11:00:14 --> Loader Class Initialized
INFO - 2016-02-18 11:00:14 --> Helper loaded: url_helper
INFO - 2016-02-18 11:00:14 --> Helper loaded: file_helper
INFO - 2016-02-18 11:00:14 --> Helper loaded: date_helper
INFO - 2016-02-18 11:00:14 --> Helper loaded: form_helper
INFO - 2016-02-18 11:00:14 --> Database Driver Class Initialized
INFO - 2016-02-18 11:00:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:00:15 --> Controller Class Initialized
INFO - 2016-02-18 11:00:15 --> Model Class Initialized
INFO - 2016-02-18 11:00:15 --> Model Class Initialized
INFO - 2016-02-18 11:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:00:15 --> Pagination Class Initialized
INFO - 2016-02-18 11:00:15 --> Helper loaded: text_helper
INFO - 2016-02-18 11:00:15 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:00:15 --> Final output sent to browser
DEBUG - 2016-02-18 14:00:15 --> Total execution time: 1.1774
INFO - 2016-02-18 11:01:42 --> Config Class Initialized
INFO - 2016-02-18 11:01:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:01:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:01:42 --> Utf8 Class Initialized
INFO - 2016-02-18 11:01:42 --> URI Class Initialized
DEBUG - 2016-02-18 11:01:42 --> No URI present. Default controller set.
INFO - 2016-02-18 11:01:42 --> Router Class Initialized
INFO - 2016-02-18 11:01:42 --> Output Class Initialized
INFO - 2016-02-18 11:01:42 --> Security Class Initialized
DEBUG - 2016-02-18 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:01:42 --> Input Class Initialized
INFO - 2016-02-18 11:01:42 --> Language Class Initialized
INFO - 2016-02-18 11:01:42 --> Loader Class Initialized
INFO - 2016-02-18 11:01:42 --> Helper loaded: url_helper
INFO - 2016-02-18 11:01:42 --> Helper loaded: file_helper
INFO - 2016-02-18 11:01:42 --> Helper loaded: date_helper
INFO - 2016-02-18 11:01:42 --> Helper loaded: form_helper
INFO - 2016-02-18 11:01:42 --> Database Driver Class Initialized
INFO - 2016-02-18 11:01:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:01:43 --> Controller Class Initialized
INFO - 2016-02-18 11:01:43 --> Model Class Initialized
INFO - 2016-02-18 11:01:43 --> Model Class Initialized
INFO - 2016-02-18 11:01:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:01:43 --> Pagination Class Initialized
INFO - 2016-02-18 11:01:43 --> Helper loaded: text_helper
INFO - 2016-02-18 11:01:43 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:01:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:01:43 --> Final output sent to browser
DEBUG - 2016-02-18 14:01:43 --> Total execution time: 1.1588
INFO - 2016-02-18 11:01:47 --> Config Class Initialized
INFO - 2016-02-18 11:01:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:01:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:01:47 --> Utf8 Class Initialized
INFO - 2016-02-18 11:01:47 --> URI Class Initialized
INFO - 2016-02-18 11:01:47 --> Router Class Initialized
INFO - 2016-02-18 11:01:47 --> Output Class Initialized
INFO - 2016-02-18 11:01:47 --> Security Class Initialized
DEBUG - 2016-02-18 11:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:01:47 --> Input Class Initialized
INFO - 2016-02-18 11:01:47 --> Language Class Initialized
INFO - 2016-02-18 11:01:47 --> Loader Class Initialized
INFO - 2016-02-18 11:01:47 --> Helper loaded: url_helper
INFO - 2016-02-18 11:01:47 --> Helper loaded: file_helper
INFO - 2016-02-18 11:01:47 --> Helper loaded: date_helper
INFO - 2016-02-18 11:01:47 --> Helper loaded: form_helper
INFO - 2016-02-18 11:01:47 --> Database Driver Class Initialized
INFO - 2016-02-18 11:01:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:01:48 --> Controller Class Initialized
INFO - 2016-02-18 11:01:48 --> Model Class Initialized
INFO - 2016-02-18 11:01:48 --> Model Class Initialized
INFO - 2016-02-18 11:01:48 --> Form Validation Class Initialized
INFO - 2016-02-18 11:01:49 --> Helper loaded: text_helper
INFO - 2016-02-18 11:01:49 --> Config Class Initialized
INFO - 2016-02-18 11:01:49 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:01:49 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:01:49 --> Utf8 Class Initialized
INFO - 2016-02-18 11:01:49 --> URI Class Initialized
INFO - 2016-02-18 11:01:49 --> Router Class Initialized
INFO - 2016-02-18 11:01:49 --> Output Class Initialized
INFO - 2016-02-18 11:01:49 --> Security Class Initialized
DEBUG - 2016-02-18 11:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:01:49 --> Input Class Initialized
INFO - 2016-02-18 11:01:49 --> Language Class Initialized
INFO - 2016-02-18 11:01:49 --> Loader Class Initialized
INFO - 2016-02-18 11:01:49 --> Helper loaded: url_helper
INFO - 2016-02-18 11:01:49 --> Helper loaded: file_helper
INFO - 2016-02-18 11:01:49 --> Helper loaded: date_helper
INFO - 2016-02-18 11:01:49 --> Helper loaded: form_helper
INFO - 2016-02-18 11:01:49 --> Database Driver Class Initialized
INFO - 2016-02-18 11:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:01:50 --> Controller Class Initialized
INFO - 2016-02-18 11:01:50 --> Model Class Initialized
INFO - 2016-02-18 11:01:50 --> Model Class Initialized
INFO - 2016-02-18 11:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:01:50 --> Pagination Class Initialized
INFO - 2016-02-18 11:01:50 --> Helper loaded: text_helper
INFO - 2016-02-18 11:01:50 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:01:50 --> Final output sent to browser
DEBUG - 2016-02-18 14:01:50 --> Total execution time: 1.1741
INFO - 2016-02-18 11:05:30 --> Config Class Initialized
INFO - 2016-02-18 11:05:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:05:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:05:30 --> Utf8 Class Initialized
INFO - 2016-02-18 11:05:30 --> URI Class Initialized
INFO - 2016-02-18 11:05:30 --> Router Class Initialized
INFO - 2016-02-18 11:05:30 --> Output Class Initialized
INFO - 2016-02-18 11:05:30 --> Security Class Initialized
DEBUG - 2016-02-18 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:05:30 --> Input Class Initialized
INFO - 2016-02-18 11:05:30 --> Language Class Initialized
INFO - 2016-02-18 11:05:30 --> Loader Class Initialized
INFO - 2016-02-18 11:05:30 --> Helper loaded: url_helper
INFO - 2016-02-18 11:05:30 --> Helper loaded: file_helper
INFO - 2016-02-18 11:05:30 --> Helper loaded: date_helper
INFO - 2016-02-18 11:05:30 --> Helper loaded: form_helper
INFO - 2016-02-18 11:05:30 --> Database Driver Class Initialized
INFO - 2016-02-18 11:05:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:05:31 --> Controller Class Initialized
INFO - 2016-02-18 11:05:31 --> Model Class Initialized
INFO - 2016-02-18 11:05:31 --> Model Class Initialized
INFO - 2016-02-18 11:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:05:31 --> Pagination Class Initialized
INFO - 2016-02-18 11:05:31 --> Helper loaded: text_helper
INFO - 2016-02-18 11:05:31 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:05:31 --> Final output sent to browser
DEBUG - 2016-02-18 14:05:31 --> Total execution time: 1.1770
INFO - 2016-02-18 11:06:15 --> Config Class Initialized
INFO - 2016-02-18 11:06:15 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:06:15 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:06:15 --> Utf8 Class Initialized
INFO - 2016-02-18 11:06:15 --> URI Class Initialized
INFO - 2016-02-18 11:06:15 --> Router Class Initialized
INFO - 2016-02-18 11:06:15 --> Output Class Initialized
INFO - 2016-02-18 11:06:15 --> Security Class Initialized
DEBUG - 2016-02-18 11:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:06:15 --> Input Class Initialized
INFO - 2016-02-18 11:06:15 --> Language Class Initialized
INFO - 2016-02-18 11:06:15 --> Loader Class Initialized
INFO - 2016-02-18 11:06:15 --> Helper loaded: url_helper
INFO - 2016-02-18 11:06:15 --> Helper loaded: file_helper
INFO - 2016-02-18 11:06:15 --> Helper loaded: date_helper
INFO - 2016-02-18 11:06:15 --> Helper loaded: form_helper
INFO - 2016-02-18 11:06:15 --> Database Driver Class Initialized
INFO - 2016-02-18 11:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:06:16 --> Controller Class Initialized
INFO - 2016-02-18 11:06:16 --> Model Class Initialized
INFO - 2016-02-18 11:06:16 --> Model Class Initialized
INFO - 2016-02-18 11:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:06:16 --> Pagination Class Initialized
INFO - 2016-02-18 11:06:16 --> Helper loaded: text_helper
INFO - 2016-02-18 11:06:16 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:06:16 --> Final output sent to browser
DEBUG - 2016-02-18 14:06:16 --> Total execution time: 1.1293
INFO - 2016-02-18 11:06:17 --> Config Class Initialized
INFO - 2016-02-18 11:06:17 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:06:17 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:06:17 --> Utf8 Class Initialized
INFO - 2016-02-18 11:06:17 --> URI Class Initialized
DEBUG - 2016-02-18 11:06:17 --> No URI present. Default controller set.
INFO - 2016-02-18 11:06:17 --> Router Class Initialized
INFO - 2016-02-18 11:06:17 --> Output Class Initialized
INFO - 2016-02-18 11:06:17 --> Security Class Initialized
DEBUG - 2016-02-18 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:06:17 --> Input Class Initialized
INFO - 2016-02-18 11:06:17 --> Language Class Initialized
INFO - 2016-02-18 11:06:17 --> Loader Class Initialized
INFO - 2016-02-18 11:06:17 --> Helper loaded: url_helper
INFO - 2016-02-18 11:06:17 --> Helper loaded: file_helper
INFO - 2016-02-18 11:06:17 --> Helper loaded: date_helper
INFO - 2016-02-18 11:06:17 --> Helper loaded: form_helper
INFO - 2016-02-18 11:06:17 --> Database Driver Class Initialized
INFO - 2016-02-18 11:06:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:06:18 --> Controller Class Initialized
INFO - 2016-02-18 11:06:18 --> Model Class Initialized
INFO - 2016-02-18 11:06:18 --> Model Class Initialized
INFO - 2016-02-18 11:06:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:06:18 --> Pagination Class Initialized
INFO - 2016-02-18 11:06:18 --> Helper loaded: text_helper
INFO - 2016-02-18 11:06:18 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:06:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:06:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:06:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:06:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:06:18 --> Final output sent to browser
DEBUG - 2016-02-18 14:06:18 --> Total execution time: 1.1119
INFO - 2016-02-18 11:06:25 --> Config Class Initialized
INFO - 2016-02-18 11:06:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:06:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:06:25 --> Utf8 Class Initialized
INFO - 2016-02-18 11:06:25 --> URI Class Initialized
INFO - 2016-02-18 11:06:25 --> Router Class Initialized
INFO - 2016-02-18 11:06:25 --> Output Class Initialized
INFO - 2016-02-18 11:06:25 --> Security Class Initialized
DEBUG - 2016-02-18 11:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:06:25 --> Input Class Initialized
INFO - 2016-02-18 11:06:25 --> Language Class Initialized
INFO - 2016-02-18 11:06:25 --> Loader Class Initialized
INFO - 2016-02-18 11:06:25 --> Helper loaded: url_helper
INFO - 2016-02-18 11:06:25 --> Helper loaded: file_helper
INFO - 2016-02-18 11:06:25 --> Helper loaded: date_helper
INFO - 2016-02-18 11:06:25 --> Helper loaded: form_helper
INFO - 2016-02-18 11:06:25 --> Database Driver Class Initialized
INFO - 2016-02-18 11:06:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:06:26 --> Controller Class Initialized
INFO - 2016-02-18 11:06:26 --> Model Class Initialized
INFO - 2016-02-18 11:06:26 --> Model Class Initialized
INFO - 2016-02-18 11:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:06:26 --> Pagination Class Initialized
INFO - 2016-02-18 11:06:26 --> Helper loaded: text_helper
INFO - 2016-02-18 11:06:26 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:06:26 --> Form Validation Class Initialized
INFO - 2016-02-18 14:06:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 14:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 14:06:26 --> Final output sent to browser
DEBUG - 2016-02-18 14:06:26 --> Total execution time: 1.2327
INFO - 2016-02-18 11:06:28 --> Config Class Initialized
INFO - 2016-02-18 11:06:28 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:06:28 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:06:28 --> Utf8 Class Initialized
INFO - 2016-02-18 11:06:28 --> URI Class Initialized
DEBUG - 2016-02-18 11:06:28 --> No URI present. Default controller set.
INFO - 2016-02-18 11:06:28 --> Router Class Initialized
INFO - 2016-02-18 11:06:28 --> Output Class Initialized
INFO - 2016-02-18 11:06:28 --> Security Class Initialized
DEBUG - 2016-02-18 11:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:06:28 --> Input Class Initialized
INFO - 2016-02-18 11:06:28 --> Language Class Initialized
INFO - 2016-02-18 11:06:28 --> Loader Class Initialized
INFO - 2016-02-18 11:06:28 --> Helper loaded: url_helper
INFO - 2016-02-18 11:06:28 --> Helper loaded: file_helper
INFO - 2016-02-18 11:06:28 --> Helper loaded: date_helper
INFO - 2016-02-18 11:06:28 --> Helper loaded: form_helper
INFO - 2016-02-18 11:06:28 --> Database Driver Class Initialized
INFO - 2016-02-18 11:06:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:06:29 --> Controller Class Initialized
INFO - 2016-02-18 11:06:29 --> Model Class Initialized
INFO - 2016-02-18 11:06:29 --> Model Class Initialized
INFO - 2016-02-18 11:06:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:06:29 --> Pagination Class Initialized
INFO - 2016-02-18 11:06:29 --> Helper loaded: text_helper
INFO - 2016-02-18 11:06:29 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:06:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:06:29 --> Final output sent to browser
DEBUG - 2016-02-18 14:06:29 --> Total execution time: 1.1433
INFO - 2016-02-18 11:10:09 --> Config Class Initialized
INFO - 2016-02-18 11:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:10:09 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:10:09 --> Utf8 Class Initialized
INFO - 2016-02-18 11:10:09 --> URI Class Initialized
INFO - 2016-02-18 11:10:09 --> Router Class Initialized
INFO - 2016-02-18 11:10:09 --> Output Class Initialized
INFO - 2016-02-18 11:10:09 --> Security Class Initialized
DEBUG - 2016-02-18 11:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:10:09 --> Input Class Initialized
INFO - 2016-02-18 11:10:09 --> Language Class Initialized
INFO - 2016-02-18 11:10:09 --> Loader Class Initialized
INFO - 2016-02-18 11:10:09 --> Helper loaded: url_helper
INFO - 2016-02-18 11:10:09 --> Helper loaded: file_helper
INFO - 2016-02-18 11:10:09 --> Helper loaded: date_helper
INFO - 2016-02-18 11:10:09 --> Helper loaded: form_helper
INFO - 2016-02-18 11:10:09 --> Database Driver Class Initialized
INFO - 2016-02-18 11:10:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:10:10 --> Controller Class Initialized
INFO - 2016-02-18 11:10:10 --> Model Class Initialized
INFO - 2016-02-18 11:10:10 --> Model Class Initialized
INFO - 2016-02-18 11:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:10:10 --> Pagination Class Initialized
INFO - 2016-02-18 11:10:10 --> Helper loaded: text_helper
INFO - 2016-02-18 11:10:10 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:10:10 --> Final output sent to browser
DEBUG - 2016-02-18 14:10:10 --> Total execution time: 1.2038
INFO - 2016-02-18 11:10:15 --> Config Class Initialized
INFO - 2016-02-18 11:10:15 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:10:15 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:10:15 --> Utf8 Class Initialized
INFO - 2016-02-18 11:10:15 --> URI Class Initialized
INFO - 2016-02-18 11:10:15 --> Router Class Initialized
INFO - 2016-02-18 11:10:15 --> Output Class Initialized
INFO - 2016-02-18 11:10:15 --> Security Class Initialized
DEBUG - 2016-02-18 11:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:10:15 --> Input Class Initialized
INFO - 2016-02-18 11:10:15 --> Language Class Initialized
INFO - 2016-02-18 11:10:15 --> Loader Class Initialized
INFO - 2016-02-18 11:10:15 --> Helper loaded: url_helper
INFO - 2016-02-18 11:10:15 --> Helper loaded: file_helper
INFO - 2016-02-18 11:10:15 --> Helper loaded: date_helper
INFO - 2016-02-18 11:10:15 --> Helper loaded: form_helper
INFO - 2016-02-18 11:10:15 --> Database Driver Class Initialized
INFO - 2016-02-18 11:10:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:10:16 --> Controller Class Initialized
INFO - 2016-02-18 11:10:16 --> Model Class Initialized
INFO - 2016-02-18 11:10:16 --> Model Class Initialized
INFO - 2016-02-18 11:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:10:16 --> Pagination Class Initialized
INFO - 2016-02-18 11:10:16 --> Helper loaded: text_helper
INFO - 2016-02-18 11:10:16 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:10:16 --> Final output sent to browser
DEBUG - 2016-02-18 14:10:16 --> Total execution time: 1.1294
INFO - 2016-02-18 11:11:36 --> Config Class Initialized
INFO - 2016-02-18 11:11:36 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:11:36 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:11:36 --> Utf8 Class Initialized
INFO - 2016-02-18 11:11:36 --> URI Class Initialized
INFO - 2016-02-18 11:11:36 --> Router Class Initialized
INFO - 2016-02-18 11:11:36 --> Output Class Initialized
INFO - 2016-02-18 11:11:36 --> Security Class Initialized
DEBUG - 2016-02-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:11:36 --> Input Class Initialized
INFO - 2016-02-18 11:11:36 --> Language Class Initialized
INFO - 2016-02-18 11:11:36 --> Loader Class Initialized
INFO - 2016-02-18 11:11:36 --> Helper loaded: url_helper
INFO - 2016-02-18 11:11:36 --> Helper loaded: file_helper
INFO - 2016-02-18 11:11:36 --> Helper loaded: date_helper
INFO - 2016-02-18 11:11:36 --> Helper loaded: form_helper
INFO - 2016-02-18 11:11:36 --> Database Driver Class Initialized
INFO - 2016-02-18 11:11:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:11:37 --> Controller Class Initialized
INFO - 2016-02-18 11:11:37 --> Model Class Initialized
INFO - 2016-02-18 11:11:37 --> Model Class Initialized
INFO - 2016-02-18 11:11:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:11:37 --> Pagination Class Initialized
INFO - 2016-02-18 11:11:37 --> Helper loaded: text_helper
INFO - 2016-02-18 11:11:37 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:11:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:11:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:11:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:11:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:11:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:11:37 --> Final output sent to browser
DEBUG - 2016-02-18 14:11:37 --> Total execution time: 1.2223
INFO - 2016-02-18 11:11:45 --> Config Class Initialized
INFO - 2016-02-18 11:11:45 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:11:45 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:11:45 --> Utf8 Class Initialized
INFO - 2016-02-18 11:11:45 --> URI Class Initialized
INFO - 2016-02-18 11:11:45 --> Router Class Initialized
INFO - 2016-02-18 11:11:45 --> Output Class Initialized
INFO - 2016-02-18 11:11:45 --> Security Class Initialized
DEBUG - 2016-02-18 11:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:11:45 --> Input Class Initialized
INFO - 2016-02-18 11:11:45 --> Language Class Initialized
INFO - 2016-02-18 11:11:45 --> Loader Class Initialized
INFO - 2016-02-18 11:11:45 --> Helper loaded: url_helper
INFO - 2016-02-18 11:11:45 --> Helper loaded: file_helper
INFO - 2016-02-18 11:11:45 --> Helper loaded: date_helper
INFO - 2016-02-18 11:11:45 --> Helper loaded: form_helper
INFO - 2016-02-18 11:11:45 --> Database Driver Class Initialized
INFO - 2016-02-18 11:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:11:46 --> Controller Class Initialized
INFO - 2016-02-18 11:11:46 --> Model Class Initialized
INFO - 2016-02-18 11:11:46 --> Model Class Initialized
INFO - 2016-02-18 11:11:46 --> Form Validation Class Initialized
INFO - 2016-02-18 11:11:46 --> Helper loaded: text_helper
INFO - 2016-02-18 11:11:46 --> Final output sent to browser
DEBUG - 2016-02-18 11:11:46 --> Total execution time: 1.1786
INFO - 2016-02-18 11:11:48 --> Config Class Initialized
INFO - 2016-02-18 11:11:48 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:11:48 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:11:48 --> Utf8 Class Initialized
INFO - 2016-02-18 11:11:48 --> URI Class Initialized
INFO - 2016-02-18 11:11:48 --> Router Class Initialized
INFO - 2016-02-18 11:11:48 --> Output Class Initialized
INFO - 2016-02-18 11:11:48 --> Security Class Initialized
DEBUG - 2016-02-18 11:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:11:48 --> Input Class Initialized
INFO - 2016-02-18 11:11:48 --> Language Class Initialized
INFO - 2016-02-18 11:11:48 --> Loader Class Initialized
INFO - 2016-02-18 11:11:48 --> Helper loaded: url_helper
INFO - 2016-02-18 11:11:48 --> Helper loaded: file_helper
INFO - 2016-02-18 11:11:48 --> Helper loaded: date_helper
INFO - 2016-02-18 11:11:48 --> Helper loaded: form_helper
INFO - 2016-02-18 11:11:48 --> Database Driver Class Initialized
INFO - 2016-02-18 11:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:11:49 --> Controller Class Initialized
INFO - 2016-02-18 11:11:49 --> Model Class Initialized
INFO - 2016-02-18 11:11:49 --> Model Class Initialized
INFO - 2016-02-18 11:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:11:49 --> Pagination Class Initialized
INFO - 2016-02-18 11:11:49 --> Helper loaded: text_helper
INFO - 2016-02-18 11:11:49 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:11:49 --> Final output sent to browser
DEBUG - 2016-02-18 14:11:49 --> Total execution time: 1.2262
INFO - 2016-02-18 11:11:56 --> Config Class Initialized
INFO - 2016-02-18 11:11:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:11:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:11:56 --> Utf8 Class Initialized
INFO - 2016-02-18 11:11:56 --> URI Class Initialized
INFO - 2016-02-18 11:11:56 --> Router Class Initialized
INFO - 2016-02-18 11:11:56 --> Output Class Initialized
INFO - 2016-02-18 11:11:56 --> Security Class Initialized
DEBUG - 2016-02-18 11:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:11:56 --> Input Class Initialized
INFO - 2016-02-18 11:11:56 --> Language Class Initialized
INFO - 2016-02-18 11:11:56 --> Loader Class Initialized
INFO - 2016-02-18 11:11:56 --> Helper loaded: url_helper
INFO - 2016-02-18 11:11:56 --> Helper loaded: file_helper
INFO - 2016-02-18 11:11:56 --> Helper loaded: date_helper
INFO - 2016-02-18 11:11:56 --> Helper loaded: form_helper
INFO - 2016-02-18 11:11:57 --> Database Driver Class Initialized
INFO - 2016-02-18 11:11:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:11:58 --> Controller Class Initialized
INFO - 2016-02-18 11:11:58 --> Model Class Initialized
INFO - 2016-02-18 11:11:58 --> Model Class Initialized
INFO - 2016-02-18 11:11:58 --> Form Validation Class Initialized
INFO - 2016-02-18 11:11:58 --> Helper loaded: text_helper
INFO - 2016-02-18 11:11:58 --> Final output sent to browser
DEBUG - 2016-02-18 11:11:58 --> Total execution time: 1.1039
INFO - 2016-02-18 11:12:37 --> Config Class Initialized
INFO - 2016-02-18 11:12:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:12:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:12:37 --> Utf8 Class Initialized
INFO - 2016-02-18 11:12:37 --> URI Class Initialized
INFO - 2016-02-18 11:12:37 --> Router Class Initialized
INFO - 2016-02-18 11:12:37 --> Output Class Initialized
INFO - 2016-02-18 11:12:37 --> Security Class Initialized
DEBUG - 2016-02-18 11:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:12:37 --> Input Class Initialized
INFO - 2016-02-18 11:12:37 --> Language Class Initialized
INFO - 2016-02-18 11:12:37 --> Loader Class Initialized
INFO - 2016-02-18 11:12:37 --> Helper loaded: url_helper
INFO - 2016-02-18 11:12:37 --> Helper loaded: file_helper
INFO - 2016-02-18 11:12:37 --> Helper loaded: date_helper
INFO - 2016-02-18 11:12:37 --> Helper loaded: form_helper
INFO - 2016-02-18 11:12:37 --> Database Driver Class Initialized
INFO - 2016-02-18 11:12:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:12:38 --> Controller Class Initialized
INFO - 2016-02-18 11:12:38 --> Model Class Initialized
INFO - 2016-02-18 11:12:38 --> Model Class Initialized
INFO - 2016-02-18 11:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:12:38 --> Pagination Class Initialized
INFO - 2016-02-18 11:12:38 --> Helper loaded: text_helper
INFO - 2016-02-18 11:12:38 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:12:38 --> Final output sent to browser
DEBUG - 2016-02-18 14:12:38 --> Total execution time: 1.1822
INFO - 2016-02-18 11:14:32 --> Config Class Initialized
INFO - 2016-02-18 11:14:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:14:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:14:32 --> Utf8 Class Initialized
INFO - 2016-02-18 11:14:32 --> URI Class Initialized
INFO - 2016-02-18 11:14:32 --> Router Class Initialized
INFO - 2016-02-18 11:14:32 --> Output Class Initialized
INFO - 2016-02-18 11:14:32 --> Security Class Initialized
DEBUG - 2016-02-18 11:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:14:32 --> Input Class Initialized
INFO - 2016-02-18 11:14:33 --> Language Class Initialized
INFO - 2016-02-18 11:14:33 --> Loader Class Initialized
INFO - 2016-02-18 11:14:33 --> Helper loaded: url_helper
INFO - 2016-02-18 11:14:33 --> Helper loaded: file_helper
INFO - 2016-02-18 11:14:33 --> Helper loaded: date_helper
INFO - 2016-02-18 11:14:33 --> Helper loaded: form_helper
INFO - 2016-02-18 11:14:33 --> Database Driver Class Initialized
INFO - 2016-02-18 11:14:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:14:34 --> Controller Class Initialized
INFO - 2016-02-18 11:14:34 --> Model Class Initialized
INFO - 2016-02-18 11:14:34 --> Model Class Initialized
INFO - 2016-02-18 11:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:14:34 --> Pagination Class Initialized
INFO - 2016-02-18 11:14:34 --> Helper loaded: text_helper
INFO - 2016-02-18 11:14:34 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:14:34 --> Final output sent to browser
DEBUG - 2016-02-18 14:14:34 --> Total execution time: 1.2276
INFO - 2016-02-18 11:14:58 --> Config Class Initialized
INFO - 2016-02-18 11:14:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:14:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:14:58 --> Utf8 Class Initialized
INFO - 2016-02-18 11:14:58 --> URI Class Initialized
INFO - 2016-02-18 11:14:58 --> Router Class Initialized
INFO - 2016-02-18 11:14:58 --> Output Class Initialized
INFO - 2016-02-18 11:14:58 --> Security Class Initialized
DEBUG - 2016-02-18 11:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:14:58 --> Input Class Initialized
INFO - 2016-02-18 11:14:58 --> Language Class Initialized
INFO - 2016-02-18 11:14:58 --> Loader Class Initialized
INFO - 2016-02-18 11:14:58 --> Helper loaded: url_helper
INFO - 2016-02-18 11:14:58 --> Helper loaded: file_helper
INFO - 2016-02-18 11:14:58 --> Helper loaded: date_helper
INFO - 2016-02-18 11:14:58 --> Helper loaded: form_helper
INFO - 2016-02-18 11:14:58 --> Database Driver Class Initialized
INFO - 2016-02-18 11:14:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:14:59 --> Controller Class Initialized
INFO - 2016-02-18 11:14:59 --> Model Class Initialized
INFO - 2016-02-18 11:14:59 --> Model Class Initialized
INFO - 2016-02-18 11:14:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:14:59 --> Pagination Class Initialized
INFO - 2016-02-18 11:14:59 --> Helper loaded: text_helper
INFO - 2016-02-18 11:14:59 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:14:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:14:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:14:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:14:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:14:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:14:59 --> Final output sent to browser
DEBUG - 2016-02-18 14:14:59 --> Total execution time: 1.2068
INFO - 2016-02-18 11:16:46 --> Config Class Initialized
INFO - 2016-02-18 11:16:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:16:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:16:46 --> Utf8 Class Initialized
INFO - 2016-02-18 11:16:46 --> URI Class Initialized
DEBUG - 2016-02-18 11:16:46 --> No URI present. Default controller set.
INFO - 2016-02-18 11:16:46 --> Router Class Initialized
INFO - 2016-02-18 11:16:46 --> Output Class Initialized
INFO - 2016-02-18 11:16:46 --> Security Class Initialized
DEBUG - 2016-02-18 11:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:16:46 --> Input Class Initialized
INFO - 2016-02-18 11:16:46 --> Language Class Initialized
INFO - 2016-02-18 11:16:46 --> Loader Class Initialized
INFO - 2016-02-18 11:16:46 --> Helper loaded: url_helper
INFO - 2016-02-18 11:16:46 --> Helper loaded: file_helper
INFO - 2016-02-18 11:16:46 --> Helper loaded: date_helper
INFO - 2016-02-18 11:16:46 --> Helper loaded: form_helper
INFO - 2016-02-18 11:16:46 --> Database Driver Class Initialized
INFO - 2016-02-18 11:16:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:16:47 --> Controller Class Initialized
INFO - 2016-02-18 11:16:47 --> Model Class Initialized
INFO - 2016-02-18 11:16:47 --> Model Class Initialized
INFO - 2016-02-18 11:16:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:16:47 --> Pagination Class Initialized
INFO - 2016-02-18 11:16:47 --> Helper loaded: text_helper
INFO - 2016-02-18 11:16:47 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:16:47 --> Final output sent to browser
DEBUG - 2016-02-18 14:16:47 --> Total execution time: 1.1600
INFO - 2016-02-18 11:18:39 --> Config Class Initialized
INFO - 2016-02-18 11:18:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:18:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:18:39 --> Utf8 Class Initialized
INFO - 2016-02-18 11:18:39 --> URI Class Initialized
DEBUG - 2016-02-18 11:18:39 --> No URI present. Default controller set.
INFO - 2016-02-18 11:18:39 --> Router Class Initialized
INFO - 2016-02-18 11:18:39 --> Output Class Initialized
INFO - 2016-02-18 11:18:39 --> Security Class Initialized
DEBUG - 2016-02-18 11:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:18:39 --> Input Class Initialized
INFO - 2016-02-18 11:18:39 --> Language Class Initialized
INFO - 2016-02-18 11:18:39 --> Loader Class Initialized
INFO - 2016-02-18 11:18:39 --> Helper loaded: url_helper
INFO - 2016-02-18 11:18:39 --> Helper loaded: file_helper
INFO - 2016-02-18 11:18:39 --> Helper loaded: date_helper
INFO - 2016-02-18 11:18:39 --> Helper loaded: form_helper
INFO - 2016-02-18 11:18:39 --> Database Driver Class Initialized
INFO - 2016-02-18 11:18:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:18:40 --> Controller Class Initialized
INFO - 2016-02-18 11:18:40 --> Model Class Initialized
INFO - 2016-02-18 11:18:40 --> Model Class Initialized
INFO - 2016-02-18 11:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:18:40 --> Pagination Class Initialized
INFO - 2016-02-18 11:18:40 --> Helper loaded: text_helper
INFO - 2016-02-18 11:18:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:18:40 --> Final output sent to browser
DEBUG - 2016-02-18 14:18:40 --> Total execution time: 1.1458
INFO - 2016-02-18 11:33:03 --> Config Class Initialized
INFO - 2016-02-18 11:33:03 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:33:03 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:33:03 --> Utf8 Class Initialized
INFO - 2016-02-18 11:33:03 --> URI Class Initialized
DEBUG - 2016-02-18 11:33:03 --> No URI present. Default controller set.
INFO - 2016-02-18 11:33:03 --> Router Class Initialized
INFO - 2016-02-18 11:33:03 --> Output Class Initialized
INFO - 2016-02-18 11:33:03 --> Security Class Initialized
DEBUG - 2016-02-18 11:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:33:03 --> Input Class Initialized
INFO - 2016-02-18 11:33:03 --> Language Class Initialized
INFO - 2016-02-18 11:33:03 --> Loader Class Initialized
INFO - 2016-02-18 11:33:03 --> Helper loaded: url_helper
INFO - 2016-02-18 11:33:03 --> Helper loaded: file_helper
INFO - 2016-02-18 11:33:03 --> Helper loaded: date_helper
INFO - 2016-02-18 11:33:03 --> Helper loaded: form_helper
INFO - 2016-02-18 11:33:03 --> Database Driver Class Initialized
INFO - 2016-02-18 11:33:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:33:05 --> Controller Class Initialized
INFO - 2016-02-18 11:33:05 --> Model Class Initialized
INFO - 2016-02-18 11:33:05 --> Model Class Initialized
INFO - 2016-02-18 11:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:33:05 --> Pagination Class Initialized
INFO - 2016-02-18 11:33:05 --> Helper loaded: text_helper
INFO - 2016-02-18 11:33:05 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:33:05 --> Final output sent to browser
DEBUG - 2016-02-18 14:33:05 --> Total execution time: 1.1315
INFO - 2016-02-18 11:37:30 --> Config Class Initialized
INFO - 2016-02-18 11:37:30 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:37:30 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:37:30 --> Utf8 Class Initialized
INFO - 2016-02-18 11:37:30 --> URI Class Initialized
INFO - 2016-02-18 11:37:30 --> Router Class Initialized
INFO - 2016-02-18 11:37:30 --> Output Class Initialized
INFO - 2016-02-18 11:37:30 --> Security Class Initialized
DEBUG - 2016-02-18 11:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:37:30 --> Input Class Initialized
INFO - 2016-02-18 11:37:30 --> Language Class Initialized
INFO - 2016-02-18 11:37:30 --> Loader Class Initialized
INFO - 2016-02-18 11:37:30 --> Helper loaded: url_helper
INFO - 2016-02-18 11:37:30 --> Helper loaded: file_helper
INFO - 2016-02-18 11:37:30 --> Helper loaded: date_helper
INFO - 2016-02-18 11:37:30 --> Helper loaded: form_helper
INFO - 2016-02-18 11:37:30 --> Database Driver Class Initialized
INFO - 2016-02-18 11:37:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:37:31 --> Controller Class Initialized
INFO - 2016-02-18 11:37:31 --> Model Class Initialized
INFO - 2016-02-18 11:37:31 --> Model Class Initialized
INFO - 2016-02-18 11:37:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:37:31 --> Pagination Class Initialized
INFO - 2016-02-18 11:37:31 --> Helper loaded: text_helper
INFO - 2016-02-18 11:37:31 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 14:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:37:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:37:31 --> Final output sent to browser
DEBUG - 2016-02-18 14:37:31 --> Total execution time: 1.2106
INFO - 2016-02-18 11:40:27 --> Config Class Initialized
INFO - 2016-02-18 11:40:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:40:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:40:27 --> Utf8 Class Initialized
INFO - 2016-02-18 11:40:27 --> URI Class Initialized
DEBUG - 2016-02-18 11:40:27 --> No URI present. Default controller set.
INFO - 2016-02-18 11:40:27 --> Router Class Initialized
INFO - 2016-02-18 11:40:27 --> Output Class Initialized
INFO - 2016-02-18 11:40:27 --> Security Class Initialized
DEBUG - 2016-02-18 11:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:40:27 --> Input Class Initialized
INFO - 2016-02-18 11:40:27 --> Language Class Initialized
INFO - 2016-02-18 11:40:27 --> Loader Class Initialized
INFO - 2016-02-18 11:40:27 --> Helper loaded: url_helper
INFO - 2016-02-18 11:40:27 --> Helper loaded: file_helper
INFO - 2016-02-18 11:40:27 --> Helper loaded: date_helper
INFO - 2016-02-18 11:40:27 --> Helper loaded: form_helper
INFO - 2016-02-18 11:40:27 --> Database Driver Class Initialized
INFO - 2016-02-18 11:40:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:40:28 --> Controller Class Initialized
INFO - 2016-02-18 11:40:28 --> Model Class Initialized
INFO - 2016-02-18 11:40:28 --> Model Class Initialized
INFO - 2016-02-18 11:40:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:40:28 --> Pagination Class Initialized
INFO - 2016-02-18 11:40:28 --> Helper loaded: text_helper
INFO - 2016-02-18 11:40:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:40:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:40:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:40:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:40:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:40:28 --> Final output sent to browser
DEBUG - 2016-02-18 14:40:28 --> Total execution time: 1.1148
INFO - 2016-02-18 11:42:58 --> Config Class Initialized
INFO - 2016-02-18 11:42:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:42:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:42:58 --> Utf8 Class Initialized
INFO - 2016-02-18 11:42:58 --> URI Class Initialized
DEBUG - 2016-02-18 11:42:58 --> No URI present. Default controller set.
INFO - 2016-02-18 11:42:58 --> Router Class Initialized
INFO - 2016-02-18 11:42:58 --> Output Class Initialized
INFO - 2016-02-18 11:42:58 --> Security Class Initialized
DEBUG - 2016-02-18 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:42:58 --> Input Class Initialized
INFO - 2016-02-18 11:42:58 --> Language Class Initialized
INFO - 2016-02-18 11:42:58 --> Loader Class Initialized
INFO - 2016-02-18 11:42:58 --> Helper loaded: url_helper
INFO - 2016-02-18 11:42:58 --> Helper loaded: file_helper
INFO - 2016-02-18 11:42:58 --> Helper loaded: date_helper
INFO - 2016-02-18 11:42:58 --> Helper loaded: form_helper
INFO - 2016-02-18 11:42:58 --> Database Driver Class Initialized
INFO - 2016-02-18 11:42:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:42:59 --> Controller Class Initialized
INFO - 2016-02-18 11:42:59 --> Model Class Initialized
INFO - 2016-02-18 11:42:59 --> Model Class Initialized
INFO - 2016-02-18 11:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:42:59 --> Pagination Class Initialized
INFO - 2016-02-18 11:42:59 --> Helper loaded: text_helper
INFO - 2016-02-18 11:42:59 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-18 14:42:59 --> Severity: Notice --> Undefined variable: entry C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 21
ERROR - 2016-02-18 14:42:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 21
INFO - 2016-02-18 14:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:42:59 --> Final output sent to browser
DEBUG - 2016-02-18 14:42:59 --> Total execution time: 1.1671
INFO - 2016-02-18 11:43:39 --> Config Class Initialized
INFO - 2016-02-18 11:43:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:43:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:43:39 --> Utf8 Class Initialized
INFO - 2016-02-18 11:43:39 --> URI Class Initialized
DEBUG - 2016-02-18 11:43:39 --> No URI present. Default controller set.
INFO - 2016-02-18 11:43:39 --> Router Class Initialized
INFO - 2016-02-18 11:43:39 --> Output Class Initialized
INFO - 2016-02-18 11:43:39 --> Security Class Initialized
DEBUG - 2016-02-18 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:43:39 --> Input Class Initialized
INFO - 2016-02-18 11:43:39 --> Language Class Initialized
INFO - 2016-02-18 11:43:39 --> Loader Class Initialized
INFO - 2016-02-18 11:43:39 --> Helper loaded: url_helper
INFO - 2016-02-18 11:43:39 --> Helper loaded: file_helper
INFO - 2016-02-18 11:43:39 --> Helper loaded: date_helper
INFO - 2016-02-18 11:43:39 --> Helper loaded: form_helper
INFO - 2016-02-18 11:43:39 --> Database Driver Class Initialized
INFO - 2016-02-18 11:43:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:43:40 --> Controller Class Initialized
INFO - 2016-02-18 11:43:40 --> Model Class Initialized
INFO - 2016-02-18 11:43:40 --> Model Class Initialized
INFO - 2016-02-18 11:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:43:40 --> Pagination Class Initialized
INFO - 2016-02-18 11:43:40 --> Helper loaded: text_helper
INFO - 2016-02-18 11:43:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:43:40 --> Final output sent to browser
DEBUG - 2016-02-18 14:43:40 --> Total execution time: 1.1291
INFO - 2016-02-18 11:43:42 --> Config Class Initialized
INFO - 2016-02-18 11:43:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:43:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:43:42 --> Utf8 Class Initialized
INFO - 2016-02-18 11:43:42 --> URI Class Initialized
INFO - 2016-02-18 11:43:42 --> Router Class Initialized
INFO - 2016-02-18 11:43:42 --> Output Class Initialized
INFO - 2016-02-18 11:43:42 --> Security Class Initialized
DEBUG - 2016-02-18 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:43:42 --> Input Class Initialized
INFO - 2016-02-18 11:43:42 --> Language Class Initialized
ERROR - 2016-02-18 11:43:42 --> 404 Page Not Found: Picture/index
INFO - 2016-02-18 11:44:54 --> Config Class Initialized
INFO - 2016-02-18 11:44:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:44:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:44:54 --> Utf8 Class Initialized
INFO - 2016-02-18 11:44:54 --> URI Class Initialized
DEBUG - 2016-02-18 11:44:54 --> No URI present. Default controller set.
INFO - 2016-02-18 11:44:54 --> Router Class Initialized
INFO - 2016-02-18 11:44:54 --> Output Class Initialized
INFO - 2016-02-18 11:44:54 --> Security Class Initialized
DEBUG - 2016-02-18 11:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:44:54 --> Input Class Initialized
INFO - 2016-02-18 11:44:54 --> Language Class Initialized
INFO - 2016-02-18 11:44:54 --> Loader Class Initialized
INFO - 2016-02-18 11:44:54 --> Helper loaded: url_helper
INFO - 2016-02-18 11:44:54 --> Helper loaded: file_helper
INFO - 2016-02-18 11:44:54 --> Helper loaded: date_helper
INFO - 2016-02-18 11:44:54 --> Helper loaded: form_helper
INFO - 2016-02-18 11:44:54 --> Database Driver Class Initialized
INFO - 2016-02-18 11:44:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:44:55 --> Controller Class Initialized
INFO - 2016-02-18 11:44:55 --> Model Class Initialized
INFO - 2016-02-18 11:44:55 --> Model Class Initialized
INFO - 2016-02-18 11:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:44:55 --> Pagination Class Initialized
INFO - 2016-02-18 11:44:55 --> Helper loaded: text_helper
INFO - 2016-02-18 11:44:55 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:44:55 --> Final output sent to browser
DEBUG - 2016-02-18 14:44:55 --> Total execution time: 1.1814
INFO - 2016-02-18 11:44:58 --> Config Class Initialized
INFO - 2016-02-18 11:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:44:58 --> Utf8 Class Initialized
INFO - 2016-02-18 11:44:58 --> URI Class Initialized
INFO - 2016-02-18 11:44:58 --> Router Class Initialized
INFO - 2016-02-18 11:44:58 --> Output Class Initialized
INFO - 2016-02-18 11:44:58 --> Security Class Initialized
DEBUG - 2016-02-18 11:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:44:58 --> Input Class Initialized
INFO - 2016-02-18 11:44:58 --> Language Class Initialized
INFO - 2016-02-18 11:44:58 --> Loader Class Initialized
INFO - 2016-02-18 11:44:58 --> Helper loaded: url_helper
INFO - 2016-02-18 11:44:58 --> Helper loaded: file_helper
INFO - 2016-02-18 11:44:58 --> Helper loaded: date_helper
INFO - 2016-02-18 11:44:58 --> Helper loaded: form_helper
INFO - 2016-02-18 11:44:58 --> Database Driver Class Initialized
INFO - 2016-02-18 11:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:44:59 --> Controller Class Initialized
INFO - 2016-02-18 11:44:59 --> Model Class Initialized
INFO - 2016-02-18 11:44:59 --> Model Class Initialized
INFO - 2016-02-18 11:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:44:59 --> Pagination Class Initialized
INFO - 2016-02-18 11:44:59 --> Helper loaded: text_helper
INFO - 2016-02-18 11:44:59 --> Helper loaded: cookie_helper
ERROR - 2016-02-18 14:44:59 --> Severity: Error --> Call to undefined method Picture::_head() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 27
INFO - 2016-02-18 11:45:35 --> Config Class Initialized
INFO - 2016-02-18 11:45:35 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:45:35 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:45:35 --> Utf8 Class Initialized
INFO - 2016-02-18 11:45:35 --> URI Class Initialized
DEBUG - 2016-02-18 11:45:35 --> No URI present. Default controller set.
INFO - 2016-02-18 11:45:35 --> Router Class Initialized
INFO - 2016-02-18 11:45:35 --> Output Class Initialized
INFO - 2016-02-18 11:45:35 --> Security Class Initialized
DEBUG - 2016-02-18 11:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:45:35 --> Input Class Initialized
INFO - 2016-02-18 11:45:35 --> Language Class Initialized
INFO - 2016-02-18 11:45:35 --> Loader Class Initialized
INFO - 2016-02-18 11:45:35 --> Helper loaded: url_helper
INFO - 2016-02-18 11:45:35 --> Helper loaded: file_helper
INFO - 2016-02-18 11:45:35 --> Helper loaded: date_helper
INFO - 2016-02-18 11:45:35 --> Helper loaded: form_helper
INFO - 2016-02-18 11:45:35 --> Database Driver Class Initialized
INFO - 2016-02-18 11:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:45:36 --> Controller Class Initialized
INFO - 2016-02-18 11:45:36 --> Model Class Initialized
INFO - 2016-02-18 11:45:36 --> Model Class Initialized
INFO - 2016-02-18 11:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:45:36 --> Pagination Class Initialized
INFO - 2016-02-18 11:45:36 --> Helper loaded: text_helper
INFO - 2016-02-18 11:45:36 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:45:36 --> Final output sent to browser
DEBUG - 2016-02-18 14:45:36 --> Total execution time: 1.1155
INFO - 2016-02-18 11:45:37 --> Config Class Initialized
INFO - 2016-02-18 11:45:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 11:45:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 11:45:37 --> Utf8 Class Initialized
INFO - 2016-02-18 11:45:37 --> URI Class Initialized
INFO - 2016-02-18 11:45:37 --> Router Class Initialized
INFO - 2016-02-18 11:45:37 --> Output Class Initialized
INFO - 2016-02-18 11:45:37 --> Security Class Initialized
DEBUG - 2016-02-18 11:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 11:45:37 --> Input Class Initialized
INFO - 2016-02-18 11:45:37 --> Language Class Initialized
INFO - 2016-02-18 11:45:37 --> Loader Class Initialized
INFO - 2016-02-18 11:45:37 --> Helper loaded: url_helper
INFO - 2016-02-18 11:45:37 --> Helper loaded: file_helper
INFO - 2016-02-18 11:45:37 --> Helper loaded: date_helper
INFO - 2016-02-18 11:45:37 --> Helper loaded: form_helper
INFO - 2016-02-18 11:45:37 --> Database Driver Class Initialized
INFO - 2016-02-18 11:45:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 11:45:38 --> Controller Class Initialized
INFO - 2016-02-18 11:45:38 --> Model Class Initialized
INFO - 2016-02-18 11:45:38 --> Model Class Initialized
INFO - 2016-02-18 11:45:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 11:45:38 --> Pagination Class Initialized
INFO - 2016-02-18 11:45:38 --> Helper loaded: text_helper
INFO - 2016-02-18 11:45:38 --> Helper loaded: cookie_helper
INFO - 2016-02-18 14:45:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:45:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:45:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:45:38 --> Final output sent to browser
DEBUG - 2016-02-18 14:45:38 --> Total execution time: 1.1160
INFO - 2016-02-18 13:22:15 --> Config Class Initialized
INFO - 2016-02-18 13:22:15 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:22:15 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:22:15 --> Utf8 Class Initialized
INFO - 2016-02-18 13:22:15 --> URI Class Initialized
INFO - 2016-02-18 13:22:15 --> Router Class Initialized
INFO - 2016-02-18 13:22:15 --> Output Class Initialized
INFO - 2016-02-18 13:22:15 --> Security Class Initialized
DEBUG - 2016-02-18 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:22:15 --> Input Class Initialized
INFO - 2016-02-18 13:22:15 --> Language Class Initialized
INFO - 2016-02-18 13:22:15 --> Loader Class Initialized
INFO - 2016-02-18 13:22:15 --> Helper loaded: url_helper
INFO - 2016-02-18 13:22:15 --> Helper loaded: file_helper
INFO - 2016-02-18 13:22:15 --> Helper loaded: date_helper
INFO - 2016-02-18 13:22:15 --> Helper loaded: form_helper
INFO - 2016-02-18 13:22:15 --> Database Driver Class Initialized
INFO - 2016-02-18 13:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:22:16 --> Controller Class Initialized
INFO - 2016-02-18 13:22:16 --> Model Class Initialized
INFO - 2016-02-18 13:22:16 --> Model Class Initialized
INFO - 2016-02-18 13:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:22:16 --> Pagination Class Initialized
INFO - 2016-02-18 13:22:16 --> Helper loaded: text_helper
INFO - 2016-02-18 13:22:16 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:22:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:22:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:22:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:22:16 --> Final output sent to browser
DEBUG - 2016-02-18 16:22:16 --> Total execution time: 1.1238
INFO - 2016-02-18 13:45:08 --> Config Class Initialized
INFO - 2016-02-18 13:45:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:45:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:45:08 --> Utf8 Class Initialized
INFO - 2016-02-18 13:45:08 --> URI Class Initialized
INFO - 2016-02-18 13:45:08 --> Router Class Initialized
INFO - 2016-02-18 13:45:08 --> Output Class Initialized
INFO - 2016-02-18 13:45:08 --> Security Class Initialized
DEBUG - 2016-02-18 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:45:08 --> Input Class Initialized
INFO - 2016-02-18 13:45:08 --> Language Class Initialized
INFO - 2016-02-18 13:45:08 --> Loader Class Initialized
INFO - 2016-02-18 13:45:08 --> Helper loaded: url_helper
INFO - 2016-02-18 13:45:08 --> Helper loaded: file_helper
INFO - 2016-02-18 13:45:08 --> Helper loaded: date_helper
INFO - 2016-02-18 13:45:08 --> Helper loaded: form_helper
INFO - 2016-02-18 13:45:08 --> Database Driver Class Initialized
INFO - 2016-02-18 13:45:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:45:09 --> Controller Class Initialized
INFO - 2016-02-18 13:45:09 --> Model Class Initialized
INFO - 2016-02-18 13:45:09 --> Model Class Initialized
INFO - 2016-02-18 13:45:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:45:09 --> Pagination Class Initialized
INFO - 2016-02-18 13:45:09 --> Helper loaded: text_helper
INFO - 2016-02-18 13:45:09 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:45:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:45:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:45:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:45:09 --> Final output sent to browser
DEBUG - 2016-02-18 16:45:09 --> Total execution time: 1.1194
INFO - 2016-02-18 13:47:23 --> Config Class Initialized
INFO - 2016-02-18 13:47:23 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:47:23 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:47:23 --> Utf8 Class Initialized
INFO - 2016-02-18 13:47:23 --> URI Class Initialized
DEBUG - 2016-02-18 13:47:23 --> No URI present. Default controller set.
INFO - 2016-02-18 13:47:23 --> Router Class Initialized
INFO - 2016-02-18 13:47:23 --> Output Class Initialized
INFO - 2016-02-18 13:47:23 --> Security Class Initialized
DEBUG - 2016-02-18 13:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:47:23 --> Input Class Initialized
INFO - 2016-02-18 13:47:23 --> Language Class Initialized
INFO - 2016-02-18 13:47:23 --> Loader Class Initialized
INFO - 2016-02-18 13:47:23 --> Helper loaded: url_helper
INFO - 2016-02-18 13:47:23 --> Helper loaded: file_helper
INFO - 2016-02-18 13:47:23 --> Helper loaded: date_helper
INFO - 2016-02-18 13:47:23 --> Helper loaded: form_helper
INFO - 2016-02-18 13:47:23 --> Database Driver Class Initialized
INFO - 2016-02-18 13:47:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:47:24 --> Controller Class Initialized
INFO - 2016-02-18 13:47:24 --> Model Class Initialized
INFO - 2016-02-18 13:47:24 --> Model Class Initialized
INFO - 2016-02-18 13:47:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:47:24 --> Pagination Class Initialized
INFO - 2016-02-18 13:47:24 --> Helper loaded: text_helper
INFO - 2016-02-18 13:47:24 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:47:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:47:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:47:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 16:47:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:47:24 --> Final output sent to browser
DEBUG - 2016-02-18 16:47:24 --> Total execution time: 1.2131
INFO - 2016-02-18 13:49:22 --> Config Class Initialized
INFO - 2016-02-18 13:49:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:49:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:49:22 --> Utf8 Class Initialized
INFO - 2016-02-18 13:49:22 --> URI Class Initialized
DEBUG - 2016-02-18 13:49:22 --> No URI present. Default controller set.
INFO - 2016-02-18 13:49:22 --> Router Class Initialized
INFO - 2016-02-18 13:49:22 --> Output Class Initialized
INFO - 2016-02-18 13:49:22 --> Security Class Initialized
DEBUG - 2016-02-18 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:49:22 --> Input Class Initialized
INFO - 2016-02-18 13:49:22 --> Language Class Initialized
INFO - 2016-02-18 13:49:22 --> Loader Class Initialized
INFO - 2016-02-18 13:49:22 --> Helper loaded: url_helper
INFO - 2016-02-18 13:49:22 --> Helper loaded: file_helper
INFO - 2016-02-18 13:49:22 --> Helper loaded: date_helper
INFO - 2016-02-18 13:49:22 --> Helper loaded: form_helper
INFO - 2016-02-18 13:49:22 --> Database Driver Class Initialized
INFO - 2016-02-18 13:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:49:23 --> Controller Class Initialized
INFO - 2016-02-18 13:49:23 --> Model Class Initialized
INFO - 2016-02-18 13:49:23 --> Model Class Initialized
INFO - 2016-02-18 13:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:49:23 --> Pagination Class Initialized
INFO - 2016-02-18 13:49:23 --> Helper loaded: text_helper
INFO - 2016-02-18 13:49:23 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 16:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:49:23 --> Final output sent to browser
DEBUG - 2016-02-18 16:49:23 --> Total execution time: 1.1470
INFO - 2016-02-18 13:49:26 --> Config Class Initialized
INFO - 2016-02-18 13:49:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:49:26 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:49:26 --> Utf8 Class Initialized
INFO - 2016-02-18 13:49:26 --> URI Class Initialized
DEBUG - 2016-02-18 13:49:26 --> No URI present. Default controller set.
INFO - 2016-02-18 13:49:26 --> Router Class Initialized
INFO - 2016-02-18 13:49:26 --> Output Class Initialized
INFO - 2016-02-18 13:49:26 --> Security Class Initialized
DEBUG - 2016-02-18 13:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:49:26 --> Input Class Initialized
INFO - 2016-02-18 13:49:26 --> Language Class Initialized
INFO - 2016-02-18 13:49:26 --> Loader Class Initialized
INFO - 2016-02-18 13:49:26 --> Helper loaded: url_helper
INFO - 2016-02-18 13:49:26 --> Helper loaded: file_helper
INFO - 2016-02-18 13:49:26 --> Helper loaded: date_helper
INFO - 2016-02-18 13:49:26 --> Helper loaded: form_helper
INFO - 2016-02-18 13:49:26 --> Database Driver Class Initialized
INFO - 2016-02-18 13:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:49:28 --> Controller Class Initialized
INFO - 2016-02-18 13:49:28 --> Model Class Initialized
INFO - 2016-02-18 13:49:28 --> Model Class Initialized
INFO - 2016-02-18 13:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:49:28 --> Pagination Class Initialized
INFO - 2016-02-18 13:49:28 --> Helper loaded: text_helper
INFO - 2016-02-18 13:49:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 16:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:49:28 --> Final output sent to browser
DEBUG - 2016-02-18 16:49:28 --> Total execution time: 1.1972
INFO - 2016-02-18 13:50:52 --> Config Class Initialized
INFO - 2016-02-18 13:50:52 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:50:52 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:50:52 --> Utf8 Class Initialized
INFO - 2016-02-18 13:50:52 --> URI Class Initialized
DEBUG - 2016-02-18 13:50:52 --> No URI present. Default controller set.
INFO - 2016-02-18 13:50:52 --> Router Class Initialized
INFO - 2016-02-18 13:50:52 --> Output Class Initialized
INFO - 2016-02-18 13:50:52 --> Security Class Initialized
DEBUG - 2016-02-18 13:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:50:52 --> Input Class Initialized
INFO - 2016-02-18 13:50:52 --> Language Class Initialized
INFO - 2016-02-18 13:50:52 --> Loader Class Initialized
INFO - 2016-02-18 13:50:52 --> Helper loaded: url_helper
INFO - 2016-02-18 13:50:52 --> Helper loaded: file_helper
INFO - 2016-02-18 13:50:52 --> Helper loaded: date_helper
INFO - 2016-02-18 13:50:52 --> Helper loaded: form_helper
INFO - 2016-02-18 13:50:52 --> Database Driver Class Initialized
INFO - 2016-02-18 13:50:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:50:53 --> Controller Class Initialized
INFO - 2016-02-18 13:50:53 --> Model Class Initialized
INFO - 2016-02-18 13:50:53 --> Model Class Initialized
INFO - 2016-02-18 13:50:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:50:53 --> Pagination Class Initialized
INFO - 2016-02-18 13:50:53 --> Helper loaded: text_helper
INFO - 2016-02-18 13:50:53 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:50:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:50:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:50:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 16:50:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:50:53 --> Final output sent to browser
DEBUG - 2016-02-18 16:50:53 --> Total execution time: 1.1786
INFO - 2016-02-18 13:51:41 --> Config Class Initialized
INFO - 2016-02-18 13:51:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 13:51:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 13:51:41 --> Utf8 Class Initialized
INFO - 2016-02-18 13:51:41 --> URI Class Initialized
DEBUG - 2016-02-18 13:51:41 --> No URI present. Default controller set.
INFO - 2016-02-18 13:51:41 --> Router Class Initialized
INFO - 2016-02-18 13:51:41 --> Output Class Initialized
INFO - 2016-02-18 13:51:41 --> Security Class Initialized
DEBUG - 2016-02-18 13:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 13:51:41 --> Input Class Initialized
INFO - 2016-02-18 13:51:41 --> Language Class Initialized
INFO - 2016-02-18 13:51:41 --> Loader Class Initialized
INFO - 2016-02-18 13:51:41 --> Helper loaded: url_helper
INFO - 2016-02-18 13:51:41 --> Helper loaded: file_helper
INFO - 2016-02-18 13:51:41 --> Helper loaded: date_helper
INFO - 2016-02-18 13:51:41 --> Helper loaded: form_helper
INFO - 2016-02-18 13:51:41 --> Database Driver Class Initialized
INFO - 2016-02-18 13:51:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 13:51:42 --> Controller Class Initialized
INFO - 2016-02-18 13:51:42 --> Model Class Initialized
INFO - 2016-02-18 13:51:42 --> Model Class Initialized
INFO - 2016-02-18 13:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 13:51:42 --> Pagination Class Initialized
INFO - 2016-02-18 13:51:42 --> Helper loaded: text_helper
INFO - 2016-02-18 13:51:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 16:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 16:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 16:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 16:51:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 16:51:42 --> Final output sent to browser
DEBUG - 2016-02-18 16:51:42 --> Total execution time: 1.1472
INFO - 2016-02-18 14:01:56 --> Config Class Initialized
INFO - 2016-02-18 14:01:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:01:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:01:56 --> Utf8 Class Initialized
INFO - 2016-02-18 14:01:56 --> URI Class Initialized
INFO - 2016-02-18 14:01:56 --> Router Class Initialized
INFO - 2016-02-18 14:01:56 --> Output Class Initialized
INFO - 2016-02-18 14:01:56 --> Security Class Initialized
DEBUG - 2016-02-18 14:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:01:56 --> Input Class Initialized
INFO - 2016-02-18 14:01:56 --> Language Class Initialized
INFO - 2016-02-18 14:01:56 --> Loader Class Initialized
INFO - 2016-02-18 14:01:56 --> Helper loaded: url_helper
INFO - 2016-02-18 14:01:56 --> Helper loaded: file_helper
INFO - 2016-02-18 14:01:56 --> Helper loaded: date_helper
INFO - 2016-02-18 14:01:56 --> Helper loaded: form_helper
INFO - 2016-02-18 14:01:56 --> Database Driver Class Initialized
INFO - 2016-02-18 14:01:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:01:58 --> Controller Class Initialized
INFO - 2016-02-18 14:01:58 --> Model Class Initialized
INFO - 2016-02-18 14:01:58 --> Model Class Initialized
INFO - 2016-02-18 14:01:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:01:58 --> Pagination Class Initialized
INFO - 2016-02-18 14:01:58 --> Helper loaded: text_helper
INFO - 2016-02-18 14:01:58 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:01:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:01:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:01:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:01:58 --> Final output sent to browser
DEBUG - 2016-02-18 17:01:58 --> Total execution time: 1.1088
INFO - 2016-02-18 14:02:03 --> Config Class Initialized
INFO - 2016-02-18 14:02:03 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:02:03 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:02:03 --> Utf8 Class Initialized
INFO - 2016-02-18 14:02:03 --> URI Class Initialized
DEBUG - 2016-02-18 14:02:03 --> No URI present. Default controller set.
INFO - 2016-02-18 14:02:03 --> Router Class Initialized
INFO - 2016-02-18 14:02:03 --> Output Class Initialized
INFO - 2016-02-18 14:02:03 --> Security Class Initialized
DEBUG - 2016-02-18 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:02:03 --> Input Class Initialized
INFO - 2016-02-18 14:02:03 --> Language Class Initialized
INFO - 2016-02-18 14:02:03 --> Loader Class Initialized
INFO - 2016-02-18 14:02:03 --> Helper loaded: url_helper
INFO - 2016-02-18 14:02:03 --> Helper loaded: file_helper
INFO - 2016-02-18 14:02:03 --> Helper loaded: date_helper
INFO - 2016-02-18 14:02:03 --> Helper loaded: form_helper
INFO - 2016-02-18 14:02:03 --> Database Driver Class Initialized
INFO - 2016-02-18 14:02:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:02:04 --> Controller Class Initialized
INFO - 2016-02-18 14:02:04 --> Model Class Initialized
INFO - 2016-02-18 14:02:04 --> Model Class Initialized
INFO - 2016-02-18 14:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:02:04 --> Pagination Class Initialized
INFO - 2016-02-18 14:02:04 --> Helper loaded: text_helper
INFO - 2016-02-18 14:02:04 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:02:04 --> Final output sent to browser
DEBUG - 2016-02-18 17:02:04 --> Total execution time: 1.1237
INFO - 2016-02-18 14:08:27 --> Config Class Initialized
INFO - 2016-02-18 14:08:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:08:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:08:27 --> Utf8 Class Initialized
INFO - 2016-02-18 14:08:27 --> URI Class Initialized
INFO - 2016-02-18 14:08:27 --> Router Class Initialized
INFO - 2016-02-18 14:08:27 --> Output Class Initialized
INFO - 2016-02-18 14:08:27 --> Security Class Initialized
DEBUG - 2016-02-18 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:08:27 --> Input Class Initialized
INFO - 2016-02-18 14:08:27 --> Language Class Initialized
INFO - 2016-02-18 14:08:27 --> Loader Class Initialized
INFO - 2016-02-18 14:08:27 --> Helper loaded: url_helper
INFO - 2016-02-18 14:08:27 --> Helper loaded: file_helper
INFO - 2016-02-18 14:08:27 --> Helper loaded: date_helper
INFO - 2016-02-18 14:08:27 --> Helper loaded: form_helper
INFO - 2016-02-18 14:08:27 --> Database Driver Class Initialized
INFO - 2016-02-18 14:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:08:28 --> Controller Class Initialized
INFO - 2016-02-18 14:08:28 --> Model Class Initialized
INFO - 2016-02-18 14:08:28 --> Model Class Initialized
INFO - 2016-02-18 14:08:28 --> Form Validation Class Initialized
INFO - 2016-02-18 14:08:28 --> Helper loaded: text_helper
INFO - 2016-02-18 14:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 14:08:28 --> Model Class Initialized
INFO - 2016-02-18 14:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:08:28 --> Final output sent to browser
DEBUG - 2016-02-18 14:08:28 --> Total execution time: 1.3543
INFO - 2016-02-18 14:08:35 --> Config Class Initialized
INFO - 2016-02-18 14:08:35 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:08:35 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:08:35 --> Utf8 Class Initialized
INFO - 2016-02-18 14:08:35 --> URI Class Initialized
DEBUG - 2016-02-18 14:08:35 --> No URI present. Default controller set.
INFO - 2016-02-18 14:08:35 --> Router Class Initialized
INFO - 2016-02-18 14:08:35 --> Output Class Initialized
INFO - 2016-02-18 14:08:35 --> Security Class Initialized
DEBUG - 2016-02-18 14:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:08:35 --> Input Class Initialized
INFO - 2016-02-18 14:08:35 --> Language Class Initialized
INFO - 2016-02-18 14:08:35 --> Loader Class Initialized
INFO - 2016-02-18 14:08:35 --> Helper loaded: url_helper
INFO - 2016-02-18 14:08:35 --> Helper loaded: file_helper
INFO - 2016-02-18 14:08:35 --> Helper loaded: date_helper
INFO - 2016-02-18 14:08:35 --> Helper loaded: form_helper
INFO - 2016-02-18 14:08:35 --> Database Driver Class Initialized
INFO - 2016-02-18 14:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:08:36 --> Controller Class Initialized
INFO - 2016-02-18 14:08:36 --> Model Class Initialized
INFO - 2016-02-18 14:08:36 --> Model Class Initialized
INFO - 2016-02-18 14:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:08:36 --> Pagination Class Initialized
INFO - 2016-02-18 14:08:36 --> Helper loaded: text_helper
INFO - 2016-02-18 14:08:36 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:08:37 --> Final output sent to browser
DEBUG - 2016-02-18 17:08:37 --> Total execution time: 1.1390
INFO - 2016-02-18 14:09:56 --> Config Class Initialized
INFO - 2016-02-18 14:09:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:09:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:09:56 --> Utf8 Class Initialized
INFO - 2016-02-18 14:09:56 --> URI Class Initialized
DEBUG - 2016-02-18 14:09:56 --> No URI present. Default controller set.
INFO - 2016-02-18 14:09:56 --> Router Class Initialized
INFO - 2016-02-18 14:09:56 --> Output Class Initialized
INFO - 2016-02-18 14:09:56 --> Security Class Initialized
DEBUG - 2016-02-18 14:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:09:56 --> Input Class Initialized
INFO - 2016-02-18 14:09:56 --> Language Class Initialized
INFO - 2016-02-18 14:09:56 --> Loader Class Initialized
INFO - 2016-02-18 14:09:56 --> Helper loaded: url_helper
INFO - 2016-02-18 14:09:56 --> Helper loaded: file_helper
INFO - 2016-02-18 14:09:56 --> Helper loaded: date_helper
INFO - 2016-02-18 14:09:56 --> Helper loaded: form_helper
INFO - 2016-02-18 14:09:56 --> Database Driver Class Initialized
INFO - 2016-02-18 14:09:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:09:57 --> Controller Class Initialized
INFO - 2016-02-18 14:09:57 --> Model Class Initialized
INFO - 2016-02-18 14:09:57 --> Model Class Initialized
INFO - 2016-02-18 14:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:09:57 --> Pagination Class Initialized
INFO - 2016-02-18 14:09:57 --> Helper loaded: text_helper
INFO - 2016-02-18 14:09:57 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:09:57 --> Final output sent to browser
DEBUG - 2016-02-18 17:09:57 --> Total execution time: 1.1587
INFO - 2016-02-18 14:10:38 --> Config Class Initialized
INFO - 2016-02-18 14:10:38 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:10:38 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:10:38 --> Utf8 Class Initialized
INFO - 2016-02-18 14:10:38 --> URI Class Initialized
INFO - 2016-02-18 14:10:38 --> Router Class Initialized
INFO - 2016-02-18 14:10:38 --> Output Class Initialized
INFO - 2016-02-18 14:10:38 --> Security Class Initialized
DEBUG - 2016-02-18 14:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:10:38 --> Input Class Initialized
INFO - 2016-02-18 14:10:38 --> Language Class Initialized
INFO - 2016-02-18 14:10:38 --> Loader Class Initialized
INFO - 2016-02-18 14:10:38 --> Helper loaded: url_helper
INFO - 2016-02-18 14:10:38 --> Helper loaded: file_helper
INFO - 2016-02-18 14:10:38 --> Helper loaded: date_helper
INFO - 2016-02-18 14:10:38 --> Helper loaded: form_helper
INFO - 2016-02-18 14:10:38 --> Database Driver Class Initialized
INFO - 2016-02-18 14:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:10:39 --> Controller Class Initialized
INFO - 2016-02-18 14:10:39 --> Model Class Initialized
INFO - 2016-02-18 14:10:39 --> Model Class Initialized
INFO - 2016-02-18 14:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:10:39 --> Pagination Class Initialized
INFO - 2016-02-18 14:10:39 --> Helper loaded: text_helper
INFO - 2016-02-18 14:10:39 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:10:39 --> Final output sent to browser
DEBUG - 2016-02-18 17:10:39 --> Total execution time: 1.1957
INFO - 2016-02-18 14:17:06 --> Config Class Initialized
INFO - 2016-02-18 14:17:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:17:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:17:06 --> Utf8 Class Initialized
INFO - 2016-02-18 14:17:07 --> URI Class Initialized
INFO - 2016-02-18 14:17:07 --> Router Class Initialized
INFO - 2016-02-18 14:17:07 --> Output Class Initialized
INFO - 2016-02-18 14:17:07 --> Security Class Initialized
DEBUG - 2016-02-18 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:17:07 --> Input Class Initialized
INFO - 2016-02-18 14:17:07 --> Language Class Initialized
INFO - 2016-02-18 14:17:07 --> Loader Class Initialized
INFO - 2016-02-18 14:17:07 --> Helper loaded: url_helper
INFO - 2016-02-18 14:17:07 --> Helper loaded: file_helper
INFO - 2016-02-18 14:17:07 --> Helper loaded: date_helper
INFO - 2016-02-18 14:17:07 --> Helper loaded: form_helper
INFO - 2016-02-18 14:17:07 --> Database Driver Class Initialized
INFO - 2016-02-18 14:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:17:08 --> Controller Class Initialized
INFO - 2016-02-18 14:17:08 --> Model Class Initialized
INFO - 2016-02-18 14:17:08 --> Model Class Initialized
INFO - 2016-02-18 14:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:17:08 --> Pagination Class Initialized
INFO - 2016-02-18 14:17:08 --> Helper loaded: text_helper
INFO - 2016-02-18 14:17:08 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:17:08 --> Final output sent to browser
DEBUG - 2016-02-18 17:17:08 --> Total execution time: 1.2591
INFO - 2016-02-18 14:18:13 --> Config Class Initialized
INFO - 2016-02-18 14:18:13 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:18:13 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:18:13 --> Utf8 Class Initialized
INFO - 2016-02-18 14:18:13 --> URI Class Initialized
INFO - 2016-02-18 14:18:13 --> Router Class Initialized
INFO - 2016-02-18 14:18:13 --> Output Class Initialized
INFO - 2016-02-18 14:18:13 --> Security Class Initialized
DEBUG - 2016-02-18 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:18:13 --> Input Class Initialized
INFO - 2016-02-18 14:18:13 --> Language Class Initialized
INFO - 2016-02-18 14:18:13 --> Loader Class Initialized
INFO - 2016-02-18 14:18:13 --> Helper loaded: url_helper
INFO - 2016-02-18 14:18:13 --> Helper loaded: file_helper
INFO - 2016-02-18 14:18:13 --> Helper loaded: date_helper
INFO - 2016-02-18 14:18:13 --> Helper loaded: form_helper
INFO - 2016-02-18 14:18:13 --> Database Driver Class Initialized
INFO - 2016-02-18 14:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:18:14 --> Controller Class Initialized
INFO - 2016-02-18 14:18:14 --> Model Class Initialized
INFO - 2016-02-18 14:18:14 --> Model Class Initialized
INFO - 2016-02-18 14:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:18:14 --> Pagination Class Initialized
INFO - 2016-02-18 14:18:14 --> Helper loaded: text_helper
INFO - 2016-02-18 14:18:14 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:18:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:18:15 --> Final output sent to browser
DEBUG - 2016-02-18 17:18:15 --> Total execution time: 1.2231
INFO - 2016-02-18 14:19:40 --> Config Class Initialized
INFO - 2016-02-18 14:19:40 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:19:40 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:19:40 --> Utf8 Class Initialized
INFO - 2016-02-18 14:19:40 --> URI Class Initialized
INFO - 2016-02-18 14:19:40 --> Router Class Initialized
INFO - 2016-02-18 14:19:40 --> Output Class Initialized
INFO - 2016-02-18 14:19:40 --> Security Class Initialized
DEBUG - 2016-02-18 14:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:19:40 --> Input Class Initialized
INFO - 2016-02-18 14:19:40 --> Language Class Initialized
INFO - 2016-02-18 14:19:40 --> Loader Class Initialized
INFO - 2016-02-18 14:19:40 --> Helper loaded: url_helper
INFO - 2016-02-18 14:19:40 --> Helper loaded: file_helper
INFO - 2016-02-18 14:19:40 --> Helper loaded: date_helper
INFO - 2016-02-18 14:19:40 --> Helper loaded: form_helper
INFO - 2016-02-18 14:19:40 --> Database Driver Class Initialized
INFO - 2016-02-18 14:19:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:19:41 --> Controller Class Initialized
INFO - 2016-02-18 14:19:41 --> Model Class Initialized
INFO - 2016-02-18 14:19:41 --> Model Class Initialized
INFO - 2016-02-18 14:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:19:41 --> Pagination Class Initialized
INFO - 2016-02-18 14:19:41 --> Helper loaded: text_helper
INFO - 2016-02-18 14:19:41 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:19:42 --> Final output sent to browser
DEBUG - 2016-02-18 17:19:42 --> Total execution time: 1.2368
INFO - 2016-02-18 14:22:16 --> Config Class Initialized
INFO - 2016-02-18 14:22:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:22:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:22:16 --> Utf8 Class Initialized
INFO - 2016-02-18 14:22:16 --> URI Class Initialized
INFO - 2016-02-18 14:22:16 --> Router Class Initialized
INFO - 2016-02-18 14:22:16 --> Output Class Initialized
INFO - 2016-02-18 14:22:16 --> Security Class Initialized
DEBUG - 2016-02-18 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:22:16 --> Input Class Initialized
INFO - 2016-02-18 14:22:16 --> Language Class Initialized
INFO - 2016-02-18 14:22:16 --> Loader Class Initialized
INFO - 2016-02-18 14:22:16 --> Helper loaded: url_helper
INFO - 2016-02-18 14:22:16 --> Helper loaded: file_helper
INFO - 2016-02-18 14:22:16 --> Helper loaded: date_helper
INFO - 2016-02-18 14:22:16 --> Helper loaded: form_helper
INFO - 2016-02-18 14:22:16 --> Database Driver Class Initialized
INFO - 2016-02-18 14:22:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:22:17 --> Controller Class Initialized
INFO - 2016-02-18 14:22:17 --> Model Class Initialized
INFO - 2016-02-18 14:22:17 --> Model Class Initialized
INFO - 2016-02-18 14:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:22:17 --> Pagination Class Initialized
INFO - 2016-02-18 14:22:17 --> Helper loaded: text_helper
INFO - 2016-02-18 14:22:17 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:22:17 --> Final output sent to browser
DEBUG - 2016-02-18 17:22:17 --> Total execution time: 1.2186
INFO - 2016-02-18 14:22:25 --> Config Class Initialized
INFO - 2016-02-18 14:22:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:22:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:22:25 --> Utf8 Class Initialized
INFO - 2016-02-18 14:22:25 --> URI Class Initialized
INFO - 2016-02-18 14:22:25 --> Router Class Initialized
INFO - 2016-02-18 14:22:25 --> Output Class Initialized
INFO - 2016-02-18 14:22:25 --> Security Class Initialized
DEBUG - 2016-02-18 14:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:22:25 --> Input Class Initialized
INFO - 2016-02-18 14:22:25 --> Language Class Initialized
INFO - 2016-02-18 14:22:25 --> Loader Class Initialized
INFO - 2016-02-18 14:22:25 --> Helper loaded: url_helper
INFO - 2016-02-18 14:22:25 --> Helper loaded: file_helper
INFO - 2016-02-18 14:22:25 --> Helper loaded: date_helper
INFO - 2016-02-18 14:22:25 --> Helper loaded: form_helper
INFO - 2016-02-18 14:22:25 --> Database Driver Class Initialized
INFO - 2016-02-18 14:22:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:22:26 --> Controller Class Initialized
INFO - 2016-02-18 14:22:26 --> Model Class Initialized
INFO - 2016-02-18 14:22:26 --> Model Class Initialized
INFO - 2016-02-18 14:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:22:26 --> Pagination Class Initialized
INFO - 2016-02-18 14:22:26 --> Helper loaded: text_helper
INFO - 2016-02-18 14:22:26 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:22:26 --> Final output sent to browser
DEBUG - 2016-02-18 17:22:26 --> Total execution time: 1.2408
INFO - 2016-02-18 14:23:06 --> Config Class Initialized
INFO - 2016-02-18 14:23:06 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:23:06 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:23:06 --> Utf8 Class Initialized
INFO - 2016-02-18 14:23:06 --> URI Class Initialized
INFO - 2016-02-18 14:23:06 --> Router Class Initialized
INFO - 2016-02-18 14:23:06 --> Output Class Initialized
INFO - 2016-02-18 14:23:06 --> Security Class Initialized
DEBUG - 2016-02-18 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:23:06 --> Input Class Initialized
INFO - 2016-02-18 14:23:06 --> Language Class Initialized
INFO - 2016-02-18 14:23:06 --> Loader Class Initialized
INFO - 2016-02-18 14:23:06 --> Helper loaded: url_helper
INFO - 2016-02-18 14:23:06 --> Helper loaded: file_helper
INFO - 2016-02-18 14:23:06 --> Helper loaded: date_helper
INFO - 2016-02-18 14:23:06 --> Helper loaded: form_helper
INFO - 2016-02-18 14:23:06 --> Database Driver Class Initialized
INFO - 2016-02-18 14:23:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:23:07 --> Controller Class Initialized
INFO - 2016-02-18 14:23:07 --> Model Class Initialized
INFO - 2016-02-18 14:23:07 --> Model Class Initialized
INFO - 2016-02-18 14:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:23:07 --> Pagination Class Initialized
INFO - 2016-02-18 14:23:07 --> Helper loaded: text_helper
INFO - 2016-02-18 14:23:07 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-18 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:23:07 --> Final output sent to browser
DEBUG - 2016-02-18 17:23:07 --> Total execution time: 1.1482
INFO - 2016-02-18 14:23:22 --> Config Class Initialized
INFO - 2016-02-18 14:23:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:23:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:23:22 --> Utf8 Class Initialized
INFO - 2016-02-18 14:23:22 --> URI Class Initialized
DEBUG - 2016-02-18 14:23:22 --> No URI present. Default controller set.
INFO - 2016-02-18 14:23:22 --> Router Class Initialized
INFO - 2016-02-18 14:23:22 --> Output Class Initialized
INFO - 2016-02-18 14:23:22 --> Security Class Initialized
DEBUG - 2016-02-18 14:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:23:22 --> Input Class Initialized
INFO - 2016-02-18 14:23:22 --> Language Class Initialized
INFO - 2016-02-18 14:23:22 --> Loader Class Initialized
INFO - 2016-02-18 14:23:22 --> Helper loaded: url_helper
INFO - 2016-02-18 14:23:22 --> Helper loaded: file_helper
INFO - 2016-02-18 14:23:22 --> Helper loaded: date_helper
INFO - 2016-02-18 14:23:22 --> Helper loaded: form_helper
INFO - 2016-02-18 14:23:22 --> Database Driver Class Initialized
INFO - 2016-02-18 14:23:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:23:23 --> Controller Class Initialized
INFO - 2016-02-18 14:23:24 --> Model Class Initialized
INFO - 2016-02-18 14:23:24 --> Model Class Initialized
INFO - 2016-02-18 14:23:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:23:24 --> Pagination Class Initialized
INFO - 2016-02-18 14:23:24 --> Helper loaded: text_helper
INFO - 2016-02-18 14:23:24 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:23:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:23:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:23:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:23:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:23:24 --> Final output sent to browser
DEBUG - 2016-02-18 17:23:24 --> Total execution time: 1.1334
INFO - 2016-02-18 14:24:08 --> Config Class Initialized
INFO - 2016-02-18 14:24:08 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:24:08 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:24:08 --> Utf8 Class Initialized
INFO - 2016-02-18 14:24:08 --> URI Class Initialized
DEBUG - 2016-02-18 14:24:08 --> No URI present. Default controller set.
INFO - 2016-02-18 14:24:08 --> Router Class Initialized
INFO - 2016-02-18 14:24:08 --> Output Class Initialized
INFO - 2016-02-18 14:24:08 --> Security Class Initialized
DEBUG - 2016-02-18 14:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:24:08 --> Input Class Initialized
INFO - 2016-02-18 14:24:08 --> Language Class Initialized
INFO - 2016-02-18 14:24:08 --> Loader Class Initialized
INFO - 2016-02-18 14:24:08 --> Helper loaded: url_helper
INFO - 2016-02-18 14:24:08 --> Helper loaded: file_helper
INFO - 2016-02-18 14:24:08 --> Helper loaded: date_helper
INFO - 2016-02-18 14:24:08 --> Helper loaded: form_helper
INFO - 2016-02-18 14:24:08 --> Database Driver Class Initialized
INFO - 2016-02-18 14:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:24:09 --> Controller Class Initialized
INFO - 2016-02-18 14:24:09 --> Model Class Initialized
INFO - 2016-02-18 14:24:09 --> Model Class Initialized
INFO - 2016-02-18 14:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:24:09 --> Pagination Class Initialized
INFO - 2016-02-18 14:24:09 --> Helper loaded: text_helper
INFO - 2016-02-18 14:24:09 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:24:09 --> Final output sent to browser
DEBUG - 2016-02-18 17:24:09 --> Total execution time: 1.1359
INFO - 2016-02-18 14:27:32 --> Config Class Initialized
INFO - 2016-02-18 14:27:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:27:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:27:32 --> Utf8 Class Initialized
INFO - 2016-02-18 14:27:32 --> URI Class Initialized
DEBUG - 2016-02-18 14:27:32 --> No URI present. Default controller set.
INFO - 2016-02-18 14:27:32 --> Router Class Initialized
INFO - 2016-02-18 14:27:32 --> Output Class Initialized
INFO - 2016-02-18 14:27:32 --> Security Class Initialized
DEBUG - 2016-02-18 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:27:32 --> Input Class Initialized
INFO - 2016-02-18 14:27:32 --> Language Class Initialized
INFO - 2016-02-18 14:27:33 --> Loader Class Initialized
INFO - 2016-02-18 14:27:33 --> Helper loaded: url_helper
INFO - 2016-02-18 14:27:33 --> Helper loaded: file_helper
INFO - 2016-02-18 14:27:33 --> Helper loaded: date_helper
INFO - 2016-02-18 14:27:33 --> Helper loaded: form_helper
INFO - 2016-02-18 14:27:33 --> Database Driver Class Initialized
INFO - 2016-02-18 14:27:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:27:34 --> Controller Class Initialized
INFO - 2016-02-18 14:27:34 --> Model Class Initialized
INFO - 2016-02-18 14:27:34 --> Model Class Initialized
INFO - 2016-02-18 14:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:27:34 --> Pagination Class Initialized
INFO - 2016-02-18 14:27:34 --> Helper loaded: text_helper
INFO - 2016-02-18 14:27:34 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:27:34 --> Final output sent to browser
DEBUG - 2016-02-18 17:27:34 --> Total execution time: 1.1745
INFO - 2016-02-18 14:28:44 --> Config Class Initialized
INFO - 2016-02-18 14:28:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:28:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:28:44 --> Utf8 Class Initialized
INFO - 2016-02-18 14:28:44 --> URI Class Initialized
DEBUG - 2016-02-18 14:28:44 --> No URI present. Default controller set.
INFO - 2016-02-18 14:28:44 --> Router Class Initialized
INFO - 2016-02-18 14:28:44 --> Output Class Initialized
INFO - 2016-02-18 14:28:44 --> Security Class Initialized
DEBUG - 2016-02-18 14:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:28:44 --> Input Class Initialized
INFO - 2016-02-18 14:28:44 --> Language Class Initialized
INFO - 2016-02-18 14:28:44 --> Loader Class Initialized
INFO - 2016-02-18 14:28:44 --> Helper loaded: url_helper
INFO - 2016-02-18 14:28:44 --> Helper loaded: file_helper
INFO - 2016-02-18 14:28:44 --> Helper loaded: date_helper
INFO - 2016-02-18 14:28:44 --> Helper loaded: form_helper
INFO - 2016-02-18 14:28:44 --> Database Driver Class Initialized
INFO - 2016-02-18 14:28:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:28:45 --> Controller Class Initialized
INFO - 2016-02-18 14:28:45 --> Model Class Initialized
INFO - 2016-02-18 14:28:45 --> Model Class Initialized
INFO - 2016-02-18 14:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:28:45 --> Pagination Class Initialized
INFO - 2016-02-18 14:28:45 --> Helper loaded: text_helper
INFO - 2016-02-18 14:28:45 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:28:45 --> Final output sent to browser
DEBUG - 2016-02-18 17:28:45 --> Total execution time: 1.1835
INFO - 2016-02-18 14:29:09 --> Config Class Initialized
INFO - 2016-02-18 14:29:09 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:29:09 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:29:09 --> Utf8 Class Initialized
INFO - 2016-02-18 14:29:09 --> URI Class Initialized
DEBUG - 2016-02-18 14:29:09 --> No URI present. Default controller set.
INFO - 2016-02-18 14:29:09 --> Router Class Initialized
INFO - 2016-02-18 14:29:09 --> Output Class Initialized
INFO - 2016-02-18 14:29:09 --> Security Class Initialized
DEBUG - 2016-02-18 14:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:29:09 --> Input Class Initialized
INFO - 2016-02-18 14:29:09 --> Language Class Initialized
INFO - 2016-02-18 14:29:09 --> Loader Class Initialized
INFO - 2016-02-18 14:29:09 --> Helper loaded: url_helper
INFO - 2016-02-18 14:29:10 --> Helper loaded: file_helper
INFO - 2016-02-18 14:29:10 --> Helper loaded: date_helper
INFO - 2016-02-18 14:29:10 --> Helper loaded: form_helper
INFO - 2016-02-18 14:29:10 --> Database Driver Class Initialized
INFO - 2016-02-18 14:29:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:29:11 --> Controller Class Initialized
INFO - 2016-02-18 14:29:11 --> Model Class Initialized
INFO - 2016-02-18 14:29:11 --> Model Class Initialized
INFO - 2016-02-18 14:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:29:11 --> Pagination Class Initialized
INFO - 2016-02-18 14:29:11 --> Helper loaded: text_helper
INFO - 2016-02-18 14:29:11 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:29:11 --> Final output sent to browser
DEBUG - 2016-02-18 17:29:11 --> Total execution time: 1.1308
INFO - 2016-02-18 14:29:39 --> Config Class Initialized
INFO - 2016-02-18 14:29:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:29:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:29:39 --> Utf8 Class Initialized
INFO - 2016-02-18 14:29:39 --> URI Class Initialized
DEBUG - 2016-02-18 14:29:39 --> No URI present. Default controller set.
INFO - 2016-02-18 14:29:39 --> Router Class Initialized
INFO - 2016-02-18 14:29:39 --> Output Class Initialized
INFO - 2016-02-18 14:29:39 --> Security Class Initialized
DEBUG - 2016-02-18 14:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:29:39 --> Input Class Initialized
INFO - 2016-02-18 14:29:39 --> Language Class Initialized
INFO - 2016-02-18 14:29:39 --> Loader Class Initialized
INFO - 2016-02-18 14:29:39 --> Helper loaded: url_helper
INFO - 2016-02-18 14:29:39 --> Helper loaded: file_helper
INFO - 2016-02-18 14:29:39 --> Helper loaded: date_helper
INFO - 2016-02-18 14:29:39 --> Helper loaded: form_helper
INFO - 2016-02-18 14:29:39 --> Database Driver Class Initialized
INFO - 2016-02-18 14:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:29:40 --> Controller Class Initialized
INFO - 2016-02-18 14:29:40 --> Model Class Initialized
INFO - 2016-02-18 14:29:40 --> Model Class Initialized
INFO - 2016-02-18 14:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:29:40 --> Pagination Class Initialized
INFO - 2016-02-18 14:29:40 --> Helper loaded: text_helper
INFO - 2016-02-18 14:29:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:29:40 --> Final output sent to browser
DEBUG - 2016-02-18 17:29:40 --> Total execution time: 1.1213
INFO - 2016-02-18 14:29:44 --> Config Class Initialized
INFO - 2016-02-18 14:29:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:29:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:29:44 --> Utf8 Class Initialized
INFO - 2016-02-18 14:29:44 --> URI Class Initialized
INFO - 2016-02-18 14:29:44 --> Router Class Initialized
INFO - 2016-02-18 14:29:44 --> Output Class Initialized
INFO - 2016-02-18 14:29:44 --> Security Class Initialized
DEBUG - 2016-02-18 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:29:44 --> Input Class Initialized
INFO - 2016-02-18 14:29:44 --> Language Class Initialized
INFO - 2016-02-18 14:29:44 --> Loader Class Initialized
INFO - 2016-02-18 14:29:44 --> Helper loaded: url_helper
INFO - 2016-02-18 14:29:44 --> Helper loaded: file_helper
INFO - 2016-02-18 14:29:44 --> Helper loaded: date_helper
INFO - 2016-02-18 14:29:44 --> Helper loaded: form_helper
INFO - 2016-02-18 14:29:44 --> Database Driver Class Initialized
INFO - 2016-02-18 14:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:29:45 --> Controller Class Initialized
INFO - 2016-02-18 14:29:45 --> Model Class Initialized
INFO - 2016-02-18 14:29:45 --> Model Class Initialized
INFO - 2016-02-18 14:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:29:45 --> Pagination Class Initialized
INFO - 2016-02-18 14:29:45 --> Helper loaded: text_helper
INFO - 2016-02-18 14:29:45 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:29:45 --> Final output sent to browser
DEBUG - 2016-02-18 17:29:45 --> Total execution time: 1.1246
INFO - 2016-02-18 14:29:46 --> Config Class Initialized
INFO - 2016-02-18 14:29:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:29:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:29:46 --> Utf8 Class Initialized
INFO - 2016-02-18 14:29:46 --> URI Class Initialized
INFO - 2016-02-18 14:29:46 --> Router Class Initialized
INFO - 2016-02-18 14:29:46 --> Output Class Initialized
INFO - 2016-02-18 14:29:46 --> Security Class Initialized
DEBUG - 2016-02-18 14:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:29:46 --> Input Class Initialized
INFO - 2016-02-18 14:29:46 --> Language Class Initialized
INFO - 2016-02-18 14:29:46 --> Loader Class Initialized
INFO - 2016-02-18 14:29:46 --> Helper loaded: url_helper
INFO - 2016-02-18 14:29:46 --> Helper loaded: file_helper
INFO - 2016-02-18 14:29:46 --> Helper loaded: date_helper
INFO - 2016-02-18 14:29:46 --> Helper loaded: form_helper
INFO - 2016-02-18 14:29:46 --> Database Driver Class Initialized
INFO - 2016-02-18 14:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:29:47 --> Controller Class Initialized
INFO - 2016-02-18 14:29:47 --> Model Class Initialized
INFO - 2016-02-18 14:29:47 --> Model Class Initialized
INFO - 2016-02-18 14:29:47 --> Form Validation Class Initialized
INFO - 2016-02-18 14:29:47 --> Helper loaded: text_helper
INFO - 2016-02-18 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-18 14:29:47 --> Model Class Initialized
INFO - 2016-02-18 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-18 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 14:29:47 --> Final output sent to browser
DEBUG - 2016-02-18 14:29:47 --> Total execution time: 1.1236
INFO - 2016-02-18 14:29:55 --> Config Class Initialized
INFO - 2016-02-18 14:29:55 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:29:55 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:29:55 --> Utf8 Class Initialized
INFO - 2016-02-18 14:29:55 --> URI Class Initialized
DEBUG - 2016-02-18 14:29:55 --> No URI present. Default controller set.
INFO - 2016-02-18 14:29:55 --> Router Class Initialized
INFO - 2016-02-18 14:29:55 --> Output Class Initialized
INFO - 2016-02-18 14:29:55 --> Security Class Initialized
DEBUG - 2016-02-18 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:29:55 --> Input Class Initialized
INFO - 2016-02-18 14:29:55 --> Language Class Initialized
INFO - 2016-02-18 14:29:55 --> Loader Class Initialized
INFO - 2016-02-18 14:29:55 --> Helper loaded: url_helper
INFO - 2016-02-18 14:29:55 --> Helper loaded: file_helper
INFO - 2016-02-18 14:29:55 --> Helper loaded: date_helper
INFO - 2016-02-18 14:29:55 --> Helper loaded: form_helper
INFO - 2016-02-18 14:29:55 --> Database Driver Class Initialized
INFO - 2016-02-18 14:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:29:56 --> Controller Class Initialized
INFO - 2016-02-18 14:29:56 --> Model Class Initialized
INFO - 2016-02-18 14:29:56 --> Model Class Initialized
INFO - 2016-02-18 14:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:29:56 --> Pagination Class Initialized
INFO - 2016-02-18 14:29:56 --> Helper loaded: text_helper
INFO - 2016-02-18 14:29:56 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:29:56 --> Final output sent to browser
DEBUG - 2016-02-18 17:29:56 --> Total execution time: 1.1477
INFO - 2016-02-18 14:31:56 --> Config Class Initialized
INFO - 2016-02-18 14:31:56 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:31:56 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:31:56 --> Utf8 Class Initialized
INFO - 2016-02-18 14:31:56 --> URI Class Initialized
DEBUG - 2016-02-18 14:31:56 --> No URI present. Default controller set.
INFO - 2016-02-18 14:31:56 --> Router Class Initialized
INFO - 2016-02-18 14:31:56 --> Output Class Initialized
INFO - 2016-02-18 14:31:56 --> Security Class Initialized
DEBUG - 2016-02-18 14:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:31:56 --> Input Class Initialized
INFO - 2016-02-18 14:31:56 --> Language Class Initialized
INFO - 2016-02-18 14:31:56 --> Loader Class Initialized
INFO - 2016-02-18 14:31:56 --> Helper loaded: url_helper
INFO - 2016-02-18 14:31:56 --> Helper loaded: file_helper
INFO - 2016-02-18 14:31:56 --> Helper loaded: date_helper
INFO - 2016-02-18 14:31:56 --> Helper loaded: form_helper
INFO - 2016-02-18 14:31:56 --> Database Driver Class Initialized
INFO - 2016-02-18 14:31:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:31:57 --> Controller Class Initialized
INFO - 2016-02-18 14:31:57 --> Model Class Initialized
INFO - 2016-02-18 14:31:57 --> Model Class Initialized
INFO - 2016-02-18 14:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:31:57 --> Pagination Class Initialized
INFO - 2016-02-18 14:31:57 --> Helper loaded: text_helper
INFO - 2016-02-18 14:31:57 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:31:57 --> Final output sent to browser
DEBUG - 2016-02-18 17:31:57 --> Total execution time: 1.1399
INFO - 2016-02-18 14:32:20 --> Config Class Initialized
INFO - 2016-02-18 14:32:20 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:32:20 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:32:20 --> Utf8 Class Initialized
INFO - 2016-02-18 14:32:20 --> URI Class Initialized
DEBUG - 2016-02-18 14:32:20 --> No URI present. Default controller set.
INFO - 2016-02-18 14:32:20 --> Router Class Initialized
INFO - 2016-02-18 14:32:20 --> Output Class Initialized
INFO - 2016-02-18 14:32:20 --> Security Class Initialized
DEBUG - 2016-02-18 14:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:32:20 --> Input Class Initialized
INFO - 2016-02-18 14:32:20 --> Language Class Initialized
INFO - 2016-02-18 14:32:21 --> Loader Class Initialized
INFO - 2016-02-18 14:32:21 --> Helper loaded: url_helper
INFO - 2016-02-18 14:32:21 --> Helper loaded: file_helper
INFO - 2016-02-18 14:32:21 --> Helper loaded: date_helper
INFO - 2016-02-18 14:32:21 --> Helper loaded: form_helper
INFO - 2016-02-18 14:32:21 --> Database Driver Class Initialized
INFO - 2016-02-18 14:32:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:32:22 --> Controller Class Initialized
INFO - 2016-02-18 14:32:22 --> Model Class Initialized
INFO - 2016-02-18 14:32:22 --> Model Class Initialized
INFO - 2016-02-18 14:32:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:32:22 --> Pagination Class Initialized
INFO - 2016-02-18 14:32:22 --> Helper loaded: text_helper
INFO - 2016-02-18 14:32:22 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 17:32:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 17:32:22 --> Final output sent to browser
DEBUG - 2016-02-18 17:32:22 --> Total execution time: 1.1500
INFO - 2016-02-18 14:33:59 --> Config Class Initialized
INFO - 2016-02-18 14:33:59 --> Hooks Class Initialized
DEBUG - 2016-02-18 14:33:59 --> UTF-8 Support Enabled
INFO - 2016-02-18 14:33:59 --> Utf8 Class Initialized
INFO - 2016-02-18 14:33:59 --> URI Class Initialized
INFO - 2016-02-18 14:33:59 --> Router Class Initialized
INFO - 2016-02-18 14:33:59 --> Output Class Initialized
INFO - 2016-02-18 14:33:59 --> Security Class Initialized
DEBUG - 2016-02-18 14:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 14:33:59 --> Input Class Initialized
INFO - 2016-02-18 14:33:59 --> Language Class Initialized
INFO - 2016-02-18 14:33:59 --> Loader Class Initialized
INFO - 2016-02-18 14:33:59 --> Helper loaded: url_helper
INFO - 2016-02-18 14:33:59 --> Helper loaded: file_helper
INFO - 2016-02-18 14:33:59 --> Helper loaded: date_helper
INFO - 2016-02-18 14:33:59 --> Helper loaded: form_helper
INFO - 2016-02-18 14:33:59 --> Database Driver Class Initialized
INFO - 2016-02-18 14:34:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 14:34:00 --> Controller Class Initialized
INFO - 2016-02-18 14:34:00 --> Model Class Initialized
INFO - 2016-02-18 14:34:00 --> Model Class Initialized
INFO - 2016-02-18 14:34:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 14:34:00 --> Pagination Class Initialized
INFO - 2016-02-18 14:34:00 --> Helper loaded: text_helper
INFO - 2016-02-18 14:34:00 --> Helper loaded: cookie_helper
INFO - 2016-02-18 17:34:00 --> Form Validation Class Initialized
INFO - 2016-02-18 17:34:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 17:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 17:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 17:34:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 17:34:01 --> Final output sent to browser
DEBUG - 2016-02-18 17:34:01 --> Total execution time: 1.1769
INFO - 2016-02-18 15:32:40 --> Config Class Initialized
INFO - 2016-02-18 15:32:40 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:32:40 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:32:40 --> Utf8 Class Initialized
INFO - 2016-02-18 15:32:40 --> URI Class Initialized
DEBUG - 2016-02-18 15:32:40 --> No URI present. Default controller set.
INFO - 2016-02-18 15:32:40 --> Router Class Initialized
INFO - 2016-02-18 15:32:40 --> Output Class Initialized
INFO - 2016-02-18 15:32:40 --> Security Class Initialized
DEBUG - 2016-02-18 15:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:32:40 --> Input Class Initialized
INFO - 2016-02-18 15:32:40 --> Language Class Initialized
INFO - 2016-02-18 15:32:40 --> Loader Class Initialized
INFO - 2016-02-18 15:32:40 --> Helper loaded: url_helper
INFO - 2016-02-18 15:32:40 --> Helper loaded: file_helper
INFO - 2016-02-18 15:32:40 --> Helper loaded: date_helper
INFO - 2016-02-18 15:32:40 --> Helper loaded: form_helper
INFO - 2016-02-18 15:32:40 --> Database Driver Class Initialized
INFO - 2016-02-18 15:32:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:32:41 --> Controller Class Initialized
INFO - 2016-02-18 15:32:42 --> Model Class Initialized
INFO - 2016-02-18 15:32:42 --> Model Class Initialized
INFO - 2016-02-18 15:32:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:32:42 --> Pagination Class Initialized
INFO - 2016-02-18 15:32:42 --> Helper loaded: text_helper
INFO - 2016-02-18 15:32:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:32:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:32:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:32:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:32:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:32:42 --> Final output sent to browser
DEBUG - 2016-02-18 18:32:42 --> Total execution time: 1.1141
INFO - 2016-02-18 15:33:00 --> Config Class Initialized
INFO - 2016-02-18 15:33:00 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:33:00 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:33:00 --> Utf8 Class Initialized
INFO - 2016-02-18 15:33:00 --> URI Class Initialized
INFO - 2016-02-18 15:33:00 --> Router Class Initialized
INFO - 2016-02-18 15:33:00 --> Output Class Initialized
INFO - 2016-02-18 15:33:00 --> Security Class Initialized
DEBUG - 2016-02-18 15:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:33:00 --> Input Class Initialized
INFO - 2016-02-18 15:33:00 --> Language Class Initialized
INFO - 2016-02-18 15:33:00 --> Loader Class Initialized
INFO - 2016-02-18 15:33:00 --> Helper loaded: url_helper
INFO - 2016-02-18 15:33:00 --> Helper loaded: file_helper
INFO - 2016-02-18 15:33:00 --> Helper loaded: date_helper
INFO - 2016-02-18 15:33:00 --> Helper loaded: form_helper
INFO - 2016-02-18 15:33:00 --> Database Driver Class Initialized
INFO - 2016-02-18 15:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:33:01 --> Controller Class Initialized
INFO - 2016-02-18 15:33:01 --> Model Class Initialized
INFO - 2016-02-18 15:33:01 --> Model Class Initialized
INFO - 2016-02-18 15:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:33:01 --> Pagination Class Initialized
INFO - 2016-02-18 15:33:01 --> Helper loaded: text_helper
INFO - 2016-02-18 15:33:01 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:33:01 --> Form Validation Class Initialized
INFO - 2016-02-18 18:33:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 18:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 18:33:01 --> Final output sent to browser
DEBUG - 2016-02-18 18:33:01 --> Total execution time: 1.1511
INFO - 2016-02-18 15:33:34 --> Config Class Initialized
INFO - 2016-02-18 15:33:34 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:33:34 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:33:34 --> Utf8 Class Initialized
INFO - 2016-02-18 15:33:34 --> URI Class Initialized
INFO - 2016-02-18 15:33:34 --> Router Class Initialized
INFO - 2016-02-18 15:33:34 --> Output Class Initialized
INFO - 2016-02-18 15:33:34 --> Security Class Initialized
DEBUG - 2016-02-18 15:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:33:34 --> Input Class Initialized
INFO - 2016-02-18 15:33:34 --> Language Class Initialized
INFO - 2016-02-18 15:33:34 --> Loader Class Initialized
INFO - 2016-02-18 15:33:34 --> Helper loaded: url_helper
INFO - 2016-02-18 15:33:34 --> Helper loaded: file_helper
INFO - 2016-02-18 15:33:34 --> Helper loaded: date_helper
INFO - 2016-02-18 15:33:34 --> Helper loaded: form_helper
INFO - 2016-02-18 15:33:34 --> Database Driver Class Initialized
INFO - 2016-02-18 15:33:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:33:36 --> Controller Class Initialized
INFO - 2016-02-18 15:33:36 --> Model Class Initialized
INFO - 2016-02-18 15:33:36 --> Model Class Initialized
INFO - 2016-02-18 15:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:33:36 --> Pagination Class Initialized
INFO - 2016-02-18 15:33:36 --> Helper loaded: text_helper
INFO - 2016-02-18 15:33:36 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:33:36 --> Form Validation Class Initialized
INFO - 2016-02-18 18:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 18:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 18:33:36 --> Final output sent to browser
DEBUG - 2016-02-18 18:33:36 --> Total execution time: 1.1408
INFO - 2016-02-18 15:34:22 --> Config Class Initialized
INFO - 2016-02-18 15:34:22 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:34:22 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:34:22 --> Utf8 Class Initialized
INFO - 2016-02-18 15:34:22 --> URI Class Initialized
INFO - 2016-02-18 15:34:22 --> Router Class Initialized
INFO - 2016-02-18 15:34:22 --> Output Class Initialized
INFO - 2016-02-18 15:34:22 --> Security Class Initialized
DEBUG - 2016-02-18 15:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:34:22 --> Input Class Initialized
INFO - 2016-02-18 15:34:22 --> Language Class Initialized
INFO - 2016-02-18 15:34:22 --> Loader Class Initialized
INFO - 2016-02-18 15:34:22 --> Helper loaded: url_helper
INFO - 2016-02-18 15:34:22 --> Helper loaded: file_helper
INFO - 2016-02-18 15:34:22 --> Helper loaded: date_helper
INFO - 2016-02-18 15:34:22 --> Helper loaded: form_helper
INFO - 2016-02-18 15:34:22 --> Database Driver Class Initialized
INFO - 2016-02-18 15:34:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:34:23 --> Controller Class Initialized
INFO - 2016-02-18 15:34:23 --> Model Class Initialized
INFO - 2016-02-18 15:34:23 --> Model Class Initialized
INFO - 2016-02-18 15:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:34:23 --> Pagination Class Initialized
INFO - 2016-02-18 15:34:23 --> Helper loaded: text_helper
INFO - 2016-02-18 15:34:23 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:34:24 --> Form Validation Class Initialized
INFO - 2016-02-18 18:34:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 18:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 18:34:24 --> Final output sent to browser
DEBUG - 2016-02-18 18:34:24 --> Total execution time: 1.1559
INFO - 2016-02-18 15:34:43 --> Config Class Initialized
INFO - 2016-02-18 15:34:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:34:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:34:43 --> Utf8 Class Initialized
INFO - 2016-02-18 15:34:43 --> URI Class Initialized
INFO - 2016-02-18 15:34:43 --> Router Class Initialized
INFO - 2016-02-18 15:34:43 --> Output Class Initialized
INFO - 2016-02-18 15:34:43 --> Security Class Initialized
DEBUG - 2016-02-18 15:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:34:43 --> Input Class Initialized
INFO - 2016-02-18 15:34:43 --> Language Class Initialized
INFO - 2016-02-18 15:34:43 --> Loader Class Initialized
INFO - 2016-02-18 15:34:43 --> Helper loaded: url_helper
INFO - 2016-02-18 15:34:43 --> Helper loaded: file_helper
INFO - 2016-02-18 15:34:43 --> Helper loaded: date_helper
INFO - 2016-02-18 15:34:43 --> Helper loaded: form_helper
INFO - 2016-02-18 15:34:43 --> Database Driver Class Initialized
INFO - 2016-02-18 15:34:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:34:44 --> Controller Class Initialized
INFO - 2016-02-18 15:34:44 --> Model Class Initialized
INFO - 2016-02-18 15:34:44 --> Model Class Initialized
INFO - 2016-02-18 15:34:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:34:44 --> Pagination Class Initialized
INFO - 2016-02-18 15:34:44 --> Helper loaded: text_helper
INFO - 2016-02-18 15:34:44 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:34:44 --> Form Validation Class Initialized
INFO - 2016-02-18 18:34:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 18:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:34:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 18:34:44 --> Final output sent to browser
DEBUG - 2016-02-18 18:34:44 --> Total execution time: 1.1392
INFO - 2016-02-18 15:35:16 --> Config Class Initialized
INFO - 2016-02-18 15:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:35:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:35:16 --> Utf8 Class Initialized
INFO - 2016-02-18 15:35:16 --> URI Class Initialized
INFO - 2016-02-18 15:35:16 --> Router Class Initialized
INFO - 2016-02-18 15:35:16 --> Output Class Initialized
INFO - 2016-02-18 15:35:16 --> Security Class Initialized
DEBUG - 2016-02-18 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:35:16 --> Input Class Initialized
INFO - 2016-02-18 15:35:16 --> Language Class Initialized
INFO - 2016-02-18 15:35:16 --> Loader Class Initialized
INFO - 2016-02-18 15:35:16 --> Helper loaded: url_helper
INFO - 2016-02-18 15:35:16 --> Helper loaded: file_helper
INFO - 2016-02-18 15:35:16 --> Helper loaded: date_helper
INFO - 2016-02-18 15:35:16 --> Helper loaded: form_helper
INFO - 2016-02-18 15:35:16 --> Database Driver Class Initialized
INFO - 2016-02-18 15:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:35:17 --> Controller Class Initialized
INFO - 2016-02-18 15:35:17 --> Model Class Initialized
INFO - 2016-02-18 15:35:17 --> Model Class Initialized
INFO - 2016-02-18 15:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:35:17 --> Pagination Class Initialized
INFO - 2016-02-18 15:35:17 --> Helper loaded: text_helper
INFO - 2016-02-18 15:35:17 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:35:17 --> Form Validation Class Initialized
INFO - 2016-02-18 18:35:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-18 18:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-18 18:35:17 --> Final output sent to browser
DEBUG - 2016-02-18 18:35:17 --> Total execution time: 1.1849
INFO - 2016-02-18 15:44:07 --> Config Class Initialized
INFO - 2016-02-18 15:44:07 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:44:07 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:44:07 --> Utf8 Class Initialized
INFO - 2016-02-18 15:44:07 --> URI Class Initialized
DEBUG - 2016-02-18 15:44:07 --> No URI present. Default controller set.
INFO - 2016-02-18 15:44:07 --> Router Class Initialized
INFO - 2016-02-18 15:44:07 --> Output Class Initialized
INFO - 2016-02-18 15:44:07 --> Security Class Initialized
DEBUG - 2016-02-18 15:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:44:07 --> Input Class Initialized
INFO - 2016-02-18 15:44:07 --> Language Class Initialized
INFO - 2016-02-18 15:44:07 --> Loader Class Initialized
INFO - 2016-02-18 15:44:07 --> Helper loaded: url_helper
INFO - 2016-02-18 15:44:07 --> Helper loaded: file_helper
INFO - 2016-02-18 15:44:07 --> Helper loaded: date_helper
INFO - 2016-02-18 15:44:07 --> Helper loaded: form_helper
INFO - 2016-02-18 15:44:07 --> Database Driver Class Initialized
INFO - 2016-02-18 15:44:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:44:08 --> Controller Class Initialized
INFO - 2016-02-18 15:44:08 --> Model Class Initialized
INFO - 2016-02-18 15:44:08 --> Model Class Initialized
INFO - 2016-02-18 15:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:44:08 --> Pagination Class Initialized
INFO - 2016-02-18 15:44:08 --> Helper loaded: text_helper
INFO - 2016-02-18 15:44:08 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:44:08 --> Final output sent to browser
DEBUG - 2016-02-18 18:44:08 --> Total execution time: 1.1416
INFO - 2016-02-18 15:44:38 --> Config Class Initialized
INFO - 2016-02-18 15:44:38 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:44:38 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:44:38 --> Utf8 Class Initialized
INFO - 2016-02-18 15:44:38 --> URI Class Initialized
DEBUG - 2016-02-18 15:44:38 --> No URI present. Default controller set.
INFO - 2016-02-18 15:44:38 --> Router Class Initialized
INFO - 2016-02-18 15:44:38 --> Output Class Initialized
INFO - 2016-02-18 15:44:38 --> Security Class Initialized
DEBUG - 2016-02-18 15:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:44:38 --> Input Class Initialized
INFO - 2016-02-18 15:44:38 --> Language Class Initialized
INFO - 2016-02-18 15:44:38 --> Loader Class Initialized
INFO - 2016-02-18 15:44:38 --> Helper loaded: url_helper
INFO - 2016-02-18 15:44:38 --> Helper loaded: file_helper
INFO - 2016-02-18 15:44:38 --> Helper loaded: date_helper
INFO - 2016-02-18 15:44:38 --> Helper loaded: form_helper
INFO - 2016-02-18 15:44:38 --> Database Driver Class Initialized
INFO - 2016-02-18 15:44:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:44:39 --> Controller Class Initialized
INFO - 2016-02-18 15:44:39 --> Model Class Initialized
INFO - 2016-02-18 15:44:39 --> Model Class Initialized
INFO - 2016-02-18 15:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:44:39 --> Pagination Class Initialized
INFO - 2016-02-18 15:44:39 --> Helper loaded: text_helper
INFO - 2016-02-18 15:44:39 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:44:39 --> Final output sent to browser
DEBUG - 2016-02-18 18:44:39 --> Total execution time: 1.1484
INFO - 2016-02-18 15:44:59 --> Config Class Initialized
INFO - 2016-02-18 15:44:59 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:44:59 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:44:59 --> Utf8 Class Initialized
INFO - 2016-02-18 15:44:59 --> URI Class Initialized
DEBUG - 2016-02-18 15:44:59 --> No URI present. Default controller set.
INFO - 2016-02-18 15:44:59 --> Router Class Initialized
INFO - 2016-02-18 15:44:59 --> Output Class Initialized
INFO - 2016-02-18 15:44:59 --> Security Class Initialized
DEBUG - 2016-02-18 15:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:44:59 --> Input Class Initialized
INFO - 2016-02-18 15:44:59 --> Language Class Initialized
INFO - 2016-02-18 15:44:59 --> Loader Class Initialized
INFO - 2016-02-18 15:44:59 --> Helper loaded: url_helper
INFO - 2016-02-18 15:44:59 --> Helper loaded: file_helper
INFO - 2016-02-18 15:44:59 --> Helper loaded: date_helper
INFO - 2016-02-18 15:44:59 --> Helper loaded: form_helper
INFO - 2016-02-18 15:44:59 --> Database Driver Class Initialized
INFO - 2016-02-18 15:45:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:45:01 --> Controller Class Initialized
INFO - 2016-02-18 15:45:01 --> Model Class Initialized
INFO - 2016-02-18 15:45:01 --> Model Class Initialized
INFO - 2016-02-18 15:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:45:01 --> Pagination Class Initialized
INFO - 2016-02-18 15:45:01 --> Helper loaded: text_helper
INFO - 2016-02-18 15:45:01 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:45:01 --> Final output sent to browser
DEBUG - 2016-02-18 18:45:01 --> Total execution time: 1.1587
INFO - 2016-02-18 15:45:11 --> Config Class Initialized
INFO - 2016-02-18 15:45:11 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:45:11 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:45:11 --> Utf8 Class Initialized
INFO - 2016-02-18 15:45:11 --> URI Class Initialized
DEBUG - 2016-02-18 15:45:11 --> No URI present. Default controller set.
INFO - 2016-02-18 15:45:11 --> Router Class Initialized
INFO - 2016-02-18 15:45:11 --> Output Class Initialized
INFO - 2016-02-18 15:45:11 --> Security Class Initialized
DEBUG - 2016-02-18 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:45:11 --> Input Class Initialized
INFO - 2016-02-18 15:45:11 --> Language Class Initialized
INFO - 2016-02-18 15:45:11 --> Loader Class Initialized
INFO - 2016-02-18 15:45:11 --> Helper loaded: url_helper
INFO - 2016-02-18 15:45:11 --> Helper loaded: file_helper
INFO - 2016-02-18 15:45:11 --> Helper loaded: date_helper
INFO - 2016-02-18 15:45:11 --> Helper loaded: form_helper
INFO - 2016-02-18 15:45:11 --> Database Driver Class Initialized
INFO - 2016-02-18 15:45:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:45:12 --> Controller Class Initialized
INFO - 2016-02-18 15:45:12 --> Model Class Initialized
INFO - 2016-02-18 15:45:12 --> Model Class Initialized
INFO - 2016-02-18 15:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:45:12 --> Pagination Class Initialized
INFO - 2016-02-18 15:45:12 --> Helper loaded: text_helper
INFO - 2016-02-18 15:45:12 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:45:12 --> Final output sent to browser
DEBUG - 2016-02-18 18:45:12 --> Total execution time: 1.1016
INFO - 2016-02-18 15:45:36 --> Config Class Initialized
INFO - 2016-02-18 15:45:36 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:45:36 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:45:36 --> Utf8 Class Initialized
INFO - 2016-02-18 15:45:36 --> URI Class Initialized
DEBUG - 2016-02-18 15:45:36 --> No URI present. Default controller set.
INFO - 2016-02-18 15:45:36 --> Router Class Initialized
INFO - 2016-02-18 15:45:36 --> Output Class Initialized
INFO - 2016-02-18 15:45:36 --> Security Class Initialized
DEBUG - 2016-02-18 15:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:45:36 --> Input Class Initialized
INFO - 2016-02-18 15:45:36 --> Language Class Initialized
INFO - 2016-02-18 15:45:36 --> Loader Class Initialized
INFO - 2016-02-18 15:45:36 --> Helper loaded: url_helper
INFO - 2016-02-18 15:45:36 --> Helper loaded: file_helper
INFO - 2016-02-18 15:45:36 --> Helper loaded: date_helper
INFO - 2016-02-18 15:45:36 --> Helper loaded: form_helper
INFO - 2016-02-18 15:45:36 --> Database Driver Class Initialized
INFO - 2016-02-18 15:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:45:37 --> Controller Class Initialized
INFO - 2016-02-18 15:45:37 --> Model Class Initialized
INFO - 2016-02-18 15:45:37 --> Model Class Initialized
INFO - 2016-02-18 15:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:45:37 --> Pagination Class Initialized
INFO - 2016-02-18 15:45:37 --> Helper loaded: text_helper
INFO - 2016-02-18 15:45:37 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:45:37 --> Final output sent to browser
DEBUG - 2016-02-18 18:45:37 --> Total execution time: 1.1508
INFO - 2016-02-18 15:45:44 --> Config Class Initialized
INFO - 2016-02-18 15:45:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:45:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:45:44 --> Utf8 Class Initialized
INFO - 2016-02-18 15:45:44 --> URI Class Initialized
DEBUG - 2016-02-18 15:45:44 --> No URI present. Default controller set.
INFO - 2016-02-18 15:45:44 --> Router Class Initialized
INFO - 2016-02-18 15:45:44 --> Output Class Initialized
INFO - 2016-02-18 15:45:44 --> Security Class Initialized
DEBUG - 2016-02-18 15:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:45:44 --> Input Class Initialized
INFO - 2016-02-18 15:45:44 --> Language Class Initialized
INFO - 2016-02-18 15:45:44 --> Loader Class Initialized
INFO - 2016-02-18 15:45:44 --> Helper loaded: url_helper
INFO - 2016-02-18 15:45:44 --> Helper loaded: file_helper
INFO - 2016-02-18 15:45:44 --> Helper loaded: date_helper
INFO - 2016-02-18 15:45:44 --> Helper loaded: form_helper
INFO - 2016-02-18 15:45:44 --> Database Driver Class Initialized
INFO - 2016-02-18 15:45:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:45:45 --> Controller Class Initialized
INFO - 2016-02-18 15:45:45 --> Model Class Initialized
INFO - 2016-02-18 15:45:45 --> Model Class Initialized
INFO - 2016-02-18 15:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:45:45 --> Pagination Class Initialized
INFO - 2016-02-18 15:45:45 --> Helper loaded: text_helper
INFO - 2016-02-18 15:45:45 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:45:45 --> Final output sent to browser
DEBUG - 2016-02-18 18:45:45 --> Total execution time: 1.1720
INFO - 2016-02-18 15:46:38 --> Config Class Initialized
INFO - 2016-02-18 15:46:38 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:46:38 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:46:38 --> Utf8 Class Initialized
INFO - 2016-02-18 15:46:38 --> URI Class Initialized
DEBUG - 2016-02-18 15:46:38 --> No URI present. Default controller set.
INFO - 2016-02-18 15:46:38 --> Router Class Initialized
INFO - 2016-02-18 15:46:38 --> Output Class Initialized
INFO - 2016-02-18 15:46:38 --> Security Class Initialized
DEBUG - 2016-02-18 15:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:46:38 --> Input Class Initialized
INFO - 2016-02-18 15:46:38 --> Language Class Initialized
INFO - 2016-02-18 15:46:39 --> Loader Class Initialized
INFO - 2016-02-18 15:46:39 --> Helper loaded: url_helper
INFO - 2016-02-18 15:46:39 --> Helper loaded: file_helper
INFO - 2016-02-18 15:46:39 --> Helper loaded: date_helper
INFO - 2016-02-18 15:46:39 --> Helper loaded: form_helper
INFO - 2016-02-18 15:46:39 --> Database Driver Class Initialized
INFO - 2016-02-18 15:46:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:46:40 --> Controller Class Initialized
INFO - 2016-02-18 15:46:40 --> Model Class Initialized
INFO - 2016-02-18 15:46:40 --> Model Class Initialized
INFO - 2016-02-18 15:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:46:40 --> Pagination Class Initialized
INFO - 2016-02-18 15:46:40 --> Helper loaded: text_helper
INFO - 2016-02-18 15:46:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:46:40 --> Final output sent to browser
DEBUG - 2016-02-18 18:46:40 --> Total execution time: 1.1343
INFO - 2016-02-18 15:51:03 --> Config Class Initialized
INFO - 2016-02-18 15:51:03 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:51:03 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:51:03 --> Utf8 Class Initialized
INFO - 2016-02-18 15:51:03 --> URI Class Initialized
DEBUG - 2016-02-18 15:51:03 --> No URI present. Default controller set.
INFO - 2016-02-18 15:51:03 --> Router Class Initialized
INFO - 2016-02-18 15:51:03 --> Output Class Initialized
INFO - 2016-02-18 15:51:03 --> Security Class Initialized
DEBUG - 2016-02-18 15:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:51:03 --> Input Class Initialized
INFO - 2016-02-18 15:51:03 --> Language Class Initialized
INFO - 2016-02-18 15:51:03 --> Loader Class Initialized
INFO - 2016-02-18 15:51:03 --> Helper loaded: url_helper
INFO - 2016-02-18 15:51:03 --> Helper loaded: file_helper
INFO - 2016-02-18 15:51:03 --> Helper loaded: date_helper
INFO - 2016-02-18 15:51:03 --> Helper loaded: form_helper
INFO - 2016-02-18 15:51:03 --> Database Driver Class Initialized
INFO - 2016-02-18 15:51:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:51:04 --> Controller Class Initialized
INFO - 2016-02-18 15:51:04 --> Model Class Initialized
INFO - 2016-02-18 15:51:04 --> Model Class Initialized
INFO - 2016-02-18 15:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:51:04 --> Pagination Class Initialized
INFO - 2016-02-18 15:51:04 --> Helper loaded: text_helper
INFO - 2016-02-18 15:51:04 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:51:04 --> Final output sent to browser
DEBUG - 2016-02-18 18:51:04 --> Total execution time: 1.1239
INFO - 2016-02-18 15:52:43 --> Config Class Initialized
INFO - 2016-02-18 15:52:43 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:52:43 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:52:43 --> Utf8 Class Initialized
INFO - 2016-02-18 15:52:43 --> URI Class Initialized
DEBUG - 2016-02-18 15:52:43 --> No URI present. Default controller set.
INFO - 2016-02-18 15:52:43 --> Router Class Initialized
INFO - 2016-02-18 15:52:43 --> Output Class Initialized
INFO - 2016-02-18 15:52:43 --> Security Class Initialized
DEBUG - 2016-02-18 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:52:43 --> Input Class Initialized
INFO - 2016-02-18 15:52:43 --> Language Class Initialized
INFO - 2016-02-18 15:52:43 --> Loader Class Initialized
INFO - 2016-02-18 15:52:43 --> Helper loaded: url_helper
INFO - 2016-02-18 15:52:43 --> Helper loaded: file_helper
INFO - 2016-02-18 15:52:43 --> Helper loaded: date_helper
INFO - 2016-02-18 15:52:43 --> Helper loaded: form_helper
INFO - 2016-02-18 15:52:43 --> Database Driver Class Initialized
INFO - 2016-02-18 15:52:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:52:44 --> Controller Class Initialized
INFO - 2016-02-18 15:52:44 --> Model Class Initialized
INFO - 2016-02-18 15:52:44 --> Model Class Initialized
INFO - 2016-02-18 15:52:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:52:44 --> Pagination Class Initialized
INFO - 2016-02-18 15:52:44 --> Helper loaded: text_helper
INFO - 2016-02-18 15:52:44 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:52:44 --> Final output sent to browser
DEBUG - 2016-02-18 18:52:44 --> Total execution time: 1.1881
INFO - 2016-02-18 15:53:24 --> Config Class Initialized
INFO - 2016-02-18 15:53:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 15:53:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 15:53:24 --> Utf8 Class Initialized
INFO - 2016-02-18 15:53:24 --> URI Class Initialized
DEBUG - 2016-02-18 15:53:24 --> No URI present. Default controller set.
INFO - 2016-02-18 15:53:24 --> Router Class Initialized
INFO - 2016-02-18 15:53:24 --> Output Class Initialized
INFO - 2016-02-18 15:53:24 --> Security Class Initialized
DEBUG - 2016-02-18 15:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 15:53:24 --> Input Class Initialized
INFO - 2016-02-18 15:53:24 --> Language Class Initialized
INFO - 2016-02-18 15:53:24 --> Loader Class Initialized
INFO - 2016-02-18 15:53:24 --> Helper loaded: url_helper
INFO - 2016-02-18 15:53:24 --> Helper loaded: file_helper
INFO - 2016-02-18 15:53:24 --> Helper loaded: date_helper
INFO - 2016-02-18 15:53:24 --> Helper loaded: form_helper
INFO - 2016-02-18 15:53:24 --> Database Driver Class Initialized
INFO - 2016-02-18 15:53:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 15:53:25 --> Controller Class Initialized
INFO - 2016-02-18 15:53:25 --> Model Class Initialized
INFO - 2016-02-18 15:53:25 --> Model Class Initialized
INFO - 2016-02-18 15:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 15:53:25 --> Pagination Class Initialized
INFO - 2016-02-18 15:53:25 --> Helper loaded: text_helper
INFO - 2016-02-18 15:53:25 --> Helper loaded: cookie_helper
INFO - 2016-02-18 18:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 18:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 18:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 18:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 18:53:25 --> Final output sent to browser
DEBUG - 2016-02-18 18:53:25 --> Total execution time: 1.1332
INFO - 2016-02-18 20:55:58 --> Config Class Initialized
INFO - 2016-02-18 20:55:58 --> Hooks Class Initialized
DEBUG - 2016-02-18 20:55:58 --> UTF-8 Support Enabled
INFO - 2016-02-18 20:55:58 --> Utf8 Class Initialized
INFO - 2016-02-18 20:55:58 --> URI Class Initialized
DEBUG - 2016-02-18 20:55:58 --> No URI present. Default controller set.
INFO - 2016-02-18 20:55:58 --> Router Class Initialized
INFO - 2016-02-18 20:55:58 --> Output Class Initialized
INFO - 2016-02-18 20:55:58 --> Security Class Initialized
DEBUG - 2016-02-18 20:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 20:55:58 --> Input Class Initialized
INFO - 2016-02-18 20:55:58 --> Language Class Initialized
INFO - 2016-02-18 20:55:58 --> Loader Class Initialized
INFO - 2016-02-18 20:55:58 --> Helper loaded: url_helper
INFO - 2016-02-18 20:55:58 --> Helper loaded: file_helper
INFO - 2016-02-18 20:55:58 --> Helper loaded: date_helper
INFO - 2016-02-18 20:55:58 --> Helper loaded: form_helper
INFO - 2016-02-18 20:55:58 --> Database Driver Class Initialized
INFO - 2016-02-18 20:55:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 20:55:59 --> Controller Class Initialized
INFO - 2016-02-18 20:55:59 --> Model Class Initialized
INFO - 2016-02-18 20:55:59 --> Model Class Initialized
INFO - 2016-02-18 20:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 20:55:59 --> Pagination Class Initialized
INFO - 2016-02-18 20:55:59 --> Helper loaded: text_helper
INFO - 2016-02-18 20:55:59 --> Helper loaded: cookie_helper
INFO - 2016-02-18 23:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 23:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 23:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-18 23:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-18 23:55:59 --> Final output sent to browser
DEBUG - 2016-02-18 23:55:59 --> Total execution time: 1.1976
INFO - 2016-02-18 21:02:25 --> Config Class Initialized
INFO - 2016-02-18 21:02:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:02:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:02:25 --> Utf8 Class Initialized
INFO - 2016-02-18 21:02:25 --> URI Class Initialized
DEBUG - 2016-02-18 21:02:25 --> No URI present. Default controller set.
INFO - 2016-02-18 21:02:25 --> Router Class Initialized
INFO - 2016-02-18 21:02:25 --> Output Class Initialized
INFO - 2016-02-18 21:02:25 --> Security Class Initialized
DEBUG - 2016-02-18 21:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:02:25 --> Input Class Initialized
INFO - 2016-02-18 21:02:25 --> Language Class Initialized
INFO - 2016-02-18 21:02:25 --> Loader Class Initialized
INFO - 2016-02-18 21:02:25 --> Helper loaded: url_helper
INFO - 2016-02-18 21:02:25 --> Helper loaded: file_helper
INFO - 2016-02-18 21:02:25 --> Helper loaded: date_helper
INFO - 2016-02-18 21:02:25 --> Helper loaded: form_helper
INFO - 2016-02-18 21:02:25 --> Database Driver Class Initialized
INFO - 2016-02-18 21:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:02:26 --> Controller Class Initialized
INFO - 2016-02-18 21:02:27 --> Model Class Initialized
INFO - 2016-02-18 21:02:27 --> Model Class Initialized
INFO - 2016-02-18 21:02:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:02:27 --> Pagination Class Initialized
INFO - 2016-02-18 21:02:27 --> Helper loaded: text_helper
INFO - 2016-02-18 21:02:27 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:02:45 --> Config Class Initialized
INFO - 2016-02-18 21:02:45 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:02:45 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:02:45 --> Utf8 Class Initialized
INFO - 2016-02-18 21:02:45 --> URI Class Initialized
INFO - 2016-02-18 21:02:45 --> Router Class Initialized
INFO - 2016-02-18 21:02:45 --> Output Class Initialized
INFO - 2016-02-18 21:02:45 --> Security Class Initialized
DEBUG - 2016-02-18 21:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:02:45 --> Input Class Initialized
INFO - 2016-02-18 21:02:45 --> Language Class Initialized
INFO - 2016-02-18 21:02:45 --> Loader Class Initialized
INFO - 2016-02-18 21:02:45 --> Helper loaded: url_helper
INFO - 2016-02-18 21:02:45 --> Helper loaded: file_helper
INFO - 2016-02-18 21:02:45 --> Helper loaded: date_helper
INFO - 2016-02-18 21:02:45 --> Helper loaded: form_helper
INFO - 2016-02-18 21:02:45 --> Database Driver Class Initialized
INFO - 2016-02-18 21:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:02:46 --> Controller Class Initialized
INFO - 2016-02-18 21:02:46 --> Model Class Initialized
INFO - 2016-02-18 21:02:46 --> Model Class Initialized
INFO - 2016-02-18 21:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:02:46 --> Pagination Class Initialized
INFO - 2016-02-18 21:02:46 --> Helper loaded: text_helper
INFO - 2016-02-18 21:02:46 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:04:39 --> Config Class Initialized
INFO - 2016-02-18 21:04:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:04:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:04:39 --> Utf8 Class Initialized
INFO - 2016-02-18 21:04:39 --> URI Class Initialized
DEBUG - 2016-02-18 21:04:39 --> No URI present. Default controller set.
INFO - 2016-02-18 21:04:39 --> Router Class Initialized
INFO - 2016-02-18 21:04:39 --> Output Class Initialized
INFO - 2016-02-18 21:04:39 --> Security Class Initialized
DEBUG - 2016-02-18 21:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:04:39 --> Input Class Initialized
INFO - 2016-02-18 21:04:39 --> Language Class Initialized
INFO - 2016-02-18 21:04:39 --> Loader Class Initialized
INFO - 2016-02-18 21:04:39 --> Helper loaded: url_helper
INFO - 2016-02-18 21:04:39 --> Helper loaded: file_helper
INFO - 2016-02-18 21:04:39 --> Helper loaded: date_helper
INFO - 2016-02-18 21:04:39 --> Helper loaded: form_helper
INFO - 2016-02-18 21:04:39 --> Database Driver Class Initialized
INFO - 2016-02-18 21:04:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:04:40 --> Controller Class Initialized
INFO - 2016-02-18 21:04:40 --> Model Class Initialized
INFO - 2016-02-18 21:04:40 --> Model Class Initialized
INFO - 2016-02-18 21:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:04:40 --> Pagination Class Initialized
INFO - 2016-02-18 21:04:40 --> Helper loaded: text_helper
INFO - 2016-02-18 21:04:40 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:06:35 --> Config Class Initialized
INFO - 2016-02-18 21:06:35 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:06:35 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:06:35 --> Utf8 Class Initialized
INFO - 2016-02-18 21:06:35 --> URI Class Initialized
INFO - 2016-02-18 21:06:35 --> Router Class Initialized
INFO - 2016-02-18 21:06:35 --> Output Class Initialized
INFO - 2016-02-18 21:06:35 --> Security Class Initialized
DEBUG - 2016-02-18 21:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:06:35 --> Input Class Initialized
INFO - 2016-02-18 21:06:35 --> Language Class Initialized
INFO - 2016-02-18 21:06:35 --> Loader Class Initialized
INFO - 2016-02-18 21:06:35 --> Helper loaded: url_helper
INFO - 2016-02-18 21:06:35 --> Helper loaded: file_helper
INFO - 2016-02-18 21:06:35 --> Helper loaded: date_helper
INFO - 2016-02-18 21:06:35 --> Helper loaded: form_helper
INFO - 2016-02-18 21:06:35 --> Database Driver Class Initialized
INFO - 2016-02-18 21:06:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:06:36 --> Controller Class Initialized
INFO - 2016-02-18 21:06:36 --> Model Class Initialized
INFO - 2016-02-18 21:06:36 --> Model Class Initialized
INFO - 2016-02-18 21:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:06:36 --> Pagination Class Initialized
INFO - 2016-02-18 21:06:36 --> Helper loaded: text_helper
INFO - 2016-02-18 21:06:36 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:06:36 --> Config Class Initialized
INFO - 2016-02-18 21:06:36 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:06:36 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:06:36 --> Utf8 Class Initialized
INFO - 2016-02-18 21:06:36 --> URI Class Initialized
INFO - 2016-02-18 21:06:36 --> Router Class Initialized
INFO - 2016-02-18 21:06:36 --> Output Class Initialized
INFO - 2016-02-18 21:06:36 --> Security Class Initialized
DEBUG - 2016-02-18 21:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:06:36 --> Input Class Initialized
INFO - 2016-02-18 21:06:36 --> Language Class Initialized
INFO - 2016-02-18 21:06:36 --> Loader Class Initialized
INFO - 2016-02-18 21:06:36 --> Helper loaded: url_helper
INFO - 2016-02-18 21:06:36 --> Helper loaded: file_helper
INFO - 2016-02-18 21:06:36 --> Helper loaded: date_helper
INFO - 2016-02-18 21:06:36 --> Helper loaded: form_helper
INFO - 2016-02-18 21:06:36 --> Database Driver Class Initialized
INFO - 2016-02-18 21:06:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:06:37 --> Controller Class Initialized
INFO - 2016-02-18 21:06:37 --> Model Class Initialized
INFO - 2016-02-18 21:06:37 --> Model Class Initialized
INFO - 2016-02-18 21:06:37 --> Form Validation Class Initialized
INFO - 2016-02-18 21:06:37 --> Helper loaded: text_helper
INFO - 2016-02-18 21:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-18 21:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-18 21:06:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-18 21:06:37 --> Final output sent to browser
DEBUG - 2016-02-18 21:06:37 --> Total execution time: 1.1727
INFO - 2016-02-18 21:06:50 --> Config Class Initialized
INFO - 2016-02-18 21:06:50 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:06:50 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:06:50 --> Utf8 Class Initialized
INFO - 2016-02-18 21:06:50 --> URI Class Initialized
DEBUG - 2016-02-18 21:06:50 --> No URI present. Default controller set.
INFO - 2016-02-18 21:06:50 --> Router Class Initialized
INFO - 2016-02-18 21:06:50 --> Output Class Initialized
INFO - 2016-02-18 21:06:50 --> Security Class Initialized
DEBUG - 2016-02-18 21:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:06:50 --> Input Class Initialized
INFO - 2016-02-18 21:06:50 --> Language Class Initialized
INFO - 2016-02-18 21:06:50 --> Loader Class Initialized
INFO - 2016-02-18 21:06:50 --> Helper loaded: url_helper
INFO - 2016-02-18 21:06:50 --> Helper loaded: file_helper
INFO - 2016-02-18 21:06:50 --> Helper loaded: date_helper
INFO - 2016-02-18 21:06:50 --> Helper loaded: form_helper
INFO - 2016-02-18 21:06:50 --> Database Driver Class Initialized
INFO - 2016-02-18 21:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:06:51 --> Controller Class Initialized
INFO - 2016-02-18 21:06:51 --> Model Class Initialized
INFO - 2016-02-18 21:06:51 --> Model Class Initialized
INFO - 2016-02-18 21:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:06:51 --> Pagination Class Initialized
INFO - 2016-02-18 21:06:51 --> Helper loaded: text_helper
INFO - 2016-02-18 21:06:51 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:07:28 --> Config Class Initialized
INFO - 2016-02-18 21:07:28 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:07:28 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:07:28 --> Utf8 Class Initialized
INFO - 2016-02-18 21:07:28 --> URI Class Initialized
INFO - 2016-02-18 21:07:28 --> Router Class Initialized
INFO - 2016-02-18 21:07:28 --> Output Class Initialized
INFO - 2016-02-18 21:07:28 --> Security Class Initialized
DEBUG - 2016-02-18 21:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:07:28 --> Input Class Initialized
INFO - 2016-02-18 21:07:28 --> Language Class Initialized
INFO - 2016-02-18 21:07:28 --> Loader Class Initialized
INFO - 2016-02-18 21:07:28 --> Helper loaded: url_helper
INFO - 2016-02-18 21:07:28 --> Helper loaded: file_helper
INFO - 2016-02-18 21:07:28 --> Helper loaded: date_helper
INFO - 2016-02-18 21:07:29 --> Helper loaded: form_helper
INFO - 2016-02-18 21:07:29 --> Database Driver Class Initialized
INFO - 2016-02-18 21:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:07:30 --> Controller Class Initialized
INFO - 2016-02-18 21:07:30 --> Model Class Initialized
INFO - 2016-02-18 21:07:30 --> Model Class Initialized
INFO - 2016-02-18 21:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:07:30 --> Pagination Class Initialized
INFO - 2016-02-18 21:07:30 --> Helper loaded: text_helper
INFO - 2016-02-18 21:07:30 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:14:41 --> Config Class Initialized
INFO - 2016-02-18 21:14:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:14:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:14:41 --> Utf8 Class Initialized
INFO - 2016-02-18 21:14:41 --> URI Class Initialized
INFO - 2016-02-18 21:14:41 --> Router Class Initialized
INFO - 2016-02-18 21:14:41 --> Output Class Initialized
INFO - 2016-02-18 21:14:41 --> Security Class Initialized
DEBUG - 2016-02-18 21:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:14:41 --> Input Class Initialized
INFO - 2016-02-18 21:14:41 --> Language Class Initialized
INFO - 2016-02-18 21:14:41 --> Loader Class Initialized
INFO - 2016-02-18 21:14:41 --> Helper loaded: url_helper
INFO - 2016-02-18 21:14:41 --> Helper loaded: file_helper
INFO - 2016-02-18 21:14:41 --> Helper loaded: date_helper
INFO - 2016-02-18 21:14:41 --> Helper loaded: form_helper
INFO - 2016-02-18 21:14:41 --> Database Driver Class Initialized
INFO - 2016-02-18 21:14:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:14:42 --> Controller Class Initialized
INFO - 2016-02-18 21:14:42 --> Model Class Initialized
INFO - 2016-02-18 21:14:42 --> Model Class Initialized
INFO - 2016-02-18 21:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:14:42 --> Pagination Class Initialized
INFO - 2016-02-18 21:14:42 --> Helper loaded: text_helper
INFO - 2016-02-18 21:14:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:14:51 --> Config Class Initialized
INFO - 2016-02-18 21:14:51 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:14:51 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:14:51 --> Utf8 Class Initialized
INFO - 2016-02-18 21:14:51 --> URI Class Initialized
DEBUG - 2016-02-18 21:14:51 --> No URI present. Default controller set.
INFO - 2016-02-18 21:14:51 --> Router Class Initialized
INFO - 2016-02-18 21:14:51 --> Output Class Initialized
INFO - 2016-02-18 21:14:51 --> Security Class Initialized
DEBUG - 2016-02-18 21:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:14:51 --> Input Class Initialized
INFO - 2016-02-18 21:14:51 --> Language Class Initialized
INFO - 2016-02-18 21:14:51 --> Loader Class Initialized
INFO - 2016-02-18 21:14:51 --> Helper loaded: url_helper
INFO - 2016-02-18 21:14:51 --> Helper loaded: file_helper
INFO - 2016-02-18 21:14:51 --> Helper loaded: date_helper
INFO - 2016-02-18 21:14:51 --> Helper loaded: form_helper
INFO - 2016-02-18 21:14:51 --> Database Driver Class Initialized
INFO - 2016-02-18 21:14:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:14:52 --> Controller Class Initialized
INFO - 2016-02-18 21:14:52 --> Model Class Initialized
INFO - 2016-02-18 21:14:52 --> Model Class Initialized
INFO - 2016-02-18 21:14:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:14:52 --> Pagination Class Initialized
INFO - 2016-02-18 21:14:52 --> Helper loaded: text_helper
INFO - 2016-02-18 21:14:52 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:14:54 --> Config Class Initialized
INFO - 2016-02-18 21:14:54 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:14:54 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:14:54 --> Utf8 Class Initialized
INFO - 2016-02-18 21:14:54 --> URI Class Initialized
INFO - 2016-02-18 21:14:54 --> Router Class Initialized
INFO - 2016-02-18 21:14:54 --> Output Class Initialized
INFO - 2016-02-18 21:14:54 --> Security Class Initialized
DEBUG - 2016-02-18 21:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:14:54 --> Input Class Initialized
INFO - 2016-02-18 21:14:54 --> Language Class Initialized
INFO - 2016-02-18 21:14:54 --> Loader Class Initialized
INFO - 2016-02-18 21:14:54 --> Helper loaded: url_helper
INFO - 2016-02-18 21:14:54 --> Helper loaded: file_helper
INFO - 2016-02-18 21:14:54 --> Helper loaded: date_helper
INFO - 2016-02-18 21:14:54 --> Helper loaded: form_helper
INFO - 2016-02-18 21:14:54 --> Database Driver Class Initialized
INFO - 2016-02-18 21:14:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:14:55 --> Controller Class Initialized
INFO - 2016-02-18 21:14:55 --> Model Class Initialized
INFO - 2016-02-18 21:14:55 --> Model Class Initialized
INFO - 2016-02-18 21:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:14:55 --> Pagination Class Initialized
INFO - 2016-02-18 21:14:55 --> Helper loaded: text_helper
INFO - 2016-02-18 21:14:55 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:15:23 --> Config Class Initialized
INFO - 2016-02-18 21:15:23 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:15:23 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:15:23 --> Utf8 Class Initialized
INFO - 2016-02-18 21:15:23 --> URI Class Initialized
INFO - 2016-02-18 21:15:23 --> Router Class Initialized
INFO - 2016-02-18 21:15:23 --> Output Class Initialized
INFO - 2016-02-18 21:15:23 --> Security Class Initialized
DEBUG - 2016-02-18 21:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:15:23 --> Input Class Initialized
INFO - 2016-02-18 21:15:23 --> Language Class Initialized
INFO - 2016-02-18 21:15:23 --> Loader Class Initialized
INFO - 2016-02-18 21:15:23 --> Helper loaded: url_helper
INFO - 2016-02-18 21:15:23 --> Helper loaded: file_helper
INFO - 2016-02-18 21:15:23 --> Helper loaded: date_helper
INFO - 2016-02-18 21:15:23 --> Helper loaded: form_helper
INFO - 2016-02-18 21:15:23 --> Database Driver Class Initialized
INFO - 2016-02-18 21:15:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:15:24 --> Controller Class Initialized
INFO - 2016-02-18 21:15:24 --> Model Class Initialized
INFO - 2016-02-18 21:15:24 --> Model Class Initialized
INFO - 2016-02-18 21:15:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:15:24 --> Pagination Class Initialized
INFO - 2016-02-18 21:15:24 --> Helper loaded: text_helper
INFO - 2016-02-18 21:15:24 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:15:42 --> Config Class Initialized
INFO - 2016-02-18 21:15:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:15:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:15:42 --> Utf8 Class Initialized
INFO - 2016-02-18 21:15:42 --> URI Class Initialized
INFO - 2016-02-18 21:15:42 --> Router Class Initialized
INFO - 2016-02-18 21:15:42 --> Output Class Initialized
INFO - 2016-02-18 21:15:42 --> Security Class Initialized
DEBUG - 2016-02-18 21:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:15:42 --> Input Class Initialized
INFO - 2016-02-18 21:15:42 --> Language Class Initialized
INFO - 2016-02-18 21:15:42 --> Loader Class Initialized
INFO - 2016-02-18 21:15:42 --> Helper loaded: url_helper
INFO - 2016-02-18 21:15:42 --> Helper loaded: file_helper
INFO - 2016-02-18 21:15:42 --> Helper loaded: date_helper
INFO - 2016-02-18 21:15:42 --> Helper loaded: form_helper
INFO - 2016-02-18 21:15:42 --> Database Driver Class Initialized
INFO - 2016-02-18 21:15:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:15:43 --> Controller Class Initialized
INFO - 2016-02-18 21:15:43 --> Model Class Initialized
INFO - 2016-02-18 21:15:43 --> Model Class Initialized
INFO - 2016-02-18 21:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:15:43 --> Pagination Class Initialized
INFO - 2016-02-18 21:15:43 --> Helper loaded: text_helper
INFO - 2016-02-18 21:15:43 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:17:28 --> Config Class Initialized
INFO - 2016-02-18 21:17:28 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:17:28 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:17:28 --> Utf8 Class Initialized
INFO - 2016-02-18 21:17:28 --> URI Class Initialized
INFO - 2016-02-18 21:17:28 --> Router Class Initialized
INFO - 2016-02-18 21:17:28 --> Output Class Initialized
INFO - 2016-02-18 21:17:28 --> Security Class Initialized
DEBUG - 2016-02-18 21:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:17:28 --> Input Class Initialized
INFO - 2016-02-18 21:17:28 --> Language Class Initialized
INFO - 2016-02-18 21:17:28 --> Loader Class Initialized
INFO - 2016-02-18 21:17:28 --> Helper loaded: url_helper
INFO - 2016-02-18 21:17:28 --> Helper loaded: file_helper
INFO - 2016-02-18 21:17:28 --> Helper loaded: date_helper
INFO - 2016-02-18 21:17:28 --> Helper loaded: form_helper
INFO - 2016-02-18 21:17:28 --> Database Driver Class Initialized
INFO - 2016-02-18 21:17:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:17:29 --> Controller Class Initialized
INFO - 2016-02-18 21:17:29 --> Model Class Initialized
INFO - 2016-02-18 21:17:29 --> Model Class Initialized
INFO - 2016-02-18 21:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:17:29 --> Pagination Class Initialized
INFO - 2016-02-18 21:17:29 --> Helper loaded: text_helper
INFO - 2016-02-18 21:17:29 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:18:41 --> Config Class Initialized
INFO - 2016-02-18 21:18:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:18:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:18:41 --> Utf8 Class Initialized
INFO - 2016-02-18 21:18:41 --> URI Class Initialized
INFO - 2016-02-18 21:18:41 --> Router Class Initialized
INFO - 2016-02-18 21:18:41 --> Output Class Initialized
INFO - 2016-02-18 21:18:41 --> Security Class Initialized
DEBUG - 2016-02-18 21:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:18:41 --> Input Class Initialized
INFO - 2016-02-18 21:18:41 --> Language Class Initialized
INFO - 2016-02-18 21:18:41 --> Loader Class Initialized
INFO - 2016-02-18 21:18:41 --> Helper loaded: url_helper
INFO - 2016-02-18 21:18:41 --> Helper loaded: file_helper
INFO - 2016-02-18 21:18:41 --> Helper loaded: date_helper
INFO - 2016-02-18 21:18:41 --> Helper loaded: form_helper
INFO - 2016-02-18 21:18:41 --> Database Driver Class Initialized
INFO - 2016-02-18 21:18:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:18:42 --> Controller Class Initialized
INFO - 2016-02-18 21:18:42 --> Model Class Initialized
INFO - 2016-02-18 21:18:42 --> Model Class Initialized
INFO - 2016-02-18 21:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:18:42 --> Pagination Class Initialized
INFO - 2016-02-18 21:18:42 --> Helper loaded: text_helper
INFO - 2016-02-18 21:18:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:23:52 --> Config Class Initialized
INFO - 2016-02-18 21:23:52 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:23:52 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:23:52 --> Utf8 Class Initialized
INFO - 2016-02-18 21:23:52 --> URI Class Initialized
INFO - 2016-02-18 21:23:52 --> Router Class Initialized
INFO - 2016-02-18 21:23:52 --> Output Class Initialized
INFO - 2016-02-18 21:23:52 --> Security Class Initialized
DEBUG - 2016-02-18 21:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:23:52 --> Input Class Initialized
INFO - 2016-02-18 21:23:52 --> Language Class Initialized
INFO - 2016-02-18 21:23:52 --> Loader Class Initialized
INFO - 2016-02-18 21:23:52 --> Helper loaded: url_helper
INFO - 2016-02-18 21:23:52 --> Helper loaded: file_helper
INFO - 2016-02-18 21:23:52 --> Helper loaded: date_helper
INFO - 2016-02-18 21:23:52 --> Helper loaded: form_helper
INFO - 2016-02-18 21:23:52 --> Database Driver Class Initialized
INFO - 2016-02-18 21:23:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:23:53 --> Controller Class Initialized
INFO - 2016-02-18 21:23:53 --> Model Class Initialized
INFO - 2016-02-18 21:23:53 --> Model Class Initialized
INFO - 2016-02-18 21:23:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:23:53 --> Pagination Class Initialized
INFO - 2016-02-18 21:23:53 --> Helper loaded: text_helper
INFO - 2016-02-18 21:23:53 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:26:02 --> Config Class Initialized
INFO - 2016-02-18 21:26:02 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:26:02 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:26:02 --> Utf8 Class Initialized
INFO - 2016-02-18 21:26:02 --> URI Class Initialized
INFO - 2016-02-18 21:26:02 --> Router Class Initialized
INFO - 2016-02-18 21:26:02 --> Output Class Initialized
INFO - 2016-02-18 21:26:02 --> Security Class Initialized
DEBUG - 2016-02-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:26:02 --> Input Class Initialized
INFO - 2016-02-18 21:26:02 --> Language Class Initialized
INFO - 2016-02-18 21:26:02 --> Loader Class Initialized
INFO - 2016-02-18 21:26:02 --> Helper loaded: url_helper
INFO - 2016-02-18 21:26:02 --> Helper loaded: file_helper
INFO - 2016-02-18 21:26:02 --> Helper loaded: date_helper
INFO - 2016-02-18 21:26:02 --> Helper loaded: form_helper
INFO - 2016-02-18 21:26:02 --> Database Driver Class Initialized
INFO - 2016-02-18 21:26:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:26:03 --> Controller Class Initialized
INFO - 2016-02-18 21:26:03 --> Model Class Initialized
INFO - 2016-02-18 21:26:03 --> Model Class Initialized
INFO - 2016-02-18 21:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:26:03 --> Pagination Class Initialized
INFO - 2016-02-18 21:26:03 --> Helper loaded: text_helper
INFO - 2016-02-18 21:26:03 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:26:57 --> Config Class Initialized
INFO - 2016-02-18 21:26:57 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:26:57 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:26:57 --> Utf8 Class Initialized
INFO - 2016-02-18 21:26:57 --> URI Class Initialized
INFO - 2016-02-18 21:26:57 --> Router Class Initialized
INFO - 2016-02-18 21:26:58 --> Output Class Initialized
INFO - 2016-02-18 21:26:58 --> Security Class Initialized
DEBUG - 2016-02-18 21:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:26:58 --> Input Class Initialized
INFO - 2016-02-18 21:26:58 --> Language Class Initialized
INFO - 2016-02-18 21:26:58 --> Loader Class Initialized
INFO - 2016-02-18 21:26:58 --> Helper loaded: url_helper
INFO - 2016-02-18 21:26:58 --> Helper loaded: file_helper
INFO - 2016-02-18 21:26:58 --> Helper loaded: date_helper
INFO - 2016-02-18 21:26:58 --> Helper loaded: form_helper
INFO - 2016-02-18 21:26:58 --> Database Driver Class Initialized
INFO - 2016-02-18 21:26:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:26:59 --> Controller Class Initialized
INFO - 2016-02-18 21:26:59 --> Model Class Initialized
INFO - 2016-02-18 21:26:59 --> Model Class Initialized
INFO - 2016-02-18 21:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:26:59 --> Pagination Class Initialized
INFO - 2016-02-18 21:26:59 --> Helper loaded: text_helper
INFO - 2016-02-18 21:26:59 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:27:24 --> Config Class Initialized
INFO - 2016-02-18 21:27:24 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:27:24 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:27:24 --> Utf8 Class Initialized
INFO - 2016-02-18 21:27:24 --> URI Class Initialized
INFO - 2016-02-18 21:27:24 --> Router Class Initialized
INFO - 2016-02-18 21:27:24 --> Output Class Initialized
INFO - 2016-02-18 21:27:24 --> Security Class Initialized
DEBUG - 2016-02-18 21:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:27:24 --> Input Class Initialized
INFO - 2016-02-18 21:27:24 --> Language Class Initialized
INFO - 2016-02-18 21:27:24 --> Loader Class Initialized
INFO - 2016-02-18 21:27:24 --> Helper loaded: url_helper
INFO - 2016-02-18 21:27:24 --> Helper loaded: file_helper
INFO - 2016-02-18 21:27:24 --> Helper loaded: date_helper
INFO - 2016-02-18 21:27:24 --> Helper loaded: form_helper
INFO - 2016-02-18 21:27:24 --> Database Driver Class Initialized
INFO - 2016-02-18 21:27:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:27:25 --> Controller Class Initialized
INFO - 2016-02-18 21:27:25 --> Model Class Initialized
INFO - 2016-02-18 21:27:25 --> Model Class Initialized
INFO - 2016-02-18 21:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:27:25 --> Pagination Class Initialized
INFO - 2016-02-18 21:27:25 --> Helper loaded: text_helper
INFO - 2016-02-18 21:27:25 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:27:47 --> Config Class Initialized
INFO - 2016-02-18 21:27:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:27:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:27:47 --> Utf8 Class Initialized
INFO - 2016-02-18 21:27:47 --> URI Class Initialized
INFO - 2016-02-18 21:27:47 --> Router Class Initialized
INFO - 2016-02-18 21:27:47 --> Output Class Initialized
INFO - 2016-02-18 21:27:47 --> Security Class Initialized
DEBUG - 2016-02-18 21:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:27:47 --> Input Class Initialized
INFO - 2016-02-18 21:27:47 --> Language Class Initialized
INFO - 2016-02-18 21:27:47 --> Loader Class Initialized
INFO - 2016-02-18 21:27:47 --> Helper loaded: url_helper
INFO - 2016-02-18 21:27:47 --> Helper loaded: file_helper
INFO - 2016-02-18 21:27:47 --> Helper loaded: date_helper
INFO - 2016-02-18 21:27:47 --> Helper loaded: form_helper
INFO - 2016-02-18 21:27:47 --> Database Driver Class Initialized
INFO - 2016-02-18 21:27:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:27:48 --> Controller Class Initialized
INFO - 2016-02-18 21:27:48 --> Model Class Initialized
INFO - 2016-02-18 21:27:48 --> Model Class Initialized
INFO - 2016-02-18 21:27:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:27:48 --> Pagination Class Initialized
INFO - 2016-02-18 21:27:48 --> Helper loaded: text_helper
INFO - 2016-02-18 21:27:48 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:31:57 --> Config Class Initialized
INFO - 2016-02-18 21:31:57 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:31:57 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:31:57 --> Utf8 Class Initialized
INFO - 2016-02-18 21:31:57 --> URI Class Initialized
INFO - 2016-02-18 21:31:57 --> Router Class Initialized
INFO - 2016-02-18 21:31:57 --> Output Class Initialized
INFO - 2016-02-18 21:31:57 --> Security Class Initialized
DEBUG - 2016-02-18 21:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:31:57 --> Input Class Initialized
INFO - 2016-02-18 21:31:57 --> Language Class Initialized
INFO - 2016-02-18 21:31:57 --> Loader Class Initialized
INFO - 2016-02-18 21:31:57 --> Helper loaded: url_helper
INFO - 2016-02-18 21:31:57 --> Helper loaded: file_helper
INFO - 2016-02-18 21:31:57 --> Helper loaded: date_helper
INFO - 2016-02-18 21:31:57 --> Helper loaded: form_helper
INFO - 2016-02-18 21:31:57 --> Database Driver Class Initialized
INFO - 2016-02-18 21:31:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:31:58 --> Controller Class Initialized
INFO - 2016-02-18 21:31:58 --> Model Class Initialized
INFO - 2016-02-18 21:31:58 --> Model Class Initialized
INFO - 2016-02-18 21:31:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:31:58 --> Pagination Class Initialized
INFO - 2016-02-18 21:31:59 --> Helper loaded: text_helper
INFO - 2016-02-18 21:31:59 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:36:25 --> Config Class Initialized
INFO - 2016-02-18 21:36:25 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:36:25 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:36:25 --> Utf8 Class Initialized
INFO - 2016-02-18 21:36:25 --> URI Class Initialized
DEBUG - 2016-02-18 21:36:25 --> No URI present. Default controller set.
INFO - 2016-02-18 21:36:25 --> Router Class Initialized
INFO - 2016-02-18 21:36:25 --> Output Class Initialized
INFO - 2016-02-18 21:36:25 --> Security Class Initialized
DEBUG - 2016-02-18 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:36:25 --> Input Class Initialized
INFO - 2016-02-18 21:36:25 --> Language Class Initialized
INFO - 2016-02-18 21:36:25 --> Loader Class Initialized
INFO - 2016-02-18 21:36:25 --> Helper loaded: url_helper
INFO - 2016-02-18 21:36:25 --> Helper loaded: file_helper
INFO - 2016-02-18 21:36:25 --> Helper loaded: date_helper
INFO - 2016-02-18 21:36:25 --> Helper loaded: form_helper
INFO - 2016-02-18 21:36:25 --> Database Driver Class Initialized
INFO - 2016-02-18 21:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:36:26 --> Controller Class Initialized
INFO - 2016-02-18 21:36:26 --> Model Class Initialized
INFO - 2016-02-18 21:36:26 --> Model Class Initialized
INFO - 2016-02-18 21:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:36:26 --> Pagination Class Initialized
INFO - 2016-02-18 21:36:26 --> Helper loaded: text_helper
INFO - 2016-02-18 21:36:26 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:36:28 --> Config Class Initialized
INFO - 2016-02-18 21:36:28 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:36:28 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:36:28 --> Utf8 Class Initialized
INFO - 2016-02-18 21:36:28 --> URI Class Initialized
INFO - 2016-02-18 21:36:28 --> Router Class Initialized
INFO - 2016-02-18 21:36:28 --> Output Class Initialized
INFO - 2016-02-18 21:36:28 --> Security Class Initialized
DEBUG - 2016-02-18 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:36:28 --> Input Class Initialized
INFO - 2016-02-18 21:36:28 --> Language Class Initialized
INFO - 2016-02-18 21:36:28 --> Loader Class Initialized
INFO - 2016-02-18 21:36:28 --> Helper loaded: url_helper
INFO - 2016-02-18 21:36:28 --> Helper loaded: file_helper
INFO - 2016-02-18 21:36:28 --> Helper loaded: date_helper
INFO - 2016-02-18 21:36:28 --> Helper loaded: form_helper
INFO - 2016-02-18 21:36:28 --> Database Driver Class Initialized
INFO - 2016-02-18 21:36:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:36:29 --> Controller Class Initialized
INFO - 2016-02-18 21:36:29 --> Model Class Initialized
INFO - 2016-02-18 21:36:29 --> Model Class Initialized
INFO - 2016-02-18 21:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:36:29 --> Pagination Class Initialized
INFO - 2016-02-18 21:36:29 --> Helper loaded: text_helper
INFO - 2016-02-18 21:36:29 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:36:31 --> Config Class Initialized
INFO - 2016-02-18 21:36:31 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:36:31 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:36:31 --> Utf8 Class Initialized
INFO - 2016-02-18 21:36:31 --> URI Class Initialized
DEBUG - 2016-02-18 21:36:31 --> No URI present. Default controller set.
INFO - 2016-02-18 21:36:31 --> Router Class Initialized
INFO - 2016-02-18 21:36:31 --> Output Class Initialized
INFO - 2016-02-18 21:36:31 --> Security Class Initialized
DEBUG - 2016-02-18 21:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:36:31 --> Input Class Initialized
INFO - 2016-02-18 21:36:31 --> Language Class Initialized
INFO - 2016-02-18 21:36:31 --> Loader Class Initialized
INFO - 2016-02-18 21:36:31 --> Helper loaded: url_helper
INFO - 2016-02-18 21:36:31 --> Helper loaded: file_helper
INFO - 2016-02-18 21:36:31 --> Helper loaded: date_helper
INFO - 2016-02-18 21:36:31 --> Helper loaded: form_helper
INFO - 2016-02-18 21:36:31 --> Database Driver Class Initialized
INFO - 2016-02-18 21:36:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:36:32 --> Controller Class Initialized
INFO - 2016-02-18 21:36:32 --> Model Class Initialized
INFO - 2016-02-18 21:36:32 --> Model Class Initialized
INFO - 2016-02-18 21:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:36:32 --> Pagination Class Initialized
INFO - 2016-02-18 21:36:32 --> Helper loaded: text_helper
INFO - 2016-02-18 21:36:32 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:36:34 --> Config Class Initialized
INFO - 2016-02-18 21:36:34 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:36:34 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:36:34 --> Utf8 Class Initialized
INFO - 2016-02-18 21:36:34 --> URI Class Initialized
INFO - 2016-02-18 21:36:34 --> Router Class Initialized
INFO - 2016-02-18 21:36:34 --> Output Class Initialized
INFO - 2016-02-18 21:36:34 --> Security Class Initialized
DEBUG - 2016-02-18 21:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:36:34 --> Input Class Initialized
INFO - 2016-02-18 21:36:34 --> Language Class Initialized
INFO - 2016-02-18 21:36:34 --> Loader Class Initialized
INFO - 2016-02-18 21:36:34 --> Helper loaded: url_helper
INFO - 2016-02-18 21:36:34 --> Helper loaded: file_helper
INFO - 2016-02-18 21:36:34 --> Helper loaded: date_helper
INFO - 2016-02-18 21:36:34 --> Helper loaded: form_helper
INFO - 2016-02-18 21:36:34 --> Database Driver Class Initialized
INFO - 2016-02-18 21:36:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:36:35 --> Controller Class Initialized
INFO - 2016-02-18 21:36:35 --> Model Class Initialized
INFO - 2016-02-18 21:36:35 --> Model Class Initialized
INFO - 2016-02-18 21:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:36:35 --> Pagination Class Initialized
INFO - 2016-02-18 21:36:35 --> Helper loaded: text_helper
INFO - 2016-02-18 21:36:35 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:38:47 --> Config Class Initialized
INFO - 2016-02-18 21:38:47 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:38:47 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:38:47 --> Utf8 Class Initialized
INFO - 2016-02-18 21:38:47 --> URI Class Initialized
INFO - 2016-02-18 21:38:47 --> Router Class Initialized
INFO - 2016-02-18 21:38:47 --> Output Class Initialized
INFO - 2016-02-18 21:38:47 --> Security Class Initialized
DEBUG - 2016-02-18 21:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:38:47 --> Input Class Initialized
INFO - 2016-02-18 21:38:47 --> Language Class Initialized
INFO - 2016-02-18 21:38:47 --> Loader Class Initialized
INFO - 2016-02-18 21:38:47 --> Helper loaded: url_helper
INFO - 2016-02-18 21:38:47 --> Helper loaded: file_helper
INFO - 2016-02-18 21:38:47 --> Helper loaded: date_helper
INFO - 2016-02-18 21:38:47 --> Helper loaded: form_helper
INFO - 2016-02-18 21:38:47 --> Database Driver Class Initialized
INFO - 2016-02-18 21:38:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:38:48 --> Controller Class Initialized
INFO - 2016-02-18 21:38:48 --> Model Class Initialized
INFO - 2016-02-18 21:38:48 --> Model Class Initialized
INFO - 2016-02-18 21:38:48 --> Form Validation Class Initialized
INFO - 2016-02-18 21:38:48 --> Helper loaded: text_helper
INFO - 2016-02-18 21:38:48 --> Config Class Initialized
INFO - 2016-02-18 21:38:48 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:38:48 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:38:48 --> Utf8 Class Initialized
INFO - 2016-02-18 21:38:48 --> URI Class Initialized
INFO - 2016-02-18 21:38:48 --> Router Class Initialized
INFO - 2016-02-18 21:38:48 --> Output Class Initialized
INFO - 2016-02-18 21:38:48 --> Security Class Initialized
DEBUG - 2016-02-18 21:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:38:48 --> Input Class Initialized
INFO - 2016-02-18 21:38:48 --> Language Class Initialized
INFO - 2016-02-18 21:38:48 --> Loader Class Initialized
INFO - 2016-02-18 21:38:48 --> Helper loaded: url_helper
INFO - 2016-02-18 21:38:48 --> Helper loaded: file_helper
INFO - 2016-02-18 21:38:48 --> Helper loaded: date_helper
INFO - 2016-02-18 21:38:48 --> Helper loaded: form_helper
INFO - 2016-02-18 21:38:48 --> Database Driver Class Initialized
INFO - 2016-02-18 21:38:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:38:49 --> Controller Class Initialized
INFO - 2016-02-18 21:38:49 --> Model Class Initialized
INFO - 2016-02-18 21:38:49 --> Model Class Initialized
INFO - 2016-02-18 21:38:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:38:49 --> Pagination Class Initialized
INFO - 2016-02-18 21:38:49 --> Helper loaded: text_helper
INFO - 2016-02-18 21:38:49 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:09 --> Config Class Initialized
INFO - 2016-02-18 21:39:09 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:09 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:09 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:09 --> URI Class Initialized
DEBUG - 2016-02-18 21:39:09 --> No URI present. Default controller set.
INFO - 2016-02-18 21:39:09 --> Router Class Initialized
INFO - 2016-02-18 21:39:09 --> Output Class Initialized
INFO - 2016-02-18 21:39:09 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:09 --> Input Class Initialized
INFO - 2016-02-18 21:39:09 --> Language Class Initialized
INFO - 2016-02-18 21:39:09 --> Loader Class Initialized
INFO - 2016-02-18 21:39:09 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:09 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:09 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:09 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:09 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:10 --> Controller Class Initialized
INFO - 2016-02-18 21:39:10 --> Model Class Initialized
INFO - 2016-02-18 21:39:10 --> Model Class Initialized
INFO - 2016-02-18 21:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:10 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:10 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:10 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:27 --> Config Class Initialized
INFO - 2016-02-18 21:39:27 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:27 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:27 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:27 --> URI Class Initialized
INFO - 2016-02-18 21:39:27 --> Router Class Initialized
INFO - 2016-02-18 21:39:27 --> Output Class Initialized
INFO - 2016-02-18 21:39:27 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:27 --> Input Class Initialized
INFO - 2016-02-18 21:39:27 --> Language Class Initialized
INFO - 2016-02-18 21:39:27 --> Loader Class Initialized
INFO - 2016-02-18 21:39:27 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:27 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:27 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:27 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:27 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:28 --> Controller Class Initialized
INFO - 2016-02-18 21:39:28 --> Model Class Initialized
INFO - 2016-02-18 21:39:28 --> Model Class Initialized
INFO - 2016-02-18 21:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:28 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:28 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:32 --> Config Class Initialized
INFO - 2016-02-18 21:39:32 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:32 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:32 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:32 --> URI Class Initialized
DEBUG - 2016-02-18 21:39:32 --> No URI present. Default controller set.
INFO - 2016-02-18 21:39:32 --> Router Class Initialized
INFO - 2016-02-18 21:39:32 --> Output Class Initialized
INFO - 2016-02-18 21:39:32 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:32 --> Input Class Initialized
INFO - 2016-02-18 21:39:32 --> Language Class Initialized
INFO - 2016-02-18 21:39:32 --> Loader Class Initialized
INFO - 2016-02-18 21:39:32 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:32 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:32 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:32 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:32 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:33 --> Controller Class Initialized
INFO - 2016-02-18 21:39:33 --> Model Class Initialized
INFO - 2016-02-18 21:39:33 --> Model Class Initialized
INFO - 2016-02-18 21:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:33 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:33 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:33 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:36 --> Config Class Initialized
INFO - 2016-02-18 21:39:36 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:36 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:36 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:36 --> URI Class Initialized
INFO - 2016-02-18 21:39:36 --> Router Class Initialized
INFO - 2016-02-18 21:39:36 --> Output Class Initialized
INFO - 2016-02-18 21:39:36 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:36 --> Input Class Initialized
INFO - 2016-02-18 21:39:36 --> Language Class Initialized
INFO - 2016-02-18 21:39:36 --> Loader Class Initialized
INFO - 2016-02-18 21:39:36 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:36 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:36 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:36 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:36 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:37 --> Controller Class Initialized
INFO - 2016-02-18 21:39:37 --> Model Class Initialized
INFO - 2016-02-18 21:39:37 --> Model Class Initialized
INFO - 2016-02-18 21:39:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:37 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:37 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:37 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:41 --> Config Class Initialized
INFO - 2016-02-18 21:39:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:41 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:41 --> URI Class Initialized
DEBUG - 2016-02-18 21:39:41 --> No URI present. Default controller set.
INFO - 2016-02-18 21:39:41 --> Router Class Initialized
INFO - 2016-02-18 21:39:41 --> Output Class Initialized
INFO - 2016-02-18 21:39:41 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:41 --> Input Class Initialized
INFO - 2016-02-18 21:39:41 --> Language Class Initialized
INFO - 2016-02-18 21:39:41 --> Loader Class Initialized
INFO - 2016-02-18 21:39:41 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:41 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:41 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:41 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:41 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:42 --> Controller Class Initialized
INFO - 2016-02-18 21:39:42 --> Model Class Initialized
INFO - 2016-02-18 21:39:42 --> Model Class Initialized
INFO - 2016-02-18 21:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:42 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:42 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:39:44 --> Config Class Initialized
INFO - 2016-02-18 21:39:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:39:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:39:44 --> Utf8 Class Initialized
INFO - 2016-02-18 21:39:44 --> URI Class Initialized
INFO - 2016-02-18 21:39:44 --> Router Class Initialized
INFO - 2016-02-18 21:39:44 --> Output Class Initialized
INFO - 2016-02-18 21:39:44 --> Security Class Initialized
DEBUG - 2016-02-18 21:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:39:44 --> Input Class Initialized
INFO - 2016-02-18 21:39:44 --> Language Class Initialized
INFO - 2016-02-18 21:39:44 --> Loader Class Initialized
INFO - 2016-02-18 21:39:44 --> Helper loaded: url_helper
INFO - 2016-02-18 21:39:44 --> Helper loaded: file_helper
INFO - 2016-02-18 21:39:44 --> Helper loaded: date_helper
INFO - 2016-02-18 21:39:44 --> Helper loaded: form_helper
INFO - 2016-02-18 21:39:44 --> Database Driver Class Initialized
INFO - 2016-02-18 21:39:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:39:45 --> Controller Class Initialized
INFO - 2016-02-18 21:39:45 --> Model Class Initialized
INFO - 2016-02-18 21:39:45 --> Model Class Initialized
INFO - 2016-02-18 21:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:39:45 --> Pagination Class Initialized
INFO - 2016-02-18 21:39:45 --> Helper loaded: text_helper
INFO - 2016-02-18 21:39:45 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:42:46 --> Config Class Initialized
INFO - 2016-02-18 21:42:46 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:42:46 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:42:46 --> Utf8 Class Initialized
INFO - 2016-02-18 21:42:46 --> URI Class Initialized
INFO - 2016-02-18 21:42:46 --> Router Class Initialized
INFO - 2016-02-18 21:42:46 --> Output Class Initialized
INFO - 2016-02-18 21:42:46 --> Security Class Initialized
DEBUG - 2016-02-18 21:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:42:46 --> Input Class Initialized
INFO - 2016-02-18 21:42:46 --> Language Class Initialized
INFO - 2016-02-18 21:42:46 --> Loader Class Initialized
INFO - 2016-02-18 21:42:46 --> Helper loaded: url_helper
INFO - 2016-02-18 21:42:46 --> Helper loaded: file_helper
INFO - 2016-02-18 21:42:46 --> Helper loaded: date_helper
INFO - 2016-02-18 21:42:46 --> Helper loaded: form_helper
INFO - 2016-02-18 21:42:46 --> Database Driver Class Initialized
INFO - 2016-02-18 21:42:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:42:47 --> Controller Class Initialized
INFO - 2016-02-18 21:42:47 --> Model Class Initialized
INFO - 2016-02-18 21:42:47 --> Model Class Initialized
INFO - 2016-02-18 21:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:42:47 --> Pagination Class Initialized
INFO - 2016-02-18 21:42:47 --> Helper loaded: text_helper
INFO - 2016-02-18 21:42:47 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:43:37 --> Config Class Initialized
INFO - 2016-02-18 21:43:37 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:43:37 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:43:37 --> Utf8 Class Initialized
INFO - 2016-02-18 21:43:37 --> URI Class Initialized
INFO - 2016-02-18 21:43:37 --> Router Class Initialized
INFO - 2016-02-18 21:43:37 --> Output Class Initialized
INFO - 2016-02-18 21:43:37 --> Security Class Initialized
DEBUG - 2016-02-18 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:43:37 --> Input Class Initialized
INFO - 2016-02-18 21:43:37 --> Language Class Initialized
INFO - 2016-02-18 21:43:37 --> Loader Class Initialized
INFO - 2016-02-18 21:43:37 --> Helper loaded: url_helper
INFO - 2016-02-18 21:43:37 --> Helper loaded: file_helper
INFO - 2016-02-18 21:43:37 --> Helper loaded: date_helper
INFO - 2016-02-18 21:43:37 --> Helper loaded: form_helper
INFO - 2016-02-18 21:43:37 --> Database Driver Class Initialized
INFO - 2016-02-18 21:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:43:38 --> Controller Class Initialized
INFO - 2016-02-18 21:43:38 --> Model Class Initialized
INFO - 2016-02-18 21:43:38 --> Model Class Initialized
INFO - 2016-02-18 21:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:43:38 --> Pagination Class Initialized
INFO - 2016-02-18 21:43:38 --> Helper loaded: text_helper
INFO - 2016-02-18 21:43:38 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:50:16 --> Config Class Initialized
INFO - 2016-02-18 21:50:16 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:50:16 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:50:16 --> Utf8 Class Initialized
INFO - 2016-02-18 21:50:16 --> URI Class Initialized
DEBUG - 2016-02-18 21:50:16 --> No URI present. Default controller set.
INFO - 2016-02-18 21:50:16 --> Router Class Initialized
INFO - 2016-02-18 21:50:16 --> Output Class Initialized
INFO - 2016-02-18 21:50:16 --> Security Class Initialized
DEBUG - 2016-02-18 21:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:50:16 --> Input Class Initialized
INFO - 2016-02-18 21:50:16 --> Language Class Initialized
INFO - 2016-02-18 21:50:16 --> Loader Class Initialized
INFO - 2016-02-18 21:50:16 --> Helper loaded: url_helper
INFO - 2016-02-18 21:50:16 --> Helper loaded: file_helper
INFO - 2016-02-18 21:50:16 --> Helper loaded: date_helper
INFO - 2016-02-18 21:50:16 --> Helper loaded: form_helper
INFO - 2016-02-18 21:50:16 --> Database Driver Class Initialized
INFO - 2016-02-18 21:50:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:50:17 --> Controller Class Initialized
INFO - 2016-02-18 21:50:17 --> Model Class Initialized
INFO - 2016-02-18 21:50:17 --> Model Class Initialized
INFO - 2016-02-18 21:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:50:17 --> Pagination Class Initialized
INFO - 2016-02-18 21:50:17 --> Helper loaded: text_helper
INFO - 2016-02-18 21:50:17 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:51:26 --> Config Class Initialized
INFO - 2016-02-18 21:51:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:51:26 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:51:26 --> Utf8 Class Initialized
INFO - 2016-02-18 21:51:26 --> URI Class Initialized
INFO - 2016-02-18 21:51:26 --> Router Class Initialized
INFO - 2016-02-18 21:51:26 --> Output Class Initialized
INFO - 2016-02-18 21:51:26 --> Security Class Initialized
DEBUG - 2016-02-18 21:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:51:26 --> Input Class Initialized
INFO - 2016-02-18 21:51:26 --> Language Class Initialized
INFO - 2016-02-18 21:51:26 --> Loader Class Initialized
INFO - 2016-02-18 21:51:26 --> Helper loaded: url_helper
INFO - 2016-02-18 21:51:26 --> Helper loaded: file_helper
INFO - 2016-02-18 21:51:26 --> Helper loaded: date_helper
INFO - 2016-02-18 21:51:26 --> Helper loaded: form_helper
INFO - 2016-02-18 21:51:26 --> Database Driver Class Initialized
INFO - 2016-02-18 21:51:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:51:27 --> Controller Class Initialized
INFO - 2016-02-18 21:51:27 --> Model Class Initialized
INFO - 2016-02-18 21:51:27 --> Model Class Initialized
INFO - 2016-02-18 21:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:51:27 --> Pagination Class Initialized
INFO - 2016-02-18 21:51:27 --> Helper loaded: text_helper
INFO - 2016-02-18 21:51:27 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:51:39 --> Config Class Initialized
INFO - 2016-02-18 21:51:39 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:51:39 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:51:39 --> Utf8 Class Initialized
INFO - 2016-02-18 21:51:39 --> URI Class Initialized
INFO - 2016-02-18 21:51:39 --> Router Class Initialized
INFO - 2016-02-18 21:51:39 --> Output Class Initialized
INFO - 2016-02-18 21:51:39 --> Security Class Initialized
DEBUG - 2016-02-18 21:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:51:39 --> Input Class Initialized
INFO - 2016-02-18 21:51:39 --> Language Class Initialized
INFO - 2016-02-18 21:51:39 --> Loader Class Initialized
INFO - 2016-02-18 21:51:39 --> Helper loaded: url_helper
INFO - 2016-02-18 21:51:39 --> Helper loaded: file_helper
INFO - 2016-02-18 21:51:39 --> Helper loaded: date_helper
INFO - 2016-02-18 21:51:39 --> Helper loaded: form_helper
INFO - 2016-02-18 21:51:39 --> Database Driver Class Initialized
INFO - 2016-02-18 21:51:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:51:40 --> Controller Class Initialized
INFO - 2016-02-18 21:51:40 --> Model Class Initialized
INFO - 2016-02-18 21:51:40 --> Model Class Initialized
INFO - 2016-02-18 21:51:40 --> Form Validation Class Initialized
INFO - 2016-02-18 21:51:41 --> Helper loaded: text_helper
INFO - 2016-02-18 21:51:41 --> Config Class Initialized
INFO - 2016-02-18 21:51:41 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:51:41 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:51:41 --> Utf8 Class Initialized
INFO - 2016-02-18 21:51:41 --> URI Class Initialized
INFO - 2016-02-18 21:51:41 --> Router Class Initialized
INFO - 2016-02-18 21:51:41 --> Output Class Initialized
INFO - 2016-02-18 21:51:41 --> Security Class Initialized
DEBUG - 2016-02-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:51:41 --> Input Class Initialized
INFO - 2016-02-18 21:51:41 --> Language Class Initialized
INFO - 2016-02-18 21:51:41 --> Loader Class Initialized
INFO - 2016-02-18 21:51:41 --> Helper loaded: url_helper
INFO - 2016-02-18 21:51:41 --> Helper loaded: file_helper
INFO - 2016-02-18 21:51:41 --> Helper loaded: date_helper
INFO - 2016-02-18 21:51:41 --> Helper loaded: form_helper
INFO - 2016-02-18 21:51:41 --> Database Driver Class Initialized
INFO - 2016-02-18 21:51:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:51:42 --> Controller Class Initialized
INFO - 2016-02-18 21:51:42 --> Model Class Initialized
INFO - 2016-02-18 21:51:42 --> Model Class Initialized
INFO - 2016-02-18 21:51:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:51:42 --> Pagination Class Initialized
INFO - 2016-02-18 21:51:42 --> Helper loaded: text_helper
INFO - 2016-02-18 21:51:42 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:52:26 --> Config Class Initialized
INFO - 2016-02-18 21:52:26 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:26 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:52:26 --> Utf8 Class Initialized
INFO - 2016-02-18 21:52:26 --> URI Class Initialized
DEBUG - 2016-02-18 21:52:26 --> No URI present. Default controller set.
INFO - 2016-02-18 21:52:26 --> Router Class Initialized
INFO - 2016-02-18 21:52:26 --> Output Class Initialized
INFO - 2016-02-18 21:52:26 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:52:26 --> Input Class Initialized
INFO - 2016-02-18 21:52:26 --> Language Class Initialized
INFO - 2016-02-18 21:52:26 --> Loader Class Initialized
INFO - 2016-02-18 21:52:26 --> Helper loaded: url_helper
INFO - 2016-02-18 21:52:26 --> Helper loaded: file_helper
INFO - 2016-02-18 21:52:26 --> Helper loaded: date_helper
INFO - 2016-02-18 21:52:26 --> Helper loaded: form_helper
INFO - 2016-02-18 21:52:26 --> Database Driver Class Initialized
INFO - 2016-02-18 21:52:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:52:28 --> Controller Class Initialized
INFO - 2016-02-18 21:52:28 --> Model Class Initialized
INFO - 2016-02-18 21:52:28 --> Model Class Initialized
INFO - 2016-02-18 21:52:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:52:28 --> Pagination Class Initialized
INFO - 2016-02-18 21:52:28 --> Helper loaded: text_helper
INFO - 2016-02-18 21:52:28 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:52:38 --> Config Class Initialized
INFO - 2016-02-18 21:52:38 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:38 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:52:38 --> Utf8 Class Initialized
INFO - 2016-02-18 21:52:38 --> URI Class Initialized
INFO - 2016-02-18 21:52:38 --> Router Class Initialized
INFO - 2016-02-18 21:52:38 --> Output Class Initialized
INFO - 2016-02-18 21:52:38 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:52:38 --> Input Class Initialized
INFO - 2016-02-18 21:52:38 --> Language Class Initialized
INFO - 2016-02-18 21:52:38 --> Loader Class Initialized
INFO - 2016-02-18 21:52:38 --> Helper loaded: url_helper
INFO - 2016-02-18 21:52:38 --> Helper loaded: file_helper
INFO - 2016-02-18 21:52:38 --> Helper loaded: date_helper
INFO - 2016-02-18 21:52:38 --> Helper loaded: form_helper
INFO - 2016-02-18 21:52:38 --> Database Driver Class Initialized
INFO - 2016-02-18 21:52:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:52:39 --> Controller Class Initialized
INFO - 2016-02-18 21:52:39 --> Model Class Initialized
INFO - 2016-02-18 21:52:39 --> Model Class Initialized
INFO - 2016-02-18 21:52:39 --> Form Validation Class Initialized
INFO - 2016-02-18 21:52:39 --> Helper loaded: text_helper
INFO - 2016-02-18 21:52:40 --> Config Class Initialized
INFO - 2016-02-18 21:52:40 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:40 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:52:40 --> Utf8 Class Initialized
INFO - 2016-02-18 21:52:40 --> URI Class Initialized
DEBUG - 2016-02-18 21:52:40 --> No URI present. Default controller set.
INFO - 2016-02-18 21:52:40 --> Router Class Initialized
INFO - 2016-02-18 21:52:40 --> Output Class Initialized
INFO - 2016-02-18 21:52:40 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:52:40 --> Input Class Initialized
INFO - 2016-02-18 21:52:40 --> Language Class Initialized
INFO - 2016-02-18 21:52:40 --> Loader Class Initialized
INFO - 2016-02-18 21:52:40 --> Helper loaded: url_helper
INFO - 2016-02-18 21:52:40 --> Helper loaded: file_helper
INFO - 2016-02-18 21:52:40 --> Helper loaded: date_helper
INFO - 2016-02-18 21:52:40 --> Helper loaded: form_helper
INFO - 2016-02-18 21:52:40 --> Database Driver Class Initialized
INFO - 2016-02-18 21:52:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:52:41 --> Controller Class Initialized
INFO - 2016-02-18 21:52:41 --> Model Class Initialized
INFO - 2016-02-18 21:52:41 --> Model Class Initialized
INFO - 2016-02-18 21:52:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:52:41 --> Pagination Class Initialized
INFO - 2016-02-18 21:52:41 --> Helper loaded: text_helper
INFO - 2016-02-18 21:52:41 --> Helper loaded: cookie_helper
INFO - 2016-02-18 21:52:42 --> Config Class Initialized
INFO - 2016-02-18 21:52:42 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:42 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:52:42 --> Utf8 Class Initialized
INFO - 2016-02-18 21:52:42 --> URI Class Initialized
INFO - 2016-02-18 21:52:42 --> Router Class Initialized
INFO - 2016-02-18 21:52:42 --> Output Class Initialized
INFO - 2016-02-18 21:52:42 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:52:42 --> Input Class Initialized
INFO - 2016-02-18 21:52:42 --> Language Class Initialized
INFO - 2016-02-18 21:52:42 --> Loader Class Initialized
INFO - 2016-02-18 21:52:42 --> Helper loaded: url_helper
INFO - 2016-02-18 21:52:42 --> Helper loaded: file_helper
INFO - 2016-02-18 21:52:42 --> Helper loaded: date_helper
INFO - 2016-02-18 21:52:42 --> Helper loaded: form_helper
INFO - 2016-02-18 21:52:42 --> Database Driver Class Initialized
INFO - 2016-02-18 21:52:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:52:43 --> Controller Class Initialized
INFO - 2016-02-18 21:52:43 --> Model Class Initialized
INFO - 2016-02-18 21:52:44 --> Model Class Initialized
INFO - 2016-02-18 21:52:44 --> Form Validation Class Initialized
INFO - 2016-02-18 21:52:44 --> Helper loaded: text_helper
INFO - 2016-02-18 21:52:44 --> Config Class Initialized
INFO - 2016-02-18 21:52:44 --> Hooks Class Initialized
DEBUG - 2016-02-18 21:52:44 --> UTF-8 Support Enabled
INFO - 2016-02-18 21:52:44 --> Utf8 Class Initialized
INFO - 2016-02-18 21:52:44 --> URI Class Initialized
DEBUG - 2016-02-18 21:52:44 --> No URI present. Default controller set.
INFO - 2016-02-18 21:52:44 --> Router Class Initialized
INFO - 2016-02-18 21:52:44 --> Output Class Initialized
INFO - 2016-02-18 21:52:44 --> Security Class Initialized
DEBUG - 2016-02-18 21:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-18 21:52:44 --> Input Class Initialized
INFO - 2016-02-18 21:52:44 --> Language Class Initialized
INFO - 2016-02-18 21:52:44 --> Loader Class Initialized
INFO - 2016-02-18 21:52:44 --> Helper loaded: url_helper
INFO - 2016-02-18 21:52:44 --> Helper loaded: file_helper
INFO - 2016-02-18 21:52:44 --> Helper loaded: date_helper
INFO - 2016-02-18 21:52:44 --> Helper loaded: form_helper
INFO - 2016-02-18 21:52:44 --> Database Driver Class Initialized
INFO - 2016-02-18 21:52:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-18 21:52:45 --> Controller Class Initialized
INFO - 2016-02-18 21:52:45 --> Model Class Initialized
INFO - 2016-02-18 21:52:45 --> Model Class Initialized
INFO - 2016-02-18 21:52:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-18 21:52:45 --> Pagination Class Initialized
INFO - 2016-02-18 21:52:45 --> Helper loaded: text_helper
INFO - 2016-02-18 21:52:45 --> Helper loaded: cookie_helper
