<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-09 05:23:52 --> Config Class Initialized
INFO - 2016-02-09 05:23:52 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:23:52 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:23:52 --> Utf8 Class Initialized
INFO - 2016-02-09 05:23:52 --> URI Class Initialized
INFO - 2016-02-09 05:23:52 --> Router Class Initialized
INFO - 2016-02-09 05:23:52 --> Output Class Initialized
INFO - 2016-02-09 05:23:52 --> Security Class Initialized
DEBUG - 2016-02-09 05:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:23:52 --> Input Class Initialized
INFO - 2016-02-09 05:23:52 --> Language Class Initialized
INFO - 2016-02-09 05:23:52 --> Loader Class Initialized
INFO - 2016-02-09 05:23:52 --> Helper loaded: url_helper
INFO - 2016-02-09 05:23:52 --> Helper loaded: file_helper
INFO - 2016-02-09 05:23:52 --> Helper loaded: date_helper
INFO - 2016-02-09 05:23:53 --> Helper loaded: form_helper
INFO - 2016-02-09 05:23:53 --> Database Driver Class Initialized
INFO - 2016-02-09 05:23:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:23:54 --> Controller Class Initialized
INFO - 2016-02-09 05:23:54 --> Model Class Initialized
INFO - 2016-02-09 05:23:54 --> Model Class Initialized
INFO - 2016-02-09 05:23:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:23:54 --> Pagination Class Initialized
INFO - 2016-02-09 05:23:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:23:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:23:54 --> Helper loaded: text_helper
INFO - 2016-02-09 05:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 05:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 05:23:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:23:55 --> Final output sent to browser
DEBUG - 2016-02-09 05:23:55 --> Total execution time: 2.6241
INFO - 2016-02-09 05:25:41 --> Config Class Initialized
INFO - 2016-02-09 05:25:41 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:25:41 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:25:41 --> Utf8 Class Initialized
INFO - 2016-02-09 05:25:41 --> URI Class Initialized
INFO - 2016-02-09 05:25:41 --> Router Class Initialized
INFO - 2016-02-09 05:25:41 --> Output Class Initialized
INFO - 2016-02-09 05:25:41 --> Security Class Initialized
DEBUG - 2016-02-09 05:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:25:41 --> Input Class Initialized
INFO - 2016-02-09 05:25:41 --> Language Class Initialized
INFO - 2016-02-09 05:25:41 --> Loader Class Initialized
INFO - 2016-02-09 05:25:41 --> Helper loaded: url_helper
INFO - 2016-02-09 05:25:41 --> Helper loaded: file_helper
INFO - 2016-02-09 05:25:41 --> Helper loaded: date_helper
INFO - 2016-02-09 05:25:41 --> Helper loaded: form_helper
INFO - 2016-02-09 05:25:41 --> Database Driver Class Initialized
INFO - 2016-02-09 05:25:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:25:42 --> Controller Class Initialized
INFO - 2016-02-09 05:25:42 --> Model Class Initialized
INFO - 2016-02-09 05:25:42 --> Model Class Initialized
INFO - 2016-02-09 05:25:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:25:42 --> Pagination Class Initialized
INFO - 2016-02-09 05:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:25:42 --> Helper loaded: text_helper
INFO - 2016-02-09 05:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 05:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 05:25:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:25:42 --> Final output sent to browser
DEBUG - 2016-02-09 05:25:42 --> Total execution time: 1.1847
INFO - 2016-02-09 05:25:54 --> Config Class Initialized
INFO - 2016-02-09 05:25:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:25:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:25:54 --> Utf8 Class Initialized
INFO - 2016-02-09 05:25:54 --> URI Class Initialized
DEBUG - 2016-02-09 05:25:54 --> No URI present. Default controller set.
INFO - 2016-02-09 05:25:54 --> Router Class Initialized
INFO - 2016-02-09 05:25:54 --> Output Class Initialized
INFO - 2016-02-09 05:25:54 --> Security Class Initialized
DEBUG - 2016-02-09 05:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:25:54 --> Input Class Initialized
INFO - 2016-02-09 05:25:54 --> Language Class Initialized
INFO - 2016-02-09 05:25:54 --> Loader Class Initialized
INFO - 2016-02-09 05:25:54 --> Helper loaded: url_helper
INFO - 2016-02-09 05:25:54 --> Helper loaded: file_helper
INFO - 2016-02-09 05:25:54 --> Helper loaded: date_helper
INFO - 2016-02-09 05:25:54 --> Helper loaded: form_helper
INFO - 2016-02-09 05:25:54 --> Database Driver Class Initialized
INFO - 2016-02-09 05:25:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:25:55 --> Controller Class Initialized
INFO - 2016-02-09 05:25:55 --> Model Class Initialized
INFO - 2016-02-09 05:25:55 --> Model Class Initialized
INFO - 2016-02-09 05:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:25:55 --> Pagination Class Initialized
INFO - 2016-02-09 05:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 05:25:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:25:56 --> Final output sent to browser
DEBUG - 2016-02-09 05:25:56 --> Total execution time: 1.1352
INFO - 2016-02-09 05:26:08 --> Config Class Initialized
INFO - 2016-02-09 05:26:08 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:26:08 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:26:08 --> Utf8 Class Initialized
INFO - 2016-02-09 05:26:08 --> URI Class Initialized
INFO - 2016-02-09 05:26:08 --> Router Class Initialized
INFO - 2016-02-09 05:26:08 --> Output Class Initialized
INFO - 2016-02-09 05:26:08 --> Security Class Initialized
DEBUG - 2016-02-09 05:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:26:08 --> Input Class Initialized
INFO - 2016-02-09 05:26:08 --> Language Class Initialized
INFO - 2016-02-09 05:26:08 --> Loader Class Initialized
INFO - 2016-02-09 05:26:08 --> Helper loaded: url_helper
INFO - 2016-02-09 05:26:08 --> Helper loaded: file_helper
INFO - 2016-02-09 05:26:08 --> Helper loaded: date_helper
INFO - 2016-02-09 05:26:08 --> Helper loaded: form_helper
INFO - 2016-02-09 05:26:08 --> Database Driver Class Initialized
INFO - 2016-02-09 05:26:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:26:09 --> Controller Class Initialized
INFO - 2016-02-09 05:26:09 --> Model Class Initialized
INFO - 2016-02-09 05:26:09 --> Model Class Initialized
INFO - 2016-02-09 05:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:26:09 --> Pagination Class Initialized
INFO - 2016-02-09 05:26:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:26:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:26:10 --> Helper loaded: text_helper
INFO - 2016-02-09 05:26:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 05:26:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 05:26:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:26:10 --> Final output sent to browser
DEBUG - 2016-02-09 05:26:10 --> Total execution time: 1.1716
INFO - 2016-02-09 05:26:48 --> Config Class Initialized
INFO - 2016-02-09 05:26:48 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:26:48 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:26:48 --> Utf8 Class Initialized
INFO - 2016-02-09 05:26:48 --> URI Class Initialized
INFO - 2016-02-09 05:26:48 --> Router Class Initialized
INFO - 2016-02-09 05:26:48 --> Output Class Initialized
INFO - 2016-02-09 05:26:48 --> Security Class Initialized
DEBUG - 2016-02-09 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:26:48 --> Input Class Initialized
INFO - 2016-02-09 05:26:48 --> Language Class Initialized
INFO - 2016-02-09 05:26:48 --> Loader Class Initialized
INFO - 2016-02-09 05:26:48 --> Helper loaded: url_helper
INFO - 2016-02-09 05:26:48 --> Helper loaded: file_helper
INFO - 2016-02-09 05:26:48 --> Helper loaded: date_helper
INFO - 2016-02-09 05:26:48 --> Helper loaded: form_helper
INFO - 2016-02-09 05:26:48 --> Database Driver Class Initialized
INFO - 2016-02-09 05:26:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:26:49 --> Controller Class Initialized
INFO - 2016-02-09 05:26:50 --> Model Class Initialized
INFO - 2016-02-09 05:26:50 --> Model Class Initialized
INFO - 2016-02-09 05:26:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:26:50 --> Pagination Class Initialized
INFO - 2016-02-09 05:26:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:26:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:26:50 --> Helper loaded: text_helper
INFO - 2016-02-09 05:26:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 05:26:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 05:26:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:26:50 --> Final output sent to browser
DEBUG - 2016-02-09 05:26:50 --> Total execution time: 1.2083
INFO - 2016-02-09 05:27:10 --> Config Class Initialized
INFO - 2016-02-09 05:27:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 05:27:10 --> UTF-8 Support Enabled
INFO - 2016-02-09 05:27:10 --> Utf8 Class Initialized
INFO - 2016-02-09 05:27:10 --> URI Class Initialized
INFO - 2016-02-09 05:27:10 --> Router Class Initialized
INFO - 2016-02-09 05:27:10 --> Output Class Initialized
INFO - 2016-02-09 05:27:10 --> Security Class Initialized
DEBUG - 2016-02-09 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 05:27:10 --> Input Class Initialized
INFO - 2016-02-09 05:27:10 --> Language Class Initialized
INFO - 2016-02-09 05:27:10 --> Loader Class Initialized
INFO - 2016-02-09 05:27:10 --> Helper loaded: url_helper
INFO - 2016-02-09 05:27:10 --> Helper loaded: file_helper
INFO - 2016-02-09 05:27:10 --> Helper loaded: date_helper
INFO - 2016-02-09 05:27:10 --> Helper loaded: form_helper
INFO - 2016-02-09 05:27:10 --> Database Driver Class Initialized
INFO - 2016-02-09 05:27:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 05:27:11 --> Controller Class Initialized
INFO - 2016-02-09 05:27:11 --> Model Class Initialized
INFO - 2016-02-09 05:27:11 --> Model Class Initialized
INFO - 2016-02-09 05:27:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 05:27:11 --> Pagination Class Initialized
INFO - 2016-02-09 05:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 05:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 05:27:11 --> Helper loaded: text_helper
INFO - 2016-02-09 05:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 05:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 05:27:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 05:27:11 --> Final output sent to browser
DEBUG - 2016-02-09 05:27:11 --> Total execution time: 1.1760
INFO - 2016-02-09 06:22:34 --> Config Class Initialized
INFO - 2016-02-09 06:22:34 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:22:35 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:22:35 --> Utf8 Class Initialized
INFO - 2016-02-09 06:22:35 --> URI Class Initialized
DEBUG - 2016-02-09 06:22:35 --> No URI present. Default controller set.
INFO - 2016-02-09 06:22:35 --> Router Class Initialized
INFO - 2016-02-09 06:22:35 --> Output Class Initialized
INFO - 2016-02-09 06:22:35 --> Security Class Initialized
DEBUG - 2016-02-09 06:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:22:35 --> Input Class Initialized
INFO - 2016-02-09 06:22:35 --> Language Class Initialized
INFO - 2016-02-09 06:22:35 --> Loader Class Initialized
INFO - 2016-02-09 06:22:35 --> Helper loaded: url_helper
INFO - 2016-02-09 06:22:35 --> Helper loaded: file_helper
INFO - 2016-02-09 06:22:35 --> Helper loaded: date_helper
INFO - 2016-02-09 06:22:35 --> Helper loaded: form_helper
INFO - 2016-02-09 06:22:35 --> Database Driver Class Initialized
INFO - 2016-02-09 06:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:22:36 --> Controller Class Initialized
INFO - 2016-02-09 06:22:36 --> Model Class Initialized
INFO - 2016-02-09 06:22:36 --> Model Class Initialized
INFO - 2016-02-09 06:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:22:36 --> Pagination Class Initialized
INFO - 2016-02-09 06:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:22:36 --> Final output sent to browser
DEBUG - 2016-02-09 06:22:36 --> Total execution time: 1.3465
INFO - 2016-02-09 06:22:39 --> Config Class Initialized
INFO - 2016-02-09 06:22:39 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:22:39 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:22:39 --> Utf8 Class Initialized
INFO - 2016-02-09 06:22:39 --> URI Class Initialized
INFO - 2016-02-09 06:22:39 --> Router Class Initialized
INFO - 2016-02-09 06:22:39 --> Output Class Initialized
INFO - 2016-02-09 06:22:39 --> Security Class Initialized
DEBUG - 2016-02-09 06:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:22:39 --> Input Class Initialized
INFO - 2016-02-09 06:22:39 --> Language Class Initialized
INFO - 2016-02-09 06:22:39 --> Loader Class Initialized
INFO - 2016-02-09 06:22:39 --> Helper loaded: url_helper
INFO - 2016-02-09 06:22:39 --> Helper loaded: file_helper
INFO - 2016-02-09 06:22:39 --> Helper loaded: date_helper
INFO - 2016-02-09 06:22:39 --> Helper loaded: form_helper
INFO - 2016-02-09 06:22:39 --> Database Driver Class Initialized
INFO - 2016-02-09 06:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:22:40 --> Controller Class Initialized
INFO - 2016-02-09 06:22:40 --> Model Class Initialized
INFO - 2016-02-09 06:22:40 --> Model Class Initialized
INFO - 2016-02-09 06:22:40 --> Form Validation Class Initialized
INFO - 2016-02-09 06:22:40 --> Helper loaded: text_helper
INFO - 2016-02-09 06:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-09 06:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:22:40 --> Final output sent to browser
DEBUG - 2016-02-09 06:22:40 --> Total execution time: 1.1233
INFO - 2016-02-09 06:22:46 --> Config Class Initialized
INFO - 2016-02-09 06:22:46 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:22:46 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:22:46 --> Utf8 Class Initialized
INFO - 2016-02-09 06:22:46 --> URI Class Initialized
INFO - 2016-02-09 06:22:46 --> Router Class Initialized
INFO - 2016-02-09 06:22:46 --> Output Class Initialized
INFO - 2016-02-09 06:22:46 --> Security Class Initialized
DEBUG - 2016-02-09 06:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:22:46 --> Input Class Initialized
INFO - 2016-02-09 06:22:46 --> Language Class Initialized
INFO - 2016-02-09 06:22:46 --> Loader Class Initialized
INFO - 2016-02-09 06:22:46 --> Helper loaded: url_helper
INFO - 2016-02-09 06:22:46 --> Helper loaded: file_helper
INFO - 2016-02-09 06:22:46 --> Helper loaded: date_helper
INFO - 2016-02-09 06:22:46 --> Helper loaded: form_helper
INFO - 2016-02-09 06:22:46 --> Database Driver Class Initialized
INFO - 2016-02-09 06:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:22:47 --> Controller Class Initialized
INFO - 2016-02-09 06:22:47 --> Model Class Initialized
INFO - 2016-02-09 06:22:47 --> Model Class Initialized
INFO - 2016-02-09 06:22:47 --> Form Validation Class Initialized
INFO - 2016-02-09 06:22:47 --> Helper loaded: text_helper
INFO - 2016-02-09 06:22:47 --> Config Class Initialized
INFO - 2016-02-09 06:22:47 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:22:47 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:22:47 --> Utf8 Class Initialized
INFO - 2016-02-09 06:22:47 --> URI Class Initialized
INFO - 2016-02-09 06:22:47 --> Router Class Initialized
INFO - 2016-02-09 06:22:47 --> Output Class Initialized
INFO - 2016-02-09 06:22:47 --> Security Class Initialized
DEBUG - 2016-02-09 06:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:22:47 --> Input Class Initialized
INFO - 2016-02-09 06:22:47 --> Language Class Initialized
INFO - 2016-02-09 06:22:47 --> Loader Class Initialized
INFO - 2016-02-09 06:22:47 --> Helper loaded: url_helper
INFO - 2016-02-09 06:22:47 --> Helper loaded: file_helper
INFO - 2016-02-09 06:22:47 --> Helper loaded: date_helper
INFO - 2016-02-09 06:22:47 --> Helper loaded: form_helper
INFO - 2016-02-09 06:22:47 --> Database Driver Class Initialized
INFO - 2016-02-09 06:22:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:22:48 --> Controller Class Initialized
INFO - 2016-02-09 06:22:48 --> Model Class Initialized
INFO - 2016-02-09 06:22:48 --> Model Class Initialized
INFO - 2016-02-09 06:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:22:48 --> Pagination Class Initialized
INFO - 2016-02-09 06:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:22:48 --> Final output sent to browser
DEBUG - 2016-02-09 06:22:48 --> Total execution time: 1.0716
INFO - 2016-02-09 06:22:50 --> Config Class Initialized
INFO - 2016-02-09 06:22:50 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:22:50 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:22:50 --> Utf8 Class Initialized
INFO - 2016-02-09 06:22:50 --> URI Class Initialized
INFO - 2016-02-09 06:22:50 --> Router Class Initialized
INFO - 2016-02-09 06:22:50 --> Output Class Initialized
INFO - 2016-02-09 06:22:50 --> Security Class Initialized
DEBUG - 2016-02-09 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:22:50 --> Input Class Initialized
INFO - 2016-02-09 06:22:50 --> Language Class Initialized
INFO - 2016-02-09 06:22:50 --> Loader Class Initialized
INFO - 2016-02-09 06:22:50 --> Helper loaded: url_helper
INFO - 2016-02-09 06:22:50 --> Helper loaded: file_helper
INFO - 2016-02-09 06:22:50 --> Helper loaded: date_helper
INFO - 2016-02-09 06:22:50 --> Helper loaded: form_helper
INFO - 2016-02-09 06:22:50 --> Database Driver Class Initialized
INFO - 2016-02-09 06:22:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:22:51 --> Controller Class Initialized
INFO - 2016-02-09 06:22:51 --> Model Class Initialized
INFO - 2016-02-09 06:22:51 --> Model Class Initialized
INFO - 2016-02-09 06:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:22:51 --> Pagination Class Initialized
INFO - 2016-02-09 06:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:22:51 --> Helper loaded: text_helper
INFO - 2016-02-09 06:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:22:51 --> Final output sent to browser
DEBUG - 2016-02-09 06:22:51 --> Total execution time: 1.2735
INFO - 2016-02-09 06:24:18 --> Config Class Initialized
INFO - 2016-02-09 06:24:18 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:24:18 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:24:18 --> Utf8 Class Initialized
INFO - 2016-02-09 06:24:18 --> URI Class Initialized
INFO - 2016-02-09 06:24:18 --> Router Class Initialized
INFO - 2016-02-09 06:24:18 --> Output Class Initialized
INFO - 2016-02-09 06:24:18 --> Security Class Initialized
DEBUG - 2016-02-09 06:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:24:18 --> Input Class Initialized
INFO - 2016-02-09 06:24:18 --> Language Class Initialized
INFO - 2016-02-09 06:24:18 --> Loader Class Initialized
INFO - 2016-02-09 06:24:18 --> Helper loaded: url_helper
INFO - 2016-02-09 06:24:18 --> Helper loaded: file_helper
INFO - 2016-02-09 06:24:18 --> Helper loaded: date_helper
INFO - 2016-02-09 06:24:18 --> Helper loaded: form_helper
INFO - 2016-02-09 06:24:18 --> Database Driver Class Initialized
INFO - 2016-02-09 06:24:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:24:19 --> Controller Class Initialized
INFO - 2016-02-09 06:24:19 --> Model Class Initialized
INFO - 2016-02-09 06:24:19 --> Model Class Initialized
INFO - 2016-02-09 06:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:24:19 --> Pagination Class Initialized
INFO - 2016-02-09 06:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:24:19 --> Helper loaded: text_helper
INFO - 2016-02-09 06:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:24:19 --> Final output sent to browser
DEBUG - 2016-02-09 06:24:19 --> Total execution time: 1.2372
INFO - 2016-02-09 06:29:33 --> Config Class Initialized
INFO - 2016-02-09 06:29:33 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:29:33 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:29:33 --> Utf8 Class Initialized
INFO - 2016-02-09 06:29:33 --> URI Class Initialized
INFO - 2016-02-09 06:29:33 --> Router Class Initialized
INFO - 2016-02-09 06:29:33 --> Output Class Initialized
INFO - 2016-02-09 06:29:33 --> Security Class Initialized
DEBUG - 2016-02-09 06:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:29:33 --> Input Class Initialized
INFO - 2016-02-09 06:29:33 --> Language Class Initialized
INFO - 2016-02-09 06:29:33 --> Loader Class Initialized
INFO - 2016-02-09 06:29:33 --> Helper loaded: url_helper
INFO - 2016-02-09 06:29:33 --> Helper loaded: file_helper
INFO - 2016-02-09 06:29:33 --> Helper loaded: date_helper
INFO - 2016-02-09 06:29:33 --> Helper loaded: form_helper
INFO - 2016-02-09 06:29:33 --> Database Driver Class Initialized
INFO - 2016-02-09 06:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:29:35 --> Controller Class Initialized
INFO - 2016-02-09 06:29:35 --> Model Class Initialized
INFO - 2016-02-09 06:29:35 --> Model Class Initialized
INFO - 2016-02-09 06:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:29:35 --> Pagination Class Initialized
INFO - 2016-02-09 06:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:29:35 --> Helper loaded: text_helper
INFO - 2016-02-09 06:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:29:35 --> Final output sent to browser
DEBUG - 2016-02-09 06:29:35 --> Total execution time: 1.1718
INFO - 2016-02-09 06:29:43 --> Config Class Initialized
INFO - 2016-02-09 06:29:43 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:29:43 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:29:43 --> Utf8 Class Initialized
INFO - 2016-02-09 06:29:43 --> URI Class Initialized
INFO - 2016-02-09 06:29:43 --> Router Class Initialized
INFO - 2016-02-09 06:29:43 --> Output Class Initialized
INFO - 2016-02-09 06:29:43 --> Security Class Initialized
DEBUG - 2016-02-09 06:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:29:43 --> Input Class Initialized
INFO - 2016-02-09 06:29:43 --> Language Class Initialized
INFO - 2016-02-09 06:29:43 --> Loader Class Initialized
INFO - 2016-02-09 06:29:43 --> Helper loaded: url_helper
INFO - 2016-02-09 06:29:43 --> Helper loaded: file_helper
INFO - 2016-02-09 06:29:43 --> Helper loaded: date_helper
INFO - 2016-02-09 06:29:43 --> Helper loaded: form_helper
INFO - 2016-02-09 06:29:43 --> Database Driver Class Initialized
INFO - 2016-02-09 06:29:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:29:44 --> Controller Class Initialized
INFO - 2016-02-09 06:29:44 --> Model Class Initialized
INFO - 2016-02-09 06:29:44 --> Model Class Initialized
INFO - 2016-02-09 06:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:29:44 --> Pagination Class Initialized
INFO - 2016-02-09 06:29:44 --> Form Validation Class Initialized
INFO - 2016-02-09 06:29:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:29:44 --> Model Class Initialized
ERROR - 2016-02-09 06:29:44 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 06:29:44 --> Final output sent to browser
DEBUG - 2016-02-09 06:29:44 --> Total execution time: 1.2197
INFO - 2016-02-09 06:30:57 --> Config Class Initialized
INFO - 2016-02-09 06:30:57 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:30:57 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:30:57 --> Utf8 Class Initialized
INFO - 2016-02-09 06:30:57 --> URI Class Initialized
INFO - 2016-02-09 06:30:57 --> Router Class Initialized
INFO - 2016-02-09 06:30:57 --> Output Class Initialized
INFO - 2016-02-09 06:30:57 --> Security Class Initialized
DEBUG - 2016-02-09 06:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:30:57 --> Input Class Initialized
INFO - 2016-02-09 06:30:57 --> Language Class Initialized
INFO - 2016-02-09 06:30:57 --> Loader Class Initialized
INFO - 2016-02-09 06:30:57 --> Helper loaded: url_helper
INFO - 2016-02-09 06:30:57 --> Helper loaded: file_helper
INFO - 2016-02-09 06:30:57 --> Helper loaded: date_helper
INFO - 2016-02-09 06:30:57 --> Helper loaded: form_helper
INFO - 2016-02-09 06:30:57 --> Database Driver Class Initialized
INFO - 2016-02-09 06:30:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:30:58 --> Controller Class Initialized
INFO - 2016-02-09 06:30:58 --> Model Class Initialized
INFO - 2016-02-09 06:30:58 --> Model Class Initialized
INFO - 2016-02-09 06:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:30:58 --> Pagination Class Initialized
INFO - 2016-02-09 06:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:30:58 --> Helper loaded: text_helper
INFO - 2016-02-09 06:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:30:58 --> Final output sent to browser
DEBUG - 2016-02-09 06:30:58 --> Total execution time: 1.1987
INFO - 2016-02-09 06:31:07 --> Config Class Initialized
INFO - 2016-02-09 06:31:07 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:31:07 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:31:07 --> Utf8 Class Initialized
INFO - 2016-02-09 06:31:07 --> URI Class Initialized
INFO - 2016-02-09 06:31:07 --> Router Class Initialized
INFO - 2016-02-09 06:31:07 --> Output Class Initialized
INFO - 2016-02-09 06:31:07 --> Security Class Initialized
DEBUG - 2016-02-09 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:31:07 --> Input Class Initialized
INFO - 2016-02-09 06:31:07 --> Language Class Initialized
INFO - 2016-02-09 06:31:07 --> Loader Class Initialized
INFO - 2016-02-09 06:31:07 --> Helper loaded: url_helper
INFO - 2016-02-09 06:31:07 --> Helper loaded: file_helper
INFO - 2016-02-09 06:31:07 --> Helper loaded: date_helper
INFO - 2016-02-09 06:31:07 --> Helper loaded: form_helper
INFO - 2016-02-09 06:31:07 --> Database Driver Class Initialized
INFO - 2016-02-09 06:31:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:31:08 --> Controller Class Initialized
INFO - 2016-02-09 06:31:08 --> Model Class Initialized
INFO - 2016-02-09 06:31:08 --> Model Class Initialized
INFO - 2016-02-09 06:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:31:08 --> Pagination Class Initialized
INFO - 2016-02-09 06:31:08 --> Form Validation Class Initialized
INFO - 2016-02-09 06:31:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:31:08 --> Model Class Initialized
ERROR - 2016-02-09 06:31:08 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 06:31:08 --> Final output sent to browser
DEBUG - 2016-02-09 06:31:08 --> Total execution time: 1.2016
INFO - 2016-02-09 06:31:59 --> Config Class Initialized
INFO - 2016-02-09 06:31:59 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:31:59 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:31:59 --> Utf8 Class Initialized
INFO - 2016-02-09 06:31:59 --> URI Class Initialized
INFO - 2016-02-09 06:31:59 --> Router Class Initialized
INFO - 2016-02-09 06:31:59 --> Output Class Initialized
INFO - 2016-02-09 06:31:59 --> Security Class Initialized
DEBUG - 2016-02-09 06:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:31:59 --> Input Class Initialized
INFO - 2016-02-09 06:31:59 --> Language Class Initialized
INFO - 2016-02-09 06:31:59 --> Loader Class Initialized
INFO - 2016-02-09 06:31:59 --> Helper loaded: url_helper
INFO - 2016-02-09 06:31:59 --> Helper loaded: file_helper
INFO - 2016-02-09 06:31:59 --> Helper loaded: date_helper
INFO - 2016-02-09 06:31:59 --> Helper loaded: form_helper
INFO - 2016-02-09 06:31:59 --> Database Driver Class Initialized
INFO - 2016-02-09 06:32:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:32:00 --> Controller Class Initialized
INFO - 2016-02-09 06:32:00 --> Model Class Initialized
INFO - 2016-02-09 06:32:00 --> Model Class Initialized
INFO - 2016-02-09 06:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:32:00 --> Pagination Class Initialized
INFO - 2016-02-09 06:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:32:00 --> Helper loaded: text_helper
INFO - 2016-02-09 06:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:32:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:32:00 --> Final output sent to browser
DEBUG - 2016-02-09 06:32:00 --> Total execution time: 1.2070
INFO - 2016-02-09 06:32:07 --> Config Class Initialized
INFO - 2016-02-09 06:32:07 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:32:07 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:32:07 --> Utf8 Class Initialized
INFO - 2016-02-09 06:32:07 --> URI Class Initialized
INFO - 2016-02-09 06:32:07 --> Router Class Initialized
INFO - 2016-02-09 06:32:07 --> Output Class Initialized
INFO - 2016-02-09 06:32:07 --> Security Class Initialized
DEBUG - 2016-02-09 06:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:32:07 --> Input Class Initialized
INFO - 2016-02-09 06:32:07 --> Language Class Initialized
INFO - 2016-02-09 06:32:07 --> Loader Class Initialized
INFO - 2016-02-09 06:32:07 --> Helper loaded: url_helper
INFO - 2016-02-09 06:32:07 --> Helper loaded: file_helper
INFO - 2016-02-09 06:32:07 --> Helper loaded: date_helper
INFO - 2016-02-09 06:32:07 --> Helper loaded: form_helper
INFO - 2016-02-09 06:32:07 --> Database Driver Class Initialized
INFO - 2016-02-09 06:32:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:32:08 --> Controller Class Initialized
INFO - 2016-02-09 06:32:08 --> Model Class Initialized
INFO - 2016-02-09 06:32:08 --> Model Class Initialized
INFO - 2016-02-09 06:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:32:08 --> Pagination Class Initialized
INFO - 2016-02-09 06:32:08 --> Form Validation Class Initialized
INFO - 2016-02-09 06:32:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:32:08 --> Model Class Initialized
INFO - 2016-02-09 06:32:08 --> Final output sent to browser
DEBUG - 2016-02-09 06:32:08 --> Total execution time: 1.3564
INFO - 2016-02-09 06:38:49 --> Config Class Initialized
INFO - 2016-02-09 06:38:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:38:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:38:49 --> Utf8 Class Initialized
INFO - 2016-02-09 06:38:49 --> URI Class Initialized
DEBUG - 2016-02-09 06:38:49 --> No URI present. Default controller set.
INFO - 2016-02-09 06:38:49 --> Router Class Initialized
INFO - 2016-02-09 06:38:49 --> Output Class Initialized
INFO - 2016-02-09 06:38:49 --> Security Class Initialized
DEBUG - 2016-02-09 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:38:49 --> Input Class Initialized
INFO - 2016-02-09 06:38:49 --> Language Class Initialized
INFO - 2016-02-09 06:38:49 --> Loader Class Initialized
INFO - 2016-02-09 06:38:49 --> Helper loaded: url_helper
INFO - 2016-02-09 06:38:49 --> Helper loaded: file_helper
INFO - 2016-02-09 06:38:49 --> Helper loaded: date_helper
INFO - 2016-02-09 06:38:49 --> Helper loaded: form_helper
INFO - 2016-02-09 06:38:49 --> Database Driver Class Initialized
INFO - 2016-02-09 06:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:38:51 --> Controller Class Initialized
INFO - 2016-02-09 06:38:51 --> Model Class Initialized
INFO - 2016-02-09 06:38:51 --> Model Class Initialized
INFO - 2016-02-09 06:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:38:51 --> Pagination Class Initialized
INFO - 2016-02-09 06:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:38:51 --> Final output sent to browser
DEBUG - 2016-02-09 06:38:51 --> Total execution time: 1.1360
INFO - 2016-02-09 06:38:53 --> Config Class Initialized
INFO - 2016-02-09 06:38:53 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:38:53 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:38:53 --> Utf8 Class Initialized
INFO - 2016-02-09 06:38:53 --> URI Class Initialized
INFO - 2016-02-09 06:38:53 --> Router Class Initialized
INFO - 2016-02-09 06:38:53 --> Output Class Initialized
INFO - 2016-02-09 06:38:53 --> Security Class Initialized
DEBUG - 2016-02-09 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:38:53 --> Input Class Initialized
INFO - 2016-02-09 06:38:53 --> Language Class Initialized
INFO - 2016-02-09 06:38:53 --> Loader Class Initialized
INFO - 2016-02-09 06:38:53 --> Helper loaded: url_helper
INFO - 2016-02-09 06:38:53 --> Helper loaded: file_helper
INFO - 2016-02-09 06:38:53 --> Helper loaded: date_helper
INFO - 2016-02-09 06:38:53 --> Helper loaded: form_helper
INFO - 2016-02-09 06:38:53 --> Database Driver Class Initialized
INFO - 2016-02-09 06:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:38:54 --> Controller Class Initialized
INFO - 2016-02-09 06:38:54 --> Model Class Initialized
INFO - 2016-02-09 06:38:54 --> Model Class Initialized
INFO - 2016-02-09 06:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:38:54 --> Pagination Class Initialized
INFO - 2016-02-09 06:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:38:54 --> Helper loaded: text_helper
INFO - 2016-02-09 06:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:38:55 --> Final output sent to browser
DEBUG - 2016-02-09 06:38:55 --> Total execution time: 1.2693
INFO - 2016-02-09 06:39:13 --> Config Class Initialized
INFO - 2016-02-09 06:39:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:39:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:39:13 --> Utf8 Class Initialized
INFO - 2016-02-09 06:39:13 --> URI Class Initialized
DEBUG - 2016-02-09 06:39:13 --> No URI present. Default controller set.
INFO - 2016-02-09 06:39:13 --> Router Class Initialized
INFO - 2016-02-09 06:39:13 --> Output Class Initialized
INFO - 2016-02-09 06:39:13 --> Security Class Initialized
DEBUG - 2016-02-09 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:39:13 --> Input Class Initialized
INFO - 2016-02-09 06:39:13 --> Language Class Initialized
INFO - 2016-02-09 06:39:13 --> Loader Class Initialized
INFO - 2016-02-09 06:39:13 --> Helper loaded: url_helper
INFO - 2016-02-09 06:39:13 --> Helper loaded: file_helper
INFO - 2016-02-09 06:39:13 --> Helper loaded: date_helper
INFO - 2016-02-09 06:39:13 --> Helper loaded: form_helper
INFO - 2016-02-09 06:39:13 --> Database Driver Class Initialized
INFO - 2016-02-09 06:39:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:39:14 --> Controller Class Initialized
INFO - 2016-02-09 06:39:14 --> Model Class Initialized
INFO - 2016-02-09 06:39:14 --> Model Class Initialized
INFO - 2016-02-09 06:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:39:14 --> Pagination Class Initialized
INFO - 2016-02-09 06:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:39:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:39:14 --> Final output sent to browser
DEBUG - 2016-02-09 06:39:14 --> Total execution time: 1.1412
INFO - 2016-02-09 06:39:22 --> Config Class Initialized
INFO - 2016-02-09 06:39:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:39:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:39:22 --> Utf8 Class Initialized
INFO - 2016-02-09 06:39:22 --> URI Class Initialized
INFO - 2016-02-09 06:39:22 --> Router Class Initialized
INFO - 2016-02-09 06:39:22 --> Output Class Initialized
INFO - 2016-02-09 06:39:22 --> Security Class Initialized
DEBUG - 2016-02-09 06:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:39:22 --> Input Class Initialized
INFO - 2016-02-09 06:39:22 --> Language Class Initialized
INFO - 2016-02-09 06:39:22 --> Loader Class Initialized
INFO - 2016-02-09 06:39:22 --> Helper loaded: url_helper
INFO - 2016-02-09 06:39:22 --> Helper loaded: file_helper
INFO - 2016-02-09 06:39:22 --> Helper loaded: date_helper
INFO - 2016-02-09 06:39:22 --> Helper loaded: form_helper
INFO - 2016-02-09 06:39:22 --> Database Driver Class Initialized
INFO - 2016-02-09 06:39:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:39:23 --> Controller Class Initialized
INFO - 2016-02-09 06:39:23 --> Model Class Initialized
INFO - 2016-02-09 06:39:23 --> Model Class Initialized
INFO - 2016-02-09 06:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:39:23 --> Pagination Class Initialized
INFO - 2016-02-09 06:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:39:23 --> Form Validation Class Initialized
INFO - 2016-02-09 06:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-09 06:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:39:23 --> Final output sent to browser
DEBUG - 2016-02-09 06:39:23 --> Total execution time: 1.1953
INFO - 2016-02-09 06:43:41 --> Config Class Initialized
INFO - 2016-02-09 06:43:41 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:43:41 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:43:41 --> Utf8 Class Initialized
INFO - 2016-02-09 06:43:41 --> URI Class Initialized
INFO - 2016-02-09 06:43:41 --> Router Class Initialized
INFO - 2016-02-09 06:43:41 --> Output Class Initialized
INFO - 2016-02-09 06:43:41 --> Security Class Initialized
DEBUG - 2016-02-09 06:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:43:41 --> Input Class Initialized
INFO - 2016-02-09 06:43:41 --> Language Class Initialized
INFO - 2016-02-09 06:43:41 --> Loader Class Initialized
INFO - 2016-02-09 06:43:41 --> Helper loaded: url_helper
INFO - 2016-02-09 06:43:41 --> Helper loaded: file_helper
INFO - 2016-02-09 06:43:41 --> Helper loaded: date_helper
INFO - 2016-02-09 06:43:41 --> Helper loaded: form_helper
INFO - 2016-02-09 06:43:41 --> Database Driver Class Initialized
INFO - 2016-02-09 06:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:43:42 --> Controller Class Initialized
INFO - 2016-02-09 06:43:42 --> Model Class Initialized
INFO - 2016-02-09 06:43:42 --> Model Class Initialized
INFO - 2016-02-09 06:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:43:42 --> Pagination Class Initialized
INFO - 2016-02-09 06:43:42 --> Upload Class Initialized
INFO - 2016-02-09 06:43:42 --> Final output sent to browser
DEBUG - 2016-02-09 06:43:42 --> Total execution time: 1.1583
INFO - 2016-02-09 06:44:02 --> Config Class Initialized
INFO - 2016-02-09 06:44:02 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:44:02 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:44:02 --> Utf8 Class Initialized
INFO - 2016-02-09 06:44:02 --> URI Class Initialized
DEBUG - 2016-02-09 06:44:02 --> No URI present. Default controller set.
INFO - 2016-02-09 06:44:02 --> Router Class Initialized
INFO - 2016-02-09 06:44:02 --> Output Class Initialized
INFO - 2016-02-09 06:44:02 --> Security Class Initialized
DEBUG - 2016-02-09 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:44:02 --> Input Class Initialized
INFO - 2016-02-09 06:44:02 --> Language Class Initialized
INFO - 2016-02-09 06:44:02 --> Loader Class Initialized
INFO - 2016-02-09 06:44:02 --> Helper loaded: url_helper
INFO - 2016-02-09 06:44:02 --> Helper loaded: file_helper
INFO - 2016-02-09 06:44:02 --> Helper loaded: date_helper
INFO - 2016-02-09 06:44:02 --> Helper loaded: form_helper
INFO - 2016-02-09 06:44:02 --> Database Driver Class Initialized
INFO - 2016-02-09 06:44:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:44:03 --> Controller Class Initialized
INFO - 2016-02-09 06:44:03 --> Model Class Initialized
INFO - 2016-02-09 06:44:03 --> Model Class Initialized
INFO - 2016-02-09 06:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:44:03 --> Pagination Class Initialized
INFO - 2016-02-09 06:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:44:03 --> Final output sent to browser
DEBUG - 2016-02-09 06:44:03 --> Total execution time: 1.1329
INFO - 2016-02-09 06:44:05 --> Config Class Initialized
INFO - 2016-02-09 06:44:05 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:44:05 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:44:05 --> Utf8 Class Initialized
INFO - 2016-02-09 06:44:05 --> URI Class Initialized
INFO - 2016-02-09 06:44:05 --> Router Class Initialized
INFO - 2016-02-09 06:44:05 --> Output Class Initialized
INFO - 2016-02-09 06:44:05 --> Security Class Initialized
DEBUG - 2016-02-09 06:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:44:05 --> Input Class Initialized
INFO - 2016-02-09 06:44:05 --> Language Class Initialized
INFO - 2016-02-09 06:44:05 --> Loader Class Initialized
INFO - 2016-02-09 06:44:05 --> Helper loaded: url_helper
INFO - 2016-02-09 06:44:05 --> Helper loaded: file_helper
INFO - 2016-02-09 06:44:05 --> Helper loaded: date_helper
INFO - 2016-02-09 06:44:05 --> Helper loaded: form_helper
INFO - 2016-02-09 06:44:05 --> Database Driver Class Initialized
INFO - 2016-02-09 06:44:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:44:06 --> Controller Class Initialized
INFO - 2016-02-09 06:44:06 --> Model Class Initialized
INFO - 2016-02-09 06:44:06 --> Model Class Initialized
INFO - 2016-02-09 06:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:44:06 --> Pagination Class Initialized
INFO - 2016-02-09 06:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:44:06 --> Helper loaded: text_helper
INFO - 2016-02-09 06:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:44:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:44:06 --> Final output sent to browser
DEBUG - 2016-02-09 06:44:06 --> Total execution time: 1.1640
INFO - 2016-02-09 06:44:08 --> Config Class Initialized
INFO - 2016-02-09 06:44:08 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:44:08 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:44:08 --> Utf8 Class Initialized
INFO - 2016-02-09 06:44:08 --> URI Class Initialized
DEBUG - 2016-02-09 06:44:08 --> No URI present. Default controller set.
INFO - 2016-02-09 06:44:08 --> Router Class Initialized
INFO - 2016-02-09 06:44:08 --> Output Class Initialized
INFO - 2016-02-09 06:44:08 --> Security Class Initialized
DEBUG - 2016-02-09 06:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:44:08 --> Input Class Initialized
INFO - 2016-02-09 06:44:08 --> Language Class Initialized
INFO - 2016-02-09 06:44:08 --> Loader Class Initialized
INFO - 2016-02-09 06:44:08 --> Helper loaded: url_helper
INFO - 2016-02-09 06:44:08 --> Helper loaded: file_helper
INFO - 2016-02-09 06:44:08 --> Helper loaded: date_helper
INFO - 2016-02-09 06:44:08 --> Helper loaded: form_helper
INFO - 2016-02-09 06:44:08 --> Database Driver Class Initialized
INFO - 2016-02-09 06:44:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:44:09 --> Controller Class Initialized
INFO - 2016-02-09 06:44:09 --> Model Class Initialized
INFO - 2016-02-09 06:44:09 --> Model Class Initialized
INFO - 2016-02-09 06:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:44:09 --> Pagination Class Initialized
INFO - 2016-02-09 06:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:44:09 --> Final output sent to browser
DEBUG - 2016-02-09 06:44:09 --> Total execution time: 1.1321
INFO - 2016-02-09 06:44:13 --> Config Class Initialized
INFO - 2016-02-09 06:44:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:44:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:44:13 --> Utf8 Class Initialized
INFO - 2016-02-09 06:44:13 --> URI Class Initialized
INFO - 2016-02-09 06:44:13 --> Router Class Initialized
INFO - 2016-02-09 06:44:13 --> Output Class Initialized
INFO - 2016-02-09 06:44:13 --> Security Class Initialized
DEBUG - 2016-02-09 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:44:13 --> Input Class Initialized
INFO - 2016-02-09 06:44:13 --> Language Class Initialized
INFO - 2016-02-09 06:44:13 --> Loader Class Initialized
INFO - 2016-02-09 06:44:13 --> Helper loaded: url_helper
INFO - 2016-02-09 06:44:13 --> Helper loaded: file_helper
INFO - 2016-02-09 06:44:13 --> Helper loaded: date_helper
INFO - 2016-02-09 06:44:13 --> Helper loaded: form_helper
INFO - 2016-02-09 06:44:13 --> Database Driver Class Initialized
INFO - 2016-02-09 06:44:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:44:14 --> Controller Class Initialized
INFO - 2016-02-09 06:44:14 --> Model Class Initialized
INFO - 2016-02-09 06:44:14 --> Model Class Initialized
INFO - 2016-02-09 06:44:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:44:14 --> Pagination Class Initialized
INFO - 2016-02-09 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:44:14 --> Helper loaded: text_helper
INFO - 2016-02-09 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:44:14 --> Final output sent to browser
DEBUG - 2016-02-09 06:44:14 --> Total execution time: 1.1371
INFO - 2016-02-09 06:45:19 --> Config Class Initialized
INFO - 2016-02-09 06:45:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:45:19 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:45:19 --> Utf8 Class Initialized
INFO - 2016-02-09 06:45:19 --> URI Class Initialized
INFO - 2016-02-09 06:45:19 --> Router Class Initialized
INFO - 2016-02-09 06:45:19 --> Output Class Initialized
INFO - 2016-02-09 06:45:19 --> Security Class Initialized
DEBUG - 2016-02-09 06:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:45:19 --> Input Class Initialized
INFO - 2016-02-09 06:45:19 --> Language Class Initialized
INFO - 2016-02-09 06:45:19 --> Loader Class Initialized
INFO - 2016-02-09 06:45:19 --> Helper loaded: url_helper
INFO - 2016-02-09 06:45:19 --> Helper loaded: file_helper
INFO - 2016-02-09 06:45:19 --> Helper loaded: date_helper
INFO - 2016-02-09 06:45:19 --> Helper loaded: form_helper
INFO - 2016-02-09 06:45:19 --> Database Driver Class Initialized
INFO - 2016-02-09 06:45:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:45:20 --> Controller Class Initialized
INFO - 2016-02-09 06:45:20 --> Model Class Initialized
INFO - 2016-02-09 06:45:20 --> Model Class Initialized
INFO - 2016-02-09 06:45:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:45:20 --> Pagination Class Initialized
INFO - 2016-02-09 06:45:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:45:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:45:20 --> Form Validation Class Initialized
INFO - 2016-02-09 06:45:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:45:21 --> Config Class Initialized
INFO - 2016-02-09 06:45:21 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:45:21 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:45:21 --> Utf8 Class Initialized
INFO - 2016-02-09 06:45:21 --> URI Class Initialized
INFO - 2016-02-09 06:45:21 --> Router Class Initialized
INFO - 2016-02-09 06:45:21 --> Output Class Initialized
INFO - 2016-02-09 06:45:21 --> Security Class Initialized
DEBUG - 2016-02-09 06:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:45:21 --> Input Class Initialized
INFO - 2016-02-09 06:45:21 --> Language Class Initialized
INFO - 2016-02-09 06:45:21 --> Loader Class Initialized
INFO - 2016-02-09 06:45:21 --> Helper loaded: url_helper
INFO - 2016-02-09 06:45:21 --> Helper loaded: file_helper
INFO - 2016-02-09 06:45:21 --> Helper loaded: date_helper
INFO - 2016-02-09 06:45:21 --> Helper loaded: form_helper
INFO - 2016-02-09 06:45:21 --> Database Driver Class Initialized
INFO - 2016-02-09 06:45:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:45:22 --> Controller Class Initialized
INFO - 2016-02-09 06:45:22 --> Model Class Initialized
INFO - 2016-02-09 06:45:22 --> Model Class Initialized
INFO - 2016-02-09 06:45:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:45:22 --> Pagination Class Initialized
INFO - 2016-02-09 06:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:45:22 --> Helper loaded: text_helper
INFO - 2016-02-09 06:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:45:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:45:22 --> Final output sent to browser
DEBUG - 2016-02-09 06:45:22 --> Total execution time: 1.1687
INFO - 2016-02-09 06:50:51 --> Config Class Initialized
INFO - 2016-02-09 06:50:51 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:50:51 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:50:51 --> Utf8 Class Initialized
INFO - 2016-02-09 06:50:51 --> URI Class Initialized
DEBUG - 2016-02-09 06:50:51 --> No URI present. Default controller set.
INFO - 2016-02-09 06:50:51 --> Router Class Initialized
INFO - 2016-02-09 06:50:51 --> Output Class Initialized
INFO - 2016-02-09 06:50:51 --> Security Class Initialized
DEBUG - 2016-02-09 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:50:51 --> Input Class Initialized
INFO - 2016-02-09 06:50:51 --> Language Class Initialized
INFO - 2016-02-09 06:50:51 --> Loader Class Initialized
INFO - 2016-02-09 06:50:51 --> Helper loaded: url_helper
INFO - 2016-02-09 06:50:51 --> Helper loaded: file_helper
INFO - 2016-02-09 06:50:51 --> Helper loaded: date_helper
INFO - 2016-02-09 06:50:51 --> Helper loaded: form_helper
INFO - 2016-02-09 06:50:51 --> Database Driver Class Initialized
INFO - 2016-02-09 06:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:50:52 --> Controller Class Initialized
INFO - 2016-02-09 06:50:52 --> Model Class Initialized
INFO - 2016-02-09 06:50:52 --> Model Class Initialized
INFO - 2016-02-09 06:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:50:52 --> Pagination Class Initialized
INFO - 2016-02-09 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 06:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:50:52 --> Final output sent to browser
DEBUG - 2016-02-09 06:50:52 --> Total execution time: 1.1125
INFO - 2016-02-09 06:50:54 --> Config Class Initialized
INFO - 2016-02-09 06:50:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:50:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:50:54 --> Utf8 Class Initialized
INFO - 2016-02-09 06:50:54 --> URI Class Initialized
INFO - 2016-02-09 06:50:54 --> Router Class Initialized
INFO - 2016-02-09 06:50:54 --> Output Class Initialized
INFO - 2016-02-09 06:50:54 --> Security Class Initialized
DEBUG - 2016-02-09 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:50:54 --> Input Class Initialized
INFO - 2016-02-09 06:50:54 --> Language Class Initialized
INFO - 2016-02-09 06:50:54 --> Loader Class Initialized
INFO - 2016-02-09 06:50:54 --> Helper loaded: url_helper
INFO - 2016-02-09 06:50:54 --> Helper loaded: file_helper
INFO - 2016-02-09 06:50:54 --> Helper loaded: date_helper
INFO - 2016-02-09 06:50:54 --> Helper loaded: form_helper
INFO - 2016-02-09 06:50:54 --> Database Driver Class Initialized
INFO - 2016-02-09 06:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:50:55 --> Controller Class Initialized
INFO - 2016-02-09 06:50:55 --> Model Class Initialized
INFO - 2016-02-09 06:50:55 --> Model Class Initialized
INFO - 2016-02-09 06:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:50:55 --> Pagination Class Initialized
INFO - 2016-02-09 06:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:50:55 --> Helper loaded: text_helper
INFO - 2016-02-09 06:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:50:55 --> Final output sent to browser
DEBUG - 2016-02-09 06:50:55 --> Total execution time: 1.1741
INFO - 2016-02-09 06:51:10 --> Config Class Initialized
INFO - 2016-02-09 06:51:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:51:10 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:51:10 --> Utf8 Class Initialized
INFO - 2016-02-09 06:51:10 --> URI Class Initialized
INFO - 2016-02-09 06:51:10 --> Router Class Initialized
INFO - 2016-02-09 06:51:10 --> Output Class Initialized
INFO - 2016-02-09 06:51:10 --> Security Class Initialized
DEBUG - 2016-02-09 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:51:10 --> Input Class Initialized
INFO - 2016-02-09 06:51:10 --> Language Class Initialized
INFO - 2016-02-09 06:51:10 --> Loader Class Initialized
INFO - 2016-02-09 06:51:10 --> Helper loaded: url_helper
INFO - 2016-02-09 06:51:10 --> Helper loaded: file_helper
INFO - 2016-02-09 06:51:10 --> Helper loaded: date_helper
INFO - 2016-02-09 06:51:10 --> Helper loaded: form_helper
INFO - 2016-02-09 06:51:10 --> Database Driver Class Initialized
INFO - 2016-02-09 06:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:51:11 --> Controller Class Initialized
INFO - 2016-02-09 06:51:11 --> Model Class Initialized
INFO - 2016-02-09 06:51:11 --> Model Class Initialized
INFO - 2016-02-09 06:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:51:11 --> Pagination Class Initialized
INFO - 2016-02-09 06:51:11 --> Form Validation Class Initialized
INFO - 2016-02-09 06:51:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:51:11 --> Model Class Initialized
ERROR - 2016-02-09 06:51:11 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 06:51:12 --> Query error: Column 'created' cannot be null - Invalid query: INSERT INTO `comment` (`board_id`, `user_id`, `user_name`, `article`, `created`) VALUES ('48', '12', 'test09095', 'see created 1', NULL)
INFO - 2016-02-09 06:51:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 06:51:22 --> Config Class Initialized
INFO - 2016-02-09 06:51:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:51:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:51:22 --> Utf8 Class Initialized
INFO - 2016-02-09 06:51:22 --> URI Class Initialized
INFO - 2016-02-09 06:51:22 --> Router Class Initialized
INFO - 2016-02-09 06:51:22 --> Output Class Initialized
INFO - 2016-02-09 06:51:22 --> Security Class Initialized
DEBUG - 2016-02-09 06:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:51:22 --> Input Class Initialized
INFO - 2016-02-09 06:51:22 --> Language Class Initialized
INFO - 2016-02-09 06:51:22 --> Loader Class Initialized
INFO - 2016-02-09 06:51:22 --> Helper loaded: url_helper
INFO - 2016-02-09 06:51:22 --> Helper loaded: file_helper
INFO - 2016-02-09 06:51:22 --> Helper loaded: date_helper
INFO - 2016-02-09 06:51:22 --> Helper loaded: form_helper
INFO - 2016-02-09 06:51:22 --> Database Driver Class Initialized
INFO - 2016-02-09 06:51:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:51:23 --> Controller Class Initialized
INFO - 2016-02-09 06:51:23 --> Model Class Initialized
INFO - 2016-02-09 06:51:23 --> Model Class Initialized
INFO - 2016-02-09 06:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:51:23 --> Pagination Class Initialized
INFO - 2016-02-09 06:51:23 --> Form Validation Class Initialized
INFO - 2016-02-09 06:51:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:51:23 --> Model Class Initialized
ERROR - 2016-02-09 06:51:23 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 06:51:23 --> Query error: Column 'created' cannot be null - Invalid query: INSERT INTO `comment` (`board_id`, `user_id`, `user_name`, `article`, `created`) VALUES ('48', '12', 'test09095', 'see created 2', NULL)
INFO - 2016-02-09 06:51:23 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 06:53:49 --> Config Class Initialized
INFO - 2016-02-09 06:53:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:53:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:53:49 --> Utf8 Class Initialized
INFO - 2016-02-09 06:53:49 --> URI Class Initialized
INFO - 2016-02-09 06:53:49 --> Router Class Initialized
INFO - 2016-02-09 06:53:49 --> Output Class Initialized
INFO - 2016-02-09 06:53:49 --> Security Class Initialized
DEBUG - 2016-02-09 06:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:53:49 --> Input Class Initialized
INFO - 2016-02-09 06:53:49 --> Language Class Initialized
INFO - 2016-02-09 06:53:49 --> Loader Class Initialized
INFO - 2016-02-09 06:53:49 --> Helper loaded: url_helper
INFO - 2016-02-09 06:53:49 --> Helper loaded: file_helper
INFO - 2016-02-09 06:53:49 --> Helper loaded: date_helper
INFO - 2016-02-09 06:53:49 --> Helper loaded: form_helper
INFO - 2016-02-09 06:53:49 --> Database Driver Class Initialized
INFO - 2016-02-09 06:53:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:53:50 --> Controller Class Initialized
INFO - 2016-02-09 06:53:50 --> Model Class Initialized
INFO - 2016-02-09 06:53:50 --> Model Class Initialized
INFO - 2016-02-09 06:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:53:50 --> Pagination Class Initialized
INFO - 2016-02-09 06:53:50 --> Form Validation Class Initialized
INFO - 2016-02-09 06:53:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:53:50 --> Model Class Initialized
ERROR - 2016-02-09 06:53:50 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 06:53:50 --> Query error: Column 'created' cannot be null - Invalid query: INSERT INTO `comment` (`board_id`, `user_id`, `user_name`, `article`, `created`) VALUES ('48', '12', 'test09095', 'see created 3', NULL)
INFO - 2016-02-09 06:53:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 06:54:31 --> Config Class Initialized
INFO - 2016-02-09 06:54:31 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:54:31 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:54:31 --> Utf8 Class Initialized
INFO - 2016-02-09 06:54:31 --> URI Class Initialized
INFO - 2016-02-09 06:54:31 --> Router Class Initialized
INFO - 2016-02-09 06:54:31 --> Output Class Initialized
INFO - 2016-02-09 06:54:31 --> Security Class Initialized
DEBUG - 2016-02-09 06:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:54:31 --> Input Class Initialized
INFO - 2016-02-09 06:54:31 --> Language Class Initialized
INFO - 2016-02-09 06:54:31 --> Loader Class Initialized
INFO - 2016-02-09 06:54:31 --> Helper loaded: url_helper
INFO - 2016-02-09 06:54:31 --> Helper loaded: file_helper
INFO - 2016-02-09 06:54:31 --> Helper loaded: date_helper
INFO - 2016-02-09 06:54:31 --> Helper loaded: form_helper
INFO - 2016-02-09 06:54:31 --> Database Driver Class Initialized
INFO - 2016-02-09 06:54:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:54:32 --> Controller Class Initialized
INFO - 2016-02-09 06:54:32 --> Model Class Initialized
INFO - 2016-02-09 06:54:32 --> Model Class Initialized
INFO - 2016-02-09 06:54:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:54:32 --> Pagination Class Initialized
INFO - 2016-02-09 06:54:32 --> Form Validation Class Initialized
INFO - 2016-02-09 06:54:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 06:54:32 --> Model Class Initialized
ERROR - 2016-02-09 06:54:32 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 06:54:32 --> Query error: Column 'created' specified twice - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`, `created`) VALUES (NOW(), '48', '12', 'test09095', 'see created 4', NULL)
INFO - 2016-02-09 06:54:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 06:58:38 --> Config Class Initialized
INFO - 2016-02-09 06:58:38 --> Hooks Class Initialized
DEBUG - 2016-02-09 06:58:38 --> UTF-8 Support Enabled
INFO - 2016-02-09 06:58:38 --> Utf8 Class Initialized
INFO - 2016-02-09 06:58:38 --> URI Class Initialized
INFO - 2016-02-09 06:58:38 --> Router Class Initialized
INFO - 2016-02-09 06:58:38 --> Output Class Initialized
INFO - 2016-02-09 06:58:38 --> Security Class Initialized
DEBUG - 2016-02-09 06:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 06:58:38 --> Input Class Initialized
INFO - 2016-02-09 06:58:38 --> Language Class Initialized
INFO - 2016-02-09 06:58:38 --> Loader Class Initialized
INFO - 2016-02-09 06:58:38 --> Helper loaded: url_helper
INFO - 2016-02-09 06:58:38 --> Helper loaded: file_helper
INFO - 2016-02-09 06:58:38 --> Helper loaded: date_helper
INFO - 2016-02-09 06:58:38 --> Helper loaded: form_helper
INFO - 2016-02-09 06:58:38 --> Database Driver Class Initialized
INFO - 2016-02-09 06:58:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 06:58:39 --> Controller Class Initialized
INFO - 2016-02-09 06:58:39 --> Model Class Initialized
INFO - 2016-02-09 06:58:39 --> Model Class Initialized
INFO - 2016-02-09 06:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 06:58:39 --> Pagination Class Initialized
INFO - 2016-02-09 06:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 06:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 06:58:39 --> Helper loaded: text_helper
INFO - 2016-02-09 06:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 06:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 06:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 06:58:39 --> Final output sent to browser
DEBUG - 2016-02-09 06:58:39 --> Total execution time: 1.2109
INFO - 2016-02-09 07:00:03 --> Config Class Initialized
INFO - 2016-02-09 07:00:03 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:00:03 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:00:03 --> Utf8 Class Initialized
INFO - 2016-02-09 07:00:03 --> URI Class Initialized
INFO - 2016-02-09 07:00:03 --> Router Class Initialized
INFO - 2016-02-09 07:00:03 --> Output Class Initialized
INFO - 2016-02-09 07:00:03 --> Security Class Initialized
DEBUG - 2016-02-09 07:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:00:03 --> Input Class Initialized
INFO - 2016-02-09 07:00:03 --> Language Class Initialized
INFO - 2016-02-09 07:00:03 --> Loader Class Initialized
INFO - 2016-02-09 07:00:03 --> Helper loaded: url_helper
INFO - 2016-02-09 07:00:03 --> Helper loaded: file_helper
INFO - 2016-02-09 07:00:03 --> Helper loaded: date_helper
INFO - 2016-02-09 07:00:03 --> Helper loaded: form_helper
INFO - 2016-02-09 07:00:03 --> Database Driver Class Initialized
INFO - 2016-02-09 07:00:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:00:04 --> Controller Class Initialized
INFO - 2016-02-09 07:00:04 --> Model Class Initialized
INFO - 2016-02-09 07:00:04 --> Model Class Initialized
INFO - 2016-02-09 07:00:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:00:04 --> Pagination Class Initialized
INFO - 2016-02-09 07:00:04 --> Form Validation Class Initialized
INFO - 2016-02-09 07:00:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:00:04 --> Model Class Initialized
ERROR - 2016-02-09 07:00:04 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 07:00:04 --> Query error: Column 'created' specified twice - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`, `created`) VALUES (NOW(), '48', '12', 'test09095', 'see comment date 1', NULL)
INFO - 2016-02-09 07:00:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 07:01:16 --> Config Class Initialized
INFO - 2016-02-09 07:01:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:01:16 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:01:16 --> Utf8 Class Initialized
INFO - 2016-02-09 07:01:16 --> URI Class Initialized
INFO - 2016-02-09 07:01:16 --> Router Class Initialized
INFO - 2016-02-09 07:01:16 --> Output Class Initialized
INFO - 2016-02-09 07:01:16 --> Security Class Initialized
DEBUG - 2016-02-09 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:01:16 --> Input Class Initialized
INFO - 2016-02-09 07:01:16 --> Language Class Initialized
ERROR - 2016-02-09 07:01:16 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 199
INFO - 2016-02-09 07:01:29 --> Config Class Initialized
INFO - 2016-02-09 07:01:29 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:01:29 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:01:29 --> Utf8 Class Initialized
INFO - 2016-02-09 07:01:29 --> URI Class Initialized
INFO - 2016-02-09 07:01:29 --> Router Class Initialized
INFO - 2016-02-09 07:01:29 --> Output Class Initialized
INFO - 2016-02-09 07:01:29 --> Security Class Initialized
DEBUG - 2016-02-09 07:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:01:29 --> Input Class Initialized
INFO - 2016-02-09 07:01:29 --> Language Class Initialized
INFO - 2016-02-09 07:01:29 --> Loader Class Initialized
INFO - 2016-02-09 07:01:29 --> Helper loaded: url_helper
INFO - 2016-02-09 07:01:29 --> Helper loaded: file_helper
INFO - 2016-02-09 07:01:29 --> Helper loaded: date_helper
INFO - 2016-02-09 07:01:29 --> Helper loaded: form_helper
INFO - 2016-02-09 07:01:29 --> Database Driver Class Initialized
INFO - 2016-02-09 07:01:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:01:30 --> Controller Class Initialized
INFO - 2016-02-09 07:01:30 --> Model Class Initialized
INFO - 2016-02-09 07:01:30 --> Model Class Initialized
INFO - 2016-02-09 07:01:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:01:30 --> Pagination Class Initialized
INFO - 2016-02-09 07:01:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:01:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:01:30 --> Helper loaded: text_helper
INFO - 2016-02-09 07:01:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:01:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:01:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:01:30 --> Final output sent to browser
DEBUG - 2016-02-09 07:01:30 --> Total execution time: 1.1823
INFO - 2016-02-09 07:01:39 --> Config Class Initialized
INFO - 2016-02-09 07:01:39 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:01:39 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:01:39 --> Utf8 Class Initialized
INFO - 2016-02-09 07:01:39 --> URI Class Initialized
INFO - 2016-02-09 07:01:39 --> Router Class Initialized
INFO - 2016-02-09 07:01:39 --> Output Class Initialized
INFO - 2016-02-09 07:01:39 --> Security Class Initialized
DEBUG - 2016-02-09 07:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:01:39 --> Input Class Initialized
INFO - 2016-02-09 07:01:39 --> Language Class Initialized
INFO - 2016-02-09 07:01:39 --> Loader Class Initialized
INFO - 2016-02-09 07:01:39 --> Helper loaded: url_helper
INFO - 2016-02-09 07:01:39 --> Helper loaded: file_helper
INFO - 2016-02-09 07:01:39 --> Helper loaded: date_helper
INFO - 2016-02-09 07:01:39 --> Helper loaded: form_helper
INFO - 2016-02-09 07:01:39 --> Database Driver Class Initialized
INFO - 2016-02-09 07:01:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:01:40 --> Controller Class Initialized
INFO - 2016-02-09 07:01:40 --> Model Class Initialized
INFO - 2016-02-09 07:01:40 --> Model Class Initialized
INFO - 2016-02-09 07:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:01:40 --> Pagination Class Initialized
INFO - 2016-02-09 07:01:40 --> Form Validation Class Initialized
INFO - 2016-02-09 07:01:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:01:40 --> Model Class Initialized
ERROR - 2016-02-09 07:01:40 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 93
ERROR - 2016-02-09 07:01:40 --> Query error: Column 'created' specified twice - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`, `created`) VALUES (NOW(), '48', '12', 'test09095', 'see created 1', NULL)
INFO - 2016-02-09 07:01:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 07:02:46 --> Config Class Initialized
INFO - 2016-02-09 07:02:46 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:02:46 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:02:46 --> Utf8 Class Initialized
INFO - 2016-02-09 07:02:46 --> URI Class Initialized
INFO - 2016-02-09 07:02:46 --> Router Class Initialized
INFO - 2016-02-09 07:02:46 --> Output Class Initialized
INFO - 2016-02-09 07:02:46 --> Security Class Initialized
DEBUG - 2016-02-09 07:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:02:46 --> Input Class Initialized
INFO - 2016-02-09 07:02:46 --> Language Class Initialized
INFO - 2016-02-09 07:02:46 --> Loader Class Initialized
INFO - 2016-02-09 07:02:46 --> Helper loaded: url_helper
INFO - 2016-02-09 07:02:46 --> Helper loaded: file_helper
INFO - 2016-02-09 07:02:46 --> Helper loaded: date_helper
INFO - 2016-02-09 07:02:46 --> Helper loaded: form_helper
INFO - 2016-02-09 07:02:46 --> Database Driver Class Initialized
INFO - 2016-02-09 07:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:02:47 --> Controller Class Initialized
INFO - 2016-02-09 07:02:47 --> Model Class Initialized
INFO - 2016-02-09 07:02:47 --> Model Class Initialized
INFO - 2016-02-09 07:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:02:47 --> Pagination Class Initialized
INFO - 2016-02-09 07:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:02:47 --> Helper loaded: text_helper
INFO - 2016-02-09 07:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:02:47 --> Final output sent to browser
DEBUG - 2016-02-09 07:02:47 --> Total execution time: 1.2224
INFO - 2016-02-09 07:02:52 --> Config Class Initialized
INFO - 2016-02-09 07:02:52 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:02:52 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:02:52 --> Utf8 Class Initialized
INFO - 2016-02-09 07:02:52 --> URI Class Initialized
INFO - 2016-02-09 07:02:52 --> Router Class Initialized
INFO - 2016-02-09 07:02:52 --> Output Class Initialized
INFO - 2016-02-09 07:02:52 --> Security Class Initialized
DEBUG - 2016-02-09 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:02:52 --> Input Class Initialized
INFO - 2016-02-09 07:02:52 --> Language Class Initialized
INFO - 2016-02-09 07:02:52 --> Loader Class Initialized
INFO - 2016-02-09 07:02:52 --> Helper loaded: url_helper
INFO - 2016-02-09 07:02:52 --> Helper loaded: file_helper
INFO - 2016-02-09 07:02:52 --> Helper loaded: date_helper
INFO - 2016-02-09 07:02:52 --> Helper loaded: form_helper
INFO - 2016-02-09 07:02:52 --> Database Driver Class Initialized
INFO - 2016-02-09 07:02:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:02:53 --> Controller Class Initialized
INFO - 2016-02-09 07:02:53 --> Model Class Initialized
INFO - 2016-02-09 07:02:53 --> Model Class Initialized
INFO - 2016-02-09 07:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:02:53 --> Pagination Class Initialized
INFO - 2016-02-09 07:02:53 --> Form Validation Class Initialized
INFO - 2016-02-09 07:02:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:02:53 --> Model Class Initialized
ERROR - 2016-02-09 07:02:53 --> Severity: Notice --> Undefined index: created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 07:02:53 --> Final output sent to browser
DEBUG - 2016-02-09 07:02:53 --> Total execution time: 1.2268
INFO - 2016-02-09 07:06:50 --> Config Class Initialized
INFO - 2016-02-09 07:06:50 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:06:50 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:06:50 --> Utf8 Class Initialized
INFO - 2016-02-09 07:06:50 --> URI Class Initialized
INFO - 2016-02-09 07:06:50 --> Router Class Initialized
INFO - 2016-02-09 07:06:50 --> Output Class Initialized
INFO - 2016-02-09 07:06:50 --> Security Class Initialized
DEBUG - 2016-02-09 07:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:06:50 --> Input Class Initialized
INFO - 2016-02-09 07:06:50 --> Language Class Initialized
INFO - 2016-02-09 07:06:50 --> Loader Class Initialized
INFO - 2016-02-09 07:06:50 --> Helper loaded: url_helper
INFO - 2016-02-09 07:06:50 --> Helper loaded: file_helper
INFO - 2016-02-09 07:06:50 --> Helper loaded: date_helper
INFO - 2016-02-09 07:06:50 --> Helper loaded: form_helper
INFO - 2016-02-09 07:06:50 --> Database Driver Class Initialized
INFO - 2016-02-09 07:06:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:06:51 --> Controller Class Initialized
INFO - 2016-02-09 07:06:51 --> Model Class Initialized
INFO - 2016-02-09 07:06:51 --> Model Class Initialized
INFO - 2016-02-09 07:06:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:06:51 --> Pagination Class Initialized
INFO - 2016-02-09 07:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:06:51 --> Helper loaded: text_helper
INFO - 2016-02-09 07:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:06:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:06:51 --> Final output sent to browser
DEBUG - 2016-02-09 07:06:51 --> Total execution time: 1.2223
INFO - 2016-02-09 07:06:57 --> Config Class Initialized
INFO - 2016-02-09 07:06:57 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:06:57 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:06:57 --> Utf8 Class Initialized
INFO - 2016-02-09 07:06:57 --> URI Class Initialized
INFO - 2016-02-09 07:06:57 --> Router Class Initialized
INFO - 2016-02-09 07:06:57 --> Output Class Initialized
INFO - 2016-02-09 07:06:57 --> Security Class Initialized
DEBUG - 2016-02-09 07:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:06:57 --> Input Class Initialized
INFO - 2016-02-09 07:06:57 --> Language Class Initialized
INFO - 2016-02-09 07:06:57 --> Loader Class Initialized
INFO - 2016-02-09 07:06:57 --> Helper loaded: url_helper
INFO - 2016-02-09 07:06:57 --> Helper loaded: file_helper
INFO - 2016-02-09 07:06:57 --> Helper loaded: date_helper
INFO - 2016-02-09 07:06:57 --> Helper loaded: form_helper
INFO - 2016-02-09 07:06:57 --> Database Driver Class Initialized
INFO - 2016-02-09 07:06:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:06:58 --> Controller Class Initialized
INFO - 2016-02-09 07:06:58 --> Model Class Initialized
INFO - 2016-02-09 07:06:58 --> Model Class Initialized
INFO - 2016-02-09 07:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:06:58 --> Pagination Class Initialized
INFO - 2016-02-09 07:06:58 --> Form Validation Class Initialized
INFO - 2016-02-09 07:06:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:06:58 --> Model Class Initialized
ERROR - 2016-02-09 07:06:59 --> Severity: Notice --> Undefined variable: ths C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-09 07:06:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
ERROR - 2016-02-09 07:06:59 --> Severity: Error --> Call to a member function row() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
INFO - 2016-02-09 07:07:46 --> Config Class Initialized
INFO - 2016-02-09 07:07:46 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:07:46 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:07:46 --> Utf8 Class Initialized
INFO - 2016-02-09 07:07:46 --> URI Class Initialized
INFO - 2016-02-09 07:07:46 --> Router Class Initialized
INFO - 2016-02-09 07:07:46 --> Output Class Initialized
INFO - 2016-02-09 07:07:46 --> Security Class Initialized
DEBUG - 2016-02-09 07:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:07:46 --> Input Class Initialized
INFO - 2016-02-09 07:07:46 --> Language Class Initialized
INFO - 2016-02-09 07:07:46 --> Loader Class Initialized
INFO - 2016-02-09 07:07:46 --> Helper loaded: url_helper
INFO - 2016-02-09 07:07:46 --> Helper loaded: file_helper
INFO - 2016-02-09 07:07:46 --> Helper loaded: date_helper
INFO - 2016-02-09 07:07:46 --> Helper loaded: form_helper
INFO - 2016-02-09 07:07:46 --> Database Driver Class Initialized
INFO - 2016-02-09 07:07:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:07:47 --> Controller Class Initialized
INFO - 2016-02-09 07:07:47 --> Model Class Initialized
INFO - 2016-02-09 07:07:47 --> Model Class Initialized
INFO - 2016-02-09 07:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:07:47 --> Pagination Class Initialized
INFO - 2016-02-09 07:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:07:47 --> Helper loaded: text_helper
INFO - 2016-02-09 07:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:07:47 --> Final output sent to browser
DEBUG - 2016-02-09 07:07:47 --> Total execution time: 1.1845
INFO - 2016-02-09 07:07:54 --> Config Class Initialized
INFO - 2016-02-09 07:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:07:54 --> Utf8 Class Initialized
INFO - 2016-02-09 07:07:54 --> URI Class Initialized
INFO - 2016-02-09 07:07:54 --> Router Class Initialized
INFO - 2016-02-09 07:07:54 --> Output Class Initialized
INFO - 2016-02-09 07:07:54 --> Security Class Initialized
DEBUG - 2016-02-09 07:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:07:54 --> Input Class Initialized
INFO - 2016-02-09 07:07:54 --> Language Class Initialized
INFO - 2016-02-09 07:07:54 --> Loader Class Initialized
INFO - 2016-02-09 07:07:54 --> Helper loaded: url_helper
INFO - 2016-02-09 07:07:54 --> Helper loaded: file_helper
INFO - 2016-02-09 07:07:54 --> Helper loaded: date_helper
INFO - 2016-02-09 07:07:54 --> Helper loaded: form_helper
INFO - 2016-02-09 07:07:54 --> Database Driver Class Initialized
INFO - 2016-02-09 07:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:07:55 --> Controller Class Initialized
INFO - 2016-02-09 07:07:55 --> Model Class Initialized
INFO - 2016-02-09 07:07:55 --> Model Class Initialized
INFO - 2016-02-09 07:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:07:55 --> Pagination Class Initialized
INFO - 2016-02-09 07:07:55 --> Form Validation Class Initialized
INFO - 2016-02-09 07:07:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:07:55 --> Model Class Initialized
ERROR - 2016-02-09 07:07:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::row() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 95
INFO - 2016-02-09 07:08:32 --> Config Class Initialized
INFO - 2016-02-09 07:08:32 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:08:32 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:08:32 --> Utf8 Class Initialized
INFO - 2016-02-09 07:08:32 --> URI Class Initialized
INFO - 2016-02-09 07:08:32 --> Router Class Initialized
INFO - 2016-02-09 07:08:32 --> Output Class Initialized
INFO - 2016-02-09 07:08:32 --> Security Class Initialized
DEBUG - 2016-02-09 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:08:32 --> Input Class Initialized
INFO - 2016-02-09 07:08:32 --> Language Class Initialized
INFO - 2016-02-09 07:08:32 --> Loader Class Initialized
INFO - 2016-02-09 07:08:32 --> Helper loaded: url_helper
INFO - 2016-02-09 07:08:32 --> Helper loaded: file_helper
INFO - 2016-02-09 07:08:32 --> Helper loaded: date_helper
INFO - 2016-02-09 07:08:32 --> Helper loaded: form_helper
INFO - 2016-02-09 07:08:32 --> Database Driver Class Initialized
INFO - 2016-02-09 07:08:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:08:33 --> Controller Class Initialized
INFO - 2016-02-09 07:08:33 --> Model Class Initialized
INFO - 2016-02-09 07:08:33 --> Model Class Initialized
INFO - 2016-02-09 07:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:08:33 --> Pagination Class Initialized
INFO - 2016-02-09 07:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:08:33 --> Helper loaded: text_helper
INFO - 2016-02-09 07:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:08:33 --> Final output sent to browser
DEBUG - 2016-02-09 07:08:33 --> Total execution time: 1.2100
INFO - 2016-02-09 07:08:40 --> Config Class Initialized
INFO - 2016-02-09 07:08:40 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:08:40 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:08:40 --> Utf8 Class Initialized
INFO - 2016-02-09 07:08:40 --> URI Class Initialized
INFO - 2016-02-09 07:08:40 --> Router Class Initialized
INFO - 2016-02-09 07:08:40 --> Output Class Initialized
INFO - 2016-02-09 07:08:40 --> Security Class Initialized
DEBUG - 2016-02-09 07:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:08:40 --> Input Class Initialized
INFO - 2016-02-09 07:08:40 --> Language Class Initialized
INFO - 2016-02-09 07:08:40 --> Loader Class Initialized
INFO - 2016-02-09 07:08:40 --> Helper loaded: url_helper
INFO - 2016-02-09 07:08:40 --> Helper loaded: file_helper
INFO - 2016-02-09 07:08:40 --> Helper loaded: date_helper
INFO - 2016-02-09 07:08:40 --> Helper loaded: form_helper
INFO - 2016-02-09 07:08:40 --> Database Driver Class Initialized
INFO - 2016-02-09 07:08:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:08:41 --> Controller Class Initialized
INFO - 2016-02-09 07:08:41 --> Model Class Initialized
INFO - 2016-02-09 07:08:41 --> Model Class Initialized
INFO - 2016-02-09 07:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:08:41 --> Pagination Class Initialized
INFO - 2016-02-09 07:08:41 --> Form Validation Class Initialized
INFO - 2016-02-09 07:08:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:08:41 --> Model Class Initialized
ERROR - 2016-02-09 07:08:41 --> Severity: Error --> Cannot use object of type stdClass as array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 223
INFO - 2016-02-09 07:10:55 --> Config Class Initialized
INFO - 2016-02-09 07:10:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:10:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:10:55 --> Utf8 Class Initialized
INFO - 2016-02-09 07:10:55 --> URI Class Initialized
INFO - 2016-02-09 07:10:55 --> Router Class Initialized
INFO - 2016-02-09 07:10:55 --> Output Class Initialized
INFO - 2016-02-09 07:10:55 --> Security Class Initialized
DEBUG - 2016-02-09 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:10:55 --> Input Class Initialized
INFO - 2016-02-09 07:10:55 --> Language Class Initialized
INFO - 2016-02-09 07:10:55 --> Loader Class Initialized
INFO - 2016-02-09 07:10:55 --> Helper loaded: url_helper
INFO - 2016-02-09 07:10:55 --> Helper loaded: file_helper
INFO - 2016-02-09 07:10:55 --> Helper loaded: date_helper
INFO - 2016-02-09 07:10:55 --> Helper loaded: form_helper
INFO - 2016-02-09 07:10:55 --> Database Driver Class Initialized
INFO - 2016-02-09 07:10:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:10:56 --> Controller Class Initialized
INFO - 2016-02-09 07:10:56 --> Model Class Initialized
INFO - 2016-02-09 07:10:56 --> Model Class Initialized
INFO - 2016-02-09 07:10:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:10:56 --> Pagination Class Initialized
INFO - 2016-02-09 07:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:10:56 --> Helper loaded: text_helper
INFO - 2016-02-09 07:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:10:56 --> Final output sent to browser
DEBUG - 2016-02-09 07:10:56 --> Total execution time: 1.2219
INFO - 2016-02-09 07:11:08 --> Config Class Initialized
INFO - 2016-02-09 07:11:08 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:11:08 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:11:08 --> Utf8 Class Initialized
INFO - 2016-02-09 07:11:08 --> URI Class Initialized
INFO - 2016-02-09 07:11:08 --> Router Class Initialized
INFO - 2016-02-09 07:11:08 --> Output Class Initialized
INFO - 2016-02-09 07:11:08 --> Security Class Initialized
DEBUG - 2016-02-09 07:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:11:08 --> Input Class Initialized
INFO - 2016-02-09 07:11:08 --> Language Class Initialized
INFO - 2016-02-09 07:11:08 --> Loader Class Initialized
INFO - 2016-02-09 07:11:08 --> Helper loaded: url_helper
INFO - 2016-02-09 07:11:08 --> Helper loaded: file_helper
INFO - 2016-02-09 07:11:08 --> Helper loaded: date_helper
INFO - 2016-02-09 07:11:08 --> Helper loaded: form_helper
INFO - 2016-02-09 07:11:08 --> Database Driver Class Initialized
INFO - 2016-02-09 07:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:11:09 --> Controller Class Initialized
INFO - 2016-02-09 07:11:09 --> Model Class Initialized
INFO - 2016-02-09 07:11:09 --> Model Class Initialized
INFO - 2016-02-09 07:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:11:09 --> Pagination Class Initialized
INFO - 2016-02-09 07:11:09 --> Form Validation Class Initialized
INFO - 2016-02-09 07:11:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:11:09 --> Model Class Initialized
INFO - 2016-02-09 07:11:09 --> Final output sent to browser
DEBUG - 2016-02-09 07:11:09 --> Total execution time: 1.1977
ERROR - 2016-02-09 07:11:09 --> Query error: Unknown column 'created' in 'field list' - Invalid query: UPDATE `ci_sessions` SET created = NOW(), `timestamp` = 1455030669
WHERE `id` = 'a2767e19564da9298959a801e87f4593882a2b75'
INFO - 2016-02-09 07:11:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-09 07:11:56 --> Config Class Initialized
INFO - 2016-02-09 07:11:56 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:11:56 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:11:56 --> Utf8 Class Initialized
INFO - 2016-02-09 07:11:56 --> URI Class Initialized
INFO - 2016-02-09 07:11:56 --> Router Class Initialized
INFO - 2016-02-09 07:11:56 --> Output Class Initialized
INFO - 2016-02-09 07:11:56 --> Security Class Initialized
DEBUG - 2016-02-09 07:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:11:56 --> Input Class Initialized
INFO - 2016-02-09 07:11:56 --> Language Class Initialized
INFO - 2016-02-09 07:11:56 --> Loader Class Initialized
INFO - 2016-02-09 07:11:56 --> Helper loaded: url_helper
INFO - 2016-02-09 07:11:56 --> Helper loaded: file_helper
INFO - 2016-02-09 07:11:56 --> Helper loaded: date_helper
INFO - 2016-02-09 07:11:56 --> Helper loaded: form_helper
INFO - 2016-02-09 07:11:56 --> Database Driver Class Initialized
INFO - 2016-02-09 07:11:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:11:57 --> Controller Class Initialized
INFO - 2016-02-09 07:11:57 --> Model Class Initialized
INFO - 2016-02-09 07:11:57 --> Model Class Initialized
INFO - 2016-02-09 07:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:11:57 --> Pagination Class Initialized
INFO - 2016-02-09 07:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:11:57 --> Helper loaded: text_helper
INFO - 2016-02-09 07:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:11:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:11:57 --> Final output sent to browser
DEBUG - 2016-02-09 07:11:57 --> Total execution time: 1.2146
INFO - 2016-02-09 07:12:04 --> Config Class Initialized
INFO - 2016-02-09 07:12:04 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:12:04 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:12:04 --> Utf8 Class Initialized
INFO - 2016-02-09 07:12:04 --> URI Class Initialized
INFO - 2016-02-09 07:12:04 --> Router Class Initialized
INFO - 2016-02-09 07:12:04 --> Output Class Initialized
INFO - 2016-02-09 07:12:04 --> Security Class Initialized
DEBUG - 2016-02-09 07:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:12:04 --> Input Class Initialized
INFO - 2016-02-09 07:12:04 --> Language Class Initialized
INFO - 2016-02-09 07:12:04 --> Loader Class Initialized
INFO - 2016-02-09 07:12:04 --> Helper loaded: url_helper
INFO - 2016-02-09 07:12:04 --> Helper loaded: file_helper
INFO - 2016-02-09 07:12:04 --> Helper loaded: date_helper
INFO - 2016-02-09 07:12:04 --> Helper loaded: form_helper
INFO - 2016-02-09 07:12:04 --> Database Driver Class Initialized
INFO - 2016-02-09 07:12:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:12:05 --> Controller Class Initialized
INFO - 2016-02-09 07:12:05 --> Model Class Initialized
INFO - 2016-02-09 07:12:05 --> Model Class Initialized
INFO - 2016-02-09 07:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:12:05 --> Pagination Class Initialized
INFO - 2016-02-09 07:12:05 --> Form Validation Class Initialized
INFO - 2016-02-09 07:12:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:12:05 --> Model Class Initialized
INFO - 2016-02-09 07:12:05 --> Final output sent to browser
DEBUG - 2016-02-09 07:12:05 --> Total execution time: 1.2123
INFO - 2016-02-09 07:12:35 --> Config Class Initialized
INFO - 2016-02-09 07:12:36 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:12:36 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:12:36 --> Utf8 Class Initialized
INFO - 2016-02-09 07:12:36 --> URI Class Initialized
INFO - 2016-02-09 07:12:36 --> Router Class Initialized
INFO - 2016-02-09 07:12:36 --> Output Class Initialized
INFO - 2016-02-09 07:12:36 --> Security Class Initialized
DEBUG - 2016-02-09 07:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:12:36 --> Input Class Initialized
INFO - 2016-02-09 07:12:36 --> Language Class Initialized
INFO - 2016-02-09 07:12:36 --> Loader Class Initialized
INFO - 2016-02-09 07:12:36 --> Helper loaded: url_helper
INFO - 2016-02-09 07:12:36 --> Helper loaded: file_helper
INFO - 2016-02-09 07:12:36 --> Helper loaded: date_helper
INFO - 2016-02-09 07:12:36 --> Helper loaded: form_helper
INFO - 2016-02-09 07:12:36 --> Database Driver Class Initialized
INFO - 2016-02-09 07:12:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:12:37 --> Controller Class Initialized
INFO - 2016-02-09 07:12:37 --> Model Class Initialized
INFO - 2016-02-09 07:12:37 --> Model Class Initialized
INFO - 2016-02-09 07:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:12:37 --> Pagination Class Initialized
INFO - 2016-02-09 07:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:12:37 --> Helper loaded: text_helper
INFO - 2016-02-09 07:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:12:37 --> Final output sent to browser
DEBUG - 2016-02-09 07:12:37 --> Total execution time: 1.2092
INFO - 2016-02-09 07:12:45 --> Config Class Initialized
INFO - 2016-02-09 07:12:45 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:12:45 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:12:45 --> Utf8 Class Initialized
INFO - 2016-02-09 07:12:45 --> URI Class Initialized
INFO - 2016-02-09 07:12:45 --> Router Class Initialized
INFO - 2016-02-09 07:12:45 --> Output Class Initialized
INFO - 2016-02-09 07:12:45 --> Security Class Initialized
DEBUG - 2016-02-09 07:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:12:45 --> Input Class Initialized
INFO - 2016-02-09 07:12:45 --> Language Class Initialized
INFO - 2016-02-09 07:12:45 --> Loader Class Initialized
INFO - 2016-02-09 07:12:45 --> Helper loaded: url_helper
INFO - 2016-02-09 07:12:45 --> Helper loaded: file_helper
INFO - 2016-02-09 07:12:45 --> Helper loaded: date_helper
INFO - 2016-02-09 07:12:45 --> Helper loaded: form_helper
INFO - 2016-02-09 07:12:45 --> Database Driver Class Initialized
INFO - 2016-02-09 07:12:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:12:46 --> Controller Class Initialized
INFO - 2016-02-09 07:12:46 --> Model Class Initialized
INFO - 2016-02-09 07:12:46 --> Model Class Initialized
INFO - 2016-02-09 07:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:12:46 --> Pagination Class Initialized
INFO - 2016-02-09 07:12:46 --> Form Validation Class Initialized
INFO - 2016-02-09 07:12:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:12:46 --> Model Class Initialized
INFO - 2016-02-09 07:12:46 --> Final output sent to browser
DEBUG - 2016-02-09 07:12:46 --> Total execution time: 1.3028
INFO - 2016-02-09 07:15:49 --> Config Class Initialized
INFO - 2016-02-09 07:15:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:15:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:15:49 --> Utf8 Class Initialized
INFO - 2016-02-09 07:15:49 --> URI Class Initialized
INFO - 2016-02-09 07:15:49 --> Router Class Initialized
INFO - 2016-02-09 07:15:49 --> Output Class Initialized
INFO - 2016-02-09 07:15:49 --> Security Class Initialized
DEBUG - 2016-02-09 07:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:15:49 --> Input Class Initialized
INFO - 2016-02-09 07:15:49 --> Language Class Initialized
INFO - 2016-02-09 07:15:49 --> Loader Class Initialized
INFO - 2016-02-09 07:15:49 --> Helper loaded: url_helper
INFO - 2016-02-09 07:15:49 --> Helper loaded: file_helper
INFO - 2016-02-09 07:15:49 --> Helper loaded: date_helper
INFO - 2016-02-09 07:15:49 --> Helper loaded: form_helper
INFO - 2016-02-09 07:15:49 --> Database Driver Class Initialized
INFO - 2016-02-09 07:15:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:15:50 --> Controller Class Initialized
INFO - 2016-02-09 07:15:50 --> Model Class Initialized
INFO - 2016-02-09 07:15:50 --> Model Class Initialized
INFO - 2016-02-09 07:15:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:15:50 --> Pagination Class Initialized
INFO - 2016-02-09 07:15:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:15:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:15:50 --> Helper loaded: text_helper
INFO - 2016-02-09 07:15:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:15:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:15:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:15:50 --> Final output sent to browser
DEBUG - 2016-02-09 07:15:50 --> Total execution time: 1.1975
INFO - 2016-02-09 07:16:47 --> Config Class Initialized
INFO - 2016-02-09 07:16:47 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:16:47 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:16:47 --> Utf8 Class Initialized
INFO - 2016-02-09 07:16:47 --> URI Class Initialized
INFO - 2016-02-09 07:16:47 --> Router Class Initialized
INFO - 2016-02-09 07:16:47 --> Output Class Initialized
INFO - 2016-02-09 07:16:47 --> Security Class Initialized
DEBUG - 2016-02-09 07:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:16:47 --> Input Class Initialized
INFO - 2016-02-09 07:16:47 --> Language Class Initialized
INFO - 2016-02-09 07:16:47 --> Loader Class Initialized
INFO - 2016-02-09 07:16:47 --> Helper loaded: url_helper
INFO - 2016-02-09 07:16:47 --> Helper loaded: file_helper
INFO - 2016-02-09 07:16:47 --> Helper loaded: date_helper
INFO - 2016-02-09 07:16:47 --> Helper loaded: form_helper
INFO - 2016-02-09 07:16:47 --> Database Driver Class Initialized
INFO - 2016-02-09 07:16:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:16:48 --> Controller Class Initialized
INFO - 2016-02-09 07:16:48 --> Model Class Initialized
INFO - 2016-02-09 07:16:48 --> Model Class Initialized
INFO - 2016-02-09 07:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:16:48 --> Pagination Class Initialized
INFO - 2016-02-09 07:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:16:48 --> Helper loaded: text_helper
INFO - 2016-02-09 07:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:16:48 --> Final output sent to browser
DEBUG - 2016-02-09 07:16:48 --> Total execution time: 1.2272
INFO - 2016-02-09 07:16:56 --> Config Class Initialized
INFO - 2016-02-09 07:16:56 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:16:56 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:16:56 --> Utf8 Class Initialized
INFO - 2016-02-09 07:16:56 --> URI Class Initialized
INFO - 2016-02-09 07:16:56 --> Router Class Initialized
INFO - 2016-02-09 07:16:56 --> Output Class Initialized
INFO - 2016-02-09 07:16:56 --> Security Class Initialized
DEBUG - 2016-02-09 07:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:16:56 --> Input Class Initialized
INFO - 2016-02-09 07:16:56 --> Language Class Initialized
INFO - 2016-02-09 07:16:56 --> Loader Class Initialized
INFO - 2016-02-09 07:16:56 --> Helper loaded: url_helper
INFO - 2016-02-09 07:16:56 --> Helper loaded: file_helper
INFO - 2016-02-09 07:16:56 --> Helper loaded: date_helper
INFO - 2016-02-09 07:16:56 --> Helper loaded: form_helper
INFO - 2016-02-09 07:16:56 --> Database Driver Class Initialized
INFO - 2016-02-09 07:16:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:16:57 --> Controller Class Initialized
INFO - 2016-02-09 07:16:57 --> Model Class Initialized
INFO - 2016-02-09 07:16:57 --> Model Class Initialized
INFO - 2016-02-09 07:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:16:57 --> Pagination Class Initialized
INFO - 2016-02-09 07:16:57 --> Form Validation Class Initialized
INFO - 2016-02-09 07:16:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:16:57 --> Model Class Initialized
INFO - 2016-02-09 07:16:58 --> Final output sent to browser
DEBUG - 2016-02-09 07:16:58 --> Total execution time: 1.2361
INFO - 2016-02-09 07:17:15 --> Config Class Initialized
INFO - 2016-02-09 07:17:15 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:17:15 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:17:15 --> Utf8 Class Initialized
INFO - 2016-02-09 07:17:15 --> URI Class Initialized
INFO - 2016-02-09 07:17:15 --> Router Class Initialized
INFO - 2016-02-09 07:17:15 --> Output Class Initialized
INFO - 2016-02-09 07:17:15 --> Security Class Initialized
DEBUG - 2016-02-09 07:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:17:15 --> Input Class Initialized
INFO - 2016-02-09 07:17:15 --> Language Class Initialized
INFO - 2016-02-09 07:17:15 --> Loader Class Initialized
INFO - 2016-02-09 07:17:15 --> Helper loaded: url_helper
INFO - 2016-02-09 07:17:15 --> Helper loaded: file_helper
INFO - 2016-02-09 07:17:15 --> Helper loaded: date_helper
INFO - 2016-02-09 07:17:15 --> Helper loaded: form_helper
INFO - 2016-02-09 07:17:15 --> Database Driver Class Initialized
INFO - 2016-02-09 07:17:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:17:16 --> Controller Class Initialized
INFO - 2016-02-09 07:17:16 --> Model Class Initialized
INFO - 2016-02-09 07:17:17 --> Model Class Initialized
INFO - 2016-02-09 07:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:17:17 --> Pagination Class Initialized
INFO - 2016-02-09 07:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:17:17 --> Helper loaded: text_helper
INFO - 2016-02-09 07:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:17:17 --> Final output sent to browser
DEBUG - 2016-02-09 07:17:17 --> Total execution time: 1.2074
INFO - 2016-02-09 07:19:33 --> Config Class Initialized
INFO - 2016-02-09 07:19:33 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:19:33 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:19:33 --> Utf8 Class Initialized
INFO - 2016-02-09 07:19:33 --> URI Class Initialized
INFO - 2016-02-09 07:19:33 --> Router Class Initialized
INFO - 2016-02-09 07:19:33 --> Output Class Initialized
INFO - 2016-02-09 07:19:33 --> Security Class Initialized
DEBUG - 2016-02-09 07:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:19:33 --> Input Class Initialized
INFO - 2016-02-09 07:19:33 --> Language Class Initialized
INFO - 2016-02-09 07:19:33 --> Loader Class Initialized
INFO - 2016-02-09 07:19:33 --> Helper loaded: url_helper
INFO - 2016-02-09 07:19:33 --> Helper loaded: file_helper
INFO - 2016-02-09 07:19:33 --> Helper loaded: date_helper
INFO - 2016-02-09 07:19:33 --> Helper loaded: form_helper
INFO - 2016-02-09 07:19:33 --> Database Driver Class Initialized
INFO - 2016-02-09 07:19:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:19:34 --> Controller Class Initialized
INFO - 2016-02-09 07:19:34 --> Model Class Initialized
INFO - 2016-02-09 07:19:34 --> Model Class Initialized
INFO - 2016-02-09 07:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:19:34 --> Pagination Class Initialized
INFO - 2016-02-09 07:19:34 --> Form Validation Class Initialized
INFO - 2016-02-09 07:19:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:19:34 --> Model Class Initialized
ERROR - 2016-02-09 07:19:34 --> Severity: Error --> Call to a member function format() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 07:20:12 --> Config Class Initialized
INFO - 2016-02-09 07:20:12 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:20:12 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:20:12 --> Utf8 Class Initialized
INFO - 2016-02-09 07:20:12 --> URI Class Initialized
INFO - 2016-02-09 07:20:12 --> Router Class Initialized
INFO - 2016-02-09 07:20:12 --> Output Class Initialized
INFO - 2016-02-09 07:20:12 --> Security Class Initialized
DEBUG - 2016-02-09 07:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:20:12 --> Input Class Initialized
INFO - 2016-02-09 07:20:12 --> Language Class Initialized
INFO - 2016-02-09 07:20:12 --> Loader Class Initialized
INFO - 2016-02-09 07:20:12 --> Helper loaded: url_helper
INFO - 2016-02-09 07:20:12 --> Helper loaded: file_helper
INFO - 2016-02-09 07:20:12 --> Helper loaded: date_helper
INFO - 2016-02-09 07:20:12 --> Helper loaded: form_helper
INFO - 2016-02-09 07:20:12 --> Database Driver Class Initialized
INFO - 2016-02-09 07:20:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:20:13 --> Controller Class Initialized
INFO - 2016-02-09 07:20:13 --> Model Class Initialized
INFO - 2016-02-09 07:20:13 --> Model Class Initialized
INFO - 2016-02-09 07:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:20:13 --> Pagination Class Initialized
INFO - 2016-02-09 07:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:20:13 --> Helper loaded: text_helper
INFO - 2016-02-09 07:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:20:13 --> Final output sent to browser
DEBUG - 2016-02-09 07:20:13 --> Total execution time: 1.1968
INFO - 2016-02-09 07:20:23 --> Config Class Initialized
INFO - 2016-02-09 07:20:23 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:20:23 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:20:23 --> Utf8 Class Initialized
INFO - 2016-02-09 07:20:23 --> URI Class Initialized
INFO - 2016-02-09 07:20:23 --> Router Class Initialized
INFO - 2016-02-09 07:20:23 --> Output Class Initialized
INFO - 2016-02-09 07:20:23 --> Security Class Initialized
DEBUG - 2016-02-09 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:20:23 --> Input Class Initialized
INFO - 2016-02-09 07:20:23 --> Language Class Initialized
INFO - 2016-02-09 07:20:23 --> Loader Class Initialized
INFO - 2016-02-09 07:20:23 --> Helper loaded: url_helper
INFO - 2016-02-09 07:20:23 --> Helper loaded: file_helper
INFO - 2016-02-09 07:20:23 --> Helper loaded: date_helper
INFO - 2016-02-09 07:20:23 --> Helper loaded: form_helper
INFO - 2016-02-09 07:20:23 --> Database Driver Class Initialized
INFO - 2016-02-09 07:20:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:20:24 --> Controller Class Initialized
INFO - 2016-02-09 07:20:24 --> Model Class Initialized
INFO - 2016-02-09 07:20:24 --> Model Class Initialized
INFO - 2016-02-09 07:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:20:24 --> Pagination Class Initialized
INFO - 2016-02-09 07:20:24 --> Form Validation Class Initialized
INFO - 2016-02-09 07:20:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:20:24 --> Model Class Initialized
INFO - 2016-02-09 07:20:24 --> Final output sent to browser
DEBUG - 2016-02-09 07:20:24 --> Total execution time: 1.2179
INFO - 2016-02-09 07:21:25 --> Config Class Initialized
INFO - 2016-02-09 07:21:25 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:21:25 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:21:25 --> Utf8 Class Initialized
INFO - 2016-02-09 07:21:25 --> URI Class Initialized
INFO - 2016-02-09 07:21:25 --> Router Class Initialized
INFO - 2016-02-09 07:21:25 --> Output Class Initialized
INFO - 2016-02-09 07:21:25 --> Security Class Initialized
DEBUG - 2016-02-09 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:21:25 --> Input Class Initialized
INFO - 2016-02-09 07:21:25 --> Language Class Initialized
INFO - 2016-02-09 07:21:25 --> Loader Class Initialized
INFO - 2016-02-09 07:21:25 --> Helper loaded: url_helper
INFO - 2016-02-09 07:21:25 --> Helper loaded: file_helper
INFO - 2016-02-09 07:21:25 --> Helper loaded: date_helper
INFO - 2016-02-09 07:21:25 --> Helper loaded: form_helper
INFO - 2016-02-09 07:21:25 --> Database Driver Class Initialized
INFO - 2016-02-09 07:21:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:21:26 --> Controller Class Initialized
INFO - 2016-02-09 07:21:26 --> Model Class Initialized
INFO - 2016-02-09 07:21:26 --> Model Class Initialized
INFO - 2016-02-09 07:21:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:21:26 --> Pagination Class Initialized
INFO - 2016-02-09 07:21:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:21:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:21:26 --> Helper loaded: text_helper
INFO - 2016-02-09 07:21:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:21:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:21:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:21:26 --> Final output sent to browser
DEBUG - 2016-02-09 07:21:26 --> Total execution time: 1.1997
INFO - 2016-02-09 07:21:31 --> Config Class Initialized
INFO - 2016-02-09 07:21:31 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:21:31 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:21:31 --> Utf8 Class Initialized
INFO - 2016-02-09 07:21:31 --> URI Class Initialized
INFO - 2016-02-09 07:21:31 --> Router Class Initialized
INFO - 2016-02-09 07:21:31 --> Output Class Initialized
INFO - 2016-02-09 07:21:31 --> Security Class Initialized
DEBUG - 2016-02-09 07:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:21:31 --> Input Class Initialized
INFO - 2016-02-09 07:21:31 --> Language Class Initialized
INFO - 2016-02-09 07:21:31 --> Loader Class Initialized
INFO - 2016-02-09 07:21:31 --> Helper loaded: url_helper
INFO - 2016-02-09 07:21:31 --> Helper loaded: file_helper
INFO - 2016-02-09 07:21:31 --> Helper loaded: date_helper
INFO - 2016-02-09 07:21:31 --> Helper loaded: form_helper
INFO - 2016-02-09 07:21:31 --> Database Driver Class Initialized
INFO - 2016-02-09 07:21:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:21:32 --> Controller Class Initialized
INFO - 2016-02-09 07:21:32 --> Model Class Initialized
INFO - 2016-02-09 07:21:32 --> Model Class Initialized
INFO - 2016-02-09 07:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:21:32 --> Pagination Class Initialized
INFO - 2016-02-09 07:21:32 --> Form Validation Class Initialized
INFO - 2016-02-09 07:21:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:21:32 --> Model Class Initialized
INFO - 2016-02-09 07:21:33 --> Final output sent to browser
DEBUG - 2016-02-09 07:21:33 --> Total execution time: 1.3036
INFO - 2016-02-09 07:21:50 --> Config Class Initialized
INFO - 2016-02-09 07:21:50 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:21:50 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:21:50 --> Utf8 Class Initialized
INFO - 2016-02-09 07:21:50 --> URI Class Initialized
INFO - 2016-02-09 07:21:50 --> Router Class Initialized
INFO - 2016-02-09 07:21:50 --> Output Class Initialized
INFO - 2016-02-09 07:21:50 --> Security Class Initialized
DEBUG - 2016-02-09 07:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:21:50 --> Input Class Initialized
INFO - 2016-02-09 07:21:50 --> Language Class Initialized
INFO - 2016-02-09 07:21:50 --> Loader Class Initialized
INFO - 2016-02-09 07:21:50 --> Helper loaded: url_helper
INFO - 2016-02-09 07:21:50 --> Helper loaded: file_helper
INFO - 2016-02-09 07:21:50 --> Helper loaded: date_helper
INFO - 2016-02-09 07:21:50 --> Helper loaded: form_helper
INFO - 2016-02-09 07:21:50 --> Database Driver Class Initialized
INFO - 2016-02-09 07:21:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:21:51 --> Controller Class Initialized
INFO - 2016-02-09 07:21:51 --> Model Class Initialized
INFO - 2016-02-09 07:21:51 --> Model Class Initialized
INFO - 2016-02-09 07:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:21:51 --> Pagination Class Initialized
INFO - 2016-02-09 07:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:21:51 --> Helper loaded: text_helper
INFO - 2016-02-09 07:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:21:51 --> Final output sent to browser
DEBUG - 2016-02-09 07:21:51 --> Total execution time: 1.1591
INFO - 2016-02-09 07:21:57 --> Config Class Initialized
INFO - 2016-02-09 07:21:57 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:21:57 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:21:57 --> Utf8 Class Initialized
INFO - 2016-02-09 07:21:57 --> URI Class Initialized
INFO - 2016-02-09 07:21:57 --> Router Class Initialized
INFO - 2016-02-09 07:21:57 --> Output Class Initialized
INFO - 2016-02-09 07:21:57 --> Security Class Initialized
DEBUG - 2016-02-09 07:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:21:57 --> Input Class Initialized
INFO - 2016-02-09 07:21:57 --> Language Class Initialized
INFO - 2016-02-09 07:21:57 --> Loader Class Initialized
INFO - 2016-02-09 07:21:57 --> Helper loaded: url_helper
INFO - 2016-02-09 07:21:57 --> Helper loaded: file_helper
INFO - 2016-02-09 07:21:57 --> Helper loaded: date_helper
INFO - 2016-02-09 07:21:57 --> Helper loaded: form_helper
INFO - 2016-02-09 07:21:57 --> Database Driver Class Initialized
INFO - 2016-02-09 07:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:21:58 --> Controller Class Initialized
INFO - 2016-02-09 07:21:58 --> Model Class Initialized
INFO - 2016-02-09 07:21:58 --> Model Class Initialized
INFO - 2016-02-09 07:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:21:58 --> Pagination Class Initialized
INFO - 2016-02-09 07:21:58 --> Form Validation Class Initialized
INFO - 2016-02-09 07:21:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:21:58 --> Model Class Initialized
ERROR - 2016-02-09 07:21:58 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 418
ERROR - 2016-02-09 07:21:58 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 418
ERROR - 2016-02-09 07:21:59 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 418
ERROR - 2016-02-09 07:21:59 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 422
ERROR - 2016-02-09 07:21:59 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 422
ERROR - 2016-02-09 07:21:59 --> Severity: Warning --> date() expects parameter 2 to be long, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 436
INFO - 2016-02-09 07:21:59 --> Final output sent to browser
DEBUG - 2016-02-09 07:21:59 --> Total execution time: 1.2250
INFO - 2016-02-09 07:22:59 --> Config Class Initialized
INFO - 2016-02-09 07:22:59 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:22:59 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:22:59 --> Utf8 Class Initialized
INFO - 2016-02-09 07:22:59 --> URI Class Initialized
INFO - 2016-02-09 07:22:59 --> Router Class Initialized
INFO - 2016-02-09 07:22:59 --> Output Class Initialized
INFO - 2016-02-09 07:22:59 --> Security Class Initialized
DEBUG - 2016-02-09 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:22:59 --> Input Class Initialized
INFO - 2016-02-09 07:22:59 --> Language Class Initialized
INFO - 2016-02-09 07:22:59 --> Loader Class Initialized
INFO - 2016-02-09 07:22:59 --> Helper loaded: url_helper
INFO - 2016-02-09 07:22:59 --> Helper loaded: file_helper
INFO - 2016-02-09 07:22:59 --> Helper loaded: date_helper
INFO - 2016-02-09 07:22:59 --> Helper loaded: form_helper
INFO - 2016-02-09 07:22:59 --> Database Driver Class Initialized
INFO - 2016-02-09 07:23:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:23:00 --> Controller Class Initialized
INFO - 2016-02-09 07:23:00 --> Model Class Initialized
INFO - 2016-02-09 07:23:00 --> Model Class Initialized
INFO - 2016-02-09 07:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:23:00 --> Pagination Class Initialized
INFO - 2016-02-09 07:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:23:00 --> Helper loaded: text_helper
INFO - 2016-02-09 07:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:23:00 --> Final output sent to browser
DEBUG - 2016-02-09 07:23:00 --> Total execution time: 1.2367
INFO - 2016-02-09 07:23:04 --> Config Class Initialized
INFO - 2016-02-09 07:23:04 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:23:04 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:23:04 --> Utf8 Class Initialized
INFO - 2016-02-09 07:23:04 --> URI Class Initialized
INFO - 2016-02-09 07:23:04 --> Router Class Initialized
INFO - 2016-02-09 07:23:04 --> Output Class Initialized
INFO - 2016-02-09 07:23:04 --> Security Class Initialized
DEBUG - 2016-02-09 07:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:23:04 --> Input Class Initialized
INFO - 2016-02-09 07:23:04 --> Language Class Initialized
INFO - 2016-02-09 07:23:04 --> Loader Class Initialized
INFO - 2016-02-09 07:23:04 --> Helper loaded: url_helper
INFO - 2016-02-09 07:23:04 --> Helper loaded: file_helper
INFO - 2016-02-09 07:23:04 --> Helper loaded: date_helper
INFO - 2016-02-09 07:23:04 --> Helper loaded: form_helper
INFO - 2016-02-09 07:23:04 --> Database Driver Class Initialized
INFO - 2016-02-09 07:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:23:06 --> Controller Class Initialized
INFO - 2016-02-09 07:23:06 --> Model Class Initialized
INFO - 2016-02-09 07:23:06 --> Model Class Initialized
INFO - 2016-02-09 07:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:23:06 --> Pagination Class Initialized
INFO - 2016-02-09 07:23:06 --> Form Validation Class Initialized
INFO - 2016-02-09 07:23:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:23:06 --> Model Class Initialized
INFO - 2016-02-09 07:23:06 --> Final output sent to browser
DEBUG - 2016-02-09 07:23:06 --> Total execution time: 1.3401
INFO - 2016-02-09 07:23:24 --> Config Class Initialized
INFO - 2016-02-09 07:23:24 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:23:24 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:23:24 --> Utf8 Class Initialized
INFO - 2016-02-09 07:23:24 --> URI Class Initialized
INFO - 2016-02-09 07:23:24 --> Router Class Initialized
INFO - 2016-02-09 07:23:24 --> Output Class Initialized
INFO - 2016-02-09 07:23:24 --> Security Class Initialized
DEBUG - 2016-02-09 07:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:23:24 --> Input Class Initialized
INFO - 2016-02-09 07:23:24 --> Language Class Initialized
INFO - 2016-02-09 07:23:24 --> Loader Class Initialized
INFO - 2016-02-09 07:23:24 --> Helper loaded: url_helper
INFO - 2016-02-09 07:23:24 --> Helper loaded: file_helper
INFO - 2016-02-09 07:23:24 --> Helper loaded: date_helper
INFO - 2016-02-09 07:23:24 --> Helper loaded: form_helper
INFO - 2016-02-09 07:23:24 --> Database Driver Class Initialized
INFO - 2016-02-09 07:23:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:23:25 --> Controller Class Initialized
INFO - 2016-02-09 07:23:25 --> Model Class Initialized
INFO - 2016-02-09 07:23:25 --> Model Class Initialized
INFO - 2016-02-09 07:23:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:23:25 --> Pagination Class Initialized
INFO - 2016-02-09 07:23:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:23:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:23:25 --> Helper loaded: text_helper
INFO - 2016-02-09 07:23:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:23:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:23:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:23:25 --> Final output sent to browser
DEBUG - 2016-02-09 07:23:25 --> Total execution time: 1.2058
INFO - 2016-02-09 07:24:07 --> Config Class Initialized
INFO - 2016-02-09 07:24:07 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:24:07 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:24:07 --> Utf8 Class Initialized
INFO - 2016-02-09 07:24:07 --> URI Class Initialized
INFO - 2016-02-09 07:24:07 --> Router Class Initialized
INFO - 2016-02-09 07:24:07 --> Output Class Initialized
INFO - 2016-02-09 07:24:07 --> Security Class Initialized
DEBUG - 2016-02-09 07:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:24:07 --> Input Class Initialized
INFO - 2016-02-09 07:24:07 --> Language Class Initialized
INFO - 2016-02-09 07:24:07 --> Loader Class Initialized
INFO - 2016-02-09 07:24:07 --> Helper loaded: url_helper
INFO - 2016-02-09 07:24:07 --> Helper loaded: file_helper
INFO - 2016-02-09 07:24:07 --> Helper loaded: date_helper
INFO - 2016-02-09 07:24:07 --> Helper loaded: form_helper
INFO - 2016-02-09 07:24:07 --> Database Driver Class Initialized
INFO - 2016-02-09 07:24:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:24:08 --> Controller Class Initialized
INFO - 2016-02-09 07:24:08 --> Model Class Initialized
INFO - 2016-02-09 07:24:08 --> Model Class Initialized
INFO - 2016-02-09 07:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:24:08 --> Pagination Class Initialized
INFO - 2016-02-09 07:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:24:08 --> Helper loaded: text_helper
INFO - 2016-02-09 07:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:24:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:24:08 --> Final output sent to browser
DEBUG - 2016-02-09 07:24:08 --> Total execution time: 1.2026
INFO - 2016-02-09 07:24:13 --> Config Class Initialized
INFO - 2016-02-09 07:24:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:24:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:24:13 --> Utf8 Class Initialized
INFO - 2016-02-09 07:24:13 --> URI Class Initialized
INFO - 2016-02-09 07:24:13 --> Router Class Initialized
INFO - 2016-02-09 07:24:13 --> Output Class Initialized
INFO - 2016-02-09 07:24:13 --> Security Class Initialized
DEBUG - 2016-02-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:24:13 --> Input Class Initialized
INFO - 2016-02-09 07:24:13 --> Language Class Initialized
INFO - 2016-02-09 07:24:13 --> Loader Class Initialized
INFO - 2016-02-09 07:24:13 --> Helper loaded: url_helper
INFO - 2016-02-09 07:24:13 --> Helper loaded: file_helper
INFO - 2016-02-09 07:24:13 --> Helper loaded: date_helper
INFO - 2016-02-09 07:24:13 --> Helper loaded: form_helper
INFO - 2016-02-09 07:24:13 --> Database Driver Class Initialized
INFO - 2016-02-09 07:24:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:24:14 --> Controller Class Initialized
INFO - 2016-02-09 07:24:14 --> Model Class Initialized
INFO - 2016-02-09 07:24:14 --> Model Class Initialized
INFO - 2016-02-09 07:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:24:14 --> Pagination Class Initialized
INFO - 2016-02-09 07:24:14 --> Form Validation Class Initialized
INFO - 2016-02-09 07:24:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:24:14 --> Model Class Initialized
INFO - 2016-02-09 07:24:14 --> Final output sent to browser
DEBUG - 2016-02-09 07:24:14 --> Total execution time: 1.2145
INFO - 2016-02-09 07:24:37 --> Config Class Initialized
INFO - 2016-02-09 07:24:37 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:24:37 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:24:37 --> Utf8 Class Initialized
INFO - 2016-02-09 07:24:37 --> URI Class Initialized
INFO - 2016-02-09 07:24:37 --> Router Class Initialized
INFO - 2016-02-09 07:24:37 --> Output Class Initialized
INFO - 2016-02-09 07:24:37 --> Security Class Initialized
DEBUG - 2016-02-09 07:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:24:37 --> Input Class Initialized
INFO - 2016-02-09 07:24:37 --> Language Class Initialized
INFO - 2016-02-09 07:24:37 --> Loader Class Initialized
INFO - 2016-02-09 07:24:37 --> Helper loaded: url_helper
INFO - 2016-02-09 07:24:37 --> Helper loaded: file_helper
INFO - 2016-02-09 07:24:37 --> Helper loaded: date_helper
INFO - 2016-02-09 07:24:37 --> Helper loaded: form_helper
INFO - 2016-02-09 07:24:37 --> Database Driver Class Initialized
INFO - 2016-02-09 07:24:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:24:38 --> Controller Class Initialized
INFO - 2016-02-09 07:24:38 --> Model Class Initialized
INFO - 2016-02-09 07:24:38 --> Model Class Initialized
INFO - 2016-02-09 07:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:24:38 --> Pagination Class Initialized
INFO - 2016-02-09 07:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:24:38 --> Helper loaded: text_helper
INFO - 2016-02-09 07:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:24:39 --> Final output sent to browser
DEBUG - 2016-02-09 07:24:39 --> Total execution time: 1.2229
INFO - 2016-02-09 07:24:42 --> Config Class Initialized
INFO - 2016-02-09 07:24:42 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:24:42 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:24:42 --> Utf8 Class Initialized
INFO - 2016-02-09 07:24:42 --> URI Class Initialized
INFO - 2016-02-09 07:24:42 --> Router Class Initialized
INFO - 2016-02-09 07:24:42 --> Output Class Initialized
INFO - 2016-02-09 07:24:42 --> Security Class Initialized
DEBUG - 2016-02-09 07:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:24:42 --> Input Class Initialized
INFO - 2016-02-09 07:24:42 --> Language Class Initialized
INFO - 2016-02-09 07:24:42 --> Loader Class Initialized
INFO - 2016-02-09 07:24:42 --> Helper loaded: url_helper
INFO - 2016-02-09 07:24:42 --> Helper loaded: file_helper
INFO - 2016-02-09 07:24:42 --> Helper loaded: date_helper
INFO - 2016-02-09 07:24:42 --> Helper loaded: form_helper
INFO - 2016-02-09 07:24:42 --> Database Driver Class Initialized
INFO - 2016-02-09 07:24:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:24:43 --> Controller Class Initialized
INFO - 2016-02-09 07:24:43 --> Model Class Initialized
INFO - 2016-02-09 07:24:43 --> Model Class Initialized
INFO - 2016-02-09 07:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:24:43 --> Pagination Class Initialized
INFO - 2016-02-09 07:24:43 --> Form Validation Class Initialized
INFO - 2016-02-09 07:24:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:24:43 --> Model Class Initialized
INFO - 2016-02-09 07:24:44 --> Final output sent to browser
DEBUG - 2016-02-09 07:24:44 --> Total execution time: 1.1751
INFO - 2016-02-09 07:27:27 --> Config Class Initialized
INFO - 2016-02-09 07:27:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:27:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:27:27 --> Utf8 Class Initialized
INFO - 2016-02-09 07:27:27 --> URI Class Initialized
INFO - 2016-02-09 07:27:27 --> Router Class Initialized
INFO - 2016-02-09 07:27:27 --> Output Class Initialized
INFO - 2016-02-09 07:27:27 --> Security Class Initialized
DEBUG - 2016-02-09 07:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:27:27 --> Input Class Initialized
INFO - 2016-02-09 07:27:27 --> Language Class Initialized
INFO - 2016-02-09 07:27:27 --> Loader Class Initialized
INFO - 2016-02-09 07:27:27 --> Helper loaded: url_helper
INFO - 2016-02-09 07:27:27 --> Helper loaded: file_helper
INFO - 2016-02-09 07:27:27 --> Helper loaded: date_helper
INFO - 2016-02-09 07:27:27 --> Helper loaded: form_helper
INFO - 2016-02-09 07:27:27 --> Database Driver Class Initialized
INFO - 2016-02-09 07:27:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:27:28 --> Controller Class Initialized
INFO - 2016-02-09 07:27:28 --> Model Class Initialized
INFO - 2016-02-09 07:27:28 --> Model Class Initialized
INFO - 2016-02-09 07:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:27:28 --> Pagination Class Initialized
INFO - 2016-02-09 07:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:27:28 --> Helper loaded: text_helper
INFO - 2016-02-09 07:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:27:28 --> Final output sent to browser
DEBUG - 2016-02-09 07:27:28 --> Total execution time: 1.1956
INFO - 2016-02-09 07:27:32 --> Config Class Initialized
INFO - 2016-02-09 07:27:32 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:27:32 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:27:32 --> Utf8 Class Initialized
INFO - 2016-02-09 07:27:32 --> URI Class Initialized
INFO - 2016-02-09 07:27:32 --> Router Class Initialized
INFO - 2016-02-09 07:27:32 --> Output Class Initialized
INFO - 2016-02-09 07:27:32 --> Security Class Initialized
DEBUG - 2016-02-09 07:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:27:32 --> Input Class Initialized
INFO - 2016-02-09 07:27:32 --> Language Class Initialized
INFO - 2016-02-09 07:27:32 --> Loader Class Initialized
INFO - 2016-02-09 07:27:32 --> Helper loaded: url_helper
INFO - 2016-02-09 07:27:32 --> Helper loaded: file_helper
INFO - 2016-02-09 07:27:32 --> Helper loaded: date_helper
INFO - 2016-02-09 07:27:32 --> Helper loaded: form_helper
INFO - 2016-02-09 07:27:32 --> Database Driver Class Initialized
INFO - 2016-02-09 07:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:27:33 --> Controller Class Initialized
INFO - 2016-02-09 07:27:33 --> Model Class Initialized
INFO - 2016-02-09 07:27:33 --> Model Class Initialized
INFO - 2016-02-09 07:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:27:33 --> Pagination Class Initialized
INFO - 2016-02-09 07:27:33 --> Form Validation Class Initialized
INFO - 2016-02-09 07:27:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:27:33 --> Model Class Initialized
INFO - 2016-02-09 07:27:33 --> Final output sent to browser
DEBUG - 2016-02-09 07:27:33 --> Total execution time: 1.2153
INFO - 2016-02-09 07:28:18 --> Config Class Initialized
INFO - 2016-02-09 07:28:18 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:28:18 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:28:18 --> Utf8 Class Initialized
INFO - 2016-02-09 07:28:18 --> URI Class Initialized
INFO - 2016-02-09 07:28:18 --> Router Class Initialized
INFO - 2016-02-09 07:28:18 --> Output Class Initialized
INFO - 2016-02-09 07:28:18 --> Security Class Initialized
DEBUG - 2016-02-09 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:28:18 --> Input Class Initialized
INFO - 2016-02-09 07:28:18 --> Language Class Initialized
INFO - 2016-02-09 07:28:18 --> Loader Class Initialized
INFO - 2016-02-09 07:28:18 --> Helper loaded: url_helper
INFO - 2016-02-09 07:28:18 --> Helper loaded: file_helper
INFO - 2016-02-09 07:28:18 --> Helper loaded: date_helper
INFO - 2016-02-09 07:28:18 --> Helper loaded: form_helper
INFO - 2016-02-09 07:28:18 --> Database Driver Class Initialized
INFO - 2016-02-09 07:28:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:28:19 --> Controller Class Initialized
INFO - 2016-02-09 07:28:19 --> Model Class Initialized
INFO - 2016-02-09 07:28:19 --> Model Class Initialized
INFO - 2016-02-09 07:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:28:19 --> Pagination Class Initialized
INFO - 2016-02-09 07:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:28:19 --> Helper loaded: text_helper
INFO - 2016-02-09 07:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:28:19 --> Final output sent to browser
DEBUG - 2016-02-09 07:28:19 --> Total execution time: 1.1936
INFO - 2016-02-09 07:28:23 --> Config Class Initialized
INFO - 2016-02-09 07:28:23 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:28:23 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:28:23 --> Utf8 Class Initialized
INFO - 2016-02-09 07:28:23 --> URI Class Initialized
INFO - 2016-02-09 07:28:23 --> Router Class Initialized
INFO - 2016-02-09 07:28:23 --> Output Class Initialized
INFO - 2016-02-09 07:28:23 --> Security Class Initialized
DEBUG - 2016-02-09 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:28:23 --> Input Class Initialized
INFO - 2016-02-09 07:28:23 --> Language Class Initialized
INFO - 2016-02-09 07:28:23 --> Loader Class Initialized
INFO - 2016-02-09 07:28:23 --> Helper loaded: url_helper
INFO - 2016-02-09 07:28:23 --> Helper loaded: file_helper
INFO - 2016-02-09 07:28:23 --> Helper loaded: date_helper
INFO - 2016-02-09 07:28:23 --> Helper loaded: form_helper
INFO - 2016-02-09 07:28:23 --> Database Driver Class Initialized
INFO - 2016-02-09 07:28:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:28:24 --> Controller Class Initialized
INFO - 2016-02-09 07:28:24 --> Model Class Initialized
INFO - 2016-02-09 07:28:24 --> Model Class Initialized
INFO - 2016-02-09 07:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:28:24 --> Pagination Class Initialized
INFO - 2016-02-09 07:28:24 --> Form Validation Class Initialized
INFO - 2016-02-09 07:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:28:24 --> Model Class Initialized
ERROR - 2016-02-09 07:28:24 --> Severity: Error --> Call to undefined function datetime() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 07:28:37 --> Config Class Initialized
INFO - 2016-02-09 07:28:37 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:28:37 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:28:37 --> Utf8 Class Initialized
INFO - 2016-02-09 07:28:37 --> URI Class Initialized
INFO - 2016-02-09 07:28:37 --> Router Class Initialized
INFO - 2016-02-09 07:28:37 --> Output Class Initialized
INFO - 2016-02-09 07:28:37 --> Security Class Initialized
DEBUG - 2016-02-09 07:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:28:37 --> Input Class Initialized
INFO - 2016-02-09 07:28:37 --> Language Class Initialized
INFO - 2016-02-09 07:28:37 --> Loader Class Initialized
INFO - 2016-02-09 07:28:37 --> Helper loaded: url_helper
INFO - 2016-02-09 07:28:37 --> Helper loaded: file_helper
INFO - 2016-02-09 07:28:37 --> Helper loaded: date_helper
INFO - 2016-02-09 07:28:37 --> Helper loaded: form_helper
INFO - 2016-02-09 07:28:37 --> Database Driver Class Initialized
INFO - 2016-02-09 07:28:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:28:38 --> Controller Class Initialized
INFO - 2016-02-09 07:28:38 --> Model Class Initialized
INFO - 2016-02-09 07:28:38 --> Model Class Initialized
INFO - 2016-02-09 07:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:28:38 --> Pagination Class Initialized
INFO - 2016-02-09 07:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:28:38 --> Helper loaded: text_helper
INFO - 2016-02-09 07:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:28:38 --> Final output sent to browser
DEBUG - 2016-02-09 07:28:38 --> Total execution time: 1.2435
INFO - 2016-02-09 07:28:43 --> Config Class Initialized
INFO - 2016-02-09 07:28:43 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:28:43 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:28:43 --> Utf8 Class Initialized
INFO - 2016-02-09 07:28:43 --> URI Class Initialized
INFO - 2016-02-09 07:28:43 --> Router Class Initialized
INFO - 2016-02-09 07:28:43 --> Output Class Initialized
INFO - 2016-02-09 07:28:43 --> Security Class Initialized
DEBUG - 2016-02-09 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:28:43 --> Input Class Initialized
INFO - 2016-02-09 07:28:43 --> Language Class Initialized
INFO - 2016-02-09 07:28:43 --> Loader Class Initialized
INFO - 2016-02-09 07:28:43 --> Helper loaded: url_helper
INFO - 2016-02-09 07:28:43 --> Helper loaded: file_helper
INFO - 2016-02-09 07:28:43 --> Helper loaded: date_helper
INFO - 2016-02-09 07:28:43 --> Helper loaded: form_helper
INFO - 2016-02-09 07:28:43 --> Database Driver Class Initialized
INFO - 2016-02-09 07:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:28:44 --> Controller Class Initialized
INFO - 2016-02-09 07:28:44 --> Model Class Initialized
INFO - 2016-02-09 07:28:44 --> Model Class Initialized
INFO - 2016-02-09 07:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:28:44 --> Pagination Class Initialized
INFO - 2016-02-09 07:28:44 --> Form Validation Class Initialized
INFO - 2016-02-09 07:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:28:44 --> Model Class Initialized
ERROR - 2016-02-09 07:28:44 --> Severity: Error --> Call to undefined function datetime() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 221
INFO - 2016-02-09 07:29:52 --> Config Class Initialized
INFO - 2016-02-09 07:29:52 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:29:52 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:29:52 --> Utf8 Class Initialized
INFO - 2016-02-09 07:29:52 --> URI Class Initialized
INFO - 2016-02-09 07:29:52 --> Router Class Initialized
INFO - 2016-02-09 07:29:52 --> Output Class Initialized
INFO - 2016-02-09 07:29:52 --> Security Class Initialized
DEBUG - 2016-02-09 07:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:29:52 --> Input Class Initialized
INFO - 2016-02-09 07:29:52 --> Language Class Initialized
INFO - 2016-02-09 07:29:52 --> Loader Class Initialized
INFO - 2016-02-09 07:29:52 --> Helper loaded: url_helper
INFO - 2016-02-09 07:29:52 --> Helper loaded: file_helper
INFO - 2016-02-09 07:29:52 --> Helper loaded: date_helper
INFO - 2016-02-09 07:29:52 --> Helper loaded: form_helper
INFO - 2016-02-09 07:29:52 --> Database Driver Class Initialized
INFO - 2016-02-09 07:29:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:29:53 --> Controller Class Initialized
INFO - 2016-02-09 07:29:53 --> Model Class Initialized
INFO - 2016-02-09 07:29:53 --> Model Class Initialized
INFO - 2016-02-09 07:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:29:53 --> Pagination Class Initialized
INFO - 2016-02-09 07:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:29:53 --> Helper loaded: text_helper
INFO - 2016-02-09 07:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:29:53 --> Final output sent to browser
DEBUG - 2016-02-09 07:29:53 --> Total execution time: 1.2171
INFO - 2016-02-09 07:29:57 --> Config Class Initialized
INFO - 2016-02-09 07:29:57 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:29:57 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:29:57 --> Utf8 Class Initialized
INFO - 2016-02-09 07:29:57 --> URI Class Initialized
INFO - 2016-02-09 07:29:57 --> Router Class Initialized
INFO - 2016-02-09 07:29:57 --> Output Class Initialized
INFO - 2016-02-09 07:29:57 --> Security Class Initialized
DEBUG - 2016-02-09 07:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:29:57 --> Input Class Initialized
INFO - 2016-02-09 07:29:57 --> Language Class Initialized
INFO - 2016-02-09 07:29:57 --> Loader Class Initialized
INFO - 2016-02-09 07:29:57 --> Helper loaded: url_helper
INFO - 2016-02-09 07:29:57 --> Helper loaded: file_helper
INFO - 2016-02-09 07:29:57 --> Helper loaded: date_helper
INFO - 2016-02-09 07:29:57 --> Helper loaded: form_helper
INFO - 2016-02-09 07:29:57 --> Database Driver Class Initialized
INFO - 2016-02-09 07:29:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:29:58 --> Controller Class Initialized
INFO - 2016-02-09 07:29:58 --> Model Class Initialized
INFO - 2016-02-09 07:29:58 --> Model Class Initialized
INFO - 2016-02-09 07:29:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:29:58 --> Pagination Class Initialized
INFO - 2016-02-09 07:29:58 --> Form Validation Class Initialized
INFO - 2016-02-09 07:29:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:29:58 --> Model Class Initialized
INFO - 2016-02-09 07:29:58 --> Final output sent to browser
DEBUG - 2016-02-09 07:29:58 --> Total execution time: 1.1966
INFO - 2016-02-09 07:31:12 --> Config Class Initialized
INFO - 2016-02-09 07:31:12 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:31:12 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:31:12 --> Utf8 Class Initialized
INFO - 2016-02-09 07:31:12 --> URI Class Initialized
INFO - 2016-02-09 07:31:12 --> Router Class Initialized
INFO - 2016-02-09 07:31:12 --> Output Class Initialized
INFO - 2016-02-09 07:31:12 --> Security Class Initialized
DEBUG - 2016-02-09 07:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:31:12 --> Input Class Initialized
INFO - 2016-02-09 07:31:12 --> Language Class Initialized
INFO - 2016-02-09 07:31:12 --> Loader Class Initialized
INFO - 2016-02-09 07:31:12 --> Helper loaded: url_helper
INFO - 2016-02-09 07:31:12 --> Helper loaded: file_helper
INFO - 2016-02-09 07:31:12 --> Helper loaded: date_helper
INFO - 2016-02-09 07:31:12 --> Helper loaded: form_helper
INFO - 2016-02-09 07:31:12 --> Database Driver Class Initialized
INFO - 2016-02-09 07:31:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:31:13 --> Controller Class Initialized
INFO - 2016-02-09 07:31:13 --> Model Class Initialized
INFO - 2016-02-09 07:31:13 --> Model Class Initialized
INFO - 2016-02-09 07:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:31:13 --> Pagination Class Initialized
INFO - 2016-02-09 07:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:31:13 --> Helper loaded: text_helper
INFO - 2016-02-09 07:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:31:13 --> Final output sent to browser
DEBUG - 2016-02-09 07:31:13 --> Total execution time: 1.1612
INFO - 2016-02-09 07:31:19 --> Config Class Initialized
INFO - 2016-02-09 07:31:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:31:19 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:31:19 --> Utf8 Class Initialized
INFO - 2016-02-09 07:31:19 --> URI Class Initialized
INFO - 2016-02-09 07:31:19 --> Router Class Initialized
INFO - 2016-02-09 07:31:19 --> Output Class Initialized
INFO - 2016-02-09 07:31:19 --> Security Class Initialized
DEBUG - 2016-02-09 07:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:31:19 --> Input Class Initialized
INFO - 2016-02-09 07:31:19 --> Language Class Initialized
INFO - 2016-02-09 07:31:19 --> Loader Class Initialized
INFO - 2016-02-09 07:31:19 --> Helper loaded: url_helper
INFO - 2016-02-09 07:31:19 --> Helper loaded: file_helper
INFO - 2016-02-09 07:31:19 --> Helper loaded: date_helper
INFO - 2016-02-09 07:31:19 --> Helper loaded: form_helper
INFO - 2016-02-09 07:31:19 --> Database Driver Class Initialized
INFO - 2016-02-09 07:31:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:31:20 --> Controller Class Initialized
INFO - 2016-02-09 07:31:20 --> Model Class Initialized
INFO - 2016-02-09 07:31:20 --> Model Class Initialized
INFO - 2016-02-09 07:31:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:31:20 --> Pagination Class Initialized
INFO - 2016-02-09 07:31:20 --> Form Validation Class Initialized
INFO - 2016-02-09 07:31:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:31:20 --> Model Class Initialized
INFO - 2016-02-09 07:31:20 --> Final output sent to browser
DEBUG - 2016-02-09 07:31:20 --> Total execution time: 1.1922
INFO - 2016-02-09 07:31:43 --> Config Class Initialized
INFO - 2016-02-09 07:31:43 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:31:43 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:31:43 --> Utf8 Class Initialized
INFO - 2016-02-09 07:31:43 --> URI Class Initialized
INFO - 2016-02-09 07:31:43 --> Router Class Initialized
INFO - 2016-02-09 07:31:43 --> Output Class Initialized
INFO - 2016-02-09 07:31:43 --> Security Class Initialized
DEBUG - 2016-02-09 07:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:31:43 --> Input Class Initialized
INFO - 2016-02-09 07:31:43 --> Language Class Initialized
INFO - 2016-02-09 07:31:43 --> Loader Class Initialized
INFO - 2016-02-09 07:31:43 --> Helper loaded: url_helper
INFO - 2016-02-09 07:31:43 --> Helper loaded: file_helper
INFO - 2016-02-09 07:31:43 --> Helper loaded: date_helper
INFO - 2016-02-09 07:31:43 --> Helper loaded: form_helper
INFO - 2016-02-09 07:31:43 --> Database Driver Class Initialized
INFO - 2016-02-09 07:31:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:31:44 --> Controller Class Initialized
INFO - 2016-02-09 07:31:44 --> Model Class Initialized
INFO - 2016-02-09 07:31:44 --> Model Class Initialized
INFO - 2016-02-09 07:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:31:44 --> Pagination Class Initialized
INFO - 2016-02-09 07:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:31:44 --> Helper loaded: text_helper
INFO - 2016-02-09 07:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:31:44 --> Final output sent to browser
DEBUG - 2016-02-09 07:31:44 --> Total execution time: 1.2029
INFO - 2016-02-09 07:31:50 --> Config Class Initialized
INFO - 2016-02-09 07:31:50 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:31:50 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:31:50 --> Utf8 Class Initialized
INFO - 2016-02-09 07:31:50 --> URI Class Initialized
INFO - 2016-02-09 07:31:50 --> Router Class Initialized
INFO - 2016-02-09 07:31:50 --> Output Class Initialized
INFO - 2016-02-09 07:31:50 --> Security Class Initialized
DEBUG - 2016-02-09 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:31:50 --> Input Class Initialized
INFO - 2016-02-09 07:31:50 --> Language Class Initialized
INFO - 2016-02-09 07:31:50 --> Loader Class Initialized
INFO - 2016-02-09 07:31:50 --> Helper loaded: url_helper
INFO - 2016-02-09 07:31:50 --> Helper loaded: file_helper
INFO - 2016-02-09 07:31:50 --> Helper loaded: date_helper
INFO - 2016-02-09 07:31:50 --> Helper loaded: form_helper
INFO - 2016-02-09 07:31:50 --> Database Driver Class Initialized
INFO - 2016-02-09 07:31:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:31:51 --> Controller Class Initialized
INFO - 2016-02-09 07:31:51 --> Model Class Initialized
INFO - 2016-02-09 07:31:51 --> Model Class Initialized
INFO - 2016-02-09 07:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:31:51 --> Pagination Class Initialized
INFO - 2016-02-09 07:31:51 --> Form Validation Class Initialized
INFO - 2016-02-09 07:31:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:31:51 --> Model Class Initialized
INFO - 2016-02-09 07:31:52 --> Final output sent to browser
DEBUG - 2016-02-09 07:31:52 --> Total execution time: 1.1910
INFO - 2016-02-09 07:31:55 --> Config Class Initialized
INFO - 2016-02-09 07:31:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:31:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:31:55 --> Utf8 Class Initialized
INFO - 2016-02-09 07:31:55 --> URI Class Initialized
INFO - 2016-02-09 07:31:55 --> Router Class Initialized
INFO - 2016-02-09 07:31:55 --> Output Class Initialized
INFO - 2016-02-09 07:31:55 --> Security Class Initialized
DEBUG - 2016-02-09 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:31:55 --> Input Class Initialized
INFO - 2016-02-09 07:31:55 --> Language Class Initialized
INFO - 2016-02-09 07:31:55 --> Loader Class Initialized
INFO - 2016-02-09 07:31:55 --> Helper loaded: url_helper
INFO - 2016-02-09 07:31:55 --> Helper loaded: file_helper
INFO - 2016-02-09 07:31:55 --> Helper loaded: date_helper
INFO - 2016-02-09 07:31:55 --> Helper loaded: form_helper
INFO - 2016-02-09 07:31:55 --> Database Driver Class Initialized
INFO - 2016-02-09 07:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:31:56 --> Controller Class Initialized
INFO - 2016-02-09 07:31:56 --> Model Class Initialized
INFO - 2016-02-09 07:31:56 --> Model Class Initialized
INFO - 2016-02-09 07:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:31:56 --> Pagination Class Initialized
INFO - 2016-02-09 07:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:31:56 --> Helper loaded: text_helper
INFO - 2016-02-09 07:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:31:56 --> Final output sent to browser
DEBUG - 2016-02-09 07:31:56 --> Total execution time: 1.1925
INFO - 2016-02-09 07:32:10 --> Config Class Initialized
INFO - 2016-02-09 07:32:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:32:10 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:32:10 --> Utf8 Class Initialized
INFO - 2016-02-09 07:32:10 --> URI Class Initialized
INFO - 2016-02-09 07:32:10 --> Router Class Initialized
INFO - 2016-02-09 07:32:10 --> Output Class Initialized
INFO - 2016-02-09 07:32:10 --> Security Class Initialized
DEBUG - 2016-02-09 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:32:10 --> Input Class Initialized
INFO - 2016-02-09 07:32:10 --> Language Class Initialized
INFO - 2016-02-09 07:32:10 --> Loader Class Initialized
INFO - 2016-02-09 07:32:10 --> Helper loaded: url_helper
INFO - 2016-02-09 07:32:10 --> Helper loaded: file_helper
INFO - 2016-02-09 07:32:10 --> Helper loaded: date_helper
INFO - 2016-02-09 07:32:10 --> Helper loaded: form_helper
INFO - 2016-02-09 07:32:10 --> Database Driver Class Initialized
INFO - 2016-02-09 07:32:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:32:11 --> Controller Class Initialized
INFO - 2016-02-09 07:32:11 --> Model Class Initialized
INFO - 2016-02-09 07:32:11 --> Model Class Initialized
INFO - 2016-02-09 07:32:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:32:11 --> Pagination Class Initialized
INFO - 2016-02-09 07:32:11 --> Form Validation Class Initialized
INFO - 2016-02-09 07:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:32:11 --> Model Class Initialized
INFO - 2016-02-09 07:32:11 --> Final output sent to browser
DEBUG - 2016-02-09 07:32:11 --> Total execution time: 1.1758
INFO - 2016-02-09 07:32:25 --> Config Class Initialized
INFO - 2016-02-09 07:32:25 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:32:25 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:32:25 --> Utf8 Class Initialized
INFO - 2016-02-09 07:32:25 --> URI Class Initialized
INFO - 2016-02-09 07:32:25 --> Router Class Initialized
INFO - 2016-02-09 07:32:25 --> Output Class Initialized
INFO - 2016-02-09 07:32:25 --> Security Class Initialized
DEBUG - 2016-02-09 07:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:32:25 --> Input Class Initialized
INFO - 2016-02-09 07:32:25 --> Language Class Initialized
INFO - 2016-02-09 07:32:25 --> Loader Class Initialized
INFO - 2016-02-09 07:32:25 --> Helper loaded: url_helper
INFO - 2016-02-09 07:32:25 --> Helper loaded: file_helper
INFO - 2016-02-09 07:32:25 --> Helper loaded: date_helper
INFO - 2016-02-09 07:32:25 --> Helper loaded: form_helper
INFO - 2016-02-09 07:32:25 --> Database Driver Class Initialized
INFO - 2016-02-09 07:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:32:26 --> Controller Class Initialized
INFO - 2016-02-09 07:32:26 --> Model Class Initialized
INFO - 2016-02-09 07:32:26 --> Model Class Initialized
INFO - 2016-02-09 07:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:32:26 --> Pagination Class Initialized
INFO - 2016-02-09 07:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:32:26 --> Helper loaded: text_helper
INFO - 2016-02-09 07:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:32:26 --> Final output sent to browser
DEBUG - 2016-02-09 07:32:26 --> Total execution time: 1.1570
INFO - 2016-02-09 07:35:56 --> Config Class Initialized
INFO - 2016-02-09 07:35:57 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:35:57 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:35:57 --> Utf8 Class Initialized
INFO - 2016-02-09 07:35:57 --> URI Class Initialized
INFO - 2016-02-09 07:35:57 --> Router Class Initialized
INFO - 2016-02-09 07:35:57 --> Output Class Initialized
INFO - 2016-02-09 07:35:57 --> Security Class Initialized
DEBUG - 2016-02-09 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:35:57 --> Input Class Initialized
INFO - 2016-02-09 07:35:57 --> Language Class Initialized
INFO - 2016-02-09 07:35:57 --> Loader Class Initialized
INFO - 2016-02-09 07:35:57 --> Helper loaded: url_helper
INFO - 2016-02-09 07:35:57 --> Helper loaded: file_helper
INFO - 2016-02-09 07:35:57 --> Helper loaded: date_helper
INFO - 2016-02-09 07:35:57 --> Helper loaded: form_helper
INFO - 2016-02-09 07:35:57 --> Database Driver Class Initialized
INFO - 2016-02-09 07:35:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:35:58 --> Controller Class Initialized
INFO - 2016-02-09 07:35:58 --> Model Class Initialized
INFO - 2016-02-09 07:35:58 --> Model Class Initialized
INFO - 2016-02-09 07:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:35:58 --> Pagination Class Initialized
INFO - 2016-02-09 07:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 07:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 07:35:58 --> Helper loaded: text_helper
INFO - 2016-02-09 07:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 07:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 07:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 07:35:58 --> Final output sent to browser
DEBUG - 2016-02-09 07:35:58 --> Total execution time: 1.1833
INFO - 2016-02-09 07:36:05 --> Config Class Initialized
INFO - 2016-02-09 07:36:05 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:36:05 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:36:05 --> Utf8 Class Initialized
INFO - 2016-02-09 07:36:05 --> URI Class Initialized
INFO - 2016-02-09 07:36:05 --> Router Class Initialized
INFO - 2016-02-09 07:36:05 --> Output Class Initialized
INFO - 2016-02-09 07:36:05 --> Security Class Initialized
DEBUG - 2016-02-09 07:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:36:05 --> Input Class Initialized
INFO - 2016-02-09 07:36:05 --> Language Class Initialized
INFO - 2016-02-09 07:36:05 --> Loader Class Initialized
INFO - 2016-02-09 07:36:05 --> Helper loaded: url_helper
INFO - 2016-02-09 07:36:05 --> Helper loaded: file_helper
INFO - 2016-02-09 07:36:05 --> Helper loaded: date_helper
INFO - 2016-02-09 07:36:05 --> Helper loaded: form_helper
INFO - 2016-02-09 07:36:05 --> Database Driver Class Initialized
INFO - 2016-02-09 07:36:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:36:06 --> Controller Class Initialized
INFO - 2016-02-09 07:36:06 --> Model Class Initialized
INFO - 2016-02-09 07:36:06 --> Model Class Initialized
INFO - 2016-02-09 07:36:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:36:06 --> Pagination Class Initialized
INFO - 2016-02-09 07:36:06 --> Form Validation Class Initialized
INFO - 2016-02-09 07:36:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 07:36:06 --> Model Class Initialized
ERROR - 2016-02-09 07:36:06 --> Severity: error --> Exception: DateTimeZone::__construct(): Unknown or bad timezone (UM5) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\helpers\date_helper.php 75
INFO - 2016-02-09 07:42:13 --> Config Class Initialized
INFO - 2016-02-09 07:42:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:42:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:42:13 --> Utf8 Class Initialized
INFO - 2016-02-09 07:42:13 --> URI Class Initialized
INFO - 2016-02-09 07:42:13 --> Router Class Initialized
INFO - 2016-02-09 07:42:13 --> Output Class Initialized
INFO - 2016-02-09 07:42:13 --> Security Class Initialized
DEBUG - 2016-02-09 07:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:42:13 --> Input Class Initialized
INFO - 2016-02-09 07:42:13 --> Language Class Initialized
INFO - 2016-02-09 07:42:13 --> Loader Class Initialized
INFO - 2016-02-09 07:42:13 --> Helper loaded: url_helper
INFO - 2016-02-09 07:42:13 --> Helper loaded: file_helper
INFO - 2016-02-09 07:42:13 --> Helper loaded: date_helper
INFO - 2016-02-09 07:42:13 --> Helper loaded: form_helper
INFO - 2016-02-09 07:42:13 --> Database Driver Class Initialized
INFO - 2016-02-09 07:42:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:42:14 --> Controller Class Initialized
INFO - 2016-02-09 07:42:14 --> Model Class Initialized
INFO - 2016-02-09 07:42:14 --> Model Class Initialized
INFO - 2016-02-09 07:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:42:14 --> Pagination Class Initialized
INFO - 2016-02-09 10:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 10:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 10:42:14 --> Helper loaded: text_helper
INFO - 2016-02-09 10:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 10:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 10:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 10:42:14 --> Final output sent to browser
DEBUG - 2016-02-09 10:42:14 --> Total execution time: 1.2586
INFO - 2016-02-09 07:42:19 --> Config Class Initialized
INFO - 2016-02-09 07:42:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:42:19 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:42:19 --> Utf8 Class Initialized
INFO - 2016-02-09 07:42:19 --> URI Class Initialized
INFO - 2016-02-09 07:42:19 --> Router Class Initialized
INFO - 2016-02-09 07:42:19 --> Output Class Initialized
INFO - 2016-02-09 07:42:19 --> Security Class Initialized
DEBUG - 2016-02-09 07:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:42:19 --> Input Class Initialized
INFO - 2016-02-09 07:42:19 --> Language Class Initialized
INFO - 2016-02-09 07:42:19 --> Loader Class Initialized
INFO - 2016-02-09 07:42:19 --> Helper loaded: url_helper
INFO - 2016-02-09 07:42:19 --> Helper loaded: file_helper
INFO - 2016-02-09 07:42:19 --> Helper loaded: date_helper
INFO - 2016-02-09 07:42:19 --> Helper loaded: form_helper
INFO - 2016-02-09 07:42:19 --> Database Driver Class Initialized
INFO - 2016-02-09 07:42:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:42:20 --> Controller Class Initialized
INFO - 2016-02-09 07:42:20 --> Model Class Initialized
INFO - 2016-02-09 07:42:20 --> Model Class Initialized
INFO - 2016-02-09 07:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:42:20 --> Pagination Class Initialized
INFO - 2016-02-09 10:42:20 --> Form Validation Class Initialized
INFO - 2016-02-09 10:42:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 10:42:20 --> Model Class Initialized
INFO - 2016-02-09 10:42:20 --> Final output sent to browser
DEBUG - 2016-02-09 10:42:20 --> Total execution time: 1.2511
INFO - 2016-02-09 07:42:27 --> Config Class Initialized
INFO - 2016-02-09 07:42:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:42:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:42:27 --> Utf8 Class Initialized
INFO - 2016-02-09 07:42:27 --> URI Class Initialized
INFO - 2016-02-09 07:42:27 --> Router Class Initialized
INFO - 2016-02-09 07:42:27 --> Output Class Initialized
INFO - 2016-02-09 07:42:27 --> Security Class Initialized
DEBUG - 2016-02-09 07:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:42:27 --> Input Class Initialized
INFO - 2016-02-09 07:42:27 --> Language Class Initialized
INFO - 2016-02-09 07:42:27 --> Loader Class Initialized
INFO - 2016-02-09 07:42:27 --> Helper loaded: url_helper
INFO - 2016-02-09 07:42:27 --> Helper loaded: file_helper
INFO - 2016-02-09 07:42:27 --> Helper loaded: date_helper
INFO - 2016-02-09 07:42:27 --> Helper loaded: form_helper
INFO - 2016-02-09 07:42:27 --> Database Driver Class Initialized
INFO - 2016-02-09 07:42:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:42:28 --> Controller Class Initialized
INFO - 2016-02-09 07:42:28 --> Model Class Initialized
INFO - 2016-02-09 07:42:28 --> Model Class Initialized
INFO - 2016-02-09 07:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:42:28 --> Pagination Class Initialized
INFO - 2016-02-09 10:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 10:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 10:42:28 --> Helper loaded: text_helper
INFO - 2016-02-09 10:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 10:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 10:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 10:42:28 --> Final output sent to browser
DEBUG - 2016-02-09 10:42:28 --> Total execution time: 1.1714
INFO - 2016-02-09 07:43:27 --> Config Class Initialized
INFO - 2016-02-09 07:43:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:43:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:43:27 --> Utf8 Class Initialized
INFO - 2016-02-09 07:43:27 --> URI Class Initialized
DEBUG - 2016-02-09 07:43:27 --> No URI present. Default controller set.
INFO - 2016-02-09 07:43:27 --> Router Class Initialized
INFO - 2016-02-09 07:43:27 --> Output Class Initialized
INFO - 2016-02-09 07:43:27 --> Security Class Initialized
DEBUG - 2016-02-09 07:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:43:27 --> Input Class Initialized
INFO - 2016-02-09 07:43:27 --> Language Class Initialized
INFO - 2016-02-09 07:43:27 --> Loader Class Initialized
INFO - 2016-02-09 07:43:27 --> Helper loaded: url_helper
INFO - 2016-02-09 07:43:27 --> Helper loaded: file_helper
INFO - 2016-02-09 07:43:27 --> Helper loaded: date_helper
INFO - 2016-02-09 07:43:27 --> Helper loaded: form_helper
INFO - 2016-02-09 07:43:27 --> Database Driver Class Initialized
INFO - 2016-02-09 07:43:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:43:28 --> Controller Class Initialized
INFO - 2016-02-09 07:43:28 --> Model Class Initialized
INFO - 2016-02-09 07:43:28 --> Model Class Initialized
INFO - 2016-02-09 07:43:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:43:28 --> Pagination Class Initialized
INFO - 2016-02-09 10:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 10:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 10:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 10:43:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 10:43:28 --> Final output sent to browser
DEBUG - 2016-02-09 10:43:28 --> Total execution time: 1.1477
INFO - 2016-02-09 07:50:47 --> Config Class Initialized
INFO - 2016-02-09 07:50:47 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:50:47 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:50:47 --> Utf8 Class Initialized
INFO - 2016-02-09 07:50:47 --> URI Class Initialized
INFO - 2016-02-09 07:50:47 --> Router Class Initialized
INFO - 2016-02-09 07:50:47 --> Output Class Initialized
INFO - 2016-02-09 07:50:47 --> Security Class Initialized
DEBUG - 2016-02-09 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:50:47 --> Input Class Initialized
INFO - 2016-02-09 07:50:47 --> Language Class Initialized
INFO - 2016-02-09 07:50:47 --> Loader Class Initialized
INFO - 2016-02-09 07:50:47 --> Helper loaded: url_helper
INFO - 2016-02-09 07:50:47 --> Helper loaded: file_helper
INFO - 2016-02-09 07:50:47 --> Helper loaded: date_helper
INFO - 2016-02-09 07:50:47 --> Helper loaded: form_helper
INFO - 2016-02-09 07:50:47 --> Database Driver Class Initialized
INFO - 2016-02-09 07:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:50:48 --> Controller Class Initialized
INFO - 2016-02-09 07:50:48 --> Model Class Initialized
INFO - 2016-02-09 07:50:48 --> Model Class Initialized
INFO - 2016-02-09 07:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:50:48 --> Pagination Class Initialized
INFO - 2016-02-09 10:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 10:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 10:50:48 --> Helper loaded: text_helper
INFO - 2016-02-09 10:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 10:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 10:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 10:50:48 --> Final output sent to browser
DEBUG - 2016-02-09 10:50:48 --> Total execution time: 1.1713
INFO - 2016-02-09 07:50:59 --> Config Class Initialized
INFO - 2016-02-09 07:50:59 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:50:59 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:50:59 --> Utf8 Class Initialized
INFO - 2016-02-09 07:50:59 --> URI Class Initialized
INFO - 2016-02-09 07:50:59 --> Router Class Initialized
INFO - 2016-02-09 07:50:59 --> Output Class Initialized
INFO - 2016-02-09 07:50:59 --> Security Class Initialized
DEBUG - 2016-02-09 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:50:59 --> Input Class Initialized
INFO - 2016-02-09 07:50:59 --> Language Class Initialized
INFO - 2016-02-09 07:50:59 --> Loader Class Initialized
INFO - 2016-02-09 07:50:59 --> Helper loaded: url_helper
INFO - 2016-02-09 07:50:59 --> Helper loaded: file_helper
INFO - 2016-02-09 07:50:59 --> Helper loaded: date_helper
INFO - 2016-02-09 07:50:59 --> Helper loaded: form_helper
INFO - 2016-02-09 07:50:59 --> Database Driver Class Initialized
INFO - 2016-02-09 07:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:51:00 --> Controller Class Initialized
INFO - 2016-02-09 07:51:00 --> Model Class Initialized
INFO - 2016-02-09 07:51:00 --> Model Class Initialized
INFO - 2016-02-09 07:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:51:00 --> Pagination Class Initialized
INFO - 2016-02-09 10:51:00 --> Form Validation Class Initialized
INFO - 2016-02-09 10:51:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 10:51:00 --> Model Class Initialized
INFO - 2016-02-09 10:51:00 --> Final output sent to browser
DEBUG - 2016-02-09 10:51:00 --> Total execution time: 1.2052
INFO - 2016-02-09 07:57:55 --> Config Class Initialized
INFO - 2016-02-09 07:57:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 07:57:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 07:57:55 --> Utf8 Class Initialized
INFO - 2016-02-09 07:57:55 --> URI Class Initialized
INFO - 2016-02-09 07:57:55 --> Router Class Initialized
INFO - 2016-02-09 07:57:55 --> Output Class Initialized
INFO - 2016-02-09 07:57:55 --> Security Class Initialized
DEBUG - 2016-02-09 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 07:57:55 --> Input Class Initialized
INFO - 2016-02-09 07:57:55 --> Language Class Initialized
INFO - 2016-02-09 07:57:55 --> Loader Class Initialized
INFO - 2016-02-09 07:57:55 --> Helper loaded: url_helper
INFO - 2016-02-09 07:57:55 --> Helper loaded: file_helper
INFO - 2016-02-09 07:57:55 --> Helper loaded: date_helper
INFO - 2016-02-09 07:57:55 --> Helper loaded: form_helper
INFO - 2016-02-09 07:57:55 --> Database Driver Class Initialized
INFO - 2016-02-09 07:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 07:57:56 --> Controller Class Initialized
INFO - 2016-02-09 07:57:56 --> Model Class Initialized
INFO - 2016-02-09 07:57:56 --> Model Class Initialized
INFO - 2016-02-09 07:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 07:57:56 --> Pagination Class Initialized
INFO - 2016-02-09 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 10:57:56 --> Helper loaded: text_helper
INFO - 2016-02-09 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 10:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 10:57:56 --> Final output sent to browser
DEBUG - 2016-02-09 10:57:56 --> Total execution time: 1.2276
INFO - 2016-02-09 08:06:13 --> Config Class Initialized
INFO - 2016-02-09 08:06:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:06:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:06:13 --> Utf8 Class Initialized
INFO - 2016-02-09 08:06:13 --> URI Class Initialized
DEBUG - 2016-02-09 08:06:13 --> No URI present. Default controller set.
INFO - 2016-02-09 08:06:13 --> Router Class Initialized
INFO - 2016-02-09 08:06:13 --> Output Class Initialized
INFO - 2016-02-09 08:06:13 --> Security Class Initialized
DEBUG - 2016-02-09 08:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:06:13 --> Input Class Initialized
INFO - 2016-02-09 08:06:13 --> Language Class Initialized
INFO - 2016-02-09 08:06:13 --> Loader Class Initialized
INFO - 2016-02-09 08:06:13 --> Helper loaded: url_helper
INFO - 2016-02-09 08:06:13 --> Helper loaded: file_helper
INFO - 2016-02-09 08:06:13 --> Helper loaded: date_helper
INFO - 2016-02-09 08:06:13 --> Helper loaded: form_helper
INFO - 2016-02-09 08:06:13 --> Database Driver Class Initialized
INFO - 2016-02-09 08:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:06:14 --> Controller Class Initialized
INFO - 2016-02-09 08:06:14 --> Model Class Initialized
INFO - 2016-02-09 08:06:14 --> Model Class Initialized
INFO - 2016-02-09 08:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:06:14 --> Pagination Class Initialized
INFO - 2016-02-09 11:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:06:14 --> Final output sent to browser
DEBUG - 2016-02-09 11:06:14 --> Total execution time: 1.1164
INFO - 2016-02-09 08:08:19 --> Config Class Initialized
INFO - 2016-02-09 08:08:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:08:19 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:08:19 --> Utf8 Class Initialized
INFO - 2016-02-09 08:08:19 --> URI Class Initialized
DEBUG - 2016-02-09 08:08:19 --> No URI present. Default controller set.
INFO - 2016-02-09 08:08:19 --> Router Class Initialized
INFO - 2016-02-09 08:08:19 --> Output Class Initialized
INFO - 2016-02-09 08:08:19 --> Security Class Initialized
DEBUG - 2016-02-09 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:08:19 --> Input Class Initialized
INFO - 2016-02-09 08:08:19 --> Language Class Initialized
INFO - 2016-02-09 08:08:19 --> Loader Class Initialized
INFO - 2016-02-09 08:08:19 --> Helper loaded: url_helper
INFO - 2016-02-09 08:08:19 --> Helper loaded: file_helper
INFO - 2016-02-09 08:08:19 --> Helper loaded: date_helper
INFO - 2016-02-09 08:08:19 --> Helper loaded: form_helper
INFO - 2016-02-09 08:08:19 --> Database Driver Class Initialized
INFO - 2016-02-09 08:08:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:08:20 --> Controller Class Initialized
INFO - 2016-02-09 08:08:20 --> Model Class Initialized
INFO - 2016-02-09 08:08:20 --> Model Class Initialized
INFO - 2016-02-09 08:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:08:20 --> Pagination Class Initialized
INFO - 2016-02-09 11:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:08:20 --> Final output sent to browser
DEBUG - 2016-02-09 11:08:20 --> Total execution time: 1.1408
INFO - 2016-02-09 08:08:32 --> Config Class Initialized
INFO - 2016-02-09 08:08:32 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:08:32 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:08:32 --> Utf8 Class Initialized
INFO - 2016-02-09 08:08:32 --> URI Class Initialized
INFO - 2016-02-09 08:08:32 --> Router Class Initialized
INFO - 2016-02-09 08:08:32 --> Output Class Initialized
INFO - 2016-02-09 08:08:32 --> Security Class Initialized
DEBUG - 2016-02-09 08:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:08:32 --> Input Class Initialized
INFO - 2016-02-09 08:08:32 --> Language Class Initialized
INFO - 2016-02-09 08:08:32 --> Loader Class Initialized
INFO - 2016-02-09 08:08:32 --> Helper loaded: url_helper
INFO - 2016-02-09 08:08:32 --> Helper loaded: file_helper
INFO - 2016-02-09 08:08:32 --> Helper loaded: date_helper
INFO - 2016-02-09 08:08:32 --> Helper loaded: form_helper
INFO - 2016-02-09 08:08:32 --> Database Driver Class Initialized
INFO - 2016-02-09 08:08:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:08:33 --> Controller Class Initialized
INFO - 2016-02-09 08:08:33 --> Model Class Initialized
INFO - 2016-02-09 08:08:33 --> Model Class Initialized
INFO - 2016-02-09 08:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:08:33 --> Pagination Class Initialized
INFO - 2016-02-09 11:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:08:33 --> Final output sent to browser
DEBUG - 2016-02-09 11:08:33 --> Total execution time: 1.1369
INFO - 2016-02-09 08:08:53 --> Config Class Initialized
INFO - 2016-02-09 08:08:53 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:08:53 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:08:53 --> Utf8 Class Initialized
INFO - 2016-02-09 08:08:53 --> URI Class Initialized
DEBUG - 2016-02-09 08:08:53 --> No URI present. Default controller set.
INFO - 2016-02-09 08:08:53 --> Router Class Initialized
INFO - 2016-02-09 08:08:53 --> Output Class Initialized
INFO - 2016-02-09 08:08:53 --> Security Class Initialized
DEBUG - 2016-02-09 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:08:53 --> Input Class Initialized
INFO - 2016-02-09 08:08:53 --> Language Class Initialized
INFO - 2016-02-09 08:08:53 --> Loader Class Initialized
INFO - 2016-02-09 08:08:53 --> Helper loaded: url_helper
INFO - 2016-02-09 08:08:53 --> Helper loaded: file_helper
INFO - 2016-02-09 08:08:53 --> Helper loaded: date_helper
INFO - 2016-02-09 08:08:53 --> Helper loaded: form_helper
INFO - 2016-02-09 08:08:53 --> Database Driver Class Initialized
INFO - 2016-02-09 08:08:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:08:54 --> Controller Class Initialized
INFO - 2016-02-09 08:08:54 --> Model Class Initialized
INFO - 2016-02-09 08:08:54 --> Model Class Initialized
INFO - 2016-02-09 08:08:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:08:54 --> Pagination Class Initialized
INFO - 2016-02-09 11:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:08:54 --> Final output sent to browser
DEBUG - 2016-02-09 11:08:54 --> Total execution time: 1.1191
INFO - 2016-02-09 08:09:15 --> Config Class Initialized
INFO - 2016-02-09 08:09:15 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:09:15 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:09:15 --> Utf8 Class Initialized
INFO - 2016-02-09 08:09:15 --> URI Class Initialized
DEBUG - 2016-02-09 08:09:15 --> No URI present. Default controller set.
INFO - 2016-02-09 08:09:15 --> Router Class Initialized
INFO - 2016-02-09 08:09:15 --> Output Class Initialized
INFO - 2016-02-09 08:09:15 --> Security Class Initialized
DEBUG - 2016-02-09 08:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:09:15 --> Input Class Initialized
INFO - 2016-02-09 08:09:15 --> Language Class Initialized
INFO - 2016-02-09 08:09:15 --> Loader Class Initialized
INFO - 2016-02-09 08:09:15 --> Helper loaded: url_helper
INFO - 2016-02-09 08:09:15 --> Helper loaded: file_helper
INFO - 2016-02-09 08:09:15 --> Helper loaded: date_helper
INFO - 2016-02-09 08:09:15 --> Helper loaded: form_helper
INFO - 2016-02-09 08:09:15 --> Database Driver Class Initialized
INFO - 2016-02-09 08:09:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:09:16 --> Controller Class Initialized
INFO - 2016-02-09 08:09:16 --> Model Class Initialized
INFO - 2016-02-09 08:09:16 --> Model Class Initialized
INFO - 2016-02-09 08:09:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:09:16 --> Pagination Class Initialized
INFO - 2016-02-09 11:09:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:09:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:09:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:09:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:09:16 --> Final output sent to browser
DEBUG - 2016-02-09 11:09:16 --> Total execution time: 1.1378
INFO - 2016-02-09 08:09:52 --> Config Class Initialized
INFO - 2016-02-09 08:09:52 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:09:52 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:09:52 --> Utf8 Class Initialized
INFO - 2016-02-09 08:09:52 --> URI Class Initialized
DEBUG - 2016-02-09 08:09:52 --> No URI present. Default controller set.
INFO - 2016-02-09 08:09:52 --> Router Class Initialized
INFO - 2016-02-09 08:09:52 --> Output Class Initialized
INFO - 2016-02-09 08:09:52 --> Security Class Initialized
DEBUG - 2016-02-09 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:09:52 --> Input Class Initialized
INFO - 2016-02-09 08:09:52 --> Language Class Initialized
INFO - 2016-02-09 08:09:52 --> Loader Class Initialized
INFO - 2016-02-09 08:09:52 --> Helper loaded: url_helper
INFO - 2016-02-09 08:09:52 --> Helper loaded: file_helper
INFO - 2016-02-09 08:09:52 --> Helper loaded: date_helper
INFO - 2016-02-09 08:09:52 --> Helper loaded: form_helper
INFO - 2016-02-09 08:09:52 --> Database Driver Class Initialized
INFO - 2016-02-09 08:09:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:09:53 --> Controller Class Initialized
INFO - 2016-02-09 08:09:53 --> Model Class Initialized
INFO - 2016-02-09 08:09:53 --> Model Class Initialized
INFO - 2016-02-09 08:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:09:53 --> Pagination Class Initialized
INFO - 2016-02-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:09:53 --> Final output sent to browser
DEBUG - 2016-02-09 11:09:53 --> Total execution time: 1.1615
INFO - 2016-02-09 08:11:22 --> Config Class Initialized
INFO - 2016-02-09 08:11:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:11:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:11:22 --> Utf8 Class Initialized
INFO - 2016-02-09 08:11:22 --> URI Class Initialized
DEBUG - 2016-02-09 08:11:22 --> No URI present. Default controller set.
INFO - 2016-02-09 08:11:22 --> Router Class Initialized
INFO - 2016-02-09 08:11:22 --> Output Class Initialized
INFO - 2016-02-09 08:11:22 --> Security Class Initialized
DEBUG - 2016-02-09 08:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:11:22 --> Input Class Initialized
INFO - 2016-02-09 08:11:22 --> Language Class Initialized
INFO - 2016-02-09 08:11:22 --> Loader Class Initialized
INFO - 2016-02-09 08:11:22 --> Helper loaded: url_helper
INFO - 2016-02-09 08:11:22 --> Helper loaded: file_helper
INFO - 2016-02-09 08:11:22 --> Helper loaded: date_helper
INFO - 2016-02-09 08:11:22 --> Helper loaded: form_helper
INFO - 2016-02-09 08:11:22 --> Database Driver Class Initialized
INFO - 2016-02-09 08:11:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:11:23 --> Controller Class Initialized
INFO - 2016-02-09 08:11:23 --> Model Class Initialized
INFO - 2016-02-09 08:11:23 --> Model Class Initialized
INFO - 2016-02-09 08:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:11:23 --> Pagination Class Initialized
INFO - 2016-02-09 11:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:11:23 --> Final output sent to browser
DEBUG - 2016-02-09 11:11:23 --> Total execution time: 1.1238
INFO - 2016-02-09 08:13:05 --> Config Class Initialized
INFO - 2016-02-09 08:13:05 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:05 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:05 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:05 --> URI Class Initialized
INFO - 2016-02-09 08:13:05 --> Router Class Initialized
INFO - 2016-02-09 08:13:05 --> Output Class Initialized
INFO - 2016-02-09 08:13:05 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:05 --> Input Class Initialized
INFO - 2016-02-09 08:13:05 --> Language Class Initialized
INFO - 2016-02-09 08:13:05 --> Loader Class Initialized
INFO - 2016-02-09 08:13:05 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:05 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:05 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:05 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:05 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:06 --> Controller Class Initialized
INFO - 2016-02-09 08:13:06 --> Model Class Initialized
INFO - 2016-02-09 08:13:06 --> Model Class Initialized
INFO - 2016-02-09 08:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:13:06 --> Pagination Class Initialized
INFO - 2016-02-09 11:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:13:06 --> Helper loaded: text_helper
INFO - 2016-02-09 11:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:13:06 --> Final output sent to browser
DEBUG - 2016-02-09 11:13:06 --> Total execution time: 1.1331
INFO - 2016-02-09 08:13:20 --> Config Class Initialized
INFO - 2016-02-09 08:13:20 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:20 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:20 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:20 --> URI Class Initialized
INFO - 2016-02-09 08:13:20 --> Router Class Initialized
INFO - 2016-02-09 08:13:20 --> Output Class Initialized
INFO - 2016-02-09 08:13:20 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:20 --> Input Class Initialized
INFO - 2016-02-09 08:13:20 --> Language Class Initialized
INFO - 2016-02-09 08:13:20 --> Loader Class Initialized
INFO - 2016-02-09 08:13:20 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:20 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:20 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:20 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:20 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:21 --> Controller Class Initialized
INFO - 2016-02-09 08:13:21 --> Model Class Initialized
INFO - 2016-02-09 08:13:21 --> Model Class Initialized
INFO - 2016-02-09 08:13:21 --> Form Validation Class Initialized
INFO - 2016-02-09 08:13:21 --> Helper loaded: text_helper
INFO - 2016-02-09 08:13:21 --> Config Class Initialized
INFO - 2016-02-09 08:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:21 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:21 --> URI Class Initialized
INFO - 2016-02-09 08:13:21 --> Router Class Initialized
INFO - 2016-02-09 08:13:21 --> Output Class Initialized
INFO - 2016-02-09 08:13:21 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:21 --> Input Class Initialized
INFO - 2016-02-09 08:13:21 --> Language Class Initialized
INFO - 2016-02-09 08:13:21 --> Loader Class Initialized
INFO - 2016-02-09 08:13:21 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:21 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:21 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:21 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:21 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:22 --> Controller Class Initialized
INFO - 2016-02-09 08:13:22 --> Model Class Initialized
INFO - 2016-02-09 08:13:22 --> Model Class Initialized
INFO - 2016-02-09 08:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:13:22 --> Pagination Class Initialized
INFO - 2016-02-09 11:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:13:22 --> Final output sent to browser
DEBUG - 2016-02-09 11:13:22 --> Total execution time: 1.1719
INFO - 2016-02-09 08:13:24 --> Config Class Initialized
INFO - 2016-02-09 08:13:24 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:24 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:24 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:24 --> URI Class Initialized
INFO - 2016-02-09 08:13:24 --> Router Class Initialized
INFO - 2016-02-09 08:13:24 --> Output Class Initialized
INFO - 2016-02-09 08:13:24 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:24 --> Input Class Initialized
INFO - 2016-02-09 08:13:24 --> Language Class Initialized
INFO - 2016-02-09 08:13:24 --> Loader Class Initialized
INFO - 2016-02-09 08:13:24 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:24 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:24 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:24 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:24 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:25 --> Controller Class Initialized
INFO - 2016-02-09 08:13:25 --> Model Class Initialized
INFO - 2016-02-09 08:13:25 --> Model Class Initialized
INFO - 2016-02-09 08:13:25 --> Form Validation Class Initialized
INFO - 2016-02-09 08:13:25 --> Helper loaded: text_helper
INFO - 2016-02-09 08:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 08:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 08:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-09 08:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 08:13:25 --> Final output sent to browser
DEBUG - 2016-02-09 08:13:25 --> Total execution time: 1.1206
INFO - 2016-02-09 08:13:38 --> Config Class Initialized
INFO - 2016-02-09 08:13:38 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:38 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:38 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:38 --> URI Class Initialized
INFO - 2016-02-09 08:13:38 --> Router Class Initialized
INFO - 2016-02-09 08:13:38 --> Output Class Initialized
INFO - 2016-02-09 08:13:38 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:38 --> Input Class Initialized
INFO - 2016-02-09 08:13:38 --> Language Class Initialized
INFO - 2016-02-09 08:13:38 --> Loader Class Initialized
INFO - 2016-02-09 08:13:38 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:38 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:38 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:38 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:38 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:39 --> Controller Class Initialized
INFO - 2016-02-09 08:13:39 --> Model Class Initialized
INFO - 2016-02-09 08:13:39 --> Model Class Initialized
INFO - 2016-02-09 08:13:39 --> Form Validation Class Initialized
INFO - 2016-02-09 08:13:39 --> Helper loaded: text_helper
INFO - 2016-02-09 08:13:39 --> Config Class Initialized
INFO - 2016-02-09 08:13:39 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:39 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:39 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:39 --> URI Class Initialized
INFO - 2016-02-09 08:13:39 --> Router Class Initialized
INFO - 2016-02-09 08:13:39 --> Output Class Initialized
INFO - 2016-02-09 08:13:39 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:39 --> Input Class Initialized
INFO - 2016-02-09 08:13:39 --> Language Class Initialized
INFO - 2016-02-09 08:13:39 --> Loader Class Initialized
INFO - 2016-02-09 08:13:39 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:39 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:39 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:39 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:39 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:40 --> Controller Class Initialized
INFO - 2016-02-09 08:13:40 --> Model Class Initialized
INFO - 2016-02-09 08:13:40 --> Model Class Initialized
INFO - 2016-02-09 08:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:13:40 --> Pagination Class Initialized
INFO - 2016-02-09 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 11:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:13:40 --> Final output sent to browser
DEBUG - 2016-02-09 11:13:40 --> Total execution time: 1.1399
INFO - 2016-02-09 08:13:45 --> Config Class Initialized
INFO - 2016-02-09 08:13:45 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:13:45 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:13:45 --> Utf8 Class Initialized
INFO - 2016-02-09 08:13:45 --> URI Class Initialized
INFO - 2016-02-09 08:13:45 --> Router Class Initialized
INFO - 2016-02-09 08:13:45 --> Output Class Initialized
INFO - 2016-02-09 08:13:45 --> Security Class Initialized
DEBUG - 2016-02-09 08:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:13:45 --> Input Class Initialized
INFO - 2016-02-09 08:13:45 --> Language Class Initialized
INFO - 2016-02-09 08:13:45 --> Loader Class Initialized
INFO - 2016-02-09 08:13:45 --> Helper loaded: url_helper
INFO - 2016-02-09 08:13:45 --> Helper loaded: file_helper
INFO - 2016-02-09 08:13:45 --> Helper loaded: date_helper
INFO - 2016-02-09 08:13:45 --> Helper loaded: form_helper
INFO - 2016-02-09 08:13:45 --> Database Driver Class Initialized
INFO - 2016-02-09 08:13:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:13:46 --> Controller Class Initialized
INFO - 2016-02-09 08:13:46 --> Model Class Initialized
INFO - 2016-02-09 08:13:46 --> Model Class Initialized
INFO - 2016-02-09 08:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:13:46 --> Pagination Class Initialized
INFO - 2016-02-09 11:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:13:46 --> Helper loaded: text_helper
INFO - 2016-02-09 11:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:13:47 --> Final output sent to browser
DEBUG - 2016-02-09 11:13:47 --> Total execution time: 1.2415
INFO - 2016-02-09 08:14:54 --> Config Class Initialized
INFO - 2016-02-09 08:14:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:14:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:14:54 --> Utf8 Class Initialized
INFO - 2016-02-09 08:14:54 --> URI Class Initialized
INFO - 2016-02-09 08:14:54 --> Router Class Initialized
INFO - 2016-02-09 08:14:54 --> Output Class Initialized
INFO - 2016-02-09 08:14:54 --> Security Class Initialized
DEBUG - 2016-02-09 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:14:54 --> Input Class Initialized
INFO - 2016-02-09 08:14:54 --> Language Class Initialized
INFO - 2016-02-09 08:14:54 --> Loader Class Initialized
INFO - 2016-02-09 08:14:54 --> Helper loaded: url_helper
INFO - 2016-02-09 08:14:54 --> Helper loaded: file_helper
INFO - 2016-02-09 08:14:54 --> Helper loaded: date_helper
INFO - 2016-02-09 08:14:54 --> Helper loaded: form_helper
INFO - 2016-02-09 08:14:54 --> Database Driver Class Initialized
INFO - 2016-02-09 08:14:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:14:55 --> Controller Class Initialized
INFO - 2016-02-09 08:14:55 --> Model Class Initialized
INFO - 2016-02-09 08:14:55 --> Model Class Initialized
INFO - 2016-02-09 08:14:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:14:55 --> Pagination Class Initialized
INFO - 2016-02-09 11:14:55 --> Form Validation Class Initialized
INFO - 2016-02-09 11:14:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:14:55 --> Model Class Initialized
INFO - 2016-02-09 11:14:55 --> Final output sent to browser
DEBUG - 2016-02-09 11:14:55 --> Total execution time: 1.1829
INFO - 2016-02-09 08:15:43 --> Config Class Initialized
INFO - 2016-02-09 08:15:43 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:15:44 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:15:44 --> Utf8 Class Initialized
INFO - 2016-02-09 08:15:44 --> URI Class Initialized
INFO - 2016-02-09 08:15:44 --> Router Class Initialized
INFO - 2016-02-09 08:15:44 --> Output Class Initialized
INFO - 2016-02-09 08:15:44 --> Security Class Initialized
DEBUG - 2016-02-09 08:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:15:44 --> Input Class Initialized
INFO - 2016-02-09 08:15:44 --> Language Class Initialized
INFO - 2016-02-09 08:15:44 --> Loader Class Initialized
INFO - 2016-02-09 08:15:44 --> Helper loaded: url_helper
INFO - 2016-02-09 08:15:44 --> Helper loaded: file_helper
INFO - 2016-02-09 08:15:44 --> Helper loaded: date_helper
INFO - 2016-02-09 08:15:44 --> Helper loaded: form_helper
INFO - 2016-02-09 08:15:44 --> Database Driver Class Initialized
INFO - 2016-02-09 08:15:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:15:45 --> Controller Class Initialized
INFO - 2016-02-09 08:15:45 --> Model Class Initialized
INFO - 2016-02-09 08:15:45 --> Model Class Initialized
INFO - 2016-02-09 08:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:15:45 --> Pagination Class Initialized
INFO - 2016-02-09 11:15:45 --> Form Validation Class Initialized
INFO - 2016-02-09 11:15:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:15:45 --> Model Class Initialized
INFO - 2016-02-09 11:15:45 --> Final output sent to browser
DEBUG - 2016-02-09 11:15:45 --> Total execution time: 1.1855
INFO - 2016-02-09 08:17:50 --> Config Class Initialized
INFO - 2016-02-09 08:17:50 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:17:50 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:17:50 --> Utf8 Class Initialized
INFO - 2016-02-09 08:17:50 --> URI Class Initialized
INFO - 2016-02-09 08:17:50 --> Router Class Initialized
INFO - 2016-02-09 08:17:50 --> Output Class Initialized
INFO - 2016-02-09 08:17:50 --> Security Class Initialized
DEBUG - 2016-02-09 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:17:50 --> Input Class Initialized
INFO - 2016-02-09 08:17:50 --> Language Class Initialized
INFO - 2016-02-09 08:17:50 --> Loader Class Initialized
INFO - 2016-02-09 08:17:50 --> Helper loaded: url_helper
INFO - 2016-02-09 08:17:50 --> Helper loaded: file_helper
INFO - 2016-02-09 08:17:50 --> Helper loaded: date_helper
INFO - 2016-02-09 08:17:50 --> Helper loaded: form_helper
INFO - 2016-02-09 08:17:50 --> Database Driver Class Initialized
INFO - 2016-02-09 08:17:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:17:51 --> Controller Class Initialized
INFO - 2016-02-09 08:17:51 --> Model Class Initialized
INFO - 2016-02-09 08:17:51 --> Model Class Initialized
INFO - 2016-02-09 08:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:17:51 --> Pagination Class Initialized
INFO - 2016-02-09 11:17:52 --> Form Validation Class Initialized
INFO - 2016-02-09 11:17:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:17:52 --> Model Class Initialized
INFO - 2016-02-09 11:17:52 --> Final output sent to browser
DEBUG - 2016-02-09 11:17:52 --> Total execution time: 1.3788
INFO - 2016-02-09 08:33:27 --> Config Class Initialized
INFO - 2016-02-09 08:33:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:33:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:33:27 --> Utf8 Class Initialized
INFO - 2016-02-09 08:33:27 --> URI Class Initialized
INFO - 2016-02-09 08:33:27 --> Router Class Initialized
INFO - 2016-02-09 08:33:27 --> Output Class Initialized
INFO - 2016-02-09 08:33:27 --> Security Class Initialized
DEBUG - 2016-02-09 08:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:33:27 --> Input Class Initialized
INFO - 2016-02-09 08:33:27 --> Language Class Initialized
INFO - 2016-02-09 08:33:27 --> Loader Class Initialized
INFO - 2016-02-09 08:33:27 --> Helper loaded: url_helper
INFO - 2016-02-09 08:33:27 --> Helper loaded: file_helper
INFO - 2016-02-09 08:33:27 --> Helper loaded: date_helper
INFO - 2016-02-09 08:33:27 --> Helper loaded: form_helper
INFO - 2016-02-09 08:33:27 --> Database Driver Class Initialized
INFO - 2016-02-09 08:33:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:33:28 --> Controller Class Initialized
INFO - 2016-02-09 08:33:28 --> Model Class Initialized
INFO - 2016-02-09 08:33:28 --> Model Class Initialized
INFO - 2016-02-09 08:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:33:28 --> Pagination Class Initialized
INFO - 2016-02-09 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:33:28 --> Helper loaded: text_helper
INFO - 2016-02-09 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:33:28 --> Final output sent to browser
DEBUG - 2016-02-09 11:33:28 --> Total execution time: 1.2246
INFO - 2016-02-09 08:33:49 --> Config Class Initialized
INFO - 2016-02-09 08:33:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:33:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:33:49 --> Utf8 Class Initialized
INFO - 2016-02-09 08:33:49 --> URI Class Initialized
INFO - 2016-02-09 08:33:49 --> Router Class Initialized
INFO - 2016-02-09 08:33:49 --> Output Class Initialized
INFO - 2016-02-09 08:33:49 --> Security Class Initialized
DEBUG - 2016-02-09 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:33:49 --> Input Class Initialized
INFO - 2016-02-09 08:33:49 --> Language Class Initialized
INFO - 2016-02-09 08:33:49 --> Loader Class Initialized
INFO - 2016-02-09 08:33:49 --> Helper loaded: url_helper
INFO - 2016-02-09 08:33:49 --> Helper loaded: file_helper
INFO - 2016-02-09 08:33:49 --> Helper loaded: date_helper
INFO - 2016-02-09 08:33:49 --> Helper loaded: form_helper
INFO - 2016-02-09 08:33:49 --> Database Driver Class Initialized
INFO - 2016-02-09 08:33:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:33:50 --> Controller Class Initialized
INFO - 2016-02-09 08:33:50 --> Model Class Initialized
INFO - 2016-02-09 08:33:50 --> Model Class Initialized
INFO - 2016-02-09 08:33:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:33:50 --> Pagination Class Initialized
INFO - 2016-02-09 11:33:50 --> Form Validation Class Initialized
INFO - 2016-02-09 11:33:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:33:50 --> Model Class Initialized
INFO - 2016-02-09 11:33:50 --> Final output sent to browser
DEBUG - 2016-02-09 11:33:50 --> Total execution time: 1.2141
INFO - 2016-02-09 08:34:26 --> Config Class Initialized
INFO - 2016-02-09 08:34:26 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:34:26 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:34:26 --> Utf8 Class Initialized
INFO - 2016-02-09 08:34:26 --> URI Class Initialized
INFO - 2016-02-09 08:34:26 --> Router Class Initialized
INFO - 2016-02-09 08:34:26 --> Output Class Initialized
INFO - 2016-02-09 08:34:26 --> Security Class Initialized
DEBUG - 2016-02-09 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:34:26 --> Input Class Initialized
INFO - 2016-02-09 08:34:26 --> Language Class Initialized
INFO - 2016-02-09 08:34:26 --> Loader Class Initialized
INFO - 2016-02-09 08:34:26 --> Helper loaded: url_helper
INFO - 2016-02-09 08:34:26 --> Helper loaded: file_helper
INFO - 2016-02-09 08:34:26 --> Helper loaded: date_helper
INFO - 2016-02-09 08:34:26 --> Helper loaded: form_helper
INFO - 2016-02-09 08:34:26 --> Database Driver Class Initialized
INFO - 2016-02-09 08:34:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:34:27 --> Controller Class Initialized
INFO - 2016-02-09 08:34:27 --> Model Class Initialized
INFO - 2016-02-09 08:34:27 --> Model Class Initialized
INFO - 2016-02-09 08:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:34:27 --> Pagination Class Initialized
INFO - 2016-02-09 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:34:27 --> Helper loaded: text_helper
INFO - 2016-02-09 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:34:27 --> Final output sent to browser
DEBUG - 2016-02-09 11:34:27 --> Total execution time: 1.1995
INFO - 2016-02-09 08:34:38 --> Config Class Initialized
INFO - 2016-02-09 08:34:38 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:34:38 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:34:38 --> Utf8 Class Initialized
INFO - 2016-02-09 08:34:38 --> URI Class Initialized
INFO - 2016-02-09 08:34:38 --> Router Class Initialized
INFO - 2016-02-09 08:34:38 --> Output Class Initialized
INFO - 2016-02-09 08:34:38 --> Security Class Initialized
DEBUG - 2016-02-09 08:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:34:38 --> Input Class Initialized
INFO - 2016-02-09 08:34:38 --> Language Class Initialized
INFO - 2016-02-09 08:34:38 --> Loader Class Initialized
INFO - 2016-02-09 08:34:38 --> Helper loaded: url_helper
INFO - 2016-02-09 08:34:38 --> Helper loaded: file_helper
INFO - 2016-02-09 08:34:38 --> Helper loaded: date_helper
INFO - 2016-02-09 08:34:38 --> Helper loaded: form_helper
INFO - 2016-02-09 08:34:38 --> Database Driver Class Initialized
INFO - 2016-02-09 08:34:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:34:39 --> Controller Class Initialized
INFO - 2016-02-09 08:34:39 --> Model Class Initialized
INFO - 2016-02-09 08:34:39 --> Model Class Initialized
INFO - 2016-02-09 08:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:34:39 --> Pagination Class Initialized
INFO - 2016-02-09 11:34:39 --> Form Validation Class Initialized
INFO - 2016-02-09 11:34:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:34:39 --> Model Class Initialized
INFO - 2016-02-09 11:34:39 --> Final output sent to browser
DEBUG - 2016-02-09 11:34:39 --> Total execution time: 1.1485
INFO - 2016-02-09 08:35:30 --> Config Class Initialized
INFO - 2016-02-09 08:35:30 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:35:30 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:35:30 --> Utf8 Class Initialized
INFO - 2016-02-09 08:35:30 --> URI Class Initialized
INFO - 2016-02-09 08:35:30 --> Router Class Initialized
INFO - 2016-02-09 08:35:30 --> Output Class Initialized
INFO - 2016-02-09 08:35:30 --> Security Class Initialized
DEBUG - 2016-02-09 08:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:35:30 --> Input Class Initialized
INFO - 2016-02-09 08:35:30 --> Language Class Initialized
INFO - 2016-02-09 08:35:30 --> Loader Class Initialized
INFO - 2016-02-09 08:35:30 --> Helper loaded: url_helper
INFO - 2016-02-09 08:35:30 --> Helper loaded: file_helper
INFO - 2016-02-09 08:35:30 --> Helper loaded: date_helper
INFO - 2016-02-09 08:35:30 --> Helper loaded: form_helper
INFO - 2016-02-09 08:35:30 --> Database Driver Class Initialized
INFO - 2016-02-09 08:35:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:35:31 --> Controller Class Initialized
INFO - 2016-02-09 08:35:31 --> Model Class Initialized
INFO - 2016-02-09 08:35:31 --> Model Class Initialized
INFO - 2016-02-09 08:35:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:35:31 --> Pagination Class Initialized
INFO - 2016-02-09 11:35:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:35:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:35:32 --> Helper loaded: text_helper
INFO - 2016-02-09 11:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:35:32 --> Final output sent to browser
DEBUG - 2016-02-09 11:35:32 --> Total execution time: 1.2732
INFO - 2016-02-09 08:35:47 --> Config Class Initialized
INFO - 2016-02-09 08:35:47 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:35:47 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:35:47 --> Utf8 Class Initialized
INFO - 2016-02-09 08:35:47 --> URI Class Initialized
INFO - 2016-02-09 08:35:47 --> Router Class Initialized
INFO - 2016-02-09 08:35:47 --> Output Class Initialized
INFO - 2016-02-09 08:35:47 --> Security Class Initialized
DEBUG - 2016-02-09 08:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:35:47 --> Input Class Initialized
INFO - 2016-02-09 08:35:47 --> Language Class Initialized
INFO - 2016-02-09 08:35:47 --> Loader Class Initialized
INFO - 2016-02-09 08:35:47 --> Helper loaded: url_helper
INFO - 2016-02-09 08:35:47 --> Helper loaded: file_helper
INFO - 2016-02-09 08:35:47 --> Helper loaded: date_helper
INFO - 2016-02-09 08:35:47 --> Helper loaded: form_helper
INFO - 2016-02-09 08:35:47 --> Database Driver Class Initialized
INFO - 2016-02-09 08:35:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:35:48 --> Controller Class Initialized
INFO - 2016-02-09 08:35:48 --> Model Class Initialized
INFO - 2016-02-09 08:35:48 --> Model Class Initialized
INFO - 2016-02-09 08:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:35:48 --> Pagination Class Initialized
INFO - 2016-02-09 11:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:35:48 --> Helper loaded: text_helper
INFO - 2016-02-09 11:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:35:48 --> Final output sent to browser
DEBUG - 2016-02-09 11:35:48 --> Total execution time: 1.1610
INFO - 2016-02-09 08:36:03 --> Config Class Initialized
INFO - 2016-02-09 08:36:03 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:36:03 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:36:03 --> Utf8 Class Initialized
INFO - 2016-02-09 08:36:03 --> URI Class Initialized
INFO - 2016-02-09 08:36:03 --> Router Class Initialized
INFO - 2016-02-09 08:36:03 --> Output Class Initialized
INFO - 2016-02-09 08:36:03 --> Security Class Initialized
DEBUG - 2016-02-09 08:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:36:03 --> Input Class Initialized
INFO - 2016-02-09 08:36:03 --> Language Class Initialized
INFO - 2016-02-09 08:36:03 --> Loader Class Initialized
INFO - 2016-02-09 08:36:03 --> Helper loaded: url_helper
INFO - 2016-02-09 08:36:03 --> Helper loaded: file_helper
INFO - 2016-02-09 08:36:03 --> Helper loaded: date_helper
INFO - 2016-02-09 08:36:03 --> Helper loaded: form_helper
INFO - 2016-02-09 08:36:03 --> Database Driver Class Initialized
INFO - 2016-02-09 08:36:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:36:04 --> Controller Class Initialized
INFO - 2016-02-09 08:36:04 --> Model Class Initialized
INFO - 2016-02-09 08:36:04 --> Model Class Initialized
INFO - 2016-02-09 08:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:36:04 --> Pagination Class Initialized
INFO - 2016-02-09 11:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:36:04 --> Helper loaded: text_helper
INFO - 2016-02-09 11:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:36:04 --> Final output sent to browser
DEBUG - 2016-02-09 11:36:04 --> Total execution time: 1.1790
INFO - 2016-02-09 08:36:27 --> Config Class Initialized
INFO - 2016-02-09 08:36:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:36:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:36:27 --> Utf8 Class Initialized
INFO - 2016-02-09 08:36:27 --> URI Class Initialized
INFO - 2016-02-09 08:36:27 --> Router Class Initialized
INFO - 2016-02-09 08:36:27 --> Output Class Initialized
INFO - 2016-02-09 08:36:27 --> Security Class Initialized
DEBUG - 2016-02-09 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:36:27 --> Input Class Initialized
INFO - 2016-02-09 08:36:27 --> Language Class Initialized
INFO - 2016-02-09 08:36:27 --> Loader Class Initialized
INFO - 2016-02-09 08:36:27 --> Helper loaded: url_helper
INFO - 2016-02-09 08:36:27 --> Helper loaded: file_helper
INFO - 2016-02-09 08:36:27 --> Helper loaded: date_helper
INFO - 2016-02-09 08:36:27 --> Helper loaded: form_helper
INFO - 2016-02-09 08:36:27 --> Database Driver Class Initialized
INFO - 2016-02-09 08:36:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:36:28 --> Controller Class Initialized
INFO - 2016-02-09 08:36:28 --> Model Class Initialized
INFO - 2016-02-09 08:36:28 --> Model Class Initialized
INFO - 2016-02-09 08:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:36:28 --> Pagination Class Initialized
INFO - 2016-02-09 11:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:36:28 --> Helper loaded: text_helper
INFO - 2016-02-09 11:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:36:28 --> Final output sent to browser
DEBUG - 2016-02-09 11:36:28 --> Total execution time: 1.1877
INFO - 2016-02-09 08:44:49 --> Config Class Initialized
INFO - 2016-02-09 08:44:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:44:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:44:49 --> Utf8 Class Initialized
INFO - 2016-02-09 08:44:49 --> URI Class Initialized
INFO - 2016-02-09 08:44:49 --> Router Class Initialized
INFO - 2016-02-09 08:44:49 --> Output Class Initialized
INFO - 2016-02-09 08:44:49 --> Security Class Initialized
DEBUG - 2016-02-09 08:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:44:49 --> Input Class Initialized
INFO - 2016-02-09 08:44:49 --> Language Class Initialized
INFO - 2016-02-09 08:44:49 --> Loader Class Initialized
INFO - 2016-02-09 08:44:49 --> Helper loaded: url_helper
INFO - 2016-02-09 08:44:49 --> Helper loaded: file_helper
INFO - 2016-02-09 08:44:49 --> Helper loaded: date_helper
INFO - 2016-02-09 08:44:49 --> Helper loaded: form_helper
INFO - 2016-02-09 08:44:49 --> Database Driver Class Initialized
INFO - 2016-02-09 08:44:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:44:50 --> Controller Class Initialized
INFO - 2016-02-09 08:44:50 --> Model Class Initialized
INFO - 2016-02-09 08:44:50 --> Model Class Initialized
INFO - 2016-02-09 08:44:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:44:50 --> Pagination Class Initialized
INFO - 2016-02-09 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:44:50 --> Helper loaded: text_helper
INFO - 2016-02-09 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:44:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:44:50 --> Final output sent to browser
DEBUG - 2016-02-09 11:44:50 --> Total execution time: 1.1813
INFO - 2016-02-09 08:45:22 --> Config Class Initialized
INFO - 2016-02-09 08:45:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:45:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:45:22 --> Utf8 Class Initialized
INFO - 2016-02-09 08:45:22 --> URI Class Initialized
INFO - 2016-02-09 08:45:22 --> Router Class Initialized
INFO - 2016-02-09 08:45:22 --> Output Class Initialized
INFO - 2016-02-09 08:45:22 --> Security Class Initialized
DEBUG - 2016-02-09 08:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:45:22 --> Input Class Initialized
INFO - 2016-02-09 08:45:22 --> Language Class Initialized
INFO - 2016-02-09 08:45:22 --> Loader Class Initialized
INFO - 2016-02-09 08:45:22 --> Helper loaded: url_helper
INFO - 2016-02-09 08:45:22 --> Helper loaded: file_helper
INFO - 2016-02-09 08:45:22 --> Helper loaded: date_helper
INFO - 2016-02-09 08:45:22 --> Helper loaded: form_helper
INFO - 2016-02-09 08:45:22 --> Database Driver Class Initialized
INFO - 2016-02-09 08:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:45:23 --> Controller Class Initialized
INFO - 2016-02-09 08:45:23 --> Model Class Initialized
INFO - 2016-02-09 08:45:23 --> Model Class Initialized
INFO - 2016-02-09 08:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:45:23 --> Pagination Class Initialized
INFO - 2016-02-09 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:45:23 --> Helper loaded: text_helper
INFO - 2016-02-09 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:45:23 --> Final output sent to browser
DEBUG - 2016-02-09 11:45:23 --> Total execution time: 1.2135
INFO - 2016-02-09 08:45:54 --> Config Class Initialized
INFO - 2016-02-09 08:45:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:45:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:45:54 --> Utf8 Class Initialized
INFO - 2016-02-09 08:45:54 --> URI Class Initialized
INFO - 2016-02-09 08:45:54 --> Router Class Initialized
INFO - 2016-02-09 08:45:54 --> Output Class Initialized
INFO - 2016-02-09 08:45:54 --> Security Class Initialized
DEBUG - 2016-02-09 08:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:45:54 --> Input Class Initialized
INFO - 2016-02-09 08:45:54 --> Language Class Initialized
INFO - 2016-02-09 08:45:54 --> Loader Class Initialized
INFO - 2016-02-09 08:45:54 --> Helper loaded: url_helper
INFO - 2016-02-09 08:45:54 --> Helper loaded: file_helper
INFO - 2016-02-09 08:45:54 --> Helper loaded: date_helper
INFO - 2016-02-09 08:45:54 --> Helper loaded: form_helper
INFO - 2016-02-09 08:45:54 --> Database Driver Class Initialized
INFO - 2016-02-09 08:45:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:45:55 --> Controller Class Initialized
INFO - 2016-02-09 08:45:55 --> Model Class Initialized
INFO - 2016-02-09 08:45:55 --> Model Class Initialized
INFO - 2016-02-09 08:45:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:45:55 --> Pagination Class Initialized
INFO - 2016-02-09 11:45:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:45:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:45:55 --> Helper loaded: text_helper
INFO - 2016-02-09 11:45:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:45:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:45:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:45:55 --> Final output sent to browser
DEBUG - 2016-02-09 11:45:55 --> Total execution time: 1.1830
INFO - 2016-02-09 08:46:10 --> Config Class Initialized
INFO - 2016-02-09 08:46:10 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:46:10 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:46:10 --> Utf8 Class Initialized
INFO - 2016-02-09 08:46:10 --> URI Class Initialized
INFO - 2016-02-09 08:46:10 --> Router Class Initialized
INFO - 2016-02-09 08:46:10 --> Output Class Initialized
INFO - 2016-02-09 08:46:10 --> Security Class Initialized
DEBUG - 2016-02-09 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:46:10 --> Input Class Initialized
INFO - 2016-02-09 08:46:10 --> Language Class Initialized
INFO - 2016-02-09 08:46:10 --> Loader Class Initialized
INFO - 2016-02-09 08:46:10 --> Helper loaded: url_helper
INFO - 2016-02-09 08:46:10 --> Helper loaded: file_helper
INFO - 2016-02-09 08:46:10 --> Helper loaded: date_helper
INFO - 2016-02-09 08:46:10 --> Helper loaded: form_helper
INFO - 2016-02-09 08:46:10 --> Database Driver Class Initialized
INFO - 2016-02-09 08:46:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:46:11 --> Controller Class Initialized
INFO - 2016-02-09 08:46:11 --> Model Class Initialized
INFO - 2016-02-09 08:46:11 --> Model Class Initialized
INFO - 2016-02-09 08:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:46:11 --> Pagination Class Initialized
INFO - 2016-02-09 11:46:11 --> Form Validation Class Initialized
INFO - 2016-02-09 11:46:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:46:11 --> Model Class Initialized
INFO - 2016-02-09 11:46:11 --> Final output sent to browser
DEBUG - 2016-02-09 11:46:11 --> Total execution time: 1.1944
INFO - 2016-02-09 08:47:55 --> Config Class Initialized
INFO - 2016-02-09 08:47:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:47:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:47:55 --> Utf8 Class Initialized
INFO - 2016-02-09 08:47:55 --> URI Class Initialized
INFO - 2016-02-09 08:47:55 --> Router Class Initialized
INFO - 2016-02-09 08:47:55 --> Output Class Initialized
INFO - 2016-02-09 08:47:55 --> Security Class Initialized
DEBUG - 2016-02-09 08:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:47:55 --> Input Class Initialized
INFO - 2016-02-09 08:47:55 --> Language Class Initialized
INFO - 2016-02-09 08:47:55 --> Loader Class Initialized
INFO - 2016-02-09 08:47:55 --> Helper loaded: url_helper
INFO - 2016-02-09 08:47:55 --> Helper loaded: file_helper
INFO - 2016-02-09 08:47:55 --> Helper loaded: date_helper
INFO - 2016-02-09 08:47:55 --> Helper loaded: form_helper
INFO - 2016-02-09 08:47:55 --> Database Driver Class Initialized
INFO - 2016-02-09 08:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:47:57 --> Controller Class Initialized
INFO - 2016-02-09 08:47:57 --> Model Class Initialized
INFO - 2016-02-09 08:47:57 --> Model Class Initialized
INFO - 2016-02-09 08:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:47:57 --> Pagination Class Initialized
INFO - 2016-02-09 11:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:47:57 --> Helper loaded: text_helper
INFO - 2016-02-09 11:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:47:57 --> Final output sent to browser
DEBUG - 2016-02-09 11:47:57 --> Total execution time: 1.1627
INFO - 2016-02-09 08:48:05 --> Config Class Initialized
INFO - 2016-02-09 08:48:05 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:48:05 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:48:05 --> Utf8 Class Initialized
INFO - 2016-02-09 08:48:05 --> URI Class Initialized
INFO - 2016-02-09 08:48:05 --> Router Class Initialized
INFO - 2016-02-09 08:48:05 --> Output Class Initialized
INFO - 2016-02-09 08:48:05 --> Security Class Initialized
DEBUG - 2016-02-09 08:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:48:05 --> Input Class Initialized
INFO - 2016-02-09 08:48:05 --> Language Class Initialized
INFO - 2016-02-09 08:48:05 --> Loader Class Initialized
INFO - 2016-02-09 08:48:05 --> Helper loaded: url_helper
INFO - 2016-02-09 08:48:05 --> Helper loaded: file_helper
INFO - 2016-02-09 08:48:05 --> Helper loaded: date_helper
INFO - 2016-02-09 08:48:05 --> Helper loaded: form_helper
INFO - 2016-02-09 08:48:05 --> Database Driver Class Initialized
INFO - 2016-02-09 08:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:48:06 --> Controller Class Initialized
INFO - 2016-02-09 08:48:06 --> Model Class Initialized
INFO - 2016-02-09 08:48:06 --> Model Class Initialized
INFO - 2016-02-09 08:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:48:06 --> Pagination Class Initialized
INFO - 2016-02-09 11:48:06 --> Form Validation Class Initialized
INFO - 2016-02-09 11:48:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:48:06 --> Model Class Initialized
INFO - 2016-02-09 11:48:06 --> Final output sent to browser
DEBUG - 2016-02-09 11:48:06 --> Total execution time: 1.1653
INFO - 2016-02-09 08:49:42 --> Config Class Initialized
INFO - 2016-02-09 08:49:42 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:49:42 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:49:42 --> Utf8 Class Initialized
INFO - 2016-02-09 08:49:42 --> URI Class Initialized
INFO - 2016-02-09 08:49:42 --> Router Class Initialized
INFO - 2016-02-09 08:49:42 --> Output Class Initialized
INFO - 2016-02-09 08:49:42 --> Security Class Initialized
DEBUG - 2016-02-09 08:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:49:42 --> Input Class Initialized
INFO - 2016-02-09 08:49:42 --> Language Class Initialized
INFO - 2016-02-09 08:49:42 --> Loader Class Initialized
INFO - 2016-02-09 08:49:42 --> Helper loaded: url_helper
INFO - 2016-02-09 08:49:42 --> Helper loaded: file_helper
INFO - 2016-02-09 08:49:42 --> Helper loaded: date_helper
INFO - 2016-02-09 08:49:42 --> Helper loaded: form_helper
INFO - 2016-02-09 08:49:42 --> Database Driver Class Initialized
INFO - 2016-02-09 08:49:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:49:43 --> Controller Class Initialized
INFO - 2016-02-09 08:49:43 --> Model Class Initialized
INFO - 2016-02-09 08:49:43 --> Model Class Initialized
INFO - 2016-02-09 08:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:49:43 --> Pagination Class Initialized
INFO - 2016-02-09 11:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:49:43 --> Helper loaded: text_helper
INFO - 2016-02-09 11:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:49:43 --> Final output sent to browser
DEBUG - 2016-02-09 11:49:43 --> Total execution time: 1.1789
INFO - 2016-02-09 08:50:01 --> Config Class Initialized
INFO - 2016-02-09 08:50:01 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:50:01 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:50:01 --> Utf8 Class Initialized
INFO - 2016-02-09 08:50:01 --> URI Class Initialized
INFO - 2016-02-09 08:50:01 --> Router Class Initialized
INFO - 2016-02-09 08:50:01 --> Output Class Initialized
INFO - 2016-02-09 08:50:01 --> Security Class Initialized
DEBUG - 2016-02-09 08:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:50:01 --> Input Class Initialized
INFO - 2016-02-09 08:50:01 --> Language Class Initialized
INFO - 2016-02-09 08:50:01 --> Loader Class Initialized
INFO - 2016-02-09 08:50:01 --> Helper loaded: url_helper
INFO - 2016-02-09 08:50:01 --> Helper loaded: file_helper
INFO - 2016-02-09 08:50:01 --> Helper loaded: date_helper
INFO - 2016-02-09 08:50:01 --> Helper loaded: form_helper
INFO - 2016-02-09 08:50:01 --> Database Driver Class Initialized
INFO - 2016-02-09 08:50:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:50:03 --> Controller Class Initialized
INFO - 2016-02-09 08:50:03 --> Model Class Initialized
INFO - 2016-02-09 08:50:03 --> Model Class Initialized
INFO - 2016-02-09 08:50:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:50:03 --> Pagination Class Initialized
INFO - 2016-02-09 11:50:03 --> Form Validation Class Initialized
INFO - 2016-02-09 11:50:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 11:50:03 --> Model Class Initialized
INFO - 2016-02-09 11:50:03 --> Final output sent to browser
DEBUG - 2016-02-09 11:50:03 --> Total execution time: 1.1994
INFO - 2016-02-09 08:51:33 --> Config Class Initialized
INFO - 2016-02-09 08:51:33 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:51:33 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:51:33 --> Utf8 Class Initialized
INFO - 2016-02-09 08:51:33 --> URI Class Initialized
INFO - 2016-02-09 08:51:33 --> Router Class Initialized
INFO - 2016-02-09 08:51:33 --> Output Class Initialized
INFO - 2016-02-09 08:51:33 --> Security Class Initialized
DEBUG - 2016-02-09 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:51:33 --> Input Class Initialized
INFO - 2016-02-09 08:51:33 --> Language Class Initialized
INFO - 2016-02-09 08:51:33 --> Loader Class Initialized
INFO - 2016-02-09 08:51:33 --> Helper loaded: url_helper
INFO - 2016-02-09 08:51:33 --> Helper loaded: file_helper
INFO - 2016-02-09 08:51:33 --> Helper loaded: date_helper
INFO - 2016-02-09 08:51:33 --> Helper loaded: form_helper
INFO - 2016-02-09 08:51:33 --> Database Driver Class Initialized
INFO - 2016-02-09 08:51:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:51:34 --> Controller Class Initialized
INFO - 2016-02-09 08:51:34 --> Model Class Initialized
INFO - 2016-02-09 08:51:34 --> Model Class Initialized
INFO - 2016-02-09 08:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:51:34 --> Pagination Class Initialized
INFO - 2016-02-09 11:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:51:34 --> Helper loaded: text_helper
INFO - 2016-02-09 11:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:51:34 --> Final output sent to browser
DEBUG - 2016-02-09 11:51:34 --> Total execution time: 1.1643
INFO - 2016-02-09 08:52:32 --> Config Class Initialized
INFO - 2016-02-09 08:52:32 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:52:32 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:52:32 --> Utf8 Class Initialized
INFO - 2016-02-09 08:52:32 --> URI Class Initialized
INFO - 2016-02-09 08:52:32 --> Router Class Initialized
INFO - 2016-02-09 08:52:32 --> Output Class Initialized
INFO - 2016-02-09 08:52:32 --> Security Class Initialized
DEBUG - 2016-02-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:52:32 --> Input Class Initialized
INFO - 2016-02-09 08:52:32 --> Language Class Initialized
INFO - 2016-02-09 08:52:32 --> Loader Class Initialized
INFO - 2016-02-09 08:52:32 --> Helper loaded: url_helper
INFO - 2016-02-09 08:52:32 --> Helper loaded: file_helper
INFO - 2016-02-09 08:52:32 --> Helper loaded: date_helper
INFO - 2016-02-09 08:52:32 --> Helper loaded: form_helper
INFO - 2016-02-09 08:52:32 --> Database Driver Class Initialized
INFO - 2016-02-09 08:52:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:52:33 --> Controller Class Initialized
INFO - 2016-02-09 08:52:33 --> Model Class Initialized
INFO - 2016-02-09 08:52:33 --> Model Class Initialized
INFO - 2016-02-09 08:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:52:33 --> Pagination Class Initialized
INFO - 2016-02-09 11:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:52:33 --> Helper loaded: text_helper
INFO - 2016-02-09 11:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:52:33 --> Final output sent to browser
DEBUG - 2016-02-09 11:52:33 --> Total execution time: 1.1968
INFO - 2016-02-09 08:54:44 --> Config Class Initialized
INFO - 2016-02-09 08:54:44 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:54:44 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:54:44 --> Utf8 Class Initialized
INFO - 2016-02-09 08:54:44 --> URI Class Initialized
INFO - 2016-02-09 08:54:44 --> Router Class Initialized
INFO - 2016-02-09 08:54:44 --> Output Class Initialized
INFO - 2016-02-09 08:54:44 --> Security Class Initialized
DEBUG - 2016-02-09 08:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:54:44 --> Input Class Initialized
INFO - 2016-02-09 08:54:44 --> Language Class Initialized
INFO - 2016-02-09 08:54:44 --> Loader Class Initialized
INFO - 2016-02-09 08:54:44 --> Helper loaded: url_helper
INFO - 2016-02-09 08:54:44 --> Helper loaded: file_helper
INFO - 2016-02-09 08:54:44 --> Helper loaded: date_helper
INFO - 2016-02-09 08:54:44 --> Helper loaded: form_helper
INFO - 2016-02-09 08:54:44 --> Database Driver Class Initialized
INFO - 2016-02-09 08:54:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:54:45 --> Controller Class Initialized
INFO - 2016-02-09 08:54:45 --> Model Class Initialized
INFO - 2016-02-09 08:54:45 --> Model Class Initialized
INFO - 2016-02-09 08:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:54:45 --> Pagination Class Initialized
INFO - 2016-02-09 11:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:54:45 --> Helper loaded: text_helper
INFO - 2016-02-09 11:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:54:45 --> Final output sent to browser
DEBUG - 2016-02-09 11:54:45 --> Total execution time: 1.2117
INFO - 2016-02-09 08:59:45 --> Config Class Initialized
INFO - 2016-02-09 08:59:45 --> Hooks Class Initialized
DEBUG - 2016-02-09 08:59:45 --> UTF-8 Support Enabled
INFO - 2016-02-09 08:59:45 --> Utf8 Class Initialized
INFO - 2016-02-09 08:59:45 --> URI Class Initialized
INFO - 2016-02-09 08:59:45 --> Router Class Initialized
INFO - 2016-02-09 08:59:45 --> Output Class Initialized
INFO - 2016-02-09 08:59:45 --> Security Class Initialized
DEBUG - 2016-02-09 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 08:59:45 --> Input Class Initialized
INFO - 2016-02-09 08:59:45 --> Language Class Initialized
INFO - 2016-02-09 08:59:45 --> Loader Class Initialized
INFO - 2016-02-09 08:59:45 --> Helper loaded: url_helper
INFO - 2016-02-09 08:59:45 --> Helper loaded: file_helper
INFO - 2016-02-09 08:59:45 --> Helper loaded: date_helper
INFO - 2016-02-09 08:59:45 --> Helper loaded: form_helper
INFO - 2016-02-09 08:59:45 --> Database Driver Class Initialized
INFO - 2016-02-09 08:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 08:59:46 --> Controller Class Initialized
INFO - 2016-02-09 08:59:46 --> Model Class Initialized
INFO - 2016-02-09 08:59:46 --> Model Class Initialized
INFO - 2016-02-09 08:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 08:59:46 --> Pagination Class Initialized
INFO - 2016-02-09 11:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 11:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 11:59:46 --> Helper loaded: text_helper
INFO - 2016-02-09 11:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 11:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 11:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 11:59:46 --> Final output sent to browser
DEBUG - 2016-02-09 11:59:46 --> Total execution time: 1.1901
INFO - 2016-02-09 09:00:06 --> Config Class Initialized
INFO - 2016-02-09 09:00:06 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:00:06 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:00:06 --> Utf8 Class Initialized
INFO - 2016-02-09 09:00:06 --> URI Class Initialized
INFO - 2016-02-09 09:00:06 --> Router Class Initialized
INFO - 2016-02-09 09:00:06 --> Output Class Initialized
INFO - 2016-02-09 09:00:06 --> Security Class Initialized
DEBUG - 2016-02-09 09:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:00:06 --> Input Class Initialized
INFO - 2016-02-09 09:00:06 --> Language Class Initialized
INFO - 2016-02-09 09:00:06 --> Loader Class Initialized
INFO - 2016-02-09 09:00:06 --> Helper loaded: url_helper
INFO - 2016-02-09 09:00:06 --> Helper loaded: file_helper
INFO - 2016-02-09 09:00:06 --> Helper loaded: date_helper
INFO - 2016-02-09 09:00:06 --> Helper loaded: form_helper
INFO - 2016-02-09 09:00:06 --> Database Driver Class Initialized
INFO - 2016-02-09 09:00:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:00:07 --> Controller Class Initialized
INFO - 2016-02-09 09:00:07 --> Model Class Initialized
INFO - 2016-02-09 09:00:07 --> Model Class Initialized
INFO - 2016-02-09 09:00:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:00:07 --> Pagination Class Initialized
INFO - 2016-02-09 12:00:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:00:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:00:07 --> Helper loaded: text_helper
INFO - 2016-02-09 12:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:00:08 --> Final output sent to browser
DEBUG - 2016-02-09 12:00:08 --> Total execution time: 1.2245
INFO - 2016-02-09 09:00:53 --> Config Class Initialized
INFO - 2016-02-09 09:00:53 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:00:53 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:00:53 --> Utf8 Class Initialized
INFO - 2016-02-09 09:00:53 --> URI Class Initialized
INFO - 2016-02-09 09:00:53 --> Router Class Initialized
INFO - 2016-02-09 09:00:53 --> Output Class Initialized
INFO - 2016-02-09 09:00:53 --> Security Class Initialized
DEBUG - 2016-02-09 09:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:00:53 --> Input Class Initialized
INFO - 2016-02-09 09:00:53 --> Language Class Initialized
INFO - 2016-02-09 09:00:53 --> Loader Class Initialized
INFO - 2016-02-09 09:00:53 --> Helper loaded: url_helper
INFO - 2016-02-09 09:00:53 --> Helper loaded: file_helper
INFO - 2016-02-09 09:00:53 --> Helper loaded: date_helper
INFO - 2016-02-09 09:00:53 --> Helper loaded: form_helper
INFO - 2016-02-09 09:00:53 --> Database Driver Class Initialized
INFO - 2016-02-09 09:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:00:54 --> Controller Class Initialized
INFO - 2016-02-09 09:00:54 --> Model Class Initialized
INFO - 2016-02-09 09:00:54 --> Model Class Initialized
INFO - 2016-02-09 09:00:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:00:54 --> Pagination Class Initialized
INFO - 2016-02-09 12:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:00:54 --> Helper loaded: text_helper
INFO - 2016-02-09 12:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:00:54 --> Final output sent to browser
DEBUG - 2016-02-09 12:00:54 --> Total execution time: 1.1721
INFO - 2016-02-09 09:01:24 --> Config Class Initialized
INFO - 2016-02-09 09:01:24 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:01:24 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:01:24 --> Utf8 Class Initialized
INFO - 2016-02-09 09:01:24 --> URI Class Initialized
INFO - 2016-02-09 09:01:24 --> Router Class Initialized
INFO - 2016-02-09 09:01:24 --> Output Class Initialized
INFO - 2016-02-09 09:01:24 --> Security Class Initialized
DEBUG - 2016-02-09 09:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:01:24 --> Input Class Initialized
INFO - 2016-02-09 09:01:24 --> Language Class Initialized
INFO - 2016-02-09 09:01:24 --> Loader Class Initialized
INFO - 2016-02-09 09:01:24 --> Helper loaded: url_helper
INFO - 2016-02-09 09:01:24 --> Helper loaded: file_helper
INFO - 2016-02-09 09:01:24 --> Helper loaded: date_helper
INFO - 2016-02-09 09:01:24 --> Helper loaded: form_helper
INFO - 2016-02-09 09:01:24 --> Database Driver Class Initialized
INFO - 2016-02-09 09:01:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:01:25 --> Controller Class Initialized
INFO - 2016-02-09 09:01:25 --> Model Class Initialized
INFO - 2016-02-09 09:01:25 --> Model Class Initialized
INFO - 2016-02-09 09:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:01:25 --> Pagination Class Initialized
INFO - 2016-02-09 12:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:01:25 --> Helper loaded: text_helper
INFO - 2016-02-09 12:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:01:25 --> Final output sent to browser
DEBUG - 2016-02-09 12:01:25 --> Total execution time: 1.2021
INFO - 2016-02-09 09:01:37 --> Config Class Initialized
INFO - 2016-02-09 09:01:37 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:01:37 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:01:37 --> Utf8 Class Initialized
INFO - 2016-02-09 09:01:37 --> URI Class Initialized
INFO - 2016-02-09 09:01:37 --> Router Class Initialized
INFO - 2016-02-09 09:01:37 --> Output Class Initialized
INFO - 2016-02-09 09:01:37 --> Security Class Initialized
DEBUG - 2016-02-09 09:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:01:37 --> Input Class Initialized
INFO - 2016-02-09 09:01:37 --> Language Class Initialized
INFO - 2016-02-09 09:01:37 --> Loader Class Initialized
INFO - 2016-02-09 09:01:37 --> Helper loaded: url_helper
INFO - 2016-02-09 09:01:37 --> Helper loaded: file_helper
INFO - 2016-02-09 09:01:37 --> Helper loaded: date_helper
INFO - 2016-02-09 09:01:37 --> Helper loaded: form_helper
INFO - 2016-02-09 09:01:37 --> Database Driver Class Initialized
INFO - 2016-02-09 09:01:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:01:38 --> Controller Class Initialized
INFO - 2016-02-09 09:01:38 --> Model Class Initialized
INFO - 2016-02-09 09:01:38 --> Model Class Initialized
INFO - 2016-02-09 09:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:01:38 --> Pagination Class Initialized
INFO - 2016-02-09 12:01:38 --> Form Validation Class Initialized
INFO - 2016-02-09 12:01:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:01:38 --> Model Class Initialized
INFO - 2016-02-09 12:01:38 --> Final output sent to browser
DEBUG - 2016-02-09 12:01:38 --> Total execution time: 1.2225
INFO - 2016-02-09 09:02:13 --> Config Class Initialized
INFO - 2016-02-09 09:02:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:02:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:02:13 --> Utf8 Class Initialized
INFO - 2016-02-09 09:02:13 --> URI Class Initialized
INFO - 2016-02-09 09:02:13 --> Router Class Initialized
INFO - 2016-02-09 09:02:13 --> Output Class Initialized
INFO - 2016-02-09 09:02:13 --> Security Class Initialized
DEBUG - 2016-02-09 09:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:02:13 --> Input Class Initialized
INFO - 2016-02-09 09:02:13 --> Language Class Initialized
INFO - 2016-02-09 09:02:13 --> Loader Class Initialized
INFO - 2016-02-09 09:02:13 --> Helper loaded: url_helper
INFO - 2016-02-09 09:02:13 --> Helper loaded: file_helper
INFO - 2016-02-09 09:02:13 --> Helper loaded: date_helper
INFO - 2016-02-09 09:02:13 --> Helper loaded: form_helper
INFO - 2016-02-09 09:02:13 --> Database Driver Class Initialized
INFO - 2016-02-09 09:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:02:14 --> Controller Class Initialized
INFO - 2016-02-09 09:02:14 --> Model Class Initialized
INFO - 2016-02-09 09:02:14 --> Model Class Initialized
INFO - 2016-02-09 09:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:02:14 --> Pagination Class Initialized
INFO - 2016-02-09 12:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:02:14 --> Helper loaded: text_helper
INFO - 2016-02-09 12:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:02:15 --> Final output sent to browser
DEBUG - 2016-02-09 12:02:15 --> Total execution time: 1.2071
INFO - 2016-02-09 09:02:21 --> Config Class Initialized
INFO - 2016-02-09 09:02:21 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:02:21 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:02:21 --> Utf8 Class Initialized
INFO - 2016-02-09 09:02:21 --> URI Class Initialized
INFO - 2016-02-09 09:02:21 --> Router Class Initialized
INFO - 2016-02-09 09:02:21 --> Output Class Initialized
INFO - 2016-02-09 09:02:21 --> Security Class Initialized
DEBUG - 2016-02-09 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:02:21 --> Input Class Initialized
INFO - 2016-02-09 09:02:21 --> Language Class Initialized
INFO - 2016-02-09 09:02:21 --> Loader Class Initialized
INFO - 2016-02-09 09:02:21 --> Helper loaded: url_helper
INFO - 2016-02-09 09:02:21 --> Helper loaded: file_helper
INFO - 2016-02-09 09:02:21 --> Helper loaded: date_helper
INFO - 2016-02-09 09:02:21 --> Helper loaded: form_helper
INFO - 2016-02-09 09:02:21 --> Database Driver Class Initialized
INFO - 2016-02-09 09:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:02:22 --> Controller Class Initialized
INFO - 2016-02-09 09:02:22 --> Model Class Initialized
INFO - 2016-02-09 09:02:22 --> Model Class Initialized
INFO - 2016-02-09 09:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:02:22 --> Pagination Class Initialized
INFO - 2016-02-09 12:02:22 --> Form Validation Class Initialized
INFO - 2016-02-09 12:02:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:02:22 --> Model Class Initialized
INFO - 2016-02-09 12:02:22 --> Final output sent to browser
DEBUG - 2016-02-09 12:02:22 --> Total execution time: 1.2244
INFO - 2016-02-09 09:03:51 --> Config Class Initialized
INFO - 2016-02-09 09:03:51 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:03:51 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:03:51 --> Utf8 Class Initialized
INFO - 2016-02-09 09:03:51 --> URI Class Initialized
INFO - 2016-02-09 09:03:51 --> Router Class Initialized
INFO - 2016-02-09 09:03:51 --> Output Class Initialized
INFO - 2016-02-09 09:03:51 --> Security Class Initialized
DEBUG - 2016-02-09 09:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:03:51 --> Input Class Initialized
INFO - 2016-02-09 09:03:51 --> Language Class Initialized
INFO - 2016-02-09 09:03:51 --> Loader Class Initialized
INFO - 2016-02-09 09:03:51 --> Helper loaded: url_helper
INFO - 2016-02-09 09:03:51 --> Helper loaded: file_helper
INFO - 2016-02-09 09:03:51 --> Helper loaded: date_helper
INFO - 2016-02-09 09:03:51 --> Helper loaded: form_helper
INFO - 2016-02-09 09:03:51 --> Database Driver Class Initialized
INFO - 2016-02-09 09:03:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:03:52 --> Controller Class Initialized
INFO - 2016-02-09 09:03:52 --> Model Class Initialized
INFO - 2016-02-09 09:03:52 --> Model Class Initialized
INFO - 2016-02-09 09:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:03:52 --> Pagination Class Initialized
INFO - 2016-02-09 12:03:52 --> Form Validation Class Initialized
INFO - 2016-02-09 12:03:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:03:52 --> Model Class Initialized
INFO - 2016-02-09 12:03:52 --> Final output sent to browser
DEBUG - 2016-02-09 12:03:52 --> Total execution time: 1.1943
INFO - 2016-02-09 09:05:16 --> Config Class Initialized
INFO - 2016-02-09 09:05:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:05:16 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:05:16 --> Utf8 Class Initialized
INFO - 2016-02-09 09:05:16 --> URI Class Initialized
INFO - 2016-02-09 09:05:16 --> Router Class Initialized
INFO - 2016-02-09 09:05:16 --> Output Class Initialized
INFO - 2016-02-09 09:05:16 --> Security Class Initialized
DEBUG - 2016-02-09 09:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:05:16 --> Input Class Initialized
INFO - 2016-02-09 09:05:16 --> Language Class Initialized
INFO - 2016-02-09 09:05:16 --> Loader Class Initialized
INFO - 2016-02-09 09:05:16 --> Helper loaded: url_helper
INFO - 2016-02-09 09:05:16 --> Helper loaded: file_helper
INFO - 2016-02-09 09:05:16 --> Helper loaded: date_helper
INFO - 2016-02-09 09:05:16 --> Helper loaded: form_helper
INFO - 2016-02-09 09:05:16 --> Database Driver Class Initialized
INFO - 2016-02-09 09:05:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:05:17 --> Controller Class Initialized
INFO - 2016-02-09 09:05:17 --> Model Class Initialized
INFO - 2016-02-09 09:05:17 --> Model Class Initialized
INFO - 2016-02-09 09:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:05:17 --> Pagination Class Initialized
INFO - 2016-02-09 12:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:05:17 --> Helper loaded: text_helper
INFO - 2016-02-09 12:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:05:17 --> Final output sent to browser
DEBUG - 2016-02-09 12:05:17 --> Total execution time: 1.1416
INFO - 2016-02-09 09:05:25 --> Config Class Initialized
INFO - 2016-02-09 09:05:25 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:05:25 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:05:25 --> Utf8 Class Initialized
INFO - 2016-02-09 09:05:25 --> URI Class Initialized
INFO - 2016-02-09 09:05:25 --> Router Class Initialized
INFO - 2016-02-09 09:05:25 --> Output Class Initialized
INFO - 2016-02-09 09:05:25 --> Security Class Initialized
DEBUG - 2016-02-09 09:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:05:25 --> Input Class Initialized
INFO - 2016-02-09 09:05:25 --> Language Class Initialized
INFO - 2016-02-09 09:05:25 --> Loader Class Initialized
INFO - 2016-02-09 09:05:25 --> Helper loaded: url_helper
INFO - 2016-02-09 09:05:25 --> Helper loaded: file_helper
INFO - 2016-02-09 09:05:25 --> Helper loaded: date_helper
INFO - 2016-02-09 09:05:25 --> Helper loaded: form_helper
INFO - 2016-02-09 09:05:25 --> Database Driver Class Initialized
INFO - 2016-02-09 09:05:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:05:26 --> Controller Class Initialized
INFO - 2016-02-09 09:05:26 --> Model Class Initialized
INFO - 2016-02-09 09:05:26 --> Model Class Initialized
INFO - 2016-02-09 09:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:05:26 --> Pagination Class Initialized
INFO - 2016-02-09 12:05:26 --> Form Validation Class Initialized
INFO - 2016-02-09 12:05:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:05:26 --> Model Class Initialized
INFO - 2016-02-09 12:05:26 --> Final output sent to browser
DEBUG - 2016-02-09 12:05:26 --> Total execution time: 1.1860
INFO - 2016-02-09 09:06:35 --> Config Class Initialized
INFO - 2016-02-09 09:06:35 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:06:35 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:06:35 --> Utf8 Class Initialized
INFO - 2016-02-09 09:06:35 --> URI Class Initialized
INFO - 2016-02-09 09:06:35 --> Router Class Initialized
INFO - 2016-02-09 09:06:35 --> Output Class Initialized
INFO - 2016-02-09 09:06:35 --> Security Class Initialized
DEBUG - 2016-02-09 09:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:06:35 --> Input Class Initialized
INFO - 2016-02-09 09:06:35 --> Language Class Initialized
INFO - 2016-02-09 09:06:35 --> Loader Class Initialized
INFO - 2016-02-09 09:06:35 --> Helper loaded: url_helper
INFO - 2016-02-09 09:06:35 --> Helper loaded: file_helper
INFO - 2016-02-09 09:06:35 --> Helper loaded: date_helper
INFO - 2016-02-09 09:06:35 --> Helper loaded: form_helper
INFO - 2016-02-09 09:06:35 --> Database Driver Class Initialized
INFO - 2016-02-09 09:06:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:06:36 --> Controller Class Initialized
INFO - 2016-02-09 09:06:36 --> Model Class Initialized
INFO - 2016-02-09 09:06:36 --> Model Class Initialized
INFO - 2016-02-09 09:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:06:36 --> Pagination Class Initialized
INFO - 2016-02-09 12:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:06:36 --> Helper loaded: text_helper
INFO - 2016-02-09 12:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:06:36 --> Final output sent to browser
DEBUG - 2016-02-09 12:06:36 --> Total execution time: 1.1855
INFO - 2016-02-09 09:06:49 --> Config Class Initialized
INFO - 2016-02-09 09:06:49 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:06:49 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:06:49 --> Utf8 Class Initialized
INFO - 2016-02-09 09:06:49 --> URI Class Initialized
INFO - 2016-02-09 09:06:49 --> Router Class Initialized
INFO - 2016-02-09 09:06:49 --> Output Class Initialized
INFO - 2016-02-09 09:06:49 --> Security Class Initialized
DEBUG - 2016-02-09 09:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:06:49 --> Input Class Initialized
INFO - 2016-02-09 09:06:49 --> Language Class Initialized
INFO - 2016-02-09 09:06:49 --> Loader Class Initialized
INFO - 2016-02-09 09:06:49 --> Helper loaded: url_helper
INFO - 2016-02-09 09:06:49 --> Helper loaded: file_helper
INFO - 2016-02-09 09:06:49 --> Helper loaded: date_helper
INFO - 2016-02-09 09:06:49 --> Helper loaded: form_helper
INFO - 2016-02-09 09:06:49 --> Database Driver Class Initialized
INFO - 2016-02-09 09:06:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:06:50 --> Controller Class Initialized
INFO - 2016-02-09 09:06:50 --> Model Class Initialized
INFO - 2016-02-09 09:06:50 --> Model Class Initialized
INFO - 2016-02-09 09:06:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:06:50 --> Pagination Class Initialized
INFO - 2016-02-09 12:06:50 --> Form Validation Class Initialized
INFO - 2016-02-09 12:06:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:06:50 --> Model Class Initialized
INFO - 2016-02-09 12:06:50 --> Final output sent to browser
DEBUG - 2016-02-09 12:06:50 --> Total execution time: 1.1941
INFO - 2016-02-09 09:07:07 --> Config Class Initialized
INFO - 2016-02-09 09:07:07 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:07:07 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:07:07 --> Utf8 Class Initialized
INFO - 2016-02-09 09:07:07 --> URI Class Initialized
INFO - 2016-02-09 09:07:07 --> Router Class Initialized
INFO - 2016-02-09 09:07:07 --> Output Class Initialized
INFO - 2016-02-09 09:07:07 --> Security Class Initialized
DEBUG - 2016-02-09 09:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:07:07 --> Input Class Initialized
INFO - 2016-02-09 09:07:07 --> Language Class Initialized
INFO - 2016-02-09 09:07:07 --> Loader Class Initialized
INFO - 2016-02-09 09:07:07 --> Helper loaded: url_helper
INFO - 2016-02-09 09:07:07 --> Helper loaded: file_helper
INFO - 2016-02-09 09:07:07 --> Helper loaded: date_helper
INFO - 2016-02-09 09:07:07 --> Helper loaded: form_helper
INFO - 2016-02-09 09:07:07 --> Database Driver Class Initialized
INFO - 2016-02-09 09:07:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:07:08 --> Controller Class Initialized
INFO - 2016-02-09 09:07:08 --> Model Class Initialized
INFO - 2016-02-09 09:07:08 --> Model Class Initialized
INFO - 2016-02-09 09:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:07:08 --> Pagination Class Initialized
INFO - 2016-02-09 12:07:08 --> Form Validation Class Initialized
INFO - 2016-02-09 12:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:07:08 --> Model Class Initialized
INFO - 2016-02-09 12:07:08 --> Final output sent to browser
DEBUG - 2016-02-09 12:07:08 --> Total execution time: 1.1913
INFO - 2016-02-09 09:10:13 --> Config Class Initialized
INFO - 2016-02-09 09:10:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:10:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:10:13 --> Utf8 Class Initialized
INFO - 2016-02-09 09:10:13 --> URI Class Initialized
INFO - 2016-02-09 09:10:13 --> Router Class Initialized
INFO - 2016-02-09 09:10:13 --> Output Class Initialized
INFO - 2016-02-09 09:10:13 --> Security Class Initialized
DEBUG - 2016-02-09 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:10:13 --> Input Class Initialized
INFO - 2016-02-09 09:10:13 --> Language Class Initialized
INFO - 2016-02-09 09:10:13 --> Loader Class Initialized
INFO - 2016-02-09 09:10:13 --> Helper loaded: url_helper
INFO - 2016-02-09 09:10:13 --> Helper loaded: file_helper
INFO - 2016-02-09 09:10:13 --> Helper loaded: date_helper
INFO - 2016-02-09 09:10:13 --> Helper loaded: form_helper
INFO - 2016-02-09 09:10:13 --> Database Driver Class Initialized
INFO - 2016-02-09 09:10:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:10:14 --> Controller Class Initialized
INFO - 2016-02-09 09:10:14 --> Model Class Initialized
INFO - 2016-02-09 09:10:14 --> Model Class Initialized
INFO - 2016-02-09 09:10:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:10:14 --> Pagination Class Initialized
INFO - 2016-02-09 12:10:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:10:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:10:14 --> Helper loaded: text_helper
INFO - 2016-02-09 12:10:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:10:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:10:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:10:14 --> Final output sent to browser
DEBUG - 2016-02-09 12:10:14 --> Total execution time: 1.2751
INFO - 2016-02-09 09:10:28 --> Config Class Initialized
INFO - 2016-02-09 09:10:28 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:10:28 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:10:28 --> Utf8 Class Initialized
INFO - 2016-02-09 09:10:28 --> URI Class Initialized
INFO - 2016-02-09 09:10:28 --> Router Class Initialized
INFO - 2016-02-09 09:10:28 --> Output Class Initialized
INFO - 2016-02-09 09:10:28 --> Security Class Initialized
DEBUG - 2016-02-09 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:10:28 --> Input Class Initialized
INFO - 2016-02-09 09:10:28 --> Language Class Initialized
INFO - 2016-02-09 09:10:28 --> Loader Class Initialized
INFO - 2016-02-09 09:10:28 --> Helper loaded: url_helper
INFO - 2016-02-09 09:10:28 --> Helper loaded: file_helper
INFO - 2016-02-09 09:10:28 --> Helper loaded: date_helper
INFO - 2016-02-09 09:10:28 --> Helper loaded: form_helper
INFO - 2016-02-09 09:10:28 --> Database Driver Class Initialized
INFO - 2016-02-09 09:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:10:29 --> Controller Class Initialized
INFO - 2016-02-09 09:10:29 --> Model Class Initialized
INFO - 2016-02-09 09:10:29 --> Model Class Initialized
INFO - 2016-02-09 09:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:10:29 --> Pagination Class Initialized
INFO - 2016-02-09 12:10:29 --> Form Validation Class Initialized
INFO - 2016-02-09 12:10:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:10:29 --> Model Class Initialized
INFO - 2016-02-09 12:10:30 --> Final output sent to browser
DEBUG - 2016-02-09 12:10:30 --> Total execution time: 1.1742
INFO - 2016-02-09 09:11:22 --> Config Class Initialized
INFO - 2016-02-09 09:11:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:11:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:11:22 --> Utf8 Class Initialized
INFO - 2016-02-09 09:11:22 --> URI Class Initialized
INFO - 2016-02-09 09:11:22 --> Router Class Initialized
INFO - 2016-02-09 09:11:22 --> Output Class Initialized
INFO - 2016-02-09 09:11:22 --> Security Class Initialized
DEBUG - 2016-02-09 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:11:22 --> Input Class Initialized
INFO - 2016-02-09 09:11:22 --> Language Class Initialized
INFO - 2016-02-09 09:11:22 --> Loader Class Initialized
INFO - 2016-02-09 09:11:22 --> Helper loaded: url_helper
INFO - 2016-02-09 09:11:22 --> Helper loaded: file_helper
INFO - 2016-02-09 09:11:22 --> Helper loaded: date_helper
INFO - 2016-02-09 09:11:22 --> Helper loaded: form_helper
INFO - 2016-02-09 09:11:22 --> Database Driver Class Initialized
INFO - 2016-02-09 09:11:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:11:23 --> Controller Class Initialized
INFO - 2016-02-09 09:11:23 --> Model Class Initialized
INFO - 2016-02-09 09:11:23 --> Model Class Initialized
INFO - 2016-02-09 09:11:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:11:23 --> Pagination Class Initialized
INFO - 2016-02-09 12:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:11:23 --> Helper loaded: text_helper
INFO - 2016-02-09 12:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:11:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:11:23 --> Final output sent to browser
DEBUG - 2016-02-09 12:11:23 --> Total execution time: 1.1760
INFO - 2016-02-09 09:11:32 --> Config Class Initialized
INFO - 2016-02-09 09:11:32 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:11:32 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:11:32 --> Utf8 Class Initialized
INFO - 2016-02-09 09:11:32 --> URI Class Initialized
INFO - 2016-02-09 09:11:32 --> Router Class Initialized
INFO - 2016-02-09 09:11:32 --> Output Class Initialized
INFO - 2016-02-09 09:11:32 --> Security Class Initialized
DEBUG - 2016-02-09 09:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:11:32 --> Input Class Initialized
INFO - 2016-02-09 09:11:32 --> Language Class Initialized
INFO - 2016-02-09 09:11:32 --> Loader Class Initialized
INFO - 2016-02-09 09:11:32 --> Helper loaded: url_helper
INFO - 2016-02-09 09:11:32 --> Helper loaded: file_helper
INFO - 2016-02-09 09:11:32 --> Helper loaded: date_helper
INFO - 2016-02-09 09:11:32 --> Helper loaded: form_helper
INFO - 2016-02-09 09:11:32 --> Database Driver Class Initialized
INFO - 2016-02-09 09:11:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:11:33 --> Controller Class Initialized
INFO - 2016-02-09 09:11:33 --> Model Class Initialized
INFO - 2016-02-09 09:11:33 --> Model Class Initialized
INFO - 2016-02-09 09:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:11:33 --> Pagination Class Initialized
INFO - 2016-02-09 12:11:33 --> Form Validation Class Initialized
INFO - 2016-02-09 12:11:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:11:33 --> Model Class Initialized
INFO - 2016-02-09 12:11:33 --> Final output sent to browser
DEBUG - 2016-02-09 12:11:33 --> Total execution time: 1.2076
INFO - 2016-02-09 09:12:03 --> Config Class Initialized
INFO - 2016-02-09 09:12:03 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:12:03 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:12:03 --> Utf8 Class Initialized
INFO - 2016-02-09 09:12:03 --> URI Class Initialized
INFO - 2016-02-09 09:12:03 --> Router Class Initialized
INFO - 2016-02-09 09:12:03 --> Output Class Initialized
INFO - 2016-02-09 09:12:03 --> Security Class Initialized
DEBUG - 2016-02-09 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:12:03 --> Input Class Initialized
INFO - 2016-02-09 09:12:03 --> Language Class Initialized
INFO - 2016-02-09 09:12:03 --> Loader Class Initialized
INFO - 2016-02-09 09:12:03 --> Helper loaded: url_helper
INFO - 2016-02-09 09:12:03 --> Helper loaded: file_helper
INFO - 2016-02-09 09:12:03 --> Helper loaded: date_helper
INFO - 2016-02-09 09:12:03 --> Helper loaded: form_helper
INFO - 2016-02-09 09:12:03 --> Database Driver Class Initialized
INFO - 2016-02-09 09:12:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:12:04 --> Controller Class Initialized
INFO - 2016-02-09 09:12:04 --> Model Class Initialized
INFO - 2016-02-09 09:12:04 --> Model Class Initialized
INFO - 2016-02-09 09:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:12:04 --> Pagination Class Initialized
INFO - 2016-02-09 12:12:04 --> Form Validation Class Initialized
INFO - 2016-02-09 12:12:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:12:04 --> Model Class Initialized
INFO - 2016-02-09 12:12:04 --> Final output sent to browser
DEBUG - 2016-02-09 12:12:04 --> Total execution time: 1.2218
INFO - 2016-02-09 09:14:09 --> Config Class Initialized
INFO - 2016-02-09 09:14:09 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:14:09 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:14:09 --> Utf8 Class Initialized
INFO - 2016-02-09 09:14:09 --> URI Class Initialized
INFO - 2016-02-09 09:14:09 --> Router Class Initialized
INFO - 2016-02-09 09:14:09 --> Output Class Initialized
INFO - 2016-02-09 09:14:09 --> Security Class Initialized
DEBUG - 2016-02-09 09:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:14:09 --> Input Class Initialized
INFO - 2016-02-09 09:14:09 --> Language Class Initialized
INFO - 2016-02-09 09:14:09 --> Loader Class Initialized
INFO - 2016-02-09 09:14:09 --> Helper loaded: url_helper
INFO - 2016-02-09 09:14:09 --> Helper loaded: file_helper
INFO - 2016-02-09 09:14:09 --> Helper loaded: date_helper
INFO - 2016-02-09 09:14:09 --> Helper loaded: form_helper
INFO - 2016-02-09 09:14:09 --> Database Driver Class Initialized
INFO - 2016-02-09 09:14:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:14:10 --> Controller Class Initialized
INFO - 2016-02-09 09:14:10 --> Model Class Initialized
INFO - 2016-02-09 09:14:10 --> Model Class Initialized
INFO - 2016-02-09 09:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:14:10 --> Pagination Class Initialized
INFO - 2016-02-09 12:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:14:10 --> Helper loaded: text_helper
INFO - 2016-02-09 12:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:14:10 --> Final output sent to browser
DEBUG - 2016-02-09 12:14:10 --> Total execution time: 1.1667
INFO - 2016-02-09 09:14:18 --> Config Class Initialized
INFO - 2016-02-09 09:14:18 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:14:18 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:14:18 --> Utf8 Class Initialized
INFO - 2016-02-09 09:14:18 --> URI Class Initialized
INFO - 2016-02-09 09:14:18 --> Router Class Initialized
INFO - 2016-02-09 09:14:18 --> Output Class Initialized
INFO - 2016-02-09 09:14:18 --> Security Class Initialized
DEBUG - 2016-02-09 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:14:18 --> Input Class Initialized
INFO - 2016-02-09 09:14:18 --> Language Class Initialized
INFO - 2016-02-09 09:14:18 --> Loader Class Initialized
INFO - 2016-02-09 09:14:18 --> Helper loaded: url_helper
INFO - 2016-02-09 09:14:18 --> Helper loaded: file_helper
INFO - 2016-02-09 09:14:18 --> Helper loaded: date_helper
INFO - 2016-02-09 09:14:18 --> Helper loaded: form_helper
INFO - 2016-02-09 09:14:18 --> Database Driver Class Initialized
INFO - 2016-02-09 09:14:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:14:19 --> Controller Class Initialized
INFO - 2016-02-09 09:14:19 --> Model Class Initialized
INFO - 2016-02-09 09:14:19 --> Model Class Initialized
INFO - 2016-02-09 09:14:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:14:19 --> Pagination Class Initialized
INFO - 2016-02-09 12:14:19 --> Form Validation Class Initialized
INFO - 2016-02-09 12:14:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:14:19 --> Model Class Initialized
INFO - 2016-02-09 12:14:19 --> Final output sent to browser
DEBUG - 2016-02-09 12:14:19 --> Total execution time: 1.2066
INFO - 2016-02-09 09:15:09 --> Config Class Initialized
INFO - 2016-02-09 09:15:09 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:15:09 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:15:09 --> Utf8 Class Initialized
INFO - 2016-02-09 09:15:09 --> URI Class Initialized
INFO - 2016-02-09 09:15:09 --> Router Class Initialized
INFO - 2016-02-09 09:15:09 --> Output Class Initialized
INFO - 2016-02-09 09:15:09 --> Security Class Initialized
DEBUG - 2016-02-09 09:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:15:09 --> Input Class Initialized
INFO - 2016-02-09 09:15:09 --> Language Class Initialized
INFO - 2016-02-09 09:15:09 --> Loader Class Initialized
INFO - 2016-02-09 09:15:09 --> Helper loaded: url_helper
INFO - 2016-02-09 09:15:09 --> Helper loaded: file_helper
INFO - 2016-02-09 09:15:09 --> Helper loaded: date_helper
INFO - 2016-02-09 09:15:09 --> Helper loaded: form_helper
INFO - 2016-02-09 09:15:09 --> Database Driver Class Initialized
INFO - 2016-02-09 09:15:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:15:10 --> Controller Class Initialized
INFO - 2016-02-09 09:15:10 --> Model Class Initialized
INFO - 2016-02-09 09:15:10 --> Model Class Initialized
INFO - 2016-02-09 09:15:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:15:10 --> Pagination Class Initialized
INFO - 2016-02-09 12:15:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:15:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:15:10 --> Helper loaded: text_helper
INFO - 2016-02-09 12:15:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:15:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:15:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:15:10 --> Final output sent to browser
DEBUG - 2016-02-09 12:15:10 --> Total execution time: 1.2172
INFO - 2016-02-09 09:16:03 --> Config Class Initialized
INFO - 2016-02-09 09:16:03 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:16:03 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:16:03 --> Utf8 Class Initialized
INFO - 2016-02-09 09:16:03 --> URI Class Initialized
INFO - 2016-02-09 09:16:03 --> Router Class Initialized
INFO - 2016-02-09 09:16:03 --> Output Class Initialized
INFO - 2016-02-09 09:16:03 --> Security Class Initialized
DEBUG - 2016-02-09 09:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:16:03 --> Input Class Initialized
INFO - 2016-02-09 09:16:03 --> Language Class Initialized
INFO - 2016-02-09 09:16:03 --> Loader Class Initialized
INFO - 2016-02-09 09:16:03 --> Helper loaded: url_helper
INFO - 2016-02-09 09:16:03 --> Helper loaded: file_helper
INFO - 2016-02-09 09:16:03 --> Helper loaded: date_helper
INFO - 2016-02-09 09:16:03 --> Helper loaded: form_helper
INFO - 2016-02-09 09:16:03 --> Database Driver Class Initialized
INFO - 2016-02-09 09:16:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:16:04 --> Controller Class Initialized
INFO - 2016-02-09 09:16:04 --> Model Class Initialized
INFO - 2016-02-09 09:16:04 --> Model Class Initialized
INFO - 2016-02-09 09:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:16:04 --> Pagination Class Initialized
INFO - 2016-02-09 12:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:16:04 --> Helper loaded: text_helper
INFO - 2016-02-09 12:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:16:04 --> Final output sent to browser
DEBUG - 2016-02-09 12:16:04 --> Total execution time: 1.1521
INFO - 2016-02-09 09:16:20 --> Config Class Initialized
INFO - 2016-02-09 09:16:20 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:16:20 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:16:20 --> Utf8 Class Initialized
INFO - 2016-02-09 09:16:20 --> URI Class Initialized
INFO - 2016-02-09 09:16:20 --> Router Class Initialized
INFO - 2016-02-09 09:16:20 --> Output Class Initialized
INFO - 2016-02-09 09:16:20 --> Security Class Initialized
DEBUG - 2016-02-09 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:16:20 --> Input Class Initialized
INFO - 2016-02-09 09:16:20 --> Language Class Initialized
INFO - 2016-02-09 09:16:20 --> Loader Class Initialized
INFO - 2016-02-09 09:16:20 --> Helper loaded: url_helper
INFO - 2016-02-09 09:16:20 --> Helper loaded: file_helper
INFO - 2016-02-09 09:16:20 --> Helper loaded: date_helper
INFO - 2016-02-09 09:16:20 --> Helper loaded: form_helper
INFO - 2016-02-09 09:16:20 --> Database Driver Class Initialized
INFO - 2016-02-09 09:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:16:21 --> Controller Class Initialized
INFO - 2016-02-09 09:16:21 --> Model Class Initialized
INFO - 2016-02-09 09:16:21 --> Model Class Initialized
INFO - 2016-02-09 09:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:16:21 --> Pagination Class Initialized
INFO - 2016-02-09 12:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:16:21 --> Helper loaded: text_helper
INFO - 2016-02-09 12:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:16:21 --> Final output sent to browser
DEBUG - 2016-02-09 12:16:21 --> Total execution time: 1.2305
INFO - 2016-02-09 09:16:29 --> Config Class Initialized
INFO - 2016-02-09 09:16:29 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:16:29 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:16:29 --> Utf8 Class Initialized
INFO - 2016-02-09 09:16:29 --> URI Class Initialized
INFO - 2016-02-09 09:16:29 --> Router Class Initialized
INFO - 2016-02-09 09:16:29 --> Output Class Initialized
INFO - 2016-02-09 09:16:29 --> Security Class Initialized
DEBUG - 2016-02-09 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:16:29 --> Input Class Initialized
INFO - 2016-02-09 09:16:29 --> Language Class Initialized
INFO - 2016-02-09 09:16:29 --> Loader Class Initialized
INFO - 2016-02-09 09:16:29 --> Helper loaded: url_helper
INFO - 2016-02-09 09:16:29 --> Helper loaded: file_helper
INFO - 2016-02-09 09:16:29 --> Helper loaded: date_helper
INFO - 2016-02-09 09:16:29 --> Helper loaded: form_helper
INFO - 2016-02-09 09:16:29 --> Database Driver Class Initialized
INFO - 2016-02-09 09:16:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:16:30 --> Controller Class Initialized
INFO - 2016-02-09 09:16:30 --> Model Class Initialized
INFO - 2016-02-09 09:16:30 --> Model Class Initialized
INFO - 2016-02-09 09:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:16:30 --> Pagination Class Initialized
INFO - 2016-02-09 12:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:16:30 --> Helper loaded: text_helper
INFO - 2016-02-09 12:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:16:30 --> Final output sent to browser
DEBUG - 2016-02-09 12:16:30 --> Total execution time: 1.1747
INFO - 2016-02-09 09:16:36 --> Config Class Initialized
INFO - 2016-02-09 09:16:36 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:16:36 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:16:36 --> Utf8 Class Initialized
INFO - 2016-02-09 09:16:36 --> URI Class Initialized
INFO - 2016-02-09 09:16:36 --> Router Class Initialized
INFO - 2016-02-09 09:16:36 --> Output Class Initialized
INFO - 2016-02-09 09:16:36 --> Security Class Initialized
DEBUG - 2016-02-09 09:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:16:36 --> Input Class Initialized
INFO - 2016-02-09 09:16:36 --> Language Class Initialized
INFO - 2016-02-09 09:16:36 --> Loader Class Initialized
INFO - 2016-02-09 09:16:36 --> Helper loaded: url_helper
INFO - 2016-02-09 09:16:36 --> Helper loaded: file_helper
INFO - 2016-02-09 09:16:36 --> Helper loaded: date_helper
INFO - 2016-02-09 09:16:36 --> Helper loaded: form_helper
INFO - 2016-02-09 09:16:36 --> Database Driver Class Initialized
INFO - 2016-02-09 09:16:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:16:37 --> Controller Class Initialized
INFO - 2016-02-09 09:16:37 --> Model Class Initialized
INFO - 2016-02-09 09:16:37 --> Model Class Initialized
INFO - 2016-02-09 09:16:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:16:37 --> Pagination Class Initialized
INFO - 2016-02-09 12:16:37 --> Form Validation Class Initialized
INFO - 2016-02-09 12:16:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-09 12:16:37 --> Model Class Initialized
INFO - 2016-02-09 12:16:37 --> Final output sent to browser
DEBUG - 2016-02-09 12:16:37 --> Total execution time: 1.2016
INFO - 2016-02-09 09:34:01 --> Config Class Initialized
INFO - 2016-02-09 09:34:01 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:34:01 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:34:01 --> Utf8 Class Initialized
INFO - 2016-02-09 09:34:01 --> URI Class Initialized
INFO - 2016-02-09 09:34:01 --> Router Class Initialized
INFO - 2016-02-09 09:34:01 --> Output Class Initialized
INFO - 2016-02-09 09:34:01 --> Security Class Initialized
DEBUG - 2016-02-09 09:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:34:01 --> Input Class Initialized
INFO - 2016-02-09 09:34:01 --> Language Class Initialized
INFO - 2016-02-09 09:34:01 --> Loader Class Initialized
INFO - 2016-02-09 09:34:01 --> Helper loaded: url_helper
INFO - 2016-02-09 09:34:01 --> Helper loaded: file_helper
INFO - 2016-02-09 09:34:01 --> Helper loaded: date_helper
INFO - 2016-02-09 09:34:01 --> Helper loaded: form_helper
INFO - 2016-02-09 09:34:01 --> Database Driver Class Initialized
INFO - 2016-02-09 09:34:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:34:02 --> Controller Class Initialized
INFO - 2016-02-09 09:34:02 --> Model Class Initialized
INFO - 2016-02-09 09:34:02 --> Model Class Initialized
INFO - 2016-02-09 09:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:34:02 --> Pagination Class Initialized
INFO - 2016-02-09 12:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:34:02 --> Helper loaded: text_helper
INFO - 2016-02-09 12:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:34:02 --> Final output sent to browser
DEBUG - 2016-02-09 12:34:02 --> Total execution time: 1.2308
INFO - 2016-02-09 09:34:13 --> Config Class Initialized
INFO - 2016-02-09 09:34:13 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:34:13 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:34:13 --> Utf8 Class Initialized
INFO - 2016-02-09 09:34:13 --> URI Class Initialized
INFO - 2016-02-09 09:34:13 --> Router Class Initialized
INFO - 2016-02-09 09:34:13 --> Output Class Initialized
INFO - 2016-02-09 09:34:13 --> Security Class Initialized
DEBUG - 2016-02-09 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:34:13 --> Input Class Initialized
INFO - 2016-02-09 09:34:13 --> Language Class Initialized
INFO - 2016-02-09 09:34:13 --> Loader Class Initialized
INFO - 2016-02-09 09:34:13 --> Helper loaded: url_helper
INFO - 2016-02-09 09:34:13 --> Helper loaded: file_helper
INFO - 2016-02-09 09:34:13 --> Helper loaded: date_helper
INFO - 2016-02-09 09:34:13 --> Helper loaded: form_helper
INFO - 2016-02-09 09:34:13 --> Database Driver Class Initialized
INFO - 2016-02-09 09:34:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:34:14 --> Controller Class Initialized
INFO - 2016-02-09 09:34:14 --> Model Class Initialized
INFO - 2016-02-09 09:34:14 --> Model Class Initialized
INFO - 2016-02-09 09:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:34:14 --> Pagination Class Initialized
INFO - 2016-02-09 12:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:34:14 --> Helper loaded: text_helper
INFO - 2016-02-09 12:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:34:14 --> Final output sent to browser
DEBUG - 2016-02-09 12:34:14 --> Total execution time: 1.1991
INFO - 2016-02-09 09:34:26 --> Config Class Initialized
INFO - 2016-02-09 09:34:26 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:34:26 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:34:26 --> Utf8 Class Initialized
INFO - 2016-02-09 09:34:26 --> URI Class Initialized
INFO - 2016-02-09 09:34:26 --> Router Class Initialized
INFO - 2016-02-09 09:34:26 --> Output Class Initialized
INFO - 2016-02-09 09:34:26 --> Security Class Initialized
DEBUG - 2016-02-09 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:34:26 --> Input Class Initialized
INFO - 2016-02-09 09:34:26 --> Language Class Initialized
INFO - 2016-02-09 09:34:26 --> Loader Class Initialized
INFO - 2016-02-09 09:34:26 --> Helper loaded: url_helper
INFO - 2016-02-09 09:34:26 --> Helper loaded: file_helper
INFO - 2016-02-09 09:34:26 --> Helper loaded: date_helper
INFO - 2016-02-09 09:34:26 --> Helper loaded: form_helper
INFO - 2016-02-09 09:34:26 --> Database Driver Class Initialized
INFO - 2016-02-09 09:34:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:34:27 --> Controller Class Initialized
INFO - 2016-02-09 09:34:27 --> Model Class Initialized
INFO - 2016-02-09 09:34:27 --> Model Class Initialized
INFO - 2016-02-09 09:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:34:27 --> Pagination Class Initialized
INFO - 2016-02-09 12:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:34:27 --> Helper loaded: text_helper
INFO - 2016-02-09 12:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:34:27 --> Final output sent to browser
DEBUG - 2016-02-09 12:34:27 --> Total execution time: 1.2137
INFO - 2016-02-09 09:34:48 --> Config Class Initialized
INFO - 2016-02-09 09:34:48 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:34:48 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:34:48 --> Utf8 Class Initialized
INFO - 2016-02-09 09:34:48 --> URI Class Initialized
INFO - 2016-02-09 09:34:48 --> Router Class Initialized
INFO - 2016-02-09 09:34:48 --> Output Class Initialized
INFO - 2016-02-09 09:34:48 --> Security Class Initialized
DEBUG - 2016-02-09 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:34:48 --> Input Class Initialized
INFO - 2016-02-09 09:34:48 --> Language Class Initialized
INFO - 2016-02-09 09:34:48 --> Loader Class Initialized
INFO - 2016-02-09 09:34:48 --> Helper loaded: url_helper
INFO - 2016-02-09 09:34:48 --> Helper loaded: file_helper
INFO - 2016-02-09 09:34:48 --> Helper loaded: date_helper
INFO - 2016-02-09 09:34:48 --> Helper loaded: form_helper
INFO - 2016-02-09 09:34:48 --> Database Driver Class Initialized
INFO - 2016-02-09 09:34:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:34:49 --> Controller Class Initialized
INFO - 2016-02-09 09:34:49 --> Model Class Initialized
INFO - 2016-02-09 09:34:49 --> Model Class Initialized
INFO - 2016-02-09 09:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:34:49 --> Pagination Class Initialized
INFO - 2016-02-09 12:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:34:49 --> Helper loaded: text_helper
INFO - 2016-02-09 12:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:34:49 --> Final output sent to browser
DEBUG - 2016-02-09 12:34:49 --> Total execution time: 1.1823
INFO - 2016-02-09 09:35:05 --> Config Class Initialized
INFO - 2016-02-09 09:35:05 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:35:05 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:35:05 --> Utf8 Class Initialized
INFO - 2016-02-09 09:35:05 --> URI Class Initialized
INFO - 2016-02-09 09:35:05 --> Router Class Initialized
INFO - 2016-02-09 09:35:05 --> Output Class Initialized
INFO - 2016-02-09 09:35:05 --> Security Class Initialized
DEBUG - 2016-02-09 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:35:05 --> Input Class Initialized
INFO - 2016-02-09 09:35:05 --> Language Class Initialized
INFO - 2016-02-09 09:35:05 --> Loader Class Initialized
INFO - 2016-02-09 09:35:05 --> Helper loaded: url_helper
INFO - 2016-02-09 09:35:05 --> Helper loaded: file_helper
INFO - 2016-02-09 09:35:05 --> Helper loaded: date_helper
INFO - 2016-02-09 09:35:05 --> Helper loaded: form_helper
INFO - 2016-02-09 09:35:05 --> Database Driver Class Initialized
INFO - 2016-02-09 09:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:35:06 --> Controller Class Initialized
INFO - 2016-02-09 09:35:06 --> Model Class Initialized
INFO - 2016-02-09 09:35:06 --> Model Class Initialized
INFO - 2016-02-09 09:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:35:06 --> Pagination Class Initialized
INFO - 2016-02-09 12:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:35:06 --> Helper loaded: text_helper
INFO - 2016-02-09 12:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:35:06 --> Final output sent to browser
DEBUG - 2016-02-09 12:35:06 --> Total execution time: 1.1856
INFO - 2016-02-09 09:35:16 --> Config Class Initialized
INFO - 2016-02-09 09:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:35:16 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:35:16 --> Utf8 Class Initialized
INFO - 2016-02-09 09:35:16 --> URI Class Initialized
INFO - 2016-02-09 09:35:16 --> Router Class Initialized
INFO - 2016-02-09 09:35:16 --> Output Class Initialized
INFO - 2016-02-09 09:35:16 --> Security Class Initialized
DEBUG - 2016-02-09 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:35:16 --> Input Class Initialized
INFO - 2016-02-09 09:35:16 --> Language Class Initialized
INFO - 2016-02-09 09:35:16 --> Loader Class Initialized
INFO - 2016-02-09 09:35:16 --> Helper loaded: url_helper
INFO - 2016-02-09 09:35:16 --> Helper loaded: file_helper
INFO - 2016-02-09 09:35:16 --> Helper loaded: date_helper
INFO - 2016-02-09 09:35:16 --> Helper loaded: form_helper
INFO - 2016-02-09 09:35:16 --> Database Driver Class Initialized
INFO - 2016-02-09 09:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:35:17 --> Controller Class Initialized
INFO - 2016-02-09 09:35:17 --> Model Class Initialized
INFO - 2016-02-09 09:35:17 --> Model Class Initialized
INFO - 2016-02-09 09:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:35:17 --> Pagination Class Initialized
INFO - 2016-02-09 12:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:35:17 --> Helper loaded: text_helper
INFO - 2016-02-09 12:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:35:17 --> Final output sent to browser
DEBUG - 2016-02-09 12:35:17 --> Total execution time: 1.1961
INFO - 2016-02-09 09:35:26 --> Config Class Initialized
INFO - 2016-02-09 09:35:26 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:35:26 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:35:26 --> Utf8 Class Initialized
INFO - 2016-02-09 09:35:26 --> URI Class Initialized
INFO - 2016-02-09 09:35:26 --> Router Class Initialized
INFO - 2016-02-09 09:35:26 --> Output Class Initialized
INFO - 2016-02-09 09:35:26 --> Security Class Initialized
DEBUG - 2016-02-09 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:35:26 --> Input Class Initialized
INFO - 2016-02-09 09:35:26 --> Language Class Initialized
INFO - 2016-02-09 09:35:26 --> Loader Class Initialized
INFO - 2016-02-09 09:35:26 --> Helper loaded: url_helper
INFO - 2016-02-09 09:35:26 --> Helper loaded: file_helper
INFO - 2016-02-09 09:35:26 --> Helper loaded: date_helper
INFO - 2016-02-09 09:35:26 --> Helper loaded: form_helper
INFO - 2016-02-09 09:35:26 --> Database Driver Class Initialized
INFO - 2016-02-09 09:35:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:35:27 --> Controller Class Initialized
INFO - 2016-02-09 09:35:27 --> Model Class Initialized
INFO - 2016-02-09 09:35:27 --> Model Class Initialized
INFO - 2016-02-09 09:35:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:35:27 --> Pagination Class Initialized
INFO - 2016-02-09 12:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:35:27 --> Helper loaded: text_helper
INFO - 2016-02-09 12:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:35:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:35:27 --> Final output sent to browser
DEBUG - 2016-02-09 12:35:27 --> Total execution time: 1.1836
INFO - 2016-02-09 09:37:09 --> Config Class Initialized
INFO - 2016-02-09 09:37:09 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:37:09 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:37:09 --> Utf8 Class Initialized
INFO - 2016-02-09 09:37:09 --> URI Class Initialized
INFO - 2016-02-09 09:37:09 --> Router Class Initialized
INFO - 2016-02-09 09:37:09 --> Output Class Initialized
INFO - 2016-02-09 09:37:09 --> Security Class Initialized
DEBUG - 2016-02-09 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:37:09 --> Input Class Initialized
INFO - 2016-02-09 09:37:09 --> Language Class Initialized
INFO - 2016-02-09 09:37:09 --> Loader Class Initialized
INFO - 2016-02-09 09:37:09 --> Helper loaded: url_helper
INFO - 2016-02-09 09:37:09 --> Helper loaded: file_helper
INFO - 2016-02-09 09:37:09 --> Helper loaded: date_helper
INFO - 2016-02-09 09:37:09 --> Helper loaded: form_helper
INFO - 2016-02-09 09:37:09 --> Database Driver Class Initialized
INFO - 2016-02-09 09:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:37:10 --> Controller Class Initialized
INFO - 2016-02-09 09:37:10 --> Model Class Initialized
INFO - 2016-02-09 09:37:10 --> Model Class Initialized
INFO - 2016-02-09 09:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:37:10 --> Pagination Class Initialized
INFO - 2016-02-09 12:37:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:37:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:37:10 --> Helper loaded: text_helper
INFO - 2016-02-09 12:37:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:37:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:37:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:37:10 --> Final output sent to browser
DEBUG - 2016-02-09 12:37:10 --> Total execution time: 1.1691
INFO - 2016-02-09 09:39:53 --> Config Class Initialized
INFO - 2016-02-09 09:39:53 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:39:53 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:39:53 --> Utf8 Class Initialized
INFO - 2016-02-09 09:39:53 --> URI Class Initialized
INFO - 2016-02-09 09:39:53 --> Router Class Initialized
INFO - 2016-02-09 09:39:53 --> Output Class Initialized
INFO - 2016-02-09 09:39:53 --> Security Class Initialized
DEBUG - 2016-02-09 09:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:39:53 --> Input Class Initialized
INFO - 2016-02-09 09:39:53 --> Language Class Initialized
INFO - 2016-02-09 09:39:54 --> Loader Class Initialized
INFO - 2016-02-09 09:39:54 --> Helper loaded: url_helper
INFO - 2016-02-09 09:39:54 --> Helper loaded: file_helper
INFO - 2016-02-09 09:39:54 --> Helper loaded: date_helper
INFO - 2016-02-09 09:39:54 --> Helper loaded: form_helper
INFO - 2016-02-09 09:39:54 --> Database Driver Class Initialized
INFO - 2016-02-09 09:39:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:39:55 --> Controller Class Initialized
INFO - 2016-02-09 09:39:55 --> Model Class Initialized
INFO - 2016-02-09 09:39:55 --> Model Class Initialized
INFO - 2016-02-09 09:39:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:39:55 --> Pagination Class Initialized
INFO - 2016-02-09 12:39:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:39:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:39:55 --> Helper loaded: text_helper
INFO - 2016-02-09 12:39:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:39:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:39:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:39:55 --> Final output sent to browser
DEBUG - 2016-02-09 12:39:55 --> Total execution time: 1.3206
INFO - 2016-02-09 09:40:22 --> Config Class Initialized
INFO - 2016-02-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:40:22 --> Utf8 Class Initialized
INFO - 2016-02-09 09:40:22 --> URI Class Initialized
INFO - 2016-02-09 09:40:22 --> Router Class Initialized
INFO - 2016-02-09 09:40:22 --> Output Class Initialized
INFO - 2016-02-09 09:40:22 --> Security Class Initialized
DEBUG - 2016-02-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:40:22 --> Input Class Initialized
INFO - 2016-02-09 09:40:22 --> Language Class Initialized
INFO - 2016-02-09 09:40:22 --> Loader Class Initialized
INFO - 2016-02-09 09:40:22 --> Helper loaded: url_helper
INFO - 2016-02-09 09:40:22 --> Helper loaded: file_helper
INFO - 2016-02-09 09:40:22 --> Helper loaded: date_helper
INFO - 2016-02-09 09:40:22 --> Helper loaded: form_helper
INFO - 2016-02-09 09:40:23 --> Database Driver Class Initialized
INFO - 2016-02-09 09:40:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:40:24 --> Controller Class Initialized
INFO - 2016-02-09 09:40:24 --> Model Class Initialized
INFO - 2016-02-09 09:40:24 --> Model Class Initialized
INFO - 2016-02-09 09:40:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:40:24 --> Pagination Class Initialized
INFO - 2016-02-09 12:40:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:40:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:40:24 --> Helper loaded: text_helper
INFO - 2016-02-09 12:40:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:40:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:40:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:40:24 --> Final output sent to browser
DEBUG - 2016-02-09 12:40:24 --> Total execution time: 1.1818
INFO - 2016-02-09 09:41:55 --> Config Class Initialized
INFO - 2016-02-09 09:41:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:41:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:41:55 --> Utf8 Class Initialized
INFO - 2016-02-09 09:41:55 --> URI Class Initialized
INFO - 2016-02-09 09:41:55 --> Router Class Initialized
INFO - 2016-02-09 09:41:55 --> Output Class Initialized
INFO - 2016-02-09 09:41:55 --> Security Class Initialized
DEBUG - 2016-02-09 09:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:41:55 --> Input Class Initialized
INFO - 2016-02-09 09:41:55 --> Language Class Initialized
INFO - 2016-02-09 09:41:55 --> Loader Class Initialized
INFO - 2016-02-09 09:41:55 --> Helper loaded: url_helper
INFO - 2016-02-09 09:41:55 --> Helper loaded: file_helper
INFO - 2016-02-09 09:41:55 --> Helper loaded: date_helper
INFO - 2016-02-09 09:41:55 --> Helper loaded: form_helper
INFO - 2016-02-09 09:41:55 --> Database Driver Class Initialized
INFO - 2016-02-09 09:41:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:41:56 --> Controller Class Initialized
INFO - 2016-02-09 09:41:56 --> Model Class Initialized
INFO - 2016-02-09 09:41:56 --> Model Class Initialized
INFO - 2016-02-09 09:41:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:41:56 --> Pagination Class Initialized
INFO - 2016-02-09 12:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:41:56 --> Helper loaded: text_helper
INFO - 2016-02-09 12:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:41:56 --> Final output sent to browser
DEBUG - 2016-02-09 12:41:56 --> Total execution time: 1.1417
INFO - 2016-02-09 09:42:20 --> Config Class Initialized
INFO - 2016-02-09 09:42:20 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:42:20 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:42:20 --> Utf8 Class Initialized
INFO - 2016-02-09 09:42:20 --> URI Class Initialized
INFO - 2016-02-09 09:42:20 --> Router Class Initialized
INFO - 2016-02-09 09:42:20 --> Output Class Initialized
INFO - 2016-02-09 09:42:20 --> Security Class Initialized
DEBUG - 2016-02-09 09:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:42:20 --> Input Class Initialized
INFO - 2016-02-09 09:42:20 --> Language Class Initialized
INFO - 2016-02-09 09:42:20 --> Loader Class Initialized
INFO - 2016-02-09 09:42:20 --> Helper loaded: url_helper
INFO - 2016-02-09 09:42:20 --> Helper loaded: file_helper
INFO - 2016-02-09 09:42:20 --> Helper loaded: date_helper
INFO - 2016-02-09 09:42:20 --> Helper loaded: form_helper
INFO - 2016-02-09 09:42:20 --> Database Driver Class Initialized
INFO - 2016-02-09 09:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:42:21 --> Controller Class Initialized
INFO - 2016-02-09 09:42:21 --> Model Class Initialized
INFO - 2016-02-09 09:42:21 --> Model Class Initialized
INFO - 2016-02-09 09:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:42:21 --> Pagination Class Initialized
INFO - 2016-02-09 12:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:42:21 --> Helper loaded: text_helper
INFO - 2016-02-09 12:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:42:21 --> Final output sent to browser
DEBUG - 2016-02-09 12:42:21 --> Total execution time: 1.2287
INFO - 2016-02-09 09:42:27 --> Config Class Initialized
INFO - 2016-02-09 09:42:27 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:42:27 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:42:27 --> Utf8 Class Initialized
INFO - 2016-02-09 09:42:27 --> URI Class Initialized
INFO - 2016-02-09 09:42:27 --> Router Class Initialized
INFO - 2016-02-09 09:42:27 --> Output Class Initialized
INFO - 2016-02-09 09:42:27 --> Security Class Initialized
DEBUG - 2016-02-09 09:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:42:27 --> Input Class Initialized
INFO - 2016-02-09 09:42:27 --> Language Class Initialized
INFO - 2016-02-09 09:42:27 --> Loader Class Initialized
INFO - 2016-02-09 09:42:28 --> Helper loaded: url_helper
INFO - 2016-02-09 09:42:28 --> Helper loaded: file_helper
INFO - 2016-02-09 09:42:28 --> Helper loaded: date_helper
INFO - 2016-02-09 09:42:28 --> Helper loaded: form_helper
INFO - 2016-02-09 09:42:28 --> Database Driver Class Initialized
INFO - 2016-02-09 09:42:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:42:29 --> Controller Class Initialized
INFO - 2016-02-09 09:42:29 --> Model Class Initialized
INFO - 2016-02-09 09:42:29 --> Model Class Initialized
INFO - 2016-02-09 09:42:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:42:29 --> Pagination Class Initialized
INFO - 2016-02-09 12:42:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:42:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:42:29 --> Helper loaded: text_helper
INFO - 2016-02-09 12:42:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:42:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:42:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:42:29 --> Final output sent to browser
DEBUG - 2016-02-09 12:42:29 --> Total execution time: 1.2166
INFO - 2016-02-09 09:44:15 --> Config Class Initialized
INFO - 2016-02-09 09:44:15 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:44:15 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:44:15 --> Utf8 Class Initialized
INFO - 2016-02-09 09:44:15 --> URI Class Initialized
INFO - 2016-02-09 09:44:15 --> Router Class Initialized
INFO - 2016-02-09 09:44:15 --> Output Class Initialized
INFO - 2016-02-09 09:44:15 --> Security Class Initialized
DEBUG - 2016-02-09 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:44:15 --> Input Class Initialized
INFO - 2016-02-09 09:44:15 --> Language Class Initialized
INFO - 2016-02-09 09:44:15 --> Loader Class Initialized
INFO - 2016-02-09 09:44:15 --> Helper loaded: url_helper
INFO - 2016-02-09 09:44:15 --> Helper loaded: file_helper
INFO - 2016-02-09 09:44:15 --> Helper loaded: date_helper
INFO - 2016-02-09 09:44:15 --> Helper loaded: form_helper
INFO - 2016-02-09 09:44:15 --> Database Driver Class Initialized
INFO - 2016-02-09 09:44:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:44:16 --> Controller Class Initialized
INFO - 2016-02-09 09:44:16 --> Model Class Initialized
INFO - 2016-02-09 09:44:16 --> Model Class Initialized
INFO - 2016-02-09 09:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:44:16 --> Pagination Class Initialized
INFO - 2016-02-09 12:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:44:16 --> Helper loaded: text_helper
INFO - 2016-02-09 12:44:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:44:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:44:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:44:17 --> Final output sent to browser
DEBUG - 2016-02-09 12:44:17 --> Total execution time: 1.1750
INFO - 2016-02-09 09:44:47 --> Config Class Initialized
INFO - 2016-02-09 09:44:47 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:44:47 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:44:47 --> Utf8 Class Initialized
INFO - 2016-02-09 09:44:47 --> URI Class Initialized
INFO - 2016-02-09 09:44:47 --> Router Class Initialized
INFO - 2016-02-09 09:44:47 --> Output Class Initialized
INFO - 2016-02-09 09:44:47 --> Security Class Initialized
DEBUG - 2016-02-09 09:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:44:47 --> Input Class Initialized
INFO - 2016-02-09 09:44:47 --> Language Class Initialized
INFO - 2016-02-09 09:44:47 --> Loader Class Initialized
INFO - 2016-02-09 09:44:47 --> Helper loaded: url_helper
INFO - 2016-02-09 09:44:47 --> Helper loaded: file_helper
INFO - 2016-02-09 09:44:47 --> Helper loaded: date_helper
INFO - 2016-02-09 09:44:47 --> Helper loaded: form_helper
INFO - 2016-02-09 09:44:47 --> Database Driver Class Initialized
INFO - 2016-02-09 09:44:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:44:48 --> Controller Class Initialized
INFO - 2016-02-09 09:44:48 --> Model Class Initialized
INFO - 2016-02-09 09:44:48 --> Model Class Initialized
INFO - 2016-02-09 09:44:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:44:49 --> Pagination Class Initialized
INFO - 2016-02-09 12:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:44:49 --> Helper loaded: text_helper
INFO - 2016-02-09 12:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:44:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:44:49 --> Final output sent to browser
DEBUG - 2016-02-09 12:44:49 --> Total execution time: 1.1849
INFO - 2016-02-09 09:45:48 --> Config Class Initialized
INFO - 2016-02-09 09:45:48 --> Hooks Class Initialized
DEBUG - 2016-02-09 09:45:48 --> UTF-8 Support Enabled
INFO - 2016-02-09 09:45:48 --> Utf8 Class Initialized
INFO - 2016-02-09 09:45:48 --> URI Class Initialized
INFO - 2016-02-09 09:45:48 --> Router Class Initialized
INFO - 2016-02-09 09:45:48 --> Output Class Initialized
INFO - 2016-02-09 09:45:48 --> Security Class Initialized
DEBUG - 2016-02-09 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 09:45:48 --> Input Class Initialized
INFO - 2016-02-09 09:45:48 --> Language Class Initialized
INFO - 2016-02-09 09:45:48 --> Loader Class Initialized
INFO - 2016-02-09 09:45:48 --> Helper loaded: url_helper
INFO - 2016-02-09 09:45:48 --> Helper loaded: file_helper
INFO - 2016-02-09 09:45:48 --> Helper loaded: date_helper
INFO - 2016-02-09 09:45:48 --> Helper loaded: form_helper
INFO - 2016-02-09 09:45:48 --> Database Driver Class Initialized
INFO - 2016-02-09 09:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 09:45:49 --> Controller Class Initialized
INFO - 2016-02-09 09:45:49 --> Model Class Initialized
INFO - 2016-02-09 09:45:49 --> Model Class Initialized
INFO - 2016-02-09 09:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 09:45:49 --> Pagination Class Initialized
INFO - 2016-02-09 12:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 12:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 12:45:49 --> Helper loaded: text_helper
INFO - 2016-02-09 12:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 12:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 12:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 12:45:49 --> Final output sent to browser
DEBUG - 2016-02-09 12:45:49 --> Total execution time: 1.2097
INFO - 2016-02-09 11:26:43 --> Config Class Initialized
INFO - 2016-02-09 11:26:43 --> Hooks Class Initialized
DEBUG - 2016-02-09 11:26:43 --> UTF-8 Support Enabled
INFO - 2016-02-09 11:26:43 --> Utf8 Class Initialized
INFO - 2016-02-09 11:26:43 --> URI Class Initialized
DEBUG - 2016-02-09 11:26:43 --> No URI present. Default controller set.
INFO - 2016-02-09 11:26:43 --> Router Class Initialized
INFO - 2016-02-09 11:26:43 --> Output Class Initialized
INFO - 2016-02-09 11:26:43 --> Security Class Initialized
DEBUG - 2016-02-09 11:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 11:26:43 --> Input Class Initialized
INFO - 2016-02-09 11:26:43 --> Language Class Initialized
INFO - 2016-02-09 11:26:43 --> Loader Class Initialized
INFO - 2016-02-09 11:26:43 --> Helper loaded: url_helper
INFO - 2016-02-09 11:26:43 --> Helper loaded: file_helper
INFO - 2016-02-09 11:26:43 --> Helper loaded: date_helper
INFO - 2016-02-09 11:26:43 --> Helper loaded: form_helper
INFO - 2016-02-09 11:26:43 --> Database Driver Class Initialized
INFO - 2016-02-09 11:26:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 11:26:44 --> Controller Class Initialized
INFO - 2016-02-09 11:26:44 --> Model Class Initialized
INFO - 2016-02-09 11:26:44 --> Model Class Initialized
INFO - 2016-02-09 11:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 11:26:44 --> Pagination Class Initialized
INFO - 2016-02-09 14:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 14:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 14:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 14:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 14:26:44 --> Final output sent to browser
DEBUG - 2016-02-09 14:26:44 --> Total execution time: 1.1463
INFO - 2016-02-09 14:29:35 --> Config Class Initialized
INFO - 2016-02-09 14:29:35 --> Hooks Class Initialized
DEBUG - 2016-02-09 14:29:35 --> UTF-8 Support Enabled
INFO - 2016-02-09 14:29:35 --> Utf8 Class Initialized
INFO - 2016-02-09 14:29:35 --> URI Class Initialized
INFO - 2016-02-09 14:29:35 --> Router Class Initialized
INFO - 2016-02-09 14:29:35 --> Output Class Initialized
INFO - 2016-02-09 14:29:35 --> Security Class Initialized
DEBUG - 2016-02-09 14:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 14:29:35 --> Input Class Initialized
INFO - 2016-02-09 14:29:35 --> Language Class Initialized
INFO - 2016-02-09 14:29:35 --> Loader Class Initialized
INFO - 2016-02-09 14:29:35 --> Helper loaded: url_helper
INFO - 2016-02-09 14:29:35 --> Helper loaded: file_helper
INFO - 2016-02-09 14:29:35 --> Helper loaded: date_helper
INFO - 2016-02-09 14:29:35 --> Helper loaded: form_helper
INFO - 2016-02-09 14:29:35 --> Database Driver Class Initialized
INFO - 2016-02-09 14:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 14:29:36 --> Controller Class Initialized
INFO - 2016-02-09 14:29:36 --> Model Class Initialized
INFO - 2016-02-09 14:29:36 --> Model Class Initialized
INFO - 2016-02-09 14:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 14:29:36 --> Pagination Class Initialized
INFO - 2016-02-09 17:29:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 17:29:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 17:29:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 17:29:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 17:29:36 --> Final output sent to browser
DEBUG - 2016-02-09 17:29:36 --> Total execution time: 1.1454
INFO - 2016-02-09 14:29:38 --> Config Class Initialized
INFO - 2016-02-09 14:29:38 --> Hooks Class Initialized
DEBUG - 2016-02-09 14:29:38 --> UTF-8 Support Enabled
INFO - 2016-02-09 14:29:38 --> Utf8 Class Initialized
INFO - 2016-02-09 14:29:38 --> URI Class Initialized
DEBUG - 2016-02-09 14:29:38 --> No URI present. Default controller set.
INFO - 2016-02-09 14:29:38 --> Router Class Initialized
INFO - 2016-02-09 14:29:38 --> Output Class Initialized
INFO - 2016-02-09 14:29:38 --> Security Class Initialized
DEBUG - 2016-02-09 14:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 14:29:38 --> Input Class Initialized
INFO - 2016-02-09 14:29:38 --> Language Class Initialized
INFO - 2016-02-09 14:29:38 --> Loader Class Initialized
INFO - 2016-02-09 14:29:38 --> Helper loaded: url_helper
INFO - 2016-02-09 14:29:38 --> Helper loaded: file_helper
INFO - 2016-02-09 14:29:38 --> Helper loaded: date_helper
INFO - 2016-02-09 14:29:38 --> Helper loaded: form_helper
INFO - 2016-02-09 14:29:38 --> Database Driver Class Initialized
INFO - 2016-02-09 14:29:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 14:29:39 --> Controller Class Initialized
INFO - 2016-02-09 14:29:39 --> Model Class Initialized
INFO - 2016-02-09 14:29:39 --> Model Class Initialized
INFO - 2016-02-09 14:29:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 14:29:39 --> Pagination Class Initialized
INFO - 2016-02-09 17:29:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 17:29:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 17:29:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 17:29:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 17:29:39 --> Final output sent to browser
DEBUG - 2016-02-09 17:29:39 --> Total execution time: 1.1585
INFO - 2016-02-09 15:13:30 --> Config Class Initialized
INFO - 2016-02-09 15:13:30 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:13:30 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:13:30 --> Utf8 Class Initialized
INFO - 2016-02-09 15:13:30 --> URI Class Initialized
DEBUG - 2016-02-09 15:13:30 --> No URI present. Default controller set.
INFO - 2016-02-09 15:13:30 --> Router Class Initialized
INFO - 2016-02-09 15:13:30 --> Output Class Initialized
INFO - 2016-02-09 15:13:30 --> Security Class Initialized
DEBUG - 2016-02-09 15:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:13:30 --> Input Class Initialized
INFO - 2016-02-09 15:13:30 --> Language Class Initialized
INFO - 2016-02-09 15:13:30 --> Loader Class Initialized
INFO - 2016-02-09 15:13:30 --> Helper loaded: url_helper
INFO - 2016-02-09 15:13:30 --> Helper loaded: file_helper
INFO - 2016-02-09 15:13:30 --> Helper loaded: date_helper
INFO - 2016-02-09 15:13:30 --> Helper loaded: form_helper
INFO - 2016-02-09 15:13:30 --> Database Driver Class Initialized
INFO - 2016-02-09 15:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:13:31 --> Controller Class Initialized
INFO - 2016-02-09 15:13:31 --> Model Class Initialized
INFO - 2016-02-09 15:13:31 --> Model Class Initialized
INFO - 2016-02-09 15:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:13:32 --> Pagination Class Initialized
INFO - 2016-02-09 18:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:13:32 --> Final output sent to browser
DEBUG - 2016-02-09 18:13:32 --> Total execution time: 1.1320
INFO - 2016-02-09 15:13:35 --> Config Class Initialized
INFO - 2016-02-09 15:13:35 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:13:35 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:13:35 --> Utf8 Class Initialized
INFO - 2016-02-09 15:13:35 --> URI Class Initialized
INFO - 2016-02-09 15:13:35 --> Router Class Initialized
INFO - 2016-02-09 15:13:35 --> Output Class Initialized
INFO - 2016-02-09 15:13:35 --> Security Class Initialized
DEBUG - 2016-02-09 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:13:35 --> Input Class Initialized
INFO - 2016-02-09 15:13:35 --> Language Class Initialized
INFO - 2016-02-09 15:13:35 --> Loader Class Initialized
INFO - 2016-02-09 15:13:35 --> Helper loaded: url_helper
INFO - 2016-02-09 15:13:35 --> Helper loaded: file_helper
INFO - 2016-02-09 15:13:35 --> Helper loaded: date_helper
INFO - 2016-02-09 15:13:35 --> Helper loaded: form_helper
INFO - 2016-02-09 15:13:35 --> Database Driver Class Initialized
INFO - 2016-02-09 15:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:13:36 --> Controller Class Initialized
INFO - 2016-02-09 15:13:36 --> Model Class Initialized
INFO - 2016-02-09 15:13:36 --> Model Class Initialized
INFO - 2016-02-09 15:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:13:36 --> Pagination Class Initialized
INFO - 2016-02-09 18:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:13:36 --> Final output sent to browser
DEBUG - 2016-02-09 18:13:36 --> Total execution time: 1.1370
INFO - 2016-02-09 15:13:37 --> Config Class Initialized
INFO - 2016-02-09 15:13:37 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:13:37 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:13:37 --> Utf8 Class Initialized
INFO - 2016-02-09 15:13:37 --> URI Class Initialized
INFO - 2016-02-09 15:13:37 --> Router Class Initialized
INFO - 2016-02-09 15:13:37 --> Output Class Initialized
INFO - 2016-02-09 15:13:37 --> Security Class Initialized
DEBUG - 2016-02-09 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:13:37 --> Input Class Initialized
INFO - 2016-02-09 15:13:37 --> Language Class Initialized
INFO - 2016-02-09 15:13:37 --> Loader Class Initialized
INFO - 2016-02-09 15:13:37 --> Helper loaded: url_helper
INFO - 2016-02-09 15:13:37 --> Helper loaded: file_helper
INFO - 2016-02-09 15:13:37 --> Helper loaded: date_helper
INFO - 2016-02-09 15:13:37 --> Helper loaded: form_helper
INFO - 2016-02-09 15:13:37 --> Database Driver Class Initialized
INFO - 2016-02-09 15:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:13:38 --> Controller Class Initialized
INFO - 2016-02-09 15:13:38 --> Model Class Initialized
INFO - 2016-02-09 15:13:38 --> Model Class Initialized
INFO - 2016-02-09 15:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:13:38 --> Pagination Class Initialized
INFO - 2016-02-09 18:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:13:38 --> Final output sent to browser
DEBUG - 2016-02-09 18:13:38 --> Total execution time: 1.0902
INFO - 2016-02-09 15:13:53 --> Config Class Initialized
INFO - 2016-02-09 15:13:54 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:13:54 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:13:54 --> Utf8 Class Initialized
INFO - 2016-02-09 15:13:54 --> URI Class Initialized
INFO - 2016-02-09 15:13:54 --> Router Class Initialized
INFO - 2016-02-09 15:13:54 --> Output Class Initialized
INFO - 2016-02-09 15:13:54 --> Security Class Initialized
DEBUG - 2016-02-09 15:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:13:54 --> Input Class Initialized
INFO - 2016-02-09 15:13:54 --> Language Class Initialized
INFO - 2016-02-09 15:13:54 --> Loader Class Initialized
INFO - 2016-02-09 15:13:54 --> Helper loaded: url_helper
INFO - 2016-02-09 15:13:54 --> Helper loaded: file_helper
INFO - 2016-02-09 15:13:54 --> Helper loaded: date_helper
INFO - 2016-02-09 15:13:54 --> Helper loaded: form_helper
INFO - 2016-02-09 15:13:54 --> Database Driver Class Initialized
INFO - 2016-02-09 15:13:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:13:55 --> Controller Class Initialized
INFO - 2016-02-09 15:13:55 --> Model Class Initialized
INFO - 2016-02-09 15:13:55 --> Model Class Initialized
INFO - 2016-02-09 15:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:13:55 --> Pagination Class Initialized
INFO - 2016-02-09 18:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:13:55 --> Helper loaded: text_helper
INFO - 2016-02-09 18:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:13:55 --> Final output sent to browser
DEBUG - 2016-02-09 18:13:55 --> Total execution time: 1.2042
INFO - 2016-02-09 15:14:22 --> Config Class Initialized
INFO - 2016-02-09 15:14:22 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:14:22 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:14:22 --> Utf8 Class Initialized
INFO - 2016-02-09 15:14:22 --> URI Class Initialized
DEBUG - 2016-02-09 15:14:22 --> No URI present. Default controller set.
INFO - 2016-02-09 15:14:22 --> Router Class Initialized
INFO - 2016-02-09 15:14:22 --> Output Class Initialized
INFO - 2016-02-09 15:14:22 --> Security Class Initialized
DEBUG - 2016-02-09 15:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:14:22 --> Input Class Initialized
INFO - 2016-02-09 15:14:22 --> Language Class Initialized
INFO - 2016-02-09 15:14:22 --> Loader Class Initialized
INFO - 2016-02-09 15:14:22 --> Helper loaded: url_helper
INFO - 2016-02-09 15:14:22 --> Helper loaded: file_helper
INFO - 2016-02-09 15:14:22 --> Helper loaded: date_helper
INFO - 2016-02-09 15:14:22 --> Helper loaded: form_helper
INFO - 2016-02-09 15:14:22 --> Database Driver Class Initialized
INFO - 2016-02-09 15:14:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:14:23 --> Controller Class Initialized
INFO - 2016-02-09 15:14:23 --> Model Class Initialized
INFO - 2016-02-09 15:14:23 --> Model Class Initialized
INFO - 2016-02-09 15:14:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:14:23 --> Pagination Class Initialized
INFO - 2016-02-09 18:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:14:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:14:23 --> Final output sent to browser
DEBUG - 2016-02-09 18:14:23 --> Total execution time: 1.1259
INFO - 2016-02-09 15:14:44 --> Config Class Initialized
INFO - 2016-02-09 15:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:14:44 --> Utf8 Class Initialized
INFO - 2016-02-09 15:14:44 --> URI Class Initialized
INFO - 2016-02-09 15:14:44 --> Router Class Initialized
INFO - 2016-02-09 15:14:44 --> Output Class Initialized
INFO - 2016-02-09 15:14:44 --> Security Class Initialized
DEBUG - 2016-02-09 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:14:44 --> Input Class Initialized
INFO - 2016-02-09 15:14:44 --> Language Class Initialized
INFO - 2016-02-09 15:14:44 --> Loader Class Initialized
INFO - 2016-02-09 15:14:44 --> Helper loaded: url_helper
INFO - 2016-02-09 15:14:44 --> Helper loaded: file_helper
INFO - 2016-02-09 15:14:44 --> Helper loaded: date_helper
INFO - 2016-02-09 15:14:44 --> Helper loaded: form_helper
INFO - 2016-02-09 15:14:44 --> Database Driver Class Initialized
INFO - 2016-02-09 15:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:14:45 --> Controller Class Initialized
INFO - 2016-02-09 15:14:45 --> Model Class Initialized
INFO - 2016-02-09 15:14:45 --> Model Class Initialized
INFO - 2016-02-09 15:14:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:14:46 --> Pagination Class Initialized
INFO - 2016-02-09 18:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:14:46 --> Helper loaded: text_helper
INFO - 2016-02-09 18:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:14:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:14:46 --> Final output sent to browser
DEBUG - 2016-02-09 18:14:46 --> Total execution time: 1.1688
INFO - 2016-02-09 15:15:07 --> Config Class Initialized
INFO - 2016-02-09 15:15:07 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:15:07 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:15:07 --> Utf8 Class Initialized
INFO - 2016-02-09 15:15:07 --> URI Class Initialized
DEBUG - 2016-02-09 15:15:07 --> No URI present. Default controller set.
INFO - 2016-02-09 15:15:07 --> Router Class Initialized
INFO - 2016-02-09 15:15:07 --> Output Class Initialized
INFO - 2016-02-09 15:15:07 --> Security Class Initialized
DEBUG - 2016-02-09 15:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:15:07 --> Input Class Initialized
INFO - 2016-02-09 15:15:07 --> Language Class Initialized
INFO - 2016-02-09 15:15:07 --> Loader Class Initialized
INFO - 2016-02-09 15:15:07 --> Helper loaded: url_helper
INFO - 2016-02-09 15:15:07 --> Helper loaded: file_helper
INFO - 2016-02-09 15:15:07 --> Helper loaded: date_helper
INFO - 2016-02-09 15:15:07 --> Helper loaded: form_helper
INFO - 2016-02-09 15:15:07 --> Database Driver Class Initialized
INFO - 2016-02-09 15:15:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:15:08 --> Controller Class Initialized
INFO - 2016-02-09 15:15:08 --> Model Class Initialized
INFO - 2016-02-09 15:15:08 --> Model Class Initialized
INFO - 2016-02-09 15:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:15:08 --> Pagination Class Initialized
INFO - 2016-02-09 18:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:15:08 --> Final output sent to browser
DEBUG - 2016-02-09 18:15:08 --> Total execution time: 1.1268
INFO - 2016-02-09 15:15:16 --> Config Class Initialized
INFO - 2016-02-09 15:15:16 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:15:16 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:15:16 --> Utf8 Class Initialized
INFO - 2016-02-09 15:15:16 --> URI Class Initialized
INFO - 2016-02-09 15:15:16 --> Router Class Initialized
INFO - 2016-02-09 15:15:16 --> Output Class Initialized
INFO - 2016-02-09 15:15:16 --> Security Class Initialized
DEBUG - 2016-02-09 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:15:16 --> Input Class Initialized
INFO - 2016-02-09 15:15:16 --> Language Class Initialized
INFO - 2016-02-09 15:15:16 --> Loader Class Initialized
INFO - 2016-02-09 15:15:16 --> Helper loaded: url_helper
INFO - 2016-02-09 15:15:16 --> Helper loaded: file_helper
INFO - 2016-02-09 15:15:16 --> Helper loaded: date_helper
INFO - 2016-02-09 15:15:16 --> Helper loaded: form_helper
INFO - 2016-02-09 15:15:16 --> Database Driver Class Initialized
INFO - 2016-02-09 15:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:15:17 --> Controller Class Initialized
INFO - 2016-02-09 15:15:17 --> Model Class Initialized
INFO - 2016-02-09 15:15:17 --> Model Class Initialized
INFO - 2016-02-09 15:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:15:17 --> Pagination Class Initialized
INFO - 2016-02-09 18:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:15:17 --> Helper loaded: text_helper
INFO - 2016-02-09 18:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:15:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:15:17 --> Final output sent to browser
DEBUG - 2016-02-09 18:15:17 --> Total execution time: 1.1615
INFO - 2016-02-09 15:15:55 --> Config Class Initialized
INFO - 2016-02-09 15:15:55 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:15:55 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:15:55 --> Utf8 Class Initialized
INFO - 2016-02-09 15:15:55 --> URI Class Initialized
INFO - 2016-02-09 15:15:55 --> Router Class Initialized
INFO - 2016-02-09 15:15:55 --> Output Class Initialized
INFO - 2016-02-09 15:15:55 --> Security Class Initialized
DEBUG - 2016-02-09 15:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:15:55 --> Input Class Initialized
INFO - 2016-02-09 15:15:55 --> Language Class Initialized
INFO - 2016-02-09 15:15:55 --> Loader Class Initialized
INFO - 2016-02-09 15:15:55 --> Helper loaded: url_helper
INFO - 2016-02-09 15:15:55 --> Helper loaded: file_helper
INFO - 2016-02-09 15:15:55 --> Helper loaded: date_helper
INFO - 2016-02-09 15:15:55 --> Helper loaded: form_helper
INFO - 2016-02-09 15:15:55 --> Database Driver Class Initialized
INFO - 2016-02-09 15:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:15:56 --> Controller Class Initialized
INFO - 2016-02-09 15:15:56 --> Model Class Initialized
INFO - 2016-02-09 15:15:56 --> Model Class Initialized
INFO - 2016-02-09 15:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:15:56 --> Pagination Class Initialized
INFO - 2016-02-09 18:15:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:15:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:15:56 --> Helper loaded: text_helper
INFO - 2016-02-09 18:15:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:15:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:15:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:15:56 --> Final output sent to browser
DEBUG - 2016-02-09 18:15:56 --> Total execution time: 1.2130
INFO - 2016-02-09 15:16:12 --> Config Class Initialized
INFO - 2016-02-09 15:16:12 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:16:12 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:16:12 --> Utf8 Class Initialized
INFO - 2016-02-09 15:16:12 --> URI Class Initialized
INFO - 2016-02-09 15:16:12 --> Router Class Initialized
INFO - 2016-02-09 15:16:12 --> Output Class Initialized
INFO - 2016-02-09 15:16:12 --> Security Class Initialized
DEBUG - 2016-02-09 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:16:12 --> Input Class Initialized
INFO - 2016-02-09 15:16:12 --> Language Class Initialized
INFO - 2016-02-09 15:16:12 --> Loader Class Initialized
INFO - 2016-02-09 15:16:12 --> Helper loaded: url_helper
INFO - 2016-02-09 15:16:12 --> Helper loaded: file_helper
INFO - 2016-02-09 15:16:12 --> Helper loaded: date_helper
INFO - 2016-02-09 15:16:12 --> Helper loaded: form_helper
INFO - 2016-02-09 15:16:12 --> Database Driver Class Initialized
INFO - 2016-02-09 15:16:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:16:13 --> Controller Class Initialized
INFO - 2016-02-09 15:16:13 --> Model Class Initialized
INFO - 2016-02-09 15:16:13 --> Model Class Initialized
INFO - 2016-02-09 15:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:16:13 --> Pagination Class Initialized
INFO - 2016-02-09 18:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:16:13 --> Helper loaded: text_helper
INFO - 2016-02-09 18:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:16:13 --> Final output sent to browser
DEBUG - 2016-02-09 18:16:13 --> Total execution time: 1.2260
INFO - 2016-02-09 15:17:19 --> Config Class Initialized
INFO - 2016-02-09 15:17:19 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:17:19 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:17:19 --> Utf8 Class Initialized
INFO - 2016-02-09 15:17:19 --> URI Class Initialized
INFO - 2016-02-09 15:17:19 --> Router Class Initialized
INFO - 2016-02-09 15:17:19 --> Output Class Initialized
INFO - 2016-02-09 15:17:19 --> Security Class Initialized
DEBUG - 2016-02-09 15:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:17:19 --> Input Class Initialized
INFO - 2016-02-09 15:17:19 --> Language Class Initialized
INFO - 2016-02-09 15:17:19 --> Loader Class Initialized
INFO - 2016-02-09 15:17:19 --> Helper loaded: url_helper
INFO - 2016-02-09 15:17:19 --> Helper loaded: file_helper
INFO - 2016-02-09 15:17:19 --> Helper loaded: date_helper
INFO - 2016-02-09 15:17:19 --> Helper loaded: form_helper
INFO - 2016-02-09 15:17:19 --> Database Driver Class Initialized
INFO - 2016-02-09 15:17:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:17:20 --> Controller Class Initialized
INFO - 2016-02-09 15:17:20 --> Model Class Initialized
INFO - 2016-02-09 15:17:20 --> Model Class Initialized
INFO - 2016-02-09 15:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:17:20 --> Pagination Class Initialized
INFO - 2016-02-09 18:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:17:20 --> Helper loaded: text_helper
INFO - 2016-02-09 18:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:17:20 --> Final output sent to browser
DEBUG - 2016-02-09 18:17:20 --> Total execution time: 1.2634
INFO - 2016-02-09 15:18:09 --> Config Class Initialized
INFO - 2016-02-09 15:18:09 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:18:09 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:18:09 --> Utf8 Class Initialized
INFO - 2016-02-09 15:18:09 --> URI Class Initialized
INFO - 2016-02-09 15:18:09 --> Router Class Initialized
INFO - 2016-02-09 15:18:09 --> Output Class Initialized
INFO - 2016-02-09 15:18:09 --> Security Class Initialized
DEBUG - 2016-02-09 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:18:09 --> Input Class Initialized
INFO - 2016-02-09 15:18:09 --> Language Class Initialized
INFO - 2016-02-09 15:18:09 --> Loader Class Initialized
INFO - 2016-02-09 15:18:09 --> Helper loaded: url_helper
INFO - 2016-02-09 15:18:09 --> Helper loaded: file_helper
INFO - 2016-02-09 15:18:09 --> Helper loaded: date_helper
INFO - 2016-02-09 15:18:09 --> Helper loaded: form_helper
INFO - 2016-02-09 15:18:09 --> Database Driver Class Initialized
INFO - 2016-02-09 15:18:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:18:10 --> Controller Class Initialized
INFO - 2016-02-09 15:18:10 --> Model Class Initialized
INFO - 2016-02-09 15:18:10 --> Model Class Initialized
INFO - 2016-02-09 15:18:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:18:10 --> Pagination Class Initialized
INFO - 2016-02-09 18:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:18:10 --> Helper loaded: text_helper
INFO - 2016-02-09 18:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:18:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:18:10 --> Final output sent to browser
DEBUG - 2016-02-09 18:18:10 --> Total execution time: 1.2004
INFO - 2016-02-09 15:18:51 --> Config Class Initialized
INFO - 2016-02-09 15:18:51 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:18:51 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:18:51 --> Utf8 Class Initialized
INFO - 2016-02-09 15:18:51 --> URI Class Initialized
INFO - 2016-02-09 15:18:51 --> Router Class Initialized
INFO - 2016-02-09 15:18:51 --> Output Class Initialized
INFO - 2016-02-09 15:18:51 --> Security Class Initialized
DEBUG - 2016-02-09 15:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:18:51 --> Input Class Initialized
INFO - 2016-02-09 15:18:51 --> Language Class Initialized
INFO - 2016-02-09 15:18:51 --> Loader Class Initialized
INFO - 2016-02-09 15:18:51 --> Helper loaded: url_helper
INFO - 2016-02-09 15:18:51 --> Helper loaded: file_helper
INFO - 2016-02-09 15:18:51 --> Helper loaded: date_helper
INFO - 2016-02-09 15:18:51 --> Helper loaded: form_helper
INFO - 2016-02-09 15:18:51 --> Database Driver Class Initialized
INFO - 2016-02-09 15:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:18:52 --> Controller Class Initialized
INFO - 2016-02-09 15:18:52 --> Model Class Initialized
INFO - 2016-02-09 15:18:52 --> Model Class Initialized
INFO - 2016-02-09 15:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:18:52 --> Pagination Class Initialized
INFO - 2016-02-09 18:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:18:52 --> Helper loaded: text_helper
INFO - 2016-02-09 18:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-09 18:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-09 18:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:18:52 --> Final output sent to browser
DEBUG - 2016-02-09 18:18:52 --> Total execution time: 1.2015
INFO - 2016-02-09 15:32:20 --> Config Class Initialized
INFO - 2016-02-09 15:32:20 --> Hooks Class Initialized
DEBUG - 2016-02-09 15:32:20 --> UTF-8 Support Enabled
INFO - 2016-02-09 15:32:20 --> Utf8 Class Initialized
INFO - 2016-02-09 15:32:20 --> URI Class Initialized
DEBUG - 2016-02-09 15:32:20 --> No URI present. Default controller set.
INFO - 2016-02-09 15:32:20 --> Router Class Initialized
INFO - 2016-02-09 15:32:20 --> Output Class Initialized
INFO - 2016-02-09 15:32:20 --> Security Class Initialized
DEBUG - 2016-02-09 15:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-09 15:32:20 --> Input Class Initialized
INFO - 2016-02-09 15:32:20 --> Language Class Initialized
INFO - 2016-02-09 15:32:20 --> Loader Class Initialized
INFO - 2016-02-09 15:32:20 --> Helper loaded: url_helper
INFO - 2016-02-09 15:32:20 --> Helper loaded: file_helper
INFO - 2016-02-09 15:32:20 --> Helper loaded: date_helper
INFO - 2016-02-09 15:32:20 --> Helper loaded: form_helper
INFO - 2016-02-09 15:32:20 --> Database Driver Class Initialized
INFO - 2016-02-09 15:32:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-09 15:32:21 --> Controller Class Initialized
INFO - 2016-02-09 15:32:21 --> Model Class Initialized
INFO - 2016-02-09 15:32:21 --> Model Class Initialized
INFO - 2016-02-09 15:32:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-09 15:32:21 --> Pagination Class Initialized
INFO - 2016-02-09 18:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-09 18:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-09 18:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-09 18:32:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-09 18:32:21 --> Final output sent to browser
DEBUG - 2016-02-09 18:32:21 --> Total execution time: 1.1419
