<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-14 10:14:54 --> Config Class Initialized
INFO - 2016-02-14 10:14:54 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:14:54 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:14:54 --> Utf8 Class Initialized
INFO - 2016-02-14 10:14:54 --> URI Class Initialized
INFO - 2016-02-14 10:14:54 --> Router Class Initialized
INFO - 2016-02-14 10:14:54 --> Output Class Initialized
INFO - 2016-02-14 10:14:54 --> Security Class Initialized
DEBUG - 2016-02-14 10:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:14:54 --> Input Class Initialized
INFO - 2016-02-14 10:14:55 --> Language Class Initialized
INFO - 2016-02-14 10:14:55 --> Loader Class Initialized
INFO - 2016-02-14 10:14:55 --> Helper loaded: url_helper
INFO - 2016-02-14 10:14:55 --> Helper loaded: file_helper
INFO - 2016-02-14 10:14:55 --> Helper loaded: date_helper
INFO - 2016-02-14 10:14:55 --> Helper loaded: form_helper
INFO - 2016-02-14 10:14:55 --> Database Driver Class Initialized
INFO - 2016-02-14 10:14:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:14:56 --> Controller Class Initialized
INFO - 2016-02-14 10:14:56 --> Model Class Initialized
INFO - 2016-02-14 10:14:56 --> Model Class Initialized
INFO - 2016-02-14 10:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:14:56 --> Pagination Class Initialized
INFO - 2016-02-14 10:14:56 --> Helper loaded: text_helper
INFO - 2016-02-14 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:14:56 --> Final output sent to browser
DEBUG - 2016-02-14 13:14:56 --> Total execution time: 2.1522
INFO - 2016-02-14 10:20:17 --> Config Class Initialized
INFO - 2016-02-14 10:20:17 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:20:17 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:20:17 --> Utf8 Class Initialized
INFO - 2016-02-14 10:20:17 --> URI Class Initialized
INFO - 2016-02-14 10:20:17 --> Router Class Initialized
INFO - 2016-02-14 10:20:17 --> Output Class Initialized
INFO - 2016-02-14 10:20:17 --> Security Class Initialized
DEBUG - 2016-02-14 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:20:17 --> Input Class Initialized
INFO - 2016-02-14 10:20:17 --> Language Class Initialized
INFO - 2016-02-14 10:20:17 --> Loader Class Initialized
INFO - 2016-02-14 10:20:17 --> Helper loaded: url_helper
INFO - 2016-02-14 10:20:17 --> Helper loaded: file_helper
INFO - 2016-02-14 10:20:17 --> Helper loaded: date_helper
INFO - 2016-02-14 10:20:17 --> Helper loaded: form_helper
INFO - 2016-02-14 10:20:17 --> Database Driver Class Initialized
INFO - 2016-02-14 10:20:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:20:18 --> Controller Class Initialized
INFO - 2016-02-14 10:20:18 --> Model Class Initialized
INFO - 2016-02-14 10:20:18 --> Model Class Initialized
INFO - 2016-02-14 10:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:20:18 --> Pagination Class Initialized
INFO - 2016-02-14 10:20:18 --> Helper loaded: text_helper
INFO - 2016-02-14 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:20:18 --> Final output sent to browser
DEBUG - 2016-02-14 13:20:18 --> Total execution time: 1.0745
INFO - 2016-02-14 10:26:35 --> Config Class Initialized
INFO - 2016-02-14 10:26:35 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:26:35 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:26:35 --> Utf8 Class Initialized
INFO - 2016-02-14 10:26:35 --> URI Class Initialized
DEBUG - 2016-02-14 10:26:35 --> No URI present. Default controller set.
INFO - 2016-02-14 10:26:35 --> Router Class Initialized
INFO - 2016-02-14 10:26:35 --> Output Class Initialized
INFO - 2016-02-14 10:26:35 --> Security Class Initialized
DEBUG - 2016-02-14 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:26:35 --> Input Class Initialized
INFO - 2016-02-14 10:26:35 --> Language Class Initialized
INFO - 2016-02-14 10:26:35 --> Loader Class Initialized
INFO - 2016-02-14 10:26:35 --> Helper loaded: url_helper
INFO - 2016-02-14 10:26:35 --> Helper loaded: file_helper
INFO - 2016-02-14 10:26:35 --> Helper loaded: date_helper
INFO - 2016-02-14 10:26:35 --> Helper loaded: form_helper
INFO - 2016-02-14 10:26:36 --> Database Driver Class Initialized
INFO - 2016-02-14 10:26:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:26:37 --> Controller Class Initialized
INFO - 2016-02-14 10:26:37 --> Model Class Initialized
INFO - 2016-02-14 10:26:37 --> Model Class Initialized
INFO - 2016-02-14 10:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:26:37 --> Pagination Class Initialized
INFO - 2016-02-14 10:26:37 --> Helper loaded: text_helper
INFO - 2016-02-14 13:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:26:37 --> Final output sent to browser
DEBUG - 2016-02-14 13:26:37 --> Total execution time: 1.1723
INFO - 2016-02-14 10:26:40 --> Config Class Initialized
INFO - 2016-02-14 10:26:40 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:26:40 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:26:40 --> Utf8 Class Initialized
INFO - 2016-02-14 10:26:40 --> URI Class Initialized
INFO - 2016-02-14 10:26:40 --> Router Class Initialized
INFO - 2016-02-14 10:26:40 --> Output Class Initialized
INFO - 2016-02-14 10:26:40 --> Security Class Initialized
DEBUG - 2016-02-14 10:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:26:40 --> Input Class Initialized
INFO - 2016-02-14 10:26:40 --> Language Class Initialized
INFO - 2016-02-14 10:26:40 --> Loader Class Initialized
INFO - 2016-02-14 10:26:40 --> Helper loaded: url_helper
INFO - 2016-02-14 10:26:40 --> Helper loaded: file_helper
INFO - 2016-02-14 10:26:40 --> Helper loaded: date_helper
INFO - 2016-02-14 10:26:40 --> Helper loaded: form_helper
INFO - 2016-02-14 10:26:40 --> Database Driver Class Initialized
INFO - 2016-02-14 10:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:26:41 --> Controller Class Initialized
INFO - 2016-02-14 10:26:41 --> Model Class Initialized
INFO - 2016-02-14 10:26:41 --> Model Class Initialized
INFO - 2016-02-14 10:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:26:41 --> Pagination Class Initialized
INFO - 2016-02-14 10:26:41 --> Helper loaded: text_helper
INFO - 2016-02-14 13:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:26:42 --> Final output sent to browser
DEBUG - 2016-02-14 13:26:42 --> Total execution time: 1.1758
INFO - 2016-02-14 10:26:43 --> Config Class Initialized
INFO - 2016-02-14 10:26:43 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:26:43 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:26:43 --> Utf8 Class Initialized
INFO - 2016-02-14 10:26:43 --> URI Class Initialized
DEBUG - 2016-02-14 10:26:43 --> No URI present. Default controller set.
INFO - 2016-02-14 10:26:43 --> Router Class Initialized
INFO - 2016-02-14 10:26:43 --> Output Class Initialized
INFO - 2016-02-14 10:26:43 --> Security Class Initialized
DEBUG - 2016-02-14 10:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:26:44 --> Input Class Initialized
INFO - 2016-02-14 10:26:44 --> Language Class Initialized
INFO - 2016-02-14 10:26:44 --> Loader Class Initialized
INFO - 2016-02-14 10:26:44 --> Helper loaded: url_helper
INFO - 2016-02-14 10:26:44 --> Helper loaded: file_helper
INFO - 2016-02-14 10:26:44 --> Helper loaded: date_helper
INFO - 2016-02-14 10:26:44 --> Helper loaded: form_helper
INFO - 2016-02-14 10:26:44 --> Database Driver Class Initialized
INFO - 2016-02-14 10:26:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:26:45 --> Controller Class Initialized
INFO - 2016-02-14 10:26:45 --> Model Class Initialized
INFO - 2016-02-14 10:26:45 --> Model Class Initialized
INFO - 2016-02-14 10:26:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:26:45 --> Pagination Class Initialized
INFO - 2016-02-14 10:26:45 --> Helper loaded: text_helper
INFO - 2016-02-14 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:26:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:26:45 --> Final output sent to browser
DEBUG - 2016-02-14 13:26:45 --> Total execution time: 1.1418
INFO - 2016-02-14 10:27:15 --> Config Class Initialized
INFO - 2016-02-14 10:27:15 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:27:15 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:27:15 --> Utf8 Class Initialized
INFO - 2016-02-14 10:27:15 --> URI Class Initialized
DEBUG - 2016-02-14 10:27:15 --> No URI present. Default controller set.
INFO - 2016-02-14 10:27:15 --> Router Class Initialized
INFO - 2016-02-14 10:27:15 --> Output Class Initialized
INFO - 2016-02-14 10:27:15 --> Security Class Initialized
DEBUG - 2016-02-14 10:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:27:15 --> Input Class Initialized
INFO - 2016-02-14 10:27:15 --> Language Class Initialized
INFO - 2016-02-14 10:27:15 --> Loader Class Initialized
INFO - 2016-02-14 10:27:15 --> Helper loaded: url_helper
INFO - 2016-02-14 10:27:15 --> Helper loaded: file_helper
INFO - 2016-02-14 10:27:15 --> Helper loaded: date_helper
INFO - 2016-02-14 10:27:15 --> Helper loaded: form_helper
INFO - 2016-02-14 10:27:15 --> Database Driver Class Initialized
INFO - 2016-02-14 10:27:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:27:16 --> Controller Class Initialized
INFO - 2016-02-14 10:27:16 --> Model Class Initialized
INFO - 2016-02-14 10:27:16 --> Model Class Initialized
INFO - 2016-02-14 10:27:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:27:16 --> Pagination Class Initialized
INFO - 2016-02-14 10:27:16 --> Helper loaded: text_helper
INFO - 2016-02-14 13:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:27:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:27:16 --> Final output sent to browser
DEBUG - 2016-02-14 13:27:16 --> Total execution time: 1.1029
INFO - 2016-02-14 10:27:18 --> Config Class Initialized
INFO - 2016-02-14 10:27:18 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:27:18 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:27:18 --> Utf8 Class Initialized
INFO - 2016-02-14 10:27:18 --> URI Class Initialized
INFO - 2016-02-14 10:27:18 --> Router Class Initialized
INFO - 2016-02-14 10:27:18 --> Output Class Initialized
INFO - 2016-02-14 10:27:18 --> Security Class Initialized
DEBUG - 2016-02-14 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:27:18 --> Input Class Initialized
INFO - 2016-02-14 10:27:18 --> Language Class Initialized
INFO - 2016-02-14 10:27:18 --> Loader Class Initialized
INFO - 2016-02-14 10:27:18 --> Helper loaded: url_helper
INFO - 2016-02-14 10:27:18 --> Helper loaded: file_helper
INFO - 2016-02-14 10:27:18 --> Helper loaded: date_helper
INFO - 2016-02-14 10:27:18 --> Helper loaded: form_helper
INFO - 2016-02-14 10:27:18 --> Database Driver Class Initialized
INFO - 2016-02-14 10:27:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:27:19 --> Controller Class Initialized
INFO - 2016-02-14 10:27:19 --> Model Class Initialized
INFO - 2016-02-14 10:27:19 --> Model Class Initialized
INFO - 2016-02-14 10:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:27:19 --> Pagination Class Initialized
INFO - 2016-02-14 10:27:19 --> Helper loaded: text_helper
INFO - 2016-02-14 13:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:27:19 --> Final output sent to browser
DEBUG - 2016-02-14 13:27:19 --> Total execution time: 1.1761
INFO - 2016-02-14 10:27:25 --> Config Class Initialized
INFO - 2016-02-14 10:27:25 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:27:25 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:27:25 --> Utf8 Class Initialized
INFO - 2016-02-14 10:27:25 --> URI Class Initialized
DEBUG - 2016-02-14 10:27:25 --> No URI present. Default controller set.
INFO - 2016-02-14 10:27:25 --> Router Class Initialized
INFO - 2016-02-14 10:27:25 --> Output Class Initialized
INFO - 2016-02-14 10:27:25 --> Security Class Initialized
DEBUG - 2016-02-14 10:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:27:25 --> Input Class Initialized
INFO - 2016-02-14 10:27:25 --> Language Class Initialized
INFO - 2016-02-14 10:27:25 --> Loader Class Initialized
INFO - 2016-02-14 10:27:25 --> Helper loaded: url_helper
INFO - 2016-02-14 10:27:25 --> Helper loaded: file_helper
INFO - 2016-02-14 10:27:25 --> Helper loaded: date_helper
INFO - 2016-02-14 10:27:25 --> Helper loaded: form_helper
INFO - 2016-02-14 10:27:25 --> Database Driver Class Initialized
INFO - 2016-02-14 10:27:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:27:26 --> Controller Class Initialized
INFO - 2016-02-14 10:27:26 --> Model Class Initialized
INFO - 2016-02-14 10:27:26 --> Model Class Initialized
INFO - 2016-02-14 10:27:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:27:26 --> Pagination Class Initialized
INFO - 2016-02-14 10:27:26 --> Helper loaded: text_helper
INFO - 2016-02-14 13:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:27:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:27:26 --> Final output sent to browser
DEBUG - 2016-02-14 13:27:26 --> Total execution time: 1.1315
INFO - 2016-02-14 10:28:52 --> Config Class Initialized
INFO - 2016-02-14 10:28:52 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:28:52 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:28:52 --> Utf8 Class Initialized
INFO - 2016-02-14 10:28:52 --> URI Class Initialized
INFO - 2016-02-14 10:28:52 --> Router Class Initialized
INFO - 2016-02-14 10:28:52 --> Output Class Initialized
INFO - 2016-02-14 10:28:52 --> Security Class Initialized
DEBUG - 2016-02-14 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:28:52 --> Input Class Initialized
INFO - 2016-02-14 10:28:52 --> Language Class Initialized
INFO - 2016-02-14 10:28:52 --> Loader Class Initialized
INFO - 2016-02-14 10:28:52 --> Helper loaded: url_helper
INFO - 2016-02-14 10:28:52 --> Helper loaded: file_helper
INFO - 2016-02-14 10:28:52 --> Helper loaded: date_helper
INFO - 2016-02-14 10:28:52 --> Helper loaded: form_helper
INFO - 2016-02-14 10:28:52 --> Database Driver Class Initialized
INFO - 2016-02-14 10:28:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:28:53 --> Controller Class Initialized
INFO - 2016-02-14 10:28:53 --> Model Class Initialized
INFO - 2016-02-14 10:28:53 --> Model Class Initialized
INFO - 2016-02-14 10:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:28:53 --> Pagination Class Initialized
INFO - 2016-02-14 10:28:53 --> Helper loaded: text_helper
INFO - 2016-02-14 13:28:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:28:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:28:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:28:53 --> Final output sent to browser
DEBUG - 2016-02-14 13:28:53 --> Total execution time: 1.1046
INFO - 2016-02-14 10:29:02 --> Config Class Initialized
INFO - 2016-02-14 10:29:02 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:29:02 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:29:02 --> Utf8 Class Initialized
INFO - 2016-02-14 10:29:02 --> URI Class Initialized
DEBUG - 2016-02-14 10:29:02 --> No URI present. Default controller set.
INFO - 2016-02-14 10:29:02 --> Router Class Initialized
INFO - 2016-02-14 10:29:02 --> Output Class Initialized
INFO - 2016-02-14 10:29:02 --> Security Class Initialized
DEBUG - 2016-02-14 10:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:29:02 --> Input Class Initialized
INFO - 2016-02-14 10:29:02 --> Language Class Initialized
INFO - 2016-02-14 10:29:02 --> Loader Class Initialized
INFO - 2016-02-14 10:29:02 --> Helper loaded: url_helper
INFO - 2016-02-14 10:29:02 --> Helper loaded: file_helper
INFO - 2016-02-14 10:29:02 --> Helper loaded: date_helper
INFO - 2016-02-14 10:29:02 --> Helper loaded: form_helper
INFO - 2016-02-14 10:29:02 --> Database Driver Class Initialized
INFO - 2016-02-14 10:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:29:03 --> Controller Class Initialized
INFO - 2016-02-14 10:29:03 --> Model Class Initialized
INFO - 2016-02-14 10:29:03 --> Model Class Initialized
INFO - 2016-02-14 10:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:29:03 --> Pagination Class Initialized
INFO - 2016-02-14 10:29:03 --> Helper loaded: text_helper
INFO - 2016-02-14 13:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:29:03 --> Final output sent to browser
DEBUG - 2016-02-14 13:29:03 --> Total execution time: 1.1130
INFO - 2016-02-14 10:33:34 --> Config Class Initialized
INFO - 2016-02-14 10:33:34 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:33:34 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:33:34 --> Utf8 Class Initialized
INFO - 2016-02-14 10:33:34 --> URI Class Initialized
DEBUG - 2016-02-14 10:33:34 --> No URI present. Default controller set.
INFO - 2016-02-14 10:33:34 --> Router Class Initialized
INFO - 2016-02-14 10:33:34 --> Output Class Initialized
INFO - 2016-02-14 10:33:34 --> Security Class Initialized
DEBUG - 2016-02-14 10:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:33:34 --> Input Class Initialized
INFO - 2016-02-14 10:33:34 --> Language Class Initialized
INFO - 2016-02-14 10:33:34 --> Loader Class Initialized
INFO - 2016-02-14 10:33:34 --> Helper loaded: url_helper
INFO - 2016-02-14 10:33:34 --> Helper loaded: file_helper
INFO - 2016-02-14 10:33:34 --> Helper loaded: date_helper
INFO - 2016-02-14 10:33:34 --> Helper loaded: form_helper
INFO - 2016-02-14 10:33:34 --> Database Driver Class Initialized
INFO - 2016-02-14 10:33:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:33:35 --> Controller Class Initialized
INFO - 2016-02-14 10:33:35 --> Model Class Initialized
INFO - 2016-02-14 10:33:35 --> Model Class Initialized
INFO - 2016-02-14 10:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:33:35 --> Pagination Class Initialized
INFO - 2016-02-14 10:33:35 --> Helper loaded: text_helper
INFO - 2016-02-14 13:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:33:35 --> Final output sent to browser
DEBUG - 2016-02-14 13:33:35 --> Total execution time: 1.1197
INFO - 2016-02-14 10:33:38 --> Config Class Initialized
INFO - 2016-02-14 10:33:38 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:33:38 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:33:38 --> Utf8 Class Initialized
INFO - 2016-02-14 10:33:38 --> URI Class Initialized
DEBUG - 2016-02-14 10:33:38 --> No URI present. Default controller set.
INFO - 2016-02-14 10:33:38 --> Router Class Initialized
INFO - 2016-02-14 10:33:38 --> Output Class Initialized
INFO - 2016-02-14 10:33:38 --> Security Class Initialized
DEBUG - 2016-02-14 10:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:33:38 --> Input Class Initialized
INFO - 2016-02-14 10:33:38 --> Language Class Initialized
INFO - 2016-02-14 10:33:38 --> Loader Class Initialized
INFO - 2016-02-14 10:33:38 --> Helper loaded: url_helper
INFO - 2016-02-14 10:33:38 --> Helper loaded: file_helper
INFO - 2016-02-14 10:33:38 --> Helper loaded: date_helper
INFO - 2016-02-14 10:33:38 --> Helper loaded: form_helper
INFO - 2016-02-14 10:33:38 --> Database Driver Class Initialized
INFO - 2016-02-14 10:33:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:33:39 --> Controller Class Initialized
INFO - 2016-02-14 10:33:39 --> Model Class Initialized
INFO - 2016-02-14 10:33:39 --> Model Class Initialized
INFO - 2016-02-14 10:33:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:33:39 --> Pagination Class Initialized
INFO - 2016-02-14 10:33:39 --> Helper loaded: text_helper
INFO - 2016-02-14 13:33:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:33:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:33:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:33:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:33:39 --> Final output sent to browser
DEBUG - 2016-02-14 13:33:39 --> Total execution time: 1.1588
INFO - 2016-02-14 10:33:51 --> Config Class Initialized
INFO - 2016-02-14 10:33:51 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:33:51 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:33:51 --> Utf8 Class Initialized
INFO - 2016-02-14 10:33:51 --> URI Class Initialized
INFO - 2016-02-14 10:33:51 --> Router Class Initialized
INFO - 2016-02-14 10:33:51 --> Output Class Initialized
INFO - 2016-02-14 10:33:51 --> Security Class Initialized
DEBUG - 2016-02-14 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:33:51 --> Input Class Initialized
INFO - 2016-02-14 10:33:51 --> Language Class Initialized
INFO - 2016-02-14 10:33:51 --> Loader Class Initialized
INFO - 2016-02-14 10:33:51 --> Helper loaded: url_helper
INFO - 2016-02-14 10:33:51 --> Helper loaded: file_helper
INFO - 2016-02-14 10:33:51 --> Helper loaded: date_helper
INFO - 2016-02-14 10:33:51 --> Helper loaded: form_helper
INFO - 2016-02-14 10:33:51 --> Database Driver Class Initialized
INFO - 2016-02-14 10:33:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:33:52 --> Controller Class Initialized
INFO - 2016-02-14 10:33:52 --> Model Class Initialized
INFO - 2016-02-14 10:33:52 --> Model Class Initialized
INFO - 2016-02-14 10:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:33:53 --> Pagination Class Initialized
INFO - 2016-02-14 10:33:53 --> Helper loaded: text_helper
INFO - 2016-02-14 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-14 13:33:53 --> Final output sent to browser
DEBUG - 2016-02-14 13:33:53 --> Total execution time: 1.1113
INFO - 2016-02-14 10:33:55 --> Config Class Initialized
INFO - 2016-02-14 10:33:55 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:33:55 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:33:55 --> Utf8 Class Initialized
INFO - 2016-02-14 10:33:55 --> URI Class Initialized
DEBUG - 2016-02-14 10:33:55 --> No URI present. Default controller set.
INFO - 2016-02-14 10:33:55 --> Router Class Initialized
INFO - 2016-02-14 10:33:55 --> Output Class Initialized
INFO - 2016-02-14 10:33:55 --> Security Class Initialized
DEBUG - 2016-02-14 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:33:55 --> Input Class Initialized
INFO - 2016-02-14 10:33:55 --> Language Class Initialized
INFO - 2016-02-14 10:33:55 --> Loader Class Initialized
INFO - 2016-02-14 10:33:55 --> Helper loaded: url_helper
INFO - 2016-02-14 10:33:55 --> Helper loaded: file_helper
INFO - 2016-02-14 10:33:55 --> Helper loaded: date_helper
INFO - 2016-02-14 10:33:55 --> Helper loaded: form_helper
INFO - 2016-02-14 10:33:55 --> Database Driver Class Initialized
INFO - 2016-02-14 10:33:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:33:56 --> Controller Class Initialized
INFO - 2016-02-14 10:33:56 --> Model Class Initialized
INFO - 2016-02-14 10:33:56 --> Model Class Initialized
INFO - 2016-02-14 10:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:33:56 --> Pagination Class Initialized
INFO - 2016-02-14 10:33:56 --> Helper loaded: text_helper
INFO - 2016-02-14 13:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:33:56 --> Final output sent to browser
DEBUG - 2016-02-14 13:33:56 --> Total execution time: 1.1622
INFO - 2016-02-14 10:38:04 --> Config Class Initialized
INFO - 2016-02-14 10:38:04 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:38:04 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:38:04 --> Utf8 Class Initialized
INFO - 2016-02-14 10:38:04 --> URI Class Initialized
INFO - 2016-02-14 10:38:04 --> Router Class Initialized
INFO - 2016-02-14 10:38:04 --> Output Class Initialized
INFO - 2016-02-14 10:38:04 --> Security Class Initialized
DEBUG - 2016-02-14 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:38:04 --> Input Class Initialized
INFO - 2016-02-14 10:38:04 --> Language Class Initialized
INFO - 2016-02-14 10:38:04 --> Loader Class Initialized
INFO - 2016-02-14 10:38:04 --> Helper loaded: url_helper
INFO - 2016-02-14 10:38:04 --> Helper loaded: file_helper
INFO - 2016-02-14 10:38:04 --> Helper loaded: date_helper
INFO - 2016-02-14 10:38:04 --> Helper loaded: form_helper
INFO - 2016-02-14 10:38:04 --> Database Driver Class Initialized
INFO - 2016-02-14 10:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:38:05 --> Controller Class Initialized
INFO - 2016-02-14 10:38:05 --> Model Class Initialized
INFO - 2016-02-14 10:38:05 --> Model Class Initialized
INFO - 2016-02-14 10:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:38:05 --> Pagination Class Initialized
INFO - 2016-02-14 10:38:05 --> Helper loaded: text_helper
INFO - 2016-02-14 13:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-14 13:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-14 13:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:38:05 --> Final output sent to browser
DEBUG - 2016-02-14 13:38:05 --> Total execution time: 1.1366
INFO - 2016-02-14 10:38:18 --> Config Class Initialized
INFO - 2016-02-14 10:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-14 10:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-14 10:38:18 --> Utf8 Class Initialized
INFO - 2016-02-14 10:38:18 --> URI Class Initialized
DEBUG - 2016-02-14 10:38:18 --> No URI present. Default controller set.
INFO - 2016-02-14 10:38:18 --> Router Class Initialized
INFO - 2016-02-14 10:38:18 --> Output Class Initialized
INFO - 2016-02-14 10:38:18 --> Security Class Initialized
DEBUG - 2016-02-14 10:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 10:38:18 --> Input Class Initialized
INFO - 2016-02-14 10:38:18 --> Language Class Initialized
INFO - 2016-02-14 10:38:18 --> Loader Class Initialized
INFO - 2016-02-14 10:38:18 --> Helper loaded: url_helper
INFO - 2016-02-14 10:38:18 --> Helper loaded: file_helper
INFO - 2016-02-14 10:38:18 --> Helper loaded: date_helper
INFO - 2016-02-14 10:38:18 --> Helper loaded: form_helper
INFO - 2016-02-14 10:38:18 --> Database Driver Class Initialized
INFO - 2016-02-14 10:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 10:38:19 --> Controller Class Initialized
INFO - 2016-02-14 10:38:19 --> Model Class Initialized
INFO - 2016-02-14 10:38:19 --> Model Class Initialized
INFO - 2016-02-14 10:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 10:38:19 --> Pagination Class Initialized
INFO - 2016-02-14 10:38:19 --> Helper loaded: text_helper
INFO - 2016-02-14 13:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 13:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 13:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 13:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 13:38:19 --> Final output sent to browser
DEBUG - 2016-02-14 13:38:19 --> Total execution time: 1.1377
INFO - 2016-02-14 11:27:06 --> Config Class Initialized
INFO - 2016-02-14 11:27:06 --> Hooks Class Initialized
DEBUG - 2016-02-14 11:27:06 --> UTF-8 Support Enabled
INFO - 2016-02-14 11:27:06 --> Utf8 Class Initialized
INFO - 2016-02-14 11:27:06 --> URI Class Initialized
DEBUG - 2016-02-14 11:27:06 --> No URI present. Default controller set.
INFO - 2016-02-14 11:27:06 --> Router Class Initialized
INFO - 2016-02-14 11:27:06 --> Output Class Initialized
INFO - 2016-02-14 11:27:06 --> Security Class Initialized
DEBUG - 2016-02-14 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 11:27:06 --> Input Class Initialized
INFO - 2016-02-14 11:27:06 --> Language Class Initialized
INFO - 2016-02-14 11:27:06 --> Loader Class Initialized
INFO - 2016-02-14 11:27:06 --> Helper loaded: url_helper
INFO - 2016-02-14 11:27:06 --> Helper loaded: file_helper
INFO - 2016-02-14 11:27:06 --> Helper loaded: date_helper
INFO - 2016-02-14 11:27:06 --> Helper loaded: form_helper
INFO - 2016-02-14 11:27:06 --> Database Driver Class Initialized
INFO - 2016-02-14 11:27:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 11:27:07 --> Controller Class Initialized
INFO - 2016-02-14 11:27:07 --> Model Class Initialized
INFO - 2016-02-14 11:27:07 --> Model Class Initialized
INFO - 2016-02-14 11:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 11:27:07 --> Pagination Class Initialized
INFO - 2016-02-14 11:27:07 --> Helper loaded: text_helper
INFO - 2016-02-14 14:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 14:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 14:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 14:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 14:27:08 --> Final output sent to browser
DEBUG - 2016-02-14 14:27:08 --> Total execution time: 1.3752
INFO - 2016-02-14 11:27:27 --> Config Class Initialized
INFO - 2016-02-14 11:27:27 --> Hooks Class Initialized
DEBUG - 2016-02-14 11:27:27 --> UTF-8 Support Enabled
INFO - 2016-02-14 11:27:27 --> Utf8 Class Initialized
INFO - 2016-02-14 11:27:27 --> URI Class Initialized
INFO - 2016-02-14 11:27:27 --> Router Class Initialized
INFO - 2016-02-14 11:27:27 --> Output Class Initialized
INFO - 2016-02-14 11:27:27 --> Security Class Initialized
DEBUG - 2016-02-14 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 11:27:27 --> Input Class Initialized
INFO - 2016-02-14 11:27:27 --> Language Class Initialized
INFO - 2016-02-14 11:27:27 --> Loader Class Initialized
INFO - 2016-02-14 11:27:27 --> Helper loaded: url_helper
INFO - 2016-02-14 11:27:27 --> Helper loaded: file_helper
INFO - 2016-02-14 11:27:27 --> Helper loaded: date_helper
INFO - 2016-02-14 11:27:27 --> Helper loaded: form_helper
INFO - 2016-02-14 11:27:27 --> Database Driver Class Initialized
INFO - 2016-02-14 11:27:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 11:27:28 --> Controller Class Initialized
INFO - 2016-02-14 11:27:28 --> Model Class Initialized
INFO - 2016-02-14 11:27:28 --> Model Class Initialized
INFO - 2016-02-14 11:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 11:27:28 --> Pagination Class Initialized
INFO - 2016-02-14 11:27:28 --> Helper loaded: text_helper
INFO - 2016-02-14 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 14:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 14:27:28 --> Final output sent to browser
DEBUG - 2016-02-14 14:27:28 --> Total execution time: 1.1178
INFO - 2016-02-14 11:27:33 --> Config Class Initialized
INFO - 2016-02-14 11:27:33 --> Hooks Class Initialized
DEBUG - 2016-02-14 11:27:33 --> UTF-8 Support Enabled
INFO - 2016-02-14 11:27:33 --> Utf8 Class Initialized
INFO - 2016-02-14 11:27:33 --> URI Class Initialized
DEBUG - 2016-02-14 11:27:33 --> No URI present. Default controller set.
INFO - 2016-02-14 11:27:33 --> Router Class Initialized
INFO - 2016-02-14 11:27:33 --> Output Class Initialized
INFO - 2016-02-14 11:27:33 --> Security Class Initialized
DEBUG - 2016-02-14 11:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-14 11:27:33 --> Input Class Initialized
INFO - 2016-02-14 11:27:33 --> Language Class Initialized
INFO - 2016-02-14 11:27:33 --> Loader Class Initialized
INFO - 2016-02-14 11:27:33 --> Helper loaded: url_helper
INFO - 2016-02-14 11:27:33 --> Helper loaded: file_helper
INFO - 2016-02-14 11:27:33 --> Helper loaded: date_helper
INFO - 2016-02-14 11:27:33 --> Helper loaded: form_helper
INFO - 2016-02-14 11:27:33 --> Database Driver Class Initialized
INFO - 2016-02-14 11:27:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-14 11:27:34 --> Controller Class Initialized
INFO - 2016-02-14 11:27:34 --> Model Class Initialized
INFO - 2016-02-14 11:27:34 --> Model Class Initialized
INFO - 2016-02-14 11:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-14 11:27:34 --> Pagination Class Initialized
INFO - 2016-02-14 11:27:34 --> Helper loaded: text_helper
INFO - 2016-02-14 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-14 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-14 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-14 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-14 14:27:34 --> Final output sent to browser
DEBUG - 2016-02-14 14:27:34 --> Total execution time: 1.1682
