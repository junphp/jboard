<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-11 06:01:00 --> Config Class Initialized
INFO - 2016-03-11 06:01:00 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:00 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:00 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:00 --> URI Class Initialized
DEBUG - 2016-03-11 06:01:00 --> No URI present. Default controller set.
INFO - 2016-03-11 06:01:00 --> Router Class Initialized
INFO - 2016-03-11 06:01:00 --> Output Class Initialized
INFO - 2016-03-11 06:01:00 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:00 --> Input Class Initialized
INFO - 2016-03-11 06:01:00 --> Language Class Initialized
INFO - 2016-03-11 06:01:00 --> Loader Class Initialized
INFO - 2016-03-11 06:01:00 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:00 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:00 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:00 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:00 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:01 --> Controller Class Initialized
INFO - 2016-03-11 06:01:01 --> Model Class Initialized
INFO - 2016-03-11 06:01:01 --> Model Class Initialized
INFO - 2016-03-11 06:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:01 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:01 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:01 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 09:01:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:01 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:01 --> Total execution time: 1.2675
INFO - 2016-03-11 06:01:04 --> Config Class Initialized
INFO - 2016-03-11 06:01:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:04 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:04 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:04 --> URI Class Initialized
INFO - 2016-03-11 06:01:04 --> Router Class Initialized
INFO - 2016-03-11 06:01:04 --> Output Class Initialized
INFO - 2016-03-11 06:01:04 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:04 --> Input Class Initialized
INFO - 2016-03-11 06:01:04 --> Language Class Initialized
INFO - 2016-03-11 06:01:04 --> Loader Class Initialized
INFO - 2016-03-11 06:01:04 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:04 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:04 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:04 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:04 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:05 --> Controller Class Initialized
INFO - 2016-03-11 06:01:05 --> Model Class Initialized
INFO - 2016-03-11 06:01:05 --> Model Class Initialized
INFO - 2016-03-11 06:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:05 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:05 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:05 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:01:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:01:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:05 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:05 --> Total execution time: 1.1581
INFO - 2016-03-11 06:01:08 --> Config Class Initialized
INFO - 2016-03-11 06:01:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:08 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:08 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:08 --> URI Class Initialized
INFO - 2016-03-11 06:01:08 --> Router Class Initialized
INFO - 2016-03-11 06:01:08 --> Output Class Initialized
INFO - 2016-03-11 06:01:08 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:08 --> Input Class Initialized
INFO - 2016-03-11 06:01:08 --> Language Class Initialized
INFO - 2016-03-11 06:01:08 --> Loader Class Initialized
INFO - 2016-03-11 06:01:08 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:08 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:08 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:08 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:08 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:09 --> Controller Class Initialized
INFO - 2016-03-11 06:01:09 --> Model Class Initialized
INFO - 2016-03-11 06:01:09 --> Model Class Initialized
INFO - 2016-03-11 06:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:09 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:09 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:09 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:09 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:09 --> Total execution time: 1.1246
INFO - 2016-03-11 06:01:11 --> Config Class Initialized
INFO - 2016-03-11 06:01:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:11 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:11 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:11 --> URI Class Initialized
INFO - 2016-03-11 06:01:11 --> Router Class Initialized
INFO - 2016-03-11 06:01:11 --> Output Class Initialized
INFO - 2016-03-11 06:01:11 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:11 --> Input Class Initialized
INFO - 2016-03-11 06:01:11 --> Language Class Initialized
INFO - 2016-03-11 06:01:11 --> Loader Class Initialized
INFO - 2016-03-11 06:01:11 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:11 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:11 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:11 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:11 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:12 --> Controller Class Initialized
INFO - 2016-03-11 06:01:12 --> Model Class Initialized
INFO - 2016-03-11 06:01:12 --> Model Class Initialized
INFO - 2016-03-11 06:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:12 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:12 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:12 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:12 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:12 --> Total execution time: 1.2254
INFO - 2016-03-11 06:01:49 --> Config Class Initialized
INFO - 2016-03-11 06:01:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:49 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:49 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:49 --> URI Class Initialized
INFO - 2016-03-11 06:01:49 --> Router Class Initialized
INFO - 2016-03-11 06:01:49 --> Output Class Initialized
INFO - 2016-03-11 06:01:49 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:49 --> Input Class Initialized
INFO - 2016-03-11 06:01:49 --> Language Class Initialized
INFO - 2016-03-11 06:01:49 --> Loader Class Initialized
INFO - 2016-03-11 06:01:49 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:49 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:49 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:49 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:49 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:50 --> Controller Class Initialized
INFO - 2016-03-11 06:01:50 --> Model Class Initialized
INFO - 2016-03-11 06:01:50 --> Model Class Initialized
INFO - 2016-03-11 06:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:50 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:50 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:50 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:50 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:50 --> Total execution time: 1.1239
INFO - 2016-03-11 06:01:52 --> Config Class Initialized
INFO - 2016-03-11 06:01:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:52 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:52 --> URI Class Initialized
INFO - 2016-03-11 06:01:52 --> Router Class Initialized
INFO - 2016-03-11 06:01:52 --> Output Class Initialized
INFO - 2016-03-11 06:01:52 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:52 --> Input Class Initialized
INFO - 2016-03-11 06:01:52 --> Language Class Initialized
INFO - 2016-03-11 06:01:52 --> Loader Class Initialized
INFO - 2016-03-11 06:01:52 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:52 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:52 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:52 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:52 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:53 --> Controller Class Initialized
INFO - 2016-03-11 06:01:53 --> Model Class Initialized
INFO - 2016-03-11 06:01:53 --> Model Class Initialized
INFO - 2016-03-11 06:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:53 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:53 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:53 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:53 --> Total execution time: 1.1261
INFO - 2016-03-11 06:01:54 --> Config Class Initialized
INFO - 2016-03-11 06:01:54 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:01:54 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:01:54 --> Utf8 Class Initialized
INFO - 2016-03-11 06:01:54 --> URI Class Initialized
INFO - 2016-03-11 06:01:54 --> Router Class Initialized
INFO - 2016-03-11 06:01:54 --> Output Class Initialized
INFO - 2016-03-11 06:01:54 --> Security Class Initialized
DEBUG - 2016-03-11 06:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:01:54 --> Input Class Initialized
INFO - 2016-03-11 06:01:54 --> Language Class Initialized
INFO - 2016-03-11 06:01:54 --> Loader Class Initialized
INFO - 2016-03-11 06:01:54 --> Helper loaded: url_helper
INFO - 2016-03-11 06:01:54 --> Helper loaded: file_helper
INFO - 2016-03-11 06:01:54 --> Helper loaded: date_helper
INFO - 2016-03-11 06:01:54 --> Helper loaded: form_helper
INFO - 2016-03-11 06:01:54 --> Database Driver Class Initialized
INFO - 2016-03-11 06:01:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:01:55 --> Controller Class Initialized
INFO - 2016-03-11 06:01:55 --> Model Class Initialized
INFO - 2016-03-11 06:01:55 --> Model Class Initialized
INFO - 2016-03-11 06:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:01:55 --> Pagination Class Initialized
INFO - 2016-03-11 06:01:55 --> Helper loaded: text_helper
INFO - 2016-03-11 06:01:55 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:01:55 --> Final output sent to browser
DEBUG - 2016-03-11 09:01:55 --> Total execution time: 1.2098
INFO - 2016-03-11 06:02:57 --> Config Class Initialized
INFO - 2016-03-11 06:02:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:02:57 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:02:57 --> Utf8 Class Initialized
INFO - 2016-03-11 06:02:57 --> URI Class Initialized
INFO - 2016-03-11 06:02:57 --> Router Class Initialized
INFO - 2016-03-11 06:02:57 --> Output Class Initialized
INFO - 2016-03-11 06:02:57 --> Security Class Initialized
DEBUG - 2016-03-11 06:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:02:57 --> Input Class Initialized
INFO - 2016-03-11 06:02:57 --> Language Class Initialized
INFO - 2016-03-11 06:02:57 --> Loader Class Initialized
INFO - 2016-03-11 06:02:57 --> Helper loaded: url_helper
INFO - 2016-03-11 06:02:57 --> Helper loaded: file_helper
INFO - 2016-03-11 06:02:57 --> Helper loaded: date_helper
INFO - 2016-03-11 06:02:57 --> Helper loaded: form_helper
INFO - 2016-03-11 06:02:57 --> Database Driver Class Initialized
INFO - 2016-03-11 06:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:02:58 --> Controller Class Initialized
INFO - 2016-03-11 06:02:58 --> Model Class Initialized
INFO - 2016-03-11 06:02:58 --> Model Class Initialized
INFO - 2016-03-11 06:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:02:58 --> Pagination Class Initialized
INFO - 2016-03-11 06:02:58 --> Helper loaded: text_helper
INFO - 2016-03-11 06:02:58 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-11 09:02:58 --> Severity: Notice --> Undefined variable: base_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Pagination.php 408
INFO - 2016-03-11 09:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:02:58 --> Final output sent to browser
DEBUG - 2016-03-11 09:02:58 --> Total execution time: 1.1791
INFO - 2016-03-11 06:04:16 --> Config Class Initialized
INFO - 2016-03-11 06:04:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:04:16 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:04:16 --> Utf8 Class Initialized
INFO - 2016-03-11 06:04:16 --> URI Class Initialized
INFO - 2016-03-11 06:04:16 --> Router Class Initialized
INFO - 2016-03-11 06:04:16 --> Output Class Initialized
INFO - 2016-03-11 06:04:16 --> Security Class Initialized
DEBUG - 2016-03-11 06:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:04:16 --> Input Class Initialized
INFO - 2016-03-11 06:04:16 --> Language Class Initialized
INFO - 2016-03-11 06:04:16 --> Loader Class Initialized
INFO - 2016-03-11 06:04:16 --> Helper loaded: url_helper
INFO - 2016-03-11 06:04:16 --> Helper loaded: file_helper
INFO - 2016-03-11 06:04:16 --> Helper loaded: date_helper
INFO - 2016-03-11 06:04:16 --> Helper loaded: form_helper
INFO - 2016-03-11 06:04:16 --> Database Driver Class Initialized
INFO - 2016-03-11 06:04:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:04:17 --> Controller Class Initialized
INFO - 2016-03-11 06:04:17 --> Model Class Initialized
INFO - 2016-03-11 06:04:17 --> Model Class Initialized
INFO - 2016-03-11 06:04:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:04:17 --> Pagination Class Initialized
INFO - 2016-03-11 06:04:17 --> Helper loaded: text_helper
INFO - 2016-03-11 06:04:17 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-11 09:04:17 --> Severity: Notice --> Undefined variable: base_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Pagination.php 408
INFO - 2016-03-11 09:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:04:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:04:17 --> Final output sent to browser
DEBUG - 2016-03-11 09:04:17 --> Total execution time: 1.1644
INFO - 2016-03-11 06:04:19 --> Config Class Initialized
INFO - 2016-03-11 06:04:19 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:04:19 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:04:19 --> Utf8 Class Initialized
INFO - 2016-03-11 06:04:19 --> URI Class Initialized
INFO - 2016-03-11 06:04:19 --> Router Class Initialized
INFO - 2016-03-11 06:04:19 --> Output Class Initialized
INFO - 2016-03-11 06:04:19 --> Security Class Initialized
DEBUG - 2016-03-11 06:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:04:19 --> Input Class Initialized
INFO - 2016-03-11 06:04:19 --> Language Class Initialized
INFO - 2016-03-11 06:04:19 --> Loader Class Initialized
INFO - 2016-03-11 06:04:19 --> Helper loaded: url_helper
INFO - 2016-03-11 06:04:19 --> Helper loaded: file_helper
INFO - 2016-03-11 06:04:19 --> Helper loaded: date_helper
INFO - 2016-03-11 06:04:19 --> Helper loaded: form_helper
INFO - 2016-03-11 06:04:19 --> Database Driver Class Initialized
INFO - 2016-03-11 06:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:04:20 --> Controller Class Initialized
INFO - 2016-03-11 06:04:20 --> Model Class Initialized
INFO - 2016-03-11 06:04:20 --> Model Class Initialized
INFO - 2016-03-11 06:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:04:20 --> Pagination Class Initialized
INFO - 2016-03-11 06:04:20 --> Helper loaded: text_helper
INFO - 2016-03-11 06:04:20 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:04:20 --> Final output sent to browser
DEBUG - 2016-03-11 09:04:20 --> Total execution time: 1.2735
INFO - 2016-03-11 06:06:40 --> Config Class Initialized
INFO - 2016-03-11 06:06:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:06:40 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:06:40 --> Utf8 Class Initialized
INFO - 2016-03-11 06:06:40 --> URI Class Initialized
DEBUG - 2016-03-11 06:06:40 --> No URI present. Default controller set.
INFO - 2016-03-11 06:06:40 --> Router Class Initialized
INFO - 2016-03-11 06:06:40 --> Output Class Initialized
INFO - 2016-03-11 06:06:40 --> Security Class Initialized
DEBUG - 2016-03-11 06:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:06:40 --> Input Class Initialized
INFO - 2016-03-11 06:06:40 --> Language Class Initialized
INFO - 2016-03-11 06:06:40 --> Loader Class Initialized
INFO - 2016-03-11 06:06:40 --> Helper loaded: url_helper
INFO - 2016-03-11 06:06:40 --> Helper loaded: file_helper
INFO - 2016-03-11 06:06:40 --> Helper loaded: date_helper
INFO - 2016-03-11 06:06:40 --> Helper loaded: form_helper
INFO - 2016-03-11 06:06:40 --> Database Driver Class Initialized
INFO - 2016-03-11 06:06:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:06:41 --> Controller Class Initialized
INFO - 2016-03-11 06:06:41 --> Model Class Initialized
INFO - 2016-03-11 06:06:41 --> Model Class Initialized
INFO - 2016-03-11 06:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:06:41 --> Pagination Class Initialized
INFO - 2016-03-11 06:06:41 --> Helper loaded: text_helper
INFO - 2016-03-11 06:06:41 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:06:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:06:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:06:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 09:06:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:06:41 --> Final output sent to browser
DEBUG - 2016-03-11 09:06:41 --> Total execution time: 1.0847
INFO - 2016-03-11 06:06:43 --> Config Class Initialized
INFO - 2016-03-11 06:06:43 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:06:43 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:06:43 --> Utf8 Class Initialized
INFO - 2016-03-11 06:06:43 --> URI Class Initialized
INFO - 2016-03-11 06:06:44 --> Router Class Initialized
INFO - 2016-03-11 06:06:44 --> Output Class Initialized
INFO - 2016-03-11 06:06:44 --> Security Class Initialized
DEBUG - 2016-03-11 06:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:06:44 --> Input Class Initialized
INFO - 2016-03-11 06:06:44 --> Language Class Initialized
INFO - 2016-03-11 06:06:44 --> Loader Class Initialized
INFO - 2016-03-11 06:06:44 --> Helper loaded: url_helper
INFO - 2016-03-11 06:06:44 --> Helper loaded: file_helper
INFO - 2016-03-11 06:06:44 --> Helper loaded: date_helper
INFO - 2016-03-11 06:06:44 --> Helper loaded: form_helper
INFO - 2016-03-11 06:06:44 --> Database Driver Class Initialized
INFO - 2016-03-11 06:06:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:06:45 --> Controller Class Initialized
INFO - 2016-03-11 06:06:45 --> Model Class Initialized
INFO - 2016-03-11 06:06:45 --> Model Class Initialized
INFO - 2016-03-11 06:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:06:45 --> Pagination Class Initialized
INFO - 2016-03-11 06:06:45 --> Helper loaded: text_helper
INFO - 2016-03-11 06:06:45 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:06:45 --> Final output sent to browser
DEBUG - 2016-03-11 09:06:45 --> Total execution time: 1.1476
INFO - 2016-03-11 06:06:47 --> Config Class Initialized
INFO - 2016-03-11 06:06:47 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:06:47 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:06:47 --> Utf8 Class Initialized
INFO - 2016-03-11 06:06:47 --> URI Class Initialized
INFO - 2016-03-11 06:06:47 --> Router Class Initialized
INFO - 2016-03-11 06:06:47 --> Output Class Initialized
INFO - 2016-03-11 06:06:47 --> Security Class Initialized
DEBUG - 2016-03-11 06:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:06:47 --> Input Class Initialized
INFO - 2016-03-11 06:06:47 --> Language Class Initialized
INFO - 2016-03-11 06:06:47 --> Loader Class Initialized
INFO - 2016-03-11 06:06:47 --> Helper loaded: url_helper
INFO - 2016-03-11 06:06:47 --> Helper loaded: file_helper
INFO - 2016-03-11 06:06:47 --> Helper loaded: date_helper
INFO - 2016-03-11 06:06:47 --> Helper loaded: form_helper
INFO - 2016-03-11 06:06:47 --> Database Driver Class Initialized
INFO - 2016-03-11 06:06:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:06:48 --> Controller Class Initialized
INFO - 2016-03-11 06:06:48 --> Model Class Initialized
INFO - 2016-03-11 06:06:48 --> Model Class Initialized
INFO - 2016-03-11 06:06:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:06:48 --> Pagination Class Initialized
INFO - 2016-03-11 06:06:48 --> Helper loaded: text_helper
INFO - 2016-03-11 06:06:48 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:06:48 --> Final output sent to browser
DEBUG - 2016-03-11 09:06:48 --> Total execution time: 1.1559
INFO - 2016-03-11 06:06:51 --> Config Class Initialized
INFO - 2016-03-11 06:06:51 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:06:51 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:06:51 --> Utf8 Class Initialized
INFO - 2016-03-11 06:06:51 --> URI Class Initialized
INFO - 2016-03-11 06:06:51 --> Router Class Initialized
INFO - 2016-03-11 06:06:51 --> Output Class Initialized
INFO - 2016-03-11 06:06:51 --> Security Class Initialized
DEBUG - 2016-03-11 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:06:51 --> Input Class Initialized
INFO - 2016-03-11 06:06:51 --> Language Class Initialized
INFO - 2016-03-11 06:06:51 --> Loader Class Initialized
INFO - 2016-03-11 06:06:51 --> Helper loaded: url_helper
INFO - 2016-03-11 06:06:51 --> Helper loaded: file_helper
INFO - 2016-03-11 06:06:51 --> Helper loaded: date_helper
INFO - 2016-03-11 06:06:51 --> Helper loaded: form_helper
INFO - 2016-03-11 06:06:51 --> Database Driver Class Initialized
INFO - 2016-03-11 06:06:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:06:52 --> Controller Class Initialized
INFO - 2016-03-11 06:06:52 --> Model Class Initialized
INFO - 2016-03-11 06:06:52 --> Model Class Initialized
INFO - 2016-03-11 06:06:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:06:52 --> Pagination Class Initialized
INFO - 2016-03-11 06:06:52 --> Helper loaded: text_helper
INFO - 2016-03-11 06:06:52 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:06:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:06:52 --> Final output sent to browser
DEBUG - 2016-03-11 09:06:52 --> Total execution time: 1.2284
INFO - 2016-03-11 06:08:31 --> Config Class Initialized
INFO - 2016-03-11 06:08:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:08:31 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:08:31 --> Utf8 Class Initialized
INFO - 2016-03-11 06:08:31 --> URI Class Initialized
INFO - 2016-03-11 06:08:31 --> Router Class Initialized
INFO - 2016-03-11 06:08:31 --> Output Class Initialized
INFO - 2016-03-11 06:08:31 --> Security Class Initialized
DEBUG - 2016-03-11 06:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:08:31 --> Input Class Initialized
INFO - 2016-03-11 06:08:31 --> Language Class Initialized
INFO - 2016-03-11 06:08:31 --> Loader Class Initialized
INFO - 2016-03-11 06:08:31 --> Helper loaded: url_helper
INFO - 2016-03-11 06:08:31 --> Helper loaded: file_helper
INFO - 2016-03-11 06:08:31 --> Helper loaded: date_helper
INFO - 2016-03-11 06:08:31 --> Helper loaded: form_helper
INFO - 2016-03-11 06:08:31 --> Database Driver Class Initialized
INFO - 2016-03-11 06:08:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:08:32 --> Controller Class Initialized
INFO - 2016-03-11 06:08:32 --> Model Class Initialized
INFO - 2016-03-11 06:08:32 --> Model Class Initialized
INFO - 2016-03-11 06:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:08:32 --> Pagination Class Initialized
INFO - 2016-03-11 06:08:32 --> Helper loaded: text_helper
INFO - 2016-03-11 06:08:32 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:08:32 --> Final output sent to browser
DEBUG - 2016-03-11 09:08:32 --> Total execution time: 1.1795
INFO - 2016-03-11 06:08:36 --> Config Class Initialized
INFO - 2016-03-11 06:08:36 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:08:36 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:08:36 --> Utf8 Class Initialized
INFO - 2016-03-11 06:08:36 --> URI Class Initialized
INFO - 2016-03-11 06:08:36 --> Router Class Initialized
INFO - 2016-03-11 06:08:36 --> Output Class Initialized
INFO - 2016-03-11 06:08:36 --> Security Class Initialized
DEBUG - 2016-03-11 06:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:08:36 --> Input Class Initialized
INFO - 2016-03-11 06:08:36 --> Language Class Initialized
INFO - 2016-03-11 06:08:36 --> Loader Class Initialized
INFO - 2016-03-11 06:08:36 --> Helper loaded: url_helper
INFO - 2016-03-11 06:08:36 --> Helper loaded: file_helper
INFO - 2016-03-11 06:08:36 --> Helper loaded: date_helper
INFO - 2016-03-11 06:08:36 --> Helper loaded: form_helper
INFO - 2016-03-11 06:08:36 --> Database Driver Class Initialized
INFO - 2016-03-11 06:08:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:08:37 --> Controller Class Initialized
INFO - 2016-03-11 06:08:37 --> Model Class Initialized
INFO - 2016-03-11 06:08:37 --> Model Class Initialized
INFO - 2016-03-11 06:08:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:08:37 --> Pagination Class Initialized
INFO - 2016-03-11 06:08:37 --> Helper loaded: text_helper
INFO - 2016-03-11 06:08:37 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:08:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:08:37 --> Final output sent to browser
DEBUG - 2016-03-11 09:08:37 --> Total execution time: 1.1352
INFO - 2016-03-11 06:08:38 --> Config Class Initialized
INFO - 2016-03-11 06:08:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:08:38 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:08:38 --> Utf8 Class Initialized
INFO - 2016-03-11 06:08:38 --> URI Class Initialized
INFO - 2016-03-11 06:08:38 --> Router Class Initialized
INFO - 2016-03-11 06:08:38 --> Output Class Initialized
INFO - 2016-03-11 06:08:38 --> Security Class Initialized
DEBUG - 2016-03-11 06:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:08:38 --> Input Class Initialized
INFO - 2016-03-11 06:08:38 --> Language Class Initialized
INFO - 2016-03-11 06:08:38 --> Loader Class Initialized
INFO - 2016-03-11 06:08:38 --> Helper loaded: url_helper
INFO - 2016-03-11 06:08:38 --> Helper loaded: file_helper
INFO - 2016-03-11 06:08:38 --> Helper loaded: date_helper
INFO - 2016-03-11 06:08:38 --> Helper loaded: form_helper
INFO - 2016-03-11 06:08:38 --> Database Driver Class Initialized
INFO - 2016-03-11 06:08:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:08:39 --> Controller Class Initialized
INFO - 2016-03-11 06:08:39 --> Model Class Initialized
INFO - 2016-03-11 06:08:39 --> Model Class Initialized
INFO - 2016-03-11 06:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:08:40 --> Pagination Class Initialized
INFO - 2016-03-11 06:08:40 --> Helper loaded: text_helper
INFO - 2016-03-11 06:08:40 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:08:40 --> Final output sent to browser
DEBUG - 2016-03-11 09:08:40 --> Total execution time: 1.1356
INFO - 2016-03-11 06:08:42 --> Config Class Initialized
INFO - 2016-03-11 06:08:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:08:42 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:08:42 --> Utf8 Class Initialized
INFO - 2016-03-11 06:08:42 --> URI Class Initialized
INFO - 2016-03-11 06:08:42 --> Router Class Initialized
INFO - 2016-03-11 06:08:42 --> Output Class Initialized
INFO - 2016-03-11 06:08:42 --> Security Class Initialized
DEBUG - 2016-03-11 06:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:08:42 --> Input Class Initialized
INFO - 2016-03-11 06:08:42 --> Language Class Initialized
INFO - 2016-03-11 06:08:42 --> Loader Class Initialized
INFO - 2016-03-11 06:08:42 --> Helper loaded: url_helper
INFO - 2016-03-11 06:08:42 --> Helper loaded: file_helper
INFO - 2016-03-11 06:08:42 --> Helper loaded: date_helper
INFO - 2016-03-11 06:08:42 --> Helper loaded: form_helper
INFO - 2016-03-11 06:08:42 --> Database Driver Class Initialized
INFO - 2016-03-11 06:08:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:08:43 --> Controller Class Initialized
INFO - 2016-03-11 06:08:43 --> Model Class Initialized
INFO - 2016-03-11 06:08:43 --> Model Class Initialized
INFO - 2016-03-11 06:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:08:43 --> Pagination Class Initialized
INFO - 2016-03-11 06:08:43 --> Helper loaded: text_helper
INFO - 2016-03-11 06:08:43 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:08:43 --> Final output sent to browser
DEBUG - 2016-03-11 09:08:43 --> Total execution time: 1.1150
INFO - 2016-03-11 06:11:46 --> Config Class Initialized
INFO - 2016-03-11 06:11:46 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:11:46 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:11:46 --> Utf8 Class Initialized
INFO - 2016-03-11 06:11:46 --> URI Class Initialized
INFO - 2016-03-11 06:11:46 --> Router Class Initialized
INFO - 2016-03-11 06:11:46 --> Output Class Initialized
INFO - 2016-03-11 06:11:46 --> Security Class Initialized
DEBUG - 2016-03-11 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:11:46 --> Input Class Initialized
INFO - 2016-03-11 06:11:46 --> Language Class Initialized
INFO - 2016-03-11 06:11:46 --> Loader Class Initialized
INFO - 2016-03-11 06:11:46 --> Helper loaded: url_helper
INFO - 2016-03-11 06:11:46 --> Helper loaded: file_helper
INFO - 2016-03-11 06:11:46 --> Helper loaded: date_helper
INFO - 2016-03-11 06:11:46 --> Helper loaded: form_helper
INFO - 2016-03-11 06:11:46 --> Database Driver Class Initialized
INFO - 2016-03-11 06:11:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:11:47 --> Controller Class Initialized
INFO - 2016-03-11 06:11:47 --> Model Class Initialized
INFO - 2016-03-11 06:11:47 --> Model Class Initialized
INFO - 2016-03-11 06:11:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:11:47 --> Pagination Class Initialized
INFO - 2016-03-11 06:11:47 --> Helper loaded: text_helper
INFO - 2016-03-11 06:11:47 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:11:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:11:47 --> Final output sent to browser
DEBUG - 2016-03-11 09:11:47 --> Total execution time: 1.1255
INFO - 2016-03-11 06:11:49 --> Config Class Initialized
INFO - 2016-03-11 06:11:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:11:49 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:11:49 --> Utf8 Class Initialized
INFO - 2016-03-11 06:11:49 --> URI Class Initialized
INFO - 2016-03-11 06:11:49 --> Router Class Initialized
INFO - 2016-03-11 06:11:49 --> Output Class Initialized
INFO - 2016-03-11 06:11:49 --> Security Class Initialized
DEBUG - 2016-03-11 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:11:49 --> Input Class Initialized
INFO - 2016-03-11 06:11:49 --> Language Class Initialized
INFO - 2016-03-11 06:11:49 --> Loader Class Initialized
INFO - 2016-03-11 06:11:49 --> Helper loaded: url_helper
INFO - 2016-03-11 06:11:49 --> Helper loaded: file_helper
INFO - 2016-03-11 06:11:49 --> Helper loaded: date_helper
INFO - 2016-03-11 06:11:49 --> Helper loaded: form_helper
INFO - 2016-03-11 06:11:49 --> Database Driver Class Initialized
INFO - 2016-03-11 06:11:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:11:50 --> Controller Class Initialized
INFO - 2016-03-11 06:11:50 --> Model Class Initialized
INFO - 2016-03-11 06:11:50 --> Model Class Initialized
INFO - 2016-03-11 06:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:11:50 --> Pagination Class Initialized
INFO - 2016-03-11 06:11:50 --> Helper loaded: text_helper
INFO - 2016-03-11 06:11:50 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:11:50 --> Final output sent to browser
DEBUG - 2016-03-11 09:11:50 --> Total execution time: 1.1372
INFO - 2016-03-11 06:11:52 --> Config Class Initialized
INFO - 2016-03-11 06:11:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:11:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:11:52 --> Utf8 Class Initialized
INFO - 2016-03-11 06:11:52 --> URI Class Initialized
INFO - 2016-03-11 06:11:52 --> Router Class Initialized
INFO - 2016-03-11 06:11:52 --> Output Class Initialized
INFO - 2016-03-11 06:11:52 --> Security Class Initialized
DEBUG - 2016-03-11 06:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:11:52 --> Input Class Initialized
INFO - 2016-03-11 06:11:52 --> Language Class Initialized
INFO - 2016-03-11 06:11:52 --> Loader Class Initialized
INFO - 2016-03-11 06:11:52 --> Helper loaded: url_helper
INFO - 2016-03-11 06:11:52 --> Helper loaded: file_helper
INFO - 2016-03-11 06:11:52 --> Helper loaded: date_helper
INFO - 2016-03-11 06:11:52 --> Helper loaded: form_helper
INFO - 2016-03-11 06:11:52 --> Database Driver Class Initialized
INFO - 2016-03-11 06:11:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:11:53 --> Controller Class Initialized
INFO - 2016-03-11 06:11:53 --> Model Class Initialized
INFO - 2016-03-11 06:11:53 --> Model Class Initialized
INFO - 2016-03-11 06:11:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:11:53 --> Pagination Class Initialized
INFO - 2016-03-11 06:11:53 --> Helper loaded: text_helper
INFO - 2016-03-11 06:11:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:11:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:11:53 --> Final output sent to browser
DEBUG - 2016-03-11 09:11:53 --> Total execution time: 1.1529
INFO - 2016-03-11 06:15:32 --> Config Class Initialized
INFO - 2016-03-11 06:15:32 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:15:32 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:15:32 --> Utf8 Class Initialized
INFO - 2016-03-11 06:15:32 --> URI Class Initialized
INFO - 2016-03-11 06:15:32 --> Router Class Initialized
INFO - 2016-03-11 06:15:32 --> Output Class Initialized
INFO - 2016-03-11 06:15:32 --> Security Class Initialized
DEBUG - 2016-03-11 06:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:15:32 --> Input Class Initialized
INFO - 2016-03-11 06:15:32 --> Language Class Initialized
INFO - 2016-03-11 06:15:32 --> Loader Class Initialized
INFO - 2016-03-11 06:15:32 --> Helper loaded: url_helper
INFO - 2016-03-11 06:15:32 --> Helper loaded: file_helper
INFO - 2016-03-11 06:15:32 --> Helper loaded: date_helper
INFO - 2016-03-11 06:15:32 --> Helper loaded: form_helper
INFO - 2016-03-11 06:15:32 --> Database Driver Class Initialized
INFO - 2016-03-11 06:15:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:15:33 --> Controller Class Initialized
INFO - 2016-03-11 06:15:33 --> Model Class Initialized
INFO - 2016-03-11 06:15:33 --> Model Class Initialized
INFO - 2016-03-11 06:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:15:33 --> Pagination Class Initialized
INFO - 2016-03-11 06:15:33 --> Helper loaded: text_helper
INFO - 2016-03-11 06:15:33 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:15:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:15:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:15:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:15:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:15:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:15:33 --> Final output sent to browser
DEBUG - 2016-03-11 09:15:33 --> Total execution time: 1.1506
INFO - 2016-03-11 06:15:34 --> Config Class Initialized
INFO - 2016-03-11 06:15:34 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:15:34 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:15:34 --> Utf8 Class Initialized
INFO - 2016-03-11 06:15:34 --> URI Class Initialized
INFO - 2016-03-11 06:15:34 --> Router Class Initialized
INFO - 2016-03-11 06:15:34 --> Output Class Initialized
INFO - 2016-03-11 06:15:34 --> Security Class Initialized
DEBUG - 2016-03-11 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:15:34 --> Input Class Initialized
INFO - 2016-03-11 06:15:34 --> Language Class Initialized
INFO - 2016-03-11 06:15:34 --> Loader Class Initialized
INFO - 2016-03-11 06:15:34 --> Helper loaded: url_helper
INFO - 2016-03-11 06:15:34 --> Helper loaded: file_helper
INFO - 2016-03-11 06:15:34 --> Helper loaded: date_helper
INFO - 2016-03-11 06:15:34 --> Helper loaded: form_helper
INFO - 2016-03-11 06:15:35 --> Database Driver Class Initialized
INFO - 2016-03-11 06:15:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:15:36 --> Controller Class Initialized
INFO - 2016-03-11 06:15:36 --> Model Class Initialized
INFO - 2016-03-11 06:15:36 --> Model Class Initialized
INFO - 2016-03-11 06:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:15:36 --> Pagination Class Initialized
INFO - 2016-03-11 06:15:36 --> Helper loaded: text_helper
INFO - 2016-03-11 06:15:36 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:15:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:15:36 --> Final output sent to browser
DEBUG - 2016-03-11 09:15:36 --> Total execution time: 1.1456
INFO - 2016-03-11 06:15:37 --> Config Class Initialized
INFO - 2016-03-11 06:15:37 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:15:37 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:15:37 --> Utf8 Class Initialized
INFO - 2016-03-11 06:15:37 --> URI Class Initialized
INFO - 2016-03-11 06:15:37 --> Router Class Initialized
INFO - 2016-03-11 06:15:37 --> Output Class Initialized
INFO - 2016-03-11 06:15:37 --> Security Class Initialized
DEBUG - 2016-03-11 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:15:37 --> Input Class Initialized
INFO - 2016-03-11 06:15:37 --> Language Class Initialized
INFO - 2016-03-11 06:15:37 --> Loader Class Initialized
INFO - 2016-03-11 06:15:37 --> Helper loaded: url_helper
INFO - 2016-03-11 06:15:37 --> Helper loaded: file_helper
INFO - 2016-03-11 06:15:37 --> Helper loaded: date_helper
INFO - 2016-03-11 06:15:37 --> Helper loaded: form_helper
INFO - 2016-03-11 06:15:37 --> Database Driver Class Initialized
INFO - 2016-03-11 06:15:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:15:38 --> Controller Class Initialized
INFO - 2016-03-11 06:15:38 --> Model Class Initialized
INFO - 2016-03-11 06:15:38 --> Model Class Initialized
INFO - 2016-03-11 06:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:15:38 --> Pagination Class Initialized
INFO - 2016-03-11 06:15:38 --> Helper loaded: text_helper
INFO - 2016-03-11 06:15:38 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:15:39 --> Final output sent to browser
DEBUG - 2016-03-11 09:15:39 --> Total execution time: 1.2029
INFO - 2016-03-11 06:22:50 --> Config Class Initialized
INFO - 2016-03-11 06:22:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:22:50 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:22:50 --> Utf8 Class Initialized
INFO - 2016-03-11 06:22:50 --> URI Class Initialized
INFO - 2016-03-11 06:22:50 --> Router Class Initialized
INFO - 2016-03-11 06:22:50 --> Output Class Initialized
INFO - 2016-03-11 06:22:50 --> Security Class Initialized
DEBUG - 2016-03-11 06:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:22:50 --> Input Class Initialized
INFO - 2016-03-11 06:22:50 --> Language Class Initialized
INFO - 2016-03-11 06:22:50 --> Loader Class Initialized
INFO - 2016-03-11 06:22:50 --> Helper loaded: url_helper
INFO - 2016-03-11 06:22:50 --> Helper loaded: file_helper
INFO - 2016-03-11 06:22:50 --> Helper loaded: date_helper
INFO - 2016-03-11 06:22:50 --> Helper loaded: form_helper
INFO - 2016-03-11 06:22:50 --> Database Driver Class Initialized
INFO - 2016-03-11 06:22:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:22:51 --> Controller Class Initialized
INFO - 2016-03-11 06:22:51 --> Model Class Initialized
INFO - 2016-03-11 06:22:51 --> Model Class Initialized
INFO - 2016-03-11 06:22:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:22:51 --> Pagination Class Initialized
INFO - 2016-03-11 06:22:51 --> Helper loaded: text_helper
INFO - 2016-03-11 06:22:51 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:22:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:22:51 --> Final output sent to browser
DEBUG - 2016-03-11 09:22:51 --> Total execution time: 1.2152
INFO - 2016-03-11 06:23:01 --> Config Class Initialized
INFO - 2016-03-11 06:23:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:01 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:01 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:01 --> URI Class Initialized
INFO - 2016-03-11 06:23:01 --> Router Class Initialized
INFO - 2016-03-11 06:23:01 --> Output Class Initialized
INFO - 2016-03-11 06:23:01 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:01 --> Input Class Initialized
INFO - 2016-03-11 06:23:01 --> Language Class Initialized
INFO - 2016-03-11 06:23:01 --> Loader Class Initialized
INFO - 2016-03-11 06:23:01 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:01 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:01 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:01 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:01 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:02 --> Controller Class Initialized
INFO - 2016-03-11 06:23:02 --> Model Class Initialized
INFO - 2016-03-11 06:23:02 --> Model Class Initialized
INFO - 2016-03-11 06:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:02 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:02 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:02 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:02 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:02 --> Total execution time: 1.1420
INFO - 2016-03-11 06:23:04 --> Config Class Initialized
INFO - 2016-03-11 06:23:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:04 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:04 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:04 --> URI Class Initialized
INFO - 2016-03-11 06:23:04 --> Router Class Initialized
INFO - 2016-03-11 06:23:04 --> Output Class Initialized
INFO - 2016-03-11 06:23:04 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:04 --> Input Class Initialized
INFO - 2016-03-11 06:23:04 --> Language Class Initialized
INFO - 2016-03-11 06:23:04 --> Loader Class Initialized
INFO - 2016-03-11 06:23:04 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:04 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:04 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:04 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:04 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:05 --> Controller Class Initialized
INFO - 2016-03-11 06:23:05 --> Model Class Initialized
INFO - 2016-03-11 06:23:05 --> Model Class Initialized
INFO - 2016-03-11 06:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:05 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:05 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:05 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:05 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:05 --> Total execution time: 1.1356
INFO - 2016-03-11 06:23:08 --> Config Class Initialized
INFO - 2016-03-11 06:23:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:08 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:08 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:08 --> URI Class Initialized
INFO - 2016-03-11 06:23:08 --> Router Class Initialized
INFO - 2016-03-11 06:23:08 --> Output Class Initialized
INFO - 2016-03-11 06:23:08 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:08 --> Input Class Initialized
INFO - 2016-03-11 06:23:08 --> Language Class Initialized
INFO - 2016-03-11 06:23:08 --> Loader Class Initialized
INFO - 2016-03-11 06:23:08 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:08 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:08 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:08 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:08 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:09 --> Controller Class Initialized
INFO - 2016-03-11 06:23:09 --> Model Class Initialized
INFO - 2016-03-11 06:23:09 --> Model Class Initialized
INFO - 2016-03-11 06:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:09 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:09 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:09 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:09 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:09 --> Total execution time: 1.1900
INFO - 2016-03-11 06:23:47 --> Config Class Initialized
INFO - 2016-03-11 06:23:47 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:47 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:47 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:47 --> URI Class Initialized
INFO - 2016-03-11 06:23:47 --> Router Class Initialized
INFO - 2016-03-11 06:23:47 --> Output Class Initialized
INFO - 2016-03-11 06:23:47 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:47 --> Input Class Initialized
INFO - 2016-03-11 06:23:47 --> Language Class Initialized
INFO - 2016-03-11 06:23:47 --> Loader Class Initialized
INFO - 2016-03-11 06:23:47 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:47 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:47 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:47 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:47 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:48 --> Controller Class Initialized
INFO - 2016-03-11 06:23:48 --> Model Class Initialized
INFO - 2016-03-11 06:23:48 --> Model Class Initialized
INFO - 2016-03-11 06:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:48 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:48 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:48 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:48 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:48 --> Total execution time: 1.1578
INFO - 2016-03-11 06:23:50 --> Config Class Initialized
INFO - 2016-03-11 06:23:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:50 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:50 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:50 --> URI Class Initialized
INFO - 2016-03-11 06:23:50 --> Router Class Initialized
INFO - 2016-03-11 06:23:50 --> Output Class Initialized
INFO - 2016-03-11 06:23:50 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:50 --> Input Class Initialized
INFO - 2016-03-11 06:23:50 --> Language Class Initialized
INFO - 2016-03-11 06:23:50 --> Loader Class Initialized
INFO - 2016-03-11 06:23:50 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:50 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:50 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:50 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:50 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:51 --> Controller Class Initialized
INFO - 2016-03-11 06:23:51 --> Model Class Initialized
INFO - 2016-03-11 06:23:51 --> Model Class Initialized
INFO - 2016-03-11 06:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:51 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:51 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:51 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:23:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:51 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:51 --> Total execution time: 1.1809
INFO - 2016-03-11 06:23:57 --> Config Class Initialized
INFO - 2016-03-11 06:23:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:23:57 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:23:57 --> Utf8 Class Initialized
INFO - 2016-03-11 06:23:57 --> URI Class Initialized
INFO - 2016-03-11 06:23:57 --> Router Class Initialized
INFO - 2016-03-11 06:23:57 --> Output Class Initialized
INFO - 2016-03-11 06:23:57 --> Security Class Initialized
DEBUG - 2016-03-11 06:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:23:57 --> Input Class Initialized
INFO - 2016-03-11 06:23:57 --> Language Class Initialized
INFO - 2016-03-11 06:23:57 --> Loader Class Initialized
INFO - 2016-03-11 06:23:57 --> Helper loaded: url_helper
INFO - 2016-03-11 06:23:57 --> Helper loaded: file_helper
INFO - 2016-03-11 06:23:57 --> Helper loaded: date_helper
INFO - 2016-03-11 06:23:57 --> Helper loaded: form_helper
INFO - 2016-03-11 06:23:57 --> Database Driver Class Initialized
INFO - 2016-03-11 06:23:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:23:59 --> Controller Class Initialized
INFO - 2016-03-11 06:23:59 --> Model Class Initialized
INFO - 2016-03-11 06:23:59 --> Model Class Initialized
INFO - 2016-03-11 06:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:23:59 --> Pagination Class Initialized
INFO - 2016-03-11 06:23:59 --> Helper loaded: text_helper
INFO - 2016-03-11 06:23:59 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:23:59 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:59 --> Total execution time: 1.1698
INFO - 2016-03-11 06:24:19 --> Config Class Initialized
INFO - 2016-03-11 06:24:19 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:19 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:19 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:19 --> URI Class Initialized
INFO - 2016-03-11 06:24:19 --> Router Class Initialized
INFO - 2016-03-11 06:24:19 --> Output Class Initialized
INFO - 2016-03-11 06:24:19 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:19 --> Input Class Initialized
INFO - 2016-03-11 06:24:19 --> Language Class Initialized
INFO - 2016-03-11 06:24:20 --> Loader Class Initialized
INFO - 2016-03-11 06:24:20 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:20 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:20 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:20 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:20 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:21 --> Controller Class Initialized
INFO - 2016-03-11 06:24:21 --> Model Class Initialized
INFO - 2016-03-11 06:24:21 --> Model Class Initialized
INFO - 2016-03-11 06:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:21 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:21 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:21 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:21 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:21 --> Total execution time: 1.1476
INFO - 2016-03-11 06:24:25 --> Config Class Initialized
INFO - 2016-03-11 06:24:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:25 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:25 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:25 --> URI Class Initialized
INFO - 2016-03-11 06:24:25 --> Router Class Initialized
INFO - 2016-03-11 06:24:25 --> Output Class Initialized
INFO - 2016-03-11 06:24:25 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:25 --> Input Class Initialized
INFO - 2016-03-11 06:24:25 --> Language Class Initialized
INFO - 2016-03-11 06:24:25 --> Loader Class Initialized
INFO - 2016-03-11 06:24:25 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:25 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:25 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:25 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:25 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:26 --> Controller Class Initialized
INFO - 2016-03-11 06:24:26 --> Model Class Initialized
INFO - 2016-03-11 06:24:26 --> Model Class Initialized
INFO - 2016-03-11 06:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:26 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:26 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:26 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:26 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:26 --> Total execution time: 1.2021
INFO - 2016-03-11 06:24:44 --> Config Class Initialized
INFO - 2016-03-11 06:24:44 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:44 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:44 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:44 --> URI Class Initialized
INFO - 2016-03-11 06:24:44 --> Router Class Initialized
INFO - 2016-03-11 06:24:44 --> Output Class Initialized
INFO - 2016-03-11 06:24:44 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:44 --> Input Class Initialized
INFO - 2016-03-11 06:24:44 --> Language Class Initialized
INFO - 2016-03-11 06:24:44 --> Loader Class Initialized
INFO - 2016-03-11 06:24:44 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:44 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:44 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:44 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:44 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:45 --> Controller Class Initialized
INFO - 2016-03-11 06:24:45 --> Model Class Initialized
INFO - 2016-03-11 06:24:45 --> Model Class Initialized
INFO - 2016-03-11 06:24:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:45 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:45 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:45 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:24:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:45 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:45 --> Total execution time: 1.2749
INFO - 2016-03-11 06:24:48 --> Config Class Initialized
INFO - 2016-03-11 06:24:48 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:48 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:48 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:48 --> URI Class Initialized
INFO - 2016-03-11 06:24:48 --> Router Class Initialized
INFO - 2016-03-11 06:24:48 --> Output Class Initialized
INFO - 2016-03-11 06:24:48 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:48 --> Input Class Initialized
INFO - 2016-03-11 06:24:48 --> Language Class Initialized
INFO - 2016-03-11 06:24:48 --> Loader Class Initialized
INFO - 2016-03-11 06:24:48 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:48 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:48 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:48 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:48 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:49 --> Controller Class Initialized
INFO - 2016-03-11 06:24:49 --> Model Class Initialized
INFO - 2016-03-11 06:24:49 --> Model Class Initialized
INFO - 2016-03-11 06:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:49 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:49 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:49 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:49 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:49 --> Total execution time: 1.1588
INFO - 2016-03-11 06:24:51 --> Config Class Initialized
INFO - 2016-03-11 06:24:51 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:51 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:51 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:51 --> URI Class Initialized
INFO - 2016-03-11 06:24:51 --> Router Class Initialized
INFO - 2016-03-11 06:24:51 --> Output Class Initialized
INFO - 2016-03-11 06:24:51 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:51 --> Input Class Initialized
INFO - 2016-03-11 06:24:51 --> Language Class Initialized
INFO - 2016-03-11 06:24:51 --> Loader Class Initialized
INFO - 2016-03-11 06:24:51 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:51 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:51 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:51 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:51 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:52 --> Controller Class Initialized
INFO - 2016-03-11 06:24:52 --> Model Class Initialized
INFO - 2016-03-11 06:24:52 --> Model Class Initialized
INFO - 2016-03-11 06:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:52 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:52 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:52 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:52 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:52 --> Total execution time: 1.1205
INFO - 2016-03-11 06:24:55 --> Config Class Initialized
INFO - 2016-03-11 06:24:55 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:24:55 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:24:55 --> Utf8 Class Initialized
INFO - 2016-03-11 06:24:55 --> URI Class Initialized
INFO - 2016-03-11 06:24:55 --> Router Class Initialized
INFO - 2016-03-11 06:24:55 --> Output Class Initialized
INFO - 2016-03-11 06:24:55 --> Security Class Initialized
DEBUG - 2016-03-11 06:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:24:55 --> Input Class Initialized
INFO - 2016-03-11 06:24:55 --> Language Class Initialized
INFO - 2016-03-11 06:24:55 --> Loader Class Initialized
INFO - 2016-03-11 06:24:55 --> Helper loaded: url_helper
INFO - 2016-03-11 06:24:55 --> Helper loaded: file_helper
INFO - 2016-03-11 06:24:55 --> Helper loaded: date_helper
INFO - 2016-03-11 06:24:55 --> Helper loaded: form_helper
INFO - 2016-03-11 06:24:55 --> Database Driver Class Initialized
INFO - 2016-03-11 06:24:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:24:56 --> Controller Class Initialized
INFO - 2016-03-11 06:24:56 --> Model Class Initialized
INFO - 2016-03-11 06:24:56 --> Model Class Initialized
INFO - 2016-03-11 06:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:24:56 --> Pagination Class Initialized
INFO - 2016-03-11 06:24:56 --> Helper loaded: text_helper
INFO - 2016-03-11 06:24:56 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:24:56 --> Final output sent to browser
DEBUG - 2016-03-11 09:24:56 --> Total execution time: 1.2042
INFO - 2016-03-11 06:27:21 --> Config Class Initialized
INFO - 2016-03-11 06:27:21 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:27:21 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:27:21 --> Utf8 Class Initialized
INFO - 2016-03-11 06:27:21 --> URI Class Initialized
INFO - 2016-03-11 06:27:21 --> Router Class Initialized
INFO - 2016-03-11 06:27:21 --> Output Class Initialized
INFO - 2016-03-11 06:27:21 --> Security Class Initialized
DEBUG - 2016-03-11 06:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:27:21 --> Input Class Initialized
INFO - 2016-03-11 06:27:21 --> Language Class Initialized
INFO - 2016-03-11 06:27:21 --> Loader Class Initialized
INFO - 2016-03-11 06:27:21 --> Helper loaded: url_helper
INFO - 2016-03-11 06:27:21 --> Helper loaded: file_helper
INFO - 2016-03-11 06:27:21 --> Helper loaded: date_helper
INFO - 2016-03-11 06:27:21 --> Helper loaded: form_helper
INFO - 2016-03-11 06:27:21 --> Database Driver Class Initialized
INFO - 2016-03-11 06:27:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:27:22 --> Controller Class Initialized
INFO - 2016-03-11 06:27:22 --> Model Class Initialized
INFO - 2016-03-11 06:27:22 --> Model Class Initialized
INFO - 2016-03-11 06:27:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:27:22 --> Pagination Class Initialized
INFO - 2016-03-11 06:27:22 --> Helper loaded: text_helper
INFO - 2016-03-11 06:27:22 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:27:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-11 09:27:22 --> Severity: Error --> Call to undefined method CI_Pagination::current_place() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 167
INFO - 2016-03-11 06:28:09 --> Config Class Initialized
INFO - 2016-03-11 06:28:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:28:09 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:28:09 --> Utf8 Class Initialized
INFO - 2016-03-11 06:28:09 --> URI Class Initialized
INFO - 2016-03-11 06:28:09 --> Router Class Initialized
INFO - 2016-03-11 06:28:09 --> Output Class Initialized
INFO - 2016-03-11 06:28:09 --> Security Class Initialized
DEBUG - 2016-03-11 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:28:09 --> Input Class Initialized
INFO - 2016-03-11 06:28:09 --> Language Class Initialized
INFO - 2016-03-11 06:28:09 --> Loader Class Initialized
INFO - 2016-03-11 06:28:09 --> Helper loaded: url_helper
INFO - 2016-03-11 06:28:09 --> Helper loaded: file_helper
INFO - 2016-03-11 06:28:09 --> Helper loaded: date_helper
INFO - 2016-03-11 06:28:09 --> Helper loaded: form_helper
INFO - 2016-03-11 06:28:09 --> Database Driver Class Initialized
INFO - 2016-03-11 06:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:28:10 --> Controller Class Initialized
INFO - 2016-03-11 06:28:10 --> Model Class Initialized
INFO - 2016-03-11 06:28:10 --> Model Class Initialized
INFO - 2016-03-11 06:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:28:10 --> Pagination Class Initialized
INFO - 2016-03-11 06:28:10 --> Helper loaded: text_helper
INFO - 2016-03-11 06:28:10 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-11 09:28:10 --> Severity: Error --> Call to undefined method CI_Pagination::current_place() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 167
INFO - 2016-03-11 06:28:19 --> Config Class Initialized
INFO - 2016-03-11 06:28:19 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:28:19 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:28:19 --> Utf8 Class Initialized
INFO - 2016-03-11 06:28:19 --> URI Class Initialized
INFO - 2016-03-11 06:28:19 --> Router Class Initialized
INFO - 2016-03-11 06:28:19 --> Output Class Initialized
INFO - 2016-03-11 06:28:19 --> Security Class Initialized
DEBUG - 2016-03-11 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:28:19 --> Input Class Initialized
INFO - 2016-03-11 06:28:19 --> Language Class Initialized
INFO - 2016-03-11 06:28:19 --> Loader Class Initialized
INFO - 2016-03-11 06:28:19 --> Helper loaded: url_helper
INFO - 2016-03-11 06:28:19 --> Helper loaded: file_helper
INFO - 2016-03-11 06:28:19 --> Helper loaded: date_helper
INFO - 2016-03-11 06:28:19 --> Helper loaded: form_helper
INFO - 2016-03-11 06:28:19 --> Database Driver Class Initialized
INFO - 2016-03-11 06:28:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:28:20 --> Controller Class Initialized
INFO - 2016-03-11 06:28:20 --> Model Class Initialized
INFO - 2016-03-11 06:28:20 --> Model Class Initialized
INFO - 2016-03-11 06:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:28:20 --> Pagination Class Initialized
INFO - 2016-03-11 06:28:20 --> Helper loaded: text_helper
INFO - 2016-03-11 06:28:20 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:28:20 --> Final output sent to browser
DEBUG - 2016-03-11 09:28:20 --> Total execution time: 1.1429
INFO - 2016-03-11 06:30:01 --> Config Class Initialized
INFO - 2016-03-11 06:30:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:01 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:01 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:01 --> URI Class Initialized
INFO - 2016-03-11 06:30:01 --> Router Class Initialized
INFO - 2016-03-11 06:30:01 --> Output Class Initialized
INFO - 2016-03-11 06:30:01 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:01 --> Input Class Initialized
INFO - 2016-03-11 06:30:01 --> Language Class Initialized
INFO - 2016-03-11 06:30:01 --> Loader Class Initialized
INFO - 2016-03-11 06:30:01 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:01 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:01 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:01 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:01 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:02 --> Controller Class Initialized
INFO - 2016-03-11 06:30:02 --> Model Class Initialized
INFO - 2016-03-11 06:30:02 --> Model Class Initialized
INFO - 2016-03-11 06:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:02 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:02 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:02 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:02 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:02 --> Total execution time: 1.1732
INFO - 2016-03-11 06:30:04 --> Config Class Initialized
INFO - 2016-03-11 06:30:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:04 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:04 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:04 --> URI Class Initialized
INFO - 2016-03-11 06:30:04 --> Router Class Initialized
INFO - 2016-03-11 06:30:04 --> Output Class Initialized
INFO - 2016-03-11 06:30:04 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:04 --> Input Class Initialized
INFO - 2016-03-11 06:30:04 --> Language Class Initialized
INFO - 2016-03-11 06:30:04 --> Loader Class Initialized
INFO - 2016-03-11 06:30:04 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:04 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:04 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:04 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:04 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:06 --> Controller Class Initialized
INFO - 2016-03-11 06:30:06 --> Model Class Initialized
INFO - 2016-03-11 06:30:06 --> Model Class Initialized
INFO - 2016-03-11 06:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:06 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:06 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:06 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:06 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:06 --> Total execution time: 1.1865
INFO - 2016-03-11 06:30:12 --> Config Class Initialized
INFO - 2016-03-11 06:30:12 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:12 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:12 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:12 --> URI Class Initialized
INFO - 2016-03-11 06:30:12 --> Router Class Initialized
INFO - 2016-03-11 06:30:12 --> Output Class Initialized
INFO - 2016-03-11 06:30:12 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:12 --> Input Class Initialized
INFO - 2016-03-11 06:30:12 --> Language Class Initialized
INFO - 2016-03-11 06:30:12 --> Loader Class Initialized
INFO - 2016-03-11 06:30:12 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:12 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:12 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:12 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:12 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:13 --> Controller Class Initialized
INFO - 2016-03-11 06:30:13 --> Model Class Initialized
INFO - 2016-03-11 06:30:13 --> Model Class Initialized
INFO - 2016-03-11 06:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:13 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:13 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:13 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:13 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:13 --> Total execution time: 1.0984
INFO - 2016-03-11 06:30:15 --> Config Class Initialized
INFO - 2016-03-11 06:30:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:15 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:15 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:15 --> URI Class Initialized
INFO - 2016-03-11 06:30:15 --> Router Class Initialized
INFO - 2016-03-11 06:30:15 --> Output Class Initialized
INFO - 2016-03-11 06:30:15 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:15 --> Input Class Initialized
INFO - 2016-03-11 06:30:15 --> Language Class Initialized
INFO - 2016-03-11 06:30:15 --> Loader Class Initialized
INFO - 2016-03-11 06:30:15 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:15 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:15 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:15 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:15 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:16 --> Controller Class Initialized
INFO - 2016-03-11 06:30:16 --> Model Class Initialized
INFO - 2016-03-11 06:30:16 --> Model Class Initialized
INFO - 2016-03-11 06:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:16 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:16 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:16 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:16 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:16 --> Total execution time: 1.1260
INFO - 2016-03-11 06:30:18 --> Config Class Initialized
INFO - 2016-03-11 06:30:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:18 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:18 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:18 --> URI Class Initialized
INFO - 2016-03-11 06:30:18 --> Router Class Initialized
INFO - 2016-03-11 06:30:18 --> Output Class Initialized
INFO - 2016-03-11 06:30:18 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:18 --> Input Class Initialized
INFO - 2016-03-11 06:30:18 --> Language Class Initialized
INFO - 2016-03-11 06:30:18 --> Loader Class Initialized
INFO - 2016-03-11 06:30:18 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:18 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:18 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:18 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:18 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:19 --> Controller Class Initialized
INFO - 2016-03-11 06:30:19 --> Model Class Initialized
INFO - 2016-03-11 06:30:19 --> Model Class Initialized
INFO - 2016-03-11 06:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:19 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:19 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:19 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:19 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:19 --> Total execution time: 1.1402
INFO - 2016-03-11 06:30:21 --> Config Class Initialized
INFO - 2016-03-11 06:30:21 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:30:21 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:30:21 --> Utf8 Class Initialized
INFO - 2016-03-11 06:30:21 --> URI Class Initialized
INFO - 2016-03-11 06:30:21 --> Router Class Initialized
INFO - 2016-03-11 06:30:21 --> Output Class Initialized
INFO - 2016-03-11 06:30:21 --> Security Class Initialized
DEBUG - 2016-03-11 06:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:30:21 --> Input Class Initialized
INFO - 2016-03-11 06:30:21 --> Language Class Initialized
INFO - 2016-03-11 06:30:21 --> Loader Class Initialized
INFO - 2016-03-11 06:30:21 --> Helper loaded: url_helper
INFO - 2016-03-11 06:30:21 --> Helper loaded: file_helper
INFO - 2016-03-11 06:30:21 --> Helper loaded: date_helper
INFO - 2016-03-11 06:30:21 --> Helper loaded: form_helper
INFO - 2016-03-11 06:30:21 --> Database Driver Class Initialized
INFO - 2016-03-11 06:30:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:30:22 --> Controller Class Initialized
INFO - 2016-03-11 06:30:22 --> Model Class Initialized
INFO - 2016-03-11 06:30:22 --> Model Class Initialized
INFO - 2016-03-11 06:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:30:22 --> Pagination Class Initialized
INFO - 2016-03-11 06:30:22 --> Helper loaded: text_helper
INFO - 2016-03-11 06:30:22 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:30:22 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:22 --> Total execution time: 1.1836
INFO - 2016-03-11 06:31:07 --> Config Class Initialized
INFO - 2016-03-11 06:31:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:07 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:07 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:07 --> URI Class Initialized
INFO - 2016-03-11 06:31:07 --> Router Class Initialized
INFO - 2016-03-11 06:31:07 --> Output Class Initialized
INFO - 2016-03-11 06:31:07 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:07 --> Input Class Initialized
INFO - 2016-03-11 06:31:07 --> Language Class Initialized
INFO - 2016-03-11 06:31:07 --> Loader Class Initialized
INFO - 2016-03-11 06:31:07 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:07 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:07 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:07 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:07 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:08 --> Controller Class Initialized
INFO - 2016-03-11 06:31:08 --> Model Class Initialized
INFO - 2016-03-11 06:31:08 --> Model Class Initialized
INFO - 2016-03-11 06:31:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:08 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:08 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:08 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:31:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:31:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:08 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:08 --> Total execution time: 1.1560
INFO - 2016-03-11 06:31:10 --> Config Class Initialized
INFO - 2016-03-11 06:31:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:10 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:10 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:10 --> URI Class Initialized
INFO - 2016-03-11 06:31:10 --> Router Class Initialized
INFO - 2016-03-11 06:31:10 --> Output Class Initialized
INFO - 2016-03-11 06:31:10 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:10 --> Input Class Initialized
INFO - 2016-03-11 06:31:10 --> Language Class Initialized
INFO - 2016-03-11 06:31:10 --> Loader Class Initialized
INFO - 2016-03-11 06:31:10 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:10 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:10 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:10 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:10 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:11 --> Controller Class Initialized
INFO - 2016-03-11 06:31:11 --> Model Class Initialized
INFO - 2016-03-11 06:31:11 --> Model Class Initialized
INFO - 2016-03-11 06:31:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:11 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:11 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:11 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:31:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:31:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:11 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:11 --> Total execution time: 1.1390
INFO - 2016-03-11 06:31:14 --> Config Class Initialized
INFO - 2016-03-11 06:31:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:14 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:14 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:14 --> URI Class Initialized
INFO - 2016-03-11 06:31:14 --> Router Class Initialized
INFO - 2016-03-11 06:31:14 --> Output Class Initialized
INFO - 2016-03-11 06:31:14 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:14 --> Input Class Initialized
INFO - 2016-03-11 06:31:14 --> Language Class Initialized
INFO - 2016-03-11 06:31:14 --> Loader Class Initialized
INFO - 2016-03-11 06:31:14 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:14 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:14 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:14 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:14 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:15 --> Controller Class Initialized
INFO - 2016-03-11 06:31:15 --> Model Class Initialized
INFO - 2016-03-11 06:31:15 --> Model Class Initialized
INFO - 2016-03-11 06:31:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:15 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:15 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:15 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:31:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:15 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:15 --> Total execution time: 1.2193
INFO - 2016-03-11 06:31:52 --> Config Class Initialized
INFO - 2016-03-11 06:31:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:52 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:52 --> URI Class Initialized
INFO - 2016-03-11 06:31:52 --> Router Class Initialized
INFO - 2016-03-11 06:31:52 --> Output Class Initialized
INFO - 2016-03-11 06:31:52 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:52 --> Input Class Initialized
INFO - 2016-03-11 06:31:52 --> Language Class Initialized
INFO - 2016-03-11 06:31:52 --> Loader Class Initialized
INFO - 2016-03-11 06:31:52 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:52 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:52 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:52 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:52 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:53 --> Controller Class Initialized
INFO - 2016-03-11 06:31:53 --> Model Class Initialized
INFO - 2016-03-11 06:31:53 --> Model Class Initialized
INFO - 2016-03-11 06:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:53 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:53 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:31:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:31:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:53 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:53 --> Total execution time: 1.1279
INFO - 2016-03-11 06:31:55 --> Config Class Initialized
INFO - 2016-03-11 06:31:55 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:55 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:55 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:55 --> URI Class Initialized
INFO - 2016-03-11 06:31:55 --> Router Class Initialized
INFO - 2016-03-11 06:31:55 --> Output Class Initialized
INFO - 2016-03-11 06:31:55 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:55 --> Input Class Initialized
INFO - 2016-03-11 06:31:55 --> Language Class Initialized
INFO - 2016-03-11 06:31:55 --> Loader Class Initialized
INFO - 2016-03-11 06:31:55 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:55 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:55 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:55 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:55 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:56 --> Controller Class Initialized
INFO - 2016-03-11 06:31:56 --> Model Class Initialized
INFO - 2016-03-11 06:31:56 --> Model Class Initialized
INFO - 2016-03-11 06:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:56 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:56 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:56 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:56 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:56 --> Total execution time: 1.1365
INFO - 2016-03-11 06:31:58 --> Config Class Initialized
INFO - 2016-03-11 06:31:58 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:31:58 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:31:58 --> Utf8 Class Initialized
INFO - 2016-03-11 06:31:58 --> URI Class Initialized
INFO - 2016-03-11 06:31:58 --> Router Class Initialized
INFO - 2016-03-11 06:31:58 --> Output Class Initialized
INFO - 2016-03-11 06:31:58 --> Security Class Initialized
DEBUG - 2016-03-11 06:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:31:58 --> Input Class Initialized
INFO - 2016-03-11 06:31:58 --> Language Class Initialized
INFO - 2016-03-11 06:31:58 --> Loader Class Initialized
INFO - 2016-03-11 06:31:58 --> Helper loaded: url_helper
INFO - 2016-03-11 06:31:58 --> Helper loaded: file_helper
INFO - 2016-03-11 06:31:58 --> Helper loaded: date_helper
INFO - 2016-03-11 06:31:58 --> Helper loaded: form_helper
INFO - 2016-03-11 06:31:58 --> Database Driver Class Initialized
INFO - 2016-03-11 06:31:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:31:59 --> Controller Class Initialized
INFO - 2016-03-11 06:31:59 --> Model Class Initialized
INFO - 2016-03-11 06:31:59 --> Model Class Initialized
INFO - 2016-03-11 06:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:31:59 --> Pagination Class Initialized
INFO - 2016-03-11 06:31:59 --> Helper loaded: text_helper
INFO - 2016-03-11 06:31:59 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:31:59 --> Final output sent to browser
DEBUG - 2016-03-11 09:31:59 --> Total execution time: 1.1635
INFO - 2016-03-11 06:37:52 --> Config Class Initialized
INFO - 2016-03-11 06:37:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:37:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:37:52 --> Utf8 Class Initialized
INFO - 2016-03-11 06:37:52 --> URI Class Initialized
INFO - 2016-03-11 06:37:52 --> Router Class Initialized
INFO - 2016-03-11 06:37:52 --> Output Class Initialized
INFO - 2016-03-11 06:37:52 --> Security Class Initialized
DEBUG - 2016-03-11 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:37:52 --> Input Class Initialized
INFO - 2016-03-11 06:37:52 --> Language Class Initialized
INFO - 2016-03-11 06:37:52 --> Loader Class Initialized
INFO - 2016-03-11 06:37:52 --> Helper loaded: url_helper
INFO - 2016-03-11 06:37:52 --> Helper loaded: file_helper
INFO - 2016-03-11 06:37:52 --> Helper loaded: date_helper
INFO - 2016-03-11 06:37:52 --> Helper loaded: form_helper
INFO - 2016-03-11 06:37:52 --> Database Driver Class Initialized
INFO - 2016-03-11 06:37:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:37:53 --> Controller Class Initialized
INFO - 2016-03-11 06:37:53 --> Model Class Initialized
INFO - 2016-03-11 06:37:53 --> Model Class Initialized
INFO - 2016-03-11 06:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:37:53 --> Pagination Class Initialized
INFO - 2016-03-11 06:37:53 --> Helper loaded: text_helper
INFO - 2016-03-11 06:37:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:37:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:37:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:37:54 --> Final output sent to browser
DEBUG - 2016-03-11 09:37:54 --> Total execution time: 1.3672
INFO - 2016-03-11 06:37:56 --> Config Class Initialized
INFO - 2016-03-11 06:37:56 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:37:56 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:37:56 --> Utf8 Class Initialized
INFO - 2016-03-11 06:37:56 --> URI Class Initialized
INFO - 2016-03-11 06:37:56 --> Router Class Initialized
INFO - 2016-03-11 06:37:56 --> Output Class Initialized
INFO - 2016-03-11 06:37:56 --> Security Class Initialized
DEBUG - 2016-03-11 06:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:37:56 --> Input Class Initialized
INFO - 2016-03-11 06:37:56 --> Language Class Initialized
INFO - 2016-03-11 06:37:56 --> Loader Class Initialized
INFO - 2016-03-11 06:37:56 --> Helper loaded: url_helper
INFO - 2016-03-11 06:37:56 --> Helper loaded: file_helper
INFO - 2016-03-11 06:37:56 --> Helper loaded: date_helper
INFO - 2016-03-11 06:37:56 --> Helper loaded: form_helper
INFO - 2016-03-11 06:37:56 --> Database Driver Class Initialized
INFO - 2016-03-11 06:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:37:57 --> Controller Class Initialized
INFO - 2016-03-11 06:37:57 --> Model Class Initialized
INFO - 2016-03-11 06:37:57 --> Model Class Initialized
INFO - 2016-03-11 06:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:37:57 --> Pagination Class Initialized
INFO - 2016-03-11 06:37:57 --> Helper loaded: text_helper
INFO - 2016-03-11 06:37:57 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:37:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:37:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:37:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:37:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:37:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:37:57 --> Final output sent to browser
DEBUG - 2016-03-11 09:37:57 --> Total execution time: 1.1452
INFO - 2016-03-11 06:37:59 --> Config Class Initialized
INFO - 2016-03-11 06:37:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:37:59 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:37:59 --> Utf8 Class Initialized
INFO - 2016-03-11 06:37:59 --> URI Class Initialized
INFO - 2016-03-11 06:37:59 --> Router Class Initialized
INFO - 2016-03-11 06:37:59 --> Output Class Initialized
INFO - 2016-03-11 06:37:59 --> Security Class Initialized
DEBUG - 2016-03-11 06:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:37:59 --> Input Class Initialized
INFO - 2016-03-11 06:37:59 --> Language Class Initialized
INFO - 2016-03-11 06:37:59 --> Loader Class Initialized
INFO - 2016-03-11 06:37:59 --> Helper loaded: url_helper
INFO - 2016-03-11 06:37:59 --> Helper loaded: file_helper
INFO - 2016-03-11 06:37:59 --> Helper loaded: date_helper
INFO - 2016-03-11 06:37:59 --> Helper loaded: form_helper
INFO - 2016-03-11 06:37:59 --> Database Driver Class Initialized
INFO - 2016-03-11 06:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:38:00 --> Controller Class Initialized
INFO - 2016-03-11 06:38:00 --> Model Class Initialized
INFO - 2016-03-11 06:38:00 --> Model Class Initialized
INFO - 2016-03-11 06:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:38:00 --> Pagination Class Initialized
INFO - 2016-03-11 06:38:00 --> Helper loaded: text_helper
INFO - 2016-03-11 06:38:00 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:38:00 --> Final output sent to browser
DEBUG - 2016-03-11 09:38:00 --> Total execution time: 1.1527
INFO - 2016-03-11 06:39:27 --> Config Class Initialized
INFO - 2016-03-11 06:39:27 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:39:27 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:39:27 --> Utf8 Class Initialized
INFO - 2016-03-11 06:39:27 --> URI Class Initialized
INFO - 2016-03-11 06:39:27 --> Router Class Initialized
INFO - 2016-03-11 06:39:27 --> Output Class Initialized
INFO - 2016-03-11 06:39:27 --> Security Class Initialized
DEBUG - 2016-03-11 06:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:39:27 --> Input Class Initialized
INFO - 2016-03-11 06:39:27 --> Language Class Initialized
INFO - 2016-03-11 06:39:27 --> Loader Class Initialized
INFO - 2016-03-11 06:39:27 --> Helper loaded: url_helper
INFO - 2016-03-11 06:39:27 --> Helper loaded: file_helper
INFO - 2016-03-11 06:39:27 --> Helper loaded: date_helper
INFO - 2016-03-11 06:39:27 --> Helper loaded: form_helper
INFO - 2016-03-11 06:39:27 --> Database Driver Class Initialized
INFO - 2016-03-11 06:39:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:39:28 --> Controller Class Initialized
INFO - 2016-03-11 06:39:28 --> Model Class Initialized
INFO - 2016-03-11 06:39:28 --> Model Class Initialized
INFO - 2016-03-11 06:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:39:28 --> Pagination Class Initialized
INFO - 2016-03-11 06:39:28 --> Helper loaded: text_helper
INFO - 2016-03-11 06:39:28 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:39:28 --> Final output sent to browser
DEBUG - 2016-03-11 09:39:28 --> Total execution time: 1.1950
INFO - 2016-03-11 06:39:30 --> Config Class Initialized
INFO - 2016-03-11 06:39:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:39:30 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:39:30 --> Utf8 Class Initialized
INFO - 2016-03-11 06:39:30 --> URI Class Initialized
INFO - 2016-03-11 06:39:30 --> Router Class Initialized
INFO - 2016-03-11 06:39:30 --> Output Class Initialized
INFO - 2016-03-11 06:39:30 --> Security Class Initialized
DEBUG - 2016-03-11 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:39:30 --> Input Class Initialized
INFO - 2016-03-11 06:39:30 --> Language Class Initialized
INFO - 2016-03-11 06:39:30 --> Loader Class Initialized
INFO - 2016-03-11 06:39:30 --> Helper loaded: url_helper
INFO - 2016-03-11 06:39:30 --> Helper loaded: file_helper
INFO - 2016-03-11 06:39:30 --> Helper loaded: date_helper
INFO - 2016-03-11 06:39:30 --> Helper loaded: form_helper
INFO - 2016-03-11 06:39:30 --> Database Driver Class Initialized
INFO - 2016-03-11 06:39:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:39:31 --> Controller Class Initialized
INFO - 2016-03-11 06:39:31 --> Model Class Initialized
INFO - 2016-03-11 06:39:31 --> Model Class Initialized
INFO - 2016-03-11 06:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:39:31 --> Pagination Class Initialized
INFO - 2016-03-11 06:39:31 --> Helper loaded: text_helper
INFO - 2016-03-11 06:39:31 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:39:31 --> Final output sent to browser
DEBUG - 2016-03-11 09:39:31 --> Total execution time: 1.1552
INFO - 2016-03-11 06:39:33 --> Config Class Initialized
INFO - 2016-03-11 06:39:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:39:33 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:39:33 --> Utf8 Class Initialized
INFO - 2016-03-11 06:39:33 --> URI Class Initialized
INFO - 2016-03-11 06:39:33 --> Router Class Initialized
INFO - 2016-03-11 06:39:33 --> Output Class Initialized
INFO - 2016-03-11 06:39:33 --> Security Class Initialized
DEBUG - 2016-03-11 06:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:39:33 --> Input Class Initialized
INFO - 2016-03-11 06:39:33 --> Language Class Initialized
INFO - 2016-03-11 06:39:33 --> Loader Class Initialized
INFO - 2016-03-11 06:39:33 --> Helper loaded: url_helper
INFO - 2016-03-11 06:39:33 --> Helper loaded: file_helper
INFO - 2016-03-11 06:39:33 --> Helper loaded: date_helper
INFO - 2016-03-11 06:39:33 --> Helper loaded: form_helper
INFO - 2016-03-11 06:39:33 --> Database Driver Class Initialized
INFO - 2016-03-11 06:39:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:39:34 --> Controller Class Initialized
INFO - 2016-03-11 06:39:34 --> Model Class Initialized
INFO - 2016-03-11 06:39:34 --> Model Class Initialized
INFO - 2016-03-11 06:39:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:39:34 --> Pagination Class Initialized
INFO - 2016-03-11 06:39:34 --> Helper loaded: text_helper
INFO - 2016-03-11 06:39:34 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:39:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:39:34 --> Final output sent to browser
DEBUG - 2016-03-11 09:39:34 --> Total execution time: 1.1983
INFO - 2016-03-11 06:40:43 --> Config Class Initialized
INFO - 2016-03-11 06:40:43 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:40:43 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:40:43 --> Utf8 Class Initialized
INFO - 2016-03-11 06:40:43 --> URI Class Initialized
INFO - 2016-03-11 06:40:43 --> Router Class Initialized
INFO - 2016-03-11 06:40:43 --> Output Class Initialized
INFO - 2016-03-11 06:40:43 --> Security Class Initialized
DEBUG - 2016-03-11 06:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:40:43 --> Input Class Initialized
INFO - 2016-03-11 06:40:43 --> Language Class Initialized
INFO - 2016-03-11 06:40:43 --> Loader Class Initialized
INFO - 2016-03-11 06:40:43 --> Helper loaded: url_helper
INFO - 2016-03-11 06:40:43 --> Helper loaded: file_helper
INFO - 2016-03-11 06:40:43 --> Helper loaded: date_helper
INFO - 2016-03-11 06:40:43 --> Helper loaded: form_helper
INFO - 2016-03-11 06:40:43 --> Database Driver Class Initialized
INFO - 2016-03-11 06:40:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:40:44 --> Controller Class Initialized
INFO - 2016-03-11 06:40:44 --> Model Class Initialized
INFO - 2016-03-11 06:40:44 --> Model Class Initialized
INFO - 2016-03-11 06:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:40:44 --> Pagination Class Initialized
INFO - 2016-03-11 06:40:44 --> Helper loaded: text_helper
INFO - 2016-03-11 06:40:44 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:40:44 --> Final output sent to browser
DEBUG - 2016-03-11 09:40:44 --> Total execution time: 1.1883
INFO - 2016-03-11 06:40:47 --> Config Class Initialized
INFO - 2016-03-11 06:40:47 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:40:47 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:40:47 --> Utf8 Class Initialized
INFO - 2016-03-11 06:40:47 --> URI Class Initialized
INFO - 2016-03-11 06:40:47 --> Router Class Initialized
INFO - 2016-03-11 06:40:47 --> Output Class Initialized
INFO - 2016-03-11 06:40:47 --> Security Class Initialized
DEBUG - 2016-03-11 06:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:40:47 --> Input Class Initialized
INFO - 2016-03-11 06:40:47 --> Language Class Initialized
INFO - 2016-03-11 06:40:47 --> Loader Class Initialized
INFO - 2016-03-11 06:40:47 --> Helper loaded: url_helper
INFO - 2016-03-11 06:40:47 --> Helper loaded: file_helper
INFO - 2016-03-11 06:40:47 --> Helper loaded: date_helper
INFO - 2016-03-11 06:40:47 --> Helper loaded: form_helper
INFO - 2016-03-11 06:40:47 --> Database Driver Class Initialized
INFO - 2016-03-11 06:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:40:48 --> Controller Class Initialized
INFO - 2016-03-11 06:40:48 --> Model Class Initialized
INFO - 2016-03-11 06:40:48 --> Model Class Initialized
INFO - 2016-03-11 06:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:40:48 --> Pagination Class Initialized
INFO - 2016-03-11 06:40:48 --> Helper loaded: text_helper
INFO - 2016-03-11 06:40:48 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:40:48 --> Final output sent to browser
DEBUG - 2016-03-11 09:40:48 --> Total execution time: 1.1492
INFO - 2016-03-11 06:40:50 --> Config Class Initialized
INFO - 2016-03-11 06:40:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:40:50 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:40:50 --> Utf8 Class Initialized
INFO - 2016-03-11 06:40:50 --> URI Class Initialized
INFO - 2016-03-11 06:40:50 --> Router Class Initialized
INFO - 2016-03-11 06:40:50 --> Output Class Initialized
INFO - 2016-03-11 06:40:50 --> Security Class Initialized
DEBUG - 2016-03-11 06:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:40:50 --> Input Class Initialized
INFO - 2016-03-11 06:40:50 --> Language Class Initialized
INFO - 2016-03-11 06:40:50 --> Loader Class Initialized
INFO - 2016-03-11 06:40:50 --> Helper loaded: url_helper
INFO - 2016-03-11 06:40:50 --> Helper loaded: file_helper
INFO - 2016-03-11 06:40:50 --> Helper loaded: date_helper
INFO - 2016-03-11 06:40:50 --> Helper loaded: form_helper
INFO - 2016-03-11 06:40:50 --> Database Driver Class Initialized
INFO - 2016-03-11 06:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:40:51 --> Controller Class Initialized
INFO - 2016-03-11 06:40:51 --> Model Class Initialized
INFO - 2016-03-11 06:40:51 --> Model Class Initialized
INFO - 2016-03-11 06:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:40:51 --> Pagination Class Initialized
INFO - 2016-03-11 06:40:51 --> Helper loaded: text_helper
INFO - 2016-03-11 06:40:51 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:40:51 --> Final output sent to browser
DEBUG - 2016-03-11 09:40:51 --> Total execution time: 1.1571
INFO - 2016-03-11 06:40:52 --> Config Class Initialized
INFO - 2016-03-11 06:40:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:40:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:40:52 --> Utf8 Class Initialized
INFO - 2016-03-11 06:40:52 --> URI Class Initialized
INFO - 2016-03-11 06:40:52 --> Router Class Initialized
INFO - 2016-03-11 06:40:52 --> Output Class Initialized
INFO - 2016-03-11 06:40:52 --> Security Class Initialized
DEBUG - 2016-03-11 06:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:40:52 --> Input Class Initialized
INFO - 2016-03-11 06:40:52 --> Language Class Initialized
INFO - 2016-03-11 06:40:52 --> Loader Class Initialized
INFO - 2016-03-11 06:40:52 --> Helper loaded: url_helper
INFO - 2016-03-11 06:40:52 --> Helper loaded: file_helper
INFO - 2016-03-11 06:40:52 --> Helper loaded: date_helper
INFO - 2016-03-11 06:40:52 --> Helper loaded: form_helper
INFO - 2016-03-11 06:40:52 --> Database Driver Class Initialized
INFO - 2016-03-11 06:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:40:53 --> Controller Class Initialized
INFO - 2016-03-11 06:40:53 --> Model Class Initialized
INFO - 2016-03-11 06:40:53 --> Model Class Initialized
INFO - 2016-03-11 06:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:40:53 --> Pagination Class Initialized
INFO - 2016-03-11 06:40:53 --> Helper loaded: text_helper
INFO - 2016-03-11 06:40:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:40:53 --> Final output sent to browser
DEBUG - 2016-03-11 09:40:53 --> Total execution time: 1.3029
INFO - 2016-03-11 06:41:22 --> Config Class Initialized
INFO - 2016-03-11 06:41:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:41:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:41:22 --> Utf8 Class Initialized
INFO - 2016-03-11 06:41:22 --> URI Class Initialized
INFO - 2016-03-11 06:41:22 --> Router Class Initialized
INFO - 2016-03-11 06:41:22 --> Output Class Initialized
INFO - 2016-03-11 06:41:22 --> Security Class Initialized
DEBUG - 2016-03-11 06:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:41:22 --> Input Class Initialized
INFO - 2016-03-11 06:41:22 --> Language Class Initialized
INFO - 2016-03-11 06:41:22 --> Loader Class Initialized
INFO - 2016-03-11 06:41:22 --> Helper loaded: url_helper
INFO - 2016-03-11 06:41:22 --> Helper loaded: file_helper
INFO - 2016-03-11 06:41:22 --> Helper loaded: date_helper
INFO - 2016-03-11 06:41:22 --> Helper loaded: form_helper
INFO - 2016-03-11 06:41:22 --> Database Driver Class Initialized
INFO - 2016-03-11 06:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:41:23 --> Controller Class Initialized
INFO - 2016-03-11 06:41:23 --> Model Class Initialized
INFO - 2016-03-11 06:41:23 --> Model Class Initialized
INFO - 2016-03-11 06:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:41:23 --> Pagination Class Initialized
INFO - 2016-03-11 06:41:23 --> Helper loaded: text_helper
INFO - 2016-03-11 06:41:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:41:23 --> Final output sent to browser
DEBUG - 2016-03-11 09:41:23 --> Total execution time: 1.1494
INFO - 2016-03-11 06:41:25 --> Config Class Initialized
INFO - 2016-03-11 06:41:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:41:25 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:41:25 --> Utf8 Class Initialized
INFO - 2016-03-11 06:41:25 --> URI Class Initialized
INFO - 2016-03-11 06:41:25 --> Router Class Initialized
INFO - 2016-03-11 06:41:25 --> Output Class Initialized
INFO - 2016-03-11 06:41:25 --> Security Class Initialized
DEBUG - 2016-03-11 06:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:41:25 --> Input Class Initialized
INFO - 2016-03-11 06:41:25 --> Language Class Initialized
INFO - 2016-03-11 06:41:25 --> Loader Class Initialized
INFO - 2016-03-11 06:41:25 --> Helper loaded: url_helper
INFO - 2016-03-11 06:41:25 --> Helper loaded: file_helper
INFO - 2016-03-11 06:41:25 --> Helper loaded: date_helper
INFO - 2016-03-11 06:41:25 --> Helper loaded: form_helper
INFO - 2016-03-11 06:41:25 --> Database Driver Class Initialized
INFO - 2016-03-11 06:41:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:41:26 --> Controller Class Initialized
INFO - 2016-03-11 06:41:26 --> Model Class Initialized
INFO - 2016-03-11 06:41:26 --> Model Class Initialized
INFO - 2016-03-11 06:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:41:26 --> Pagination Class Initialized
INFO - 2016-03-11 06:41:26 --> Helper loaded: text_helper
INFO - 2016-03-11 06:41:26 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:41:26 --> Final output sent to browser
DEBUG - 2016-03-11 09:41:26 --> Total execution time: 1.1551
INFO - 2016-03-11 06:41:28 --> Config Class Initialized
INFO - 2016-03-11 06:41:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:41:28 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:41:28 --> Utf8 Class Initialized
INFO - 2016-03-11 06:41:28 --> URI Class Initialized
INFO - 2016-03-11 06:41:28 --> Router Class Initialized
INFO - 2016-03-11 06:41:28 --> Output Class Initialized
INFO - 2016-03-11 06:41:28 --> Security Class Initialized
DEBUG - 2016-03-11 06:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:41:28 --> Input Class Initialized
INFO - 2016-03-11 06:41:28 --> Language Class Initialized
INFO - 2016-03-11 06:41:28 --> Loader Class Initialized
INFO - 2016-03-11 06:41:28 --> Helper loaded: url_helper
INFO - 2016-03-11 06:41:28 --> Helper loaded: file_helper
INFO - 2016-03-11 06:41:28 --> Helper loaded: date_helper
INFO - 2016-03-11 06:41:28 --> Helper loaded: form_helper
INFO - 2016-03-11 06:41:28 --> Database Driver Class Initialized
INFO - 2016-03-11 06:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:41:29 --> Controller Class Initialized
INFO - 2016-03-11 06:41:29 --> Model Class Initialized
INFO - 2016-03-11 06:41:29 --> Model Class Initialized
INFO - 2016-03-11 06:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:41:29 --> Pagination Class Initialized
INFO - 2016-03-11 06:41:29 --> Helper loaded: text_helper
INFO - 2016-03-11 06:41:29 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:41:29 --> Final output sent to browser
DEBUG - 2016-03-11 09:41:29 --> Total execution time: 1.2184
INFO - 2016-03-11 06:41:35 --> Config Class Initialized
INFO - 2016-03-11 06:41:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:41:35 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:41:35 --> Utf8 Class Initialized
INFO - 2016-03-11 06:41:35 --> URI Class Initialized
INFO - 2016-03-11 06:41:35 --> Router Class Initialized
INFO - 2016-03-11 06:41:35 --> Output Class Initialized
INFO - 2016-03-11 06:41:35 --> Security Class Initialized
DEBUG - 2016-03-11 06:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:41:35 --> Input Class Initialized
INFO - 2016-03-11 06:41:35 --> Language Class Initialized
INFO - 2016-03-11 06:41:35 --> Loader Class Initialized
INFO - 2016-03-11 06:41:35 --> Helper loaded: url_helper
INFO - 2016-03-11 06:41:35 --> Helper loaded: file_helper
INFO - 2016-03-11 06:41:35 --> Helper loaded: date_helper
INFO - 2016-03-11 06:41:35 --> Helper loaded: form_helper
INFO - 2016-03-11 06:41:35 --> Database Driver Class Initialized
INFO - 2016-03-11 06:41:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:41:36 --> Controller Class Initialized
INFO - 2016-03-11 06:41:36 --> Model Class Initialized
INFO - 2016-03-11 06:41:36 --> Model Class Initialized
INFO - 2016-03-11 06:41:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:41:36 --> Pagination Class Initialized
INFO - 2016-03-11 06:41:36 --> Helper loaded: text_helper
INFO - 2016-03-11 06:41:36 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:41:36 --> Final output sent to browser
DEBUG - 2016-03-11 09:41:36 --> Total execution time: 1.1506
INFO - 2016-03-11 06:48:19 --> Config Class Initialized
INFO - 2016-03-11 06:48:19 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:48:19 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:48:19 --> Utf8 Class Initialized
INFO - 2016-03-11 06:48:19 --> URI Class Initialized
INFO - 2016-03-11 06:48:19 --> Router Class Initialized
INFO - 2016-03-11 06:48:19 --> Output Class Initialized
INFO - 2016-03-11 06:48:19 --> Security Class Initialized
DEBUG - 2016-03-11 06:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:48:19 --> Input Class Initialized
INFO - 2016-03-11 06:48:19 --> Language Class Initialized
INFO - 2016-03-11 06:48:19 --> Loader Class Initialized
INFO - 2016-03-11 06:48:19 --> Helper loaded: url_helper
INFO - 2016-03-11 06:48:19 --> Helper loaded: file_helper
INFO - 2016-03-11 06:48:19 --> Helper loaded: date_helper
INFO - 2016-03-11 06:48:19 --> Helper loaded: form_helper
INFO - 2016-03-11 06:48:19 --> Database Driver Class Initialized
INFO - 2016-03-11 06:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:48:20 --> Controller Class Initialized
INFO - 2016-03-11 06:48:20 --> Model Class Initialized
INFO - 2016-03-11 06:48:20 --> Model Class Initialized
INFO - 2016-03-11 06:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:48:20 --> Pagination Class Initialized
INFO - 2016-03-11 06:48:20 --> Helper loaded: text_helper
INFO - 2016-03-11 06:48:20 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:48:20 --> Final output sent to browser
DEBUG - 2016-03-11 09:48:20 --> Total execution time: 1.1500
INFO - 2016-03-11 06:48:22 --> Config Class Initialized
INFO - 2016-03-11 06:48:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:48:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:48:22 --> Utf8 Class Initialized
INFO - 2016-03-11 06:48:22 --> URI Class Initialized
INFO - 2016-03-11 06:48:22 --> Router Class Initialized
INFO - 2016-03-11 06:48:22 --> Output Class Initialized
INFO - 2016-03-11 06:48:22 --> Security Class Initialized
DEBUG - 2016-03-11 06:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:48:22 --> Input Class Initialized
INFO - 2016-03-11 06:48:22 --> Language Class Initialized
INFO - 2016-03-11 06:48:22 --> Loader Class Initialized
INFO - 2016-03-11 06:48:22 --> Helper loaded: url_helper
INFO - 2016-03-11 06:48:22 --> Helper loaded: file_helper
INFO - 2016-03-11 06:48:22 --> Helper loaded: date_helper
INFO - 2016-03-11 06:48:22 --> Helper loaded: form_helper
INFO - 2016-03-11 06:48:22 --> Database Driver Class Initialized
INFO - 2016-03-11 06:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:48:23 --> Controller Class Initialized
INFO - 2016-03-11 06:48:23 --> Model Class Initialized
INFO - 2016-03-11 06:48:23 --> Model Class Initialized
INFO - 2016-03-11 06:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:48:23 --> Pagination Class Initialized
INFO - 2016-03-11 06:48:23 --> Helper loaded: text_helper
INFO - 2016-03-11 06:48:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:48:23 --> Final output sent to browser
DEBUG - 2016-03-11 09:48:23 --> Total execution time: 1.1017
INFO - 2016-03-11 06:48:25 --> Config Class Initialized
INFO - 2016-03-11 06:48:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:48:25 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:48:25 --> Utf8 Class Initialized
INFO - 2016-03-11 06:48:25 --> URI Class Initialized
INFO - 2016-03-11 06:48:25 --> Router Class Initialized
INFO - 2016-03-11 06:48:25 --> Output Class Initialized
INFO - 2016-03-11 06:48:25 --> Security Class Initialized
DEBUG - 2016-03-11 06:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:48:25 --> Input Class Initialized
INFO - 2016-03-11 06:48:25 --> Language Class Initialized
INFO - 2016-03-11 06:48:25 --> Loader Class Initialized
INFO - 2016-03-11 06:48:25 --> Helper loaded: url_helper
INFO - 2016-03-11 06:48:25 --> Helper loaded: file_helper
INFO - 2016-03-11 06:48:25 --> Helper loaded: date_helper
INFO - 2016-03-11 06:48:25 --> Helper loaded: form_helper
INFO - 2016-03-11 06:48:25 --> Database Driver Class Initialized
INFO - 2016-03-11 06:48:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:48:26 --> Controller Class Initialized
INFO - 2016-03-11 06:48:26 --> Model Class Initialized
INFO - 2016-03-11 06:48:26 --> Model Class Initialized
INFO - 2016-03-11 06:48:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:48:26 --> Pagination Class Initialized
INFO - 2016-03-11 06:48:26 --> Helper loaded: text_helper
INFO - 2016-03-11 06:48:26 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:48:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:48:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:48:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:48:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:48:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:48:26 --> Final output sent to browser
DEBUG - 2016-03-11 09:48:26 --> Total execution time: 1.1253
INFO - 2016-03-11 06:48:28 --> Config Class Initialized
INFO - 2016-03-11 06:48:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:48:28 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:48:28 --> Utf8 Class Initialized
INFO - 2016-03-11 06:48:28 --> URI Class Initialized
INFO - 2016-03-11 06:48:28 --> Router Class Initialized
INFO - 2016-03-11 06:48:28 --> Output Class Initialized
INFO - 2016-03-11 06:48:28 --> Security Class Initialized
DEBUG - 2016-03-11 06:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:48:28 --> Input Class Initialized
INFO - 2016-03-11 06:48:28 --> Language Class Initialized
INFO - 2016-03-11 06:48:28 --> Loader Class Initialized
INFO - 2016-03-11 06:48:28 --> Helper loaded: url_helper
INFO - 2016-03-11 06:48:28 --> Helper loaded: file_helper
INFO - 2016-03-11 06:48:28 --> Helper loaded: date_helper
INFO - 2016-03-11 06:48:28 --> Helper loaded: form_helper
INFO - 2016-03-11 06:48:28 --> Database Driver Class Initialized
INFO - 2016-03-11 06:48:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:48:29 --> Controller Class Initialized
INFO - 2016-03-11 06:48:29 --> Model Class Initialized
INFO - 2016-03-11 06:48:29 --> Model Class Initialized
INFO - 2016-03-11 06:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:48:29 --> Pagination Class Initialized
INFO - 2016-03-11 06:48:29 --> Helper loaded: text_helper
INFO - 2016-03-11 06:48:29 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:48:29 --> Final output sent to browser
DEBUG - 2016-03-11 09:48:29 --> Total execution time: 1.1527
INFO - 2016-03-11 06:53:03 --> Config Class Initialized
INFO - 2016-03-11 06:53:03 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:03 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:03 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:03 --> URI Class Initialized
INFO - 2016-03-11 06:53:03 --> Router Class Initialized
INFO - 2016-03-11 06:53:03 --> Output Class Initialized
INFO - 2016-03-11 06:53:03 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:03 --> Input Class Initialized
INFO - 2016-03-11 06:53:03 --> Language Class Initialized
INFO - 2016-03-11 06:53:03 --> Loader Class Initialized
INFO - 2016-03-11 06:53:03 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:03 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:03 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:03 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:03 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:04 --> Controller Class Initialized
INFO - 2016-03-11 06:53:04 --> Model Class Initialized
INFO - 2016-03-11 06:53:04 --> Model Class Initialized
INFO - 2016-03-11 06:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:04 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:04 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:04 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:04 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:04 --> Total execution time: 1.1850
INFO - 2016-03-11 06:53:08 --> Config Class Initialized
INFO - 2016-03-11 06:53:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:08 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:08 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:08 --> URI Class Initialized
INFO - 2016-03-11 06:53:08 --> Router Class Initialized
INFO - 2016-03-11 06:53:08 --> Output Class Initialized
INFO - 2016-03-11 06:53:08 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:08 --> Input Class Initialized
INFO - 2016-03-11 06:53:08 --> Language Class Initialized
INFO - 2016-03-11 06:53:08 --> Loader Class Initialized
INFO - 2016-03-11 06:53:08 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:08 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:08 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:08 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:08 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:09 --> Controller Class Initialized
INFO - 2016-03-11 06:53:09 --> Model Class Initialized
INFO - 2016-03-11 06:53:09 --> Model Class Initialized
INFO - 2016-03-11 06:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:09 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:09 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:09 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:09 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:09 --> Total execution time: 1.1998
INFO - 2016-03-11 06:53:22 --> Config Class Initialized
INFO - 2016-03-11 06:53:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:22 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:22 --> URI Class Initialized
INFO - 2016-03-11 06:53:22 --> Router Class Initialized
INFO - 2016-03-11 06:53:22 --> Output Class Initialized
INFO - 2016-03-11 06:53:22 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:22 --> Input Class Initialized
INFO - 2016-03-11 06:53:22 --> Language Class Initialized
INFO - 2016-03-11 06:53:22 --> Loader Class Initialized
INFO - 2016-03-11 06:53:22 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:22 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:22 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:22 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:22 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:23 --> Controller Class Initialized
INFO - 2016-03-11 06:53:23 --> Model Class Initialized
INFO - 2016-03-11 06:53:23 --> Model Class Initialized
INFO - 2016-03-11 06:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:23 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:23 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:23 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:23 --> Total execution time: 1.1794
INFO - 2016-03-11 06:53:32 --> Config Class Initialized
INFO - 2016-03-11 06:53:32 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:32 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:32 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:32 --> URI Class Initialized
INFO - 2016-03-11 06:53:32 --> Router Class Initialized
INFO - 2016-03-11 06:53:32 --> Output Class Initialized
INFO - 2016-03-11 06:53:32 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:32 --> Input Class Initialized
INFO - 2016-03-11 06:53:32 --> Language Class Initialized
INFO - 2016-03-11 06:53:32 --> Loader Class Initialized
INFO - 2016-03-11 06:53:32 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:32 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:32 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:32 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:32 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:33 --> Controller Class Initialized
INFO - 2016-03-11 06:53:33 --> Model Class Initialized
INFO - 2016-03-11 06:53:33 --> Model Class Initialized
INFO - 2016-03-11 06:53:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:33 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:33 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:33 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:33 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:33 --> Total execution time: 1.2359
INFO - 2016-03-11 06:53:40 --> Config Class Initialized
INFO - 2016-03-11 06:53:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:40 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:40 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:40 --> URI Class Initialized
INFO - 2016-03-11 06:53:40 --> Router Class Initialized
INFO - 2016-03-11 06:53:40 --> Output Class Initialized
INFO - 2016-03-11 06:53:40 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:40 --> Input Class Initialized
INFO - 2016-03-11 06:53:40 --> Language Class Initialized
INFO - 2016-03-11 06:53:40 --> Loader Class Initialized
INFO - 2016-03-11 06:53:40 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:40 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:40 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:40 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:40 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:41 --> Controller Class Initialized
INFO - 2016-03-11 06:53:41 --> Model Class Initialized
INFO - 2016-03-11 06:53:41 --> Model Class Initialized
INFO - 2016-03-11 06:53:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:41 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:41 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:41 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:53:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:53:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:41 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:41 --> Total execution time: 1.1224
INFO - 2016-03-11 06:53:43 --> Config Class Initialized
INFO - 2016-03-11 06:53:43 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:43 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:43 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:43 --> URI Class Initialized
INFO - 2016-03-11 06:53:43 --> Router Class Initialized
INFO - 2016-03-11 06:53:43 --> Output Class Initialized
INFO - 2016-03-11 06:53:43 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:43 --> Input Class Initialized
INFO - 2016-03-11 06:53:43 --> Language Class Initialized
INFO - 2016-03-11 06:53:43 --> Loader Class Initialized
INFO - 2016-03-11 06:53:43 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:43 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:43 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:43 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:43 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:44 --> Controller Class Initialized
INFO - 2016-03-11 06:53:44 --> Model Class Initialized
INFO - 2016-03-11 06:53:44 --> Model Class Initialized
INFO - 2016-03-11 06:53:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:44 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:44 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:44 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:53:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:44 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:44 --> Total execution time: 1.1278
INFO - 2016-03-11 06:53:46 --> Config Class Initialized
INFO - 2016-03-11 06:53:46 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:46 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:46 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:46 --> URI Class Initialized
INFO - 2016-03-11 06:53:46 --> Router Class Initialized
INFO - 2016-03-11 06:53:46 --> Output Class Initialized
INFO - 2016-03-11 06:53:46 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:46 --> Input Class Initialized
INFO - 2016-03-11 06:53:46 --> Language Class Initialized
INFO - 2016-03-11 06:53:46 --> Loader Class Initialized
INFO - 2016-03-11 06:53:46 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:46 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:46 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:46 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:46 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:47 --> Controller Class Initialized
INFO - 2016-03-11 06:53:47 --> Model Class Initialized
INFO - 2016-03-11 06:53:47 --> Model Class Initialized
INFO - 2016-03-11 06:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:47 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:47 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:47 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:47 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:47 --> Total execution time: 1.1928
INFO - 2016-03-11 06:53:50 --> Config Class Initialized
INFO - 2016-03-11 06:53:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:50 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:50 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:50 --> URI Class Initialized
INFO - 2016-03-11 06:53:50 --> Router Class Initialized
INFO - 2016-03-11 06:53:50 --> Output Class Initialized
INFO - 2016-03-11 06:53:50 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:50 --> Input Class Initialized
INFO - 2016-03-11 06:53:50 --> Language Class Initialized
INFO - 2016-03-11 06:53:50 --> Loader Class Initialized
INFO - 2016-03-11 06:53:50 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:50 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:50 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:50 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:50 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:51 --> Controller Class Initialized
INFO - 2016-03-11 06:53:51 --> Model Class Initialized
INFO - 2016-03-11 06:53:51 --> Model Class Initialized
INFO - 2016-03-11 06:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:51 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:51 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:51 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:51 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:51 --> Total execution time: 1.1647
INFO - 2016-03-11 06:53:53 --> Config Class Initialized
INFO - 2016-03-11 06:53:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:53 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:53 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:53 --> URI Class Initialized
INFO - 2016-03-11 06:53:53 --> Router Class Initialized
INFO - 2016-03-11 06:53:53 --> Output Class Initialized
INFO - 2016-03-11 06:53:53 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:53 --> Input Class Initialized
INFO - 2016-03-11 06:53:53 --> Language Class Initialized
INFO - 2016-03-11 06:53:53 --> Loader Class Initialized
INFO - 2016-03-11 06:53:53 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:53 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:53 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:53 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:53 --> Database Driver Class Initialized
INFO - 2016-03-11 06:53:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:53:54 --> Controller Class Initialized
INFO - 2016-03-11 06:53:54 --> Model Class Initialized
INFO - 2016-03-11 06:53:54 --> Model Class Initialized
INFO - 2016-03-11 06:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:53:54 --> Pagination Class Initialized
INFO - 2016-03-11 06:53:54 --> Helper loaded: text_helper
INFO - 2016-03-11 06:53:54 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:53:54 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:54 --> Total execution time: 1.2191
INFO - 2016-03-11 06:53:59 --> Config Class Initialized
INFO - 2016-03-11 06:53:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:53:59 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:53:59 --> Utf8 Class Initialized
INFO - 2016-03-11 06:53:59 --> URI Class Initialized
INFO - 2016-03-11 06:53:59 --> Router Class Initialized
INFO - 2016-03-11 06:53:59 --> Output Class Initialized
INFO - 2016-03-11 06:53:59 --> Security Class Initialized
DEBUG - 2016-03-11 06:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:53:59 --> Input Class Initialized
INFO - 2016-03-11 06:53:59 --> Language Class Initialized
INFO - 2016-03-11 06:53:59 --> Loader Class Initialized
INFO - 2016-03-11 06:53:59 --> Helper loaded: url_helper
INFO - 2016-03-11 06:53:59 --> Helper loaded: file_helper
INFO - 2016-03-11 06:53:59 --> Helper loaded: date_helper
INFO - 2016-03-11 06:53:59 --> Helper loaded: form_helper
INFO - 2016-03-11 06:53:59 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:00 --> Controller Class Initialized
INFO - 2016-03-11 06:54:00 --> Model Class Initialized
INFO - 2016-03-11 06:54:00 --> Model Class Initialized
INFO - 2016-03-11 06:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:54:00 --> Pagination Class Initialized
INFO - 2016-03-11 06:54:00 --> Helper loaded: text_helper
INFO - 2016-03-11 06:54:00 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:54:00 --> Final output sent to browser
DEBUG - 2016-03-11 09:54:00 --> Total execution time: 1.1232
INFO - 2016-03-11 06:54:02 --> Config Class Initialized
INFO - 2016-03-11 06:54:02 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:54:02 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:54:02 --> Utf8 Class Initialized
INFO - 2016-03-11 06:54:02 --> URI Class Initialized
INFO - 2016-03-11 06:54:02 --> Router Class Initialized
INFO - 2016-03-11 06:54:02 --> Output Class Initialized
INFO - 2016-03-11 06:54:02 --> Security Class Initialized
DEBUG - 2016-03-11 06:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:54:02 --> Input Class Initialized
INFO - 2016-03-11 06:54:02 --> Language Class Initialized
INFO - 2016-03-11 06:54:02 --> Loader Class Initialized
INFO - 2016-03-11 06:54:02 --> Helper loaded: url_helper
INFO - 2016-03-11 06:54:02 --> Helper loaded: file_helper
INFO - 2016-03-11 06:54:02 --> Helper loaded: date_helper
INFO - 2016-03-11 06:54:02 --> Helper loaded: form_helper
INFO - 2016-03-11 06:54:02 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:03 --> Controller Class Initialized
INFO - 2016-03-11 06:54:03 --> Model Class Initialized
INFO - 2016-03-11 06:54:03 --> Model Class Initialized
INFO - 2016-03-11 06:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:54:03 --> Pagination Class Initialized
INFO - 2016-03-11 06:54:03 --> Helper loaded: text_helper
INFO - 2016-03-11 06:54:03 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:54:03 --> Final output sent to browser
DEBUG - 2016-03-11 09:54:03 --> Total execution time: 1.1313
INFO - 2016-03-11 06:54:05 --> Config Class Initialized
INFO - 2016-03-11 06:54:05 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:54:05 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:54:05 --> Utf8 Class Initialized
INFO - 2016-03-11 06:54:05 --> URI Class Initialized
INFO - 2016-03-11 06:54:05 --> Router Class Initialized
INFO - 2016-03-11 06:54:05 --> Output Class Initialized
INFO - 2016-03-11 06:54:05 --> Security Class Initialized
DEBUG - 2016-03-11 06:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:54:05 --> Input Class Initialized
INFO - 2016-03-11 06:54:05 --> Language Class Initialized
INFO - 2016-03-11 06:54:05 --> Loader Class Initialized
INFO - 2016-03-11 06:54:05 --> Helper loaded: url_helper
INFO - 2016-03-11 06:54:05 --> Helper loaded: file_helper
INFO - 2016-03-11 06:54:05 --> Helper loaded: date_helper
INFO - 2016-03-11 06:54:05 --> Helper loaded: form_helper
INFO - 2016-03-11 06:54:05 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:06 --> Controller Class Initialized
INFO - 2016-03-11 06:54:06 --> Model Class Initialized
INFO - 2016-03-11 06:54:06 --> Model Class Initialized
INFO - 2016-03-11 06:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:54:06 --> Pagination Class Initialized
INFO - 2016-03-11 06:54:06 --> Helper loaded: text_helper
INFO - 2016-03-11 06:54:06 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:54:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:54:06 --> Final output sent to browser
DEBUG - 2016-03-11 09:54:06 --> Total execution time: 1.1621
INFO - 2016-03-11 06:54:12 --> Config Class Initialized
INFO - 2016-03-11 06:54:12 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:54:12 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:54:12 --> Utf8 Class Initialized
INFO - 2016-03-11 06:54:12 --> URI Class Initialized
INFO - 2016-03-11 06:54:12 --> Router Class Initialized
INFO - 2016-03-11 06:54:12 --> Output Class Initialized
INFO - 2016-03-11 06:54:12 --> Security Class Initialized
DEBUG - 2016-03-11 06:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:54:12 --> Input Class Initialized
INFO - 2016-03-11 06:54:12 --> Language Class Initialized
INFO - 2016-03-11 06:54:12 --> Loader Class Initialized
INFO - 2016-03-11 06:54:12 --> Helper loaded: url_helper
INFO - 2016-03-11 06:54:12 --> Helper loaded: file_helper
INFO - 2016-03-11 06:54:12 --> Helper loaded: date_helper
INFO - 2016-03-11 06:54:12 --> Helper loaded: form_helper
INFO - 2016-03-11 06:54:12 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:13 --> Controller Class Initialized
INFO - 2016-03-11 06:54:13 --> Model Class Initialized
INFO - 2016-03-11 06:54:13 --> Model Class Initialized
INFO - 2016-03-11 06:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:54:13 --> Pagination Class Initialized
INFO - 2016-03-11 06:54:13 --> Helper loaded: text_helper
INFO - 2016-03-11 06:54:13 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:54:13 --> Final output sent to browser
DEBUG - 2016-03-11 09:54:13 --> Total execution time: 1.1388
INFO - 2016-03-11 06:54:42 --> Config Class Initialized
INFO - 2016-03-11 06:54:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:54:42 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:54:42 --> Utf8 Class Initialized
INFO - 2016-03-11 06:54:42 --> URI Class Initialized
INFO - 2016-03-11 06:54:42 --> Router Class Initialized
INFO - 2016-03-11 06:54:42 --> Output Class Initialized
INFO - 2016-03-11 06:54:42 --> Security Class Initialized
DEBUG - 2016-03-11 06:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:54:42 --> Input Class Initialized
INFO - 2016-03-11 06:54:42 --> Language Class Initialized
INFO - 2016-03-11 06:54:42 --> Loader Class Initialized
INFO - 2016-03-11 06:54:42 --> Helper loaded: url_helper
INFO - 2016-03-11 06:54:42 --> Helper loaded: file_helper
INFO - 2016-03-11 06:54:42 --> Helper loaded: date_helper
INFO - 2016-03-11 06:54:42 --> Helper loaded: form_helper
INFO - 2016-03-11 06:54:42 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:44 --> Controller Class Initialized
INFO - 2016-03-11 06:54:44 --> Model Class Initialized
INFO - 2016-03-11 06:54:44 --> Model Class Initialized
ERROR - 2016-03-11 06:54:44 --> Severity: Parsing Error --> syntax error, unexpected 'protected' (T_PROTECTED) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Pagination.php 668
INFO - 2016-03-11 06:54:53 --> Config Class Initialized
INFO - 2016-03-11 06:54:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:54:53 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:54:53 --> Utf8 Class Initialized
INFO - 2016-03-11 06:54:53 --> URI Class Initialized
INFO - 2016-03-11 06:54:53 --> Router Class Initialized
INFO - 2016-03-11 06:54:53 --> Output Class Initialized
INFO - 2016-03-11 06:54:53 --> Security Class Initialized
DEBUG - 2016-03-11 06:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:54:53 --> Input Class Initialized
INFO - 2016-03-11 06:54:53 --> Language Class Initialized
INFO - 2016-03-11 06:54:53 --> Loader Class Initialized
INFO - 2016-03-11 06:54:54 --> Helper loaded: url_helper
INFO - 2016-03-11 06:54:54 --> Helper loaded: file_helper
INFO - 2016-03-11 06:54:54 --> Helper loaded: date_helper
INFO - 2016-03-11 06:54:54 --> Helper loaded: form_helper
INFO - 2016-03-11 06:54:54 --> Database Driver Class Initialized
INFO - 2016-03-11 06:54:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:54:55 --> Controller Class Initialized
INFO - 2016-03-11 06:54:55 --> Model Class Initialized
INFO - 2016-03-11 06:54:55 --> Model Class Initialized
ERROR - 2016-03-11 06:54:55 --> Severity: Parsing Error --> syntax error, unexpected 'protected' (T_PROTECTED) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Pagination.php 668
INFO - 2016-03-11 06:55:41 --> Config Class Initialized
INFO - 2016-03-11 06:55:41 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:55:41 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:55:41 --> Utf8 Class Initialized
INFO - 2016-03-11 06:55:41 --> URI Class Initialized
DEBUG - 2016-03-11 06:55:41 --> No URI present. Default controller set.
INFO - 2016-03-11 06:55:41 --> Router Class Initialized
INFO - 2016-03-11 06:55:41 --> Output Class Initialized
INFO - 2016-03-11 06:55:41 --> Security Class Initialized
DEBUG - 2016-03-11 06:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:55:41 --> Input Class Initialized
INFO - 2016-03-11 06:55:41 --> Language Class Initialized
INFO - 2016-03-11 06:55:41 --> Loader Class Initialized
INFO - 2016-03-11 06:55:41 --> Helper loaded: url_helper
INFO - 2016-03-11 06:55:41 --> Helper loaded: file_helper
INFO - 2016-03-11 06:55:41 --> Helper loaded: date_helper
INFO - 2016-03-11 06:55:41 --> Helper loaded: form_helper
INFO - 2016-03-11 06:55:41 --> Database Driver Class Initialized
INFO - 2016-03-11 06:55:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:55:42 --> Controller Class Initialized
INFO - 2016-03-11 06:55:42 --> Model Class Initialized
INFO - 2016-03-11 06:55:42 --> Model Class Initialized
INFO - 2016-03-11 06:55:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:55:42 --> Pagination Class Initialized
INFO - 2016-03-11 06:55:43 --> Helper loaded: text_helper
INFO - 2016-03-11 06:55:43 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:55:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:55:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:55:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 09:55:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:55:43 --> Final output sent to browser
DEBUG - 2016-03-11 09:55:43 --> Total execution time: 1.1227
INFO - 2016-03-11 06:55:46 --> Config Class Initialized
INFO - 2016-03-11 06:55:46 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:55:46 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:55:46 --> Utf8 Class Initialized
INFO - 2016-03-11 06:55:46 --> URI Class Initialized
INFO - 2016-03-11 06:55:46 --> Router Class Initialized
INFO - 2016-03-11 06:55:46 --> Output Class Initialized
INFO - 2016-03-11 06:55:46 --> Security Class Initialized
DEBUG - 2016-03-11 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:55:46 --> Input Class Initialized
INFO - 2016-03-11 06:55:46 --> Language Class Initialized
INFO - 2016-03-11 06:55:46 --> Loader Class Initialized
INFO - 2016-03-11 06:55:46 --> Helper loaded: url_helper
INFO - 2016-03-11 06:55:46 --> Helper loaded: file_helper
INFO - 2016-03-11 06:55:46 --> Helper loaded: date_helper
INFO - 2016-03-11 06:55:46 --> Helper loaded: form_helper
INFO - 2016-03-11 06:55:46 --> Database Driver Class Initialized
INFO - 2016-03-11 06:55:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:55:47 --> Controller Class Initialized
INFO - 2016-03-11 06:55:47 --> Model Class Initialized
INFO - 2016-03-11 06:55:47 --> Model Class Initialized
INFO - 2016-03-11 06:55:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:55:47 --> Pagination Class Initialized
INFO - 2016-03-11 06:55:47 --> Helper loaded: text_helper
INFO - 2016-03-11 06:55:47 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:55:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:55:47 --> Final output sent to browser
DEBUG - 2016-03-11 09:55:47 --> Total execution time: 1.1308
INFO - 2016-03-11 06:55:49 --> Config Class Initialized
INFO - 2016-03-11 06:55:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:55:49 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:55:49 --> Utf8 Class Initialized
INFO - 2016-03-11 06:55:49 --> URI Class Initialized
INFO - 2016-03-11 06:55:49 --> Router Class Initialized
INFO - 2016-03-11 06:55:49 --> Output Class Initialized
INFO - 2016-03-11 06:55:49 --> Security Class Initialized
DEBUG - 2016-03-11 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:55:49 --> Input Class Initialized
INFO - 2016-03-11 06:55:49 --> Language Class Initialized
INFO - 2016-03-11 06:55:49 --> Loader Class Initialized
INFO - 2016-03-11 06:55:49 --> Helper loaded: url_helper
INFO - 2016-03-11 06:55:49 --> Helper loaded: file_helper
INFO - 2016-03-11 06:55:49 --> Helper loaded: date_helper
INFO - 2016-03-11 06:55:49 --> Helper loaded: form_helper
INFO - 2016-03-11 06:55:49 --> Database Driver Class Initialized
INFO - 2016-03-11 06:55:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:55:50 --> Controller Class Initialized
INFO - 2016-03-11 06:55:50 --> Model Class Initialized
INFO - 2016-03-11 06:55:50 --> Model Class Initialized
INFO - 2016-03-11 06:55:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:55:50 --> Pagination Class Initialized
INFO - 2016-03-11 06:55:50 --> Helper loaded: text_helper
INFO - 2016-03-11 06:55:50 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:55:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:55:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:55:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:55:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:55:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:55:50 --> Final output sent to browser
DEBUG - 2016-03-11 09:55:50 --> Total execution time: 1.1165
INFO - 2016-03-11 06:55:51 --> Config Class Initialized
INFO - 2016-03-11 06:55:51 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:55:51 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:55:51 --> Utf8 Class Initialized
INFO - 2016-03-11 06:55:51 --> URI Class Initialized
INFO - 2016-03-11 06:55:51 --> Router Class Initialized
INFO - 2016-03-11 06:55:51 --> Output Class Initialized
INFO - 2016-03-11 06:55:51 --> Security Class Initialized
DEBUG - 2016-03-11 06:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:55:51 --> Input Class Initialized
INFO - 2016-03-11 06:55:51 --> Language Class Initialized
INFO - 2016-03-11 06:55:51 --> Loader Class Initialized
INFO - 2016-03-11 06:55:51 --> Helper loaded: url_helper
INFO - 2016-03-11 06:55:51 --> Helper loaded: file_helper
INFO - 2016-03-11 06:55:51 --> Helper loaded: date_helper
INFO - 2016-03-11 06:55:51 --> Helper loaded: form_helper
INFO - 2016-03-11 06:55:51 --> Database Driver Class Initialized
INFO - 2016-03-11 06:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:55:52 --> Controller Class Initialized
INFO - 2016-03-11 06:55:52 --> Model Class Initialized
INFO - 2016-03-11 06:55:52 --> Model Class Initialized
INFO - 2016-03-11 06:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:55:52 --> Pagination Class Initialized
INFO - 2016-03-11 06:55:52 --> Helper loaded: text_helper
INFO - 2016-03-11 06:55:52 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:55:52 --> Final output sent to browser
DEBUG - 2016-03-11 09:55:52 --> Total execution time: 1.1565
INFO - 2016-03-11 06:56:42 --> Config Class Initialized
INFO - 2016-03-11 06:56:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:56:42 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:56:42 --> Utf8 Class Initialized
INFO - 2016-03-11 06:56:42 --> URI Class Initialized
INFO - 2016-03-11 06:56:42 --> Router Class Initialized
INFO - 2016-03-11 06:56:42 --> Output Class Initialized
INFO - 2016-03-11 06:56:42 --> Security Class Initialized
DEBUG - 2016-03-11 06:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:56:42 --> Input Class Initialized
INFO - 2016-03-11 06:56:42 --> Language Class Initialized
INFO - 2016-03-11 06:56:42 --> Loader Class Initialized
INFO - 2016-03-11 06:56:42 --> Helper loaded: url_helper
INFO - 2016-03-11 06:56:42 --> Helper loaded: file_helper
INFO - 2016-03-11 06:56:42 --> Helper loaded: date_helper
INFO - 2016-03-11 06:56:42 --> Helper loaded: form_helper
INFO - 2016-03-11 06:56:42 --> Database Driver Class Initialized
INFO - 2016-03-11 06:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:56:43 --> Controller Class Initialized
INFO - 2016-03-11 06:56:43 --> Model Class Initialized
INFO - 2016-03-11 06:56:43 --> Model Class Initialized
INFO - 2016-03-11 06:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:56:43 --> Pagination Class Initialized
INFO - 2016-03-11 06:56:43 --> Helper loaded: text_helper
INFO - 2016-03-11 06:56:43 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:56:43 --> Final output sent to browser
DEBUG - 2016-03-11 09:56:43 --> Total execution time: 1.1556
INFO - 2016-03-11 06:57:18 --> Config Class Initialized
INFO - 2016-03-11 06:57:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:57:18 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:57:18 --> Utf8 Class Initialized
INFO - 2016-03-11 06:57:18 --> URI Class Initialized
INFO - 2016-03-11 06:57:18 --> Router Class Initialized
INFO - 2016-03-11 06:57:18 --> Output Class Initialized
INFO - 2016-03-11 06:57:18 --> Security Class Initialized
DEBUG - 2016-03-11 06:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:57:18 --> Input Class Initialized
INFO - 2016-03-11 06:57:18 --> Language Class Initialized
INFO - 2016-03-11 06:57:18 --> Loader Class Initialized
INFO - 2016-03-11 06:57:18 --> Helper loaded: url_helper
INFO - 2016-03-11 06:57:18 --> Helper loaded: file_helper
INFO - 2016-03-11 06:57:18 --> Helper loaded: date_helper
INFO - 2016-03-11 06:57:18 --> Helper loaded: form_helper
INFO - 2016-03-11 06:57:18 --> Database Driver Class Initialized
INFO - 2016-03-11 06:57:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:57:19 --> Controller Class Initialized
INFO - 2016-03-11 06:57:19 --> Model Class Initialized
INFO - 2016-03-11 06:57:19 --> Model Class Initialized
INFO - 2016-03-11 06:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:57:19 --> Pagination Class Initialized
INFO - 2016-03-11 06:57:19 --> Helper loaded: text_helper
INFO - 2016-03-11 06:57:19 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:57:19 --> Final output sent to browser
DEBUG - 2016-03-11 09:57:19 --> Total execution time: 1.1469
INFO - 2016-03-11 06:57:22 --> Config Class Initialized
INFO - 2016-03-11 06:57:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:57:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:57:22 --> Utf8 Class Initialized
INFO - 2016-03-11 06:57:22 --> URI Class Initialized
INFO - 2016-03-11 06:57:22 --> Router Class Initialized
INFO - 2016-03-11 06:57:22 --> Output Class Initialized
INFO - 2016-03-11 06:57:22 --> Security Class Initialized
DEBUG - 2016-03-11 06:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:57:22 --> Input Class Initialized
INFO - 2016-03-11 06:57:22 --> Language Class Initialized
INFO - 2016-03-11 06:57:22 --> Loader Class Initialized
INFO - 2016-03-11 06:57:22 --> Helper loaded: url_helper
INFO - 2016-03-11 06:57:22 --> Helper loaded: file_helper
INFO - 2016-03-11 06:57:22 --> Helper loaded: date_helper
INFO - 2016-03-11 06:57:22 --> Helper loaded: form_helper
INFO - 2016-03-11 06:57:22 --> Database Driver Class Initialized
INFO - 2016-03-11 06:57:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:57:23 --> Controller Class Initialized
INFO - 2016-03-11 06:57:23 --> Model Class Initialized
INFO - 2016-03-11 06:57:23 --> Model Class Initialized
INFO - 2016-03-11 06:57:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:57:23 --> Pagination Class Initialized
INFO - 2016-03-11 06:57:23 --> Helper loaded: text_helper
INFO - 2016-03-11 06:57:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:57:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:57:23 --> Final output sent to browser
DEBUG - 2016-03-11 09:57:23 --> Total execution time: 1.1468
INFO - 2016-03-11 06:57:25 --> Config Class Initialized
INFO - 2016-03-11 06:57:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:57:25 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:57:25 --> Utf8 Class Initialized
INFO - 2016-03-11 06:57:25 --> URI Class Initialized
INFO - 2016-03-11 06:57:25 --> Router Class Initialized
INFO - 2016-03-11 06:57:25 --> Output Class Initialized
INFO - 2016-03-11 06:57:25 --> Security Class Initialized
DEBUG - 2016-03-11 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:57:25 --> Input Class Initialized
INFO - 2016-03-11 06:57:25 --> Language Class Initialized
INFO - 2016-03-11 06:57:25 --> Loader Class Initialized
INFO - 2016-03-11 06:57:25 --> Helper loaded: url_helper
INFO - 2016-03-11 06:57:25 --> Helper loaded: file_helper
INFO - 2016-03-11 06:57:25 --> Helper loaded: date_helper
INFO - 2016-03-11 06:57:25 --> Helper loaded: form_helper
INFO - 2016-03-11 06:57:25 --> Database Driver Class Initialized
INFO - 2016-03-11 06:57:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:57:26 --> Controller Class Initialized
INFO - 2016-03-11 06:57:26 --> Model Class Initialized
INFO - 2016-03-11 06:57:26 --> Model Class Initialized
INFO - 2016-03-11 06:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:57:26 --> Pagination Class Initialized
INFO - 2016-03-11 06:57:26 --> Helper loaded: text_helper
INFO - 2016-03-11 06:57:26 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:57:26 --> Final output sent to browser
DEBUG - 2016-03-11 09:57:26 --> Total execution time: 1.2045
INFO - 2016-03-11 06:57:33 --> Config Class Initialized
INFO - 2016-03-11 06:57:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:57:33 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:57:33 --> Utf8 Class Initialized
INFO - 2016-03-11 06:57:33 --> URI Class Initialized
INFO - 2016-03-11 06:57:33 --> Router Class Initialized
INFO - 2016-03-11 06:57:33 --> Output Class Initialized
INFO - 2016-03-11 06:57:33 --> Security Class Initialized
DEBUG - 2016-03-11 06:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:57:33 --> Input Class Initialized
INFO - 2016-03-11 06:57:33 --> Language Class Initialized
INFO - 2016-03-11 06:57:33 --> Loader Class Initialized
INFO - 2016-03-11 06:57:33 --> Helper loaded: url_helper
INFO - 2016-03-11 06:57:33 --> Helper loaded: file_helper
INFO - 2016-03-11 06:57:33 --> Helper loaded: date_helper
INFO - 2016-03-11 06:57:33 --> Helper loaded: form_helper
INFO - 2016-03-11 06:57:33 --> Database Driver Class Initialized
INFO - 2016-03-11 06:57:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:57:34 --> Controller Class Initialized
INFO - 2016-03-11 06:57:34 --> Model Class Initialized
INFO - 2016-03-11 06:57:34 --> Model Class Initialized
INFO - 2016-03-11 06:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:57:34 --> Pagination Class Initialized
INFO - 2016-03-11 06:57:34 --> Helper loaded: text_helper
INFO - 2016-03-11 06:57:34 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:57:34 --> Final output sent to browser
DEBUG - 2016-03-11 09:57:34 --> Total execution time: 1.2738
INFO - 2016-03-11 06:59:07 --> Config Class Initialized
INFO - 2016-03-11 06:59:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:59:07 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:59:07 --> Utf8 Class Initialized
INFO - 2016-03-11 06:59:07 --> URI Class Initialized
INFO - 2016-03-11 06:59:07 --> Router Class Initialized
INFO - 2016-03-11 06:59:07 --> Output Class Initialized
INFO - 2016-03-11 06:59:07 --> Security Class Initialized
DEBUG - 2016-03-11 06:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:59:07 --> Input Class Initialized
INFO - 2016-03-11 06:59:07 --> Language Class Initialized
INFO - 2016-03-11 06:59:07 --> Loader Class Initialized
INFO - 2016-03-11 06:59:07 --> Helper loaded: url_helper
INFO - 2016-03-11 06:59:07 --> Helper loaded: file_helper
INFO - 2016-03-11 06:59:07 --> Helper loaded: date_helper
INFO - 2016-03-11 06:59:07 --> Helper loaded: form_helper
INFO - 2016-03-11 06:59:07 --> Database Driver Class Initialized
INFO - 2016-03-11 06:59:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:59:08 --> Controller Class Initialized
INFO - 2016-03-11 06:59:08 --> Model Class Initialized
INFO - 2016-03-11 06:59:08 --> Model Class Initialized
INFO - 2016-03-11 06:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:59:08 --> Pagination Class Initialized
INFO - 2016-03-11 06:59:08 --> Helper loaded: text_helper
INFO - 2016-03-11 06:59:08 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:59:08 --> Final output sent to browser
DEBUG - 2016-03-11 09:59:08 --> Total execution time: 1.1655
INFO - 2016-03-11 06:59:10 --> Config Class Initialized
INFO - 2016-03-11 06:59:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:59:10 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:59:10 --> Utf8 Class Initialized
INFO - 2016-03-11 06:59:10 --> URI Class Initialized
INFO - 2016-03-11 06:59:10 --> Router Class Initialized
INFO - 2016-03-11 06:59:10 --> Output Class Initialized
INFO - 2016-03-11 06:59:10 --> Security Class Initialized
DEBUG - 2016-03-11 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:59:10 --> Input Class Initialized
INFO - 2016-03-11 06:59:10 --> Language Class Initialized
INFO - 2016-03-11 06:59:10 --> Loader Class Initialized
INFO - 2016-03-11 06:59:10 --> Helper loaded: url_helper
INFO - 2016-03-11 06:59:10 --> Helper loaded: file_helper
INFO - 2016-03-11 06:59:10 --> Helper loaded: date_helper
INFO - 2016-03-11 06:59:10 --> Helper loaded: form_helper
INFO - 2016-03-11 06:59:10 --> Database Driver Class Initialized
INFO - 2016-03-11 06:59:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:59:11 --> Controller Class Initialized
INFO - 2016-03-11 06:59:11 --> Model Class Initialized
INFO - 2016-03-11 06:59:11 --> Model Class Initialized
INFO - 2016-03-11 06:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:59:11 --> Pagination Class Initialized
INFO - 2016-03-11 06:59:11 --> Helper loaded: text_helper
INFO - 2016-03-11 06:59:11 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 09:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 09:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:59:11 --> Final output sent to browser
DEBUG - 2016-03-11 09:59:11 --> Total execution time: 1.1466
INFO - 2016-03-11 06:59:16 --> Config Class Initialized
INFO - 2016-03-11 06:59:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 06:59:16 --> UTF-8 Support Enabled
INFO - 2016-03-11 06:59:16 --> Utf8 Class Initialized
INFO - 2016-03-11 06:59:16 --> URI Class Initialized
INFO - 2016-03-11 06:59:16 --> Router Class Initialized
INFO - 2016-03-11 06:59:16 --> Output Class Initialized
INFO - 2016-03-11 06:59:16 --> Security Class Initialized
DEBUG - 2016-03-11 06:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 06:59:16 --> Input Class Initialized
INFO - 2016-03-11 06:59:16 --> Language Class Initialized
INFO - 2016-03-11 06:59:16 --> Loader Class Initialized
INFO - 2016-03-11 06:59:16 --> Helper loaded: url_helper
INFO - 2016-03-11 06:59:16 --> Helper loaded: file_helper
INFO - 2016-03-11 06:59:16 --> Helper loaded: date_helper
INFO - 2016-03-11 06:59:16 --> Helper loaded: form_helper
INFO - 2016-03-11 06:59:16 --> Database Driver Class Initialized
INFO - 2016-03-11 06:59:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 06:59:17 --> Controller Class Initialized
INFO - 2016-03-11 06:59:17 --> Model Class Initialized
INFO - 2016-03-11 06:59:17 --> Model Class Initialized
INFO - 2016-03-11 06:59:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 06:59:17 --> Pagination Class Initialized
INFO - 2016-03-11 06:59:17 --> Helper loaded: text_helper
INFO - 2016-03-11 06:59:17 --> Helper loaded: cookie_helper
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 09:59:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 09:59:17 --> Final output sent to browser
DEBUG - 2016-03-11 09:59:17 --> Total execution time: 1.2147
INFO - 2016-03-11 07:01:12 --> Config Class Initialized
INFO - 2016-03-11 07:01:12 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:12 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:12 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:12 --> URI Class Initialized
INFO - 2016-03-11 07:01:12 --> Router Class Initialized
INFO - 2016-03-11 07:01:12 --> Output Class Initialized
INFO - 2016-03-11 07:01:12 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:12 --> Input Class Initialized
INFO - 2016-03-11 07:01:12 --> Language Class Initialized
INFO - 2016-03-11 07:01:12 --> Loader Class Initialized
INFO - 2016-03-11 07:01:12 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:12 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:12 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:12 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:12 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:14 --> Controller Class Initialized
INFO - 2016-03-11 07:01:14 --> Model Class Initialized
INFO - 2016-03-11 07:01:14 --> Model Class Initialized
INFO - 2016-03-11 07:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:14 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:14 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:14 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:14 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:14 --> Total execution time: 1.1363
INFO - 2016-03-11 07:01:15 --> Config Class Initialized
INFO - 2016-03-11 07:01:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:15 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:15 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:15 --> URI Class Initialized
INFO - 2016-03-11 07:01:15 --> Router Class Initialized
INFO - 2016-03-11 07:01:15 --> Output Class Initialized
INFO - 2016-03-11 07:01:15 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:15 --> Input Class Initialized
INFO - 2016-03-11 07:01:15 --> Language Class Initialized
INFO - 2016-03-11 07:01:15 --> Loader Class Initialized
INFO - 2016-03-11 07:01:15 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:15 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:15 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:15 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:15 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:16 --> Controller Class Initialized
INFO - 2016-03-11 07:01:16 --> Model Class Initialized
INFO - 2016-03-11 07:01:16 --> Model Class Initialized
INFO - 2016-03-11 07:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:16 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:16 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:16 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:16 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:16 --> Total execution time: 1.1980
INFO - 2016-03-11 07:01:17 --> Config Class Initialized
INFO - 2016-03-11 07:01:17 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:17 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:17 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:17 --> URI Class Initialized
INFO - 2016-03-11 07:01:17 --> Router Class Initialized
INFO - 2016-03-11 07:01:17 --> Output Class Initialized
INFO - 2016-03-11 07:01:17 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:17 --> Input Class Initialized
INFO - 2016-03-11 07:01:17 --> Language Class Initialized
INFO - 2016-03-11 07:01:17 --> Loader Class Initialized
INFO - 2016-03-11 07:01:17 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:17 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:17 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:17 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:17 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:18 --> Controller Class Initialized
INFO - 2016-03-11 07:01:18 --> Model Class Initialized
INFO - 2016-03-11 07:01:18 --> Model Class Initialized
INFO - 2016-03-11 07:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:18 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:18 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:18 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-11 10:01:18 --> Severity: Notice --> Undefined variable: page_index C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 155
ERROR - 2016-03-11 10:01:18 --> Severity: Notice --> Undefined variable: page_index C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 158
ERROR - 2016-03-11 10:01:18 --> Severity: Notice --> Undefined variable: page_index C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 166
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 10:01:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:18 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:18 --> Total execution time: 1.2458
INFO - 2016-03-11 07:01:22 --> Config Class Initialized
INFO - 2016-03-11 07:01:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:22 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:22 --> URI Class Initialized
INFO - 2016-03-11 07:01:22 --> Router Class Initialized
INFO - 2016-03-11 07:01:22 --> Output Class Initialized
INFO - 2016-03-11 07:01:22 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:22 --> Input Class Initialized
INFO - 2016-03-11 07:01:22 --> Language Class Initialized
INFO - 2016-03-11 07:01:22 --> Loader Class Initialized
INFO - 2016-03-11 07:01:22 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:22 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:22 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:22 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:22 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:23 --> Controller Class Initialized
INFO - 2016-03-11 07:01:23 --> Model Class Initialized
INFO - 2016-03-11 07:01:23 --> Model Class Initialized
INFO - 2016-03-11 07:01:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:23 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:23 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:01:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:23 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:23 --> Total execution time: 1.1468
INFO - 2016-03-11 07:01:26 --> Config Class Initialized
INFO - 2016-03-11 07:01:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:26 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:26 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:26 --> URI Class Initialized
INFO - 2016-03-11 07:01:26 --> Router Class Initialized
INFO - 2016-03-11 07:01:27 --> Output Class Initialized
INFO - 2016-03-11 07:01:27 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:27 --> Input Class Initialized
INFO - 2016-03-11 07:01:27 --> Language Class Initialized
INFO - 2016-03-11 07:01:27 --> Loader Class Initialized
INFO - 2016-03-11 07:01:27 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:27 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:27 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:27 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:27 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:28 --> Controller Class Initialized
INFO - 2016-03-11 07:01:28 --> Model Class Initialized
INFO - 2016-03-11 07:01:28 --> Model Class Initialized
INFO - 2016-03-11 07:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:28 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:28 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:28 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:28 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:28 --> Total execution time: 1.1295
INFO - 2016-03-11 07:01:31 --> Config Class Initialized
INFO - 2016-03-11 07:01:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:31 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:31 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:31 --> URI Class Initialized
INFO - 2016-03-11 07:01:31 --> Router Class Initialized
INFO - 2016-03-11 07:01:31 --> Output Class Initialized
INFO - 2016-03-11 07:01:31 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:31 --> Input Class Initialized
INFO - 2016-03-11 07:01:31 --> Language Class Initialized
INFO - 2016-03-11 07:01:31 --> Loader Class Initialized
INFO - 2016-03-11 07:01:31 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:31 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:31 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:31 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:31 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:32 --> Controller Class Initialized
INFO - 2016-03-11 07:01:32 --> Model Class Initialized
INFO - 2016-03-11 07:01:32 --> Model Class Initialized
INFO - 2016-03-11 07:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:32 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:32 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:32 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:01:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:32 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:32 --> Total execution time: 1.1425
INFO - 2016-03-11 07:01:34 --> Config Class Initialized
INFO - 2016-03-11 07:01:34 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:01:34 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:01:34 --> Utf8 Class Initialized
INFO - 2016-03-11 07:01:34 --> URI Class Initialized
INFO - 2016-03-11 07:01:34 --> Router Class Initialized
INFO - 2016-03-11 07:01:34 --> Output Class Initialized
INFO - 2016-03-11 07:01:34 --> Security Class Initialized
DEBUG - 2016-03-11 07:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:01:34 --> Input Class Initialized
INFO - 2016-03-11 07:01:34 --> Language Class Initialized
INFO - 2016-03-11 07:01:34 --> Loader Class Initialized
INFO - 2016-03-11 07:01:34 --> Helper loaded: url_helper
INFO - 2016-03-11 07:01:34 --> Helper loaded: file_helper
INFO - 2016-03-11 07:01:34 --> Helper loaded: date_helper
INFO - 2016-03-11 07:01:34 --> Helper loaded: form_helper
INFO - 2016-03-11 07:01:34 --> Database Driver Class Initialized
INFO - 2016-03-11 07:01:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:01:35 --> Controller Class Initialized
INFO - 2016-03-11 07:01:35 --> Model Class Initialized
INFO - 2016-03-11 07:01:35 --> Model Class Initialized
INFO - 2016-03-11 07:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:01:35 --> Pagination Class Initialized
INFO - 2016-03-11 07:01:35 --> Helper loaded: text_helper
INFO - 2016-03-11 07:01:35 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 10:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:01:35 --> Final output sent to browser
DEBUG - 2016-03-11 10:01:35 --> Total execution time: 1.1910
INFO - 2016-03-11 07:20:35 --> Config Class Initialized
INFO - 2016-03-11 07:20:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:20:35 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:20:35 --> Utf8 Class Initialized
INFO - 2016-03-11 07:20:35 --> URI Class Initialized
INFO - 2016-03-11 07:20:35 --> Router Class Initialized
INFO - 2016-03-11 07:20:35 --> Output Class Initialized
INFO - 2016-03-11 07:20:35 --> Security Class Initialized
DEBUG - 2016-03-11 07:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:20:35 --> Input Class Initialized
INFO - 2016-03-11 07:20:35 --> Language Class Initialized
INFO - 2016-03-11 07:20:35 --> Loader Class Initialized
INFO - 2016-03-11 07:20:35 --> Helper loaded: url_helper
INFO - 2016-03-11 07:20:35 --> Helper loaded: file_helper
INFO - 2016-03-11 07:20:35 --> Helper loaded: date_helper
INFO - 2016-03-11 07:20:35 --> Helper loaded: form_helper
INFO - 2016-03-11 07:20:35 --> Database Driver Class Initialized
INFO - 2016-03-11 07:20:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:20:36 --> Controller Class Initialized
INFO - 2016-03-11 07:20:36 --> Model Class Initialized
INFO - 2016-03-11 07:20:36 --> Model Class Initialized
INFO - 2016-03-11 07:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:20:36 --> Pagination Class Initialized
INFO - 2016-03-11 07:20:36 --> Helper loaded: text_helper
INFO - 2016-03-11 07:20:36 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:20:36 --> Final output sent to browser
DEBUG - 2016-03-11 10:20:36 --> Total execution time: 1.1685
INFO - 2016-03-11 07:20:38 --> Config Class Initialized
INFO - 2016-03-11 07:20:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:20:38 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:20:38 --> Utf8 Class Initialized
INFO - 2016-03-11 07:20:38 --> URI Class Initialized
INFO - 2016-03-11 07:20:38 --> Router Class Initialized
INFO - 2016-03-11 07:20:38 --> Output Class Initialized
INFO - 2016-03-11 07:20:38 --> Security Class Initialized
DEBUG - 2016-03-11 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:20:38 --> Input Class Initialized
INFO - 2016-03-11 07:20:38 --> Language Class Initialized
INFO - 2016-03-11 07:20:38 --> Loader Class Initialized
INFO - 2016-03-11 07:20:38 --> Helper loaded: url_helper
INFO - 2016-03-11 07:20:38 --> Helper loaded: file_helper
INFO - 2016-03-11 07:20:38 --> Helper loaded: date_helper
INFO - 2016-03-11 07:20:38 --> Helper loaded: form_helper
INFO - 2016-03-11 07:20:38 --> Database Driver Class Initialized
INFO - 2016-03-11 07:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:20:39 --> Controller Class Initialized
INFO - 2016-03-11 07:20:39 --> Model Class Initialized
INFO - 2016-03-11 07:20:39 --> Model Class Initialized
INFO - 2016-03-11 07:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:20:39 --> Pagination Class Initialized
INFO - 2016-03-11 07:20:39 --> Helper loaded: text_helper
INFO - 2016-03-11 07:20:39 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:20:39 --> Final output sent to browser
DEBUG - 2016-03-11 10:20:39 --> Total execution time: 1.1775
INFO - 2016-03-11 07:20:41 --> Config Class Initialized
INFO - 2016-03-11 07:20:41 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:20:41 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:20:41 --> Utf8 Class Initialized
INFO - 2016-03-11 07:20:41 --> URI Class Initialized
INFO - 2016-03-11 07:20:41 --> Router Class Initialized
INFO - 2016-03-11 07:20:41 --> Output Class Initialized
INFO - 2016-03-11 07:20:41 --> Security Class Initialized
DEBUG - 2016-03-11 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:20:41 --> Input Class Initialized
INFO - 2016-03-11 07:20:41 --> Language Class Initialized
INFO - 2016-03-11 07:20:41 --> Loader Class Initialized
INFO - 2016-03-11 07:20:41 --> Helper loaded: url_helper
INFO - 2016-03-11 07:20:41 --> Helper loaded: file_helper
INFO - 2016-03-11 07:20:41 --> Helper loaded: date_helper
INFO - 2016-03-11 07:20:41 --> Helper loaded: form_helper
INFO - 2016-03-11 07:20:41 --> Database Driver Class Initialized
INFO - 2016-03-11 07:20:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:20:42 --> Controller Class Initialized
INFO - 2016-03-11 07:20:42 --> Model Class Initialized
INFO - 2016-03-11 07:20:42 --> Model Class Initialized
INFO - 2016-03-11 07:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:20:42 --> Pagination Class Initialized
INFO - 2016-03-11 07:20:42 --> Helper loaded: text_helper
INFO - 2016-03-11 07:20:42 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 10:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:20:42 --> Final output sent to browser
DEBUG - 2016-03-11 10:20:42 --> Total execution time: 1.1525
INFO - 2016-03-11 07:20:48 --> Config Class Initialized
INFO - 2016-03-11 07:20:48 --> Hooks Class Initialized
DEBUG - 2016-03-11 07:20:48 --> UTF-8 Support Enabled
INFO - 2016-03-11 07:20:48 --> Utf8 Class Initialized
INFO - 2016-03-11 07:20:48 --> URI Class Initialized
INFO - 2016-03-11 07:20:48 --> Router Class Initialized
INFO - 2016-03-11 07:20:48 --> Output Class Initialized
INFO - 2016-03-11 07:20:48 --> Security Class Initialized
DEBUG - 2016-03-11 07:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 07:20:48 --> Input Class Initialized
INFO - 2016-03-11 07:20:48 --> Language Class Initialized
INFO - 2016-03-11 07:20:48 --> Loader Class Initialized
INFO - 2016-03-11 07:20:48 --> Helper loaded: url_helper
INFO - 2016-03-11 07:20:48 --> Helper loaded: file_helper
INFO - 2016-03-11 07:20:48 --> Helper loaded: date_helper
INFO - 2016-03-11 07:20:48 --> Helper loaded: form_helper
INFO - 2016-03-11 07:20:48 --> Database Driver Class Initialized
INFO - 2016-03-11 07:20:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 07:20:49 --> Controller Class Initialized
INFO - 2016-03-11 07:20:49 --> Model Class Initialized
INFO - 2016-03-11 07:20:49 --> Model Class Initialized
INFO - 2016-03-11 07:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 07:20:49 --> Pagination Class Initialized
INFO - 2016-03-11 07:20:49 --> Helper loaded: text_helper
INFO - 2016-03-11 07:20:49 --> Helper loaded: cookie_helper
INFO - 2016-03-11 10:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 10:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 10:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 10:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 10:20:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 10:20:49 --> Final output sent to browser
DEBUG - 2016-03-11 10:20:49 --> Total execution time: 1.1591
INFO - 2016-03-11 08:27:07 --> Config Class Initialized
INFO - 2016-03-11 08:27:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:27:07 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:27:07 --> Utf8 Class Initialized
INFO - 2016-03-11 08:27:07 --> URI Class Initialized
DEBUG - 2016-03-11 08:27:07 --> No URI present. Default controller set.
INFO - 2016-03-11 08:27:07 --> Router Class Initialized
INFO - 2016-03-11 08:27:07 --> Output Class Initialized
INFO - 2016-03-11 08:27:07 --> Security Class Initialized
DEBUG - 2016-03-11 08:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:27:07 --> Input Class Initialized
INFO - 2016-03-11 08:27:07 --> Language Class Initialized
INFO - 2016-03-11 08:27:07 --> Loader Class Initialized
INFO - 2016-03-11 08:27:07 --> Helper loaded: url_helper
INFO - 2016-03-11 08:27:07 --> Helper loaded: file_helper
INFO - 2016-03-11 08:27:07 --> Helper loaded: date_helper
INFO - 2016-03-11 08:27:07 --> Helper loaded: form_helper
INFO - 2016-03-11 08:27:07 --> Database Driver Class Initialized
INFO - 2016-03-11 08:27:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:27:08 --> Controller Class Initialized
INFO - 2016-03-11 08:27:08 --> Model Class Initialized
INFO - 2016-03-11 08:27:08 --> Model Class Initialized
INFO - 2016-03-11 08:27:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:27:08 --> Pagination Class Initialized
INFO - 2016-03-11 08:27:08 --> Helper loaded: text_helper
INFO - 2016-03-11 08:27:08 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 11:27:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:27:08 --> Final output sent to browser
DEBUG - 2016-03-11 11:27:08 --> Total execution time: 1.4546
INFO - 2016-03-11 08:27:11 --> Config Class Initialized
INFO - 2016-03-11 08:27:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:27:11 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:27:11 --> Utf8 Class Initialized
INFO - 2016-03-11 08:27:11 --> URI Class Initialized
INFO - 2016-03-11 08:27:11 --> Router Class Initialized
INFO - 2016-03-11 08:27:11 --> Output Class Initialized
INFO - 2016-03-11 08:27:11 --> Security Class Initialized
DEBUG - 2016-03-11 08:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:27:11 --> Input Class Initialized
INFO - 2016-03-11 08:27:11 --> Language Class Initialized
INFO - 2016-03-11 08:27:11 --> Loader Class Initialized
INFO - 2016-03-11 08:27:11 --> Helper loaded: url_helper
INFO - 2016-03-11 08:27:11 --> Helper loaded: file_helper
INFO - 2016-03-11 08:27:11 --> Helper loaded: date_helper
INFO - 2016-03-11 08:27:11 --> Helper loaded: form_helper
INFO - 2016-03-11 08:27:11 --> Database Driver Class Initialized
INFO - 2016-03-11 08:27:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:27:12 --> Controller Class Initialized
INFO - 2016-03-11 08:27:12 --> Model Class Initialized
INFO - 2016-03-11 08:27:12 --> Model Class Initialized
INFO - 2016-03-11 08:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:27:12 --> Pagination Class Initialized
INFO - 2016-03-11 08:27:12 --> Helper loaded: text_helper
INFO - 2016-03-11 08:27:12 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:27:12 --> Final output sent to browser
DEBUG - 2016-03-11 11:27:12 --> Total execution time: 1.1488
INFO - 2016-03-11 08:27:14 --> Config Class Initialized
INFO - 2016-03-11 08:27:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:27:14 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:27:14 --> Utf8 Class Initialized
INFO - 2016-03-11 08:27:14 --> URI Class Initialized
INFO - 2016-03-11 08:27:14 --> Router Class Initialized
INFO - 2016-03-11 08:27:14 --> Output Class Initialized
INFO - 2016-03-11 08:27:14 --> Security Class Initialized
DEBUG - 2016-03-11 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:27:14 --> Input Class Initialized
INFO - 2016-03-11 08:27:14 --> Language Class Initialized
INFO - 2016-03-11 08:27:14 --> Loader Class Initialized
INFO - 2016-03-11 08:27:14 --> Helper loaded: url_helper
INFO - 2016-03-11 08:27:14 --> Helper loaded: file_helper
INFO - 2016-03-11 08:27:14 --> Helper loaded: date_helper
INFO - 2016-03-11 08:27:14 --> Helper loaded: form_helper
INFO - 2016-03-11 08:27:14 --> Database Driver Class Initialized
INFO - 2016-03-11 08:27:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:27:15 --> Controller Class Initialized
INFO - 2016-03-11 08:27:15 --> Model Class Initialized
INFO - 2016-03-11 08:27:15 --> Model Class Initialized
INFO - 2016-03-11 08:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:27:15 --> Pagination Class Initialized
INFO - 2016-03-11 08:27:15 --> Helper loaded: text_helper
INFO - 2016-03-11 08:27:15 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:27:15 --> Final output sent to browser
DEBUG - 2016-03-11 11:27:15 --> Total execution time: 1.1875
INFO - 2016-03-11 08:27:18 --> Config Class Initialized
INFO - 2016-03-11 08:27:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:27:18 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:27:18 --> Utf8 Class Initialized
INFO - 2016-03-11 08:27:18 --> URI Class Initialized
INFO - 2016-03-11 08:27:18 --> Router Class Initialized
INFO - 2016-03-11 08:27:18 --> Output Class Initialized
INFO - 2016-03-11 08:27:18 --> Security Class Initialized
DEBUG - 2016-03-11 08:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:27:18 --> Input Class Initialized
INFO - 2016-03-11 08:27:18 --> Language Class Initialized
INFO - 2016-03-11 08:27:18 --> Loader Class Initialized
INFO - 2016-03-11 08:27:18 --> Helper loaded: url_helper
INFO - 2016-03-11 08:27:18 --> Helper loaded: file_helper
INFO - 2016-03-11 08:27:18 --> Helper loaded: date_helper
INFO - 2016-03-11 08:27:18 --> Helper loaded: form_helper
INFO - 2016-03-11 08:27:18 --> Database Driver Class Initialized
INFO - 2016-03-11 08:27:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:27:19 --> Controller Class Initialized
INFO - 2016-03-11 08:27:19 --> Model Class Initialized
INFO - 2016-03-11 08:27:19 --> Model Class Initialized
INFO - 2016-03-11 08:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:27:19 --> Pagination Class Initialized
INFO - 2016-03-11 08:27:19 --> Helper loaded: text_helper
INFO - 2016-03-11 08:27:19 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:27:19 --> Final output sent to browser
DEBUG - 2016-03-11 11:27:19 --> Total execution time: 1.2496
INFO - 2016-03-11 08:27:50 --> Config Class Initialized
INFO - 2016-03-11 08:27:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:27:50 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:27:50 --> Utf8 Class Initialized
INFO - 2016-03-11 08:27:50 --> URI Class Initialized
INFO - 2016-03-11 08:27:50 --> Router Class Initialized
INFO - 2016-03-11 08:27:50 --> Output Class Initialized
INFO - 2016-03-11 08:27:50 --> Security Class Initialized
DEBUG - 2016-03-11 08:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:27:50 --> Input Class Initialized
INFO - 2016-03-11 08:27:50 --> Language Class Initialized
INFO - 2016-03-11 08:27:50 --> Loader Class Initialized
INFO - 2016-03-11 08:27:50 --> Helper loaded: url_helper
INFO - 2016-03-11 08:27:50 --> Helper loaded: file_helper
INFO - 2016-03-11 08:27:50 --> Helper loaded: date_helper
INFO - 2016-03-11 08:27:51 --> Helper loaded: form_helper
INFO - 2016-03-11 08:27:51 --> Database Driver Class Initialized
INFO - 2016-03-11 08:27:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:27:52 --> Controller Class Initialized
INFO - 2016-03-11 08:27:52 --> Model Class Initialized
INFO - 2016-03-11 08:27:52 --> Model Class Initialized
INFO - 2016-03-11 08:27:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:27:52 --> Pagination Class Initialized
INFO - 2016-03-11 08:27:52 --> Helper loaded: text_helper
INFO - 2016-03-11 08:27:52 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:27:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:27:52 --> Final output sent to browser
DEBUG - 2016-03-11 11:27:52 --> Total execution time: 1.2545
INFO - 2016-03-11 08:30:09 --> Config Class Initialized
INFO - 2016-03-11 08:30:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:30:09 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:30:09 --> Utf8 Class Initialized
INFO - 2016-03-11 08:30:09 --> URI Class Initialized
INFO - 2016-03-11 08:30:09 --> Router Class Initialized
INFO - 2016-03-11 08:30:09 --> Output Class Initialized
INFO - 2016-03-11 08:30:09 --> Security Class Initialized
DEBUG - 2016-03-11 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:30:09 --> Input Class Initialized
INFO - 2016-03-11 08:30:09 --> Language Class Initialized
INFO - 2016-03-11 08:30:09 --> Loader Class Initialized
INFO - 2016-03-11 08:30:09 --> Helper loaded: url_helper
INFO - 2016-03-11 08:30:09 --> Helper loaded: file_helper
INFO - 2016-03-11 08:30:09 --> Helper loaded: date_helper
INFO - 2016-03-11 08:30:09 --> Helper loaded: form_helper
INFO - 2016-03-11 08:30:09 --> Database Driver Class Initialized
INFO - 2016-03-11 08:30:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:30:11 --> Controller Class Initialized
INFO - 2016-03-11 08:30:11 --> Model Class Initialized
INFO - 2016-03-11 08:30:11 --> Model Class Initialized
INFO - 2016-03-11 08:30:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:30:11 --> Pagination Class Initialized
INFO - 2016-03-11 08:30:11 --> Helper loaded: text_helper
INFO - 2016-03-11 08:30:11 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:30:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:30:11 --> Final output sent to browser
DEBUG - 2016-03-11 11:30:11 --> Total execution time: 1.2402
INFO - 2016-03-11 08:30:14 --> Config Class Initialized
INFO - 2016-03-11 08:30:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:30:14 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:30:14 --> Utf8 Class Initialized
INFO - 2016-03-11 08:30:14 --> URI Class Initialized
INFO - 2016-03-11 08:30:14 --> Router Class Initialized
INFO - 2016-03-11 08:30:14 --> Output Class Initialized
INFO - 2016-03-11 08:30:14 --> Security Class Initialized
DEBUG - 2016-03-11 08:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:30:14 --> Input Class Initialized
INFO - 2016-03-11 08:30:14 --> Language Class Initialized
INFO - 2016-03-11 08:30:14 --> Loader Class Initialized
INFO - 2016-03-11 08:30:14 --> Helper loaded: url_helper
INFO - 2016-03-11 08:30:14 --> Helper loaded: file_helper
INFO - 2016-03-11 08:30:14 --> Helper loaded: date_helper
INFO - 2016-03-11 08:30:14 --> Helper loaded: form_helper
INFO - 2016-03-11 08:30:14 --> Database Driver Class Initialized
INFO - 2016-03-11 08:30:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:30:15 --> Controller Class Initialized
INFO - 2016-03-11 08:30:15 --> Model Class Initialized
INFO - 2016-03-11 08:30:15 --> Model Class Initialized
INFO - 2016-03-11 08:30:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:30:15 --> Pagination Class Initialized
INFO - 2016-03-11 08:30:15 --> Helper loaded: text_helper
INFO - 2016-03-11 08:30:15 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:30:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:30:15 --> Final output sent to browser
DEBUG - 2016-03-11 11:30:15 --> Total execution time: 1.2147
INFO - 2016-03-11 08:33:12 --> Config Class Initialized
INFO - 2016-03-11 08:33:12 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:12 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:12 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:12 --> URI Class Initialized
INFO - 2016-03-11 08:33:12 --> Router Class Initialized
INFO - 2016-03-11 08:33:12 --> Output Class Initialized
INFO - 2016-03-11 08:33:12 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:12 --> Input Class Initialized
INFO - 2016-03-11 08:33:12 --> Language Class Initialized
INFO - 2016-03-11 08:33:12 --> Loader Class Initialized
INFO - 2016-03-11 08:33:12 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:12 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:12 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:12 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:12 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:13 --> Controller Class Initialized
INFO - 2016-03-11 08:33:13 --> Model Class Initialized
INFO - 2016-03-11 08:33:13 --> Model Class Initialized
INFO - 2016-03-11 08:33:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:13 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:13 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:13 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:33:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:14 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:14 --> Total execution time: 1.2356
INFO - 2016-03-11 08:33:15 --> Config Class Initialized
INFO - 2016-03-11 08:33:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:15 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:15 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:15 --> URI Class Initialized
INFO - 2016-03-11 08:33:15 --> Router Class Initialized
INFO - 2016-03-11 08:33:15 --> Output Class Initialized
INFO - 2016-03-11 08:33:15 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:15 --> Input Class Initialized
INFO - 2016-03-11 08:33:15 --> Language Class Initialized
INFO - 2016-03-11 08:33:15 --> Loader Class Initialized
INFO - 2016-03-11 08:33:15 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:15 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:15 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:15 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:15 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:16 --> Controller Class Initialized
INFO - 2016-03-11 08:33:16 --> Model Class Initialized
INFO - 2016-03-11 08:33:16 --> Model Class Initialized
INFO - 2016-03-11 08:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:16 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:16 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:16 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:16 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:16 --> Total execution time: 1.1521
INFO - 2016-03-11 08:33:18 --> Config Class Initialized
INFO - 2016-03-11 08:33:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:18 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:18 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:18 --> URI Class Initialized
INFO - 2016-03-11 08:33:18 --> Router Class Initialized
INFO - 2016-03-11 08:33:18 --> Output Class Initialized
INFO - 2016-03-11 08:33:18 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:18 --> Input Class Initialized
INFO - 2016-03-11 08:33:18 --> Language Class Initialized
INFO - 2016-03-11 08:33:18 --> Loader Class Initialized
INFO - 2016-03-11 08:33:18 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:18 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:18 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:18 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:18 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:19 --> Controller Class Initialized
INFO - 2016-03-11 08:33:19 --> Model Class Initialized
INFO - 2016-03-11 08:33:19 --> Model Class Initialized
INFO - 2016-03-11 08:33:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:19 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:19 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:19 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:33:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:19 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:19 --> Total execution time: 1.2019
INFO - 2016-03-11 08:33:28 --> Config Class Initialized
INFO - 2016-03-11 08:33:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:28 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:28 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:28 --> URI Class Initialized
INFO - 2016-03-11 08:33:28 --> Router Class Initialized
INFO - 2016-03-11 08:33:28 --> Output Class Initialized
INFO - 2016-03-11 08:33:28 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:28 --> Input Class Initialized
INFO - 2016-03-11 08:33:28 --> Language Class Initialized
INFO - 2016-03-11 08:33:28 --> Loader Class Initialized
INFO - 2016-03-11 08:33:28 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:28 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:28 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:28 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:28 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:29 --> Controller Class Initialized
INFO - 2016-03-11 08:33:29 --> Model Class Initialized
INFO - 2016-03-11 08:33:29 --> Model Class Initialized
INFO - 2016-03-11 08:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:29 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:29 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:29 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:29 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:29 --> Total execution time: 1.1890
INFO - 2016-03-11 08:33:39 --> Config Class Initialized
INFO - 2016-03-11 08:33:39 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:39 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:39 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:39 --> URI Class Initialized
INFO - 2016-03-11 08:33:39 --> Router Class Initialized
INFO - 2016-03-11 08:33:39 --> Output Class Initialized
INFO - 2016-03-11 08:33:39 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:39 --> Input Class Initialized
INFO - 2016-03-11 08:33:39 --> Language Class Initialized
INFO - 2016-03-11 08:33:39 --> Loader Class Initialized
INFO - 2016-03-11 08:33:39 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:39 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:39 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:39 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:39 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:40 --> Controller Class Initialized
INFO - 2016-03-11 08:33:40 --> Model Class Initialized
INFO - 2016-03-11 08:33:40 --> Model Class Initialized
INFO - 2016-03-11 08:33:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:40 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:40 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:40 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:33:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:40 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:40 --> Total execution time: 1.1481
INFO - 2016-03-11 08:33:41 --> Config Class Initialized
INFO - 2016-03-11 08:33:41 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:41 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:41 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:41 --> URI Class Initialized
INFO - 2016-03-11 08:33:41 --> Router Class Initialized
INFO - 2016-03-11 08:33:41 --> Output Class Initialized
INFO - 2016-03-11 08:33:41 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:41 --> Input Class Initialized
INFO - 2016-03-11 08:33:41 --> Language Class Initialized
INFO - 2016-03-11 08:33:41 --> Loader Class Initialized
INFO - 2016-03-11 08:33:41 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:41 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:41 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:41 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:41 --> Database Driver Class Initialized
INFO - 2016-03-11 08:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:33:42 --> Controller Class Initialized
INFO - 2016-03-11 08:33:42 --> Model Class Initialized
INFO - 2016-03-11 08:33:42 --> Model Class Initialized
INFO - 2016-03-11 08:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:33:42 --> Pagination Class Initialized
INFO - 2016-03-11 08:33:42 --> Helper loaded: text_helper
INFO - 2016-03-11 08:33:42 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:33:42 --> Final output sent to browser
DEBUG - 2016-03-11 11:33:42 --> Total execution time: 1.1951
INFO - 2016-03-11 08:33:59 --> Config Class Initialized
INFO - 2016-03-11 08:33:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:33:59 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:33:59 --> Utf8 Class Initialized
INFO - 2016-03-11 08:33:59 --> URI Class Initialized
INFO - 2016-03-11 08:33:59 --> Router Class Initialized
INFO - 2016-03-11 08:33:59 --> Output Class Initialized
INFO - 2016-03-11 08:33:59 --> Security Class Initialized
DEBUG - 2016-03-11 08:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:33:59 --> Input Class Initialized
INFO - 2016-03-11 08:33:59 --> Language Class Initialized
INFO - 2016-03-11 08:33:59 --> Loader Class Initialized
INFO - 2016-03-11 08:33:59 --> Helper loaded: url_helper
INFO - 2016-03-11 08:33:59 --> Helper loaded: file_helper
INFO - 2016-03-11 08:33:59 --> Helper loaded: date_helper
INFO - 2016-03-11 08:33:59 --> Helper loaded: form_helper
INFO - 2016-03-11 08:33:59 --> Database Driver Class Initialized
INFO - 2016-03-11 08:34:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:34:00 --> Controller Class Initialized
INFO - 2016-03-11 08:34:00 --> Model Class Initialized
INFO - 2016-03-11 08:34:00 --> Model Class Initialized
INFO - 2016-03-11 08:34:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:34:00 --> Pagination Class Initialized
INFO - 2016-03-11 08:34:00 --> Helper loaded: text_helper
INFO - 2016-03-11 08:34:00 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:34:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:34:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:34:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:34:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:34:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:34:00 --> Final output sent to browser
DEBUG - 2016-03-11 11:34:00 --> Total execution time: 1.1298
INFO - 2016-03-11 08:37:11 --> Config Class Initialized
INFO - 2016-03-11 08:37:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:37:11 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:37:11 --> Utf8 Class Initialized
INFO - 2016-03-11 08:37:11 --> URI Class Initialized
INFO - 2016-03-11 08:37:11 --> Router Class Initialized
INFO - 2016-03-11 08:37:11 --> Output Class Initialized
INFO - 2016-03-11 08:37:11 --> Security Class Initialized
DEBUG - 2016-03-11 08:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:37:11 --> Input Class Initialized
INFO - 2016-03-11 08:37:11 --> Language Class Initialized
INFO - 2016-03-11 08:37:11 --> Loader Class Initialized
INFO - 2016-03-11 08:37:11 --> Helper loaded: url_helper
INFO - 2016-03-11 08:37:11 --> Helper loaded: file_helper
INFO - 2016-03-11 08:37:11 --> Helper loaded: date_helper
INFO - 2016-03-11 08:37:11 --> Helper loaded: form_helper
INFO - 2016-03-11 08:37:11 --> Database Driver Class Initialized
INFO - 2016-03-11 08:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:37:12 --> Controller Class Initialized
INFO - 2016-03-11 08:37:12 --> Model Class Initialized
INFO - 2016-03-11 08:37:12 --> Model Class Initialized
INFO - 2016-03-11 08:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:37:12 --> Pagination Class Initialized
INFO - 2016-03-11 08:37:12 --> Helper loaded: text_helper
INFO - 2016-03-11 08:37:12 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:37:12 --> Final output sent to browser
DEBUG - 2016-03-11 11:37:12 --> Total execution time: 1.1511
INFO - 2016-03-11 08:47:58 --> Config Class Initialized
INFO - 2016-03-11 08:47:58 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:47:58 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:47:58 --> Utf8 Class Initialized
INFO - 2016-03-11 08:47:58 --> URI Class Initialized
DEBUG - 2016-03-11 08:47:58 --> No URI present. Default controller set.
INFO - 2016-03-11 08:47:58 --> Router Class Initialized
INFO - 2016-03-11 08:47:58 --> Output Class Initialized
INFO - 2016-03-11 08:47:58 --> Security Class Initialized
DEBUG - 2016-03-11 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:47:58 --> Input Class Initialized
INFO - 2016-03-11 08:47:58 --> Language Class Initialized
INFO - 2016-03-11 08:47:58 --> Loader Class Initialized
INFO - 2016-03-11 08:47:58 --> Helper loaded: url_helper
INFO - 2016-03-11 08:47:58 --> Helper loaded: file_helper
INFO - 2016-03-11 08:47:58 --> Helper loaded: date_helper
INFO - 2016-03-11 08:47:58 --> Helper loaded: form_helper
INFO - 2016-03-11 08:47:58 --> Database Driver Class Initialized
INFO - 2016-03-11 08:47:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:47:59 --> Controller Class Initialized
INFO - 2016-03-11 08:47:59 --> Model Class Initialized
INFO - 2016-03-11 08:47:59 --> Model Class Initialized
INFO - 2016-03-11 08:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:47:59 --> Pagination Class Initialized
INFO - 2016-03-11 08:47:59 --> Helper loaded: text_helper
INFO - 2016-03-11 08:47:59 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 11:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:47:59 --> Final output sent to browser
DEBUG - 2016-03-11 11:47:59 --> Total execution time: 1.1290
INFO - 2016-03-11 08:48:02 --> Config Class Initialized
INFO - 2016-03-11 08:48:02 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:48:02 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:48:02 --> Utf8 Class Initialized
INFO - 2016-03-11 08:48:02 --> URI Class Initialized
INFO - 2016-03-11 08:48:02 --> Router Class Initialized
INFO - 2016-03-11 08:48:02 --> Output Class Initialized
INFO - 2016-03-11 08:48:02 --> Security Class Initialized
DEBUG - 2016-03-11 08:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:48:02 --> Input Class Initialized
INFO - 2016-03-11 08:48:02 --> Language Class Initialized
INFO - 2016-03-11 08:48:02 --> Loader Class Initialized
INFO - 2016-03-11 08:48:02 --> Helper loaded: url_helper
INFO - 2016-03-11 08:48:02 --> Helper loaded: file_helper
INFO - 2016-03-11 08:48:02 --> Helper loaded: date_helper
INFO - 2016-03-11 08:48:02 --> Helper loaded: form_helper
INFO - 2016-03-11 08:48:02 --> Database Driver Class Initialized
INFO - 2016-03-11 08:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:48:03 --> Controller Class Initialized
INFO - 2016-03-11 08:48:03 --> Model Class Initialized
INFO - 2016-03-11 08:48:03 --> Model Class Initialized
INFO - 2016-03-11 08:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:48:03 --> Pagination Class Initialized
INFO - 2016-03-11 08:48:03 --> Helper loaded: text_helper
INFO - 2016-03-11 08:48:03 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:48:03 --> Final output sent to browser
DEBUG - 2016-03-11 11:48:03 --> Total execution time: 1.1429
INFO - 2016-03-11 08:48:05 --> Config Class Initialized
INFO - 2016-03-11 08:48:05 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:48:05 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:48:05 --> Utf8 Class Initialized
INFO - 2016-03-11 08:48:05 --> URI Class Initialized
INFO - 2016-03-11 08:48:05 --> Router Class Initialized
INFO - 2016-03-11 08:48:05 --> Output Class Initialized
INFO - 2016-03-11 08:48:05 --> Security Class Initialized
DEBUG - 2016-03-11 08:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:48:05 --> Input Class Initialized
INFO - 2016-03-11 08:48:05 --> Language Class Initialized
INFO - 2016-03-11 08:48:05 --> Loader Class Initialized
INFO - 2016-03-11 08:48:05 --> Helper loaded: url_helper
INFO - 2016-03-11 08:48:05 --> Helper loaded: file_helper
INFO - 2016-03-11 08:48:05 --> Helper loaded: date_helper
INFO - 2016-03-11 08:48:05 --> Helper loaded: form_helper
INFO - 2016-03-11 08:48:05 --> Database Driver Class Initialized
INFO - 2016-03-11 08:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:48:06 --> Controller Class Initialized
INFO - 2016-03-11 08:48:06 --> Model Class Initialized
INFO - 2016-03-11 08:48:06 --> Model Class Initialized
INFO - 2016-03-11 08:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:48:06 --> Pagination Class Initialized
INFO - 2016-03-11 08:48:06 --> Helper loaded: text_helper
INFO - 2016-03-11 08:48:06 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:48:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:48:06 --> Final output sent to browser
DEBUG - 2016-03-11 11:48:06 --> Total execution time: 1.1457
INFO - 2016-03-11 08:48:07 --> Config Class Initialized
INFO - 2016-03-11 08:48:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:48:07 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:48:07 --> Utf8 Class Initialized
INFO - 2016-03-11 08:48:07 --> URI Class Initialized
INFO - 2016-03-11 08:48:07 --> Router Class Initialized
INFO - 2016-03-11 08:48:07 --> Output Class Initialized
INFO - 2016-03-11 08:48:07 --> Security Class Initialized
DEBUG - 2016-03-11 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:48:07 --> Input Class Initialized
INFO - 2016-03-11 08:48:07 --> Language Class Initialized
INFO - 2016-03-11 08:48:07 --> Loader Class Initialized
INFO - 2016-03-11 08:48:07 --> Helper loaded: url_helper
INFO - 2016-03-11 08:48:07 --> Helper loaded: file_helper
INFO - 2016-03-11 08:48:07 --> Helper loaded: date_helper
INFO - 2016-03-11 08:48:07 --> Helper loaded: form_helper
INFO - 2016-03-11 08:48:07 --> Database Driver Class Initialized
INFO - 2016-03-11 08:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:48:08 --> Controller Class Initialized
INFO - 2016-03-11 08:48:08 --> Model Class Initialized
INFO - 2016-03-11 08:48:08 --> Model Class Initialized
INFO - 2016-03-11 08:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:48:08 --> Pagination Class Initialized
INFO - 2016-03-11 08:48:08 --> Helper loaded: text_helper
INFO - 2016-03-11 08:48:08 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:48:08 --> Final output sent to browser
DEBUG - 2016-03-11 11:48:08 --> Total execution time: 1.1927
INFO - 2016-03-11 08:49:26 --> Config Class Initialized
INFO - 2016-03-11 08:49:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:49:26 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:49:26 --> Utf8 Class Initialized
INFO - 2016-03-11 08:49:26 --> URI Class Initialized
INFO - 2016-03-11 08:49:26 --> Router Class Initialized
INFO - 2016-03-11 08:49:26 --> Output Class Initialized
INFO - 2016-03-11 08:49:26 --> Security Class Initialized
DEBUG - 2016-03-11 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:49:26 --> Input Class Initialized
INFO - 2016-03-11 08:49:26 --> Language Class Initialized
INFO - 2016-03-11 08:49:26 --> Loader Class Initialized
INFO - 2016-03-11 08:49:26 --> Helper loaded: url_helper
INFO - 2016-03-11 08:49:26 --> Helper loaded: file_helper
INFO - 2016-03-11 08:49:26 --> Helper loaded: date_helper
INFO - 2016-03-11 08:49:26 --> Helper loaded: form_helper
INFO - 2016-03-11 08:49:26 --> Database Driver Class Initialized
INFO - 2016-03-11 08:49:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:49:27 --> Controller Class Initialized
INFO - 2016-03-11 08:49:27 --> Model Class Initialized
INFO - 2016-03-11 08:49:27 --> Model Class Initialized
INFO - 2016-03-11 08:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:49:27 --> Pagination Class Initialized
INFO - 2016-03-11 08:49:27 --> Helper loaded: text_helper
INFO - 2016-03-11 08:49:27 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:49:27 --> Final output sent to browser
DEBUG - 2016-03-11 11:49:27 --> Total execution time: 1.2058
INFO - 2016-03-11 08:49:29 --> Config Class Initialized
INFO - 2016-03-11 08:49:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:49:29 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:49:29 --> Utf8 Class Initialized
INFO - 2016-03-11 08:49:29 --> URI Class Initialized
INFO - 2016-03-11 08:49:29 --> Router Class Initialized
INFO - 2016-03-11 08:49:29 --> Output Class Initialized
INFO - 2016-03-11 08:49:29 --> Security Class Initialized
DEBUG - 2016-03-11 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:49:29 --> Input Class Initialized
INFO - 2016-03-11 08:49:29 --> Language Class Initialized
INFO - 2016-03-11 08:49:29 --> Loader Class Initialized
INFO - 2016-03-11 08:49:29 --> Helper loaded: url_helper
INFO - 2016-03-11 08:49:29 --> Helper loaded: file_helper
INFO - 2016-03-11 08:49:29 --> Helper loaded: date_helper
INFO - 2016-03-11 08:49:29 --> Helper loaded: form_helper
INFO - 2016-03-11 08:49:29 --> Database Driver Class Initialized
INFO - 2016-03-11 08:49:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:49:30 --> Controller Class Initialized
INFO - 2016-03-11 08:49:30 --> Model Class Initialized
INFO - 2016-03-11 08:49:30 --> Model Class Initialized
INFO - 2016-03-11 08:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:49:30 --> Pagination Class Initialized
INFO - 2016-03-11 08:49:30 --> Helper loaded: text_helper
INFO - 2016-03-11 08:49:30 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 11:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 11:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:49:30 --> Final output sent to browser
DEBUG - 2016-03-11 11:49:30 --> Total execution time: 1.1278
INFO - 2016-03-11 08:49:32 --> Config Class Initialized
INFO - 2016-03-11 08:49:32 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:49:32 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:49:32 --> Utf8 Class Initialized
INFO - 2016-03-11 08:49:32 --> URI Class Initialized
INFO - 2016-03-11 08:49:32 --> Router Class Initialized
INFO - 2016-03-11 08:49:32 --> Output Class Initialized
INFO - 2016-03-11 08:49:32 --> Security Class Initialized
DEBUG - 2016-03-11 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:49:32 --> Input Class Initialized
INFO - 2016-03-11 08:49:32 --> Language Class Initialized
INFO - 2016-03-11 08:49:32 --> Loader Class Initialized
INFO - 2016-03-11 08:49:32 --> Helper loaded: url_helper
INFO - 2016-03-11 08:49:32 --> Helper loaded: file_helper
INFO - 2016-03-11 08:49:32 --> Helper loaded: date_helper
INFO - 2016-03-11 08:49:32 --> Helper loaded: form_helper
INFO - 2016-03-11 08:49:32 --> Database Driver Class Initialized
INFO - 2016-03-11 08:49:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:49:33 --> Controller Class Initialized
INFO - 2016-03-11 08:49:33 --> Model Class Initialized
INFO - 2016-03-11 08:49:33 --> Model Class Initialized
INFO - 2016-03-11 08:49:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:49:33 --> Pagination Class Initialized
INFO - 2016-03-11 08:49:33 --> Helper loaded: text_helper
INFO - 2016-03-11 08:49:33 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:49:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:49:33 --> Final output sent to browser
DEBUG - 2016-03-11 11:49:33 --> Total execution time: 1.2673
INFO - 2016-03-11 08:50:28 --> Config Class Initialized
INFO - 2016-03-11 08:50:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:50:28 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:50:28 --> Utf8 Class Initialized
INFO - 2016-03-11 08:50:28 --> URI Class Initialized
INFO - 2016-03-11 08:50:28 --> Router Class Initialized
INFO - 2016-03-11 08:50:28 --> Output Class Initialized
INFO - 2016-03-11 08:50:28 --> Security Class Initialized
DEBUG - 2016-03-11 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:50:28 --> Input Class Initialized
INFO - 2016-03-11 08:50:28 --> Language Class Initialized
INFO - 2016-03-11 08:50:28 --> Loader Class Initialized
INFO - 2016-03-11 08:50:28 --> Helper loaded: url_helper
INFO - 2016-03-11 08:50:28 --> Helper loaded: file_helper
INFO - 2016-03-11 08:50:28 --> Helper loaded: date_helper
INFO - 2016-03-11 08:50:28 --> Helper loaded: form_helper
INFO - 2016-03-11 08:50:28 --> Database Driver Class Initialized
INFO - 2016-03-11 08:50:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:50:29 --> Controller Class Initialized
INFO - 2016-03-11 08:50:29 --> Model Class Initialized
INFO - 2016-03-11 08:50:29 --> Model Class Initialized
INFO - 2016-03-11 08:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:50:29 --> Pagination Class Initialized
INFO - 2016-03-11 08:50:29 --> Helper loaded: text_helper
INFO - 2016-03-11 08:50:29 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:50:29 --> Final output sent to browser
DEBUG - 2016-03-11 11:50:29 --> Total execution time: 1.1883
INFO - 2016-03-11 08:51:02 --> Config Class Initialized
INFO - 2016-03-11 08:51:02 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:51:02 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:51:02 --> Utf8 Class Initialized
INFO - 2016-03-11 08:51:02 --> URI Class Initialized
INFO - 2016-03-11 08:51:02 --> Router Class Initialized
INFO - 2016-03-11 08:51:02 --> Output Class Initialized
INFO - 2016-03-11 08:51:02 --> Security Class Initialized
DEBUG - 2016-03-11 08:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:51:02 --> Input Class Initialized
INFO - 2016-03-11 08:51:02 --> Language Class Initialized
INFO - 2016-03-11 08:51:02 --> Loader Class Initialized
INFO - 2016-03-11 08:51:02 --> Helper loaded: url_helper
INFO - 2016-03-11 08:51:02 --> Helper loaded: file_helper
INFO - 2016-03-11 08:51:02 --> Helper loaded: date_helper
INFO - 2016-03-11 08:51:02 --> Helper loaded: form_helper
INFO - 2016-03-11 08:51:02 --> Database Driver Class Initialized
INFO - 2016-03-11 08:51:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:51:03 --> Controller Class Initialized
INFO - 2016-03-11 08:51:03 --> Model Class Initialized
INFO - 2016-03-11 08:51:03 --> Model Class Initialized
INFO - 2016-03-11 08:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:51:03 --> Pagination Class Initialized
INFO - 2016-03-11 08:51:03 --> Helper loaded: text_helper
INFO - 2016-03-11 08:51:03 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:51:03 --> Final output sent to browser
DEBUG - 2016-03-11 11:51:03 --> Total execution time: 1.1957
INFO - 2016-03-11 08:58:30 --> Config Class Initialized
INFO - 2016-03-11 08:58:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:58:30 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:58:30 --> Utf8 Class Initialized
INFO - 2016-03-11 08:58:30 --> URI Class Initialized
INFO - 2016-03-11 08:58:30 --> Router Class Initialized
INFO - 2016-03-11 08:58:30 --> Output Class Initialized
INFO - 2016-03-11 08:58:30 --> Security Class Initialized
DEBUG - 2016-03-11 08:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:58:30 --> Input Class Initialized
INFO - 2016-03-11 08:58:30 --> Language Class Initialized
INFO - 2016-03-11 08:58:30 --> Loader Class Initialized
INFO - 2016-03-11 08:58:30 --> Helper loaded: url_helper
INFO - 2016-03-11 08:58:30 --> Helper loaded: file_helper
INFO - 2016-03-11 08:58:30 --> Helper loaded: date_helper
INFO - 2016-03-11 08:58:30 --> Helper loaded: form_helper
INFO - 2016-03-11 08:58:30 --> Database Driver Class Initialized
INFO - 2016-03-11 08:58:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:58:31 --> Controller Class Initialized
INFO - 2016-03-11 08:58:31 --> Model Class Initialized
INFO - 2016-03-11 08:58:31 --> Model Class Initialized
INFO - 2016-03-11 08:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:58:31 --> Pagination Class Initialized
INFO - 2016-03-11 08:58:31 --> Helper loaded: text_helper
INFO - 2016-03-11 08:58:31 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:58:31 --> Final output sent to browser
DEBUG - 2016-03-11 11:58:31 --> Total execution time: 1.2161
INFO - 2016-03-11 08:58:56 --> Config Class Initialized
INFO - 2016-03-11 08:58:56 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:58:56 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:58:56 --> Utf8 Class Initialized
INFO - 2016-03-11 08:58:56 --> URI Class Initialized
INFO - 2016-03-11 08:58:56 --> Router Class Initialized
INFO - 2016-03-11 08:58:56 --> Output Class Initialized
INFO - 2016-03-11 08:58:56 --> Security Class Initialized
DEBUG - 2016-03-11 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:58:56 --> Input Class Initialized
INFO - 2016-03-11 08:58:56 --> Language Class Initialized
INFO - 2016-03-11 08:58:56 --> Loader Class Initialized
INFO - 2016-03-11 08:58:56 --> Helper loaded: url_helper
INFO - 2016-03-11 08:58:56 --> Helper loaded: file_helper
INFO - 2016-03-11 08:58:56 --> Helper loaded: date_helper
INFO - 2016-03-11 08:58:56 --> Helper loaded: form_helper
INFO - 2016-03-11 08:58:56 --> Database Driver Class Initialized
INFO - 2016-03-11 08:58:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:58:57 --> Controller Class Initialized
INFO - 2016-03-11 08:58:57 --> Model Class Initialized
INFO - 2016-03-11 08:58:57 --> Model Class Initialized
INFO - 2016-03-11 08:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:58:57 --> Pagination Class Initialized
INFO - 2016-03-11 08:58:57 --> Helper loaded: text_helper
INFO - 2016-03-11 08:58:57 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:58:57 --> Final output sent to browser
DEBUG - 2016-03-11 11:58:57 --> Total execution time: 1.2032
INFO - 2016-03-11 08:59:07 --> Config Class Initialized
INFO - 2016-03-11 08:59:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:59:07 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:59:07 --> Utf8 Class Initialized
INFO - 2016-03-11 08:59:07 --> URI Class Initialized
INFO - 2016-03-11 08:59:07 --> Router Class Initialized
INFO - 2016-03-11 08:59:07 --> Output Class Initialized
INFO - 2016-03-11 08:59:07 --> Security Class Initialized
DEBUG - 2016-03-11 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:59:07 --> Input Class Initialized
INFO - 2016-03-11 08:59:07 --> Language Class Initialized
INFO - 2016-03-11 08:59:07 --> Loader Class Initialized
INFO - 2016-03-11 08:59:07 --> Helper loaded: url_helper
INFO - 2016-03-11 08:59:07 --> Helper loaded: file_helper
INFO - 2016-03-11 08:59:07 --> Helper loaded: date_helper
INFO - 2016-03-11 08:59:07 --> Helper loaded: form_helper
INFO - 2016-03-11 08:59:07 --> Database Driver Class Initialized
INFO - 2016-03-11 08:59:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:59:08 --> Controller Class Initialized
INFO - 2016-03-11 08:59:08 --> Model Class Initialized
INFO - 2016-03-11 08:59:08 --> Model Class Initialized
INFO - 2016-03-11 08:59:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:59:08 --> Pagination Class Initialized
INFO - 2016-03-11 08:59:08 --> Helper loaded: text_helper
INFO - 2016-03-11 08:59:08 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:59:08 --> Final output sent to browser
DEBUG - 2016-03-11 11:59:08 --> Total execution time: 1.1757
INFO - 2016-03-11 08:59:20 --> Config Class Initialized
INFO - 2016-03-11 08:59:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:59:20 --> UTF-8 Support Enabled
INFO - 2016-03-11 08:59:20 --> Utf8 Class Initialized
INFO - 2016-03-11 08:59:20 --> URI Class Initialized
INFO - 2016-03-11 08:59:20 --> Router Class Initialized
INFO - 2016-03-11 08:59:20 --> Output Class Initialized
INFO - 2016-03-11 08:59:20 --> Security Class Initialized
DEBUG - 2016-03-11 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 08:59:20 --> Input Class Initialized
INFO - 2016-03-11 08:59:20 --> Language Class Initialized
INFO - 2016-03-11 08:59:20 --> Loader Class Initialized
INFO - 2016-03-11 08:59:20 --> Helper loaded: url_helper
INFO - 2016-03-11 08:59:20 --> Helper loaded: file_helper
INFO - 2016-03-11 08:59:20 --> Helper loaded: date_helper
INFO - 2016-03-11 08:59:20 --> Helper loaded: form_helper
INFO - 2016-03-11 08:59:20 --> Database Driver Class Initialized
INFO - 2016-03-11 08:59:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 08:59:21 --> Controller Class Initialized
INFO - 2016-03-11 08:59:21 --> Model Class Initialized
INFO - 2016-03-11 08:59:21 --> Model Class Initialized
INFO - 2016-03-11 08:59:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 08:59:21 --> Pagination Class Initialized
INFO - 2016-03-11 08:59:21 --> Helper loaded: text_helper
INFO - 2016-03-11 08:59:21 --> Helper loaded: cookie_helper
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 11:59:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 11:59:21 --> Final output sent to browser
DEBUG - 2016-03-11 11:59:21 --> Total execution time: 1.1623
INFO - 2016-03-11 09:00:10 --> Config Class Initialized
INFO - 2016-03-11 09:00:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:00:10 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:00:10 --> Utf8 Class Initialized
INFO - 2016-03-11 09:00:10 --> URI Class Initialized
INFO - 2016-03-11 09:00:10 --> Router Class Initialized
INFO - 2016-03-11 09:00:10 --> Output Class Initialized
INFO - 2016-03-11 09:00:10 --> Security Class Initialized
DEBUG - 2016-03-11 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:00:10 --> Input Class Initialized
INFO - 2016-03-11 09:00:10 --> Language Class Initialized
INFO - 2016-03-11 09:00:10 --> Loader Class Initialized
INFO - 2016-03-11 09:00:10 --> Helper loaded: url_helper
INFO - 2016-03-11 09:00:10 --> Helper loaded: file_helper
INFO - 2016-03-11 09:00:10 --> Helper loaded: date_helper
INFO - 2016-03-11 09:00:10 --> Helper loaded: form_helper
INFO - 2016-03-11 09:00:10 --> Database Driver Class Initialized
INFO - 2016-03-11 09:00:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:00:11 --> Controller Class Initialized
INFO - 2016-03-11 09:00:11 --> Model Class Initialized
INFO - 2016-03-11 09:00:11 --> Model Class Initialized
INFO - 2016-03-11 09:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:00:11 --> Pagination Class Initialized
INFO - 2016-03-11 09:00:11 --> Helper loaded: text_helper
INFO - 2016-03-11 09:00:11 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:00:11 --> Final output sent to browser
DEBUG - 2016-03-11 12:00:11 --> Total execution time: 1.1128
INFO - 2016-03-11 09:00:13 --> Config Class Initialized
INFO - 2016-03-11 09:00:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:00:13 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:00:13 --> Utf8 Class Initialized
INFO - 2016-03-11 09:00:13 --> URI Class Initialized
INFO - 2016-03-11 09:00:13 --> Router Class Initialized
INFO - 2016-03-11 09:00:13 --> Output Class Initialized
INFO - 2016-03-11 09:00:13 --> Security Class Initialized
DEBUG - 2016-03-11 09:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:00:13 --> Input Class Initialized
INFO - 2016-03-11 09:00:13 --> Language Class Initialized
INFO - 2016-03-11 09:00:13 --> Loader Class Initialized
INFO - 2016-03-11 09:00:13 --> Helper loaded: url_helper
INFO - 2016-03-11 09:00:13 --> Helper loaded: file_helper
INFO - 2016-03-11 09:00:13 --> Helper loaded: date_helper
INFO - 2016-03-11 09:00:13 --> Helper loaded: form_helper
INFO - 2016-03-11 09:00:13 --> Database Driver Class Initialized
INFO - 2016-03-11 09:00:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:00:14 --> Controller Class Initialized
INFO - 2016-03-11 09:00:14 --> Model Class Initialized
INFO - 2016-03-11 09:00:14 --> Model Class Initialized
INFO - 2016-03-11 09:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:00:14 --> Pagination Class Initialized
INFO - 2016-03-11 09:00:14 --> Helper loaded: text_helper
INFO - 2016-03-11 09:00:14 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:00:14 --> Final output sent to browser
DEBUG - 2016-03-11 12:00:14 --> Total execution time: 1.1219
INFO - 2016-03-11 09:00:16 --> Config Class Initialized
INFO - 2016-03-11 09:00:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:00:16 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:00:16 --> Utf8 Class Initialized
INFO - 2016-03-11 09:00:16 --> URI Class Initialized
INFO - 2016-03-11 09:00:16 --> Router Class Initialized
INFO - 2016-03-11 09:00:16 --> Output Class Initialized
INFO - 2016-03-11 09:00:16 --> Security Class Initialized
DEBUG - 2016-03-11 09:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:00:16 --> Input Class Initialized
INFO - 2016-03-11 09:00:16 --> Language Class Initialized
INFO - 2016-03-11 09:00:16 --> Loader Class Initialized
INFO - 2016-03-11 09:00:16 --> Helper loaded: url_helper
INFO - 2016-03-11 09:00:16 --> Helper loaded: file_helper
INFO - 2016-03-11 09:00:16 --> Helper loaded: date_helper
INFO - 2016-03-11 09:00:16 --> Helper loaded: form_helper
INFO - 2016-03-11 09:00:16 --> Database Driver Class Initialized
INFO - 2016-03-11 09:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:00:17 --> Controller Class Initialized
INFO - 2016-03-11 09:00:17 --> Model Class Initialized
INFO - 2016-03-11 09:00:17 --> Model Class Initialized
INFO - 2016-03-11 09:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:00:17 --> Pagination Class Initialized
INFO - 2016-03-11 09:00:17 --> Helper loaded: text_helper
INFO - 2016-03-11 09:00:17 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 12:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:00:17 --> Final output sent to browser
DEBUG - 2016-03-11 12:00:17 --> Total execution time: 1.1506
INFO - 2016-03-11 09:00:22 --> Config Class Initialized
INFO - 2016-03-11 09:00:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:00:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:00:22 --> Utf8 Class Initialized
INFO - 2016-03-11 09:00:22 --> URI Class Initialized
INFO - 2016-03-11 09:00:22 --> Router Class Initialized
INFO - 2016-03-11 09:00:22 --> Output Class Initialized
INFO - 2016-03-11 09:00:22 --> Security Class Initialized
DEBUG - 2016-03-11 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:00:22 --> Input Class Initialized
INFO - 2016-03-11 09:00:22 --> Language Class Initialized
INFO - 2016-03-11 09:00:22 --> Loader Class Initialized
INFO - 2016-03-11 09:00:22 --> Helper loaded: url_helper
INFO - 2016-03-11 09:00:22 --> Helper loaded: file_helper
INFO - 2016-03-11 09:00:22 --> Helper loaded: date_helper
INFO - 2016-03-11 09:00:22 --> Helper loaded: form_helper
INFO - 2016-03-11 09:00:22 --> Database Driver Class Initialized
INFO - 2016-03-11 09:00:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:00:23 --> Controller Class Initialized
INFO - 2016-03-11 09:00:23 --> Model Class Initialized
INFO - 2016-03-11 09:00:23 --> Model Class Initialized
INFO - 2016-03-11 09:00:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:00:23 --> Pagination Class Initialized
INFO - 2016-03-11 09:00:23 --> Helper loaded: text_helper
INFO - 2016-03-11 09:00:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 12:00:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:00:23 --> Final output sent to browser
DEBUG - 2016-03-11 12:00:23 --> Total execution time: 1.1517
INFO - 2016-03-11 09:12:26 --> Config Class Initialized
INFO - 2016-03-11 09:12:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:12:26 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:12:26 --> Utf8 Class Initialized
INFO - 2016-03-11 09:12:26 --> URI Class Initialized
INFO - 2016-03-11 09:12:26 --> Router Class Initialized
INFO - 2016-03-11 09:12:26 --> Output Class Initialized
INFO - 2016-03-11 09:12:26 --> Security Class Initialized
DEBUG - 2016-03-11 09:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:12:26 --> Input Class Initialized
INFO - 2016-03-11 09:12:26 --> Language Class Initialized
INFO - 2016-03-11 09:12:26 --> Loader Class Initialized
INFO - 2016-03-11 09:12:26 --> Helper loaded: url_helper
INFO - 2016-03-11 09:12:26 --> Helper loaded: file_helper
INFO - 2016-03-11 09:12:26 --> Helper loaded: date_helper
INFO - 2016-03-11 09:12:26 --> Helper loaded: form_helper
INFO - 2016-03-11 09:12:26 --> Database Driver Class Initialized
INFO - 2016-03-11 09:12:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:12:27 --> Controller Class Initialized
INFO - 2016-03-11 09:12:27 --> Model Class Initialized
INFO - 2016-03-11 09:12:27 --> Model Class Initialized
INFO - 2016-03-11 09:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:12:27 --> Pagination Class Initialized
INFO - 2016-03-11 09:12:27 --> Helper loaded: text_helper
INFO - 2016-03-11 09:12:27 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:12:27 --> Final output sent to browser
DEBUG - 2016-03-11 12:12:27 --> Total execution time: 1.1709
INFO - 2016-03-11 09:12:28 --> Config Class Initialized
INFO - 2016-03-11 09:12:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:12:28 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:12:28 --> Utf8 Class Initialized
INFO - 2016-03-11 09:12:28 --> URI Class Initialized
INFO - 2016-03-11 09:12:28 --> Router Class Initialized
INFO - 2016-03-11 09:12:28 --> Output Class Initialized
INFO - 2016-03-11 09:12:28 --> Security Class Initialized
DEBUG - 2016-03-11 09:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:12:28 --> Input Class Initialized
INFO - 2016-03-11 09:12:28 --> Language Class Initialized
INFO - 2016-03-11 09:12:28 --> Loader Class Initialized
INFO - 2016-03-11 09:12:28 --> Helper loaded: url_helper
INFO - 2016-03-11 09:12:28 --> Helper loaded: file_helper
INFO - 2016-03-11 09:12:28 --> Helper loaded: date_helper
INFO - 2016-03-11 09:12:28 --> Helper loaded: form_helper
INFO - 2016-03-11 09:12:28 --> Database Driver Class Initialized
INFO - 2016-03-11 09:12:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:12:29 --> Controller Class Initialized
INFO - 2016-03-11 09:12:29 --> Model Class Initialized
INFO - 2016-03-11 09:12:29 --> Model Class Initialized
INFO - 2016-03-11 09:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:12:29 --> Pagination Class Initialized
INFO - 2016-03-11 09:12:29 --> Helper loaded: text_helper
INFO - 2016-03-11 09:12:29 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:12:29 --> Final output sent to browser
DEBUG - 2016-03-11 12:12:29 --> Total execution time: 1.1468
INFO - 2016-03-11 09:12:31 --> Config Class Initialized
INFO - 2016-03-11 09:12:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:12:31 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:12:31 --> Utf8 Class Initialized
INFO - 2016-03-11 09:12:31 --> URI Class Initialized
INFO - 2016-03-11 09:12:31 --> Router Class Initialized
INFO - 2016-03-11 09:12:31 --> Output Class Initialized
INFO - 2016-03-11 09:12:31 --> Security Class Initialized
DEBUG - 2016-03-11 09:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:12:31 --> Input Class Initialized
INFO - 2016-03-11 09:12:31 --> Language Class Initialized
INFO - 2016-03-11 09:12:31 --> Loader Class Initialized
INFO - 2016-03-11 09:12:31 --> Helper loaded: url_helper
INFO - 2016-03-11 09:12:31 --> Helper loaded: file_helper
INFO - 2016-03-11 09:12:31 --> Helper loaded: date_helper
INFO - 2016-03-11 09:12:31 --> Helper loaded: form_helper
INFO - 2016-03-11 09:12:31 --> Database Driver Class Initialized
INFO - 2016-03-11 09:12:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:12:32 --> Controller Class Initialized
INFO - 2016-03-11 09:12:32 --> Model Class Initialized
INFO - 2016-03-11 09:12:32 --> Model Class Initialized
INFO - 2016-03-11 09:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:12:32 --> Pagination Class Initialized
INFO - 2016-03-11 09:12:32 --> Helper loaded: text_helper
INFO - 2016-03-11 09:12:32 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 12:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:12:32 --> Final output sent to browser
DEBUG - 2016-03-11 12:12:32 --> Total execution time: 1.2416
INFO - 2016-03-11 09:12:34 --> Config Class Initialized
INFO - 2016-03-11 09:12:34 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:12:34 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:12:34 --> Utf8 Class Initialized
INFO - 2016-03-11 09:12:34 --> URI Class Initialized
INFO - 2016-03-11 09:12:34 --> Router Class Initialized
INFO - 2016-03-11 09:12:34 --> Output Class Initialized
INFO - 2016-03-11 09:12:34 --> Security Class Initialized
DEBUG - 2016-03-11 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:12:34 --> Input Class Initialized
INFO - 2016-03-11 09:12:34 --> Language Class Initialized
INFO - 2016-03-11 09:12:34 --> Loader Class Initialized
INFO - 2016-03-11 09:12:34 --> Helper loaded: url_helper
INFO - 2016-03-11 09:12:34 --> Helper loaded: file_helper
INFO - 2016-03-11 09:12:34 --> Helper loaded: date_helper
INFO - 2016-03-11 09:12:34 --> Helper loaded: form_helper
INFO - 2016-03-11 09:12:34 --> Database Driver Class Initialized
INFO - 2016-03-11 09:12:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:12:35 --> Controller Class Initialized
INFO - 2016-03-11 09:12:35 --> Model Class Initialized
INFO - 2016-03-11 09:12:35 --> Model Class Initialized
INFO - 2016-03-11 09:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:12:35 --> Pagination Class Initialized
INFO - 2016-03-11 09:12:35 --> Helper loaded: text_helper
INFO - 2016-03-11 09:12:35 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:12:35 --> Final output sent to browser
DEBUG - 2016-03-11 12:12:35 --> Total execution time: 1.1481
INFO - 2016-03-11 09:13:09 --> Config Class Initialized
INFO - 2016-03-11 09:13:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:13:09 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:13:09 --> Utf8 Class Initialized
INFO - 2016-03-11 09:13:09 --> URI Class Initialized
INFO - 2016-03-11 09:13:09 --> Router Class Initialized
INFO - 2016-03-11 09:13:09 --> Output Class Initialized
INFO - 2016-03-11 09:13:09 --> Security Class Initialized
DEBUG - 2016-03-11 09:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:13:09 --> Input Class Initialized
INFO - 2016-03-11 09:13:09 --> Language Class Initialized
INFO - 2016-03-11 09:13:09 --> Loader Class Initialized
INFO - 2016-03-11 09:13:09 --> Helper loaded: url_helper
INFO - 2016-03-11 09:13:09 --> Helper loaded: file_helper
INFO - 2016-03-11 09:13:09 --> Helper loaded: date_helper
INFO - 2016-03-11 09:13:09 --> Helper loaded: form_helper
INFO - 2016-03-11 09:13:09 --> Database Driver Class Initialized
INFO - 2016-03-11 09:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:13:10 --> Controller Class Initialized
INFO - 2016-03-11 09:13:10 --> Model Class Initialized
INFO - 2016-03-11 09:13:10 --> Model Class Initialized
INFO - 2016-03-11 09:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:13:10 --> Pagination Class Initialized
INFO - 2016-03-11 09:13:10 --> Helper loaded: text_helper
INFO - 2016-03-11 09:13:10 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:13:10 --> Final output sent to browser
DEBUG - 2016-03-11 12:13:10 --> Total execution time: 1.1869
INFO - 2016-03-11 09:13:11 --> Config Class Initialized
INFO - 2016-03-11 09:13:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:13:11 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:13:11 --> Utf8 Class Initialized
INFO - 2016-03-11 09:13:11 --> URI Class Initialized
INFO - 2016-03-11 09:13:11 --> Router Class Initialized
INFO - 2016-03-11 09:13:11 --> Output Class Initialized
INFO - 2016-03-11 09:13:11 --> Security Class Initialized
DEBUG - 2016-03-11 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:13:11 --> Input Class Initialized
INFO - 2016-03-11 09:13:11 --> Language Class Initialized
INFO - 2016-03-11 09:13:11 --> Loader Class Initialized
INFO - 2016-03-11 09:13:11 --> Helper loaded: url_helper
INFO - 2016-03-11 09:13:11 --> Helper loaded: file_helper
INFO - 2016-03-11 09:13:11 --> Helper loaded: date_helper
INFO - 2016-03-11 09:13:11 --> Helper loaded: form_helper
INFO - 2016-03-11 09:13:11 --> Database Driver Class Initialized
INFO - 2016-03-11 09:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:13:12 --> Controller Class Initialized
INFO - 2016-03-11 09:13:12 --> Model Class Initialized
INFO - 2016-03-11 09:13:12 --> Model Class Initialized
INFO - 2016-03-11 09:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:13:12 --> Pagination Class Initialized
INFO - 2016-03-11 09:13:12 --> Helper loaded: text_helper
INFO - 2016-03-11 09:13:12 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:13:12 --> Final output sent to browser
DEBUG - 2016-03-11 12:13:12 --> Total execution time: 1.1439
INFO - 2016-03-11 09:13:14 --> Config Class Initialized
INFO - 2016-03-11 09:13:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:13:14 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:13:14 --> Utf8 Class Initialized
INFO - 2016-03-11 09:13:14 --> URI Class Initialized
INFO - 2016-03-11 09:13:14 --> Router Class Initialized
INFO - 2016-03-11 09:13:14 --> Output Class Initialized
INFO - 2016-03-11 09:13:14 --> Security Class Initialized
DEBUG - 2016-03-11 09:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:13:14 --> Input Class Initialized
INFO - 2016-03-11 09:13:14 --> Language Class Initialized
INFO - 2016-03-11 09:13:14 --> Loader Class Initialized
INFO - 2016-03-11 09:13:14 --> Helper loaded: url_helper
INFO - 2016-03-11 09:13:14 --> Helper loaded: file_helper
INFO - 2016-03-11 09:13:14 --> Helper loaded: date_helper
INFO - 2016-03-11 09:13:14 --> Helper loaded: form_helper
INFO - 2016-03-11 09:13:14 --> Database Driver Class Initialized
INFO - 2016-03-11 09:13:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:13:15 --> Controller Class Initialized
INFO - 2016-03-11 09:13:15 --> Model Class Initialized
INFO - 2016-03-11 09:13:15 --> Model Class Initialized
INFO - 2016-03-11 09:13:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:13:15 --> Pagination Class Initialized
INFO - 2016-03-11 09:13:15 --> Helper loaded: text_helper
INFO - 2016-03-11 09:13:15 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 12:13:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:13:15 --> Final output sent to browser
DEBUG - 2016-03-11 12:13:15 --> Total execution time: 1.2089
INFO - 2016-03-11 09:13:18 --> Config Class Initialized
INFO - 2016-03-11 09:13:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:13:18 --> UTF-8 Support Enabled
INFO - 2016-03-11 09:13:18 --> Utf8 Class Initialized
INFO - 2016-03-11 09:13:18 --> URI Class Initialized
INFO - 2016-03-11 09:13:18 --> Router Class Initialized
INFO - 2016-03-11 09:13:18 --> Output Class Initialized
INFO - 2016-03-11 09:13:18 --> Security Class Initialized
DEBUG - 2016-03-11 09:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 09:13:18 --> Input Class Initialized
INFO - 2016-03-11 09:13:18 --> Language Class Initialized
INFO - 2016-03-11 09:13:18 --> Loader Class Initialized
INFO - 2016-03-11 09:13:18 --> Helper loaded: url_helper
INFO - 2016-03-11 09:13:18 --> Helper loaded: file_helper
INFO - 2016-03-11 09:13:18 --> Helper loaded: date_helper
INFO - 2016-03-11 09:13:18 --> Helper loaded: form_helper
INFO - 2016-03-11 09:13:18 --> Database Driver Class Initialized
INFO - 2016-03-11 09:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 09:13:19 --> Controller Class Initialized
INFO - 2016-03-11 09:13:19 --> Model Class Initialized
INFO - 2016-03-11 09:13:19 --> Model Class Initialized
INFO - 2016-03-11 09:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 09:13:19 --> Pagination Class Initialized
INFO - 2016-03-11 09:13:19 --> Helper loaded: text_helper
INFO - 2016-03-11 09:13:19 --> Helper loaded: cookie_helper
INFO - 2016-03-11 12:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 12:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 12:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 12:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 12:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 12:13:19 --> Final output sent to browser
DEBUG - 2016-03-11 12:13:19 --> Total execution time: 1.1409
INFO - 2016-03-11 13:31:04 --> Config Class Initialized
INFO - 2016-03-11 13:31:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:04 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:04 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:04 --> URI Class Initialized
DEBUG - 2016-03-11 13:31:04 --> No URI present. Default controller set.
INFO - 2016-03-11 13:31:04 --> Router Class Initialized
INFO - 2016-03-11 13:31:04 --> Output Class Initialized
INFO - 2016-03-11 13:31:04 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:04 --> Input Class Initialized
INFO - 2016-03-11 13:31:04 --> Language Class Initialized
INFO - 2016-03-11 13:31:04 --> Loader Class Initialized
INFO - 2016-03-11 13:31:04 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:04 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:04 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:04 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:04 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:05 --> Controller Class Initialized
INFO - 2016-03-11 13:31:05 --> Model Class Initialized
INFO - 2016-03-11 13:31:05 --> Model Class Initialized
INFO - 2016-03-11 13:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:05 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:05 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:05 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-11 16:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:05 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:05 --> Total execution time: 1.1372
INFO - 2016-03-11 13:31:08 --> Config Class Initialized
INFO - 2016-03-11 13:31:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:08 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:08 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:08 --> URI Class Initialized
INFO - 2016-03-11 13:31:08 --> Router Class Initialized
INFO - 2016-03-11 13:31:08 --> Output Class Initialized
INFO - 2016-03-11 13:31:08 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:08 --> Input Class Initialized
INFO - 2016-03-11 13:31:08 --> Language Class Initialized
INFO - 2016-03-11 13:31:08 --> Loader Class Initialized
INFO - 2016-03-11 13:31:08 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:08 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:08 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:08 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:08 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:09 --> Controller Class Initialized
INFO - 2016-03-11 13:31:09 --> Model Class Initialized
INFO - 2016-03-11 13:31:09 --> Model Class Initialized
INFO - 2016-03-11 13:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:09 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:09 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:09 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 16:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 16:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:09 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:09 --> Total execution time: 1.1254
INFO - 2016-03-11 13:31:17 --> Config Class Initialized
INFO - 2016-03-11 13:31:17 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:17 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:17 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:17 --> URI Class Initialized
INFO - 2016-03-11 13:31:17 --> Router Class Initialized
INFO - 2016-03-11 13:31:17 --> Output Class Initialized
INFO - 2016-03-11 13:31:17 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:17 --> Input Class Initialized
INFO - 2016-03-11 13:31:17 --> Language Class Initialized
INFO - 2016-03-11 13:31:17 --> Loader Class Initialized
INFO - 2016-03-11 13:31:17 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:17 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:17 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:17 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:17 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:18 --> Controller Class Initialized
INFO - 2016-03-11 13:31:18 --> Model Class Initialized
INFO - 2016-03-11 13:31:18 --> Model Class Initialized
INFO - 2016-03-11 13:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:18 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:18 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:18 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 16:31:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 16:31:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:18 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:18 --> Total execution time: 1.1540
INFO - 2016-03-11 13:31:20 --> Config Class Initialized
INFO - 2016-03-11 13:31:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:20 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:20 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:20 --> URI Class Initialized
INFO - 2016-03-11 13:31:20 --> Router Class Initialized
INFO - 2016-03-11 13:31:20 --> Output Class Initialized
INFO - 2016-03-11 13:31:20 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:20 --> Input Class Initialized
INFO - 2016-03-11 13:31:20 --> Language Class Initialized
INFO - 2016-03-11 13:31:20 --> Loader Class Initialized
INFO - 2016-03-11 13:31:20 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:20 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:20 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:20 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:20 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:21 --> Controller Class Initialized
INFO - 2016-03-11 13:31:21 --> Model Class Initialized
INFO - 2016-03-11 13:31:21 --> Model Class Initialized
INFO - 2016-03-11 13:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:21 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:21 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:21 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 16:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 16:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:21 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:21 --> Total execution time: 1.1328
INFO - 2016-03-11 13:31:22 --> Config Class Initialized
INFO - 2016-03-11 13:31:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:22 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:22 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:22 --> URI Class Initialized
INFO - 2016-03-11 13:31:22 --> Router Class Initialized
INFO - 2016-03-11 13:31:22 --> Output Class Initialized
INFO - 2016-03-11 13:31:22 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:22 --> Input Class Initialized
INFO - 2016-03-11 13:31:22 --> Language Class Initialized
INFO - 2016-03-11 13:31:22 --> Loader Class Initialized
INFO - 2016-03-11 13:31:22 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:22 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:22 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:22 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:22 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:23 --> Controller Class Initialized
INFO - 2016-03-11 13:31:23 --> Model Class Initialized
INFO - 2016-03-11 13:31:23 --> Model Class Initialized
INFO - 2016-03-11 13:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:23 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:23 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:23 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 16:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 16:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:23 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:23 --> Total execution time: 1.1142
INFO - 2016-03-11 13:31:52 --> Config Class Initialized
INFO - 2016-03-11 13:31:52 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:31:52 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:31:52 --> Utf8 Class Initialized
INFO - 2016-03-11 13:31:52 --> URI Class Initialized
INFO - 2016-03-11 13:31:52 --> Router Class Initialized
INFO - 2016-03-11 13:31:52 --> Output Class Initialized
INFO - 2016-03-11 13:31:52 --> Security Class Initialized
DEBUG - 2016-03-11 13:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:31:52 --> Input Class Initialized
INFO - 2016-03-11 13:31:52 --> Language Class Initialized
INFO - 2016-03-11 13:31:52 --> Loader Class Initialized
INFO - 2016-03-11 13:31:52 --> Helper loaded: url_helper
INFO - 2016-03-11 13:31:52 --> Helper loaded: file_helper
INFO - 2016-03-11 13:31:52 --> Helper loaded: date_helper
INFO - 2016-03-11 13:31:52 --> Helper loaded: form_helper
INFO - 2016-03-11 13:31:52 --> Database Driver Class Initialized
INFO - 2016-03-11 13:31:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:31:53 --> Controller Class Initialized
INFO - 2016-03-11 13:31:53 --> Model Class Initialized
INFO - 2016-03-11 13:31:53 --> Model Class Initialized
INFO - 2016-03-11 13:31:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:31:53 --> Pagination Class Initialized
INFO - 2016-03-11 13:31:53 --> Helper loaded: text_helper
INFO - 2016-03-11 13:31:53 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-11 16:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:31:54 --> Final output sent to browser
DEBUG - 2016-03-11 16:31:54 --> Total execution time: 1.2235
INFO - 2016-03-11 13:32:26 --> Config Class Initialized
INFO - 2016-03-11 13:32:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 13:32:26 --> UTF-8 Support Enabled
INFO - 2016-03-11 13:32:26 --> Utf8 Class Initialized
INFO - 2016-03-11 13:32:26 --> URI Class Initialized
INFO - 2016-03-11 13:32:26 --> Router Class Initialized
INFO - 2016-03-11 13:32:26 --> Output Class Initialized
INFO - 2016-03-11 13:32:26 --> Security Class Initialized
DEBUG - 2016-03-11 13:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-11 13:32:26 --> Input Class Initialized
INFO - 2016-03-11 13:32:26 --> Language Class Initialized
INFO - 2016-03-11 13:32:26 --> Loader Class Initialized
INFO - 2016-03-11 13:32:26 --> Helper loaded: url_helper
INFO - 2016-03-11 13:32:26 --> Helper loaded: file_helper
INFO - 2016-03-11 13:32:26 --> Helper loaded: date_helper
INFO - 2016-03-11 13:32:26 --> Helper loaded: form_helper
INFO - 2016-03-11 13:32:26 --> Database Driver Class Initialized
INFO - 2016-03-11 13:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-11 13:32:27 --> Controller Class Initialized
INFO - 2016-03-11 13:32:27 --> Model Class Initialized
INFO - 2016-03-11 13:32:27 --> Model Class Initialized
INFO - 2016-03-11 13:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-11 13:32:27 --> Pagination Class Initialized
INFO - 2016-03-11 13:32:27 --> Helper loaded: text_helper
INFO - 2016-03-11 13:32:27 --> Helper loaded: cookie_helper
INFO - 2016-03-11 16:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-11 16:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-11 16:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-11 16:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-11 16:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-11 16:32:27 --> Final output sent to browser
DEBUG - 2016-03-11 16:32:27 --> Total execution time: 1.1291
