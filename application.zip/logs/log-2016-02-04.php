<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-04 08:10:01 --> Config Class Initialized
INFO - 2016-02-04 08:10:01 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:10:01 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:10:01 --> Utf8 Class Initialized
INFO - 2016-02-04 08:10:01 --> URI Class Initialized
DEBUG - 2016-02-04 08:10:01 --> No URI present. Default controller set.
INFO - 2016-02-04 08:10:01 --> Router Class Initialized
INFO - 2016-02-04 08:10:01 --> Output Class Initialized
INFO - 2016-02-04 08:10:01 --> Security Class Initialized
DEBUG - 2016-02-04 08:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:10:01 --> Input Class Initialized
INFO - 2016-02-04 08:10:01 --> Language Class Initialized
INFO - 2016-02-04 08:10:01 --> Loader Class Initialized
INFO - 2016-02-04 08:10:01 --> Helper loaded: url_helper
INFO - 2016-02-04 08:10:01 --> Helper loaded: file_helper
INFO - 2016-02-04 08:10:01 --> Helper loaded: date_helper
INFO - 2016-02-04 08:10:01 --> Database Driver Class Initialized
INFO - 2016-02-04 08:10:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:10:02 --> Controller Class Initialized
INFO - 2016-02-04 08:10:02 --> Model Class Initialized
INFO - 2016-02-04 08:10:02 --> Model Class Initialized
INFO - 2016-02-04 08:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:10:02 --> Pagination Class Initialized
INFO - 2016-02-04 08:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 08:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:10:02 --> Final output sent to browser
DEBUG - 2016-02-04 08:10:02 --> Total execution time: 1.1159
INFO - 2016-02-04 08:12:38 --> Config Class Initialized
INFO - 2016-02-04 08:12:38 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:12:38 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:12:38 --> Utf8 Class Initialized
INFO - 2016-02-04 08:12:38 --> URI Class Initialized
DEBUG - 2016-02-04 08:12:38 --> No URI present. Default controller set.
INFO - 2016-02-04 08:12:38 --> Router Class Initialized
INFO - 2016-02-04 08:12:38 --> Output Class Initialized
INFO - 2016-02-04 08:12:38 --> Security Class Initialized
DEBUG - 2016-02-04 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:12:38 --> Input Class Initialized
INFO - 2016-02-04 08:12:38 --> Language Class Initialized
INFO - 2016-02-04 08:12:38 --> Loader Class Initialized
INFO - 2016-02-04 08:12:38 --> Helper loaded: url_helper
INFO - 2016-02-04 08:12:38 --> Helper loaded: file_helper
INFO - 2016-02-04 08:12:38 --> Helper loaded: date_helper
INFO - 2016-02-04 08:12:38 --> Database Driver Class Initialized
INFO - 2016-02-04 08:12:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:12:39 --> Controller Class Initialized
INFO - 2016-02-04 08:12:39 --> Model Class Initialized
INFO - 2016-02-04 08:12:39 --> Model Class Initialized
INFO - 2016-02-04 08:12:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:12:39 --> Pagination Class Initialized
INFO - 2016-02-04 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 08:12:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:12:39 --> Final output sent to browser
DEBUG - 2016-02-04 08:12:39 --> Total execution time: 1.1063
INFO - 2016-02-04 08:12:53 --> Config Class Initialized
INFO - 2016-02-04 08:12:53 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:12:53 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:12:53 --> Utf8 Class Initialized
INFO - 2016-02-04 08:12:53 --> URI Class Initialized
DEBUG - 2016-02-04 08:12:53 --> No URI present. Default controller set.
INFO - 2016-02-04 08:12:53 --> Router Class Initialized
INFO - 2016-02-04 08:12:53 --> Output Class Initialized
INFO - 2016-02-04 08:12:53 --> Security Class Initialized
DEBUG - 2016-02-04 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:12:53 --> Input Class Initialized
INFO - 2016-02-04 08:12:53 --> Language Class Initialized
INFO - 2016-02-04 08:12:53 --> Loader Class Initialized
INFO - 2016-02-04 08:12:53 --> Helper loaded: url_helper
INFO - 2016-02-04 08:12:53 --> Helper loaded: file_helper
INFO - 2016-02-04 08:12:53 --> Helper loaded: date_helper
INFO - 2016-02-04 08:12:53 --> Database Driver Class Initialized
INFO - 2016-02-04 08:12:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:12:54 --> Controller Class Initialized
INFO - 2016-02-04 08:12:54 --> Model Class Initialized
INFO - 2016-02-04 08:12:54 --> Model Class Initialized
INFO - 2016-02-04 08:12:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:12:54 --> Pagination Class Initialized
INFO - 2016-02-04 08:12:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:12:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:12:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 08:12:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:12:54 --> Final output sent to browser
DEBUG - 2016-02-04 08:12:54 --> Total execution time: 1.0823
INFO - 2016-02-04 08:13:00 --> Config Class Initialized
INFO - 2016-02-04 08:13:00 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:13:00 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:13:00 --> Utf8 Class Initialized
INFO - 2016-02-04 08:13:00 --> URI Class Initialized
INFO - 2016-02-04 08:13:00 --> Router Class Initialized
INFO - 2016-02-04 08:13:00 --> Output Class Initialized
INFO - 2016-02-04 08:13:00 --> Security Class Initialized
DEBUG - 2016-02-04 08:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:13:00 --> Input Class Initialized
INFO - 2016-02-04 08:13:00 --> Language Class Initialized
INFO - 2016-02-04 08:13:00 --> Loader Class Initialized
INFO - 2016-02-04 08:13:00 --> Helper loaded: url_helper
INFO - 2016-02-04 08:13:00 --> Helper loaded: file_helper
INFO - 2016-02-04 08:13:00 --> Helper loaded: date_helper
INFO - 2016-02-04 08:13:00 --> Database Driver Class Initialized
INFO - 2016-02-04 08:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:13:01 --> Controller Class Initialized
INFO - 2016-02-04 08:13:01 --> Model Class Initialized
INFO - 2016-02-04 08:13:01 --> Model Class Initialized
INFO - 2016-02-04 08:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:13:01 --> Pagination Class Initialized
INFO - 2016-02-04 08:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:13:01 --> Helper loaded: text_helper
INFO - 2016-02-04 08:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-04 08:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-04 08:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:13:01 --> Final output sent to browser
DEBUG - 2016-02-04 08:13:01 --> Total execution time: 1.1715
INFO - 2016-02-04 08:15:42 --> Config Class Initialized
INFO - 2016-02-04 08:15:42 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:15:42 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:15:42 --> Utf8 Class Initialized
INFO - 2016-02-04 08:15:42 --> URI Class Initialized
INFO - 2016-02-04 08:15:42 --> Router Class Initialized
INFO - 2016-02-04 08:15:42 --> Output Class Initialized
INFO - 2016-02-04 08:15:42 --> Security Class Initialized
DEBUG - 2016-02-04 08:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:15:42 --> Input Class Initialized
INFO - 2016-02-04 08:15:42 --> Language Class Initialized
INFO - 2016-02-04 08:15:42 --> Loader Class Initialized
INFO - 2016-02-04 08:15:42 --> Helper loaded: url_helper
INFO - 2016-02-04 08:15:42 --> Helper loaded: file_helper
INFO - 2016-02-04 08:15:42 --> Helper loaded: date_helper
INFO - 2016-02-04 08:15:42 --> Database Driver Class Initialized
INFO - 2016-02-04 08:15:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:15:43 --> Controller Class Initialized
INFO - 2016-02-04 08:15:43 --> Model Class Initialized
INFO - 2016-02-04 08:15:43 --> Model Class Initialized
INFO - 2016-02-04 08:15:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:15:43 --> Pagination Class Initialized
INFO - 2016-02-04 08:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:15:43 --> Helper loaded: text_helper
INFO - 2016-02-04 08:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-04 08:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-04 08:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:15:43 --> Final output sent to browser
DEBUG - 2016-02-04 08:15:43 --> Total execution time: 1.1789
INFO - 2016-02-04 08:19:18 --> Config Class Initialized
INFO - 2016-02-04 08:19:18 --> Hooks Class Initialized
DEBUG - 2016-02-04 08:19:18 --> UTF-8 Support Enabled
INFO - 2016-02-04 08:19:18 --> Utf8 Class Initialized
INFO - 2016-02-04 08:19:18 --> URI Class Initialized
DEBUG - 2016-02-04 08:19:18 --> No URI present. Default controller set.
INFO - 2016-02-04 08:19:18 --> Router Class Initialized
INFO - 2016-02-04 08:19:18 --> Output Class Initialized
INFO - 2016-02-04 08:19:18 --> Security Class Initialized
DEBUG - 2016-02-04 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 08:19:18 --> Input Class Initialized
INFO - 2016-02-04 08:19:18 --> Language Class Initialized
INFO - 2016-02-04 08:19:18 --> Loader Class Initialized
INFO - 2016-02-04 08:19:18 --> Helper loaded: url_helper
INFO - 2016-02-04 08:19:18 --> Helper loaded: file_helper
INFO - 2016-02-04 08:19:18 --> Helper loaded: date_helper
INFO - 2016-02-04 08:19:18 --> Database Driver Class Initialized
INFO - 2016-02-04 08:19:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 08:19:19 --> Controller Class Initialized
INFO - 2016-02-04 08:19:19 --> Model Class Initialized
INFO - 2016-02-04 08:19:19 --> Model Class Initialized
INFO - 2016-02-04 08:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 08:19:19 --> Pagination Class Initialized
INFO - 2016-02-04 08:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 08:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 08:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 08:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 08:19:19 --> Final output sent to browser
DEBUG - 2016-02-04 08:19:19 --> Total execution time: 1.1213
INFO - 2016-02-04 11:30:19 --> Config Class Initialized
INFO - 2016-02-04 11:30:19 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:30:19 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:30:19 --> Utf8 Class Initialized
INFO - 2016-02-04 11:30:19 --> URI Class Initialized
INFO - 2016-02-04 11:30:19 --> Router Class Initialized
INFO - 2016-02-04 11:30:19 --> Output Class Initialized
INFO - 2016-02-04 11:30:19 --> Security Class Initialized
DEBUG - 2016-02-04 11:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:30:19 --> Input Class Initialized
INFO - 2016-02-04 11:30:19 --> Language Class Initialized
INFO - 2016-02-04 11:30:19 --> Loader Class Initialized
INFO - 2016-02-04 11:30:19 --> Helper loaded: url_helper
INFO - 2016-02-04 11:30:19 --> Helper loaded: file_helper
INFO - 2016-02-04 11:30:19 --> Helper loaded: date_helper
INFO - 2016-02-04 11:30:19 --> Database Driver Class Initialized
INFO - 2016-02-04 11:30:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:30:20 --> Controller Class Initialized
INFO - 2016-02-04 11:30:20 --> Model Class Initialized
INFO - 2016-02-04 11:30:20 --> Model Class Initialized
INFO - 2016-02-04 11:30:20 --> Helper loaded: form_helper
INFO - 2016-02-04 11:30:20 --> Form Validation Class Initialized
INFO - 2016-02-04 11:30:20 --> Helper loaded: text_helper
INFO - 2016-02-04 11:30:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:30:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:30:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 11:30:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:30:20 --> Final output sent to browser
DEBUG - 2016-02-04 11:30:20 --> Total execution time: 1.1111
INFO - 2016-02-04 11:36:19 --> Config Class Initialized
INFO - 2016-02-04 11:36:19 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:36:19 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:36:19 --> Utf8 Class Initialized
INFO - 2016-02-04 11:36:19 --> URI Class Initialized
DEBUG - 2016-02-04 11:36:19 --> No URI present. Default controller set.
INFO - 2016-02-04 11:36:19 --> Router Class Initialized
INFO - 2016-02-04 11:36:19 --> Output Class Initialized
INFO - 2016-02-04 11:36:19 --> Security Class Initialized
DEBUG - 2016-02-04 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:36:19 --> Input Class Initialized
INFO - 2016-02-04 11:36:19 --> Language Class Initialized
INFO - 2016-02-04 11:36:19 --> Loader Class Initialized
INFO - 2016-02-04 11:36:19 --> Helper loaded: url_helper
INFO - 2016-02-04 11:36:19 --> Helper loaded: file_helper
INFO - 2016-02-04 11:36:19 --> Helper loaded: date_helper
INFO - 2016-02-04 11:36:19 --> Database Driver Class Initialized
INFO - 2016-02-04 11:36:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:36:20 --> Controller Class Initialized
INFO - 2016-02-04 11:36:20 --> Model Class Initialized
INFO - 2016-02-04 11:36:20 --> Model Class Initialized
INFO - 2016-02-04 11:36:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:36:20 --> Pagination Class Initialized
INFO - 2016-02-04 11:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:36:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:36:20 --> Final output sent to browser
DEBUG - 2016-02-04 11:36:20 --> Total execution time: 1.1167
INFO - 2016-02-04 11:38:29 --> Config Class Initialized
INFO - 2016-02-04 11:38:29 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:29 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:29 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:29 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:29 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:29 --> Router Class Initialized
INFO - 2016-02-04 11:38:29 --> Output Class Initialized
INFO - 2016-02-04 11:38:29 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:29 --> Input Class Initialized
INFO - 2016-02-04 11:38:29 --> Language Class Initialized
INFO - 2016-02-04 11:38:29 --> Loader Class Initialized
INFO - 2016-02-04 11:38:29 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:29 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:29 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:29 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:30 --> Controller Class Initialized
INFO - 2016-02-04 11:38:30 --> Model Class Initialized
INFO - 2016-02-04 11:38:30 --> Model Class Initialized
INFO - 2016-02-04 11:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:30 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:30 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:30 --> Total execution time: 1.1143
INFO - 2016-02-04 11:38:32 --> Config Class Initialized
INFO - 2016-02-04 11:38:32 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:32 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:32 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:32 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:32 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:32 --> Router Class Initialized
INFO - 2016-02-04 11:38:32 --> Output Class Initialized
INFO - 2016-02-04 11:38:32 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:32 --> Input Class Initialized
INFO - 2016-02-04 11:38:32 --> Language Class Initialized
INFO - 2016-02-04 11:38:32 --> Loader Class Initialized
INFO - 2016-02-04 11:38:32 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:32 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:32 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:32 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:33 --> Controller Class Initialized
INFO - 2016-02-04 11:38:33 --> Model Class Initialized
INFO - 2016-02-04 11:38:33 --> Model Class Initialized
INFO - 2016-02-04 11:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:33 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:33 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:33 --> Total execution time: 1.1286
INFO - 2016-02-04 11:38:34 --> Config Class Initialized
INFO - 2016-02-04 11:38:34 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:34 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:34 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:34 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:34 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:34 --> Router Class Initialized
INFO - 2016-02-04 11:38:34 --> Output Class Initialized
INFO - 2016-02-04 11:38:34 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:34 --> Input Class Initialized
INFO - 2016-02-04 11:38:34 --> Language Class Initialized
INFO - 2016-02-04 11:38:34 --> Loader Class Initialized
INFO - 2016-02-04 11:38:34 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:34 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:34 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:34 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:35 --> Controller Class Initialized
INFO - 2016-02-04 11:38:35 --> Model Class Initialized
INFO - 2016-02-04 11:38:35 --> Model Class Initialized
INFO - 2016-02-04 11:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:35 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:35 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:35 --> Total execution time: 1.1587
INFO - 2016-02-04 11:38:37 --> Config Class Initialized
INFO - 2016-02-04 11:38:37 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:37 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:37 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:37 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:37 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:37 --> Router Class Initialized
INFO - 2016-02-04 11:38:37 --> Output Class Initialized
INFO - 2016-02-04 11:38:37 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:37 --> Input Class Initialized
INFO - 2016-02-04 11:38:37 --> Language Class Initialized
INFO - 2016-02-04 11:38:37 --> Loader Class Initialized
INFO - 2016-02-04 11:38:37 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:37 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:37 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:37 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:38 --> Controller Class Initialized
INFO - 2016-02-04 11:38:38 --> Model Class Initialized
INFO - 2016-02-04 11:38:38 --> Model Class Initialized
INFO - 2016-02-04 11:38:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:38 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:38 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:38 --> Total execution time: 1.2021
INFO - 2016-02-04 11:38:40 --> Config Class Initialized
INFO - 2016-02-04 11:38:40 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:40 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:40 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:40 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:40 --> Router Class Initialized
INFO - 2016-02-04 11:38:40 --> Output Class Initialized
INFO - 2016-02-04 11:38:40 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:40 --> Input Class Initialized
INFO - 2016-02-04 11:38:40 --> Language Class Initialized
INFO - 2016-02-04 11:38:40 --> Loader Class Initialized
INFO - 2016-02-04 11:38:40 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:40 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:40 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:40 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:41 --> Controller Class Initialized
INFO - 2016-02-04 11:38:41 --> Model Class Initialized
INFO - 2016-02-04 11:38:41 --> Model Class Initialized
INFO - 2016-02-04 11:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:41 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:41 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:41 --> Total execution time: 1.1595
INFO - 2016-02-04 11:38:42 --> Config Class Initialized
INFO - 2016-02-04 11:38:42 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:38:42 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:38:42 --> Utf8 Class Initialized
INFO - 2016-02-04 11:38:42 --> URI Class Initialized
DEBUG - 2016-02-04 11:38:42 --> No URI present. Default controller set.
INFO - 2016-02-04 11:38:42 --> Router Class Initialized
INFO - 2016-02-04 11:38:42 --> Output Class Initialized
INFO - 2016-02-04 11:38:42 --> Security Class Initialized
DEBUG - 2016-02-04 11:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:38:42 --> Input Class Initialized
INFO - 2016-02-04 11:38:42 --> Language Class Initialized
INFO - 2016-02-04 11:38:42 --> Loader Class Initialized
INFO - 2016-02-04 11:38:42 --> Helper loaded: url_helper
INFO - 2016-02-04 11:38:42 --> Helper loaded: file_helper
INFO - 2016-02-04 11:38:42 --> Helper loaded: date_helper
INFO - 2016-02-04 11:38:42 --> Database Driver Class Initialized
INFO - 2016-02-04 11:38:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:38:43 --> Controller Class Initialized
INFO - 2016-02-04 11:38:43 --> Model Class Initialized
INFO - 2016-02-04 11:38:43 --> Model Class Initialized
INFO - 2016-02-04 11:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:38:43 --> Pagination Class Initialized
INFO - 2016-02-04 11:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:38:44 --> Final output sent to browser
DEBUG - 2016-02-04 11:38:44 --> Total execution time: 1.1459
INFO - 2016-02-04 11:39:08 --> Config Class Initialized
INFO - 2016-02-04 11:39:08 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:39:08 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:39:08 --> Utf8 Class Initialized
INFO - 2016-02-04 11:39:08 --> URI Class Initialized
DEBUG - 2016-02-04 11:39:08 --> No URI present. Default controller set.
INFO - 2016-02-04 11:39:08 --> Router Class Initialized
INFO - 2016-02-04 11:39:08 --> Output Class Initialized
INFO - 2016-02-04 11:39:08 --> Security Class Initialized
DEBUG - 2016-02-04 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:39:08 --> Input Class Initialized
INFO - 2016-02-04 11:39:08 --> Language Class Initialized
INFO - 2016-02-04 11:39:08 --> Loader Class Initialized
INFO - 2016-02-04 11:39:08 --> Helper loaded: url_helper
INFO - 2016-02-04 11:39:08 --> Helper loaded: file_helper
INFO - 2016-02-04 11:39:08 --> Helper loaded: date_helper
INFO - 2016-02-04 11:39:08 --> Database Driver Class Initialized
INFO - 2016-02-04 11:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:39:09 --> Controller Class Initialized
INFO - 2016-02-04 11:39:09 --> Model Class Initialized
INFO - 2016-02-04 11:39:09 --> Model Class Initialized
INFO - 2016-02-04 11:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:39:09 --> Pagination Class Initialized
INFO - 2016-02-04 11:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:39:09 --> Final output sent to browser
DEBUG - 2016-02-04 11:39:09 --> Total execution time: 1.1358
INFO - 2016-02-04 11:42:34 --> Config Class Initialized
INFO - 2016-02-04 11:42:34 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:42:34 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:42:34 --> Utf8 Class Initialized
INFO - 2016-02-04 11:42:34 --> URI Class Initialized
DEBUG - 2016-02-04 11:42:34 --> No URI present. Default controller set.
INFO - 2016-02-04 11:42:34 --> Router Class Initialized
INFO - 2016-02-04 11:42:34 --> Output Class Initialized
INFO - 2016-02-04 11:42:34 --> Security Class Initialized
DEBUG - 2016-02-04 11:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:42:34 --> Input Class Initialized
INFO - 2016-02-04 11:42:34 --> Language Class Initialized
INFO - 2016-02-04 11:42:34 --> Loader Class Initialized
INFO - 2016-02-04 11:42:34 --> Helper loaded: url_helper
INFO - 2016-02-04 11:42:34 --> Helper loaded: file_helper
INFO - 2016-02-04 11:42:34 --> Helper loaded: date_helper
INFO - 2016-02-04 11:42:34 --> Database Driver Class Initialized
INFO - 2016-02-04 11:42:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:42:35 --> Controller Class Initialized
INFO - 2016-02-04 11:42:35 --> Model Class Initialized
INFO - 2016-02-04 11:42:35 --> Model Class Initialized
INFO - 2016-02-04 11:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:42:35 --> Pagination Class Initialized
INFO - 2016-02-04 11:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:42:35 --> Final output sent to browser
DEBUG - 2016-02-04 11:42:35 --> Total execution time: 1.1184
INFO - 2016-02-04 11:44:14 --> Config Class Initialized
INFO - 2016-02-04 11:44:14 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:44:14 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:44:14 --> Utf8 Class Initialized
INFO - 2016-02-04 11:44:14 --> URI Class Initialized
DEBUG - 2016-02-04 11:44:14 --> No URI present. Default controller set.
INFO - 2016-02-04 11:44:14 --> Router Class Initialized
INFO - 2016-02-04 11:44:14 --> Output Class Initialized
INFO - 2016-02-04 11:44:14 --> Security Class Initialized
DEBUG - 2016-02-04 11:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:44:14 --> Input Class Initialized
INFO - 2016-02-04 11:44:14 --> Language Class Initialized
INFO - 2016-02-04 11:44:14 --> Loader Class Initialized
INFO - 2016-02-04 11:44:14 --> Helper loaded: url_helper
INFO - 2016-02-04 11:44:14 --> Helper loaded: file_helper
INFO - 2016-02-04 11:44:15 --> Helper loaded: date_helper
INFO - 2016-02-04 11:44:15 --> Database Driver Class Initialized
INFO - 2016-02-04 11:44:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:44:16 --> Controller Class Initialized
INFO - 2016-02-04 11:44:16 --> Model Class Initialized
INFO - 2016-02-04 11:44:16 --> Model Class Initialized
INFO - 2016-02-04 11:44:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:44:16 --> Pagination Class Initialized
INFO - 2016-02-04 11:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-04 11:44:16 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 79
INFO - 2016-02-04 11:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:44:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:44:16 --> Final output sent to browser
DEBUG - 2016-02-04 11:44:16 --> Total execution time: 1.1629
INFO - 2016-02-04 11:44:20 --> Config Class Initialized
INFO - 2016-02-04 11:44:20 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:44:20 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:44:20 --> Utf8 Class Initialized
INFO - 2016-02-04 11:44:20 --> URI Class Initialized
INFO - 2016-02-04 11:44:20 --> Router Class Initialized
INFO - 2016-02-04 11:44:20 --> Output Class Initialized
INFO - 2016-02-04 11:44:20 --> Security Class Initialized
DEBUG - 2016-02-04 11:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:44:20 --> Input Class Initialized
INFO - 2016-02-04 11:44:20 --> Language Class Initialized
INFO - 2016-02-04 11:44:20 --> Loader Class Initialized
INFO - 2016-02-04 11:44:20 --> Helper loaded: url_helper
INFO - 2016-02-04 11:44:20 --> Helper loaded: file_helper
INFO - 2016-02-04 11:44:20 --> Helper loaded: date_helper
INFO - 2016-02-04 11:44:20 --> Database Driver Class Initialized
INFO - 2016-02-04 11:44:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:44:21 --> Controller Class Initialized
INFO - 2016-02-04 11:44:21 --> Model Class Initialized
INFO - 2016-02-04 11:44:21 --> Model Class Initialized
INFO - 2016-02-04 11:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:44:21 --> Pagination Class Initialized
INFO - 2016-02-04 11:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-04 11:44:21 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 79
INFO - 2016-02-04 11:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:44:21 --> Helper loaded: text_helper
INFO - 2016-02-04 11:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-04 11:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-04 11:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:44:21 --> Final output sent to browser
DEBUG - 2016-02-04 11:44:21 --> Total execution time: 1.1417
INFO - 2016-02-04 11:45:46 --> Config Class Initialized
INFO - 2016-02-04 11:45:46 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:45:46 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:45:46 --> Utf8 Class Initialized
INFO - 2016-02-04 11:45:46 --> URI Class Initialized
DEBUG - 2016-02-04 11:45:46 --> No URI present. Default controller set.
INFO - 2016-02-04 11:45:46 --> Router Class Initialized
INFO - 2016-02-04 11:45:46 --> Output Class Initialized
INFO - 2016-02-04 11:45:46 --> Security Class Initialized
DEBUG - 2016-02-04 11:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:45:46 --> Input Class Initialized
INFO - 2016-02-04 11:45:46 --> Language Class Initialized
INFO - 2016-02-04 11:45:46 --> Loader Class Initialized
INFO - 2016-02-04 11:45:46 --> Helper loaded: url_helper
INFO - 2016-02-04 11:45:46 --> Helper loaded: file_helper
INFO - 2016-02-04 11:45:46 --> Helper loaded: date_helper
INFO - 2016-02-04 11:45:46 --> Database Driver Class Initialized
INFO - 2016-02-04 11:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:45:47 --> Controller Class Initialized
INFO - 2016-02-04 11:45:47 --> Model Class Initialized
INFO - 2016-02-04 11:45:47 --> Model Class Initialized
INFO - 2016-02-04 11:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:45:47 --> Pagination Class Initialized
INFO - 2016-02-04 11:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-04 11:45:47 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 79
INFO - 2016-02-04 11:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:45:47 --> Final output sent to browser
DEBUG - 2016-02-04 11:45:47 --> Total execution time: 1.1696
INFO - 2016-02-04 11:46:20 --> Config Class Initialized
INFO - 2016-02-04 11:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:46:20 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:46:20 --> Utf8 Class Initialized
INFO - 2016-02-04 11:46:20 --> URI Class Initialized
DEBUG - 2016-02-04 11:46:20 --> No URI present. Default controller set.
INFO - 2016-02-04 11:46:20 --> Router Class Initialized
INFO - 2016-02-04 11:46:20 --> Output Class Initialized
INFO - 2016-02-04 11:46:20 --> Security Class Initialized
DEBUG - 2016-02-04 11:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:46:20 --> Input Class Initialized
INFO - 2016-02-04 11:46:20 --> Language Class Initialized
INFO - 2016-02-04 11:46:20 --> Loader Class Initialized
INFO - 2016-02-04 11:46:20 --> Helper loaded: url_helper
INFO - 2016-02-04 11:46:20 --> Helper loaded: file_helper
INFO - 2016-02-04 11:46:20 --> Helper loaded: date_helper
INFO - 2016-02-04 11:46:20 --> Database Driver Class Initialized
INFO - 2016-02-04 11:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:46:21 --> Controller Class Initialized
INFO - 2016-02-04 11:46:21 --> Model Class Initialized
INFO - 2016-02-04 11:46:21 --> Model Class Initialized
INFO - 2016-02-04 11:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:46:21 --> Pagination Class Initialized
INFO - 2016-02-04 11:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-04 11:46:21 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 61
INFO - 2016-02-04 11:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:46:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:46:21 --> Final output sent to browser
DEBUG - 2016-02-04 11:46:21 --> Total execution time: 1.1075
INFO - 2016-02-04 11:46:37 --> Config Class Initialized
INFO - 2016-02-04 11:46:37 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:46:37 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:46:37 --> Utf8 Class Initialized
INFO - 2016-02-04 11:46:37 --> URI Class Initialized
DEBUG - 2016-02-04 11:46:37 --> No URI present. Default controller set.
INFO - 2016-02-04 11:46:37 --> Router Class Initialized
INFO - 2016-02-04 11:46:37 --> Output Class Initialized
INFO - 2016-02-04 11:46:37 --> Security Class Initialized
DEBUG - 2016-02-04 11:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:46:37 --> Input Class Initialized
INFO - 2016-02-04 11:46:37 --> Language Class Initialized
INFO - 2016-02-04 11:46:37 --> Loader Class Initialized
INFO - 2016-02-04 11:46:37 --> Helper loaded: url_helper
INFO - 2016-02-04 11:46:37 --> Helper loaded: file_helper
INFO - 2016-02-04 11:46:37 --> Helper loaded: date_helper
INFO - 2016-02-04 11:46:37 --> Database Driver Class Initialized
INFO - 2016-02-04 11:46:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:46:39 --> Controller Class Initialized
INFO - 2016-02-04 11:46:39 --> Model Class Initialized
INFO - 2016-02-04 11:46:39 --> Model Class Initialized
INFO - 2016-02-04 11:46:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:46:39 --> Pagination Class Initialized
INFO - 2016-02-04 11:46:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-04 11:46:39 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 61
INFO - 2016-02-04 11:46:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:46:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:46:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:46:39 --> Final output sent to browser
DEBUG - 2016-02-04 11:46:39 --> Total execution time: 1.1266
INFO - 2016-02-04 11:48:07 --> Config Class Initialized
INFO - 2016-02-04 11:48:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:48:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:48:07 --> Utf8 Class Initialized
INFO - 2016-02-04 11:48:07 --> URI Class Initialized
DEBUG - 2016-02-04 11:48:07 --> No URI present. Default controller set.
INFO - 2016-02-04 11:48:07 --> Router Class Initialized
INFO - 2016-02-04 11:48:07 --> Output Class Initialized
INFO - 2016-02-04 11:48:07 --> Security Class Initialized
DEBUG - 2016-02-04 11:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:48:07 --> Input Class Initialized
INFO - 2016-02-04 11:48:07 --> Language Class Initialized
INFO - 2016-02-04 11:48:07 --> Loader Class Initialized
INFO - 2016-02-04 11:48:07 --> Helper loaded: url_helper
INFO - 2016-02-04 11:48:07 --> Helper loaded: file_helper
INFO - 2016-02-04 11:48:07 --> Helper loaded: date_helper
INFO - 2016-02-04 11:48:07 --> Database Driver Class Initialized
INFO - 2016-02-04 11:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:48:08 --> Controller Class Initialized
INFO - 2016-02-04 11:48:08 --> Model Class Initialized
INFO - 2016-02-04 11:48:08 --> Model Class Initialized
INFO - 2016-02-04 11:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:48:08 --> Pagination Class Initialized
INFO - 2016-02-04 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:48:08 --> Final output sent to browser
DEBUG - 2016-02-04 11:48:08 --> Total execution time: 1.0964
INFO - 2016-02-04 11:48:09 --> Config Class Initialized
INFO - 2016-02-04 11:48:09 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:48:09 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:48:09 --> Utf8 Class Initialized
INFO - 2016-02-04 11:48:09 --> URI Class Initialized
INFO - 2016-02-04 11:48:09 --> Router Class Initialized
INFO - 2016-02-04 11:48:09 --> Output Class Initialized
INFO - 2016-02-04 11:48:09 --> Security Class Initialized
DEBUG - 2016-02-04 11:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:48:09 --> Input Class Initialized
INFO - 2016-02-04 11:48:09 --> Language Class Initialized
INFO - 2016-02-04 11:48:09 --> Loader Class Initialized
INFO - 2016-02-04 11:48:10 --> Helper loaded: url_helper
INFO - 2016-02-04 11:48:10 --> Helper loaded: file_helper
INFO - 2016-02-04 11:48:10 --> Helper loaded: date_helper
INFO - 2016-02-04 11:48:10 --> Database Driver Class Initialized
INFO - 2016-02-04 11:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:48:11 --> Controller Class Initialized
INFO - 2016-02-04 11:48:11 --> Model Class Initialized
INFO - 2016-02-04 11:48:11 --> Model Class Initialized
INFO - 2016-02-04 11:48:11 --> Helper loaded: form_helper
INFO - 2016-02-04 11:48:11 --> Form Validation Class Initialized
INFO - 2016-02-04 11:48:11 --> Helper loaded: text_helper
INFO - 2016-02-04 11:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 11:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:48:11 --> Final output sent to browser
DEBUG - 2016-02-04 11:48:11 --> Total execution time: 1.1235
INFO - 2016-02-04 11:48:15 --> Config Class Initialized
INFO - 2016-02-04 11:48:15 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:48:15 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:48:15 --> Utf8 Class Initialized
INFO - 2016-02-04 11:48:15 --> URI Class Initialized
INFO - 2016-02-04 11:48:15 --> Router Class Initialized
INFO - 2016-02-04 11:48:15 --> Output Class Initialized
INFO - 2016-02-04 11:48:15 --> Security Class Initialized
DEBUG - 2016-02-04 11:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:48:15 --> Input Class Initialized
INFO - 2016-02-04 11:48:15 --> Language Class Initialized
INFO - 2016-02-04 11:48:15 --> Loader Class Initialized
INFO - 2016-02-04 11:48:15 --> Helper loaded: url_helper
INFO - 2016-02-04 11:48:15 --> Helper loaded: file_helper
INFO - 2016-02-04 11:48:15 --> Helper loaded: date_helper
INFO - 2016-02-04 11:48:15 --> Database Driver Class Initialized
INFO - 2016-02-04 11:48:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:48:16 --> Controller Class Initialized
INFO - 2016-02-04 11:48:16 --> Model Class Initialized
INFO - 2016-02-04 11:48:16 --> Model Class Initialized
INFO - 2016-02-04 11:48:16 --> Helper loaded: form_helper
INFO - 2016-02-04 11:48:16 --> Form Validation Class Initialized
INFO - 2016-02-04 11:48:16 --> Helper loaded: text_helper
INFO - 2016-02-04 11:48:16 --> Config Class Initialized
INFO - 2016-02-04 11:48:16 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:48:16 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:48:16 --> Utf8 Class Initialized
INFO - 2016-02-04 11:48:16 --> URI Class Initialized
INFO - 2016-02-04 11:48:16 --> Router Class Initialized
INFO - 2016-02-04 11:48:16 --> Output Class Initialized
INFO - 2016-02-04 11:48:16 --> Security Class Initialized
DEBUG - 2016-02-04 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:48:16 --> Input Class Initialized
INFO - 2016-02-04 11:48:16 --> Language Class Initialized
INFO - 2016-02-04 11:48:16 --> Loader Class Initialized
INFO - 2016-02-04 11:48:16 --> Helper loaded: url_helper
INFO - 2016-02-04 11:48:16 --> Helper loaded: file_helper
INFO - 2016-02-04 11:48:16 --> Helper loaded: date_helper
INFO - 2016-02-04 11:48:16 --> Database Driver Class Initialized
INFO - 2016-02-04 11:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:48:17 --> Controller Class Initialized
INFO - 2016-02-04 11:48:17 --> Model Class Initialized
INFO - 2016-02-04 11:48:17 --> Model Class Initialized
INFO - 2016-02-04 11:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:48:17 --> Pagination Class Initialized
INFO - 2016-02-04 11:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:48:17 --> Final output sent to browser
DEBUG - 2016-02-04 11:48:17 --> Total execution time: 1.1334
INFO - 2016-02-04 11:50:09 --> Config Class Initialized
INFO - 2016-02-04 11:50:09 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:09 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:09 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:09 --> URI Class Initialized
INFO - 2016-02-04 11:50:09 --> Router Class Initialized
INFO - 2016-02-04 11:50:09 --> Output Class Initialized
INFO - 2016-02-04 11:50:09 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:09 --> Input Class Initialized
INFO - 2016-02-04 11:50:09 --> Language Class Initialized
INFO - 2016-02-04 11:50:09 --> Loader Class Initialized
INFO - 2016-02-04 11:50:09 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:09 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:09 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:09 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:10 --> Controller Class Initialized
INFO - 2016-02-04 11:50:10 --> Model Class Initialized
INFO - 2016-02-04 11:50:10 --> Model Class Initialized
INFO - 2016-02-04 11:50:10 --> Helper loaded: form_helper
INFO - 2016-02-04 11:50:10 --> Form Validation Class Initialized
INFO - 2016-02-04 11:50:10 --> Helper loaded: text_helper
INFO - 2016-02-04 11:50:10 --> Config Class Initialized
INFO - 2016-02-04 11:50:10 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:10 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:10 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:10 --> URI Class Initialized
INFO - 2016-02-04 11:50:10 --> Router Class Initialized
INFO - 2016-02-04 11:50:10 --> Output Class Initialized
INFO - 2016-02-04 11:50:10 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:10 --> Input Class Initialized
INFO - 2016-02-04 11:50:10 --> Language Class Initialized
INFO - 2016-02-04 11:50:10 --> Loader Class Initialized
INFO - 2016-02-04 11:50:10 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:10 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:10 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:10 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:11 --> Controller Class Initialized
INFO - 2016-02-04 11:50:11 --> Model Class Initialized
INFO - 2016-02-04 11:50:11 --> Model Class Initialized
INFO - 2016-02-04 11:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 11:50:11 --> Pagination Class Initialized
INFO - 2016-02-04 11:50:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:50:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:50:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 11:50:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:50:11 --> Final output sent to browser
DEBUG - 2016-02-04 11:50:11 --> Total execution time: 1.1252
INFO - 2016-02-04 11:50:13 --> Config Class Initialized
INFO - 2016-02-04 11:50:13 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:13 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:13 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:13 --> URI Class Initialized
INFO - 2016-02-04 11:50:13 --> Router Class Initialized
INFO - 2016-02-04 11:50:13 --> Output Class Initialized
INFO - 2016-02-04 11:50:13 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:13 --> Input Class Initialized
INFO - 2016-02-04 11:50:13 --> Language Class Initialized
INFO - 2016-02-04 11:50:13 --> Loader Class Initialized
INFO - 2016-02-04 11:50:13 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:13 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:13 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:13 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:14 --> Controller Class Initialized
INFO - 2016-02-04 11:50:14 --> Model Class Initialized
INFO - 2016-02-04 11:50:14 --> Model Class Initialized
INFO - 2016-02-04 11:50:14 --> Helper loaded: form_helper
INFO - 2016-02-04 11:50:14 --> Form Validation Class Initialized
INFO - 2016-02-04 11:50:14 --> Helper loaded: text_helper
INFO - 2016-02-04 11:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 11:50:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:50:14 --> Final output sent to browser
DEBUG - 2016-02-04 11:50:14 --> Total execution time: 1.1372
INFO - 2016-02-04 11:50:26 --> Config Class Initialized
INFO - 2016-02-04 11:50:26 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:26 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:26 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:26 --> URI Class Initialized
INFO - 2016-02-04 11:50:26 --> Router Class Initialized
INFO - 2016-02-04 11:50:26 --> Output Class Initialized
INFO - 2016-02-04 11:50:26 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:26 --> Input Class Initialized
INFO - 2016-02-04 11:50:26 --> Language Class Initialized
INFO - 2016-02-04 11:50:26 --> Loader Class Initialized
INFO - 2016-02-04 11:50:26 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:26 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:26 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:26 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:27 --> Controller Class Initialized
INFO - 2016-02-04 11:50:27 --> Model Class Initialized
INFO - 2016-02-04 11:50:27 --> Model Class Initialized
INFO - 2016-02-04 11:50:27 --> Helper loaded: form_helper
INFO - 2016-02-04 11:50:27 --> Form Validation Class Initialized
INFO - 2016-02-04 11:50:27 --> Helper loaded: text_helper
ERROR - 2016-02-04 11:50:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 11:50:27 --> Config Class Initialized
INFO - 2016-02-04 11:50:27 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:27 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:27 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:27 --> URI Class Initialized
INFO - 2016-02-04 11:50:27 --> Router Class Initialized
INFO - 2016-02-04 11:50:27 --> Output Class Initialized
INFO - 2016-02-04 11:50:27 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:27 --> Input Class Initialized
INFO - 2016-02-04 11:50:27 --> Language Class Initialized
INFO - 2016-02-04 11:50:27 --> Loader Class Initialized
INFO - 2016-02-04 11:50:27 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:27 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:27 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:27 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:28 --> Controller Class Initialized
INFO - 2016-02-04 11:50:28 --> Model Class Initialized
INFO - 2016-02-04 11:50:28 --> Model Class Initialized
INFO - 2016-02-04 11:50:29 --> Helper loaded: form_helper
INFO - 2016-02-04 11:50:29 --> Form Validation Class Initialized
INFO - 2016-02-04 11:50:29 --> Helper loaded: text_helper
INFO - 2016-02-04 11:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 11:50:29 --> Final output sent to browser
DEBUG - 2016-02-04 11:50:29 --> Total execution time: 1.1703
INFO - 2016-02-04 11:50:45 --> Config Class Initialized
INFO - 2016-02-04 11:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-04 11:50:45 --> UTF-8 Support Enabled
INFO - 2016-02-04 11:50:45 --> Utf8 Class Initialized
INFO - 2016-02-04 11:50:45 --> URI Class Initialized
INFO - 2016-02-04 11:50:45 --> Router Class Initialized
INFO - 2016-02-04 11:50:45 --> Output Class Initialized
INFO - 2016-02-04 11:50:45 --> Security Class Initialized
DEBUG - 2016-02-04 11:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 11:50:45 --> Input Class Initialized
INFO - 2016-02-04 11:50:45 --> Language Class Initialized
INFO - 2016-02-04 11:50:45 --> Loader Class Initialized
INFO - 2016-02-04 11:50:45 --> Helper loaded: url_helper
INFO - 2016-02-04 11:50:45 --> Helper loaded: file_helper
INFO - 2016-02-04 11:50:45 --> Helper loaded: date_helper
INFO - 2016-02-04 11:50:45 --> Database Driver Class Initialized
INFO - 2016-02-04 11:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 11:50:46 --> Controller Class Initialized
INFO - 2016-02-04 11:50:46 --> Model Class Initialized
INFO - 2016-02-04 11:50:46 --> Model Class Initialized
INFO - 2016-02-04 11:50:46 --> Helper loaded: form_helper
INFO - 2016-02-04 11:50:46 --> Form Validation Class Initialized
INFO - 2016-02-04 11:50:46 --> Helper loaded: text_helper
INFO - 2016-02-04 11:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 11:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 11:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 11:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 11:50:46 --> Final output sent to browser
DEBUG - 2016-02-04 11:50:46 --> Total execution time: 1.2559
INFO - 2016-02-04 12:02:28 --> Config Class Initialized
INFO - 2016-02-04 12:02:28 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:02:28 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:02:28 --> Utf8 Class Initialized
INFO - 2016-02-04 12:02:28 --> URI Class Initialized
DEBUG - 2016-02-04 12:02:28 --> No URI present. Default controller set.
INFO - 2016-02-04 12:02:28 --> Router Class Initialized
INFO - 2016-02-04 12:02:28 --> Output Class Initialized
INFO - 2016-02-04 12:02:28 --> Security Class Initialized
DEBUG - 2016-02-04 12:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:02:28 --> Input Class Initialized
INFO - 2016-02-04 12:02:28 --> Language Class Initialized
INFO - 2016-02-04 12:02:28 --> Loader Class Initialized
INFO - 2016-02-04 12:02:28 --> Helper loaded: url_helper
INFO - 2016-02-04 12:02:28 --> Helper loaded: file_helper
INFO - 2016-02-04 12:02:28 --> Helper loaded: date_helper
INFO - 2016-02-04 12:02:28 --> Database Driver Class Initialized
INFO - 2016-02-04 12:02:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:02:30 --> Controller Class Initialized
INFO - 2016-02-04 12:02:30 --> Model Class Initialized
INFO - 2016-02-04 12:02:30 --> Model Class Initialized
INFO - 2016-02-04 12:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 12:02:30 --> Pagination Class Initialized
INFO - 2016-02-04 12:02:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:02:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:02:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 12:02:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:02:30 --> Final output sent to browser
DEBUG - 2016-02-04 12:02:30 --> Total execution time: 1.1365
INFO - 2016-02-04 12:02:31 --> Config Class Initialized
INFO - 2016-02-04 12:02:31 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:02:31 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:02:31 --> Utf8 Class Initialized
INFO - 2016-02-04 12:02:31 --> URI Class Initialized
INFO - 2016-02-04 12:02:31 --> Router Class Initialized
INFO - 2016-02-04 12:02:31 --> Output Class Initialized
INFO - 2016-02-04 12:02:31 --> Security Class Initialized
DEBUG - 2016-02-04 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:02:31 --> Input Class Initialized
INFO - 2016-02-04 12:02:31 --> Language Class Initialized
INFO - 2016-02-04 12:02:31 --> Loader Class Initialized
INFO - 2016-02-04 12:02:31 --> Helper loaded: url_helper
INFO - 2016-02-04 12:02:31 --> Helper loaded: file_helper
INFO - 2016-02-04 12:02:31 --> Helper loaded: date_helper
INFO - 2016-02-04 12:02:31 --> Database Driver Class Initialized
INFO - 2016-02-04 12:02:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:02:32 --> Controller Class Initialized
INFO - 2016-02-04 12:02:32 --> Model Class Initialized
INFO - 2016-02-04 12:02:32 --> Model Class Initialized
INFO - 2016-02-04 12:02:32 --> Helper loaded: form_helper
INFO - 2016-02-04 12:02:32 --> Form Validation Class Initialized
INFO - 2016-02-04 12:02:32 --> Helper loaded: text_helper
INFO - 2016-02-04 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 12:02:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:02:32 --> Final output sent to browser
DEBUG - 2016-02-04 12:02:32 --> Total execution time: 1.1073
INFO - 2016-02-04 12:03:07 --> Config Class Initialized
INFO - 2016-02-04 12:03:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:03:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:03:07 --> Utf8 Class Initialized
INFO - 2016-02-04 12:03:07 --> URI Class Initialized
DEBUG - 2016-02-04 12:03:07 --> No URI present. Default controller set.
INFO - 2016-02-04 12:03:07 --> Router Class Initialized
INFO - 2016-02-04 12:03:07 --> Output Class Initialized
INFO - 2016-02-04 12:03:07 --> Security Class Initialized
DEBUG - 2016-02-04 12:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:03:07 --> Input Class Initialized
INFO - 2016-02-04 12:03:07 --> Language Class Initialized
INFO - 2016-02-04 12:03:07 --> Loader Class Initialized
INFO - 2016-02-04 12:03:07 --> Helper loaded: url_helper
INFO - 2016-02-04 12:03:07 --> Helper loaded: file_helper
INFO - 2016-02-04 12:03:07 --> Helper loaded: date_helper
INFO - 2016-02-04 12:03:07 --> Database Driver Class Initialized
INFO - 2016-02-04 12:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:03:08 --> Controller Class Initialized
INFO - 2016-02-04 12:03:08 --> Model Class Initialized
INFO - 2016-02-04 12:03:08 --> Model Class Initialized
INFO - 2016-02-04 12:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 12:03:08 --> Pagination Class Initialized
INFO - 2016-02-04 12:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 12:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:03:08 --> Final output sent to browser
DEBUG - 2016-02-04 12:03:08 --> Total execution time: 1.1314
INFO - 2016-02-04 12:03:09 --> Config Class Initialized
INFO - 2016-02-04 12:03:09 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:03:09 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:03:09 --> Utf8 Class Initialized
INFO - 2016-02-04 12:03:09 --> URI Class Initialized
INFO - 2016-02-04 12:03:09 --> Router Class Initialized
INFO - 2016-02-04 12:03:09 --> Output Class Initialized
INFO - 2016-02-04 12:03:09 --> Security Class Initialized
DEBUG - 2016-02-04 12:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:03:09 --> Input Class Initialized
INFO - 2016-02-04 12:03:10 --> Language Class Initialized
INFO - 2016-02-04 12:03:10 --> Loader Class Initialized
INFO - 2016-02-04 12:03:10 --> Helper loaded: url_helper
INFO - 2016-02-04 12:03:10 --> Helper loaded: file_helper
INFO - 2016-02-04 12:03:10 --> Helper loaded: date_helper
INFO - 2016-02-04 12:03:10 --> Database Driver Class Initialized
INFO - 2016-02-04 12:03:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:03:11 --> Controller Class Initialized
INFO - 2016-02-04 12:03:11 --> Model Class Initialized
INFO - 2016-02-04 12:03:11 --> Model Class Initialized
INFO - 2016-02-04 12:03:11 --> Helper loaded: form_helper
INFO - 2016-02-04 12:03:11 --> Form Validation Class Initialized
INFO - 2016-02-04 12:03:11 --> Helper loaded: text_helper
INFO - 2016-02-04 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:03:11 --> Final output sent to browser
DEBUG - 2016-02-04 12:03:11 --> Total execution time: 1.1209
INFO - 2016-02-04 12:03:35 --> Config Class Initialized
INFO - 2016-02-04 12:03:35 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:03:35 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:03:35 --> Utf8 Class Initialized
INFO - 2016-02-04 12:03:35 --> URI Class Initialized
INFO - 2016-02-04 12:03:35 --> Router Class Initialized
INFO - 2016-02-04 12:03:35 --> Output Class Initialized
INFO - 2016-02-04 12:03:35 --> Security Class Initialized
DEBUG - 2016-02-04 12:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:03:35 --> Input Class Initialized
INFO - 2016-02-04 12:03:35 --> Language Class Initialized
INFO - 2016-02-04 12:03:35 --> Loader Class Initialized
INFO - 2016-02-04 12:03:35 --> Helper loaded: url_helper
INFO - 2016-02-04 12:03:35 --> Helper loaded: file_helper
INFO - 2016-02-04 12:03:35 --> Helper loaded: date_helper
INFO - 2016-02-04 12:03:35 --> Database Driver Class Initialized
INFO - 2016-02-04 12:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:03:36 --> Controller Class Initialized
INFO - 2016-02-04 12:03:36 --> Model Class Initialized
INFO - 2016-02-04 12:03:36 --> Model Class Initialized
INFO - 2016-02-04 12:03:36 --> Helper loaded: form_helper
INFO - 2016-02-04 12:03:36 --> Form Validation Class Initialized
INFO - 2016-02-04 12:03:36 --> Helper loaded: text_helper
INFO - 2016-02-04 12:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 12:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:03:36 --> Final output sent to browser
DEBUG - 2016-02-04 12:03:36 --> Total execution time: 1.1618
INFO - 2016-02-04 12:03:56 --> Config Class Initialized
INFO - 2016-02-04 12:03:56 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:03:56 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:03:56 --> Utf8 Class Initialized
INFO - 2016-02-04 12:03:56 --> URI Class Initialized
INFO - 2016-02-04 12:03:56 --> Router Class Initialized
INFO - 2016-02-04 12:03:56 --> Output Class Initialized
INFO - 2016-02-04 12:03:56 --> Security Class Initialized
DEBUG - 2016-02-04 12:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:03:56 --> Input Class Initialized
INFO - 2016-02-04 12:03:56 --> Language Class Initialized
INFO - 2016-02-04 12:03:56 --> Loader Class Initialized
INFO - 2016-02-04 12:03:56 --> Helper loaded: url_helper
INFO - 2016-02-04 12:03:56 --> Helper loaded: file_helper
INFO - 2016-02-04 12:03:56 --> Helper loaded: date_helper
INFO - 2016-02-04 12:03:56 --> Database Driver Class Initialized
INFO - 2016-02-04 12:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:03:57 --> Controller Class Initialized
INFO - 2016-02-04 12:03:57 --> Model Class Initialized
INFO - 2016-02-04 12:03:57 --> Model Class Initialized
INFO - 2016-02-04 12:03:57 --> Helper loaded: form_helper
INFO - 2016-02-04 12:03:57 --> Form Validation Class Initialized
INFO - 2016-02-04 12:03:57 --> Helper loaded: text_helper
INFO - 2016-02-04 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:03:57 --> Final output sent to browser
DEBUG - 2016-02-04 12:03:57 --> Total execution time: 1.1660
INFO - 2016-02-04 12:04:56 --> Config Class Initialized
INFO - 2016-02-04 12:04:56 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:04:56 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:04:56 --> Utf8 Class Initialized
INFO - 2016-02-04 12:04:56 --> URI Class Initialized
INFO - 2016-02-04 12:04:56 --> Router Class Initialized
INFO - 2016-02-04 12:04:56 --> Output Class Initialized
INFO - 2016-02-04 12:04:56 --> Security Class Initialized
DEBUG - 2016-02-04 12:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:04:56 --> Input Class Initialized
INFO - 2016-02-04 12:04:56 --> Language Class Initialized
INFO - 2016-02-04 12:04:56 --> Loader Class Initialized
INFO - 2016-02-04 12:04:56 --> Helper loaded: url_helper
INFO - 2016-02-04 12:04:56 --> Helper loaded: file_helper
INFO - 2016-02-04 12:04:56 --> Helper loaded: date_helper
INFO - 2016-02-04 12:04:56 --> Database Driver Class Initialized
INFO - 2016-02-04 12:04:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:04:57 --> Controller Class Initialized
INFO - 2016-02-04 12:04:57 --> Model Class Initialized
INFO - 2016-02-04 12:04:57 --> Model Class Initialized
INFO - 2016-02-04 12:04:57 --> Helper loaded: form_helper
INFO - 2016-02-04 12:04:57 --> Form Validation Class Initialized
INFO - 2016-02-04 12:04:57 --> Helper loaded: text_helper
INFO - 2016-02-04 12:04:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 12:04:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 12:04:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 12:04:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 12:04:57 --> Final output sent to browser
DEBUG - 2016-02-04 12:04:57 --> Total execution time: 1.1684
INFO - 2016-02-04 12:36:46 --> Config Class Initialized
INFO - 2016-02-04 12:36:46 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:36:46 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:36:46 --> Utf8 Class Initialized
INFO - 2016-02-04 12:36:46 --> URI Class Initialized
INFO - 2016-02-04 12:36:46 --> Router Class Initialized
INFO - 2016-02-04 12:36:46 --> Output Class Initialized
INFO - 2016-02-04 12:36:46 --> Security Class Initialized
DEBUG - 2016-02-04 12:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:36:46 --> Input Class Initialized
INFO - 2016-02-04 12:36:46 --> Language Class Initialized
INFO - 2016-02-04 12:36:46 --> Loader Class Initialized
INFO - 2016-02-04 12:36:46 --> Helper loaded: url_helper
INFO - 2016-02-04 12:36:46 --> Helper loaded: file_helper
INFO - 2016-02-04 12:36:46 --> Helper loaded: date_helper
INFO - 2016-02-04 12:36:46 --> Database Driver Class Initialized
INFO - 2016-02-04 12:36:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:36:47 --> Controller Class Initialized
INFO - 2016-02-04 12:36:47 --> Model Class Initialized
INFO - 2016-02-04 12:36:47 --> Model Class Initialized
INFO - 2016-02-04 12:36:47 --> Helper loaded: form_helper
INFO - 2016-02-04 12:36:47 --> Form Validation Class Initialized
INFO - 2016-02-04 12:36:47 --> Helper loaded: text_helper
ERROR - 2016-02-04 12:36:47 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 12:36:47 --> Config Class Initialized
INFO - 2016-02-04 12:36:47 --> Hooks Class Initialized
DEBUG - 2016-02-04 12:36:47 --> UTF-8 Support Enabled
INFO - 2016-02-04 12:36:47 --> Utf8 Class Initialized
INFO - 2016-02-04 12:36:47 --> URI Class Initialized
INFO - 2016-02-04 12:36:47 --> Router Class Initialized
INFO - 2016-02-04 12:36:47 --> Output Class Initialized
INFO - 2016-02-04 12:36:47 --> Security Class Initialized
DEBUG - 2016-02-04 12:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 12:36:47 --> Input Class Initialized
INFO - 2016-02-04 12:36:47 --> Language Class Initialized
INFO - 2016-02-04 12:36:47 --> Loader Class Initialized
INFO - 2016-02-04 12:36:47 --> Helper loaded: url_helper
INFO - 2016-02-04 12:36:47 --> Helper loaded: file_helper
INFO - 2016-02-04 12:36:47 --> Helper loaded: date_helper
INFO - 2016-02-04 12:36:47 --> Database Driver Class Initialized
INFO - 2016-02-04 12:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 12:36:48 --> Controller Class Initialized
INFO - 2016-02-04 12:36:48 --> Model Class Initialized
INFO - 2016-02-04 12:36:48 --> Model Class Initialized
INFO - 2016-02-04 12:36:48 --> Helper loaded: form_helper
INFO - 2016-02-04 12:36:48 --> Form Validation Class Initialized
INFO - 2016-02-04 12:36:48 --> Helper loaded: text_helper
INFO - 2016-02-04 12:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 12:36:48 --> Final output sent to browser
DEBUG - 2016-02-04 12:36:48 --> Total execution time: 1.1395
INFO - 2016-02-04 13:05:33 --> Config Class Initialized
INFO - 2016-02-04 13:05:33 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:33 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:33 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:33 --> URI Class Initialized
INFO - 2016-02-04 13:05:33 --> Router Class Initialized
INFO - 2016-02-04 13:05:33 --> Output Class Initialized
INFO - 2016-02-04 13:05:33 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:33 --> Input Class Initialized
INFO - 2016-02-04 13:05:33 --> Language Class Initialized
INFO - 2016-02-04 13:05:33 --> Loader Class Initialized
INFO - 2016-02-04 13:05:33 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:33 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:33 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:33 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:34 --> Controller Class Initialized
INFO - 2016-02-04 13:05:34 --> Model Class Initialized
INFO - 2016-02-04 13:05:34 --> Model Class Initialized
INFO - 2016-02-04 13:05:34 --> Helper loaded: form_helper
INFO - 2016-02-04 13:05:34 --> Form Validation Class Initialized
INFO - 2016-02-04 13:05:34 --> Helper loaded: text_helper
INFO - 2016-02-04 13:05:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:05:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:05:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:05:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:05:34 --> Final output sent to browser
DEBUG - 2016-02-04 13:05:34 --> Total execution time: 1.1502
INFO - 2016-02-04 13:05:41 --> Config Class Initialized
INFO - 2016-02-04 13:05:41 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:41 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:41 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:41 --> URI Class Initialized
INFO - 2016-02-04 13:05:41 --> Router Class Initialized
INFO - 2016-02-04 13:05:41 --> Output Class Initialized
INFO - 2016-02-04 13:05:41 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:41 --> Input Class Initialized
INFO - 2016-02-04 13:05:41 --> Language Class Initialized
INFO - 2016-02-04 13:05:41 --> Loader Class Initialized
INFO - 2016-02-04 13:05:41 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:41 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:41 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:41 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:42 --> Controller Class Initialized
INFO - 2016-02-04 13:05:42 --> Model Class Initialized
INFO - 2016-02-04 13:05:42 --> Model Class Initialized
INFO - 2016-02-04 13:05:42 --> Helper loaded: form_helper
INFO - 2016-02-04 13:05:42 --> Form Validation Class Initialized
INFO - 2016-02-04 13:05:42 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:05:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:05:42 --> Config Class Initialized
INFO - 2016-02-04 13:05:42 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:42 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:42 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:42 --> URI Class Initialized
INFO - 2016-02-04 13:05:42 --> Router Class Initialized
INFO - 2016-02-04 13:05:42 --> Output Class Initialized
INFO - 2016-02-04 13:05:42 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:42 --> Input Class Initialized
INFO - 2016-02-04 13:05:42 --> Language Class Initialized
INFO - 2016-02-04 13:05:42 --> Loader Class Initialized
INFO - 2016-02-04 13:05:42 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:42 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:42 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:42 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:44 --> Controller Class Initialized
INFO - 2016-02-04 13:05:44 --> Model Class Initialized
INFO - 2016-02-04 13:05:44 --> Model Class Initialized
INFO - 2016-02-04 13:05:44 --> Helper loaded: form_helper
INFO - 2016-02-04 13:05:44 --> Form Validation Class Initialized
INFO - 2016-02-04 13:05:44 --> Helper loaded: text_helper
INFO - 2016-02-04 13:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:05:44 --> Final output sent to browser
DEBUG - 2016-02-04 13:05:44 --> Total execution time: 1.1395
INFO - 2016-02-04 13:05:50 --> Config Class Initialized
INFO - 2016-02-04 13:05:50 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:50 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:50 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:50 --> URI Class Initialized
INFO - 2016-02-04 13:05:50 --> Router Class Initialized
INFO - 2016-02-04 13:05:50 --> Output Class Initialized
INFO - 2016-02-04 13:05:50 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:50 --> Input Class Initialized
INFO - 2016-02-04 13:05:50 --> Language Class Initialized
INFO - 2016-02-04 13:05:50 --> Loader Class Initialized
INFO - 2016-02-04 13:05:50 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:50 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:50 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:50 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:51 --> Controller Class Initialized
INFO - 2016-02-04 13:05:51 --> Model Class Initialized
INFO - 2016-02-04 13:05:51 --> Model Class Initialized
INFO - 2016-02-04 13:05:51 --> Helper loaded: form_helper
INFO - 2016-02-04 13:05:51 --> Form Validation Class Initialized
INFO - 2016-02-04 13:05:51 --> Helper loaded: text_helper
INFO - 2016-02-04 13:05:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:05:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:05:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:05:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:05:51 --> Final output sent to browser
DEBUG - 2016-02-04 13:05:51 --> Total execution time: 1.1584
INFO - 2016-02-04 13:05:56 --> Config Class Initialized
INFO - 2016-02-04 13:05:56 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:56 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:56 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:56 --> URI Class Initialized
INFO - 2016-02-04 13:05:56 --> Router Class Initialized
INFO - 2016-02-04 13:05:56 --> Output Class Initialized
INFO - 2016-02-04 13:05:56 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:56 --> Input Class Initialized
INFO - 2016-02-04 13:05:56 --> Language Class Initialized
INFO - 2016-02-04 13:05:56 --> Loader Class Initialized
INFO - 2016-02-04 13:05:56 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:56 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:56 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:56 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:57 --> Controller Class Initialized
INFO - 2016-02-04 13:05:57 --> Model Class Initialized
INFO - 2016-02-04 13:05:57 --> Model Class Initialized
INFO - 2016-02-04 13:05:57 --> Helper loaded: form_helper
INFO - 2016-02-04 13:05:57 --> Form Validation Class Initialized
INFO - 2016-02-04 13:05:57 --> Helper loaded: text_helper
INFO - 2016-02-04 13:05:57 --> Config Class Initialized
INFO - 2016-02-04 13:05:57 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:05:57 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:05:57 --> Utf8 Class Initialized
INFO - 2016-02-04 13:05:57 --> URI Class Initialized
INFO - 2016-02-04 13:05:57 --> Router Class Initialized
INFO - 2016-02-04 13:05:57 --> Output Class Initialized
INFO - 2016-02-04 13:05:57 --> Security Class Initialized
DEBUG - 2016-02-04 13:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:05:57 --> Input Class Initialized
INFO - 2016-02-04 13:05:57 --> Language Class Initialized
INFO - 2016-02-04 13:05:57 --> Loader Class Initialized
INFO - 2016-02-04 13:05:57 --> Helper loaded: url_helper
INFO - 2016-02-04 13:05:57 --> Helper loaded: file_helper
INFO - 2016-02-04 13:05:57 --> Helper loaded: date_helper
INFO - 2016-02-04 13:05:57 --> Database Driver Class Initialized
INFO - 2016-02-04 13:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:05:58 --> Controller Class Initialized
INFO - 2016-02-04 13:05:58 --> Model Class Initialized
INFO - 2016-02-04 13:05:58 --> Model Class Initialized
INFO - 2016-02-04 13:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:05:58 --> Pagination Class Initialized
INFO - 2016-02-04 13:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:05:58 --> Final output sent to browser
DEBUG - 2016-02-04 13:05:58 --> Total execution time: 1.1017
INFO - 2016-02-04 13:16:41 --> Config Class Initialized
INFO - 2016-02-04 13:16:41 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:41 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:41 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:41 --> URI Class Initialized
INFO - 2016-02-04 13:16:41 --> Router Class Initialized
INFO - 2016-02-04 13:16:41 --> Output Class Initialized
INFO - 2016-02-04 13:16:41 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:41 --> Input Class Initialized
INFO - 2016-02-04 13:16:41 --> Language Class Initialized
INFO - 2016-02-04 13:16:41 --> Loader Class Initialized
INFO - 2016-02-04 13:16:41 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:41 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:41 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:41 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:42 --> Controller Class Initialized
INFO - 2016-02-04 13:16:42 --> Model Class Initialized
INFO - 2016-02-04 13:16:42 --> Model Class Initialized
INFO - 2016-02-04 13:16:42 --> Helper loaded: form_helper
INFO - 2016-02-04 13:16:42 --> Form Validation Class Initialized
INFO - 2016-02-04 13:16:42 --> Helper loaded: text_helper
INFO - 2016-02-04 13:16:42 --> Config Class Initialized
INFO - 2016-02-04 13:16:42 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:42 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:42 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:42 --> URI Class Initialized
INFO - 2016-02-04 13:16:42 --> Router Class Initialized
INFO - 2016-02-04 13:16:42 --> Output Class Initialized
INFO - 2016-02-04 13:16:42 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:42 --> Input Class Initialized
INFO - 2016-02-04 13:16:42 --> Language Class Initialized
INFO - 2016-02-04 13:16:42 --> Loader Class Initialized
INFO - 2016-02-04 13:16:42 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:42 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:42 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:42 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:43 --> Controller Class Initialized
INFO - 2016-02-04 13:16:43 --> Model Class Initialized
INFO - 2016-02-04 13:16:43 --> Model Class Initialized
INFO - 2016-02-04 13:16:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:16:43 --> Pagination Class Initialized
INFO - 2016-02-04 13:16:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:16:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:16:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:16:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:16:43 --> Final output sent to browser
DEBUG - 2016-02-04 13:16:43 --> Total execution time: 1.1389
INFO - 2016-02-04 13:16:44 --> Config Class Initialized
INFO - 2016-02-04 13:16:44 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:44 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:44 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:44 --> URI Class Initialized
DEBUG - 2016-02-04 13:16:44 --> No URI present. Default controller set.
INFO - 2016-02-04 13:16:44 --> Router Class Initialized
INFO - 2016-02-04 13:16:44 --> Output Class Initialized
INFO - 2016-02-04 13:16:44 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:44 --> Input Class Initialized
INFO - 2016-02-04 13:16:44 --> Language Class Initialized
INFO - 2016-02-04 13:16:44 --> Loader Class Initialized
INFO - 2016-02-04 13:16:44 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:44 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:44 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:44 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:45 --> Controller Class Initialized
INFO - 2016-02-04 13:16:45 --> Model Class Initialized
INFO - 2016-02-04 13:16:45 --> Model Class Initialized
INFO - 2016-02-04 13:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:16:45 --> Pagination Class Initialized
INFO - 2016-02-04 13:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:16:45 --> Final output sent to browser
DEBUG - 2016-02-04 13:16:45 --> Total execution time: 1.1459
INFO - 2016-02-04 13:16:46 --> Config Class Initialized
INFO - 2016-02-04 13:16:46 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:46 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:46 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:46 --> URI Class Initialized
INFO - 2016-02-04 13:16:46 --> Router Class Initialized
INFO - 2016-02-04 13:16:46 --> Output Class Initialized
INFO - 2016-02-04 13:16:46 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:46 --> Input Class Initialized
INFO - 2016-02-04 13:16:46 --> Language Class Initialized
INFO - 2016-02-04 13:16:46 --> Loader Class Initialized
INFO - 2016-02-04 13:16:46 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:46 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:46 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:46 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:47 --> Controller Class Initialized
INFO - 2016-02-04 13:16:47 --> Model Class Initialized
INFO - 2016-02-04 13:16:47 --> Model Class Initialized
INFO - 2016-02-04 13:16:47 --> Helper loaded: form_helper
INFO - 2016-02-04 13:16:47 --> Form Validation Class Initialized
INFO - 2016-02-04 13:16:47 --> Helper loaded: text_helper
INFO - 2016-02-04 13:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:16:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:16:47 --> Final output sent to browser
DEBUG - 2016-02-04 13:16:47 --> Total execution time: 1.1399
INFO - 2016-02-04 13:16:52 --> Config Class Initialized
INFO - 2016-02-04 13:16:52 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:52 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:52 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:52 --> URI Class Initialized
INFO - 2016-02-04 13:16:52 --> Router Class Initialized
INFO - 2016-02-04 13:16:52 --> Output Class Initialized
INFO - 2016-02-04 13:16:52 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:52 --> Input Class Initialized
INFO - 2016-02-04 13:16:52 --> Language Class Initialized
INFO - 2016-02-04 13:16:52 --> Loader Class Initialized
INFO - 2016-02-04 13:16:52 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:52 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:52 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:52 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:53 --> Controller Class Initialized
INFO - 2016-02-04 13:16:53 --> Model Class Initialized
INFO - 2016-02-04 13:16:53 --> Model Class Initialized
INFO - 2016-02-04 13:16:53 --> Helper loaded: form_helper
INFO - 2016-02-04 13:16:53 --> Form Validation Class Initialized
INFO - 2016-02-04 13:16:53 --> Helper loaded: text_helper
INFO - 2016-02-04 13:16:53 --> Config Class Initialized
INFO - 2016-02-04 13:16:53 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:53 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:53 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:53 --> URI Class Initialized
INFO - 2016-02-04 13:16:53 --> Router Class Initialized
INFO - 2016-02-04 13:16:53 --> Output Class Initialized
INFO - 2016-02-04 13:16:53 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:53 --> Input Class Initialized
INFO - 2016-02-04 13:16:53 --> Language Class Initialized
INFO - 2016-02-04 13:16:53 --> Loader Class Initialized
INFO - 2016-02-04 13:16:53 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:53 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:53 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:53 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:54 --> Controller Class Initialized
INFO - 2016-02-04 13:16:54 --> Model Class Initialized
INFO - 2016-02-04 13:16:54 --> Model Class Initialized
INFO - 2016-02-04 13:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:16:54 --> Pagination Class Initialized
INFO - 2016-02-04 13:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:16:54 --> Final output sent to browser
DEBUG - 2016-02-04 13:16:54 --> Total execution time: 1.1084
INFO - 2016-02-04 13:16:57 --> Config Class Initialized
INFO - 2016-02-04 13:16:57 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:57 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:57 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:57 --> URI Class Initialized
INFO - 2016-02-04 13:16:57 --> Router Class Initialized
INFO - 2016-02-04 13:16:57 --> Output Class Initialized
INFO - 2016-02-04 13:16:57 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:57 --> Input Class Initialized
INFO - 2016-02-04 13:16:57 --> Language Class Initialized
INFO - 2016-02-04 13:16:57 --> Loader Class Initialized
INFO - 2016-02-04 13:16:57 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:57 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:57 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:57 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:58 --> Controller Class Initialized
INFO - 2016-02-04 13:16:58 --> Model Class Initialized
INFO - 2016-02-04 13:16:58 --> Model Class Initialized
INFO - 2016-02-04 13:16:58 --> Helper loaded: form_helper
INFO - 2016-02-04 13:16:58 --> Form Validation Class Initialized
INFO - 2016-02-04 13:16:58 --> Helper loaded: text_helper
INFO - 2016-02-04 13:16:58 --> Config Class Initialized
INFO - 2016-02-04 13:16:58 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:16:58 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:16:58 --> Utf8 Class Initialized
INFO - 2016-02-04 13:16:58 --> URI Class Initialized
INFO - 2016-02-04 13:16:58 --> Router Class Initialized
INFO - 2016-02-04 13:16:58 --> Output Class Initialized
INFO - 2016-02-04 13:16:58 --> Security Class Initialized
DEBUG - 2016-02-04 13:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:16:58 --> Input Class Initialized
INFO - 2016-02-04 13:16:58 --> Language Class Initialized
INFO - 2016-02-04 13:16:58 --> Loader Class Initialized
INFO - 2016-02-04 13:16:58 --> Helper loaded: url_helper
INFO - 2016-02-04 13:16:58 --> Helper loaded: file_helper
INFO - 2016-02-04 13:16:58 --> Helper loaded: date_helper
INFO - 2016-02-04 13:16:58 --> Database Driver Class Initialized
INFO - 2016-02-04 13:16:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:16:59 --> Controller Class Initialized
INFO - 2016-02-04 13:16:59 --> Model Class Initialized
INFO - 2016-02-04 13:16:59 --> Model Class Initialized
INFO - 2016-02-04 13:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:16:59 --> Pagination Class Initialized
INFO - 2016-02-04 13:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:16:59 --> Final output sent to browser
DEBUG - 2016-02-04 13:16:59 --> Total execution time: 1.1192
INFO - 2016-02-04 13:17:01 --> Config Class Initialized
INFO - 2016-02-04 13:17:01 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:01 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:01 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:01 --> URI Class Initialized
INFO - 2016-02-04 13:17:01 --> Router Class Initialized
INFO - 2016-02-04 13:17:01 --> Output Class Initialized
INFO - 2016-02-04 13:17:01 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:01 --> Input Class Initialized
INFO - 2016-02-04 13:17:01 --> Language Class Initialized
INFO - 2016-02-04 13:17:01 --> Loader Class Initialized
INFO - 2016-02-04 13:17:01 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:01 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:01 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:01 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:02 --> Controller Class Initialized
INFO - 2016-02-04 13:17:02 --> Model Class Initialized
INFO - 2016-02-04 13:17:02 --> Model Class Initialized
INFO - 2016-02-04 13:17:02 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:02 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:02 --> Helper loaded: text_helper
INFO - 2016-02-04 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:17:02 --> Final output sent to browser
DEBUG - 2016-02-04 13:17:02 --> Total execution time: 1.1208
INFO - 2016-02-04 13:17:07 --> Config Class Initialized
INFO - 2016-02-04 13:17:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:07 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:07 --> URI Class Initialized
INFO - 2016-02-04 13:17:07 --> Router Class Initialized
INFO - 2016-02-04 13:17:07 --> Output Class Initialized
INFO - 2016-02-04 13:17:07 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:07 --> Input Class Initialized
INFO - 2016-02-04 13:17:07 --> Language Class Initialized
INFO - 2016-02-04 13:17:07 --> Loader Class Initialized
INFO - 2016-02-04 13:17:07 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:07 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:07 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:07 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:08 --> Controller Class Initialized
INFO - 2016-02-04 13:17:08 --> Model Class Initialized
INFO - 2016-02-04 13:17:08 --> Model Class Initialized
INFO - 2016-02-04 13:17:08 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:08 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:08 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:17:08 --> Config Class Initialized
INFO - 2016-02-04 13:17:08 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:08 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:08 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:08 --> URI Class Initialized
INFO - 2016-02-04 13:17:08 --> Router Class Initialized
INFO - 2016-02-04 13:17:08 --> Output Class Initialized
INFO - 2016-02-04 13:17:08 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:08 --> Input Class Initialized
INFO - 2016-02-04 13:17:08 --> Language Class Initialized
INFO - 2016-02-04 13:17:08 --> Loader Class Initialized
INFO - 2016-02-04 13:17:08 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:08 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:08 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:08 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:09 --> Controller Class Initialized
INFO - 2016-02-04 13:17:09 --> Model Class Initialized
INFO - 2016-02-04 13:17:09 --> Model Class Initialized
INFO - 2016-02-04 13:17:09 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:09 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:09 --> Helper loaded: text_helper
INFO - 2016-02-04 13:17:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:17:09 --> Final output sent to browser
DEBUG - 2016-02-04 13:17:09 --> Total execution time: 1.1317
INFO - 2016-02-04 13:17:13 --> Config Class Initialized
INFO - 2016-02-04 13:17:13 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:13 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:13 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:13 --> URI Class Initialized
INFO - 2016-02-04 13:17:13 --> Router Class Initialized
INFO - 2016-02-04 13:17:13 --> Output Class Initialized
INFO - 2016-02-04 13:17:13 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:13 --> Input Class Initialized
INFO - 2016-02-04 13:17:13 --> Language Class Initialized
INFO - 2016-02-04 13:17:13 --> Loader Class Initialized
INFO - 2016-02-04 13:17:13 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:13 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:13 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:13 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:14 --> Controller Class Initialized
INFO - 2016-02-04 13:17:14 --> Model Class Initialized
INFO - 2016-02-04 13:17:14 --> Model Class Initialized
INFO - 2016-02-04 13:17:14 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:14 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:14 --> Helper loaded: text_helper
INFO - 2016-02-04 13:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:17:14 --> Final output sent to browser
DEBUG - 2016-02-04 13:17:14 --> Total execution time: 1.0990
INFO - 2016-02-04 13:17:23 --> Config Class Initialized
INFO - 2016-02-04 13:17:23 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:23 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:23 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:23 --> URI Class Initialized
INFO - 2016-02-04 13:17:23 --> Router Class Initialized
INFO - 2016-02-04 13:17:23 --> Output Class Initialized
INFO - 2016-02-04 13:17:23 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:23 --> Input Class Initialized
INFO - 2016-02-04 13:17:23 --> Language Class Initialized
INFO - 2016-02-04 13:17:23 --> Loader Class Initialized
INFO - 2016-02-04 13:17:23 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:23 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:23 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:23 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:24 --> Controller Class Initialized
INFO - 2016-02-04 13:17:24 --> Model Class Initialized
INFO - 2016-02-04 13:17:24 --> Model Class Initialized
INFO - 2016-02-04 13:17:24 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:24 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:24 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:17:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:17:24 --> Config Class Initialized
INFO - 2016-02-04 13:17:24 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:17:24 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:17:24 --> Utf8 Class Initialized
INFO - 2016-02-04 13:17:24 --> URI Class Initialized
INFO - 2016-02-04 13:17:24 --> Router Class Initialized
INFO - 2016-02-04 13:17:24 --> Output Class Initialized
INFO - 2016-02-04 13:17:24 --> Security Class Initialized
DEBUG - 2016-02-04 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:17:24 --> Input Class Initialized
INFO - 2016-02-04 13:17:24 --> Language Class Initialized
INFO - 2016-02-04 13:17:24 --> Loader Class Initialized
INFO - 2016-02-04 13:17:24 --> Helper loaded: url_helper
INFO - 2016-02-04 13:17:24 --> Helper loaded: file_helper
INFO - 2016-02-04 13:17:24 --> Helper loaded: date_helper
INFO - 2016-02-04 13:17:24 --> Database Driver Class Initialized
INFO - 2016-02-04 13:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:17:25 --> Controller Class Initialized
INFO - 2016-02-04 13:17:25 --> Model Class Initialized
INFO - 2016-02-04 13:17:25 --> Model Class Initialized
INFO - 2016-02-04 13:17:25 --> Helper loaded: form_helper
INFO - 2016-02-04 13:17:25 --> Form Validation Class Initialized
INFO - 2016-02-04 13:17:25 --> Helper loaded: text_helper
INFO - 2016-02-04 13:17:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:17:25 --> Final output sent to browser
DEBUG - 2016-02-04 13:17:25 --> Total execution time: 1.1796
INFO - 2016-02-04 13:19:42 --> Config Class Initialized
INFO - 2016-02-04 13:19:42 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:19:42 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:19:42 --> Utf8 Class Initialized
INFO - 2016-02-04 13:19:42 --> URI Class Initialized
INFO - 2016-02-04 13:19:42 --> Router Class Initialized
INFO - 2016-02-04 13:19:42 --> Output Class Initialized
INFO - 2016-02-04 13:19:42 --> Security Class Initialized
DEBUG - 2016-02-04 13:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:19:42 --> Input Class Initialized
INFO - 2016-02-04 13:19:42 --> Language Class Initialized
INFO - 2016-02-04 13:19:42 --> Loader Class Initialized
INFO - 2016-02-04 13:19:42 --> Helper loaded: url_helper
INFO - 2016-02-04 13:19:42 --> Helper loaded: file_helper
INFO - 2016-02-04 13:19:42 --> Helper loaded: date_helper
INFO - 2016-02-04 13:19:42 --> Database Driver Class Initialized
INFO - 2016-02-04 13:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:19:43 --> Controller Class Initialized
INFO - 2016-02-04 13:19:43 --> Model Class Initialized
INFO - 2016-02-04 13:19:43 --> Model Class Initialized
INFO - 2016-02-04 13:19:43 --> Helper loaded: form_helper
INFO - 2016-02-04 13:19:43 --> Form Validation Class Initialized
INFO - 2016-02-04 13:19:43 --> Helper loaded: text_helper
INFO - 2016-02-04 13:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:19:43 --> Final output sent to browser
DEBUG - 2016-02-04 13:19:43 --> Total execution time: 1.1197
INFO - 2016-02-04 13:19:46 --> Config Class Initialized
INFO - 2016-02-04 13:19:46 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:19:46 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:19:46 --> Utf8 Class Initialized
INFO - 2016-02-04 13:19:46 --> URI Class Initialized
INFO - 2016-02-04 13:19:46 --> Router Class Initialized
INFO - 2016-02-04 13:19:46 --> Output Class Initialized
INFO - 2016-02-04 13:19:46 --> Security Class Initialized
DEBUG - 2016-02-04 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:19:46 --> Input Class Initialized
INFO - 2016-02-04 13:19:46 --> Language Class Initialized
INFO - 2016-02-04 13:19:46 --> Loader Class Initialized
INFO - 2016-02-04 13:19:46 --> Helper loaded: url_helper
INFO - 2016-02-04 13:19:46 --> Helper loaded: file_helper
INFO - 2016-02-04 13:19:46 --> Helper loaded: date_helper
INFO - 2016-02-04 13:19:46 --> Database Driver Class Initialized
INFO - 2016-02-04 13:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:19:47 --> Controller Class Initialized
INFO - 2016-02-04 13:19:47 --> Model Class Initialized
INFO - 2016-02-04 13:19:47 --> Model Class Initialized
INFO - 2016-02-04 13:19:47 --> Helper loaded: form_helper
INFO - 2016-02-04 13:19:47 --> Form Validation Class Initialized
INFO - 2016-02-04 13:19:47 --> Helper loaded: text_helper
INFO - 2016-02-04 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:19:47 --> Final output sent to browser
DEBUG - 2016-02-04 13:19:47 --> Total execution time: 1.1323
INFO - 2016-02-04 13:19:52 --> Config Class Initialized
INFO - 2016-02-04 13:19:52 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:19:52 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:19:52 --> Utf8 Class Initialized
INFO - 2016-02-04 13:19:52 --> URI Class Initialized
INFO - 2016-02-04 13:19:52 --> Router Class Initialized
INFO - 2016-02-04 13:19:52 --> Output Class Initialized
INFO - 2016-02-04 13:19:52 --> Security Class Initialized
DEBUG - 2016-02-04 13:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:19:52 --> Input Class Initialized
INFO - 2016-02-04 13:19:52 --> Language Class Initialized
INFO - 2016-02-04 13:19:52 --> Loader Class Initialized
INFO - 2016-02-04 13:19:52 --> Helper loaded: url_helper
INFO - 2016-02-04 13:19:53 --> Helper loaded: file_helper
INFO - 2016-02-04 13:19:53 --> Helper loaded: date_helper
INFO - 2016-02-04 13:19:53 --> Database Driver Class Initialized
INFO - 2016-02-04 13:19:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:19:54 --> Controller Class Initialized
INFO - 2016-02-04 13:19:54 --> Model Class Initialized
INFO - 2016-02-04 13:19:54 --> Model Class Initialized
INFO - 2016-02-04 13:19:54 --> Helper loaded: form_helper
INFO - 2016-02-04 13:19:54 --> Form Validation Class Initialized
INFO - 2016-02-04 13:19:54 --> Helper loaded: text_helper
INFO - 2016-02-04 13:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:19:54 --> Final output sent to browser
DEBUG - 2016-02-04 13:19:54 --> Total execution time: 1.1387
INFO - 2016-02-04 13:21:00 --> Config Class Initialized
INFO - 2016-02-04 13:21:00 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:21:00 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:21:00 --> Utf8 Class Initialized
INFO - 2016-02-04 13:21:00 --> URI Class Initialized
INFO - 2016-02-04 13:21:00 --> Router Class Initialized
INFO - 2016-02-04 13:21:00 --> Output Class Initialized
INFO - 2016-02-04 13:21:00 --> Security Class Initialized
DEBUG - 2016-02-04 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:21:00 --> Input Class Initialized
INFO - 2016-02-04 13:21:00 --> Language Class Initialized
INFO - 2016-02-04 13:21:00 --> Loader Class Initialized
INFO - 2016-02-04 13:21:00 --> Helper loaded: url_helper
INFO - 2016-02-04 13:21:00 --> Helper loaded: file_helper
INFO - 2016-02-04 13:21:00 --> Helper loaded: date_helper
INFO - 2016-02-04 13:21:00 --> Database Driver Class Initialized
INFO - 2016-02-04 13:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:21:01 --> Controller Class Initialized
INFO - 2016-02-04 13:21:01 --> Model Class Initialized
INFO - 2016-02-04 13:21:01 --> Model Class Initialized
INFO - 2016-02-04 13:21:01 --> Helper loaded: form_helper
INFO - 2016-02-04 13:21:01 --> Form Validation Class Initialized
INFO - 2016-02-04 13:21:01 --> Helper loaded: text_helper
INFO - 2016-02-04 13:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:21:01 --> Final output sent to browser
DEBUG - 2016-02-04 13:21:01 --> Total execution time: 1.1584
INFO - 2016-02-04 13:22:11 --> Config Class Initialized
INFO - 2016-02-04 13:22:11 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:22:11 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:22:11 --> Utf8 Class Initialized
INFO - 2016-02-04 13:22:11 --> URI Class Initialized
INFO - 2016-02-04 13:22:11 --> Router Class Initialized
INFO - 2016-02-04 13:22:11 --> Output Class Initialized
INFO - 2016-02-04 13:22:12 --> Security Class Initialized
DEBUG - 2016-02-04 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:22:12 --> Input Class Initialized
INFO - 2016-02-04 13:22:12 --> Language Class Initialized
INFO - 2016-02-04 13:22:12 --> Loader Class Initialized
INFO - 2016-02-04 13:22:12 --> Helper loaded: url_helper
INFO - 2016-02-04 13:22:12 --> Helper loaded: file_helper
INFO - 2016-02-04 13:22:12 --> Helper loaded: date_helper
INFO - 2016-02-04 13:22:12 --> Database Driver Class Initialized
INFO - 2016-02-04 13:22:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:22:13 --> Controller Class Initialized
INFO - 2016-02-04 13:22:13 --> Model Class Initialized
INFO - 2016-02-04 13:22:13 --> Model Class Initialized
INFO - 2016-02-04 13:22:13 --> Helper loaded: form_helper
INFO - 2016-02-04 13:22:13 --> Form Validation Class Initialized
INFO - 2016-02-04 13:22:13 --> Helper loaded: text_helper
INFO - 2016-02-04 13:22:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:22:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:22:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:22:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:22:13 --> Final output sent to browser
DEBUG - 2016-02-04 13:22:13 --> Total execution time: 1.1576
INFO - 2016-02-04 13:23:07 --> Config Class Initialized
INFO - 2016-02-04 13:23:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:23:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:23:07 --> Utf8 Class Initialized
INFO - 2016-02-04 13:23:07 --> URI Class Initialized
INFO - 2016-02-04 13:23:07 --> Router Class Initialized
INFO - 2016-02-04 13:23:07 --> Output Class Initialized
INFO - 2016-02-04 13:23:07 --> Security Class Initialized
DEBUG - 2016-02-04 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:23:07 --> Input Class Initialized
INFO - 2016-02-04 13:23:07 --> Language Class Initialized
INFO - 2016-02-04 13:23:07 --> Loader Class Initialized
INFO - 2016-02-04 13:23:07 --> Helper loaded: url_helper
INFO - 2016-02-04 13:23:07 --> Helper loaded: file_helper
INFO - 2016-02-04 13:23:07 --> Helper loaded: date_helper
INFO - 2016-02-04 13:23:07 --> Database Driver Class Initialized
INFO - 2016-02-04 13:23:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:23:08 --> Controller Class Initialized
INFO - 2016-02-04 13:23:08 --> Model Class Initialized
INFO - 2016-02-04 13:23:08 --> Model Class Initialized
INFO - 2016-02-04 13:23:08 --> Helper loaded: form_helper
INFO - 2016-02-04 13:23:08 --> Form Validation Class Initialized
INFO - 2016-02-04 13:23:08 --> Helper loaded: text_helper
INFO - 2016-02-04 13:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:23:08 --> Final output sent to browser
DEBUG - 2016-02-04 13:23:08 --> Total execution time: 1.1585
INFO - 2016-02-04 13:23:17 --> Config Class Initialized
INFO - 2016-02-04 13:23:17 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:23:17 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:23:17 --> Utf8 Class Initialized
INFO - 2016-02-04 13:23:17 --> URI Class Initialized
INFO - 2016-02-04 13:23:17 --> Router Class Initialized
INFO - 2016-02-04 13:23:17 --> Output Class Initialized
INFO - 2016-02-04 13:23:17 --> Security Class Initialized
DEBUG - 2016-02-04 13:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:23:17 --> Input Class Initialized
INFO - 2016-02-04 13:23:17 --> Language Class Initialized
INFO - 2016-02-04 13:23:17 --> Loader Class Initialized
INFO - 2016-02-04 13:23:17 --> Helper loaded: url_helper
INFO - 2016-02-04 13:23:17 --> Helper loaded: file_helper
INFO - 2016-02-04 13:23:17 --> Helper loaded: date_helper
INFO - 2016-02-04 13:23:17 --> Database Driver Class Initialized
INFO - 2016-02-04 13:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:23:18 --> Controller Class Initialized
INFO - 2016-02-04 13:23:18 --> Model Class Initialized
INFO - 2016-02-04 13:23:18 --> Model Class Initialized
INFO - 2016-02-04 13:23:18 --> Helper loaded: form_helper
INFO - 2016-02-04 13:23:18 --> Form Validation Class Initialized
INFO - 2016-02-04 13:23:18 --> Helper loaded: text_helper
INFO - 2016-02-04 13:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:23:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:23:18 --> Final output sent to browser
DEBUG - 2016-02-04 13:23:18 --> Total execution time: 1.1027
INFO - 2016-02-04 13:23:58 --> Config Class Initialized
INFO - 2016-02-04 13:23:58 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:23:58 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:23:58 --> Utf8 Class Initialized
INFO - 2016-02-04 13:23:58 --> URI Class Initialized
INFO - 2016-02-04 13:23:58 --> Router Class Initialized
INFO - 2016-02-04 13:23:58 --> Output Class Initialized
INFO - 2016-02-04 13:23:58 --> Security Class Initialized
DEBUG - 2016-02-04 13:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:23:58 --> Input Class Initialized
INFO - 2016-02-04 13:23:58 --> Language Class Initialized
INFO - 2016-02-04 13:23:58 --> Loader Class Initialized
INFO - 2016-02-04 13:23:58 --> Helper loaded: url_helper
INFO - 2016-02-04 13:23:58 --> Helper loaded: file_helper
INFO - 2016-02-04 13:23:58 --> Helper loaded: date_helper
INFO - 2016-02-04 13:23:58 --> Database Driver Class Initialized
INFO - 2016-02-04 13:23:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:23:59 --> Controller Class Initialized
INFO - 2016-02-04 13:23:59 --> Model Class Initialized
INFO - 2016-02-04 13:23:59 --> Model Class Initialized
INFO - 2016-02-04 13:23:59 --> Helper loaded: form_helper
INFO - 2016-02-04 13:23:59 --> Form Validation Class Initialized
INFO - 2016-02-04 13:23:59 --> Helper loaded: text_helper
INFO - 2016-02-04 13:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:23:59 --> Final output sent to browser
DEBUG - 2016-02-04 13:23:59 --> Total execution time: 1.1586
INFO - 2016-02-04 13:24:08 --> Config Class Initialized
INFO - 2016-02-04 13:24:08 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:24:08 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:24:08 --> Utf8 Class Initialized
INFO - 2016-02-04 13:24:08 --> URI Class Initialized
INFO - 2016-02-04 13:24:08 --> Router Class Initialized
INFO - 2016-02-04 13:24:08 --> Output Class Initialized
INFO - 2016-02-04 13:24:08 --> Security Class Initialized
DEBUG - 2016-02-04 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:24:08 --> Input Class Initialized
INFO - 2016-02-04 13:24:08 --> Language Class Initialized
INFO - 2016-02-04 13:24:08 --> Loader Class Initialized
INFO - 2016-02-04 13:24:08 --> Helper loaded: url_helper
INFO - 2016-02-04 13:24:08 --> Helper loaded: file_helper
INFO - 2016-02-04 13:24:08 --> Helper loaded: date_helper
INFO - 2016-02-04 13:24:08 --> Database Driver Class Initialized
INFO - 2016-02-04 13:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:24:09 --> Controller Class Initialized
INFO - 2016-02-04 13:24:09 --> Model Class Initialized
INFO - 2016-02-04 13:24:09 --> Model Class Initialized
INFO - 2016-02-04 13:24:09 --> Helper loaded: form_helper
INFO - 2016-02-04 13:24:09 --> Form Validation Class Initialized
INFO - 2016-02-04 13:24:09 --> Helper loaded: text_helper
INFO - 2016-02-04 13:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:24:09 --> Final output sent to browser
DEBUG - 2016-02-04 13:24:09 --> Total execution time: 1.1041
INFO - 2016-02-04 13:24:18 --> Config Class Initialized
INFO - 2016-02-04 13:24:18 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:24:18 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:24:18 --> Utf8 Class Initialized
INFO - 2016-02-04 13:24:18 --> URI Class Initialized
INFO - 2016-02-04 13:24:18 --> Router Class Initialized
INFO - 2016-02-04 13:24:18 --> Output Class Initialized
INFO - 2016-02-04 13:24:18 --> Security Class Initialized
DEBUG - 2016-02-04 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:24:18 --> Input Class Initialized
INFO - 2016-02-04 13:24:18 --> Language Class Initialized
INFO - 2016-02-04 13:24:18 --> Loader Class Initialized
INFO - 2016-02-04 13:24:18 --> Helper loaded: url_helper
INFO - 2016-02-04 13:24:18 --> Helper loaded: file_helper
INFO - 2016-02-04 13:24:18 --> Helper loaded: date_helper
INFO - 2016-02-04 13:24:18 --> Database Driver Class Initialized
INFO - 2016-02-04 13:24:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:24:19 --> Controller Class Initialized
INFO - 2016-02-04 13:24:19 --> Model Class Initialized
INFO - 2016-02-04 13:24:19 --> Model Class Initialized
INFO - 2016-02-04 13:24:19 --> Helper loaded: form_helper
INFO - 2016-02-04 13:24:19 --> Form Validation Class Initialized
INFO - 2016-02-04 13:24:19 --> Helper loaded: text_helper
INFO - 2016-02-04 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:24:19 --> Final output sent to browser
DEBUG - 2016-02-04 13:24:19 --> Total execution time: 1.0989
INFO - 2016-02-04 13:26:28 --> Config Class Initialized
INFO - 2016-02-04 13:26:28 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:26:28 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:26:28 --> Utf8 Class Initialized
INFO - 2016-02-04 13:26:28 --> URI Class Initialized
DEBUG - 2016-02-04 13:26:28 --> No URI present. Default controller set.
INFO - 2016-02-04 13:26:28 --> Router Class Initialized
INFO - 2016-02-04 13:26:28 --> Output Class Initialized
INFO - 2016-02-04 13:26:28 --> Security Class Initialized
DEBUG - 2016-02-04 13:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:26:28 --> Input Class Initialized
INFO - 2016-02-04 13:26:28 --> Language Class Initialized
INFO - 2016-02-04 13:26:28 --> Loader Class Initialized
INFO - 2016-02-04 13:26:28 --> Helper loaded: url_helper
INFO - 2016-02-04 13:26:28 --> Helper loaded: file_helper
INFO - 2016-02-04 13:26:28 --> Helper loaded: date_helper
INFO - 2016-02-04 13:26:28 --> Helper loaded: form_helper
INFO - 2016-02-04 13:26:28 --> Database Driver Class Initialized
INFO - 2016-02-04 13:26:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:26:29 --> Controller Class Initialized
INFO - 2016-02-04 13:26:29 --> Model Class Initialized
INFO - 2016-02-04 13:26:29 --> Model Class Initialized
INFO - 2016-02-04 13:26:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:26:29 --> Pagination Class Initialized
INFO - 2016-02-04 13:26:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:26:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:26:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:26:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:26:29 --> Final output sent to browser
DEBUG - 2016-02-04 13:26:29 --> Total execution time: 1.1424
INFO - 2016-02-04 13:26:32 --> Config Class Initialized
INFO - 2016-02-04 13:26:32 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:26:32 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:26:32 --> Utf8 Class Initialized
INFO - 2016-02-04 13:26:32 --> URI Class Initialized
INFO - 2016-02-04 13:26:32 --> Router Class Initialized
INFO - 2016-02-04 13:26:32 --> Output Class Initialized
INFO - 2016-02-04 13:26:32 --> Security Class Initialized
DEBUG - 2016-02-04 13:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:26:32 --> Input Class Initialized
INFO - 2016-02-04 13:26:32 --> Language Class Initialized
INFO - 2016-02-04 13:26:32 --> Loader Class Initialized
INFO - 2016-02-04 13:26:32 --> Helper loaded: url_helper
INFO - 2016-02-04 13:26:32 --> Helper loaded: file_helper
INFO - 2016-02-04 13:26:32 --> Helper loaded: date_helper
INFO - 2016-02-04 13:26:32 --> Helper loaded: form_helper
INFO - 2016-02-04 13:26:32 --> Database Driver Class Initialized
INFO - 2016-02-04 13:26:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:26:33 --> Controller Class Initialized
INFO - 2016-02-04 13:26:33 --> Model Class Initialized
INFO - 2016-02-04 13:26:33 --> Model Class Initialized
INFO - 2016-02-04 13:26:33 --> Form Validation Class Initialized
INFO - 2016-02-04 13:26:33 --> Helper loaded: text_helper
INFO - 2016-02-04 13:26:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:26:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:26:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:26:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:26:33 --> Final output sent to browser
DEBUG - 2016-02-04 13:26:33 --> Total execution time: 1.1385
INFO - 2016-02-04 13:26:37 --> Config Class Initialized
INFO - 2016-02-04 13:26:37 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:26:37 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:26:37 --> Utf8 Class Initialized
INFO - 2016-02-04 13:26:37 --> URI Class Initialized
INFO - 2016-02-04 13:26:37 --> Router Class Initialized
INFO - 2016-02-04 13:26:37 --> Output Class Initialized
INFO - 2016-02-04 13:26:37 --> Security Class Initialized
DEBUG - 2016-02-04 13:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:26:37 --> Input Class Initialized
INFO - 2016-02-04 13:26:37 --> Language Class Initialized
INFO - 2016-02-04 13:26:37 --> Loader Class Initialized
INFO - 2016-02-04 13:26:37 --> Helper loaded: url_helper
INFO - 2016-02-04 13:26:37 --> Helper loaded: file_helper
INFO - 2016-02-04 13:26:37 --> Helper loaded: date_helper
INFO - 2016-02-04 13:26:37 --> Helper loaded: form_helper
INFO - 2016-02-04 13:26:37 --> Database Driver Class Initialized
INFO - 2016-02-04 13:26:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:26:38 --> Controller Class Initialized
INFO - 2016-02-04 13:26:38 --> Model Class Initialized
INFO - 2016-02-04 13:26:38 --> Model Class Initialized
INFO - 2016-02-04 13:26:38 --> Form Validation Class Initialized
INFO - 2016-02-04 13:26:38 --> Helper loaded: text_helper
INFO - 2016-02-04 13:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:26:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:26:38 --> Final output sent to browser
DEBUG - 2016-02-04 13:26:38 --> Total execution time: 1.1235
INFO - 2016-02-04 13:30:00 --> Config Class Initialized
INFO - 2016-02-04 13:30:01 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:30:01 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:30:01 --> Utf8 Class Initialized
INFO - 2016-02-04 13:30:01 --> URI Class Initialized
INFO - 2016-02-04 13:30:01 --> Router Class Initialized
INFO - 2016-02-04 13:30:01 --> Output Class Initialized
INFO - 2016-02-04 13:30:01 --> Security Class Initialized
DEBUG - 2016-02-04 13:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:30:01 --> Input Class Initialized
INFO - 2016-02-04 13:30:01 --> Language Class Initialized
INFO - 2016-02-04 13:30:01 --> Loader Class Initialized
INFO - 2016-02-04 13:30:01 --> Helper loaded: url_helper
INFO - 2016-02-04 13:30:01 --> Helper loaded: file_helper
INFO - 2016-02-04 13:30:01 --> Helper loaded: date_helper
INFO - 2016-02-04 13:30:01 --> Helper loaded: form_helper
INFO - 2016-02-04 13:30:01 --> Database Driver Class Initialized
INFO - 2016-02-04 13:30:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:30:02 --> Controller Class Initialized
INFO - 2016-02-04 13:30:02 --> Model Class Initialized
INFO - 2016-02-04 13:30:02 --> Model Class Initialized
INFO - 2016-02-04 13:30:02 --> Form Validation Class Initialized
INFO - 2016-02-04 13:30:02 --> Helper loaded: text_helper
INFO - 2016-02-04 13:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:30:02 --> Final output sent to browser
DEBUG - 2016-02-04 13:30:02 --> Total execution time: 1.1684
INFO - 2016-02-04 13:30:07 --> Config Class Initialized
INFO - 2016-02-04 13:30:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:30:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:30:07 --> Utf8 Class Initialized
INFO - 2016-02-04 13:30:07 --> URI Class Initialized
INFO - 2016-02-04 13:30:07 --> Router Class Initialized
INFO - 2016-02-04 13:30:07 --> Output Class Initialized
INFO - 2016-02-04 13:30:07 --> Security Class Initialized
DEBUG - 2016-02-04 13:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:30:07 --> Input Class Initialized
INFO - 2016-02-04 13:30:07 --> Language Class Initialized
INFO - 2016-02-04 13:30:07 --> Loader Class Initialized
INFO - 2016-02-04 13:30:07 --> Helper loaded: url_helper
INFO - 2016-02-04 13:30:07 --> Helper loaded: file_helper
INFO - 2016-02-04 13:30:07 --> Helper loaded: date_helper
INFO - 2016-02-04 13:30:07 --> Helper loaded: form_helper
INFO - 2016-02-04 13:30:07 --> Database Driver Class Initialized
INFO - 2016-02-04 13:30:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:30:09 --> Controller Class Initialized
INFO - 2016-02-04 13:30:09 --> Model Class Initialized
INFO - 2016-02-04 13:30:09 --> Model Class Initialized
INFO - 2016-02-04 13:30:09 --> Form Validation Class Initialized
INFO - 2016-02-04 13:30:09 --> Helper loaded: text_helper
INFO - 2016-02-04 13:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:30:09 --> Final output sent to browser
DEBUG - 2016-02-04 13:30:09 --> Total execution time: 1.1250
INFO - 2016-02-04 13:31:43 --> Config Class Initialized
INFO - 2016-02-04 13:31:43 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:31:43 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:31:43 --> Utf8 Class Initialized
INFO - 2016-02-04 13:31:43 --> URI Class Initialized
DEBUG - 2016-02-04 13:31:43 --> No URI present. Default controller set.
INFO - 2016-02-04 13:31:43 --> Router Class Initialized
INFO - 2016-02-04 13:31:43 --> Output Class Initialized
INFO - 2016-02-04 13:31:43 --> Security Class Initialized
DEBUG - 2016-02-04 13:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:31:43 --> Input Class Initialized
INFO - 2016-02-04 13:31:43 --> Language Class Initialized
INFO - 2016-02-04 13:31:43 --> Loader Class Initialized
INFO - 2016-02-04 13:31:43 --> Helper loaded: url_helper
INFO - 2016-02-04 13:31:43 --> Helper loaded: file_helper
INFO - 2016-02-04 13:31:43 --> Helper loaded: date_helper
INFO - 2016-02-04 13:31:43 --> Helper loaded: form_helper
INFO - 2016-02-04 13:31:43 --> Database Driver Class Initialized
INFO - 2016-02-04 13:31:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:31:44 --> Controller Class Initialized
INFO - 2016-02-04 13:31:44 --> Model Class Initialized
INFO - 2016-02-04 13:31:44 --> Model Class Initialized
INFO - 2016-02-04 13:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:31:44 --> Pagination Class Initialized
INFO - 2016-02-04 13:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:31:44 --> Final output sent to browser
DEBUG - 2016-02-04 13:31:44 --> Total execution time: 1.1564
INFO - 2016-02-04 13:32:05 --> Config Class Initialized
INFO - 2016-02-04 13:32:05 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:05 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:05 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:05 --> URI Class Initialized
INFO - 2016-02-04 13:32:05 --> Router Class Initialized
INFO - 2016-02-04 13:32:05 --> Output Class Initialized
INFO - 2016-02-04 13:32:05 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:05 --> Input Class Initialized
INFO - 2016-02-04 13:32:05 --> Language Class Initialized
INFO - 2016-02-04 13:32:05 --> Loader Class Initialized
INFO - 2016-02-04 13:32:05 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:05 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:05 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:05 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:05 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:06 --> Controller Class Initialized
INFO - 2016-02-04 13:32:06 --> Model Class Initialized
INFO - 2016-02-04 13:32:06 --> Model Class Initialized
INFO - 2016-02-04 13:32:06 --> Form Validation Class Initialized
INFO - 2016-02-04 13:32:06 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:32:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
ERROR - 2016-02-04 13:32:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:32:07 --> Config Class Initialized
INFO - 2016-02-04 13:32:07 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:07 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:07 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:07 --> URI Class Initialized
INFO - 2016-02-04 13:32:07 --> Router Class Initialized
INFO - 2016-02-04 13:32:07 --> Output Class Initialized
INFO - 2016-02-04 13:32:07 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:07 --> Input Class Initialized
INFO - 2016-02-04 13:32:07 --> Language Class Initialized
INFO - 2016-02-04 13:32:07 --> Loader Class Initialized
INFO - 2016-02-04 13:32:07 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:07 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:07 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:07 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:07 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:08 --> Controller Class Initialized
INFO - 2016-02-04 13:32:08 --> Model Class Initialized
INFO - 2016-02-04 13:32:08 --> Model Class Initialized
INFO - 2016-02-04 13:32:08 --> Form Validation Class Initialized
INFO - 2016-02-04 13:32:08 --> Helper loaded: text_helper
INFO - 2016-02-04 13:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:32:08 --> Final output sent to browser
DEBUG - 2016-02-04 13:32:08 --> Total execution time: 1.1362
INFO - 2016-02-04 13:32:29 --> Config Class Initialized
INFO - 2016-02-04 13:32:29 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:29 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:29 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:29 --> URI Class Initialized
DEBUG - 2016-02-04 13:32:29 --> No URI present. Default controller set.
INFO - 2016-02-04 13:32:29 --> Router Class Initialized
INFO - 2016-02-04 13:32:29 --> Output Class Initialized
INFO - 2016-02-04 13:32:29 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:29 --> Input Class Initialized
INFO - 2016-02-04 13:32:29 --> Language Class Initialized
INFO - 2016-02-04 13:32:29 --> Loader Class Initialized
INFO - 2016-02-04 13:32:29 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:29 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:29 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:29 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:29 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:30 --> Controller Class Initialized
INFO - 2016-02-04 13:32:30 --> Model Class Initialized
INFO - 2016-02-04 13:32:30 --> Model Class Initialized
INFO - 2016-02-04 13:32:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:32:30 --> Pagination Class Initialized
INFO - 2016-02-04 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:32:30 --> Final output sent to browser
DEBUG - 2016-02-04 13:32:30 --> Total execution time: 1.1325
INFO - 2016-02-04 13:32:37 --> Config Class Initialized
INFO - 2016-02-04 13:32:37 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:37 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:37 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:37 --> URI Class Initialized
INFO - 2016-02-04 13:32:37 --> Router Class Initialized
INFO - 2016-02-04 13:32:37 --> Output Class Initialized
INFO - 2016-02-04 13:32:37 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:37 --> Input Class Initialized
INFO - 2016-02-04 13:32:37 --> Language Class Initialized
INFO - 2016-02-04 13:32:37 --> Loader Class Initialized
INFO - 2016-02-04 13:32:37 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:37 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:37 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:37 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:37 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:38 --> Controller Class Initialized
INFO - 2016-02-04 13:32:38 --> Model Class Initialized
INFO - 2016-02-04 13:32:38 --> Model Class Initialized
INFO - 2016-02-04 13:32:38 --> Form Validation Class Initialized
INFO - 2016-02-04 13:32:38 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:32:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
ERROR - 2016-02-04 13:32:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:32:39 --> Config Class Initialized
INFO - 2016-02-04 13:32:39 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:39 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:39 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:39 --> URI Class Initialized
INFO - 2016-02-04 13:32:39 --> Router Class Initialized
INFO - 2016-02-04 13:32:39 --> Output Class Initialized
INFO - 2016-02-04 13:32:39 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:39 --> Input Class Initialized
INFO - 2016-02-04 13:32:39 --> Language Class Initialized
INFO - 2016-02-04 13:32:39 --> Loader Class Initialized
INFO - 2016-02-04 13:32:39 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:39 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:39 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:39 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:39 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:40 --> Controller Class Initialized
INFO - 2016-02-04 13:32:40 --> Model Class Initialized
INFO - 2016-02-04 13:32:40 --> Model Class Initialized
INFO - 2016-02-04 13:32:40 --> Form Validation Class Initialized
INFO - 2016-02-04 13:32:40 --> Helper loaded: text_helper
INFO - 2016-02-04 13:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:32:40 --> Final output sent to browser
DEBUG - 2016-02-04 13:32:40 --> Total execution time: 1.1245
INFO - 2016-02-04 13:32:54 --> Config Class Initialized
INFO - 2016-02-04 13:32:54 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:54 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:54 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:54 --> URI Class Initialized
DEBUG - 2016-02-04 13:32:54 --> No URI present. Default controller set.
INFO - 2016-02-04 13:32:54 --> Router Class Initialized
INFO - 2016-02-04 13:32:54 --> Output Class Initialized
INFO - 2016-02-04 13:32:54 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:54 --> Input Class Initialized
INFO - 2016-02-04 13:32:54 --> Language Class Initialized
INFO - 2016-02-04 13:32:54 --> Loader Class Initialized
INFO - 2016-02-04 13:32:54 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:54 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:54 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:54 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:54 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:55 --> Controller Class Initialized
INFO - 2016-02-04 13:32:55 --> Model Class Initialized
INFO - 2016-02-04 13:32:55 --> Model Class Initialized
INFO - 2016-02-04 13:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-04 13:32:55 --> Pagination Class Initialized
INFO - 2016-02-04 13:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-04 13:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:32:55 --> Final output sent to browser
DEBUG - 2016-02-04 13:32:55 --> Total execution time: 1.1518
INFO - 2016-02-04 13:32:56 --> Config Class Initialized
INFO - 2016-02-04 13:32:56 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:32:56 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:32:56 --> Utf8 Class Initialized
INFO - 2016-02-04 13:32:56 --> URI Class Initialized
INFO - 2016-02-04 13:32:56 --> Router Class Initialized
INFO - 2016-02-04 13:32:56 --> Output Class Initialized
INFO - 2016-02-04 13:32:56 --> Security Class Initialized
DEBUG - 2016-02-04 13:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:32:56 --> Input Class Initialized
INFO - 2016-02-04 13:32:56 --> Language Class Initialized
INFO - 2016-02-04 13:32:56 --> Loader Class Initialized
INFO - 2016-02-04 13:32:56 --> Helper loaded: url_helper
INFO - 2016-02-04 13:32:56 --> Helper loaded: file_helper
INFO - 2016-02-04 13:32:56 --> Helper loaded: date_helper
INFO - 2016-02-04 13:32:56 --> Helper loaded: form_helper
INFO - 2016-02-04 13:32:56 --> Database Driver Class Initialized
INFO - 2016-02-04 13:32:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:32:57 --> Controller Class Initialized
INFO - 2016-02-04 13:32:57 --> Model Class Initialized
INFO - 2016-02-04 13:32:57 --> Model Class Initialized
INFO - 2016-02-04 13:32:57 --> Form Validation Class Initialized
INFO - 2016-02-04 13:32:57 --> Helper loaded: text_helper
INFO - 2016-02-04 13:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:32:57 --> Final output sent to browser
DEBUG - 2016-02-04 13:32:57 --> Total execution time: 1.1326
INFO - 2016-02-04 13:33:03 --> Config Class Initialized
INFO - 2016-02-04 13:33:03 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:33:03 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:33:03 --> Utf8 Class Initialized
INFO - 2016-02-04 13:33:03 --> URI Class Initialized
INFO - 2016-02-04 13:33:03 --> Router Class Initialized
INFO - 2016-02-04 13:33:03 --> Output Class Initialized
INFO - 2016-02-04 13:33:03 --> Security Class Initialized
DEBUG - 2016-02-04 13:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:33:03 --> Input Class Initialized
INFO - 2016-02-04 13:33:03 --> Language Class Initialized
INFO - 2016-02-04 13:33:03 --> Loader Class Initialized
INFO - 2016-02-04 13:33:03 --> Helper loaded: url_helper
INFO - 2016-02-04 13:33:03 --> Helper loaded: file_helper
INFO - 2016-02-04 13:33:03 --> Helper loaded: date_helper
INFO - 2016-02-04 13:33:03 --> Helper loaded: form_helper
INFO - 2016-02-04 13:33:03 --> Database Driver Class Initialized
INFO - 2016-02-04 13:33:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:33:04 --> Controller Class Initialized
INFO - 2016-02-04 13:33:04 --> Model Class Initialized
INFO - 2016-02-04 13:33:04 --> Model Class Initialized
INFO - 2016-02-04 13:33:04 --> Form Validation Class Initialized
INFO - 2016-02-04 13:33:04 --> Helper loaded: text_helper
INFO - 2016-02-04 13:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:33:04 --> Final output sent to browser
DEBUG - 2016-02-04 13:33:04 --> Total execution time: 1.1188
INFO - 2016-02-04 13:44:44 --> Config Class Initialized
INFO - 2016-02-04 13:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:44:44 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:44:44 --> Utf8 Class Initialized
INFO - 2016-02-04 13:44:44 --> URI Class Initialized
INFO - 2016-02-04 13:44:44 --> Router Class Initialized
INFO - 2016-02-04 13:44:44 --> Output Class Initialized
INFO - 2016-02-04 13:44:44 --> Security Class Initialized
DEBUG - 2016-02-04 13:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:44:44 --> Input Class Initialized
INFO - 2016-02-04 13:44:44 --> Language Class Initialized
INFO - 2016-02-04 13:44:44 --> Loader Class Initialized
INFO - 2016-02-04 13:44:44 --> Helper loaded: url_helper
INFO - 2016-02-04 13:44:44 --> Helper loaded: file_helper
INFO - 2016-02-04 13:44:44 --> Helper loaded: date_helper
INFO - 2016-02-04 13:44:44 --> Helper loaded: form_helper
INFO - 2016-02-04 13:44:44 --> Database Driver Class Initialized
INFO - 2016-02-04 13:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:44:45 --> Controller Class Initialized
INFO - 2016-02-04 13:44:45 --> Model Class Initialized
INFO - 2016-02-04 13:44:45 --> Model Class Initialized
INFO - 2016-02-04 13:44:45 --> Form Validation Class Initialized
INFO - 2016-02-04 13:44:45 --> Helper loaded: text_helper
INFO - 2016-02-04 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:44:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:44:46 --> Final output sent to browser
DEBUG - 2016-02-04 13:44:46 --> Total execution time: 1.1664
INFO - 2016-02-04 13:44:52 --> Config Class Initialized
INFO - 2016-02-04 13:44:52 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:44:52 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:44:52 --> Utf8 Class Initialized
INFO - 2016-02-04 13:44:52 --> URI Class Initialized
INFO - 2016-02-04 13:44:52 --> Router Class Initialized
INFO - 2016-02-04 13:44:52 --> Output Class Initialized
INFO - 2016-02-04 13:44:52 --> Security Class Initialized
DEBUG - 2016-02-04 13:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:44:52 --> Input Class Initialized
INFO - 2016-02-04 13:44:52 --> Language Class Initialized
INFO - 2016-02-04 13:44:52 --> Loader Class Initialized
INFO - 2016-02-04 13:44:52 --> Helper loaded: url_helper
INFO - 2016-02-04 13:44:52 --> Helper loaded: file_helper
INFO - 2016-02-04 13:44:52 --> Helper loaded: date_helper
INFO - 2016-02-04 13:44:52 --> Helper loaded: form_helper
INFO - 2016-02-04 13:44:52 --> Database Driver Class Initialized
INFO - 2016-02-04 13:44:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:44:53 --> Controller Class Initialized
INFO - 2016-02-04 13:44:53 --> Model Class Initialized
INFO - 2016-02-04 13:44:53 --> Model Class Initialized
INFO - 2016-02-04 13:44:53 --> Form Validation Class Initialized
INFO - 2016-02-04 13:44:53 --> Helper loaded: text_helper
INFO - 2016-02-04 13:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:44:53 --> Final output sent to browser
DEBUG - 2016-02-04 13:44:53 --> Total execution time: 1.1164
INFO - 2016-02-04 13:45:05 --> Config Class Initialized
INFO - 2016-02-04 13:45:05 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:45:05 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:45:05 --> Utf8 Class Initialized
INFO - 2016-02-04 13:45:05 --> URI Class Initialized
INFO - 2016-02-04 13:45:05 --> Router Class Initialized
INFO - 2016-02-04 13:45:05 --> Output Class Initialized
INFO - 2016-02-04 13:45:05 --> Security Class Initialized
DEBUG - 2016-02-04 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:45:05 --> Input Class Initialized
INFO - 2016-02-04 13:45:05 --> Language Class Initialized
INFO - 2016-02-04 13:45:05 --> Loader Class Initialized
INFO - 2016-02-04 13:45:05 --> Helper loaded: url_helper
INFO - 2016-02-04 13:45:05 --> Helper loaded: file_helper
INFO - 2016-02-04 13:45:05 --> Helper loaded: date_helper
INFO - 2016-02-04 13:45:05 --> Helper loaded: form_helper
INFO - 2016-02-04 13:45:05 --> Database Driver Class Initialized
INFO - 2016-02-04 13:45:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:45:06 --> Controller Class Initialized
INFO - 2016-02-04 13:45:06 --> Model Class Initialized
INFO - 2016-02-04 13:45:06 --> Model Class Initialized
INFO - 2016-02-04 13:45:06 --> Form Validation Class Initialized
INFO - 2016-02-04 13:45:06 --> Helper loaded: text_helper
INFO - 2016-02-04 13:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:45:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:45:06 --> Final output sent to browser
DEBUG - 2016-02-04 13:45:06 --> Total execution time: 1.1465
INFO - 2016-02-04 13:53:21 --> Config Class Initialized
INFO - 2016-02-04 13:53:21 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:53:21 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:53:21 --> Utf8 Class Initialized
INFO - 2016-02-04 13:53:21 --> URI Class Initialized
INFO - 2016-02-04 13:53:21 --> Router Class Initialized
INFO - 2016-02-04 13:53:21 --> Output Class Initialized
INFO - 2016-02-04 13:53:21 --> Security Class Initialized
DEBUG - 2016-02-04 13:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:53:21 --> Input Class Initialized
INFO - 2016-02-04 13:53:21 --> Language Class Initialized
INFO - 2016-02-04 13:53:21 --> Loader Class Initialized
INFO - 2016-02-04 13:53:21 --> Helper loaded: url_helper
INFO - 2016-02-04 13:53:21 --> Helper loaded: file_helper
INFO - 2016-02-04 13:53:21 --> Helper loaded: date_helper
INFO - 2016-02-04 13:53:21 --> Helper loaded: form_helper
INFO - 2016-02-04 13:53:21 --> Database Driver Class Initialized
INFO - 2016-02-04 13:53:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:53:22 --> Controller Class Initialized
INFO - 2016-02-04 13:53:22 --> Model Class Initialized
INFO - 2016-02-04 13:53:22 --> Model Class Initialized
INFO - 2016-02-04 13:53:22 --> Form Validation Class Initialized
INFO - 2016-02-04 13:53:22 --> Helper loaded: text_helper
ERROR - 2016-02-04 13:53:22 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 13:53:22 --> Config Class Initialized
INFO - 2016-02-04 13:53:22 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:53:22 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:53:22 --> Utf8 Class Initialized
INFO - 2016-02-04 13:53:22 --> URI Class Initialized
INFO - 2016-02-04 13:53:22 --> Router Class Initialized
INFO - 2016-02-04 13:53:22 --> Output Class Initialized
INFO - 2016-02-04 13:53:22 --> Security Class Initialized
DEBUG - 2016-02-04 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:53:22 --> Input Class Initialized
INFO - 2016-02-04 13:53:22 --> Language Class Initialized
INFO - 2016-02-04 13:53:22 --> Loader Class Initialized
INFO - 2016-02-04 13:53:22 --> Helper loaded: url_helper
INFO - 2016-02-04 13:53:22 --> Helper loaded: file_helper
INFO - 2016-02-04 13:53:22 --> Helper loaded: date_helper
INFO - 2016-02-04 13:53:22 --> Helper loaded: form_helper
INFO - 2016-02-04 13:53:22 --> Database Driver Class Initialized
INFO - 2016-02-04 13:53:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:53:23 --> Controller Class Initialized
INFO - 2016-02-04 13:53:23 --> Model Class Initialized
INFO - 2016-02-04 13:53:23 --> Model Class Initialized
INFO - 2016-02-04 13:53:23 --> Form Validation Class Initialized
INFO - 2016-02-04 13:53:23 --> Helper loaded: text_helper
INFO - 2016-02-04 13:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-04 13:53:23 --> Final output sent to browser
DEBUG - 2016-02-04 13:53:23 --> Total execution time: 1.1669
INFO - 2016-02-04 13:53:32 --> Config Class Initialized
INFO - 2016-02-04 13:53:32 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:53:32 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:53:32 --> Utf8 Class Initialized
INFO - 2016-02-04 13:53:32 --> URI Class Initialized
INFO - 2016-02-04 13:53:32 --> Router Class Initialized
INFO - 2016-02-04 13:53:32 --> Output Class Initialized
INFO - 2016-02-04 13:53:32 --> Security Class Initialized
DEBUG - 2016-02-04 13:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:53:32 --> Input Class Initialized
INFO - 2016-02-04 13:53:32 --> Language Class Initialized
INFO - 2016-02-04 13:53:32 --> Loader Class Initialized
INFO - 2016-02-04 13:53:32 --> Helper loaded: url_helper
INFO - 2016-02-04 13:53:32 --> Helper loaded: file_helper
INFO - 2016-02-04 13:53:32 --> Helper loaded: date_helper
INFO - 2016-02-04 13:53:32 --> Helper loaded: form_helper
INFO - 2016-02-04 13:53:32 --> Database Driver Class Initialized
INFO - 2016-02-04 13:53:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:53:33 --> Controller Class Initialized
INFO - 2016-02-04 13:53:33 --> Model Class Initialized
INFO - 2016-02-04 13:53:33 --> Model Class Initialized
INFO - 2016-02-04 13:53:33 --> Form Validation Class Initialized
INFO - 2016-02-04 13:53:33 --> Helper loaded: text_helper
INFO - 2016-02-04 13:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:53:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:53:33 --> Final output sent to browser
DEBUG - 2016-02-04 13:53:33 --> Total execution time: 1.1409
INFO - 2016-02-04 13:57:23 --> Config Class Initialized
INFO - 2016-02-04 13:57:23 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:57:23 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:57:23 --> Utf8 Class Initialized
INFO - 2016-02-04 13:57:23 --> URI Class Initialized
INFO - 2016-02-04 13:57:23 --> Router Class Initialized
INFO - 2016-02-04 13:57:23 --> Output Class Initialized
INFO - 2016-02-04 13:57:23 --> Security Class Initialized
DEBUG - 2016-02-04 13:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:57:23 --> CSRF cookie sent
INFO - 2016-02-04 13:57:23 --> Input Class Initialized
INFO - 2016-02-04 13:57:23 --> Language Class Initialized
INFO - 2016-02-04 13:57:23 --> Loader Class Initialized
INFO - 2016-02-04 13:57:23 --> Helper loaded: url_helper
INFO - 2016-02-04 13:57:23 --> Helper loaded: file_helper
INFO - 2016-02-04 13:57:23 --> Helper loaded: date_helper
INFO - 2016-02-04 13:57:23 --> Helper loaded: form_helper
INFO - 2016-02-04 13:57:23 --> Database Driver Class Initialized
INFO - 2016-02-04 13:57:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:57:25 --> Controller Class Initialized
INFO - 2016-02-04 13:57:25 --> Model Class Initialized
INFO - 2016-02-04 13:57:25 --> Model Class Initialized
INFO - 2016-02-04 13:57:25 --> Form Validation Class Initialized
INFO - 2016-02-04 13:57:25 --> Helper loaded: text_helper
INFO - 2016-02-04 13:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:57:25 --> Final output sent to browser
DEBUG - 2016-02-04 13:57:25 --> Total execution time: 1.2413
INFO - 2016-02-04 13:57:46 --> Config Class Initialized
INFO - 2016-02-04 13:57:46 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:57:46 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:57:46 --> Utf8 Class Initialized
INFO - 2016-02-04 13:57:46 --> URI Class Initialized
INFO - 2016-02-04 13:57:46 --> Router Class Initialized
INFO - 2016-02-04 13:57:46 --> Output Class Initialized
INFO - 2016-02-04 13:57:46 --> Security Class Initialized
DEBUG - 2016-02-04 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:57:46 --> CSRF cookie sent
INFO - 2016-02-04 13:57:46 --> Input Class Initialized
INFO - 2016-02-04 13:57:46 --> Language Class Initialized
INFO - 2016-02-04 13:57:46 --> Loader Class Initialized
INFO - 2016-02-04 13:57:46 --> Helper loaded: url_helper
INFO - 2016-02-04 13:57:46 --> Helper loaded: file_helper
INFO - 2016-02-04 13:57:46 --> Helper loaded: date_helper
INFO - 2016-02-04 13:57:46 --> Helper loaded: form_helper
INFO - 2016-02-04 13:57:46 --> Database Driver Class Initialized
INFO - 2016-02-04 13:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:57:48 --> Controller Class Initialized
INFO - 2016-02-04 13:57:48 --> Model Class Initialized
INFO - 2016-02-04 13:57:48 --> Model Class Initialized
INFO - 2016-02-04 13:57:48 --> Form Validation Class Initialized
INFO - 2016-02-04 13:57:48 --> Helper loaded: text_helper
INFO - 2016-02-04 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:57:48 --> Final output sent to browser
DEBUG - 2016-02-04 13:57:48 --> Total execution time: 1.1696
INFO - 2016-02-04 13:58:58 --> Config Class Initialized
INFO - 2016-02-04 13:58:58 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:58:58 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:58:58 --> Utf8 Class Initialized
INFO - 2016-02-04 13:58:58 --> URI Class Initialized
INFO - 2016-02-04 13:58:58 --> Router Class Initialized
INFO - 2016-02-04 13:58:58 --> Output Class Initialized
INFO - 2016-02-04 13:58:58 --> Security Class Initialized
DEBUG - 2016-02-04 13:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:58:58 --> Input Class Initialized
INFO - 2016-02-04 13:58:58 --> Language Class Initialized
INFO - 2016-02-04 13:58:58 --> Loader Class Initialized
INFO - 2016-02-04 13:58:58 --> Helper loaded: url_helper
INFO - 2016-02-04 13:58:58 --> Helper loaded: file_helper
INFO - 2016-02-04 13:58:58 --> Helper loaded: date_helper
INFO - 2016-02-04 13:58:58 --> Helper loaded: form_helper
INFO - 2016-02-04 13:58:58 --> Database Driver Class Initialized
INFO - 2016-02-04 13:58:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:58:59 --> Controller Class Initialized
INFO - 2016-02-04 13:58:59 --> Model Class Initialized
INFO - 2016-02-04 13:58:59 --> Model Class Initialized
INFO - 2016-02-04 13:58:59 --> Form Validation Class Initialized
INFO - 2016-02-04 13:58:59 --> Helper loaded: text_helper
INFO - 2016-02-04 13:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:58:59 --> Final output sent to browser
DEBUG - 2016-02-04 13:58:59 --> Total execution time: 1.1724
INFO - 2016-02-04 13:59:04 --> Config Class Initialized
INFO - 2016-02-04 13:59:04 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:59:04 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:59:04 --> Utf8 Class Initialized
INFO - 2016-02-04 13:59:04 --> URI Class Initialized
INFO - 2016-02-04 13:59:04 --> Router Class Initialized
INFO - 2016-02-04 13:59:04 --> Output Class Initialized
INFO - 2016-02-04 13:59:04 --> Security Class Initialized
DEBUG - 2016-02-04 13:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:59:04 --> Input Class Initialized
INFO - 2016-02-04 13:59:04 --> Language Class Initialized
INFO - 2016-02-04 13:59:05 --> Loader Class Initialized
INFO - 2016-02-04 13:59:05 --> Helper loaded: url_helper
INFO - 2016-02-04 13:59:05 --> Helper loaded: file_helper
INFO - 2016-02-04 13:59:05 --> Helper loaded: date_helper
INFO - 2016-02-04 13:59:05 --> Helper loaded: form_helper
INFO - 2016-02-04 13:59:05 --> Database Driver Class Initialized
INFO - 2016-02-04 13:59:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:59:06 --> Controller Class Initialized
INFO - 2016-02-04 13:59:06 --> Model Class Initialized
INFO - 2016-02-04 13:59:06 --> Model Class Initialized
INFO - 2016-02-04 13:59:06 --> Form Validation Class Initialized
INFO - 2016-02-04 13:59:06 --> Helper loaded: text_helper
INFO - 2016-02-04 13:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:59:06 --> Final output sent to browser
DEBUG - 2016-02-04 13:59:06 --> Total execution time: 1.1419
INFO - 2016-02-04 13:59:13 --> Config Class Initialized
INFO - 2016-02-04 13:59:13 --> Hooks Class Initialized
DEBUG - 2016-02-04 13:59:13 --> UTF-8 Support Enabled
INFO - 2016-02-04 13:59:13 --> Utf8 Class Initialized
INFO - 2016-02-04 13:59:13 --> URI Class Initialized
INFO - 2016-02-04 13:59:13 --> Router Class Initialized
INFO - 2016-02-04 13:59:13 --> Output Class Initialized
INFO - 2016-02-04 13:59:13 --> Security Class Initialized
DEBUG - 2016-02-04 13:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 13:59:13 --> Input Class Initialized
INFO - 2016-02-04 13:59:13 --> Language Class Initialized
INFO - 2016-02-04 13:59:13 --> Loader Class Initialized
INFO - 2016-02-04 13:59:13 --> Helper loaded: url_helper
INFO - 2016-02-04 13:59:13 --> Helper loaded: file_helper
INFO - 2016-02-04 13:59:13 --> Helper loaded: date_helper
INFO - 2016-02-04 13:59:13 --> Helper loaded: form_helper
INFO - 2016-02-04 13:59:13 --> Database Driver Class Initialized
INFO - 2016-02-04 13:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 13:59:14 --> Controller Class Initialized
INFO - 2016-02-04 13:59:14 --> Model Class Initialized
INFO - 2016-02-04 13:59:14 --> Model Class Initialized
INFO - 2016-02-04 13:59:14 --> Form Validation Class Initialized
INFO - 2016-02-04 13:59:14 --> Helper loaded: text_helper
INFO - 2016-02-04 13:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 13:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 13:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 13:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 13:59:14 --> Final output sent to browser
DEBUG - 2016-02-04 13:59:14 --> Total execution time: 1.1279
INFO - 2016-02-04 14:00:00 --> Config Class Initialized
INFO - 2016-02-04 14:00:00 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:00:00 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:00:00 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:00 --> URI Class Initialized
INFO - 2016-02-04 14:00:00 --> Router Class Initialized
INFO - 2016-02-04 14:00:00 --> Output Class Initialized
INFO - 2016-02-04 14:00:01 --> Security Class Initialized
DEBUG - 2016-02-04 14:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:00:01 --> Input Class Initialized
INFO - 2016-02-04 14:00:01 --> Language Class Initialized
INFO - 2016-02-04 14:00:01 --> Loader Class Initialized
INFO - 2016-02-04 14:00:01 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:01 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:01 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:01 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:01 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:02 --> Controller Class Initialized
INFO - 2016-02-04 14:00:02 --> Model Class Initialized
INFO - 2016-02-04 14:00:02 --> Model Class Initialized
INFO - 2016-02-04 14:00:02 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:02 --> Helper loaded: text_helper
INFO - 2016-02-04 14:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:00:02 --> Final output sent to browser
DEBUG - 2016-02-04 14:00:02 --> Total execution time: 1.1921
INFO - 2016-02-04 14:00:14 --> Config Class Initialized
INFO - 2016-02-04 14:00:14 --> Config Class Initialized
INFO - 2016-02-04 14:00:14 --> Hooks Class Initialized
INFO - 2016-02-04 14:00:14 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-04 14:00:14 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:00:14 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:14 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:14 --> URI Class Initialized
INFO - 2016-02-04 14:00:14 --> URI Class Initialized
INFO - 2016-02-04 14:00:14 --> Router Class Initialized
INFO - 2016-02-04 14:00:14 --> Router Class Initialized
INFO - 2016-02-04 14:00:14 --> Output Class Initialized
INFO - 2016-02-04 14:00:14 --> Output Class Initialized
INFO - 2016-02-04 14:00:14 --> Security Class Initialized
INFO - 2016-02-04 14:00:14 --> Security Class Initialized
DEBUG - 2016-02-04 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-02-04 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:00:14 --> Input Class Initialized
INFO - 2016-02-04 14:00:14 --> Input Class Initialized
INFO - 2016-02-04 14:00:14 --> Language Class Initialized
INFO - 2016-02-04 14:00:14 --> Language Class Initialized
INFO - 2016-02-04 14:00:14 --> Loader Class Initialized
INFO - 2016-02-04 14:00:14 --> Loader Class Initialized
INFO - 2016-02-04 14:00:14 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:14 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:14 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:14 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:15 --> Controller Class Initialized
INFO - 2016-02-04 14:00:15 --> Model Class Initialized
INFO - 2016-02-04 14:00:15 --> Model Class Initialized
INFO - 2016-02-04 14:00:15 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:15 --> Helper loaded: text_helper
INFO - 2016-02-04 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:00:15 --> Final output sent to browser
DEBUG - 2016-02-04 14:00:15 --> Total execution time: 1.1596
INFO - 2016-02-04 14:00:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:15 --> Controller Class Initialized
INFO - 2016-02-04 14:00:15 --> Model Class Initialized
INFO - 2016-02-04 14:00:15 --> Model Class Initialized
INFO - 2016-02-04 14:00:15 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:15 --> Helper loaded: text_helper
ERROR - 2016-02-04 14:00:15 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
ERROR - 2016-02-04 14:00:15 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-04 14:00:24 --> Config Class Initialized
INFO - 2016-02-04 14:00:24 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:00:24 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:00:24 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:24 --> URI Class Initialized
INFO - 2016-02-04 14:00:24 --> Router Class Initialized
INFO - 2016-02-04 14:00:24 --> Output Class Initialized
INFO - 2016-02-04 14:00:24 --> Security Class Initialized
DEBUG - 2016-02-04 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:00:24 --> Input Class Initialized
INFO - 2016-02-04 14:00:24 --> Language Class Initialized
INFO - 2016-02-04 14:00:24 --> Loader Class Initialized
INFO - 2016-02-04 14:00:24 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:24 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:24 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:24 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:24 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:25 --> Controller Class Initialized
INFO - 2016-02-04 14:00:25 --> Model Class Initialized
INFO - 2016-02-04 14:00:25 --> Model Class Initialized
INFO - 2016-02-04 14:00:25 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:25 --> Helper loaded: text_helper
INFO - 2016-02-04 14:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:00:25 --> Final output sent to browser
DEBUG - 2016-02-04 14:00:25 --> Total execution time: 1.1361
INFO - 2016-02-04 14:00:30 --> Config Class Initialized
INFO - 2016-02-04 14:00:30 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:00:30 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:00:30 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:30 --> URI Class Initialized
INFO - 2016-02-04 14:00:30 --> Router Class Initialized
INFO - 2016-02-04 14:00:30 --> Output Class Initialized
INFO - 2016-02-04 14:00:30 --> Security Class Initialized
DEBUG - 2016-02-04 14:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:00:30 --> Input Class Initialized
INFO - 2016-02-04 14:00:30 --> Language Class Initialized
INFO - 2016-02-04 14:00:30 --> Loader Class Initialized
INFO - 2016-02-04 14:00:30 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:30 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:30 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:30 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:30 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:31 --> Controller Class Initialized
INFO - 2016-02-04 14:00:31 --> Model Class Initialized
INFO - 2016-02-04 14:00:31 --> Model Class Initialized
INFO - 2016-02-04 14:00:31 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:31 --> Helper loaded: text_helper
INFO - 2016-02-04 14:00:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:00:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:00:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:00:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:00:31 --> Final output sent to browser
DEBUG - 2016-02-04 14:00:31 --> Total execution time: 1.1287
INFO - 2016-02-04 14:00:56 --> Config Class Initialized
INFO - 2016-02-04 14:00:56 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:00:56 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:00:56 --> Utf8 Class Initialized
INFO - 2016-02-04 14:00:56 --> URI Class Initialized
INFO - 2016-02-04 14:00:56 --> Router Class Initialized
INFO - 2016-02-04 14:00:56 --> Output Class Initialized
INFO - 2016-02-04 14:00:56 --> Security Class Initialized
DEBUG - 2016-02-04 14:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:00:56 --> Input Class Initialized
INFO - 2016-02-04 14:00:56 --> Language Class Initialized
INFO - 2016-02-04 14:00:56 --> Loader Class Initialized
INFO - 2016-02-04 14:00:56 --> Helper loaded: url_helper
INFO - 2016-02-04 14:00:56 --> Helper loaded: file_helper
INFO - 2016-02-04 14:00:56 --> Helper loaded: date_helper
INFO - 2016-02-04 14:00:56 --> Helper loaded: form_helper
INFO - 2016-02-04 14:00:56 --> Database Driver Class Initialized
INFO - 2016-02-04 14:00:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:00:57 --> Controller Class Initialized
INFO - 2016-02-04 14:00:57 --> Model Class Initialized
INFO - 2016-02-04 14:00:57 --> Model Class Initialized
INFO - 2016-02-04 14:00:57 --> Form Validation Class Initialized
INFO - 2016-02-04 14:00:57 --> Helper loaded: text_helper
INFO - 2016-02-04 14:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:00:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:00:57 --> Final output sent to browser
DEBUG - 2016-02-04 14:00:57 --> Total execution time: 1.1372
INFO - 2016-02-04 14:01:27 --> Config Class Initialized
INFO - 2016-02-04 14:01:27 --> Hooks Class Initialized
DEBUG - 2016-02-04 14:01:27 --> UTF-8 Support Enabled
INFO - 2016-02-04 14:01:27 --> Utf8 Class Initialized
INFO - 2016-02-04 14:01:27 --> URI Class Initialized
INFO - 2016-02-04 14:01:27 --> Router Class Initialized
INFO - 2016-02-04 14:01:27 --> Output Class Initialized
INFO - 2016-02-04 14:01:27 --> Security Class Initialized
DEBUG - 2016-02-04 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-04 14:01:27 --> Input Class Initialized
INFO - 2016-02-04 14:01:27 --> Language Class Initialized
INFO - 2016-02-04 14:01:27 --> Loader Class Initialized
INFO - 2016-02-04 14:01:27 --> Helper loaded: url_helper
INFO - 2016-02-04 14:01:27 --> Helper loaded: file_helper
INFO - 2016-02-04 14:01:27 --> Helper loaded: date_helper
INFO - 2016-02-04 14:01:27 --> Helper loaded: form_helper
INFO - 2016-02-04 14:01:27 --> Database Driver Class Initialized
INFO - 2016-02-04 14:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-04 14:01:28 --> Controller Class Initialized
INFO - 2016-02-04 14:01:28 --> Model Class Initialized
INFO - 2016-02-04 14:01:28 --> Model Class Initialized
INFO - 2016-02-04 14:01:28 --> Form Validation Class Initialized
INFO - 2016-02-04 14:01:28 --> Helper loaded: text_helper
INFO - 2016-02-04 14:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-04 14:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-04 14:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-04 14:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-04 14:01:28 --> Final output sent to browser
DEBUG - 2016-02-04 14:01:28 --> Total execution time: 1.1274
