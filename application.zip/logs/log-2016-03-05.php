<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-05 05:36:53 --> Config Class Initialized
INFO - 2016-03-05 05:36:53 --> Hooks Class Initialized
DEBUG - 2016-03-05 05:36:53 --> UTF-8 Support Enabled
INFO - 2016-03-05 05:36:53 --> Utf8 Class Initialized
INFO - 2016-03-05 05:36:53 --> URI Class Initialized
DEBUG - 2016-03-05 05:36:53 --> No URI present. Default controller set.
INFO - 2016-03-05 05:36:53 --> Router Class Initialized
INFO - 2016-03-05 05:36:53 --> Output Class Initialized
INFO - 2016-03-05 05:36:53 --> Security Class Initialized
DEBUG - 2016-03-05 05:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 05:36:53 --> Input Class Initialized
INFO - 2016-03-05 05:36:53 --> Language Class Initialized
INFO - 2016-03-05 05:36:53 --> Loader Class Initialized
INFO - 2016-03-05 05:36:53 --> Helper loaded: url_helper
INFO - 2016-03-05 05:36:53 --> Helper loaded: file_helper
INFO - 2016-03-05 05:36:53 --> Helper loaded: date_helper
INFO - 2016-03-05 05:36:53 --> Helper loaded: form_helper
INFO - 2016-03-05 05:36:53 --> Database Driver Class Initialized
INFO - 2016-03-05 05:36:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 05:36:54 --> Controller Class Initialized
INFO - 2016-03-05 05:36:54 --> Model Class Initialized
INFO - 2016-03-05 05:36:54 --> Model Class Initialized
INFO - 2016-03-05 05:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 05:36:54 --> Pagination Class Initialized
INFO - 2016-03-05 05:36:54 --> Helper loaded: text_helper
INFO - 2016-03-05 05:36:54 --> Helper loaded: cookie_helper
INFO - 2016-03-05 08:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 08:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 08:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 08:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 08:36:54 --> Final output sent to browser
DEBUG - 2016-03-05 08:36:54 --> Total execution time: 1.0873
INFO - 2016-03-05 06:58:46 --> Config Class Initialized
INFO - 2016-03-05 06:58:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 06:58:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 06:58:46 --> Utf8 Class Initialized
INFO - 2016-03-05 06:58:46 --> URI Class Initialized
DEBUG - 2016-03-05 06:58:46 --> No URI present. Default controller set.
INFO - 2016-03-05 06:58:46 --> Router Class Initialized
INFO - 2016-03-05 06:58:46 --> Output Class Initialized
INFO - 2016-03-05 06:58:46 --> Security Class Initialized
DEBUG - 2016-03-05 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 06:58:46 --> Input Class Initialized
INFO - 2016-03-05 06:58:46 --> Language Class Initialized
INFO - 2016-03-05 06:58:46 --> Loader Class Initialized
INFO - 2016-03-05 06:58:46 --> Helper loaded: url_helper
INFO - 2016-03-05 06:58:46 --> Helper loaded: file_helper
INFO - 2016-03-05 06:58:46 --> Helper loaded: date_helper
INFO - 2016-03-05 06:58:46 --> Helper loaded: form_helper
INFO - 2016-03-05 06:58:46 --> Database Driver Class Initialized
INFO - 2016-03-05 06:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 06:58:47 --> Controller Class Initialized
INFO - 2016-03-05 06:58:47 --> Model Class Initialized
INFO - 2016-03-05 06:58:47 --> Model Class Initialized
INFO - 2016-03-05 06:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 06:58:47 --> Pagination Class Initialized
INFO - 2016-03-05 06:58:47 --> Helper loaded: text_helper
INFO - 2016-03-05 06:58:47 --> Helper loaded: cookie_helper
INFO - 2016-03-05 09:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 09:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 09:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 09:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 09:58:47 --> Final output sent to browser
DEBUG - 2016-03-05 09:58:47 --> Total execution time: 1.1160
INFO - 2016-03-05 06:59:47 --> Config Class Initialized
INFO - 2016-03-05 06:59:47 --> Hooks Class Initialized
DEBUG - 2016-03-05 06:59:47 --> UTF-8 Support Enabled
INFO - 2016-03-05 06:59:47 --> Utf8 Class Initialized
INFO - 2016-03-05 06:59:47 --> URI Class Initialized
DEBUG - 2016-03-05 06:59:47 --> No URI present. Default controller set.
INFO - 2016-03-05 06:59:47 --> Router Class Initialized
INFO - 2016-03-05 06:59:47 --> Output Class Initialized
INFO - 2016-03-05 06:59:47 --> Security Class Initialized
DEBUG - 2016-03-05 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 06:59:47 --> Input Class Initialized
INFO - 2016-03-05 06:59:47 --> Language Class Initialized
INFO - 2016-03-05 06:59:47 --> Loader Class Initialized
INFO - 2016-03-05 06:59:47 --> Helper loaded: url_helper
INFO - 2016-03-05 06:59:47 --> Helper loaded: file_helper
INFO - 2016-03-05 06:59:47 --> Helper loaded: date_helper
INFO - 2016-03-05 06:59:47 --> Helper loaded: form_helper
INFO - 2016-03-05 06:59:47 --> Database Driver Class Initialized
INFO - 2016-03-05 06:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 06:59:48 --> Controller Class Initialized
INFO - 2016-03-05 06:59:48 --> Model Class Initialized
INFO - 2016-03-05 06:59:48 --> Model Class Initialized
INFO - 2016-03-05 06:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 06:59:48 --> Pagination Class Initialized
INFO - 2016-03-05 06:59:48 --> Helper loaded: text_helper
INFO - 2016-03-05 06:59:48 --> Helper loaded: cookie_helper
INFO - 2016-03-05 09:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 09:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 09:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 09:59:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 09:59:48 --> Final output sent to browser
DEBUG - 2016-03-05 09:59:48 --> Total execution time: 1.1104
INFO - 2016-03-05 07:01:03 --> Config Class Initialized
INFO - 2016-03-05 07:01:03 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:01:03 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:01:03 --> Utf8 Class Initialized
INFO - 2016-03-05 07:01:03 --> URI Class Initialized
DEBUG - 2016-03-05 07:01:03 --> No URI present. Default controller set.
INFO - 2016-03-05 07:01:03 --> Router Class Initialized
INFO - 2016-03-05 07:01:03 --> Output Class Initialized
INFO - 2016-03-05 07:01:03 --> Security Class Initialized
DEBUG - 2016-03-05 07:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:01:03 --> Input Class Initialized
INFO - 2016-03-05 07:01:03 --> Language Class Initialized
INFO - 2016-03-05 07:01:03 --> Loader Class Initialized
INFO - 2016-03-05 07:01:03 --> Helper loaded: url_helper
INFO - 2016-03-05 07:01:03 --> Helper loaded: file_helper
INFO - 2016-03-05 07:01:03 --> Helper loaded: date_helper
INFO - 2016-03-05 07:01:03 --> Helper loaded: form_helper
INFO - 2016-03-05 07:01:03 --> Database Driver Class Initialized
INFO - 2016-03-05 07:01:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:01:04 --> Controller Class Initialized
INFO - 2016-03-05 07:01:04 --> Model Class Initialized
INFO - 2016-03-05 07:01:04 --> Model Class Initialized
INFO - 2016-03-05 07:01:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:01:04 --> Pagination Class Initialized
INFO - 2016-03-05 07:01:04 --> Helper loaded: text_helper
INFO - 2016-03-05 07:01:04 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:01:04 --> Final output sent to browser
DEBUG - 2016-03-05 10:01:04 --> Total execution time: 1.1953
INFO - 2016-03-05 07:02:45 --> Config Class Initialized
INFO - 2016-03-05 07:02:45 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:02:45 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:02:45 --> Utf8 Class Initialized
INFO - 2016-03-05 07:02:45 --> URI Class Initialized
DEBUG - 2016-03-05 07:02:46 --> No URI present. Default controller set.
INFO - 2016-03-05 07:02:46 --> Router Class Initialized
INFO - 2016-03-05 07:02:46 --> Output Class Initialized
INFO - 2016-03-05 07:02:46 --> Security Class Initialized
DEBUG - 2016-03-05 07:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:02:46 --> Input Class Initialized
INFO - 2016-03-05 07:02:46 --> Language Class Initialized
INFO - 2016-03-05 07:02:46 --> Loader Class Initialized
INFO - 2016-03-05 07:02:46 --> Helper loaded: url_helper
INFO - 2016-03-05 07:02:46 --> Helper loaded: file_helper
INFO - 2016-03-05 07:02:46 --> Helper loaded: date_helper
INFO - 2016-03-05 07:02:46 --> Helper loaded: form_helper
INFO - 2016-03-05 07:02:46 --> Database Driver Class Initialized
INFO - 2016-03-05 07:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:02:47 --> Controller Class Initialized
INFO - 2016-03-05 07:02:47 --> Model Class Initialized
INFO - 2016-03-05 07:02:47 --> Model Class Initialized
INFO - 2016-03-05 07:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:02:47 --> Pagination Class Initialized
INFO - 2016-03-05 07:02:47 --> Helper loaded: text_helper
INFO - 2016-03-05 07:02:47 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:02:47 --> Final output sent to browser
DEBUG - 2016-03-05 10:02:47 --> Total execution time: 1.2231
INFO - 2016-03-05 07:04:00 --> Config Class Initialized
INFO - 2016-03-05 07:04:00 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:04:00 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:04:00 --> Utf8 Class Initialized
INFO - 2016-03-05 07:04:00 --> URI Class Initialized
DEBUG - 2016-03-05 07:04:00 --> No URI present. Default controller set.
INFO - 2016-03-05 07:04:00 --> Router Class Initialized
INFO - 2016-03-05 07:04:00 --> Output Class Initialized
INFO - 2016-03-05 07:04:00 --> Security Class Initialized
DEBUG - 2016-03-05 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:04:00 --> Input Class Initialized
INFO - 2016-03-05 07:04:00 --> Language Class Initialized
INFO - 2016-03-05 07:04:00 --> Loader Class Initialized
INFO - 2016-03-05 07:04:00 --> Helper loaded: url_helper
INFO - 2016-03-05 07:04:00 --> Helper loaded: file_helper
INFO - 2016-03-05 07:04:00 --> Helper loaded: date_helper
INFO - 2016-03-05 07:04:00 --> Helper loaded: form_helper
INFO - 2016-03-05 07:04:00 --> Database Driver Class Initialized
INFO - 2016-03-05 07:04:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:04:01 --> Controller Class Initialized
INFO - 2016-03-05 07:04:01 --> Model Class Initialized
INFO - 2016-03-05 07:04:01 --> Model Class Initialized
INFO - 2016-03-05 07:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:04:01 --> Pagination Class Initialized
INFO - 2016-03-05 07:04:01 --> Helper loaded: text_helper
INFO - 2016-03-05 07:04:01 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:04:01 --> Final output sent to browser
DEBUG - 2016-03-05 10:04:01 --> Total execution time: 1.1131
INFO - 2016-03-05 07:08:05 --> Config Class Initialized
INFO - 2016-03-05 07:08:05 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:08:05 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:08:05 --> Utf8 Class Initialized
INFO - 2016-03-05 07:08:05 --> URI Class Initialized
DEBUG - 2016-03-05 07:08:05 --> No URI present. Default controller set.
INFO - 2016-03-05 07:08:05 --> Router Class Initialized
INFO - 2016-03-05 07:08:05 --> Output Class Initialized
INFO - 2016-03-05 07:08:05 --> Security Class Initialized
DEBUG - 2016-03-05 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:08:05 --> Input Class Initialized
INFO - 2016-03-05 07:08:05 --> Language Class Initialized
INFO - 2016-03-05 07:08:05 --> Loader Class Initialized
INFO - 2016-03-05 07:08:05 --> Helper loaded: url_helper
INFO - 2016-03-05 07:08:05 --> Helper loaded: file_helper
INFO - 2016-03-05 07:08:05 --> Helper loaded: date_helper
INFO - 2016-03-05 07:08:05 --> Helper loaded: form_helper
INFO - 2016-03-05 07:08:05 --> Database Driver Class Initialized
INFO - 2016-03-05 07:08:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:08:06 --> Controller Class Initialized
INFO - 2016-03-05 07:08:06 --> Model Class Initialized
INFO - 2016-03-05 07:08:06 --> Model Class Initialized
INFO - 2016-03-05 07:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:08:06 --> Pagination Class Initialized
INFO - 2016-03-05 07:08:06 --> Helper loaded: text_helper
INFO - 2016-03-05 07:08:06 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:08:06 --> Final output sent to browser
DEBUG - 2016-03-05 10:08:06 --> Total execution time: 1.1283
INFO - 2016-03-05 07:12:29 --> Config Class Initialized
INFO - 2016-03-05 07:12:29 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:12:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:12:29 --> Utf8 Class Initialized
INFO - 2016-03-05 07:12:29 --> URI Class Initialized
DEBUG - 2016-03-05 07:12:29 --> No URI present. Default controller set.
INFO - 2016-03-05 07:12:29 --> Router Class Initialized
INFO - 2016-03-05 07:12:29 --> Output Class Initialized
INFO - 2016-03-05 07:12:29 --> Security Class Initialized
DEBUG - 2016-03-05 07:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:12:29 --> Input Class Initialized
INFO - 2016-03-05 07:12:29 --> Language Class Initialized
INFO - 2016-03-05 07:12:29 --> Loader Class Initialized
INFO - 2016-03-05 07:12:29 --> Helper loaded: url_helper
INFO - 2016-03-05 07:12:29 --> Helper loaded: file_helper
INFO - 2016-03-05 07:12:29 --> Helper loaded: date_helper
INFO - 2016-03-05 07:12:29 --> Helper loaded: form_helper
INFO - 2016-03-05 07:12:29 --> Database Driver Class Initialized
INFO - 2016-03-05 07:12:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:12:30 --> Controller Class Initialized
INFO - 2016-03-05 07:12:30 --> Model Class Initialized
INFO - 2016-03-05 07:12:30 --> Model Class Initialized
INFO - 2016-03-05 07:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:12:30 --> Pagination Class Initialized
INFO - 2016-03-05 07:12:30 --> Helper loaded: text_helper
INFO - 2016-03-05 07:12:30 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:12:30 --> Final output sent to browser
DEBUG - 2016-03-05 10:12:30 --> Total execution time: 1.1251
INFO - 2016-03-05 07:13:03 --> Config Class Initialized
INFO - 2016-03-05 07:13:03 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:03 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:03 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:03 --> URI Class Initialized
DEBUG - 2016-03-05 07:13:03 --> No URI present. Default controller set.
INFO - 2016-03-05 07:13:03 --> Router Class Initialized
INFO - 2016-03-05 07:13:03 --> Output Class Initialized
INFO - 2016-03-05 07:13:03 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:03 --> Input Class Initialized
INFO - 2016-03-05 07:13:03 --> Language Class Initialized
INFO - 2016-03-05 07:13:03 --> Loader Class Initialized
INFO - 2016-03-05 07:13:03 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:03 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:03 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:03 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:03 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:04 --> Controller Class Initialized
INFO - 2016-03-05 07:13:04 --> Model Class Initialized
INFO - 2016-03-05 07:13:04 --> Model Class Initialized
INFO - 2016-03-05 07:13:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:04 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:04 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:04 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:13:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:04 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:04 --> Total execution time: 1.1158
INFO - 2016-03-05 07:13:11 --> Config Class Initialized
INFO - 2016-03-05 07:13:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:11 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:11 --> URI Class Initialized
INFO - 2016-03-05 07:13:11 --> Router Class Initialized
INFO - 2016-03-05 07:13:11 --> Output Class Initialized
INFO - 2016-03-05 07:13:11 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:11 --> Input Class Initialized
INFO - 2016-03-05 07:13:11 --> Language Class Initialized
INFO - 2016-03-05 07:13:11 --> Loader Class Initialized
INFO - 2016-03-05 07:13:11 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:11 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:11 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:11 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:11 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:12 --> Controller Class Initialized
INFO - 2016-03-05 07:13:12 --> Model Class Initialized
INFO - 2016-03-05 07:13:12 --> Model Class Initialized
INFO - 2016-03-05 07:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:12 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:12 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:13:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:12 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:12 --> Total execution time: 1.1046
INFO - 2016-03-05 07:13:28 --> Config Class Initialized
INFO - 2016-03-05 07:13:28 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:28 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:28 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:28 --> URI Class Initialized
INFO - 2016-03-05 07:13:28 --> Router Class Initialized
INFO - 2016-03-05 07:13:28 --> Output Class Initialized
INFO - 2016-03-05 07:13:28 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:28 --> Input Class Initialized
INFO - 2016-03-05 07:13:28 --> Language Class Initialized
INFO - 2016-03-05 07:13:28 --> Loader Class Initialized
INFO - 2016-03-05 07:13:28 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:28 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:28 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:28 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:28 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:29 --> Controller Class Initialized
INFO - 2016-03-05 07:13:29 --> Model Class Initialized
INFO - 2016-03-05 07:13:29 --> Model Class Initialized
INFO - 2016-03-05 07:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:29 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:29 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:29 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:13:29 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:13:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:29 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:29 --> Total execution time: 1.1327
INFO - 2016-03-05 07:13:32 --> Config Class Initialized
INFO - 2016-03-05 07:13:32 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:32 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:32 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:32 --> URI Class Initialized
INFO - 2016-03-05 07:13:32 --> Router Class Initialized
INFO - 2016-03-05 07:13:32 --> Output Class Initialized
INFO - 2016-03-05 07:13:32 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:32 --> Input Class Initialized
INFO - 2016-03-05 07:13:32 --> Language Class Initialized
INFO - 2016-03-05 07:13:32 --> Loader Class Initialized
INFO - 2016-03-05 07:13:32 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:32 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:32 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:32 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:32 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:33 --> Controller Class Initialized
INFO - 2016-03-05 07:13:33 --> Model Class Initialized
INFO - 2016-03-05 07:13:33 --> Model Class Initialized
INFO - 2016-03-05 07:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:33 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:33 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:33 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:13:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:33 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:33 --> Total execution time: 1.1373
INFO - 2016-03-05 07:13:36 --> Config Class Initialized
INFO - 2016-03-05 07:13:36 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:36 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:36 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:36 --> URI Class Initialized
INFO - 2016-03-05 07:13:36 --> Router Class Initialized
INFO - 2016-03-05 07:13:36 --> Output Class Initialized
INFO - 2016-03-05 07:13:36 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:36 --> Input Class Initialized
INFO - 2016-03-05 07:13:36 --> Language Class Initialized
INFO - 2016-03-05 07:13:36 --> Loader Class Initialized
INFO - 2016-03-05 07:13:36 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:36 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:36 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:36 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:36 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:37 --> Controller Class Initialized
INFO - 2016-03-05 07:13:37 --> Model Class Initialized
INFO - 2016-03-05 07:13:37 --> Model Class Initialized
INFO - 2016-03-05 07:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:37 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:37 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:37 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:13:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:37 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:37 --> Total execution time: 1.1020
INFO - 2016-03-05 07:13:39 --> Config Class Initialized
INFO - 2016-03-05 07:13:39 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:13:39 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:13:39 --> Utf8 Class Initialized
INFO - 2016-03-05 07:13:39 --> URI Class Initialized
INFO - 2016-03-05 07:13:39 --> Router Class Initialized
INFO - 2016-03-05 07:13:39 --> Output Class Initialized
INFO - 2016-03-05 07:13:39 --> Security Class Initialized
DEBUG - 2016-03-05 07:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:13:39 --> Input Class Initialized
INFO - 2016-03-05 07:13:39 --> Language Class Initialized
INFO - 2016-03-05 07:13:39 --> Loader Class Initialized
INFO - 2016-03-05 07:13:39 --> Helper loaded: url_helper
INFO - 2016-03-05 07:13:39 --> Helper loaded: file_helper
INFO - 2016-03-05 07:13:39 --> Helper loaded: date_helper
INFO - 2016-03-05 07:13:39 --> Helper loaded: form_helper
INFO - 2016-03-05 07:13:39 --> Database Driver Class Initialized
INFO - 2016-03-05 07:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:13:40 --> Controller Class Initialized
INFO - 2016-03-05 07:13:40 --> Model Class Initialized
INFO - 2016-03-05 07:13:40 --> Model Class Initialized
INFO - 2016-03-05 07:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:13:40 --> Pagination Class Initialized
INFO - 2016-03-05 07:13:40 --> Helper loaded: text_helper
INFO - 2016-03-05 07:13:40 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:13:40 --> Final output sent to browser
DEBUG - 2016-03-05 10:13:40 --> Total execution time: 1.1526
INFO - 2016-03-05 07:15:38 --> Config Class Initialized
INFO - 2016-03-05 07:15:38 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:15:38 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:15:38 --> Utf8 Class Initialized
INFO - 2016-03-05 07:15:38 --> URI Class Initialized
INFO - 2016-03-05 07:15:38 --> Router Class Initialized
INFO - 2016-03-05 07:15:38 --> Output Class Initialized
INFO - 2016-03-05 07:15:38 --> Security Class Initialized
DEBUG - 2016-03-05 07:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:15:38 --> Input Class Initialized
INFO - 2016-03-05 07:15:38 --> Language Class Initialized
INFO - 2016-03-05 07:15:38 --> Loader Class Initialized
INFO - 2016-03-05 07:15:38 --> Helper loaded: url_helper
INFO - 2016-03-05 07:15:38 --> Helper loaded: file_helper
INFO - 2016-03-05 07:15:38 --> Helper loaded: date_helper
INFO - 2016-03-05 07:15:38 --> Helper loaded: form_helper
INFO - 2016-03-05 07:15:38 --> Database Driver Class Initialized
INFO - 2016-03-05 07:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:15:39 --> Controller Class Initialized
INFO - 2016-03-05 07:15:39 --> Model Class Initialized
INFO - 2016-03-05 07:15:39 --> Model Class Initialized
INFO - 2016-03-05 07:15:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:15:39 --> Pagination Class Initialized
INFO - 2016-03-05 07:15:39 --> Helper loaded: text_helper
INFO - 2016-03-05 07:15:39 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:15:39 --> Final output sent to browser
DEBUG - 2016-03-05 10:15:39 --> Total execution time: 1.1681
INFO - 2016-03-05 07:16:48 --> Config Class Initialized
INFO - 2016-03-05 07:16:48 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:16:48 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:16:48 --> Utf8 Class Initialized
INFO - 2016-03-05 07:16:48 --> URI Class Initialized
INFO - 2016-03-05 07:16:48 --> Router Class Initialized
INFO - 2016-03-05 07:16:48 --> Output Class Initialized
INFO - 2016-03-05 07:16:48 --> Security Class Initialized
DEBUG - 2016-03-05 07:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:16:48 --> Input Class Initialized
INFO - 2016-03-05 07:16:48 --> Language Class Initialized
INFO - 2016-03-05 07:16:48 --> Loader Class Initialized
INFO - 2016-03-05 07:16:48 --> Helper loaded: url_helper
INFO - 2016-03-05 07:16:48 --> Helper loaded: file_helper
INFO - 2016-03-05 07:16:48 --> Helper loaded: date_helper
INFO - 2016-03-05 07:16:48 --> Helper loaded: form_helper
INFO - 2016-03-05 07:16:48 --> Database Driver Class Initialized
INFO - 2016-03-05 07:16:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:16:49 --> Controller Class Initialized
INFO - 2016-03-05 07:16:49 --> Model Class Initialized
INFO - 2016-03-05 07:16:49 --> Model Class Initialized
INFO - 2016-03-05 07:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:16:49 --> Pagination Class Initialized
INFO - 2016-03-05 07:16:49 --> Helper loaded: text_helper
INFO - 2016-03-05 07:16:49 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:16:49 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:16:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:16:49 --> Final output sent to browser
DEBUG - 2016-03-05 10:16:49 --> Total execution time: 1.1419
INFO - 2016-03-05 07:16:51 --> Config Class Initialized
INFO - 2016-03-05 07:16:51 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:16:51 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:16:51 --> Utf8 Class Initialized
INFO - 2016-03-05 07:16:51 --> URI Class Initialized
INFO - 2016-03-05 07:16:51 --> Router Class Initialized
INFO - 2016-03-05 07:16:51 --> Output Class Initialized
INFO - 2016-03-05 07:16:51 --> Security Class Initialized
DEBUG - 2016-03-05 07:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:16:51 --> Input Class Initialized
INFO - 2016-03-05 07:16:51 --> Language Class Initialized
INFO - 2016-03-05 07:16:51 --> Loader Class Initialized
INFO - 2016-03-05 07:16:51 --> Helper loaded: url_helper
INFO - 2016-03-05 07:16:51 --> Helper loaded: file_helper
INFO - 2016-03-05 07:16:51 --> Helper loaded: date_helper
INFO - 2016-03-05 07:16:51 --> Helper loaded: form_helper
INFO - 2016-03-05 07:16:51 --> Database Driver Class Initialized
INFO - 2016-03-05 07:16:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:16:52 --> Controller Class Initialized
INFO - 2016-03-05 07:16:52 --> Model Class Initialized
INFO - 2016-03-05 07:16:52 --> Model Class Initialized
INFO - 2016-03-05 07:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:16:52 --> Pagination Class Initialized
INFO - 2016-03-05 07:16:52 --> Helper loaded: text_helper
INFO - 2016-03-05 07:16:52 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:16:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:16:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:16:52 --> Final output sent to browser
DEBUG - 2016-03-05 10:16:52 --> Total execution time: 1.1291
INFO - 2016-03-05 07:16:56 --> Config Class Initialized
INFO - 2016-03-05 07:16:56 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:16:56 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:16:56 --> Utf8 Class Initialized
INFO - 2016-03-05 07:16:56 --> URI Class Initialized
INFO - 2016-03-05 07:16:56 --> Router Class Initialized
INFO - 2016-03-05 07:16:56 --> Output Class Initialized
INFO - 2016-03-05 07:16:56 --> Security Class Initialized
DEBUG - 2016-03-05 07:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:16:56 --> Input Class Initialized
INFO - 2016-03-05 07:16:56 --> Language Class Initialized
INFO - 2016-03-05 07:16:56 --> Loader Class Initialized
INFO - 2016-03-05 07:16:56 --> Helper loaded: url_helper
INFO - 2016-03-05 07:16:56 --> Helper loaded: file_helper
INFO - 2016-03-05 07:16:56 --> Helper loaded: date_helper
INFO - 2016-03-05 07:16:56 --> Helper loaded: form_helper
INFO - 2016-03-05 07:16:56 --> Database Driver Class Initialized
INFO - 2016-03-05 07:16:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:16:57 --> Controller Class Initialized
INFO - 2016-03-05 07:16:57 --> Model Class Initialized
INFO - 2016-03-05 07:16:57 --> Model Class Initialized
INFO - 2016-03-05 07:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:16:57 --> Pagination Class Initialized
INFO - 2016-03-05 07:16:57 --> Helper loaded: text_helper
INFO - 2016-03-05 07:16:57 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:16:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:16:57 --> Final output sent to browser
DEBUG - 2016-03-05 10:16:57 --> Total execution time: 1.1469
INFO - 2016-03-05 07:17:01 --> Config Class Initialized
INFO - 2016-03-05 07:17:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:17:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:17:01 --> Utf8 Class Initialized
INFO - 2016-03-05 07:17:01 --> URI Class Initialized
INFO - 2016-03-05 07:17:01 --> Router Class Initialized
INFO - 2016-03-05 07:17:01 --> Output Class Initialized
INFO - 2016-03-05 07:17:01 --> Security Class Initialized
DEBUG - 2016-03-05 07:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:17:01 --> Input Class Initialized
INFO - 2016-03-05 07:17:01 --> Language Class Initialized
INFO - 2016-03-05 07:17:01 --> Loader Class Initialized
INFO - 2016-03-05 07:17:01 --> Helper loaded: url_helper
INFO - 2016-03-05 07:17:01 --> Helper loaded: file_helper
INFO - 2016-03-05 07:17:01 --> Helper loaded: date_helper
INFO - 2016-03-05 07:17:01 --> Helper loaded: form_helper
INFO - 2016-03-05 07:17:01 --> Database Driver Class Initialized
INFO - 2016-03-05 07:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:17:02 --> Controller Class Initialized
INFO - 2016-03-05 07:17:02 --> Model Class Initialized
INFO - 2016-03-05 07:17:02 --> Model Class Initialized
INFO - 2016-03-05 07:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:17:02 --> Pagination Class Initialized
INFO - 2016-03-05 07:17:02 --> Helper loaded: text_helper
INFO - 2016-03-05 07:17:02 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:17:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:17:02 --> Final output sent to browser
DEBUG - 2016-03-05 10:17:02 --> Total execution time: 1.1285
INFO - 2016-03-05 07:17:04 --> Config Class Initialized
INFO - 2016-03-05 07:17:04 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:17:04 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:17:04 --> Utf8 Class Initialized
INFO - 2016-03-05 07:17:04 --> URI Class Initialized
INFO - 2016-03-05 07:17:04 --> Router Class Initialized
INFO - 2016-03-05 07:17:05 --> Output Class Initialized
INFO - 2016-03-05 07:17:05 --> Security Class Initialized
DEBUG - 2016-03-05 07:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:17:05 --> Input Class Initialized
INFO - 2016-03-05 07:17:05 --> Language Class Initialized
INFO - 2016-03-05 07:17:05 --> Loader Class Initialized
INFO - 2016-03-05 07:17:05 --> Helper loaded: url_helper
INFO - 2016-03-05 07:17:05 --> Helper loaded: file_helper
INFO - 2016-03-05 07:17:05 --> Helper loaded: date_helper
INFO - 2016-03-05 07:17:05 --> Helper loaded: form_helper
INFO - 2016-03-05 07:17:05 --> Database Driver Class Initialized
INFO - 2016-03-05 07:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:17:06 --> Controller Class Initialized
INFO - 2016-03-05 07:17:06 --> Model Class Initialized
INFO - 2016-03-05 07:17:06 --> Model Class Initialized
INFO - 2016-03-05 07:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:17:06 --> Pagination Class Initialized
INFO - 2016-03-05 07:17:06 --> Helper loaded: text_helper
INFO - 2016-03-05 07:17:06 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 10:17:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 10:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 10:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 10:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:17:06 --> Final output sent to browser
DEBUG - 2016-03-05 10:17:06 --> Total execution time: 1.1115
INFO - 2016-03-05 07:17:12 --> Config Class Initialized
INFO - 2016-03-05 07:17:12 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:17:12 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:17:12 --> Utf8 Class Initialized
INFO - 2016-03-05 07:17:12 --> URI Class Initialized
INFO - 2016-03-05 07:17:12 --> Router Class Initialized
INFO - 2016-03-05 07:17:12 --> Output Class Initialized
INFO - 2016-03-05 07:17:12 --> Security Class Initialized
DEBUG - 2016-03-05 07:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:17:12 --> Input Class Initialized
INFO - 2016-03-05 07:17:12 --> Language Class Initialized
INFO - 2016-03-05 07:17:12 --> Loader Class Initialized
INFO - 2016-03-05 07:17:12 --> Helper loaded: url_helper
INFO - 2016-03-05 07:17:12 --> Helper loaded: file_helper
INFO - 2016-03-05 07:17:12 --> Helper loaded: date_helper
INFO - 2016-03-05 07:17:12 --> Helper loaded: form_helper
INFO - 2016-03-05 07:17:12 --> Database Driver Class Initialized
INFO - 2016-03-05 07:17:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:17:13 --> Controller Class Initialized
INFO - 2016-03-05 07:17:14 --> Model Class Initialized
INFO - 2016-03-05 07:17:14 --> Model Class Initialized
INFO - 2016-03-05 07:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:17:14 --> Pagination Class Initialized
INFO - 2016-03-05 07:17:14 --> Helper loaded: text_helper
INFO - 2016-03-05 07:17:14 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:17:14 --> Final output sent to browser
DEBUG - 2016-03-05 10:17:14 --> Total execution time: 1.1620
INFO - 2016-03-05 07:22:46 --> Config Class Initialized
INFO - 2016-03-05 07:22:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:22:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:22:46 --> Utf8 Class Initialized
INFO - 2016-03-05 07:22:46 --> URI Class Initialized
INFO - 2016-03-05 07:22:46 --> Router Class Initialized
INFO - 2016-03-05 07:22:46 --> Output Class Initialized
INFO - 2016-03-05 07:22:46 --> Security Class Initialized
DEBUG - 2016-03-05 07:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:22:46 --> Input Class Initialized
INFO - 2016-03-05 07:22:46 --> Language Class Initialized
INFO - 2016-03-05 07:22:46 --> Loader Class Initialized
INFO - 2016-03-05 07:22:46 --> Helper loaded: url_helper
INFO - 2016-03-05 07:22:46 --> Helper loaded: file_helper
INFO - 2016-03-05 07:22:46 --> Helper loaded: date_helper
INFO - 2016-03-05 07:22:46 --> Helper loaded: form_helper
INFO - 2016-03-05 07:22:46 --> Database Driver Class Initialized
INFO - 2016-03-05 07:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:22:47 --> Controller Class Initialized
INFO - 2016-03-05 07:22:47 --> Model Class Initialized
INFO - 2016-03-05 07:22:47 --> Model Class Initialized
INFO - 2016-03-05 07:22:47 --> Form Validation Class Initialized
INFO - 2016-03-05 07:22:47 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:22:47 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:22:47 --> Final output sent to browser
DEBUG - 2016-03-05 07:22:47 --> Total execution time: 1.2213
INFO - 2016-03-05 07:22:52 --> Config Class Initialized
INFO - 2016-03-05 07:22:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:22:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:22:52 --> Utf8 Class Initialized
INFO - 2016-03-05 07:22:52 --> URI Class Initialized
INFO - 2016-03-05 07:22:52 --> Router Class Initialized
INFO - 2016-03-05 07:22:52 --> Output Class Initialized
INFO - 2016-03-05 07:22:52 --> Security Class Initialized
DEBUG - 2016-03-05 07:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:22:52 --> Input Class Initialized
INFO - 2016-03-05 07:22:52 --> Language Class Initialized
INFO - 2016-03-05 07:22:52 --> Loader Class Initialized
INFO - 2016-03-05 07:22:52 --> Helper loaded: url_helper
INFO - 2016-03-05 07:22:52 --> Helper loaded: file_helper
INFO - 2016-03-05 07:22:52 --> Helper loaded: date_helper
INFO - 2016-03-05 07:22:52 --> Helper loaded: form_helper
INFO - 2016-03-05 07:22:52 --> Database Driver Class Initialized
INFO - 2016-03-05 07:22:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:22:53 --> Controller Class Initialized
INFO - 2016-03-05 07:22:53 --> Model Class Initialized
INFO - 2016-03-05 07:22:53 --> Model Class Initialized
INFO - 2016-03-05 07:22:53 --> Form Validation Class Initialized
INFO - 2016-03-05 07:22:53 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:22:53 --> Final output sent to browser
DEBUG - 2016-03-05 07:22:53 --> Total execution time: 1.1004
INFO - 2016-03-05 07:23:04 --> Config Class Initialized
INFO - 2016-03-05 07:23:04 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:23:04 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:23:04 --> Utf8 Class Initialized
INFO - 2016-03-05 07:23:04 --> URI Class Initialized
INFO - 2016-03-05 07:23:04 --> Router Class Initialized
INFO - 2016-03-05 07:23:04 --> Output Class Initialized
INFO - 2016-03-05 07:23:04 --> Security Class Initialized
DEBUG - 2016-03-05 07:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:23:04 --> Input Class Initialized
INFO - 2016-03-05 07:23:04 --> Language Class Initialized
INFO - 2016-03-05 07:23:04 --> Loader Class Initialized
INFO - 2016-03-05 07:23:04 --> Helper loaded: url_helper
INFO - 2016-03-05 07:23:04 --> Helper loaded: file_helper
INFO - 2016-03-05 07:23:04 --> Helper loaded: date_helper
INFO - 2016-03-05 07:23:04 --> Helper loaded: form_helper
INFO - 2016-03-05 07:23:04 --> Database Driver Class Initialized
INFO - 2016-03-05 07:23:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:23:05 --> Controller Class Initialized
INFO - 2016-03-05 07:23:05 --> Model Class Initialized
INFO - 2016-03-05 07:23:05 --> Model Class Initialized
INFO - 2016-03-05 07:23:05 --> Form Validation Class Initialized
INFO - 2016-03-05 07:23:05 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:23:05 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:23:05 --> Final output sent to browser
DEBUG - 2016-03-05 07:23:05 --> Total execution time: 1.0966
INFO - 2016-03-05 07:24:04 --> Config Class Initialized
INFO - 2016-03-05 07:24:04 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:24:04 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:24:04 --> Utf8 Class Initialized
INFO - 2016-03-05 07:24:04 --> URI Class Initialized
INFO - 2016-03-05 07:24:04 --> Router Class Initialized
INFO - 2016-03-05 07:24:04 --> Output Class Initialized
INFO - 2016-03-05 07:24:04 --> Security Class Initialized
DEBUG - 2016-03-05 07:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:24:04 --> Input Class Initialized
INFO - 2016-03-05 07:24:04 --> Language Class Initialized
INFO - 2016-03-05 07:24:04 --> Loader Class Initialized
INFO - 2016-03-05 07:24:04 --> Helper loaded: url_helper
INFO - 2016-03-05 07:24:04 --> Helper loaded: file_helper
INFO - 2016-03-05 07:24:04 --> Helper loaded: date_helper
INFO - 2016-03-05 07:24:04 --> Helper loaded: form_helper
INFO - 2016-03-05 07:24:04 --> Database Driver Class Initialized
INFO - 2016-03-05 07:24:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:24:05 --> Controller Class Initialized
INFO - 2016-03-05 07:24:05 --> Model Class Initialized
INFO - 2016-03-05 07:24:05 --> Model Class Initialized
INFO - 2016-03-05 07:24:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:24:05 --> Pagination Class Initialized
INFO - 2016-03-05 07:24:05 --> Helper loaded: text_helper
INFO - 2016-03-05 07:24:05 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:24:05 --> Final output sent to browser
DEBUG - 2016-03-05 10:24:05 --> Total execution time: 1.1932
INFO - 2016-03-05 07:24:17 --> Config Class Initialized
INFO - 2016-03-05 07:24:17 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:24:17 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:24:17 --> Utf8 Class Initialized
INFO - 2016-03-05 07:24:17 --> URI Class Initialized
INFO - 2016-03-05 07:24:17 --> Router Class Initialized
INFO - 2016-03-05 07:24:17 --> Output Class Initialized
INFO - 2016-03-05 07:24:17 --> Security Class Initialized
DEBUG - 2016-03-05 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:24:17 --> Input Class Initialized
INFO - 2016-03-05 07:24:17 --> Language Class Initialized
INFO - 2016-03-05 07:24:17 --> Loader Class Initialized
INFO - 2016-03-05 07:24:17 --> Helper loaded: url_helper
INFO - 2016-03-05 07:24:17 --> Helper loaded: file_helper
INFO - 2016-03-05 07:24:17 --> Helper loaded: date_helper
INFO - 2016-03-05 07:24:17 --> Helper loaded: form_helper
INFO - 2016-03-05 07:24:17 --> Database Driver Class Initialized
INFO - 2016-03-05 07:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:24:18 --> Controller Class Initialized
INFO - 2016-03-05 07:24:18 --> Model Class Initialized
INFO - 2016-03-05 07:24:18 --> Model Class Initialized
INFO - 2016-03-05 07:24:18 --> Form Validation Class Initialized
INFO - 2016-03-05 07:24:18 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:24:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:24:18 --> Final output sent to browser
DEBUG - 2016-03-05 07:24:18 --> Total execution time: 1.1002
INFO - 2016-03-05 07:35:52 --> Config Class Initialized
INFO - 2016-03-05 07:35:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:35:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:35:52 --> Utf8 Class Initialized
INFO - 2016-03-05 07:35:52 --> URI Class Initialized
INFO - 2016-03-05 07:35:52 --> Router Class Initialized
INFO - 2016-03-05 07:35:52 --> Output Class Initialized
INFO - 2016-03-05 07:35:52 --> Security Class Initialized
DEBUG - 2016-03-05 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:35:52 --> Input Class Initialized
INFO - 2016-03-05 07:35:52 --> Language Class Initialized
INFO - 2016-03-05 07:35:52 --> Loader Class Initialized
INFO - 2016-03-05 07:35:52 --> Helper loaded: url_helper
INFO - 2016-03-05 07:35:52 --> Helper loaded: file_helper
INFO - 2016-03-05 07:35:52 --> Helper loaded: date_helper
INFO - 2016-03-05 07:35:52 --> Helper loaded: form_helper
INFO - 2016-03-05 07:35:52 --> Database Driver Class Initialized
INFO - 2016-03-05 07:35:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:35:53 --> Controller Class Initialized
INFO - 2016-03-05 07:35:53 --> Model Class Initialized
INFO - 2016-03-05 07:35:53 --> Model Class Initialized
INFO - 2016-03-05 07:35:53 --> Form Validation Class Initialized
INFO - 2016-03-05 07:35:53 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:35:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:35:53 --> Final output sent to browser
DEBUG - 2016-03-05 07:35:53 --> Total execution time: 1.1122
INFO - 2016-03-05 07:36:42 --> Config Class Initialized
INFO - 2016-03-05 07:36:42 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:36:42 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:36:42 --> Utf8 Class Initialized
INFO - 2016-03-05 07:36:42 --> URI Class Initialized
INFO - 2016-03-05 07:36:42 --> Router Class Initialized
INFO - 2016-03-05 07:36:42 --> Output Class Initialized
INFO - 2016-03-05 07:36:42 --> Security Class Initialized
DEBUG - 2016-03-05 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:36:42 --> Input Class Initialized
INFO - 2016-03-05 07:36:42 --> Language Class Initialized
INFO - 2016-03-05 07:36:42 --> Loader Class Initialized
INFO - 2016-03-05 07:36:42 --> Helper loaded: url_helper
INFO - 2016-03-05 07:36:42 --> Helper loaded: file_helper
INFO - 2016-03-05 07:36:42 --> Helper loaded: date_helper
INFO - 2016-03-05 07:36:42 --> Helper loaded: form_helper
INFO - 2016-03-05 07:36:42 --> Database Driver Class Initialized
INFO - 2016-03-05 07:36:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:36:43 --> Controller Class Initialized
INFO - 2016-03-05 07:36:43 --> Model Class Initialized
INFO - 2016-03-05 07:36:43 --> Model Class Initialized
INFO - 2016-03-05 07:36:43 --> Form Validation Class Initialized
INFO - 2016-03-05 07:36:43 --> Helper loaded: text_helper
INFO - 2016-03-05 07:36:43 --> Final output sent to browser
DEBUG - 2016-03-05 07:36:43 --> Total execution time: 1.2362
INFO - 2016-03-05 07:36:43 --> Config Class Initialized
INFO - 2016-03-05 07:36:43 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:36:43 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:36:43 --> Utf8 Class Initialized
INFO - 2016-03-05 07:36:43 --> URI Class Initialized
INFO - 2016-03-05 07:36:43 --> Router Class Initialized
INFO - 2016-03-05 07:36:43 --> Output Class Initialized
INFO - 2016-03-05 07:36:43 --> Security Class Initialized
DEBUG - 2016-03-05 07:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:36:43 --> Input Class Initialized
INFO - 2016-03-05 07:36:43 --> Language Class Initialized
INFO - 2016-03-05 07:36:43 --> Loader Class Initialized
INFO - 2016-03-05 07:36:43 --> Helper loaded: url_helper
INFO - 2016-03-05 07:36:43 --> Helper loaded: file_helper
INFO - 2016-03-05 07:36:43 --> Helper loaded: date_helper
INFO - 2016-03-05 07:36:43 --> Helper loaded: form_helper
INFO - 2016-03-05 07:36:43 --> Database Driver Class Initialized
INFO - 2016-03-05 07:36:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:36:44 --> Controller Class Initialized
INFO - 2016-03-05 07:36:44 --> Model Class Initialized
INFO - 2016-03-05 07:36:44 --> Model Class Initialized
INFO - 2016-03-05 07:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:36:44 --> Pagination Class Initialized
INFO - 2016-03-05 07:36:44 --> Helper loaded: text_helper
INFO - 2016-03-05 07:36:44 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 10:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 10:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:36:44 --> Final output sent to browser
DEBUG - 2016-03-05 10:36:44 --> Total execution time: 1.1870
INFO - 2016-03-05 07:36:46 --> Config Class Initialized
INFO - 2016-03-05 07:36:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:36:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:36:46 --> Utf8 Class Initialized
INFO - 2016-03-05 07:36:46 --> URI Class Initialized
INFO - 2016-03-05 07:36:46 --> Router Class Initialized
INFO - 2016-03-05 07:36:46 --> Output Class Initialized
INFO - 2016-03-05 07:36:46 --> Security Class Initialized
DEBUG - 2016-03-05 07:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:36:46 --> Input Class Initialized
INFO - 2016-03-05 07:36:47 --> Language Class Initialized
INFO - 2016-03-05 07:36:47 --> Loader Class Initialized
INFO - 2016-03-05 07:36:47 --> Helper loaded: url_helper
INFO - 2016-03-05 07:36:47 --> Helper loaded: file_helper
INFO - 2016-03-05 07:36:47 --> Helper loaded: date_helper
INFO - 2016-03-05 07:36:47 --> Helper loaded: form_helper
INFO - 2016-03-05 07:36:47 --> Database Driver Class Initialized
INFO - 2016-03-05 07:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:36:48 --> Controller Class Initialized
INFO - 2016-03-05 07:36:48 --> Model Class Initialized
INFO - 2016-03-05 07:36:48 --> Model Class Initialized
INFO - 2016-03-05 07:36:48 --> Form Validation Class Initialized
INFO - 2016-03-05 07:36:48 --> Helper loaded: text_helper
INFO - 2016-03-05 07:36:48 --> Config Class Initialized
INFO - 2016-03-05 07:36:48 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:36:48 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:36:48 --> Utf8 Class Initialized
INFO - 2016-03-05 07:36:48 --> URI Class Initialized
DEBUG - 2016-03-05 07:36:48 --> No URI present. Default controller set.
INFO - 2016-03-05 07:36:48 --> Router Class Initialized
INFO - 2016-03-05 07:36:48 --> Output Class Initialized
INFO - 2016-03-05 07:36:48 --> Security Class Initialized
DEBUG - 2016-03-05 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:36:48 --> Input Class Initialized
INFO - 2016-03-05 07:36:48 --> Language Class Initialized
INFO - 2016-03-05 07:36:48 --> Loader Class Initialized
INFO - 2016-03-05 07:36:48 --> Helper loaded: url_helper
INFO - 2016-03-05 07:36:48 --> Helper loaded: file_helper
INFO - 2016-03-05 07:36:48 --> Helper loaded: date_helper
INFO - 2016-03-05 07:36:48 --> Helper loaded: form_helper
INFO - 2016-03-05 07:36:48 --> Database Driver Class Initialized
INFO - 2016-03-05 07:36:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:36:49 --> Controller Class Initialized
INFO - 2016-03-05 07:36:49 --> Model Class Initialized
INFO - 2016-03-05 07:36:49 --> Model Class Initialized
INFO - 2016-03-05 07:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:36:49 --> Pagination Class Initialized
INFO - 2016-03-05 07:36:49 --> Helper loaded: text_helper
INFO - 2016-03-05 07:36:49 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:36:49 --> Final output sent to browser
DEBUG - 2016-03-05 10:36:49 --> Total execution time: 1.1045
INFO - 2016-03-05 07:36:58 --> Config Class Initialized
INFO - 2016-03-05 07:36:58 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:36:58 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:36:58 --> Utf8 Class Initialized
INFO - 2016-03-05 07:36:58 --> URI Class Initialized
INFO - 2016-03-05 07:36:58 --> Router Class Initialized
INFO - 2016-03-05 07:36:58 --> Output Class Initialized
INFO - 2016-03-05 07:36:58 --> Security Class Initialized
DEBUG - 2016-03-05 07:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:36:58 --> Input Class Initialized
INFO - 2016-03-05 07:36:58 --> Language Class Initialized
INFO - 2016-03-05 07:36:58 --> Loader Class Initialized
INFO - 2016-03-05 07:36:58 --> Helper loaded: url_helper
INFO - 2016-03-05 07:36:58 --> Helper loaded: file_helper
INFO - 2016-03-05 07:36:58 --> Helper loaded: date_helper
INFO - 2016-03-05 07:36:58 --> Helper loaded: form_helper
INFO - 2016-03-05 07:36:58 --> Database Driver Class Initialized
INFO - 2016-03-05 07:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:36:59 --> Controller Class Initialized
INFO - 2016-03-05 07:36:59 --> Model Class Initialized
INFO - 2016-03-05 07:36:59 --> Model Class Initialized
INFO - 2016-03-05 07:36:59 --> Form Validation Class Initialized
INFO - 2016-03-05 07:36:59 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:36:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:36:59 --> Final output sent to browser
DEBUG - 2016-03-05 07:36:59 --> Total execution time: 1.0912
INFO - 2016-03-05 07:39:16 --> Config Class Initialized
INFO - 2016-03-05 07:39:16 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:39:16 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:39:16 --> Utf8 Class Initialized
INFO - 2016-03-05 07:39:17 --> URI Class Initialized
DEBUG - 2016-03-05 07:39:17 --> No URI present. Default controller set.
INFO - 2016-03-05 07:39:17 --> Router Class Initialized
INFO - 2016-03-05 07:39:17 --> Output Class Initialized
INFO - 2016-03-05 07:39:17 --> Security Class Initialized
DEBUG - 2016-03-05 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:39:17 --> Input Class Initialized
INFO - 2016-03-05 07:39:17 --> Language Class Initialized
INFO - 2016-03-05 07:39:17 --> Loader Class Initialized
INFO - 2016-03-05 07:39:17 --> Helper loaded: url_helper
INFO - 2016-03-05 07:39:17 --> Helper loaded: file_helper
INFO - 2016-03-05 07:39:17 --> Helper loaded: date_helper
INFO - 2016-03-05 07:39:17 --> Helper loaded: form_helper
INFO - 2016-03-05 07:39:17 --> Database Driver Class Initialized
INFO - 2016-03-05 07:39:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:39:18 --> Controller Class Initialized
INFO - 2016-03-05 07:39:18 --> Model Class Initialized
INFO - 2016-03-05 07:39:18 --> Model Class Initialized
INFO - 2016-03-05 07:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:39:18 --> Pagination Class Initialized
INFO - 2016-03-05 07:39:18 --> Helper loaded: text_helper
INFO - 2016-03-05 07:39:18 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:39:18 --> Final output sent to browser
DEBUG - 2016-03-05 10:39:18 --> Total execution time: 1.1328
INFO - 2016-03-05 07:39:28 --> Config Class Initialized
INFO - 2016-03-05 07:39:28 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:39:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:39:29 --> Utf8 Class Initialized
INFO - 2016-03-05 07:39:29 --> URI Class Initialized
INFO - 2016-03-05 07:39:29 --> Router Class Initialized
INFO - 2016-03-05 07:39:29 --> Output Class Initialized
INFO - 2016-03-05 07:39:29 --> Security Class Initialized
DEBUG - 2016-03-05 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:39:29 --> Input Class Initialized
INFO - 2016-03-05 07:39:29 --> Language Class Initialized
INFO - 2016-03-05 07:39:29 --> Loader Class Initialized
INFO - 2016-03-05 07:39:29 --> Helper loaded: url_helper
INFO - 2016-03-05 07:39:29 --> Helper loaded: file_helper
INFO - 2016-03-05 07:39:29 --> Helper loaded: date_helper
INFO - 2016-03-05 07:39:29 --> Helper loaded: form_helper
INFO - 2016-03-05 07:39:29 --> Database Driver Class Initialized
INFO - 2016-03-05 07:39:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:39:30 --> Controller Class Initialized
INFO - 2016-03-05 07:39:30 --> Model Class Initialized
INFO - 2016-03-05 07:39:30 --> Model Class Initialized
INFO - 2016-03-05 07:39:30 --> Form Validation Class Initialized
INFO - 2016-03-05 07:39:30 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:39:30 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:39:30 --> Final output sent to browser
DEBUG - 2016-03-05 07:39:30 --> Total execution time: 1.1291
INFO - 2016-03-05 07:39:52 --> Config Class Initialized
INFO - 2016-03-05 07:39:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:39:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:39:52 --> Utf8 Class Initialized
INFO - 2016-03-05 07:39:52 --> URI Class Initialized
INFO - 2016-03-05 07:39:52 --> Router Class Initialized
INFO - 2016-03-05 07:39:52 --> Output Class Initialized
INFO - 2016-03-05 07:39:52 --> Security Class Initialized
DEBUG - 2016-03-05 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:39:52 --> Input Class Initialized
INFO - 2016-03-05 07:39:52 --> Language Class Initialized
INFO - 2016-03-05 07:39:52 --> Loader Class Initialized
INFO - 2016-03-05 07:39:52 --> Helper loaded: url_helper
INFO - 2016-03-05 07:39:52 --> Helper loaded: file_helper
INFO - 2016-03-05 07:39:52 --> Helper loaded: date_helper
INFO - 2016-03-05 07:39:52 --> Helper loaded: form_helper
INFO - 2016-03-05 07:39:52 --> Database Driver Class Initialized
INFO - 2016-03-05 07:39:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:39:53 --> Controller Class Initialized
INFO - 2016-03-05 07:39:53 --> Model Class Initialized
INFO - 2016-03-05 07:39:53 --> Model Class Initialized
INFO - 2016-03-05 07:39:53 --> Form Validation Class Initialized
INFO - 2016-03-05 07:39:53 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:39:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:39:53 --> Final output sent to browser
DEBUG - 2016-03-05 07:39:53 --> Total execution time: 1.1161
INFO - 2016-03-05 07:40:16 --> Config Class Initialized
INFO - 2016-03-05 07:40:16 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:40:16 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:40:16 --> Utf8 Class Initialized
INFO - 2016-03-05 07:40:16 --> URI Class Initialized
DEBUG - 2016-03-05 07:40:16 --> No URI present. Default controller set.
INFO - 2016-03-05 07:40:16 --> Router Class Initialized
INFO - 2016-03-05 07:40:16 --> Output Class Initialized
INFO - 2016-03-05 07:40:16 --> Security Class Initialized
DEBUG - 2016-03-05 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:40:16 --> Input Class Initialized
INFO - 2016-03-05 07:40:16 --> Language Class Initialized
INFO - 2016-03-05 07:40:16 --> Loader Class Initialized
INFO - 2016-03-05 07:40:16 --> Helper loaded: url_helper
INFO - 2016-03-05 07:40:16 --> Helper loaded: file_helper
INFO - 2016-03-05 07:40:16 --> Helper loaded: date_helper
INFO - 2016-03-05 07:40:16 --> Helper loaded: form_helper
INFO - 2016-03-05 07:40:16 --> Database Driver Class Initialized
INFO - 2016-03-05 07:40:17 --> Config Class Initialized
INFO - 2016-03-05 07:40:17 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:40:17 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:40:17 --> Utf8 Class Initialized
INFO - 2016-03-05 07:40:17 --> URI Class Initialized
DEBUG - 2016-03-05 07:40:17 --> No URI present. Default controller set.
INFO - 2016-03-05 07:40:17 --> Router Class Initialized
INFO - 2016-03-05 07:40:17 --> Output Class Initialized
INFO - 2016-03-05 07:40:17 --> Security Class Initialized
DEBUG - 2016-03-05 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:40:17 --> Input Class Initialized
INFO - 2016-03-05 07:40:17 --> Language Class Initialized
INFO - 2016-03-05 07:40:17 --> Loader Class Initialized
INFO - 2016-03-05 07:40:17 --> Helper loaded: url_helper
INFO - 2016-03-05 07:40:17 --> Helper loaded: file_helper
INFO - 2016-03-05 07:40:17 --> Helper loaded: date_helper
INFO - 2016-03-05 07:40:17 --> Helper loaded: form_helper
INFO - 2016-03-05 07:40:17 --> Database Driver Class Initialized
INFO - 2016-03-05 07:40:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:40:17 --> Controller Class Initialized
INFO - 2016-03-05 07:40:17 --> Model Class Initialized
INFO - 2016-03-05 07:40:17 --> Model Class Initialized
INFO - 2016-03-05 07:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:40:17 --> Pagination Class Initialized
INFO - 2016-03-05 07:40:17 --> Helper loaded: text_helper
INFO - 2016-03-05 07:40:17 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:40:17 --> Final output sent to browser
DEBUG - 2016-03-05 10:40:17 --> Total execution time: 1.0911
INFO - 2016-03-05 07:40:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:40:18 --> Controller Class Initialized
INFO - 2016-03-05 07:40:18 --> Model Class Initialized
INFO - 2016-03-05 07:40:18 --> Model Class Initialized
INFO - 2016-03-05 07:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:40:18 --> Pagination Class Initialized
INFO - 2016-03-05 07:40:18 --> Helper loaded: text_helper
INFO - 2016-03-05 07:40:18 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:40:18 --> Final output sent to browser
DEBUG - 2016-03-05 10:40:18 --> Total execution time: 1.1097
INFO - 2016-03-05 07:40:29 --> Config Class Initialized
INFO - 2016-03-05 07:40:29 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:40:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:40:29 --> Utf8 Class Initialized
INFO - 2016-03-05 07:40:29 --> URI Class Initialized
INFO - 2016-03-05 07:40:29 --> Router Class Initialized
INFO - 2016-03-05 07:40:29 --> Output Class Initialized
INFO - 2016-03-05 07:40:29 --> Security Class Initialized
DEBUG - 2016-03-05 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:40:29 --> Input Class Initialized
INFO - 2016-03-05 07:40:29 --> Language Class Initialized
INFO - 2016-03-05 07:40:29 --> Loader Class Initialized
INFO - 2016-03-05 07:40:29 --> Helper loaded: url_helper
INFO - 2016-03-05 07:40:29 --> Helper loaded: file_helper
INFO - 2016-03-05 07:40:29 --> Helper loaded: date_helper
INFO - 2016-03-05 07:40:29 --> Helper loaded: form_helper
INFO - 2016-03-05 07:40:29 --> Database Driver Class Initialized
INFO - 2016-03-05 07:40:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:40:30 --> Controller Class Initialized
INFO - 2016-03-05 07:40:30 --> Model Class Initialized
INFO - 2016-03-05 07:40:30 --> Model Class Initialized
INFO - 2016-03-05 07:40:30 --> Form Validation Class Initialized
INFO - 2016-03-05 07:40:30 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:40:30 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:40:30 --> Final output sent to browser
DEBUG - 2016-03-05 07:40:30 --> Total execution time: 1.1193
INFO - 2016-03-05 07:40:43 --> Config Class Initialized
INFO - 2016-03-05 07:40:43 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:40:43 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:40:43 --> Utf8 Class Initialized
INFO - 2016-03-05 07:40:43 --> URI Class Initialized
DEBUG - 2016-03-05 07:40:43 --> No URI present. Default controller set.
INFO - 2016-03-05 07:40:43 --> Router Class Initialized
INFO - 2016-03-05 07:40:43 --> Output Class Initialized
INFO - 2016-03-05 07:40:43 --> Security Class Initialized
DEBUG - 2016-03-05 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:40:43 --> Input Class Initialized
INFO - 2016-03-05 07:40:44 --> Language Class Initialized
INFO - 2016-03-05 07:40:44 --> Loader Class Initialized
INFO - 2016-03-05 07:40:44 --> Helper loaded: url_helper
INFO - 2016-03-05 07:40:44 --> Helper loaded: file_helper
INFO - 2016-03-05 07:40:44 --> Helper loaded: date_helper
INFO - 2016-03-05 07:40:44 --> Helper loaded: form_helper
INFO - 2016-03-05 07:40:44 --> Database Driver Class Initialized
INFO - 2016-03-05 07:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:40:45 --> Controller Class Initialized
INFO - 2016-03-05 07:40:45 --> Model Class Initialized
INFO - 2016-03-05 07:40:45 --> Model Class Initialized
INFO - 2016-03-05 07:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:40:45 --> Pagination Class Initialized
INFO - 2016-03-05 07:40:45 --> Helper loaded: text_helper
INFO - 2016-03-05 07:40:45 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:40:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:40:45 --> Final output sent to browser
DEBUG - 2016-03-05 10:40:45 --> Total execution time: 1.1494
INFO - 2016-03-05 07:41:01 --> Config Class Initialized
INFO - 2016-03-05 07:41:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:41:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:41:01 --> Utf8 Class Initialized
INFO - 2016-03-05 07:41:01 --> URI Class Initialized
INFO - 2016-03-05 07:41:01 --> Router Class Initialized
INFO - 2016-03-05 07:41:01 --> Output Class Initialized
INFO - 2016-03-05 07:41:01 --> Security Class Initialized
DEBUG - 2016-03-05 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:41:01 --> Input Class Initialized
INFO - 2016-03-05 07:41:01 --> Language Class Initialized
INFO - 2016-03-05 07:41:01 --> Loader Class Initialized
INFO - 2016-03-05 07:41:01 --> Helper loaded: url_helper
INFO - 2016-03-05 07:41:01 --> Helper loaded: file_helper
INFO - 2016-03-05 07:41:01 --> Helper loaded: date_helper
INFO - 2016-03-05 07:41:01 --> Helper loaded: form_helper
INFO - 2016-03-05 07:41:01 --> Database Driver Class Initialized
INFO - 2016-03-05 07:41:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:41:02 --> Controller Class Initialized
INFO - 2016-03-05 07:41:02 --> Model Class Initialized
INFO - 2016-03-05 07:41:02 --> Model Class Initialized
INFO - 2016-03-05 07:41:02 --> Form Validation Class Initialized
INFO - 2016-03-05 07:41:02 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:41:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 106
INFO - 2016-03-05 07:41:02 --> Final output sent to browser
DEBUG - 2016-03-05 07:41:02 --> Total execution time: 1.1949
INFO - 2016-03-05 07:43:37 --> Config Class Initialized
INFO - 2016-03-05 07:43:37 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:43:37 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:43:37 --> Utf8 Class Initialized
INFO - 2016-03-05 07:43:38 --> URI Class Initialized
DEBUG - 2016-03-05 07:43:38 --> No URI present. Default controller set.
INFO - 2016-03-05 07:43:38 --> Router Class Initialized
INFO - 2016-03-05 07:43:38 --> Output Class Initialized
INFO - 2016-03-05 07:43:38 --> Security Class Initialized
DEBUG - 2016-03-05 07:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:43:38 --> Input Class Initialized
INFO - 2016-03-05 07:43:38 --> Language Class Initialized
INFO - 2016-03-05 07:43:38 --> Loader Class Initialized
INFO - 2016-03-05 07:43:38 --> Helper loaded: url_helper
INFO - 2016-03-05 07:43:38 --> Helper loaded: file_helper
INFO - 2016-03-05 07:43:38 --> Helper loaded: date_helper
INFO - 2016-03-05 07:43:38 --> Helper loaded: form_helper
INFO - 2016-03-05 07:43:38 --> Database Driver Class Initialized
INFO - 2016-03-05 07:43:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:43:39 --> Controller Class Initialized
INFO - 2016-03-05 07:43:39 --> Model Class Initialized
INFO - 2016-03-05 07:43:39 --> Model Class Initialized
INFO - 2016-03-05 07:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:43:39 --> Pagination Class Initialized
INFO - 2016-03-05 07:43:39 --> Helper loaded: text_helper
INFO - 2016-03-05 07:43:39 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:43:39 --> Final output sent to browser
DEBUG - 2016-03-05 10:43:39 --> Total execution time: 1.1314
INFO - 2016-03-05 07:43:43 --> Config Class Initialized
INFO - 2016-03-05 07:43:43 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:43:43 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:43:43 --> Utf8 Class Initialized
INFO - 2016-03-05 07:43:43 --> URI Class Initialized
INFO - 2016-03-05 07:43:43 --> Router Class Initialized
INFO - 2016-03-05 07:43:43 --> Output Class Initialized
INFO - 2016-03-05 07:43:43 --> Security Class Initialized
DEBUG - 2016-03-05 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:43:43 --> Input Class Initialized
INFO - 2016-03-05 07:43:43 --> Language Class Initialized
INFO - 2016-03-05 07:43:43 --> Loader Class Initialized
INFO - 2016-03-05 07:43:43 --> Helper loaded: url_helper
INFO - 2016-03-05 07:43:43 --> Helper loaded: file_helper
INFO - 2016-03-05 07:43:43 --> Helper loaded: date_helper
INFO - 2016-03-05 07:43:43 --> Helper loaded: form_helper
INFO - 2016-03-05 07:43:43 --> Database Driver Class Initialized
INFO - 2016-03-05 07:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:43:44 --> Controller Class Initialized
INFO - 2016-03-05 07:43:44 --> Model Class Initialized
INFO - 2016-03-05 07:43:44 --> Model Class Initialized
INFO - 2016-03-05 07:43:44 --> Form Validation Class Initialized
INFO - 2016-03-05 07:43:44 --> Helper loaded: text_helper
INFO - 2016-03-05 07:43:44 --> Final output sent to browser
DEBUG - 2016-03-05 07:43:44 --> Total execution time: 1.1144
INFO - 2016-03-05 07:43:57 --> Config Class Initialized
INFO - 2016-03-05 07:43:57 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:43:57 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:43:57 --> Utf8 Class Initialized
INFO - 2016-03-05 07:43:57 --> URI Class Initialized
DEBUG - 2016-03-05 07:43:57 --> No URI present. Default controller set.
INFO - 2016-03-05 07:43:57 --> Router Class Initialized
INFO - 2016-03-05 07:43:57 --> Output Class Initialized
INFO - 2016-03-05 07:43:57 --> Security Class Initialized
DEBUG - 2016-03-05 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:43:57 --> Input Class Initialized
INFO - 2016-03-05 07:43:57 --> Language Class Initialized
INFO - 2016-03-05 07:43:57 --> Loader Class Initialized
INFO - 2016-03-05 07:43:57 --> Helper loaded: url_helper
INFO - 2016-03-05 07:43:57 --> Helper loaded: file_helper
INFO - 2016-03-05 07:43:57 --> Helper loaded: date_helper
INFO - 2016-03-05 07:43:57 --> Helper loaded: form_helper
INFO - 2016-03-05 07:43:57 --> Database Driver Class Initialized
INFO - 2016-03-05 07:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:43:58 --> Controller Class Initialized
INFO - 2016-03-05 07:43:58 --> Model Class Initialized
INFO - 2016-03-05 07:43:58 --> Model Class Initialized
INFO - 2016-03-05 07:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:43:58 --> Pagination Class Initialized
INFO - 2016-03-05 07:43:58 --> Helper loaded: text_helper
INFO - 2016-03-05 07:43:58 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:43:58 --> Final output sent to browser
DEBUG - 2016-03-05 10:43:58 --> Total execution time: 1.1365
INFO - 2016-03-05 07:44:11 --> Config Class Initialized
INFO - 2016-03-05 07:44:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:44:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:44:11 --> Utf8 Class Initialized
INFO - 2016-03-05 07:44:11 --> URI Class Initialized
INFO - 2016-03-05 07:44:11 --> Router Class Initialized
INFO - 2016-03-05 07:44:11 --> Output Class Initialized
INFO - 2016-03-05 07:44:11 --> Security Class Initialized
DEBUG - 2016-03-05 07:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:44:11 --> Input Class Initialized
INFO - 2016-03-05 07:44:11 --> Language Class Initialized
INFO - 2016-03-05 07:44:11 --> Loader Class Initialized
INFO - 2016-03-05 07:44:11 --> Helper loaded: url_helper
INFO - 2016-03-05 07:44:11 --> Helper loaded: file_helper
INFO - 2016-03-05 07:44:11 --> Helper loaded: date_helper
INFO - 2016-03-05 07:44:11 --> Helper loaded: form_helper
INFO - 2016-03-05 07:44:11 --> Database Driver Class Initialized
INFO - 2016-03-05 07:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:44:12 --> Controller Class Initialized
INFO - 2016-03-05 07:44:12 --> Model Class Initialized
INFO - 2016-03-05 07:44:12 --> Model Class Initialized
INFO - 2016-03-05 07:44:12 --> Form Validation Class Initialized
INFO - 2016-03-05 07:44:12 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:44:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 07:44:12 --> Final output sent to browser
DEBUG - 2016-03-05 07:44:12 --> Total execution time: 1.0935
INFO - 2016-03-05 07:50:32 --> Config Class Initialized
INFO - 2016-03-05 07:50:32 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:50:32 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:50:32 --> Utf8 Class Initialized
INFO - 2016-03-05 07:50:32 --> URI Class Initialized
DEBUG - 2016-03-05 07:50:32 --> No URI present. Default controller set.
INFO - 2016-03-05 07:50:32 --> Router Class Initialized
INFO - 2016-03-05 07:50:32 --> Output Class Initialized
INFO - 2016-03-05 07:50:32 --> Security Class Initialized
DEBUG - 2016-03-05 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:50:33 --> Input Class Initialized
INFO - 2016-03-05 07:50:33 --> Language Class Initialized
INFO - 2016-03-05 07:50:33 --> Loader Class Initialized
INFO - 2016-03-05 07:50:33 --> Helper loaded: url_helper
INFO - 2016-03-05 07:50:33 --> Helper loaded: file_helper
INFO - 2016-03-05 07:50:33 --> Helper loaded: date_helper
INFO - 2016-03-05 07:50:33 --> Helper loaded: form_helper
INFO - 2016-03-05 07:50:33 --> Database Driver Class Initialized
INFO - 2016-03-05 07:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:50:34 --> Controller Class Initialized
INFO - 2016-03-05 07:50:34 --> Model Class Initialized
INFO - 2016-03-05 07:50:34 --> Model Class Initialized
INFO - 2016-03-05 07:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:50:34 --> Pagination Class Initialized
INFO - 2016-03-05 07:50:34 --> Helper loaded: text_helper
INFO - 2016-03-05 07:50:34 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:50:34 --> Final output sent to browser
DEBUG - 2016-03-05 10:50:34 --> Total execution time: 1.1732
INFO - 2016-03-05 07:50:44 --> Config Class Initialized
INFO - 2016-03-05 07:50:44 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:50:44 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:50:44 --> Utf8 Class Initialized
INFO - 2016-03-05 07:50:44 --> URI Class Initialized
INFO - 2016-03-05 07:50:44 --> Router Class Initialized
INFO - 2016-03-05 07:50:44 --> Output Class Initialized
INFO - 2016-03-05 07:50:44 --> Security Class Initialized
DEBUG - 2016-03-05 07:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:50:44 --> Input Class Initialized
INFO - 2016-03-05 07:50:44 --> Language Class Initialized
INFO - 2016-03-05 07:50:44 --> Loader Class Initialized
INFO - 2016-03-05 07:50:44 --> Helper loaded: url_helper
INFO - 2016-03-05 07:50:44 --> Helper loaded: file_helper
INFO - 2016-03-05 07:50:44 --> Helper loaded: date_helper
INFO - 2016-03-05 07:50:44 --> Helper loaded: form_helper
INFO - 2016-03-05 07:50:44 --> Database Driver Class Initialized
INFO - 2016-03-05 07:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:50:45 --> Controller Class Initialized
INFO - 2016-03-05 07:50:45 --> Model Class Initialized
INFO - 2016-03-05 07:50:45 --> Model Class Initialized
INFO - 2016-03-05 07:50:45 --> Form Validation Class Initialized
INFO - 2016-03-05 07:50:45 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:50:45 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\user_model.php 73
ERROR - 2016-03-05 07:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 07:50:45 --> Final output sent to browser
DEBUG - 2016-03-05 07:50:45 --> Total execution time: 1.1195
INFO - 2016-03-05 07:51:26 --> Config Class Initialized
INFO - 2016-03-05 07:51:26 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:51:26 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:51:26 --> Utf8 Class Initialized
INFO - 2016-03-05 07:51:26 --> URI Class Initialized
DEBUG - 2016-03-05 07:51:26 --> No URI present. Default controller set.
INFO - 2016-03-05 07:51:26 --> Router Class Initialized
INFO - 2016-03-05 07:51:26 --> Output Class Initialized
INFO - 2016-03-05 07:51:26 --> Security Class Initialized
DEBUG - 2016-03-05 07:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:51:26 --> Input Class Initialized
INFO - 2016-03-05 07:51:26 --> Language Class Initialized
INFO - 2016-03-05 07:51:26 --> Loader Class Initialized
INFO - 2016-03-05 07:51:26 --> Helper loaded: url_helper
INFO - 2016-03-05 07:51:26 --> Helper loaded: file_helper
INFO - 2016-03-05 07:51:26 --> Helper loaded: date_helper
INFO - 2016-03-05 07:51:26 --> Helper loaded: form_helper
INFO - 2016-03-05 07:51:26 --> Database Driver Class Initialized
INFO - 2016-03-05 07:51:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:51:27 --> Controller Class Initialized
INFO - 2016-03-05 07:51:27 --> Model Class Initialized
INFO - 2016-03-05 07:51:27 --> Model Class Initialized
INFO - 2016-03-05 07:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:51:27 --> Pagination Class Initialized
INFO - 2016-03-05 07:51:27 --> Helper loaded: text_helper
INFO - 2016-03-05 07:51:27 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:51:27 --> Final output sent to browser
DEBUG - 2016-03-05 10:51:27 --> Total execution time: 1.1904
INFO - 2016-03-05 07:51:39 --> Config Class Initialized
INFO - 2016-03-05 07:51:39 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:51:39 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:51:39 --> Utf8 Class Initialized
INFO - 2016-03-05 07:51:39 --> URI Class Initialized
INFO - 2016-03-05 07:51:39 --> Router Class Initialized
INFO - 2016-03-05 07:51:39 --> Output Class Initialized
INFO - 2016-03-05 07:51:39 --> Security Class Initialized
DEBUG - 2016-03-05 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:51:39 --> Input Class Initialized
INFO - 2016-03-05 07:51:39 --> Language Class Initialized
INFO - 2016-03-05 07:51:39 --> Loader Class Initialized
INFO - 2016-03-05 07:51:39 --> Helper loaded: url_helper
INFO - 2016-03-05 07:51:39 --> Helper loaded: file_helper
INFO - 2016-03-05 07:51:39 --> Helper loaded: date_helper
INFO - 2016-03-05 07:51:39 --> Helper loaded: form_helper
INFO - 2016-03-05 07:51:39 --> Database Driver Class Initialized
INFO - 2016-03-05 07:51:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:51:40 --> Controller Class Initialized
INFO - 2016-03-05 07:51:40 --> Model Class Initialized
INFO - 2016-03-05 07:51:40 --> Model Class Initialized
INFO - 2016-03-05 07:51:40 --> Form Validation Class Initialized
INFO - 2016-03-05 07:51:40 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:51:40 --> Severity: Notice --> Object of class CI_DB_mysqli_result could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\user_model.php 73
ERROR - 2016-03-05 07:51:40 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 07:51:40 --> Final output sent to browser
DEBUG - 2016-03-05 07:51:40 --> Total execution time: 1.1382
INFO - 2016-03-05 07:52:15 --> Config Class Initialized
INFO - 2016-03-05 07:52:15 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:52:15 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:52:15 --> Utf8 Class Initialized
INFO - 2016-03-05 07:52:15 --> URI Class Initialized
DEBUG - 2016-03-05 07:52:15 --> No URI present. Default controller set.
INFO - 2016-03-05 07:52:15 --> Router Class Initialized
INFO - 2016-03-05 07:52:15 --> Output Class Initialized
INFO - 2016-03-05 07:52:15 --> Security Class Initialized
DEBUG - 2016-03-05 07:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:52:15 --> Input Class Initialized
INFO - 2016-03-05 07:52:15 --> Language Class Initialized
INFO - 2016-03-05 07:52:15 --> Loader Class Initialized
INFO - 2016-03-05 07:52:15 --> Helper loaded: url_helper
INFO - 2016-03-05 07:52:15 --> Helper loaded: file_helper
INFO - 2016-03-05 07:52:15 --> Helper loaded: date_helper
INFO - 2016-03-05 07:52:15 --> Helper loaded: form_helper
INFO - 2016-03-05 07:52:15 --> Database Driver Class Initialized
INFO - 2016-03-05 07:52:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:52:16 --> Controller Class Initialized
INFO - 2016-03-05 07:52:16 --> Model Class Initialized
INFO - 2016-03-05 07:52:16 --> Model Class Initialized
INFO - 2016-03-05 07:52:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:52:16 --> Pagination Class Initialized
INFO - 2016-03-05 07:52:16 --> Helper loaded: text_helper
INFO - 2016-03-05 07:52:16 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:52:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:52:16 --> Final output sent to browser
DEBUG - 2016-03-05 10:52:16 --> Total execution time: 1.1718
INFO - 2016-03-05 07:52:23 --> Config Class Initialized
INFO - 2016-03-05 07:52:23 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:52:23 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:52:23 --> Utf8 Class Initialized
INFO - 2016-03-05 07:52:23 --> URI Class Initialized
DEBUG - 2016-03-05 07:52:23 --> No URI present. Default controller set.
INFO - 2016-03-05 07:52:23 --> Router Class Initialized
INFO - 2016-03-05 07:52:23 --> Output Class Initialized
INFO - 2016-03-05 07:52:23 --> Security Class Initialized
DEBUG - 2016-03-05 07:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:52:23 --> Input Class Initialized
INFO - 2016-03-05 07:52:23 --> Language Class Initialized
INFO - 2016-03-05 07:52:23 --> Loader Class Initialized
INFO - 2016-03-05 07:52:23 --> Helper loaded: url_helper
INFO - 2016-03-05 07:52:23 --> Helper loaded: file_helper
INFO - 2016-03-05 07:52:23 --> Helper loaded: date_helper
INFO - 2016-03-05 07:52:23 --> Helper loaded: form_helper
INFO - 2016-03-05 07:52:23 --> Database Driver Class Initialized
INFO - 2016-03-05 07:52:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:52:24 --> Controller Class Initialized
INFO - 2016-03-05 07:52:24 --> Model Class Initialized
INFO - 2016-03-05 07:52:24 --> Model Class Initialized
INFO - 2016-03-05 07:52:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:52:24 --> Pagination Class Initialized
INFO - 2016-03-05 07:52:24 --> Helper loaded: text_helper
INFO - 2016-03-05 07:52:24 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:52:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:52:24 --> Final output sent to browser
DEBUG - 2016-03-05 10:52:24 --> Total execution time: 1.1391
INFO - 2016-03-05 07:52:33 --> Config Class Initialized
INFO - 2016-03-05 07:52:33 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:52:33 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:52:33 --> Utf8 Class Initialized
INFO - 2016-03-05 07:52:33 --> URI Class Initialized
INFO - 2016-03-05 07:52:33 --> Router Class Initialized
INFO - 2016-03-05 07:52:33 --> Output Class Initialized
INFO - 2016-03-05 07:52:33 --> Security Class Initialized
DEBUG - 2016-03-05 07:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:52:33 --> Input Class Initialized
INFO - 2016-03-05 07:52:33 --> Language Class Initialized
INFO - 2016-03-05 07:52:33 --> Loader Class Initialized
INFO - 2016-03-05 07:52:33 --> Helper loaded: url_helper
INFO - 2016-03-05 07:52:33 --> Helper loaded: file_helper
INFO - 2016-03-05 07:52:33 --> Helper loaded: date_helper
INFO - 2016-03-05 07:52:33 --> Helper loaded: form_helper
INFO - 2016-03-05 07:52:33 --> Database Driver Class Initialized
INFO - 2016-03-05 07:52:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:52:34 --> Controller Class Initialized
INFO - 2016-03-05 07:52:34 --> Model Class Initialized
INFO - 2016-03-05 07:52:34 --> Model Class Initialized
INFO - 2016-03-05 07:52:34 --> Form Validation Class Initialized
INFO - 2016-03-05 07:52:34 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:52:34 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 07:52:34 --> Final output sent to browser
DEBUG - 2016-03-05 07:52:34 --> Total execution time: 1.1148
INFO - 2016-03-05 07:54:56 --> Config Class Initialized
INFO - 2016-03-05 07:54:56 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:54:57 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:54:57 --> Utf8 Class Initialized
INFO - 2016-03-05 07:54:57 --> URI Class Initialized
DEBUG - 2016-03-05 07:54:57 --> No URI present. Default controller set.
INFO - 2016-03-05 07:54:57 --> Router Class Initialized
INFO - 2016-03-05 07:54:57 --> Output Class Initialized
INFO - 2016-03-05 07:54:57 --> Security Class Initialized
DEBUG - 2016-03-05 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:54:57 --> Input Class Initialized
INFO - 2016-03-05 07:54:57 --> Language Class Initialized
INFO - 2016-03-05 07:54:57 --> Loader Class Initialized
INFO - 2016-03-05 07:54:57 --> Helper loaded: url_helper
INFO - 2016-03-05 07:54:57 --> Helper loaded: file_helper
INFO - 2016-03-05 07:54:57 --> Helper loaded: date_helper
INFO - 2016-03-05 07:54:57 --> Helper loaded: form_helper
INFO - 2016-03-05 07:54:57 --> Database Driver Class Initialized
INFO - 2016-03-05 07:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:54:58 --> Controller Class Initialized
INFO - 2016-03-05 07:54:58 --> Model Class Initialized
INFO - 2016-03-05 07:54:58 --> Model Class Initialized
INFO - 2016-03-05 07:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 07:54:58 --> Pagination Class Initialized
INFO - 2016-03-05 07:54:58 --> Helper loaded: text_helper
INFO - 2016-03-05 07:54:58 --> Helper loaded: cookie_helper
INFO - 2016-03-05 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 10:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 10:54:58 --> Final output sent to browser
DEBUG - 2016-03-05 10:54:58 --> Total execution time: 1.1588
INFO - 2016-03-05 07:55:09 --> Config Class Initialized
INFO - 2016-03-05 07:55:09 --> Hooks Class Initialized
DEBUG - 2016-03-05 07:55:09 --> UTF-8 Support Enabled
INFO - 2016-03-05 07:55:09 --> Utf8 Class Initialized
INFO - 2016-03-05 07:55:09 --> URI Class Initialized
INFO - 2016-03-05 07:55:09 --> Router Class Initialized
INFO - 2016-03-05 07:55:09 --> Output Class Initialized
INFO - 2016-03-05 07:55:09 --> Security Class Initialized
DEBUG - 2016-03-05 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 07:55:09 --> Input Class Initialized
INFO - 2016-03-05 07:55:09 --> Language Class Initialized
INFO - 2016-03-05 07:55:09 --> Loader Class Initialized
INFO - 2016-03-05 07:55:09 --> Helper loaded: url_helper
INFO - 2016-03-05 07:55:09 --> Helper loaded: file_helper
INFO - 2016-03-05 07:55:09 --> Helper loaded: date_helper
INFO - 2016-03-05 07:55:09 --> Helper loaded: form_helper
INFO - 2016-03-05 07:55:09 --> Database Driver Class Initialized
INFO - 2016-03-05 07:55:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 07:55:10 --> Controller Class Initialized
INFO - 2016-03-05 07:55:10 --> Model Class Initialized
INFO - 2016-03-05 07:55:10 --> Model Class Initialized
INFO - 2016-03-05 07:55:10 --> Form Validation Class Initialized
INFO - 2016-03-05 07:55:10 --> Helper loaded: text_helper
ERROR - 2016-03-05 07:55:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 110
INFO - 2016-03-05 07:55:10 --> Final output sent to browser
DEBUG - 2016-03-05 07:55:10 --> Total execution time: 1.1171
INFO - 2016-03-05 08:02:00 --> Config Class Initialized
INFO - 2016-03-05 08:02:00 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:02:00 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:02:00 --> Utf8 Class Initialized
INFO - 2016-03-05 08:02:00 --> URI Class Initialized
DEBUG - 2016-03-05 08:02:00 --> No URI present. Default controller set.
INFO - 2016-03-05 08:02:00 --> Router Class Initialized
INFO - 2016-03-05 08:02:00 --> Output Class Initialized
INFO - 2016-03-05 08:02:00 --> Security Class Initialized
DEBUG - 2016-03-05 08:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:02:00 --> Input Class Initialized
INFO - 2016-03-05 08:02:00 --> Language Class Initialized
INFO - 2016-03-05 08:02:00 --> Loader Class Initialized
INFO - 2016-03-05 08:02:00 --> Helper loaded: url_helper
INFO - 2016-03-05 08:02:00 --> Helper loaded: file_helper
INFO - 2016-03-05 08:02:00 --> Helper loaded: date_helper
INFO - 2016-03-05 08:02:00 --> Helper loaded: form_helper
INFO - 2016-03-05 08:02:00 --> Database Driver Class Initialized
INFO - 2016-03-05 08:02:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:02:01 --> Controller Class Initialized
INFO - 2016-03-05 08:02:01 --> Model Class Initialized
INFO - 2016-03-05 08:02:01 --> Model Class Initialized
INFO - 2016-03-05 08:02:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:02:01 --> Pagination Class Initialized
INFO - 2016-03-05 08:02:01 --> Helper loaded: text_helper
INFO - 2016-03-05 08:02:01 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:02:01 --> Final output sent to browser
DEBUG - 2016-03-05 11:02:01 --> Total execution time: 1.1756
INFO - 2016-03-05 08:02:12 --> Config Class Initialized
INFO - 2016-03-05 08:02:12 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:02:12 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:02:12 --> Utf8 Class Initialized
INFO - 2016-03-05 08:02:12 --> URI Class Initialized
INFO - 2016-03-05 08:02:12 --> Router Class Initialized
INFO - 2016-03-05 08:02:12 --> Output Class Initialized
INFO - 2016-03-05 08:02:12 --> Security Class Initialized
DEBUG - 2016-03-05 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:02:12 --> Input Class Initialized
INFO - 2016-03-05 08:02:12 --> Language Class Initialized
INFO - 2016-03-05 08:02:12 --> Loader Class Initialized
INFO - 2016-03-05 08:02:12 --> Helper loaded: url_helper
INFO - 2016-03-05 08:02:12 --> Helper loaded: file_helper
INFO - 2016-03-05 08:02:12 --> Helper loaded: date_helper
INFO - 2016-03-05 08:02:12 --> Helper loaded: form_helper
INFO - 2016-03-05 08:02:12 --> Database Driver Class Initialized
INFO - 2016-03-05 08:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:02:14 --> Controller Class Initialized
INFO - 2016-03-05 08:02:14 --> Model Class Initialized
INFO - 2016-03-05 08:02:14 --> Model Class Initialized
INFO - 2016-03-05 08:02:14 --> Form Validation Class Initialized
INFO - 2016-03-05 08:02:14 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:02:14 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:02:14 --> Final output sent to browser
DEBUG - 2016-03-05 08:02:14 --> Total execution time: 1.1349
INFO - 2016-03-05 08:04:12 --> Config Class Initialized
INFO - 2016-03-05 08:04:12 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:12 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:12 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:12 --> URI Class Initialized
DEBUG - 2016-03-05 08:04:12 --> No URI present. Default controller set.
INFO - 2016-03-05 08:04:12 --> Router Class Initialized
INFO - 2016-03-05 08:04:12 --> Output Class Initialized
INFO - 2016-03-05 08:04:12 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:12 --> Input Class Initialized
INFO - 2016-03-05 08:04:12 --> Language Class Initialized
INFO - 2016-03-05 08:04:12 --> Loader Class Initialized
INFO - 2016-03-05 08:04:12 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:12 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:12 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:12 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:12 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:14 --> Controller Class Initialized
INFO - 2016-03-05 08:04:14 --> Model Class Initialized
INFO - 2016-03-05 08:04:14 --> Model Class Initialized
INFO - 2016-03-05 08:04:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:04:14 --> Pagination Class Initialized
INFO - 2016-03-05 08:04:14 --> Helper loaded: text_helper
INFO - 2016-03-05 08:04:14 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:04:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:04:14 --> Final output sent to browser
DEBUG - 2016-03-05 11:04:14 --> Total execution time: 1.1005
INFO - 2016-03-05 08:04:19 --> Config Class Initialized
INFO - 2016-03-05 08:04:19 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:19 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:19 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:19 --> URI Class Initialized
DEBUG - 2016-03-05 08:04:19 --> No URI present. Default controller set.
INFO - 2016-03-05 08:04:19 --> Router Class Initialized
INFO - 2016-03-05 08:04:19 --> Output Class Initialized
INFO - 2016-03-05 08:04:19 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:19 --> Input Class Initialized
INFO - 2016-03-05 08:04:19 --> Language Class Initialized
INFO - 2016-03-05 08:04:19 --> Loader Class Initialized
INFO - 2016-03-05 08:04:19 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:19 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:19 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:19 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:19 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:20 --> Controller Class Initialized
INFO - 2016-03-05 08:04:20 --> Model Class Initialized
INFO - 2016-03-05 08:04:20 --> Model Class Initialized
INFO - 2016-03-05 08:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:04:20 --> Pagination Class Initialized
INFO - 2016-03-05 08:04:20 --> Helper loaded: text_helper
INFO - 2016-03-05 08:04:20 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:04:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:04:20 --> Final output sent to browser
DEBUG - 2016-03-05 11:04:20 --> Total execution time: 1.1338
INFO - 2016-03-05 08:04:25 --> Config Class Initialized
INFO - 2016-03-05 08:04:25 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:25 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:25 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:25 --> URI Class Initialized
INFO - 2016-03-05 08:04:25 --> Router Class Initialized
INFO - 2016-03-05 08:04:25 --> Output Class Initialized
INFO - 2016-03-05 08:04:25 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:25 --> Input Class Initialized
INFO - 2016-03-05 08:04:25 --> Language Class Initialized
INFO - 2016-03-05 08:04:25 --> Loader Class Initialized
INFO - 2016-03-05 08:04:25 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:25 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:25 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:25 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:25 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:26 --> Controller Class Initialized
INFO - 2016-03-05 08:04:26 --> Model Class Initialized
INFO - 2016-03-05 08:04:26 --> Model Class Initialized
INFO - 2016-03-05 08:04:26 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:26 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:26 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:26 --> Total execution time: 1.1149
INFO - 2016-03-05 08:04:29 --> Config Class Initialized
INFO - 2016-03-05 08:04:29 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:29 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:29 --> URI Class Initialized
INFO - 2016-03-05 08:04:29 --> Router Class Initialized
INFO - 2016-03-05 08:04:29 --> Output Class Initialized
INFO - 2016-03-05 08:04:29 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:29 --> Input Class Initialized
INFO - 2016-03-05 08:04:29 --> Language Class Initialized
INFO - 2016-03-05 08:04:29 --> Loader Class Initialized
INFO - 2016-03-05 08:04:29 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:29 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:29 --> Config Class Initialized
INFO - 2016-03-05 08:04:29 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:29 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:29 --> URI Class Initialized
INFO - 2016-03-05 08:04:29 --> Router Class Initialized
INFO - 2016-03-05 08:04:29 --> Output Class Initialized
INFO - 2016-03-05 08:04:29 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:29 --> Input Class Initialized
INFO - 2016-03-05 08:04:29 --> Language Class Initialized
INFO - 2016-03-05 08:04:29 --> Loader Class Initialized
INFO - 2016-03-05 08:04:29 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:29 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:29 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Config Class Initialized
INFO - 2016-03-05 08:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:30 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:30 --> URI Class Initialized
INFO - 2016-03-05 08:04:30 --> Router Class Initialized
INFO - 2016-03-05 08:04:30 --> Output Class Initialized
INFO - 2016-03-05 08:04:30 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:30 --> Input Class Initialized
INFO - 2016-03-05 08:04:30 --> Language Class Initialized
INFO - 2016-03-05 08:04:30 --> Loader Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:30 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Config Class Initialized
INFO - 2016-03-05 08:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:30 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:30 --> URI Class Initialized
INFO - 2016-03-05 08:04:30 --> Router Class Initialized
INFO - 2016-03-05 08:04:30 --> Output Class Initialized
INFO - 2016-03-05 08:04:30 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:30 --> Input Class Initialized
INFO - 2016-03-05 08:04:30 --> Language Class Initialized
INFO - 2016-03-05 08:04:30 --> Loader Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:30 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Config Class Initialized
INFO - 2016-03-05 08:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:30 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:30 --> URI Class Initialized
INFO - 2016-03-05 08:04:30 --> Router Class Initialized
INFO - 2016-03-05 08:04:30 --> Output Class Initialized
INFO - 2016-03-05 08:04:30 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:30 --> Input Class Initialized
INFO - 2016-03-05 08:04:30 --> Language Class Initialized
INFO - 2016-03-05 08:04:30 --> Loader Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:30 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Config Class Initialized
INFO - 2016-03-05 08:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:30 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:30 --> URI Class Initialized
INFO - 2016-03-05 08:04:30 --> Router Class Initialized
INFO - 2016-03-05 08:04:30 --> Output Class Initialized
INFO - 2016-03-05 08:04:30 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:30 --> Input Class Initialized
INFO - 2016-03-05 08:04:30 --> Language Class Initialized
INFO - 2016-03-05 08:04:30 --> Loader Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:30 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:30 --> Controller Class Initialized
INFO - 2016-03-05 08:04:30 --> Model Class Initialized
INFO - 2016-03-05 08:04:30 --> Model Class Initialized
INFO - 2016-03-05 08:04:30 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:30 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:30 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:30 --> Total execution time: 1.1176
INFO - 2016-03-05 08:04:30 --> Config Class Initialized
INFO - 2016-03-05 08:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:30 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:30 --> URI Class Initialized
INFO - 2016-03-05 08:04:30 --> Router Class Initialized
INFO - 2016-03-05 08:04:30 --> Output Class Initialized
INFO - 2016-03-05 08:04:30 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:30 --> Input Class Initialized
INFO - 2016-03-05 08:04:30 --> Language Class Initialized
INFO - 2016-03-05 08:04:30 --> Loader Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:30 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:30 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:30 --> Controller Class Initialized
INFO - 2016-03-05 08:04:30 --> Model Class Initialized
INFO - 2016-03-05 08:04:30 --> Model Class Initialized
INFO - 2016-03-05 08:04:30 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:30 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.1015
INFO - 2016-03-05 08:04:31 --> Config Class Initialized
INFO - 2016-03-05 08:04:31 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:31 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:31 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:31 --> URI Class Initialized
INFO - 2016-03-05 08:04:31 --> Router Class Initialized
INFO - 2016-03-05 08:04:31 --> Output Class Initialized
INFO - 2016-03-05 08:04:31 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:31 --> Input Class Initialized
INFO - 2016-03-05 08:04:31 --> Language Class Initialized
INFO - 2016-03-05 08:04:31 --> Loader Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:31 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:31 --> Controller Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.0736
INFO - 2016-03-05 08:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:31 --> Controller Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.1158
INFO - 2016-03-05 08:04:31 --> Config Class Initialized
INFO - 2016-03-05 08:04:31 --> Hooks Class Initialized
INFO - 2016-03-05 08:04:31 --> Session: Class initialized using 'database' driver.
DEBUG - 2016-03-05 08:04:31 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:31 --> Controller Class Initialized
INFO - 2016-03-05 08:04:31 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> URI Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Router Class Initialized
INFO - 2016-03-05 08:04:31 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:31 --> Output Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: text_helper
INFO - 2016-03-05 08:04:31 --> Security Class Initialized
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
DEBUG - 2016-03-05 08:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
INFO - 2016-03-05 08:04:31 --> Input Class Initialized
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.1089
INFO - 2016-03-05 08:04:31 --> Language Class Initialized
INFO - 2016-03-05 08:04:31 --> Loader Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:31 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:31 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:31 --> Controller Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.0911
INFO - 2016-03-05 08:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:31 --> Controller Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Model Class Initialized
INFO - 2016-03-05 08:04:31 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:31 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:31 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:31 --> Total execution time: 1.1104
INFO - 2016-03-05 08:04:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:32 --> Controller Class Initialized
INFO - 2016-03-05 08:04:32 --> Model Class Initialized
INFO - 2016-03-05 08:04:32 --> Model Class Initialized
INFO - 2016-03-05 08:04:32 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:32 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:32 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:32 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:32 --> Total execution time: 1.1216
INFO - 2016-03-05 08:04:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:32 --> Controller Class Initialized
INFO - 2016-03-05 08:04:32 --> Model Class Initialized
INFO - 2016-03-05 08:04:32 --> Model Class Initialized
INFO - 2016-03-05 08:04:32 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:32 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:32 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:32 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:32 --> Total execution time: 1.1408
INFO - 2016-03-05 08:04:48 --> Config Class Initialized
INFO - 2016-03-05 08:04:48 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:48 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:48 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:48 --> URI Class Initialized
INFO - 2016-03-05 08:04:48 --> Router Class Initialized
INFO - 2016-03-05 08:04:48 --> Output Class Initialized
INFO - 2016-03-05 08:04:48 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:48 --> Input Class Initialized
INFO - 2016-03-05 08:04:48 --> Language Class Initialized
INFO - 2016-03-05 08:04:48 --> Loader Class Initialized
INFO - 2016-03-05 08:04:48 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:48 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:48 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:48 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:48 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:49 --> Controller Class Initialized
INFO - 2016-03-05 08:04:49 --> Model Class Initialized
INFO - 2016-03-05 08:04:49 --> Model Class Initialized
INFO - 2016-03-05 08:04:49 --> Form Validation Class Initialized
INFO - 2016-03-05 08:04:49 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:04:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:04:49 --> Final output sent to browser
DEBUG - 2016-03-05 08:04:50 --> Total execution time: 1.1291
INFO - 2016-03-05 08:04:52 --> Config Class Initialized
INFO - 2016-03-05 08:04:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:04:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:04:52 --> Utf8 Class Initialized
INFO - 2016-03-05 08:04:52 --> URI Class Initialized
DEBUG - 2016-03-05 08:04:52 --> No URI present. Default controller set.
INFO - 2016-03-05 08:04:52 --> Router Class Initialized
INFO - 2016-03-05 08:04:52 --> Output Class Initialized
INFO - 2016-03-05 08:04:52 --> Security Class Initialized
DEBUG - 2016-03-05 08:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:04:52 --> Input Class Initialized
INFO - 2016-03-05 08:04:52 --> Language Class Initialized
INFO - 2016-03-05 08:04:52 --> Loader Class Initialized
INFO - 2016-03-05 08:04:52 --> Helper loaded: url_helper
INFO - 2016-03-05 08:04:52 --> Helper loaded: file_helper
INFO - 2016-03-05 08:04:52 --> Helper loaded: date_helper
INFO - 2016-03-05 08:04:52 --> Helper loaded: form_helper
INFO - 2016-03-05 08:04:52 --> Database Driver Class Initialized
INFO - 2016-03-05 08:04:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:04:53 --> Controller Class Initialized
INFO - 2016-03-05 08:04:53 --> Model Class Initialized
INFO - 2016-03-05 08:04:53 --> Model Class Initialized
INFO - 2016-03-05 08:04:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:04:53 --> Pagination Class Initialized
INFO - 2016-03-05 08:04:53 --> Helper loaded: text_helper
INFO - 2016-03-05 08:04:53 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:04:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:04:53 --> Final output sent to browser
DEBUG - 2016-03-05 11:04:53 --> Total execution time: 1.1488
INFO - 2016-03-05 08:05:55 --> Config Class Initialized
INFO - 2016-03-05 08:05:55 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:05:55 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:05:55 --> Utf8 Class Initialized
INFO - 2016-03-05 08:05:55 --> URI Class Initialized
DEBUG - 2016-03-05 08:05:55 --> No URI present. Default controller set.
INFO - 2016-03-05 08:05:55 --> Router Class Initialized
INFO - 2016-03-05 08:05:55 --> Output Class Initialized
INFO - 2016-03-05 08:05:55 --> Security Class Initialized
DEBUG - 2016-03-05 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:05:55 --> Input Class Initialized
INFO - 2016-03-05 08:05:55 --> Language Class Initialized
INFO - 2016-03-05 08:05:55 --> Loader Class Initialized
INFO - 2016-03-05 08:05:55 --> Helper loaded: url_helper
INFO - 2016-03-05 08:05:55 --> Helper loaded: file_helper
INFO - 2016-03-05 08:05:55 --> Helper loaded: date_helper
INFO - 2016-03-05 08:05:55 --> Helper loaded: form_helper
INFO - 2016-03-05 08:05:55 --> Database Driver Class Initialized
INFO - 2016-03-05 08:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:05:56 --> Controller Class Initialized
INFO - 2016-03-05 08:05:56 --> Model Class Initialized
INFO - 2016-03-05 08:05:56 --> Model Class Initialized
INFO - 2016-03-05 08:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:05:56 --> Pagination Class Initialized
INFO - 2016-03-05 08:05:56 --> Helper loaded: text_helper
INFO - 2016-03-05 08:05:56 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:05:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:05:56 --> Final output sent to browser
DEBUG - 2016-03-05 11:05:56 --> Total execution time: 1.1285
INFO - 2016-03-05 08:06:08 --> Config Class Initialized
INFO - 2016-03-05 08:06:08 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:06:08 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:06:08 --> Utf8 Class Initialized
INFO - 2016-03-05 08:06:08 --> URI Class Initialized
INFO - 2016-03-05 08:06:08 --> Router Class Initialized
INFO - 2016-03-05 08:06:08 --> Output Class Initialized
INFO - 2016-03-05 08:06:08 --> Security Class Initialized
DEBUG - 2016-03-05 08:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:06:08 --> Input Class Initialized
INFO - 2016-03-05 08:06:08 --> Language Class Initialized
INFO - 2016-03-05 08:06:08 --> Loader Class Initialized
INFO - 2016-03-05 08:06:08 --> Helper loaded: url_helper
INFO - 2016-03-05 08:06:08 --> Helper loaded: file_helper
INFO - 2016-03-05 08:06:08 --> Helper loaded: date_helper
INFO - 2016-03-05 08:06:08 --> Helper loaded: form_helper
INFO - 2016-03-05 08:06:08 --> Database Driver Class Initialized
INFO - 2016-03-05 08:06:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:06:09 --> Controller Class Initialized
INFO - 2016-03-05 08:06:09 --> Model Class Initialized
INFO - 2016-03-05 08:06:09 --> Model Class Initialized
INFO - 2016-03-05 08:06:09 --> Form Validation Class Initialized
INFO - 2016-03-05 08:06:09 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:06:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:06:09 --> Final output sent to browser
DEBUG - 2016-03-05 08:06:09 --> Total execution time: 1.1193
INFO - 2016-03-05 08:15:16 --> Config Class Initialized
INFO - 2016-03-05 08:15:16 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:15:16 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:15:16 --> Utf8 Class Initialized
INFO - 2016-03-05 08:15:16 --> URI Class Initialized
INFO - 2016-03-05 08:15:16 --> Router Class Initialized
INFO - 2016-03-05 08:15:16 --> Output Class Initialized
INFO - 2016-03-05 08:15:16 --> Security Class Initialized
DEBUG - 2016-03-05 08:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:15:16 --> Input Class Initialized
INFO - 2016-03-05 08:15:16 --> Language Class Initialized
INFO - 2016-03-05 08:15:16 --> Loader Class Initialized
INFO - 2016-03-05 08:15:16 --> Helper loaded: url_helper
INFO - 2016-03-05 08:15:16 --> Helper loaded: file_helper
INFO - 2016-03-05 08:15:16 --> Helper loaded: date_helper
INFO - 2016-03-05 08:15:16 --> Helper loaded: form_helper
INFO - 2016-03-05 08:15:16 --> Database Driver Class Initialized
INFO - 2016-03-05 08:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:15:17 --> Controller Class Initialized
INFO - 2016-03-05 08:15:17 --> Model Class Initialized
INFO - 2016-03-05 08:15:17 --> Model Class Initialized
INFO - 2016-03-05 08:15:17 --> Form Validation Class Initialized
INFO - 2016-03-05 08:15:17 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:15:17 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:15:17 --> Final output sent to browser
DEBUG - 2016-03-05 08:15:17 --> Total execution time: 1.1203
INFO - 2016-03-05 08:15:20 --> Config Class Initialized
INFO - 2016-03-05 08:15:20 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:15:20 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:15:20 --> Utf8 Class Initialized
INFO - 2016-03-05 08:15:20 --> URI Class Initialized
INFO - 2016-03-05 08:15:20 --> Router Class Initialized
INFO - 2016-03-05 08:15:20 --> Output Class Initialized
INFO - 2016-03-05 08:15:20 --> Security Class Initialized
DEBUG - 2016-03-05 08:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:15:20 --> Input Class Initialized
INFO - 2016-03-05 08:15:20 --> Language Class Initialized
INFO - 2016-03-05 08:15:20 --> Loader Class Initialized
INFO - 2016-03-05 08:15:20 --> Helper loaded: url_helper
INFO - 2016-03-05 08:15:20 --> Helper loaded: file_helper
INFO - 2016-03-05 08:15:20 --> Helper loaded: date_helper
INFO - 2016-03-05 08:15:20 --> Helper loaded: form_helper
INFO - 2016-03-05 08:15:20 --> Database Driver Class Initialized
INFO - 2016-03-05 08:15:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:15:21 --> Controller Class Initialized
INFO - 2016-03-05 08:15:21 --> Model Class Initialized
INFO - 2016-03-05 08:15:21 --> Model Class Initialized
INFO - 2016-03-05 08:15:21 --> Form Validation Class Initialized
INFO - 2016-03-05 08:15:21 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:15:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:15:21 --> Final output sent to browser
DEBUG - 2016-03-05 08:15:21 --> Total execution time: 1.1315
INFO - 2016-03-05 08:15:25 --> Config Class Initialized
INFO - 2016-03-05 08:15:25 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:15:25 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:15:25 --> Utf8 Class Initialized
INFO - 2016-03-05 08:15:25 --> URI Class Initialized
INFO - 2016-03-05 08:15:25 --> Router Class Initialized
INFO - 2016-03-05 08:15:25 --> Output Class Initialized
INFO - 2016-03-05 08:15:25 --> Security Class Initialized
DEBUG - 2016-03-05 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:15:25 --> Input Class Initialized
INFO - 2016-03-05 08:15:25 --> Language Class Initialized
INFO - 2016-03-05 08:15:25 --> Loader Class Initialized
INFO - 2016-03-05 08:15:25 --> Helper loaded: url_helper
INFO - 2016-03-05 08:15:25 --> Helper loaded: file_helper
INFO - 2016-03-05 08:15:25 --> Helper loaded: date_helper
INFO - 2016-03-05 08:15:25 --> Helper loaded: form_helper
INFO - 2016-03-05 08:15:25 --> Database Driver Class Initialized
INFO - 2016-03-05 08:15:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:15:26 --> Controller Class Initialized
INFO - 2016-03-05 08:15:26 --> Model Class Initialized
INFO - 2016-03-05 08:15:26 --> Model Class Initialized
INFO - 2016-03-05 08:15:26 --> Form Validation Class Initialized
INFO - 2016-03-05 08:15:26 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:15:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:15:26 --> Final output sent to browser
DEBUG - 2016-03-05 08:15:26 --> Total execution time: 1.1277
INFO - 2016-03-05 08:16:39 --> Config Class Initialized
INFO - 2016-03-05 08:16:39 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:16:39 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:16:39 --> Utf8 Class Initialized
INFO - 2016-03-05 08:16:39 --> URI Class Initialized
DEBUG - 2016-03-05 08:16:39 --> No URI present. Default controller set.
INFO - 2016-03-05 08:16:39 --> Router Class Initialized
INFO - 2016-03-05 08:16:39 --> Output Class Initialized
INFO - 2016-03-05 08:16:39 --> Security Class Initialized
DEBUG - 2016-03-05 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:16:39 --> Input Class Initialized
INFO - 2016-03-05 08:16:39 --> Language Class Initialized
INFO - 2016-03-05 08:16:39 --> Loader Class Initialized
INFO - 2016-03-05 08:16:39 --> Helper loaded: url_helper
INFO - 2016-03-05 08:16:39 --> Helper loaded: file_helper
INFO - 2016-03-05 08:16:39 --> Helper loaded: date_helper
INFO - 2016-03-05 08:16:39 --> Helper loaded: form_helper
INFO - 2016-03-05 08:16:39 --> Database Driver Class Initialized
INFO - 2016-03-05 08:16:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:16:40 --> Controller Class Initialized
INFO - 2016-03-05 08:16:40 --> Model Class Initialized
INFO - 2016-03-05 08:16:40 --> Model Class Initialized
INFO - 2016-03-05 08:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:16:40 --> Pagination Class Initialized
INFO - 2016-03-05 08:16:40 --> Helper loaded: text_helper
INFO - 2016-03-05 08:16:40 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:16:40 --> Final output sent to browser
DEBUG - 2016-03-05 11:16:40 --> Total execution time: 1.2286
INFO - 2016-03-05 08:16:43 --> Config Class Initialized
INFO - 2016-03-05 08:16:43 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:16:43 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:16:43 --> Utf8 Class Initialized
INFO - 2016-03-05 08:16:43 --> URI Class Initialized
INFO - 2016-03-05 08:16:43 --> Router Class Initialized
INFO - 2016-03-05 08:16:43 --> Output Class Initialized
INFO - 2016-03-05 08:16:43 --> Security Class Initialized
DEBUG - 2016-03-05 08:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:16:43 --> Input Class Initialized
INFO - 2016-03-05 08:16:43 --> Language Class Initialized
INFO - 2016-03-05 08:16:43 --> Loader Class Initialized
INFO - 2016-03-05 08:16:43 --> Helper loaded: url_helper
INFO - 2016-03-05 08:16:43 --> Helper loaded: file_helper
INFO - 2016-03-05 08:16:43 --> Helper loaded: date_helper
INFO - 2016-03-05 08:16:43 --> Helper loaded: form_helper
INFO - 2016-03-05 08:16:43 --> Database Driver Class Initialized
INFO - 2016-03-05 08:16:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:16:44 --> Controller Class Initialized
INFO - 2016-03-05 08:16:44 --> Model Class Initialized
INFO - 2016-03-05 08:16:44 --> Model Class Initialized
INFO - 2016-03-05 08:16:44 --> Form Validation Class Initialized
INFO - 2016-03-05 08:16:44 --> Helper loaded: text_helper
INFO - 2016-03-05 08:16:44 --> Final output sent to browser
DEBUG - 2016-03-05 08:16:44 --> Total execution time: 1.1049
INFO - 2016-03-05 08:16:55 --> Config Class Initialized
INFO - 2016-03-05 08:16:55 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:16:55 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:16:55 --> Utf8 Class Initialized
INFO - 2016-03-05 08:16:55 --> URI Class Initialized
INFO - 2016-03-05 08:16:55 --> Router Class Initialized
INFO - 2016-03-05 08:16:55 --> Output Class Initialized
INFO - 2016-03-05 08:16:55 --> Security Class Initialized
DEBUG - 2016-03-05 08:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:16:55 --> Input Class Initialized
INFO - 2016-03-05 08:16:55 --> Language Class Initialized
INFO - 2016-03-05 08:16:55 --> Loader Class Initialized
INFO - 2016-03-05 08:16:55 --> Helper loaded: url_helper
INFO - 2016-03-05 08:16:55 --> Helper loaded: file_helper
INFO - 2016-03-05 08:16:55 --> Helper loaded: date_helper
INFO - 2016-03-05 08:16:55 --> Helper loaded: form_helper
INFO - 2016-03-05 08:16:55 --> Database Driver Class Initialized
INFO - 2016-03-05 08:16:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:16:56 --> Controller Class Initialized
INFO - 2016-03-05 08:16:56 --> Model Class Initialized
INFO - 2016-03-05 08:16:56 --> Model Class Initialized
INFO - 2016-03-05 08:16:56 --> Form Validation Class Initialized
INFO - 2016-03-05 08:16:56 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:16:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:16:56 --> Final output sent to browser
DEBUG - 2016-03-05 08:16:56 --> Total execution time: 1.0966
INFO - 2016-03-05 08:17:01 --> Config Class Initialized
INFO - 2016-03-05 08:17:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:17:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:17:01 --> Utf8 Class Initialized
INFO - 2016-03-05 08:17:01 --> URI Class Initialized
DEBUG - 2016-03-05 08:17:01 --> No URI present. Default controller set.
INFO - 2016-03-05 08:17:01 --> Router Class Initialized
INFO - 2016-03-05 08:17:01 --> Output Class Initialized
INFO - 2016-03-05 08:17:01 --> Security Class Initialized
DEBUG - 2016-03-05 08:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:17:01 --> Input Class Initialized
INFO - 2016-03-05 08:17:01 --> Language Class Initialized
INFO - 2016-03-05 08:17:01 --> Loader Class Initialized
INFO - 2016-03-05 08:17:01 --> Helper loaded: url_helper
INFO - 2016-03-05 08:17:01 --> Helper loaded: file_helper
INFO - 2016-03-05 08:17:01 --> Helper loaded: date_helper
INFO - 2016-03-05 08:17:01 --> Helper loaded: form_helper
INFO - 2016-03-05 08:17:01 --> Database Driver Class Initialized
INFO - 2016-03-05 08:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:17:02 --> Controller Class Initialized
INFO - 2016-03-05 08:17:02 --> Model Class Initialized
INFO - 2016-03-05 08:17:02 --> Model Class Initialized
INFO - 2016-03-05 08:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:17:02 --> Pagination Class Initialized
INFO - 2016-03-05 08:17:02 --> Helper loaded: text_helper
INFO - 2016-03-05 08:17:02 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:17:02 --> Final output sent to browser
DEBUG - 2016-03-05 11:17:02 --> Total execution time: 1.1268
INFO - 2016-03-05 08:17:13 --> Config Class Initialized
INFO - 2016-03-05 08:17:13 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:17:13 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:17:13 --> Utf8 Class Initialized
INFO - 2016-03-05 08:17:14 --> URI Class Initialized
INFO - 2016-03-05 08:17:14 --> Router Class Initialized
INFO - 2016-03-05 08:17:14 --> Output Class Initialized
INFO - 2016-03-05 08:17:14 --> Security Class Initialized
DEBUG - 2016-03-05 08:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:17:14 --> Input Class Initialized
INFO - 2016-03-05 08:17:14 --> Language Class Initialized
INFO - 2016-03-05 08:17:14 --> Loader Class Initialized
INFO - 2016-03-05 08:17:14 --> Helper loaded: url_helper
INFO - 2016-03-05 08:17:14 --> Helper loaded: file_helper
INFO - 2016-03-05 08:17:14 --> Helper loaded: date_helper
INFO - 2016-03-05 08:17:14 --> Helper loaded: form_helper
INFO - 2016-03-05 08:17:14 --> Database Driver Class Initialized
INFO - 2016-03-05 08:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:17:15 --> Controller Class Initialized
INFO - 2016-03-05 08:17:15 --> Model Class Initialized
INFO - 2016-03-05 08:17:15 --> Model Class Initialized
INFO - 2016-03-05 08:17:15 --> Form Validation Class Initialized
INFO - 2016-03-05 08:17:15 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:17:15 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 105
INFO - 2016-03-05 08:17:15 --> Final output sent to browser
DEBUG - 2016-03-05 08:17:15 --> Total execution time: 1.1938
INFO - 2016-03-05 08:53:21 --> Config Class Initialized
INFO - 2016-03-05 08:53:21 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:53:21 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:53:21 --> Utf8 Class Initialized
INFO - 2016-03-05 08:53:21 --> URI Class Initialized
DEBUG - 2016-03-05 08:53:21 --> No URI present. Default controller set.
INFO - 2016-03-05 08:53:21 --> Router Class Initialized
INFO - 2016-03-05 08:53:21 --> Output Class Initialized
INFO - 2016-03-05 08:53:21 --> Security Class Initialized
DEBUG - 2016-03-05 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:53:21 --> Input Class Initialized
INFO - 2016-03-05 08:53:21 --> Language Class Initialized
INFO - 2016-03-05 08:53:21 --> Loader Class Initialized
INFO - 2016-03-05 08:53:21 --> Helper loaded: url_helper
INFO - 2016-03-05 08:53:21 --> Helper loaded: file_helper
INFO - 2016-03-05 08:53:21 --> Helper loaded: date_helper
INFO - 2016-03-05 08:53:21 --> Helper loaded: form_helper
INFO - 2016-03-05 08:53:21 --> Database Driver Class Initialized
INFO - 2016-03-05 08:53:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:53:22 --> Controller Class Initialized
INFO - 2016-03-05 08:53:22 --> Model Class Initialized
INFO - 2016-03-05 08:53:22 --> Model Class Initialized
INFO - 2016-03-05 08:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:53:22 --> Pagination Class Initialized
INFO - 2016-03-05 08:53:22 --> Helper loaded: text_helper
INFO - 2016-03-05 08:53:22 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:53:22 --> Final output sent to browser
DEBUG - 2016-03-05 11:53:22 --> Total execution time: 1.1856
INFO - 2016-03-05 08:53:26 --> Config Class Initialized
INFO - 2016-03-05 08:53:26 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:53:26 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:53:26 --> Utf8 Class Initialized
INFO - 2016-03-05 08:53:26 --> URI Class Initialized
INFO - 2016-03-05 08:53:26 --> Router Class Initialized
INFO - 2016-03-05 08:53:26 --> Output Class Initialized
INFO - 2016-03-05 08:53:26 --> Security Class Initialized
DEBUG - 2016-03-05 08:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:53:26 --> Input Class Initialized
INFO - 2016-03-05 08:53:26 --> Language Class Initialized
INFO - 2016-03-05 08:53:26 --> Loader Class Initialized
INFO - 2016-03-05 08:53:26 --> Helper loaded: url_helper
INFO - 2016-03-05 08:53:26 --> Helper loaded: file_helper
INFO - 2016-03-05 08:53:26 --> Helper loaded: date_helper
INFO - 2016-03-05 08:53:26 --> Helper loaded: form_helper
INFO - 2016-03-05 08:53:26 --> Database Driver Class Initialized
INFO - 2016-03-05 08:53:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:53:27 --> Controller Class Initialized
INFO - 2016-03-05 08:53:27 --> Model Class Initialized
INFO - 2016-03-05 08:53:27 --> Model Class Initialized
INFO - 2016-03-05 08:53:27 --> Form Validation Class Initialized
INFO - 2016-03-05 08:53:27 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:53:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 104
INFO - 2016-03-05 08:53:27 --> Final output sent to browser
DEBUG - 2016-03-05 08:53:27 --> Total execution time: 1.1125
INFO - 2016-03-05 08:55:58 --> Config Class Initialized
INFO - 2016-03-05 08:55:58 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:55:58 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:55:58 --> Utf8 Class Initialized
INFO - 2016-03-05 08:55:58 --> URI Class Initialized
DEBUG - 2016-03-05 08:55:58 --> No URI present. Default controller set.
INFO - 2016-03-05 08:55:58 --> Router Class Initialized
INFO - 2016-03-05 08:55:58 --> Output Class Initialized
INFO - 2016-03-05 08:55:58 --> Security Class Initialized
DEBUG - 2016-03-05 08:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:55:58 --> Input Class Initialized
INFO - 2016-03-05 08:55:58 --> Language Class Initialized
INFO - 2016-03-05 08:55:58 --> Loader Class Initialized
INFO - 2016-03-05 08:55:58 --> Helper loaded: url_helper
INFO - 2016-03-05 08:55:58 --> Helper loaded: file_helper
INFO - 2016-03-05 08:55:58 --> Helper loaded: date_helper
INFO - 2016-03-05 08:55:58 --> Helper loaded: form_helper
INFO - 2016-03-05 08:55:58 --> Database Driver Class Initialized
INFO - 2016-03-05 08:55:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:55:59 --> Controller Class Initialized
INFO - 2016-03-05 08:55:59 --> Model Class Initialized
INFO - 2016-03-05 08:55:59 --> Model Class Initialized
INFO - 2016-03-05 08:55:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:55:59 --> Pagination Class Initialized
INFO - 2016-03-05 08:55:59 --> Helper loaded: text_helper
INFO - 2016-03-05 08:55:59 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:55:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:55:59 --> Final output sent to browser
DEBUG - 2016-03-05 11:55:59 --> Total execution time: 1.1537
INFO - 2016-03-05 08:56:02 --> Config Class Initialized
INFO - 2016-03-05 08:56:02 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:56:02 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:56:02 --> Utf8 Class Initialized
INFO - 2016-03-05 08:56:02 --> URI Class Initialized
INFO - 2016-03-05 08:56:02 --> Router Class Initialized
INFO - 2016-03-05 08:56:02 --> Output Class Initialized
INFO - 2016-03-05 08:56:02 --> Security Class Initialized
DEBUG - 2016-03-05 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:56:02 --> Input Class Initialized
INFO - 2016-03-05 08:56:02 --> Language Class Initialized
INFO - 2016-03-05 08:56:02 --> Loader Class Initialized
INFO - 2016-03-05 08:56:02 --> Helper loaded: url_helper
INFO - 2016-03-05 08:56:02 --> Helper loaded: file_helper
INFO - 2016-03-05 08:56:02 --> Helper loaded: date_helper
INFO - 2016-03-05 08:56:02 --> Helper loaded: form_helper
INFO - 2016-03-05 08:56:02 --> Database Driver Class Initialized
INFO - 2016-03-05 08:56:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:56:03 --> Controller Class Initialized
INFO - 2016-03-05 08:56:03 --> Model Class Initialized
INFO - 2016-03-05 08:56:03 --> Model Class Initialized
INFO - 2016-03-05 08:56:03 --> Form Validation Class Initialized
INFO - 2016-03-05 08:56:03 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:56:03 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 104
INFO - 2016-03-05 08:56:03 --> Final output sent to browser
DEBUG - 2016-03-05 08:56:03 --> Total execution time: 1.1157
INFO - 2016-03-05 08:57:06 --> Config Class Initialized
INFO - 2016-03-05 08:57:06 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:57:06 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:57:06 --> Utf8 Class Initialized
INFO - 2016-03-05 08:57:06 --> URI Class Initialized
DEBUG - 2016-03-05 08:57:06 --> No URI present. Default controller set.
INFO - 2016-03-05 08:57:06 --> Router Class Initialized
INFO - 2016-03-05 08:57:06 --> Output Class Initialized
INFO - 2016-03-05 08:57:06 --> Security Class Initialized
DEBUG - 2016-03-05 08:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:57:06 --> Input Class Initialized
INFO - 2016-03-05 08:57:06 --> Language Class Initialized
INFO - 2016-03-05 08:57:06 --> Loader Class Initialized
INFO - 2016-03-05 08:57:06 --> Helper loaded: url_helper
INFO - 2016-03-05 08:57:06 --> Helper loaded: file_helper
INFO - 2016-03-05 08:57:06 --> Helper loaded: date_helper
INFO - 2016-03-05 08:57:06 --> Helper loaded: form_helper
INFO - 2016-03-05 08:57:06 --> Database Driver Class Initialized
INFO - 2016-03-05 08:57:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:57:07 --> Controller Class Initialized
INFO - 2016-03-05 08:57:07 --> Model Class Initialized
INFO - 2016-03-05 08:57:07 --> Model Class Initialized
INFO - 2016-03-05 08:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:57:07 --> Pagination Class Initialized
INFO - 2016-03-05 08:57:07 --> Helper loaded: text_helper
INFO - 2016-03-05 08:57:07 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:57:07 --> Final output sent to browser
DEBUG - 2016-03-05 11:57:07 --> Total execution time: 1.1510
INFO - 2016-03-05 08:57:10 --> Config Class Initialized
INFO - 2016-03-05 08:57:10 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:57:10 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:57:10 --> Utf8 Class Initialized
INFO - 2016-03-05 08:57:10 --> URI Class Initialized
INFO - 2016-03-05 08:57:10 --> Router Class Initialized
INFO - 2016-03-05 08:57:10 --> Output Class Initialized
INFO - 2016-03-05 08:57:10 --> Security Class Initialized
DEBUG - 2016-03-05 08:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:57:10 --> Input Class Initialized
INFO - 2016-03-05 08:57:10 --> Language Class Initialized
INFO - 2016-03-05 08:57:10 --> Loader Class Initialized
INFO - 2016-03-05 08:57:10 --> Helper loaded: url_helper
INFO - 2016-03-05 08:57:10 --> Helper loaded: file_helper
INFO - 2016-03-05 08:57:10 --> Helper loaded: date_helper
INFO - 2016-03-05 08:57:10 --> Helper loaded: form_helper
INFO - 2016-03-05 08:57:10 --> Database Driver Class Initialized
INFO - 2016-03-05 08:57:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:57:11 --> Controller Class Initialized
INFO - 2016-03-05 08:57:11 --> Model Class Initialized
INFO - 2016-03-05 08:57:11 --> Model Class Initialized
INFO - 2016-03-05 08:57:11 --> Form Validation Class Initialized
INFO - 2016-03-05 08:57:11 --> Helper loaded: text_helper
ERROR - 2016-03-05 08:57:11 --> Severity: Notice --> Object of class stdClass could not be converted to int C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 104
INFO - 2016-03-05 08:57:11 --> Final output sent to browser
DEBUG - 2016-03-05 08:57:11 --> Total execution time: 1.1029
INFO - 2016-03-05 08:57:40 --> Config Class Initialized
INFO - 2016-03-05 08:57:40 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:57:40 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:57:40 --> Utf8 Class Initialized
INFO - 2016-03-05 08:57:40 --> URI Class Initialized
DEBUG - 2016-03-05 08:57:40 --> No URI present. Default controller set.
INFO - 2016-03-05 08:57:40 --> Router Class Initialized
INFO - 2016-03-05 08:57:40 --> Output Class Initialized
INFO - 2016-03-05 08:57:40 --> Security Class Initialized
DEBUG - 2016-03-05 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:57:40 --> Input Class Initialized
INFO - 2016-03-05 08:57:40 --> Language Class Initialized
INFO - 2016-03-05 08:57:40 --> Loader Class Initialized
INFO - 2016-03-05 08:57:40 --> Helper loaded: url_helper
INFO - 2016-03-05 08:57:40 --> Helper loaded: file_helper
INFO - 2016-03-05 08:57:40 --> Helper loaded: date_helper
INFO - 2016-03-05 08:57:40 --> Helper loaded: form_helper
INFO - 2016-03-05 08:57:40 --> Database Driver Class Initialized
INFO - 2016-03-05 08:57:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:57:41 --> Controller Class Initialized
INFO - 2016-03-05 08:57:41 --> Model Class Initialized
INFO - 2016-03-05 08:57:41 --> Model Class Initialized
INFO - 2016-03-05 08:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:57:41 --> Pagination Class Initialized
INFO - 2016-03-05 08:57:41 --> Helper loaded: text_helper
INFO - 2016-03-05 08:57:41 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:57:41 --> Final output sent to browser
DEBUG - 2016-03-05 11:57:41 --> Total execution time: 1.1746
INFO - 2016-03-05 08:57:45 --> Config Class Initialized
INFO - 2016-03-05 08:57:45 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:57:45 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:57:45 --> Utf8 Class Initialized
INFO - 2016-03-05 08:57:45 --> URI Class Initialized
INFO - 2016-03-05 08:57:45 --> Router Class Initialized
INFO - 2016-03-05 08:57:45 --> Output Class Initialized
INFO - 2016-03-05 08:57:45 --> Security Class Initialized
DEBUG - 2016-03-05 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:57:45 --> Input Class Initialized
INFO - 2016-03-05 08:57:45 --> Language Class Initialized
INFO - 2016-03-05 08:57:45 --> Loader Class Initialized
INFO - 2016-03-05 08:57:45 --> Helper loaded: url_helper
INFO - 2016-03-05 08:57:45 --> Helper loaded: file_helper
INFO - 2016-03-05 08:57:45 --> Helper loaded: date_helper
INFO - 2016-03-05 08:57:45 --> Helper loaded: form_helper
INFO - 2016-03-05 08:57:45 --> Database Driver Class Initialized
INFO - 2016-03-05 08:57:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:57:46 --> Controller Class Initialized
INFO - 2016-03-05 08:57:46 --> Model Class Initialized
INFO - 2016-03-05 08:57:46 --> Model Class Initialized
INFO - 2016-03-05 08:57:46 --> Form Validation Class Initialized
INFO - 2016-03-05 08:57:46 --> Helper loaded: text_helper
INFO - 2016-03-05 08:57:46 --> Final output sent to browser
DEBUG - 2016-03-05 08:57:46 --> Total execution time: 1.1009
INFO - 2016-03-05 08:57:54 --> Config Class Initialized
INFO - 2016-03-05 08:57:54 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:57:54 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:57:54 --> Utf8 Class Initialized
INFO - 2016-03-05 08:57:54 --> URI Class Initialized
DEBUG - 2016-03-05 08:57:54 --> No URI present. Default controller set.
INFO - 2016-03-05 08:57:54 --> Router Class Initialized
INFO - 2016-03-05 08:57:54 --> Output Class Initialized
INFO - 2016-03-05 08:57:54 --> Security Class Initialized
DEBUG - 2016-03-05 08:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:57:54 --> Input Class Initialized
INFO - 2016-03-05 08:57:54 --> Language Class Initialized
INFO - 2016-03-05 08:57:54 --> Loader Class Initialized
INFO - 2016-03-05 08:57:54 --> Helper loaded: url_helper
INFO - 2016-03-05 08:57:54 --> Helper loaded: file_helper
INFO - 2016-03-05 08:57:54 --> Helper loaded: date_helper
INFO - 2016-03-05 08:57:54 --> Helper loaded: form_helper
INFO - 2016-03-05 08:57:54 --> Database Driver Class Initialized
INFO - 2016-03-05 08:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:57:55 --> Controller Class Initialized
INFO - 2016-03-05 08:57:55 --> Model Class Initialized
INFO - 2016-03-05 08:57:55 --> Model Class Initialized
INFO - 2016-03-05 08:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:57:55 --> Pagination Class Initialized
INFO - 2016-03-05 08:57:55 --> Helper loaded: text_helper
INFO - 2016-03-05 08:57:55 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:57:55 --> Final output sent to browser
DEBUG - 2016-03-05 11:57:55 --> Total execution time: 1.1221
INFO - 2016-03-05 08:58:06 --> Config Class Initialized
INFO - 2016-03-05 08:58:06 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:06 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:06 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:06 --> URI Class Initialized
INFO - 2016-03-05 08:58:06 --> Router Class Initialized
INFO - 2016-03-05 08:58:06 --> Output Class Initialized
INFO - 2016-03-05 08:58:06 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:06 --> Input Class Initialized
INFO - 2016-03-05 08:58:06 --> Language Class Initialized
INFO - 2016-03-05 08:58:06 --> Loader Class Initialized
INFO - 2016-03-05 08:58:06 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:06 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:06 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:06 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:06 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:07 --> Controller Class Initialized
INFO - 2016-03-05 08:58:07 --> Model Class Initialized
INFO - 2016-03-05 08:58:07 --> Model Class Initialized
INFO - 2016-03-05 08:58:07 --> Form Validation Class Initialized
INFO - 2016-03-05 08:58:07 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:07 --> Final output sent to browser
DEBUG - 2016-03-05 08:58:07 --> Total execution time: 1.1173
INFO - 2016-03-05 08:58:38 --> Config Class Initialized
INFO - 2016-03-05 08:58:38 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:38 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:38 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:38 --> URI Class Initialized
DEBUG - 2016-03-05 08:58:38 --> No URI present. Default controller set.
INFO - 2016-03-05 08:58:38 --> Router Class Initialized
INFO - 2016-03-05 08:58:38 --> Output Class Initialized
INFO - 2016-03-05 08:58:38 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:38 --> Input Class Initialized
INFO - 2016-03-05 08:58:38 --> Language Class Initialized
INFO - 2016-03-05 08:58:38 --> Loader Class Initialized
INFO - 2016-03-05 08:58:38 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:38 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:38 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:38 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:38 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:39 --> Controller Class Initialized
INFO - 2016-03-05 08:58:39 --> Model Class Initialized
INFO - 2016-03-05 08:58:39 --> Model Class Initialized
INFO - 2016-03-05 08:58:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:58:39 --> Pagination Class Initialized
INFO - 2016-03-05 08:58:39 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:39 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:58:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:58:39 --> Final output sent to browser
DEBUG - 2016-03-05 11:58:39 --> Total execution time: 1.1731
INFO - 2016-03-05 08:58:46 --> Config Class Initialized
INFO - 2016-03-05 08:58:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:46 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:46 --> URI Class Initialized
INFO - 2016-03-05 08:58:46 --> Router Class Initialized
INFO - 2016-03-05 08:58:46 --> Output Class Initialized
INFO - 2016-03-05 08:58:46 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:46 --> Input Class Initialized
INFO - 2016-03-05 08:58:46 --> Language Class Initialized
INFO - 2016-03-05 08:58:46 --> Loader Class Initialized
INFO - 2016-03-05 08:58:46 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:46 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:46 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:46 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:46 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:47 --> Controller Class Initialized
INFO - 2016-03-05 08:58:47 --> Model Class Initialized
INFO - 2016-03-05 08:58:47 --> Model Class Initialized
INFO - 2016-03-05 08:58:47 --> Form Validation Class Initialized
INFO - 2016-03-05 08:58:47 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:47 --> Final output sent to browser
DEBUG - 2016-03-05 08:58:47 --> Total execution time: 1.1837
INFO - 2016-03-05 08:58:48 --> Config Class Initialized
INFO - 2016-03-05 08:58:48 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:48 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:48 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:48 --> URI Class Initialized
DEBUG - 2016-03-05 08:58:48 --> No URI present. Default controller set.
INFO - 2016-03-05 08:58:48 --> Router Class Initialized
INFO - 2016-03-05 08:58:48 --> Output Class Initialized
INFO - 2016-03-05 08:58:48 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:48 --> Input Class Initialized
INFO - 2016-03-05 08:58:48 --> Language Class Initialized
INFO - 2016-03-05 08:58:48 --> Loader Class Initialized
INFO - 2016-03-05 08:58:48 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:48 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:48 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:48 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:48 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:49 --> Controller Class Initialized
INFO - 2016-03-05 08:58:49 --> Model Class Initialized
INFO - 2016-03-05 08:58:49 --> Model Class Initialized
INFO - 2016-03-05 08:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:58:49 --> Pagination Class Initialized
INFO - 2016-03-05 08:58:49 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:49 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:58:49 --> Final output sent to browser
DEBUG - 2016-03-05 11:58:49 --> Total execution time: 1.1893
INFO - 2016-03-05 08:58:51 --> Config Class Initialized
INFO - 2016-03-05 08:58:51 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:51 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:51 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:51 --> URI Class Initialized
INFO - 2016-03-05 08:58:51 --> Router Class Initialized
INFO - 2016-03-05 08:58:51 --> Output Class Initialized
INFO - 2016-03-05 08:58:51 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:51 --> Input Class Initialized
INFO - 2016-03-05 08:58:51 --> Language Class Initialized
INFO - 2016-03-05 08:58:51 --> Loader Class Initialized
INFO - 2016-03-05 08:58:51 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:51 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:51 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:51 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:51 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:52 --> Controller Class Initialized
INFO - 2016-03-05 08:58:52 --> Model Class Initialized
INFO - 2016-03-05 08:58:52 --> Model Class Initialized
INFO - 2016-03-05 08:58:52 --> Form Validation Class Initialized
INFO - 2016-03-05 08:58:52 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:52 --> Config Class Initialized
INFO - 2016-03-05 08:58:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 08:58:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 08:58:52 --> Utf8 Class Initialized
INFO - 2016-03-05 08:58:52 --> URI Class Initialized
DEBUG - 2016-03-05 08:58:52 --> No URI present. Default controller set.
INFO - 2016-03-05 08:58:52 --> Router Class Initialized
INFO - 2016-03-05 08:58:52 --> Output Class Initialized
INFO - 2016-03-05 08:58:52 --> Security Class Initialized
DEBUG - 2016-03-05 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 08:58:52 --> Input Class Initialized
INFO - 2016-03-05 08:58:52 --> Language Class Initialized
INFO - 2016-03-05 08:58:52 --> Loader Class Initialized
INFO - 2016-03-05 08:58:52 --> Helper loaded: url_helper
INFO - 2016-03-05 08:58:52 --> Helper loaded: file_helper
INFO - 2016-03-05 08:58:52 --> Helper loaded: date_helper
INFO - 2016-03-05 08:58:52 --> Helper loaded: form_helper
INFO - 2016-03-05 08:58:53 --> Database Driver Class Initialized
INFO - 2016-03-05 08:58:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 08:58:54 --> Controller Class Initialized
INFO - 2016-03-05 08:58:54 --> Model Class Initialized
INFO - 2016-03-05 08:58:54 --> Model Class Initialized
INFO - 2016-03-05 08:58:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 08:58:54 --> Pagination Class Initialized
INFO - 2016-03-05 08:58:54 --> Helper loaded: text_helper
INFO - 2016-03-05 08:58:54 --> Helper loaded: cookie_helper
INFO - 2016-03-05 11:58:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 11:58:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 11:58:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 11:58:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 11:58:54 --> Final output sent to browser
DEBUG - 2016-03-05 11:58:54 --> Total execution time: 1.1210
INFO - 2016-03-05 10:15:01 --> Config Class Initialized
INFO - 2016-03-05 10:15:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:15:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:15:01 --> Utf8 Class Initialized
INFO - 2016-03-05 10:15:01 --> URI Class Initialized
DEBUG - 2016-03-05 10:15:01 --> No URI present. Default controller set.
INFO - 2016-03-05 10:15:01 --> Router Class Initialized
INFO - 2016-03-05 10:15:01 --> Output Class Initialized
INFO - 2016-03-05 10:15:01 --> Security Class Initialized
DEBUG - 2016-03-05 10:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:15:01 --> Input Class Initialized
INFO - 2016-03-05 10:15:01 --> Language Class Initialized
INFO - 2016-03-05 10:15:01 --> Loader Class Initialized
INFO - 2016-03-05 10:15:01 --> Helper loaded: url_helper
INFO - 2016-03-05 10:15:01 --> Helper loaded: file_helper
INFO - 2016-03-05 10:15:01 --> Helper loaded: date_helper
INFO - 2016-03-05 10:15:01 --> Helper loaded: form_helper
INFO - 2016-03-05 10:15:01 --> Database Driver Class Initialized
INFO - 2016-03-05 10:15:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:15:02 --> Controller Class Initialized
INFO - 2016-03-05 10:15:02 --> Model Class Initialized
INFO - 2016-03-05 10:15:02 --> Model Class Initialized
INFO - 2016-03-05 10:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:15:02 --> Pagination Class Initialized
INFO - 2016-03-05 10:15:02 --> Helper loaded: text_helper
INFO - 2016-03-05 10:15:02 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:15:02 --> Final output sent to browser
DEBUG - 2016-03-05 13:15:02 --> Total execution time: 1.1696
INFO - 2016-03-05 10:15:44 --> Config Class Initialized
INFO - 2016-03-05 10:15:44 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:15:44 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:15:44 --> Utf8 Class Initialized
INFO - 2016-03-05 10:15:44 --> URI Class Initialized
DEBUG - 2016-03-05 10:15:44 --> No URI present. Default controller set.
INFO - 2016-03-05 10:15:44 --> Router Class Initialized
INFO - 2016-03-05 10:15:44 --> Output Class Initialized
INFO - 2016-03-05 10:15:44 --> Security Class Initialized
DEBUG - 2016-03-05 10:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:15:44 --> Input Class Initialized
INFO - 2016-03-05 10:15:44 --> Language Class Initialized
INFO - 2016-03-05 10:15:44 --> Loader Class Initialized
INFO - 2016-03-05 10:15:44 --> Helper loaded: url_helper
INFO - 2016-03-05 10:15:44 --> Helper loaded: file_helper
INFO - 2016-03-05 10:15:44 --> Helper loaded: date_helper
INFO - 2016-03-05 10:15:44 --> Helper loaded: form_helper
INFO - 2016-03-05 10:15:44 --> Database Driver Class Initialized
INFO - 2016-03-05 10:15:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:15:45 --> Controller Class Initialized
INFO - 2016-03-05 10:15:45 --> Model Class Initialized
INFO - 2016-03-05 10:15:45 --> Model Class Initialized
INFO - 2016-03-05 10:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:15:45 --> Pagination Class Initialized
INFO - 2016-03-05 10:15:45 --> Helper loaded: text_helper
INFO - 2016-03-05 10:15:45 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:15:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:15:45 --> Final output sent to browser
DEBUG - 2016-03-05 13:15:45 --> Total execution time: 1.1500
INFO - 2016-03-05 10:15:58 --> Config Class Initialized
INFO - 2016-03-05 10:15:58 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:15:58 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:15:58 --> Utf8 Class Initialized
INFO - 2016-03-05 10:15:58 --> URI Class Initialized
INFO - 2016-03-05 10:15:58 --> Router Class Initialized
INFO - 2016-03-05 10:15:58 --> Output Class Initialized
INFO - 2016-03-05 10:15:58 --> Security Class Initialized
DEBUG - 2016-03-05 10:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:15:58 --> Input Class Initialized
INFO - 2016-03-05 10:15:58 --> Language Class Initialized
INFO - 2016-03-05 10:15:58 --> Loader Class Initialized
INFO - 2016-03-05 10:15:58 --> Helper loaded: url_helper
INFO - 2016-03-05 10:15:58 --> Helper loaded: file_helper
INFO - 2016-03-05 10:15:58 --> Helper loaded: date_helper
INFO - 2016-03-05 10:15:58 --> Helper loaded: form_helper
INFO - 2016-03-05 10:15:58 --> Database Driver Class Initialized
INFO - 2016-03-05 10:15:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:15:59 --> Controller Class Initialized
INFO - 2016-03-05 10:15:59 --> Model Class Initialized
INFO - 2016-03-05 10:15:59 --> Model Class Initialized
INFO - 2016-03-05 10:15:59 --> Form Validation Class Initialized
INFO - 2016-03-05 10:15:59 --> Helper loaded: text_helper
INFO - 2016-03-05 10:15:59 --> Final output sent to browser
DEBUG - 2016-03-05 10:15:59 --> Total execution time: 1.1332
INFO - 2016-03-05 10:16:15 --> Config Class Initialized
INFO - 2016-03-05 10:16:15 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:16:15 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:16:15 --> Utf8 Class Initialized
INFO - 2016-03-05 10:16:15 --> URI Class Initialized
INFO - 2016-03-05 10:16:15 --> Router Class Initialized
INFO - 2016-03-05 10:16:15 --> Output Class Initialized
INFO - 2016-03-05 10:16:15 --> Security Class Initialized
DEBUG - 2016-03-05 10:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:16:15 --> Input Class Initialized
INFO - 2016-03-05 10:16:15 --> Language Class Initialized
INFO - 2016-03-05 10:16:15 --> Loader Class Initialized
INFO - 2016-03-05 10:16:15 --> Helper loaded: url_helper
INFO - 2016-03-05 10:16:15 --> Helper loaded: file_helper
INFO - 2016-03-05 10:16:15 --> Helper loaded: date_helper
INFO - 2016-03-05 10:16:15 --> Helper loaded: form_helper
INFO - 2016-03-05 10:16:15 --> Database Driver Class Initialized
INFO - 2016-03-05 10:16:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:16:16 --> Controller Class Initialized
INFO - 2016-03-05 10:16:16 --> Model Class Initialized
INFO - 2016-03-05 10:16:16 --> Model Class Initialized
INFO - 2016-03-05 10:16:16 --> Form Validation Class Initialized
INFO - 2016-03-05 10:16:16 --> Helper loaded: text_helper
INFO - 2016-03-05 10:16:16 --> Final output sent to browser
DEBUG - 2016-03-05 10:16:16 --> Total execution time: 1.2053
INFO - 2016-03-05 10:18:33 --> Config Class Initialized
INFO - 2016-03-05 10:18:33 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:18:33 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:18:33 --> Utf8 Class Initialized
INFO - 2016-03-05 10:18:33 --> URI Class Initialized
DEBUG - 2016-03-05 10:18:33 --> No URI present. Default controller set.
INFO - 2016-03-05 10:18:33 --> Router Class Initialized
INFO - 2016-03-05 10:18:33 --> Output Class Initialized
INFO - 2016-03-05 10:18:33 --> Security Class Initialized
DEBUG - 2016-03-05 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:18:33 --> Input Class Initialized
INFO - 2016-03-05 10:18:33 --> Language Class Initialized
INFO - 2016-03-05 10:18:33 --> Loader Class Initialized
INFO - 2016-03-05 10:18:33 --> Helper loaded: url_helper
INFO - 2016-03-05 10:18:33 --> Helper loaded: file_helper
INFO - 2016-03-05 10:18:33 --> Helper loaded: date_helper
INFO - 2016-03-05 10:18:33 --> Helper loaded: form_helper
INFO - 2016-03-05 10:18:33 --> Database Driver Class Initialized
INFO - 2016-03-05 10:18:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:18:34 --> Controller Class Initialized
INFO - 2016-03-05 10:18:34 --> Model Class Initialized
INFO - 2016-03-05 10:18:34 --> Model Class Initialized
INFO - 2016-03-05 10:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:18:34 --> Pagination Class Initialized
INFO - 2016-03-05 10:18:34 --> Helper loaded: text_helper
INFO - 2016-03-05 10:18:34 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:18:34 --> Final output sent to browser
DEBUG - 2016-03-05 13:18:34 --> Total execution time: 1.1647
INFO - 2016-03-05 10:18:49 --> Config Class Initialized
INFO - 2016-03-05 10:18:49 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:18:49 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:18:49 --> Utf8 Class Initialized
INFO - 2016-03-05 10:18:49 --> URI Class Initialized
INFO - 2016-03-05 10:18:49 --> Router Class Initialized
INFO - 2016-03-05 10:18:49 --> Output Class Initialized
INFO - 2016-03-05 10:18:49 --> Security Class Initialized
DEBUG - 2016-03-05 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:18:49 --> Input Class Initialized
INFO - 2016-03-05 10:18:49 --> Language Class Initialized
INFO - 2016-03-05 10:18:49 --> Loader Class Initialized
INFO - 2016-03-05 10:18:49 --> Helper loaded: url_helper
INFO - 2016-03-05 10:18:49 --> Helper loaded: file_helper
INFO - 2016-03-05 10:18:49 --> Helper loaded: date_helper
INFO - 2016-03-05 10:18:49 --> Helper loaded: form_helper
INFO - 2016-03-05 10:18:49 --> Database Driver Class Initialized
INFO - 2016-03-05 10:18:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:18:50 --> Controller Class Initialized
INFO - 2016-03-05 10:18:50 --> Model Class Initialized
INFO - 2016-03-05 10:18:50 --> Model Class Initialized
INFO - 2016-03-05 10:18:50 --> Form Validation Class Initialized
INFO - 2016-03-05 10:18:50 --> Helper loaded: text_helper
INFO - 2016-03-05 10:18:50 --> Final output sent to browser
DEBUG - 2016-03-05 10:18:50 --> Total execution time: 1.1263
INFO - 2016-03-05 10:19:05 --> Config Class Initialized
INFO - 2016-03-05 10:19:05 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:19:05 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:19:05 --> Utf8 Class Initialized
INFO - 2016-03-05 10:19:05 --> URI Class Initialized
INFO - 2016-03-05 10:19:05 --> Router Class Initialized
INFO - 2016-03-05 10:19:05 --> Output Class Initialized
INFO - 2016-03-05 10:19:05 --> Security Class Initialized
DEBUG - 2016-03-05 10:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:19:05 --> Input Class Initialized
INFO - 2016-03-05 10:19:05 --> Language Class Initialized
INFO - 2016-03-05 10:19:05 --> Loader Class Initialized
INFO - 2016-03-05 10:19:05 --> Helper loaded: url_helper
INFO - 2016-03-05 10:19:05 --> Helper loaded: file_helper
INFO - 2016-03-05 10:19:05 --> Helper loaded: date_helper
INFO - 2016-03-05 10:19:05 --> Helper loaded: form_helper
INFO - 2016-03-05 10:19:05 --> Database Driver Class Initialized
INFO - 2016-03-05 10:19:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:19:06 --> Controller Class Initialized
INFO - 2016-03-05 10:19:06 --> Model Class Initialized
INFO - 2016-03-05 10:19:06 --> Model Class Initialized
INFO - 2016-03-05 10:19:06 --> Form Validation Class Initialized
INFO - 2016-03-05 10:19:06 --> Helper loaded: text_helper
INFO - 2016-03-05 10:19:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-05 10:19:06 --> Final output sent to browser
DEBUG - 2016-03-05 10:19:06 --> Total execution time: 1.2814
INFO - 2016-03-05 10:19:16 --> Config Class Initialized
INFO - 2016-03-05 10:19:16 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:19:16 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:19:16 --> Utf8 Class Initialized
INFO - 2016-03-05 10:19:16 --> URI Class Initialized
DEBUG - 2016-03-05 10:19:16 --> No URI present. Default controller set.
INFO - 2016-03-05 10:19:16 --> Router Class Initialized
INFO - 2016-03-05 10:19:16 --> Output Class Initialized
INFO - 2016-03-05 10:19:16 --> Security Class Initialized
DEBUG - 2016-03-05 10:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:19:16 --> Input Class Initialized
INFO - 2016-03-05 10:19:16 --> Language Class Initialized
INFO - 2016-03-05 10:19:16 --> Loader Class Initialized
INFO - 2016-03-05 10:19:16 --> Helper loaded: url_helper
INFO - 2016-03-05 10:19:16 --> Helper loaded: file_helper
INFO - 2016-03-05 10:19:16 --> Helper loaded: date_helper
INFO - 2016-03-05 10:19:16 --> Helper loaded: form_helper
INFO - 2016-03-05 10:19:16 --> Database Driver Class Initialized
INFO - 2016-03-05 10:19:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:19:17 --> Controller Class Initialized
INFO - 2016-03-05 10:19:17 --> Model Class Initialized
INFO - 2016-03-05 10:19:17 --> Model Class Initialized
INFO - 2016-03-05 10:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:19:17 --> Pagination Class Initialized
INFO - 2016-03-05 10:19:17 --> Helper loaded: text_helper
INFO - 2016-03-05 10:19:17 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:19:18 --> Final output sent to browser
DEBUG - 2016-03-05 13:19:18 --> Total execution time: 1.1692
INFO - 2016-03-05 10:36:08 --> Config Class Initialized
INFO - 2016-03-05 10:36:08 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:36:08 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:36:08 --> Utf8 Class Initialized
INFO - 2016-03-05 10:36:08 --> URI Class Initialized
DEBUG - 2016-03-05 10:36:08 --> No URI present. Default controller set.
INFO - 2016-03-05 10:36:08 --> Router Class Initialized
INFO - 2016-03-05 10:36:08 --> Output Class Initialized
INFO - 2016-03-05 10:36:08 --> Security Class Initialized
DEBUG - 2016-03-05 10:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:36:08 --> Input Class Initialized
INFO - 2016-03-05 10:36:08 --> Language Class Initialized
INFO - 2016-03-05 10:36:08 --> Loader Class Initialized
INFO - 2016-03-05 10:36:08 --> Helper loaded: url_helper
INFO - 2016-03-05 10:36:08 --> Helper loaded: file_helper
INFO - 2016-03-05 10:36:08 --> Helper loaded: date_helper
INFO - 2016-03-05 10:36:08 --> Helper loaded: form_helper
INFO - 2016-03-05 10:36:08 --> Database Driver Class Initialized
INFO - 2016-03-05 10:36:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:36:09 --> Controller Class Initialized
INFO - 2016-03-05 10:36:09 --> Model Class Initialized
INFO - 2016-03-05 10:36:09 --> Model Class Initialized
INFO - 2016-03-05 10:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:36:09 --> Pagination Class Initialized
INFO - 2016-03-05 10:36:09 --> Helper loaded: text_helper
INFO - 2016-03-05 10:36:09 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:36:09 --> Final output sent to browser
DEBUG - 2016-03-05 13:36:09 --> Total execution time: 1.1877
INFO - 2016-03-05 10:36:14 --> Config Class Initialized
INFO - 2016-03-05 10:36:14 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:36:14 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:36:14 --> Utf8 Class Initialized
INFO - 2016-03-05 10:36:14 --> URI Class Initialized
DEBUG - 2016-03-05 10:36:14 --> No URI present. Default controller set.
INFO - 2016-03-05 10:36:14 --> Router Class Initialized
INFO - 2016-03-05 10:36:14 --> Output Class Initialized
INFO - 2016-03-05 10:36:14 --> Security Class Initialized
DEBUG - 2016-03-05 10:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:36:14 --> Input Class Initialized
INFO - 2016-03-05 10:36:14 --> Language Class Initialized
INFO - 2016-03-05 10:36:14 --> Loader Class Initialized
INFO - 2016-03-05 10:36:14 --> Helper loaded: url_helper
INFO - 2016-03-05 10:36:14 --> Helper loaded: file_helper
INFO - 2016-03-05 10:36:14 --> Helper loaded: date_helper
INFO - 2016-03-05 10:36:14 --> Helper loaded: form_helper
INFO - 2016-03-05 10:36:14 --> Database Driver Class Initialized
INFO - 2016-03-05 10:36:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:36:15 --> Controller Class Initialized
INFO - 2016-03-05 10:36:15 --> Model Class Initialized
INFO - 2016-03-05 10:36:15 --> Model Class Initialized
INFO - 2016-03-05 10:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:36:15 --> Pagination Class Initialized
INFO - 2016-03-05 10:36:15 --> Helper loaded: text_helper
INFO - 2016-03-05 10:36:15 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:36:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:36:15 --> Final output sent to browser
DEBUG - 2016-03-05 13:36:15 --> Total execution time: 1.1591
INFO - 2016-03-05 10:39:58 --> Config Class Initialized
INFO - 2016-03-05 10:39:58 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:39:58 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:39:58 --> Utf8 Class Initialized
INFO - 2016-03-05 10:39:58 --> URI Class Initialized
DEBUG - 2016-03-05 10:39:58 --> No URI present. Default controller set.
INFO - 2016-03-05 10:39:58 --> Router Class Initialized
INFO - 2016-03-05 10:39:58 --> Output Class Initialized
INFO - 2016-03-05 10:39:58 --> Security Class Initialized
DEBUG - 2016-03-05 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:39:58 --> Input Class Initialized
INFO - 2016-03-05 10:39:58 --> Language Class Initialized
INFO - 2016-03-05 10:39:58 --> Loader Class Initialized
INFO - 2016-03-05 10:39:58 --> Helper loaded: url_helper
INFO - 2016-03-05 10:39:58 --> Helper loaded: file_helper
INFO - 2016-03-05 10:39:58 --> Helper loaded: date_helper
INFO - 2016-03-05 10:39:58 --> Helper loaded: form_helper
INFO - 2016-03-05 10:39:58 --> Database Driver Class Initialized
INFO - 2016-03-05 10:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:39:59 --> Controller Class Initialized
INFO - 2016-03-05 10:39:59 --> Model Class Initialized
INFO - 2016-03-05 10:39:59 --> Model Class Initialized
INFO - 2016-03-05 10:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:39:59 --> Pagination Class Initialized
INFO - 2016-03-05 10:39:59 --> Helper loaded: text_helper
INFO - 2016-03-05 10:39:59 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:39:59 --> Final output sent to browser
DEBUG - 2016-03-05 13:39:59 --> Total execution time: 1.1615
INFO - 2016-03-05 10:39:59 --> Config Class Initialized
INFO - 2016-03-05 10:39:59 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:39:59 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:39:59 --> Utf8 Class Initialized
INFO - 2016-03-05 10:39:59 --> URI Class Initialized
INFO - 2016-03-05 10:39:59 --> Router Class Initialized
INFO - 2016-03-05 10:39:59 --> Output Class Initialized
INFO - 2016-03-05 10:39:59 --> Security Class Initialized
DEBUG - 2016-03-05 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:39:59 --> Input Class Initialized
INFO - 2016-03-05 10:39:59 --> Language Class Initialized
INFO - 2016-03-05 10:39:59 --> Loader Class Initialized
INFO - 2016-03-05 10:39:59 --> Helper loaded: url_helper
INFO - 2016-03-05 10:39:59 --> Helper loaded: file_helper
INFO - 2016-03-05 10:39:59 --> Helper loaded: date_helper
INFO - 2016-03-05 10:39:59 --> Helper loaded: form_helper
INFO - 2016-03-05 10:39:59 --> Database Driver Class Initialized
INFO - 2016-03-05 10:40:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:40:00 --> Controller Class Initialized
INFO - 2016-03-05 10:40:00 --> User Agent Class Initialized
INFO - 2016-03-05 10:40:00 --> Final output sent to browser
DEBUG - 2016-03-05 10:40:00 --> Total execution time: 1.1364
INFO - 2016-03-05 10:40:05 --> Config Class Initialized
INFO - 2016-03-05 10:40:05 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:40:05 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:40:05 --> Utf8 Class Initialized
INFO - 2016-03-05 10:40:05 --> URI Class Initialized
INFO - 2016-03-05 10:40:05 --> Router Class Initialized
INFO - 2016-03-05 10:40:05 --> Output Class Initialized
INFO - 2016-03-05 10:40:05 --> Security Class Initialized
DEBUG - 2016-03-05 10:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:40:05 --> Input Class Initialized
INFO - 2016-03-05 10:40:05 --> Language Class Initialized
INFO - 2016-03-05 10:40:05 --> Loader Class Initialized
INFO - 2016-03-05 10:40:05 --> Helper loaded: url_helper
INFO - 2016-03-05 10:40:05 --> Helper loaded: file_helper
INFO - 2016-03-05 10:40:05 --> Helper loaded: date_helper
INFO - 2016-03-05 10:40:05 --> Helper loaded: form_helper
INFO - 2016-03-05 10:40:05 --> Database Driver Class Initialized
INFO - 2016-03-05 10:40:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:40:06 --> Controller Class Initialized
INFO - 2016-03-05 10:40:06 --> User Agent Class Initialized
INFO - 2016-03-05 10:40:06 --> Final output sent to browser
DEBUG - 2016-03-05 10:40:06 --> Total execution time: 1.0891
INFO - 2016-03-05 10:40:41 --> Config Class Initialized
INFO - 2016-03-05 10:40:41 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:40:41 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:40:41 --> Utf8 Class Initialized
INFO - 2016-03-05 10:40:41 --> URI Class Initialized
DEBUG - 2016-03-05 10:40:41 --> No URI present. Default controller set.
INFO - 2016-03-05 10:40:41 --> Router Class Initialized
INFO - 2016-03-05 10:40:41 --> Output Class Initialized
INFO - 2016-03-05 10:40:41 --> Security Class Initialized
DEBUG - 2016-03-05 10:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:40:41 --> Input Class Initialized
INFO - 2016-03-05 10:40:41 --> Language Class Initialized
INFO - 2016-03-05 10:40:41 --> Loader Class Initialized
INFO - 2016-03-05 10:40:41 --> Helper loaded: url_helper
INFO - 2016-03-05 10:40:41 --> Helper loaded: file_helper
INFO - 2016-03-05 10:40:41 --> Helper loaded: date_helper
INFO - 2016-03-05 10:40:41 --> Helper loaded: form_helper
INFO - 2016-03-05 10:40:41 --> Database Driver Class Initialized
INFO - 2016-03-05 10:40:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:40:42 --> Controller Class Initialized
INFO - 2016-03-05 10:40:42 --> Model Class Initialized
INFO - 2016-03-05 10:40:42 --> Model Class Initialized
INFO - 2016-03-05 10:40:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:40:42 --> Pagination Class Initialized
INFO - 2016-03-05 10:40:42 --> Helper loaded: text_helper
INFO - 2016-03-05 10:40:42 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:40:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:40:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:40:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:40:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:40:42 --> Final output sent to browser
DEBUG - 2016-03-05 13:40:42 --> Total execution time: 1.2077
INFO - 2016-03-05 10:40:54 --> Config Class Initialized
INFO - 2016-03-05 10:40:54 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:40:54 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:40:54 --> Utf8 Class Initialized
INFO - 2016-03-05 10:40:54 --> URI Class Initialized
DEBUG - 2016-03-05 10:40:54 --> No URI present. Default controller set.
INFO - 2016-03-05 10:40:54 --> Router Class Initialized
INFO - 2016-03-05 10:40:54 --> Output Class Initialized
INFO - 2016-03-05 10:40:54 --> Security Class Initialized
DEBUG - 2016-03-05 10:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:40:54 --> Input Class Initialized
INFO - 2016-03-05 10:40:54 --> Language Class Initialized
INFO - 2016-03-05 10:40:54 --> Loader Class Initialized
INFO - 2016-03-05 10:40:54 --> Helper loaded: url_helper
INFO - 2016-03-05 10:40:54 --> Helper loaded: file_helper
INFO - 2016-03-05 10:40:54 --> Helper loaded: date_helper
INFO - 2016-03-05 10:40:54 --> Helper loaded: form_helper
INFO - 2016-03-05 10:40:54 --> Database Driver Class Initialized
INFO - 2016-03-05 10:40:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:40:55 --> Controller Class Initialized
INFO - 2016-03-05 10:40:55 --> Model Class Initialized
INFO - 2016-03-05 10:40:55 --> Model Class Initialized
INFO - 2016-03-05 10:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:40:55 --> Pagination Class Initialized
INFO - 2016-03-05 10:40:55 --> Helper loaded: text_helper
INFO - 2016-03-05 10:40:55 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:40:55 --> Final output sent to browser
DEBUG - 2016-03-05 13:40:55 --> Total execution time: 1.2832
INFO - 2016-03-05 10:42:22 --> Config Class Initialized
INFO - 2016-03-05 10:42:22 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:42:22 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:42:22 --> Utf8 Class Initialized
INFO - 2016-03-05 10:42:22 --> URI Class Initialized
DEBUG - 2016-03-05 10:42:22 --> No URI present. Default controller set.
INFO - 2016-03-05 10:42:22 --> Router Class Initialized
INFO - 2016-03-05 10:42:22 --> Output Class Initialized
INFO - 2016-03-05 10:42:22 --> Security Class Initialized
DEBUG - 2016-03-05 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:42:22 --> Input Class Initialized
INFO - 2016-03-05 10:42:22 --> Language Class Initialized
INFO - 2016-03-05 10:42:22 --> Loader Class Initialized
INFO - 2016-03-05 10:42:22 --> Helper loaded: url_helper
INFO - 2016-03-05 10:42:22 --> Helper loaded: file_helper
INFO - 2016-03-05 10:42:22 --> Helper loaded: date_helper
INFO - 2016-03-05 10:42:22 --> Helper loaded: form_helper
INFO - 2016-03-05 10:42:22 --> Database Driver Class Initialized
INFO - 2016-03-05 10:42:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:42:23 --> Controller Class Initialized
INFO - 2016-03-05 10:42:23 --> Model Class Initialized
INFO - 2016-03-05 10:42:23 --> Model Class Initialized
INFO - 2016-03-05 10:42:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:42:23 --> Pagination Class Initialized
INFO - 2016-03-05 10:42:23 --> Helper loaded: text_helper
INFO - 2016-03-05 10:42:23 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:42:23 --> Final output sent to browser
DEBUG - 2016-03-05 13:42:23 --> Total execution time: 1.1495
INFO - 2016-03-05 10:45:35 --> Config Class Initialized
INFO - 2016-03-05 10:45:35 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:45:35 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:45:35 --> Utf8 Class Initialized
INFO - 2016-03-05 10:45:35 --> URI Class Initialized
DEBUG - 2016-03-05 10:45:35 --> No URI present. Default controller set.
INFO - 2016-03-05 10:45:35 --> Router Class Initialized
INFO - 2016-03-05 10:45:35 --> Output Class Initialized
INFO - 2016-03-05 10:45:35 --> Security Class Initialized
DEBUG - 2016-03-05 10:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:45:35 --> Input Class Initialized
INFO - 2016-03-05 10:45:35 --> Language Class Initialized
INFO - 2016-03-05 10:45:35 --> Loader Class Initialized
INFO - 2016-03-05 10:45:35 --> Helper loaded: url_helper
INFO - 2016-03-05 10:45:35 --> Helper loaded: file_helper
INFO - 2016-03-05 10:45:35 --> Helper loaded: date_helper
INFO - 2016-03-05 10:45:35 --> Helper loaded: form_helper
INFO - 2016-03-05 10:45:35 --> Database Driver Class Initialized
INFO - 2016-03-05 10:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:45:36 --> Controller Class Initialized
INFO - 2016-03-05 10:45:36 --> Model Class Initialized
INFO - 2016-03-05 10:45:36 --> Model Class Initialized
INFO - 2016-03-05 10:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:45:36 --> Pagination Class Initialized
INFO - 2016-03-05 10:45:36 --> Helper loaded: text_helper
INFO - 2016-03-05 10:45:36 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:45:36 --> Final output sent to browser
DEBUG - 2016-03-05 13:45:36 --> Total execution time: 1.1584
INFO - 2016-03-05 10:46:51 --> Config Class Initialized
INFO - 2016-03-05 10:46:51 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:46:51 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:46:51 --> Utf8 Class Initialized
INFO - 2016-03-05 10:46:51 --> URI Class Initialized
DEBUG - 2016-03-05 10:46:51 --> No URI present. Default controller set.
INFO - 2016-03-05 10:46:51 --> Router Class Initialized
INFO - 2016-03-05 10:46:51 --> Output Class Initialized
INFO - 2016-03-05 10:46:51 --> Security Class Initialized
DEBUG - 2016-03-05 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:46:51 --> Input Class Initialized
INFO - 2016-03-05 10:46:51 --> Language Class Initialized
INFO - 2016-03-05 10:46:51 --> Loader Class Initialized
INFO - 2016-03-05 10:46:51 --> Helper loaded: url_helper
INFO - 2016-03-05 10:46:51 --> Helper loaded: file_helper
INFO - 2016-03-05 10:46:51 --> Helper loaded: date_helper
INFO - 2016-03-05 10:46:51 --> Helper loaded: form_helper
INFO - 2016-03-05 10:46:51 --> Database Driver Class Initialized
INFO - 2016-03-05 10:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:46:52 --> Controller Class Initialized
INFO - 2016-03-05 10:46:52 --> Model Class Initialized
INFO - 2016-03-05 10:46:52 --> Model Class Initialized
INFO - 2016-03-05 10:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:46:52 --> Pagination Class Initialized
INFO - 2016-03-05 10:46:52 --> Helper loaded: text_helper
INFO - 2016-03-05 10:46:52 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:46:52 --> Final output sent to browser
DEBUG - 2016-03-05 13:46:52 --> Total execution time: 1.1745
INFO - 2016-03-05 10:47:35 --> Config Class Initialized
INFO - 2016-03-05 10:47:35 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:47:35 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:47:35 --> Utf8 Class Initialized
INFO - 2016-03-05 10:47:35 --> URI Class Initialized
DEBUG - 2016-03-05 10:47:35 --> No URI present. Default controller set.
INFO - 2016-03-05 10:47:35 --> Router Class Initialized
INFO - 2016-03-05 10:47:35 --> Output Class Initialized
INFO - 2016-03-05 10:47:35 --> Security Class Initialized
DEBUG - 2016-03-05 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:47:35 --> Input Class Initialized
INFO - 2016-03-05 10:47:35 --> Language Class Initialized
INFO - 2016-03-05 10:47:35 --> Loader Class Initialized
INFO - 2016-03-05 10:47:35 --> Helper loaded: url_helper
INFO - 2016-03-05 10:47:35 --> Helper loaded: file_helper
INFO - 2016-03-05 10:47:35 --> Helper loaded: date_helper
INFO - 2016-03-05 10:47:35 --> Helper loaded: form_helper
INFO - 2016-03-05 10:47:35 --> Database Driver Class Initialized
INFO - 2016-03-05 10:47:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:47:36 --> Controller Class Initialized
INFO - 2016-03-05 10:47:36 --> Model Class Initialized
INFO - 2016-03-05 10:47:36 --> Model Class Initialized
INFO - 2016-03-05 10:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:47:36 --> Pagination Class Initialized
INFO - 2016-03-05 10:47:36 --> Helper loaded: text_helper
INFO - 2016-03-05 10:47:36 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:47:36 --> Final output sent to browser
DEBUG - 2016-03-05 13:47:36 --> Total execution time: 1.1198
INFO - 2016-03-05 10:48:22 --> Config Class Initialized
INFO - 2016-03-05 10:48:22 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:48:22 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:48:22 --> Utf8 Class Initialized
INFO - 2016-03-05 10:48:22 --> URI Class Initialized
DEBUG - 2016-03-05 10:48:22 --> No URI present. Default controller set.
INFO - 2016-03-05 10:48:22 --> Router Class Initialized
INFO - 2016-03-05 10:48:22 --> Output Class Initialized
INFO - 2016-03-05 10:48:22 --> Security Class Initialized
DEBUG - 2016-03-05 10:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:48:22 --> Input Class Initialized
INFO - 2016-03-05 10:48:22 --> Language Class Initialized
INFO - 2016-03-05 10:48:23 --> Loader Class Initialized
INFO - 2016-03-05 10:48:23 --> Helper loaded: url_helper
INFO - 2016-03-05 10:48:23 --> Helper loaded: file_helper
INFO - 2016-03-05 10:48:23 --> Helper loaded: date_helper
INFO - 2016-03-05 10:48:23 --> Helper loaded: form_helper
INFO - 2016-03-05 10:48:23 --> Database Driver Class Initialized
INFO - 2016-03-05 10:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:48:24 --> Controller Class Initialized
INFO - 2016-03-05 10:48:24 --> Model Class Initialized
INFO - 2016-03-05 10:48:24 --> Model Class Initialized
INFO - 2016-03-05 10:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:48:24 --> Pagination Class Initialized
INFO - 2016-03-05 10:48:24 --> Helper loaded: text_helper
INFO - 2016-03-05 10:48:24 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:48:24 --> Final output sent to browser
DEBUG - 2016-03-05 13:48:24 --> Total execution time: 1.1652
INFO - 2016-03-05 10:48:36 --> Config Class Initialized
INFO - 2016-03-05 10:48:36 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:48:36 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:48:36 --> Utf8 Class Initialized
INFO - 2016-03-05 10:48:36 --> URI Class Initialized
DEBUG - 2016-03-05 10:48:36 --> No URI present. Default controller set.
INFO - 2016-03-05 10:48:36 --> Router Class Initialized
INFO - 2016-03-05 10:48:36 --> Output Class Initialized
INFO - 2016-03-05 10:48:36 --> Security Class Initialized
DEBUG - 2016-03-05 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:48:36 --> Input Class Initialized
INFO - 2016-03-05 10:48:36 --> Language Class Initialized
INFO - 2016-03-05 10:48:36 --> Loader Class Initialized
INFO - 2016-03-05 10:48:36 --> Helper loaded: url_helper
INFO - 2016-03-05 10:48:36 --> Helper loaded: file_helper
INFO - 2016-03-05 10:48:36 --> Helper loaded: date_helper
INFO - 2016-03-05 10:48:36 --> Helper loaded: form_helper
INFO - 2016-03-05 10:48:36 --> Database Driver Class Initialized
INFO - 2016-03-05 10:48:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:48:37 --> Controller Class Initialized
INFO - 2016-03-05 10:48:37 --> Model Class Initialized
INFO - 2016-03-05 10:48:37 --> Model Class Initialized
INFO - 2016-03-05 10:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:48:37 --> Pagination Class Initialized
INFO - 2016-03-05 10:48:37 --> Helper loaded: text_helper
INFO - 2016-03-05 10:48:37 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:48:37 --> Final output sent to browser
DEBUG - 2016-03-05 13:48:37 --> Total execution time: 1.1514
INFO - 2016-03-05 10:48:49 --> Config Class Initialized
INFO - 2016-03-05 10:48:49 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:48:49 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:48:49 --> Utf8 Class Initialized
INFO - 2016-03-05 10:48:49 --> URI Class Initialized
DEBUG - 2016-03-05 10:48:49 --> No URI present. Default controller set.
INFO - 2016-03-05 10:48:49 --> Router Class Initialized
INFO - 2016-03-05 10:48:49 --> Output Class Initialized
INFO - 2016-03-05 10:48:49 --> Security Class Initialized
DEBUG - 2016-03-05 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:48:49 --> Input Class Initialized
INFO - 2016-03-05 10:48:49 --> Language Class Initialized
INFO - 2016-03-05 10:48:49 --> Loader Class Initialized
INFO - 2016-03-05 10:48:49 --> Helper loaded: url_helper
INFO - 2016-03-05 10:48:49 --> Helper loaded: file_helper
INFO - 2016-03-05 10:48:49 --> Helper loaded: date_helper
INFO - 2016-03-05 10:48:49 --> Helper loaded: form_helper
INFO - 2016-03-05 10:48:49 --> Database Driver Class Initialized
INFO - 2016-03-05 10:48:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:48:50 --> Controller Class Initialized
INFO - 2016-03-05 10:48:50 --> Model Class Initialized
INFO - 2016-03-05 10:48:50 --> Model Class Initialized
INFO - 2016-03-05 10:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:48:50 --> Pagination Class Initialized
INFO - 2016-03-05 10:48:50 --> Helper loaded: text_helper
INFO - 2016-03-05 10:48:50 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:48:50 --> Final output sent to browser
DEBUG - 2016-03-05 13:48:50 --> Total execution time: 1.1760
INFO - 2016-03-05 10:49:00 --> Config Class Initialized
INFO - 2016-03-05 10:49:00 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:49:00 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:49:00 --> Utf8 Class Initialized
INFO - 2016-03-05 10:49:00 --> URI Class Initialized
DEBUG - 2016-03-05 10:49:00 --> No URI present. Default controller set.
INFO - 2016-03-05 10:49:00 --> Router Class Initialized
INFO - 2016-03-05 10:49:00 --> Output Class Initialized
INFO - 2016-03-05 10:49:00 --> Security Class Initialized
DEBUG - 2016-03-05 10:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:49:00 --> Input Class Initialized
INFO - 2016-03-05 10:49:00 --> Language Class Initialized
INFO - 2016-03-05 10:49:00 --> Loader Class Initialized
INFO - 2016-03-05 10:49:00 --> Helper loaded: url_helper
INFO - 2016-03-05 10:49:00 --> Helper loaded: file_helper
INFO - 2016-03-05 10:49:00 --> Helper loaded: date_helper
INFO - 2016-03-05 10:49:00 --> Helper loaded: form_helper
INFO - 2016-03-05 10:49:00 --> Database Driver Class Initialized
INFO - 2016-03-05 10:49:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:49:01 --> Controller Class Initialized
INFO - 2016-03-05 10:49:01 --> Model Class Initialized
INFO - 2016-03-05 10:49:01 --> Model Class Initialized
INFO - 2016-03-05 10:49:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:49:01 --> Pagination Class Initialized
INFO - 2016-03-05 10:49:01 --> Helper loaded: text_helper
INFO - 2016-03-05 10:49:01 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:49:01 --> Final output sent to browser
DEBUG - 2016-03-05 13:49:01 --> Total execution time: 1.1176
INFO - 2016-03-05 10:49:11 --> Config Class Initialized
INFO - 2016-03-05 10:49:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:49:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:49:11 --> Utf8 Class Initialized
INFO - 2016-03-05 10:49:11 --> URI Class Initialized
DEBUG - 2016-03-05 10:49:11 --> No URI present. Default controller set.
INFO - 2016-03-05 10:49:11 --> Router Class Initialized
INFO - 2016-03-05 10:49:11 --> Output Class Initialized
INFO - 2016-03-05 10:49:11 --> Security Class Initialized
DEBUG - 2016-03-05 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:49:11 --> Input Class Initialized
INFO - 2016-03-05 10:49:11 --> Language Class Initialized
INFO - 2016-03-05 10:49:11 --> Loader Class Initialized
INFO - 2016-03-05 10:49:11 --> Helper loaded: url_helper
INFO - 2016-03-05 10:49:11 --> Helper loaded: file_helper
INFO - 2016-03-05 10:49:11 --> Helper loaded: date_helper
INFO - 2016-03-05 10:49:11 --> Helper loaded: form_helper
INFO - 2016-03-05 10:49:11 --> Database Driver Class Initialized
INFO - 2016-03-05 10:49:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:49:12 --> Controller Class Initialized
INFO - 2016-03-05 10:49:12 --> Model Class Initialized
INFO - 2016-03-05 10:49:12 --> Model Class Initialized
INFO - 2016-03-05 10:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:49:12 --> Pagination Class Initialized
INFO - 2016-03-05 10:49:12 --> Helper loaded: text_helper
INFO - 2016-03-05 10:49:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:49:12 --> Final output sent to browser
DEBUG - 2016-03-05 13:49:12 --> Total execution time: 1.1460
INFO - 2016-03-05 10:57:05 --> Config Class Initialized
INFO - 2016-03-05 10:57:05 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:57:05 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:57:05 --> Utf8 Class Initialized
INFO - 2016-03-05 10:57:05 --> URI Class Initialized
DEBUG - 2016-03-05 10:57:05 --> No URI present. Default controller set.
INFO - 2016-03-05 10:57:05 --> Router Class Initialized
INFO - 2016-03-05 10:57:05 --> Output Class Initialized
INFO - 2016-03-05 10:57:05 --> Security Class Initialized
DEBUG - 2016-03-05 10:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:57:05 --> Input Class Initialized
INFO - 2016-03-05 10:57:05 --> Language Class Initialized
INFO - 2016-03-05 10:57:05 --> Loader Class Initialized
INFO - 2016-03-05 10:57:05 --> Helper loaded: url_helper
INFO - 2016-03-05 10:57:05 --> Helper loaded: file_helper
INFO - 2016-03-05 10:57:05 --> Helper loaded: date_helper
INFO - 2016-03-05 10:57:05 --> Helper loaded: form_helper
INFO - 2016-03-05 10:57:05 --> Database Driver Class Initialized
INFO - 2016-03-05 10:57:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:57:06 --> Controller Class Initialized
INFO - 2016-03-05 10:57:06 --> Model Class Initialized
INFO - 2016-03-05 10:57:06 --> Model Class Initialized
INFO - 2016-03-05 10:57:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:57:06 --> Pagination Class Initialized
INFO - 2016-03-05 10:57:06 --> Helper loaded: text_helper
INFO - 2016-03-05 10:57:06 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:57:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:57:06 --> Final output sent to browser
DEBUG - 2016-03-05 13:57:06 --> Total execution time: 1.1904
INFO - 2016-03-05 10:57:19 --> Config Class Initialized
INFO - 2016-03-05 10:57:19 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:57:19 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:57:19 --> Utf8 Class Initialized
INFO - 2016-03-05 10:57:19 --> URI Class Initialized
INFO - 2016-03-05 10:57:19 --> Router Class Initialized
INFO - 2016-03-05 10:57:19 --> Output Class Initialized
INFO - 2016-03-05 10:57:19 --> Security Class Initialized
DEBUG - 2016-03-05 10:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:57:19 --> Input Class Initialized
INFO - 2016-03-05 10:57:19 --> Language Class Initialized
INFO - 2016-03-05 10:57:19 --> Loader Class Initialized
INFO - 2016-03-05 10:57:19 --> Helper loaded: url_helper
INFO - 2016-03-05 10:57:19 --> Helper loaded: file_helper
INFO - 2016-03-05 10:57:19 --> Helper loaded: date_helper
INFO - 2016-03-05 10:57:19 --> Helper loaded: form_helper
INFO - 2016-03-05 10:57:19 --> Database Driver Class Initialized
INFO - 2016-03-05 10:57:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:57:20 --> Controller Class Initialized
INFO - 2016-03-05 10:57:20 --> Model Class Initialized
INFO - 2016-03-05 10:57:20 --> Model Class Initialized
INFO - 2016-03-05 10:57:20 --> Form Validation Class Initialized
INFO - 2016-03-05 10:57:20 --> Helper loaded: text_helper
INFO - 2016-03-05 10:57:20 --> Final output sent to browser
DEBUG - 2016-03-05 10:57:20 --> Total execution time: 1.1462
INFO - 2016-03-05 10:58:44 --> Config Class Initialized
INFO - 2016-03-05 10:58:44 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:58:44 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:58:44 --> Utf8 Class Initialized
INFO - 2016-03-05 10:58:44 --> URI Class Initialized
INFO - 2016-03-05 10:58:44 --> Router Class Initialized
INFO - 2016-03-05 10:58:44 --> Output Class Initialized
INFO - 2016-03-05 10:58:44 --> Security Class Initialized
DEBUG - 2016-03-05 10:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:58:44 --> Input Class Initialized
INFO - 2016-03-05 10:58:44 --> Language Class Initialized
INFO - 2016-03-05 10:58:44 --> Loader Class Initialized
INFO - 2016-03-05 10:58:44 --> Helper loaded: url_helper
INFO - 2016-03-05 10:58:44 --> Helper loaded: file_helper
INFO - 2016-03-05 10:58:44 --> Helper loaded: date_helper
INFO - 2016-03-05 10:58:44 --> Helper loaded: form_helper
INFO - 2016-03-05 10:58:44 --> Database Driver Class Initialized
INFO - 2016-03-05 10:58:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:58:45 --> Controller Class Initialized
INFO - 2016-03-05 10:58:45 --> Model Class Initialized
INFO - 2016-03-05 10:58:45 --> Model Class Initialized
INFO - 2016-03-05 10:58:45 --> Form Validation Class Initialized
INFO - 2016-03-05 10:58:45 --> Helper loaded: text_helper
INFO - 2016-03-05 10:58:46 --> Final output sent to browser
DEBUG - 2016-03-05 10:58:46 --> Total execution time: 1.2142
INFO - 2016-03-05 10:58:46 --> Config Class Initialized
INFO - 2016-03-05 10:58:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:58:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:58:46 --> Utf8 Class Initialized
INFO - 2016-03-05 10:58:46 --> URI Class Initialized
DEBUG - 2016-03-05 10:58:46 --> No URI present. Default controller set.
INFO - 2016-03-05 10:58:46 --> Router Class Initialized
INFO - 2016-03-05 10:58:46 --> Output Class Initialized
INFO - 2016-03-05 10:58:46 --> Security Class Initialized
DEBUG - 2016-03-05 10:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:58:46 --> Input Class Initialized
INFO - 2016-03-05 10:58:46 --> Language Class Initialized
INFO - 2016-03-05 10:58:46 --> Loader Class Initialized
INFO - 2016-03-05 10:58:46 --> Helper loaded: url_helper
INFO - 2016-03-05 10:58:46 --> Helper loaded: file_helper
INFO - 2016-03-05 10:58:46 --> Helper loaded: date_helper
INFO - 2016-03-05 10:58:46 --> Helper loaded: form_helper
INFO - 2016-03-05 10:58:46 --> Database Driver Class Initialized
INFO - 2016-03-05 10:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:58:47 --> Controller Class Initialized
INFO - 2016-03-05 10:58:47 --> Model Class Initialized
INFO - 2016-03-05 10:58:47 --> Model Class Initialized
INFO - 2016-03-05 10:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:58:47 --> Pagination Class Initialized
INFO - 2016-03-05 10:58:47 --> Helper loaded: text_helper
INFO - 2016-03-05 10:58:47 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:58:47 --> Final output sent to browser
DEBUG - 2016-03-05 13:58:47 --> Total execution time: 1.2049
INFO - 2016-03-05 10:58:57 --> Config Class Initialized
INFO - 2016-03-05 10:58:57 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:58:57 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:58:57 --> Utf8 Class Initialized
INFO - 2016-03-05 10:58:57 --> URI Class Initialized
DEBUG - 2016-03-05 10:58:57 --> No URI present. Default controller set.
INFO - 2016-03-05 10:58:57 --> Router Class Initialized
INFO - 2016-03-05 10:58:57 --> Output Class Initialized
INFO - 2016-03-05 10:58:57 --> Security Class Initialized
DEBUG - 2016-03-05 10:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:58:57 --> Input Class Initialized
INFO - 2016-03-05 10:58:57 --> Language Class Initialized
INFO - 2016-03-05 10:58:57 --> Loader Class Initialized
INFO - 2016-03-05 10:58:57 --> Helper loaded: url_helper
INFO - 2016-03-05 10:58:57 --> Helper loaded: file_helper
INFO - 2016-03-05 10:58:57 --> Helper loaded: date_helper
INFO - 2016-03-05 10:58:57 --> Helper loaded: form_helper
INFO - 2016-03-05 10:58:57 --> Database Driver Class Initialized
INFO - 2016-03-05 10:58:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:58:58 --> Controller Class Initialized
INFO - 2016-03-05 10:58:58 --> Model Class Initialized
INFO - 2016-03-05 10:58:58 --> Model Class Initialized
INFO - 2016-03-05 10:58:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:58:58 --> Pagination Class Initialized
INFO - 2016-03-05 10:58:58 --> Helper loaded: text_helper
INFO - 2016-03-05 10:58:58 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:58:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:58:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:58:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:58:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:58:58 --> Final output sent to browser
DEBUG - 2016-03-05 13:58:58 --> Total execution time: 1.1491
INFO - 2016-03-05 10:58:59 --> Config Class Initialized
INFO - 2016-03-05 10:58:59 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:58:59 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:58:59 --> Utf8 Class Initialized
INFO - 2016-03-05 10:58:59 --> URI Class Initialized
INFO - 2016-03-05 10:58:59 --> Router Class Initialized
INFO - 2016-03-05 10:58:59 --> Output Class Initialized
INFO - 2016-03-05 10:58:59 --> Security Class Initialized
DEBUG - 2016-03-05 10:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:58:59 --> Input Class Initialized
INFO - 2016-03-05 10:58:59 --> Language Class Initialized
INFO - 2016-03-05 10:58:59 --> Loader Class Initialized
INFO - 2016-03-05 10:58:59 --> Helper loaded: url_helper
INFO - 2016-03-05 10:58:59 --> Helper loaded: file_helper
INFO - 2016-03-05 10:58:59 --> Helper loaded: date_helper
INFO - 2016-03-05 10:58:59 --> Helper loaded: form_helper
INFO - 2016-03-05 10:58:59 --> Database Driver Class Initialized
INFO - 2016-03-05 10:59:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:59:00 --> Controller Class Initialized
INFO - 2016-03-05 10:59:00 --> Model Class Initialized
INFO - 2016-03-05 10:59:00 --> Model Class Initialized
INFO - 2016-03-05 10:59:00 --> Form Validation Class Initialized
INFO - 2016-03-05 10:59:00 --> Helper loaded: text_helper
INFO - 2016-03-05 10:59:00 --> Config Class Initialized
INFO - 2016-03-05 10:59:00 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:59:00 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:59:00 --> Utf8 Class Initialized
INFO - 2016-03-05 10:59:00 --> URI Class Initialized
DEBUG - 2016-03-05 10:59:00 --> No URI present. Default controller set.
INFO - 2016-03-05 10:59:00 --> Router Class Initialized
INFO - 2016-03-05 10:59:00 --> Output Class Initialized
INFO - 2016-03-05 10:59:00 --> Security Class Initialized
DEBUG - 2016-03-05 10:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:59:00 --> Input Class Initialized
INFO - 2016-03-05 10:59:00 --> Language Class Initialized
INFO - 2016-03-05 10:59:00 --> Loader Class Initialized
INFO - 2016-03-05 10:59:00 --> Helper loaded: url_helper
INFO - 2016-03-05 10:59:00 --> Helper loaded: file_helper
INFO - 2016-03-05 10:59:00 --> Helper loaded: date_helper
INFO - 2016-03-05 10:59:00 --> Helper loaded: form_helper
INFO - 2016-03-05 10:59:00 --> Database Driver Class Initialized
INFO - 2016-03-05 10:59:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:59:01 --> Controller Class Initialized
INFO - 2016-03-05 10:59:01 --> Model Class Initialized
INFO - 2016-03-05 10:59:01 --> Model Class Initialized
INFO - 2016-03-05 10:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:59:01 --> Pagination Class Initialized
INFO - 2016-03-05 10:59:01 --> Helper loaded: text_helper
INFO - 2016-03-05 10:59:01 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:59:01 --> Final output sent to browser
DEBUG - 2016-03-05 13:59:01 --> Total execution time: 1.1193
INFO - 2016-03-05 10:59:14 --> Config Class Initialized
INFO - 2016-03-05 10:59:14 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:59:14 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:59:14 --> Utf8 Class Initialized
INFO - 2016-03-05 10:59:14 --> URI Class Initialized
INFO - 2016-03-05 10:59:14 --> Router Class Initialized
INFO - 2016-03-05 10:59:14 --> Output Class Initialized
INFO - 2016-03-05 10:59:14 --> Security Class Initialized
DEBUG - 2016-03-05 10:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:59:14 --> Input Class Initialized
INFO - 2016-03-05 10:59:14 --> Language Class Initialized
INFO - 2016-03-05 10:59:14 --> Loader Class Initialized
INFO - 2016-03-05 10:59:14 --> Helper loaded: url_helper
INFO - 2016-03-05 10:59:14 --> Helper loaded: file_helper
INFO - 2016-03-05 10:59:14 --> Helper loaded: date_helper
INFO - 2016-03-05 10:59:14 --> Helper loaded: form_helper
INFO - 2016-03-05 10:59:14 --> Database Driver Class Initialized
INFO - 2016-03-05 10:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:59:15 --> Controller Class Initialized
INFO - 2016-03-05 10:59:15 --> Model Class Initialized
INFO - 2016-03-05 10:59:15 --> Model Class Initialized
INFO - 2016-03-05 10:59:15 --> Form Validation Class Initialized
INFO - 2016-03-05 10:59:15 --> Helper loaded: text_helper
INFO - 2016-03-05 10:59:15 --> Final output sent to browser
DEBUG - 2016-03-05 10:59:15 --> Total execution time: 1.1696
INFO - 2016-03-05 10:59:15 --> Config Class Initialized
INFO - 2016-03-05 10:59:15 --> Hooks Class Initialized
DEBUG - 2016-03-05 10:59:15 --> UTF-8 Support Enabled
INFO - 2016-03-05 10:59:15 --> Utf8 Class Initialized
INFO - 2016-03-05 10:59:15 --> URI Class Initialized
DEBUG - 2016-03-05 10:59:15 --> No URI present. Default controller set.
INFO - 2016-03-05 10:59:15 --> Router Class Initialized
INFO - 2016-03-05 10:59:15 --> Output Class Initialized
INFO - 2016-03-05 10:59:15 --> Security Class Initialized
DEBUG - 2016-03-05 10:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 10:59:15 --> Input Class Initialized
INFO - 2016-03-05 10:59:15 --> Language Class Initialized
INFO - 2016-03-05 10:59:15 --> Loader Class Initialized
INFO - 2016-03-05 10:59:15 --> Helper loaded: url_helper
INFO - 2016-03-05 10:59:15 --> Helper loaded: file_helper
INFO - 2016-03-05 10:59:15 --> Helper loaded: date_helper
INFO - 2016-03-05 10:59:15 --> Helper loaded: form_helper
INFO - 2016-03-05 10:59:15 --> Database Driver Class Initialized
INFO - 2016-03-05 10:59:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 10:59:16 --> Controller Class Initialized
INFO - 2016-03-05 10:59:16 --> Model Class Initialized
INFO - 2016-03-05 10:59:16 --> Model Class Initialized
INFO - 2016-03-05 10:59:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 10:59:16 --> Pagination Class Initialized
INFO - 2016-03-05 10:59:16 --> Helper loaded: text_helper
INFO - 2016-03-05 10:59:16 --> Helper loaded: cookie_helper
INFO - 2016-03-05 13:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 13:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 13:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 13:59:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 13:59:16 --> Final output sent to browser
DEBUG - 2016-03-05 13:59:16 --> Total execution time: 1.1324
INFO - 2016-03-05 11:02:12 --> Config Class Initialized
INFO - 2016-03-05 11:02:12 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:02:12 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:02:12 --> Utf8 Class Initialized
INFO - 2016-03-05 11:02:12 --> URI Class Initialized
DEBUG - 2016-03-05 11:02:12 --> No URI present. Default controller set.
INFO - 2016-03-05 11:02:12 --> Router Class Initialized
INFO - 2016-03-05 11:02:12 --> Output Class Initialized
INFO - 2016-03-05 11:02:12 --> Security Class Initialized
DEBUG - 2016-03-05 11:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:02:12 --> Input Class Initialized
INFO - 2016-03-05 11:02:12 --> Language Class Initialized
INFO - 2016-03-05 11:02:12 --> Loader Class Initialized
INFO - 2016-03-05 11:02:12 --> Helper loaded: url_helper
INFO - 2016-03-05 11:02:12 --> Helper loaded: file_helper
INFO - 2016-03-05 11:02:12 --> Helper loaded: date_helper
INFO - 2016-03-05 11:02:12 --> Helper loaded: form_helper
INFO - 2016-03-05 11:02:12 --> Database Driver Class Initialized
INFO - 2016-03-05 11:02:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:02:13 --> Controller Class Initialized
INFO - 2016-03-05 11:02:13 --> Model Class Initialized
INFO - 2016-03-05 11:02:13 --> Model Class Initialized
INFO - 2016-03-05 11:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:02:13 --> Pagination Class Initialized
INFO - 2016-03-05 11:02:13 --> Helper loaded: text_helper
INFO - 2016-03-05 11:02:13 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 14:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:02:13 --> Final output sent to browser
DEBUG - 2016-03-05 14:02:13 --> Total execution time: 1.1466
INFO - 2016-03-05 11:02:50 --> Config Class Initialized
INFO - 2016-03-05 11:02:50 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:02:50 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:02:50 --> Utf8 Class Initialized
INFO - 2016-03-05 11:02:51 --> URI Class Initialized
INFO - 2016-03-05 11:02:51 --> Router Class Initialized
INFO - 2016-03-05 11:02:51 --> Output Class Initialized
INFO - 2016-03-05 11:02:51 --> Security Class Initialized
DEBUG - 2016-03-05 11:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:02:51 --> Input Class Initialized
INFO - 2016-03-05 11:02:51 --> Language Class Initialized
INFO - 2016-03-05 11:02:51 --> Loader Class Initialized
INFO - 2016-03-05 11:02:51 --> Helper loaded: url_helper
INFO - 2016-03-05 11:02:51 --> Helper loaded: file_helper
INFO - 2016-03-05 11:02:51 --> Helper loaded: date_helper
INFO - 2016-03-05 11:02:51 --> Helper loaded: form_helper
INFO - 2016-03-05 11:02:51 --> Database Driver Class Initialized
INFO - 2016-03-05 11:02:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:02:52 --> Controller Class Initialized
INFO - 2016-03-05 11:02:52 --> Model Class Initialized
INFO - 2016-03-05 11:02:52 --> Model Class Initialized
INFO - 2016-03-05 11:02:52 --> Form Validation Class Initialized
INFO - 2016-03-05 11:02:52 --> Helper loaded: text_helper
INFO - 2016-03-05 11:02:52 --> Config Class Initialized
INFO - 2016-03-05 11:02:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:02:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:02:52 --> Utf8 Class Initialized
INFO - 2016-03-05 11:02:52 --> URI Class Initialized
DEBUG - 2016-03-05 11:02:52 --> No URI present. Default controller set.
INFO - 2016-03-05 11:02:52 --> Router Class Initialized
INFO - 2016-03-05 11:02:52 --> Output Class Initialized
INFO - 2016-03-05 11:02:52 --> Security Class Initialized
DEBUG - 2016-03-05 11:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:02:52 --> Input Class Initialized
INFO - 2016-03-05 11:02:52 --> Language Class Initialized
INFO - 2016-03-05 11:02:52 --> Loader Class Initialized
INFO - 2016-03-05 11:02:52 --> Helper loaded: url_helper
INFO - 2016-03-05 11:02:52 --> Helper loaded: file_helper
INFO - 2016-03-05 11:02:52 --> Helper loaded: date_helper
INFO - 2016-03-05 11:02:52 --> Helper loaded: form_helper
INFO - 2016-03-05 11:02:52 --> Database Driver Class Initialized
INFO - 2016-03-05 11:02:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:02:53 --> Controller Class Initialized
INFO - 2016-03-05 11:02:53 --> Model Class Initialized
INFO - 2016-03-05 11:02:53 --> Model Class Initialized
INFO - 2016-03-05 11:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:02:53 --> Pagination Class Initialized
INFO - 2016-03-05 11:02:53 --> Helper loaded: text_helper
INFO - 2016-03-05 11:02:53 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 14:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:02:53 --> Final output sent to browser
DEBUG - 2016-03-05 14:02:53 --> Total execution time: 1.1235
INFO - 2016-03-05 11:03:03 --> Config Class Initialized
INFO - 2016-03-05 11:03:03 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:03:03 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:03:03 --> Utf8 Class Initialized
INFO - 2016-03-05 11:03:03 --> URI Class Initialized
INFO - 2016-03-05 11:03:03 --> Router Class Initialized
INFO - 2016-03-05 11:03:03 --> Output Class Initialized
INFO - 2016-03-05 11:03:03 --> Security Class Initialized
DEBUG - 2016-03-05 11:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:03:03 --> Input Class Initialized
INFO - 2016-03-05 11:03:03 --> Language Class Initialized
INFO - 2016-03-05 11:03:03 --> Loader Class Initialized
INFO - 2016-03-05 11:03:03 --> Helper loaded: url_helper
INFO - 2016-03-05 11:03:03 --> Helper loaded: file_helper
INFO - 2016-03-05 11:03:03 --> Helper loaded: date_helper
INFO - 2016-03-05 11:03:03 --> Helper loaded: form_helper
INFO - 2016-03-05 11:03:03 --> Database Driver Class Initialized
INFO - 2016-03-05 11:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:03:04 --> Controller Class Initialized
INFO - 2016-03-05 11:03:04 --> Model Class Initialized
INFO - 2016-03-05 11:03:04 --> Model Class Initialized
INFO - 2016-03-05 11:03:04 --> Form Validation Class Initialized
INFO - 2016-03-05 11:03:04 --> Helper loaded: text_helper
INFO - 2016-03-05 11:03:04 --> Final output sent to browser
DEBUG - 2016-03-05 11:03:04 --> Total execution time: 1.2091
INFO - 2016-03-05 11:03:04 --> Config Class Initialized
INFO - 2016-03-05 11:03:04 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:03:04 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:03:04 --> Utf8 Class Initialized
INFO - 2016-03-05 11:03:04 --> URI Class Initialized
DEBUG - 2016-03-05 11:03:04 --> No URI present. Default controller set.
INFO - 2016-03-05 11:03:04 --> Router Class Initialized
INFO - 2016-03-05 11:03:04 --> Output Class Initialized
INFO - 2016-03-05 11:03:04 --> Security Class Initialized
DEBUG - 2016-03-05 11:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:03:04 --> Input Class Initialized
INFO - 2016-03-05 11:03:04 --> Language Class Initialized
INFO - 2016-03-05 11:03:04 --> Loader Class Initialized
INFO - 2016-03-05 11:03:04 --> Helper loaded: url_helper
INFO - 2016-03-05 11:03:04 --> Helper loaded: file_helper
INFO - 2016-03-05 11:03:04 --> Helper loaded: date_helper
INFO - 2016-03-05 11:03:04 --> Helper loaded: form_helper
INFO - 2016-03-05 11:03:04 --> Database Driver Class Initialized
INFO - 2016-03-05 11:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:03:05 --> Controller Class Initialized
INFO - 2016-03-05 11:03:05 --> Model Class Initialized
INFO - 2016-03-05 11:03:05 --> Model Class Initialized
INFO - 2016-03-05 11:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:03:05 --> Pagination Class Initialized
INFO - 2016-03-05 11:03:05 --> Helper loaded: text_helper
INFO - 2016-03-05 11:03:05 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 14:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:03:05 --> Final output sent to browser
DEBUG - 2016-03-05 14:03:05 --> Total execution time: 1.1701
INFO - 2016-03-05 11:03:11 --> Config Class Initialized
INFO - 2016-03-05 11:03:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:03:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:03:11 --> Utf8 Class Initialized
INFO - 2016-03-05 11:03:11 --> URI Class Initialized
INFO - 2016-03-05 11:03:11 --> Router Class Initialized
INFO - 2016-03-05 11:03:11 --> Output Class Initialized
INFO - 2016-03-05 11:03:11 --> Security Class Initialized
DEBUG - 2016-03-05 11:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:03:11 --> Input Class Initialized
INFO - 2016-03-05 11:03:11 --> Language Class Initialized
INFO - 2016-03-05 11:03:11 --> Loader Class Initialized
INFO - 2016-03-05 11:03:11 --> Helper loaded: url_helper
INFO - 2016-03-05 11:03:11 --> Helper loaded: file_helper
INFO - 2016-03-05 11:03:11 --> Helper loaded: date_helper
INFO - 2016-03-05 11:03:11 --> Helper loaded: form_helper
INFO - 2016-03-05 11:03:11 --> Database Driver Class Initialized
INFO - 2016-03-05 11:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:03:12 --> Controller Class Initialized
INFO - 2016-03-05 11:03:12 --> Model Class Initialized
INFO - 2016-03-05 11:03:12 --> Model Class Initialized
INFO - 2016-03-05 11:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:03:12 --> Pagination Class Initialized
INFO - 2016-03-05 11:03:12 --> Helper loaded: text_helper
INFO - 2016-03-05 11:03:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 14:03:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 14:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 14:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 14:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:03:12 --> Final output sent to browser
DEBUG - 2016-03-05 14:03:12 --> Total execution time: 1.1558
INFO - 2016-03-05 11:03:14 --> Config Class Initialized
INFO - 2016-03-05 11:03:14 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:03:14 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:03:14 --> Utf8 Class Initialized
INFO - 2016-03-05 11:03:14 --> URI Class Initialized
INFO - 2016-03-05 11:03:14 --> Router Class Initialized
INFO - 2016-03-05 11:03:14 --> Output Class Initialized
INFO - 2016-03-05 11:03:14 --> Security Class Initialized
DEBUG - 2016-03-05 11:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:03:14 --> Input Class Initialized
INFO - 2016-03-05 11:03:14 --> Language Class Initialized
INFO - 2016-03-05 11:03:14 --> Loader Class Initialized
INFO - 2016-03-05 11:03:14 --> Helper loaded: url_helper
INFO - 2016-03-05 11:03:14 --> Helper loaded: file_helper
INFO - 2016-03-05 11:03:14 --> Helper loaded: date_helper
INFO - 2016-03-05 11:03:14 --> Helper loaded: form_helper
INFO - 2016-03-05 11:03:14 --> Database Driver Class Initialized
INFO - 2016-03-05 11:03:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:03:15 --> Controller Class Initialized
INFO - 2016-03-05 11:03:15 --> Model Class Initialized
INFO - 2016-03-05 11:03:15 --> Model Class Initialized
INFO - 2016-03-05 11:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:03:15 --> Pagination Class Initialized
INFO - 2016-03-05 11:03:15 --> Helper loaded: text_helper
INFO - 2016-03-05 11:03:15 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:03:15 --> Final output sent to browser
DEBUG - 2016-03-05 14:03:16 --> Total execution time: 1.1601
INFO - 2016-03-05 11:54:21 --> Config Class Initialized
INFO - 2016-03-05 11:54:21 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:54:21 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:54:21 --> Utf8 Class Initialized
INFO - 2016-03-05 11:54:21 --> URI Class Initialized
INFO - 2016-03-05 11:54:21 --> Router Class Initialized
INFO - 2016-03-05 11:54:21 --> Output Class Initialized
INFO - 2016-03-05 11:54:21 --> Security Class Initialized
DEBUG - 2016-03-05 11:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:54:21 --> Input Class Initialized
INFO - 2016-03-05 11:54:21 --> Language Class Initialized
INFO - 2016-03-05 11:54:22 --> Loader Class Initialized
INFO - 2016-03-05 11:54:22 --> Helper loaded: url_helper
INFO - 2016-03-05 11:54:22 --> Helper loaded: file_helper
INFO - 2016-03-05 11:54:22 --> Helper loaded: date_helper
INFO - 2016-03-05 11:54:22 --> Helper loaded: form_helper
INFO - 2016-03-05 11:54:22 --> Database Driver Class Initialized
INFO - 2016-03-05 11:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:54:23 --> Controller Class Initialized
INFO - 2016-03-05 11:54:23 --> Model Class Initialized
INFO - 2016-03-05 11:54:23 --> Model Class Initialized
INFO - 2016-03-05 11:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:54:23 --> Pagination Class Initialized
INFO - 2016-03-05 11:54:23 --> Helper loaded: text_helper
INFO - 2016-03-05 11:54:23 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:54:23 --> Final output sent to browser
DEBUG - 2016-03-05 14:54:23 --> Total execution time: 1.2045
INFO - 2016-03-05 11:54:37 --> Config Class Initialized
INFO - 2016-03-05 11:54:37 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:54:37 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:54:37 --> Utf8 Class Initialized
INFO - 2016-03-05 11:54:37 --> URI Class Initialized
INFO - 2016-03-05 11:54:37 --> Router Class Initialized
INFO - 2016-03-05 11:54:37 --> Output Class Initialized
INFO - 2016-03-05 11:54:37 --> Security Class Initialized
DEBUG - 2016-03-05 11:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:54:37 --> Input Class Initialized
INFO - 2016-03-05 11:54:37 --> Language Class Initialized
INFO - 2016-03-05 11:54:37 --> Loader Class Initialized
INFO - 2016-03-05 11:54:37 --> Helper loaded: url_helper
INFO - 2016-03-05 11:54:37 --> Helper loaded: file_helper
INFO - 2016-03-05 11:54:37 --> Helper loaded: date_helper
INFO - 2016-03-05 11:54:37 --> Helper loaded: form_helper
INFO - 2016-03-05 11:54:37 --> Database Driver Class Initialized
INFO - 2016-03-05 11:54:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:54:38 --> Controller Class Initialized
INFO - 2016-03-05 11:54:38 --> Model Class Initialized
INFO - 2016-03-05 11:54:38 --> Model Class Initialized
INFO - 2016-03-05 11:54:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:54:38 --> Pagination Class Initialized
INFO - 2016-03-05 11:54:38 --> Helper loaded: text_helper
INFO - 2016-03-05 11:54:38 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:54:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:54:38 --> Final output sent to browser
DEBUG - 2016-03-05 14:54:38 --> Total execution time: 1.1809
INFO - 2016-03-05 11:55:11 --> Config Class Initialized
INFO - 2016-03-05 11:55:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:55:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:55:11 --> Utf8 Class Initialized
INFO - 2016-03-05 11:55:11 --> URI Class Initialized
INFO - 2016-03-05 11:55:11 --> Router Class Initialized
INFO - 2016-03-05 11:55:11 --> Output Class Initialized
INFO - 2016-03-05 11:55:11 --> Security Class Initialized
DEBUG - 2016-03-05 11:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:55:11 --> Input Class Initialized
INFO - 2016-03-05 11:55:11 --> Language Class Initialized
INFO - 2016-03-05 11:55:11 --> Loader Class Initialized
INFO - 2016-03-05 11:55:11 --> Helper loaded: url_helper
INFO - 2016-03-05 11:55:11 --> Helper loaded: file_helper
INFO - 2016-03-05 11:55:11 --> Helper loaded: date_helper
INFO - 2016-03-05 11:55:11 --> Helper loaded: form_helper
INFO - 2016-03-05 11:55:11 --> Database Driver Class Initialized
INFO - 2016-03-05 11:55:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:55:12 --> Controller Class Initialized
INFO - 2016-03-05 11:55:12 --> Model Class Initialized
INFO - 2016-03-05 11:55:12 --> Model Class Initialized
INFO - 2016-03-05 11:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:55:12 --> Pagination Class Initialized
INFO - 2016-03-05 11:55:12 --> Helper loaded: text_helper
INFO - 2016-03-05 11:55:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:55:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:55:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:55:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:55:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:55:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:55:12 --> Final output sent to browser
DEBUG - 2016-03-05 14:55:12 --> Total execution time: 1.1823
INFO - 2016-03-05 11:55:31 --> Config Class Initialized
INFO - 2016-03-05 11:55:31 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:55:31 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:55:31 --> Utf8 Class Initialized
INFO - 2016-03-05 11:55:31 --> URI Class Initialized
INFO - 2016-03-05 11:55:31 --> Router Class Initialized
INFO - 2016-03-05 11:55:31 --> Output Class Initialized
INFO - 2016-03-05 11:55:31 --> Security Class Initialized
DEBUG - 2016-03-05 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:55:31 --> Input Class Initialized
INFO - 2016-03-05 11:55:31 --> Language Class Initialized
INFO - 2016-03-05 11:55:31 --> Loader Class Initialized
INFO - 2016-03-05 11:55:31 --> Helper loaded: url_helper
INFO - 2016-03-05 11:55:31 --> Helper loaded: file_helper
INFO - 2016-03-05 11:55:31 --> Helper loaded: date_helper
INFO - 2016-03-05 11:55:31 --> Helper loaded: form_helper
INFO - 2016-03-05 11:55:31 --> Database Driver Class Initialized
INFO - 2016-03-05 11:55:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:55:32 --> Controller Class Initialized
INFO - 2016-03-05 11:55:32 --> Model Class Initialized
INFO - 2016-03-05 11:55:32 --> Model Class Initialized
INFO - 2016-03-05 11:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:55:32 --> Pagination Class Initialized
INFO - 2016-03-05 11:55:32 --> Helper loaded: text_helper
INFO - 2016-03-05 11:55:32 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:55:32 --> Final output sent to browser
DEBUG - 2016-03-05 14:55:32 --> Total execution time: 1.1797
INFO - 2016-03-05 11:55:55 --> Config Class Initialized
INFO - 2016-03-05 11:55:55 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:55:55 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:55:55 --> Utf8 Class Initialized
INFO - 2016-03-05 11:55:55 --> URI Class Initialized
INFO - 2016-03-05 11:55:55 --> Router Class Initialized
INFO - 2016-03-05 11:55:55 --> Output Class Initialized
INFO - 2016-03-05 11:55:55 --> Security Class Initialized
DEBUG - 2016-03-05 11:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:55:55 --> Input Class Initialized
INFO - 2016-03-05 11:55:55 --> Language Class Initialized
INFO - 2016-03-05 11:55:55 --> Loader Class Initialized
INFO - 2016-03-05 11:55:55 --> Helper loaded: url_helper
INFO - 2016-03-05 11:55:55 --> Helper loaded: file_helper
INFO - 2016-03-05 11:55:55 --> Helper loaded: date_helper
INFO - 2016-03-05 11:55:55 --> Helper loaded: form_helper
INFO - 2016-03-05 11:55:55 --> Database Driver Class Initialized
INFO - 2016-03-05 11:55:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:55:56 --> Controller Class Initialized
INFO - 2016-03-05 11:55:56 --> Model Class Initialized
INFO - 2016-03-05 11:55:56 --> Model Class Initialized
INFO - 2016-03-05 11:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:55:56 --> Pagination Class Initialized
INFO - 2016-03-05 11:55:56 --> Helper loaded: text_helper
INFO - 2016-03-05 11:55:56 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:55:56 --> Final output sent to browser
DEBUG - 2016-03-05 14:55:56 --> Total execution time: 1.1964
INFO - 2016-03-05 11:56:28 --> Config Class Initialized
INFO - 2016-03-05 11:56:28 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:56:28 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:56:29 --> Utf8 Class Initialized
INFO - 2016-03-05 11:56:29 --> URI Class Initialized
INFO - 2016-03-05 11:56:29 --> Router Class Initialized
INFO - 2016-03-05 11:56:29 --> Output Class Initialized
INFO - 2016-03-05 11:56:29 --> Security Class Initialized
DEBUG - 2016-03-05 11:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:56:29 --> Input Class Initialized
INFO - 2016-03-05 11:56:29 --> Language Class Initialized
INFO - 2016-03-05 11:56:29 --> Loader Class Initialized
INFO - 2016-03-05 11:56:29 --> Helper loaded: url_helper
INFO - 2016-03-05 11:56:29 --> Helper loaded: file_helper
INFO - 2016-03-05 11:56:29 --> Helper loaded: date_helper
INFO - 2016-03-05 11:56:29 --> Helper loaded: form_helper
INFO - 2016-03-05 11:56:29 --> Database Driver Class Initialized
INFO - 2016-03-05 11:56:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:56:30 --> Controller Class Initialized
INFO - 2016-03-05 11:56:30 --> Model Class Initialized
INFO - 2016-03-05 11:56:30 --> Model Class Initialized
INFO - 2016-03-05 11:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:56:30 --> Pagination Class Initialized
INFO - 2016-03-05 11:56:30 --> Helper loaded: text_helper
INFO - 2016-03-05 11:56:30 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:56:30 --> Final output sent to browser
DEBUG - 2016-03-05 14:56:30 --> Total execution time: 1.2042
INFO - 2016-03-05 11:57:10 --> Config Class Initialized
INFO - 2016-03-05 11:57:10 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:57:10 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:57:10 --> Utf8 Class Initialized
INFO - 2016-03-05 11:57:10 --> URI Class Initialized
INFO - 2016-03-05 11:57:10 --> Router Class Initialized
INFO - 2016-03-05 11:57:10 --> Output Class Initialized
INFO - 2016-03-05 11:57:10 --> Security Class Initialized
DEBUG - 2016-03-05 11:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:57:10 --> Input Class Initialized
INFO - 2016-03-05 11:57:10 --> Language Class Initialized
INFO - 2016-03-05 11:57:10 --> Loader Class Initialized
INFO - 2016-03-05 11:57:10 --> Helper loaded: url_helper
INFO - 2016-03-05 11:57:10 --> Helper loaded: file_helper
INFO - 2016-03-05 11:57:10 --> Helper loaded: date_helper
INFO - 2016-03-05 11:57:10 --> Helper loaded: form_helper
INFO - 2016-03-05 11:57:10 --> Database Driver Class Initialized
INFO - 2016-03-05 11:57:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:57:11 --> Controller Class Initialized
INFO - 2016-03-05 11:57:11 --> Model Class Initialized
INFO - 2016-03-05 11:57:11 --> Model Class Initialized
INFO - 2016-03-05 11:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:57:11 --> Pagination Class Initialized
INFO - 2016-03-05 11:57:11 --> Helper loaded: text_helper
INFO - 2016-03-05 11:57:11 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:57:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:57:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:57:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:57:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:57:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:57:11 --> Final output sent to browser
DEBUG - 2016-03-05 14:57:11 --> Total execution time: 1.2517
INFO - 2016-03-05 11:57:41 --> Config Class Initialized
INFO - 2016-03-05 11:57:41 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:57:41 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:57:41 --> Utf8 Class Initialized
INFO - 2016-03-05 11:57:41 --> URI Class Initialized
INFO - 2016-03-05 11:57:41 --> Router Class Initialized
INFO - 2016-03-05 11:57:41 --> Output Class Initialized
INFO - 2016-03-05 11:57:41 --> Security Class Initialized
DEBUG - 2016-03-05 11:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:57:41 --> Input Class Initialized
INFO - 2016-03-05 11:57:41 --> Language Class Initialized
INFO - 2016-03-05 11:57:41 --> Loader Class Initialized
INFO - 2016-03-05 11:57:41 --> Helper loaded: url_helper
INFO - 2016-03-05 11:57:41 --> Helper loaded: file_helper
INFO - 2016-03-05 11:57:41 --> Helper loaded: date_helper
INFO - 2016-03-05 11:57:41 --> Helper loaded: form_helper
INFO - 2016-03-05 11:57:41 --> Database Driver Class Initialized
INFO - 2016-03-05 11:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:57:42 --> Controller Class Initialized
INFO - 2016-03-05 11:57:42 --> Model Class Initialized
INFO - 2016-03-05 11:57:42 --> Model Class Initialized
INFO - 2016-03-05 11:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:57:42 --> Pagination Class Initialized
INFO - 2016-03-05 11:57:42 --> Helper loaded: text_helper
INFO - 2016-03-05 11:57:42 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:57:42 --> Final output sent to browser
DEBUG - 2016-03-05 14:57:42 --> Total execution time: 1.2155
INFO - 2016-03-05 11:57:48 --> Config Class Initialized
INFO - 2016-03-05 11:57:48 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:57:48 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:57:48 --> Utf8 Class Initialized
INFO - 2016-03-05 11:57:48 --> URI Class Initialized
INFO - 2016-03-05 11:57:48 --> Router Class Initialized
INFO - 2016-03-05 11:57:48 --> Output Class Initialized
INFO - 2016-03-05 11:57:48 --> Security Class Initialized
DEBUG - 2016-03-05 11:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:57:48 --> Input Class Initialized
INFO - 2016-03-05 11:57:48 --> Language Class Initialized
INFO - 2016-03-05 11:57:48 --> Loader Class Initialized
INFO - 2016-03-05 11:57:48 --> Helper loaded: url_helper
INFO - 2016-03-05 11:57:48 --> Helper loaded: file_helper
INFO - 2016-03-05 11:57:48 --> Helper loaded: date_helper
INFO - 2016-03-05 11:57:48 --> Helper loaded: form_helper
INFO - 2016-03-05 11:57:48 --> Database Driver Class Initialized
INFO - 2016-03-05 11:57:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:57:49 --> Controller Class Initialized
INFO - 2016-03-05 11:57:49 --> Model Class Initialized
INFO - 2016-03-05 11:57:49 --> Model Class Initialized
INFO - 2016-03-05 11:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:57:49 --> Pagination Class Initialized
INFO - 2016-03-05 11:57:49 --> Helper loaded: text_helper
INFO - 2016-03-05 11:57:49 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:57:49 --> Final output sent to browser
DEBUG - 2016-03-05 14:57:49 --> Total execution time: 1.1614
INFO - 2016-03-05 11:57:55 --> Config Class Initialized
INFO - 2016-03-05 11:57:55 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:57:55 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:57:55 --> Utf8 Class Initialized
INFO - 2016-03-05 11:57:55 --> URI Class Initialized
INFO - 2016-03-05 11:57:55 --> Router Class Initialized
INFO - 2016-03-05 11:57:55 --> Output Class Initialized
INFO - 2016-03-05 11:57:55 --> Security Class Initialized
DEBUG - 2016-03-05 11:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:57:55 --> Input Class Initialized
INFO - 2016-03-05 11:57:55 --> Language Class Initialized
INFO - 2016-03-05 11:57:55 --> Loader Class Initialized
INFO - 2016-03-05 11:57:55 --> Helper loaded: url_helper
INFO - 2016-03-05 11:57:55 --> Helper loaded: file_helper
INFO - 2016-03-05 11:57:55 --> Helper loaded: date_helper
INFO - 2016-03-05 11:57:55 --> Helper loaded: form_helper
INFO - 2016-03-05 11:57:55 --> Database Driver Class Initialized
INFO - 2016-03-05 11:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:57:56 --> Controller Class Initialized
INFO - 2016-03-05 11:57:56 --> Model Class Initialized
INFO - 2016-03-05 11:57:56 --> Model Class Initialized
INFO - 2016-03-05 11:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:57:56 --> Pagination Class Initialized
INFO - 2016-03-05 11:57:56 --> Helper loaded: text_helper
INFO - 2016-03-05 11:57:56 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 14:57:56 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 14:57:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 14:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 14:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:57:56 --> Final output sent to browser
DEBUG - 2016-03-05 14:57:56 --> Total execution time: 1.1623
INFO - 2016-03-05 11:58:47 --> Config Class Initialized
INFO - 2016-03-05 11:58:47 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:58:47 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:58:47 --> Utf8 Class Initialized
INFO - 2016-03-05 11:58:47 --> URI Class Initialized
INFO - 2016-03-05 11:58:47 --> Router Class Initialized
INFO - 2016-03-05 11:58:47 --> Output Class Initialized
INFO - 2016-03-05 11:58:47 --> Security Class Initialized
DEBUG - 2016-03-05 11:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:58:47 --> Input Class Initialized
INFO - 2016-03-05 11:58:47 --> Language Class Initialized
INFO - 2016-03-05 11:58:47 --> Loader Class Initialized
INFO - 2016-03-05 11:58:47 --> Helper loaded: url_helper
INFO - 2016-03-05 11:58:47 --> Helper loaded: file_helper
INFO - 2016-03-05 11:58:47 --> Helper loaded: date_helper
INFO - 2016-03-05 11:58:47 --> Helper loaded: form_helper
INFO - 2016-03-05 11:58:47 --> Database Driver Class Initialized
INFO - 2016-03-05 11:58:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:58:48 --> Controller Class Initialized
INFO - 2016-03-05 11:58:48 --> Model Class Initialized
INFO - 2016-03-05 11:58:48 --> Model Class Initialized
INFO - 2016-03-05 11:58:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:58:48 --> Pagination Class Initialized
INFO - 2016-03-05 11:58:48 --> Helper loaded: text_helper
INFO - 2016-03-05 11:58:48 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 14:58:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 14:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 14:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 14:58:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:58:48 --> Final output sent to browser
DEBUG - 2016-03-05 14:58:48 --> Total execution time: 1.1698
INFO - 2016-03-05 11:59:01 --> Config Class Initialized
INFO - 2016-03-05 11:59:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 11:59:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 11:59:01 --> Utf8 Class Initialized
INFO - 2016-03-05 11:59:01 --> URI Class Initialized
INFO - 2016-03-05 11:59:01 --> Router Class Initialized
INFO - 2016-03-05 11:59:01 --> Output Class Initialized
INFO - 2016-03-05 11:59:01 --> Security Class Initialized
DEBUG - 2016-03-05 11:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 11:59:01 --> Input Class Initialized
INFO - 2016-03-05 11:59:01 --> Language Class Initialized
INFO - 2016-03-05 11:59:01 --> Loader Class Initialized
INFO - 2016-03-05 11:59:01 --> Helper loaded: url_helper
INFO - 2016-03-05 11:59:01 --> Helper loaded: file_helper
INFO - 2016-03-05 11:59:01 --> Helper loaded: date_helper
INFO - 2016-03-05 11:59:01 --> Helper loaded: form_helper
INFO - 2016-03-05 11:59:01 --> Database Driver Class Initialized
INFO - 2016-03-05 11:59:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 11:59:02 --> Controller Class Initialized
INFO - 2016-03-05 11:59:02 --> Model Class Initialized
INFO - 2016-03-05 11:59:02 --> Model Class Initialized
INFO - 2016-03-05 11:59:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 11:59:02 --> Pagination Class Initialized
INFO - 2016-03-05 11:59:02 --> Helper loaded: text_helper
INFO - 2016-03-05 11:59:02 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:59:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 14:59:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 14:59:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 14:59:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 14:59:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 14:59:02 --> Final output sent to browser
DEBUG - 2016-03-05 14:59:02 --> Total execution time: 1.1876
INFO - 2016-03-05 12:05:22 --> Config Class Initialized
INFO - 2016-03-05 12:05:22 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:05:22 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:05:22 --> Utf8 Class Initialized
INFO - 2016-03-05 12:05:22 --> URI Class Initialized
INFO - 2016-03-05 12:05:22 --> Router Class Initialized
INFO - 2016-03-05 12:05:22 --> Output Class Initialized
INFO - 2016-03-05 12:05:22 --> Security Class Initialized
DEBUG - 2016-03-05 12:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:05:22 --> Input Class Initialized
INFO - 2016-03-05 12:05:22 --> Language Class Initialized
INFO - 2016-03-05 12:05:22 --> Loader Class Initialized
INFO - 2016-03-05 12:05:22 --> Helper loaded: url_helper
INFO - 2016-03-05 12:05:22 --> Helper loaded: file_helper
INFO - 2016-03-05 12:05:22 --> Helper loaded: date_helper
INFO - 2016-03-05 12:05:22 --> Helper loaded: form_helper
INFO - 2016-03-05 12:05:22 --> Database Driver Class Initialized
INFO - 2016-03-05 12:05:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:05:23 --> Controller Class Initialized
INFO - 2016-03-05 12:05:23 --> Model Class Initialized
INFO - 2016-03-05 12:05:23 --> Model Class Initialized
INFO - 2016-03-05 12:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:05:23 --> Pagination Class Initialized
INFO - 2016-03-05 12:05:23 --> Helper loaded: text_helper
INFO - 2016-03-05 12:05:23 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 15:05:23 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 15:05:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:05:23 --> Final output sent to browser
DEBUG - 2016-03-05 15:05:23 --> Total execution time: 1.1309
INFO - 2016-03-05 12:16:11 --> Config Class Initialized
INFO - 2016-03-05 12:16:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:16:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:16:11 --> Utf8 Class Initialized
INFO - 2016-03-05 12:16:11 --> URI Class Initialized
INFO - 2016-03-05 12:16:11 --> Router Class Initialized
INFO - 2016-03-05 12:16:11 --> Output Class Initialized
INFO - 2016-03-05 12:16:11 --> Security Class Initialized
DEBUG - 2016-03-05 12:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:16:11 --> Input Class Initialized
INFO - 2016-03-05 12:16:11 --> Language Class Initialized
INFO - 2016-03-05 12:16:11 --> Loader Class Initialized
INFO - 2016-03-05 12:16:11 --> Helper loaded: url_helper
INFO - 2016-03-05 12:16:11 --> Helper loaded: file_helper
INFO - 2016-03-05 12:16:11 --> Helper loaded: date_helper
INFO - 2016-03-05 12:16:11 --> Helper loaded: form_helper
INFO - 2016-03-05 12:16:11 --> Database Driver Class Initialized
INFO - 2016-03-05 12:16:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:16:12 --> Controller Class Initialized
INFO - 2016-03-05 12:16:12 --> Model Class Initialized
INFO - 2016-03-05 12:16:12 --> Model Class Initialized
INFO - 2016-03-05 12:16:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:16:12 --> Pagination Class Initialized
INFO - 2016-03-05 12:16:12 --> Helper loaded: text_helper
INFO - 2016-03-05 12:16:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:16:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:16:12 --> Final output sent to browser
DEBUG - 2016-03-05 15:16:12 --> Total execution time: 1.1346
INFO - 2016-03-05 12:18:15 --> Config Class Initialized
INFO - 2016-03-05 12:18:15 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:18:15 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:18:15 --> Utf8 Class Initialized
INFO - 2016-03-05 12:18:15 --> URI Class Initialized
INFO - 2016-03-05 12:18:15 --> Router Class Initialized
INFO - 2016-03-05 12:18:15 --> Output Class Initialized
INFO - 2016-03-05 12:18:15 --> Security Class Initialized
DEBUG - 2016-03-05 12:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:18:15 --> Input Class Initialized
INFO - 2016-03-05 12:18:15 --> Language Class Initialized
INFO - 2016-03-05 12:18:15 --> Loader Class Initialized
INFO - 2016-03-05 12:18:15 --> Helper loaded: url_helper
INFO - 2016-03-05 12:18:15 --> Helper loaded: file_helper
INFO - 2016-03-05 12:18:15 --> Helper loaded: date_helper
INFO - 2016-03-05 12:18:15 --> Helper loaded: form_helper
INFO - 2016-03-05 12:18:15 --> Database Driver Class Initialized
INFO - 2016-03-05 12:18:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:18:16 --> Controller Class Initialized
INFO - 2016-03-05 12:18:16 --> Model Class Initialized
INFO - 2016-03-05 12:18:16 --> Model Class Initialized
INFO - 2016-03-05 12:18:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:18:16 --> Pagination Class Initialized
INFO - 2016-03-05 12:18:16 --> Helper loaded: text_helper
INFO - 2016-03-05 12:18:16 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:18:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:18:16 --> Final output sent to browser
DEBUG - 2016-03-05 15:18:16 --> Total execution time: 1.1706
INFO - 2016-03-05 12:18:38 --> Config Class Initialized
INFO - 2016-03-05 12:18:38 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:18:38 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:18:38 --> Utf8 Class Initialized
INFO - 2016-03-05 12:18:38 --> URI Class Initialized
INFO - 2016-03-05 12:18:38 --> Router Class Initialized
INFO - 2016-03-05 12:18:38 --> Output Class Initialized
INFO - 2016-03-05 12:18:38 --> Security Class Initialized
DEBUG - 2016-03-05 12:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:18:38 --> Input Class Initialized
INFO - 2016-03-05 12:18:38 --> Language Class Initialized
INFO - 2016-03-05 12:18:38 --> Loader Class Initialized
INFO - 2016-03-05 12:18:38 --> Helper loaded: url_helper
INFO - 2016-03-05 12:18:38 --> Helper loaded: file_helper
INFO - 2016-03-05 12:18:38 --> Helper loaded: date_helper
INFO - 2016-03-05 12:18:38 --> Helper loaded: form_helper
INFO - 2016-03-05 12:18:38 --> Database Driver Class Initialized
INFO - 2016-03-05 12:18:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:18:39 --> Controller Class Initialized
INFO - 2016-03-05 12:18:39 --> Model Class Initialized
INFO - 2016-03-05 12:18:39 --> Model Class Initialized
INFO - 2016-03-05 12:18:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:18:39 --> Pagination Class Initialized
INFO - 2016-03-05 12:18:39 --> Helper loaded: text_helper
INFO - 2016-03-05 12:18:39 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:18:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:18:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:18:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:18:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:18:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:18:39 --> Final output sent to browser
DEBUG - 2016-03-05 15:18:39 --> Total execution time: 1.1780
INFO - 2016-03-05 12:18:46 --> Config Class Initialized
INFO - 2016-03-05 12:18:46 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:18:46 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:18:46 --> Utf8 Class Initialized
INFO - 2016-03-05 12:18:46 --> URI Class Initialized
INFO - 2016-03-05 12:18:46 --> Router Class Initialized
INFO - 2016-03-05 12:18:46 --> Output Class Initialized
INFO - 2016-03-05 12:18:46 --> Security Class Initialized
DEBUG - 2016-03-05 12:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:18:46 --> Input Class Initialized
INFO - 2016-03-05 12:18:46 --> Language Class Initialized
INFO - 2016-03-05 12:18:46 --> Loader Class Initialized
INFO - 2016-03-05 12:18:46 --> Helper loaded: url_helper
INFO - 2016-03-05 12:18:46 --> Helper loaded: file_helper
INFO - 2016-03-05 12:18:46 --> Helper loaded: date_helper
INFO - 2016-03-05 12:18:46 --> Helper loaded: form_helper
INFO - 2016-03-05 12:18:46 --> Database Driver Class Initialized
INFO - 2016-03-05 12:18:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:18:47 --> Controller Class Initialized
INFO - 2016-03-05 12:18:47 --> Model Class Initialized
INFO - 2016-03-05 12:18:47 --> Model Class Initialized
INFO - 2016-03-05 12:18:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:18:47 --> Pagination Class Initialized
INFO - 2016-03-05 12:18:47 --> Helper loaded: text_helper
INFO - 2016-03-05 12:18:47 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:18:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:18:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:18:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:18:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:18:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:18:47 --> Final output sent to browser
DEBUG - 2016-03-05 15:18:47 --> Total execution time: 1.1954
INFO - 2016-03-05 12:18:58 --> Config Class Initialized
INFO - 2016-03-05 12:18:58 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:18:58 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:18:58 --> Utf8 Class Initialized
INFO - 2016-03-05 12:18:58 --> URI Class Initialized
INFO - 2016-03-05 12:18:58 --> Router Class Initialized
INFO - 2016-03-05 12:18:58 --> Output Class Initialized
INFO - 2016-03-05 12:18:58 --> Security Class Initialized
DEBUG - 2016-03-05 12:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:18:58 --> Input Class Initialized
INFO - 2016-03-05 12:18:58 --> Language Class Initialized
INFO - 2016-03-05 12:18:58 --> Loader Class Initialized
INFO - 2016-03-05 12:18:58 --> Helper loaded: url_helper
INFO - 2016-03-05 12:18:58 --> Helper loaded: file_helper
INFO - 2016-03-05 12:18:58 --> Helper loaded: date_helper
INFO - 2016-03-05 12:18:58 --> Helper loaded: form_helper
INFO - 2016-03-05 12:18:58 --> Database Driver Class Initialized
INFO - 2016-03-05 12:18:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:18:59 --> Controller Class Initialized
INFO - 2016-03-05 12:18:59 --> Model Class Initialized
INFO - 2016-03-05 12:18:59 --> Model Class Initialized
INFO - 2016-03-05 12:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:18:59 --> Pagination Class Initialized
INFO - 2016-03-05 12:18:59 --> Helper loaded: text_helper
INFO - 2016-03-05 12:18:59 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:18:59 --> Final output sent to browser
DEBUG - 2016-03-05 15:18:59 --> Total execution time: 1.1427
INFO - 2016-03-05 12:19:03 --> Config Class Initialized
INFO - 2016-03-05 12:19:03 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:19:03 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:19:03 --> Utf8 Class Initialized
INFO - 2016-03-05 12:19:03 --> URI Class Initialized
INFO - 2016-03-05 12:19:03 --> Router Class Initialized
INFO - 2016-03-05 12:19:03 --> Output Class Initialized
INFO - 2016-03-05 12:19:03 --> Security Class Initialized
DEBUG - 2016-03-05 12:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:19:03 --> Input Class Initialized
INFO - 2016-03-05 12:19:03 --> Language Class Initialized
INFO - 2016-03-05 12:19:03 --> Loader Class Initialized
INFO - 2016-03-05 12:19:03 --> Helper loaded: url_helper
INFO - 2016-03-05 12:19:03 --> Helper loaded: file_helper
INFO - 2016-03-05 12:19:03 --> Helper loaded: date_helper
INFO - 2016-03-05 12:19:03 --> Helper loaded: form_helper
INFO - 2016-03-05 12:19:03 --> Database Driver Class Initialized
INFO - 2016-03-05 12:19:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:19:04 --> Controller Class Initialized
INFO - 2016-03-05 12:19:04 --> Model Class Initialized
INFO - 2016-03-05 12:19:04 --> Model Class Initialized
INFO - 2016-03-05 12:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:19:04 --> Pagination Class Initialized
INFO - 2016-03-05 12:19:04 --> Helper loaded: text_helper
INFO - 2016-03-05 12:19:04 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-05 15:19:04 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-05 15:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:19:04 --> Final output sent to browser
DEBUG - 2016-03-05 15:19:04 --> Total execution time: 1.2253
INFO - 2016-03-05 12:19:56 --> Config Class Initialized
INFO - 2016-03-05 12:19:56 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:19:56 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:19:56 --> Utf8 Class Initialized
INFO - 2016-03-05 12:19:56 --> URI Class Initialized
INFO - 2016-03-05 12:19:56 --> Router Class Initialized
INFO - 2016-03-05 12:19:56 --> Output Class Initialized
INFO - 2016-03-05 12:19:56 --> Security Class Initialized
DEBUG - 2016-03-05 12:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:19:56 --> Input Class Initialized
INFO - 2016-03-05 12:19:56 --> Language Class Initialized
INFO - 2016-03-05 12:19:56 --> Loader Class Initialized
INFO - 2016-03-05 12:19:56 --> Helper loaded: url_helper
INFO - 2016-03-05 12:19:56 --> Helper loaded: file_helper
INFO - 2016-03-05 12:19:56 --> Helper loaded: date_helper
INFO - 2016-03-05 12:19:56 --> Helper loaded: form_helper
INFO - 2016-03-05 12:19:56 --> Database Driver Class Initialized
INFO - 2016-03-05 12:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:19:57 --> Controller Class Initialized
INFO - 2016-03-05 12:19:57 --> Model Class Initialized
INFO - 2016-03-05 12:19:57 --> Model Class Initialized
INFO - 2016-03-05 12:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:19:57 --> Pagination Class Initialized
INFO - 2016-03-05 12:19:57 --> Helper loaded: text_helper
INFO - 2016-03-05 12:19:57 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:19:57 --> Final output sent to browser
DEBUG - 2016-03-05 15:19:57 --> Total execution time: 1.1594
INFO - 2016-03-05 12:22:29 --> Config Class Initialized
INFO - 2016-03-05 12:22:29 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:22:29 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:22:29 --> Utf8 Class Initialized
INFO - 2016-03-05 12:22:29 --> URI Class Initialized
INFO - 2016-03-05 12:22:29 --> Router Class Initialized
INFO - 2016-03-05 12:22:29 --> Output Class Initialized
INFO - 2016-03-05 12:22:29 --> Security Class Initialized
DEBUG - 2016-03-05 12:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:22:29 --> Input Class Initialized
INFO - 2016-03-05 12:22:29 --> Language Class Initialized
INFO - 2016-03-05 12:22:29 --> Loader Class Initialized
INFO - 2016-03-05 12:22:29 --> Helper loaded: url_helper
INFO - 2016-03-05 12:22:29 --> Helper loaded: file_helper
INFO - 2016-03-05 12:22:29 --> Helper loaded: date_helper
INFO - 2016-03-05 12:22:29 --> Helper loaded: form_helper
INFO - 2016-03-05 12:22:29 --> Database Driver Class Initialized
INFO - 2016-03-05 12:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:22:31 --> Controller Class Initialized
INFO - 2016-03-05 12:22:31 --> Model Class Initialized
INFO - 2016-03-05 12:22:31 --> Model Class Initialized
INFO - 2016-03-05 12:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:22:31 --> Pagination Class Initialized
INFO - 2016-03-05 12:22:31 --> Helper loaded: text_helper
INFO - 2016-03-05 12:22:31 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:22:31 --> Final output sent to browser
DEBUG - 2016-03-05 15:22:31 --> Total execution time: 1.5145
INFO - 2016-03-05 12:23:37 --> Config Class Initialized
INFO - 2016-03-05 12:23:37 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:23:37 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:23:37 --> Utf8 Class Initialized
INFO - 2016-03-05 12:23:37 --> URI Class Initialized
INFO - 2016-03-05 12:23:37 --> Router Class Initialized
INFO - 2016-03-05 12:23:37 --> Output Class Initialized
INFO - 2016-03-05 12:23:37 --> Security Class Initialized
DEBUG - 2016-03-05 12:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:23:37 --> Input Class Initialized
INFO - 2016-03-05 12:23:37 --> Language Class Initialized
INFO - 2016-03-05 12:23:37 --> Loader Class Initialized
INFO - 2016-03-05 12:23:37 --> Helper loaded: url_helper
INFO - 2016-03-05 12:23:37 --> Helper loaded: file_helper
INFO - 2016-03-05 12:23:37 --> Helper loaded: date_helper
INFO - 2016-03-05 12:23:37 --> Helper loaded: form_helper
INFO - 2016-03-05 12:23:37 --> Database Driver Class Initialized
INFO - 2016-03-05 12:23:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:23:38 --> Controller Class Initialized
INFO - 2016-03-05 12:23:38 --> Model Class Initialized
INFO - 2016-03-05 12:23:38 --> Model Class Initialized
INFO - 2016-03-05 12:23:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:23:38 --> Pagination Class Initialized
INFO - 2016-03-05 12:23:38 --> Helper loaded: text_helper
INFO - 2016-03-05 12:23:38 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:23:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:23:38 --> Final output sent to browser
DEBUG - 2016-03-05 15:23:38 --> Total execution time: 1.1682
INFO - 2016-03-05 12:24:35 --> Config Class Initialized
INFO - 2016-03-05 12:24:35 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:24:35 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:24:35 --> Utf8 Class Initialized
INFO - 2016-03-05 12:24:35 --> URI Class Initialized
INFO - 2016-03-05 12:24:35 --> Router Class Initialized
INFO - 2016-03-05 12:24:35 --> Output Class Initialized
INFO - 2016-03-05 12:24:35 --> Security Class Initialized
DEBUG - 2016-03-05 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:24:35 --> Input Class Initialized
INFO - 2016-03-05 12:24:35 --> Language Class Initialized
INFO - 2016-03-05 12:24:35 --> Loader Class Initialized
INFO - 2016-03-05 12:24:35 --> Helper loaded: url_helper
INFO - 2016-03-05 12:24:35 --> Helper loaded: file_helper
INFO - 2016-03-05 12:24:35 --> Helper loaded: date_helper
INFO - 2016-03-05 12:24:35 --> Helper loaded: form_helper
INFO - 2016-03-05 12:24:35 --> Database Driver Class Initialized
INFO - 2016-03-05 12:24:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:24:36 --> Controller Class Initialized
INFO - 2016-03-05 12:24:36 --> Model Class Initialized
INFO - 2016-03-05 12:24:36 --> Model Class Initialized
INFO - 2016-03-05 12:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:24:36 --> Pagination Class Initialized
INFO - 2016-03-05 12:24:36 --> Helper loaded: text_helper
INFO - 2016-03-05 12:24:36 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:24:36 --> Final output sent to browser
DEBUG - 2016-03-05 15:24:36 --> Total execution time: 1.1648
INFO - 2016-03-05 12:24:43 --> Config Class Initialized
INFO - 2016-03-05 12:24:43 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:24:43 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:24:43 --> Utf8 Class Initialized
INFO - 2016-03-05 12:24:43 --> URI Class Initialized
INFO - 2016-03-05 12:24:43 --> Router Class Initialized
INFO - 2016-03-05 12:24:43 --> Output Class Initialized
INFO - 2016-03-05 12:24:43 --> Security Class Initialized
DEBUG - 2016-03-05 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:24:43 --> Input Class Initialized
INFO - 2016-03-05 12:24:43 --> Language Class Initialized
INFO - 2016-03-05 12:24:43 --> Loader Class Initialized
INFO - 2016-03-05 12:24:43 --> Helper loaded: url_helper
INFO - 2016-03-05 12:24:43 --> Helper loaded: file_helper
INFO - 2016-03-05 12:24:43 --> Helper loaded: date_helper
INFO - 2016-03-05 12:24:43 --> Helper loaded: form_helper
INFO - 2016-03-05 12:24:43 --> Database Driver Class Initialized
INFO - 2016-03-05 12:24:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:24:44 --> Controller Class Initialized
INFO - 2016-03-05 12:24:44 --> Model Class Initialized
INFO - 2016-03-05 12:24:44 --> Model Class Initialized
INFO - 2016-03-05 12:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:24:44 --> Pagination Class Initialized
INFO - 2016-03-05 12:24:44 --> Helper loaded: text_helper
INFO - 2016-03-05 12:24:44 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-05 15:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:24:44 --> Final output sent to browser
DEBUG - 2016-03-05 15:24:44 --> Total execution time: 1.2013
INFO - 2016-03-05 12:33:32 --> Config Class Initialized
INFO - 2016-03-05 12:33:32 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:33:32 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:33:32 --> Utf8 Class Initialized
INFO - 2016-03-05 12:33:32 --> URI Class Initialized
DEBUG - 2016-03-05 12:33:32 --> No URI present. Default controller set.
INFO - 2016-03-05 12:33:32 --> Router Class Initialized
INFO - 2016-03-05 12:33:32 --> Output Class Initialized
INFO - 2016-03-05 12:33:32 --> Security Class Initialized
DEBUG - 2016-03-05 12:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:33:32 --> Input Class Initialized
INFO - 2016-03-05 12:33:32 --> Language Class Initialized
INFO - 2016-03-05 12:33:32 --> Loader Class Initialized
INFO - 2016-03-05 12:33:32 --> Helper loaded: url_helper
INFO - 2016-03-05 12:33:32 --> Helper loaded: file_helper
INFO - 2016-03-05 12:33:32 --> Helper loaded: date_helper
INFO - 2016-03-05 12:33:32 --> Helper loaded: form_helper
INFO - 2016-03-05 12:33:32 --> Database Driver Class Initialized
INFO - 2016-03-05 12:33:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:33:33 --> Controller Class Initialized
INFO - 2016-03-05 12:33:33 --> Model Class Initialized
INFO - 2016-03-05 12:33:33 --> Model Class Initialized
INFO - 2016-03-05 12:33:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:33:33 --> Pagination Class Initialized
INFO - 2016-03-05 12:33:33 --> Helper loaded: text_helper
INFO - 2016-03-05 12:33:33 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-05 15:33:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:33:33 --> Final output sent to browser
DEBUG - 2016-03-05 15:33:33 --> Total execution time: 1.1855
INFO - 2016-03-05 12:33:36 --> Config Class Initialized
INFO - 2016-03-05 12:33:36 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:33:36 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:33:36 --> Utf8 Class Initialized
INFO - 2016-03-05 12:33:36 --> URI Class Initialized
INFO - 2016-03-05 12:33:36 --> Router Class Initialized
INFO - 2016-03-05 12:33:36 --> Output Class Initialized
INFO - 2016-03-05 12:33:36 --> Security Class Initialized
DEBUG - 2016-03-05 12:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:33:36 --> Input Class Initialized
INFO - 2016-03-05 12:33:36 --> Language Class Initialized
INFO - 2016-03-05 12:33:36 --> Loader Class Initialized
INFO - 2016-03-05 12:33:36 --> Helper loaded: url_helper
INFO - 2016-03-05 12:33:36 --> Helper loaded: file_helper
INFO - 2016-03-05 12:33:36 --> Helper loaded: date_helper
INFO - 2016-03-05 12:33:36 --> Helper loaded: form_helper
INFO - 2016-03-05 12:33:36 --> Database Driver Class Initialized
INFO - 2016-03-05 12:33:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:33:37 --> Controller Class Initialized
INFO - 2016-03-05 12:33:37 --> Model Class Initialized
INFO - 2016-03-05 12:33:37 --> Model Class Initialized
INFO - 2016-03-05 12:33:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:33:37 --> Pagination Class Initialized
INFO - 2016-03-05 12:33:37 --> Helper loaded: text_helper
INFO - 2016-03-05 12:33:37 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:33:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:33:37 --> Final output sent to browser
DEBUG - 2016-03-05 15:33:37 --> Total execution time: 1.0911
INFO - 2016-03-05 12:33:40 --> Config Class Initialized
INFO - 2016-03-05 12:33:40 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:33:40 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:33:40 --> Utf8 Class Initialized
INFO - 2016-03-05 12:33:40 --> URI Class Initialized
INFO - 2016-03-05 12:33:40 --> Router Class Initialized
INFO - 2016-03-05 12:33:40 --> Output Class Initialized
INFO - 2016-03-05 12:33:40 --> Security Class Initialized
DEBUG - 2016-03-05 12:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:33:40 --> Input Class Initialized
INFO - 2016-03-05 12:33:40 --> Language Class Initialized
INFO - 2016-03-05 12:33:40 --> Loader Class Initialized
INFO - 2016-03-05 12:33:40 --> Helper loaded: url_helper
INFO - 2016-03-05 12:33:40 --> Helper loaded: file_helper
INFO - 2016-03-05 12:33:40 --> Helper loaded: date_helper
INFO - 2016-03-05 12:33:40 --> Helper loaded: form_helper
INFO - 2016-03-05 12:33:40 --> Database Driver Class Initialized
INFO - 2016-03-05 12:33:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:33:41 --> Controller Class Initialized
INFO - 2016-03-05 12:33:41 --> Model Class Initialized
INFO - 2016-03-05 12:33:41 --> Model Class Initialized
INFO - 2016-03-05 12:33:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:33:41 --> Pagination Class Initialized
INFO - 2016-03-05 12:33:41 --> Helper loaded: text_helper
INFO - 2016-03-05 12:33:41 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:33:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:33:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 15:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 15:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:33:42 --> Final output sent to browser
DEBUG - 2016-03-05 15:33:42 --> Total execution time: 1.1894
INFO - 2016-03-05 12:45:09 --> Config Class Initialized
INFO - 2016-03-05 12:45:09 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:45:09 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:45:09 --> Utf8 Class Initialized
INFO - 2016-03-05 12:45:09 --> URI Class Initialized
INFO - 2016-03-05 12:45:09 --> Router Class Initialized
INFO - 2016-03-05 12:45:09 --> Output Class Initialized
INFO - 2016-03-05 12:45:09 --> Security Class Initialized
DEBUG - 2016-03-05 12:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:45:09 --> Input Class Initialized
INFO - 2016-03-05 12:45:09 --> Language Class Initialized
INFO - 2016-03-05 12:45:09 --> Loader Class Initialized
INFO - 2016-03-05 12:45:09 --> Helper loaded: url_helper
INFO - 2016-03-05 12:45:09 --> Helper loaded: file_helper
INFO - 2016-03-05 12:45:09 --> Helper loaded: date_helper
INFO - 2016-03-05 12:45:09 --> Helper loaded: form_helper
INFO - 2016-03-05 12:45:09 --> Database Driver Class Initialized
INFO - 2016-03-05 12:45:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:45:10 --> Controller Class Initialized
INFO - 2016-03-05 12:45:10 --> Model Class Initialized
INFO - 2016-03-05 12:45:10 --> Model Class Initialized
INFO - 2016-03-05 12:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:45:10 --> Pagination Class Initialized
INFO - 2016-03-05 12:45:10 --> Helper loaded: text_helper
INFO - 2016-03-05 12:45:10 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 15:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 15:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:45:10 --> Final output sent to browser
DEBUG - 2016-03-05 15:45:10 --> Total execution time: 1.1307
INFO - 2016-03-05 12:45:11 --> Config Class Initialized
INFO - 2016-03-05 12:45:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 12:45:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 12:45:11 --> Utf8 Class Initialized
INFO - 2016-03-05 12:45:11 --> URI Class Initialized
INFO - 2016-03-05 12:45:11 --> Router Class Initialized
INFO - 2016-03-05 12:45:11 --> Output Class Initialized
INFO - 2016-03-05 12:45:11 --> Security Class Initialized
DEBUG - 2016-03-05 12:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 12:45:11 --> Input Class Initialized
INFO - 2016-03-05 12:45:11 --> Language Class Initialized
INFO - 2016-03-05 12:45:11 --> Loader Class Initialized
INFO - 2016-03-05 12:45:11 --> Helper loaded: url_helper
INFO - 2016-03-05 12:45:11 --> Helper loaded: file_helper
INFO - 2016-03-05 12:45:11 --> Helper loaded: date_helper
INFO - 2016-03-05 12:45:11 --> Helper loaded: form_helper
INFO - 2016-03-05 12:45:11 --> Database Driver Class Initialized
INFO - 2016-03-05 12:45:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 12:45:12 --> Controller Class Initialized
INFO - 2016-03-05 12:45:12 --> Model Class Initialized
INFO - 2016-03-05 12:45:12 --> Model Class Initialized
INFO - 2016-03-05 12:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 12:45:12 --> Pagination Class Initialized
INFO - 2016-03-05 12:45:12 --> Helper loaded: text_helper
INFO - 2016-03-05 12:45:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 15:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 15:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 15:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 15:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 15:45:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 15:45:13 --> Final output sent to browser
DEBUG - 2016-03-05 15:45:13 --> Total execution time: 1.1619
INFO - 2016-03-05 13:46:36 --> Config Class Initialized
INFO - 2016-03-05 13:46:36 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:46:36 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:46:36 --> Utf8 Class Initialized
INFO - 2016-03-05 13:46:36 --> URI Class Initialized
INFO - 2016-03-05 13:46:36 --> Router Class Initialized
INFO - 2016-03-05 13:46:36 --> Output Class Initialized
INFO - 2016-03-05 13:46:36 --> Security Class Initialized
DEBUG - 2016-03-05 13:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:46:36 --> Input Class Initialized
INFO - 2016-03-05 13:46:36 --> Language Class Initialized
INFO - 2016-03-05 13:46:36 --> Loader Class Initialized
INFO - 2016-03-05 13:46:36 --> Helper loaded: url_helper
INFO - 2016-03-05 13:46:36 --> Helper loaded: file_helper
INFO - 2016-03-05 13:46:36 --> Helper loaded: date_helper
INFO - 2016-03-05 13:46:36 --> Helper loaded: form_helper
INFO - 2016-03-05 13:46:36 --> Database Driver Class Initialized
INFO - 2016-03-05 13:46:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:46:37 --> Controller Class Initialized
INFO - 2016-03-05 13:46:37 --> Model Class Initialized
INFO - 2016-03-05 13:46:37 --> Model Class Initialized
INFO - 2016-03-05 13:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:46:37 --> Pagination Class Initialized
INFO - 2016-03-05 13:46:37 --> Helper loaded: text_helper
INFO - 2016-03-05 13:46:37 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$tcomment C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$tcomment C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 23
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 24
ERROR - 2016-03-05 16:46:38 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 37
INFO - 2016-03-05 16:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 16:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:46:38 --> Final output sent to browser
DEBUG - 2016-03-05 16:46:38 --> Total execution time: 1.4666
INFO - 2016-03-05 13:47:38 --> Config Class Initialized
INFO - 2016-03-05 13:47:38 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:47:38 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:47:38 --> Utf8 Class Initialized
INFO - 2016-03-05 13:47:38 --> URI Class Initialized
INFO - 2016-03-05 13:47:38 --> Router Class Initialized
INFO - 2016-03-05 13:47:38 --> Output Class Initialized
INFO - 2016-03-05 13:47:38 --> Security Class Initialized
DEBUG - 2016-03-05 13:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:47:38 --> Input Class Initialized
INFO - 2016-03-05 13:47:38 --> Language Class Initialized
INFO - 2016-03-05 13:47:38 --> Loader Class Initialized
INFO - 2016-03-05 13:47:38 --> Helper loaded: url_helper
INFO - 2016-03-05 13:47:38 --> Helper loaded: file_helper
INFO - 2016-03-05 13:47:38 --> Helper loaded: date_helper
INFO - 2016-03-05 13:47:38 --> Helper loaded: form_helper
INFO - 2016-03-05 13:47:38 --> Database Driver Class Initialized
INFO - 2016-03-05 13:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:47:39 --> Controller Class Initialized
INFO - 2016-03-05 13:47:39 --> Model Class Initialized
INFO - 2016-03-05 13:47:39 --> Model Class Initialized
INFO - 2016-03-05 13:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:47:39 --> Pagination Class Initialized
INFO - 2016-03-05 13:47:39 --> Helper loaded: text_helper
INFO - 2016-03-05 13:47:39 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-05 16:47:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:47:39 --> Final output sent to browser
DEBUG - 2016-03-05 16:47:39 --> Total execution time: 1.3532
INFO - 2016-03-05 13:53:18 --> Config Class Initialized
INFO - 2016-03-05 13:53:18 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:53:18 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:53:18 --> Utf8 Class Initialized
INFO - 2016-03-05 13:53:18 --> URI Class Initialized
INFO - 2016-03-05 13:53:18 --> Router Class Initialized
INFO - 2016-03-05 13:53:18 --> Output Class Initialized
INFO - 2016-03-05 13:53:18 --> Security Class Initialized
DEBUG - 2016-03-05 13:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:53:18 --> Input Class Initialized
INFO - 2016-03-05 13:53:18 --> Language Class Initialized
INFO - 2016-03-05 13:53:18 --> Loader Class Initialized
INFO - 2016-03-05 13:53:18 --> Helper loaded: url_helper
INFO - 2016-03-05 13:53:18 --> Helper loaded: file_helper
INFO - 2016-03-05 13:53:18 --> Helper loaded: date_helper
INFO - 2016-03-05 13:53:18 --> Helper loaded: form_helper
INFO - 2016-03-05 13:53:18 --> Database Driver Class Initialized
INFO - 2016-03-05 13:53:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:53:19 --> Controller Class Initialized
INFO - 2016-03-05 13:53:19 --> Model Class Initialized
INFO - 2016-03-05 13:53:19 --> Model Class Initialized
INFO - 2016-03-05 13:53:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:53:19 --> Pagination Class Initialized
INFO - 2016-03-05 13:53:19 --> Helper loaded: text_helper
INFO - 2016-03-05 13:53:19 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:19 --> Severity: Notice --> Undefined property: stdClass::$user_nick C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:53:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:53:19 --> Final output sent to browser
DEBUG - 2016-03-05 16:53:19 --> Total execution time: 1.3203
INFO - 2016-03-05 13:53:39 --> Config Class Initialized
INFO - 2016-03-05 13:53:39 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:53:39 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:53:39 --> Utf8 Class Initialized
INFO - 2016-03-05 13:53:39 --> URI Class Initialized
INFO - 2016-03-05 13:53:39 --> Router Class Initialized
INFO - 2016-03-05 13:53:39 --> Output Class Initialized
INFO - 2016-03-05 13:53:39 --> Security Class Initialized
DEBUG - 2016-03-05 13:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:53:39 --> Input Class Initialized
INFO - 2016-03-05 13:53:39 --> Language Class Initialized
INFO - 2016-03-05 13:53:39 --> Loader Class Initialized
INFO - 2016-03-05 13:53:39 --> Helper loaded: url_helper
INFO - 2016-03-05 13:53:39 --> Helper loaded: file_helper
INFO - 2016-03-05 13:53:39 --> Helper loaded: date_helper
INFO - 2016-03-05 13:53:39 --> Helper loaded: form_helper
INFO - 2016-03-05 13:53:39 --> Database Driver Class Initialized
INFO - 2016-03-05 13:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:53:40 --> Controller Class Initialized
INFO - 2016-03-05 13:53:40 --> Model Class Initialized
INFO - 2016-03-05 13:53:40 --> Model Class Initialized
INFO - 2016-03-05 13:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:53:40 --> Pagination Class Initialized
INFO - 2016-03-05 13:53:40 --> Helper loaded: text_helper
INFO - 2016-03-05 13:53:40 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-05 16:53:40 --> Severity: Notice --> Undefined property: stdClass::$nickname C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:53:40 --> Final output sent to browser
DEBUG - 2016-03-05 16:53:40 --> Total execution time: 1.1797
INFO - 2016-03-05 13:54:08 --> Config Class Initialized
INFO - 2016-03-05 13:54:08 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:54:08 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:54:08 --> Utf8 Class Initialized
INFO - 2016-03-05 13:54:08 --> URI Class Initialized
INFO - 2016-03-05 13:54:08 --> Router Class Initialized
INFO - 2016-03-05 13:54:08 --> Output Class Initialized
INFO - 2016-03-05 13:54:08 --> Security Class Initialized
DEBUG - 2016-03-05 13:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:54:08 --> Input Class Initialized
INFO - 2016-03-05 13:54:08 --> Language Class Initialized
INFO - 2016-03-05 13:54:08 --> Loader Class Initialized
INFO - 2016-03-05 13:54:08 --> Helper loaded: url_helper
INFO - 2016-03-05 13:54:08 --> Helper loaded: file_helper
INFO - 2016-03-05 13:54:08 --> Helper loaded: date_helper
INFO - 2016-03-05 13:54:08 --> Helper loaded: form_helper
INFO - 2016-03-05 13:54:08 --> Database Driver Class Initialized
INFO - 2016-03-05 13:54:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:54:09 --> Controller Class Initialized
INFO - 2016-03-05 13:54:09 --> Model Class Initialized
INFO - 2016-03-05 13:54:09 --> Model Class Initialized
INFO - 2016-03-05 13:54:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:54:09 --> Pagination Class Initialized
INFO - 2016-03-05 13:54:09 --> Helper loaded: text_helper
INFO - 2016-03-05 13:54:09 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:54:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:54:09 --> Final output sent to browser
DEBUG - 2016-03-05 16:54:09 --> Total execution time: 1.2075
INFO - 2016-03-05 13:54:55 --> Config Class Initialized
INFO - 2016-03-05 13:54:55 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:54:55 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:54:55 --> Utf8 Class Initialized
INFO - 2016-03-05 13:54:55 --> URI Class Initialized
INFO - 2016-03-05 13:54:55 --> Router Class Initialized
INFO - 2016-03-05 13:54:55 --> Output Class Initialized
INFO - 2016-03-05 13:54:55 --> Security Class Initialized
DEBUG - 2016-03-05 13:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:54:55 --> Input Class Initialized
INFO - 2016-03-05 13:54:55 --> Language Class Initialized
INFO - 2016-03-05 13:54:55 --> Loader Class Initialized
INFO - 2016-03-05 13:54:55 --> Helper loaded: url_helper
INFO - 2016-03-05 13:54:55 --> Helper loaded: file_helper
INFO - 2016-03-05 13:54:55 --> Helper loaded: date_helper
INFO - 2016-03-05 13:54:55 --> Helper loaded: form_helper
INFO - 2016-03-05 13:54:55 --> Database Driver Class Initialized
INFO - 2016-03-05 13:54:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:54:56 --> Controller Class Initialized
INFO - 2016-03-05 13:54:56 --> Model Class Initialized
INFO - 2016-03-05 13:54:56 --> Model Class Initialized
INFO - 2016-03-05 13:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:54:56 --> Pagination Class Initialized
INFO - 2016-03-05 13:54:56 --> Helper loaded: text_helper
INFO - 2016-03-05 13:54:56 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:54:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:54:56 --> Final output sent to browser
DEBUG - 2016-03-05 16:54:56 --> Total execution time: 1.1900
INFO - 2016-03-05 13:55:21 --> Config Class Initialized
INFO - 2016-03-05 13:55:21 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:55:21 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:55:21 --> Utf8 Class Initialized
INFO - 2016-03-05 13:55:21 --> URI Class Initialized
INFO - 2016-03-05 13:55:21 --> Router Class Initialized
INFO - 2016-03-05 13:55:21 --> Output Class Initialized
INFO - 2016-03-05 13:55:21 --> Security Class Initialized
DEBUG - 2016-03-05 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:55:21 --> Input Class Initialized
INFO - 2016-03-05 13:55:21 --> Language Class Initialized
INFO - 2016-03-05 13:55:21 --> Loader Class Initialized
INFO - 2016-03-05 13:55:21 --> Helper loaded: url_helper
INFO - 2016-03-05 13:55:21 --> Helper loaded: file_helper
INFO - 2016-03-05 13:55:21 --> Helper loaded: date_helper
INFO - 2016-03-05 13:55:21 --> Helper loaded: form_helper
INFO - 2016-03-05 13:55:21 --> Database Driver Class Initialized
INFO - 2016-03-05 13:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:55:22 --> Controller Class Initialized
INFO - 2016-03-05 13:55:22 --> Model Class Initialized
INFO - 2016-03-05 13:55:22 --> Model Class Initialized
INFO - 2016-03-05 13:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:55:22 --> Pagination Class Initialized
INFO - 2016-03-05 13:55:22 --> Helper loaded: text_helper
INFO - 2016-03-05 13:55:22 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:55:22 --> Final output sent to browser
DEBUG - 2016-03-05 16:55:22 --> Total execution time: 1.2279
INFO - 2016-03-05 13:56:10 --> Config Class Initialized
INFO - 2016-03-05 13:56:10 --> Hooks Class Initialized
DEBUG - 2016-03-05 13:56:10 --> UTF-8 Support Enabled
INFO - 2016-03-05 13:56:10 --> Utf8 Class Initialized
INFO - 2016-03-05 13:56:10 --> URI Class Initialized
INFO - 2016-03-05 13:56:10 --> Router Class Initialized
INFO - 2016-03-05 13:56:10 --> Output Class Initialized
INFO - 2016-03-05 13:56:10 --> Security Class Initialized
DEBUG - 2016-03-05 13:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 13:56:10 --> Input Class Initialized
INFO - 2016-03-05 13:56:10 --> Language Class Initialized
INFO - 2016-03-05 13:56:10 --> Loader Class Initialized
INFO - 2016-03-05 13:56:10 --> Helper loaded: url_helper
INFO - 2016-03-05 13:56:10 --> Helper loaded: file_helper
INFO - 2016-03-05 13:56:10 --> Helper loaded: date_helper
INFO - 2016-03-05 13:56:10 --> Helper loaded: form_helper
INFO - 2016-03-05 13:56:10 --> Database Driver Class Initialized
INFO - 2016-03-05 13:56:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 13:56:11 --> Controller Class Initialized
INFO - 2016-03-05 13:56:11 --> Model Class Initialized
INFO - 2016-03-05 13:56:11 --> Model Class Initialized
INFO - 2016-03-05 13:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 13:56:11 --> Pagination Class Initialized
INFO - 2016-03-05 13:56:11 --> Helper loaded: text_helper
INFO - 2016-03-05 13:56:11 --> Helper loaded: cookie_helper
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 16:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 16:56:11 --> Final output sent to browser
DEBUG - 2016-03-05 16:56:11 --> Total execution time: 1.1830
INFO - 2016-03-05 14:07:34 --> Config Class Initialized
INFO - 2016-03-05 14:07:34 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:07:34 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:07:34 --> Utf8 Class Initialized
INFO - 2016-03-05 14:07:34 --> URI Class Initialized
INFO - 2016-03-05 14:07:34 --> Router Class Initialized
INFO - 2016-03-05 14:07:34 --> Output Class Initialized
INFO - 2016-03-05 14:07:34 --> Security Class Initialized
DEBUG - 2016-03-05 14:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:07:34 --> Input Class Initialized
INFO - 2016-03-05 14:07:34 --> Language Class Initialized
INFO - 2016-03-05 14:07:34 --> Loader Class Initialized
INFO - 2016-03-05 14:07:34 --> Helper loaded: url_helper
INFO - 2016-03-05 14:07:34 --> Helper loaded: file_helper
INFO - 2016-03-05 14:07:34 --> Helper loaded: date_helper
INFO - 2016-03-05 14:07:34 --> Helper loaded: form_helper
INFO - 2016-03-05 14:07:34 --> Database Driver Class Initialized
INFO - 2016-03-05 14:07:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:07:35 --> Controller Class Initialized
INFO - 2016-03-05 14:07:35 --> Model Class Initialized
INFO - 2016-03-05 14:07:35 --> Model Class Initialized
INFO - 2016-03-05 14:07:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:07:35 --> Pagination Class Initialized
INFO - 2016-03-05 14:07:35 --> Helper loaded: text_helper
INFO - 2016-03-05 14:07:35 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:07:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:07:35 --> Final output sent to browser
DEBUG - 2016-03-05 17:07:35 --> Total execution time: 1.2331
INFO - 2016-03-05 14:07:49 --> Config Class Initialized
INFO - 2016-03-05 14:07:49 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:07:49 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:07:49 --> Utf8 Class Initialized
INFO - 2016-03-05 14:07:49 --> URI Class Initialized
INFO - 2016-03-05 14:07:49 --> Router Class Initialized
INFO - 2016-03-05 14:07:49 --> Output Class Initialized
INFO - 2016-03-05 14:07:49 --> Security Class Initialized
DEBUG - 2016-03-05 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:07:49 --> Input Class Initialized
INFO - 2016-03-05 14:07:49 --> Language Class Initialized
INFO - 2016-03-05 14:07:49 --> Loader Class Initialized
INFO - 2016-03-05 14:07:49 --> Helper loaded: url_helper
INFO - 2016-03-05 14:07:49 --> Helper loaded: file_helper
INFO - 2016-03-05 14:07:49 --> Helper loaded: date_helper
INFO - 2016-03-05 14:07:49 --> Helper loaded: form_helper
INFO - 2016-03-05 14:07:49 --> Database Driver Class Initialized
INFO - 2016-03-05 14:07:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:07:50 --> Controller Class Initialized
INFO - 2016-03-05 14:07:50 --> Model Class Initialized
INFO - 2016-03-05 14:07:50 --> Model Class Initialized
INFO - 2016-03-05 14:07:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:07:50 --> Pagination Class Initialized
INFO - 2016-03-05 14:07:50 --> Helper loaded: text_helper
INFO - 2016-03-05 14:07:50 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 17:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 17:07:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:07:50 --> Final output sent to browser
DEBUG - 2016-03-05 17:07:50 --> Total execution time: 1.1049
INFO - 2016-03-05 14:07:54 --> Config Class Initialized
INFO - 2016-03-05 14:07:54 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:07:54 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:07:54 --> Utf8 Class Initialized
INFO - 2016-03-05 14:07:54 --> URI Class Initialized
INFO - 2016-03-05 14:07:54 --> Router Class Initialized
INFO - 2016-03-05 14:07:54 --> Output Class Initialized
INFO - 2016-03-05 14:07:54 --> Security Class Initialized
DEBUG - 2016-03-05 14:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:07:54 --> Input Class Initialized
INFO - 2016-03-05 14:07:54 --> Language Class Initialized
INFO - 2016-03-05 14:07:54 --> Loader Class Initialized
INFO - 2016-03-05 14:07:54 --> Helper loaded: url_helper
INFO - 2016-03-05 14:07:54 --> Helper loaded: file_helper
INFO - 2016-03-05 14:07:54 --> Helper loaded: date_helper
INFO - 2016-03-05 14:07:54 --> Helper loaded: form_helper
INFO - 2016-03-05 14:07:54 --> Database Driver Class Initialized
INFO - 2016-03-05 14:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:07:55 --> Controller Class Initialized
INFO - 2016-03-05 14:07:55 --> Model Class Initialized
INFO - 2016-03-05 14:07:55 --> Model Class Initialized
INFO - 2016-03-05 14:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:07:55 --> Pagination Class Initialized
INFO - 2016-03-05 14:07:55 --> Helper loaded: text_helper
INFO - 2016-03-05 14:07:55 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-05 17:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-05 17:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:07:55 --> Final output sent to browser
DEBUG - 2016-03-05 17:07:55 --> Total execution time: 1.1328
INFO - 2016-03-05 14:07:57 --> Config Class Initialized
INFO - 2016-03-05 14:07:57 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:07:57 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:07:57 --> Utf8 Class Initialized
INFO - 2016-03-05 14:07:57 --> URI Class Initialized
INFO - 2016-03-05 14:07:57 --> Router Class Initialized
INFO - 2016-03-05 14:07:57 --> Output Class Initialized
INFO - 2016-03-05 14:07:57 --> Security Class Initialized
DEBUG - 2016-03-05 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:07:57 --> Input Class Initialized
INFO - 2016-03-05 14:07:57 --> Language Class Initialized
INFO - 2016-03-05 14:07:57 --> Loader Class Initialized
INFO - 2016-03-05 14:07:57 --> Helper loaded: url_helper
INFO - 2016-03-05 14:07:57 --> Helper loaded: file_helper
INFO - 2016-03-05 14:07:57 --> Helper loaded: date_helper
INFO - 2016-03-05 14:07:57 --> Helper loaded: form_helper
INFO - 2016-03-05 14:07:57 --> Database Driver Class Initialized
INFO - 2016-03-05 14:07:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:07:58 --> Controller Class Initialized
INFO - 2016-03-05 14:07:58 --> Model Class Initialized
INFO - 2016-03-05 14:07:58 --> Model Class Initialized
INFO - 2016-03-05 14:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:07:58 --> Pagination Class Initialized
INFO - 2016-03-05 14:07:58 --> Helper loaded: text_helper
INFO - 2016-03-05 14:07:58 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:07:59 --> Final output sent to browser
DEBUG - 2016-03-05 17:07:59 --> Total execution time: 1.2132
INFO - 2016-03-05 14:13:08 --> Config Class Initialized
INFO - 2016-03-05 14:13:08 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:13:08 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:13:08 --> Utf8 Class Initialized
INFO - 2016-03-05 14:13:08 --> URI Class Initialized
INFO - 2016-03-05 14:13:08 --> Router Class Initialized
INFO - 2016-03-05 14:13:08 --> Output Class Initialized
INFO - 2016-03-05 14:13:08 --> Security Class Initialized
DEBUG - 2016-03-05 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:13:08 --> Input Class Initialized
INFO - 2016-03-05 14:13:08 --> Language Class Initialized
INFO - 2016-03-05 14:13:08 --> Loader Class Initialized
INFO - 2016-03-05 14:13:08 --> Helper loaded: url_helper
INFO - 2016-03-05 14:13:08 --> Helper loaded: file_helper
INFO - 2016-03-05 14:13:08 --> Helper loaded: date_helper
INFO - 2016-03-05 14:13:08 --> Helper loaded: form_helper
INFO - 2016-03-05 14:13:08 --> Database Driver Class Initialized
INFO - 2016-03-05 14:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:13:10 --> Controller Class Initialized
INFO - 2016-03-05 14:13:10 --> Model Class Initialized
INFO - 2016-03-05 14:13:10 --> Model Class Initialized
INFO - 2016-03-05 14:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:13:10 --> Pagination Class Initialized
INFO - 2016-03-05 14:13:10 --> Helper loaded: text_helper
INFO - 2016-03-05 14:13:10 --> Helper loaded: cookie_helper
INFO - 2016-03-05 14:13:10 --> Form Validation Class Initialized
INFO - 2016-03-05 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-05 17:13:10 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 121 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 181
ERROR - 2016-03-05 17:13:10 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 183
ERROR - 2016-03-05 17:13:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '83 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 83 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-03-05 17:13:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-05 14:13:15 --> Config Class Initialized
INFO - 2016-03-05 14:13:15 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:13:15 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:13:15 --> Utf8 Class Initialized
INFO - 2016-03-05 14:13:15 --> URI Class Initialized
INFO - 2016-03-05 14:13:15 --> Router Class Initialized
INFO - 2016-03-05 14:13:15 --> Output Class Initialized
INFO - 2016-03-05 14:13:15 --> Security Class Initialized
DEBUG - 2016-03-05 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:13:15 --> Input Class Initialized
INFO - 2016-03-05 14:13:15 --> Language Class Initialized
INFO - 2016-03-05 14:13:15 --> Loader Class Initialized
INFO - 2016-03-05 14:13:15 --> Helper loaded: url_helper
INFO - 2016-03-05 14:13:15 --> Helper loaded: file_helper
INFO - 2016-03-05 14:13:15 --> Helper loaded: date_helper
INFO - 2016-03-05 14:13:15 --> Helper loaded: form_helper
INFO - 2016-03-05 14:13:15 --> Database Driver Class Initialized
INFO - 2016-03-05 14:13:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:13:16 --> Controller Class Initialized
INFO - 2016-03-05 14:13:16 --> Model Class Initialized
INFO - 2016-03-05 14:13:16 --> Model Class Initialized
INFO - 2016-03-05 14:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:13:16 --> Pagination Class Initialized
INFO - 2016-03-05 14:13:16 --> Helper loaded: text_helper
INFO - 2016-03-05 14:13:16 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:13:16 --> Final output sent to browser
DEBUG - 2016-03-05 17:13:16 --> Total execution time: 1.2179
INFO - 2016-03-05 14:13:59 --> Config Class Initialized
INFO - 2016-03-05 14:13:59 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:13:59 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:13:59 --> Utf8 Class Initialized
INFO - 2016-03-05 14:13:59 --> URI Class Initialized
INFO - 2016-03-05 14:13:59 --> Router Class Initialized
INFO - 2016-03-05 14:13:59 --> Output Class Initialized
INFO - 2016-03-05 14:13:59 --> Security Class Initialized
DEBUG - 2016-03-05 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:13:59 --> Input Class Initialized
INFO - 2016-03-05 14:13:59 --> Language Class Initialized
INFO - 2016-03-05 14:13:59 --> Loader Class Initialized
INFO - 2016-03-05 14:13:59 --> Helper loaded: url_helper
INFO - 2016-03-05 14:13:59 --> Helper loaded: file_helper
INFO - 2016-03-05 14:13:59 --> Helper loaded: date_helper
INFO - 2016-03-05 14:13:59 --> Helper loaded: form_helper
INFO - 2016-03-05 14:13:59 --> Database Driver Class Initialized
INFO - 2016-03-05 14:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:14:00 --> Controller Class Initialized
INFO - 2016-03-05 14:14:00 --> Model Class Initialized
INFO - 2016-03-05 14:14:00 --> Model Class Initialized
INFO - 2016-03-05 14:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:14:00 --> Pagination Class Initialized
INFO - 2016-03-05 14:14:00 --> Helper loaded: text_helper
INFO - 2016-03-05 14:14:00 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:14:00 --> Final output sent to browser
DEBUG - 2016-03-05 17:14:00 --> Total execution time: 1.2165
INFO - 2016-03-05 14:14:01 --> Config Class Initialized
INFO - 2016-03-05 14:14:01 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:14:01 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:14:01 --> Utf8 Class Initialized
INFO - 2016-03-05 14:14:01 --> URI Class Initialized
INFO - 2016-03-05 14:14:01 --> Router Class Initialized
INFO - 2016-03-05 14:14:01 --> Output Class Initialized
INFO - 2016-03-05 14:14:01 --> Security Class Initialized
DEBUG - 2016-03-05 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:14:01 --> Input Class Initialized
INFO - 2016-03-05 14:14:01 --> Language Class Initialized
INFO - 2016-03-05 14:14:01 --> Loader Class Initialized
INFO - 2016-03-05 14:14:01 --> Helper loaded: url_helper
INFO - 2016-03-05 14:14:01 --> Helper loaded: file_helper
INFO - 2016-03-05 14:14:01 --> Helper loaded: date_helper
INFO - 2016-03-05 14:14:01 --> Helper loaded: form_helper
INFO - 2016-03-05 14:14:01 --> Database Driver Class Initialized
INFO - 2016-03-05 14:14:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:14:02 --> Controller Class Initialized
INFO - 2016-03-05 14:14:02 --> Model Class Initialized
INFO - 2016-03-05 14:14:02 --> Model Class Initialized
INFO - 2016-03-05 14:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:14:02 --> Pagination Class Initialized
INFO - 2016-03-05 14:14:02 --> Helper loaded: text_helper
INFO - 2016-03-05 14:14:02 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:14:02 --> Final output sent to browser
DEBUG - 2016-03-05 17:14:02 --> Total execution time: 1.2919
INFO - 2016-03-05 14:21:11 --> Config Class Initialized
INFO - 2016-03-05 14:21:11 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:21:11 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:21:11 --> Utf8 Class Initialized
INFO - 2016-03-05 14:21:11 --> URI Class Initialized
INFO - 2016-03-05 14:21:11 --> Router Class Initialized
INFO - 2016-03-05 14:21:11 --> Output Class Initialized
INFO - 2016-03-05 14:21:11 --> Security Class Initialized
DEBUG - 2016-03-05 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:21:11 --> Input Class Initialized
INFO - 2016-03-05 14:21:11 --> Language Class Initialized
INFO - 2016-03-05 14:21:11 --> Loader Class Initialized
INFO - 2016-03-05 14:21:11 --> Helper loaded: url_helper
INFO - 2016-03-05 14:21:11 --> Helper loaded: file_helper
INFO - 2016-03-05 14:21:11 --> Helper loaded: date_helper
INFO - 2016-03-05 14:21:11 --> Helper loaded: form_helper
INFO - 2016-03-05 14:21:11 --> Database Driver Class Initialized
INFO - 2016-03-05 14:21:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:21:12 --> Controller Class Initialized
INFO - 2016-03-05 14:21:12 --> Model Class Initialized
INFO - 2016-03-05 14:21:12 --> Model Class Initialized
INFO - 2016-03-05 14:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:21:12 --> Pagination Class Initialized
INFO - 2016-03-05 14:21:12 --> Helper loaded: text_helper
INFO - 2016-03-05 14:21:12 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-05 17:21:12 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 18
INFO - 2016-03-05 14:21:27 --> Config Class Initialized
INFO - 2016-03-05 14:21:27 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:21:27 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:21:27 --> Utf8 Class Initialized
INFO - 2016-03-05 14:21:27 --> URI Class Initialized
INFO - 2016-03-05 14:21:27 --> Router Class Initialized
INFO - 2016-03-05 14:21:27 --> Output Class Initialized
INFO - 2016-03-05 14:21:27 --> Security Class Initialized
DEBUG - 2016-03-05 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:21:27 --> Input Class Initialized
INFO - 2016-03-05 14:21:27 --> Language Class Initialized
INFO - 2016-03-05 14:21:27 --> Loader Class Initialized
INFO - 2016-03-05 14:21:27 --> Helper loaded: url_helper
INFO - 2016-03-05 14:21:27 --> Helper loaded: file_helper
INFO - 2016-03-05 14:21:27 --> Helper loaded: date_helper
INFO - 2016-03-05 14:21:27 --> Helper loaded: form_helper
INFO - 2016-03-05 14:21:27 --> Database Driver Class Initialized
INFO - 2016-03-05 14:21:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:21:28 --> Controller Class Initialized
INFO - 2016-03-05 14:21:28 --> Model Class Initialized
INFO - 2016-03-05 14:21:28 --> Model Class Initialized
INFO - 2016-03-05 14:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:21:28 --> Pagination Class Initialized
INFO - 2016-03-05 14:21:28 --> Helper loaded: text_helper
INFO - 2016-03-05 14:21:28 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:21:28 --> Final output sent to browser
DEBUG - 2016-03-05 17:21:28 --> Total execution time: 1.1835
INFO - 2016-03-05 14:22:26 --> Config Class Initialized
INFO - 2016-03-05 14:22:26 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:22:26 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:22:26 --> Utf8 Class Initialized
INFO - 2016-03-05 14:22:26 --> URI Class Initialized
INFO - 2016-03-05 14:22:26 --> Router Class Initialized
INFO - 2016-03-05 14:22:26 --> Output Class Initialized
INFO - 2016-03-05 14:22:26 --> Security Class Initialized
DEBUG - 2016-03-05 14:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:22:26 --> Input Class Initialized
INFO - 2016-03-05 14:22:26 --> Language Class Initialized
INFO - 2016-03-05 14:22:26 --> Loader Class Initialized
INFO - 2016-03-05 14:22:26 --> Helper loaded: url_helper
INFO - 2016-03-05 14:22:26 --> Helper loaded: file_helper
INFO - 2016-03-05 14:22:26 --> Helper loaded: date_helper
INFO - 2016-03-05 14:22:26 --> Helper loaded: form_helper
INFO - 2016-03-05 14:22:26 --> Database Driver Class Initialized
INFO - 2016-03-05 14:22:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:22:27 --> Controller Class Initialized
INFO - 2016-03-05 14:22:27 --> Model Class Initialized
INFO - 2016-03-05 14:22:27 --> Model Class Initialized
INFO - 2016-03-05 14:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:22:27 --> Pagination Class Initialized
INFO - 2016-03-05 14:22:27 --> Helper loaded: text_helper
INFO - 2016-03-05 14:22:27 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:22:27 --> Final output sent to browser
DEBUG - 2016-03-05 17:22:27 --> Total execution time: 1.2197
INFO - 2016-03-05 14:22:52 --> Config Class Initialized
INFO - 2016-03-05 14:22:52 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:22:52 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:22:52 --> Utf8 Class Initialized
INFO - 2016-03-05 14:22:52 --> URI Class Initialized
INFO - 2016-03-05 14:22:52 --> Router Class Initialized
INFO - 2016-03-05 14:22:52 --> Output Class Initialized
INFO - 2016-03-05 14:22:52 --> Security Class Initialized
DEBUG - 2016-03-05 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:22:52 --> Input Class Initialized
INFO - 2016-03-05 14:22:52 --> Language Class Initialized
INFO - 2016-03-05 14:22:52 --> Loader Class Initialized
INFO - 2016-03-05 14:22:52 --> Helper loaded: url_helper
INFO - 2016-03-05 14:22:52 --> Helper loaded: file_helper
INFO - 2016-03-05 14:22:52 --> Helper loaded: date_helper
INFO - 2016-03-05 14:22:52 --> Helper loaded: form_helper
INFO - 2016-03-05 14:22:52 --> Database Driver Class Initialized
INFO - 2016-03-05 14:22:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:22:53 --> Controller Class Initialized
INFO - 2016-03-05 14:22:53 --> Model Class Initialized
INFO - 2016-03-05 14:22:54 --> Model Class Initialized
INFO - 2016-03-05 14:22:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:22:54 --> Pagination Class Initialized
INFO - 2016-03-05 14:22:54 --> Helper loaded: text_helper
INFO - 2016-03-05 14:22:54 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:22:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:22:54 --> Final output sent to browser
DEBUG - 2016-03-05 17:22:54 --> Total execution time: 1.2362
INFO - 2016-03-05 14:24:53 --> Config Class Initialized
INFO - 2016-03-05 14:24:53 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:24:53 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:24:53 --> Utf8 Class Initialized
INFO - 2016-03-05 14:24:53 --> URI Class Initialized
INFO - 2016-03-05 14:24:53 --> Router Class Initialized
INFO - 2016-03-05 14:24:53 --> Output Class Initialized
INFO - 2016-03-05 14:24:53 --> Security Class Initialized
DEBUG - 2016-03-05 14:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:24:53 --> Input Class Initialized
INFO - 2016-03-05 14:24:53 --> Language Class Initialized
INFO - 2016-03-05 14:24:53 --> Loader Class Initialized
INFO - 2016-03-05 14:24:53 --> Helper loaded: url_helper
INFO - 2016-03-05 14:24:53 --> Helper loaded: file_helper
INFO - 2016-03-05 14:24:53 --> Helper loaded: date_helper
INFO - 2016-03-05 14:24:53 --> Helper loaded: form_helper
INFO - 2016-03-05 14:24:53 --> Database Driver Class Initialized
INFO - 2016-03-05 14:24:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:24:54 --> Controller Class Initialized
INFO - 2016-03-05 14:24:54 --> Model Class Initialized
INFO - 2016-03-05 14:24:54 --> Model Class Initialized
INFO - 2016-03-05 14:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:24:54 --> Pagination Class Initialized
INFO - 2016-03-05 14:24:54 --> Helper loaded: text_helper
INFO - 2016-03-05 14:24:54 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:24:54 --> Final output sent to browser
DEBUG - 2016-03-05 17:24:54 --> Total execution time: 1.2119
INFO - 2016-03-05 14:26:17 --> Config Class Initialized
INFO - 2016-03-05 14:26:17 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:26:17 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:26:17 --> Utf8 Class Initialized
INFO - 2016-03-05 14:26:17 --> URI Class Initialized
INFO - 2016-03-05 14:26:17 --> Router Class Initialized
INFO - 2016-03-05 14:26:17 --> Output Class Initialized
INFO - 2016-03-05 14:26:17 --> Security Class Initialized
DEBUG - 2016-03-05 14:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:26:17 --> Input Class Initialized
INFO - 2016-03-05 14:26:17 --> Language Class Initialized
INFO - 2016-03-05 14:26:17 --> Loader Class Initialized
INFO - 2016-03-05 14:26:17 --> Helper loaded: url_helper
INFO - 2016-03-05 14:26:17 --> Helper loaded: file_helper
INFO - 2016-03-05 14:26:17 --> Helper loaded: date_helper
INFO - 2016-03-05 14:26:17 --> Helper loaded: form_helper
INFO - 2016-03-05 14:26:17 --> Database Driver Class Initialized
INFO - 2016-03-05 14:26:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:26:18 --> Controller Class Initialized
INFO - 2016-03-05 14:26:18 --> Model Class Initialized
INFO - 2016-03-05 14:26:18 --> Model Class Initialized
INFO - 2016-03-05 14:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:26:18 --> Pagination Class Initialized
INFO - 2016-03-05 14:26:18 --> Helper loaded: text_helper
INFO - 2016-03-05 14:26:18 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:26:18 --> Final output sent to browser
DEBUG - 2016-03-05 17:26:18 --> Total execution time: 1.2573
INFO - 2016-03-05 14:27:45 --> Config Class Initialized
INFO - 2016-03-05 14:27:45 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:27:45 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:27:45 --> Utf8 Class Initialized
INFO - 2016-03-05 14:27:45 --> URI Class Initialized
INFO - 2016-03-05 14:27:45 --> Router Class Initialized
INFO - 2016-03-05 14:27:45 --> Output Class Initialized
INFO - 2016-03-05 14:27:45 --> Security Class Initialized
DEBUG - 2016-03-05 14:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:27:45 --> Input Class Initialized
INFO - 2016-03-05 14:27:45 --> Language Class Initialized
INFO - 2016-03-05 14:27:45 --> Loader Class Initialized
INFO - 2016-03-05 14:27:45 --> Helper loaded: url_helper
INFO - 2016-03-05 14:27:45 --> Helper loaded: file_helper
INFO - 2016-03-05 14:27:45 --> Helper loaded: date_helper
INFO - 2016-03-05 14:27:45 --> Helper loaded: form_helper
INFO - 2016-03-05 14:27:45 --> Database Driver Class Initialized
INFO - 2016-03-05 14:27:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:27:46 --> Controller Class Initialized
INFO - 2016-03-05 14:27:46 --> Model Class Initialized
INFO - 2016-03-05 14:27:46 --> Model Class Initialized
INFO - 2016-03-05 14:27:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:27:46 --> Pagination Class Initialized
INFO - 2016-03-05 14:27:46 --> Helper loaded: text_helper
INFO - 2016-03-05 14:27:46 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:27:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:27:46 --> Final output sent to browser
DEBUG - 2016-03-05 17:27:46 --> Total execution time: 1.1887
INFO - 2016-03-05 14:28:33 --> Config Class Initialized
INFO - 2016-03-05 14:28:33 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:28:33 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:28:33 --> Utf8 Class Initialized
INFO - 2016-03-05 14:28:33 --> URI Class Initialized
INFO - 2016-03-05 14:28:33 --> Router Class Initialized
INFO - 2016-03-05 14:28:33 --> Output Class Initialized
INFO - 2016-03-05 14:28:33 --> Security Class Initialized
DEBUG - 2016-03-05 14:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:28:33 --> Input Class Initialized
INFO - 2016-03-05 14:28:33 --> Language Class Initialized
INFO - 2016-03-05 14:28:33 --> Loader Class Initialized
INFO - 2016-03-05 14:28:33 --> Helper loaded: url_helper
INFO - 2016-03-05 14:28:33 --> Helper loaded: file_helper
INFO - 2016-03-05 14:28:33 --> Helper loaded: date_helper
INFO - 2016-03-05 14:28:33 --> Helper loaded: form_helper
INFO - 2016-03-05 14:28:33 --> Database Driver Class Initialized
INFO - 2016-03-05 14:28:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:28:34 --> Controller Class Initialized
INFO - 2016-03-05 14:28:34 --> Model Class Initialized
INFO - 2016-03-05 14:28:34 --> Model Class Initialized
INFO - 2016-03-05 14:28:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:28:34 --> Pagination Class Initialized
INFO - 2016-03-05 14:28:34 --> Helper loaded: text_helper
INFO - 2016-03-05 14:28:34 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:28:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:28:34 --> Final output sent to browser
DEBUG - 2016-03-05 17:28:34 --> Total execution time: 1.2061
INFO - 2016-03-05 14:28:40 --> Config Class Initialized
INFO - 2016-03-05 14:28:40 --> Hooks Class Initialized
DEBUG - 2016-03-05 14:28:40 --> UTF-8 Support Enabled
INFO - 2016-03-05 14:28:40 --> Utf8 Class Initialized
INFO - 2016-03-05 14:28:40 --> URI Class Initialized
INFO - 2016-03-05 14:28:40 --> Router Class Initialized
INFO - 2016-03-05 14:28:40 --> Output Class Initialized
INFO - 2016-03-05 14:28:40 --> Security Class Initialized
DEBUG - 2016-03-05 14:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-05 14:28:40 --> Input Class Initialized
INFO - 2016-03-05 14:28:40 --> Language Class Initialized
INFO - 2016-03-05 14:28:40 --> Loader Class Initialized
INFO - 2016-03-05 14:28:40 --> Helper loaded: url_helper
INFO - 2016-03-05 14:28:40 --> Helper loaded: file_helper
INFO - 2016-03-05 14:28:40 --> Helper loaded: date_helper
INFO - 2016-03-05 14:28:40 --> Helper loaded: form_helper
INFO - 2016-03-05 14:28:40 --> Database Driver Class Initialized
INFO - 2016-03-05 14:28:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-05 14:28:41 --> Controller Class Initialized
INFO - 2016-03-05 14:28:41 --> Model Class Initialized
INFO - 2016-03-05 14:28:41 --> Model Class Initialized
INFO - 2016-03-05 14:28:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-05 14:28:41 --> Pagination Class Initialized
INFO - 2016-03-05 14:28:41 --> Helper loaded: text_helper
INFO - 2016-03-05 14:28:41 --> Helper loaded: cookie_helper
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-05 17:28:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-05 17:28:41 --> Final output sent to browser
DEBUG - 2016-03-05 17:28:41 --> Total execution time: 1.3122
