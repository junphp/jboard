<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-23 06:48:11 --> Config Class Initialized
INFO - 2016-03-23 06:48:11 --> Hooks Class Initialized
DEBUG - 2016-03-23 06:48:11 --> UTF-8 Support Enabled
INFO - 2016-03-23 06:48:11 --> Utf8 Class Initialized
INFO - 2016-03-23 06:48:11 --> URI Class Initialized
DEBUG - 2016-03-23 06:48:11 --> No URI present. Default controller set.
INFO - 2016-03-23 06:48:11 --> Router Class Initialized
INFO - 2016-03-23 06:48:11 --> Output Class Initialized
INFO - 2016-03-23 06:48:11 --> Security Class Initialized
DEBUG - 2016-03-23 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-23 06:48:11 --> Input Class Initialized
INFO - 2016-03-23 06:48:11 --> Language Class Initialized
INFO - 2016-03-23 06:48:11 --> Loader Class Initialized
INFO - 2016-03-23 06:48:11 --> Helper loaded: url_helper
INFO - 2016-03-23 06:48:11 --> Helper loaded: file_helper
INFO - 2016-03-23 06:48:11 --> Helper loaded: date_helper
INFO - 2016-03-23 06:48:11 --> Helper loaded: form_helper
INFO - 2016-03-23 06:48:11 --> Database Driver Class Initialized
INFO - 2016-03-23 06:48:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-23 06:48:15 --> Controller Class Initialized
INFO - 2016-03-23 06:48:15 --> Model Class Initialized
INFO - 2016-03-23 06:48:15 --> Model Class Initialized
INFO - 2016-03-23 06:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-23 06:48:15 --> Pagination Class Initialized
INFO - 2016-03-23 06:48:15 --> Helper loaded: text_helper
INFO - 2016-03-23 06:48:15 --> Helper loaded: cookie_helper
INFO - 2016-03-23 09:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-23 09:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-23 09:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-23 09:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-23 09:48:15 --> Final output sent to browser
DEBUG - 2016-03-23 09:48:15 --> Total execution time: 5.2223
INFO - 2016-03-23 10:10:05 --> Config Class Initialized
INFO - 2016-03-23 10:10:05 --> Hooks Class Initialized
DEBUG - 2016-03-23 10:10:05 --> UTF-8 Support Enabled
INFO - 2016-03-23 10:10:05 --> Utf8 Class Initialized
INFO - 2016-03-23 10:10:05 --> URI Class Initialized
DEBUG - 2016-03-23 10:10:05 --> No URI present. Default controller set.
INFO - 2016-03-23 10:10:05 --> Router Class Initialized
INFO - 2016-03-23 10:10:05 --> Output Class Initialized
INFO - 2016-03-23 10:10:05 --> Security Class Initialized
DEBUG - 2016-03-23 10:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-23 10:10:05 --> Input Class Initialized
INFO - 2016-03-23 10:10:05 --> Language Class Initialized
INFO - 2016-03-23 10:10:05 --> Loader Class Initialized
INFO - 2016-03-23 10:10:05 --> Helper loaded: url_helper
INFO - 2016-03-23 10:10:05 --> Helper loaded: file_helper
INFO - 2016-03-23 10:10:05 --> Helper loaded: date_helper
INFO - 2016-03-23 10:10:05 --> Helper loaded: form_helper
INFO - 2016-03-23 10:10:05 --> Database Driver Class Initialized
INFO - 2016-03-23 10:10:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-23 10:10:07 --> Controller Class Initialized
INFO - 2016-03-23 10:10:07 --> Model Class Initialized
INFO - 2016-03-23 10:10:07 --> Model Class Initialized
INFO - 2016-03-23 10:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-23 10:10:07 --> Pagination Class Initialized
INFO - 2016-03-23 10:10:07 --> Helper loaded: text_helper
INFO - 2016-03-23 10:10:07 --> Helper loaded: cookie_helper
INFO - 2016-03-23 13:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-23 13:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-23 13:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-23 13:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-23 13:10:07 --> Final output sent to browser
DEBUG - 2016-03-23 13:10:07 --> Total execution time: 2.4447
INFO - 2016-03-23 10:10:22 --> Config Class Initialized
INFO - 2016-03-23 10:10:22 --> Hooks Class Initialized
DEBUG - 2016-03-23 10:10:22 --> UTF-8 Support Enabled
INFO - 2016-03-23 10:10:22 --> Utf8 Class Initialized
INFO - 2016-03-23 10:10:22 --> URI Class Initialized
INFO - 2016-03-23 10:10:22 --> Router Class Initialized
INFO - 2016-03-23 10:10:22 --> Output Class Initialized
INFO - 2016-03-23 10:10:22 --> Security Class Initialized
DEBUG - 2016-03-23 10:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-23 10:10:22 --> Input Class Initialized
INFO - 2016-03-23 10:10:22 --> Language Class Initialized
INFO - 2016-03-23 10:10:22 --> Loader Class Initialized
INFO - 2016-03-23 10:10:22 --> Helper loaded: url_helper
INFO - 2016-03-23 10:10:22 --> Helper loaded: file_helper
INFO - 2016-03-23 10:10:22 --> Helper loaded: date_helper
INFO - 2016-03-23 10:10:22 --> Helper loaded: form_helper
INFO - 2016-03-23 10:10:22 --> Database Driver Class Initialized
INFO - 2016-03-23 10:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-23 10:10:23 --> Controller Class Initialized
INFO - 2016-03-23 10:10:23 --> Model Class Initialized
INFO - 2016-03-23 10:10:23 --> Model Class Initialized
INFO - 2016-03-23 10:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-23 10:10:23 --> Pagination Class Initialized
INFO - 2016-03-23 10:10:23 --> Helper loaded: text_helper
INFO - 2016-03-23 10:10:23 --> Helper loaded: cookie_helper
INFO - 2016-03-23 13:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-23 13:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-23 13:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-23 13:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-23 13:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-23 13:10:23 --> Final output sent to browser
DEBUG - 2016-03-23 13:10:23 --> Total execution time: 1.2923
