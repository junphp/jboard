<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-02 05:24:21 --> Config Class Initialized
INFO - 2016-02-02 05:24:21 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:24:21 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:24:21 --> Utf8 Class Initialized
INFO - 2016-02-02 05:24:21 --> URI Class Initialized
INFO - 2016-02-02 05:24:21 --> Router Class Initialized
INFO - 2016-02-02 05:24:21 --> Output Class Initialized
INFO - 2016-02-02 05:24:21 --> Security Class Initialized
DEBUG - 2016-02-02 05:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:24:21 --> Input Class Initialized
INFO - 2016-02-02 05:24:21 --> Language Class Initialized
INFO - 2016-02-02 05:24:21 --> Loader Class Initialized
INFO - 2016-02-02 05:24:21 --> Helper loaded: url_helper
INFO - 2016-02-02 05:24:21 --> Helper loaded: file_helper
INFO - 2016-02-02 05:24:21 --> Helper loaded: date_helper
INFO - 2016-02-02 05:24:21 --> Database Driver Class Initialized
INFO - 2016-02-02 05:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:24:22 --> Controller Class Initialized
INFO - 2016-02-02 05:24:22 --> Model Class Initialized
INFO - 2016-02-02 05:24:22 --> Model Class Initialized
INFO - 2016-02-02 05:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:24:22 --> Pagination Class Initialized
INFO - 2016-02-02 05:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:24:22 --> Helper loaded: text_helper
INFO - 2016-02-02 05:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:24:22 --> Final output sent to browser
DEBUG - 2016-02-02 05:24:22 --> Total execution time: 1.1618
INFO - 2016-02-02 05:24:27 --> Config Class Initialized
INFO - 2016-02-02 05:24:27 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:24:27 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:24:27 --> Utf8 Class Initialized
INFO - 2016-02-02 05:24:27 --> URI Class Initialized
DEBUG - 2016-02-02 05:24:27 --> No URI present. Default controller set.
INFO - 2016-02-02 05:24:27 --> Router Class Initialized
INFO - 2016-02-02 05:24:27 --> Output Class Initialized
INFO - 2016-02-02 05:24:27 --> Security Class Initialized
DEBUG - 2016-02-02 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:24:27 --> Input Class Initialized
INFO - 2016-02-02 05:24:27 --> Language Class Initialized
INFO - 2016-02-02 05:24:27 --> Loader Class Initialized
INFO - 2016-02-02 05:24:27 --> Helper loaded: url_helper
INFO - 2016-02-02 05:24:27 --> Helper loaded: file_helper
INFO - 2016-02-02 05:24:27 --> Helper loaded: date_helper
INFO - 2016-02-02 05:24:27 --> Database Driver Class Initialized
INFO - 2016-02-02 05:24:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:24:28 --> Controller Class Initialized
INFO - 2016-02-02 05:24:28 --> Model Class Initialized
INFO - 2016-02-02 05:24:28 --> Model Class Initialized
INFO - 2016-02-02 05:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:24:28 --> Pagination Class Initialized
INFO - 2016-02-02 05:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 05:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:24:28 --> Final output sent to browser
DEBUG - 2016-02-02 05:24:28 --> Total execution time: 1.0842
INFO - 2016-02-02 05:24:34 --> Config Class Initialized
INFO - 2016-02-02 05:24:34 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:24:34 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:24:34 --> Utf8 Class Initialized
INFO - 2016-02-02 05:24:34 --> URI Class Initialized
INFO - 2016-02-02 05:24:34 --> Router Class Initialized
INFO - 2016-02-02 05:24:34 --> Output Class Initialized
INFO - 2016-02-02 05:24:34 --> Security Class Initialized
DEBUG - 2016-02-02 05:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:24:34 --> Input Class Initialized
INFO - 2016-02-02 05:24:34 --> Language Class Initialized
INFO - 2016-02-02 05:24:34 --> Loader Class Initialized
INFO - 2016-02-02 05:24:34 --> Helper loaded: url_helper
INFO - 2016-02-02 05:24:34 --> Helper loaded: file_helper
INFO - 2016-02-02 05:24:34 --> Helper loaded: date_helper
INFO - 2016-02-02 05:24:34 --> Database Driver Class Initialized
INFO - 2016-02-02 05:24:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:24:35 --> Controller Class Initialized
INFO - 2016-02-02 05:24:35 --> Model Class Initialized
INFO - 2016-02-02 05:24:35 --> Model Class Initialized
INFO - 2016-02-02 05:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:24:35 --> Pagination Class Initialized
INFO - 2016-02-02 05:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:24:35 --> Helper loaded: text_helper
INFO - 2016-02-02 05:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:24:35 --> Final output sent to browser
DEBUG - 2016-02-02 05:24:35 --> Total execution time: 1.2726
INFO - 2016-02-02 05:25:36 --> Config Class Initialized
INFO - 2016-02-02 05:25:36 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:25:36 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:25:36 --> Utf8 Class Initialized
INFO - 2016-02-02 05:25:36 --> URI Class Initialized
INFO - 2016-02-02 05:25:36 --> Router Class Initialized
INFO - 2016-02-02 05:25:36 --> Output Class Initialized
INFO - 2016-02-02 05:25:36 --> Security Class Initialized
DEBUG - 2016-02-02 05:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:25:36 --> Input Class Initialized
INFO - 2016-02-02 05:25:36 --> Language Class Initialized
INFO - 2016-02-02 05:25:36 --> Loader Class Initialized
INFO - 2016-02-02 05:25:36 --> Helper loaded: url_helper
INFO - 2016-02-02 05:25:36 --> Helper loaded: file_helper
INFO - 2016-02-02 05:25:36 --> Helper loaded: date_helper
INFO - 2016-02-02 05:25:36 --> Database Driver Class Initialized
INFO - 2016-02-02 05:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:25:37 --> Controller Class Initialized
INFO - 2016-02-02 05:25:37 --> Model Class Initialized
INFO - 2016-02-02 05:25:37 --> Model Class Initialized
INFO - 2016-02-02 05:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:25:37 --> Pagination Class Initialized
INFO - 2016-02-02 05:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:25:37 --> Helper loaded: text_helper
INFO - 2016-02-02 05:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:25:37 --> Final output sent to browser
DEBUG - 2016-02-02 05:25:37 --> Total execution time: 1.1885
INFO - 2016-02-02 05:26:24 --> Config Class Initialized
INFO - 2016-02-02 05:26:24 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:26:24 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:26:24 --> Utf8 Class Initialized
INFO - 2016-02-02 05:26:24 --> URI Class Initialized
INFO - 2016-02-02 05:26:24 --> Router Class Initialized
INFO - 2016-02-02 05:26:24 --> Output Class Initialized
INFO - 2016-02-02 05:26:24 --> Security Class Initialized
DEBUG - 2016-02-02 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:26:24 --> Input Class Initialized
INFO - 2016-02-02 05:26:24 --> Language Class Initialized
INFO - 2016-02-02 05:26:24 --> Loader Class Initialized
INFO - 2016-02-02 05:26:24 --> Helper loaded: url_helper
INFO - 2016-02-02 05:26:24 --> Helper loaded: file_helper
INFO - 2016-02-02 05:26:24 --> Helper loaded: date_helper
INFO - 2016-02-02 05:26:24 --> Database Driver Class Initialized
INFO - 2016-02-02 05:26:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:26:25 --> Controller Class Initialized
INFO - 2016-02-02 05:26:25 --> Model Class Initialized
INFO - 2016-02-02 05:26:25 --> Model Class Initialized
INFO - 2016-02-02 05:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:26:25 --> Pagination Class Initialized
INFO - 2016-02-02 05:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:26:25 --> Helper loaded: text_helper
INFO - 2016-02-02 05:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:26:25 --> Final output sent to browser
DEBUG - 2016-02-02 05:26:25 --> Total execution time: 1.1679
INFO - 2016-02-02 05:27:08 --> Config Class Initialized
INFO - 2016-02-02 05:27:08 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:27:08 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:27:08 --> Utf8 Class Initialized
INFO - 2016-02-02 05:27:08 --> URI Class Initialized
INFO - 2016-02-02 05:27:08 --> Router Class Initialized
INFO - 2016-02-02 05:27:08 --> Output Class Initialized
INFO - 2016-02-02 05:27:08 --> Security Class Initialized
DEBUG - 2016-02-02 05:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:27:08 --> Input Class Initialized
INFO - 2016-02-02 05:27:08 --> Language Class Initialized
INFO - 2016-02-02 05:27:08 --> Loader Class Initialized
INFO - 2016-02-02 05:27:08 --> Helper loaded: url_helper
INFO - 2016-02-02 05:27:08 --> Helper loaded: file_helper
INFO - 2016-02-02 05:27:08 --> Helper loaded: date_helper
INFO - 2016-02-02 05:27:08 --> Database Driver Class Initialized
INFO - 2016-02-02 05:27:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:27:09 --> Controller Class Initialized
INFO - 2016-02-02 05:27:09 --> Model Class Initialized
INFO - 2016-02-02 05:27:09 --> Model Class Initialized
INFO - 2016-02-02 05:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:27:09 --> Pagination Class Initialized
INFO - 2016-02-02 05:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:27:09 --> Helper loaded: text_helper
INFO - 2016-02-02 05:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:27:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:27:09 --> Final output sent to browser
DEBUG - 2016-02-02 05:27:09 --> Total execution time: 1.1592
INFO - 2016-02-02 05:28:32 --> Config Class Initialized
INFO - 2016-02-02 05:28:32 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:28:32 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:28:32 --> Utf8 Class Initialized
INFO - 2016-02-02 05:28:32 --> URI Class Initialized
INFO - 2016-02-02 05:28:32 --> Router Class Initialized
INFO - 2016-02-02 05:28:32 --> Output Class Initialized
INFO - 2016-02-02 05:28:32 --> Security Class Initialized
DEBUG - 2016-02-02 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:28:32 --> Input Class Initialized
INFO - 2016-02-02 05:28:32 --> Language Class Initialized
INFO - 2016-02-02 05:28:32 --> Loader Class Initialized
INFO - 2016-02-02 05:28:32 --> Helper loaded: url_helper
INFO - 2016-02-02 05:28:32 --> Helper loaded: file_helper
INFO - 2016-02-02 05:28:32 --> Helper loaded: date_helper
INFO - 2016-02-02 05:28:32 --> Database Driver Class Initialized
INFO - 2016-02-02 05:28:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:28:33 --> Controller Class Initialized
INFO - 2016-02-02 05:28:33 --> Model Class Initialized
INFO - 2016-02-02 05:28:33 --> Model Class Initialized
INFO - 2016-02-02 05:28:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:28:33 --> Pagination Class Initialized
INFO - 2016-02-02 05:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:28:33 --> Helper loaded: text_helper
INFO - 2016-02-02 05:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:28:33 --> Final output sent to browser
DEBUG - 2016-02-02 05:28:33 --> Total execution time: 1.1944
INFO - 2016-02-02 05:29:27 --> Config Class Initialized
INFO - 2016-02-02 05:29:27 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:29:27 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:29:27 --> Utf8 Class Initialized
INFO - 2016-02-02 05:29:27 --> URI Class Initialized
INFO - 2016-02-02 05:29:27 --> Router Class Initialized
INFO - 2016-02-02 05:29:27 --> Output Class Initialized
INFO - 2016-02-02 05:29:27 --> Security Class Initialized
DEBUG - 2016-02-02 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:29:27 --> Input Class Initialized
INFO - 2016-02-02 05:29:27 --> Language Class Initialized
INFO - 2016-02-02 05:29:27 --> Loader Class Initialized
INFO - 2016-02-02 05:29:27 --> Helper loaded: url_helper
INFO - 2016-02-02 05:29:27 --> Helper loaded: file_helper
INFO - 2016-02-02 05:29:27 --> Helper loaded: date_helper
INFO - 2016-02-02 05:29:27 --> Database Driver Class Initialized
INFO - 2016-02-02 05:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:29:28 --> Controller Class Initialized
INFO - 2016-02-02 05:29:28 --> Model Class Initialized
INFO - 2016-02-02 05:29:28 --> Model Class Initialized
INFO - 2016-02-02 05:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:29:28 --> Pagination Class Initialized
INFO - 2016-02-02 05:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:29:28 --> Helper loaded: text_helper
INFO - 2016-02-02 05:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:29:28 --> Final output sent to browser
DEBUG - 2016-02-02 05:29:28 --> Total execution time: 1.1522
INFO - 2016-02-02 05:30:02 --> Config Class Initialized
INFO - 2016-02-02 05:30:02 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:30:02 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:30:02 --> Utf8 Class Initialized
INFO - 2016-02-02 05:30:02 --> URI Class Initialized
INFO - 2016-02-02 05:30:02 --> Router Class Initialized
INFO - 2016-02-02 05:30:02 --> Output Class Initialized
INFO - 2016-02-02 05:30:02 --> Security Class Initialized
DEBUG - 2016-02-02 05:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:30:02 --> Input Class Initialized
INFO - 2016-02-02 05:30:02 --> Language Class Initialized
INFO - 2016-02-02 05:30:02 --> Loader Class Initialized
INFO - 2016-02-02 05:30:02 --> Helper loaded: url_helper
INFO - 2016-02-02 05:30:02 --> Helper loaded: file_helper
INFO - 2016-02-02 05:30:02 --> Helper loaded: date_helper
INFO - 2016-02-02 05:30:02 --> Database Driver Class Initialized
INFO - 2016-02-02 05:30:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:30:03 --> Controller Class Initialized
INFO - 2016-02-02 05:30:03 --> Model Class Initialized
INFO - 2016-02-02 05:30:03 --> Model Class Initialized
INFO - 2016-02-02 05:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:30:03 --> Pagination Class Initialized
INFO - 2016-02-02 05:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:30:03 --> Helper loaded: text_helper
INFO - 2016-02-02 05:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:30:03 --> Final output sent to browser
DEBUG - 2016-02-02 05:30:03 --> Total execution time: 1.1978
INFO - 2016-02-02 05:30:20 --> Config Class Initialized
INFO - 2016-02-02 05:30:20 --> Hooks Class Initialized
DEBUG - 2016-02-02 05:30:20 --> UTF-8 Support Enabled
INFO - 2016-02-02 05:30:20 --> Utf8 Class Initialized
INFO - 2016-02-02 05:30:20 --> URI Class Initialized
INFO - 2016-02-02 05:30:20 --> Router Class Initialized
INFO - 2016-02-02 05:30:20 --> Output Class Initialized
INFO - 2016-02-02 05:30:20 --> Security Class Initialized
DEBUG - 2016-02-02 05:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 05:30:20 --> Input Class Initialized
INFO - 2016-02-02 05:30:20 --> Language Class Initialized
INFO - 2016-02-02 05:30:20 --> Loader Class Initialized
INFO - 2016-02-02 05:30:20 --> Helper loaded: url_helper
INFO - 2016-02-02 05:30:20 --> Helper loaded: file_helper
INFO - 2016-02-02 05:30:20 --> Helper loaded: date_helper
INFO - 2016-02-02 05:30:20 --> Database Driver Class Initialized
INFO - 2016-02-02 05:30:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 05:30:21 --> Controller Class Initialized
INFO - 2016-02-02 05:30:21 --> Model Class Initialized
INFO - 2016-02-02 05:30:21 --> Model Class Initialized
INFO - 2016-02-02 05:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 05:30:21 --> Pagination Class Initialized
INFO - 2016-02-02 05:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 05:30:21 --> Helper loaded: text_helper
INFO - 2016-02-02 05:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 05:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 05:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 05:30:21 --> Final output sent to browser
DEBUG - 2016-02-02 05:30:21 --> Total execution time: 1.3317
INFO - 2016-02-02 08:42:21 --> Config Class Initialized
INFO - 2016-02-02 08:42:21 --> Hooks Class Initialized
DEBUG - 2016-02-02 08:42:21 --> UTF-8 Support Enabled
INFO - 2016-02-02 08:42:21 --> Utf8 Class Initialized
INFO - 2016-02-02 08:42:21 --> URI Class Initialized
DEBUG - 2016-02-02 08:42:21 --> No URI present. Default controller set.
INFO - 2016-02-02 08:42:21 --> Router Class Initialized
INFO - 2016-02-02 08:42:21 --> Output Class Initialized
INFO - 2016-02-02 08:42:21 --> Security Class Initialized
DEBUG - 2016-02-02 08:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 08:42:21 --> Input Class Initialized
INFO - 2016-02-02 08:42:21 --> Language Class Initialized
INFO - 2016-02-02 08:42:21 --> Loader Class Initialized
INFO - 2016-02-02 08:42:21 --> Helper loaded: url_helper
INFO - 2016-02-02 08:42:21 --> Helper loaded: file_helper
INFO - 2016-02-02 08:42:21 --> Helper loaded: date_helper
INFO - 2016-02-02 08:42:21 --> Database Driver Class Initialized
INFO - 2016-02-02 08:42:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 08:42:22 --> Controller Class Initialized
INFO - 2016-02-02 08:42:22 --> Model Class Initialized
INFO - 2016-02-02 08:42:22 --> Model Class Initialized
INFO - 2016-02-02 08:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 08:42:22 --> Pagination Class Initialized
INFO - 2016-02-02 08:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 08:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 08:42:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 08:42:23 --> Final output sent to browser
DEBUG - 2016-02-02 08:42:23 --> Total execution time: 1.1848
INFO - 2016-02-02 09:14:25 --> Config Class Initialized
INFO - 2016-02-02 09:14:25 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:14:25 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:14:25 --> Utf8 Class Initialized
INFO - 2016-02-02 09:14:25 --> URI Class Initialized
INFO - 2016-02-02 09:14:25 --> Router Class Initialized
INFO - 2016-02-02 09:14:25 --> Output Class Initialized
INFO - 2016-02-02 09:14:25 --> Security Class Initialized
DEBUG - 2016-02-02 09:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:14:25 --> Input Class Initialized
INFO - 2016-02-02 09:14:25 --> Language Class Initialized
INFO - 2016-02-02 09:14:25 --> Loader Class Initialized
INFO - 2016-02-02 09:14:25 --> Helper loaded: url_helper
INFO - 2016-02-02 09:14:25 --> Helper loaded: file_helper
INFO - 2016-02-02 09:14:25 --> Helper loaded: date_helper
INFO - 2016-02-02 09:14:25 --> Database Driver Class Initialized
INFO - 2016-02-02 09:14:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:14:26 --> Controller Class Initialized
INFO - 2016-02-02 09:14:26 --> Model Class Initialized
INFO - 2016-02-02 09:14:26 --> Model Class Initialized
INFO - 2016-02-02 09:14:26 --> Helper loaded: form_helper
INFO - 2016-02-02 09:14:26 --> Form Validation Class Initialized
INFO - 2016-02-02 09:14:26 --> Helper loaded: text_helper
INFO - 2016-02-02 09:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:14:26 --> Final output sent to browser
DEBUG - 2016-02-02 09:14:26 --> Total execution time: 1.2202
INFO - 2016-02-02 09:14:40 --> Config Class Initialized
INFO - 2016-02-02 09:14:40 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:14:40 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:14:40 --> Utf8 Class Initialized
INFO - 2016-02-02 09:14:40 --> URI Class Initialized
INFO - 2016-02-02 09:14:40 --> Router Class Initialized
INFO - 2016-02-02 09:14:40 --> Output Class Initialized
INFO - 2016-02-02 09:14:40 --> Security Class Initialized
DEBUG - 2016-02-02 09:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:14:40 --> Input Class Initialized
INFO - 2016-02-02 09:14:40 --> Language Class Initialized
INFO - 2016-02-02 09:14:40 --> Loader Class Initialized
INFO - 2016-02-02 09:14:40 --> Helper loaded: url_helper
INFO - 2016-02-02 09:14:40 --> Helper loaded: file_helper
INFO - 2016-02-02 09:14:40 --> Helper loaded: date_helper
INFO - 2016-02-02 09:14:40 --> Database Driver Class Initialized
INFO - 2016-02-02 09:14:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:14:41 --> Controller Class Initialized
INFO - 2016-02-02 09:14:41 --> Model Class Initialized
INFO - 2016-02-02 09:14:41 --> Model Class Initialized
INFO - 2016-02-02 09:14:41 --> Helper loaded: form_helper
INFO - 2016-02-02 09:14:41 --> Form Validation Class Initialized
INFO - 2016-02-02 09:14:41 --> Helper loaded: text_helper
INFO - 2016-02-02 09:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-02 09:14:41 --> Model Class Initialized
ERROR - 2016-02-02 09:14:41 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-02 09:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-02 09:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 09:14:41 --> Final output sent to browser
DEBUG - 2016-02-02 09:14:41 --> Total execution time: 1.2039
INFO - 2016-02-02 09:15:36 --> Config Class Initialized
INFO - 2016-02-02 09:15:36 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:15:36 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:15:36 --> Utf8 Class Initialized
INFO - 2016-02-02 09:15:36 --> URI Class Initialized
DEBUG - 2016-02-02 09:15:36 --> No URI present. Default controller set.
INFO - 2016-02-02 09:15:36 --> Router Class Initialized
INFO - 2016-02-02 09:15:36 --> Output Class Initialized
INFO - 2016-02-02 09:15:36 --> Security Class Initialized
DEBUG - 2016-02-02 09:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:15:36 --> Input Class Initialized
INFO - 2016-02-02 09:15:36 --> Language Class Initialized
INFO - 2016-02-02 09:15:36 --> Loader Class Initialized
INFO - 2016-02-02 09:15:36 --> Helper loaded: url_helper
INFO - 2016-02-02 09:15:36 --> Helper loaded: file_helper
INFO - 2016-02-02 09:15:36 --> Helper loaded: date_helper
INFO - 2016-02-02 09:15:36 --> Database Driver Class Initialized
INFO - 2016-02-02 09:15:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:15:37 --> Controller Class Initialized
INFO - 2016-02-02 09:15:37 --> Model Class Initialized
INFO - 2016-02-02 09:15:37 --> Model Class Initialized
INFO - 2016-02-02 09:15:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:15:37 --> Pagination Class Initialized
INFO - 2016-02-02 09:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:15:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:15:37 --> Final output sent to browser
DEBUG - 2016-02-02 09:15:37 --> Total execution time: 1.0871
INFO - 2016-02-02 09:15:38 --> Config Class Initialized
INFO - 2016-02-02 09:15:38 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:15:38 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:15:38 --> Utf8 Class Initialized
INFO - 2016-02-02 09:15:38 --> URI Class Initialized
INFO - 2016-02-02 09:15:38 --> Router Class Initialized
INFO - 2016-02-02 09:15:38 --> Output Class Initialized
INFO - 2016-02-02 09:15:38 --> Security Class Initialized
DEBUG - 2016-02-02 09:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:15:38 --> Input Class Initialized
INFO - 2016-02-02 09:15:38 --> Language Class Initialized
INFO - 2016-02-02 09:15:38 --> Loader Class Initialized
INFO - 2016-02-02 09:15:38 --> Helper loaded: url_helper
INFO - 2016-02-02 09:15:38 --> Helper loaded: file_helper
INFO - 2016-02-02 09:15:38 --> Helper loaded: date_helper
INFO - 2016-02-02 09:15:38 --> Database Driver Class Initialized
INFO - 2016-02-02 09:15:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:15:39 --> Controller Class Initialized
INFO - 2016-02-02 09:15:39 --> Model Class Initialized
INFO - 2016-02-02 09:15:39 --> Model Class Initialized
INFO - 2016-02-02 09:15:39 --> Helper loaded: form_helper
INFO - 2016-02-02 09:15:39 --> Form Validation Class Initialized
INFO - 2016-02-02 09:15:39 --> Helper loaded: text_helper
INFO - 2016-02-02 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:15:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:15:39 --> Final output sent to browser
DEBUG - 2016-02-02 09:15:39 --> Total execution time: 1.1123
INFO - 2016-02-02 09:16:16 --> Config Class Initialized
INFO - 2016-02-02 09:16:16 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:16:16 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:16:16 --> Utf8 Class Initialized
INFO - 2016-02-02 09:16:16 --> URI Class Initialized
INFO - 2016-02-02 09:16:16 --> Router Class Initialized
INFO - 2016-02-02 09:16:16 --> Output Class Initialized
INFO - 2016-02-02 09:16:16 --> Security Class Initialized
DEBUG - 2016-02-02 09:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:16:16 --> Input Class Initialized
INFO - 2016-02-02 09:16:16 --> Language Class Initialized
INFO - 2016-02-02 09:16:16 --> Loader Class Initialized
INFO - 2016-02-02 09:16:16 --> Helper loaded: url_helper
INFO - 2016-02-02 09:16:16 --> Helper loaded: file_helper
INFO - 2016-02-02 09:16:16 --> Helper loaded: date_helper
INFO - 2016-02-02 09:16:16 --> Database Driver Class Initialized
INFO - 2016-02-02 09:16:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:16:17 --> Controller Class Initialized
INFO - 2016-02-02 09:16:17 --> Model Class Initialized
INFO - 2016-02-02 09:16:17 --> Model Class Initialized
INFO - 2016-02-02 09:16:17 --> Helper loaded: form_helper
INFO - 2016-02-02 09:16:17 --> Form Validation Class Initialized
INFO - 2016-02-02 09:16:17 --> Helper loaded: text_helper
INFO - 2016-02-02 09:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:16:17 --> Final output sent to browser
DEBUG - 2016-02-02 09:16:17 --> Total execution time: 1.0817
INFO - 2016-02-02 09:16:52 --> Config Class Initialized
INFO - 2016-02-02 09:16:52 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:16:52 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:16:52 --> Utf8 Class Initialized
INFO - 2016-02-02 09:16:52 --> URI Class Initialized
INFO - 2016-02-02 09:16:52 --> Router Class Initialized
INFO - 2016-02-02 09:16:52 --> Output Class Initialized
INFO - 2016-02-02 09:16:52 --> Security Class Initialized
DEBUG - 2016-02-02 09:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:16:52 --> Input Class Initialized
INFO - 2016-02-02 09:16:52 --> Language Class Initialized
INFO - 2016-02-02 09:16:52 --> Loader Class Initialized
INFO - 2016-02-02 09:16:52 --> Helper loaded: url_helper
INFO - 2016-02-02 09:16:52 --> Helper loaded: file_helper
INFO - 2016-02-02 09:16:52 --> Helper loaded: date_helper
INFO - 2016-02-02 09:16:52 --> Database Driver Class Initialized
INFO - 2016-02-02 09:16:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:16:53 --> Controller Class Initialized
INFO - 2016-02-02 09:16:53 --> Model Class Initialized
INFO - 2016-02-02 09:16:53 --> Model Class Initialized
INFO - 2016-02-02 09:16:53 --> Helper loaded: form_helper
INFO - 2016-02-02 09:16:53 --> Form Validation Class Initialized
INFO - 2016-02-02 09:16:53 --> Helper loaded: text_helper
INFO - 2016-02-02 09:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:16:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:16:53 --> Final output sent to browser
DEBUG - 2016-02-02 09:16:53 --> Total execution time: 1.1290
INFO - 2016-02-02 09:17:44 --> Config Class Initialized
INFO - 2016-02-02 09:17:44 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:17:44 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:17:44 --> Utf8 Class Initialized
INFO - 2016-02-02 09:17:44 --> URI Class Initialized
DEBUG - 2016-02-02 09:17:44 --> No URI present. Default controller set.
INFO - 2016-02-02 09:17:44 --> Router Class Initialized
INFO - 2016-02-02 09:17:44 --> Output Class Initialized
INFO - 2016-02-02 09:17:44 --> Security Class Initialized
DEBUG - 2016-02-02 09:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:17:44 --> Input Class Initialized
INFO - 2016-02-02 09:17:44 --> Language Class Initialized
INFO - 2016-02-02 09:17:44 --> Loader Class Initialized
INFO - 2016-02-02 09:17:44 --> Helper loaded: url_helper
INFO - 2016-02-02 09:17:44 --> Helper loaded: file_helper
INFO - 2016-02-02 09:17:44 --> Helper loaded: date_helper
INFO - 2016-02-02 09:17:44 --> Database Driver Class Initialized
INFO - 2016-02-02 09:17:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:17:45 --> Controller Class Initialized
INFO - 2016-02-02 09:17:45 --> Model Class Initialized
INFO - 2016-02-02 09:17:45 --> Model Class Initialized
INFO - 2016-02-02 09:17:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:17:45 --> Pagination Class Initialized
INFO - 2016-02-02 09:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:17:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:17:45 --> Final output sent to browser
DEBUG - 2016-02-02 09:17:45 --> Total execution time: 1.0927
INFO - 2016-02-02 09:17:47 --> Config Class Initialized
INFO - 2016-02-02 09:17:47 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:17:47 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:17:47 --> Utf8 Class Initialized
INFO - 2016-02-02 09:17:47 --> URI Class Initialized
INFO - 2016-02-02 09:17:47 --> Router Class Initialized
INFO - 2016-02-02 09:17:47 --> Output Class Initialized
INFO - 2016-02-02 09:17:47 --> Security Class Initialized
DEBUG - 2016-02-02 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:17:47 --> Input Class Initialized
INFO - 2016-02-02 09:17:47 --> Language Class Initialized
INFO - 2016-02-02 09:17:47 --> Loader Class Initialized
INFO - 2016-02-02 09:17:47 --> Helper loaded: url_helper
INFO - 2016-02-02 09:17:47 --> Helper loaded: file_helper
INFO - 2016-02-02 09:17:47 --> Helper loaded: date_helper
INFO - 2016-02-02 09:17:47 --> Database Driver Class Initialized
INFO - 2016-02-02 09:17:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:17:48 --> Controller Class Initialized
INFO - 2016-02-02 09:17:48 --> Model Class Initialized
INFO - 2016-02-02 09:17:48 --> Model Class Initialized
INFO - 2016-02-02 09:17:48 --> Helper loaded: form_helper
INFO - 2016-02-02 09:17:48 --> Form Validation Class Initialized
INFO - 2016-02-02 09:17:48 --> Helper loaded: text_helper
INFO - 2016-02-02 09:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:17:48 --> Final output sent to browser
DEBUG - 2016-02-02 09:17:48 --> Total execution time: 1.1087
INFO - 2016-02-02 09:17:54 --> Config Class Initialized
INFO - 2016-02-02 09:17:54 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:17:54 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:17:54 --> Utf8 Class Initialized
INFO - 2016-02-02 09:17:54 --> URI Class Initialized
INFO - 2016-02-02 09:17:54 --> Router Class Initialized
INFO - 2016-02-02 09:17:54 --> Output Class Initialized
INFO - 2016-02-02 09:17:54 --> Security Class Initialized
DEBUG - 2016-02-02 09:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:17:54 --> Input Class Initialized
INFO - 2016-02-02 09:17:54 --> Language Class Initialized
INFO - 2016-02-02 09:17:54 --> Loader Class Initialized
INFO - 2016-02-02 09:17:54 --> Helper loaded: url_helper
INFO - 2016-02-02 09:17:54 --> Helper loaded: file_helper
INFO - 2016-02-02 09:17:54 --> Helper loaded: date_helper
INFO - 2016-02-02 09:17:54 --> Database Driver Class Initialized
INFO - 2016-02-02 09:17:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:17:55 --> Controller Class Initialized
INFO - 2016-02-02 09:17:55 --> Model Class Initialized
INFO - 2016-02-02 09:17:55 --> Model Class Initialized
INFO - 2016-02-02 09:17:55 --> Helper loaded: form_helper
INFO - 2016-02-02 09:17:55 --> Form Validation Class Initialized
INFO - 2016-02-02 09:17:55 --> Helper loaded: text_helper
INFO - 2016-02-02 09:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:17:55 --> Final output sent to browser
DEBUG - 2016-02-02 09:17:55 --> Total execution time: 1.1423
INFO - 2016-02-02 09:21:00 --> Config Class Initialized
INFO - 2016-02-02 09:21:00 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:21:00 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:21:00 --> Utf8 Class Initialized
INFO - 2016-02-02 09:21:00 --> URI Class Initialized
INFO - 2016-02-02 09:21:00 --> Router Class Initialized
INFO - 2016-02-02 09:21:00 --> Output Class Initialized
INFO - 2016-02-02 09:21:00 --> Security Class Initialized
DEBUG - 2016-02-02 09:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:21:00 --> Input Class Initialized
INFO - 2016-02-02 09:21:00 --> Language Class Initialized
INFO - 2016-02-02 09:21:00 --> Loader Class Initialized
INFO - 2016-02-02 09:21:00 --> Helper loaded: url_helper
INFO - 2016-02-02 09:21:00 --> Helper loaded: file_helper
INFO - 2016-02-02 09:21:00 --> Helper loaded: date_helper
INFO - 2016-02-02 09:21:00 --> Database Driver Class Initialized
INFO - 2016-02-02 09:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:21:01 --> Controller Class Initialized
INFO - 2016-02-02 09:21:01 --> Model Class Initialized
INFO - 2016-02-02 09:21:01 --> Model Class Initialized
INFO - 2016-02-02 09:21:01 --> Helper loaded: form_helper
INFO - 2016-02-02 09:21:01 --> Form Validation Class Initialized
INFO - 2016-02-02 09:21:01 --> Helper loaded: text_helper
INFO - 2016-02-02 09:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:21:01 --> Final output sent to browser
DEBUG - 2016-02-02 09:21:01 --> Total execution time: 1.1413
INFO - 2016-02-02 09:22:02 --> Config Class Initialized
INFO - 2016-02-02 09:22:02 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:22:02 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:22:02 --> Utf8 Class Initialized
INFO - 2016-02-02 09:22:02 --> URI Class Initialized
INFO - 2016-02-02 09:22:02 --> Router Class Initialized
INFO - 2016-02-02 09:22:02 --> Output Class Initialized
INFO - 2016-02-02 09:22:02 --> Security Class Initialized
DEBUG - 2016-02-02 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:22:02 --> Input Class Initialized
INFO - 2016-02-02 09:22:02 --> Language Class Initialized
INFO - 2016-02-02 09:22:02 --> Loader Class Initialized
INFO - 2016-02-02 09:22:02 --> Helper loaded: url_helper
INFO - 2016-02-02 09:22:02 --> Helper loaded: file_helper
INFO - 2016-02-02 09:22:02 --> Helper loaded: date_helper
INFO - 2016-02-02 09:22:02 --> Database Driver Class Initialized
INFO - 2016-02-02 09:22:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:22:03 --> Controller Class Initialized
INFO - 2016-02-02 09:22:04 --> Model Class Initialized
INFO - 2016-02-02 09:22:04 --> Model Class Initialized
INFO - 2016-02-02 09:22:04 --> Helper loaded: form_helper
INFO - 2016-02-02 09:22:04 --> Form Validation Class Initialized
INFO - 2016-02-02 09:22:04 --> Helper loaded: text_helper
INFO - 2016-02-02 09:22:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:22:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:22:04 --> Final output sent to browser
DEBUG - 2016-02-02 09:22:04 --> Total execution time: 1.1172
INFO - 2016-02-02 09:24:51 --> Config Class Initialized
INFO - 2016-02-02 09:24:51 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:24:51 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:24:51 --> Utf8 Class Initialized
INFO - 2016-02-02 09:24:51 --> URI Class Initialized
INFO - 2016-02-02 09:24:51 --> Router Class Initialized
INFO - 2016-02-02 09:24:51 --> Output Class Initialized
INFO - 2016-02-02 09:24:51 --> Security Class Initialized
DEBUG - 2016-02-02 09:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:24:51 --> Input Class Initialized
INFO - 2016-02-02 09:24:51 --> Language Class Initialized
INFO - 2016-02-02 09:24:51 --> Loader Class Initialized
INFO - 2016-02-02 09:24:51 --> Helper loaded: url_helper
INFO - 2016-02-02 09:24:51 --> Helper loaded: file_helper
INFO - 2016-02-02 09:24:51 --> Helper loaded: date_helper
INFO - 2016-02-02 09:24:51 --> Database Driver Class Initialized
INFO - 2016-02-02 09:24:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:24:52 --> Controller Class Initialized
INFO - 2016-02-02 09:24:52 --> Model Class Initialized
INFO - 2016-02-02 09:24:52 --> Model Class Initialized
INFO - 2016-02-02 09:24:52 --> Helper loaded: form_helper
INFO - 2016-02-02 09:24:52 --> Form Validation Class Initialized
INFO - 2016-02-02 09:24:52 --> Helper loaded: text_helper
INFO - 2016-02-02 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:24:52 --> Final output sent to browser
DEBUG - 2016-02-02 09:24:52 --> Total execution time: 1.1203
INFO - 2016-02-02 09:26:07 --> Config Class Initialized
INFO - 2016-02-02 09:26:07 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:26:07 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:26:07 --> Utf8 Class Initialized
INFO - 2016-02-02 09:26:07 --> URI Class Initialized
INFO - 2016-02-02 09:26:07 --> Router Class Initialized
INFO - 2016-02-02 09:26:07 --> Output Class Initialized
INFO - 2016-02-02 09:26:07 --> Security Class Initialized
DEBUG - 2016-02-02 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:26:07 --> Input Class Initialized
INFO - 2016-02-02 09:26:07 --> Language Class Initialized
INFO - 2016-02-02 09:26:07 --> Loader Class Initialized
INFO - 2016-02-02 09:26:07 --> Helper loaded: url_helper
INFO - 2016-02-02 09:26:07 --> Helper loaded: file_helper
INFO - 2016-02-02 09:26:07 --> Helper loaded: date_helper
INFO - 2016-02-02 09:26:07 --> Database Driver Class Initialized
INFO - 2016-02-02 09:26:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:26:08 --> Controller Class Initialized
INFO - 2016-02-02 09:26:08 --> Model Class Initialized
INFO - 2016-02-02 09:26:08 --> Model Class Initialized
INFO - 2016-02-02 09:26:08 --> Helper loaded: form_helper
INFO - 2016-02-02 09:26:08 --> Form Validation Class Initialized
INFO - 2016-02-02 09:26:08 --> Helper loaded: text_helper
INFO - 2016-02-02 09:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:26:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:26:08 --> Final output sent to browser
DEBUG - 2016-02-02 09:26:08 --> Total execution time: 1.1015
INFO - 2016-02-02 09:26:20 --> Config Class Initialized
INFO - 2016-02-02 09:26:20 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:26:20 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:26:20 --> Utf8 Class Initialized
INFO - 2016-02-02 09:26:20 --> URI Class Initialized
INFO - 2016-02-02 09:26:20 --> Router Class Initialized
INFO - 2016-02-02 09:26:20 --> Output Class Initialized
INFO - 2016-02-02 09:26:20 --> Security Class Initialized
DEBUG - 2016-02-02 09:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:26:20 --> Input Class Initialized
INFO - 2016-02-02 09:26:20 --> Language Class Initialized
INFO - 2016-02-02 09:26:20 --> Loader Class Initialized
INFO - 2016-02-02 09:26:20 --> Helper loaded: url_helper
INFO - 2016-02-02 09:26:20 --> Helper loaded: file_helper
INFO - 2016-02-02 09:26:20 --> Helper loaded: date_helper
INFO - 2016-02-02 09:26:20 --> Database Driver Class Initialized
INFO - 2016-02-02 09:26:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:26:21 --> Controller Class Initialized
INFO - 2016-02-02 09:26:21 --> Model Class Initialized
INFO - 2016-02-02 09:26:21 --> Model Class Initialized
INFO - 2016-02-02 09:26:21 --> Helper loaded: form_helper
INFO - 2016-02-02 09:26:21 --> Form Validation Class Initialized
INFO - 2016-02-02 09:26:21 --> Helper loaded: text_helper
INFO - 2016-02-02 09:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:26:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:26:21 --> Final output sent to browser
DEBUG - 2016-02-02 09:26:21 --> Total execution time: 1.0991
INFO - 2016-02-02 09:27:56 --> Config Class Initialized
INFO - 2016-02-02 09:27:56 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:27:56 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:27:56 --> Utf8 Class Initialized
INFO - 2016-02-02 09:27:56 --> URI Class Initialized
INFO - 2016-02-02 09:27:56 --> Router Class Initialized
INFO - 2016-02-02 09:27:56 --> Output Class Initialized
INFO - 2016-02-02 09:27:56 --> Security Class Initialized
DEBUG - 2016-02-02 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:27:56 --> Input Class Initialized
INFO - 2016-02-02 09:27:56 --> Language Class Initialized
INFO - 2016-02-02 09:27:56 --> Loader Class Initialized
INFO - 2016-02-02 09:27:56 --> Helper loaded: url_helper
INFO - 2016-02-02 09:27:56 --> Helper loaded: file_helper
INFO - 2016-02-02 09:27:56 --> Helper loaded: date_helper
INFO - 2016-02-02 09:27:56 --> Database Driver Class Initialized
INFO - 2016-02-02 09:27:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:27:57 --> Controller Class Initialized
INFO - 2016-02-02 09:27:57 --> Model Class Initialized
INFO - 2016-02-02 09:27:57 --> Model Class Initialized
INFO - 2016-02-02 09:27:57 --> Helper loaded: form_helper
INFO - 2016-02-02 09:27:57 --> Form Validation Class Initialized
INFO - 2016-02-02 09:27:57 --> Helper loaded: text_helper
INFO - 2016-02-02 09:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:27:57 --> Final output sent to browser
DEBUG - 2016-02-02 09:27:57 --> Total execution time: 1.1025
INFO - 2016-02-02 09:28:07 --> Config Class Initialized
INFO - 2016-02-02 09:28:07 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:28:07 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:28:07 --> Utf8 Class Initialized
INFO - 2016-02-02 09:28:07 --> URI Class Initialized
INFO - 2016-02-02 09:28:07 --> Router Class Initialized
INFO - 2016-02-02 09:28:07 --> Output Class Initialized
INFO - 2016-02-02 09:28:07 --> Security Class Initialized
DEBUG - 2016-02-02 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:28:08 --> Input Class Initialized
INFO - 2016-02-02 09:28:08 --> Language Class Initialized
INFO - 2016-02-02 09:28:08 --> Loader Class Initialized
INFO - 2016-02-02 09:28:08 --> Helper loaded: url_helper
INFO - 2016-02-02 09:28:08 --> Helper loaded: file_helper
INFO - 2016-02-02 09:28:08 --> Helper loaded: date_helper
INFO - 2016-02-02 09:28:08 --> Database Driver Class Initialized
INFO - 2016-02-02 09:28:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:28:09 --> Controller Class Initialized
INFO - 2016-02-02 09:28:09 --> Model Class Initialized
INFO - 2016-02-02 09:28:09 --> Model Class Initialized
INFO - 2016-02-02 09:28:09 --> Helper loaded: form_helper
INFO - 2016-02-02 09:28:09 --> Form Validation Class Initialized
INFO - 2016-02-02 09:28:09 --> Helper loaded: text_helper
INFO - 2016-02-02 09:28:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:28:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:28:09 --> Final output sent to browser
DEBUG - 2016-02-02 09:28:09 --> Total execution time: 1.1060
INFO - 2016-02-02 09:30:07 --> Config Class Initialized
INFO - 2016-02-02 09:30:07 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:30:07 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:30:07 --> Utf8 Class Initialized
INFO - 2016-02-02 09:30:07 --> URI Class Initialized
INFO - 2016-02-02 09:30:07 --> Router Class Initialized
INFO - 2016-02-02 09:30:07 --> Output Class Initialized
INFO - 2016-02-02 09:30:07 --> Security Class Initialized
DEBUG - 2016-02-02 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:30:07 --> Input Class Initialized
INFO - 2016-02-02 09:30:07 --> Language Class Initialized
INFO - 2016-02-02 09:30:07 --> Loader Class Initialized
INFO - 2016-02-02 09:30:07 --> Helper loaded: url_helper
INFO - 2016-02-02 09:30:07 --> Helper loaded: file_helper
INFO - 2016-02-02 09:30:07 --> Helper loaded: date_helper
INFO - 2016-02-02 09:30:07 --> Database Driver Class Initialized
INFO - 2016-02-02 09:30:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:30:08 --> Controller Class Initialized
INFO - 2016-02-02 09:30:08 --> Model Class Initialized
INFO - 2016-02-02 09:30:08 --> Model Class Initialized
INFO - 2016-02-02 09:30:08 --> Helper loaded: form_helper
INFO - 2016-02-02 09:30:08 --> Form Validation Class Initialized
INFO - 2016-02-02 09:30:08 --> Helper loaded: text_helper
INFO - 2016-02-02 09:30:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:30:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:30:08 --> Final output sent to browser
DEBUG - 2016-02-02 09:30:08 --> Total execution time: 1.0907
INFO - 2016-02-02 09:35:42 --> Config Class Initialized
INFO - 2016-02-02 09:35:42 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:35:42 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:35:42 --> Utf8 Class Initialized
INFO - 2016-02-02 09:35:42 --> URI Class Initialized
DEBUG - 2016-02-02 09:35:42 --> No URI present. Default controller set.
INFO - 2016-02-02 09:35:42 --> Router Class Initialized
INFO - 2016-02-02 09:35:42 --> Output Class Initialized
INFO - 2016-02-02 09:35:42 --> Security Class Initialized
DEBUG - 2016-02-02 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:35:42 --> Input Class Initialized
INFO - 2016-02-02 09:35:42 --> Language Class Initialized
INFO - 2016-02-02 09:35:42 --> Loader Class Initialized
INFO - 2016-02-02 09:35:42 --> Helper loaded: url_helper
INFO - 2016-02-02 09:35:42 --> Helper loaded: file_helper
INFO - 2016-02-02 09:35:42 --> Helper loaded: date_helper
INFO - 2016-02-02 09:35:42 --> Database Driver Class Initialized
INFO - 2016-02-02 09:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:35:43 --> Controller Class Initialized
INFO - 2016-02-02 09:35:43 --> Model Class Initialized
INFO - 2016-02-02 09:35:43 --> Model Class Initialized
INFO - 2016-02-02 09:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:35:43 --> Pagination Class Initialized
INFO - 2016-02-02 09:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:35:43 --> Final output sent to browser
DEBUG - 2016-02-02 09:35:43 --> Total execution time: 1.0872
INFO - 2016-02-02 09:35:46 --> Config Class Initialized
INFO - 2016-02-02 09:35:46 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:35:46 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:35:46 --> Utf8 Class Initialized
INFO - 2016-02-02 09:35:46 --> URI Class Initialized
INFO - 2016-02-02 09:35:46 --> Router Class Initialized
INFO - 2016-02-02 09:35:46 --> Output Class Initialized
INFO - 2016-02-02 09:35:46 --> Security Class Initialized
DEBUG - 2016-02-02 09:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:35:46 --> Input Class Initialized
INFO - 2016-02-02 09:35:46 --> Language Class Initialized
INFO - 2016-02-02 09:35:46 --> Loader Class Initialized
INFO - 2016-02-02 09:35:46 --> Helper loaded: url_helper
INFO - 2016-02-02 09:35:46 --> Helper loaded: file_helper
INFO - 2016-02-02 09:35:46 --> Helper loaded: date_helper
INFO - 2016-02-02 09:35:46 --> Database Driver Class Initialized
INFO - 2016-02-02 09:35:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:35:47 --> Controller Class Initialized
INFO - 2016-02-02 09:35:47 --> Model Class Initialized
INFO - 2016-02-02 09:35:47 --> Model Class Initialized
INFO - 2016-02-02 09:35:47 --> Helper loaded: form_helper
INFO - 2016-02-02 09:35:47 --> Form Validation Class Initialized
INFO - 2016-02-02 09:35:47 --> Helper loaded: text_helper
INFO - 2016-02-02 09:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-02 09:35:47 --> Model Class Initialized
ERROR - 2016-02-02 09:35:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-02 09:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-02 09:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 09:35:47 --> Final output sent to browser
DEBUG - 2016-02-02 09:35:47 --> Total execution time: 1.1085
INFO - 2016-02-02 09:35:50 --> Config Class Initialized
INFO - 2016-02-02 09:35:50 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:35:50 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:35:50 --> Utf8 Class Initialized
INFO - 2016-02-02 09:35:50 --> URI Class Initialized
INFO - 2016-02-02 09:35:50 --> Router Class Initialized
INFO - 2016-02-02 09:35:50 --> Output Class Initialized
INFO - 2016-02-02 09:35:50 --> Security Class Initialized
DEBUG - 2016-02-02 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:35:50 --> Input Class Initialized
INFO - 2016-02-02 09:35:50 --> Language Class Initialized
INFO - 2016-02-02 09:35:50 --> Loader Class Initialized
INFO - 2016-02-02 09:35:50 --> Helper loaded: url_helper
INFO - 2016-02-02 09:35:50 --> Helper loaded: file_helper
INFO - 2016-02-02 09:35:50 --> Helper loaded: date_helper
INFO - 2016-02-02 09:35:50 --> Database Driver Class Initialized
INFO - 2016-02-02 09:35:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:35:51 --> Controller Class Initialized
INFO - 2016-02-02 09:35:51 --> Model Class Initialized
INFO - 2016-02-02 09:35:51 --> Model Class Initialized
INFO - 2016-02-02 09:35:51 --> Helper loaded: form_helper
INFO - 2016-02-02 09:35:51 --> Form Validation Class Initialized
INFO - 2016-02-02 09:35:51 --> Helper loaded: text_helper
INFO - 2016-02-02 09:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:35:51 --> Final output sent to browser
DEBUG - 2016-02-02 09:35:51 --> Total execution time: 1.0959
INFO - 2016-02-02 09:35:54 --> Config Class Initialized
INFO - 2016-02-02 09:35:54 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:35:54 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:35:54 --> Utf8 Class Initialized
INFO - 2016-02-02 09:35:54 --> URI Class Initialized
DEBUG - 2016-02-02 09:35:54 --> No URI present. Default controller set.
INFO - 2016-02-02 09:35:54 --> Router Class Initialized
INFO - 2016-02-02 09:35:54 --> Output Class Initialized
INFO - 2016-02-02 09:35:54 --> Security Class Initialized
DEBUG - 2016-02-02 09:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:35:54 --> Input Class Initialized
INFO - 2016-02-02 09:35:54 --> Language Class Initialized
INFO - 2016-02-02 09:35:54 --> Loader Class Initialized
INFO - 2016-02-02 09:35:54 --> Helper loaded: url_helper
INFO - 2016-02-02 09:35:54 --> Helper loaded: file_helper
INFO - 2016-02-02 09:35:54 --> Helper loaded: date_helper
INFO - 2016-02-02 09:35:54 --> Database Driver Class Initialized
INFO - 2016-02-02 09:35:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:35:55 --> Controller Class Initialized
INFO - 2016-02-02 09:35:55 --> Model Class Initialized
INFO - 2016-02-02 09:35:55 --> Model Class Initialized
INFO - 2016-02-02 09:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:35:55 --> Pagination Class Initialized
INFO - 2016-02-02 09:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:35:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:35:55 --> Final output sent to browser
DEBUG - 2016-02-02 09:35:55 --> Total execution time: 1.1135
INFO - 2016-02-02 09:35:57 --> Config Class Initialized
INFO - 2016-02-02 09:35:57 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:35:57 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:35:57 --> Utf8 Class Initialized
INFO - 2016-02-02 09:35:57 --> URI Class Initialized
INFO - 2016-02-02 09:35:57 --> Router Class Initialized
INFO - 2016-02-02 09:35:57 --> Output Class Initialized
INFO - 2016-02-02 09:35:57 --> Security Class Initialized
DEBUG - 2016-02-02 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:35:57 --> Input Class Initialized
INFO - 2016-02-02 09:35:57 --> Language Class Initialized
INFO - 2016-02-02 09:35:57 --> Loader Class Initialized
INFO - 2016-02-02 09:35:57 --> Helper loaded: url_helper
INFO - 2016-02-02 09:35:57 --> Helper loaded: file_helper
INFO - 2016-02-02 09:35:57 --> Helper loaded: date_helper
INFO - 2016-02-02 09:35:57 --> Database Driver Class Initialized
INFO - 2016-02-02 09:35:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:35:58 --> Controller Class Initialized
INFO - 2016-02-02 09:35:58 --> Model Class Initialized
INFO - 2016-02-02 09:35:58 --> Model Class Initialized
INFO - 2016-02-02 09:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:35:58 --> Pagination Class Initialized
INFO - 2016-02-02 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:35:58 --> Helper loaded: text_helper
INFO - 2016-02-02 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:35:58 --> Final output sent to browser
DEBUG - 2016-02-02 09:35:58 --> Total execution time: 1.1237
INFO - 2016-02-02 09:37:02 --> Config Class Initialized
INFO - 2016-02-02 09:37:02 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:02 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:02 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:02 --> URI Class Initialized
INFO - 2016-02-02 09:37:02 --> Router Class Initialized
INFO - 2016-02-02 09:37:02 --> Output Class Initialized
INFO - 2016-02-02 09:37:02 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:02 --> Input Class Initialized
INFO - 2016-02-02 09:37:02 --> Language Class Initialized
INFO - 2016-02-02 09:37:02 --> Loader Class Initialized
INFO - 2016-02-02 09:37:02 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:02 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:02 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:02 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:03 --> Controller Class Initialized
INFO - 2016-02-02 09:37:03 --> Model Class Initialized
INFO - 2016-02-02 09:37:03 --> Model Class Initialized
INFO - 2016-02-02 09:37:03 --> Helper loaded: form_helper
INFO - 2016-02-02 09:37:03 --> Form Validation Class Initialized
INFO - 2016-02-02 09:37:03 --> Helper loaded: text_helper
INFO - 2016-02-02 09:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-02 09:37:03 --> Model Class Initialized
ERROR - 2016-02-02 09:37:03 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-02 09:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-02 09:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 09:37:03 --> Final output sent to browser
DEBUG - 2016-02-02 09:37:03 --> Total execution time: 1.0989
INFO - 2016-02-02 09:37:07 --> Config Class Initialized
INFO - 2016-02-02 09:37:07 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:07 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:07 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:07 --> URI Class Initialized
INFO - 2016-02-02 09:37:07 --> Router Class Initialized
INFO - 2016-02-02 09:37:07 --> Output Class Initialized
INFO - 2016-02-02 09:37:07 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:07 --> Input Class Initialized
INFO - 2016-02-02 09:37:07 --> Language Class Initialized
INFO - 2016-02-02 09:37:07 --> Loader Class Initialized
INFO - 2016-02-02 09:37:07 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:07 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:07 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:07 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:08 --> Controller Class Initialized
INFO - 2016-02-02 09:37:08 --> Model Class Initialized
INFO - 2016-02-02 09:37:08 --> Model Class Initialized
INFO - 2016-02-02 09:37:08 --> Helper loaded: form_helper
INFO - 2016-02-02 09:37:08 --> Form Validation Class Initialized
INFO - 2016-02-02 09:37:08 --> Helper loaded: text_helper
INFO - 2016-02-02 09:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:37:08 --> Final output sent to browser
DEBUG - 2016-02-02 09:37:08 --> Total execution time: 1.1115
INFO - 2016-02-02 09:37:39 --> Config Class Initialized
INFO - 2016-02-02 09:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:39 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:39 --> URI Class Initialized
INFO - 2016-02-02 09:37:39 --> Router Class Initialized
INFO - 2016-02-02 09:37:39 --> Output Class Initialized
INFO - 2016-02-02 09:37:39 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:39 --> Input Class Initialized
INFO - 2016-02-02 09:37:39 --> Language Class Initialized
INFO - 2016-02-02 09:37:39 --> Loader Class Initialized
INFO - 2016-02-02 09:37:39 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:39 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:39 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:39 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:40 --> Controller Class Initialized
INFO - 2016-02-02 09:37:40 --> Model Class Initialized
INFO - 2016-02-02 09:37:40 --> Model Class Initialized
INFO - 2016-02-02 09:37:40 --> Helper loaded: form_helper
INFO - 2016-02-02 09:37:40 --> Form Validation Class Initialized
INFO - 2016-02-02 09:37:40 --> Helper loaded: text_helper
INFO - 2016-02-02 09:37:41 --> Config Class Initialized
INFO - 2016-02-02 09:37:41 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:41 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:41 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:41 --> URI Class Initialized
INFO - 2016-02-02 09:37:41 --> Router Class Initialized
INFO - 2016-02-02 09:37:41 --> Output Class Initialized
INFO - 2016-02-02 09:37:41 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:41 --> Input Class Initialized
INFO - 2016-02-02 09:37:41 --> Language Class Initialized
INFO - 2016-02-02 09:37:41 --> Loader Class Initialized
INFO - 2016-02-02 09:37:41 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:41 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:41 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:41 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:42 --> Controller Class Initialized
INFO - 2016-02-02 09:37:42 --> Model Class Initialized
INFO - 2016-02-02 09:37:42 --> Model Class Initialized
INFO - 2016-02-02 09:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:37:42 --> Pagination Class Initialized
INFO - 2016-02-02 09:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:37:42 --> Final output sent to browser
DEBUG - 2016-02-02 09:37:42 --> Total execution time: 1.1111
INFO - 2016-02-02 09:37:44 --> Config Class Initialized
INFO - 2016-02-02 09:37:44 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:44 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:44 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:44 --> URI Class Initialized
DEBUG - 2016-02-02 09:37:44 --> No URI present. Default controller set.
INFO - 2016-02-02 09:37:44 --> Router Class Initialized
INFO - 2016-02-02 09:37:44 --> Output Class Initialized
INFO - 2016-02-02 09:37:44 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:44 --> Input Class Initialized
INFO - 2016-02-02 09:37:44 --> Language Class Initialized
INFO - 2016-02-02 09:37:44 --> Loader Class Initialized
INFO - 2016-02-02 09:37:44 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:44 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:44 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:44 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:45 --> Controller Class Initialized
INFO - 2016-02-02 09:37:45 --> Model Class Initialized
INFO - 2016-02-02 09:37:45 --> Model Class Initialized
INFO - 2016-02-02 09:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:37:45 --> Pagination Class Initialized
INFO - 2016-02-02 09:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:37:45 --> Final output sent to browser
DEBUG - 2016-02-02 09:37:45 --> Total execution time: 1.0852
INFO - 2016-02-02 09:37:56 --> Config Class Initialized
INFO - 2016-02-02 09:37:56 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:56 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:56 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:56 --> URI Class Initialized
INFO - 2016-02-02 09:37:56 --> Router Class Initialized
INFO - 2016-02-02 09:37:56 --> Output Class Initialized
INFO - 2016-02-02 09:37:56 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:56 --> Input Class Initialized
INFO - 2016-02-02 09:37:56 --> Language Class Initialized
INFO - 2016-02-02 09:37:56 --> Loader Class Initialized
INFO - 2016-02-02 09:37:56 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:56 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:56 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:56 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:57 --> Controller Class Initialized
INFO - 2016-02-02 09:37:57 --> Model Class Initialized
INFO - 2016-02-02 09:37:57 --> Model Class Initialized
INFO - 2016-02-02 09:37:57 --> Helper loaded: form_helper
INFO - 2016-02-02 09:37:57 --> Form Validation Class Initialized
INFO - 2016-02-02 09:37:57 --> Helper loaded: text_helper
INFO - 2016-02-02 09:37:57 --> Config Class Initialized
INFO - 2016-02-02 09:37:57 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:37:57 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:37:57 --> Utf8 Class Initialized
INFO - 2016-02-02 09:37:57 --> URI Class Initialized
INFO - 2016-02-02 09:37:57 --> Router Class Initialized
INFO - 2016-02-02 09:37:57 --> Output Class Initialized
INFO - 2016-02-02 09:37:57 --> Security Class Initialized
DEBUG - 2016-02-02 09:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:37:57 --> Input Class Initialized
INFO - 2016-02-02 09:37:57 --> Language Class Initialized
INFO - 2016-02-02 09:37:57 --> Loader Class Initialized
INFO - 2016-02-02 09:37:57 --> Helper loaded: url_helper
INFO - 2016-02-02 09:37:57 --> Helper loaded: file_helper
INFO - 2016-02-02 09:37:57 --> Helper loaded: date_helper
INFO - 2016-02-02 09:37:57 --> Database Driver Class Initialized
INFO - 2016-02-02 09:37:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:37:58 --> Controller Class Initialized
INFO - 2016-02-02 09:37:58 --> Model Class Initialized
INFO - 2016-02-02 09:37:58 --> Model Class Initialized
INFO - 2016-02-02 09:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:37:58 --> Pagination Class Initialized
INFO - 2016-02-02 09:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:37:58 --> Final output sent to browser
DEBUG - 2016-02-02 09:37:58 --> Total execution time: 1.0956
INFO - 2016-02-02 09:38:32 --> Config Class Initialized
INFO - 2016-02-02 09:38:32 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:38:32 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:38:32 --> Utf8 Class Initialized
INFO - 2016-02-02 09:38:32 --> URI Class Initialized
INFO - 2016-02-02 09:38:32 --> Router Class Initialized
INFO - 2016-02-02 09:38:32 --> Output Class Initialized
INFO - 2016-02-02 09:38:32 --> Security Class Initialized
DEBUG - 2016-02-02 09:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:38:32 --> Input Class Initialized
INFO - 2016-02-02 09:38:32 --> Language Class Initialized
INFO - 2016-02-02 09:38:32 --> Loader Class Initialized
INFO - 2016-02-02 09:38:32 --> Helper loaded: url_helper
INFO - 2016-02-02 09:38:32 --> Helper loaded: file_helper
INFO - 2016-02-02 09:38:32 --> Helper loaded: date_helper
INFO - 2016-02-02 09:38:32 --> Database Driver Class Initialized
INFO - 2016-02-02 09:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:38:33 --> Controller Class Initialized
INFO - 2016-02-02 09:38:33 --> Model Class Initialized
INFO - 2016-02-02 09:38:33 --> Model Class Initialized
INFO - 2016-02-02 09:38:33 --> Helper loaded: form_helper
INFO - 2016-02-02 09:38:33 --> Form Validation Class Initialized
INFO - 2016-02-02 09:38:33 --> Helper loaded: text_helper
INFO - 2016-02-02 09:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:38:33 --> Final output sent to browser
DEBUG - 2016-02-02 09:38:33 --> Total execution time: 1.0921
INFO - 2016-02-02 09:39:15 --> Config Class Initialized
INFO - 2016-02-02 09:39:15 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:39:15 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:39:15 --> Utf8 Class Initialized
INFO - 2016-02-02 09:39:15 --> URI Class Initialized
DEBUG - 2016-02-02 09:39:15 --> No URI present. Default controller set.
INFO - 2016-02-02 09:39:15 --> Router Class Initialized
INFO - 2016-02-02 09:39:15 --> Output Class Initialized
INFO - 2016-02-02 09:39:15 --> Security Class Initialized
DEBUG - 2016-02-02 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:39:15 --> Input Class Initialized
INFO - 2016-02-02 09:39:15 --> Language Class Initialized
INFO - 2016-02-02 09:39:15 --> Loader Class Initialized
INFO - 2016-02-02 09:39:15 --> Helper loaded: url_helper
INFO - 2016-02-02 09:39:15 --> Helper loaded: file_helper
INFO - 2016-02-02 09:39:15 --> Helper loaded: date_helper
INFO - 2016-02-02 09:39:15 --> Database Driver Class Initialized
INFO - 2016-02-02 09:39:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:39:16 --> Controller Class Initialized
INFO - 2016-02-02 09:39:16 --> Model Class Initialized
INFO - 2016-02-02 09:39:16 --> Model Class Initialized
INFO - 2016-02-02 09:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:39:16 --> Pagination Class Initialized
INFO - 2016-02-02 09:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:39:16 --> Final output sent to browser
DEBUG - 2016-02-02 09:39:16 --> Total execution time: 1.1099
INFO - 2016-02-02 09:39:30 --> Config Class Initialized
INFO - 2016-02-02 09:39:30 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:39:30 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:39:30 --> Utf8 Class Initialized
INFO - 2016-02-02 09:39:30 --> URI Class Initialized
DEBUG - 2016-02-02 09:39:30 --> No URI present. Default controller set.
INFO - 2016-02-02 09:39:30 --> Router Class Initialized
INFO - 2016-02-02 09:39:30 --> Output Class Initialized
INFO - 2016-02-02 09:39:30 --> Security Class Initialized
DEBUG - 2016-02-02 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:39:30 --> Input Class Initialized
INFO - 2016-02-02 09:39:30 --> Language Class Initialized
INFO - 2016-02-02 09:39:30 --> Loader Class Initialized
INFO - 2016-02-02 09:39:30 --> Helper loaded: url_helper
INFO - 2016-02-02 09:39:30 --> Helper loaded: file_helper
INFO - 2016-02-02 09:39:30 --> Helper loaded: date_helper
INFO - 2016-02-02 09:39:30 --> Database Driver Class Initialized
INFO - 2016-02-02 09:39:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:39:31 --> Controller Class Initialized
INFO - 2016-02-02 09:39:31 --> Model Class Initialized
INFO - 2016-02-02 09:39:31 --> Model Class Initialized
INFO - 2016-02-02 09:39:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:39:31 --> Pagination Class Initialized
INFO - 2016-02-02 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:39:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:39:31 --> Final output sent to browser
DEBUG - 2016-02-02 09:39:31 --> Total execution time: 1.1160
INFO - 2016-02-02 09:40:13 --> Config Class Initialized
INFO - 2016-02-02 09:40:13 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:40:13 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:40:13 --> Utf8 Class Initialized
INFO - 2016-02-02 09:40:13 --> URI Class Initialized
DEBUG - 2016-02-02 09:40:13 --> No URI present. Default controller set.
INFO - 2016-02-02 09:40:13 --> Router Class Initialized
INFO - 2016-02-02 09:40:13 --> Output Class Initialized
INFO - 2016-02-02 09:40:13 --> Security Class Initialized
DEBUG - 2016-02-02 09:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:40:13 --> Input Class Initialized
INFO - 2016-02-02 09:40:13 --> Language Class Initialized
INFO - 2016-02-02 09:40:13 --> Loader Class Initialized
INFO - 2016-02-02 09:40:13 --> Helper loaded: url_helper
INFO - 2016-02-02 09:40:13 --> Helper loaded: file_helper
INFO - 2016-02-02 09:40:13 --> Helper loaded: date_helper
INFO - 2016-02-02 09:40:13 --> Database Driver Class Initialized
INFO - 2016-02-02 09:40:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:40:14 --> Controller Class Initialized
INFO - 2016-02-02 09:40:14 --> Model Class Initialized
INFO - 2016-02-02 09:40:14 --> Model Class Initialized
INFO - 2016-02-02 09:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:40:14 --> Pagination Class Initialized
INFO - 2016-02-02 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:40:14 --> Final output sent to browser
DEBUG - 2016-02-02 09:40:14 --> Total execution time: 1.1198
INFO - 2016-02-02 09:40:25 --> Config Class Initialized
INFO - 2016-02-02 09:40:25 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:40:25 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:40:25 --> Utf8 Class Initialized
INFO - 2016-02-02 09:40:25 --> URI Class Initialized
DEBUG - 2016-02-02 09:40:25 --> No URI present. Default controller set.
INFO - 2016-02-02 09:40:25 --> Router Class Initialized
INFO - 2016-02-02 09:40:25 --> Output Class Initialized
INFO - 2016-02-02 09:40:25 --> Security Class Initialized
DEBUG - 2016-02-02 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:40:25 --> Input Class Initialized
INFO - 2016-02-02 09:40:25 --> Language Class Initialized
INFO - 2016-02-02 09:40:25 --> Loader Class Initialized
INFO - 2016-02-02 09:40:25 --> Helper loaded: url_helper
INFO - 2016-02-02 09:40:25 --> Helper loaded: file_helper
INFO - 2016-02-02 09:40:25 --> Helper loaded: date_helper
INFO - 2016-02-02 09:40:25 --> Database Driver Class Initialized
INFO - 2016-02-02 09:40:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:40:26 --> Controller Class Initialized
INFO - 2016-02-02 09:40:26 --> Model Class Initialized
INFO - 2016-02-02 09:40:26 --> Model Class Initialized
INFO - 2016-02-02 09:40:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:40:26 --> Pagination Class Initialized
INFO - 2016-02-02 09:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:40:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:40:26 --> Final output sent to browser
DEBUG - 2016-02-02 09:40:26 --> Total execution time: 1.1021
INFO - 2016-02-02 09:42:34 --> Config Class Initialized
INFO - 2016-02-02 09:42:34 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:42:34 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:42:34 --> Utf8 Class Initialized
INFO - 2016-02-02 09:42:34 --> URI Class Initialized
DEBUG - 2016-02-02 09:42:34 --> No URI present. Default controller set.
INFO - 2016-02-02 09:42:34 --> Router Class Initialized
INFO - 2016-02-02 09:42:34 --> Output Class Initialized
INFO - 2016-02-02 09:42:34 --> Security Class Initialized
DEBUG - 2016-02-02 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:42:34 --> Input Class Initialized
INFO - 2016-02-02 09:42:34 --> Language Class Initialized
INFO - 2016-02-02 09:42:34 --> Loader Class Initialized
INFO - 2016-02-02 09:42:34 --> Helper loaded: url_helper
INFO - 2016-02-02 09:42:34 --> Helper loaded: file_helper
INFO - 2016-02-02 09:42:34 --> Helper loaded: date_helper
INFO - 2016-02-02 09:42:34 --> Database Driver Class Initialized
INFO - 2016-02-02 09:42:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:42:35 --> Controller Class Initialized
INFO - 2016-02-02 09:42:35 --> Model Class Initialized
INFO - 2016-02-02 09:42:35 --> Model Class Initialized
INFO - 2016-02-02 09:42:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:42:35 --> Pagination Class Initialized
INFO - 2016-02-02 09:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:42:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:42:35 --> Final output sent to browser
DEBUG - 2016-02-02 09:42:35 --> Total execution time: 1.1285
INFO - 2016-02-02 09:42:53 --> Config Class Initialized
INFO - 2016-02-02 09:42:53 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:42:53 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:42:53 --> Utf8 Class Initialized
INFO - 2016-02-02 09:42:53 --> URI Class Initialized
DEBUG - 2016-02-02 09:42:53 --> No URI present. Default controller set.
INFO - 2016-02-02 09:42:53 --> Router Class Initialized
INFO - 2016-02-02 09:42:53 --> Output Class Initialized
INFO - 2016-02-02 09:42:53 --> Security Class Initialized
DEBUG - 2016-02-02 09:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:42:53 --> Input Class Initialized
INFO - 2016-02-02 09:42:53 --> Language Class Initialized
INFO - 2016-02-02 09:42:53 --> Loader Class Initialized
INFO - 2016-02-02 09:42:53 --> Helper loaded: url_helper
INFO - 2016-02-02 09:42:53 --> Helper loaded: file_helper
INFO - 2016-02-02 09:42:53 --> Helper loaded: date_helper
INFO - 2016-02-02 09:42:53 --> Database Driver Class Initialized
INFO - 2016-02-02 09:42:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:42:54 --> Controller Class Initialized
INFO - 2016-02-02 09:42:54 --> Model Class Initialized
INFO - 2016-02-02 09:42:54 --> Model Class Initialized
INFO - 2016-02-02 09:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:42:54 --> Pagination Class Initialized
INFO - 2016-02-02 09:42:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:42:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:42:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:42:54 --> Final output sent to browser
DEBUG - 2016-02-02 09:42:54 --> Total execution time: 1.1124
INFO - 2016-02-02 09:43:00 --> Config Class Initialized
INFO - 2016-02-02 09:43:00 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:43:00 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:43:00 --> Utf8 Class Initialized
INFO - 2016-02-02 09:43:00 --> URI Class Initialized
DEBUG - 2016-02-02 09:43:00 --> No URI present. Default controller set.
INFO - 2016-02-02 09:43:00 --> Router Class Initialized
INFO - 2016-02-02 09:43:00 --> Output Class Initialized
INFO - 2016-02-02 09:43:00 --> Security Class Initialized
DEBUG - 2016-02-02 09:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:43:00 --> Input Class Initialized
INFO - 2016-02-02 09:43:00 --> Language Class Initialized
INFO - 2016-02-02 09:43:00 --> Loader Class Initialized
INFO - 2016-02-02 09:43:00 --> Helper loaded: url_helper
INFO - 2016-02-02 09:43:00 --> Helper loaded: file_helper
INFO - 2016-02-02 09:43:00 --> Helper loaded: date_helper
INFO - 2016-02-02 09:43:00 --> Database Driver Class Initialized
INFO - 2016-02-02 09:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:43:01 --> Controller Class Initialized
INFO - 2016-02-02 09:43:01 --> Model Class Initialized
INFO - 2016-02-02 09:43:01 --> Model Class Initialized
INFO - 2016-02-02 09:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:43:01 --> Pagination Class Initialized
INFO - 2016-02-02 09:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:43:01 --> Final output sent to browser
DEBUG - 2016-02-02 09:43:01 --> Total execution time: 1.1200
INFO - 2016-02-02 09:44:17 --> Config Class Initialized
INFO - 2016-02-02 09:44:17 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:44:17 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:44:17 --> Utf8 Class Initialized
INFO - 2016-02-02 09:44:17 --> URI Class Initialized
INFO - 2016-02-02 09:44:17 --> Router Class Initialized
INFO - 2016-02-02 09:44:17 --> Output Class Initialized
INFO - 2016-02-02 09:44:17 --> Security Class Initialized
DEBUG - 2016-02-02 09:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:44:17 --> Input Class Initialized
INFO - 2016-02-02 09:44:17 --> Language Class Initialized
INFO - 2016-02-02 09:44:17 --> Loader Class Initialized
INFO - 2016-02-02 09:44:17 --> Helper loaded: url_helper
INFO - 2016-02-02 09:44:17 --> Helper loaded: file_helper
INFO - 2016-02-02 09:44:17 --> Helper loaded: date_helper
INFO - 2016-02-02 09:44:17 --> Database Driver Class Initialized
INFO - 2016-02-02 09:44:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:44:18 --> Controller Class Initialized
INFO - 2016-02-02 09:44:18 --> Model Class Initialized
INFO - 2016-02-02 09:44:18 --> Model Class Initialized
INFO - 2016-02-02 09:44:18 --> Helper loaded: form_helper
INFO - 2016-02-02 09:44:18 --> Form Validation Class Initialized
INFO - 2016-02-02 09:44:18 --> Helper loaded: text_helper
INFO - 2016-02-02 09:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 09:44:18 --> Final output sent to browser
DEBUG - 2016-02-02 09:44:18 --> Total execution time: 1.1066
INFO - 2016-02-02 09:44:21 --> Config Class Initialized
INFO - 2016-02-02 09:44:21 --> Hooks Class Initialized
DEBUG - 2016-02-02 09:44:21 --> UTF-8 Support Enabled
INFO - 2016-02-02 09:44:21 --> Utf8 Class Initialized
INFO - 2016-02-02 09:44:21 --> URI Class Initialized
DEBUG - 2016-02-02 09:44:21 --> No URI present. Default controller set.
INFO - 2016-02-02 09:44:21 --> Router Class Initialized
INFO - 2016-02-02 09:44:21 --> Output Class Initialized
INFO - 2016-02-02 09:44:21 --> Security Class Initialized
DEBUG - 2016-02-02 09:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 09:44:21 --> Input Class Initialized
INFO - 2016-02-02 09:44:21 --> Language Class Initialized
INFO - 2016-02-02 09:44:21 --> Loader Class Initialized
INFO - 2016-02-02 09:44:21 --> Helper loaded: url_helper
INFO - 2016-02-02 09:44:21 --> Helper loaded: file_helper
INFO - 2016-02-02 09:44:21 --> Helper loaded: date_helper
INFO - 2016-02-02 09:44:21 --> Database Driver Class Initialized
INFO - 2016-02-02 09:44:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 09:44:22 --> Controller Class Initialized
INFO - 2016-02-02 09:44:22 --> Model Class Initialized
INFO - 2016-02-02 09:44:22 --> Model Class Initialized
INFO - 2016-02-02 09:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 09:44:22 --> Pagination Class Initialized
INFO - 2016-02-02 09:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 09:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 09:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 09:44:22 --> Final output sent to browser
DEBUG - 2016-02-02 09:44:22 --> Total execution time: 1.1297
INFO - 2016-02-02 11:07:52 --> Config Class Initialized
INFO - 2016-02-02 11:07:52 --> Hooks Class Initialized
DEBUG - 2016-02-02 11:07:52 --> UTF-8 Support Enabled
INFO - 2016-02-02 11:07:52 --> Utf8 Class Initialized
INFO - 2016-02-02 11:07:52 --> URI Class Initialized
DEBUG - 2016-02-02 11:07:52 --> No URI present. Default controller set.
INFO - 2016-02-02 11:07:52 --> Router Class Initialized
INFO - 2016-02-02 11:07:52 --> Output Class Initialized
INFO - 2016-02-02 11:07:52 --> Security Class Initialized
DEBUG - 2016-02-02 11:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 11:07:52 --> Input Class Initialized
INFO - 2016-02-02 11:07:52 --> Language Class Initialized
INFO - 2016-02-02 11:07:52 --> Loader Class Initialized
INFO - 2016-02-02 11:07:52 --> Helper loaded: url_helper
INFO - 2016-02-02 11:07:52 --> Helper loaded: file_helper
INFO - 2016-02-02 11:07:52 --> Helper loaded: date_helper
INFO - 2016-02-02 11:07:52 --> Database Driver Class Initialized
INFO - 2016-02-02 11:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 11:07:54 --> Controller Class Initialized
INFO - 2016-02-02 11:07:54 --> Model Class Initialized
INFO - 2016-02-02 11:07:54 --> Model Class Initialized
INFO - 2016-02-02 11:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 11:07:54 --> Pagination Class Initialized
INFO - 2016-02-02 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 11:07:54 --> Final output sent to browser
DEBUG - 2016-02-02 11:07:54 --> Total execution time: 1.1345
INFO - 2016-02-02 13:16:44 --> Config Class Initialized
INFO - 2016-02-02 13:16:44 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:16:44 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:16:44 --> Utf8 Class Initialized
INFO - 2016-02-02 13:16:44 --> URI Class Initialized
DEBUG - 2016-02-02 13:16:44 --> No URI present. Default controller set.
INFO - 2016-02-02 13:16:44 --> Router Class Initialized
INFO - 2016-02-02 13:16:44 --> Output Class Initialized
INFO - 2016-02-02 13:16:44 --> Security Class Initialized
DEBUG - 2016-02-02 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:16:44 --> Input Class Initialized
INFO - 2016-02-02 13:16:44 --> Language Class Initialized
INFO - 2016-02-02 13:16:44 --> Loader Class Initialized
INFO - 2016-02-02 13:16:44 --> Helper loaded: url_helper
INFO - 2016-02-02 13:16:44 --> Helper loaded: file_helper
INFO - 2016-02-02 13:16:44 --> Helper loaded: date_helper
INFO - 2016-02-02 13:16:45 --> Database Driver Class Initialized
INFO - 2016-02-02 13:16:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:16:46 --> Controller Class Initialized
INFO - 2016-02-02 13:16:46 --> Model Class Initialized
INFO - 2016-02-02 13:16:46 --> Model Class Initialized
INFO - 2016-02-02 13:16:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:16:46 --> Pagination Class Initialized
INFO - 2016-02-02 13:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 13:16:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:16:46 --> Final output sent to browser
DEBUG - 2016-02-02 13:16:46 --> Total execution time: 1.9934
INFO - 2016-02-02 13:16:48 --> Config Class Initialized
INFO - 2016-02-02 13:16:48 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:16:48 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:16:48 --> Utf8 Class Initialized
INFO - 2016-02-02 13:16:48 --> URI Class Initialized
INFO - 2016-02-02 13:16:48 --> Router Class Initialized
INFO - 2016-02-02 13:16:48 --> Output Class Initialized
INFO - 2016-02-02 13:16:48 --> Security Class Initialized
DEBUG - 2016-02-02 13:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:16:48 --> Input Class Initialized
INFO - 2016-02-02 13:16:48 --> Language Class Initialized
INFO - 2016-02-02 13:16:48 --> Loader Class Initialized
INFO - 2016-02-02 13:16:48 --> Helper loaded: url_helper
INFO - 2016-02-02 13:16:48 --> Helper loaded: file_helper
INFO - 2016-02-02 13:16:48 --> Helper loaded: date_helper
INFO - 2016-02-02 13:16:48 --> Database Driver Class Initialized
INFO - 2016-02-02 13:16:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:16:49 --> Controller Class Initialized
INFO - 2016-02-02 13:16:49 --> Model Class Initialized
INFO - 2016-02-02 13:16:49 --> Model Class Initialized
INFO - 2016-02-02 13:16:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:16:49 --> Pagination Class Initialized
INFO - 2016-02-02 13:16:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:16:49 --> Helper loaded: text_helper
INFO - 2016-02-02 13:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:16:50 --> Final output sent to browser
DEBUG - 2016-02-02 13:16:50 --> Total execution time: 1.2727
INFO - 2016-02-02 13:18:54 --> Config Class Initialized
INFO - 2016-02-02 13:18:54 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:18:54 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:18:54 --> Utf8 Class Initialized
INFO - 2016-02-02 13:18:54 --> URI Class Initialized
INFO - 2016-02-02 13:18:54 --> Router Class Initialized
INFO - 2016-02-02 13:18:54 --> Output Class Initialized
INFO - 2016-02-02 13:18:54 --> Security Class Initialized
DEBUG - 2016-02-02 13:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:18:54 --> Input Class Initialized
INFO - 2016-02-02 13:18:54 --> Language Class Initialized
INFO - 2016-02-02 13:18:54 --> Loader Class Initialized
INFO - 2016-02-02 13:18:54 --> Helper loaded: url_helper
INFO - 2016-02-02 13:18:54 --> Helper loaded: file_helper
INFO - 2016-02-02 13:18:54 --> Helper loaded: date_helper
INFO - 2016-02-02 13:18:54 --> Database Driver Class Initialized
INFO - 2016-02-02 13:18:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:18:56 --> Controller Class Initialized
INFO - 2016-02-02 13:18:56 --> Model Class Initialized
INFO - 2016-02-02 13:18:56 --> Model Class Initialized
INFO - 2016-02-02 13:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:18:56 --> Pagination Class Initialized
INFO - 2016-02-02 13:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:18:56 --> Helper loaded: text_helper
INFO - 2016-02-02 13:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:18:56 --> Final output sent to browser
DEBUG - 2016-02-02 13:18:56 --> Total execution time: 1.5735
INFO - 2016-02-02 13:23:48 --> Config Class Initialized
INFO - 2016-02-02 13:23:48 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:23:48 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:23:48 --> Utf8 Class Initialized
INFO - 2016-02-02 13:23:49 --> URI Class Initialized
INFO - 2016-02-02 13:23:49 --> Router Class Initialized
INFO - 2016-02-02 13:23:49 --> Output Class Initialized
INFO - 2016-02-02 13:23:49 --> Security Class Initialized
DEBUG - 2016-02-02 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:23:49 --> Input Class Initialized
INFO - 2016-02-02 13:23:49 --> Language Class Initialized
INFO - 2016-02-02 13:23:49 --> Loader Class Initialized
INFO - 2016-02-02 13:23:49 --> Helper loaded: url_helper
INFO - 2016-02-02 13:23:49 --> Helper loaded: file_helper
INFO - 2016-02-02 13:23:49 --> Helper loaded: date_helper
INFO - 2016-02-02 13:23:49 --> Database Driver Class Initialized
INFO - 2016-02-02 13:23:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:23:50 --> Controller Class Initialized
INFO - 2016-02-02 13:23:50 --> Model Class Initialized
INFO - 2016-02-02 13:23:50 --> Model Class Initialized
INFO - 2016-02-02 13:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:23:50 --> Pagination Class Initialized
INFO - 2016-02-02 13:23:50 --> Config Class Initialized
INFO - 2016-02-02 13:23:50 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:23:50 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:23:50 --> Utf8 Class Initialized
INFO - 2016-02-02 13:23:50 --> URI Class Initialized
INFO - 2016-02-02 13:23:50 --> Router Class Initialized
INFO - 2016-02-02 13:23:50 --> Output Class Initialized
INFO - 2016-02-02 13:23:50 --> Security Class Initialized
DEBUG - 2016-02-02 13:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:23:50 --> Input Class Initialized
INFO - 2016-02-02 13:23:50 --> Language Class Initialized
INFO - 2016-02-02 13:23:50 --> Loader Class Initialized
INFO - 2016-02-02 13:23:50 --> Helper loaded: url_helper
INFO - 2016-02-02 13:23:50 --> Helper loaded: file_helper
INFO - 2016-02-02 13:23:50 --> Helper loaded: date_helper
INFO - 2016-02-02 13:23:50 --> Database Driver Class Initialized
INFO - 2016-02-02 13:23:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:23:51 --> Controller Class Initialized
INFO - 2016-02-02 13:23:51 --> Model Class Initialized
INFO - 2016-02-02 13:23:51 --> Model Class Initialized
INFO - 2016-02-02 13:23:52 --> Helper loaded: form_helper
INFO - 2016-02-02 13:23:52 --> Form Validation Class Initialized
INFO - 2016-02-02 13:23:52 --> Helper loaded: text_helper
INFO - 2016-02-02 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 13:23:52 --> Final output sent to browser
DEBUG - 2016-02-02 13:23:52 --> Total execution time: 1.4933
INFO - 2016-02-02 13:24:50 --> Config Class Initialized
INFO - 2016-02-02 13:24:50 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:24:50 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:24:50 --> Utf8 Class Initialized
INFO - 2016-02-02 13:24:50 --> URI Class Initialized
DEBUG - 2016-02-02 13:24:50 --> No URI present. Default controller set.
INFO - 2016-02-02 13:24:50 --> Router Class Initialized
INFO - 2016-02-02 13:24:50 --> Output Class Initialized
INFO - 2016-02-02 13:24:50 --> Security Class Initialized
DEBUG - 2016-02-02 13:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:24:50 --> Input Class Initialized
INFO - 2016-02-02 13:24:50 --> Language Class Initialized
INFO - 2016-02-02 13:24:50 --> Loader Class Initialized
INFO - 2016-02-02 13:24:50 --> Helper loaded: url_helper
INFO - 2016-02-02 13:24:50 --> Helper loaded: file_helper
INFO - 2016-02-02 13:24:50 --> Helper loaded: date_helper
INFO - 2016-02-02 13:24:50 --> Database Driver Class Initialized
INFO - 2016-02-02 13:24:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:24:52 --> Controller Class Initialized
INFO - 2016-02-02 13:24:52 --> Model Class Initialized
INFO - 2016-02-02 13:24:52 --> Model Class Initialized
INFO - 2016-02-02 13:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:24:52 --> Pagination Class Initialized
INFO - 2016-02-02 13:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-02 13:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:24:52 --> Final output sent to browser
DEBUG - 2016-02-02 13:24:52 --> Total execution time: 1.3942
INFO - 2016-02-02 13:24:54 --> Config Class Initialized
INFO - 2016-02-02 13:24:54 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:24:54 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:24:54 --> Utf8 Class Initialized
INFO - 2016-02-02 13:24:54 --> URI Class Initialized
INFO - 2016-02-02 13:24:54 --> Router Class Initialized
INFO - 2016-02-02 13:24:54 --> Output Class Initialized
INFO - 2016-02-02 13:24:54 --> Security Class Initialized
DEBUG - 2016-02-02 13:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:24:54 --> Input Class Initialized
INFO - 2016-02-02 13:24:54 --> Language Class Initialized
INFO - 2016-02-02 13:24:54 --> Loader Class Initialized
INFO - 2016-02-02 13:24:54 --> Helper loaded: url_helper
INFO - 2016-02-02 13:24:54 --> Helper loaded: file_helper
INFO - 2016-02-02 13:24:54 --> Helper loaded: date_helper
INFO - 2016-02-02 13:24:54 --> Database Driver Class Initialized
INFO - 2016-02-02 13:24:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:24:55 --> Controller Class Initialized
INFO - 2016-02-02 13:24:55 --> Model Class Initialized
INFO - 2016-02-02 13:24:55 --> Model Class Initialized
INFO - 2016-02-02 13:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:24:55 --> Pagination Class Initialized
INFO - 2016-02-02 13:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:24:55 --> Helper loaded: text_helper
INFO - 2016-02-02 13:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:24:55 --> Final output sent to browser
DEBUG - 2016-02-02 13:24:55 --> Total execution time: 1.5751
INFO - 2016-02-02 13:24:58 --> Config Class Initialized
INFO - 2016-02-02 13:24:58 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:24:58 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:24:58 --> Utf8 Class Initialized
INFO - 2016-02-02 13:24:58 --> URI Class Initialized
INFO - 2016-02-02 13:24:58 --> Router Class Initialized
INFO - 2016-02-02 13:24:58 --> Output Class Initialized
INFO - 2016-02-02 13:24:58 --> Security Class Initialized
DEBUG - 2016-02-02 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:24:58 --> Input Class Initialized
INFO - 2016-02-02 13:24:58 --> Language Class Initialized
INFO - 2016-02-02 13:24:58 --> Loader Class Initialized
INFO - 2016-02-02 13:24:58 --> Helper loaded: url_helper
INFO - 2016-02-02 13:24:58 --> Helper loaded: file_helper
INFO - 2016-02-02 13:24:58 --> Helper loaded: date_helper
INFO - 2016-02-02 13:24:58 --> Database Driver Class Initialized
INFO - 2016-02-02 13:24:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:24:59 --> Controller Class Initialized
INFO - 2016-02-02 13:24:59 --> Model Class Initialized
INFO - 2016-02-02 13:24:59 --> Model Class Initialized
INFO - 2016-02-02 13:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:24:59 --> Pagination Class Initialized
INFO - 2016-02-02 13:24:59 --> Config Class Initialized
INFO - 2016-02-02 13:24:59 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:24:59 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:24:59 --> Utf8 Class Initialized
INFO - 2016-02-02 13:24:59 --> URI Class Initialized
INFO - 2016-02-02 13:24:59 --> Router Class Initialized
INFO - 2016-02-02 13:24:59 --> Output Class Initialized
INFO - 2016-02-02 13:24:59 --> Security Class Initialized
DEBUG - 2016-02-02 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:24:59 --> Input Class Initialized
INFO - 2016-02-02 13:24:59 --> Language Class Initialized
INFO - 2016-02-02 13:24:59 --> Loader Class Initialized
INFO - 2016-02-02 13:24:59 --> Helper loaded: url_helper
INFO - 2016-02-02 13:24:59 --> Helper loaded: file_helper
INFO - 2016-02-02 13:24:59 --> Helper loaded: date_helper
INFO - 2016-02-02 13:24:59 --> Database Driver Class Initialized
INFO - 2016-02-02 13:25:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:25:00 --> Controller Class Initialized
INFO - 2016-02-02 13:25:00 --> Model Class Initialized
INFO - 2016-02-02 13:25:00 --> Model Class Initialized
INFO - 2016-02-02 13:25:00 --> Helper loaded: form_helper
INFO - 2016-02-02 13:25:00 --> Form Validation Class Initialized
INFO - 2016-02-02 13:25:00 --> Helper loaded: text_helper
INFO - 2016-02-02 13:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-02 13:25:01 --> Final output sent to browser
DEBUG - 2016-02-02 13:25:01 --> Total execution time: 1.2815
INFO - 2016-02-02 13:25:29 --> Config Class Initialized
INFO - 2016-02-02 13:25:29 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:25:29 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:25:29 --> Utf8 Class Initialized
INFO - 2016-02-02 13:25:29 --> URI Class Initialized
INFO - 2016-02-02 13:25:29 --> Router Class Initialized
INFO - 2016-02-02 13:25:29 --> Output Class Initialized
INFO - 2016-02-02 13:25:29 --> Security Class Initialized
DEBUG - 2016-02-02 13:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:25:29 --> Input Class Initialized
INFO - 2016-02-02 13:25:29 --> Language Class Initialized
INFO - 2016-02-02 13:25:29 --> Loader Class Initialized
INFO - 2016-02-02 13:25:29 --> Helper loaded: url_helper
INFO - 2016-02-02 13:25:29 --> Helper loaded: file_helper
INFO - 2016-02-02 13:25:29 --> Helper loaded: date_helper
INFO - 2016-02-02 13:25:29 --> Database Driver Class Initialized
INFO - 2016-02-02 13:25:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:25:30 --> Controller Class Initialized
INFO - 2016-02-02 13:25:30 --> Model Class Initialized
INFO - 2016-02-02 13:25:30 --> Model Class Initialized
INFO - 2016-02-02 13:25:30 --> Helper loaded: form_helper
INFO - 2016-02-02 13:25:30 --> Form Validation Class Initialized
INFO - 2016-02-02 13:25:30 --> Helper loaded: text_helper
INFO - 2016-02-02 13:25:30 --> Config Class Initialized
INFO - 2016-02-02 13:25:30 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:25:30 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:25:30 --> Utf8 Class Initialized
INFO - 2016-02-02 13:25:30 --> URI Class Initialized
INFO - 2016-02-02 13:25:30 --> Router Class Initialized
INFO - 2016-02-02 13:25:30 --> Output Class Initialized
INFO - 2016-02-02 13:25:30 --> Security Class Initialized
DEBUG - 2016-02-02 13:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:25:30 --> Input Class Initialized
INFO - 2016-02-02 13:25:30 --> Language Class Initialized
INFO - 2016-02-02 13:25:30 --> Loader Class Initialized
INFO - 2016-02-02 13:25:30 --> Helper loaded: url_helper
INFO - 2016-02-02 13:25:30 --> Helper loaded: file_helper
INFO - 2016-02-02 13:25:30 --> Helper loaded: date_helper
INFO - 2016-02-02 13:25:30 --> Database Driver Class Initialized
INFO - 2016-02-02 13:25:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:25:31 --> Controller Class Initialized
INFO - 2016-02-02 13:25:31 --> Model Class Initialized
INFO - 2016-02-02 13:25:31 --> Model Class Initialized
INFO - 2016-02-02 13:25:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:25:31 --> Pagination Class Initialized
INFO - 2016-02-02 13:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:25:31 --> Helper loaded: text_helper
INFO - 2016-02-02 13:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:25:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:25:31 --> Final output sent to browser
DEBUG - 2016-02-02 13:25:31 --> Total execution time: 1.2091
INFO - 2016-02-02 13:25:34 --> Config Class Initialized
INFO - 2016-02-02 13:25:34 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:25:34 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:25:34 --> Utf8 Class Initialized
INFO - 2016-02-02 13:25:34 --> URI Class Initialized
INFO - 2016-02-02 13:25:34 --> Router Class Initialized
INFO - 2016-02-02 13:25:34 --> Output Class Initialized
INFO - 2016-02-02 13:25:34 --> Security Class Initialized
DEBUG - 2016-02-02 13:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:25:34 --> Input Class Initialized
INFO - 2016-02-02 13:25:34 --> Language Class Initialized
INFO - 2016-02-02 13:25:34 --> Loader Class Initialized
INFO - 2016-02-02 13:25:34 --> Helper loaded: url_helper
INFO - 2016-02-02 13:25:34 --> Helper loaded: file_helper
INFO - 2016-02-02 13:25:34 --> Helper loaded: date_helper
INFO - 2016-02-02 13:25:34 --> Database Driver Class Initialized
INFO - 2016-02-02 13:25:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:25:35 --> Controller Class Initialized
INFO - 2016-02-02 13:25:35 --> Model Class Initialized
INFO - 2016-02-02 13:25:35 --> Model Class Initialized
INFO - 2016-02-02 13:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:25:35 --> Pagination Class Initialized
INFO - 2016-02-02 13:25:35 --> Config Class Initialized
INFO - 2016-02-02 13:25:35 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:25:35 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:25:35 --> Utf8 Class Initialized
INFO - 2016-02-02 13:25:35 --> URI Class Initialized
INFO - 2016-02-02 13:25:35 --> Router Class Initialized
INFO - 2016-02-02 13:25:35 --> Output Class Initialized
INFO - 2016-02-02 13:25:35 --> Security Class Initialized
DEBUG - 2016-02-02 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:25:35 --> Input Class Initialized
INFO - 2016-02-02 13:25:35 --> Language Class Initialized
INFO - 2016-02-02 13:25:35 --> Loader Class Initialized
INFO - 2016-02-02 13:25:35 --> Helper loaded: url_helper
INFO - 2016-02-02 13:25:35 --> Helper loaded: file_helper
INFO - 2016-02-02 13:25:35 --> Helper loaded: date_helper
INFO - 2016-02-02 13:25:35 --> Database Driver Class Initialized
INFO - 2016-02-02 13:25:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:25:36 --> Controller Class Initialized
INFO - 2016-02-02 13:25:36 --> Model Class Initialized
INFO - 2016-02-02 13:25:36 --> Model Class Initialized
INFO - 2016-02-02 13:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:25:36 --> Pagination Class Initialized
INFO - 2016-02-02 13:25:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:25:36 --> Helper loaded: text_helper
INFO - 2016-02-02 13:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:25:37 --> Final output sent to browser
DEBUG - 2016-02-02 13:25:37 --> Total execution time: 1.1873
INFO - 2016-02-02 13:29:18 --> Config Class Initialized
INFO - 2016-02-02 13:29:18 --> Hooks Class Initialized
DEBUG - 2016-02-02 13:29:18 --> UTF-8 Support Enabled
INFO - 2016-02-02 13:29:18 --> Utf8 Class Initialized
INFO - 2016-02-02 13:29:18 --> URI Class Initialized
INFO - 2016-02-02 13:29:18 --> Router Class Initialized
INFO - 2016-02-02 13:29:18 --> Output Class Initialized
INFO - 2016-02-02 13:29:18 --> Security Class Initialized
DEBUG - 2016-02-02 13:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 13:29:18 --> Input Class Initialized
INFO - 2016-02-02 13:29:18 --> Language Class Initialized
INFO - 2016-02-02 13:29:18 --> Loader Class Initialized
INFO - 2016-02-02 13:29:18 --> Helper loaded: url_helper
INFO - 2016-02-02 13:29:18 --> Helper loaded: file_helper
INFO - 2016-02-02 13:29:18 --> Helper loaded: date_helper
INFO - 2016-02-02 13:29:18 --> Database Driver Class Initialized
INFO - 2016-02-02 13:29:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 13:29:19 --> Controller Class Initialized
INFO - 2016-02-02 13:29:19 --> Model Class Initialized
INFO - 2016-02-02 13:29:19 --> Model Class Initialized
INFO - 2016-02-02 13:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 13:29:19 --> Pagination Class Initialized
INFO - 2016-02-02 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 13:29:19 --> Helper loaded: text_helper
INFO - 2016-02-02 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 13:29:19 --> Final output sent to browser
DEBUG - 2016-02-02 13:29:19 --> Total execution time: 1.2167
INFO - 2016-02-02 14:21:23 --> Config Class Initialized
INFO - 2016-02-02 14:21:23 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:21:23 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:21:23 --> Utf8 Class Initialized
INFO - 2016-02-02 14:21:23 --> URI Class Initialized
INFO - 2016-02-02 14:21:23 --> Router Class Initialized
INFO - 2016-02-02 14:21:23 --> Output Class Initialized
INFO - 2016-02-02 14:21:23 --> Security Class Initialized
DEBUG - 2016-02-02 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:21:23 --> Input Class Initialized
INFO - 2016-02-02 14:21:23 --> Language Class Initialized
INFO - 2016-02-02 14:21:23 --> Loader Class Initialized
INFO - 2016-02-02 14:21:23 --> Helper loaded: url_helper
INFO - 2016-02-02 14:21:23 --> Helper loaded: file_helper
INFO - 2016-02-02 14:21:23 --> Helper loaded: date_helper
INFO - 2016-02-02 14:21:23 --> Database Driver Class Initialized
INFO - 2016-02-02 14:21:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:21:24 --> Controller Class Initialized
INFO - 2016-02-02 14:21:24 --> Model Class Initialized
INFO - 2016-02-02 14:21:24 --> Model Class Initialized
INFO - 2016-02-02 14:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:21:24 --> Pagination Class Initialized
INFO - 2016-02-02 14:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:21:24 --> Helper loaded: text_helper
INFO - 2016-02-02 14:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:21:25 --> Final output sent to browser
DEBUG - 2016-02-02 14:21:25 --> Total execution time: 1.1803
INFO - 2016-02-02 14:22:15 --> Config Class Initialized
INFO - 2016-02-02 14:22:15 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:22:15 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:22:15 --> Utf8 Class Initialized
INFO - 2016-02-02 14:22:15 --> URI Class Initialized
INFO - 2016-02-02 14:22:15 --> Router Class Initialized
INFO - 2016-02-02 14:22:15 --> Output Class Initialized
INFO - 2016-02-02 14:22:15 --> Security Class Initialized
DEBUG - 2016-02-02 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:22:15 --> Input Class Initialized
INFO - 2016-02-02 14:22:15 --> Language Class Initialized
INFO - 2016-02-02 14:22:15 --> Loader Class Initialized
INFO - 2016-02-02 14:22:15 --> Helper loaded: url_helper
INFO - 2016-02-02 14:22:15 --> Helper loaded: file_helper
INFO - 2016-02-02 14:22:15 --> Helper loaded: date_helper
INFO - 2016-02-02 14:22:15 --> Database Driver Class Initialized
INFO - 2016-02-02 14:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:22:16 --> Controller Class Initialized
INFO - 2016-02-02 14:22:16 --> Model Class Initialized
INFO - 2016-02-02 14:22:16 --> Model Class Initialized
INFO - 2016-02-02 14:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:22:16 --> Pagination Class Initialized
INFO - 2016-02-02 14:22:16 --> Config Class Initialized
INFO - 2016-02-02 14:22:16 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:22:16 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:22:16 --> Utf8 Class Initialized
INFO - 2016-02-02 14:22:16 --> URI Class Initialized
INFO - 2016-02-02 14:22:16 --> Router Class Initialized
INFO - 2016-02-02 14:22:16 --> Output Class Initialized
INFO - 2016-02-02 14:22:16 --> Security Class Initialized
DEBUG - 2016-02-02 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:22:16 --> Input Class Initialized
INFO - 2016-02-02 14:22:16 --> Language Class Initialized
INFO - 2016-02-02 14:22:16 --> Loader Class Initialized
INFO - 2016-02-02 14:22:16 --> Helper loaded: url_helper
INFO - 2016-02-02 14:22:16 --> Helper loaded: file_helper
INFO - 2016-02-02 14:22:16 --> Helper loaded: date_helper
INFO - 2016-02-02 14:22:16 --> Database Driver Class Initialized
INFO - 2016-02-02 14:22:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:22:17 --> Controller Class Initialized
INFO - 2016-02-02 14:22:17 --> Model Class Initialized
INFO - 2016-02-02 14:22:17 --> Model Class Initialized
INFO - 2016-02-02 14:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:22:17 --> Pagination Class Initialized
INFO - 2016-02-02 14:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:22:17 --> Helper loaded: text_helper
INFO - 2016-02-02 14:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:22:17 --> Final output sent to browser
DEBUG - 2016-02-02 14:22:17 --> Total execution time: 1.1305
INFO - 2016-02-02 14:25:36 --> Config Class Initialized
INFO - 2016-02-02 14:25:36 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:25:36 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:25:36 --> Utf8 Class Initialized
INFO - 2016-02-02 14:25:36 --> URI Class Initialized
INFO - 2016-02-02 14:25:36 --> Router Class Initialized
INFO - 2016-02-02 14:25:36 --> Output Class Initialized
INFO - 2016-02-02 14:25:36 --> Security Class Initialized
DEBUG - 2016-02-02 14:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:25:36 --> Input Class Initialized
INFO - 2016-02-02 14:25:36 --> Language Class Initialized
INFO - 2016-02-02 14:25:36 --> Loader Class Initialized
INFO - 2016-02-02 14:25:36 --> Helper loaded: url_helper
INFO - 2016-02-02 14:25:36 --> Helper loaded: file_helper
INFO - 2016-02-02 14:25:36 --> Helper loaded: date_helper
INFO - 2016-02-02 14:25:36 --> Database Driver Class Initialized
INFO - 2016-02-02 14:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:25:37 --> Controller Class Initialized
INFO - 2016-02-02 14:25:37 --> Model Class Initialized
INFO - 2016-02-02 14:25:37 --> Model Class Initialized
INFO - 2016-02-02 14:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:25:37 --> Pagination Class Initialized
INFO - 2016-02-02 14:25:37 --> Config Class Initialized
INFO - 2016-02-02 14:25:37 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:25:37 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:25:37 --> Utf8 Class Initialized
INFO - 2016-02-02 14:25:37 --> URI Class Initialized
INFO - 2016-02-02 14:25:37 --> Router Class Initialized
INFO - 2016-02-02 14:25:37 --> Output Class Initialized
INFO - 2016-02-02 14:25:37 --> Security Class Initialized
DEBUG - 2016-02-02 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:25:37 --> Input Class Initialized
INFO - 2016-02-02 14:25:37 --> Language Class Initialized
INFO - 2016-02-02 14:25:37 --> Loader Class Initialized
INFO - 2016-02-02 14:25:37 --> Helper loaded: url_helper
INFO - 2016-02-02 14:25:37 --> Helper loaded: file_helper
INFO - 2016-02-02 14:25:37 --> Helper loaded: date_helper
INFO - 2016-02-02 14:25:37 --> Database Driver Class Initialized
INFO - 2016-02-02 14:25:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:25:38 --> Controller Class Initialized
INFO - 2016-02-02 14:25:38 --> Model Class Initialized
INFO - 2016-02-02 14:25:38 --> Model Class Initialized
INFO - 2016-02-02 14:25:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:25:38 --> Pagination Class Initialized
INFO - 2016-02-02 14:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:25:38 --> Helper loaded: text_helper
INFO - 2016-02-02 14:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:25:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:25:38 --> Final output sent to browser
DEBUG - 2016-02-02 14:25:38 --> Total execution time: 1.1565
INFO - 2016-02-02 14:25:45 --> Config Class Initialized
INFO - 2016-02-02 14:25:45 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:25:45 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:25:45 --> Utf8 Class Initialized
INFO - 2016-02-02 14:25:45 --> URI Class Initialized
INFO - 2016-02-02 14:25:45 --> Router Class Initialized
INFO - 2016-02-02 14:25:45 --> Output Class Initialized
INFO - 2016-02-02 14:25:45 --> Security Class Initialized
DEBUG - 2016-02-02 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:25:45 --> Input Class Initialized
INFO - 2016-02-02 14:25:45 --> Language Class Initialized
INFO - 2016-02-02 14:25:45 --> Loader Class Initialized
INFO - 2016-02-02 14:25:45 --> Helper loaded: url_helper
INFO - 2016-02-02 14:25:45 --> Helper loaded: file_helper
INFO - 2016-02-02 14:25:45 --> Helper loaded: date_helper
INFO - 2016-02-02 14:25:45 --> Database Driver Class Initialized
INFO - 2016-02-02 14:25:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:25:46 --> Controller Class Initialized
INFO - 2016-02-02 14:25:46 --> Model Class Initialized
INFO - 2016-02-02 14:25:46 --> Model Class Initialized
INFO - 2016-02-02 14:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:25:46 --> Pagination Class Initialized
INFO - 2016-02-02 14:25:47 --> Config Class Initialized
INFO - 2016-02-02 14:25:47 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:25:47 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:25:47 --> Utf8 Class Initialized
INFO - 2016-02-02 14:25:47 --> URI Class Initialized
INFO - 2016-02-02 14:25:47 --> Router Class Initialized
INFO - 2016-02-02 14:25:47 --> Output Class Initialized
INFO - 2016-02-02 14:25:47 --> Security Class Initialized
DEBUG - 2016-02-02 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:25:47 --> Input Class Initialized
INFO - 2016-02-02 14:25:47 --> Language Class Initialized
INFO - 2016-02-02 14:25:47 --> Loader Class Initialized
INFO - 2016-02-02 14:25:47 --> Helper loaded: url_helper
INFO - 2016-02-02 14:25:47 --> Helper loaded: file_helper
INFO - 2016-02-02 14:25:47 --> Helper loaded: date_helper
INFO - 2016-02-02 14:25:47 --> Database Driver Class Initialized
INFO - 2016-02-02 14:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:25:48 --> Controller Class Initialized
INFO - 2016-02-02 14:25:48 --> Model Class Initialized
INFO - 2016-02-02 14:25:48 --> Model Class Initialized
INFO - 2016-02-02 14:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:25:48 --> Pagination Class Initialized
INFO - 2016-02-02 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:25:48 --> Helper loaded: text_helper
INFO - 2016-02-02 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:25:48 --> Final output sent to browser
DEBUG - 2016-02-02 14:25:48 --> Total execution time: 1.1892
INFO - 2016-02-02 14:30:41 --> Config Class Initialized
INFO - 2016-02-02 14:30:41 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:30:41 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:30:41 --> Utf8 Class Initialized
INFO - 2016-02-02 14:30:41 --> URI Class Initialized
INFO - 2016-02-02 14:30:41 --> Router Class Initialized
INFO - 2016-02-02 14:30:41 --> Output Class Initialized
INFO - 2016-02-02 14:30:41 --> Security Class Initialized
DEBUG - 2016-02-02 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:30:41 --> Input Class Initialized
INFO - 2016-02-02 14:30:41 --> Language Class Initialized
INFO - 2016-02-02 14:30:41 --> Loader Class Initialized
INFO - 2016-02-02 14:30:41 --> Helper loaded: url_helper
INFO - 2016-02-02 14:30:41 --> Helper loaded: file_helper
INFO - 2016-02-02 14:30:41 --> Helper loaded: date_helper
INFO - 2016-02-02 14:30:41 --> Database Driver Class Initialized
INFO - 2016-02-02 14:30:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:30:42 --> Controller Class Initialized
INFO - 2016-02-02 14:30:42 --> Model Class Initialized
INFO - 2016-02-02 14:30:42 --> Model Class Initialized
INFO - 2016-02-02 14:30:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:30:42 --> Pagination Class Initialized
INFO - 2016-02-02 14:30:42 --> Config Class Initialized
INFO - 2016-02-02 14:30:42 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:30:42 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:30:42 --> Utf8 Class Initialized
INFO - 2016-02-02 14:30:42 --> URI Class Initialized
INFO - 2016-02-02 14:30:42 --> Router Class Initialized
INFO - 2016-02-02 14:30:42 --> Output Class Initialized
INFO - 2016-02-02 14:30:42 --> Security Class Initialized
DEBUG - 2016-02-02 14:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:30:43 --> Input Class Initialized
INFO - 2016-02-02 14:30:43 --> Language Class Initialized
INFO - 2016-02-02 14:30:43 --> Loader Class Initialized
INFO - 2016-02-02 14:30:43 --> Helper loaded: url_helper
INFO - 2016-02-02 14:30:43 --> Helper loaded: file_helper
INFO - 2016-02-02 14:30:43 --> Helper loaded: date_helper
INFO - 2016-02-02 14:30:43 --> Database Driver Class Initialized
INFO - 2016-02-02 14:30:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:30:44 --> Controller Class Initialized
INFO - 2016-02-02 14:30:44 --> Model Class Initialized
INFO - 2016-02-02 14:30:44 --> Model Class Initialized
INFO - 2016-02-02 14:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:30:44 --> Pagination Class Initialized
INFO - 2016-02-02 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:30:44 --> Helper loaded: text_helper
INFO - 2016-02-02 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:30:44 --> Final output sent to browser
DEBUG - 2016-02-02 14:30:44 --> Total execution time: 1.1592
INFO - 2016-02-02 14:32:59 --> Config Class Initialized
INFO - 2016-02-02 14:32:59 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:32:59 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:32:59 --> Utf8 Class Initialized
INFO - 2016-02-02 14:32:59 --> URI Class Initialized
INFO - 2016-02-02 14:32:59 --> Router Class Initialized
INFO - 2016-02-02 14:32:59 --> Output Class Initialized
INFO - 2016-02-02 14:32:59 --> Security Class Initialized
DEBUG - 2016-02-02 14:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:32:59 --> Input Class Initialized
INFO - 2016-02-02 14:32:59 --> Language Class Initialized
INFO - 2016-02-02 14:32:59 --> Loader Class Initialized
INFO - 2016-02-02 14:32:59 --> Helper loaded: url_helper
INFO - 2016-02-02 14:32:59 --> Helper loaded: file_helper
INFO - 2016-02-02 14:32:59 --> Helper loaded: date_helper
INFO - 2016-02-02 14:32:59 --> Database Driver Class Initialized
INFO - 2016-02-02 14:33:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:33:00 --> Controller Class Initialized
INFO - 2016-02-02 14:33:00 --> Model Class Initialized
INFO - 2016-02-02 14:33:00 --> Model Class Initialized
INFO - 2016-02-02 14:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:33:00 --> Pagination Class Initialized
INFO - 2016-02-02 14:33:00 --> Config Class Initialized
INFO - 2016-02-02 14:33:00 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:33:00 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:33:00 --> Utf8 Class Initialized
INFO - 2016-02-02 14:33:00 --> URI Class Initialized
INFO - 2016-02-02 14:33:00 --> Router Class Initialized
INFO - 2016-02-02 14:33:00 --> Output Class Initialized
INFO - 2016-02-02 14:33:00 --> Security Class Initialized
DEBUG - 2016-02-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:33:00 --> Input Class Initialized
INFO - 2016-02-02 14:33:00 --> Language Class Initialized
INFO - 2016-02-02 14:33:00 --> Loader Class Initialized
INFO - 2016-02-02 14:33:00 --> Helper loaded: url_helper
INFO - 2016-02-02 14:33:00 --> Helper loaded: file_helper
INFO - 2016-02-02 14:33:00 --> Helper loaded: date_helper
INFO - 2016-02-02 14:33:00 --> Database Driver Class Initialized
INFO - 2016-02-02 14:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:33:01 --> Controller Class Initialized
INFO - 2016-02-02 14:33:01 --> Model Class Initialized
INFO - 2016-02-02 14:33:01 --> Model Class Initialized
INFO - 2016-02-02 14:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:33:01 --> Pagination Class Initialized
INFO - 2016-02-02 14:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:33:01 --> Helper loaded: text_helper
INFO - 2016-02-02 14:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:33:01 --> Final output sent to browser
DEBUG - 2016-02-02 14:33:01 --> Total execution time: 1.1310
INFO - 2016-02-02 14:37:26 --> Config Class Initialized
INFO - 2016-02-02 14:37:26 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:37:26 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:37:26 --> Utf8 Class Initialized
INFO - 2016-02-02 14:37:26 --> URI Class Initialized
INFO - 2016-02-02 14:37:26 --> Router Class Initialized
INFO - 2016-02-02 14:37:26 --> Output Class Initialized
INFO - 2016-02-02 14:37:26 --> Security Class Initialized
DEBUG - 2016-02-02 14:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:37:26 --> Input Class Initialized
INFO - 2016-02-02 14:37:26 --> Language Class Initialized
INFO - 2016-02-02 14:37:26 --> Loader Class Initialized
INFO - 2016-02-02 14:37:26 --> Helper loaded: url_helper
INFO - 2016-02-02 14:37:26 --> Helper loaded: file_helper
INFO - 2016-02-02 14:37:26 --> Helper loaded: date_helper
INFO - 2016-02-02 14:37:26 --> Database Driver Class Initialized
INFO - 2016-02-02 14:37:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:37:27 --> Controller Class Initialized
INFO - 2016-02-02 14:37:27 --> Model Class Initialized
INFO - 2016-02-02 14:37:27 --> Model Class Initialized
INFO - 2016-02-02 14:37:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:37:27 --> Pagination Class Initialized
INFO - 2016-02-02 14:37:28 --> Config Class Initialized
INFO - 2016-02-02 14:37:28 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:37:28 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:37:28 --> Utf8 Class Initialized
INFO - 2016-02-02 14:37:28 --> URI Class Initialized
INFO - 2016-02-02 14:37:28 --> Router Class Initialized
INFO - 2016-02-02 14:37:28 --> Output Class Initialized
INFO - 2016-02-02 14:37:28 --> Security Class Initialized
DEBUG - 2016-02-02 14:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:37:28 --> Input Class Initialized
INFO - 2016-02-02 14:37:28 --> Language Class Initialized
INFO - 2016-02-02 14:37:28 --> Loader Class Initialized
INFO - 2016-02-02 14:37:28 --> Helper loaded: url_helper
INFO - 2016-02-02 14:37:28 --> Helper loaded: file_helper
INFO - 2016-02-02 14:37:28 --> Helper loaded: date_helper
INFO - 2016-02-02 14:37:28 --> Database Driver Class Initialized
INFO - 2016-02-02 14:37:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:37:29 --> Controller Class Initialized
INFO - 2016-02-02 14:37:29 --> Model Class Initialized
INFO - 2016-02-02 14:37:29 --> Model Class Initialized
INFO - 2016-02-02 14:37:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:37:29 --> Pagination Class Initialized
INFO - 2016-02-02 14:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:37:29 --> Helper loaded: text_helper
INFO - 2016-02-02 14:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:37:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:37:29 --> Final output sent to browser
DEBUG - 2016-02-02 14:37:29 --> Total execution time: 1.1293
INFO - 2016-02-02 14:37:38 --> Config Class Initialized
INFO - 2016-02-02 14:37:38 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:37:38 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:37:38 --> Utf8 Class Initialized
INFO - 2016-02-02 14:37:38 --> URI Class Initialized
INFO - 2016-02-02 14:37:38 --> Router Class Initialized
INFO - 2016-02-02 14:37:38 --> Output Class Initialized
INFO - 2016-02-02 14:37:38 --> Security Class Initialized
DEBUG - 2016-02-02 14:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:37:38 --> Input Class Initialized
INFO - 2016-02-02 14:37:38 --> Language Class Initialized
INFO - 2016-02-02 14:37:38 --> Loader Class Initialized
INFO - 2016-02-02 14:37:38 --> Helper loaded: url_helper
INFO - 2016-02-02 14:37:38 --> Helper loaded: file_helper
INFO - 2016-02-02 14:37:38 --> Helper loaded: date_helper
INFO - 2016-02-02 14:37:38 --> Database Driver Class Initialized
INFO - 2016-02-02 14:37:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:37:39 --> Controller Class Initialized
INFO - 2016-02-02 14:37:39 --> Model Class Initialized
INFO - 2016-02-02 14:37:39 --> Model Class Initialized
INFO - 2016-02-02 14:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:37:39 --> Pagination Class Initialized
INFO - 2016-02-02 14:37:39 --> Config Class Initialized
INFO - 2016-02-02 14:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:37:39 --> Utf8 Class Initialized
INFO - 2016-02-02 14:37:39 --> URI Class Initialized
INFO - 2016-02-02 14:37:39 --> Router Class Initialized
INFO - 2016-02-02 14:37:39 --> Output Class Initialized
INFO - 2016-02-02 14:37:39 --> Security Class Initialized
DEBUG - 2016-02-02 14:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:37:39 --> Input Class Initialized
INFO - 2016-02-02 14:37:39 --> Language Class Initialized
INFO - 2016-02-02 14:37:39 --> Loader Class Initialized
INFO - 2016-02-02 14:37:39 --> Helper loaded: url_helper
INFO - 2016-02-02 14:37:39 --> Helper loaded: file_helper
INFO - 2016-02-02 14:37:39 --> Helper loaded: date_helper
INFO - 2016-02-02 14:37:39 --> Database Driver Class Initialized
INFO - 2016-02-02 14:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:37:40 --> Controller Class Initialized
INFO - 2016-02-02 14:37:40 --> Model Class Initialized
INFO - 2016-02-02 14:37:40 --> Model Class Initialized
INFO - 2016-02-02 14:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:37:40 --> Pagination Class Initialized
INFO - 2016-02-02 14:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:37:40 --> Helper loaded: text_helper
INFO - 2016-02-02 14:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:37:40 --> Final output sent to browser
DEBUG - 2016-02-02 14:37:40 --> Total execution time: 1.1651
INFO - 2016-02-02 14:42:39 --> Config Class Initialized
INFO - 2016-02-02 14:42:39 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:42:39 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:42:39 --> Utf8 Class Initialized
INFO - 2016-02-02 14:42:39 --> URI Class Initialized
INFO - 2016-02-02 14:42:39 --> Router Class Initialized
INFO - 2016-02-02 14:42:39 --> Output Class Initialized
INFO - 2016-02-02 14:42:39 --> Security Class Initialized
DEBUG - 2016-02-02 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:42:39 --> Input Class Initialized
INFO - 2016-02-02 14:42:39 --> Language Class Initialized
INFO - 2016-02-02 14:42:39 --> Loader Class Initialized
INFO - 2016-02-02 14:42:39 --> Helper loaded: url_helper
INFO - 2016-02-02 14:42:39 --> Helper loaded: file_helper
INFO - 2016-02-02 14:42:39 --> Helper loaded: date_helper
INFO - 2016-02-02 14:42:39 --> Database Driver Class Initialized
INFO - 2016-02-02 14:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:42:40 --> Controller Class Initialized
INFO - 2016-02-02 14:42:40 --> Model Class Initialized
INFO - 2016-02-02 14:42:40 --> Model Class Initialized
INFO - 2016-02-02 14:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:42:40 --> Pagination Class Initialized
INFO - 2016-02-02 14:42:40 --> Config Class Initialized
INFO - 2016-02-02 14:42:40 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:42:40 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:42:40 --> Utf8 Class Initialized
INFO - 2016-02-02 14:42:40 --> URI Class Initialized
INFO - 2016-02-02 14:42:40 --> Router Class Initialized
INFO - 2016-02-02 14:42:40 --> Output Class Initialized
INFO - 2016-02-02 14:42:40 --> Security Class Initialized
DEBUG - 2016-02-02 14:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:42:40 --> Input Class Initialized
INFO - 2016-02-02 14:42:40 --> Language Class Initialized
INFO - 2016-02-02 14:42:40 --> Loader Class Initialized
INFO - 2016-02-02 14:42:40 --> Helper loaded: url_helper
INFO - 2016-02-02 14:42:40 --> Helper loaded: file_helper
INFO - 2016-02-02 14:42:40 --> Helper loaded: date_helper
INFO - 2016-02-02 14:42:40 --> Database Driver Class Initialized
INFO - 2016-02-02 14:42:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:42:41 --> Controller Class Initialized
INFO - 2016-02-02 14:42:41 --> Model Class Initialized
INFO - 2016-02-02 14:42:41 --> Model Class Initialized
INFO - 2016-02-02 14:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:42:41 --> Pagination Class Initialized
INFO - 2016-02-02 14:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:42:41 --> Helper loaded: text_helper
INFO - 2016-02-02 14:42:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:42:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:42:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:42:42 --> Final output sent to browser
DEBUG - 2016-02-02 14:42:42 --> Total execution time: 1.2463
INFO - 2016-02-02 14:43:11 --> Config Class Initialized
INFO - 2016-02-02 14:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:43:11 --> Utf8 Class Initialized
INFO - 2016-02-02 14:43:11 --> URI Class Initialized
INFO - 2016-02-02 14:43:11 --> Router Class Initialized
INFO - 2016-02-02 14:43:11 --> Output Class Initialized
INFO - 2016-02-02 14:43:11 --> Security Class Initialized
DEBUG - 2016-02-02 14:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:43:11 --> Input Class Initialized
INFO - 2016-02-02 14:43:11 --> Language Class Initialized
INFO - 2016-02-02 14:43:11 --> Loader Class Initialized
INFO - 2016-02-02 14:43:11 --> Helper loaded: url_helper
INFO - 2016-02-02 14:43:11 --> Helper loaded: file_helper
INFO - 2016-02-02 14:43:11 --> Helper loaded: date_helper
INFO - 2016-02-02 14:43:11 --> Database Driver Class Initialized
INFO - 2016-02-02 14:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:43:12 --> Controller Class Initialized
INFO - 2016-02-02 14:43:12 --> Model Class Initialized
INFO - 2016-02-02 14:43:12 --> Model Class Initialized
INFO - 2016-02-02 14:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:43:12 --> Pagination Class Initialized
INFO - 2016-02-02 14:43:12 --> Config Class Initialized
INFO - 2016-02-02 14:43:12 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:43:12 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:43:12 --> Utf8 Class Initialized
INFO - 2016-02-02 14:43:12 --> URI Class Initialized
INFO - 2016-02-02 14:43:12 --> Router Class Initialized
INFO - 2016-02-02 14:43:12 --> Output Class Initialized
INFO - 2016-02-02 14:43:12 --> Security Class Initialized
DEBUG - 2016-02-02 14:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:43:12 --> Input Class Initialized
INFO - 2016-02-02 14:43:12 --> Language Class Initialized
INFO - 2016-02-02 14:43:12 --> Loader Class Initialized
INFO - 2016-02-02 14:43:12 --> Helper loaded: url_helper
INFO - 2016-02-02 14:43:12 --> Helper loaded: file_helper
INFO - 2016-02-02 14:43:12 --> Helper loaded: date_helper
INFO - 2016-02-02 14:43:12 --> Database Driver Class Initialized
INFO - 2016-02-02 14:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:43:13 --> Controller Class Initialized
INFO - 2016-02-02 14:43:13 --> Model Class Initialized
INFO - 2016-02-02 14:43:13 --> Model Class Initialized
INFO - 2016-02-02 14:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:43:13 --> Pagination Class Initialized
INFO - 2016-02-02 14:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:43:13 --> Helper loaded: text_helper
INFO - 2016-02-02 14:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:43:13 --> Final output sent to browser
DEBUG - 2016-02-02 14:43:13 --> Total execution time: 1.2303
INFO - 2016-02-02 14:43:45 --> Config Class Initialized
INFO - 2016-02-02 14:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:43:45 --> Utf8 Class Initialized
INFO - 2016-02-02 14:43:45 --> URI Class Initialized
INFO - 2016-02-02 14:43:45 --> Router Class Initialized
INFO - 2016-02-02 14:43:45 --> Output Class Initialized
INFO - 2016-02-02 14:43:45 --> Security Class Initialized
DEBUG - 2016-02-02 14:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:43:45 --> Input Class Initialized
INFO - 2016-02-02 14:43:45 --> Language Class Initialized
INFO - 2016-02-02 14:43:45 --> Loader Class Initialized
INFO - 2016-02-02 14:43:45 --> Helper loaded: url_helper
INFO - 2016-02-02 14:43:45 --> Helper loaded: file_helper
INFO - 2016-02-02 14:43:45 --> Helper loaded: date_helper
INFO - 2016-02-02 14:43:45 --> Database Driver Class Initialized
INFO - 2016-02-02 14:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:43:46 --> Controller Class Initialized
INFO - 2016-02-02 14:43:46 --> Model Class Initialized
INFO - 2016-02-02 14:43:46 --> Model Class Initialized
INFO - 2016-02-02 14:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:43:46 --> Pagination Class Initialized
INFO - 2016-02-02 14:43:46 --> Config Class Initialized
INFO - 2016-02-02 14:43:46 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:43:46 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:43:46 --> Utf8 Class Initialized
INFO - 2016-02-02 14:43:46 --> URI Class Initialized
INFO - 2016-02-02 14:43:46 --> Router Class Initialized
INFO - 2016-02-02 14:43:46 --> Output Class Initialized
INFO - 2016-02-02 14:43:46 --> Security Class Initialized
DEBUG - 2016-02-02 14:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:43:46 --> Input Class Initialized
INFO - 2016-02-02 14:43:46 --> Language Class Initialized
INFO - 2016-02-02 14:43:46 --> Loader Class Initialized
INFO - 2016-02-02 14:43:46 --> Helper loaded: url_helper
INFO - 2016-02-02 14:43:46 --> Helper loaded: file_helper
INFO - 2016-02-02 14:43:46 --> Helper loaded: date_helper
INFO - 2016-02-02 14:43:46 --> Database Driver Class Initialized
INFO - 2016-02-02 14:43:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:43:47 --> Controller Class Initialized
INFO - 2016-02-02 14:43:47 --> Model Class Initialized
INFO - 2016-02-02 14:43:47 --> Model Class Initialized
INFO - 2016-02-02 14:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:43:47 --> Pagination Class Initialized
INFO - 2016-02-02 14:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:43:47 --> Helper loaded: text_helper
INFO - 2016-02-02 14:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 14:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 14:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 14:43:47 --> Final output sent to browser
DEBUG - 2016-02-02 14:43:47 --> Total execution time: 1.1545
INFO - 2016-02-02 14:46:02 --> Config Class Initialized
INFO - 2016-02-02 14:46:02 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:46:02 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:46:02 --> Utf8 Class Initialized
INFO - 2016-02-02 14:46:02 --> URI Class Initialized
INFO - 2016-02-02 14:46:02 --> Router Class Initialized
INFO - 2016-02-02 14:46:02 --> Output Class Initialized
INFO - 2016-02-02 14:46:02 --> Security Class Initialized
DEBUG - 2016-02-02 14:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:46:02 --> Input Class Initialized
INFO - 2016-02-02 14:46:02 --> Language Class Initialized
INFO - 2016-02-02 14:46:02 --> Loader Class Initialized
INFO - 2016-02-02 14:46:02 --> Helper loaded: url_helper
INFO - 2016-02-02 14:46:02 --> Helper loaded: file_helper
INFO - 2016-02-02 14:46:02 --> Helper loaded: date_helper
INFO - 2016-02-02 14:46:02 --> Database Driver Class Initialized
INFO - 2016-02-02 14:46:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:46:03 --> Controller Class Initialized
INFO - 2016-02-02 14:46:03 --> Model Class Initialized
INFO - 2016-02-02 14:46:03 --> Model Class Initialized
INFO - 2016-02-02 14:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:46:03 --> Pagination Class Initialized
INFO - 2016-02-02 14:46:04 --> Config Class Initialized
INFO - 2016-02-02 14:46:04 --> Hooks Class Initialized
DEBUG - 2016-02-02 14:46:04 --> UTF-8 Support Enabled
INFO - 2016-02-02 14:46:04 --> Utf8 Class Initialized
INFO - 2016-02-02 14:46:04 --> URI Class Initialized
INFO - 2016-02-02 14:46:04 --> Router Class Initialized
INFO - 2016-02-02 14:46:04 --> Output Class Initialized
INFO - 2016-02-02 14:46:04 --> Security Class Initialized
DEBUG - 2016-02-02 14:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 14:46:04 --> Input Class Initialized
INFO - 2016-02-02 14:46:04 --> Language Class Initialized
INFO - 2016-02-02 14:46:04 --> Loader Class Initialized
INFO - 2016-02-02 14:46:04 --> Helper loaded: url_helper
INFO - 2016-02-02 14:46:04 --> Helper loaded: file_helper
INFO - 2016-02-02 14:46:04 --> Helper loaded: date_helper
INFO - 2016-02-02 14:46:04 --> Database Driver Class Initialized
INFO - 2016-02-02 14:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 14:46:05 --> Controller Class Initialized
INFO - 2016-02-02 14:46:05 --> Model Class Initialized
INFO - 2016-02-02 14:46:05 --> Model Class Initialized
INFO - 2016-02-02 14:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 14:46:05 --> Pagination Class Initialized
INFO - 2016-02-02 14:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 14:46:05 --> Helper loaded: text_helper
ERROR - 2016-02-02 14:46:05 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 75
INFO - 2016-02-02 18:09:56 --> Config Class Initialized
INFO - 2016-02-02 18:09:56 --> Hooks Class Initialized
DEBUG - 2016-02-02 18:09:56 --> UTF-8 Support Enabled
INFO - 2016-02-02 18:09:56 --> Utf8 Class Initialized
INFO - 2016-02-02 18:09:56 --> URI Class Initialized
INFO - 2016-02-02 18:09:56 --> Router Class Initialized
INFO - 2016-02-02 18:09:56 --> Output Class Initialized
INFO - 2016-02-02 18:09:56 --> Security Class Initialized
DEBUG - 2016-02-02 18:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 18:09:56 --> Input Class Initialized
INFO - 2016-02-02 18:09:56 --> Language Class Initialized
INFO - 2016-02-02 18:09:56 --> Loader Class Initialized
INFO - 2016-02-02 18:09:56 --> Helper loaded: url_helper
INFO - 2016-02-02 18:09:56 --> Helper loaded: file_helper
INFO - 2016-02-02 18:09:56 --> Helper loaded: date_helper
INFO - 2016-02-02 18:09:56 --> Database Driver Class Initialized
INFO - 2016-02-02 18:09:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 18:09:57 --> Controller Class Initialized
INFO - 2016-02-02 18:09:57 --> Model Class Initialized
INFO - 2016-02-02 18:09:57 --> Model Class Initialized
INFO - 2016-02-02 18:09:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 18:09:57 --> Pagination Class Initialized
INFO - 2016-02-02 18:09:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 18:09:57 --> Helper loaded: text_helper
ERROR - 2016-02-02 18:09:57 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 75
INFO - 2016-02-02 18:40:52 --> Config Class Initialized
INFO - 2016-02-02 18:40:52 --> Hooks Class Initialized
DEBUG - 2016-02-02 18:40:52 --> UTF-8 Support Enabled
INFO - 2016-02-02 18:40:52 --> Utf8 Class Initialized
INFO - 2016-02-02 18:40:52 --> URI Class Initialized
INFO - 2016-02-02 18:40:52 --> Router Class Initialized
INFO - 2016-02-02 18:40:52 --> Output Class Initialized
INFO - 2016-02-02 18:40:52 --> Security Class Initialized
DEBUG - 2016-02-02 18:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 18:40:52 --> Input Class Initialized
INFO - 2016-02-02 18:40:52 --> Language Class Initialized
INFO - 2016-02-02 18:40:52 --> Loader Class Initialized
INFO - 2016-02-02 18:40:52 --> Helper loaded: url_helper
INFO - 2016-02-02 18:40:52 --> Helper loaded: file_helper
INFO - 2016-02-02 18:40:52 --> Helper loaded: date_helper
INFO - 2016-02-02 18:40:52 --> Database Driver Class Initialized
INFO - 2016-02-02 18:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 18:40:53 --> Controller Class Initialized
INFO - 2016-02-02 18:40:53 --> Model Class Initialized
INFO - 2016-02-02 18:40:53 --> Model Class Initialized
INFO - 2016-02-02 18:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 18:40:53 --> Pagination Class Initialized
INFO - 2016-02-02 18:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 18:40:53 --> Helper loaded: text_helper
ERROR - 2016-02-02 18:40:53 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 78
INFO - 2016-02-02 18:50:43 --> Config Class Initialized
INFO - 2016-02-02 18:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-02 18:50:43 --> UTF-8 Support Enabled
INFO - 2016-02-02 18:50:43 --> Utf8 Class Initialized
INFO - 2016-02-02 18:50:43 --> URI Class Initialized
INFO - 2016-02-02 18:50:43 --> Router Class Initialized
INFO - 2016-02-02 18:50:43 --> Output Class Initialized
INFO - 2016-02-02 18:50:43 --> Security Class Initialized
DEBUG - 2016-02-02 18:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 18:50:43 --> Input Class Initialized
INFO - 2016-02-02 18:50:43 --> Language Class Initialized
INFO - 2016-02-02 18:50:43 --> Loader Class Initialized
INFO - 2016-02-02 18:50:43 --> Helper loaded: url_helper
INFO - 2016-02-02 18:50:44 --> Helper loaded: file_helper
INFO - 2016-02-02 18:50:44 --> Helper loaded: date_helper
INFO - 2016-02-02 18:50:44 --> Database Driver Class Initialized
INFO - 2016-02-02 18:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-02 18:50:45 --> Controller Class Initialized
INFO - 2016-02-02 18:50:45 --> Model Class Initialized
INFO - 2016-02-02 18:50:45 --> Model Class Initialized
INFO - 2016-02-02 18:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-02 18:50:45 --> Pagination Class Initialized
INFO - 2016-02-02 18:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-02 18:50:45 --> Helper loaded: text_helper
ERROR - 2016-02-02 18:50:45 --> Severity: Notice --> Undefined index: result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 78
INFO - 2016-02-02 18:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-02 18:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-02 18:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-02 18:50:45 --> Final output sent to browser
DEBUG - 2016-02-02 18:50:45 --> Total execution time: 1.1405
INFO - 2016-02-02 19:05:08 --> Config Class Initialized
INFO - 2016-02-02 19:05:08 --> Hooks Class Initialized
DEBUG - 2016-02-02 19:05:08 --> UTF-8 Support Enabled
INFO - 2016-02-02 19:05:08 --> Utf8 Class Initialized
INFO - 2016-02-02 19:05:08 --> URI Class Initialized
INFO - 2016-02-02 19:05:08 --> Router Class Initialized
INFO - 2016-02-02 19:05:08 --> Output Class Initialized
INFO - 2016-02-02 19:05:08 --> Security Class Initialized
DEBUG - 2016-02-02 19:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 19:05:08 --> Input Class Initialized
INFO - 2016-02-02 19:05:08 --> Language Class Initialized
ERROR - 2016-02-02 19:05:08 --> 404 Page Not Found: Json/index
INFO - 2016-02-02 19:05:25 --> Config Class Initialized
INFO - 2016-02-02 19:05:25 --> Hooks Class Initialized
DEBUG - 2016-02-02 19:05:25 --> UTF-8 Support Enabled
INFO - 2016-02-02 19:05:25 --> Utf8 Class Initialized
INFO - 2016-02-02 19:05:25 --> URI Class Initialized
INFO - 2016-02-02 19:05:25 --> Router Class Initialized
INFO - 2016-02-02 19:05:25 --> Output Class Initialized
INFO - 2016-02-02 19:05:25 --> Security Class Initialized
DEBUG - 2016-02-02 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 19:05:25 --> Input Class Initialized
INFO - 2016-02-02 19:05:25 --> Language Class Initialized
ERROR - 2016-02-02 19:05:25 --> 404 Page Not Found: ListBeers/index
INFO - 2016-02-02 19:07:37 --> Config Class Initialized
INFO - 2016-02-02 19:07:37 --> Hooks Class Initialized
DEBUG - 2016-02-02 19:07:37 --> UTF-8 Support Enabled
INFO - 2016-02-02 19:07:37 --> Utf8 Class Initialized
INFO - 2016-02-02 19:07:37 --> URI Class Initialized
INFO - 2016-02-02 19:07:37 --> Router Class Initialized
INFO - 2016-02-02 19:07:37 --> Output Class Initialized
INFO - 2016-02-02 19:07:37 --> Security Class Initialized
DEBUG - 2016-02-02 19:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-02 19:07:37 --> Input Class Initialized
INFO - 2016-02-02 19:07:37 --> Language Class Initialized
ERROR - 2016-02-02 19:07:37 --> 404 Page Not Found: Json/index
