<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-27 08:21:23 --> Config Class Initialized
INFO - 2016-02-27 08:21:23 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:21:23 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:21:23 --> Utf8 Class Initialized
INFO - 2016-02-27 08:21:23 --> URI Class Initialized
DEBUG - 2016-02-27 08:21:23 --> No URI present. Default controller set.
INFO - 2016-02-27 08:21:23 --> Router Class Initialized
INFO - 2016-02-27 08:21:23 --> Output Class Initialized
INFO - 2016-02-27 08:21:23 --> Security Class Initialized
DEBUG - 2016-02-27 08:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:21:23 --> Input Class Initialized
INFO - 2016-02-27 08:21:23 --> Language Class Initialized
INFO - 2016-02-27 08:21:23 --> Loader Class Initialized
INFO - 2016-02-27 08:21:23 --> Helper loaded: url_helper
INFO - 2016-02-27 08:21:23 --> Helper loaded: file_helper
INFO - 2016-02-27 08:21:23 --> Helper loaded: date_helper
INFO - 2016-02-27 08:21:23 --> Helper loaded: form_helper
INFO - 2016-02-27 08:21:23 --> Database Driver Class Initialized
INFO - 2016-02-27 08:21:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:21:24 --> Controller Class Initialized
INFO - 2016-02-27 08:21:24 --> Model Class Initialized
INFO - 2016-02-27 08:21:24 --> Model Class Initialized
INFO - 2016-02-27 08:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:21:24 --> Pagination Class Initialized
INFO - 2016-02-27 08:21:24 --> Helper loaded: text_helper
INFO - 2016-02-27 08:21:24 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:21:24 --> Final output sent to browser
DEBUG - 2016-02-27 11:21:24 --> Total execution time: 1.1291
INFO - 2016-02-27 08:23:25 --> Config Class Initialized
INFO - 2016-02-27 08:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:23:25 --> Utf8 Class Initialized
INFO - 2016-02-27 08:23:25 --> URI Class Initialized
DEBUG - 2016-02-27 08:23:25 --> No URI present. Default controller set.
INFO - 2016-02-27 08:23:25 --> Router Class Initialized
INFO - 2016-02-27 08:23:25 --> Output Class Initialized
INFO - 2016-02-27 08:23:25 --> Security Class Initialized
DEBUG - 2016-02-27 08:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:23:25 --> Input Class Initialized
INFO - 2016-02-27 08:23:25 --> Language Class Initialized
INFO - 2016-02-27 08:23:25 --> Loader Class Initialized
INFO - 2016-02-27 08:23:25 --> Helper loaded: url_helper
INFO - 2016-02-27 08:23:25 --> Helper loaded: file_helper
INFO - 2016-02-27 08:23:25 --> Helper loaded: date_helper
INFO - 2016-02-27 08:23:25 --> Helper loaded: form_helper
INFO - 2016-02-27 08:23:25 --> Database Driver Class Initialized
INFO - 2016-02-27 08:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:23:26 --> Controller Class Initialized
INFO - 2016-02-27 08:23:26 --> Model Class Initialized
INFO - 2016-02-27 08:23:26 --> Model Class Initialized
INFO - 2016-02-27 08:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:23:26 --> Pagination Class Initialized
INFO - 2016-02-27 08:23:26 --> Helper loaded: text_helper
INFO - 2016-02-27 08:23:26 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:23:26 --> Final output sent to browser
DEBUG - 2016-02-27 11:23:26 --> Total execution time: 1.1245
INFO - 2016-02-27 08:23:33 --> Config Class Initialized
INFO - 2016-02-27 08:23:33 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:23:33 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:23:33 --> Utf8 Class Initialized
INFO - 2016-02-27 08:23:33 --> URI Class Initialized
INFO - 2016-02-27 08:23:33 --> Router Class Initialized
INFO - 2016-02-27 08:23:33 --> Output Class Initialized
INFO - 2016-02-27 08:23:33 --> Security Class Initialized
DEBUG - 2016-02-27 08:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:23:33 --> Input Class Initialized
INFO - 2016-02-27 08:23:33 --> Language Class Initialized
INFO - 2016-02-27 08:23:33 --> Loader Class Initialized
INFO - 2016-02-27 08:23:33 --> Helper loaded: url_helper
INFO - 2016-02-27 08:23:33 --> Helper loaded: file_helper
INFO - 2016-02-27 08:23:33 --> Helper loaded: date_helper
INFO - 2016-02-27 08:23:33 --> Helper loaded: form_helper
INFO - 2016-02-27 08:23:33 --> Database Driver Class Initialized
INFO - 2016-02-27 08:23:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:23:34 --> Controller Class Initialized
INFO - 2016-02-27 08:23:34 --> Model Class Initialized
INFO - 2016-02-27 08:23:34 --> Model Class Initialized
INFO - 2016-02-27 08:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:23:34 --> Pagination Class Initialized
INFO - 2016-02-27 08:23:34 --> Helper loaded: text_helper
INFO - 2016-02-27 08:23:34 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 11:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 11:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:23:34 --> Final output sent to browser
DEBUG - 2016-02-27 11:23:34 --> Total execution time: 1.1262
INFO - 2016-02-27 08:23:47 --> Config Class Initialized
INFO - 2016-02-27 08:23:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:23:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:23:47 --> Utf8 Class Initialized
INFO - 2016-02-27 08:23:47 --> URI Class Initialized
INFO - 2016-02-27 08:23:47 --> Router Class Initialized
INFO - 2016-02-27 08:23:47 --> Output Class Initialized
INFO - 2016-02-27 08:23:47 --> Security Class Initialized
DEBUG - 2016-02-27 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:23:47 --> Input Class Initialized
INFO - 2016-02-27 08:23:47 --> Language Class Initialized
INFO - 2016-02-27 08:23:47 --> Loader Class Initialized
INFO - 2016-02-27 08:23:47 --> Helper loaded: url_helper
INFO - 2016-02-27 08:23:47 --> Helper loaded: file_helper
INFO - 2016-02-27 08:23:47 --> Helper loaded: date_helper
INFO - 2016-02-27 08:23:47 --> Helper loaded: form_helper
INFO - 2016-02-27 08:23:47 --> Database Driver Class Initialized
INFO - 2016-02-27 08:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:23:48 --> Controller Class Initialized
INFO - 2016-02-27 08:23:48 --> Model Class Initialized
INFO - 2016-02-27 08:23:48 --> Model Class Initialized
INFO - 2016-02-27 08:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:23:48 --> Pagination Class Initialized
INFO - 2016-02-27 08:23:48 --> Helper loaded: text_helper
INFO - 2016-02-27 08:23:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 11:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:23:48 --> Final output sent to browser
DEBUG - 2016-02-27 11:23:48 --> Total execution time: 1.0880
INFO - 2016-02-27 08:24:33 --> Config Class Initialized
INFO - 2016-02-27 08:24:33 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:24:33 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:24:33 --> Utf8 Class Initialized
INFO - 2016-02-27 08:24:33 --> URI Class Initialized
DEBUG - 2016-02-27 08:24:33 --> No URI present. Default controller set.
INFO - 2016-02-27 08:24:33 --> Router Class Initialized
INFO - 2016-02-27 08:24:33 --> Output Class Initialized
INFO - 2016-02-27 08:24:33 --> Security Class Initialized
DEBUG - 2016-02-27 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:24:33 --> Input Class Initialized
INFO - 2016-02-27 08:24:33 --> Language Class Initialized
INFO - 2016-02-27 08:24:33 --> Loader Class Initialized
INFO - 2016-02-27 08:24:33 --> Helper loaded: url_helper
INFO - 2016-02-27 08:24:33 --> Helper loaded: file_helper
INFO - 2016-02-27 08:24:33 --> Helper loaded: date_helper
INFO - 2016-02-27 08:24:33 --> Helper loaded: form_helper
INFO - 2016-02-27 08:24:33 --> Database Driver Class Initialized
INFO - 2016-02-27 08:24:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:24:34 --> Controller Class Initialized
INFO - 2016-02-27 08:24:34 --> Model Class Initialized
INFO - 2016-02-27 08:24:34 --> Model Class Initialized
INFO - 2016-02-27 08:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:24:34 --> Pagination Class Initialized
INFO - 2016-02-27 08:24:34 --> Helper loaded: text_helper
INFO - 2016-02-27 08:24:34 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:24:34 --> Final output sent to browser
DEBUG - 2016-02-27 11:24:34 --> Total execution time: 1.1386
INFO - 2016-02-27 08:24:35 --> Config Class Initialized
INFO - 2016-02-27 08:24:35 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:24:35 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:24:35 --> Utf8 Class Initialized
INFO - 2016-02-27 08:24:35 --> URI Class Initialized
DEBUG - 2016-02-27 08:24:35 --> No URI present. Default controller set.
INFO - 2016-02-27 08:24:35 --> Router Class Initialized
INFO - 2016-02-27 08:24:35 --> Output Class Initialized
INFO - 2016-02-27 08:24:35 --> Security Class Initialized
DEBUG - 2016-02-27 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:24:35 --> Input Class Initialized
INFO - 2016-02-27 08:24:35 --> Language Class Initialized
INFO - 2016-02-27 08:24:35 --> Loader Class Initialized
INFO - 2016-02-27 08:24:35 --> Helper loaded: url_helper
INFO - 2016-02-27 08:24:35 --> Helper loaded: file_helper
INFO - 2016-02-27 08:24:35 --> Helper loaded: date_helper
INFO - 2016-02-27 08:24:35 --> Helper loaded: form_helper
INFO - 2016-02-27 08:24:35 --> Database Driver Class Initialized
INFO - 2016-02-27 08:24:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:24:36 --> Controller Class Initialized
INFO - 2016-02-27 08:24:36 --> Model Class Initialized
INFO - 2016-02-27 08:24:36 --> Model Class Initialized
INFO - 2016-02-27 08:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:24:36 --> Pagination Class Initialized
INFO - 2016-02-27 08:24:36 --> Helper loaded: text_helper
INFO - 2016-02-27 08:24:36 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:24:36 --> Final output sent to browser
DEBUG - 2016-02-27 11:24:36 --> Total execution time: 1.1126
INFO - 2016-02-27 08:24:47 --> Config Class Initialized
INFO - 2016-02-27 08:24:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:24:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:24:47 --> Utf8 Class Initialized
INFO - 2016-02-27 08:24:47 --> URI Class Initialized
DEBUG - 2016-02-27 08:24:47 --> No URI present. Default controller set.
INFO - 2016-02-27 08:24:47 --> Router Class Initialized
INFO - 2016-02-27 08:24:47 --> Output Class Initialized
INFO - 2016-02-27 08:24:47 --> Security Class Initialized
DEBUG - 2016-02-27 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:24:47 --> Input Class Initialized
INFO - 2016-02-27 08:24:47 --> Language Class Initialized
INFO - 2016-02-27 08:24:47 --> Loader Class Initialized
INFO - 2016-02-27 08:24:47 --> Helper loaded: url_helper
INFO - 2016-02-27 08:24:47 --> Helper loaded: file_helper
INFO - 2016-02-27 08:24:47 --> Helper loaded: date_helper
INFO - 2016-02-27 08:24:47 --> Helper loaded: form_helper
INFO - 2016-02-27 08:24:47 --> Database Driver Class Initialized
INFO - 2016-02-27 08:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:24:48 --> Controller Class Initialized
INFO - 2016-02-27 08:24:48 --> Model Class Initialized
INFO - 2016-02-27 08:24:48 --> Model Class Initialized
INFO - 2016-02-27 08:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:24:48 --> Pagination Class Initialized
INFO - 2016-02-27 08:24:48 --> Helper loaded: text_helper
INFO - 2016-02-27 08:24:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:24:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:24:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:24:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:24:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:24:48 --> Final output sent to browser
DEBUG - 2016-02-27 11:24:48 --> Total execution time: 1.1663
INFO - 2016-02-27 08:25:16 --> Config Class Initialized
INFO - 2016-02-27 08:25:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:25:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:25:16 --> Utf8 Class Initialized
INFO - 2016-02-27 08:25:16 --> URI Class Initialized
DEBUG - 2016-02-27 08:25:16 --> No URI present. Default controller set.
INFO - 2016-02-27 08:25:16 --> Router Class Initialized
INFO - 2016-02-27 08:25:16 --> Output Class Initialized
INFO - 2016-02-27 08:25:16 --> Security Class Initialized
DEBUG - 2016-02-27 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:25:16 --> Input Class Initialized
INFO - 2016-02-27 08:25:16 --> Language Class Initialized
INFO - 2016-02-27 08:25:16 --> Loader Class Initialized
INFO - 2016-02-27 08:25:16 --> Helper loaded: url_helper
INFO - 2016-02-27 08:25:16 --> Helper loaded: file_helper
INFO - 2016-02-27 08:25:16 --> Helper loaded: date_helper
INFO - 2016-02-27 08:25:16 --> Helper loaded: form_helper
INFO - 2016-02-27 08:25:16 --> Database Driver Class Initialized
INFO - 2016-02-27 08:25:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:25:17 --> Controller Class Initialized
INFO - 2016-02-27 08:25:17 --> Model Class Initialized
INFO - 2016-02-27 08:25:17 --> Model Class Initialized
INFO - 2016-02-27 08:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:25:17 --> Pagination Class Initialized
INFO - 2016-02-27 08:25:17 --> Helper loaded: text_helper
INFO - 2016-02-27 08:25:17 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:25:17 --> Final output sent to browser
DEBUG - 2016-02-27 11:25:17 --> Total execution time: 1.1936
INFO - 2016-02-27 08:25:27 --> Config Class Initialized
INFO - 2016-02-27 08:25:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:25:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:25:27 --> Utf8 Class Initialized
INFO - 2016-02-27 08:25:27 --> URI Class Initialized
INFO - 2016-02-27 08:25:27 --> Router Class Initialized
INFO - 2016-02-27 08:25:27 --> Output Class Initialized
INFO - 2016-02-27 08:25:27 --> Security Class Initialized
DEBUG - 2016-02-27 08:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:25:27 --> Input Class Initialized
INFO - 2016-02-27 08:25:27 --> Language Class Initialized
INFO - 2016-02-27 08:25:27 --> Loader Class Initialized
INFO - 2016-02-27 08:25:27 --> Helper loaded: url_helper
INFO - 2016-02-27 08:25:27 --> Helper loaded: file_helper
INFO - 2016-02-27 08:25:27 --> Helper loaded: date_helper
INFO - 2016-02-27 08:25:27 --> Helper loaded: form_helper
INFO - 2016-02-27 08:25:27 --> Database Driver Class Initialized
INFO - 2016-02-27 08:25:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:25:28 --> Controller Class Initialized
INFO - 2016-02-27 08:25:28 --> Model Class Initialized
INFO - 2016-02-27 08:25:28 --> Model Class Initialized
INFO - 2016-02-27 08:25:28 --> Form Validation Class Initialized
INFO - 2016-02-27 08:25:28 --> Helper loaded: text_helper
INFO - 2016-02-27 08:25:28 --> Final output sent to browser
DEBUG - 2016-02-27 08:25:28 --> Total execution time: 1.1568
INFO - 2016-02-27 08:27:11 --> Config Class Initialized
INFO - 2016-02-27 08:27:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:27:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:27:11 --> Utf8 Class Initialized
INFO - 2016-02-27 08:27:11 --> URI Class Initialized
DEBUG - 2016-02-27 08:27:11 --> No URI present. Default controller set.
INFO - 2016-02-27 08:27:11 --> Router Class Initialized
INFO - 2016-02-27 08:27:11 --> Output Class Initialized
INFO - 2016-02-27 08:27:11 --> Security Class Initialized
DEBUG - 2016-02-27 08:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:27:11 --> Input Class Initialized
INFO - 2016-02-27 08:27:11 --> Language Class Initialized
INFO - 2016-02-27 08:27:11 --> Loader Class Initialized
INFO - 2016-02-27 08:27:11 --> Helper loaded: url_helper
INFO - 2016-02-27 08:27:11 --> Helper loaded: file_helper
INFO - 2016-02-27 08:27:11 --> Helper loaded: date_helper
INFO - 2016-02-27 08:27:11 --> Helper loaded: form_helper
INFO - 2016-02-27 08:27:11 --> Database Driver Class Initialized
INFO - 2016-02-27 08:27:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:27:12 --> Controller Class Initialized
INFO - 2016-02-27 08:27:12 --> Model Class Initialized
INFO - 2016-02-27 08:27:12 --> Model Class Initialized
INFO - 2016-02-27 08:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:27:12 --> Pagination Class Initialized
INFO - 2016-02-27 08:27:12 --> Helper loaded: text_helper
INFO - 2016-02-27 08:27:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:27:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:27:12 --> Final output sent to browser
DEBUG - 2016-02-27 11:27:12 --> Total execution time: 1.0984
INFO - 2016-02-27 08:29:32 --> Config Class Initialized
INFO - 2016-02-27 08:29:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:29:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:29:32 --> Utf8 Class Initialized
INFO - 2016-02-27 08:29:32 --> URI Class Initialized
DEBUG - 2016-02-27 08:29:32 --> No URI present. Default controller set.
INFO - 2016-02-27 08:29:32 --> Router Class Initialized
INFO - 2016-02-27 08:29:32 --> Output Class Initialized
INFO - 2016-02-27 08:29:32 --> Security Class Initialized
DEBUG - 2016-02-27 08:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:29:32 --> Input Class Initialized
INFO - 2016-02-27 08:29:32 --> Language Class Initialized
INFO - 2016-02-27 08:29:32 --> Loader Class Initialized
INFO - 2016-02-27 08:29:32 --> Helper loaded: url_helper
INFO - 2016-02-27 08:29:32 --> Helper loaded: file_helper
INFO - 2016-02-27 08:29:32 --> Helper loaded: date_helper
INFO - 2016-02-27 08:29:32 --> Helper loaded: form_helper
INFO - 2016-02-27 08:29:32 --> Database Driver Class Initialized
INFO - 2016-02-27 08:29:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:29:34 --> Controller Class Initialized
INFO - 2016-02-27 08:29:34 --> Model Class Initialized
INFO - 2016-02-27 08:29:34 --> Model Class Initialized
INFO - 2016-02-27 08:29:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:29:34 --> Pagination Class Initialized
INFO - 2016-02-27 08:29:34 --> Helper loaded: text_helper
INFO - 2016-02-27 08:29:34 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:29:34 --> Final output sent to browser
DEBUG - 2016-02-27 11:29:34 --> Total execution time: 1.1329
INFO - 2016-02-27 08:31:27 --> Config Class Initialized
INFO - 2016-02-27 08:31:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:31:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:31:27 --> Utf8 Class Initialized
INFO - 2016-02-27 08:31:27 --> URI Class Initialized
DEBUG - 2016-02-27 08:31:27 --> No URI present. Default controller set.
INFO - 2016-02-27 08:31:27 --> Router Class Initialized
INFO - 2016-02-27 08:31:27 --> Output Class Initialized
INFO - 2016-02-27 08:31:27 --> Security Class Initialized
DEBUG - 2016-02-27 08:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:31:27 --> Input Class Initialized
INFO - 2016-02-27 08:31:27 --> Language Class Initialized
INFO - 2016-02-27 08:31:27 --> Loader Class Initialized
INFO - 2016-02-27 08:31:27 --> Helper loaded: url_helper
INFO - 2016-02-27 08:31:27 --> Helper loaded: file_helper
INFO - 2016-02-27 08:31:27 --> Helper loaded: date_helper
INFO - 2016-02-27 08:31:27 --> Helper loaded: form_helper
INFO - 2016-02-27 08:31:27 --> Database Driver Class Initialized
INFO - 2016-02-27 08:31:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:31:28 --> Controller Class Initialized
INFO - 2016-02-27 08:31:28 --> Model Class Initialized
INFO - 2016-02-27 08:31:28 --> Model Class Initialized
INFO - 2016-02-27 08:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:31:28 --> Pagination Class Initialized
INFO - 2016-02-27 08:31:28 --> Helper loaded: text_helper
INFO - 2016-02-27 08:31:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:31:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:31:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:31:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:31:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:31:28 --> Final output sent to browser
DEBUG - 2016-02-27 11:31:28 --> Total execution time: 1.1640
INFO - 2016-02-27 08:32:15 --> Config Class Initialized
INFO - 2016-02-27 08:32:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:32:15 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:32:15 --> Utf8 Class Initialized
INFO - 2016-02-27 08:32:15 --> URI Class Initialized
DEBUG - 2016-02-27 08:32:15 --> No URI present. Default controller set.
INFO - 2016-02-27 08:32:15 --> Router Class Initialized
INFO - 2016-02-27 08:32:15 --> Output Class Initialized
INFO - 2016-02-27 08:32:15 --> Security Class Initialized
DEBUG - 2016-02-27 08:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:32:15 --> Input Class Initialized
INFO - 2016-02-27 08:32:15 --> Language Class Initialized
INFO - 2016-02-27 08:32:15 --> Loader Class Initialized
INFO - 2016-02-27 08:32:15 --> Helper loaded: url_helper
INFO - 2016-02-27 08:32:15 --> Helper loaded: file_helper
INFO - 2016-02-27 08:32:15 --> Helper loaded: date_helper
INFO - 2016-02-27 08:32:15 --> Helper loaded: form_helper
INFO - 2016-02-27 08:32:15 --> Database Driver Class Initialized
INFO - 2016-02-27 08:32:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:32:16 --> Controller Class Initialized
INFO - 2016-02-27 08:32:16 --> Model Class Initialized
INFO - 2016-02-27 08:32:16 --> Model Class Initialized
INFO - 2016-02-27 08:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:32:16 --> Pagination Class Initialized
INFO - 2016-02-27 08:32:16 --> Helper loaded: text_helper
INFO - 2016-02-27 08:32:16 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:32:16 --> Final output sent to browser
DEBUG - 2016-02-27 11:32:16 --> Total execution time: 1.1485
INFO - 2016-02-27 08:39:32 --> Config Class Initialized
INFO - 2016-02-27 08:39:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:39:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:39:32 --> Utf8 Class Initialized
INFO - 2016-02-27 08:39:32 --> URI Class Initialized
DEBUG - 2016-02-27 08:39:32 --> No URI present. Default controller set.
INFO - 2016-02-27 08:39:32 --> Router Class Initialized
INFO - 2016-02-27 08:39:32 --> Output Class Initialized
INFO - 2016-02-27 08:39:32 --> Security Class Initialized
DEBUG - 2016-02-27 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:39:32 --> Input Class Initialized
INFO - 2016-02-27 08:39:32 --> Language Class Initialized
INFO - 2016-02-27 08:39:32 --> Loader Class Initialized
INFO - 2016-02-27 08:39:32 --> Helper loaded: url_helper
INFO - 2016-02-27 08:39:32 --> Helper loaded: file_helper
INFO - 2016-02-27 08:39:32 --> Helper loaded: date_helper
INFO - 2016-02-27 08:39:32 --> Helper loaded: form_helper
INFO - 2016-02-27 08:39:32 --> Database Driver Class Initialized
INFO - 2016-02-27 08:39:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:39:33 --> Controller Class Initialized
INFO - 2016-02-27 08:39:33 --> Model Class Initialized
INFO - 2016-02-27 08:39:33 --> Model Class Initialized
INFO - 2016-02-27 08:39:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:39:33 --> Pagination Class Initialized
INFO - 2016-02-27 08:39:33 --> Helper loaded: text_helper
INFO - 2016-02-27 08:39:33 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:39:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:39:33 --> Final output sent to browser
DEBUG - 2016-02-27 11:39:33 --> Total execution time: 1.2936
INFO - 2016-02-27 08:39:42 --> Config Class Initialized
INFO - 2016-02-27 08:39:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:39:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:39:42 --> Utf8 Class Initialized
INFO - 2016-02-27 08:39:42 --> URI Class Initialized
INFO - 2016-02-27 08:39:42 --> Router Class Initialized
INFO - 2016-02-27 08:39:42 --> Output Class Initialized
INFO - 2016-02-27 08:39:42 --> Security Class Initialized
DEBUG - 2016-02-27 08:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:39:42 --> Input Class Initialized
INFO - 2016-02-27 08:39:42 --> Language Class Initialized
INFO - 2016-02-27 08:39:42 --> Loader Class Initialized
INFO - 2016-02-27 08:39:42 --> Helper loaded: url_helper
INFO - 2016-02-27 08:39:42 --> Helper loaded: file_helper
INFO - 2016-02-27 08:39:42 --> Helper loaded: date_helper
INFO - 2016-02-27 08:39:42 --> Helper loaded: form_helper
INFO - 2016-02-27 08:39:42 --> Database Driver Class Initialized
INFO - 2016-02-27 08:39:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:39:43 --> Controller Class Initialized
INFO - 2016-02-27 08:39:43 --> Model Class Initialized
INFO - 2016-02-27 08:39:43 --> Model Class Initialized
INFO - 2016-02-27 08:39:43 --> Form Validation Class Initialized
INFO - 2016-02-27 08:39:43 --> Helper loaded: text_helper
INFO - 2016-02-27 08:39:43 --> Config Class Initialized
INFO - 2016-02-27 08:39:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:39:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:39:43 --> Utf8 Class Initialized
INFO - 2016-02-27 08:39:43 --> URI Class Initialized
DEBUG - 2016-02-27 08:39:43 --> No URI present. Default controller set.
INFO - 2016-02-27 08:39:43 --> Router Class Initialized
INFO - 2016-02-27 08:39:43 --> Output Class Initialized
INFO - 2016-02-27 08:39:43 --> Security Class Initialized
DEBUG - 2016-02-27 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:39:43 --> Input Class Initialized
INFO - 2016-02-27 08:39:43 --> Language Class Initialized
INFO - 2016-02-27 08:39:43 --> Loader Class Initialized
INFO - 2016-02-27 08:39:43 --> Helper loaded: url_helper
INFO - 2016-02-27 08:39:43 --> Helper loaded: file_helper
INFO - 2016-02-27 08:39:43 --> Helper loaded: date_helper
INFO - 2016-02-27 08:39:44 --> Helper loaded: form_helper
INFO - 2016-02-27 08:39:44 --> Database Driver Class Initialized
INFO - 2016-02-27 08:39:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:39:45 --> Controller Class Initialized
INFO - 2016-02-27 08:39:45 --> Model Class Initialized
INFO - 2016-02-27 08:39:45 --> Model Class Initialized
INFO - 2016-02-27 08:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:39:45 --> Pagination Class Initialized
INFO - 2016-02-27 08:39:45 --> Helper loaded: text_helper
INFO - 2016-02-27 08:39:45 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:39:45 --> Final output sent to browser
DEBUG - 2016-02-27 11:39:45 --> Total execution time: 1.1567
INFO - 2016-02-27 08:39:48 --> Config Class Initialized
INFO - 2016-02-27 08:39:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:39:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:39:48 --> Utf8 Class Initialized
INFO - 2016-02-27 08:39:48 --> URI Class Initialized
INFO - 2016-02-27 08:39:48 --> Router Class Initialized
INFO - 2016-02-27 08:39:48 --> Output Class Initialized
INFO - 2016-02-27 08:39:48 --> Security Class Initialized
DEBUG - 2016-02-27 08:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:39:48 --> Input Class Initialized
INFO - 2016-02-27 08:39:48 --> Language Class Initialized
INFO - 2016-02-27 08:39:48 --> Loader Class Initialized
INFO - 2016-02-27 08:39:48 --> Helper loaded: url_helper
INFO - 2016-02-27 08:39:48 --> Helper loaded: file_helper
INFO - 2016-02-27 08:39:48 --> Helper loaded: date_helper
INFO - 2016-02-27 08:39:48 --> Helper loaded: form_helper
INFO - 2016-02-27 08:39:48 --> Database Driver Class Initialized
INFO - 2016-02-27 08:39:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:39:49 --> Controller Class Initialized
INFO - 2016-02-27 08:39:49 --> Model Class Initialized
INFO - 2016-02-27 08:39:49 --> Model Class Initialized
INFO - 2016-02-27 08:39:49 --> Form Validation Class Initialized
INFO - 2016-02-27 08:39:49 --> Helper loaded: text_helper
INFO - 2016-02-27 08:39:49 --> Config Class Initialized
INFO - 2016-02-27 08:39:49 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:39:49 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:39:49 --> Utf8 Class Initialized
INFO - 2016-02-27 08:39:49 --> URI Class Initialized
DEBUG - 2016-02-27 08:39:49 --> No URI present. Default controller set.
INFO - 2016-02-27 08:39:49 --> Router Class Initialized
INFO - 2016-02-27 08:39:49 --> Output Class Initialized
INFO - 2016-02-27 08:39:49 --> Security Class Initialized
DEBUG - 2016-02-27 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:39:49 --> Input Class Initialized
INFO - 2016-02-27 08:39:49 --> Language Class Initialized
INFO - 2016-02-27 08:39:49 --> Loader Class Initialized
INFO - 2016-02-27 08:39:49 --> Helper loaded: url_helper
INFO - 2016-02-27 08:39:49 --> Helper loaded: file_helper
INFO - 2016-02-27 08:39:49 --> Helper loaded: date_helper
INFO - 2016-02-27 08:39:49 --> Helper loaded: form_helper
INFO - 2016-02-27 08:39:49 --> Database Driver Class Initialized
INFO - 2016-02-27 08:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:39:50 --> Controller Class Initialized
INFO - 2016-02-27 08:39:50 --> Model Class Initialized
INFO - 2016-02-27 08:39:50 --> Model Class Initialized
INFO - 2016-02-27 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:39:50 --> Pagination Class Initialized
INFO - 2016-02-27 08:39:50 --> Helper loaded: text_helper
INFO - 2016-02-27 08:39:50 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:39:50 --> Final output sent to browser
DEBUG - 2016-02-27 11:39:50 --> Total execution time: 1.2158
INFO - 2016-02-27 08:40:31 --> Config Class Initialized
INFO - 2016-02-27 08:40:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:40:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:40:31 --> Utf8 Class Initialized
INFO - 2016-02-27 08:40:31 --> URI Class Initialized
DEBUG - 2016-02-27 08:40:31 --> No URI present. Default controller set.
INFO - 2016-02-27 08:40:31 --> Router Class Initialized
INFO - 2016-02-27 08:40:31 --> Output Class Initialized
INFO - 2016-02-27 08:40:31 --> Security Class Initialized
DEBUG - 2016-02-27 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:40:31 --> Input Class Initialized
INFO - 2016-02-27 08:40:31 --> Language Class Initialized
INFO - 2016-02-27 08:40:31 --> Loader Class Initialized
INFO - 2016-02-27 08:40:31 --> Helper loaded: url_helper
INFO - 2016-02-27 08:40:31 --> Helper loaded: file_helper
INFO - 2016-02-27 08:40:31 --> Helper loaded: date_helper
INFO - 2016-02-27 08:40:31 --> Helper loaded: form_helper
INFO - 2016-02-27 08:40:31 --> Database Driver Class Initialized
INFO - 2016-02-27 08:40:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:40:32 --> Controller Class Initialized
INFO - 2016-02-27 08:40:32 --> Model Class Initialized
INFO - 2016-02-27 08:40:32 --> Model Class Initialized
INFO - 2016-02-27 08:40:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:40:32 --> Pagination Class Initialized
INFO - 2016-02-27 08:40:32 --> Helper loaded: text_helper
INFO - 2016-02-27 08:40:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:40:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:40:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:40:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:40:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:40:32 --> Final output sent to browser
DEBUG - 2016-02-27 11:40:32 --> Total execution time: 1.1588
INFO - 2016-02-27 08:40:35 --> Config Class Initialized
INFO - 2016-02-27 08:40:35 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:40:35 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:40:35 --> Utf8 Class Initialized
INFO - 2016-02-27 08:40:35 --> URI Class Initialized
INFO - 2016-02-27 08:40:35 --> Router Class Initialized
INFO - 2016-02-27 08:40:35 --> Output Class Initialized
INFO - 2016-02-27 08:40:35 --> Security Class Initialized
DEBUG - 2016-02-27 08:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:40:35 --> Input Class Initialized
INFO - 2016-02-27 08:40:35 --> Language Class Initialized
INFO - 2016-02-27 08:40:35 --> Loader Class Initialized
INFO - 2016-02-27 08:40:35 --> Helper loaded: url_helper
INFO - 2016-02-27 08:40:35 --> Helper loaded: file_helper
INFO - 2016-02-27 08:40:35 --> Helper loaded: date_helper
INFO - 2016-02-27 08:40:35 --> Helper loaded: form_helper
INFO - 2016-02-27 08:40:35 --> Database Driver Class Initialized
INFO - 2016-02-27 08:40:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:40:36 --> Controller Class Initialized
INFO - 2016-02-27 08:40:36 --> Model Class Initialized
INFO - 2016-02-27 08:40:36 --> Model Class Initialized
INFO - 2016-02-27 08:40:36 --> Form Validation Class Initialized
INFO - 2016-02-27 08:40:36 --> Helper loaded: text_helper
INFO - 2016-02-27 08:40:36 --> Final output sent to browser
DEBUG - 2016-02-27 08:40:36 --> Total execution time: 1.1255
INFO - 2016-02-27 08:40:37 --> Config Class Initialized
INFO - 2016-02-27 08:40:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:40:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:40:37 --> Utf8 Class Initialized
INFO - 2016-02-27 08:40:37 --> URI Class Initialized
DEBUG - 2016-02-27 08:40:37 --> No URI present. Default controller set.
INFO - 2016-02-27 08:40:37 --> Router Class Initialized
INFO - 2016-02-27 08:40:37 --> Output Class Initialized
INFO - 2016-02-27 08:40:37 --> Security Class Initialized
DEBUG - 2016-02-27 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:40:38 --> Input Class Initialized
INFO - 2016-02-27 08:40:38 --> Language Class Initialized
INFO - 2016-02-27 08:40:38 --> Loader Class Initialized
INFO - 2016-02-27 08:40:38 --> Helper loaded: url_helper
INFO - 2016-02-27 08:40:38 --> Helper loaded: file_helper
INFO - 2016-02-27 08:40:38 --> Helper loaded: date_helper
INFO - 2016-02-27 08:40:38 --> Helper loaded: form_helper
INFO - 2016-02-27 08:40:38 --> Database Driver Class Initialized
INFO - 2016-02-27 08:40:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:40:39 --> Controller Class Initialized
INFO - 2016-02-27 08:40:39 --> Model Class Initialized
INFO - 2016-02-27 08:40:39 --> Model Class Initialized
INFO - 2016-02-27 08:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:40:39 --> Pagination Class Initialized
INFO - 2016-02-27 08:40:39 --> Helper loaded: text_helper
INFO - 2016-02-27 08:40:39 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:40:39 --> Final output sent to browser
DEBUG - 2016-02-27 11:40:39 --> Total execution time: 1.1458
INFO - 2016-02-27 08:41:14 --> Config Class Initialized
INFO - 2016-02-27 08:41:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:41:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:41:14 --> Utf8 Class Initialized
INFO - 2016-02-27 08:41:14 --> URI Class Initialized
DEBUG - 2016-02-27 08:41:14 --> No URI present. Default controller set.
INFO - 2016-02-27 08:41:14 --> Router Class Initialized
INFO - 2016-02-27 08:41:14 --> Output Class Initialized
INFO - 2016-02-27 08:41:14 --> Security Class Initialized
DEBUG - 2016-02-27 08:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:41:14 --> Input Class Initialized
INFO - 2016-02-27 08:41:14 --> Language Class Initialized
INFO - 2016-02-27 08:41:14 --> Loader Class Initialized
INFO - 2016-02-27 08:41:14 --> Helper loaded: url_helper
INFO - 2016-02-27 08:41:14 --> Helper loaded: file_helper
INFO - 2016-02-27 08:41:14 --> Helper loaded: date_helper
INFO - 2016-02-27 08:41:14 --> Helper loaded: form_helper
INFO - 2016-02-27 08:41:14 --> Database Driver Class Initialized
INFO - 2016-02-27 08:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:41:15 --> Controller Class Initialized
INFO - 2016-02-27 08:41:15 --> Model Class Initialized
INFO - 2016-02-27 08:41:15 --> Model Class Initialized
INFO - 2016-02-27 08:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:41:15 --> Pagination Class Initialized
INFO - 2016-02-27 08:41:15 --> Helper loaded: text_helper
INFO - 2016-02-27 08:41:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:41:15 --> Final output sent to browser
DEBUG - 2016-02-27 11:41:15 --> Total execution time: 1.1149
INFO - 2016-02-27 08:41:17 --> Config Class Initialized
INFO - 2016-02-27 08:41:17 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:41:17 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:41:17 --> Utf8 Class Initialized
INFO - 2016-02-27 08:41:17 --> URI Class Initialized
INFO - 2016-02-27 08:41:17 --> Router Class Initialized
INFO - 2016-02-27 08:41:17 --> Output Class Initialized
INFO - 2016-02-27 08:41:17 --> Security Class Initialized
DEBUG - 2016-02-27 08:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:41:17 --> Input Class Initialized
INFO - 2016-02-27 08:41:17 --> Language Class Initialized
INFO - 2016-02-27 08:41:17 --> Loader Class Initialized
INFO - 2016-02-27 08:41:17 --> Helper loaded: url_helper
INFO - 2016-02-27 08:41:17 --> Helper loaded: file_helper
INFO - 2016-02-27 08:41:17 --> Helper loaded: date_helper
INFO - 2016-02-27 08:41:17 --> Helper loaded: form_helper
INFO - 2016-02-27 08:41:17 --> Database Driver Class Initialized
INFO - 2016-02-27 08:41:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:41:18 --> Controller Class Initialized
INFO - 2016-02-27 08:41:18 --> Model Class Initialized
INFO - 2016-02-27 08:41:18 --> Model Class Initialized
INFO - 2016-02-27 08:41:18 --> Form Validation Class Initialized
INFO - 2016-02-27 08:41:18 --> Helper loaded: text_helper
INFO - 2016-02-27 08:41:18 --> Config Class Initialized
INFO - 2016-02-27 08:41:18 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:41:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:41:19 --> Utf8 Class Initialized
INFO - 2016-02-27 08:41:19 --> URI Class Initialized
DEBUG - 2016-02-27 08:41:19 --> No URI present. Default controller set.
INFO - 2016-02-27 08:41:19 --> Router Class Initialized
INFO - 2016-02-27 08:41:19 --> Output Class Initialized
INFO - 2016-02-27 08:41:19 --> Security Class Initialized
DEBUG - 2016-02-27 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:41:19 --> Input Class Initialized
INFO - 2016-02-27 08:41:19 --> Language Class Initialized
INFO - 2016-02-27 08:41:19 --> Loader Class Initialized
INFO - 2016-02-27 08:41:19 --> Helper loaded: url_helper
INFO - 2016-02-27 08:41:19 --> Helper loaded: file_helper
INFO - 2016-02-27 08:41:19 --> Helper loaded: date_helper
INFO - 2016-02-27 08:41:19 --> Helper loaded: form_helper
INFO - 2016-02-27 08:41:19 --> Database Driver Class Initialized
INFO - 2016-02-27 08:41:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:41:20 --> Controller Class Initialized
INFO - 2016-02-27 08:41:20 --> Model Class Initialized
INFO - 2016-02-27 08:41:20 --> Model Class Initialized
INFO - 2016-02-27 08:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:41:20 --> Pagination Class Initialized
INFO - 2016-02-27 08:41:20 --> Helper loaded: text_helper
INFO - 2016-02-27 08:41:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:41:20 --> Final output sent to browser
DEBUG - 2016-02-27 11:41:20 --> Total execution time: 1.1810
INFO - 2016-02-27 08:41:52 --> Config Class Initialized
INFO - 2016-02-27 08:41:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:41:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:41:52 --> Utf8 Class Initialized
INFO - 2016-02-27 08:41:52 --> URI Class Initialized
INFO - 2016-02-27 08:41:52 --> Router Class Initialized
INFO - 2016-02-27 08:41:52 --> Output Class Initialized
INFO - 2016-02-27 08:41:52 --> Security Class Initialized
DEBUG - 2016-02-27 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:41:52 --> Input Class Initialized
INFO - 2016-02-27 08:41:52 --> Language Class Initialized
INFO - 2016-02-27 08:41:52 --> Loader Class Initialized
INFO - 2016-02-27 08:41:52 --> Helper loaded: url_helper
INFO - 2016-02-27 08:41:52 --> Helper loaded: file_helper
INFO - 2016-02-27 08:41:52 --> Helper loaded: date_helper
INFO - 2016-02-27 08:41:52 --> Helper loaded: form_helper
INFO - 2016-02-27 08:41:52 --> Database Driver Class Initialized
INFO - 2016-02-27 08:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:41:53 --> Controller Class Initialized
INFO - 2016-02-27 08:41:53 --> Model Class Initialized
INFO - 2016-02-27 08:41:53 --> Model Class Initialized
INFO - 2016-02-27 08:41:53 --> Form Validation Class Initialized
INFO - 2016-02-27 08:41:53 --> Helper loaded: text_helper
INFO - 2016-02-27 08:41:53 --> Config Class Initialized
INFO - 2016-02-27 08:41:53 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:41:53 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:41:53 --> Utf8 Class Initialized
INFO - 2016-02-27 08:41:53 --> URI Class Initialized
DEBUG - 2016-02-27 08:41:53 --> No URI present. Default controller set.
INFO - 2016-02-27 08:41:53 --> Router Class Initialized
INFO - 2016-02-27 08:41:53 --> Output Class Initialized
INFO - 2016-02-27 08:41:53 --> Security Class Initialized
DEBUG - 2016-02-27 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:41:53 --> Input Class Initialized
INFO - 2016-02-27 08:41:53 --> Language Class Initialized
INFO - 2016-02-27 08:41:53 --> Loader Class Initialized
INFO - 2016-02-27 08:41:53 --> Helper loaded: url_helper
INFO - 2016-02-27 08:41:53 --> Helper loaded: file_helper
INFO - 2016-02-27 08:41:53 --> Helper loaded: date_helper
INFO - 2016-02-27 08:41:53 --> Helper loaded: form_helper
INFO - 2016-02-27 08:41:53 --> Database Driver Class Initialized
INFO - 2016-02-27 08:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:41:54 --> Controller Class Initialized
INFO - 2016-02-27 08:41:54 --> Model Class Initialized
INFO - 2016-02-27 08:41:55 --> Model Class Initialized
INFO - 2016-02-27 08:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:41:55 --> Pagination Class Initialized
INFO - 2016-02-27 08:41:55 --> Helper loaded: text_helper
INFO - 2016-02-27 08:41:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:41:55 --> Final output sent to browser
DEBUG - 2016-02-27 11:41:55 --> Total execution time: 1.1663
INFO - 2016-02-27 08:52:57 --> Config Class Initialized
INFO - 2016-02-27 08:52:57 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:52:57 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:52:57 --> Utf8 Class Initialized
INFO - 2016-02-27 08:52:57 --> URI Class Initialized
DEBUG - 2016-02-27 08:52:57 --> No URI present. Default controller set.
INFO - 2016-02-27 08:52:57 --> Router Class Initialized
INFO - 2016-02-27 08:52:57 --> Output Class Initialized
INFO - 2016-02-27 08:52:57 --> Security Class Initialized
DEBUG - 2016-02-27 08:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:52:57 --> Input Class Initialized
INFO - 2016-02-27 08:52:57 --> Language Class Initialized
INFO - 2016-02-27 08:52:57 --> Loader Class Initialized
INFO - 2016-02-27 08:52:57 --> Helper loaded: url_helper
INFO - 2016-02-27 08:52:57 --> Helper loaded: file_helper
INFO - 2016-02-27 08:52:57 --> Helper loaded: date_helper
INFO - 2016-02-27 08:52:57 --> Helper loaded: form_helper
INFO - 2016-02-27 08:52:57 --> Database Driver Class Initialized
INFO - 2016-02-27 08:52:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:52:58 --> Controller Class Initialized
INFO - 2016-02-27 08:52:58 --> Model Class Initialized
INFO - 2016-02-27 08:52:58 --> Model Class Initialized
INFO - 2016-02-27 08:52:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:52:58 --> Pagination Class Initialized
INFO - 2016-02-27 08:52:58 --> Helper loaded: text_helper
INFO - 2016-02-27 08:52:58 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:52:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:52:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:52:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:52:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:52:58 --> Final output sent to browser
DEBUG - 2016-02-27 11:52:58 --> Total execution time: 1.1410
INFO - 2016-02-27 08:53:00 --> Config Class Initialized
INFO - 2016-02-27 08:53:00 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:53:00 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:53:00 --> Utf8 Class Initialized
INFO - 2016-02-27 08:53:00 --> URI Class Initialized
INFO - 2016-02-27 08:53:00 --> Router Class Initialized
INFO - 2016-02-27 08:53:00 --> Output Class Initialized
INFO - 2016-02-27 08:53:00 --> Security Class Initialized
DEBUG - 2016-02-27 08:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:53:00 --> Input Class Initialized
INFO - 2016-02-27 08:53:00 --> Language Class Initialized
INFO - 2016-02-27 08:53:00 --> Loader Class Initialized
INFO - 2016-02-27 08:53:00 --> Helper loaded: url_helper
INFO - 2016-02-27 08:53:00 --> Helper loaded: file_helper
INFO - 2016-02-27 08:53:00 --> Helper loaded: date_helper
INFO - 2016-02-27 08:53:00 --> Helper loaded: form_helper
INFO - 2016-02-27 08:53:00 --> Database Driver Class Initialized
INFO - 2016-02-27 08:53:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:53:01 --> Controller Class Initialized
INFO - 2016-02-27 08:53:01 --> Model Class Initialized
INFO - 2016-02-27 08:53:01 --> Model Class Initialized
INFO - 2016-02-27 08:53:01 --> Form Validation Class Initialized
INFO - 2016-02-27 08:53:01 --> Helper loaded: text_helper
INFO - 2016-02-27 08:53:02 --> Config Class Initialized
INFO - 2016-02-27 08:53:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 08:53:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 08:53:02 --> Utf8 Class Initialized
INFO - 2016-02-27 08:53:02 --> URI Class Initialized
DEBUG - 2016-02-27 08:53:02 --> No URI present. Default controller set.
INFO - 2016-02-27 08:53:02 --> Router Class Initialized
INFO - 2016-02-27 08:53:02 --> Output Class Initialized
INFO - 2016-02-27 08:53:02 --> Security Class Initialized
DEBUG - 2016-02-27 08:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 08:53:02 --> Input Class Initialized
INFO - 2016-02-27 08:53:02 --> Language Class Initialized
INFO - 2016-02-27 08:53:02 --> Loader Class Initialized
INFO - 2016-02-27 08:53:02 --> Helper loaded: url_helper
INFO - 2016-02-27 08:53:02 --> Helper loaded: file_helper
INFO - 2016-02-27 08:53:02 --> Helper loaded: date_helper
INFO - 2016-02-27 08:53:02 --> Helper loaded: form_helper
INFO - 2016-02-27 08:53:02 --> Database Driver Class Initialized
INFO - 2016-02-27 08:53:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 08:53:03 --> Controller Class Initialized
INFO - 2016-02-27 08:53:03 --> Model Class Initialized
INFO - 2016-02-27 08:53:03 --> Model Class Initialized
INFO - 2016-02-27 08:53:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 08:53:03 --> Pagination Class Initialized
INFO - 2016-02-27 08:53:03 --> Helper loaded: text_helper
INFO - 2016-02-27 08:53:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 11:53:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:53:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:53:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 11:53:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 11:53:03 --> Final output sent to browser
DEBUG - 2016-02-27 11:53:03 --> Total execution time: 1.1562
INFO - 2016-02-27 09:08:09 --> Config Class Initialized
INFO - 2016-02-27 09:08:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:08:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:08:09 --> Utf8 Class Initialized
INFO - 2016-02-27 09:08:09 --> URI Class Initialized
DEBUG - 2016-02-27 09:08:09 --> No URI present. Default controller set.
INFO - 2016-02-27 09:08:09 --> Router Class Initialized
INFO - 2016-02-27 09:08:09 --> Output Class Initialized
INFO - 2016-02-27 09:08:09 --> Security Class Initialized
DEBUG - 2016-02-27 09:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:08:09 --> Input Class Initialized
INFO - 2016-02-27 09:08:09 --> Language Class Initialized
INFO - 2016-02-27 09:08:09 --> Loader Class Initialized
INFO - 2016-02-27 09:08:09 --> Helper loaded: url_helper
INFO - 2016-02-27 09:08:09 --> Helper loaded: file_helper
INFO - 2016-02-27 09:08:09 --> Helper loaded: date_helper
INFO - 2016-02-27 09:08:09 --> Helper loaded: form_helper
INFO - 2016-02-27 09:08:09 --> Database Driver Class Initialized
INFO - 2016-02-27 09:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:08:10 --> Controller Class Initialized
INFO - 2016-02-27 09:08:10 --> Model Class Initialized
INFO - 2016-02-27 09:08:10 --> Model Class Initialized
INFO - 2016-02-27 09:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:08:10 --> Pagination Class Initialized
INFO - 2016-02-27 09:08:10 --> Helper loaded: text_helper
INFO - 2016-02-27 09:08:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:08:10 --> Final output sent to browser
DEBUG - 2016-02-27 12:08:10 --> Total execution time: 1.1161
INFO - 2016-02-27 09:08:19 --> Config Class Initialized
INFO - 2016-02-27 09:08:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:08:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:08:19 --> Utf8 Class Initialized
INFO - 2016-02-27 09:08:19 --> URI Class Initialized
INFO - 2016-02-27 09:08:19 --> Router Class Initialized
INFO - 2016-02-27 09:08:19 --> Output Class Initialized
INFO - 2016-02-27 09:08:19 --> Security Class Initialized
DEBUG - 2016-02-27 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:08:19 --> Input Class Initialized
INFO - 2016-02-27 09:08:19 --> Language Class Initialized
INFO - 2016-02-27 09:08:19 --> Loader Class Initialized
INFO - 2016-02-27 09:08:19 --> Helper loaded: url_helper
INFO - 2016-02-27 09:08:19 --> Helper loaded: file_helper
INFO - 2016-02-27 09:08:19 --> Helper loaded: date_helper
INFO - 2016-02-27 09:08:19 --> Helper loaded: form_helper
INFO - 2016-02-27 09:08:19 --> Database Driver Class Initialized
INFO - 2016-02-27 09:08:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:08:20 --> Controller Class Initialized
INFO - 2016-02-27 09:08:20 --> Model Class Initialized
INFO - 2016-02-27 09:08:20 --> Model Class Initialized
INFO - 2016-02-27 09:08:20 --> Form Validation Class Initialized
INFO - 2016-02-27 09:08:20 --> Helper loaded: text_helper
ERROR - 2016-02-27 09:08:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-27 09:08:20 --> Config Class Initialized
INFO - 2016-02-27 09:08:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:08:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:08:20 --> Utf8 Class Initialized
INFO - 2016-02-27 09:08:20 --> URI Class Initialized
DEBUG - 2016-02-27 09:08:20 --> No URI present. Default controller set.
INFO - 2016-02-27 09:08:20 --> Router Class Initialized
INFO - 2016-02-27 09:08:20 --> Output Class Initialized
INFO - 2016-02-27 09:08:20 --> Security Class Initialized
DEBUG - 2016-02-27 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:08:20 --> Input Class Initialized
INFO - 2016-02-27 09:08:20 --> Language Class Initialized
INFO - 2016-02-27 09:08:20 --> Loader Class Initialized
INFO - 2016-02-27 09:08:20 --> Helper loaded: url_helper
INFO - 2016-02-27 09:08:20 --> Helper loaded: file_helper
INFO - 2016-02-27 09:08:20 --> Helper loaded: date_helper
INFO - 2016-02-27 09:08:20 --> Helper loaded: form_helper
INFO - 2016-02-27 09:08:20 --> Database Driver Class Initialized
INFO - 2016-02-27 09:08:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:08:21 --> Controller Class Initialized
INFO - 2016-02-27 09:08:21 --> Model Class Initialized
INFO - 2016-02-27 09:08:21 --> Model Class Initialized
INFO - 2016-02-27 09:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:08:21 --> Pagination Class Initialized
INFO - 2016-02-27 09:08:21 --> Helper loaded: text_helper
INFO - 2016-02-27 09:08:21 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:08:21 --> Final output sent to browser
DEBUG - 2016-02-27 12:08:21 --> Total execution time: 1.1581
INFO - 2016-02-27 09:10:48 --> Config Class Initialized
INFO - 2016-02-27 09:10:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:10:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:10:48 --> Utf8 Class Initialized
INFO - 2016-02-27 09:10:48 --> URI Class Initialized
DEBUG - 2016-02-27 09:10:48 --> No URI present. Default controller set.
INFO - 2016-02-27 09:10:48 --> Router Class Initialized
INFO - 2016-02-27 09:10:48 --> Output Class Initialized
INFO - 2016-02-27 09:10:48 --> Security Class Initialized
DEBUG - 2016-02-27 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:10:48 --> Input Class Initialized
INFO - 2016-02-27 09:10:48 --> Language Class Initialized
INFO - 2016-02-27 09:10:48 --> Loader Class Initialized
INFO - 2016-02-27 09:10:48 --> Helper loaded: url_helper
INFO - 2016-02-27 09:10:48 --> Helper loaded: file_helper
INFO - 2016-02-27 09:10:48 --> Helper loaded: date_helper
INFO - 2016-02-27 09:10:48 --> Helper loaded: form_helper
INFO - 2016-02-27 09:10:48 --> Database Driver Class Initialized
INFO - 2016-02-27 09:10:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:10:50 --> Controller Class Initialized
INFO - 2016-02-27 09:10:50 --> Model Class Initialized
INFO - 2016-02-27 09:10:50 --> Model Class Initialized
INFO - 2016-02-27 09:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:10:50 --> Pagination Class Initialized
INFO - 2016-02-27 09:10:50 --> Helper loaded: text_helper
INFO - 2016-02-27 09:10:50 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:10:50 --> Final output sent to browser
DEBUG - 2016-02-27 12:10:50 --> Total execution time: 1.1925
INFO - 2016-02-27 09:11:29 --> Config Class Initialized
INFO - 2016-02-27 09:11:29 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:11:29 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:11:29 --> Utf8 Class Initialized
INFO - 2016-02-27 09:11:29 --> URI Class Initialized
INFO - 2016-02-27 09:11:29 --> Router Class Initialized
INFO - 2016-02-27 09:11:29 --> Output Class Initialized
INFO - 2016-02-27 09:11:29 --> Security Class Initialized
DEBUG - 2016-02-27 09:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:11:29 --> Input Class Initialized
INFO - 2016-02-27 09:11:29 --> Language Class Initialized
INFO - 2016-02-27 09:11:29 --> Loader Class Initialized
INFO - 2016-02-27 09:11:29 --> Helper loaded: url_helper
INFO - 2016-02-27 09:11:29 --> Helper loaded: file_helper
INFO - 2016-02-27 09:11:29 --> Helper loaded: date_helper
INFO - 2016-02-27 09:11:29 --> Helper loaded: form_helper
INFO - 2016-02-27 09:11:29 --> Database Driver Class Initialized
INFO - 2016-02-27 09:11:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:11:30 --> Controller Class Initialized
INFO - 2016-02-27 09:11:30 --> Model Class Initialized
INFO - 2016-02-27 09:11:30 --> Model Class Initialized
INFO - 2016-02-27 09:11:30 --> Form Validation Class Initialized
INFO - 2016-02-27 09:11:30 --> Helper loaded: text_helper
INFO - 2016-02-27 09:11:30 --> Config Class Initialized
INFO - 2016-02-27 09:11:30 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:11:30 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:11:30 --> Utf8 Class Initialized
INFO - 2016-02-27 09:11:30 --> URI Class Initialized
DEBUG - 2016-02-27 09:11:30 --> No URI present. Default controller set.
INFO - 2016-02-27 09:11:30 --> Router Class Initialized
INFO - 2016-02-27 09:11:30 --> Output Class Initialized
INFO - 2016-02-27 09:11:30 --> Security Class Initialized
DEBUG - 2016-02-27 09:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:11:30 --> Input Class Initialized
INFO - 2016-02-27 09:11:30 --> Language Class Initialized
INFO - 2016-02-27 09:11:30 --> Loader Class Initialized
INFO - 2016-02-27 09:11:30 --> Helper loaded: url_helper
INFO - 2016-02-27 09:11:30 --> Helper loaded: file_helper
INFO - 2016-02-27 09:11:30 --> Helper loaded: date_helper
INFO - 2016-02-27 09:11:30 --> Helper loaded: form_helper
INFO - 2016-02-27 09:11:30 --> Database Driver Class Initialized
INFO - 2016-02-27 09:11:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:11:31 --> Controller Class Initialized
INFO - 2016-02-27 09:11:31 --> Model Class Initialized
INFO - 2016-02-27 09:11:31 --> Model Class Initialized
INFO - 2016-02-27 09:11:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:11:31 --> Pagination Class Initialized
INFO - 2016-02-27 09:11:31 --> Helper loaded: text_helper
INFO - 2016-02-27 09:11:31 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:11:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:11:31 --> Final output sent to browser
DEBUG - 2016-02-27 12:11:31 --> Total execution time: 1.1803
INFO - 2016-02-27 09:11:36 --> Config Class Initialized
INFO - 2016-02-27 09:11:36 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:11:36 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:11:36 --> Utf8 Class Initialized
INFO - 2016-02-27 09:11:36 --> URI Class Initialized
INFO - 2016-02-27 09:11:36 --> Router Class Initialized
INFO - 2016-02-27 09:11:36 --> Output Class Initialized
INFO - 2016-02-27 09:11:36 --> Security Class Initialized
DEBUG - 2016-02-27 09:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:11:36 --> Input Class Initialized
INFO - 2016-02-27 09:11:36 --> Language Class Initialized
INFO - 2016-02-27 09:11:36 --> Loader Class Initialized
INFO - 2016-02-27 09:11:36 --> Helper loaded: url_helper
INFO - 2016-02-27 09:11:36 --> Helper loaded: file_helper
INFO - 2016-02-27 09:11:36 --> Helper loaded: date_helper
INFO - 2016-02-27 09:11:36 --> Helper loaded: form_helper
INFO - 2016-02-27 09:11:36 --> Database Driver Class Initialized
INFO - 2016-02-27 09:11:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:11:37 --> Controller Class Initialized
INFO - 2016-02-27 09:11:37 --> Model Class Initialized
INFO - 2016-02-27 09:11:37 --> Model Class Initialized
INFO - 2016-02-27 09:11:37 --> Form Validation Class Initialized
INFO - 2016-02-27 09:11:37 --> Helper loaded: text_helper
INFO - 2016-02-27 09:11:37 --> Config Class Initialized
INFO - 2016-02-27 09:11:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:11:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:11:37 --> Utf8 Class Initialized
INFO - 2016-02-27 09:11:37 --> URI Class Initialized
DEBUG - 2016-02-27 09:11:37 --> No URI present. Default controller set.
INFO - 2016-02-27 09:11:37 --> Router Class Initialized
INFO - 2016-02-27 09:11:37 --> Output Class Initialized
INFO - 2016-02-27 09:11:37 --> Security Class Initialized
DEBUG - 2016-02-27 09:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:11:37 --> Input Class Initialized
INFO - 2016-02-27 09:11:37 --> Language Class Initialized
INFO - 2016-02-27 09:11:38 --> Loader Class Initialized
INFO - 2016-02-27 09:11:38 --> Helper loaded: url_helper
INFO - 2016-02-27 09:11:38 --> Helper loaded: file_helper
INFO - 2016-02-27 09:11:38 --> Helper loaded: date_helper
INFO - 2016-02-27 09:11:38 --> Helper loaded: form_helper
INFO - 2016-02-27 09:11:38 --> Database Driver Class Initialized
INFO - 2016-02-27 09:11:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:11:39 --> Controller Class Initialized
INFO - 2016-02-27 09:11:39 --> Model Class Initialized
INFO - 2016-02-27 09:11:39 --> Model Class Initialized
INFO - 2016-02-27 09:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:11:39 --> Pagination Class Initialized
INFO - 2016-02-27 09:11:39 --> Helper loaded: text_helper
INFO - 2016-02-27 09:11:39 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:11:39 --> Final output sent to browser
DEBUG - 2016-02-27 12:11:39 --> Total execution time: 1.2255
INFO - 2016-02-27 09:12:14 --> Config Class Initialized
INFO - 2016-02-27 09:12:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:12:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:12:14 --> Utf8 Class Initialized
INFO - 2016-02-27 09:12:14 --> URI Class Initialized
DEBUG - 2016-02-27 09:12:14 --> No URI present. Default controller set.
INFO - 2016-02-27 09:12:14 --> Router Class Initialized
INFO - 2016-02-27 09:12:14 --> Output Class Initialized
INFO - 2016-02-27 09:12:14 --> Security Class Initialized
DEBUG - 2016-02-27 09:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:12:14 --> Input Class Initialized
INFO - 2016-02-27 09:12:14 --> Language Class Initialized
INFO - 2016-02-27 09:12:14 --> Loader Class Initialized
INFO - 2016-02-27 09:12:14 --> Helper loaded: url_helper
INFO - 2016-02-27 09:12:14 --> Helper loaded: file_helper
INFO - 2016-02-27 09:12:14 --> Helper loaded: date_helper
INFO - 2016-02-27 09:12:14 --> Helper loaded: form_helper
INFO - 2016-02-27 09:12:14 --> Database Driver Class Initialized
INFO - 2016-02-27 09:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:12:15 --> Controller Class Initialized
INFO - 2016-02-27 09:12:15 --> Model Class Initialized
INFO - 2016-02-27 09:12:15 --> Model Class Initialized
INFO - 2016-02-27 09:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:12:15 --> Pagination Class Initialized
INFO - 2016-02-27 09:12:15 --> Helper loaded: text_helper
INFO - 2016-02-27 09:12:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:12:15 --> Final output sent to browser
DEBUG - 2016-02-27 12:12:15 --> Total execution time: 1.1233
INFO - 2016-02-27 09:12:19 --> Config Class Initialized
INFO - 2016-02-27 09:12:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:12:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:12:19 --> Utf8 Class Initialized
INFO - 2016-02-27 09:12:19 --> URI Class Initialized
INFO - 2016-02-27 09:12:19 --> Router Class Initialized
INFO - 2016-02-27 09:12:19 --> Output Class Initialized
INFO - 2016-02-27 09:12:19 --> Security Class Initialized
DEBUG - 2016-02-27 09:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:12:19 --> Input Class Initialized
INFO - 2016-02-27 09:12:19 --> Language Class Initialized
INFO - 2016-02-27 09:12:19 --> Loader Class Initialized
INFO - 2016-02-27 09:12:19 --> Helper loaded: url_helper
INFO - 2016-02-27 09:12:19 --> Helper loaded: file_helper
INFO - 2016-02-27 09:12:19 --> Helper loaded: date_helper
INFO - 2016-02-27 09:12:19 --> Helper loaded: form_helper
INFO - 2016-02-27 09:12:19 --> Database Driver Class Initialized
INFO - 2016-02-27 09:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:12:20 --> Controller Class Initialized
INFO - 2016-02-27 09:12:20 --> Model Class Initialized
INFO - 2016-02-27 09:12:20 --> Model Class Initialized
INFO - 2016-02-27 09:12:20 --> Form Validation Class Initialized
INFO - 2016-02-27 09:12:20 --> Helper loaded: text_helper
INFO - 2016-02-27 09:12:20 --> Final output sent to browser
DEBUG - 2016-02-27 09:12:20 --> Total execution time: 1.1273
INFO - 2016-02-27 09:13:43 --> Config Class Initialized
INFO - 2016-02-27 09:13:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:13:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:13:43 --> Utf8 Class Initialized
INFO - 2016-02-27 09:13:43 --> URI Class Initialized
DEBUG - 2016-02-27 09:13:43 --> No URI present. Default controller set.
INFO - 2016-02-27 09:13:43 --> Router Class Initialized
INFO - 2016-02-27 09:13:43 --> Output Class Initialized
INFO - 2016-02-27 09:13:43 --> Security Class Initialized
DEBUG - 2016-02-27 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:13:43 --> Input Class Initialized
INFO - 2016-02-27 09:13:43 --> Language Class Initialized
INFO - 2016-02-27 09:13:43 --> Loader Class Initialized
INFO - 2016-02-27 09:13:43 --> Helper loaded: url_helper
INFO - 2016-02-27 09:13:43 --> Helper loaded: file_helper
INFO - 2016-02-27 09:13:43 --> Helper loaded: date_helper
INFO - 2016-02-27 09:13:43 --> Helper loaded: form_helper
INFO - 2016-02-27 09:13:43 --> Database Driver Class Initialized
INFO - 2016-02-27 09:13:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:13:44 --> Controller Class Initialized
INFO - 2016-02-27 09:13:44 --> Model Class Initialized
INFO - 2016-02-27 09:13:44 --> Model Class Initialized
INFO - 2016-02-27 09:13:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:13:44 --> Pagination Class Initialized
INFO - 2016-02-27 09:13:44 --> Helper loaded: text_helper
INFO - 2016-02-27 09:13:44 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:13:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:13:44 --> Final output sent to browser
DEBUG - 2016-02-27 12:13:44 --> Total execution time: 1.1474
INFO - 2016-02-27 09:13:47 --> Config Class Initialized
INFO - 2016-02-27 09:13:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:13:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:13:47 --> Utf8 Class Initialized
INFO - 2016-02-27 09:13:47 --> URI Class Initialized
INFO - 2016-02-27 09:13:47 --> Router Class Initialized
INFO - 2016-02-27 09:13:47 --> Output Class Initialized
INFO - 2016-02-27 09:13:47 --> Security Class Initialized
DEBUG - 2016-02-27 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:13:47 --> Input Class Initialized
INFO - 2016-02-27 09:13:47 --> Language Class Initialized
INFO - 2016-02-27 09:13:47 --> Loader Class Initialized
INFO - 2016-02-27 09:13:47 --> Helper loaded: url_helper
INFO - 2016-02-27 09:13:47 --> Helper loaded: file_helper
INFO - 2016-02-27 09:13:47 --> Helper loaded: date_helper
INFO - 2016-02-27 09:13:47 --> Helper loaded: form_helper
INFO - 2016-02-27 09:13:47 --> Database Driver Class Initialized
INFO - 2016-02-27 09:13:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:13:48 --> Controller Class Initialized
INFO - 2016-02-27 09:13:48 --> Model Class Initialized
INFO - 2016-02-27 09:13:48 --> Model Class Initialized
INFO - 2016-02-27 09:13:48 --> Form Validation Class Initialized
INFO - 2016-02-27 09:13:48 --> Helper loaded: text_helper
INFO - 2016-02-27 09:18:49 --> Config Class Initialized
INFO - 2016-02-27 09:18:49 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:18:49 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:18:49 --> Utf8 Class Initialized
INFO - 2016-02-27 09:18:49 --> URI Class Initialized
DEBUG - 2016-02-27 09:18:49 --> No URI present. Default controller set.
INFO - 2016-02-27 09:18:49 --> Router Class Initialized
INFO - 2016-02-27 09:18:49 --> Output Class Initialized
INFO - 2016-02-27 09:18:49 --> Security Class Initialized
DEBUG - 2016-02-27 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:18:49 --> Input Class Initialized
INFO - 2016-02-27 09:18:49 --> Language Class Initialized
INFO - 2016-02-27 09:18:49 --> Loader Class Initialized
INFO - 2016-02-27 09:18:49 --> Helper loaded: url_helper
INFO - 2016-02-27 09:18:49 --> Helper loaded: file_helper
INFO - 2016-02-27 09:18:49 --> Helper loaded: date_helper
INFO - 2016-02-27 09:18:49 --> Helper loaded: form_helper
INFO - 2016-02-27 09:18:49 --> Database Driver Class Initialized
INFO - 2016-02-27 09:18:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:18:50 --> Controller Class Initialized
INFO - 2016-02-27 09:18:50 --> Model Class Initialized
INFO - 2016-02-27 09:18:50 --> Model Class Initialized
INFO - 2016-02-27 09:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:18:50 --> Pagination Class Initialized
INFO - 2016-02-27 09:18:50 --> Helper loaded: text_helper
INFO - 2016-02-27 09:18:50 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:18:50 --> Final output sent to browser
DEBUG - 2016-02-27 12:18:50 --> Total execution time: 1.1420
INFO - 2016-02-27 09:18:52 --> Config Class Initialized
INFO - 2016-02-27 09:18:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:18:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:18:52 --> Utf8 Class Initialized
INFO - 2016-02-27 09:18:52 --> URI Class Initialized
INFO - 2016-02-27 09:18:52 --> Router Class Initialized
INFO - 2016-02-27 09:18:52 --> Output Class Initialized
INFO - 2016-02-27 09:18:52 --> Security Class Initialized
DEBUG - 2016-02-27 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:18:52 --> Input Class Initialized
INFO - 2016-02-27 09:18:52 --> Language Class Initialized
INFO - 2016-02-27 09:18:52 --> Loader Class Initialized
INFO - 2016-02-27 09:18:52 --> Helper loaded: url_helper
INFO - 2016-02-27 09:18:52 --> Helper loaded: file_helper
INFO - 2016-02-27 09:18:52 --> Helper loaded: date_helper
INFO - 2016-02-27 09:18:52 --> Helper loaded: form_helper
INFO - 2016-02-27 09:18:52 --> Database Driver Class Initialized
INFO - 2016-02-27 09:18:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:18:53 --> Controller Class Initialized
INFO - 2016-02-27 09:18:53 --> Model Class Initialized
INFO - 2016-02-27 09:18:53 --> Model Class Initialized
INFO - 2016-02-27 09:18:53 --> Form Validation Class Initialized
INFO - 2016-02-27 09:18:53 --> Helper loaded: text_helper
INFO - 2016-02-27 09:18:55 --> Config Class Initialized
INFO - 2016-02-27 09:18:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:18:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:18:55 --> Utf8 Class Initialized
INFO - 2016-02-27 09:18:55 --> URI Class Initialized
DEBUG - 2016-02-27 09:18:55 --> No URI present. Default controller set.
INFO - 2016-02-27 09:18:55 --> Router Class Initialized
INFO - 2016-02-27 09:18:55 --> Output Class Initialized
INFO - 2016-02-27 09:18:55 --> Security Class Initialized
DEBUG - 2016-02-27 09:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:18:55 --> Input Class Initialized
INFO - 2016-02-27 09:18:55 --> Language Class Initialized
INFO - 2016-02-27 09:18:55 --> Loader Class Initialized
INFO - 2016-02-27 09:18:55 --> Helper loaded: url_helper
INFO - 2016-02-27 09:18:55 --> Helper loaded: file_helper
INFO - 2016-02-27 09:18:55 --> Helper loaded: date_helper
INFO - 2016-02-27 09:18:55 --> Helper loaded: form_helper
INFO - 2016-02-27 09:18:55 --> Database Driver Class Initialized
INFO - 2016-02-27 09:18:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:18:56 --> Controller Class Initialized
INFO - 2016-02-27 09:18:56 --> Model Class Initialized
INFO - 2016-02-27 09:18:56 --> Model Class Initialized
INFO - 2016-02-27 09:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:18:56 --> Pagination Class Initialized
INFO - 2016-02-27 09:18:56 --> Helper loaded: text_helper
INFO - 2016-02-27 09:18:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:18:56 --> Final output sent to browser
DEBUG - 2016-02-27 12:18:56 --> Total execution time: 1.1258
INFO - 2016-02-27 09:19:20 --> Config Class Initialized
INFO - 2016-02-27 09:19:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:19:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:19:20 --> Utf8 Class Initialized
INFO - 2016-02-27 09:19:20 --> URI Class Initialized
DEBUG - 2016-02-27 09:19:20 --> No URI present. Default controller set.
INFO - 2016-02-27 09:19:20 --> Router Class Initialized
INFO - 2016-02-27 09:19:20 --> Output Class Initialized
INFO - 2016-02-27 09:19:20 --> Security Class Initialized
DEBUG - 2016-02-27 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:19:21 --> Input Class Initialized
INFO - 2016-02-27 09:19:21 --> Language Class Initialized
INFO - 2016-02-27 09:19:21 --> Loader Class Initialized
INFO - 2016-02-27 09:19:21 --> Helper loaded: url_helper
INFO - 2016-02-27 09:19:21 --> Helper loaded: file_helper
INFO - 2016-02-27 09:19:21 --> Helper loaded: date_helper
INFO - 2016-02-27 09:19:21 --> Helper loaded: form_helper
INFO - 2016-02-27 09:19:21 --> Database Driver Class Initialized
INFO - 2016-02-27 09:19:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:19:22 --> Controller Class Initialized
INFO - 2016-02-27 09:19:22 --> Model Class Initialized
INFO - 2016-02-27 09:19:22 --> Model Class Initialized
INFO - 2016-02-27 09:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:19:22 --> Pagination Class Initialized
INFO - 2016-02-27 09:19:22 --> Helper loaded: text_helper
INFO - 2016-02-27 09:19:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:19:22 --> Final output sent to browser
DEBUG - 2016-02-27 12:19:22 --> Total execution time: 1.1343
INFO - 2016-02-27 09:19:24 --> Config Class Initialized
INFO - 2016-02-27 09:19:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:19:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:19:24 --> Utf8 Class Initialized
INFO - 2016-02-27 09:19:24 --> URI Class Initialized
INFO - 2016-02-27 09:19:24 --> Router Class Initialized
INFO - 2016-02-27 09:19:24 --> Output Class Initialized
INFO - 2016-02-27 09:19:24 --> Security Class Initialized
DEBUG - 2016-02-27 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:19:24 --> Input Class Initialized
INFO - 2016-02-27 09:19:24 --> Language Class Initialized
INFO - 2016-02-27 09:19:24 --> Loader Class Initialized
INFO - 2016-02-27 09:19:24 --> Helper loaded: url_helper
INFO - 2016-02-27 09:19:24 --> Helper loaded: file_helper
INFO - 2016-02-27 09:19:24 --> Helper loaded: date_helper
INFO - 2016-02-27 09:19:24 --> Helper loaded: form_helper
INFO - 2016-02-27 09:19:24 --> Database Driver Class Initialized
INFO - 2016-02-27 09:19:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:19:25 --> Controller Class Initialized
INFO - 2016-02-27 09:19:25 --> Model Class Initialized
INFO - 2016-02-27 09:19:25 --> Model Class Initialized
INFO - 2016-02-27 09:19:25 --> Form Validation Class Initialized
INFO - 2016-02-27 09:19:25 --> Helper loaded: text_helper
INFO - 2016-02-27 09:19:27 --> Config Class Initialized
INFO - 2016-02-27 09:19:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:19:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:19:27 --> Utf8 Class Initialized
INFO - 2016-02-27 09:19:27 --> URI Class Initialized
DEBUG - 2016-02-27 09:19:27 --> No URI present. Default controller set.
INFO - 2016-02-27 09:19:27 --> Router Class Initialized
INFO - 2016-02-27 09:19:27 --> Output Class Initialized
INFO - 2016-02-27 09:19:27 --> Security Class Initialized
DEBUG - 2016-02-27 09:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:19:27 --> Input Class Initialized
INFO - 2016-02-27 09:19:27 --> Language Class Initialized
INFO - 2016-02-27 09:19:27 --> Loader Class Initialized
INFO - 2016-02-27 09:19:27 --> Helper loaded: url_helper
INFO - 2016-02-27 09:19:27 --> Helper loaded: file_helper
INFO - 2016-02-27 09:19:27 --> Helper loaded: date_helper
INFO - 2016-02-27 09:19:27 --> Helper loaded: form_helper
INFO - 2016-02-27 09:19:27 --> Database Driver Class Initialized
INFO - 2016-02-27 09:19:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:19:28 --> Controller Class Initialized
INFO - 2016-02-27 09:19:28 --> Model Class Initialized
INFO - 2016-02-27 09:19:28 --> Model Class Initialized
INFO - 2016-02-27 09:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:19:28 --> Pagination Class Initialized
INFO - 2016-02-27 09:19:28 --> Helper loaded: text_helper
INFO - 2016-02-27 09:19:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:19:28 --> Final output sent to browser
DEBUG - 2016-02-27 12:19:28 --> Total execution time: 1.1033
INFO - 2016-02-27 09:26:54 --> Config Class Initialized
INFO - 2016-02-27 09:26:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:26:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:26:54 --> Utf8 Class Initialized
INFO - 2016-02-27 09:26:54 --> URI Class Initialized
DEBUG - 2016-02-27 09:26:54 --> No URI present. Default controller set.
INFO - 2016-02-27 09:26:54 --> Router Class Initialized
INFO - 2016-02-27 09:26:54 --> Output Class Initialized
INFO - 2016-02-27 09:26:54 --> Security Class Initialized
DEBUG - 2016-02-27 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:26:54 --> Input Class Initialized
INFO - 2016-02-27 09:26:54 --> Language Class Initialized
INFO - 2016-02-27 09:26:54 --> Loader Class Initialized
INFO - 2016-02-27 09:26:54 --> Helper loaded: url_helper
INFO - 2016-02-27 09:26:54 --> Helper loaded: file_helper
INFO - 2016-02-27 09:26:54 --> Helper loaded: date_helper
INFO - 2016-02-27 09:26:54 --> Helper loaded: form_helper
INFO - 2016-02-27 09:26:54 --> Database Driver Class Initialized
INFO - 2016-02-27 09:26:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:26:55 --> Controller Class Initialized
INFO - 2016-02-27 09:26:55 --> Model Class Initialized
INFO - 2016-02-27 09:26:55 --> Model Class Initialized
INFO - 2016-02-27 09:26:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:26:55 --> Pagination Class Initialized
INFO - 2016-02-27 09:26:55 --> Helper loaded: text_helper
INFO - 2016-02-27 09:26:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:26:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:26:55 --> Final output sent to browser
DEBUG - 2016-02-27 12:26:55 --> Total execution time: 1.1866
INFO - 2016-02-27 09:26:58 --> Config Class Initialized
INFO - 2016-02-27 09:26:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:26:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:26:58 --> Utf8 Class Initialized
INFO - 2016-02-27 09:26:58 --> URI Class Initialized
INFO - 2016-02-27 09:26:58 --> Router Class Initialized
INFO - 2016-02-27 09:26:58 --> Output Class Initialized
INFO - 2016-02-27 09:26:58 --> Security Class Initialized
DEBUG - 2016-02-27 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:26:58 --> Input Class Initialized
INFO - 2016-02-27 09:26:58 --> Language Class Initialized
INFO - 2016-02-27 09:26:58 --> Loader Class Initialized
INFO - 2016-02-27 09:26:58 --> Helper loaded: url_helper
INFO - 2016-02-27 09:26:58 --> Helper loaded: file_helper
INFO - 2016-02-27 09:26:58 --> Helper loaded: date_helper
INFO - 2016-02-27 09:26:58 --> Helper loaded: form_helper
INFO - 2016-02-27 09:26:58 --> Database Driver Class Initialized
INFO - 2016-02-27 09:26:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:26:59 --> Controller Class Initialized
INFO - 2016-02-27 09:26:59 --> Model Class Initialized
INFO - 2016-02-27 09:26:59 --> Model Class Initialized
INFO - 2016-02-27 09:26:59 --> Form Validation Class Initialized
INFO - 2016-02-27 09:26:59 --> Helper loaded: text_helper
INFO - 2016-02-27 09:27:43 --> Config Class Initialized
INFO - 2016-02-27 09:27:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:27:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:27:43 --> Utf8 Class Initialized
INFO - 2016-02-27 09:27:43 --> URI Class Initialized
DEBUG - 2016-02-27 09:27:43 --> No URI present. Default controller set.
INFO - 2016-02-27 09:27:43 --> Router Class Initialized
INFO - 2016-02-27 09:27:43 --> Output Class Initialized
INFO - 2016-02-27 09:27:43 --> Security Class Initialized
DEBUG - 2016-02-27 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:27:43 --> Input Class Initialized
INFO - 2016-02-27 09:27:43 --> Language Class Initialized
INFO - 2016-02-27 09:27:43 --> Loader Class Initialized
INFO - 2016-02-27 09:27:43 --> Helper loaded: url_helper
INFO - 2016-02-27 09:27:43 --> Helper loaded: file_helper
INFO - 2016-02-27 09:27:43 --> Helper loaded: date_helper
INFO - 2016-02-27 09:27:43 --> Helper loaded: form_helper
INFO - 2016-02-27 09:27:43 --> Database Driver Class Initialized
INFO - 2016-02-27 09:27:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:27:44 --> Controller Class Initialized
INFO - 2016-02-27 09:27:44 --> Model Class Initialized
INFO - 2016-02-27 09:27:44 --> Model Class Initialized
INFO - 2016-02-27 09:27:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:27:44 --> Pagination Class Initialized
INFO - 2016-02-27 09:27:44 --> Helper loaded: text_helper
INFO - 2016-02-27 09:27:44 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:27:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:27:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:27:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:27:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:27:44 --> Final output sent to browser
DEBUG - 2016-02-27 12:27:44 --> Total execution time: 1.1543
INFO - 2016-02-27 09:39:27 --> Config Class Initialized
INFO - 2016-02-27 09:39:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:39:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:39:27 --> Utf8 Class Initialized
INFO - 2016-02-27 09:39:27 --> URI Class Initialized
INFO - 2016-02-27 09:39:27 --> Router Class Initialized
INFO - 2016-02-27 09:39:27 --> Output Class Initialized
INFO - 2016-02-27 09:39:27 --> Security Class Initialized
DEBUG - 2016-02-27 09:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:39:27 --> Input Class Initialized
INFO - 2016-02-27 09:39:27 --> Language Class Initialized
INFO - 2016-02-27 09:39:27 --> Loader Class Initialized
INFO - 2016-02-27 09:39:27 --> Helper loaded: url_helper
INFO - 2016-02-27 09:39:27 --> Helper loaded: file_helper
INFO - 2016-02-27 09:39:27 --> Helper loaded: date_helper
INFO - 2016-02-27 09:39:27 --> Helper loaded: form_helper
INFO - 2016-02-27 09:39:27 --> Database Driver Class Initialized
INFO - 2016-02-27 09:39:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:39:28 --> Controller Class Initialized
INFO - 2016-02-27 09:39:28 --> Model Class Initialized
INFO - 2016-02-27 09:39:28 --> Model Class Initialized
INFO - 2016-02-27 09:39:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:39:28 --> Pagination Class Initialized
INFO - 2016-02-27 09:39:28 --> Helper loaded: text_helper
INFO - 2016-02-27 09:39:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:39:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-27 12:39:28 --> Query error: Table 'jdboard.info_comment' doesn't exist - Invalid query: SELECT *
FROM `info_comment`
WHERE `board_id` = '63'
INFO - 2016-02-27 12:39:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-27 09:39:31 --> Config Class Initialized
INFO - 2016-02-27 09:39:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:39:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:39:31 --> Utf8 Class Initialized
INFO - 2016-02-27 09:39:31 --> URI Class Initialized
DEBUG - 2016-02-27 09:39:31 --> No URI present. Default controller set.
INFO - 2016-02-27 09:39:31 --> Router Class Initialized
INFO - 2016-02-27 09:39:31 --> Output Class Initialized
INFO - 2016-02-27 09:39:31 --> Security Class Initialized
DEBUG - 2016-02-27 09:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:39:31 --> Input Class Initialized
INFO - 2016-02-27 09:39:31 --> Language Class Initialized
INFO - 2016-02-27 09:39:31 --> Loader Class Initialized
INFO - 2016-02-27 09:39:31 --> Helper loaded: url_helper
INFO - 2016-02-27 09:39:31 --> Helper loaded: file_helper
INFO - 2016-02-27 09:39:31 --> Helper loaded: date_helper
INFO - 2016-02-27 09:39:31 --> Helper loaded: form_helper
INFO - 2016-02-27 09:39:31 --> Database Driver Class Initialized
INFO - 2016-02-27 09:39:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:39:32 --> Controller Class Initialized
INFO - 2016-02-27 09:39:32 --> Model Class Initialized
INFO - 2016-02-27 09:39:32 --> Model Class Initialized
INFO - 2016-02-27 09:39:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:39:32 --> Pagination Class Initialized
INFO - 2016-02-27 09:39:32 --> Helper loaded: text_helper
INFO - 2016-02-27 09:39:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:39:32 --> Final output sent to browser
DEBUG - 2016-02-27 12:39:32 --> Total execution time: 1.1155
INFO - 2016-02-27 09:39:33 --> Config Class Initialized
INFO - 2016-02-27 09:39:33 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:39:33 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:39:33 --> Utf8 Class Initialized
INFO - 2016-02-27 09:39:33 --> URI Class Initialized
INFO - 2016-02-27 09:39:33 --> Router Class Initialized
INFO - 2016-02-27 09:39:33 --> Output Class Initialized
INFO - 2016-02-27 09:39:33 --> Security Class Initialized
DEBUG - 2016-02-27 09:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:39:33 --> Input Class Initialized
INFO - 2016-02-27 09:39:33 --> Language Class Initialized
INFO - 2016-02-27 09:39:33 --> Loader Class Initialized
INFO - 2016-02-27 09:39:33 --> Helper loaded: url_helper
INFO - 2016-02-27 09:39:33 --> Helper loaded: file_helper
INFO - 2016-02-27 09:39:33 --> Helper loaded: date_helper
INFO - 2016-02-27 09:39:33 --> Helper loaded: form_helper
INFO - 2016-02-27 09:39:33 --> Database Driver Class Initialized
INFO - 2016-02-27 09:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:39:35 --> Controller Class Initialized
INFO - 2016-02-27 09:39:35 --> Model Class Initialized
INFO - 2016-02-27 09:39:35 --> Model Class Initialized
INFO - 2016-02-27 09:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:39:35 --> Pagination Class Initialized
INFO - 2016-02-27 09:39:35 --> Helper loaded: text_helper
INFO - 2016-02-27 09:39:35 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 12:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 12:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:39:35 --> Final output sent to browser
DEBUG - 2016-02-27 12:39:35 --> Total execution time: 1.1996
INFO - 2016-02-27 09:40:04 --> Config Class Initialized
INFO - 2016-02-27 09:40:04 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:40:04 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:40:04 --> Utf8 Class Initialized
INFO - 2016-02-27 09:40:04 --> URI Class Initialized
INFO - 2016-02-27 09:40:04 --> Router Class Initialized
INFO - 2016-02-27 09:40:04 --> Output Class Initialized
INFO - 2016-02-27 09:40:04 --> Security Class Initialized
DEBUG - 2016-02-27 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:40:04 --> Input Class Initialized
INFO - 2016-02-27 09:40:04 --> Language Class Initialized
INFO - 2016-02-27 09:40:04 --> Loader Class Initialized
INFO - 2016-02-27 09:40:04 --> Helper loaded: url_helper
INFO - 2016-02-27 09:40:04 --> Helper loaded: file_helper
INFO - 2016-02-27 09:40:04 --> Helper loaded: date_helper
INFO - 2016-02-27 09:40:04 --> Helper loaded: form_helper
INFO - 2016-02-27 09:40:04 --> Database Driver Class Initialized
INFO - 2016-02-27 09:40:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:40:05 --> Controller Class Initialized
INFO - 2016-02-27 09:40:05 --> Model Class Initialized
INFO - 2016-02-27 09:40:05 --> Model Class Initialized
INFO - 2016-02-27 09:40:05 --> Form Validation Class Initialized
INFO - 2016-02-27 09:40:05 --> Helper loaded: text_helper
INFO - 2016-02-27 09:40:05 --> Config Class Initialized
INFO - 2016-02-27 09:40:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:40:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:40:05 --> Utf8 Class Initialized
INFO - 2016-02-27 09:40:05 --> URI Class Initialized
INFO - 2016-02-27 09:40:05 --> Router Class Initialized
INFO - 2016-02-27 09:40:05 --> Output Class Initialized
INFO - 2016-02-27 09:40:05 --> Security Class Initialized
DEBUG - 2016-02-27 09:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:40:05 --> Input Class Initialized
INFO - 2016-02-27 09:40:05 --> Language Class Initialized
INFO - 2016-02-27 09:40:05 --> Loader Class Initialized
INFO - 2016-02-27 09:40:05 --> Helper loaded: url_helper
INFO - 2016-02-27 09:40:05 --> Helper loaded: file_helper
INFO - 2016-02-27 09:40:05 --> Helper loaded: date_helper
INFO - 2016-02-27 09:40:05 --> Helper loaded: form_helper
INFO - 2016-02-27 09:40:05 --> Database Driver Class Initialized
INFO - 2016-02-27 09:40:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:40:06 --> Controller Class Initialized
INFO - 2016-02-27 09:40:06 --> Model Class Initialized
INFO - 2016-02-27 09:40:06 --> Model Class Initialized
INFO - 2016-02-27 09:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:40:06 --> Pagination Class Initialized
INFO - 2016-02-27 09:40:06 --> Helper loaded: text_helper
INFO - 2016-02-27 09:40:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 12:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 12:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:40:06 --> Final output sent to browser
DEBUG - 2016-02-27 12:40:06 --> Total execution time: 1.2169
INFO - 2016-02-27 09:41:46 --> Config Class Initialized
INFO - 2016-02-27 09:41:46 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:41:46 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:41:46 --> Utf8 Class Initialized
INFO - 2016-02-27 09:41:46 --> URI Class Initialized
INFO - 2016-02-27 09:41:46 --> Router Class Initialized
INFO - 2016-02-27 09:41:46 --> Output Class Initialized
INFO - 2016-02-27 09:41:46 --> Security Class Initialized
DEBUG - 2016-02-27 09:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:41:46 --> Input Class Initialized
INFO - 2016-02-27 09:41:46 --> Language Class Initialized
INFO - 2016-02-27 09:41:46 --> Loader Class Initialized
INFO - 2016-02-27 09:41:46 --> Helper loaded: url_helper
INFO - 2016-02-27 09:41:46 --> Helper loaded: file_helper
INFO - 2016-02-27 09:41:46 --> Helper loaded: date_helper
INFO - 2016-02-27 09:41:46 --> Helper loaded: form_helper
INFO - 2016-02-27 09:41:46 --> Database Driver Class Initialized
INFO - 2016-02-27 09:41:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:41:47 --> Controller Class Initialized
INFO - 2016-02-27 09:41:47 --> Model Class Initialized
INFO - 2016-02-27 09:41:47 --> Model Class Initialized
INFO - 2016-02-27 09:41:47 --> Form Validation Class Initialized
INFO - 2016-02-27 09:41:47 --> Helper loaded: text_helper
INFO - 2016-02-27 09:41:48 --> Config Class Initialized
INFO - 2016-02-27 09:41:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:41:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:41:48 --> Utf8 Class Initialized
INFO - 2016-02-27 09:41:48 --> URI Class Initialized
DEBUG - 2016-02-27 09:41:48 --> No URI present. Default controller set.
INFO - 2016-02-27 09:41:48 --> Router Class Initialized
INFO - 2016-02-27 09:41:48 --> Output Class Initialized
INFO - 2016-02-27 09:41:48 --> Security Class Initialized
DEBUG - 2016-02-27 09:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:41:48 --> Input Class Initialized
INFO - 2016-02-27 09:41:48 --> Language Class Initialized
INFO - 2016-02-27 09:41:48 --> Loader Class Initialized
INFO - 2016-02-27 09:41:48 --> Helper loaded: url_helper
INFO - 2016-02-27 09:41:48 --> Helper loaded: file_helper
INFO - 2016-02-27 09:41:48 --> Helper loaded: date_helper
INFO - 2016-02-27 09:41:48 --> Helper loaded: form_helper
INFO - 2016-02-27 09:41:48 --> Database Driver Class Initialized
INFO - 2016-02-27 09:41:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:41:49 --> Controller Class Initialized
INFO - 2016-02-27 09:41:49 --> Model Class Initialized
INFO - 2016-02-27 09:41:49 --> Model Class Initialized
INFO - 2016-02-27 09:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:41:49 --> Pagination Class Initialized
INFO - 2016-02-27 09:41:49 --> Helper loaded: text_helper
INFO - 2016-02-27 09:41:49 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:41:49 --> Final output sent to browser
DEBUG - 2016-02-27 12:41:49 --> Total execution time: 1.2641
INFO - 2016-02-27 09:45:42 --> Config Class Initialized
INFO - 2016-02-27 09:45:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:45:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:45:42 --> Utf8 Class Initialized
INFO - 2016-02-27 09:45:42 --> URI Class Initialized
INFO - 2016-02-27 09:45:42 --> Router Class Initialized
INFO - 2016-02-27 09:45:42 --> Output Class Initialized
INFO - 2016-02-27 09:45:42 --> Security Class Initialized
DEBUG - 2016-02-27 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:45:42 --> Input Class Initialized
INFO - 2016-02-27 09:45:42 --> Language Class Initialized
INFO - 2016-02-27 09:45:42 --> Loader Class Initialized
INFO - 2016-02-27 09:45:42 --> Helper loaded: url_helper
INFO - 2016-02-27 09:45:42 --> Helper loaded: file_helper
INFO - 2016-02-27 09:45:42 --> Helper loaded: date_helper
INFO - 2016-02-27 09:45:42 --> Helper loaded: form_helper
INFO - 2016-02-27 09:45:42 --> Database Driver Class Initialized
INFO - 2016-02-27 09:45:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:45:43 --> Controller Class Initialized
INFO - 2016-02-27 09:45:43 --> Model Class Initialized
INFO - 2016-02-27 09:45:43 --> Model Class Initialized
INFO - 2016-02-27 09:45:43 --> Form Validation Class Initialized
INFO - 2016-02-27 09:45:43 --> Helper loaded: text_helper
INFO - 2016-02-27 09:45:45 --> Config Class Initialized
INFO - 2016-02-27 09:45:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:45:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:45:45 --> Utf8 Class Initialized
INFO - 2016-02-27 09:45:45 --> URI Class Initialized
DEBUG - 2016-02-27 09:45:45 --> No URI present. Default controller set.
INFO - 2016-02-27 09:45:45 --> Router Class Initialized
INFO - 2016-02-27 09:45:45 --> Output Class Initialized
INFO - 2016-02-27 09:45:45 --> Security Class Initialized
DEBUG - 2016-02-27 09:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:45:45 --> Input Class Initialized
INFO - 2016-02-27 09:45:45 --> Language Class Initialized
INFO - 2016-02-27 09:45:45 --> Loader Class Initialized
INFO - 2016-02-27 09:45:45 --> Helper loaded: url_helper
INFO - 2016-02-27 09:45:45 --> Helper loaded: file_helper
INFO - 2016-02-27 09:45:45 --> Helper loaded: date_helper
INFO - 2016-02-27 09:45:45 --> Helper loaded: form_helper
INFO - 2016-02-27 09:45:45 --> Database Driver Class Initialized
INFO - 2016-02-27 09:45:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:45:46 --> Controller Class Initialized
INFO - 2016-02-27 09:45:46 --> Model Class Initialized
INFO - 2016-02-27 09:45:46 --> Model Class Initialized
INFO - 2016-02-27 09:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:45:46 --> Pagination Class Initialized
INFO - 2016-02-27 09:45:46 --> Helper loaded: text_helper
INFO - 2016-02-27 09:45:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:45:46 --> Final output sent to browser
DEBUG - 2016-02-27 12:45:46 --> Total execution time: 1.1289
INFO - 2016-02-27 09:45:50 --> Config Class Initialized
INFO - 2016-02-27 09:45:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:45:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:45:50 --> Utf8 Class Initialized
INFO - 2016-02-27 09:45:50 --> URI Class Initialized
INFO - 2016-02-27 09:45:50 --> Router Class Initialized
INFO - 2016-02-27 09:45:50 --> Output Class Initialized
INFO - 2016-02-27 09:45:50 --> Security Class Initialized
DEBUG - 2016-02-27 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:45:50 --> Input Class Initialized
INFO - 2016-02-27 09:45:50 --> Language Class Initialized
INFO - 2016-02-27 09:45:50 --> Loader Class Initialized
INFO - 2016-02-27 09:45:50 --> Helper loaded: url_helper
INFO - 2016-02-27 09:45:50 --> Helper loaded: file_helper
INFO - 2016-02-27 09:45:50 --> Helper loaded: date_helper
INFO - 2016-02-27 09:45:50 --> Helper loaded: form_helper
INFO - 2016-02-27 09:45:50 --> Database Driver Class Initialized
INFO - 2016-02-27 09:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:45:51 --> Controller Class Initialized
INFO - 2016-02-27 09:45:51 --> Model Class Initialized
INFO - 2016-02-27 09:45:51 --> Model Class Initialized
INFO - 2016-02-27 09:45:51 --> Form Validation Class Initialized
INFO - 2016-02-27 09:45:51 --> Helper loaded: text_helper
ERROR - 2016-02-27 09:45:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
ERROR - 2016-02-27 09:45:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-27 09:45:56 --> Config Class Initialized
INFO - 2016-02-27 09:45:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:45:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:45:56 --> Utf8 Class Initialized
INFO - 2016-02-27 09:45:56 --> URI Class Initialized
DEBUG - 2016-02-27 09:45:56 --> No URI present. Default controller set.
INFO - 2016-02-27 09:45:56 --> Router Class Initialized
INFO - 2016-02-27 09:45:56 --> Output Class Initialized
INFO - 2016-02-27 09:45:56 --> Security Class Initialized
DEBUG - 2016-02-27 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:45:56 --> Input Class Initialized
INFO - 2016-02-27 09:45:56 --> Language Class Initialized
INFO - 2016-02-27 09:45:56 --> Loader Class Initialized
INFO - 2016-02-27 09:45:56 --> Helper loaded: url_helper
INFO - 2016-02-27 09:45:56 --> Helper loaded: file_helper
INFO - 2016-02-27 09:45:56 --> Helper loaded: date_helper
INFO - 2016-02-27 09:45:56 --> Helper loaded: form_helper
INFO - 2016-02-27 09:45:56 --> Database Driver Class Initialized
INFO - 2016-02-27 09:45:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:45:57 --> Controller Class Initialized
INFO - 2016-02-27 09:45:57 --> Model Class Initialized
INFO - 2016-02-27 09:45:57 --> Model Class Initialized
INFO - 2016-02-27 09:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:45:57 --> Pagination Class Initialized
INFO - 2016-02-27 09:45:57 --> Helper loaded: text_helper
INFO - 2016-02-27 09:45:57 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:45:57 --> Final output sent to browser
DEBUG - 2016-02-27 12:45:57 --> Total execution time: 1.1621
INFO - 2016-02-27 09:54:27 --> Config Class Initialized
INFO - 2016-02-27 09:54:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:54:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:54:27 --> Utf8 Class Initialized
INFO - 2016-02-27 09:54:27 --> URI Class Initialized
DEBUG - 2016-02-27 09:54:27 --> No URI present. Default controller set.
INFO - 2016-02-27 09:54:27 --> Router Class Initialized
INFO - 2016-02-27 09:54:27 --> Output Class Initialized
INFO - 2016-02-27 09:54:27 --> Security Class Initialized
DEBUG - 2016-02-27 09:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:54:27 --> Input Class Initialized
INFO - 2016-02-27 09:54:27 --> Language Class Initialized
INFO - 2016-02-27 09:54:27 --> Loader Class Initialized
INFO - 2016-02-27 09:54:27 --> Helper loaded: url_helper
INFO - 2016-02-27 09:54:27 --> Helper loaded: file_helper
INFO - 2016-02-27 09:54:27 --> Helper loaded: date_helper
INFO - 2016-02-27 09:54:27 --> Helper loaded: form_helper
INFO - 2016-02-27 09:54:27 --> Database Driver Class Initialized
INFO - 2016-02-27 09:54:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:54:28 --> Controller Class Initialized
INFO - 2016-02-27 09:54:28 --> Model Class Initialized
INFO - 2016-02-27 09:54:28 --> Model Class Initialized
INFO - 2016-02-27 09:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:54:28 --> Pagination Class Initialized
INFO - 2016-02-27 09:54:28 --> Helper loaded: text_helper
INFO - 2016-02-27 09:54:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:54:28 --> Final output sent to browser
DEBUG - 2016-02-27 12:54:28 --> Total execution time: 1.1516
INFO - 2016-02-27 09:55:54 --> Config Class Initialized
INFO - 2016-02-27 09:55:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 09:55:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 09:55:54 --> Utf8 Class Initialized
INFO - 2016-02-27 09:55:54 --> URI Class Initialized
DEBUG - 2016-02-27 09:55:54 --> No URI present. Default controller set.
INFO - 2016-02-27 09:55:54 --> Router Class Initialized
INFO - 2016-02-27 09:55:54 --> Output Class Initialized
INFO - 2016-02-27 09:55:54 --> Security Class Initialized
DEBUG - 2016-02-27 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 09:55:54 --> Input Class Initialized
INFO - 2016-02-27 09:55:54 --> Language Class Initialized
INFO - 2016-02-27 09:55:54 --> Loader Class Initialized
INFO - 2016-02-27 09:55:54 --> Helper loaded: url_helper
INFO - 2016-02-27 09:55:54 --> Helper loaded: file_helper
INFO - 2016-02-27 09:55:54 --> Helper loaded: date_helper
INFO - 2016-02-27 09:55:54 --> Helper loaded: form_helper
INFO - 2016-02-27 09:55:54 --> Database Driver Class Initialized
INFO - 2016-02-27 09:55:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 09:55:55 --> Controller Class Initialized
INFO - 2016-02-27 09:55:55 --> Model Class Initialized
INFO - 2016-02-27 09:55:55 --> Model Class Initialized
INFO - 2016-02-27 09:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 09:55:55 --> Pagination Class Initialized
INFO - 2016-02-27 09:55:55 --> Helper loaded: text_helper
INFO - 2016-02-27 09:55:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 12:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 12:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 12:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 12:55:55 --> Final output sent to browser
DEBUG - 2016-02-27 12:55:55 --> Total execution time: 1.1718
INFO - 2016-02-27 10:06:23 --> Config Class Initialized
INFO - 2016-02-27 10:06:23 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:06:23 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:06:23 --> Utf8 Class Initialized
INFO - 2016-02-27 10:06:23 --> URI Class Initialized
DEBUG - 2016-02-27 10:06:23 --> No URI present. Default controller set.
INFO - 2016-02-27 10:06:23 --> Router Class Initialized
INFO - 2016-02-27 10:06:23 --> Output Class Initialized
INFO - 2016-02-27 10:06:23 --> Security Class Initialized
DEBUG - 2016-02-27 10:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:06:23 --> Input Class Initialized
INFO - 2016-02-27 10:06:23 --> Language Class Initialized
INFO - 2016-02-27 10:06:23 --> Loader Class Initialized
INFO - 2016-02-27 10:06:23 --> Helper loaded: url_helper
INFO - 2016-02-27 10:06:23 --> Helper loaded: file_helper
INFO - 2016-02-27 10:06:23 --> Helper loaded: date_helper
INFO - 2016-02-27 10:06:23 --> Helper loaded: form_helper
INFO - 2016-02-27 10:06:23 --> Database Driver Class Initialized
INFO - 2016-02-27 10:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:06:24 --> Controller Class Initialized
INFO - 2016-02-27 10:06:24 --> Model Class Initialized
INFO - 2016-02-27 10:06:24 --> Model Class Initialized
INFO - 2016-02-27 10:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:06:24 --> Pagination Class Initialized
INFO - 2016-02-27 10:06:24 --> Helper loaded: text_helper
INFO - 2016-02-27 10:06:24 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:06:24 --> Final output sent to browser
DEBUG - 2016-02-27 13:06:24 --> Total execution time: 1.1404
INFO - 2016-02-27 10:06:52 --> Config Class Initialized
INFO - 2016-02-27 10:06:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:06:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:06:52 --> Utf8 Class Initialized
INFO - 2016-02-27 10:06:52 --> URI Class Initialized
DEBUG - 2016-02-27 10:06:52 --> No URI present. Default controller set.
INFO - 2016-02-27 10:06:52 --> Router Class Initialized
INFO - 2016-02-27 10:06:52 --> Output Class Initialized
INFO - 2016-02-27 10:06:52 --> Security Class Initialized
DEBUG - 2016-02-27 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:06:52 --> Input Class Initialized
INFO - 2016-02-27 10:06:52 --> Language Class Initialized
INFO - 2016-02-27 10:06:52 --> Loader Class Initialized
INFO - 2016-02-27 10:06:52 --> Helper loaded: url_helper
INFO - 2016-02-27 10:06:52 --> Helper loaded: file_helper
INFO - 2016-02-27 10:06:52 --> Helper loaded: date_helper
INFO - 2016-02-27 10:06:52 --> Helper loaded: form_helper
INFO - 2016-02-27 10:06:52 --> Database Driver Class Initialized
INFO - 2016-02-27 10:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:06:53 --> Controller Class Initialized
INFO - 2016-02-27 10:06:53 --> Model Class Initialized
INFO - 2016-02-27 10:06:53 --> Model Class Initialized
INFO - 2016-02-27 10:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:06:53 --> Pagination Class Initialized
INFO - 2016-02-27 10:06:53 --> Helper loaded: text_helper
INFO - 2016-02-27 10:06:53 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:06:53 --> Final output sent to browser
DEBUG - 2016-02-27 13:06:53 --> Total execution time: 1.1456
INFO - 2016-02-27 10:10:50 --> Config Class Initialized
INFO - 2016-02-27 10:10:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:10:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:10:50 --> Utf8 Class Initialized
INFO - 2016-02-27 10:10:50 --> URI Class Initialized
DEBUG - 2016-02-27 10:10:50 --> No URI present. Default controller set.
INFO - 2016-02-27 10:10:50 --> Router Class Initialized
INFO - 2016-02-27 10:10:50 --> Output Class Initialized
INFO - 2016-02-27 10:10:50 --> Security Class Initialized
DEBUG - 2016-02-27 10:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:10:50 --> Input Class Initialized
INFO - 2016-02-27 10:10:50 --> Language Class Initialized
INFO - 2016-02-27 10:10:50 --> Loader Class Initialized
INFO - 2016-02-27 10:10:50 --> Helper loaded: url_helper
INFO - 2016-02-27 10:10:50 --> Helper loaded: file_helper
INFO - 2016-02-27 10:10:50 --> Helper loaded: date_helper
INFO - 2016-02-27 10:10:50 --> Helper loaded: form_helper
INFO - 2016-02-27 10:10:50 --> Database Driver Class Initialized
INFO - 2016-02-27 10:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:10:51 --> Controller Class Initialized
INFO - 2016-02-27 10:10:51 --> Model Class Initialized
INFO - 2016-02-27 10:10:51 --> Model Class Initialized
INFO - 2016-02-27 10:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:10:51 --> Pagination Class Initialized
INFO - 2016-02-27 10:10:51 --> Helper loaded: text_helper
INFO - 2016-02-27 10:10:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:10:51 --> Final output sent to browser
DEBUG - 2016-02-27 13:10:51 --> Total execution time: 1.1615
INFO - 2016-02-27 10:11:08 --> Config Class Initialized
INFO - 2016-02-27 10:11:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:11:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:11:08 --> Utf8 Class Initialized
INFO - 2016-02-27 10:11:08 --> URI Class Initialized
DEBUG - 2016-02-27 10:11:08 --> No URI present. Default controller set.
INFO - 2016-02-27 10:11:08 --> Router Class Initialized
INFO - 2016-02-27 10:11:08 --> Output Class Initialized
INFO - 2016-02-27 10:11:08 --> Security Class Initialized
DEBUG - 2016-02-27 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:11:08 --> Input Class Initialized
INFO - 2016-02-27 10:11:08 --> Language Class Initialized
INFO - 2016-02-27 10:11:08 --> Loader Class Initialized
INFO - 2016-02-27 10:11:08 --> Helper loaded: url_helper
INFO - 2016-02-27 10:11:08 --> Helper loaded: file_helper
INFO - 2016-02-27 10:11:08 --> Helper loaded: date_helper
INFO - 2016-02-27 10:11:08 --> Helper loaded: form_helper
INFO - 2016-02-27 10:11:08 --> Database Driver Class Initialized
INFO - 2016-02-27 10:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:11:09 --> Controller Class Initialized
INFO - 2016-02-27 10:11:09 --> Model Class Initialized
INFO - 2016-02-27 10:11:09 --> Model Class Initialized
INFO - 2016-02-27 10:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:11:09 --> Pagination Class Initialized
INFO - 2016-02-27 10:11:09 --> Helper loaded: text_helper
INFO - 2016-02-27 10:11:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:11:09 --> Final output sent to browser
DEBUG - 2016-02-27 13:11:09 --> Total execution time: 1.2358
INFO - 2016-02-27 10:11:28 --> Config Class Initialized
INFO - 2016-02-27 10:11:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:11:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:11:28 --> Utf8 Class Initialized
INFO - 2016-02-27 10:11:28 --> URI Class Initialized
DEBUG - 2016-02-27 10:11:28 --> No URI present. Default controller set.
INFO - 2016-02-27 10:11:28 --> Router Class Initialized
INFO - 2016-02-27 10:11:28 --> Output Class Initialized
INFO - 2016-02-27 10:11:28 --> Security Class Initialized
DEBUG - 2016-02-27 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:11:28 --> Input Class Initialized
INFO - 2016-02-27 10:11:28 --> Language Class Initialized
INFO - 2016-02-27 10:11:28 --> Loader Class Initialized
INFO - 2016-02-27 10:11:28 --> Helper loaded: url_helper
INFO - 2016-02-27 10:11:28 --> Helper loaded: file_helper
INFO - 2016-02-27 10:11:28 --> Helper loaded: date_helper
INFO - 2016-02-27 10:11:28 --> Helper loaded: form_helper
INFO - 2016-02-27 10:11:28 --> Database Driver Class Initialized
INFO - 2016-02-27 10:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:11:29 --> Controller Class Initialized
INFO - 2016-02-27 10:11:30 --> Model Class Initialized
INFO - 2016-02-27 10:11:30 --> Model Class Initialized
INFO - 2016-02-27 10:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:11:30 --> Pagination Class Initialized
INFO - 2016-02-27 10:11:30 --> Helper loaded: text_helper
INFO - 2016-02-27 10:11:30 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:11:30 --> Final output sent to browser
DEBUG - 2016-02-27 13:11:30 --> Total execution time: 1.1727
INFO - 2016-02-27 10:14:29 --> Config Class Initialized
INFO - 2016-02-27 10:14:29 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:14:29 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:14:29 --> Utf8 Class Initialized
INFO - 2016-02-27 10:14:29 --> URI Class Initialized
DEBUG - 2016-02-27 10:14:29 --> No URI present. Default controller set.
INFO - 2016-02-27 10:14:29 --> Router Class Initialized
INFO - 2016-02-27 10:14:29 --> Output Class Initialized
INFO - 2016-02-27 10:14:29 --> Security Class Initialized
DEBUG - 2016-02-27 10:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:14:29 --> Input Class Initialized
INFO - 2016-02-27 10:14:29 --> Language Class Initialized
INFO - 2016-02-27 10:14:29 --> Loader Class Initialized
INFO - 2016-02-27 10:14:29 --> Helper loaded: url_helper
INFO - 2016-02-27 10:14:29 --> Helper loaded: file_helper
INFO - 2016-02-27 10:14:29 --> Helper loaded: date_helper
INFO - 2016-02-27 10:14:29 --> Helper loaded: form_helper
INFO - 2016-02-27 10:14:29 --> Database Driver Class Initialized
INFO - 2016-02-27 10:14:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:14:30 --> Controller Class Initialized
INFO - 2016-02-27 10:14:30 --> Model Class Initialized
INFO - 2016-02-27 10:14:30 --> Model Class Initialized
INFO - 2016-02-27 10:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:14:30 --> Pagination Class Initialized
INFO - 2016-02-27 10:14:30 --> Helper loaded: text_helper
INFO - 2016-02-27 10:14:30 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:14:30 --> Final output sent to browser
DEBUG - 2016-02-27 13:14:30 --> Total execution time: 1.1433
INFO - 2016-02-27 10:14:38 --> Config Class Initialized
INFO - 2016-02-27 10:14:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:14:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:14:38 --> Utf8 Class Initialized
INFO - 2016-02-27 10:14:38 --> URI Class Initialized
DEBUG - 2016-02-27 10:14:38 --> No URI present. Default controller set.
INFO - 2016-02-27 10:14:38 --> Router Class Initialized
INFO - 2016-02-27 10:14:38 --> Output Class Initialized
INFO - 2016-02-27 10:14:38 --> Security Class Initialized
DEBUG - 2016-02-27 10:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:14:38 --> Input Class Initialized
INFO - 2016-02-27 10:14:38 --> Language Class Initialized
INFO - 2016-02-27 10:14:38 --> Loader Class Initialized
INFO - 2016-02-27 10:14:38 --> Helper loaded: url_helper
INFO - 2016-02-27 10:14:38 --> Helper loaded: file_helper
INFO - 2016-02-27 10:14:38 --> Helper loaded: date_helper
INFO - 2016-02-27 10:14:38 --> Helper loaded: form_helper
INFO - 2016-02-27 10:14:38 --> Database Driver Class Initialized
INFO - 2016-02-27 10:14:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:14:39 --> Controller Class Initialized
INFO - 2016-02-27 10:14:39 --> Model Class Initialized
INFO - 2016-02-27 10:14:39 --> Model Class Initialized
INFO - 2016-02-27 10:14:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:14:39 --> Pagination Class Initialized
INFO - 2016-02-27 10:14:39 --> Helper loaded: text_helper
INFO - 2016-02-27 10:14:39 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:14:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:14:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:14:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:14:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:14:39 --> Final output sent to browser
DEBUG - 2016-02-27 13:14:39 --> Total execution time: 1.1621
INFO - 2016-02-27 10:15:05 --> Config Class Initialized
INFO - 2016-02-27 10:15:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:15:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:15:05 --> Utf8 Class Initialized
INFO - 2016-02-27 10:15:05 --> URI Class Initialized
DEBUG - 2016-02-27 10:15:05 --> No URI present. Default controller set.
INFO - 2016-02-27 10:15:05 --> Router Class Initialized
INFO - 2016-02-27 10:15:05 --> Output Class Initialized
INFO - 2016-02-27 10:15:05 --> Security Class Initialized
DEBUG - 2016-02-27 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:15:05 --> Input Class Initialized
INFO - 2016-02-27 10:15:05 --> Language Class Initialized
INFO - 2016-02-27 10:15:05 --> Loader Class Initialized
INFO - 2016-02-27 10:15:05 --> Helper loaded: url_helper
INFO - 2016-02-27 10:15:05 --> Helper loaded: file_helper
INFO - 2016-02-27 10:15:05 --> Helper loaded: date_helper
INFO - 2016-02-27 10:15:05 --> Helper loaded: form_helper
INFO - 2016-02-27 10:15:05 --> Database Driver Class Initialized
INFO - 2016-02-27 10:15:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:15:06 --> Controller Class Initialized
INFO - 2016-02-27 10:15:06 --> Model Class Initialized
INFO - 2016-02-27 10:15:06 --> Model Class Initialized
INFO - 2016-02-27 10:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:15:06 --> Pagination Class Initialized
INFO - 2016-02-27 10:15:06 --> Helper loaded: text_helper
INFO - 2016-02-27 10:15:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:15:06 --> Final output sent to browser
DEBUG - 2016-02-27 13:15:06 --> Total execution time: 1.1436
INFO - 2016-02-27 10:16:51 --> Config Class Initialized
INFO - 2016-02-27 10:16:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:16:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:16:51 --> Utf8 Class Initialized
INFO - 2016-02-27 10:16:51 --> URI Class Initialized
DEBUG - 2016-02-27 10:16:51 --> No URI present. Default controller set.
INFO - 2016-02-27 10:16:51 --> Router Class Initialized
INFO - 2016-02-27 10:16:51 --> Output Class Initialized
INFO - 2016-02-27 10:16:51 --> Security Class Initialized
DEBUG - 2016-02-27 10:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:16:51 --> Input Class Initialized
INFO - 2016-02-27 10:16:51 --> Language Class Initialized
INFO - 2016-02-27 10:16:51 --> Loader Class Initialized
INFO - 2016-02-27 10:16:51 --> Helper loaded: url_helper
INFO - 2016-02-27 10:16:51 --> Helper loaded: file_helper
INFO - 2016-02-27 10:16:51 --> Helper loaded: date_helper
INFO - 2016-02-27 10:16:51 --> Helper loaded: form_helper
INFO - 2016-02-27 10:16:51 --> Database Driver Class Initialized
INFO - 2016-02-27 10:16:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:16:52 --> Controller Class Initialized
INFO - 2016-02-27 10:16:52 --> Model Class Initialized
INFO - 2016-02-27 10:16:52 --> Model Class Initialized
INFO - 2016-02-27 10:16:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:16:52 --> Pagination Class Initialized
INFO - 2016-02-27 10:16:52 --> Helper loaded: text_helper
INFO - 2016-02-27 10:16:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:16:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:16:52 --> Final output sent to browser
DEBUG - 2016-02-27 13:16:52 --> Total execution time: 1.1187
INFO - 2016-02-27 10:18:50 --> Config Class Initialized
INFO - 2016-02-27 10:18:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:18:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:18:50 --> Utf8 Class Initialized
INFO - 2016-02-27 10:18:50 --> URI Class Initialized
DEBUG - 2016-02-27 10:18:50 --> No URI present. Default controller set.
INFO - 2016-02-27 10:18:50 --> Router Class Initialized
INFO - 2016-02-27 10:18:50 --> Output Class Initialized
INFO - 2016-02-27 10:18:50 --> Security Class Initialized
DEBUG - 2016-02-27 10:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:18:50 --> Input Class Initialized
INFO - 2016-02-27 10:18:50 --> Language Class Initialized
INFO - 2016-02-27 10:18:50 --> Loader Class Initialized
INFO - 2016-02-27 10:18:50 --> Helper loaded: url_helper
INFO - 2016-02-27 10:18:50 --> Helper loaded: file_helper
INFO - 2016-02-27 10:18:50 --> Helper loaded: date_helper
INFO - 2016-02-27 10:18:50 --> Helper loaded: form_helper
INFO - 2016-02-27 10:18:50 --> Database Driver Class Initialized
INFO - 2016-02-27 10:18:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:18:51 --> Controller Class Initialized
INFO - 2016-02-27 10:18:51 --> Model Class Initialized
INFO - 2016-02-27 10:18:51 --> Model Class Initialized
INFO - 2016-02-27 10:18:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:18:51 --> Pagination Class Initialized
INFO - 2016-02-27 10:18:51 --> Helper loaded: text_helper
INFO - 2016-02-27 10:18:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:18:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:18:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:18:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:18:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:18:51 --> Final output sent to browser
DEBUG - 2016-02-27 13:18:51 --> Total execution time: 1.0942
INFO - 2016-02-27 10:32:26 --> Config Class Initialized
INFO - 2016-02-27 10:32:26 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:32:26 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:32:26 --> Utf8 Class Initialized
INFO - 2016-02-27 10:32:26 --> URI Class Initialized
DEBUG - 2016-02-27 10:32:26 --> No URI present. Default controller set.
INFO - 2016-02-27 10:32:26 --> Router Class Initialized
INFO - 2016-02-27 10:32:26 --> Output Class Initialized
INFO - 2016-02-27 10:32:26 --> Security Class Initialized
DEBUG - 2016-02-27 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:32:26 --> Input Class Initialized
INFO - 2016-02-27 10:32:26 --> Language Class Initialized
INFO - 2016-02-27 10:32:26 --> Loader Class Initialized
INFO - 2016-02-27 10:32:26 --> Helper loaded: url_helper
INFO - 2016-02-27 10:32:26 --> Helper loaded: file_helper
INFO - 2016-02-27 10:32:26 --> Helper loaded: date_helper
INFO - 2016-02-27 10:32:26 --> Helper loaded: form_helper
INFO - 2016-02-27 10:32:26 --> Database Driver Class Initialized
INFO - 2016-02-27 10:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:32:27 --> Controller Class Initialized
INFO - 2016-02-27 10:32:27 --> Model Class Initialized
INFO - 2016-02-27 10:32:27 --> Model Class Initialized
INFO - 2016-02-27 10:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:32:27 --> Pagination Class Initialized
INFO - 2016-02-27 10:32:27 --> Helper loaded: text_helper
INFO - 2016-02-27 10:32:27 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:32:27 --> Final output sent to browser
DEBUG - 2016-02-27 13:32:27 --> Total execution time: 1.5478
INFO - 2016-02-27 10:33:24 --> Config Class Initialized
INFO - 2016-02-27 10:33:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:33:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:33:24 --> Utf8 Class Initialized
INFO - 2016-02-27 10:33:24 --> URI Class Initialized
DEBUG - 2016-02-27 10:33:24 --> No URI present. Default controller set.
INFO - 2016-02-27 10:33:24 --> Router Class Initialized
INFO - 2016-02-27 10:33:24 --> Output Class Initialized
INFO - 2016-02-27 10:33:24 --> Security Class Initialized
DEBUG - 2016-02-27 10:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:33:24 --> Input Class Initialized
INFO - 2016-02-27 10:33:24 --> Language Class Initialized
INFO - 2016-02-27 10:33:24 --> Loader Class Initialized
INFO - 2016-02-27 10:33:24 --> Helper loaded: url_helper
INFO - 2016-02-27 10:33:24 --> Helper loaded: file_helper
INFO - 2016-02-27 10:33:24 --> Helper loaded: date_helper
INFO - 2016-02-27 10:33:24 --> Helper loaded: form_helper
INFO - 2016-02-27 10:33:24 --> Database Driver Class Initialized
INFO - 2016-02-27 10:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:33:25 --> Controller Class Initialized
INFO - 2016-02-27 10:33:25 --> Model Class Initialized
INFO - 2016-02-27 10:33:25 --> Model Class Initialized
INFO - 2016-02-27 10:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:33:25 --> Pagination Class Initialized
INFO - 2016-02-27 10:33:25 --> Helper loaded: text_helper
INFO - 2016-02-27 10:33:25 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:33:25 --> Final output sent to browser
DEBUG - 2016-02-27 13:33:25 --> Total execution time: 1.1667
INFO - 2016-02-27 10:33:41 --> Config Class Initialized
INFO - 2016-02-27 10:33:41 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:33:41 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:33:41 --> Utf8 Class Initialized
INFO - 2016-02-27 10:33:41 --> URI Class Initialized
DEBUG - 2016-02-27 10:33:41 --> No URI present. Default controller set.
INFO - 2016-02-27 10:33:41 --> Router Class Initialized
INFO - 2016-02-27 10:33:41 --> Output Class Initialized
INFO - 2016-02-27 10:33:41 --> Security Class Initialized
DEBUG - 2016-02-27 10:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:33:41 --> Input Class Initialized
INFO - 2016-02-27 10:33:41 --> Language Class Initialized
INFO - 2016-02-27 10:33:41 --> Loader Class Initialized
INFO - 2016-02-27 10:33:41 --> Helper loaded: url_helper
INFO - 2016-02-27 10:33:41 --> Helper loaded: file_helper
INFO - 2016-02-27 10:33:41 --> Helper loaded: date_helper
INFO - 2016-02-27 10:33:41 --> Helper loaded: form_helper
INFO - 2016-02-27 10:33:41 --> Database Driver Class Initialized
INFO - 2016-02-27 10:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:33:42 --> Controller Class Initialized
INFO - 2016-02-27 10:33:42 --> Model Class Initialized
INFO - 2016-02-27 10:33:42 --> Model Class Initialized
INFO - 2016-02-27 10:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:33:42 --> Pagination Class Initialized
INFO - 2016-02-27 10:33:42 --> Helper loaded: text_helper
INFO - 2016-02-27 10:33:42 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:33:42 --> Final output sent to browser
DEBUG - 2016-02-27 13:33:42 --> Total execution time: 1.1576
INFO - 2016-02-27 10:39:28 --> Config Class Initialized
INFO - 2016-02-27 10:39:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:39:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:39:28 --> Utf8 Class Initialized
INFO - 2016-02-27 10:39:28 --> URI Class Initialized
DEBUG - 2016-02-27 10:39:28 --> No URI present. Default controller set.
INFO - 2016-02-27 10:39:28 --> Router Class Initialized
INFO - 2016-02-27 10:39:28 --> Output Class Initialized
INFO - 2016-02-27 10:39:28 --> Security Class Initialized
DEBUG - 2016-02-27 10:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:39:28 --> Input Class Initialized
INFO - 2016-02-27 10:39:28 --> Language Class Initialized
INFO - 2016-02-27 10:39:28 --> Loader Class Initialized
INFO - 2016-02-27 10:39:28 --> Helper loaded: url_helper
INFO - 2016-02-27 10:39:28 --> Helper loaded: file_helper
INFO - 2016-02-27 10:39:28 --> Helper loaded: date_helper
INFO - 2016-02-27 10:39:28 --> Helper loaded: form_helper
INFO - 2016-02-27 10:39:28 --> Database Driver Class Initialized
INFO - 2016-02-27 10:39:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:39:29 --> Controller Class Initialized
INFO - 2016-02-27 10:39:29 --> Model Class Initialized
INFO - 2016-02-27 10:39:29 --> Model Class Initialized
INFO - 2016-02-27 10:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:39:29 --> Pagination Class Initialized
INFO - 2016-02-27 10:39:29 --> Helper loaded: text_helper
INFO - 2016-02-27 10:39:29 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:39:29 --> Final output sent to browser
DEBUG - 2016-02-27 13:39:29 --> Total execution time: 1.1123
INFO - 2016-02-27 10:39:52 --> Config Class Initialized
INFO - 2016-02-27 10:39:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:39:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:39:52 --> Utf8 Class Initialized
INFO - 2016-02-27 10:39:52 --> URI Class Initialized
DEBUG - 2016-02-27 10:39:52 --> No URI present. Default controller set.
INFO - 2016-02-27 10:39:52 --> Router Class Initialized
INFO - 2016-02-27 10:39:52 --> Output Class Initialized
INFO - 2016-02-27 10:39:52 --> Security Class Initialized
DEBUG - 2016-02-27 10:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:39:52 --> Input Class Initialized
INFO - 2016-02-27 10:39:52 --> Language Class Initialized
INFO - 2016-02-27 10:39:52 --> Loader Class Initialized
INFO - 2016-02-27 10:39:52 --> Helper loaded: url_helper
INFO - 2016-02-27 10:39:52 --> Helper loaded: file_helper
INFO - 2016-02-27 10:39:52 --> Helper loaded: date_helper
INFO - 2016-02-27 10:39:52 --> Helper loaded: form_helper
INFO - 2016-02-27 10:39:52 --> Database Driver Class Initialized
INFO - 2016-02-27 10:39:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:39:53 --> Controller Class Initialized
INFO - 2016-02-27 10:39:53 --> Model Class Initialized
INFO - 2016-02-27 10:39:53 --> Model Class Initialized
INFO - 2016-02-27 10:39:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:39:53 --> Pagination Class Initialized
INFO - 2016-02-27 10:39:53 --> Helper loaded: text_helper
INFO - 2016-02-27 10:39:53 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:39:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:39:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:39:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:39:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:39:53 --> Final output sent to browser
DEBUG - 2016-02-27 13:39:53 --> Total execution time: 1.1138
INFO - 2016-02-27 10:40:57 --> Config Class Initialized
INFO - 2016-02-27 10:40:57 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:40:57 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:40:57 --> Utf8 Class Initialized
INFO - 2016-02-27 10:40:57 --> URI Class Initialized
DEBUG - 2016-02-27 10:40:57 --> No URI present. Default controller set.
INFO - 2016-02-27 10:40:57 --> Router Class Initialized
INFO - 2016-02-27 10:40:57 --> Output Class Initialized
INFO - 2016-02-27 10:40:57 --> Security Class Initialized
DEBUG - 2016-02-27 10:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:40:57 --> Input Class Initialized
INFO - 2016-02-27 10:40:57 --> Language Class Initialized
INFO - 2016-02-27 10:40:57 --> Loader Class Initialized
INFO - 2016-02-27 10:40:57 --> Helper loaded: url_helper
INFO - 2016-02-27 10:40:57 --> Helper loaded: file_helper
INFO - 2016-02-27 10:40:57 --> Helper loaded: date_helper
INFO - 2016-02-27 10:40:57 --> Helper loaded: form_helper
INFO - 2016-02-27 10:40:57 --> Database Driver Class Initialized
INFO - 2016-02-27 10:40:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:40:58 --> Controller Class Initialized
INFO - 2016-02-27 10:40:58 --> Model Class Initialized
INFO - 2016-02-27 10:40:58 --> Model Class Initialized
INFO - 2016-02-27 10:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:40:58 --> Pagination Class Initialized
INFO - 2016-02-27 10:40:58 --> Helper loaded: text_helper
INFO - 2016-02-27 10:40:58 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:40:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:40:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:40:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:40:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:40:58 --> Final output sent to browser
DEBUG - 2016-02-27 13:40:58 --> Total execution time: 1.1164
INFO - 2016-02-27 10:41:14 --> Config Class Initialized
INFO - 2016-02-27 10:41:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:41:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:41:14 --> Utf8 Class Initialized
INFO - 2016-02-27 10:41:14 --> URI Class Initialized
DEBUG - 2016-02-27 10:41:14 --> No URI present. Default controller set.
INFO - 2016-02-27 10:41:14 --> Router Class Initialized
INFO - 2016-02-27 10:41:14 --> Output Class Initialized
INFO - 2016-02-27 10:41:14 --> Security Class Initialized
DEBUG - 2016-02-27 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:41:14 --> Input Class Initialized
INFO - 2016-02-27 10:41:14 --> Language Class Initialized
INFO - 2016-02-27 10:41:14 --> Loader Class Initialized
INFO - 2016-02-27 10:41:14 --> Helper loaded: url_helper
INFO - 2016-02-27 10:41:14 --> Helper loaded: file_helper
INFO - 2016-02-27 10:41:14 --> Helper loaded: date_helper
INFO - 2016-02-27 10:41:14 --> Helper loaded: form_helper
INFO - 2016-02-27 10:41:14 --> Database Driver Class Initialized
INFO - 2016-02-27 10:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:41:15 --> Controller Class Initialized
INFO - 2016-02-27 10:41:15 --> Model Class Initialized
INFO - 2016-02-27 10:41:15 --> Model Class Initialized
INFO - 2016-02-27 10:41:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:41:15 --> Pagination Class Initialized
INFO - 2016-02-27 10:41:15 --> Helper loaded: text_helper
INFO - 2016-02-27 10:41:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:41:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:41:15 --> Final output sent to browser
DEBUG - 2016-02-27 13:41:15 --> Total execution time: 1.1258
INFO - 2016-02-27 10:41:24 --> Config Class Initialized
INFO - 2016-02-27 10:41:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:41:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:41:24 --> Utf8 Class Initialized
INFO - 2016-02-27 10:41:24 --> URI Class Initialized
DEBUG - 2016-02-27 10:41:24 --> No URI present. Default controller set.
INFO - 2016-02-27 10:41:24 --> Router Class Initialized
INFO - 2016-02-27 10:41:24 --> Output Class Initialized
INFO - 2016-02-27 10:41:24 --> Security Class Initialized
DEBUG - 2016-02-27 10:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:41:24 --> Input Class Initialized
INFO - 2016-02-27 10:41:24 --> Language Class Initialized
INFO - 2016-02-27 10:41:24 --> Loader Class Initialized
INFO - 2016-02-27 10:41:24 --> Helper loaded: url_helper
INFO - 2016-02-27 10:41:24 --> Helper loaded: file_helper
INFO - 2016-02-27 10:41:24 --> Helper loaded: date_helper
INFO - 2016-02-27 10:41:24 --> Helper loaded: form_helper
INFO - 2016-02-27 10:41:24 --> Database Driver Class Initialized
INFO - 2016-02-27 10:41:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:41:25 --> Controller Class Initialized
INFO - 2016-02-27 10:41:25 --> Model Class Initialized
INFO - 2016-02-27 10:41:25 --> Model Class Initialized
INFO - 2016-02-27 10:41:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:41:25 --> Pagination Class Initialized
INFO - 2016-02-27 10:41:25 --> Helper loaded: text_helper
INFO - 2016-02-27 10:41:25 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:41:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:41:25 --> Final output sent to browser
DEBUG - 2016-02-27 13:41:25 --> Total execution time: 1.1195
INFO - 2016-02-27 10:41:51 --> Config Class Initialized
INFO - 2016-02-27 10:41:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:41:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:41:51 --> Utf8 Class Initialized
INFO - 2016-02-27 10:41:51 --> URI Class Initialized
DEBUG - 2016-02-27 10:41:51 --> No URI present. Default controller set.
INFO - 2016-02-27 10:41:51 --> Router Class Initialized
INFO - 2016-02-27 10:41:51 --> Output Class Initialized
INFO - 2016-02-27 10:41:51 --> Security Class Initialized
DEBUG - 2016-02-27 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:41:51 --> Input Class Initialized
INFO - 2016-02-27 10:41:51 --> Language Class Initialized
INFO - 2016-02-27 10:41:51 --> Loader Class Initialized
INFO - 2016-02-27 10:41:51 --> Helper loaded: url_helper
INFO - 2016-02-27 10:41:51 --> Helper loaded: file_helper
INFO - 2016-02-27 10:41:51 --> Helper loaded: date_helper
INFO - 2016-02-27 10:41:51 --> Helper loaded: form_helper
INFO - 2016-02-27 10:41:51 --> Database Driver Class Initialized
INFO - 2016-02-27 10:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:41:52 --> Controller Class Initialized
INFO - 2016-02-27 10:41:52 --> Model Class Initialized
INFO - 2016-02-27 10:41:52 --> Model Class Initialized
INFO - 2016-02-27 10:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:41:52 --> Pagination Class Initialized
INFO - 2016-02-27 10:41:52 --> Helper loaded: text_helper
INFO - 2016-02-27 10:41:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:41:52 --> Final output sent to browser
DEBUG - 2016-02-27 13:41:52 --> Total execution time: 1.1046
INFO - 2016-02-27 10:42:07 --> Config Class Initialized
INFO - 2016-02-27 10:42:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:42:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:42:07 --> Utf8 Class Initialized
INFO - 2016-02-27 10:42:07 --> URI Class Initialized
DEBUG - 2016-02-27 10:42:07 --> No URI present. Default controller set.
INFO - 2016-02-27 10:42:07 --> Router Class Initialized
INFO - 2016-02-27 10:42:07 --> Output Class Initialized
INFO - 2016-02-27 10:42:07 --> Security Class Initialized
DEBUG - 2016-02-27 10:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:42:07 --> Input Class Initialized
INFO - 2016-02-27 10:42:07 --> Language Class Initialized
INFO - 2016-02-27 10:42:07 --> Loader Class Initialized
INFO - 2016-02-27 10:42:07 --> Helper loaded: url_helper
INFO - 2016-02-27 10:42:07 --> Helper loaded: file_helper
INFO - 2016-02-27 10:42:07 --> Helper loaded: date_helper
INFO - 2016-02-27 10:42:07 --> Helper loaded: form_helper
INFO - 2016-02-27 10:42:07 --> Database Driver Class Initialized
INFO - 2016-02-27 10:42:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:42:08 --> Controller Class Initialized
INFO - 2016-02-27 10:42:08 --> Model Class Initialized
INFO - 2016-02-27 10:42:08 --> Model Class Initialized
INFO - 2016-02-27 10:42:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:42:08 --> Pagination Class Initialized
INFO - 2016-02-27 10:42:08 --> Helper loaded: text_helper
INFO - 2016-02-27 10:42:08 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:42:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:42:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:42:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:42:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:42:08 --> Final output sent to browser
DEBUG - 2016-02-27 13:42:08 --> Total execution time: 1.1075
INFO - 2016-02-27 10:43:28 --> Config Class Initialized
INFO - 2016-02-27 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:43:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:43:28 --> Utf8 Class Initialized
INFO - 2016-02-27 10:43:28 --> URI Class Initialized
DEBUG - 2016-02-27 10:43:28 --> No URI present. Default controller set.
INFO - 2016-02-27 10:43:28 --> Router Class Initialized
INFO - 2016-02-27 10:43:28 --> Output Class Initialized
INFO - 2016-02-27 10:43:28 --> Security Class Initialized
DEBUG - 2016-02-27 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:43:28 --> Input Class Initialized
INFO - 2016-02-27 10:43:28 --> Language Class Initialized
INFO - 2016-02-27 10:43:28 --> Loader Class Initialized
INFO - 2016-02-27 10:43:28 --> Helper loaded: url_helper
INFO - 2016-02-27 10:43:28 --> Helper loaded: file_helper
INFO - 2016-02-27 10:43:28 --> Helper loaded: date_helper
INFO - 2016-02-27 10:43:28 --> Helper loaded: form_helper
INFO - 2016-02-27 10:43:28 --> Database Driver Class Initialized
INFO - 2016-02-27 10:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:43:29 --> Controller Class Initialized
INFO - 2016-02-27 10:43:29 --> Model Class Initialized
INFO - 2016-02-27 10:43:29 --> Model Class Initialized
INFO - 2016-02-27 10:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:43:29 --> Pagination Class Initialized
INFO - 2016-02-27 10:43:29 --> Helper loaded: text_helper
INFO - 2016-02-27 10:43:29 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:43:29 --> Final output sent to browser
DEBUG - 2016-02-27 13:43:29 --> Total execution time: 1.1373
INFO - 2016-02-27 10:46:35 --> Config Class Initialized
INFO - 2016-02-27 10:46:35 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:46:35 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:46:35 --> Utf8 Class Initialized
INFO - 2016-02-27 10:46:35 --> URI Class Initialized
DEBUG - 2016-02-27 10:46:35 --> No URI present. Default controller set.
INFO - 2016-02-27 10:46:35 --> Router Class Initialized
INFO - 2016-02-27 10:46:35 --> Output Class Initialized
INFO - 2016-02-27 10:46:35 --> Security Class Initialized
DEBUG - 2016-02-27 10:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:46:35 --> Input Class Initialized
INFO - 2016-02-27 10:46:35 --> Language Class Initialized
INFO - 2016-02-27 10:46:35 --> Loader Class Initialized
INFO - 2016-02-27 10:46:35 --> Helper loaded: url_helper
INFO - 2016-02-27 10:46:35 --> Helper loaded: file_helper
INFO - 2016-02-27 10:46:35 --> Helper loaded: date_helper
INFO - 2016-02-27 10:46:35 --> Helper loaded: form_helper
INFO - 2016-02-27 10:46:35 --> Database Driver Class Initialized
INFO - 2016-02-27 10:46:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:46:36 --> Controller Class Initialized
INFO - 2016-02-27 10:46:36 --> Model Class Initialized
INFO - 2016-02-27 10:46:36 --> Model Class Initialized
INFO - 2016-02-27 10:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:46:36 --> Pagination Class Initialized
INFO - 2016-02-27 10:46:36 --> Helper loaded: text_helper
INFO - 2016-02-27 10:46:36 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:46:36 --> Final output sent to browser
DEBUG - 2016-02-27 13:46:36 --> Total execution time: 1.1135
INFO - 2016-02-27 10:48:02 --> Config Class Initialized
INFO - 2016-02-27 10:48:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:48:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:48:02 --> Utf8 Class Initialized
INFO - 2016-02-27 10:48:02 --> URI Class Initialized
DEBUG - 2016-02-27 10:48:02 --> No URI present. Default controller set.
INFO - 2016-02-27 10:48:02 --> Router Class Initialized
INFO - 2016-02-27 10:48:02 --> Output Class Initialized
INFO - 2016-02-27 10:48:02 --> Security Class Initialized
DEBUG - 2016-02-27 10:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:48:02 --> Input Class Initialized
INFO - 2016-02-27 10:48:02 --> Language Class Initialized
INFO - 2016-02-27 10:48:02 --> Loader Class Initialized
INFO - 2016-02-27 10:48:02 --> Helper loaded: url_helper
INFO - 2016-02-27 10:48:02 --> Helper loaded: file_helper
INFO - 2016-02-27 10:48:02 --> Helper loaded: date_helper
INFO - 2016-02-27 10:48:02 --> Helper loaded: form_helper
INFO - 2016-02-27 10:48:02 --> Database Driver Class Initialized
INFO - 2016-02-27 10:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:48:03 --> Controller Class Initialized
INFO - 2016-02-27 10:48:03 --> Model Class Initialized
INFO - 2016-02-27 10:48:03 --> Model Class Initialized
INFO - 2016-02-27 10:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:48:03 --> Pagination Class Initialized
INFO - 2016-02-27 10:48:03 --> Helper loaded: text_helper
INFO - 2016-02-27 10:48:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:48:03 --> Final output sent to browser
DEBUG - 2016-02-27 13:48:03 --> Total execution time: 1.1293
INFO - 2016-02-27 10:48:32 --> Config Class Initialized
INFO - 2016-02-27 10:48:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:48:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:48:32 --> Utf8 Class Initialized
INFO - 2016-02-27 10:48:32 --> URI Class Initialized
DEBUG - 2016-02-27 10:48:32 --> No URI present. Default controller set.
INFO - 2016-02-27 10:48:32 --> Router Class Initialized
INFO - 2016-02-27 10:48:32 --> Output Class Initialized
INFO - 2016-02-27 10:48:32 --> Security Class Initialized
DEBUG - 2016-02-27 10:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:48:32 --> Input Class Initialized
INFO - 2016-02-27 10:48:32 --> Language Class Initialized
INFO - 2016-02-27 10:48:32 --> Loader Class Initialized
INFO - 2016-02-27 10:48:32 --> Helper loaded: url_helper
INFO - 2016-02-27 10:48:32 --> Helper loaded: file_helper
INFO - 2016-02-27 10:48:32 --> Helper loaded: date_helper
INFO - 2016-02-27 10:48:32 --> Helper loaded: form_helper
INFO - 2016-02-27 10:48:32 --> Database Driver Class Initialized
INFO - 2016-02-27 10:48:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:48:33 --> Controller Class Initialized
INFO - 2016-02-27 10:48:33 --> Model Class Initialized
INFO - 2016-02-27 10:48:33 --> Model Class Initialized
INFO - 2016-02-27 10:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:48:33 --> Pagination Class Initialized
INFO - 2016-02-27 10:48:33 --> Helper loaded: text_helper
INFO - 2016-02-27 10:48:33 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:48:33 --> Final output sent to browser
DEBUG - 2016-02-27 13:48:33 --> Total execution time: 1.2548
INFO - 2016-02-27 10:48:47 --> Config Class Initialized
INFO - 2016-02-27 10:48:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:48:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:48:47 --> Utf8 Class Initialized
INFO - 2016-02-27 10:48:47 --> URI Class Initialized
DEBUG - 2016-02-27 10:48:47 --> No URI present. Default controller set.
INFO - 2016-02-27 10:48:47 --> Router Class Initialized
INFO - 2016-02-27 10:48:48 --> Output Class Initialized
INFO - 2016-02-27 10:48:48 --> Security Class Initialized
DEBUG - 2016-02-27 10:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:48:48 --> Input Class Initialized
INFO - 2016-02-27 10:48:48 --> Language Class Initialized
INFO - 2016-02-27 10:48:48 --> Loader Class Initialized
INFO - 2016-02-27 10:48:48 --> Helper loaded: url_helper
INFO - 2016-02-27 10:48:48 --> Helper loaded: file_helper
INFO - 2016-02-27 10:48:48 --> Helper loaded: date_helper
INFO - 2016-02-27 10:48:48 --> Helper loaded: form_helper
INFO - 2016-02-27 10:48:48 --> Database Driver Class Initialized
INFO - 2016-02-27 10:48:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:48:49 --> Controller Class Initialized
INFO - 2016-02-27 10:48:49 --> Model Class Initialized
INFO - 2016-02-27 10:48:49 --> Model Class Initialized
INFO - 2016-02-27 10:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:48:49 --> Pagination Class Initialized
INFO - 2016-02-27 10:48:49 --> Helper loaded: text_helper
INFO - 2016-02-27 10:48:49 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:48:49 --> Final output sent to browser
DEBUG - 2016-02-27 13:48:49 --> Total execution time: 1.1251
INFO - 2016-02-27 10:49:11 --> Config Class Initialized
INFO - 2016-02-27 10:49:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:49:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:49:11 --> Utf8 Class Initialized
INFO - 2016-02-27 10:49:11 --> URI Class Initialized
DEBUG - 2016-02-27 10:49:11 --> No URI present. Default controller set.
INFO - 2016-02-27 10:49:11 --> Router Class Initialized
INFO - 2016-02-27 10:49:11 --> Output Class Initialized
INFO - 2016-02-27 10:49:11 --> Security Class Initialized
DEBUG - 2016-02-27 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:49:11 --> Input Class Initialized
INFO - 2016-02-27 10:49:11 --> Language Class Initialized
INFO - 2016-02-27 10:49:11 --> Loader Class Initialized
INFO - 2016-02-27 10:49:11 --> Helper loaded: url_helper
INFO - 2016-02-27 10:49:11 --> Helper loaded: file_helper
INFO - 2016-02-27 10:49:11 --> Helper loaded: date_helper
INFO - 2016-02-27 10:49:11 --> Helper loaded: form_helper
INFO - 2016-02-27 10:49:11 --> Database Driver Class Initialized
INFO - 2016-02-27 10:49:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:49:12 --> Controller Class Initialized
INFO - 2016-02-27 10:49:12 --> Model Class Initialized
INFO - 2016-02-27 10:49:12 --> Model Class Initialized
INFO - 2016-02-27 10:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:49:12 --> Pagination Class Initialized
INFO - 2016-02-27 10:49:12 --> Helper loaded: text_helper
INFO - 2016-02-27 10:49:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:49:12 --> Final output sent to browser
DEBUG - 2016-02-27 13:49:12 --> Total execution time: 1.1251
INFO - 2016-02-27 10:49:22 --> Config Class Initialized
INFO - 2016-02-27 10:49:22 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:49:22 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:49:22 --> Utf8 Class Initialized
INFO - 2016-02-27 10:49:22 --> URI Class Initialized
DEBUG - 2016-02-27 10:49:22 --> No URI present. Default controller set.
INFO - 2016-02-27 10:49:22 --> Router Class Initialized
INFO - 2016-02-27 10:49:22 --> Output Class Initialized
INFO - 2016-02-27 10:49:22 --> Security Class Initialized
DEBUG - 2016-02-27 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:49:22 --> Input Class Initialized
INFO - 2016-02-27 10:49:22 --> Language Class Initialized
INFO - 2016-02-27 10:49:22 --> Loader Class Initialized
INFO - 2016-02-27 10:49:22 --> Helper loaded: url_helper
INFO - 2016-02-27 10:49:22 --> Helper loaded: file_helper
INFO - 2016-02-27 10:49:22 --> Helper loaded: date_helper
INFO - 2016-02-27 10:49:22 --> Helper loaded: form_helper
INFO - 2016-02-27 10:49:22 --> Database Driver Class Initialized
INFO - 2016-02-27 10:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:49:23 --> Controller Class Initialized
INFO - 2016-02-27 10:49:23 --> Model Class Initialized
INFO - 2016-02-27 10:49:23 --> Model Class Initialized
INFO - 2016-02-27 10:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:49:23 --> Pagination Class Initialized
INFO - 2016-02-27 10:49:23 --> Helper loaded: text_helper
INFO - 2016-02-27 10:49:23 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:49:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:49:23 --> Final output sent to browser
DEBUG - 2016-02-27 13:49:23 --> Total execution time: 1.1627
INFO - 2016-02-27 10:49:43 --> Config Class Initialized
INFO - 2016-02-27 10:49:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:49:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:49:43 --> Utf8 Class Initialized
INFO - 2016-02-27 10:49:43 --> URI Class Initialized
DEBUG - 2016-02-27 10:49:43 --> No URI present. Default controller set.
INFO - 2016-02-27 10:49:43 --> Router Class Initialized
INFO - 2016-02-27 10:49:43 --> Output Class Initialized
INFO - 2016-02-27 10:49:43 --> Security Class Initialized
DEBUG - 2016-02-27 10:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:49:43 --> Input Class Initialized
INFO - 2016-02-27 10:49:43 --> Language Class Initialized
INFO - 2016-02-27 10:49:43 --> Loader Class Initialized
INFO - 2016-02-27 10:49:43 --> Helper loaded: url_helper
INFO - 2016-02-27 10:49:43 --> Helper loaded: file_helper
INFO - 2016-02-27 10:49:43 --> Helper loaded: date_helper
INFO - 2016-02-27 10:49:43 --> Helper loaded: form_helper
INFO - 2016-02-27 10:49:43 --> Database Driver Class Initialized
INFO - 2016-02-27 10:49:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:49:44 --> Controller Class Initialized
INFO - 2016-02-27 10:49:44 --> Model Class Initialized
INFO - 2016-02-27 10:49:44 --> Model Class Initialized
INFO - 2016-02-27 10:49:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:49:44 --> Pagination Class Initialized
INFO - 2016-02-27 10:49:44 --> Helper loaded: text_helper
INFO - 2016-02-27 10:49:44 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:49:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:49:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:49:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:49:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:49:45 --> Final output sent to browser
DEBUG - 2016-02-27 13:49:45 --> Total execution time: 1.1309
INFO - 2016-02-27 10:49:55 --> Config Class Initialized
INFO - 2016-02-27 10:49:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:49:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:49:55 --> Utf8 Class Initialized
INFO - 2016-02-27 10:49:55 --> URI Class Initialized
DEBUG - 2016-02-27 10:49:55 --> No URI present. Default controller set.
INFO - 2016-02-27 10:49:55 --> Router Class Initialized
INFO - 2016-02-27 10:49:55 --> Output Class Initialized
INFO - 2016-02-27 10:49:55 --> Security Class Initialized
DEBUG - 2016-02-27 10:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:49:55 --> Input Class Initialized
INFO - 2016-02-27 10:49:55 --> Language Class Initialized
INFO - 2016-02-27 10:49:55 --> Loader Class Initialized
INFO - 2016-02-27 10:49:55 --> Helper loaded: url_helper
INFO - 2016-02-27 10:49:55 --> Helper loaded: file_helper
INFO - 2016-02-27 10:49:55 --> Helper loaded: date_helper
INFO - 2016-02-27 10:49:55 --> Helper loaded: form_helper
INFO - 2016-02-27 10:49:55 --> Database Driver Class Initialized
INFO - 2016-02-27 10:49:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:49:56 --> Controller Class Initialized
INFO - 2016-02-27 10:49:56 --> Model Class Initialized
INFO - 2016-02-27 10:49:56 --> Model Class Initialized
INFO - 2016-02-27 10:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:49:56 --> Pagination Class Initialized
INFO - 2016-02-27 10:49:56 --> Helper loaded: text_helper
INFO - 2016-02-27 10:49:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:49:56 --> Final output sent to browser
DEBUG - 2016-02-27 13:49:56 --> Total execution time: 1.1258
INFO - 2016-02-27 10:51:10 --> Config Class Initialized
INFO - 2016-02-27 10:51:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:51:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:51:10 --> Utf8 Class Initialized
INFO - 2016-02-27 10:51:10 --> URI Class Initialized
DEBUG - 2016-02-27 10:51:10 --> No URI present. Default controller set.
INFO - 2016-02-27 10:51:10 --> Router Class Initialized
INFO - 2016-02-27 10:51:10 --> Output Class Initialized
INFO - 2016-02-27 10:51:10 --> Security Class Initialized
DEBUG - 2016-02-27 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:51:10 --> Input Class Initialized
INFO - 2016-02-27 10:51:10 --> Language Class Initialized
INFO - 2016-02-27 10:51:10 --> Loader Class Initialized
INFO - 2016-02-27 10:51:10 --> Helper loaded: url_helper
INFO - 2016-02-27 10:51:10 --> Helper loaded: file_helper
INFO - 2016-02-27 10:51:10 --> Helper loaded: date_helper
INFO - 2016-02-27 10:51:10 --> Helper loaded: form_helper
INFO - 2016-02-27 10:51:10 --> Database Driver Class Initialized
INFO - 2016-02-27 10:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:51:11 --> Controller Class Initialized
INFO - 2016-02-27 10:51:11 --> Model Class Initialized
INFO - 2016-02-27 10:51:11 --> Model Class Initialized
INFO - 2016-02-27 10:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:51:11 --> Pagination Class Initialized
INFO - 2016-02-27 10:51:11 --> Helper loaded: text_helper
INFO - 2016-02-27 10:51:11 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:51:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:51:11 --> Final output sent to browser
DEBUG - 2016-02-27 13:51:11 --> Total execution time: 1.1204
INFO - 2016-02-27 10:51:29 --> Config Class Initialized
INFO - 2016-02-27 10:51:29 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:51:29 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:51:29 --> Utf8 Class Initialized
INFO - 2016-02-27 10:51:29 --> URI Class Initialized
DEBUG - 2016-02-27 10:51:29 --> No URI present. Default controller set.
INFO - 2016-02-27 10:51:29 --> Router Class Initialized
INFO - 2016-02-27 10:51:29 --> Output Class Initialized
INFO - 2016-02-27 10:51:29 --> Security Class Initialized
DEBUG - 2016-02-27 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:51:29 --> Input Class Initialized
INFO - 2016-02-27 10:51:29 --> Language Class Initialized
INFO - 2016-02-27 10:51:29 --> Loader Class Initialized
INFO - 2016-02-27 10:51:29 --> Helper loaded: url_helper
INFO - 2016-02-27 10:51:29 --> Helper loaded: file_helper
INFO - 2016-02-27 10:51:29 --> Helper loaded: date_helper
INFO - 2016-02-27 10:51:29 --> Helper loaded: form_helper
INFO - 2016-02-27 10:51:29 --> Database Driver Class Initialized
INFO - 2016-02-27 10:51:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:51:30 --> Controller Class Initialized
INFO - 2016-02-27 10:51:30 --> Model Class Initialized
INFO - 2016-02-27 10:51:30 --> Model Class Initialized
INFO - 2016-02-27 10:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:51:30 --> Pagination Class Initialized
INFO - 2016-02-27 10:51:30 --> Helper loaded: text_helper
INFO - 2016-02-27 10:51:30 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:51:30 --> Final output sent to browser
DEBUG - 2016-02-27 13:51:30 --> Total execution time: 1.1066
INFO - 2016-02-27 10:51:40 --> Config Class Initialized
INFO - 2016-02-27 10:51:40 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:51:40 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:51:40 --> Utf8 Class Initialized
INFO - 2016-02-27 10:51:40 --> URI Class Initialized
INFO - 2016-02-27 10:51:40 --> Router Class Initialized
INFO - 2016-02-27 10:51:40 --> Output Class Initialized
INFO - 2016-02-27 10:51:40 --> Security Class Initialized
DEBUG - 2016-02-27 10:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:51:40 --> Input Class Initialized
INFO - 2016-02-27 10:51:40 --> Language Class Initialized
INFO - 2016-02-27 10:51:40 --> Loader Class Initialized
INFO - 2016-02-27 10:51:40 --> Helper loaded: url_helper
INFO - 2016-02-27 10:51:40 --> Helper loaded: file_helper
INFO - 2016-02-27 10:51:40 --> Helper loaded: date_helper
INFO - 2016-02-27 10:51:40 --> Helper loaded: form_helper
INFO - 2016-02-27 10:51:40 --> Database Driver Class Initialized
INFO - 2016-02-27 10:51:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:51:41 --> Controller Class Initialized
INFO - 2016-02-27 10:51:41 --> Model Class Initialized
INFO - 2016-02-27 10:51:41 --> Model Class Initialized
INFO - 2016-02-27 10:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:51:41 --> Pagination Class Initialized
INFO - 2016-02-27 10:51:41 --> Helper loaded: text_helper
INFO - 2016-02-27 10:51:41 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:51:41 --> Final output sent to browser
DEBUG - 2016-02-27 13:51:41 --> Total execution time: 1.2151
INFO - 2016-02-27 10:52:22 --> Config Class Initialized
INFO - 2016-02-27 10:52:22 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:52:22 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:52:22 --> Utf8 Class Initialized
INFO - 2016-02-27 10:52:22 --> URI Class Initialized
INFO - 2016-02-27 10:52:22 --> Router Class Initialized
INFO - 2016-02-27 10:52:22 --> Output Class Initialized
INFO - 2016-02-27 10:52:22 --> Security Class Initialized
DEBUG - 2016-02-27 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:52:22 --> Input Class Initialized
INFO - 2016-02-27 10:52:22 --> Language Class Initialized
INFO - 2016-02-27 10:52:22 --> Loader Class Initialized
INFO - 2016-02-27 10:52:22 --> Helper loaded: url_helper
INFO - 2016-02-27 10:52:22 --> Helper loaded: file_helper
INFO - 2016-02-27 10:52:22 --> Helper loaded: date_helper
INFO - 2016-02-27 10:52:22 --> Helper loaded: form_helper
INFO - 2016-02-27 10:52:22 --> Database Driver Class Initialized
INFO - 2016-02-27 10:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:52:23 --> Controller Class Initialized
INFO - 2016-02-27 10:52:23 --> Model Class Initialized
INFO - 2016-02-27 10:52:23 --> Model Class Initialized
INFO - 2016-02-27 10:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:52:23 --> Pagination Class Initialized
INFO - 2016-02-27 10:52:23 --> Helper loaded: text_helper
INFO - 2016-02-27 10:52:23 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:52:23 --> Final output sent to browser
DEBUG - 2016-02-27 13:52:23 --> Total execution time: 1.1291
INFO - 2016-02-27 10:53:34 --> Config Class Initialized
INFO - 2016-02-27 10:53:34 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:53:34 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:53:34 --> Utf8 Class Initialized
INFO - 2016-02-27 10:53:34 --> URI Class Initialized
INFO - 2016-02-27 10:53:34 --> Router Class Initialized
INFO - 2016-02-27 10:53:34 --> Output Class Initialized
INFO - 2016-02-27 10:53:34 --> Security Class Initialized
DEBUG - 2016-02-27 10:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:53:34 --> Input Class Initialized
INFO - 2016-02-27 10:53:34 --> Language Class Initialized
INFO - 2016-02-27 10:53:34 --> Loader Class Initialized
INFO - 2016-02-27 10:53:34 --> Helper loaded: url_helper
INFO - 2016-02-27 10:53:34 --> Helper loaded: file_helper
INFO - 2016-02-27 10:53:34 --> Helper loaded: date_helper
INFO - 2016-02-27 10:53:34 --> Helper loaded: form_helper
INFO - 2016-02-27 10:53:34 --> Database Driver Class Initialized
INFO - 2016-02-27 10:53:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:53:35 --> Controller Class Initialized
INFO - 2016-02-27 10:53:35 --> Model Class Initialized
INFO - 2016-02-27 10:53:35 --> Model Class Initialized
INFO - 2016-02-27 10:53:35 --> Form Validation Class Initialized
INFO - 2016-02-27 10:53:35 --> Helper loaded: text_helper
ERROR - 2016-02-27 10:53:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-27 10:53:37 --> Config Class Initialized
INFO - 2016-02-27 10:53:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:53:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:53:37 --> Utf8 Class Initialized
INFO - 2016-02-27 10:53:37 --> URI Class Initialized
INFO - 2016-02-27 10:53:37 --> Router Class Initialized
INFO - 2016-02-27 10:53:37 --> Output Class Initialized
INFO - 2016-02-27 10:53:37 --> Security Class Initialized
DEBUG - 2016-02-27 10:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:53:37 --> Input Class Initialized
INFO - 2016-02-27 10:53:37 --> Language Class Initialized
INFO - 2016-02-27 10:53:37 --> Loader Class Initialized
INFO - 2016-02-27 10:53:37 --> Helper loaded: url_helper
INFO - 2016-02-27 10:53:37 --> Helper loaded: file_helper
INFO - 2016-02-27 10:53:37 --> Helper loaded: date_helper
INFO - 2016-02-27 10:53:37 --> Helper loaded: form_helper
INFO - 2016-02-27 10:53:37 --> Database Driver Class Initialized
INFO - 2016-02-27 10:53:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:53:38 --> Controller Class Initialized
INFO - 2016-02-27 10:53:38 --> Model Class Initialized
INFO - 2016-02-27 10:53:38 --> Model Class Initialized
INFO - 2016-02-27 10:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:53:38 --> Pagination Class Initialized
INFO - 2016-02-27 10:53:38 --> Helper loaded: text_helper
INFO - 2016-02-27 10:53:38 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:53:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:53:38 --> Final output sent to browser
DEBUG - 2016-02-27 13:53:38 --> Total execution time: 1.1370
INFO - 2016-02-27 10:54:15 --> Config Class Initialized
INFO - 2016-02-27 10:54:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:54:15 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:54:15 --> Utf8 Class Initialized
INFO - 2016-02-27 10:54:15 --> URI Class Initialized
INFO - 2016-02-27 10:54:15 --> Router Class Initialized
INFO - 2016-02-27 10:54:15 --> Output Class Initialized
INFO - 2016-02-27 10:54:15 --> Security Class Initialized
DEBUG - 2016-02-27 10:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:54:15 --> Input Class Initialized
INFO - 2016-02-27 10:54:15 --> Language Class Initialized
INFO - 2016-02-27 10:54:15 --> Loader Class Initialized
INFO - 2016-02-27 10:54:15 --> Helper loaded: url_helper
INFO - 2016-02-27 10:54:15 --> Helper loaded: file_helper
INFO - 2016-02-27 10:54:15 --> Helper loaded: date_helper
INFO - 2016-02-27 10:54:15 --> Helper loaded: form_helper
INFO - 2016-02-27 10:54:15 --> Database Driver Class Initialized
INFO - 2016-02-27 10:54:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:54:16 --> Controller Class Initialized
INFO - 2016-02-27 10:54:16 --> Model Class Initialized
INFO - 2016-02-27 10:54:16 --> Model Class Initialized
INFO - 2016-02-27 10:54:16 --> Form Validation Class Initialized
INFO - 2016-02-27 10:54:16 --> Helper loaded: text_helper
ERROR - 2016-02-27 10:54:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-27 10:54:19 --> Config Class Initialized
INFO - 2016-02-27 10:54:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:54:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:54:19 --> Utf8 Class Initialized
INFO - 2016-02-27 10:54:19 --> URI Class Initialized
INFO - 2016-02-27 10:54:19 --> Router Class Initialized
INFO - 2016-02-27 10:54:19 --> Output Class Initialized
INFO - 2016-02-27 10:54:19 --> Security Class Initialized
DEBUG - 2016-02-27 10:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:54:19 --> Input Class Initialized
INFO - 2016-02-27 10:54:19 --> Language Class Initialized
INFO - 2016-02-27 10:54:19 --> Loader Class Initialized
INFO - 2016-02-27 10:54:19 --> Helper loaded: url_helper
INFO - 2016-02-27 10:54:19 --> Helper loaded: file_helper
INFO - 2016-02-27 10:54:19 --> Helper loaded: date_helper
INFO - 2016-02-27 10:54:19 --> Helper loaded: form_helper
INFO - 2016-02-27 10:54:19 --> Database Driver Class Initialized
INFO - 2016-02-27 10:54:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:54:20 --> Controller Class Initialized
INFO - 2016-02-27 10:54:20 --> Model Class Initialized
INFO - 2016-02-27 10:54:20 --> Model Class Initialized
INFO - 2016-02-27 10:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:54:20 --> Pagination Class Initialized
INFO - 2016-02-27 10:54:20 --> Helper loaded: text_helper
INFO - 2016-02-27 10:54:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:54:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:54:20 --> Final output sent to browser
DEBUG - 2016-02-27 13:54:20 --> Total execution time: 1.1276
INFO - 2016-02-27 10:55:07 --> Config Class Initialized
INFO - 2016-02-27 10:55:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:55:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:55:07 --> Utf8 Class Initialized
INFO - 2016-02-27 10:55:07 --> URI Class Initialized
INFO - 2016-02-27 10:55:07 --> Router Class Initialized
INFO - 2016-02-27 10:55:07 --> Output Class Initialized
INFO - 2016-02-27 10:55:07 --> Security Class Initialized
DEBUG - 2016-02-27 10:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:55:07 --> Input Class Initialized
INFO - 2016-02-27 10:55:07 --> Language Class Initialized
INFO - 2016-02-27 10:55:07 --> Loader Class Initialized
INFO - 2016-02-27 10:55:07 --> Helper loaded: url_helper
INFO - 2016-02-27 10:55:07 --> Helper loaded: file_helper
INFO - 2016-02-27 10:55:07 --> Helper loaded: date_helper
INFO - 2016-02-27 10:55:07 --> Helper loaded: form_helper
INFO - 2016-02-27 10:55:07 --> Database Driver Class Initialized
INFO - 2016-02-27 10:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:55:08 --> Controller Class Initialized
INFO - 2016-02-27 10:55:08 --> Model Class Initialized
INFO - 2016-02-27 10:55:08 --> Model Class Initialized
INFO - 2016-02-27 10:55:08 --> Form Validation Class Initialized
INFO - 2016-02-27 10:55:08 --> Helper loaded: text_helper
INFO - 2016-02-27 10:55:31 --> Config Class Initialized
INFO - 2016-02-27 10:55:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:55:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:55:31 --> Utf8 Class Initialized
INFO - 2016-02-27 10:55:31 --> URI Class Initialized
INFO - 2016-02-27 10:55:31 --> Router Class Initialized
INFO - 2016-02-27 10:55:31 --> Output Class Initialized
INFO - 2016-02-27 10:55:31 --> Security Class Initialized
DEBUG - 2016-02-27 10:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:55:31 --> Input Class Initialized
INFO - 2016-02-27 10:55:31 --> Language Class Initialized
INFO - 2016-02-27 10:55:31 --> Loader Class Initialized
INFO - 2016-02-27 10:55:31 --> Helper loaded: url_helper
INFO - 2016-02-27 10:55:31 --> Helper loaded: file_helper
INFO - 2016-02-27 10:55:31 --> Helper loaded: date_helper
INFO - 2016-02-27 10:55:31 --> Helper loaded: form_helper
INFO - 2016-02-27 10:55:31 --> Database Driver Class Initialized
INFO - 2016-02-27 10:55:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:55:32 --> Controller Class Initialized
INFO - 2016-02-27 10:55:32 --> Model Class Initialized
INFO - 2016-02-27 10:55:32 --> Model Class Initialized
INFO - 2016-02-27 10:55:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:55:32 --> Pagination Class Initialized
INFO - 2016-02-27 10:55:32 --> Helper loaded: text_helper
INFO - 2016-02-27 10:55:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:55:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:55:32 --> Final output sent to browser
DEBUG - 2016-02-27 13:55:32 --> Total execution time: 1.1294
INFO - 2016-02-27 10:55:38 --> Config Class Initialized
INFO - 2016-02-27 10:55:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:55:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:55:38 --> Utf8 Class Initialized
INFO - 2016-02-27 10:55:38 --> URI Class Initialized
INFO - 2016-02-27 10:55:38 --> Router Class Initialized
INFO - 2016-02-27 10:55:38 --> Output Class Initialized
INFO - 2016-02-27 10:55:38 --> Security Class Initialized
DEBUG - 2016-02-27 10:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:55:38 --> Input Class Initialized
INFO - 2016-02-27 10:55:38 --> Language Class Initialized
INFO - 2016-02-27 10:55:38 --> Loader Class Initialized
INFO - 2016-02-27 10:55:38 --> Helper loaded: url_helper
INFO - 2016-02-27 10:55:38 --> Helper loaded: file_helper
INFO - 2016-02-27 10:55:38 --> Helper loaded: date_helper
INFO - 2016-02-27 10:55:38 --> Helper loaded: form_helper
INFO - 2016-02-27 10:55:38 --> Database Driver Class Initialized
INFO - 2016-02-27 10:55:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:55:39 --> Controller Class Initialized
INFO - 2016-02-27 10:55:39 --> Model Class Initialized
INFO - 2016-02-27 10:55:39 --> Model Class Initialized
INFO - 2016-02-27 10:55:39 --> Form Validation Class Initialized
INFO - 2016-02-27 10:55:39 --> Helper loaded: text_helper
INFO - 2016-02-27 10:55:39 --> Final output sent to browser
DEBUG - 2016-02-27 10:55:39 --> Total execution time: 1.1182
INFO - 2016-02-27 10:55:45 --> Config Class Initialized
INFO - 2016-02-27 10:55:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:55:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:55:45 --> Utf8 Class Initialized
INFO - 2016-02-27 10:55:45 --> URI Class Initialized
INFO - 2016-02-27 10:55:45 --> Router Class Initialized
INFO - 2016-02-27 10:55:45 --> Output Class Initialized
INFO - 2016-02-27 10:55:45 --> Security Class Initialized
DEBUG - 2016-02-27 10:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:55:45 --> Input Class Initialized
INFO - 2016-02-27 10:55:45 --> Language Class Initialized
INFO - 2016-02-27 10:55:45 --> Loader Class Initialized
INFO - 2016-02-27 10:55:45 --> Helper loaded: url_helper
INFO - 2016-02-27 10:55:45 --> Helper loaded: file_helper
INFO - 2016-02-27 10:55:45 --> Helper loaded: date_helper
INFO - 2016-02-27 10:55:45 --> Helper loaded: form_helper
INFO - 2016-02-27 10:55:45 --> Database Driver Class Initialized
INFO - 2016-02-27 10:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:55:46 --> Controller Class Initialized
INFO - 2016-02-27 10:55:46 --> Model Class Initialized
INFO - 2016-02-27 10:55:46 --> Model Class Initialized
INFO - 2016-02-27 10:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:55:46 --> Pagination Class Initialized
INFO - 2016-02-27 10:55:46 --> Helper loaded: text_helper
INFO - 2016-02-27 10:55:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:55:46 --> Final output sent to browser
DEBUG - 2016-02-27 13:55:46 --> Total execution time: 1.1373
INFO - 2016-02-27 10:55:54 --> Config Class Initialized
INFO - 2016-02-27 10:55:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:55:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:55:54 --> Utf8 Class Initialized
INFO - 2016-02-27 10:55:54 --> URI Class Initialized
INFO - 2016-02-27 10:55:54 --> Router Class Initialized
INFO - 2016-02-27 10:55:54 --> Output Class Initialized
INFO - 2016-02-27 10:55:54 --> Security Class Initialized
DEBUG - 2016-02-27 10:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:55:54 --> Input Class Initialized
INFO - 2016-02-27 10:55:54 --> Language Class Initialized
INFO - 2016-02-27 10:55:54 --> Loader Class Initialized
INFO - 2016-02-27 10:55:54 --> Helper loaded: url_helper
INFO - 2016-02-27 10:55:54 --> Helper loaded: file_helper
INFO - 2016-02-27 10:55:54 --> Helper loaded: date_helper
INFO - 2016-02-27 10:55:54 --> Helper loaded: form_helper
INFO - 2016-02-27 10:55:54 --> Database Driver Class Initialized
INFO - 2016-02-27 10:55:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:55:55 --> Controller Class Initialized
INFO - 2016-02-27 10:55:55 --> Model Class Initialized
INFO - 2016-02-27 10:55:55 --> Model Class Initialized
INFO - 2016-02-27 10:55:55 --> Form Validation Class Initialized
INFO - 2016-02-27 10:55:55 --> Helper loaded: text_helper
ERROR - 2016-02-27 10:55:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-27 10:55:55 --> Final output sent to browser
DEBUG - 2016-02-27 10:55:55 --> Total execution time: 1.1119
INFO - 2016-02-27 10:56:32 --> Config Class Initialized
INFO - 2016-02-27 10:56:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:56:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:56:32 --> Utf8 Class Initialized
INFO - 2016-02-27 10:56:32 --> URI Class Initialized
INFO - 2016-02-27 10:56:32 --> Router Class Initialized
INFO - 2016-02-27 10:56:32 --> Output Class Initialized
INFO - 2016-02-27 10:56:32 --> Security Class Initialized
DEBUG - 2016-02-27 10:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:56:32 --> Input Class Initialized
INFO - 2016-02-27 10:56:32 --> Language Class Initialized
INFO - 2016-02-27 10:56:32 --> Loader Class Initialized
INFO - 2016-02-27 10:56:32 --> Helper loaded: url_helper
INFO - 2016-02-27 10:56:32 --> Helper loaded: file_helper
INFO - 2016-02-27 10:56:32 --> Helper loaded: date_helper
INFO - 2016-02-27 10:56:32 --> Helper loaded: form_helper
INFO - 2016-02-27 10:56:32 --> Database Driver Class Initialized
INFO - 2016-02-27 10:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:56:34 --> Controller Class Initialized
INFO - 2016-02-27 10:56:34 --> Model Class Initialized
INFO - 2016-02-27 10:56:34 --> Model Class Initialized
INFO - 2016-02-27 10:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:56:34 --> Pagination Class Initialized
INFO - 2016-02-27 10:56:34 --> Helper loaded: text_helper
INFO - 2016-02-27 10:56:34 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:56:34 --> Final output sent to browser
DEBUG - 2016-02-27 13:56:34 --> Total execution time: 1.1556
INFO - 2016-02-27 10:56:36 --> Config Class Initialized
INFO - 2016-02-27 10:56:36 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:56:36 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:56:36 --> Utf8 Class Initialized
INFO - 2016-02-27 10:56:36 --> URI Class Initialized
DEBUG - 2016-02-27 10:56:36 --> No URI present. Default controller set.
INFO - 2016-02-27 10:56:36 --> Router Class Initialized
INFO - 2016-02-27 10:56:36 --> Output Class Initialized
INFO - 2016-02-27 10:56:36 --> Security Class Initialized
DEBUG - 2016-02-27 10:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:56:36 --> Input Class Initialized
INFO - 2016-02-27 10:56:36 --> Language Class Initialized
INFO - 2016-02-27 10:56:36 --> Loader Class Initialized
INFO - 2016-02-27 10:56:36 --> Helper loaded: url_helper
INFO - 2016-02-27 10:56:36 --> Helper loaded: file_helper
INFO - 2016-02-27 10:56:36 --> Helper loaded: date_helper
INFO - 2016-02-27 10:56:36 --> Helper loaded: form_helper
INFO - 2016-02-27 10:56:36 --> Database Driver Class Initialized
INFO - 2016-02-27 10:56:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:56:37 --> Controller Class Initialized
INFO - 2016-02-27 10:56:37 --> Model Class Initialized
INFO - 2016-02-27 10:56:37 --> Model Class Initialized
INFO - 2016-02-27 10:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:56:37 --> Pagination Class Initialized
INFO - 2016-02-27 10:56:37 --> Helper loaded: text_helper
INFO - 2016-02-27 10:56:37 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:56:37 --> Final output sent to browser
DEBUG - 2016-02-27 13:56:37 --> Total execution time: 1.1741
INFO - 2016-02-27 10:56:53 --> Config Class Initialized
INFO - 2016-02-27 10:56:53 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:56:53 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:56:53 --> Utf8 Class Initialized
INFO - 2016-02-27 10:56:53 --> URI Class Initialized
INFO - 2016-02-27 10:56:53 --> Router Class Initialized
INFO - 2016-02-27 10:56:53 --> Output Class Initialized
INFO - 2016-02-27 10:56:53 --> Security Class Initialized
DEBUG - 2016-02-27 10:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:56:53 --> Input Class Initialized
INFO - 2016-02-27 10:56:53 --> Language Class Initialized
INFO - 2016-02-27 10:56:53 --> Loader Class Initialized
INFO - 2016-02-27 10:56:53 --> Helper loaded: url_helper
INFO - 2016-02-27 10:56:53 --> Helper loaded: file_helper
INFO - 2016-02-27 10:56:53 --> Helper loaded: date_helper
INFO - 2016-02-27 10:56:53 --> Helper loaded: form_helper
INFO - 2016-02-27 10:56:53 --> Database Driver Class Initialized
INFO - 2016-02-27 10:56:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:56:54 --> Controller Class Initialized
INFO - 2016-02-27 10:56:54 --> Model Class Initialized
INFO - 2016-02-27 10:56:54 --> Model Class Initialized
INFO - 2016-02-27 10:56:54 --> Form Validation Class Initialized
INFO - 2016-02-27 10:56:54 --> Helper loaded: text_helper
INFO - 2016-02-27 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 10:56:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 10:56:54 --> Model Class Initialized
ERROR - 2016-02-27 10:56:54 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php on line 37 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-27 10:56:54 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-27 10:56:54 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-27 10:56:54 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-27 10:56:57 --> Config Class Initialized
INFO - 2016-02-27 10:56:57 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:56:57 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:56:57 --> Utf8 Class Initialized
INFO - 2016-02-27 10:56:57 --> URI Class Initialized
DEBUG - 2016-02-27 10:56:57 --> No URI present. Default controller set.
INFO - 2016-02-27 10:56:57 --> Router Class Initialized
INFO - 2016-02-27 10:56:57 --> Output Class Initialized
INFO - 2016-02-27 10:56:57 --> Security Class Initialized
DEBUG - 2016-02-27 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:56:57 --> Input Class Initialized
INFO - 2016-02-27 10:56:57 --> Language Class Initialized
INFO - 2016-02-27 10:56:57 --> Loader Class Initialized
INFO - 2016-02-27 10:56:57 --> Helper loaded: url_helper
INFO - 2016-02-27 10:56:57 --> Helper loaded: file_helper
INFO - 2016-02-27 10:56:57 --> Helper loaded: date_helper
INFO - 2016-02-27 10:56:57 --> Helper loaded: form_helper
INFO - 2016-02-27 10:56:57 --> Database Driver Class Initialized
INFO - 2016-02-27 10:56:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:56:58 --> Controller Class Initialized
INFO - 2016-02-27 10:56:58 --> Model Class Initialized
INFO - 2016-02-27 10:56:58 --> Model Class Initialized
INFO - 2016-02-27 10:56:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:56:58 --> Pagination Class Initialized
INFO - 2016-02-27 10:56:58 --> Helper loaded: text_helper
INFO - 2016-02-27 10:56:58 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:56:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:56:58 --> Final output sent to browser
DEBUG - 2016-02-27 13:56:58 --> Total execution time: 1.1125
INFO - 2016-02-27 10:57:07 --> Config Class Initialized
INFO - 2016-02-27 10:57:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:57:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:57:07 --> Utf8 Class Initialized
INFO - 2016-02-27 10:57:07 --> URI Class Initialized
INFO - 2016-02-27 10:57:07 --> Router Class Initialized
INFO - 2016-02-27 10:57:07 --> Output Class Initialized
INFO - 2016-02-27 10:57:07 --> Security Class Initialized
DEBUG - 2016-02-27 10:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:57:07 --> Input Class Initialized
INFO - 2016-02-27 10:57:07 --> Language Class Initialized
INFO - 2016-02-27 10:57:07 --> Loader Class Initialized
INFO - 2016-02-27 10:57:07 --> Helper loaded: url_helper
INFO - 2016-02-27 10:57:07 --> Helper loaded: file_helper
INFO - 2016-02-27 10:57:07 --> Helper loaded: date_helper
INFO - 2016-02-27 10:57:07 --> Helper loaded: form_helper
INFO - 2016-02-27 10:57:07 --> Database Driver Class Initialized
INFO - 2016-02-27 10:57:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:57:08 --> Controller Class Initialized
INFO - 2016-02-27 10:57:08 --> Model Class Initialized
INFO - 2016-02-27 10:57:08 --> Model Class Initialized
INFO - 2016-02-27 10:57:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:57:08 --> Pagination Class Initialized
INFO - 2016-02-27 10:57:08 --> Helper loaded: text_helper
INFO - 2016-02-27 10:57:08 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:57:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:57:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:57:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 13:57:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 13:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:57:09 --> Final output sent to browser
DEBUG - 2016-02-27 13:57:09 --> Total execution time: 1.2697
INFO - 2016-02-27 10:57:41 --> Config Class Initialized
INFO - 2016-02-27 10:57:41 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:57:41 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:57:41 --> Utf8 Class Initialized
INFO - 2016-02-27 10:57:41 --> URI Class Initialized
DEBUG - 2016-02-27 10:57:41 --> No URI present. Default controller set.
INFO - 2016-02-27 10:57:41 --> Router Class Initialized
INFO - 2016-02-27 10:57:41 --> Output Class Initialized
INFO - 2016-02-27 10:57:41 --> Security Class Initialized
DEBUG - 2016-02-27 10:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:57:41 --> Input Class Initialized
INFO - 2016-02-27 10:57:41 --> Language Class Initialized
INFO - 2016-02-27 10:57:41 --> Loader Class Initialized
INFO - 2016-02-27 10:57:41 --> Helper loaded: url_helper
INFO - 2016-02-27 10:57:41 --> Helper loaded: file_helper
INFO - 2016-02-27 10:57:41 --> Helper loaded: date_helper
INFO - 2016-02-27 10:57:41 --> Helper loaded: form_helper
INFO - 2016-02-27 10:57:41 --> Database Driver Class Initialized
INFO - 2016-02-27 10:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:57:42 --> Controller Class Initialized
INFO - 2016-02-27 10:57:42 --> Model Class Initialized
INFO - 2016-02-27 10:57:42 --> Model Class Initialized
INFO - 2016-02-27 10:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:57:42 --> Pagination Class Initialized
INFO - 2016-02-27 10:57:42 --> Helper loaded: text_helper
INFO - 2016-02-27 10:57:42 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 13:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:57:42 --> Final output sent to browser
DEBUG - 2016-02-27 13:57:42 --> Total execution time: 1.1930
INFO - 2016-02-27 10:57:46 --> Config Class Initialized
INFO - 2016-02-27 10:57:46 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:57:46 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:57:46 --> Utf8 Class Initialized
INFO - 2016-02-27 10:57:46 --> URI Class Initialized
INFO - 2016-02-27 10:57:46 --> Router Class Initialized
INFO - 2016-02-27 10:57:47 --> Output Class Initialized
INFO - 2016-02-27 10:57:47 --> Security Class Initialized
DEBUG - 2016-02-27 10:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:57:47 --> Input Class Initialized
INFO - 2016-02-27 10:57:47 --> Language Class Initialized
INFO - 2016-02-27 10:57:47 --> Loader Class Initialized
INFO - 2016-02-27 10:57:47 --> Helper loaded: url_helper
INFO - 2016-02-27 10:57:47 --> Helper loaded: file_helper
INFO - 2016-02-27 10:57:47 --> Helper loaded: date_helper
INFO - 2016-02-27 10:57:47 --> Helper loaded: form_helper
INFO - 2016-02-27 10:57:47 --> Database Driver Class Initialized
INFO - 2016-02-27 10:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:57:48 --> Controller Class Initialized
INFO - 2016-02-27 10:57:48 --> Model Class Initialized
INFO - 2016-02-27 10:57:48 --> Model Class Initialized
INFO - 2016-02-27 10:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:57:48 --> Pagination Class Initialized
INFO - 2016-02-27 10:57:48 --> Helper loaded: text_helper
INFO - 2016-02-27 10:57:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:57:48 --> Final output sent to browser
DEBUG - 2016-02-27 13:57:48 --> Total execution time: 1.1217
INFO - 2016-02-27 10:57:53 --> Config Class Initialized
INFO - 2016-02-27 10:57:53 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:57:53 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:57:53 --> Utf8 Class Initialized
INFO - 2016-02-27 10:57:53 --> URI Class Initialized
INFO - 2016-02-27 10:57:54 --> Router Class Initialized
INFO - 2016-02-27 10:57:54 --> Output Class Initialized
INFO - 2016-02-27 10:57:54 --> Security Class Initialized
DEBUG - 2016-02-27 10:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:57:54 --> Input Class Initialized
INFO - 2016-02-27 10:57:54 --> Language Class Initialized
INFO - 2016-02-27 10:57:54 --> Loader Class Initialized
INFO - 2016-02-27 10:57:54 --> Helper loaded: url_helper
INFO - 2016-02-27 10:57:54 --> Helper loaded: file_helper
INFO - 2016-02-27 10:57:54 --> Helper loaded: date_helper
INFO - 2016-02-27 10:57:54 --> Helper loaded: form_helper
INFO - 2016-02-27 10:57:54 --> Database Driver Class Initialized
INFO - 2016-02-27 10:57:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:57:55 --> Controller Class Initialized
INFO - 2016-02-27 10:57:55 --> Model Class Initialized
INFO - 2016-02-27 10:57:55 --> Model Class Initialized
INFO - 2016-02-27 10:57:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:57:55 --> Pagination Class Initialized
INFO - 2016-02-27 10:57:55 --> Helper loaded: text_helper
INFO - 2016-02-27 10:57:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 13:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 13:57:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:57:55 --> Final output sent to browser
DEBUG - 2016-02-27 13:57:55 --> Total execution time: 1.3065
INFO - 2016-02-27 10:58:02 --> Config Class Initialized
INFO - 2016-02-27 10:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 10:58:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 10:58:02 --> Utf8 Class Initialized
INFO - 2016-02-27 10:58:02 --> URI Class Initialized
INFO - 2016-02-27 10:58:02 --> Router Class Initialized
INFO - 2016-02-27 10:58:02 --> Output Class Initialized
INFO - 2016-02-27 10:58:02 --> Security Class Initialized
DEBUG - 2016-02-27 10:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 10:58:02 --> Input Class Initialized
INFO - 2016-02-27 10:58:02 --> Language Class Initialized
INFO - 2016-02-27 10:58:02 --> Loader Class Initialized
INFO - 2016-02-27 10:58:02 --> Helper loaded: url_helper
INFO - 2016-02-27 10:58:02 --> Helper loaded: file_helper
INFO - 2016-02-27 10:58:02 --> Helper loaded: date_helper
INFO - 2016-02-27 10:58:02 --> Helper loaded: form_helper
INFO - 2016-02-27 10:58:02 --> Database Driver Class Initialized
INFO - 2016-02-27 10:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 10:58:03 --> Controller Class Initialized
INFO - 2016-02-27 10:58:03 --> Model Class Initialized
INFO - 2016-02-27 10:58:03 --> Model Class Initialized
INFO - 2016-02-27 10:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 10:58:03 --> Pagination Class Initialized
INFO - 2016-02-27 10:58:03 --> Helper loaded: text_helper
INFO - 2016-02-27 10:58:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 13:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 13:58:03 --> Final output sent to browser
DEBUG - 2016-02-27 13:58:03 --> Total execution time: 1.1006
INFO - 2016-02-27 11:06:04 --> Config Class Initialized
INFO - 2016-02-27 11:06:04 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:04 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:04 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:04 --> URI Class Initialized
INFO - 2016-02-27 11:06:04 --> Router Class Initialized
INFO - 2016-02-27 11:06:04 --> Output Class Initialized
INFO - 2016-02-27 11:06:04 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:04 --> Input Class Initialized
INFO - 2016-02-27 11:06:04 --> Language Class Initialized
INFO - 2016-02-27 11:06:04 --> Loader Class Initialized
INFO - 2016-02-27 11:06:04 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:04 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:04 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:04 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:04 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:05 --> Controller Class Initialized
INFO - 2016-02-27 11:06:05 --> Model Class Initialized
INFO - 2016-02-27 11:06:05 --> Model Class Initialized
INFO - 2016-02-27 11:06:05 --> Form Validation Class Initialized
INFO - 2016-02-27 11:06:05 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 11:06:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 11:06:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 11:06:05 --> Model Class Initialized
ERROR - 2016-02-27 11:06:05 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php on line 37 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-27 11:06:05 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-27 11:06:05 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-27 11:06:05 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-27 11:06:07 --> Config Class Initialized
INFO - 2016-02-27 11:06:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:07 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:07 --> URI Class Initialized
INFO - 2016-02-27 11:06:07 --> Router Class Initialized
INFO - 2016-02-27 11:06:07 --> Output Class Initialized
INFO - 2016-02-27 11:06:07 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:07 --> Input Class Initialized
INFO - 2016-02-27 11:06:07 --> Language Class Initialized
INFO - 2016-02-27 11:06:07 --> Loader Class Initialized
INFO - 2016-02-27 11:06:07 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:07 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:07 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:07 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:07 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:09 --> Controller Class Initialized
INFO - 2016-02-27 11:06:09 --> Model Class Initialized
INFO - 2016-02-27 11:06:09 --> Model Class Initialized
INFO - 2016-02-27 11:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:06:09 --> Pagination Class Initialized
INFO - 2016-02-27 11:06:09 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:06:09 --> Final output sent to browser
DEBUG - 2016-02-27 14:06:09 --> Total execution time: 1.1290
INFO - 2016-02-27 11:06:11 --> Config Class Initialized
INFO - 2016-02-27 11:06:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:11 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:11 --> URI Class Initialized
INFO - 2016-02-27 11:06:11 --> Router Class Initialized
INFO - 2016-02-27 11:06:11 --> Output Class Initialized
INFO - 2016-02-27 11:06:11 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:11 --> Input Class Initialized
INFO - 2016-02-27 11:06:11 --> Language Class Initialized
INFO - 2016-02-27 11:06:11 --> Loader Class Initialized
INFO - 2016-02-27 11:06:11 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:11 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:11 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:11 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:11 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:12 --> Controller Class Initialized
INFO - 2016-02-27 11:06:12 --> Model Class Initialized
INFO - 2016-02-27 11:06:12 --> Model Class Initialized
INFO - 2016-02-27 11:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:06:12 --> Pagination Class Initialized
INFO - 2016-02-27 11:06:12 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:06:12 --> Final output sent to browser
DEBUG - 2016-02-27 14:06:12 --> Total execution time: 1.1309
INFO - 2016-02-27 11:06:30 --> Config Class Initialized
INFO - 2016-02-27 11:06:30 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:30 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:30 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:30 --> URI Class Initialized
INFO - 2016-02-27 11:06:30 --> Router Class Initialized
INFO - 2016-02-27 11:06:30 --> Output Class Initialized
INFO - 2016-02-27 11:06:30 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:30 --> Input Class Initialized
INFO - 2016-02-27 11:06:30 --> Language Class Initialized
INFO - 2016-02-27 11:06:30 --> Loader Class Initialized
INFO - 2016-02-27 11:06:30 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:30 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:30 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:30 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:30 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:31 --> Controller Class Initialized
INFO - 2016-02-27 11:06:31 --> Model Class Initialized
INFO - 2016-02-27 11:06:31 --> Model Class Initialized
INFO - 2016-02-27 11:06:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:06:31 --> Pagination Class Initialized
INFO - 2016-02-27 11:06:31 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:31 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-27 14:06:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:06:31 --> Final output sent to browser
DEBUG - 2016-02-27 14:06:31 --> Total execution time: 1.1413
INFO - 2016-02-27 11:06:42 --> Config Class Initialized
INFO - 2016-02-27 11:06:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:42 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:42 --> URI Class Initialized
INFO - 2016-02-27 11:06:42 --> Router Class Initialized
INFO - 2016-02-27 11:06:42 --> Output Class Initialized
INFO - 2016-02-27 11:06:42 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:42 --> Input Class Initialized
INFO - 2016-02-27 11:06:42 --> Language Class Initialized
INFO - 2016-02-27 11:06:42 --> Loader Class Initialized
INFO - 2016-02-27 11:06:42 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:42 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:42 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:42 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:42 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:43 --> Controller Class Initialized
INFO - 2016-02-27 11:06:43 --> Model Class Initialized
INFO - 2016-02-27 11:06:43 --> Model Class Initialized
INFO - 2016-02-27 11:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:06:43 --> Pagination Class Initialized
INFO - 2016-02-27 11:06:43 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:43 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:06:43 --> Final output sent to browser
DEBUG - 2016-02-27 14:06:43 --> Total execution time: 1.1905
INFO - 2016-02-27 11:06:45 --> Config Class Initialized
INFO - 2016-02-27 11:06:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:06:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:06:45 --> Utf8 Class Initialized
INFO - 2016-02-27 11:06:45 --> URI Class Initialized
INFO - 2016-02-27 11:06:45 --> Router Class Initialized
INFO - 2016-02-27 11:06:45 --> Output Class Initialized
INFO - 2016-02-27 11:06:45 --> Security Class Initialized
DEBUG - 2016-02-27 11:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:06:45 --> Input Class Initialized
INFO - 2016-02-27 11:06:45 --> Language Class Initialized
INFO - 2016-02-27 11:06:45 --> Loader Class Initialized
INFO - 2016-02-27 11:06:45 --> Helper loaded: url_helper
INFO - 2016-02-27 11:06:45 --> Helper loaded: file_helper
INFO - 2016-02-27 11:06:45 --> Helper loaded: date_helper
INFO - 2016-02-27 11:06:45 --> Helper loaded: form_helper
INFO - 2016-02-27 11:06:45 --> Database Driver Class Initialized
INFO - 2016-02-27 11:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:06:46 --> Controller Class Initialized
INFO - 2016-02-27 11:06:46 --> Model Class Initialized
INFO - 2016-02-27 11:06:46 --> Model Class Initialized
INFO - 2016-02-27 11:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:06:46 --> Pagination Class Initialized
INFO - 2016-02-27 11:06:46 --> Helper loaded: text_helper
INFO - 2016-02-27 11:06:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 14:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 14:06:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:06:46 --> Final output sent to browser
DEBUG - 2016-02-27 14:06:46 --> Total execution time: 1.1800
INFO - 2016-02-27 11:07:10 --> Config Class Initialized
INFO - 2016-02-27 11:07:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:07:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:07:10 --> Utf8 Class Initialized
INFO - 2016-02-27 11:07:10 --> URI Class Initialized
DEBUG - 2016-02-27 11:07:10 --> No URI present. Default controller set.
INFO - 2016-02-27 11:07:10 --> Router Class Initialized
INFO - 2016-02-27 11:07:10 --> Output Class Initialized
INFO - 2016-02-27 11:07:10 --> Security Class Initialized
DEBUG - 2016-02-27 11:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:07:10 --> Input Class Initialized
INFO - 2016-02-27 11:07:10 --> Language Class Initialized
INFO - 2016-02-27 11:07:10 --> Loader Class Initialized
INFO - 2016-02-27 11:07:10 --> Helper loaded: url_helper
INFO - 2016-02-27 11:07:10 --> Helper loaded: file_helper
INFO - 2016-02-27 11:07:10 --> Helper loaded: date_helper
INFO - 2016-02-27 11:07:10 --> Helper loaded: form_helper
INFO - 2016-02-27 11:07:10 --> Database Driver Class Initialized
INFO - 2016-02-27 11:07:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:07:11 --> Controller Class Initialized
INFO - 2016-02-27 11:07:11 --> Model Class Initialized
INFO - 2016-02-27 11:07:11 --> Model Class Initialized
INFO - 2016-02-27 11:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:07:11 --> Pagination Class Initialized
INFO - 2016-02-27 11:07:11 --> Helper loaded: text_helper
INFO - 2016-02-27 11:07:11 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 14:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:07:11 --> Final output sent to browser
DEBUG - 2016-02-27 14:07:11 --> Total execution time: 1.1316
INFO - 2016-02-27 11:07:54 --> Config Class Initialized
INFO - 2016-02-27 11:07:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:07:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:07:54 --> Utf8 Class Initialized
INFO - 2016-02-27 11:07:54 --> URI Class Initialized
INFO - 2016-02-27 11:07:54 --> Router Class Initialized
INFO - 2016-02-27 11:07:54 --> Output Class Initialized
INFO - 2016-02-27 11:07:54 --> Security Class Initialized
DEBUG - 2016-02-27 11:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:07:54 --> Input Class Initialized
INFO - 2016-02-27 11:07:54 --> Language Class Initialized
INFO - 2016-02-27 11:07:54 --> Loader Class Initialized
INFO - 2016-02-27 11:07:54 --> Helper loaded: url_helper
INFO - 2016-02-27 11:07:54 --> Helper loaded: file_helper
INFO - 2016-02-27 11:07:54 --> Helper loaded: date_helper
INFO - 2016-02-27 11:07:54 --> Helper loaded: form_helper
INFO - 2016-02-27 11:07:54 --> Database Driver Class Initialized
INFO - 2016-02-27 11:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:07:55 --> Controller Class Initialized
INFO - 2016-02-27 11:07:55 --> Model Class Initialized
INFO - 2016-02-27 11:07:55 --> Model Class Initialized
INFO - 2016-02-27 11:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:07:55 --> Pagination Class Initialized
INFO - 2016-02-27 11:07:55 --> Helper loaded: text_helper
INFO - 2016-02-27 11:07:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-27 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:07:55 --> Final output sent to browser
DEBUG - 2016-02-27 14:07:55 --> Total execution time: 1.1010
INFO - 2016-02-27 11:07:58 --> Config Class Initialized
INFO - 2016-02-27 11:07:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:07:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:07:58 --> Utf8 Class Initialized
INFO - 2016-02-27 11:07:58 --> URI Class Initialized
INFO - 2016-02-27 11:07:58 --> Router Class Initialized
INFO - 2016-02-27 11:07:58 --> Output Class Initialized
INFO - 2016-02-27 11:07:58 --> Security Class Initialized
DEBUG - 2016-02-27 11:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:07:58 --> Input Class Initialized
INFO - 2016-02-27 11:07:58 --> Language Class Initialized
INFO - 2016-02-27 11:07:58 --> Loader Class Initialized
INFO - 2016-02-27 11:07:58 --> Helper loaded: url_helper
INFO - 2016-02-27 11:07:58 --> Helper loaded: file_helper
INFO - 2016-02-27 11:07:58 --> Helper loaded: date_helper
INFO - 2016-02-27 11:07:58 --> Helper loaded: form_helper
INFO - 2016-02-27 11:07:58 --> Database Driver Class Initialized
INFO - 2016-02-27 11:07:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:07:59 --> Controller Class Initialized
INFO - 2016-02-27 11:07:59 --> Model Class Initialized
INFO - 2016-02-27 11:07:59 --> Model Class Initialized
INFO - 2016-02-27 11:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:07:59 --> Pagination Class Initialized
INFO - 2016-02-27 11:07:59 --> Helper loaded: text_helper
INFO - 2016-02-27 11:07:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 14:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:07:59 --> Final output sent to browser
DEBUG - 2016-02-27 14:07:59 --> Total execution time: 1.1127
INFO - 2016-02-27 11:08:01 --> Config Class Initialized
INFO - 2016-02-27 11:08:01 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:08:01 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:08:01 --> Utf8 Class Initialized
INFO - 2016-02-27 11:08:01 --> URI Class Initialized
INFO - 2016-02-27 11:08:01 --> Router Class Initialized
INFO - 2016-02-27 11:08:01 --> Output Class Initialized
INFO - 2016-02-27 11:08:01 --> Security Class Initialized
DEBUG - 2016-02-27 11:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:08:01 --> Input Class Initialized
INFO - 2016-02-27 11:08:01 --> Language Class Initialized
INFO - 2016-02-27 11:08:01 --> Loader Class Initialized
INFO - 2016-02-27 11:08:01 --> Helper loaded: url_helper
INFO - 2016-02-27 11:08:01 --> Helper loaded: file_helper
INFO - 2016-02-27 11:08:01 --> Helper loaded: date_helper
INFO - 2016-02-27 11:08:01 --> Helper loaded: form_helper
INFO - 2016-02-27 11:08:01 --> Database Driver Class Initialized
INFO - 2016-02-27 11:08:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:08:02 --> Controller Class Initialized
INFO - 2016-02-27 11:08:02 --> Model Class Initialized
INFO - 2016-02-27 11:08:02 --> Model Class Initialized
INFO - 2016-02-27 11:08:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:08:02 --> Pagination Class Initialized
INFO - 2016-02-27 11:08:02 --> Helper loaded: text_helper
INFO - 2016-02-27 11:08:02 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 14:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 14:08:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:08:02 --> Final output sent to browser
DEBUG - 2016-02-27 14:08:02 --> Total execution time: 1.2031
INFO - 2016-02-27 11:08:45 --> Config Class Initialized
INFO - 2016-02-27 11:08:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:08:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:08:45 --> Utf8 Class Initialized
INFO - 2016-02-27 11:08:45 --> URI Class Initialized
INFO - 2016-02-27 11:08:45 --> Router Class Initialized
INFO - 2016-02-27 11:08:45 --> Output Class Initialized
INFO - 2016-02-27 11:08:45 --> Security Class Initialized
DEBUG - 2016-02-27 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:08:45 --> Input Class Initialized
INFO - 2016-02-27 11:08:45 --> Language Class Initialized
INFO - 2016-02-27 11:08:45 --> Loader Class Initialized
INFO - 2016-02-27 11:08:45 --> Helper loaded: url_helper
INFO - 2016-02-27 11:08:45 --> Helper loaded: file_helper
INFO - 2016-02-27 11:08:45 --> Helper loaded: date_helper
INFO - 2016-02-27 11:08:45 --> Helper loaded: form_helper
INFO - 2016-02-27 11:08:45 --> Database Driver Class Initialized
INFO - 2016-02-27 11:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:08:46 --> Controller Class Initialized
INFO - 2016-02-27 11:08:46 --> Model Class Initialized
INFO - 2016-02-27 11:08:46 --> Model Class Initialized
INFO - 2016-02-27 11:08:46 --> Form Validation Class Initialized
INFO - 2016-02-27 11:08:47 --> Helper loaded: text_helper
INFO - 2016-02-27 11:08:47 --> Final output sent to browser
DEBUG - 2016-02-27 11:08:47 --> Total execution time: 1.1902
INFO - 2016-02-27 11:16:25 --> Config Class Initialized
INFO - 2016-02-27 11:16:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 11:16:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 11:16:25 --> Utf8 Class Initialized
INFO - 2016-02-27 11:16:25 --> URI Class Initialized
INFO - 2016-02-27 11:16:25 --> Router Class Initialized
INFO - 2016-02-27 11:16:25 --> Output Class Initialized
INFO - 2016-02-27 11:16:25 --> Security Class Initialized
DEBUG - 2016-02-27 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 11:16:25 --> Input Class Initialized
INFO - 2016-02-27 11:16:25 --> Language Class Initialized
INFO - 2016-02-27 11:16:25 --> Loader Class Initialized
INFO - 2016-02-27 11:16:25 --> Helper loaded: url_helper
INFO - 2016-02-27 11:16:25 --> Helper loaded: file_helper
INFO - 2016-02-27 11:16:25 --> Helper loaded: date_helper
INFO - 2016-02-27 11:16:25 --> Helper loaded: form_helper
INFO - 2016-02-27 11:16:25 --> Database Driver Class Initialized
INFO - 2016-02-27 11:16:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 11:16:26 --> Controller Class Initialized
INFO - 2016-02-27 11:16:26 --> Model Class Initialized
INFO - 2016-02-27 11:16:26 --> Model Class Initialized
INFO - 2016-02-27 11:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 11:16:26 --> Pagination Class Initialized
INFO - 2016-02-27 11:16:26 --> Helper loaded: text_helper
INFO - 2016-02-27 11:16:26 --> Helper loaded: cookie_helper
INFO - 2016-02-27 14:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 14:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 14:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:16:26 --> Final output sent to browser
DEBUG - 2016-02-27 14:16:26 --> Total execution time: 1.2425
INFO - 2016-02-27 12:37:48 --> Config Class Initialized
INFO - 2016-02-27 12:37:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:37:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:37:48 --> Utf8 Class Initialized
INFO - 2016-02-27 12:37:48 --> URI Class Initialized
DEBUG - 2016-02-27 12:37:48 --> No URI present. Default controller set.
INFO - 2016-02-27 12:37:48 --> Router Class Initialized
INFO - 2016-02-27 12:37:48 --> Output Class Initialized
INFO - 2016-02-27 12:37:48 --> Security Class Initialized
DEBUG - 2016-02-27 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:37:48 --> Input Class Initialized
INFO - 2016-02-27 12:37:49 --> Language Class Initialized
INFO - 2016-02-27 12:37:49 --> Loader Class Initialized
INFO - 2016-02-27 12:37:49 --> Helper loaded: url_helper
INFO - 2016-02-27 12:37:49 --> Helper loaded: file_helper
INFO - 2016-02-27 12:37:49 --> Helper loaded: date_helper
INFO - 2016-02-27 12:37:49 --> Helper loaded: form_helper
INFO - 2016-02-27 12:37:49 --> Database Driver Class Initialized
INFO - 2016-02-27 12:37:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:37:50 --> Controller Class Initialized
INFO - 2016-02-27 12:37:50 --> Model Class Initialized
INFO - 2016-02-27 12:37:50 --> Model Class Initialized
INFO - 2016-02-27 12:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 12:37:50 --> Pagination Class Initialized
INFO - 2016-02-27 12:37:50 --> Helper loaded: text_helper
INFO - 2016-02-27 12:37:50 --> Helper loaded: cookie_helper
INFO - 2016-02-27 15:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 15:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 15:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 15:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 15:37:50 --> Final output sent to browser
DEBUG - 2016-02-27 15:37:50 --> Total execution time: 1.2353
INFO - 2016-02-27 12:41:03 --> Config Class Initialized
INFO - 2016-02-27 12:41:03 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:41:03 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:41:03 --> Utf8 Class Initialized
INFO - 2016-02-27 12:41:03 --> URI Class Initialized
DEBUG - 2016-02-27 12:41:03 --> No URI present. Default controller set.
INFO - 2016-02-27 12:41:03 --> Router Class Initialized
INFO - 2016-02-27 12:41:03 --> Output Class Initialized
INFO - 2016-02-27 12:41:03 --> Security Class Initialized
DEBUG - 2016-02-27 12:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:41:03 --> Input Class Initialized
INFO - 2016-02-27 12:41:03 --> Language Class Initialized
INFO - 2016-02-27 12:41:03 --> Loader Class Initialized
INFO - 2016-02-27 12:41:03 --> Helper loaded: url_helper
INFO - 2016-02-27 12:41:03 --> Helper loaded: file_helper
INFO - 2016-02-27 12:41:03 --> Helper loaded: date_helper
INFO - 2016-02-27 12:41:03 --> Helper loaded: form_helper
INFO - 2016-02-27 12:41:03 --> Database Driver Class Initialized
INFO - 2016-02-27 12:41:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:41:04 --> Controller Class Initialized
INFO - 2016-02-27 12:41:04 --> Model Class Initialized
INFO - 2016-02-27 12:41:04 --> Model Class Initialized
INFO - 2016-02-27 12:41:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 12:41:04 --> Pagination Class Initialized
INFO - 2016-02-27 12:41:04 --> Helper loaded: text_helper
INFO - 2016-02-27 12:41:04 --> Helper loaded: cookie_helper
INFO - 2016-02-27 15:41:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 15:41:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 15:41:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 15:41:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 15:41:04 --> Final output sent to browser
DEBUG - 2016-02-27 15:41:04 --> Total execution time: 1.1699
INFO - 2016-02-27 12:44:32 --> Config Class Initialized
INFO - 2016-02-27 12:44:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:44:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:44:32 --> Utf8 Class Initialized
INFO - 2016-02-27 12:44:32 --> URI Class Initialized
DEBUG - 2016-02-27 12:44:32 --> No URI present. Default controller set.
INFO - 2016-02-27 12:44:32 --> Router Class Initialized
INFO - 2016-02-27 12:44:32 --> Output Class Initialized
INFO - 2016-02-27 12:44:32 --> Security Class Initialized
DEBUG - 2016-02-27 12:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:44:32 --> Input Class Initialized
INFO - 2016-02-27 12:44:32 --> Language Class Initialized
INFO - 2016-02-27 12:44:32 --> Loader Class Initialized
INFO - 2016-02-27 12:44:32 --> Helper loaded: url_helper
INFO - 2016-02-27 12:44:32 --> Helper loaded: file_helper
INFO - 2016-02-27 12:44:32 --> Helper loaded: date_helper
INFO - 2016-02-27 12:44:32 --> Helper loaded: form_helper
INFO - 2016-02-27 12:44:32 --> Database Driver Class Initialized
INFO - 2016-02-27 12:44:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:44:33 --> Controller Class Initialized
INFO - 2016-02-27 12:44:33 --> Model Class Initialized
INFO - 2016-02-27 12:44:33 --> Model Class Initialized
INFO - 2016-02-27 12:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 12:44:33 --> Pagination Class Initialized
INFO - 2016-02-27 12:44:33 --> Helper loaded: text_helper
INFO - 2016-02-27 12:44:33 --> Helper loaded: cookie_helper
INFO - 2016-02-27 15:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 15:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 15:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 15:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 15:44:33 --> Final output sent to browser
DEBUG - 2016-02-27 15:44:33 --> Total execution time: 1.1195
INFO - 2016-02-27 12:44:37 --> Config Class Initialized
INFO - 2016-02-27 12:44:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:44:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:44:37 --> Utf8 Class Initialized
INFO - 2016-02-27 12:44:37 --> URI Class Initialized
INFO - 2016-02-27 12:44:37 --> Router Class Initialized
INFO - 2016-02-27 12:44:37 --> Output Class Initialized
INFO - 2016-02-27 12:44:37 --> Security Class Initialized
DEBUG - 2016-02-27 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:44:37 --> Input Class Initialized
INFO - 2016-02-27 12:44:37 --> Language Class Initialized
INFO - 2016-02-27 12:44:37 --> Loader Class Initialized
INFO - 2016-02-27 12:44:37 --> Helper loaded: url_helper
INFO - 2016-02-27 12:44:37 --> Helper loaded: file_helper
INFO - 2016-02-27 12:44:37 --> Helper loaded: date_helper
INFO - 2016-02-27 12:44:37 --> Helper loaded: form_helper
INFO - 2016-02-27 12:44:37 --> Database Driver Class Initialized
INFO - 2016-02-27 12:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:44:38 --> Controller Class Initialized
INFO - 2016-02-27 12:44:38 --> Model Class Initialized
INFO - 2016-02-27 12:44:38 --> Model Class Initialized
INFO - 2016-02-27 12:44:38 --> Form Validation Class Initialized
INFO - 2016-02-27 12:44:38 --> Helper loaded: text_helper
INFO - 2016-02-27 12:44:38 --> Config Class Initialized
INFO - 2016-02-27 12:44:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:44:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:44:38 --> Utf8 Class Initialized
INFO - 2016-02-27 12:44:38 --> URI Class Initialized
INFO - 2016-02-27 12:44:38 --> Router Class Initialized
INFO - 2016-02-27 12:44:38 --> Output Class Initialized
INFO - 2016-02-27 12:44:38 --> Security Class Initialized
DEBUG - 2016-02-27 12:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:44:38 --> Input Class Initialized
INFO - 2016-02-27 12:44:38 --> Language Class Initialized
INFO - 2016-02-27 12:44:38 --> Loader Class Initialized
INFO - 2016-02-27 12:44:38 --> Helper loaded: url_helper
INFO - 2016-02-27 12:44:38 --> Helper loaded: file_helper
INFO - 2016-02-27 12:44:38 --> Helper loaded: date_helper
INFO - 2016-02-27 12:44:38 --> Helper loaded: form_helper
INFO - 2016-02-27 12:44:38 --> Database Driver Class Initialized
INFO - 2016-02-27 12:44:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:44:39 --> Controller Class Initialized
INFO - 2016-02-27 12:44:39 --> Model Class Initialized
INFO - 2016-02-27 12:44:39 --> Model Class Initialized
INFO - 2016-02-27 12:44:39 --> Form Validation Class Initialized
INFO - 2016-02-27 12:44:39 --> Helper loaded: text_helper
INFO - 2016-02-27 12:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:44:39 --> Final output sent to browser
DEBUG - 2016-02-27 12:44:39 --> Total execution time: 1.0915
INFO - 2016-02-27 12:46:21 --> Config Class Initialized
INFO - 2016-02-27 12:46:21 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:46:21 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:46:21 --> Utf8 Class Initialized
INFO - 2016-02-27 12:46:21 --> URI Class Initialized
DEBUG - 2016-02-27 12:46:21 --> No URI present. Default controller set.
INFO - 2016-02-27 12:46:21 --> Router Class Initialized
INFO - 2016-02-27 12:46:21 --> Output Class Initialized
INFO - 2016-02-27 12:46:21 --> Security Class Initialized
DEBUG - 2016-02-27 12:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:46:21 --> Input Class Initialized
INFO - 2016-02-27 12:46:21 --> Language Class Initialized
INFO - 2016-02-27 12:46:21 --> Loader Class Initialized
INFO - 2016-02-27 12:46:21 --> Helper loaded: url_helper
INFO - 2016-02-27 12:46:21 --> Helper loaded: file_helper
INFO - 2016-02-27 12:46:21 --> Helper loaded: date_helper
INFO - 2016-02-27 12:46:21 --> Helper loaded: form_helper
INFO - 2016-02-27 12:46:21 --> Database Driver Class Initialized
INFO - 2016-02-27 12:46:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:46:22 --> Controller Class Initialized
INFO - 2016-02-27 12:46:22 --> Model Class Initialized
INFO - 2016-02-27 12:46:22 --> Model Class Initialized
INFO - 2016-02-27 12:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 12:46:22 --> Pagination Class Initialized
INFO - 2016-02-27 12:46:22 --> Helper loaded: text_helper
INFO - 2016-02-27 12:46:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 15:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 15:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 15:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 15:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 15:46:22 --> Final output sent to browser
DEBUG - 2016-02-27 15:46:22 --> Total execution time: 1.1249
INFO - 2016-02-27 12:46:25 --> Config Class Initialized
INFO - 2016-02-27 12:46:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:46:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:46:25 --> Utf8 Class Initialized
INFO - 2016-02-27 12:46:25 --> URI Class Initialized
INFO - 2016-02-27 12:46:25 --> Router Class Initialized
INFO - 2016-02-27 12:46:25 --> Output Class Initialized
INFO - 2016-02-27 12:46:25 --> Security Class Initialized
DEBUG - 2016-02-27 12:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:46:25 --> Input Class Initialized
INFO - 2016-02-27 12:46:25 --> Language Class Initialized
INFO - 2016-02-27 12:46:25 --> Loader Class Initialized
INFO - 2016-02-27 12:46:25 --> Helper loaded: url_helper
INFO - 2016-02-27 12:46:25 --> Helper loaded: file_helper
INFO - 2016-02-27 12:46:25 --> Helper loaded: date_helper
INFO - 2016-02-27 12:46:25 --> Helper loaded: form_helper
INFO - 2016-02-27 12:46:25 --> Database Driver Class Initialized
INFO - 2016-02-27 12:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:46:26 --> Controller Class Initialized
INFO - 2016-02-27 12:46:26 --> Model Class Initialized
INFO - 2016-02-27 12:46:26 --> Model Class Initialized
INFO - 2016-02-27 12:46:26 --> Form Validation Class Initialized
INFO - 2016-02-27 12:46:26 --> Helper loaded: text_helper
INFO - 2016-02-27 12:46:26 --> Config Class Initialized
INFO - 2016-02-27 12:46:26 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:46:26 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:46:26 --> Utf8 Class Initialized
INFO - 2016-02-27 12:46:26 --> URI Class Initialized
INFO - 2016-02-27 12:46:26 --> Router Class Initialized
INFO - 2016-02-27 12:46:26 --> Output Class Initialized
INFO - 2016-02-27 12:46:26 --> Security Class Initialized
DEBUG - 2016-02-27 12:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:46:26 --> Input Class Initialized
INFO - 2016-02-27 12:46:26 --> Language Class Initialized
INFO - 2016-02-27 12:46:26 --> Loader Class Initialized
INFO - 2016-02-27 12:46:26 --> Helper loaded: url_helper
INFO - 2016-02-27 12:46:26 --> Helper loaded: file_helper
INFO - 2016-02-27 12:46:26 --> Helper loaded: date_helper
INFO - 2016-02-27 12:46:26 --> Helper loaded: form_helper
INFO - 2016-02-27 12:46:26 --> Database Driver Class Initialized
INFO - 2016-02-27 12:46:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:46:27 --> Controller Class Initialized
INFO - 2016-02-27 12:46:27 --> Model Class Initialized
INFO - 2016-02-27 12:46:27 --> Model Class Initialized
INFO - 2016-02-27 12:46:27 --> Form Validation Class Initialized
INFO - 2016-02-27 12:46:27 --> Helper loaded: text_helper
INFO - 2016-02-27 12:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:46:27 --> Final output sent to browser
DEBUG - 2016-02-27 12:46:27 --> Total execution time: 1.0961
INFO - 2016-02-27 12:53:25 --> Config Class Initialized
INFO - 2016-02-27 12:53:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:53:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:53:25 --> Utf8 Class Initialized
INFO - 2016-02-27 12:53:25 --> URI Class Initialized
INFO - 2016-02-27 12:53:25 --> Router Class Initialized
INFO - 2016-02-27 12:53:25 --> Output Class Initialized
INFO - 2016-02-27 12:53:25 --> Security Class Initialized
DEBUG - 2016-02-27 12:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:53:25 --> Input Class Initialized
INFO - 2016-02-27 12:53:25 --> Language Class Initialized
INFO - 2016-02-27 12:53:25 --> Loader Class Initialized
INFO - 2016-02-27 12:53:25 --> Helper loaded: url_helper
INFO - 2016-02-27 12:53:25 --> Helper loaded: file_helper
INFO - 2016-02-27 12:53:25 --> Helper loaded: date_helper
INFO - 2016-02-27 12:53:25 --> Helper loaded: form_helper
INFO - 2016-02-27 12:53:25 --> Database Driver Class Initialized
INFO - 2016-02-27 12:53:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:53:26 --> Controller Class Initialized
INFO - 2016-02-27 12:53:26 --> Model Class Initialized
INFO - 2016-02-27 12:53:26 --> Model Class Initialized
INFO - 2016-02-27 12:53:26 --> Form Validation Class Initialized
INFO - 2016-02-27 12:53:26 --> Helper loaded: text_helper
INFO - 2016-02-27 12:53:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:53:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:53:26 --> Final output sent to browser
DEBUG - 2016-02-27 12:53:26 --> Total execution time: 1.1042
INFO - 2016-02-27 12:54:02 --> Config Class Initialized
INFO - 2016-02-27 12:54:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:54:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:54:02 --> Utf8 Class Initialized
INFO - 2016-02-27 12:54:02 --> URI Class Initialized
INFO - 2016-02-27 12:54:02 --> Router Class Initialized
INFO - 2016-02-27 12:54:02 --> Output Class Initialized
INFO - 2016-02-27 12:54:02 --> Security Class Initialized
DEBUG - 2016-02-27 12:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:54:02 --> Input Class Initialized
INFO - 2016-02-27 12:54:02 --> Language Class Initialized
INFO - 2016-02-27 12:54:02 --> Loader Class Initialized
INFO - 2016-02-27 12:54:02 --> Helper loaded: url_helper
INFO - 2016-02-27 12:54:02 --> Helper loaded: file_helper
INFO - 2016-02-27 12:54:02 --> Helper loaded: date_helper
INFO - 2016-02-27 12:54:02 --> Helper loaded: form_helper
INFO - 2016-02-27 12:54:02 --> Database Driver Class Initialized
INFO - 2016-02-27 12:54:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:54:03 --> Controller Class Initialized
INFO - 2016-02-27 12:54:03 --> Model Class Initialized
INFO - 2016-02-27 12:54:03 --> Model Class Initialized
INFO - 2016-02-27 12:54:03 --> Form Validation Class Initialized
INFO - 2016-02-27 12:54:03 --> Helper loaded: text_helper
INFO - 2016-02-27 12:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:54:03 --> Final output sent to browser
DEBUG - 2016-02-27 12:54:03 --> Total execution time: 1.1162
INFO - 2016-02-27 12:55:07 --> Config Class Initialized
INFO - 2016-02-27 12:55:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:55:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:55:07 --> Utf8 Class Initialized
INFO - 2016-02-27 12:55:07 --> URI Class Initialized
INFO - 2016-02-27 12:55:07 --> Router Class Initialized
INFO - 2016-02-27 12:55:07 --> Output Class Initialized
INFO - 2016-02-27 12:55:07 --> Security Class Initialized
DEBUG - 2016-02-27 12:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:55:07 --> Input Class Initialized
INFO - 2016-02-27 12:55:07 --> Language Class Initialized
INFO - 2016-02-27 12:55:07 --> Loader Class Initialized
INFO - 2016-02-27 12:55:07 --> Helper loaded: url_helper
INFO - 2016-02-27 12:55:07 --> Helper loaded: file_helper
INFO - 2016-02-27 12:55:07 --> Helper loaded: date_helper
INFO - 2016-02-27 12:55:07 --> Helper loaded: form_helper
INFO - 2016-02-27 12:55:07 --> Database Driver Class Initialized
INFO - 2016-02-27 12:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:55:08 --> Controller Class Initialized
INFO - 2016-02-27 12:55:08 --> Model Class Initialized
INFO - 2016-02-27 12:55:08 --> Model Class Initialized
INFO - 2016-02-27 12:55:08 --> Form Validation Class Initialized
INFO - 2016-02-27 12:55:08 --> Helper loaded: text_helper
INFO - 2016-02-27 12:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:55:08 --> Final output sent to browser
DEBUG - 2016-02-27 12:55:08 --> Total execution time: 1.1127
INFO - 2016-02-27 12:58:12 --> Config Class Initialized
INFO - 2016-02-27 12:58:12 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:58:12 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:58:12 --> Utf8 Class Initialized
INFO - 2016-02-27 12:58:12 --> URI Class Initialized
DEBUG - 2016-02-27 12:58:12 --> No URI present. Default controller set.
INFO - 2016-02-27 12:58:12 --> Router Class Initialized
INFO - 2016-02-27 12:58:12 --> Output Class Initialized
INFO - 2016-02-27 12:58:12 --> Security Class Initialized
DEBUG - 2016-02-27 12:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:58:12 --> Input Class Initialized
INFO - 2016-02-27 12:58:12 --> Language Class Initialized
INFO - 2016-02-27 12:58:12 --> Loader Class Initialized
INFO - 2016-02-27 12:58:12 --> Helper loaded: url_helper
INFO - 2016-02-27 12:58:12 --> Helper loaded: file_helper
INFO - 2016-02-27 12:58:12 --> Helper loaded: date_helper
INFO - 2016-02-27 12:58:12 --> Helper loaded: form_helper
INFO - 2016-02-27 12:58:12 --> Database Driver Class Initialized
INFO - 2016-02-27 12:58:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:58:13 --> Controller Class Initialized
INFO - 2016-02-27 12:58:13 --> Model Class Initialized
INFO - 2016-02-27 12:58:13 --> Model Class Initialized
INFO - 2016-02-27 12:58:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 12:58:13 --> Pagination Class Initialized
INFO - 2016-02-27 12:58:13 --> Helper loaded: text_helper
INFO - 2016-02-27 12:58:13 --> Helper loaded: cookie_helper
INFO - 2016-02-27 15:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 15:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 15:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 15:58:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 15:58:13 --> Final output sent to browser
DEBUG - 2016-02-27 15:58:13 --> Total execution time: 1.1701
INFO - 2016-02-27 12:59:13 --> Config Class Initialized
INFO - 2016-02-27 12:59:13 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:59:13 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:59:13 --> Utf8 Class Initialized
INFO - 2016-02-27 12:59:13 --> URI Class Initialized
INFO - 2016-02-27 12:59:13 --> Router Class Initialized
INFO - 2016-02-27 12:59:13 --> Output Class Initialized
INFO - 2016-02-27 12:59:13 --> Security Class Initialized
DEBUG - 2016-02-27 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:59:13 --> Input Class Initialized
INFO - 2016-02-27 12:59:13 --> Language Class Initialized
INFO - 2016-02-27 12:59:13 --> Loader Class Initialized
INFO - 2016-02-27 12:59:13 --> Helper loaded: url_helper
INFO - 2016-02-27 12:59:13 --> Helper loaded: file_helper
INFO - 2016-02-27 12:59:13 --> Helper loaded: date_helper
INFO - 2016-02-27 12:59:13 --> Helper loaded: form_helper
INFO - 2016-02-27 12:59:13 --> Database Driver Class Initialized
INFO - 2016-02-27 12:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:59:14 --> Controller Class Initialized
INFO - 2016-02-27 12:59:14 --> Model Class Initialized
INFO - 2016-02-27 12:59:14 --> Model Class Initialized
INFO - 2016-02-27 12:59:14 --> Form Validation Class Initialized
INFO - 2016-02-27 12:59:14 --> Helper loaded: text_helper
INFO - 2016-02-27 12:59:14 --> Config Class Initialized
INFO - 2016-02-27 12:59:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 12:59:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 12:59:14 --> Utf8 Class Initialized
INFO - 2016-02-27 12:59:14 --> URI Class Initialized
INFO - 2016-02-27 12:59:14 --> Router Class Initialized
INFO - 2016-02-27 12:59:14 --> Output Class Initialized
INFO - 2016-02-27 12:59:14 --> Security Class Initialized
DEBUG - 2016-02-27 12:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 12:59:14 --> Input Class Initialized
INFO - 2016-02-27 12:59:14 --> Language Class Initialized
INFO - 2016-02-27 12:59:14 --> Loader Class Initialized
INFO - 2016-02-27 12:59:14 --> Helper loaded: url_helper
INFO - 2016-02-27 12:59:14 --> Helper loaded: file_helper
INFO - 2016-02-27 12:59:14 --> Helper loaded: date_helper
INFO - 2016-02-27 12:59:14 --> Helper loaded: form_helper
INFO - 2016-02-27 12:59:14 --> Database Driver Class Initialized
INFO - 2016-02-27 12:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 12:59:15 --> Controller Class Initialized
INFO - 2016-02-27 12:59:15 --> Model Class Initialized
INFO - 2016-02-27 12:59:15 --> Model Class Initialized
INFO - 2016-02-27 12:59:15 --> Form Validation Class Initialized
INFO - 2016-02-27 12:59:15 --> Helper loaded: text_helper
INFO - 2016-02-27 12:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 12:59:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 12:59:15 --> Final output sent to browser
DEBUG - 2016-02-27 12:59:15 --> Total execution time: 1.1441
INFO - 2016-02-27 13:12:42 --> Config Class Initialized
INFO - 2016-02-27 13:12:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:12:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:12:43 --> Utf8 Class Initialized
INFO - 2016-02-27 13:12:43 --> URI Class Initialized
INFO - 2016-02-27 13:12:43 --> Router Class Initialized
INFO - 2016-02-27 13:12:43 --> Output Class Initialized
INFO - 2016-02-27 13:12:43 --> Security Class Initialized
DEBUG - 2016-02-27 13:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:12:43 --> Input Class Initialized
INFO - 2016-02-27 13:12:43 --> Language Class Initialized
INFO - 2016-02-27 13:12:43 --> Loader Class Initialized
INFO - 2016-02-27 13:12:43 --> Helper loaded: url_helper
INFO - 2016-02-27 13:12:43 --> Helper loaded: file_helper
INFO - 2016-02-27 13:12:43 --> Helper loaded: date_helper
INFO - 2016-02-27 13:12:43 --> Helper loaded: form_helper
INFO - 2016-02-27 13:12:43 --> Database Driver Class Initialized
INFO - 2016-02-27 13:12:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:12:44 --> Controller Class Initialized
INFO - 2016-02-27 13:12:44 --> Model Class Initialized
INFO - 2016-02-27 13:12:44 --> Model Class Initialized
INFO - 2016-02-27 13:12:44 --> Form Validation Class Initialized
INFO - 2016-02-27 13:12:44 --> Helper loaded: text_helper
INFO - 2016-02-27 13:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:12:44 --> Final output sent to browser
DEBUG - 2016-02-27 13:12:44 --> Total execution time: 1.3631
INFO - 2016-02-27 13:13:09 --> Config Class Initialized
INFO - 2016-02-27 13:13:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:13:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:13:09 --> Utf8 Class Initialized
INFO - 2016-02-27 13:13:09 --> URI Class Initialized
INFO - 2016-02-27 13:13:09 --> Router Class Initialized
INFO - 2016-02-27 13:13:09 --> Output Class Initialized
INFO - 2016-02-27 13:13:09 --> Security Class Initialized
DEBUG - 2016-02-27 13:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:13:09 --> Input Class Initialized
INFO - 2016-02-27 13:13:09 --> Language Class Initialized
INFO - 2016-02-27 13:13:09 --> Loader Class Initialized
INFO - 2016-02-27 13:13:09 --> Helper loaded: url_helper
INFO - 2016-02-27 13:13:09 --> Helper loaded: file_helper
INFO - 2016-02-27 13:13:09 --> Helper loaded: date_helper
INFO - 2016-02-27 13:13:09 --> Helper loaded: form_helper
INFO - 2016-02-27 13:13:09 --> Database Driver Class Initialized
INFO - 2016-02-27 13:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:13:10 --> Controller Class Initialized
INFO - 2016-02-27 13:13:10 --> Model Class Initialized
INFO - 2016-02-27 13:13:10 --> Model Class Initialized
INFO - 2016-02-27 13:13:10 --> Form Validation Class Initialized
INFO - 2016-02-27 13:13:10 --> Helper loaded: text_helper
INFO - 2016-02-27 13:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:13:10 --> Final output sent to browser
DEBUG - 2016-02-27 13:13:10 --> Total execution time: 1.2348
INFO - 2016-02-27 13:13:34 --> Config Class Initialized
INFO - 2016-02-27 13:13:34 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:13:34 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:13:34 --> Utf8 Class Initialized
INFO - 2016-02-27 13:13:34 --> URI Class Initialized
INFO - 2016-02-27 13:13:34 --> Router Class Initialized
INFO - 2016-02-27 13:13:34 --> Output Class Initialized
INFO - 2016-02-27 13:13:34 --> Security Class Initialized
DEBUG - 2016-02-27 13:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:13:34 --> Input Class Initialized
INFO - 2016-02-27 13:13:34 --> Language Class Initialized
INFO - 2016-02-27 13:13:34 --> Loader Class Initialized
INFO - 2016-02-27 13:13:34 --> Helper loaded: url_helper
INFO - 2016-02-27 13:13:34 --> Helper loaded: file_helper
INFO - 2016-02-27 13:13:34 --> Helper loaded: date_helper
INFO - 2016-02-27 13:13:34 --> Helper loaded: form_helper
INFO - 2016-02-27 13:13:34 --> Database Driver Class Initialized
INFO - 2016-02-27 13:13:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:13:35 --> Controller Class Initialized
INFO - 2016-02-27 13:13:36 --> Model Class Initialized
INFO - 2016-02-27 13:13:36 --> Model Class Initialized
INFO - 2016-02-27 13:13:36 --> Form Validation Class Initialized
INFO - 2016-02-27 13:13:36 --> Helper loaded: text_helper
INFO - 2016-02-27 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:13:36 --> Final output sent to browser
DEBUG - 2016-02-27 13:13:36 --> Total execution time: 1.1131
INFO - 2016-02-27 13:13:40 --> Config Class Initialized
INFO - 2016-02-27 13:13:40 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:13:40 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:13:40 --> Utf8 Class Initialized
INFO - 2016-02-27 13:13:40 --> URI Class Initialized
INFO - 2016-02-27 13:13:40 --> Router Class Initialized
INFO - 2016-02-27 13:13:40 --> Output Class Initialized
INFO - 2016-02-27 13:13:40 --> Security Class Initialized
DEBUG - 2016-02-27 13:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:13:40 --> Input Class Initialized
INFO - 2016-02-27 13:13:40 --> Language Class Initialized
INFO - 2016-02-27 13:13:40 --> Loader Class Initialized
INFO - 2016-02-27 13:13:40 --> Helper loaded: url_helper
INFO - 2016-02-27 13:13:40 --> Helper loaded: file_helper
INFO - 2016-02-27 13:13:40 --> Helper loaded: date_helper
INFO - 2016-02-27 13:13:41 --> Helper loaded: form_helper
INFO - 2016-02-27 13:13:41 --> Database Driver Class Initialized
INFO - 2016-02-27 13:13:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:13:42 --> Controller Class Initialized
INFO - 2016-02-27 13:13:42 --> Model Class Initialized
INFO - 2016-02-27 13:13:42 --> Model Class Initialized
INFO - 2016-02-27 13:13:42 --> Form Validation Class Initialized
INFO - 2016-02-27 13:13:42 --> Helper loaded: text_helper
INFO - 2016-02-27 13:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:13:42 --> Final output sent to browser
DEBUG - 2016-02-27 13:13:42 --> Total execution time: 1.1006
INFO - 2016-02-27 13:13:51 --> Config Class Initialized
INFO - 2016-02-27 13:13:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:13:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:13:51 --> Utf8 Class Initialized
INFO - 2016-02-27 13:13:51 --> URI Class Initialized
INFO - 2016-02-27 13:13:51 --> Router Class Initialized
INFO - 2016-02-27 13:13:51 --> Output Class Initialized
INFO - 2016-02-27 13:13:51 --> Security Class Initialized
DEBUG - 2016-02-27 13:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:13:51 --> Input Class Initialized
INFO - 2016-02-27 13:13:51 --> Language Class Initialized
INFO - 2016-02-27 13:13:51 --> Loader Class Initialized
INFO - 2016-02-27 13:13:51 --> Helper loaded: url_helper
INFO - 2016-02-27 13:13:51 --> Helper loaded: file_helper
INFO - 2016-02-27 13:13:51 --> Helper loaded: date_helper
INFO - 2016-02-27 13:13:51 --> Helper loaded: form_helper
INFO - 2016-02-27 13:13:51 --> Database Driver Class Initialized
INFO - 2016-02-27 13:13:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:13:52 --> Controller Class Initialized
INFO - 2016-02-27 13:13:52 --> Model Class Initialized
INFO - 2016-02-27 13:13:52 --> Model Class Initialized
INFO - 2016-02-27 13:13:52 --> Form Validation Class Initialized
INFO - 2016-02-27 13:13:52 --> Helper loaded: text_helper
INFO - 2016-02-27 13:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:13:52 --> Final output sent to browser
DEBUG - 2016-02-27 13:13:52 --> Total execution time: 1.1836
INFO - 2016-02-27 13:14:10 --> Config Class Initialized
INFO - 2016-02-27 13:14:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:14:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:14:10 --> Utf8 Class Initialized
INFO - 2016-02-27 13:14:10 --> URI Class Initialized
INFO - 2016-02-27 13:14:10 --> Router Class Initialized
INFO - 2016-02-27 13:14:10 --> Output Class Initialized
INFO - 2016-02-27 13:14:10 --> Security Class Initialized
DEBUG - 2016-02-27 13:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:14:10 --> Input Class Initialized
INFO - 2016-02-27 13:14:10 --> Language Class Initialized
INFO - 2016-02-27 13:14:10 --> Loader Class Initialized
INFO - 2016-02-27 13:14:10 --> Helper loaded: url_helper
INFO - 2016-02-27 13:14:10 --> Helper loaded: file_helper
INFO - 2016-02-27 13:14:10 --> Helper loaded: date_helper
INFO - 2016-02-27 13:14:10 --> Helper loaded: form_helper
INFO - 2016-02-27 13:14:10 --> Database Driver Class Initialized
INFO - 2016-02-27 13:14:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:14:11 --> Controller Class Initialized
INFO - 2016-02-27 13:14:11 --> Model Class Initialized
INFO - 2016-02-27 13:14:11 --> Model Class Initialized
INFO - 2016-02-27 13:14:11 --> Form Validation Class Initialized
INFO - 2016-02-27 13:14:11 --> Helper loaded: text_helper
INFO - 2016-02-27 13:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:14:11 --> Final output sent to browser
DEBUG - 2016-02-27 13:14:11 --> Total execution time: 1.1776
INFO - 2016-02-27 13:15:54 --> Config Class Initialized
INFO - 2016-02-27 13:15:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:15:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:15:54 --> Utf8 Class Initialized
INFO - 2016-02-27 13:15:54 --> URI Class Initialized
INFO - 2016-02-27 13:15:54 --> Router Class Initialized
INFO - 2016-02-27 13:15:54 --> Output Class Initialized
INFO - 2016-02-27 13:15:54 --> Security Class Initialized
DEBUG - 2016-02-27 13:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:15:54 --> Input Class Initialized
INFO - 2016-02-27 13:15:54 --> Language Class Initialized
INFO - 2016-02-27 13:15:54 --> Loader Class Initialized
INFO - 2016-02-27 13:15:54 --> Helper loaded: url_helper
INFO - 2016-02-27 13:15:54 --> Helper loaded: file_helper
INFO - 2016-02-27 13:15:54 --> Helper loaded: date_helper
INFO - 2016-02-27 13:15:54 --> Helper loaded: form_helper
INFO - 2016-02-27 13:15:54 --> Database Driver Class Initialized
INFO - 2016-02-27 13:15:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:15:55 --> Controller Class Initialized
INFO - 2016-02-27 13:15:55 --> Model Class Initialized
INFO - 2016-02-27 13:15:55 --> Model Class Initialized
INFO - 2016-02-27 13:15:55 --> Form Validation Class Initialized
INFO - 2016-02-27 13:15:55 --> Helper loaded: text_helper
INFO - 2016-02-27 13:15:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:15:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:15:55 --> Final output sent to browser
DEBUG - 2016-02-27 13:15:55 --> Total execution time: 1.1168
INFO - 2016-02-27 13:16:49 --> Config Class Initialized
INFO - 2016-02-27 13:16:49 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:16:49 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:16:49 --> Utf8 Class Initialized
INFO - 2016-02-27 13:16:49 --> URI Class Initialized
INFO - 2016-02-27 13:16:49 --> Router Class Initialized
INFO - 2016-02-27 13:16:49 --> Output Class Initialized
INFO - 2016-02-27 13:16:49 --> Security Class Initialized
DEBUG - 2016-02-27 13:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:16:49 --> Input Class Initialized
INFO - 2016-02-27 13:16:49 --> Language Class Initialized
INFO - 2016-02-27 13:16:49 --> Loader Class Initialized
INFO - 2016-02-27 13:16:49 --> Helper loaded: url_helper
INFO - 2016-02-27 13:16:49 --> Helper loaded: file_helper
INFO - 2016-02-27 13:16:49 --> Helper loaded: date_helper
INFO - 2016-02-27 13:16:49 --> Helper loaded: form_helper
INFO - 2016-02-27 13:16:49 --> Database Driver Class Initialized
INFO - 2016-02-27 13:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:16:50 --> Controller Class Initialized
INFO - 2016-02-27 13:16:50 --> Model Class Initialized
INFO - 2016-02-27 13:16:50 --> Model Class Initialized
INFO - 2016-02-27 13:16:50 --> Form Validation Class Initialized
INFO - 2016-02-27 13:16:50 --> Helper loaded: text_helper
INFO - 2016-02-27 13:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:16:50 --> Final output sent to browser
DEBUG - 2016-02-27 13:16:50 --> Total execution time: 1.1517
INFO - 2016-02-27 13:17:16 --> Config Class Initialized
INFO - 2016-02-27 13:17:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:17:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:17:16 --> Utf8 Class Initialized
INFO - 2016-02-27 13:17:16 --> URI Class Initialized
INFO - 2016-02-27 13:17:16 --> Router Class Initialized
INFO - 2016-02-27 13:17:16 --> Output Class Initialized
INFO - 2016-02-27 13:17:16 --> Security Class Initialized
DEBUG - 2016-02-27 13:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:17:16 --> Input Class Initialized
INFO - 2016-02-27 13:17:16 --> Language Class Initialized
INFO - 2016-02-27 13:17:16 --> Loader Class Initialized
INFO - 2016-02-27 13:17:16 --> Helper loaded: url_helper
INFO - 2016-02-27 13:17:16 --> Helper loaded: file_helper
INFO - 2016-02-27 13:17:16 --> Helper loaded: date_helper
INFO - 2016-02-27 13:17:16 --> Helper loaded: form_helper
INFO - 2016-02-27 13:17:16 --> Database Driver Class Initialized
INFO - 2016-02-27 13:17:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:17:17 --> Controller Class Initialized
INFO - 2016-02-27 13:17:17 --> Model Class Initialized
INFO - 2016-02-27 13:17:17 --> Model Class Initialized
INFO - 2016-02-27 13:17:17 --> Form Validation Class Initialized
INFO - 2016-02-27 13:17:17 --> Helper loaded: text_helper
INFO - 2016-02-27 13:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:17:17 --> Final output sent to browser
DEBUG - 2016-02-27 13:17:17 --> Total execution time: 1.1435
INFO - 2016-02-27 13:17:25 --> Config Class Initialized
INFO - 2016-02-27 13:17:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:17:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:17:25 --> Utf8 Class Initialized
INFO - 2016-02-27 13:17:25 --> URI Class Initialized
INFO - 2016-02-27 13:17:25 --> Router Class Initialized
INFO - 2016-02-27 13:17:25 --> Output Class Initialized
INFO - 2016-02-27 13:17:25 --> Security Class Initialized
DEBUG - 2016-02-27 13:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:17:25 --> Input Class Initialized
INFO - 2016-02-27 13:17:25 --> Language Class Initialized
INFO - 2016-02-27 13:17:25 --> Loader Class Initialized
INFO - 2016-02-27 13:17:25 --> Helper loaded: url_helper
INFO - 2016-02-27 13:17:25 --> Helper loaded: file_helper
INFO - 2016-02-27 13:17:25 --> Helper loaded: date_helper
INFO - 2016-02-27 13:17:25 --> Helper loaded: form_helper
INFO - 2016-02-27 13:17:25 --> Database Driver Class Initialized
INFO - 2016-02-27 13:17:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:17:26 --> Controller Class Initialized
INFO - 2016-02-27 13:17:26 --> Model Class Initialized
INFO - 2016-02-27 13:17:26 --> Model Class Initialized
INFO - 2016-02-27 13:17:26 --> Form Validation Class Initialized
INFO - 2016-02-27 13:17:26 --> Helper loaded: text_helper
INFO - 2016-02-27 13:17:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:17:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:17:26 --> Final output sent to browser
DEBUG - 2016-02-27 13:17:26 --> Total execution time: 1.1282
INFO - 2016-02-27 13:18:47 --> Config Class Initialized
INFO - 2016-02-27 13:18:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:18:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:18:47 --> Utf8 Class Initialized
INFO - 2016-02-27 13:18:47 --> URI Class Initialized
INFO - 2016-02-27 13:18:47 --> Router Class Initialized
INFO - 2016-02-27 13:18:47 --> Output Class Initialized
INFO - 2016-02-27 13:18:47 --> Security Class Initialized
DEBUG - 2016-02-27 13:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:18:47 --> Input Class Initialized
INFO - 2016-02-27 13:18:47 --> Language Class Initialized
INFO - 2016-02-27 13:18:47 --> Loader Class Initialized
INFO - 2016-02-27 13:18:47 --> Helper loaded: url_helper
INFO - 2016-02-27 13:18:47 --> Helper loaded: file_helper
INFO - 2016-02-27 13:18:47 --> Helper loaded: date_helper
INFO - 2016-02-27 13:18:47 --> Helper loaded: form_helper
INFO - 2016-02-27 13:18:47 --> Database Driver Class Initialized
INFO - 2016-02-27 13:18:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:18:49 --> Controller Class Initialized
INFO - 2016-02-27 13:18:49 --> Model Class Initialized
INFO - 2016-02-27 13:18:49 --> Model Class Initialized
INFO - 2016-02-27 13:18:49 --> Form Validation Class Initialized
INFO - 2016-02-27 13:18:49 --> Helper loaded: text_helper
INFO - 2016-02-27 13:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:18:49 --> Final output sent to browser
DEBUG - 2016-02-27 13:18:49 --> Total execution time: 1.1493
INFO - 2016-02-27 13:21:53 --> Config Class Initialized
INFO - 2016-02-27 13:21:53 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:21:53 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:21:53 --> Utf8 Class Initialized
INFO - 2016-02-27 13:21:53 --> URI Class Initialized
INFO - 2016-02-27 13:21:53 --> Router Class Initialized
INFO - 2016-02-27 13:21:53 --> Output Class Initialized
INFO - 2016-02-27 13:21:53 --> Security Class Initialized
DEBUG - 2016-02-27 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:21:53 --> Input Class Initialized
INFO - 2016-02-27 13:21:53 --> Language Class Initialized
INFO - 2016-02-27 13:21:53 --> Loader Class Initialized
INFO - 2016-02-27 13:21:53 --> Helper loaded: url_helper
INFO - 2016-02-27 13:21:53 --> Helper loaded: file_helper
INFO - 2016-02-27 13:21:53 --> Helper loaded: date_helper
INFO - 2016-02-27 13:21:53 --> Helper loaded: form_helper
INFO - 2016-02-27 13:21:53 --> Database Driver Class Initialized
INFO - 2016-02-27 13:21:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:21:54 --> Controller Class Initialized
INFO - 2016-02-27 13:21:54 --> Model Class Initialized
INFO - 2016-02-27 13:21:54 --> Model Class Initialized
INFO - 2016-02-27 13:21:54 --> Form Validation Class Initialized
INFO - 2016-02-27 13:21:54 --> Helper loaded: text_helper
INFO - 2016-02-27 13:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:21:54 --> Final output sent to browser
DEBUG - 2016-02-27 13:21:54 --> Total execution time: 1.0828
INFO - 2016-02-27 13:22:44 --> Config Class Initialized
INFO - 2016-02-27 13:22:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:22:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:22:44 --> Utf8 Class Initialized
INFO - 2016-02-27 13:22:44 --> URI Class Initialized
INFO - 2016-02-27 13:22:44 --> Router Class Initialized
INFO - 2016-02-27 13:22:44 --> Output Class Initialized
INFO - 2016-02-27 13:22:44 --> Security Class Initialized
DEBUG - 2016-02-27 13:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:22:44 --> Input Class Initialized
INFO - 2016-02-27 13:22:44 --> Language Class Initialized
INFO - 2016-02-27 13:22:44 --> Loader Class Initialized
INFO - 2016-02-27 13:22:44 --> Helper loaded: url_helper
INFO - 2016-02-27 13:22:44 --> Helper loaded: file_helper
INFO - 2016-02-27 13:22:44 --> Helper loaded: date_helper
INFO - 2016-02-27 13:22:44 --> Helper loaded: form_helper
INFO - 2016-02-27 13:22:44 --> Database Driver Class Initialized
INFO - 2016-02-27 13:22:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:22:45 --> Controller Class Initialized
INFO - 2016-02-27 13:22:45 --> Model Class Initialized
INFO - 2016-02-27 13:22:45 --> Model Class Initialized
INFO - 2016-02-27 13:22:45 --> Form Validation Class Initialized
INFO - 2016-02-27 13:22:45 --> Helper loaded: text_helper
INFO - 2016-02-27 13:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:22:45 --> Final output sent to browser
DEBUG - 2016-02-27 13:22:45 --> Total execution time: 1.1367
INFO - 2016-02-27 13:24:42 --> Config Class Initialized
INFO - 2016-02-27 13:24:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:24:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:24:42 --> Utf8 Class Initialized
INFO - 2016-02-27 13:24:42 --> URI Class Initialized
INFO - 2016-02-27 13:24:42 --> Router Class Initialized
INFO - 2016-02-27 13:24:42 --> Output Class Initialized
INFO - 2016-02-27 13:24:42 --> Security Class Initialized
DEBUG - 2016-02-27 13:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:24:42 --> Input Class Initialized
INFO - 2016-02-27 13:24:42 --> Language Class Initialized
INFO - 2016-02-27 13:24:42 --> Loader Class Initialized
INFO - 2016-02-27 13:24:42 --> Helper loaded: url_helper
INFO - 2016-02-27 13:24:42 --> Helper loaded: file_helper
INFO - 2016-02-27 13:24:42 --> Helper loaded: date_helper
INFO - 2016-02-27 13:24:42 --> Helper loaded: form_helper
INFO - 2016-02-27 13:24:42 --> Database Driver Class Initialized
INFO - 2016-02-27 13:24:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:24:43 --> Controller Class Initialized
INFO - 2016-02-27 13:24:43 --> Model Class Initialized
INFO - 2016-02-27 13:24:43 --> Model Class Initialized
INFO - 2016-02-27 13:24:43 --> Form Validation Class Initialized
INFO - 2016-02-27 13:24:43 --> Helper loaded: text_helper
INFO - 2016-02-27 13:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:24:43 --> Final output sent to browser
DEBUG - 2016-02-27 13:24:43 --> Total execution time: 1.1030
INFO - 2016-02-27 13:25:19 --> Config Class Initialized
INFO - 2016-02-27 13:25:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:25:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:25:19 --> Utf8 Class Initialized
INFO - 2016-02-27 13:25:19 --> URI Class Initialized
INFO - 2016-02-27 13:25:19 --> Router Class Initialized
INFO - 2016-02-27 13:25:19 --> Output Class Initialized
INFO - 2016-02-27 13:25:19 --> Security Class Initialized
DEBUG - 2016-02-27 13:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:25:19 --> Input Class Initialized
INFO - 2016-02-27 13:25:19 --> Language Class Initialized
INFO - 2016-02-27 13:25:19 --> Loader Class Initialized
INFO - 2016-02-27 13:25:19 --> Helper loaded: url_helper
INFO - 2016-02-27 13:25:19 --> Helper loaded: file_helper
INFO - 2016-02-27 13:25:19 --> Helper loaded: date_helper
INFO - 2016-02-27 13:25:19 --> Helper loaded: form_helper
INFO - 2016-02-27 13:25:19 --> Database Driver Class Initialized
INFO - 2016-02-27 13:25:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:25:20 --> Controller Class Initialized
INFO - 2016-02-27 13:25:20 --> Model Class Initialized
INFO - 2016-02-27 13:25:20 --> Model Class Initialized
INFO - 2016-02-27 13:25:20 --> Form Validation Class Initialized
INFO - 2016-02-27 13:25:20 --> Helper loaded: text_helper
INFO - 2016-02-27 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:25:20 --> Final output sent to browser
DEBUG - 2016-02-27 13:25:20 --> Total execution time: 1.1132
INFO - 2016-02-27 13:26:25 --> Config Class Initialized
INFO - 2016-02-27 13:26:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:26:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:26:25 --> Utf8 Class Initialized
INFO - 2016-02-27 13:26:25 --> URI Class Initialized
INFO - 2016-02-27 13:26:25 --> Router Class Initialized
INFO - 2016-02-27 13:26:25 --> Output Class Initialized
INFO - 2016-02-27 13:26:25 --> Security Class Initialized
DEBUG - 2016-02-27 13:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:26:25 --> Input Class Initialized
INFO - 2016-02-27 13:26:25 --> Language Class Initialized
INFO - 2016-02-27 13:26:25 --> Loader Class Initialized
INFO - 2016-02-27 13:26:25 --> Helper loaded: url_helper
INFO - 2016-02-27 13:26:25 --> Helper loaded: file_helper
INFO - 2016-02-27 13:26:25 --> Helper loaded: date_helper
INFO - 2016-02-27 13:26:25 --> Helper loaded: form_helper
INFO - 2016-02-27 13:26:25 --> Database Driver Class Initialized
INFO - 2016-02-27 13:26:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:26:26 --> Controller Class Initialized
INFO - 2016-02-27 13:26:26 --> Model Class Initialized
INFO - 2016-02-27 13:26:26 --> Model Class Initialized
INFO - 2016-02-27 13:26:26 --> Form Validation Class Initialized
INFO - 2016-02-27 13:26:26 --> Helper loaded: text_helper
INFO - 2016-02-27 13:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:26:26 --> Final output sent to browser
DEBUG - 2016-02-27 13:26:26 --> Total execution time: 1.1090
INFO - 2016-02-27 13:27:26 --> Config Class Initialized
INFO - 2016-02-27 13:27:26 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:27:26 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:27:26 --> Utf8 Class Initialized
INFO - 2016-02-27 13:27:26 --> URI Class Initialized
INFO - 2016-02-27 13:27:26 --> Router Class Initialized
INFO - 2016-02-27 13:27:26 --> Output Class Initialized
INFO - 2016-02-27 13:27:26 --> Security Class Initialized
DEBUG - 2016-02-27 13:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:27:26 --> Input Class Initialized
INFO - 2016-02-27 13:27:26 --> Language Class Initialized
INFO - 2016-02-27 13:27:26 --> Loader Class Initialized
INFO - 2016-02-27 13:27:26 --> Helper loaded: url_helper
INFO - 2016-02-27 13:27:26 --> Helper loaded: file_helper
INFO - 2016-02-27 13:27:26 --> Helper loaded: date_helper
INFO - 2016-02-27 13:27:26 --> Helper loaded: form_helper
INFO - 2016-02-27 13:27:26 --> Database Driver Class Initialized
INFO - 2016-02-27 13:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:27:27 --> Controller Class Initialized
INFO - 2016-02-27 13:27:27 --> Model Class Initialized
INFO - 2016-02-27 13:27:27 --> Model Class Initialized
INFO - 2016-02-27 13:27:27 --> Form Validation Class Initialized
INFO - 2016-02-27 13:27:27 --> Helper loaded: text_helper
INFO - 2016-02-27 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:27:27 --> Final output sent to browser
DEBUG - 2016-02-27 13:27:27 --> Total execution time: 1.0993
INFO - 2016-02-27 13:27:40 --> Config Class Initialized
INFO - 2016-02-27 13:27:40 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:27:40 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:27:40 --> Utf8 Class Initialized
INFO - 2016-02-27 13:27:40 --> URI Class Initialized
INFO - 2016-02-27 13:27:40 --> Router Class Initialized
INFO - 2016-02-27 13:27:40 --> Output Class Initialized
INFO - 2016-02-27 13:27:40 --> Security Class Initialized
DEBUG - 2016-02-27 13:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:27:40 --> Input Class Initialized
INFO - 2016-02-27 13:27:40 --> Language Class Initialized
INFO - 2016-02-27 13:27:40 --> Loader Class Initialized
INFO - 2016-02-27 13:27:40 --> Helper loaded: url_helper
INFO - 2016-02-27 13:27:40 --> Helper loaded: file_helper
INFO - 2016-02-27 13:27:40 --> Helper loaded: date_helper
INFO - 2016-02-27 13:27:40 --> Helper loaded: form_helper
INFO - 2016-02-27 13:27:40 --> Database Driver Class Initialized
INFO - 2016-02-27 13:27:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:27:41 --> Controller Class Initialized
INFO - 2016-02-27 13:27:41 --> Model Class Initialized
INFO - 2016-02-27 13:27:41 --> Model Class Initialized
INFO - 2016-02-27 13:27:41 --> Form Validation Class Initialized
INFO - 2016-02-27 13:27:41 --> Helper loaded: text_helper
INFO - 2016-02-27 13:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:27:41 --> Final output sent to browser
DEBUG - 2016-02-27 13:27:41 --> Total execution time: 1.1120
INFO - 2016-02-27 13:27:45 --> Config Class Initialized
INFO - 2016-02-27 13:27:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:27:46 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:27:46 --> Utf8 Class Initialized
INFO - 2016-02-27 13:27:46 --> URI Class Initialized
INFO - 2016-02-27 13:27:46 --> Router Class Initialized
INFO - 2016-02-27 13:27:46 --> Output Class Initialized
INFO - 2016-02-27 13:27:46 --> Security Class Initialized
DEBUG - 2016-02-27 13:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:27:46 --> Input Class Initialized
INFO - 2016-02-27 13:27:46 --> Language Class Initialized
INFO - 2016-02-27 13:27:46 --> Loader Class Initialized
INFO - 2016-02-27 13:27:46 --> Helper loaded: url_helper
INFO - 2016-02-27 13:27:46 --> Helper loaded: file_helper
INFO - 2016-02-27 13:27:46 --> Helper loaded: date_helper
INFO - 2016-02-27 13:27:46 --> Helper loaded: form_helper
INFO - 2016-02-27 13:27:46 --> Database Driver Class Initialized
INFO - 2016-02-27 13:27:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:27:47 --> Controller Class Initialized
INFO - 2016-02-27 13:27:47 --> Model Class Initialized
INFO - 2016-02-27 13:27:47 --> Model Class Initialized
INFO - 2016-02-27 13:27:47 --> Form Validation Class Initialized
INFO - 2016-02-27 13:27:47 --> Helper loaded: text_helper
INFO - 2016-02-27 13:27:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:27:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:27:47 --> Final output sent to browser
DEBUG - 2016-02-27 13:27:47 --> Total execution time: 1.1853
INFO - 2016-02-27 13:28:16 --> Config Class Initialized
INFO - 2016-02-27 13:28:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:28:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:28:16 --> Utf8 Class Initialized
INFO - 2016-02-27 13:28:16 --> URI Class Initialized
INFO - 2016-02-27 13:28:16 --> Router Class Initialized
INFO - 2016-02-27 13:28:16 --> Output Class Initialized
INFO - 2016-02-27 13:28:16 --> Security Class Initialized
DEBUG - 2016-02-27 13:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:28:16 --> Input Class Initialized
INFO - 2016-02-27 13:28:16 --> Language Class Initialized
INFO - 2016-02-27 13:28:16 --> Loader Class Initialized
INFO - 2016-02-27 13:28:16 --> Helper loaded: url_helper
INFO - 2016-02-27 13:28:16 --> Helper loaded: file_helper
INFO - 2016-02-27 13:28:16 --> Helper loaded: date_helper
INFO - 2016-02-27 13:28:16 --> Helper loaded: form_helper
INFO - 2016-02-27 13:28:16 --> Database Driver Class Initialized
INFO - 2016-02-27 13:28:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:28:17 --> Controller Class Initialized
INFO - 2016-02-27 13:28:17 --> Model Class Initialized
INFO - 2016-02-27 13:28:17 --> Model Class Initialized
INFO - 2016-02-27 13:28:17 --> Form Validation Class Initialized
INFO - 2016-02-27 13:28:17 --> Helper loaded: text_helper
INFO - 2016-02-27 13:28:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:28:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:28:17 --> Final output sent to browser
DEBUG - 2016-02-27 13:28:17 --> Total execution time: 1.1474
INFO - 2016-02-27 13:28:54 --> Config Class Initialized
INFO - 2016-02-27 13:28:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:28:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:28:54 --> Utf8 Class Initialized
INFO - 2016-02-27 13:28:54 --> URI Class Initialized
INFO - 2016-02-27 13:28:54 --> Router Class Initialized
INFO - 2016-02-27 13:28:54 --> Output Class Initialized
INFO - 2016-02-27 13:28:54 --> Security Class Initialized
DEBUG - 2016-02-27 13:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:28:54 --> Input Class Initialized
INFO - 2016-02-27 13:28:54 --> Language Class Initialized
INFO - 2016-02-27 13:28:54 --> Loader Class Initialized
INFO - 2016-02-27 13:28:54 --> Helper loaded: url_helper
INFO - 2016-02-27 13:28:54 --> Helper loaded: file_helper
INFO - 2016-02-27 13:28:54 --> Helper loaded: date_helper
INFO - 2016-02-27 13:28:54 --> Helper loaded: form_helper
INFO - 2016-02-27 13:28:54 --> Database Driver Class Initialized
INFO - 2016-02-27 13:28:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:28:55 --> Controller Class Initialized
INFO - 2016-02-27 13:28:55 --> Model Class Initialized
INFO - 2016-02-27 13:28:55 --> Model Class Initialized
INFO - 2016-02-27 13:28:55 --> Form Validation Class Initialized
INFO - 2016-02-27 13:28:55 --> Helper loaded: text_helper
INFO - 2016-02-27 13:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:28:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:28:55 --> Final output sent to browser
DEBUG - 2016-02-27 13:28:55 --> Total execution time: 1.1350
INFO - 2016-02-27 13:29:24 --> Config Class Initialized
INFO - 2016-02-27 13:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:29:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:29:24 --> Utf8 Class Initialized
INFO - 2016-02-27 13:29:24 --> URI Class Initialized
INFO - 2016-02-27 13:29:24 --> Router Class Initialized
INFO - 2016-02-27 13:29:24 --> Output Class Initialized
INFO - 2016-02-27 13:29:24 --> Security Class Initialized
DEBUG - 2016-02-27 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:29:24 --> Input Class Initialized
INFO - 2016-02-27 13:29:24 --> Language Class Initialized
INFO - 2016-02-27 13:29:24 --> Loader Class Initialized
INFO - 2016-02-27 13:29:24 --> Helper loaded: url_helper
INFO - 2016-02-27 13:29:24 --> Helper loaded: file_helper
INFO - 2016-02-27 13:29:24 --> Helper loaded: date_helper
INFO - 2016-02-27 13:29:24 --> Helper loaded: form_helper
INFO - 2016-02-27 13:29:24 --> Database Driver Class Initialized
INFO - 2016-02-27 13:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:29:25 --> Controller Class Initialized
INFO - 2016-02-27 13:29:25 --> Model Class Initialized
INFO - 2016-02-27 13:29:25 --> Model Class Initialized
INFO - 2016-02-27 13:29:25 --> Form Validation Class Initialized
INFO - 2016-02-27 13:29:25 --> Helper loaded: text_helper
INFO - 2016-02-27 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:29:25 --> Final output sent to browser
DEBUG - 2016-02-27 13:29:25 --> Total execution time: 1.1256
INFO - 2016-02-27 13:29:35 --> Config Class Initialized
INFO - 2016-02-27 13:29:35 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:29:35 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:29:35 --> Utf8 Class Initialized
INFO - 2016-02-27 13:29:35 --> URI Class Initialized
INFO - 2016-02-27 13:29:35 --> Router Class Initialized
INFO - 2016-02-27 13:29:35 --> Output Class Initialized
INFO - 2016-02-27 13:29:35 --> Security Class Initialized
DEBUG - 2016-02-27 13:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:29:35 --> Input Class Initialized
INFO - 2016-02-27 13:29:35 --> Language Class Initialized
INFO - 2016-02-27 13:29:35 --> Loader Class Initialized
INFO - 2016-02-27 13:29:35 --> Helper loaded: url_helper
INFO - 2016-02-27 13:29:35 --> Helper loaded: file_helper
INFO - 2016-02-27 13:29:35 --> Helper loaded: date_helper
INFO - 2016-02-27 13:29:35 --> Helper loaded: form_helper
INFO - 2016-02-27 13:29:35 --> Database Driver Class Initialized
INFO - 2016-02-27 13:29:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:29:37 --> Controller Class Initialized
INFO - 2016-02-27 13:29:37 --> Model Class Initialized
INFO - 2016-02-27 13:29:37 --> Model Class Initialized
INFO - 2016-02-27 13:29:37 --> Form Validation Class Initialized
INFO - 2016-02-27 13:29:37 --> Helper loaded: text_helper
INFO - 2016-02-27 13:29:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:29:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:29:37 --> Final output sent to browser
DEBUG - 2016-02-27 13:29:37 --> Total execution time: 1.1419
INFO - 2016-02-27 13:29:49 --> Config Class Initialized
INFO - 2016-02-27 13:29:49 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:29:49 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:29:49 --> Utf8 Class Initialized
INFO - 2016-02-27 13:29:49 --> URI Class Initialized
INFO - 2016-02-27 13:29:49 --> Router Class Initialized
INFO - 2016-02-27 13:29:49 --> Output Class Initialized
INFO - 2016-02-27 13:29:49 --> Security Class Initialized
DEBUG - 2016-02-27 13:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:29:49 --> Input Class Initialized
INFO - 2016-02-27 13:29:49 --> Language Class Initialized
INFO - 2016-02-27 13:29:49 --> Loader Class Initialized
INFO - 2016-02-27 13:29:49 --> Helper loaded: url_helper
INFO - 2016-02-27 13:29:49 --> Helper loaded: file_helper
INFO - 2016-02-27 13:29:49 --> Helper loaded: date_helper
INFO - 2016-02-27 13:29:49 --> Helper loaded: form_helper
INFO - 2016-02-27 13:29:49 --> Database Driver Class Initialized
INFO - 2016-02-27 13:29:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:29:50 --> Controller Class Initialized
INFO - 2016-02-27 13:29:50 --> Model Class Initialized
INFO - 2016-02-27 13:29:50 --> Model Class Initialized
INFO - 2016-02-27 13:29:50 --> Form Validation Class Initialized
INFO - 2016-02-27 13:29:50 --> Helper loaded: text_helper
INFO - 2016-02-27 13:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:29:50 --> Final output sent to browser
DEBUG - 2016-02-27 13:29:50 --> Total execution time: 1.1147
INFO - 2016-02-27 13:32:09 --> Config Class Initialized
INFO - 2016-02-27 13:32:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:32:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:32:09 --> Utf8 Class Initialized
INFO - 2016-02-27 13:32:09 --> URI Class Initialized
INFO - 2016-02-27 13:32:09 --> Router Class Initialized
INFO - 2016-02-27 13:32:09 --> Output Class Initialized
INFO - 2016-02-27 13:32:09 --> Security Class Initialized
DEBUG - 2016-02-27 13:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:32:09 --> Input Class Initialized
INFO - 2016-02-27 13:32:09 --> Language Class Initialized
INFO - 2016-02-27 13:32:09 --> Loader Class Initialized
INFO - 2016-02-27 13:32:09 --> Helper loaded: url_helper
INFO - 2016-02-27 13:32:09 --> Helper loaded: file_helper
INFO - 2016-02-27 13:32:09 --> Helper loaded: date_helper
INFO - 2016-02-27 13:32:09 --> Helper loaded: form_helper
INFO - 2016-02-27 13:32:09 --> Database Driver Class Initialized
INFO - 2016-02-27 13:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:32:10 --> Controller Class Initialized
INFO - 2016-02-27 13:32:10 --> Model Class Initialized
INFO - 2016-02-27 13:32:10 --> Model Class Initialized
INFO - 2016-02-27 13:32:10 --> Form Validation Class Initialized
INFO - 2016-02-27 13:32:10 --> Helper loaded: text_helper
INFO - 2016-02-27 13:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:32:10 --> Final output sent to browser
DEBUG - 2016-02-27 13:32:10 --> Total execution time: 1.0999
INFO - 2016-02-27 13:33:06 --> Config Class Initialized
INFO - 2016-02-27 13:33:06 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:33:06 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:33:06 --> Utf8 Class Initialized
INFO - 2016-02-27 13:33:06 --> URI Class Initialized
INFO - 2016-02-27 13:33:06 --> Router Class Initialized
INFO - 2016-02-27 13:33:06 --> Output Class Initialized
INFO - 2016-02-27 13:33:06 --> Security Class Initialized
DEBUG - 2016-02-27 13:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:33:06 --> Input Class Initialized
INFO - 2016-02-27 13:33:06 --> Language Class Initialized
INFO - 2016-02-27 13:33:06 --> Loader Class Initialized
INFO - 2016-02-27 13:33:06 --> Helper loaded: url_helper
INFO - 2016-02-27 13:33:06 --> Helper loaded: file_helper
INFO - 2016-02-27 13:33:06 --> Helper loaded: date_helper
INFO - 2016-02-27 13:33:06 --> Helper loaded: form_helper
INFO - 2016-02-27 13:33:06 --> Database Driver Class Initialized
INFO - 2016-02-27 13:33:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:33:07 --> Controller Class Initialized
INFO - 2016-02-27 13:33:07 --> Model Class Initialized
INFO - 2016-02-27 13:33:07 --> Model Class Initialized
INFO - 2016-02-27 13:33:07 --> Form Validation Class Initialized
INFO - 2016-02-27 13:33:07 --> Helper loaded: text_helper
INFO - 2016-02-27 13:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:33:07 --> Final output sent to browser
DEBUG - 2016-02-27 13:33:07 --> Total execution time: 1.0838
INFO - 2016-02-27 13:38:50 --> Config Class Initialized
INFO - 2016-02-27 13:38:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:38:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:38:50 --> Utf8 Class Initialized
INFO - 2016-02-27 13:38:50 --> URI Class Initialized
INFO - 2016-02-27 13:38:50 --> Router Class Initialized
INFO - 2016-02-27 13:38:50 --> Output Class Initialized
INFO - 2016-02-27 13:38:50 --> Security Class Initialized
DEBUG - 2016-02-27 13:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:38:50 --> Input Class Initialized
INFO - 2016-02-27 13:38:50 --> Language Class Initialized
INFO - 2016-02-27 13:38:50 --> Loader Class Initialized
INFO - 2016-02-27 13:38:50 --> Helper loaded: url_helper
INFO - 2016-02-27 13:38:50 --> Helper loaded: file_helper
INFO - 2016-02-27 13:38:50 --> Helper loaded: date_helper
INFO - 2016-02-27 13:38:50 --> Helper loaded: form_helper
INFO - 2016-02-27 13:38:50 --> Database Driver Class Initialized
INFO - 2016-02-27 13:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:38:51 --> Controller Class Initialized
INFO - 2016-02-27 13:38:51 --> Model Class Initialized
INFO - 2016-02-27 13:38:51 --> Model Class Initialized
INFO - 2016-02-27 13:38:51 --> Form Validation Class Initialized
INFO - 2016-02-27 13:38:51 --> Helper loaded: text_helper
INFO - 2016-02-27 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:38:51 --> Final output sent to browser
DEBUG - 2016-02-27 13:38:51 --> Total execution time: 1.1016
INFO - 2016-02-27 13:39:38 --> Config Class Initialized
INFO - 2016-02-27 13:39:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:39:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:39:38 --> Utf8 Class Initialized
INFO - 2016-02-27 13:39:38 --> URI Class Initialized
INFO - 2016-02-27 13:39:38 --> Router Class Initialized
INFO - 2016-02-27 13:39:38 --> Output Class Initialized
INFO - 2016-02-27 13:39:38 --> Security Class Initialized
DEBUG - 2016-02-27 13:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:39:38 --> Input Class Initialized
INFO - 2016-02-27 13:39:38 --> Language Class Initialized
INFO - 2016-02-27 13:39:38 --> Loader Class Initialized
INFO - 2016-02-27 13:39:38 --> Helper loaded: url_helper
INFO - 2016-02-27 13:39:38 --> Helper loaded: file_helper
INFO - 2016-02-27 13:39:38 --> Helper loaded: date_helper
INFO - 2016-02-27 13:39:38 --> Helper loaded: form_helper
INFO - 2016-02-27 13:39:38 --> Database Driver Class Initialized
INFO - 2016-02-27 13:39:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:39:39 --> Controller Class Initialized
INFO - 2016-02-27 13:39:39 --> Model Class Initialized
INFO - 2016-02-27 13:39:39 --> Model Class Initialized
INFO - 2016-02-27 13:39:39 --> Form Validation Class Initialized
INFO - 2016-02-27 13:39:39 --> Helper loaded: text_helper
INFO - 2016-02-27 13:39:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:39:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:39:39 --> Final output sent to browser
DEBUG - 2016-02-27 13:39:39 --> Total execution time: 1.1403
INFO - 2016-02-27 13:41:07 --> Config Class Initialized
INFO - 2016-02-27 13:41:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:41:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:41:07 --> Utf8 Class Initialized
INFO - 2016-02-27 13:41:07 --> URI Class Initialized
INFO - 2016-02-27 13:41:07 --> Router Class Initialized
INFO - 2016-02-27 13:41:07 --> Output Class Initialized
INFO - 2016-02-27 13:41:07 --> Security Class Initialized
DEBUG - 2016-02-27 13:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:41:07 --> Input Class Initialized
INFO - 2016-02-27 13:41:07 --> Language Class Initialized
INFO - 2016-02-27 13:41:07 --> Loader Class Initialized
INFO - 2016-02-27 13:41:07 --> Helper loaded: url_helper
INFO - 2016-02-27 13:41:07 --> Helper loaded: file_helper
INFO - 2016-02-27 13:41:07 --> Helper loaded: date_helper
INFO - 2016-02-27 13:41:07 --> Helper loaded: form_helper
INFO - 2016-02-27 13:41:07 --> Database Driver Class Initialized
INFO - 2016-02-27 13:41:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:41:08 --> Controller Class Initialized
INFO - 2016-02-27 13:41:08 --> Model Class Initialized
INFO - 2016-02-27 13:41:08 --> Model Class Initialized
INFO - 2016-02-27 13:41:08 --> Form Validation Class Initialized
INFO - 2016-02-27 13:41:08 --> Helper loaded: text_helper
INFO - 2016-02-27 13:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:41:08 --> Final output sent to browser
DEBUG - 2016-02-27 13:41:08 --> Total execution time: 1.1371
INFO - 2016-02-27 13:41:59 --> Config Class Initialized
INFO - 2016-02-27 13:41:59 --> Hooks Class Initialized
DEBUG - 2016-02-27 13:41:59 --> UTF-8 Support Enabled
INFO - 2016-02-27 13:41:59 --> Utf8 Class Initialized
INFO - 2016-02-27 13:41:59 --> URI Class Initialized
INFO - 2016-02-27 13:41:59 --> Router Class Initialized
INFO - 2016-02-27 13:41:59 --> Output Class Initialized
INFO - 2016-02-27 13:41:59 --> Security Class Initialized
DEBUG - 2016-02-27 13:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 13:41:59 --> Input Class Initialized
INFO - 2016-02-27 13:41:59 --> Language Class Initialized
INFO - 2016-02-27 13:41:59 --> Loader Class Initialized
INFO - 2016-02-27 13:41:59 --> Helper loaded: url_helper
INFO - 2016-02-27 13:41:59 --> Helper loaded: file_helper
INFO - 2016-02-27 13:41:59 --> Helper loaded: date_helper
INFO - 2016-02-27 13:41:59 --> Helper loaded: form_helper
INFO - 2016-02-27 13:41:59 --> Database Driver Class Initialized
INFO - 2016-02-27 13:42:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 13:42:00 --> Controller Class Initialized
INFO - 2016-02-27 13:42:00 --> Model Class Initialized
INFO - 2016-02-27 13:42:00 --> Model Class Initialized
INFO - 2016-02-27 13:42:00 --> Form Validation Class Initialized
INFO - 2016-02-27 13:42:00 --> Helper loaded: text_helper
INFO - 2016-02-27 13:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 13:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 13:42:00 --> Final output sent to browser
DEBUG - 2016-02-27 13:42:00 --> Total execution time: 1.2218
INFO - 2016-02-27 14:04:09 --> Config Class Initialized
INFO - 2016-02-27 14:04:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:04:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:04:09 --> Utf8 Class Initialized
INFO - 2016-02-27 14:04:09 --> URI Class Initialized
DEBUG - 2016-02-27 14:04:09 --> No URI present. Default controller set.
INFO - 2016-02-27 14:04:09 --> Router Class Initialized
INFO - 2016-02-27 14:04:09 --> Output Class Initialized
INFO - 2016-02-27 14:04:09 --> Security Class Initialized
DEBUG - 2016-02-27 14:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:04:09 --> Input Class Initialized
INFO - 2016-02-27 14:04:09 --> Language Class Initialized
INFO - 2016-02-27 14:04:09 --> Loader Class Initialized
INFO - 2016-02-27 14:04:09 --> Helper loaded: url_helper
INFO - 2016-02-27 14:04:09 --> Helper loaded: file_helper
INFO - 2016-02-27 14:04:09 --> Helper loaded: date_helper
INFO - 2016-02-27 14:04:09 --> Helper loaded: form_helper
INFO - 2016-02-27 14:04:09 --> Database Driver Class Initialized
INFO - 2016-02-27 14:04:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:04:10 --> Controller Class Initialized
INFO - 2016-02-27 14:04:10 --> Model Class Initialized
INFO - 2016-02-27 14:04:10 --> Model Class Initialized
INFO - 2016-02-27 14:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:04:10 --> Pagination Class Initialized
INFO - 2016-02-27 14:04:10 --> Helper loaded: text_helper
INFO - 2016-02-27 14:04:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 17:04:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:04:10 --> Final output sent to browser
DEBUG - 2016-02-27 17:04:10 --> Total execution time: 1.3462
INFO - 2016-02-27 14:04:20 --> Config Class Initialized
INFO - 2016-02-27 14:04:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:04:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:04:20 --> Utf8 Class Initialized
INFO - 2016-02-27 14:04:20 --> URI Class Initialized
INFO - 2016-02-27 14:04:20 --> Router Class Initialized
INFO - 2016-02-27 14:04:20 --> Output Class Initialized
INFO - 2016-02-27 14:04:20 --> Security Class Initialized
DEBUG - 2016-02-27 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:04:20 --> Input Class Initialized
INFO - 2016-02-27 14:04:20 --> Language Class Initialized
INFO - 2016-02-27 14:04:20 --> Loader Class Initialized
INFO - 2016-02-27 14:04:20 --> Helper loaded: url_helper
INFO - 2016-02-27 14:04:20 --> Helper loaded: file_helper
INFO - 2016-02-27 14:04:20 --> Helper loaded: date_helper
INFO - 2016-02-27 14:04:20 --> Helper loaded: form_helper
INFO - 2016-02-27 14:04:20 --> Database Driver Class Initialized
INFO - 2016-02-27 14:04:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:04:21 --> Controller Class Initialized
INFO - 2016-02-27 14:04:21 --> Model Class Initialized
INFO - 2016-02-27 14:04:22 --> Model Class Initialized
INFO - 2016-02-27 14:04:22 --> Form Validation Class Initialized
INFO - 2016-02-27 14:04:22 --> Helper loaded: text_helper
INFO - 2016-02-27 14:04:22 --> Config Class Initialized
INFO - 2016-02-27 14:04:22 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:04:22 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:04:22 --> Utf8 Class Initialized
INFO - 2016-02-27 14:04:22 --> URI Class Initialized
INFO - 2016-02-27 14:04:22 --> Router Class Initialized
INFO - 2016-02-27 14:04:22 --> Output Class Initialized
INFO - 2016-02-27 14:04:22 --> Security Class Initialized
DEBUG - 2016-02-27 14:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:04:22 --> Input Class Initialized
INFO - 2016-02-27 14:04:22 --> Language Class Initialized
INFO - 2016-02-27 14:04:22 --> Loader Class Initialized
INFO - 2016-02-27 14:04:22 --> Helper loaded: url_helper
INFO - 2016-02-27 14:04:22 --> Helper loaded: file_helper
INFO - 2016-02-27 14:04:22 --> Helper loaded: date_helper
INFO - 2016-02-27 14:04:22 --> Helper loaded: form_helper
INFO - 2016-02-27 14:04:22 --> Database Driver Class Initialized
INFO - 2016-02-27 14:04:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:04:23 --> Controller Class Initialized
INFO - 2016-02-27 14:04:23 --> Model Class Initialized
INFO - 2016-02-27 14:04:23 --> Model Class Initialized
INFO - 2016-02-27 14:04:23 --> Form Validation Class Initialized
INFO - 2016-02-27 14:04:23 --> Helper loaded: text_helper
INFO - 2016-02-27 14:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 14:04:23 --> Final output sent to browser
DEBUG - 2016-02-27 14:04:23 --> Total execution time: 1.1435
INFO - 2016-02-27 14:05:08 --> Config Class Initialized
INFO - 2016-02-27 14:05:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:05:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:05:09 --> Utf8 Class Initialized
INFO - 2016-02-27 14:05:09 --> URI Class Initialized
DEBUG - 2016-02-27 14:05:09 --> No URI present. Default controller set.
INFO - 2016-02-27 14:05:09 --> Router Class Initialized
INFO - 2016-02-27 14:05:09 --> Output Class Initialized
INFO - 2016-02-27 14:05:09 --> Security Class Initialized
DEBUG - 2016-02-27 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:05:09 --> Input Class Initialized
INFO - 2016-02-27 14:05:09 --> Language Class Initialized
INFO - 2016-02-27 14:05:09 --> Loader Class Initialized
INFO - 2016-02-27 14:05:09 --> Helper loaded: url_helper
INFO - 2016-02-27 14:05:09 --> Helper loaded: file_helper
INFO - 2016-02-27 14:05:09 --> Helper loaded: date_helper
INFO - 2016-02-27 14:05:09 --> Helper loaded: form_helper
INFO - 2016-02-27 14:05:09 --> Database Driver Class Initialized
INFO - 2016-02-27 14:05:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:05:10 --> Controller Class Initialized
INFO - 2016-02-27 14:05:10 --> Model Class Initialized
INFO - 2016-02-27 14:05:10 --> Model Class Initialized
INFO - 2016-02-27 14:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:05:10 --> Pagination Class Initialized
INFO - 2016-02-27 14:05:10 --> Helper loaded: text_helper
INFO - 2016-02-27 14:05:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:05:10 --> Final output sent to browser
DEBUG - 2016-02-27 17:05:10 --> Total execution time: 1.0992
INFO - 2016-02-27 14:09:17 --> Config Class Initialized
INFO - 2016-02-27 14:09:17 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:09:17 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:09:17 --> Utf8 Class Initialized
INFO - 2016-02-27 14:09:17 --> URI Class Initialized
INFO - 2016-02-27 14:09:17 --> Router Class Initialized
INFO - 2016-02-27 14:09:17 --> Output Class Initialized
INFO - 2016-02-27 14:09:17 --> Security Class Initialized
DEBUG - 2016-02-27 14:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:09:18 --> Input Class Initialized
INFO - 2016-02-27 14:09:18 --> Language Class Initialized
INFO - 2016-02-27 14:09:18 --> Loader Class Initialized
INFO - 2016-02-27 14:09:18 --> Helper loaded: url_helper
INFO - 2016-02-27 14:09:18 --> Helper loaded: file_helper
INFO - 2016-02-27 14:09:18 --> Helper loaded: date_helper
INFO - 2016-02-27 14:09:18 --> Helper loaded: form_helper
INFO - 2016-02-27 14:09:18 --> Database Driver Class Initialized
INFO - 2016-02-27 14:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:09:19 --> Controller Class Initialized
INFO - 2016-02-27 14:09:19 --> Model Class Initialized
INFO - 2016-02-27 14:09:19 --> Model Class Initialized
INFO - 2016-02-27 14:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:09:19 --> Pagination Class Initialized
INFO - 2016-02-27 14:09:19 --> Helper loaded: text_helper
INFO - 2016-02-27 14:09:19 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:09:19 --> Final output sent to browser
DEBUG - 2016-02-27 17:09:19 --> Total execution time: 1.1599
INFO - 2016-02-27 14:10:10 --> Config Class Initialized
INFO - 2016-02-27 14:10:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:10:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:10:11 --> Utf8 Class Initialized
INFO - 2016-02-27 14:10:11 --> URI Class Initialized
INFO - 2016-02-27 14:10:11 --> Router Class Initialized
INFO - 2016-02-27 14:10:11 --> Output Class Initialized
INFO - 2016-02-27 14:10:11 --> Security Class Initialized
DEBUG - 2016-02-27 14:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:10:11 --> Input Class Initialized
INFO - 2016-02-27 14:10:11 --> Language Class Initialized
INFO - 2016-02-27 14:10:11 --> Loader Class Initialized
INFO - 2016-02-27 14:10:11 --> Helper loaded: url_helper
INFO - 2016-02-27 14:10:11 --> Helper loaded: file_helper
INFO - 2016-02-27 14:10:11 --> Helper loaded: date_helper
INFO - 2016-02-27 14:10:11 --> Helper loaded: form_helper
INFO - 2016-02-27 14:10:11 --> Database Driver Class Initialized
INFO - 2016-02-27 14:10:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:10:12 --> Controller Class Initialized
INFO - 2016-02-27 14:10:12 --> Model Class Initialized
INFO - 2016-02-27 14:10:12 --> Model Class Initialized
INFO - 2016-02-27 14:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:10:12 --> Pagination Class Initialized
INFO - 2016-02-27 14:10:12 --> Helper loaded: text_helper
INFO - 2016-02-27 14:10:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 17:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 17:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:10:12 --> Final output sent to browser
DEBUG - 2016-02-27 17:10:12 --> Total execution time: 1.3346
INFO - 2016-02-27 14:12:04 --> Config Class Initialized
INFO - 2016-02-27 14:12:04 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:12:04 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:12:04 --> Utf8 Class Initialized
INFO - 2016-02-27 14:12:04 --> URI Class Initialized
INFO - 2016-02-27 14:12:04 --> Router Class Initialized
INFO - 2016-02-27 14:12:04 --> Output Class Initialized
INFO - 2016-02-27 14:12:04 --> Security Class Initialized
DEBUG - 2016-02-27 14:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:12:04 --> Input Class Initialized
INFO - 2016-02-27 14:12:04 --> Language Class Initialized
INFO - 2016-02-27 14:12:04 --> Loader Class Initialized
INFO - 2016-02-27 14:12:04 --> Helper loaded: url_helper
INFO - 2016-02-27 14:12:04 --> Helper loaded: file_helper
INFO - 2016-02-27 14:12:04 --> Helper loaded: date_helper
INFO - 2016-02-27 14:12:04 --> Helper loaded: form_helper
INFO - 2016-02-27 14:12:04 --> Database Driver Class Initialized
INFO - 2016-02-27 14:12:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:12:05 --> Controller Class Initialized
INFO - 2016-02-27 14:12:05 --> Model Class Initialized
INFO - 2016-02-27 14:12:05 --> Model Class Initialized
INFO - 2016-02-27 14:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:12:05 --> Pagination Class Initialized
INFO - 2016-02-27 14:12:05 --> Helper loaded: text_helper
INFO - 2016-02-27 14:12:05 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:12:05 --> Final output sent to browser
DEBUG - 2016-02-27 17:12:05 --> Total execution time: 1.1427
INFO - 2016-02-27 14:12:17 --> Config Class Initialized
INFO - 2016-02-27 14:12:17 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:12:17 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:12:17 --> Utf8 Class Initialized
INFO - 2016-02-27 14:12:17 --> URI Class Initialized
INFO - 2016-02-27 14:12:17 --> Router Class Initialized
INFO - 2016-02-27 14:12:17 --> Output Class Initialized
INFO - 2016-02-27 14:12:17 --> Security Class Initialized
DEBUG - 2016-02-27 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:12:17 --> Input Class Initialized
INFO - 2016-02-27 14:12:17 --> Language Class Initialized
INFO - 2016-02-27 14:12:17 --> Loader Class Initialized
INFO - 2016-02-27 14:12:17 --> Helper loaded: url_helper
INFO - 2016-02-27 14:12:17 --> Helper loaded: file_helper
INFO - 2016-02-27 14:12:17 --> Helper loaded: date_helper
INFO - 2016-02-27 14:12:17 --> Helper loaded: form_helper
INFO - 2016-02-27 14:12:17 --> Database Driver Class Initialized
INFO - 2016-02-27 14:12:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:12:18 --> Controller Class Initialized
INFO - 2016-02-27 14:12:18 --> Model Class Initialized
INFO - 2016-02-27 14:12:18 --> Model Class Initialized
INFO - 2016-02-27 14:12:18 --> Form Validation Class Initialized
INFO - 2016-02-27 14:12:18 --> Helper loaded: text_helper
INFO - 2016-02-27 14:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:12:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:12:18 --> Model Class Initialized
ERROR - 2016-02-27 14:12:18 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php on line 37 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-27 14:12:18 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-27 14:12:18 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-27 14:12:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-27 14:12:19 --> Config Class Initialized
INFO - 2016-02-27 14:12:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:12:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:12:19 --> Utf8 Class Initialized
INFO - 2016-02-27 14:12:19 --> URI Class Initialized
INFO - 2016-02-27 14:12:19 --> Router Class Initialized
INFO - 2016-02-27 14:12:19 --> Output Class Initialized
INFO - 2016-02-27 14:12:19 --> Security Class Initialized
DEBUG - 2016-02-27 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:12:19 --> Input Class Initialized
INFO - 2016-02-27 14:12:19 --> Language Class Initialized
INFO - 2016-02-27 14:12:19 --> Loader Class Initialized
INFO - 2016-02-27 14:12:19 --> Helper loaded: url_helper
INFO - 2016-02-27 14:12:19 --> Helper loaded: file_helper
INFO - 2016-02-27 14:12:19 --> Helper loaded: date_helper
INFO - 2016-02-27 14:12:19 --> Helper loaded: form_helper
INFO - 2016-02-27 14:12:19 --> Database Driver Class Initialized
INFO - 2016-02-27 14:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:12:20 --> Controller Class Initialized
INFO - 2016-02-27 14:12:20 --> Model Class Initialized
INFO - 2016-02-27 14:12:20 --> Model Class Initialized
INFO - 2016-02-27 14:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:12:20 --> Pagination Class Initialized
INFO - 2016-02-27 14:12:20 --> Helper loaded: text_helper
INFO - 2016-02-27 14:12:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:12:20 --> Final output sent to browser
DEBUG - 2016-02-27 17:12:20 --> Total execution time: 1.1346
INFO - 2016-02-27 14:12:32 --> Config Class Initialized
INFO - 2016-02-27 14:12:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:12:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:12:32 --> Utf8 Class Initialized
INFO - 2016-02-27 14:12:32 --> URI Class Initialized
INFO - 2016-02-27 14:12:32 --> Router Class Initialized
INFO - 2016-02-27 14:12:32 --> Output Class Initialized
INFO - 2016-02-27 14:12:32 --> Security Class Initialized
DEBUG - 2016-02-27 14:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:12:32 --> Input Class Initialized
INFO - 2016-02-27 14:12:32 --> Language Class Initialized
INFO - 2016-02-27 14:12:32 --> Loader Class Initialized
INFO - 2016-02-27 14:12:32 --> Helper loaded: url_helper
INFO - 2016-02-27 14:12:32 --> Helper loaded: file_helper
INFO - 2016-02-27 14:12:32 --> Helper loaded: date_helper
INFO - 2016-02-27 14:12:32 --> Helper loaded: form_helper
INFO - 2016-02-27 14:12:32 --> Database Driver Class Initialized
INFO - 2016-02-27 14:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:12:33 --> Controller Class Initialized
INFO - 2016-02-27 14:12:33 --> Model Class Initialized
INFO - 2016-02-27 14:12:33 --> Model Class Initialized
INFO - 2016-02-27 14:12:33 --> Form Validation Class Initialized
INFO - 2016-02-27 14:12:33 --> Helper loaded: text_helper
INFO - 2016-02-27 14:12:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:12:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:12:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:12:33 --> Model Class Initialized
ERROR - 2016-02-27 14:12:33 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php on line 37 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-27 14:12:33 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-27 14:12:33 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-27 14:12:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-27 14:12:34 --> Config Class Initialized
INFO - 2016-02-27 14:12:34 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:12:34 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:12:34 --> Utf8 Class Initialized
INFO - 2016-02-27 14:12:34 --> URI Class Initialized
INFO - 2016-02-27 14:12:34 --> Router Class Initialized
INFO - 2016-02-27 14:12:34 --> Output Class Initialized
INFO - 2016-02-27 14:12:34 --> Security Class Initialized
DEBUG - 2016-02-27 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:12:34 --> Input Class Initialized
INFO - 2016-02-27 14:12:34 --> Language Class Initialized
INFO - 2016-02-27 14:12:34 --> Loader Class Initialized
INFO - 2016-02-27 14:12:34 --> Helper loaded: url_helper
INFO - 2016-02-27 14:12:34 --> Helper loaded: file_helper
INFO - 2016-02-27 14:12:34 --> Helper loaded: date_helper
INFO - 2016-02-27 14:12:34 --> Helper loaded: form_helper
INFO - 2016-02-27 14:12:34 --> Database Driver Class Initialized
INFO - 2016-02-27 14:12:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:12:35 --> Controller Class Initialized
INFO - 2016-02-27 14:12:35 --> Model Class Initialized
INFO - 2016-02-27 14:12:35 --> Model Class Initialized
INFO - 2016-02-27 14:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:12:35 --> Pagination Class Initialized
INFO - 2016-02-27 14:12:35 --> Helper loaded: text_helper
INFO - 2016-02-27 14:12:35 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:12:35 --> Final output sent to browser
DEBUG - 2016-02-27 17:12:35 --> Total execution time: 1.1081
INFO - 2016-02-27 14:16:26 --> Config Class Initialized
INFO - 2016-02-27 14:16:26 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:16:26 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:16:26 --> Utf8 Class Initialized
INFO - 2016-02-27 14:16:26 --> URI Class Initialized
INFO - 2016-02-27 14:16:26 --> Router Class Initialized
INFO - 2016-02-27 14:16:26 --> Output Class Initialized
INFO - 2016-02-27 14:16:26 --> Security Class Initialized
DEBUG - 2016-02-27 14:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:16:26 --> Input Class Initialized
INFO - 2016-02-27 14:16:26 --> Language Class Initialized
INFO - 2016-02-27 14:16:26 --> Loader Class Initialized
INFO - 2016-02-27 14:16:26 --> Helper loaded: url_helper
INFO - 2016-02-27 14:16:26 --> Helper loaded: file_helper
INFO - 2016-02-27 14:16:26 --> Helper loaded: date_helper
INFO - 2016-02-27 14:16:26 --> Helper loaded: form_helper
INFO - 2016-02-27 14:16:26 --> Database Driver Class Initialized
INFO - 2016-02-27 14:16:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:16:27 --> Controller Class Initialized
INFO - 2016-02-27 14:16:27 --> Model Class Initialized
INFO - 2016-02-27 14:16:27 --> Model Class Initialized
INFO - 2016-02-27 14:16:27 --> Form Validation Class Initialized
INFO - 2016-02-27 14:16:27 --> Helper loaded: text_helper
INFO - 2016-02-27 14:16:27 --> Config Class Initialized
INFO - 2016-02-27 14:16:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:16:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:16:27 --> Utf8 Class Initialized
INFO - 2016-02-27 14:16:27 --> URI Class Initialized
INFO - 2016-02-27 14:16:27 --> Router Class Initialized
INFO - 2016-02-27 14:16:27 --> Output Class Initialized
INFO - 2016-02-27 14:16:27 --> Security Class Initialized
DEBUG - 2016-02-27 14:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:16:27 --> Input Class Initialized
INFO - 2016-02-27 14:16:27 --> Language Class Initialized
INFO - 2016-02-27 14:16:27 --> Loader Class Initialized
INFO - 2016-02-27 14:16:27 --> Helper loaded: url_helper
INFO - 2016-02-27 14:16:27 --> Helper loaded: file_helper
INFO - 2016-02-27 14:16:27 --> Helper loaded: date_helper
INFO - 2016-02-27 14:16:27 --> Helper loaded: form_helper
INFO - 2016-02-27 14:16:27 --> Database Driver Class Initialized
INFO - 2016-02-27 14:16:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:16:28 --> Controller Class Initialized
INFO - 2016-02-27 14:16:28 --> Model Class Initialized
INFO - 2016-02-27 14:16:28 --> Model Class Initialized
INFO - 2016-02-27 14:16:28 --> Form Validation Class Initialized
INFO - 2016-02-27 14:16:28 --> Helper loaded: text_helper
INFO - 2016-02-27 14:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 14:16:28 --> Final output sent to browser
DEBUG - 2016-02-27 14:16:28 --> Total execution time: 1.1452
INFO - 2016-02-27 14:20:12 --> Config Class Initialized
INFO - 2016-02-27 14:20:12 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:20:12 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:20:12 --> Utf8 Class Initialized
INFO - 2016-02-27 14:20:12 --> URI Class Initialized
INFO - 2016-02-27 14:20:12 --> Router Class Initialized
INFO - 2016-02-27 14:20:12 --> Output Class Initialized
INFO - 2016-02-27 14:20:12 --> Security Class Initialized
DEBUG - 2016-02-27 14:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:20:12 --> Input Class Initialized
INFO - 2016-02-27 14:20:12 --> Language Class Initialized
INFO - 2016-02-27 14:20:12 --> Loader Class Initialized
INFO - 2016-02-27 14:20:12 --> Helper loaded: url_helper
INFO - 2016-02-27 14:20:12 --> Helper loaded: file_helper
INFO - 2016-02-27 14:20:12 --> Helper loaded: date_helper
INFO - 2016-02-27 14:20:12 --> Helper loaded: form_helper
INFO - 2016-02-27 14:20:12 --> Database Driver Class Initialized
INFO - 2016-02-27 14:20:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:20:13 --> Controller Class Initialized
INFO - 2016-02-27 14:20:13 --> Model Class Initialized
INFO - 2016-02-27 14:20:13 --> Model Class Initialized
INFO - 2016-02-27 14:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:20:13 --> Pagination Class Initialized
INFO - 2016-02-27 14:20:13 --> Helper loaded: text_helper
INFO - 2016-02-27 14:20:13 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:20:13 --> Final output sent to browser
DEBUG - 2016-02-27 17:20:13 --> Total execution time: 1.1543
INFO - 2016-02-27 14:20:14 --> Config Class Initialized
INFO - 2016-02-27 14:20:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:20:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:20:14 --> Utf8 Class Initialized
INFO - 2016-02-27 14:20:14 --> URI Class Initialized
INFO - 2016-02-27 14:20:14 --> Router Class Initialized
INFO - 2016-02-27 14:20:14 --> Output Class Initialized
INFO - 2016-02-27 14:20:14 --> Security Class Initialized
DEBUG - 2016-02-27 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:20:14 --> Input Class Initialized
INFO - 2016-02-27 14:20:14 --> Language Class Initialized
INFO - 2016-02-27 14:20:14 --> Loader Class Initialized
INFO - 2016-02-27 14:20:14 --> Helper loaded: url_helper
INFO - 2016-02-27 14:20:14 --> Helper loaded: file_helper
INFO - 2016-02-27 14:20:14 --> Helper loaded: date_helper
INFO - 2016-02-27 14:20:14 --> Helper loaded: form_helper
INFO - 2016-02-27 14:20:14 --> Database Driver Class Initialized
INFO - 2016-02-27 14:20:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:20:15 --> Controller Class Initialized
INFO - 2016-02-27 14:20:15 --> Model Class Initialized
INFO - 2016-02-27 14:20:15 --> Model Class Initialized
INFO - 2016-02-27 14:20:15 --> Form Validation Class Initialized
INFO - 2016-02-27 14:20:15 --> Helper loaded: text_helper
INFO - 2016-02-27 14:20:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:20:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 14:20:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:20:15 --> Final output sent to browser
DEBUG - 2016-02-27 14:20:15 --> Total execution time: 1.1472
INFO - 2016-02-27 14:21:02 --> Config Class Initialized
INFO - 2016-02-27 14:21:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:21:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:21:02 --> Utf8 Class Initialized
INFO - 2016-02-27 14:21:02 --> URI Class Initialized
INFO - 2016-02-27 14:21:02 --> Router Class Initialized
INFO - 2016-02-27 14:21:02 --> Output Class Initialized
INFO - 2016-02-27 14:21:02 --> Security Class Initialized
DEBUG - 2016-02-27 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:21:02 --> Input Class Initialized
INFO - 2016-02-27 14:21:02 --> Language Class Initialized
INFO - 2016-02-27 14:21:02 --> Loader Class Initialized
INFO - 2016-02-27 14:21:02 --> Helper loaded: url_helper
INFO - 2016-02-27 14:21:02 --> Helper loaded: file_helper
INFO - 2016-02-27 14:21:02 --> Helper loaded: date_helper
INFO - 2016-02-27 14:21:02 --> Helper loaded: form_helper
INFO - 2016-02-27 14:21:02 --> Database Driver Class Initialized
INFO - 2016-02-27 14:21:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:21:03 --> Controller Class Initialized
INFO - 2016-02-27 14:21:03 --> Model Class Initialized
INFO - 2016-02-27 14:21:03 --> Model Class Initialized
INFO - 2016-02-27 14:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:21:03 --> Pagination Class Initialized
INFO - 2016-02-27 14:21:03 --> Helper loaded: text_helper
INFO - 2016-02-27 14:21:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:21:03 --> Final output sent to browser
DEBUG - 2016-02-27 17:21:03 --> Total execution time: 1.1161
INFO - 2016-02-27 14:21:05 --> Config Class Initialized
INFO - 2016-02-27 14:21:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:21:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:21:05 --> Utf8 Class Initialized
INFO - 2016-02-27 14:21:05 --> URI Class Initialized
INFO - 2016-02-27 14:21:05 --> Router Class Initialized
INFO - 2016-02-27 14:21:05 --> Output Class Initialized
INFO - 2016-02-27 14:21:05 --> Security Class Initialized
DEBUG - 2016-02-27 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:21:05 --> Input Class Initialized
INFO - 2016-02-27 14:21:05 --> Language Class Initialized
INFO - 2016-02-27 14:21:05 --> Loader Class Initialized
INFO - 2016-02-27 14:21:05 --> Helper loaded: url_helper
INFO - 2016-02-27 14:21:05 --> Helper loaded: file_helper
INFO - 2016-02-27 14:21:05 --> Helper loaded: date_helper
INFO - 2016-02-27 14:21:05 --> Helper loaded: form_helper
INFO - 2016-02-27 14:21:05 --> Database Driver Class Initialized
INFO - 2016-02-27 14:21:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:21:06 --> Controller Class Initialized
INFO - 2016-02-27 14:21:06 --> Model Class Initialized
INFO - 2016-02-27 14:21:06 --> Model Class Initialized
INFO - 2016-02-27 14:21:06 --> Form Validation Class Initialized
INFO - 2016-02-27 14:21:06 --> Helper loaded: text_helper
INFO - 2016-02-27 14:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:21:06 --> Final output sent to browser
DEBUG - 2016-02-27 14:21:06 --> Total execution time: 1.1098
INFO - 2016-02-27 14:21:55 --> Config Class Initialized
INFO - 2016-02-27 14:21:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:21:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:21:55 --> Utf8 Class Initialized
INFO - 2016-02-27 14:21:55 --> URI Class Initialized
INFO - 2016-02-27 14:21:55 --> Router Class Initialized
INFO - 2016-02-27 14:21:55 --> Output Class Initialized
INFO - 2016-02-27 14:21:55 --> Security Class Initialized
DEBUG - 2016-02-27 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:21:55 --> Input Class Initialized
INFO - 2016-02-27 14:21:55 --> Language Class Initialized
INFO - 2016-02-27 14:21:55 --> Loader Class Initialized
INFO - 2016-02-27 14:21:55 --> Helper loaded: url_helper
INFO - 2016-02-27 14:21:55 --> Helper loaded: file_helper
INFO - 2016-02-27 14:21:55 --> Helper loaded: date_helper
INFO - 2016-02-27 14:21:55 --> Helper loaded: form_helper
INFO - 2016-02-27 14:21:55 --> Database Driver Class Initialized
INFO - 2016-02-27 14:21:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:21:56 --> Controller Class Initialized
INFO - 2016-02-27 14:21:56 --> Model Class Initialized
INFO - 2016-02-27 14:21:56 --> Model Class Initialized
INFO - 2016-02-27 14:21:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:21:56 --> Pagination Class Initialized
INFO - 2016-02-27 14:21:56 --> Helper loaded: text_helper
INFO - 2016-02-27 14:21:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:21:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:21:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:21:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:21:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:21:56 --> Final output sent to browser
DEBUG - 2016-02-27 17:21:56 --> Total execution time: 1.1524
INFO - 2016-02-27 14:21:58 --> Config Class Initialized
INFO - 2016-02-27 14:21:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:21:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:21:58 --> Utf8 Class Initialized
INFO - 2016-02-27 14:21:58 --> URI Class Initialized
INFO - 2016-02-27 14:21:58 --> Router Class Initialized
INFO - 2016-02-27 14:21:58 --> Output Class Initialized
INFO - 2016-02-27 14:21:58 --> Security Class Initialized
DEBUG - 2016-02-27 14:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:21:58 --> Input Class Initialized
INFO - 2016-02-27 14:21:58 --> Language Class Initialized
INFO - 2016-02-27 14:21:58 --> Loader Class Initialized
INFO - 2016-02-27 14:21:58 --> Helper loaded: url_helper
INFO - 2016-02-27 14:21:58 --> Helper loaded: file_helper
INFO - 2016-02-27 14:21:58 --> Helper loaded: date_helper
INFO - 2016-02-27 14:21:58 --> Helper loaded: form_helper
INFO - 2016-02-27 14:21:58 --> Database Driver Class Initialized
INFO - 2016-02-27 14:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:21:59 --> Controller Class Initialized
INFO - 2016-02-27 14:21:59 --> Model Class Initialized
INFO - 2016-02-27 14:21:59 --> Model Class Initialized
INFO - 2016-02-27 14:21:59 --> Form Validation Class Initialized
INFO - 2016-02-27 14:21:59 --> Helper loaded: text_helper
INFO - 2016-02-27 14:21:59 --> Config Class Initialized
INFO - 2016-02-27 14:21:59 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:21:59 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:21:59 --> Utf8 Class Initialized
INFO - 2016-02-27 14:21:59 --> URI Class Initialized
INFO - 2016-02-27 14:21:59 --> Router Class Initialized
INFO - 2016-02-27 14:21:59 --> Output Class Initialized
INFO - 2016-02-27 14:21:59 --> Security Class Initialized
DEBUG - 2016-02-27 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:21:59 --> Input Class Initialized
INFO - 2016-02-27 14:21:59 --> Language Class Initialized
INFO - 2016-02-27 14:21:59 --> Loader Class Initialized
INFO - 2016-02-27 14:21:59 --> Helper loaded: url_helper
INFO - 2016-02-27 14:21:59 --> Helper loaded: file_helper
INFO - 2016-02-27 14:21:59 --> Helper loaded: date_helper
INFO - 2016-02-27 14:21:59 --> Helper loaded: form_helper
INFO - 2016-02-27 14:21:59 --> Database Driver Class Initialized
INFO - 2016-02-27 14:22:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:22:00 --> Controller Class Initialized
INFO - 2016-02-27 14:22:00 --> Model Class Initialized
INFO - 2016-02-27 14:22:00 --> Model Class Initialized
INFO - 2016-02-27 14:22:00 --> Form Validation Class Initialized
INFO - 2016-02-27 14:22:01 --> Helper loaded: text_helper
INFO - 2016-02-27 14:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 14:22:01 --> Final output sent to browser
DEBUG - 2016-02-27 14:22:01 --> Total execution time: 1.1613
INFO - 2016-02-27 14:23:14 --> Config Class Initialized
INFO - 2016-02-27 14:23:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:23:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:23:14 --> Utf8 Class Initialized
INFO - 2016-02-27 14:23:14 --> URI Class Initialized
INFO - 2016-02-27 14:23:14 --> Router Class Initialized
INFO - 2016-02-27 14:23:14 --> Output Class Initialized
INFO - 2016-02-27 14:23:14 --> Security Class Initialized
DEBUG - 2016-02-27 14:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:23:14 --> Input Class Initialized
INFO - 2016-02-27 14:23:14 --> Language Class Initialized
INFO - 2016-02-27 14:23:14 --> Loader Class Initialized
INFO - 2016-02-27 14:23:14 --> Helper loaded: url_helper
INFO - 2016-02-27 14:23:14 --> Helper loaded: file_helper
INFO - 2016-02-27 14:23:14 --> Helper loaded: date_helper
INFO - 2016-02-27 14:23:14 --> Helper loaded: form_helper
INFO - 2016-02-27 14:23:14 --> Database Driver Class Initialized
INFO - 2016-02-27 14:23:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:23:15 --> Controller Class Initialized
INFO - 2016-02-27 14:23:15 --> Model Class Initialized
INFO - 2016-02-27 14:23:15 --> Model Class Initialized
INFO - 2016-02-27 14:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:23:15 --> Pagination Class Initialized
INFO - 2016-02-27 14:23:15 --> Helper loaded: text_helper
INFO - 2016-02-27 14:23:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:23:15 --> Final output sent to browser
DEBUG - 2016-02-27 17:23:15 --> Total execution time: 1.1840
INFO - 2016-02-27 14:23:16 --> Config Class Initialized
INFO - 2016-02-27 14:23:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:23:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:23:16 --> Utf8 Class Initialized
INFO - 2016-02-27 14:23:16 --> URI Class Initialized
INFO - 2016-02-27 14:23:16 --> Router Class Initialized
INFO - 2016-02-27 14:23:16 --> Output Class Initialized
INFO - 2016-02-27 14:23:16 --> Security Class Initialized
DEBUG - 2016-02-27 14:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:23:16 --> Input Class Initialized
INFO - 2016-02-27 14:23:16 --> Language Class Initialized
INFO - 2016-02-27 14:23:16 --> Loader Class Initialized
INFO - 2016-02-27 14:23:16 --> Helper loaded: url_helper
INFO - 2016-02-27 14:23:16 --> Helper loaded: file_helper
INFO - 2016-02-27 14:23:16 --> Helper loaded: date_helper
INFO - 2016-02-27 14:23:16 --> Helper loaded: form_helper
INFO - 2016-02-27 14:23:16 --> Database Driver Class Initialized
INFO - 2016-02-27 14:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:23:17 --> Controller Class Initialized
INFO - 2016-02-27 14:23:17 --> Model Class Initialized
INFO - 2016-02-27 14:23:17 --> Model Class Initialized
INFO - 2016-02-27 14:23:17 --> Form Validation Class Initialized
INFO - 2016-02-27 14:23:17 --> Helper loaded: text_helper
INFO - 2016-02-27 14:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 14:23:17 --> Final output sent to browser
DEBUG - 2016-02-27 14:23:17 --> Total execution time: 1.1410
INFO - 2016-02-27 14:23:27 --> Config Class Initialized
INFO - 2016-02-27 14:23:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:23:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:23:27 --> Utf8 Class Initialized
INFO - 2016-02-27 14:23:27 --> URI Class Initialized
INFO - 2016-02-27 14:23:27 --> Router Class Initialized
INFO - 2016-02-27 14:23:27 --> Output Class Initialized
INFO - 2016-02-27 14:23:28 --> Security Class Initialized
DEBUG - 2016-02-27 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:23:28 --> Input Class Initialized
INFO - 2016-02-27 14:23:28 --> Language Class Initialized
INFO - 2016-02-27 14:23:28 --> Loader Class Initialized
INFO - 2016-02-27 14:23:28 --> Helper loaded: url_helper
INFO - 2016-02-27 14:23:28 --> Helper loaded: file_helper
INFO - 2016-02-27 14:23:28 --> Helper loaded: date_helper
INFO - 2016-02-27 14:23:28 --> Helper loaded: form_helper
INFO - 2016-02-27 14:23:28 --> Database Driver Class Initialized
INFO - 2016-02-27 14:23:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:23:29 --> Controller Class Initialized
INFO - 2016-02-27 14:23:29 --> Model Class Initialized
INFO - 2016-02-27 14:23:29 --> Model Class Initialized
INFO - 2016-02-27 14:23:29 --> Form Validation Class Initialized
INFO - 2016-02-27 14:23:29 --> Helper loaded: text_helper
INFO - 2016-02-27 14:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:23:29 --> Final output sent to browser
DEBUG - 2016-02-27 14:23:29 --> Total execution time: 1.1557
INFO - 2016-02-27 14:23:44 --> Config Class Initialized
INFO - 2016-02-27 14:23:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:23:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:23:44 --> Utf8 Class Initialized
INFO - 2016-02-27 14:23:44 --> URI Class Initialized
INFO - 2016-02-27 14:23:44 --> Router Class Initialized
INFO - 2016-02-27 14:23:44 --> Output Class Initialized
INFO - 2016-02-27 14:23:44 --> Security Class Initialized
DEBUG - 2016-02-27 14:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:23:44 --> Input Class Initialized
INFO - 2016-02-27 14:23:44 --> Language Class Initialized
INFO - 2016-02-27 14:23:44 --> Loader Class Initialized
INFO - 2016-02-27 14:23:44 --> Helper loaded: url_helper
INFO - 2016-02-27 14:23:44 --> Helper loaded: file_helper
INFO - 2016-02-27 14:23:44 --> Helper loaded: date_helper
INFO - 2016-02-27 14:23:44 --> Helper loaded: form_helper
INFO - 2016-02-27 14:23:44 --> Database Driver Class Initialized
INFO - 2016-02-27 14:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:23:45 --> Controller Class Initialized
INFO - 2016-02-27 14:23:45 --> Model Class Initialized
INFO - 2016-02-27 14:23:45 --> Model Class Initialized
INFO - 2016-02-27 14:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:23:45 --> Pagination Class Initialized
INFO - 2016-02-27 14:23:45 --> Helper loaded: text_helper
INFO - 2016-02-27 14:23:45 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:23:45 --> Final output sent to browser
DEBUG - 2016-02-27 17:23:45 --> Total execution time: 1.1629
INFO - 2016-02-27 14:23:56 --> Config Class Initialized
INFO - 2016-02-27 14:23:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:23:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:23:56 --> Utf8 Class Initialized
INFO - 2016-02-27 14:23:56 --> URI Class Initialized
INFO - 2016-02-27 14:23:56 --> Router Class Initialized
INFO - 2016-02-27 14:23:56 --> Output Class Initialized
INFO - 2016-02-27 14:23:56 --> Security Class Initialized
DEBUG - 2016-02-27 14:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:23:56 --> Input Class Initialized
INFO - 2016-02-27 14:23:56 --> Language Class Initialized
INFO - 2016-02-27 14:23:56 --> Loader Class Initialized
INFO - 2016-02-27 14:23:56 --> Helper loaded: url_helper
INFO - 2016-02-27 14:23:56 --> Helper loaded: file_helper
INFO - 2016-02-27 14:23:56 --> Helper loaded: date_helper
INFO - 2016-02-27 14:23:56 --> Helper loaded: form_helper
INFO - 2016-02-27 14:23:56 --> Database Driver Class Initialized
INFO - 2016-02-27 14:23:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:23:57 --> Controller Class Initialized
INFO - 2016-02-27 14:23:57 --> Model Class Initialized
INFO - 2016-02-27 14:23:57 --> Model Class Initialized
INFO - 2016-02-27 14:23:57 --> Form Validation Class Initialized
INFO - 2016-02-27 14:23:57 --> Helper loaded: text_helper
INFO - 2016-02-27 14:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:23:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:23:57 --> Final output sent to browser
DEBUG - 2016-02-27 14:23:57 --> Total execution time: 1.1133
INFO - 2016-02-27 14:25:36 --> Config Class Initialized
INFO - 2016-02-27 14:25:36 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:25:36 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:25:36 --> Utf8 Class Initialized
INFO - 2016-02-27 14:25:36 --> URI Class Initialized
INFO - 2016-02-27 14:25:36 --> Router Class Initialized
INFO - 2016-02-27 14:25:36 --> Output Class Initialized
INFO - 2016-02-27 14:25:36 --> Security Class Initialized
DEBUG - 2016-02-27 14:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:25:36 --> Input Class Initialized
INFO - 2016-02-27 14:25:36 --> Language Class Initialized
INFO - 2016-02-27 14:25:36 --> Loader Class Initialized
INFO - 2016-02-27 14:25:36 --> Helper loaded: url_helper
INFO - 2016-02-27 14:25:36 --> Helper loaded: file_helper
INFO - 2016-02-27 14:25:36 --> Helper loaded: date_helper
INFO - 2016-02-27 14:25:36 --> Helper loaded: form_helper
INFO - 2016-02-27 14:25:36 --> Database Driver Class Initialized
INFO - 2016-02-27 14:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:25:37 --> Controller Class Initialized
INFO - 2016-02-27 14:25:37 --> Model Class Initialized
INFO - 2016-02-27 14:25:37 --> Model Class Initialized
INFO - 2016-02-27 14:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:25:37 --> Pagination Class Initialized
INFO - 2016-02-27 14:25:37 --> Helper loaded: text_helper
INFO - 2016-02-27 14:25:37 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:25:37 --> Final output sent to browser
DEBUG - 2016-02-27 17:25:37 --> Total execution time: 1.1434
INFO - 2016-02-27 14:25:38 --> Config Class Initialized
INFO - 2016-02-27 14:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:25:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:25:38 --> Utf8 Class Initialized
INFO - 2016-02-27 14:25:38 --> URI Class Initialized
INFO - 2016-02-27 14:25:38 --> Router Class Initialized
INFO - 2016-02-27 14:25:38 --> Output Class Initialized
INFO - 2016-02-27 14:25:38 --> Security Class Initialized
DEBUG - 2016-02-27 14:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:25:38 --> Input Class Initialized
INFO - 2016-02-27 14:25:38 --> Language Class Initialized
INFO - 2016-02-27 14:25:38 --> Loader Class Initialized
INFO - 2016-02-27 14:25:38 --> Helper loaded: url_helper
INFO - 2016-02-27 14:25:38 --> Helper loaded: file_helper
INFO - 2016-02-27 14:25:38 --> Helper loaded: date_helper
INFO - 2016-02-27 14:25:38 --> Helper loaded: form_helper
INFO - 2016-02-27 14:25:38 --> Database Driver Class Initialized
INFO - 2016-02-27 14:25:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:25:39 --> Controller Class Initialized
INFO - 2016-02-27 14:25:39 --> Model Class Initialized
INFO - 2016-02-27 14:25:39 --> Model Class Initialized
INFO - 2016-02-27 14:25:39 --> Form Validation Class Initialized
INFO - 2016-02-27 14:25:39 --> Helper loaded: text_helper
INFO - 2016-02-27 14:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:25:39 --> Final output sent to browser
DEBUG - 2016-02-27 14:25:39 --> Total execution time: 1.0986
INFO - 2016-02-27 14:27:31 --> Config Class Initialized
INFO - 2016-02-27 14:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:27:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:27:31 --> Utf8 Class Initialized
INFO - 2016-02-27 14:27:31 --> URI Class Initialized
INFO - 2016-02-27 14:27:31 --> Router Class Initialized
INFO - 2016-02-27 14:27:31 --> Output Class Initialized
INFO - 2016-02-27 14:27:31 --> Security Class Initialized
DEBUG - 2016-02-27 14:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:27:31 --> Input Class Initialized
INFO - 2016-02-27 14:27:31 --> Language Class Initialized
INFO - 2016-02-27 14:27:31 --> Loader Class Initialized
INFO - 2016-02-27 14:27:31 --> Helper loaded: url_helper
INFO - 2016-02-27 14:27:31 --> Helper loaded: file_helper
INFO - 2016-02-27 14:27:31 --> Helper loaded: date_helper
INFO - 2016-02-27 14:27:31 --> Helper loaded: form_helper
INFO - 2016-02-27 14:27:31 --> Database Driver Class Initialized
INFO - 2016-02-27 14:27:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:27:32 --> Controller Class Initialized
INFO - 2016-02-27 14:27:32 --> Model Class Initialized
INFO - 2016-02-27 14:27:32 --> Model Class Initialized
INFO - 2016-02-27 14:27:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:27:32 --> Pagination Class Initialized
INFO - 2016-02-27 14:27:32 --> Helper loaded: text_helper
INFO - 2016-02-27 14:27:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:27:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:27:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:27:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:27:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:27:32 --> Final output sent to browser
DEBUG - 2016-02-27 17:27:32 --> Total execution time: 1.1337
INFO - 2016-02-27 14:27:33 --> Config Class Initialized
INFO - 2016-02-27 14:27:33 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:27:33 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:27:33 --> Utf8 Class Initialized
INFO - 2016-02-27 14:27:33 --> URI Class Initialized
INFO - 2016-02-27 14:27:33 --> Router Class Initialized
INFO - 2016-02-27 14:27:33 --> Output Class Initialized
INFO - 2016-02-27 14:27:33 --> Security Class Initialized
DEBUG - 2016-02-27 14:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:27:33 --> Input Class Initialized
INFO - 2016-02-27 14:27:33 --> Language Class Initialized
INFO - 2016-02-27 14:27:33 --> Loader Class Initialized
INFO - 2016-02-27 14:27:33 --> Helper loaded: url_helper
INFO - 2016-02-27 14:27:33 --> Helper loaded: file_helper
INFO - 2016-02-27 14:27:33 --> Helper loaded: date_helper
INFO - 2016-02-27 14:27:33 --> Helper loaded: form_helper
INFO - 2016-02-27 14:27:33 --> Database Driver Class Initialized
INFO - 2016-02-27 14:27:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:27:34 --> Controller Class Initialized
INFO - 2016-02-27 14:27:34 --> Model Class Initialized
INFO - 2016-02-27 14:27:34 --> Model Class Initialized
INFO - 2016-02-27 14:27:34 --> Form Validation Class Initialized
INFO - 2016-02-27 14:27:34 --> Helper loaded: text_helper
INFO - 2016-02-27 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:27:34 --> Final output sent to browser
DEBUG - 2016-02-27 14:27:34 --> Total execution time: 1.1580
INFO - 2016-02-27 14:28:01 --> Config Class Initialized
INFO - 2016-02-27 14:28:01 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:28:01 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:28:01 --> Utf8 Class Initialized
INFO - 2016-02-27 14:28:01 --> URI Class Initialized
INFO - 2016-02-27 14:28:01 --> Router Class Initialized
INFO - 2016-02-27 14:28:01 --> Output Class Initialized
INFO - 2016-02-27 14:28:01 --> Security Class Initialized
DEBUG - 2016-02-27 14:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:28:01 --> Input Class Initialized
INFO - 2016-02-27 14:28:01 --> Language Class Initialized
INFO - 2016-02-27 14:28:01 --> Loader Class Initialized
INFO - 2016-02-27 14:28:01 --> Helper loaded: url_helper
INFO - 2016-02-27 14:28:01 --> Helper loaded: file_helper
INFO - 2016-02-27 14:28:01 --> Helper loaded: date_helper
INFO - 2016-02-27 14:28:01 --> Helper loaded: form_helper
INFO - 2016-02-27 14:28:01 --> Database Driver Class Initialized
INFO - 2016-02-27 14:28:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:28:02 --> Controller Class Initialized
INFO - 2016-02-27 14:28:02 --> Model Class Initialized
INFO - 2016-02-27 14:28:02 --> Model Class Initialized
INFO - 2016-02-27 14:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:28:02 --> Pagination Class Initialized
INFO - 2016-02-27 14:28:02 --> Helper loaded: text_helper
INFO - 2016-02-27 14:28:02 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:28:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:28:03 --> Final output sent to browser
DEBUG - 2016-02-27 17:28:03 --> Total execution time: 1.1880
INFO - 2016-02-27 14:28:04 --> Config Class Initialized
INFO - 2016-02-27 14:28:04 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:28:04 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:28:04 --> Utf8 Class Initialized
INFO - 2016-02-27 14:28:04 --> URI Class Initialized
INFO - 2016-02-27 14:28:04 --> Router Class Initialized
INFO - 2016-02-27 14:28:04 --> Output Class Initialized
INFO - 2016-02-27 14:28:04 --> Security Class Initialized
DEBUG - 2016-02-27 14:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:28:04 --> Input Class Initialized
INFO - 2016-02-27 14:28:04 --> Language Class Initialized
INFO - 2016-02-27 14:28:04 --> Loader Class Initialized
INFO - 2016-02-27 14:28:04 --> Helper loaded: url_helper
INFO - 2016-02-27 14:28:04 --> Helper loaded: file_helper
INFO - 2016-02-27 14:28:04 --> Helper loaded: date_helper
INFO - 2016-02-27 14:28:04 --> Helper loaded: form_helper
INFO - 2016-02-27 14:28:04 --> Database Driver Class Initialized
INFO - 2016-02-27 14:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:28:05 --> Controller Class Initialized
INFO - 2016-02-27 14:28:05 --> Model Class Initialized
INFO - 2016-02-27 14:28:05 --> Model Class Initialized
INFO - 2016-02-27 14:28:05 --> Form Validation Class Initialized
INFO - 2016-02-27 14:28:05 --> Helper loaded: text_helper
INFO - 2016-02-27 14:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 14:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-27 14:28:05 --> Final output sent to browser
DEBUG - 2016-02-27 14:28:05 --> Total execution time: 1.1329
INFO - 2016-02-27 14:29:13 --> Config Class Initialized
INFO - 2016-02-27 14:29:13 --> Hooks Class Initialized
DEBUG - 2016-02-27 14:29:13 --> UTF-8 Support Enabled
INFO - 2016-02-27 14:29:13 --> Utf8 Class Initialized
INFO - 2016-02-27 14:29:13 --> URI Class Initialized
INFO - 2016-02-27 14:29:13 --> Router Class Initialized
INFO - 2016-02-27 14:29:13 --> Output Class Initialized
INFO - 2016-02-27 14:29:13 --> Security Class Initialized
DEBUG - 2016-02-27 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 14:29:13 --> Input Class Initialized
INFO - 2016-02-27 14:29:13 --> Language Class Initialized
INFO - 2016-02-27 14:29:13 --> Loader Class Initialized
INFO - 2016-02-27 14:29:13 --> Helper loaded: url_helper
INFO - 2016-02-27 14:29:13 --> Helper loaded: file_helper
INFO - 2016-02-27 14:29:13 --> Helper loaded: date_helper
INFO - 2016-02-27 14:29:13 --> Helper loaded: form_helper
INFO - 2016-02-27 14:29:13 --> Database Driver Class Initialized
INFO - 2016-02-27 14:29:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 14:29:14 --> Controller Class Initialized
INFO - 2016-02-27 14:29:15 --> Model Class Initialized
INFO - 2016-02-27 14:29:15 --> Model Class Initialized
INFO - 2016-02-27 14:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 14:29:15 --> Pagination Class Initialized
INFO - 2016-02-27 14:29:15 --> Helper loaded: text_helper
INFO - 2016-02-27 14:29:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 17:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 17:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 17:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 17:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 17:29:15 --> Final output sent to browser
DEBUG - 2016-02-27 17:29:15 --> Total execution time: 1.1685
INFO - 2016-02-27 19:02:06 --> Config Class Initialized
INFO - 2016-02-27 19:02:06 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:02:06 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:02:06 --> Utf8 Class Initialized
INFO - 2016-02-27 19:02:06 --> URI Class Initialized
DEBUG - 2016-02-27 19:02:06 --> No URI present. Default controller set.
INFO - 2016-02-27 19:02:06 --> Router Class Initialized
INFO - 2016-02-27 19:02:06 --> Output Class Initialized
INFO - 2016-02-27 19:02:06 --> Security Class Initialized
DEBUG - 2016-02-27 19:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:02:06 --> Input Class Initialized
INFO - 2016-02-27 19:02:06 --> Language Class Initialized
INFO - 2016-02-27 19:02:06 --> Loader Class Initialized
INFO - 2016-02-27 19:02:06 --> Helper loaded: url_helper
INFO - 2016-02-27 19:02:06 --> Helper loaded: file_helper
INFO - 2016-02-27 19:02:06 --> Helper loaded: date_helper
INFO - 2016-02-27 19:02:06 --> Helper loaded: form_helper
INFO - 2016-02-27 19:02:06 --> Database Driver Class Initialized
INFO - 2016-02-27 19:02:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:02:07 --> Controller Class Initialized
INFO - 2016-02-27 19:02:07 --> Model Class Initialized
INFO - 2016-02-27 19:02:07 --> Model Class Initialized
INFO - 2016-02-27 19:02:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:02:07 --> Pagination Class Initialized
INFO - 2016-02-27 19:02:07 --> Helper loaded: text_helper
INFO - 2016-02-27 19:02:07 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:02:07 --> Final output sent to browser
DEBUG - 2016-02-27 22:02:07 --> Total execution time: 1.1767
INFO - 2016-02-27 19:02:11 --> Config Class Initialized
INFO - 2016-02-27 19:02:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:02:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:02:11 --> Utf8 Class Initialized
INFO - 2016-02-27 19:02:11 --> URI Class Initialized
INFO - 2016-02-27 19:02:11 --> Router Class Initialized
INFO - 2016-02-27 19:02:11 --> Output Class Initialized
INFO - 2016-02-27 19:02:11 --> Security Class Initialized
DEBUG - 2016-02-27 19:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:02:11 --> Input Class Initialized
INFO - 2016-02-27 19:02:11 --> Language Class Initialized
INFO - 2016-02-27 19:02:11 --> Loader Class Initialized
INFO - 2016-02-27 19:02:11 --> Helper loaded: url_helper
INFO - 2016-02-27 19:02:11 --> Helper loaded: file_helper
INFO - 2016-02-27 19:02:11 --> Helper loaded: date_helper
INFO - 2016-02-27 19:02:11 --> Helper loaded: form_helper
INFO - 2016-02-27 19:02:11 --> Database Driver Class Initialized
INFO - 2016-02-27 19:02:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:02:12 --> Controller Class Initialized
INFO - 2016-02-27 19:02:12 --> Model Class Initialized
INFO - 2016-02-27 19:02:12 --> Model Class Initialized
INFO - 2016-02-27 19:02:12 --> Form Validation Class Initialized
INFO - 2016-02-27 19:02:12 --> Helper loaded: text_helper
INFO - 2016-02-27 19:02:12 --> Config Class Initialized
INFO - 2016-02-27 19:02:12 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:02:12 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:02:12 --> Utf8 Class Initialized
INFO - 2016-02-27 19:02:12 --> URI Class Initialized
INFO - 2016-02-27 19:02:12 --> Router Class Initialized
INFO - 2016-02-27 19:02:12 --> Output Class Initialized
INFO - 2016-02-27 19:02:12 --> Security Class Initialized
DEBUG - 2016-02-27 19:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:02:13 --> Input Class Initialized
INFO - 2016-02-27 19:02:13 --> Language Class Initialized
INFO - 2016-02-27 19:02:13 --> Loader Class Initialized
INFO - 2016-02-27 19:02:13 --> Helper loaded: url_helper
INFO - 2016-02-27 19:02:13 --> Helper loaded: file_helper
INFO - 2016-02-27 19:02:13 --> Helper loaded: date_helper
INFO - 2016-02-27 19:02:13 --> Helper loaded: form_helper
INFO - 2016-02-27 19:02:13 --> Database Driver Class Initialized
INFO - 2016-02-27 19:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:02:14 --> Controller Class Initialized
INFO - 2016-02-27 19:02:14 --> Model Class Initialized
INFO - 2016-02-27 19:02:14 --> Model Class Initialized
INFO - 2016-02-27 19:02:14 --> Form Validation Class Initialized
INFO - 2016-02-27 19:02:14 --> Helper loaded: text_helper
INFO - 2016-02-27 19:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 19:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 19:02:14 --> Final output sent to browser
DEBUG - 2016-02-27 19:02:14 --> Total execution time: 1.1430
INFO - 2016-02-27 19:02:24 --> Config Class Initialized
INFO - 2016-02-27 19:02:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:02:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:02:24 --> Utf8 Class Initialized
INFO - 2016-02-27 19:02:24 --> URI Class Initialized
DEBUG - 2016-02-27 19:02:24 --> No URI present. Default controller set.
INFO - 2016-02-27 19:02:24 --> Router Class Initialized
INFO - 2016-02-27 19:02:24 --> Output Class Initialized
INFO - 2016-02-27 19:02:24 --> Security Class Initialized
DEBUG - 2016-02-27 19:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:02:24 --> Input Class Initialized
INFO - 2016-02-27 19:02:24 --> Language Class Initialized
INFO - 2016-02-27 19:02:24 --> Loader Class Initialized
INFO - 2016-02-27 19:02:24 --> Helper loaded: url_helper
INFO - 2016-02-27 19:02:24 --> Helper loaded: file_helper
INFO - 2016-02-27 19:02:24 --> Helper loaded: date_helper
INFO - 2016-02-27 19:02:24 --> Helper loaded: form_helper
INFO - 2016-02-27 19:02:24 --> Database Driver Class Initialized
INFO - 2016-02-27 19:02:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:02:25 --> Controller Class Initialized
INFO - 2016-02-27 19:02:25 --> Model Class Initialized
INFO - 2016-02-27 19:02:25 --> Model Class Initialized
INFO - 2016-02-27 19:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:02:25 --> Pagination Class Initialized
INFO - 2016-02-27 19:02:25 --> Helper loaded: text_helper
INFO - 2016-02-27 19:02:25 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:02:25 --> Final output sent to browser
DEBUG - 2016-02-27 22:02:25 --> Total execution time: 1.1145
INFO - 2016-02-27 19:03:15 --> Config Class Initialized
INFO - 2016-02-27 19:03:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:03:15 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:03:15 --> Utf8 Class Initialized
INFO - 2016-02-27 19:03:15 --> URI Class Initialized
INFO - 2016-02-27 19:03:15 --> Router Class Initialized
INFO - 2016-02-27 19:03:15 --> Output Class Initialized
INFO - 2016-02-27 19:03:15 --> Security Class Initialized
DEBUG - 2016-02-27 19:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:03:15 --> Input Class Initialized
INFO - 2016-02-27 19:03:15 --> Language Class Initialized
INFO - 2016-02-27 19:03:15 --> Loader Class Initialized
INFO - 2016-02-27 19:03:15 --> Helper loaded: url_helper
INFO - 2016-02-27 19:03:15 --> Helper loaded: file_helper
INFO - 2016-02-27 19:03:15 --> Helper loaded: date_helper
INFO - 2016-02-27 19:03:15 --> Helper loaded: form_helper
INFO - 2016-02-27 19:03:15 --> Database Driver Class Initialized
INFO - 2016-02-27 19:03:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:03:16 --> Controller Class Initialized
INFO - 2016-02-27 19:03:16 --> Model Class Initialized
INFO - 2016-02-27 19:03:16 --> Model Class Initialized
INFO - 2016-02-27 19:03:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:03:16 --> Pagination Class Initialized
INFO - 2016-02-27 19:03:16 --> Helper loaded: text_helper
INFO - 2016-02-27 19:03:16 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:03:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:03:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:03:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:03:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:03:16 --> Final output sent to browser
DEBUG - 2016-02-27 22:03:16 --> Total execution time: 1.3071
INFO - 2016-02-27 19:04:39 --> Config Class Initialized
INFO - 2016-02-27 19:04:39 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:04:39 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:04:39 --> Utf8 Class Initialized
INFO - 2016-02-27 19:04:39 --> URI Class Initialized
INFO - 2016-02-27 19:04:39 --> Router Class Initialized
INFO - 2016-02-27 19:04:39 --> Output Class Initialized
INFO - 2016-02-27 19:04:39 --> Security Class Initialized
DEBUG - 2016-02-27 19:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:04:39 --> Input Class Initialized
INFO - 2016-02-27 19:04:39 --> Language Class Initialized
INFO - 2016-02-27 19:04:39 --> Loader Class Initialized
INFO - 2016-02-27 19:04:39 --> Helper loaded: url_helper
INFO - 2016-02-27 19:04:39 --> Helper loaded: file_helper
INFO - 2016-02-27 19:04:39 --> Helper loaded: date_helper
INFO - 2016-02-27 19:04:39 --> Helper loaded: form_helper
INFO - 2016-02-27 19:04:39 --> Database Driver Class Initialized
INFO - 2016-02-27 19:04:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:04:40 --> Controller Class Initialized
INFO - 2016-02-27 19:04:40 --> Model Class Initialized
INFO - 2016-02-27 19:04:40 --> Model Class Initialized
INFO - 2016-02-27 19:04:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:04:40 --> Pagination Class Initialized
INFO - 2016-02-27 19:04:40 --> Helper loaded: text_helper
INFO - 2016-02-27 19:04:40 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:04:40 --> Final output sent to browser
DEBUG - 2016-02-27 22:04:40 --> Total execution time: 1.1634
INFO - 2016-02-27 19:06:16 --> Config Class Initialized
INFO - 2016-02-27 19:06:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:06:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:06:16 --> Utf8 Class Initialized
INFO - 2016-02-27 19:06:16 --> URI Class Initialized
DEBUG - 2016-02-27 19:06:16 --> No URI present. Default controller set.
INFO - 2016-02-27 19:06:16 --> Router Class Initialized
INFO - 2016-02-27 19:06:16 --> Output Class Initialized
INFO - 2016-02-27 19:06:16 --> Security Class Initialized
DEBUG - 2016-02-27 19:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:06:16 --> Input Class Initialized
INFO - 2016-02-27 19:06:16 --> Language Class Initialized
INFO - 2016-02-27 19:06:16 --> Loader Class Initialized
INFO - 2016-02-27 19:06:16 --> Helper loaded: url_helper
INFO - 2016-02-27 19:06:16 --> Helper loaded: file_helper
INFO - 2016-02-27 19:06:16 --> Helper loaded: date_helper
INFO - 2016-02-27 19:06:16 --> Helper loaded: form_helper
INFO - 2016-02-27 19:06:16 --> Database Driver Class Initialized
INFO - 2016-02-27 19:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:06:17 --> Controller Class Initialized
INFO - 2016-02-27 19:06:17 --> Model Class Initialized
INFO - 2016-02-27 19:06:17 --> Model Class Initialized
INFO - 2016-02-27 19:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:06:17 --> Pagination Class Initialized
INFO - 2016-02-27 19:06:17 --> Helper loaded: text_helper
INFO - 2016-02-27 19:06:17 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:06:17 --> Final output sent to browser
DEBUG - 2016-02-27 22:06:17 --> Total execution time: 1.1421
INFO - 2016-02-27 19:06:36 --> Config Class Initialized
INFO - 2016-02-27 19:06:36 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:06:36 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:06:36 --> Utf8 Class Initialized
INFO - 2016-02-27 19:06:36 --> URI Class Initialized
INFO - 2016-02-27 19:06:36 --> Router Class Initialized
INFO - 2016-02-27 19:06:36 --> Output Class Initialized
INFO - 2016-02-27 19:06:36 --> Security Class Initialized
DEBUG - 2016-02-27 19:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:06:36 --> Input Class Initialized
INFO - 2016-02-27 19:06:36 --> Language Class Initialized
INFO - 2016-02-27 19:06:36 --> Loader Class Initialized
INFO - 2016-02-27 19:06:36 --> Helper loaded: url_helper
INFO - 2016-02-27 19:06:36 --> Helper loaded: file_helper
INFO - 2016-02-27 19:06:36 --> Helper loaded: date_helper
INFO - 2016-02-27 19:06:36 --> Helper loaded: form_helper
INFO - 2016-02-27 19:06:36 --> Database Driver Class Initialized
INFO - 2016-02-27 19:06:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:06:37 --> Controller Class Initialized
INFO - 2016-02-27 19:06:37 --> Model Class Initialized
INFO - 2016-02-27 19:06:37 --> Model Class Initialized
INFO - 2016-02-27 19:06:37 --> Form Validation Class Initialized
INFO - 2016-02-27 19:06:37 --> Helper loaded: text_helper
INFO - 2016-02-27 19:06:37 --> Config Class Initialized
INFO - 2016-02-27 19:06:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:06:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:06:37 --> Utf8 Class Initialized
INFO - 2016-02-27 19:06:37 --> URI Class Initialized
INFO - 2016-02-27 19:06:37 --> Router Class Initialized
INFO - 2016-02-27 19:06:37 --> Output Class Initialized
INFO - 2016-02-27 19:06:37 --> Security Class Initialized
DEBUG - 2016-02-27 19:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:06:37 --> Input Class Initialized
INFO - 2016-02-27 19:06:37 --> Language Class Initialized
INFO - 2016-02-27 19:06:37 --> Loader Class Initialized
INFO - 2016-02-27 19:06:37 --> Helper loaded: url_helper
INFO - 2016-02-27 19:06:37 --> Helper loaded: file_helper
INFO - 2016-02-27 19:06:37 --> Helper loaded: date_helper
INFO - 2016-02-27 19:06:37 --> Helper loaded: form_helper
INFO - 2016-02-27 19:06:37 --> Database Driver Class Initialized
INFO - 2016-02-27 19:06:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:06:39 --> Controller Class Initialized
INFO - 2016-02-27 19:06:39 --> Model Class Initialized
INFO - 2016-02-27 19:06:39 --> Model Class Initialized
INFO - 2016-02-27 19:06:39 --> Form Validation Class Initialized
INFO - 2016-02-27 19:06:39 --> Helper loaded: text_helper
INFO - 2016-02-27 19:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 19:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 19:06:39 --> Final output sent to browser
DEBUG - 2016-02-27 19:06:39 --> Total execution time: 1.1381
INFO - 2016-02-27 19:06:58 --> Config Class Initialized
INFO - 2016-02-27 19:06:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:06:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:06:58 --> Utf8 Class Initialized
INFO - 2016-02-27 19:06:58 --> URI Class Initialized
DEBUG - 2016-02-27 19:06:58 --> No URI present. Default controller set.
INFO - 2016-02-27 19:06:58 --> Router Class Initialized
INFO - 2016-02-27 19:06:58 --> Output Class Initialized
INFO - 2016-02-27 19:06:58 --> Security Class Initialized
DEBUG - 2016-02-27 19:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:06:58 --> Input Class Initialized
INFO - 2016-02-27 19:06:58 --> Language Class Initialized
INFO - 2016-02-27 19:06:58 --> Loader Class Initialized
INFO - 2016-02-27 19:06:58 --> Helper loaded: url_helper
INFO - 2016-02-27 19:06:58 --> Helper loaded: file_helper
INFO - 2016-02-27 19:06:58 --> Helper loaded: date_helper
INFO - 2016-02-27 19:06:58 --> Helper loaded: form_helper
INFO - 2016-02-27 19:06:58 --> Database Driver Class Initialized
INFO - 2016-02-27 19:06:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:06:59 --> Controller Class Initialized
INFO - 2016-02-27 19:06:59 --> Model Class Initialized
INFO - 2016-02-27 19:06:59 --> Model Class Initialized
INFO - 2016-02-27 19:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:06:59 --> Pagination Class Initialized
INFO - 2016-02-27 19:06:59 --> Helper loaded: text_helper
INFO - 2016-02-27 19:06:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:06:59 --> Final output sent to browser
DEBUG - 2016-02-27 22:06:59 --> Total execution time: 1.1485
INFO - 2016-02-27 19:08:14 --> Config Class Initialized
INFO - 2016-02-27 19:08:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:08:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:08:14 --> Utf8 Class Initialized
INFO - 2016-02-27 19:08:14 --> URI Class Initialized
INFO - 2016-02-27 19:08:14 --> Router Class Initialized
INFO - 2016-02-27 19:08:14 --> Output Class Initialized
INFO - 2016-02-27 19:08:14 --> Security Class Initialized
DEBUG - 2016-02-27 19:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:08:14 --> Input Class Initialized
INFO - 2016-02-27 19:08:14 --> Language Class Initialized
INFO - 2016-02-27 19:08:14 --> Loader Class Initialized
INFO - 2016-02-27 19:08:14 --> Helper loaded: url_helper
INFO - 2016-02-27 19:08:14 --> Helper loaded: file_helper
INFO - 2016-02-27 19:08:14 --> Helper loaded: date_helper
INFO - 2016-02-27 19:08:14 --> Helper loaded: form_helper
INFO - 2016-02-27 19:08:14 --> Database Driver Class Initialized
INFO - 2016-02-27 19:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:08:15 --> Controller Class Initialized
INFO - 2016-02-27 19:08:15 --> Model Class Initialized
INFO - 2016-02-27 19:08:15 --> Model Class Initialized
INFO - 2016-02-27 19:08:15 --> Form Validation Class Initialized
INFO - 2016-02-27 19:08:15 --> Helper loaded: text_helper
INFO - 2016-02-27 19:08:15 --> Config Class Initialized
INFO - 2016-02-27 19:08:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:08:15 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:08:15 --> Utf8 Class Initialized
INFO - 2016-02-27 19:08:15 --> URI Class Initialized
INFO - 2016-02-27 19:08:15 --> Router Class Initialized
INFO - 2016-02-27 19:08:15 --> Output Class Initialized
INFO - 2016-02-27 19:08:15 --> Security Class Initialized
DEBUG - 2016-02-27 19:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:08:15 --> Input Class Initialized
INFO - 2016-02-27 19:08:15 --> Language Class Initialized
INFO - 2016-02-27 19:08:15 --> Loader Class Initialized
INFO - 2016-02-27 19:08:15 --> Helper loaded: url_helper
INFO - 2016-02-27 19:08:15 --> Helper loaded: file_helper
INFO - 2016-02-27 19:08:15 --> Helper loaded: date_helper
INFO - 2016-02-27 19:08:15 --> Helper loaded: form_helper
INFO - 2016-02-27 19:08:15 --> Database Driver Class Initialized
INFO - 2016-02-27 19:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:08:16 --> Controller Class Initialized
INFO - 2016-02-27 19:08:16 --> Model Class Initialized
INFO - 2016-02-27 19:08:16 --> Model Class Initialized
INFO - 2016-02-27 19:08:16 --> Form Validation Class Initialized
INFO - 2016-02-27 19:08:16 --> Helper loaded: text_helper
INFO - 2016-02-27 19:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 19:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-27 19:08:16 --> Final output sent to browser
DEBUG - 2016-02-27 19:08:16 --> Total execution time: 1.1455
INFO - 2016-02-27 19:08:21 --> Config Class Initialized
INFO - 2016-02-27 19:08:21 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:08:21 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:08:21 --> Utf8 Class Initialized
INFO - 2016-02-27 19:08:21 --> URI Class Initialized
DEBUG - 2016-02-27 19:08:21 --> No URI present. Default controller set.
INFO - 2016-02-27 19:08:21 --> Router Class Initialized
INFO - 2016-02-27 19:08:21 --> Output Class Initialized
INFO - 2016-02-27 19:08:21 --> Security Class Initialized
DEBUG - 2016-02-27 19:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:08:21 --> Input Class Initialized
INFO - 2016-02-27 19:08:21 --> Language Class Initialized
INFO - 2016-02-27 19:08:21 --> Loader Class Initialized
INFO - 2016-02-27 19:08:21 --> Helper loaded: url_helper
INFO - 2016-02-27 19:08:21 --> Helper loaded: file_helper
INFO - 2016-02-27 19:08:21 --> Helper loaded: date_helper
INFO - 2016-02-27 19:08:21 --> Helper loaded: form_helper
INFO - 2016-02-27 19:08:21 --> Database Driver Class Initialized
INFO - 2016-02-27 19:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:08:22 --> Controller Class Initialized
INFO - 2016-02-27 19:08:22 --> Model Class Initialized
INFO - 2016-02-27 19:08:22 --> Model Class Initialized
INFO - 2016-02-27 19:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:08:22 --> Pagination Class Initialized
INFO - 2016-02-27 19:08:22 --> Helper loaded: text_helper
INFO - 2016-02-27 19:08:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:08:22 --> Final output sent to browser
DEBUG - 2016-02-27 22:08:22 --> Total execution time: 1.1872
INFO - 2016-02-27 19:08:34 --> Config Class Initialized
INFO - 2016-02-27 19:08:34 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:08:34 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:08:34 --> Utf8 Class Initialized
INFO - 2016-02-27 19:08:34 --> URI Class Initialized
INFO - 2016-02-27 19:08:34 --> Router Class Initialized
INFO - 2016-02-27 19:08:34 --> Output Class Initialized
INFO - 2016-02-27 19:08:34 --> Security Class Initialized
DEBUG - 2016-02-27 19:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:08:34 --> Input Class Initialized
INFO - 2016-02-27 19:08:34 --> Language Class Initialized
INFO - 2016-02-27 19:08:34 --> Loader Class Initialized
INFO - 2016-02-27 19:08:34 --> Helper loaded: url_helper
INFO - 2016-02-27 19:08:34 --> Helper loaded: file_helper
INFO - 2016-02-27 19:08:34 --> Helper loaded: date_helper
INFO - 2016-02-27 19:08:34 --> Helper loaded: form_helper
INFO - 2016-02-27 19:08:34 --> Database Driver Class Initialized
INFO - 2016-02-27 19:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:08:35 --> Controller Class Initialized
INFO - 2016-02-27 19:08:35 --> Model Class Initialized
INFO - 2016-02-27 19:08:35 --> Model Class Initialized
INFO - 2016-02-27 19:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:08:35 --> Pagination Class Initialized
INFO - 2016-02-27 19:08:35 --> Helper loaded: text_helper
INFO - 2016-02-27 19:08:35 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:08:35 --> Final output sent to browser
DEBUG - 2016-02-27 22:08:35 --> Total execution time: 1.1588
INFO - 2016-02-27 19:36:49 --> Config Class Initialized
INFO - 2016-02-27 19:36:49 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:36:49 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:36:49 --> Utf8 Class Initialized
INFO - 2016-02-27 19:36:49 --> URI Class Initialized
INFO - 2016-02-27 19:36:49 --> Router Class Initialized
INFO - 2016-02-27 19:36:49 --> Output Class Initialized
INFO - 2016-02-27 19:36:49 --> Security Class Initialized
DEBUG - 2016-02-27 19:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:36:49 --> Input Class Initialized
INFO - 2016-02-27 19:36:49 --> Language Class Initialized
ERROR - 2016-02-27 19:36:49 --> 404 Page Not Found: Board_tank/install
INFO - 2016-02-27 19:36:55 --> Config Class Initialized
INFO - 2016-02-27 19:36:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:36:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:36:55 --> Utf8 Class Initialized
INFO - 2016-02-27 19:36:55 --> URI Class Initialized
INFO - 2016-02-27 19:36:55 --> Router Class Initialized
INFO - 2016-02-27 19:36:55 --> Output Class Initialized
INFO - 2016-02-27 19:36:55 --> Security Class Initialized
DEBUG - 2016-02-27 19:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:36:55 --> Input Class Initialized
INFO - 2016-02-27 19:36:55 --> Language Class Initialized
ERROR - 2016-02-27 19:36:55 --> 404 Page Not Found: Board_tank/auth
INFO - 2016-02-27 19:46:19 --> Config Class Initialized
INFO - 2016-02-27 19:46:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:46:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:46:19 --> Utf8 Class Initialized
INFO - 2016-02-27 19:46:19 --> URI Class Initialized
INFO - 2016-02-27 19:46:19 --> Router Class Initialized
INFO - 2016-02-27 19:46:19 --> Output Class Initialized
INFO - 2016-02-27 19:46:19 --> Security Class Initialized
DEBUG - 2016-02-27 19:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:46:19 --> Input Class Initialized
INFO - 2016-02-27 19:46:19 --> Language Class Initialized
ERROR - 2016-02-27 19:46:19 --> 404 Page Not Found: Root_folder/controller
INFO - 2016-02-27 19:51:51 --> Config Class Initialized
INFO - 2016-02-27 19:51:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:51:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:51:51 --> Utf8 Class Initialized
INFO - 2016-02-27 19:51:51 --> URI Class Initialized
INFO - 2016-02-27 19:51:51 --> Router Class Initialized
INFO - 2016-02-27 19:51:51 --> Output Class Initialized
INFO - 2016-02-27 19:51:51 --> Security Class Initialized
DEBUG - 2016-02-27 19:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:51:51 --> Input Class Initialized
INFO - 2016-02-27 19:51:51 --> Language Class Initialized
INFO - 2016-02-27 19:51:51 --> Loader Class Initialized
INFO - 2016-02-27 19:51:51 --> Helper loaded: url_helper
INFO - 2016-02-27 19:51:51 --> Helper loaded: file_helper
INFO - 2016-02-27 19:51:51 --> Helper loaded: date_helper
INFO - 2016-02-27 19:51:51 --> Helper loaded: form_helper
INFO - 2016-02-27 19:51:51 --> Database Driver Class Initialized
INFO - 2016-02-27 19:51:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:51:52 --> Controller Class Initialized
INFO - 2016-02-27 19:51:52 --> Model Class Initialized
INFO - 2016-02-27 19:51:52 --> Model Class Initialized
INFO - 2016-02-27 19:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:51:52 --> Pagination Class Initialized
INFO - 2016-02-27 19:51:52 --> Helper loaded: text_helper
INFO - 2016-02-27 19:51:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-27 22:51:52 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 31
INFO - 2016-02-27 19:53:20 --> Config Class Initialized
INFO - 2016-02-27 19:53:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:20 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:20 --> URI Class Initialized
INFO - 2016-02-27 19:53:20 --> Router Class Initialized
INFO - 2016-02-27 19:53:20 --> Output Class Initialized
INFO - 2016-02-27 19:53:20 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:20 --> Input Class Initialized
INFO - 2016-02-27 19:53:20 --> Language Class Initialized
INFO - 2016-02-27 19:53:20 --> Loader Class Initialized
INFO - 2016-02-27 19:53:20 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:21 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:21 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:21 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:21 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:22 --> Controller Class Initialized
INFO - 2016-02-27 19:53:22 --> Model Class Initialized
INFO - 2016-02-27 19:53:22 --> Model Class Initialized
INFO - 2016-02-27 19:53:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:22 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:22 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:22 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:22 --> Total execution time: 1.2046
INFO - 2016-02-27 19:53:24 --> Config Class Initialized
INFO - 2016-02-27 19:53:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:24 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:24 --> URI Class Initialized
INFO - 2016-02-27 19:53:24 --> Router Class Initialized
INFO - 2016-02-27 19:53:24 --> Output Class Initialized
INFO - 2016-02-27 19:53:24 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:24 --> Input Class Initialized
INFO - 2016-02-27 19:53:24 --> Language Class Initialized
INFO - 2016-02-27 19:53:24 --> Loader Class Initialized
INFO - 2016-02-27 19:53:24 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:24 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:24 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:24 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:24 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:25 --> Controller Class Initialized
INFO - 2016-02-27 19:53:25 --> Model Class Initialized
INFO - 2016-02-27 19:53:25 --> Model Class Initialized
INFO - 2016-02-27 19:53:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:25 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:25 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:25 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:53:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:25 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:25 --> Total execution time: 1.1613
INFO - 2016-02-27 19:53:28 --> Config Class Initialized
INFO - 2016-02-27 19:53:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:28 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:28 --> URI Class Initialized
DEBUG - 2016-02-27 19:53:28 --> No URI present. Default controller set.
INFO - 2016-02-27 19:53:28 --> Router Class Initialized
INFO - 2016-02-27 19:53:28 --> Output Class Initialized
INFO - 2016-02-27 19:53:28 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:28 --> Input Class Initialized
INFO - 2016-02-27 19:53:28 --> Language Class Initialized
INFO - 2016-02-27 19:53:28 --> Loader Class Initialized
INFO - 2016-02-27 19:53:28 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:28 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:28 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:28 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:28 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:29 --> Controller Class Initialized
INFO - 2016-02-27 19:53:29 --> Model Class Initialized
INFO - 2016-02-27 19:53:29 --> Model Class Initialized
INFO - 2016-02-27 19:53:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:29 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:29 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:29 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:53:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:29 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:29 --> Total execution time: 1.1864
INFO - 2016-02-27 19:53:36 --> Config Class Initialized
INFO - 2016-02-27 19:53:36 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:36 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:36 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:36 --> URI Class Initialized
INFO - 2016-02-27 19:53:36 --> Router Class Initialized
INFO - 2016-02-27 19:53:36 --> Output Class Initialized
INFO - 2016-02-27 19:53:36 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:36 --> Input Class Initialized
INFO - 2016-02-27 19:53:36 --> Language Class Initialized
INFO - 2016-02-27 19:53:36 --> Loader Class Initialized
INFO - 2016-02-27 19:53:36 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:36 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:36 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:36 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:36 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:37 --> Controller Class Initialized
INFO - 2016-02-27 19:53:37 --> Model Class Initialized
INFO - 2016-02-27 19:53:37 --> Model Class Initialized
INFO - 2016-02-27 19:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:37 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:37 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:37 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-27 22:53:37 --> Query error: Table 'jdboard.info_comment' doesn't exist - Invalid query: SELECT *
FROM `info_comment`
WHERE `board_id` = '60'
INFO - 2016-02-27 22:53:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-27 22:53:37 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456631617
WHERE `board_id` = '60'
AND `id` = 'e06093b3b9accf6d58a0149f05971259cd98bd68'
INFO - 2016-02-27 19:53:39 --> Config Class Initialized
INFO - 2016-02-27 19:53:39 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:39 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:39 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:39 --> URI Class Initialized
DEBUG - 2016-02-27 19:53:39 --> No URI present. Default controller set.
INFO - 2016-02-27 19:53:39 --> Router Class Initialized
INFO - 2016-02-27 19:53:39 --> Output Class Initialized
INFO - 2016-02-27 19:53:39 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:39 --> Input Class Initialized
INFO - 2016-02-27 19:53:39 --> Language Class Initialized
INFO - 2016-02-27 19:53:39 --> Loader Class Initialized
INFO - 2016-02-27 19:53:39 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:39 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:39 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:39 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:39 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:40 --> Controller Class Initialized
INFO - 2016-02-27 19:53:40 --> Model Class Initialized
INFO - 2016-02-27 19:53:40 --> Model Class Initialized
INFO - 2016-02-27 19:53:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:40 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:40 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:40 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:53:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:40 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:40 --> Total execution time: 1.1078
INFO - 2016-02-27 19:53:41 --> Config Class Initialized
INFO - 2016-02-27 19:53:41 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:41 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:41 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:41 --> URI Class Initialized
INFO - 2016-02-27 19:53:41 --> Router Class Initialized
INFO - 2016-02-27 19:53:41 --> Output Class Initialized
INFO - 2016-02-27 19:53:41 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:41 --> Input Class Initialized
INFO - 2016-02-27 19:53:41 --> Language Class Initialized
INFO - 2016-02-27 19:53:41 --> Loader Class Initialized
INFO - 2016-02-27 19:53:41 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:41 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:41 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:41 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:41 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:42 --> Controller Class Initialized
INFO - 2016-02-27 19:53:42 --> Model Class Initialized
INFO - 2016-02-27 19:53:42 --> Model Class Initialized
INFO - 2016-02-27 19:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:42 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:42 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:42 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:42 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:42 --> Total execution time: 1.1510
INFO - 2016-02-27 19:53:47 --> Config Class Initialized
INFO - 2016-02-27 19:53:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:53:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:53:47 --> Utf8 Class Initialized
INFO - 2016-02-27 19:53:47 --> URI Class Initialized
INFO - 2016-02-27 19:53:47 --> Router Class Initialized
INFO - 2016-02-27 19:53:47 --> Output Class Initialized
INFO - 2016-02-27 19:53:47 --> Security Class Initialized
DEBUG - 2016-02-27 19:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:53:47 --> Input Class Initialized
INFO - 2016-02-27 19:53:47 --> Language Class Initialized
INFO - 2016-02-27 19:53:47 --> Loader Class Initialized
INFO - 2016-02-27 19:53:47 --> Helper loaded: url_helper
INFO - 2016-02-27 19:53:47 --> Helper loaded: file_helper
INFO - 2016-02-27 19:53:47 --> Helper loaded: date_helper
INFO - 2016-02-27 19:53:47 --> Helper loaded: form_helper
INFO - 2016-02-27 19:53:47 --> Database Driver Class Initialized
INFO - 2016-02-27 19:53:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:53:48 --> Controller Class Initialized
INFO - 2016-02-27 19:53:48 --> Model Class Initialized
INFO - 2016-02-27 19:53:48 --> Model Class Initialized
INFO - 2016-02-27 19:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:53:48 --> Pagination Class Initialized
INFO - 2016-02-27 19:53:48 --> Helper loaded: text_helper
INFO - 2016-02-27 19:53:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 22:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 22:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:53:48 --> Final output sent to browser
DEBUG - 2016-02-27 22:53:48 --> Total execution time: 1.1309
INFO - 2016-02-27 19:56:05 --> Config Class Initialized
INFO - 2016-02-27 19:56:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 19:56:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 19:56:05 --> Utf8 Class Initialized
INFO - 2016-02-27 19:56:05 --> URI Class Initialized
DEBUG - 2016-02-27 19:56:05 --> No URI present. Default controller set.
INFO - 2016-02-27 19:56:05 --> Router Class Initialized
INFO - 2016-02-27 19:56:05 --> Output Class Initialized
INFO - 2016-02-27 19:56:05 --> Security Class Initialized
DEBUG - 2016-02-27 19:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 19:56:05 --> Input Class Initialized
INFO - 2016-02-27 19:56:05 --> Language Class Initialized
INFO - 2016-02-27 19:56:05 --> Loader Class Initialized
INFO - 2016-02-27 19:56:05 --> Helper loaded: url_helper
INFO - 2016-02-27 19:56:05 --> Helper loaded: file_helper
INFO - 2016-02-27 19:56:05 --> Helper loaded: date_helper
INFO - 2016-02-27 19:56:05 --> Helper loaded: form_helper
INFO - 2016-02-27 19:56:05 --> Database Driver Class Initialized
INFO - 2016-02-27 19:56:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 19:56:06 --> Controller Class Initialized
INFO - 2016-02-27 19:56:06 --> Model Class Initialized
INFO - 2016-02-27 19:56:06 --> Model Class Initialized
INFO - 2016-02-27 19:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 19:56:06 --> Pagination Class Initialized
INFO - 2016-02-27 19:56:06 --> Helper loaded: text_helper
INFO - 2016-02-27 19:56:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 22:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 22:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 22:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 22:56:06 --> Final output sent to browser
DEBUG - 2016-02-27 22:56:06 --> Total execution time: 1.1184
INFO - 2016-02-27 20:03:14 --> Config Class Initialized
INFO - 2016-02-27 20:03:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:03:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:03:14 --> Utf8 Class Initialized
INFO - 2016-02-27 20:03:14 --> URI Class Initialized
INFO - 2016-02-27 20:03:14 --> Router Class Initialized
INFO - 2016-02-27 20:03:14 --> Output Class Initialized
INFO - 2016-02-27 20:03:14 --> Security Class Initialized
DEBUG - 2016-02-27 20:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:03:14 --> Input Class Initialized
INFO - 2016-02-27 20:03:14 --> Language Class Initialized
INFO - 2016-02-27 20:03:14 --> Loader Class Initialized
INFO - 2016-02-27 20:03:14 --> Helper loaded: url_helper
INFO - 2016-02-27 20:03:14 --> Helper loaded: file_helper
INFO - 2016-02-27 20:03:14 --> Helper loaded: date_helper
INFO - 2016-02-27 20:03:14 --> Helper loaded: form_helper
INFO - 2016-02-27 20:03:14 --> Database Driver Class Initialized
INFO - 2016-02-27 20:03:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:03:15 --> Controller Class Initialized
INFO - 2016-02-27 20:03:15 --> Model Class Initialized
INFO - 2016-02-27 20:03:15 --> Model Class Initialized
INFO - 2016-02-27 20:03:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:03:15 --> Pagination Class Initialized
INFO - 2016-02-27 20:03:15 --> Helper loaded: text_helper
INFO - 2016-02-27 20:03:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-27 23:03:16 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
INFO - 2016-02-27 20:03:48 --> Config Class Initialized
INFO - 2016-02-27 20:03:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:03:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:03:48 --> Utf8 Class Initialized
INFO - 2016-02-27 20:03:48 --> URI Class Initialized
INFO - 2016-02-27 20:03:48 --> Router Class Initialized
INFO - 2016-02-27 20:03:48 --> Output Class Initialized
INFO - 2016-02-27 20:03:48 --> Security Class Initialized
DEBUG - 2016-02-27 20:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:03:48 --> Input Class Initialized
INFO - 2016-02-27 20:03:48 --> Language Class Initialized
INFO - 2016-02-27 20:03:48 --> Loader Class Initialized
INFO - 2016-02-27 20:03:48 --> Helper loaded: url_helper
INFO - 2016-02-27 20:03:48 --> Helper loaded: file_helper
INFO - 2016-02-27 20:03:48 --> Helper loaded: date_helper
INFO - 2016-02-27 20:03:48 --> Helper loaded: form_helper
INFO - 2016-02-27 20:03:48 --> Database Driver Class Initialized
INFO - 2016-02-27 20:03:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:03:49 --> Controller Class Initialized
INFO - 2016-02-27 20:03:49 --> Model Class Initialized
INFO - 2016-02-27 20:03:49 --> Model Class Initialized
INFO - 2016-02-27 20:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:03:49 --> Pagination Class Initialized
INFO - 2016-02-27 20:03:49 --> Helper loaded: text_helper
INFO - 2016-02-27 20:03:49 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:03:49 --> Final output sent to browser
DEBUG - 2016-02-27 23:03:49 --> Total execution time: 1.1580
INFO - 2016-02-27 20:03:53 --> Config Class Initialized
INFO - 2016-02-27 20:03:53 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:03:53 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:03:53 --> Utf8 Class Initialized
INFO - 2016-02-27 20:03:53 --> URI Class Initialized
DEBUG - 2016-02-27 20:03:53 --> No URI present. Default controller set.
INFO - 2016-02-27 20:03:53 --> Router Class Initialized
INFO - 2016-02-27 20:03:53 --> Output Class Initialized
INFO - 2016-02-27 20:03:53 --> Security Class Initialized
DEBUG - 2016-02-27 20:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:03:53 --> Input Class Initialized
INFO - 2016-02-27 20:03:53 --> Language Class Initialized
INFO - 2016-02-27 20:03:53 --> Loader Class Initialized
INFO - 2016-02-27 20:03:53 --> Helper loaded: url_helper
INFO - 2016-02-27 20:03:53 --> Helper loaded: file_helper
INFO - 2016-02-27 20:03:53 --> Helper loaded: date_helper
INFO - 2016-02-27 20:03:53 --> Helper loaded: form_helper
INFO - 2016-02-27 20:03:53 --> Database Driver Class Initialized
INFO - 2016-02-27 20:03:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:03:54 --> Controller Class Initialized
INFO - 2016-02-27 20:03:54 --> Model Class Initialized
INFO - 2016-02-27 20:03:54 --> Model Class Initialized
INFO - 2016-02-27 20:03:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:03:54 --> Pagination Class Initialized
INFO - 2016-02-27 20:03:54 --> Helper loaded: text_helper
INFO - 2016-02-27 20:03:54 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 23:03:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:03:54 --> Final output sent to browser
DEBUG - 2016-02-27 23:03:54 --> Total execution time: 1.1245
INFO - 2016-02-27 20:04:00 --> Config Class Initialized
INFO - 2016-02-27 20:04:00 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:04:00 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:04:00 --> Utf8 Class Initialized
INFO - 2016-02-27 20:04:00 --> URI Class Initialized
INFO - 2016-02-27 20:04:00 --> Router Class Initialized
INFO - 2016-02-27 20:04:00 --> Output Class Initialized
INFO - 2016-02-27 20:04:00 --> Security Class Initialized
DEBUG - 2016-02-27 20:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:04:00 --> Input Class Initialized
INFO - 2016-02-27 20:04:00 --> Language Class Initialized
INFO - 2016-02-27 20:04:00 --> Loader Class Initialized
INFO - 2016-02-27 20:04:00 --> Helper loaded: url_helper
INFO - 2016-02-27 20:04:00 --> Helper loaded: file_helper
INFO - 2016-02-27 20:04:00 --> Helper loaded: date_helper
INFO - 2016-02-27 20:04:00 --> Helper loaded: form_helper
INFO - 2016-02-27 20:04:00 --> Database Driver Class Initialized
INFO - 2016-02-27 20:04:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:04:01 --> Controller Class Initialized
INFO - 2016-02-27 20:04:01 --> Model Class Initialized
INFO - 2016-02-27 20:04:01 --> Model Class Initialized
INFO - 2016-02-27 20:04:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:04:01 --> Pagination Class Initialized
INFO - 2016-02-27 20:04:01 --> Helper loaded: text_helper
INFO - 2016-02-27 20:04:01 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:04:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:04:02 --> Final output sent to browser
DEBUG - 2016-02-27 23:04:02 --> Total execution time: 1.1497
INFO - 2016-02-27 20:04:04 --> Config Class Initialized
INFO - 2016-02-27 20:04:04 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:04:04 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:04:04 --> Utf8 Class Initialized
INFO - 2016-02-27 20:04:04 --> URI Class Initialized
DEBUG - 2016-02-27 20:04:04 --> No URI present. Default controller set.
INFO - 2016-02-27 20:04:04 --> Router Class Initialized
INFO - 2016-02-27 20:04:04 --> Output Class Initialized
INFO - 2016-02-27 20:04:04 --> Security Class Initialized
DEBUG - 2016-02-27 20:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:04:04 --> Input Class Initialized
INFO - 2016-02-27 20:04:04 --> Language Class Initialized
INFO - 2016-02-27 20:04:04 --> Loader Class Initialized
INFO - 2016-02-27 20:04:04 --> Helper loaded: url_helper
INFO - 2016-02-27 20:04:04 --> Helper loaded: file_helper
INFO - 2016-02-27 20:04:04 --> Helper loaded: date_helper
INFO - 2016-02-27 20:04:04 --> Helper loaded: form_helper
INFO - 2016-02-27 20:04:04 --> Database Driver Class Initialized
INFO - 2016-02-27 20:04:05 --> Config Class Initialized
INFO - 2016-02-27 20:04:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:04:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:04:05 --> Utf8 Class Initialized
INFO - 2016-02-27 20:04:05 --> URI Class Initialized
INFO - 2016-02-27 20:04:05 --> Router Class Initialized
INFO - 2016-02-27 20:04:05 --> Output Class Initialized
INFO - 2016-02-27 20:04:05 --> Security Class Initialized
DEBUG - 2016-02-27 20:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:04:05 --> Input Class Initialized
INFO - 2016-02-27 20:04:05 --> Language Class Initialized
INFO - 2016-02-27 20:04:05 --> Loader Class Initialized
INFO - 2016-02-27 20:04:05 --> Helper loaded: url_helper
INFO - 2016-02-27 20:04:05 --> Helper loaded: file_helper
INFO - 2016-02-27 20:04:05 --> Helper loaded: date_helper
INFO - 2016-02-27 20:04:05 --> Helper loaded: form_helper
INFO - 2016-02-27 20:04:05 --> Database Driver Class Initialized
INFO - 2016-02-27 20:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:04:05 --> Controller Class Initialized
INFO - 2016-02-27 20:04:05 --> Model Class Initialized
INFO - 2016-02-27 20:04:05 --> Model Class Initialized
INFO - 2016-02-27 20:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:04:05 --> Pagination Class Initialized
INFO - 2016-02-27 20:04:05 --> Helper loaded: text_helper
INFO - 2016-02-27 20:04:05 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 23:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:04:05 --> Final output sent to browser
DEBUG - 2016-02-27 23:04:05 --> Total execution time: 1.1091
INFO - 2016-02-27 20:04:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:04:06 --> Controller Class Initialized
INFO - 2016-02-27 20:04:06 --> Model Class Initialized
INFO - 2016-02-27 20:04:06 --> Model Class Initialized
INFO - 2016-02-27 20:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:04:06 --> Pagination Class Initialized
INFO - 2016-02-27 20:04:06 --> Helper loaded: text_helper
INFO - 2016-02-27 20:04:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:04:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:04:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:04:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:04:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:04:06 --> Final output sent to browser
DEBUG - 2016-02-27 23:04:06 --> Total execution time: 1.1230
INFO - 2016-02-27 20:04:08 --> Config Class Initialized
INFO - 2016-02-27 20:04:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:04:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:04:08 --> Utf8 Class Initialized
INFO - 2016-02-27 20:04:08 --> URI Class Initialized
INFO - 2016-02-27 20:04:08 --> Router Class Initialized
INFO - 2016-02-27 20:04:08 --> Output Class Initialized
INFO - 2016-02-27 20:04:08 --> Security Class Initialized
DEBUG - 2016-02-27 20:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:04:08 --> Input Class Initialized
INFO - 2016-02-27 20:04:08 --> Language Class Initialized
INFO - 2016-02-27 20:04:08 --> Loader Class Initialized
INFO - 2016-02-27 20:04:08 --> Helper loaded: url_helper
INFO - 2016-02-27 20:04:08 --> Helper loaded: file_helper
INFO - 2016-02-27 20:04:08 --> Helper loaded: date_helper
INFO - 2016-02-27 20:04:08 --> Helper loaded: form_helper
INFO - 2016-02-27 20:04:08 --> Database Driver Class Initialized
INFO - 2016-02-27 20:04:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:04:09 --> Controller Class Initialized
INFO - 2016-02-27 20:04:09 --> Model Class Initialized
INFO - 2016-02-27 20:04:09 --> Model Class Initialized
INFO - 2016-02-27 20:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:04:09 --> Pagination Class Initialized
INFO - 2016-02-27 20:04:09 --> Helper loaded: text_helper
INFO - 2016-02-27 20:04:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:04:09 --> Final output sent to browser
DEBUG - 2016-02-27 23:04:09 --> Total execution time: 1.1235
INFO - 2016-02-27 20:10:58 --> Config Class Initialized
INFO - 2016-02-27 20:10:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:10:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:10:58 --> Utf8 Class Initialized
INFO - 2016-02-27 20:10:58 --> URI Class Initialized
INFO - 2016-02-27 20:10:58 --> Router Class Initialized
INFO - 2016-02-27 20:10:58 --> Output Class Initialized
INFO - 2016-02-27 20:10:58 --> Security Class Initialized
DEBUG - 2016-02-27 20:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:10:58 --> Input Class Initialized
INFO - 2016-02-27 20:10:58 --> Language Class Initialized
INFO - 2016-02-27 20:10:58 --> Loader Class Initialized
INFO - 2016-02-27 20:10:58 --> Helper loaded: url_helper
INFO - 2016-02-27 20:10:58 --> Helper loaded: file_helper
INFO - 2016-02-27 20:10:58 --> Helper loaded: date_helper
INFO - 2016-02-27 20:10:58 --> Helper loaded: form_helper
INFO - 2016-02-27 20:10:58 --> Database Driver Class Initialized
INFO - 2016-02-27 20:10:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:10:59 --> Controller Class Initialized
INFO - 2016-02-27 20:10:59 --> Model Class Initialized
INFO - 2016-02-27 20:10:59 --> Model Class Initialized
INFO - 2016-02-27 20:10:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:10:59 --> Pagination Class Initialized
INFO - 2016-02-27 20:10:59 --> Helper loaded: text_helper
INFO - 2016-02-27 20:10:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:11:00 --> Final output sent to browser
DEBUG - 2016-02-27 23:11:00 --> Total execution time: 1.1134
INFO - 2016-02-27 20:11:50 --> Config Class Initialized
INFO - 2016-02-27 20:11:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:11:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:11:50 --> Utf8 Class Initialized
INFO - 2016-02-27 20:11:50 --> URI Class Initialized
INFO - 2016-02-27 20:11:50 --> Router Class Initialized
INFO - 2016-02-27 20:11:50 --> Output Class Initialized
INFO - 2016-02-27 20:11:50 --> Security Class Initialized
DEBUG - 2016-02-27 20:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:11:50 --> Input Class Initialized
INFO - 2016-02-27 20:11:50 --> Language Class Initialized
INFO - 2016-02-27 20:11:50 --> Loader Class Initialized
INFO - 2016-02-27 20:11:50 --> Helper loaded: url_helper
INFO - 2016-02-27 20:11:50 --> Helper loaded: file_helper
INFO - 2016-02-27 20:11:50 --> Helper loaded: date_helper
INFO - 2016-02-27 20:11:50 --> Helper loaded: form_helper
INFO - 2016-02-27 20:11:50 --> Database Driver Class Initialized
INFO - 2016-02-27 20:11:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:11:51 --> Controller Class Initialized
INFO - 2016-02-27 20:11:51 --> Model Class Initialized
INFO - 2016-02-27 20:11:51 --> Model Class Initialized
INFO - 2016-02-27 20:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:11:51 --> Pagination Class Initialized
INFO - 2016-02-27 20:11:51 --> Helper loaded: text_helper
INFO - 2016-02-27 20:11:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:11:51 --> Final output sent to browser
DEBUG - 2016-02-27 23:11:51 --> Total execution time: 1.1424
INFO - 2016-02-27 20:28:19 --> Config Class Initialized
INFO - 2016-02-27 20:28:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:19 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:19 --> URI Class Initialized
DEBUG - 2016-02-27 20:28:19 --> No URI present. Default controller set.
INFO - 2016-02-27 20:28:19 --> Router Class Initialized
INFO - 2016-02-27 20:28:19 --> Output Class Initialized
INFO - 2016-02-27 20:28:19 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:19 --> Input Class Initialized
INFO - 2016-02-27 20:28:19 --> Language Class Initialized
INFO - 2016-02-27 20:28:19 --> Loader Class Initialized
INFO - 2016-02-27 20:28:19 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:19 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:19 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:19 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:19 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:20 --> Controller Class Initialized
INFO - 2016-02-27 20:28:20 --> Model Class Initialized
INFO - 2016-02-27 20:28:20 --> Model Class Initialized
INFO - 2016-02-27 20:28:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:20 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:20 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 23:28:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:20 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:20 --> Total execution time: 1.0963
INFO - 2016-02-27 20:28:25 --> Config Class Initialized
INFO - 2016-02-27 20:28:25 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:25 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:25 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:25 --> URI Class Initialized
INFO - 2016-02-27 20:28:25 --> Router Class Initialized
INFO - 2016-02-27 20:28:25 --> Output Class Initialized
INFO - 2016-02-27 20:28:25 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:25 --> Input Class Initialized
INFO - 2016-02-27 20:28:25 --> Language Class Initialized
INFO - 2016-02-27 20:28:25 --> Loader Class Initialized
INFO - 2016-02-27 20:28:25 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:25 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:25 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:25 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:25 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:26 --> Controller Class Initialized
INFO - 2016-02-27 20:28:26 --> Model Class Initialized
INFO - 2016-02-27 20:28:26 --> Model Class Initialized
INFO - 2016-02-27 20:28:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:26 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:26 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:26 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:26 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:26 --> Total execution time: 1.2199
INFO - 2016-02-27 20:28:44 --> Config Class Initialized
INFO - 2016-02-27 20:28:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:44 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:44 --> URI Class Initialized
DEBUG - 2016-02-27 20:28:44 --> No URI present. Default controller set.
INFO - 2016-02-27 20:28:44 --> Router Class Initialized
INFO - 2016-02-27 20:28:44 --> Output Class Initialized
INFO - 2016-02-27 20:28:44 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:44 --> Input Class Initialized
INFO - 2016-02-27 20:28:44 --> Language Class Initialized
INFO - 2016-02-27 20:28:44 --> Loader Class Initialized
INFO - 2016-02-27 20:28:44 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:44 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:44 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:44 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:44 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:45 --> Controller Class Initialized
INFO - 2016-02-27 20:28:45 --> Model Class Initialized
INFO - 2016-02-27 20:28:45 --> Model Class Initialized
INFO - 2016-02-27 20:28:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:45 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:45 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:45 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 23:28:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:45 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:45 --> Total execution time: 1.1003
INFO - 2016-02-27 20:28:50 --> Config Class Initialized
INFO - 2016-02-27 20:28:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:50 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:50 --> URI Class Initialized
INFO - 2016-02-27 20:28:50 --> Router Class Initialized
INFO - 2016-02-27 20:28:50 --> Output Class Initialized
INFO - 2016-02-27 20:28:50 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:50 --> Input Class Initialized
INFO - 2016-02-27 20:28:50 --> Language Class Initialized
INFO - 2016-02-27 20:28:50 --> Loader Class Initialized
INFO - 2016-02-27 20:28:50 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:50 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:50 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:50 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:50 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:51 --> Controller Class Initialized
INFO - 2016-02-27 20:28:51 --> Model Class Initialized
INFO - 2016-02-27 20:28:51 --> Model Class Initialized
INFO - 2016-02-27 20:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:51 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:51 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:28:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:28:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:51 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:51 --> Total execution time: 1.1511
INFO - 2016-02-27 20:28:55 --> Config Class Initialized
INFO - 2016-02-27 20:28:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:55 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:55 --> URI Class Initialized
INFO - 2016-02-27 20:28:55 --> Router Class Initialized
INFO - 2016-02-27 20:28:55 --> Output Class Initialized
INFO - 2016-02-27 20:28:55 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:55 --> Input Class Initialized
INFO - 2016-02-27 20:28:55 --> Language Class Initialized
INFO - 2016-02-27 20:28:55 --> Loader Class Initialized
INFO - 2016-02-27 20:28:55 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:55 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:55 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:55 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:55 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:56 --> Controller Class Initialized
INFO - 2016-02-27 20:28:56 --> Model Class Initialized
INFO - 2016-02-27 20:28:56 --> Model Class Initialized
INFO - 2016-02-27 20:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:56 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:56 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:56 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:56 --> Total execution time: 1.1065
INFO - 2016-02-27 20:28:58 --> Config Class Initialized
INFO - 2016-02-27 20:28:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:28:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:28:58 --> Utf8 Class Initialized
INFO - 2016-02-27 20:28:58 --> URI Class Initialized
INFO - 2016-02-27 20:28:58 --> Router Class Initialized
INFO - 2016-02-27 20:28:58 --> Output Class Initialized
INFO - 2016-02-27 20:28:58 --> Security Class Initialized
DEBUG - 2016-02-27 20:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:28:58 --> Input Class Initialized
INFO - 2016-02-27 20:28:58 --> Language Class Initialized
INFO - 2016-02-27 20:28:58 --> Loader Class Initialized
INFO - 2016-02-27 20:28:58 --> Helper loaded: url_helper
INFO - 2016-02-27 20:28:58 --> Helper loaded: file_helper
INFO - 2016-02-27 20:28:58 --> Helper loaded: date_helper
INFO - 2016-02-27 20:28:58 --> Helper loaded: form_helper
INFO - 2016-02-27 20:28:58 --> Database Driver Class Initialized
INFO - 2016-02-27 20:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:28:59 --> Controller Class Initialized
INFO - 2016-02-27 20:28:59 --> Model Class Initialized
INFO - 2016-02-27 20:28:59 --> Model Class Initialized
INFO - 2016-02-27 20:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:28:59 --> Pagination Class Initialized
INFO - 2016-02-27 20:28:59 --> Helper loaded: text_helper
INFO - 2016-02-27 20:28:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:28:59 --> Final output sent to browser
DEBUG - 2016-02-27 23:28:59 --> Total execution time: 1.1105
INFO - 2016-02-27 20:29:08 --> Config Class Initialized
INFO - 2016-02-27 20:29:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:29:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:29:08 --> Utf8 Class Initialized
INFO - 2016-02-27 20:29:08 --> URI Class Initialized
INFO - 2016-02-27 20:29:08 --> Router Class Initialized
INFO - 2016-02-27 20:29:08 --> Output Class Initialized
INFO - 2016-02-27 20:29:08 --> Security Class Initialized
DEBUG - 2016-02-27 20:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:29:08 --> Input Class Initialized
INFO - 2016-02-27 20:29:08 --> Language Class Initialized
INFO - 2016-02-27 20:29:08 --> Loader Class Initialized
INFO - 2016-02-27 20:29:08 --> Helper loaded: url_helper
INFO - 2016-02-27 20:29:08 --> Helper loaded: file_helper
INFO - 2016-02-27 20:29:08 --> Helper loaded: date_helper
INFO - 2016-02-27 20:29:08 --> Helper loaded: form_helper
INFO - 2016-02-27 20:29:08 --> Database Driver Class Initialized
INFO - 2016-02-27 20:29:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:29:09 --> Controller Class Initialized
INFO - 2016-02-27 20:29:09 --> Model Class Initialized
INFO - 2016-02-27 20:29:09 --> Model Class Initialized
INFO - 2016-02-27 20:29:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:29:09 --> Pagination Class Initialized
INFO - 2016-02-27 20:29:09 --> Helper loaded: text_helper
INFO - 2016-02-27 20:29:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:29:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:29:09 --> Final output sent to browser
DEBUG - 2016-02-27 23:29:09 --> Total execution time: 1.1436
INFO - 2016-02-27 20:32:03 --> Config Class Initialized
INFO - 2016-02-27 20:32:03 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:03 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:03 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:03 --> URI Class Initialized
INFO - 2016-02-27 20:32:03 --> Router Class Initialized
INFO - 2016-02-27 20:32:03 --> Output Class Initialized
INFO - 2016-02-27 20:32:03 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:03 --> Input Class Initialized
INFO - 2016-02-27 20:32:03 --> Language Class Initialized
INFO - 2016-02-27 20:32:03 --> Loader Class Initialized
INFO - 2016-02-27 20:32:03 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:03 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:03 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:03 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:03 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:04 --> Controller Class Initialized
INFO - 2016-02-27 20:32:04 --> Model Class Initialized
INFO - 2016-02-27 20:32:04 --> Model Class Initialized
INFO - 2016-02-27 20:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:32:04 --> Pagination Class Initialized
INFO - 2016-02-27 20:32:04 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:04 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:32:04 --> Final output sent to browser
DEBUG - 2016-02-27 23:32:04 --> Total execution time: 1.1343
INFO - 2016-02-27 20:32:07 --> Config Class Initialized
INFO - 2016-02-27 20:32:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:07 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:07 --> URI Class Initialized
INFO - 2016-02-27 20:32:07 --> Router Class Initialized
INFO - 2016-02-27 20:32:07 --> Output Class Initialized
INFO - 2016-02-27 20:32:07 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:07 --> Input Class Initialized
INFO - 2016-02-27 20:32:07 --> Language Class Initialized
INFO - 2016-02-27 20:32:07 --> Loader Class Initialized
INFO - 2016-02-27 20:32:07 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:07 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:07 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:07 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:07 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:08 --> Controller Class Initialized
INFO - 2016-02-27 20:32:08 --> Model Class Initialized
INFO - 2016-02-27 20:32:08 --> Model Class Initialized
INFO - 2016-02-27 20:32:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:32:08 --> Pagination Class Initialized
INFO - 2016-02-27 20:32:08 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:08 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:32:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:32:08 --> Final output sent to browser
DEBUG - 2016-02-27 23:32:08 --> Total execution time: 1.1417
INFO - 2016-02-27 20:32:11 --> Config Class Initialized
INFO - 2016-02-27 20:32:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:11 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:11 --> URI Class Initialized
INFO - 2016-02-27 20:32:11 --> Router Class Initialized
INFO - 2016-02-27 20:32:11 --> Output Class Initialized
INFO - 2016-02-27 20:32:11 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:11 --> Input Class Initialized
INFO - 2016-02-27 20:32:11 --> Language Class Initialized
INFO - 2016-02-27 20:32:11 --> Loader Class Initialized
INFO - 2016-02-27 20:32:11 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:11 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:11 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:11 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:11 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:12 --> Controller Class Initialized
INFO - 2016-02-27 20:32:12 --> Model Class Initialized
INFO - 2016-02-27 20:32:12 --> Model Class Initialized
INFO - 2016-02-27 20:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:32:12 --> Pagination Class Initialized
INFO - 2016-02-27 20:32:12 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:32:12 --> Final output sent to browser
DEBUG - 2016-02-27 23:32:12 --> Total execution time: 1.1255
INFO - 2016-02-27 20:32:15 --> Config Class Initialized
INFO - 2016-02-27 20:32:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:15 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:15 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:15 --> URI Class Initialized
INFO - 2016-02-27 20:32:15 --> Router Class Initialized
INFO - 2016-02-27 20:32:15 --> Output Class Initialized
INFO - 2016-02-27 20:32:15 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:15 --> Input Class Initialized
INFO - 2016-02-27 20:32:15 --> Language Class Initialized
INFO - 2016-02-27 20:32:15 --> Loader Class Initialized
INFO - 2016-02-27 20:32:15 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:15 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:15 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:15 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:15 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:16 --> Controller Class Initialized
INFO - 2016-02-27 20:32:16 --> Model Class Initialized
INFO - 2016-02-27 20:32:16 --> Model Class Initialized
INFO - 2016-02-27 20:32:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:32:16 --> Pagination Class Initialized
INFO - 2016-02-27 20:32:16 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:16 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:32:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:32:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:32:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:32:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:32:17 --> Final output sent to browser
DEBUG - 2016-02-27 23:32:17 --> Total execution time: 1.1378
INFO - 2016-02-27 20:32:50 --> Config Class Initialized
INFO - 2016-02-27 20:32:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:50 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:50 --> URI Class Initialized
INFO - 2016-02-27 20:32:50 --> Router Class Initialized
INFO - 2016-02-27 20:32:50 --> Output Class Initialized
INFO - 2016-02-27 20:32:50 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:50 --> Input Class Initialized
INFO - 2016-02-27 20:32:50 --> Language Class Initialized
INFO - 2016-02-27 20:32:50 --> Loader Class Initialized
INFO - 2016-02-27 20:32:50 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:50 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:50 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:50 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:50 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:51 --> Controller Class Initialized
INFO - 2016-02-27 20:32:51 --> Model Class Initialized
INFO - 2016-02-27 20:32:51 --> Model Class Initialized
INFO - 2016-02-27 20:32:51 --> Form Validation Class Initialized
INFO - 2016-02-27 20:32:51 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:51 --> Config Class Initialized
INFO - 2016-02-27 20:32:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:32:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:32:51 --> Utf8 Class Initialized
INFO - 2016-02-27 20:32:51 --> URI Class Initialized
INFO - 2016-02-27 20:32:51 --> Router Class Initialized
INFO - 2016-02-27 20:32:51 --> Output Class Initialized
INFO - 2016-02-27 20:32:51 --> Security Class Initialized
DEBUG - 2016-02-27 20:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:32:51 --> Input Class Initialized
INFO - 2016-02-27 20:32:51 --> Language Class Initialized
INFO - 2016-02-27 20:32:51 --> Loader Class Initialized
INFO - 2016-02-27 20:32:51 --> Helper loaded: url_helper
INFO - 2016-02-27 20:32:51 --> Helper loaded: file_helper
INFO - 2016-02-27 20:32:51 --> Helper loaded: date_helper
INFO - 2016-02-27 20:32:51 --> Helper loaded: form_helper
INFO - 2016-02-27 20:32:51 --> Database Driver Class Initialized
INFO - 2016-02-27 20:32:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:32:52 --> Controller Class Initialized
INFO - 2016-02-27 20:32:52 --> Model Class Initialized
INFO - 2016-02-27 20:32:52 --> Model Class Initialized
INFO - 2016-02-27 20:32:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:32:52 --> Pagination Class Initialized
INFO - 2016-02-27 20:32:52 --> Helper loaded: text_helper
INFO - 2016-02-27 20:32:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:32:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:32:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:32:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:32:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:32:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:32:52 --> Final output sent to browser
DEBUG - 2016-02-27 23:32:52 --> Total execution time: 1.1963
INFO - 2016-02-27 20:33:52 --> Config Class Initialized
INFO - 2016-02-27 20:33:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:33:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:33:52 --> Utf8 Class Initialized
INFO - 2016-02-27 20:33:52 --> URI Class Initialized
INFO - 2016-02-27 20:33:52 --> Router Class Initialized
INFO - 2016-02-27 20:33:52 --> Output Class Initialized
INFO - 2016-02-27 20:33:52 --> Security Class Initialized
DEBUG - 2016-02-27 20:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:33:52 --> Input Class Initialized
INFO - 2016-02-27 20:33:52 --> Language Class Initialized
INFO - 2016-02-27 20:33:52 --> Loader Class Initialized
INFO - 2016-02-27 20:33:52 --> Helper loaded: url_helper
INFO - 2016-02-27 20:33:52 --> Helper loaded: file_helper
INFO - 2016-02-27 20:33:52 --> Helper loaded: date_helper
INFO - 2016-02-27 20:33:52 --> Helper loaded: form_helper
INFO - 2016-02-27 20:33:52 --> Database Driver Class Initialized
INFO - 2016-02-27 20:33:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:33:53 --> Controller Class Initialized
INFO - 2016-02-27 20:33:53 --> Model Class Initialized
INFO - 2016-02-27 20:33:53 --> Model Class Initialized
INFO - 2016-02-27 20:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:33:53 --> Pagination Class Initialized
INFO - 2016-02-27 20:33:53 --> Helper loaded: text_helper
INFO - 2016-02-27 20:33:53 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:33:53 --> Final output sent to browser
DEBUG - 2016-02-27 23:33:53 --> Total execution time: 1.1609
INFO - 2016-02-27 20:33:55 --> Config Class Initialized
INFO - 2016-02-27 20:33:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:33:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:33:55 --> Utf8 Class Initialized
INFO - 2016-02-27 20:33:55 --> URI Class Initialized
INFO - 2016-02-27 20:33:55 --> Router Class Initialized
INFO - 2016-02-27 20:33:55 --> Output Class Initialized
INFO - 2016-02-27 20:33:55 --> Security Class Initialized
DEBUG - 2016-02-27 20:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:33:55 --> Input Class Initialized
INFO - 2016-02-27 20:33:55 --> Language Class Initialized
INFO - 2016-02-27 20:33:55 --> Loader Class Initialized
INFO - 2016-02-27 20:33:55 --> Helper loaded: url_helper
INFO - 2016-02-27 20:33:55 --> Helper loaded: file_helper
INFO - 2016-02-27 20:33:55 --> Helper loaded: date_helper
INFO - 2016-02-27 20:33:55 --> Helper loaded: form_helper
INFO - 2016-02-27 20:33:55 --> Database Driver Class Initialized
INFO - 2016-02-27 20:33:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:33:56 --> Controller Class Initialized
INFO - 2016-02-27 20:33:56 --> Model Class Initialized
INFO - 2016-02-27 20:33:56 --> Model Class Initialized
INFO - 2016-02-27 20:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:33:56 --> Pagination Class Initialized
INFO - 2016-02-27 20:33:56 --> Helper loaded: text_helper
INFO - 2016-02-27 20:33:56 --> Helper loaded: cookie_helper
ERROR - 2016-02-27 23:33:56 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-27 23:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:33:56 --> Form Validation Class Initialized
INFO - 2016-02-27 23:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-27 23:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:33:56 --> Final output sent to browser
DEBUG - 2016-02-27 23:33:56 --> Total execution time: 1.2458
INFO - 2016-02-27 20:33:56 --> Config Class Initialized
INFO - 2016-02-27 20:33:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:33:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:33:56 --> Utf8 Class Initialized
INFO - 2016-02-27 20:33:56 --> URI Class Initialized
INFO - 2016-02-27 20:33:56 --> Router Class Initialized
INFO - 2016-02-27 20:33:56 --> Output Class Initialized
INFO - 2016-02-27 20:33:56 --> Security Class Initialized
DEBUG - 2016-02-27 20:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:33:56 --> Input Class Initialized
INFO - 2016-02-27 20:33:56 --> Language Class Initialized
INFO - 2016-02-27 20:33:56 --> Loader Class Initialized
INFO - 2016-02-27 20:33:56 --> Helper loaded: url_helper
INFO - 2016-02-27 20:33:56 --> Helper loaded: file_helper
INFO - 2016-02-27 20:33:56 --> Helper loaded: date_helper
INFO - 2016-02-27 20:33:56 --> Helper loaded: form_helper
INFO - 2016-02-27 20:33:56 --> Database Driver Class Initialized
INFO - 2016-02-27 20:33:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:33:57 --> Controller Class Initialized
INFO - 2016-02-27 20:33:57 --> Model Class Initialized
INFO - 2016-02-27 20:33:57 --> Model Class Initialized
INFO - 2016-02-27 20:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:33:57 --> Pagination Class Initialized
INFO - 2016-02-27 20:33:57 --> Helper loaded: text_helper
INFO - 2016-02-27 20:33:57 --> Helper loaded: cookie_helper
ERROR - 2016-02-27 23:33:57 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-27 23:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:33:57 --> Form Validation Class Initialized
INFO - 2016-02-27 23:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-27 23:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:33:57 --> Final output sent to browser
DEBUG - 2016-02-27 23:33:57 --> Total execution time: 1.2164
INFO - 2016-02-27 20:34:34 --> Config Class Initialized
INFO - 2016-02-27 20:34:34 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:34:34 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:34:34 --> Utf8 Class Initialized
INFO - 2016-02-27 20:34:34 --> URI Class Initialized
INFO - 2016-02-27 20:34:34 --> Router Class Initialized
INFO - 2016-02-27 20:34:34 --> Output Class Initialized
INFO - 2016-02-27 20:34:34 --> Security Class Initialized
DEBUG - 2016-02-27 20:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:34:34 --> Input Class Initialized
INFO - 2016-02-27 20:34:34 --> Language Class Initialized
INFO - 2016-02-27 20:34:34 --> Loader Class Initialized
INFO - 2016-02-27 20:34:34 --> Helper loaded: url_helper
INFO - 2016-02-27 20:34:34 --> Helper loaded: file_helper
INFO - 2016-02-27 20:34:34 --> Helper loaded: date_helper
INFO - 2016-02-27 20:34:34 --> Helper loaded: form_helper
INFO - 2016-02-27 20:34:34 --> Database Driver Class Initialized
INFO - 2016-02-27 20:34:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:34:35 --> Controller Class Initialized
INFO - 2016-02-27 20:34:35 --> Model Class Initialized
INFO - 2016-02-27 20:34:35 --> Model Class Initialized
INFO - 2016-02-27 20:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:34:35 --> Pagination Class Initialized
INFO - 2016-02-27 20:34:35 --> Helper loaded: text_helper
INFO - 2016-02-27 20:34:35 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:34:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:34:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-27 23:34:35 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 31
INFO - 2016-02-27 20:34:58 --> Config Class Initialized
INFO - 2016-02-27 20:34:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:34:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:34:58 --> Utf8 Class Initialized
INFO - 2016-02-27 20:34:58 --> URI Class Initialized
INFO - 2016-02-27 20:34:58 --> Router Class Initialized
INFO - 2016-02-27 20:34:58 --> Output Class Initialized
INFO - 2016-02-27 20:34:58 --> Security Class Initialized
DEBUG - 2016-02-27 20:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:34:58 --> Input Class Initialized
INFO - 2016-02-27 20:34:58 --> Language Class Initialized
INFO - 2016-02-27 20:34:58 --> Loader Class Initialized
INFO - 2016-02-27 20:34:58 --> Helper loaded: url_helper
INFO - 2016-02-27 20:34:58 --> Helper loaded: file_helper
INFO - 2016-02-27 20:34:58 --> Helper loaded: date_helper
INFO - 2016-02-27 20:34:58 --> Helper loaded: form_helper
INFO - 2016-02-27 20:34:58 --> Database Driver Class Initialized
INFO - 2016-02-27 20:34:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:34:59 --> Controller Class Initialized
INFO - 2016-02-27 20:34:59 --> Model Class Initialized
INFO - 2016-02-27 20:34:59 --> Model Class Initialized
INFO - 2016-02-27 20:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:34:59 --> Pagination Class Initialized
INFO - 2016-02-27 20:34:59 --> Helper loaded: text_helper
INFO - 2016-02-27 20:34:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:35:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:35:00 --> Final output sent to browser
DEBUG - 2016-02-27 23:35:00 --> Total execution time: 1.1022
INFO - 2016-02-27 20:35:05 --> Config Class Initialized
INFO - 2016-02-27 20:35:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:35:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:35:05 --> Utf8 Class Initialized
INFO - 2016-02-27 20:35:05 --> URI Class Initialized
INFO - 2016-02-27 20:35:05 --> Router Class Initialized
INFO - 2016-02-27 20:35:05 --> Output Class Initialized
INFO - 2016-02-27 20:35:05 --> Security Class Initialized
DEBUG - 2016-02-27 20:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:35:05 --> Input Class Initialized
INFO - 2016-02-27 20:35:05 --> Language Class Initialized
INFO - 2016-02-27 20:35:05 --> Loader Class Initialized
INFO - 2016-02-27 20:35:05 --> Helper loaded: url_helper
INFO - 2016-02-27 20:35:05 --> Helper loaded: file_helper
INFO - 2016-02-27 20:35:05 --> Helper loaded: date_helper
INFO - 2016-02-27 20:35:05 --> Helper loaded: form_helper
INFO - 2016-02-27 20:35:05 --> Database Driver Class Initialized
INFO - 2016-02-27 20:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:35:06 --> Controller Class Initialized
INFO - 2016-02-27 20:35:06 --> Model Class Initialized
INFO - 2016-02-27 20:35:06 --> Model Class Initialized
INFO - 2016-02-27 20:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:35:06 --> Pagination Class Initialized
INFO - 2016-02-27 20:35:06 --> Helper loaded: text_helper
INFO - 2016-02-27 20:35:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-27 23:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:35:06 --> Final output sent to browser
DEBUG - 2016-02-27 23:35:06 --> Total execution time: 1.1194
INFO - 2016-02-27 20:35:06 --> Config Class Initialized
INFO - 2016-02-27 20:35:06 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:35:06 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:35:06 --> Utf8 Class Initialized
INFO - 2016-02-27 20:35:06 --> URI Class Initialized
INFO - 2016-02-27 20:35:06 --> Router Class Initialized
INFO - 2016-02-27 20:35:06 --> Output Class Initialized
INFO - 2016-02-27 20:35:06 --> Security Class Initialized
DEBUG - 2016-02-27 20:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:35:06 --> Input Class Initialized
INFO - 2016-02-27 20:35:06 --> Language Class Initialized
INFO - 2016-02-27 20:35:06 --> Loader Class Initialized
INFO - 2016-02-27 20:35:06 --> Helper loaded: url_helper
INFO - 2016-02-27 20:35:06 --> Helper loaded: file_helper
INFO - 2016-02-27 20:35:06 --> Helper loaded: date_helper
INFO - 2016-02-27 20:35:06 --> Helper loaded: form_helper
INFO - 2016-02-27 20:35:06 --> Database Driver Class Initialized
INFO - 2016-02-27 20:35:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:35:07 --> Controller Class Initialized
INFO - 2016-02-27 20:35:07 --> Model Class Initialized
INFO - 2016-02-27 20:35:07 --> Model Class Initialized
INFO - 2016-02-27 20:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:35:07 --> Pagination Class Initialized
INFO - 2016-02-27 20:35:07 --> Helper loaded: text_helper
INFO - 2016-02-27 20:35:07 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-27 23:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:35:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:35:07 --> Final output sent to browser
DEBUG - 2016-02-27 23:35:07 --> Total execution time: 1.1565
INFO - 2016-02-27 20:37:56 --> Config Class Initialized
INFO - 2016-02-27 20:37:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:37:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:37:56 --> Utf8 Class Initialized
INFO - 2016-02-27 20:37:56 --> URI Class Initialized
INFO - 2016-02-27 20:37:56 --> Router Class Initialized
INFO - 2016-02-27 20:37:56 --> Output Class Initialized
INFO - 2016-02-27 20:37:56 --> Security Class Initialized
DEBUG - 2016-02-27 20:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:37:56 --> Input Class Initialized
INFO - 2016-02-27 20:37:56 --> Language Class Initialized
INFO - 2016-02-27 20:37:56 --> Loader Class Initialized
INFO - 2016-02-27 20:37:56 --> Helper loaded: url_helper
INFO - 2016-02-27 20:37:56 --> Helper loaded: file_helper
INFO - 2016-02-27 20:37:56 --> Helper loaded: date_helper
INFO - 2016-02-27 20:37:56 --> Helper loaded: form_helper
INFO - 2016-02-27 20:37:56 --> Database Driver Class Initialized
INFO - 2016-02-27 20:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:37:57 --> Controller Class Initialized
INFO - 2016-02-27 20:37:57 --> Model Class Initialized
INFO - 2016-02-27 20:37:57 --> Model Class Initialized
INFO - 2016-02-27 20:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:37:57 --> Pagination Class Initialized
INFO - 2016-02-27 20:37:57 --> Helper loaded: text_helper
INFO - 2016-02-27 20:37:57 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:37:57 --> Upload Class Initialized
INFO - 2016-02-27 23:37:57 --> Image Lib Class Initialized
DEBUG - 2016-02-27 23:37:57 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-27 23:37:57 --> Final output sent to browser
DEBUG - 2016-02-27 23:37:57 --> Total execution time: 1.5158
INFO - 2016-02-27 20:38:08 --> Config Class Initialized
INFO - 2016-02-27 20:38:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:38:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:38:08 --> Utf8 Class Initialized
INFO - 2016-02-27 20:38:08 --> URI Class Initialized
INFO - 2016-02-27 20:38:08 --> Router Class Initialized
INFO - 2016-02-27 20:38:08 --> Output Class Initialized
INFO - 2016-02-27 20:38:08 --> Security Class Initialized
DEBUG - 2016-02-27 20:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:38:08 --> Input Class Initialized
INFO - 2016-02-27 20:38:08 --> Language Class Initialized
INFO - 2016-02-27 20:38:08 --> Loader Class Initialized
INFO - 2016-02-27 20:38:08 --> Helper loaded: url_helper
INFO - 2016-02-27 20:38:08 --> Helper loaded: file_helper
INFO - 2016-02-27 20:38:08 --> Helper loaded: date_helper
INFO - 2016-02-27 20:38:08 --> Helper loaded: form_helper
INFO - 2016-02-27 20:38:08 --> Database Driver Class Initialized
INFO - 2016-02-27 20:38:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:38:09 --> Controller Class Initialized
INFO - 2016-02-27 20:38:09 --> Model Class Initialized
INFO - 2016-02-27 20:38:09 --> Model Class Initialized
INFO - 2016-02-27 20:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:38:09 --> Pagination Class Initialized
INFO - 2016-02-27 20:38:09 --> Helper loaded: text_helper
INFO - 2016-02-27 20:38:09 --> Helper loaded: cookie_helper
ERROR - 2016-02-27 23:38:09 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-27 23:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:38:09 --> Form Validation Class Initialized
INFO - 2016-02-27 23:38:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-27 20:38:09 --> Config Class Initialized
INFO - 2016-02-27 20:38:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:38:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:38:09 --> Utf8 Class Initialized
INFO - 2016-02-27 20:38:09 --> URI Class Initialized
INFO - 2016-02-27 20:38:09 --> Router Class Initialized
INFO - 2016-02-27 20:38:09 --> Output Class Initialized
INFO - 2016-02-27 20:38:09 --> Security Class Initialized
DEBUG - 2016-02-27 20:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:38:09 --> Input Class Initialized
INFO - 2016-02-27 20:38:09 --> Language Class Initialized
INFO - 2016-02-27 20:38:09 --> Loader Class Initialized
INFO - 2016-02-27 20:38:09 --> Helper loaded: url_helper
INFO - 2016-02-27 20:38:09 --> Helper loaded: file_helper
INFO - 2016-02-27 20:38:09 --> Helper loaded: date_helper
INFO - 2016-02-27 20:38:09 --> Helper loaded: form_helper
INFO - 2016-02-27 20:38:09 --> Database Driver Class Initialized
INFO - 2016-02-27 20:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:38:10 --> Controller Class Initialized
INFO - 2016-02-27 20:38:10 --> Model Class Initialized
INFO - 2016-02-27 20:38:10 --> Model Class Initialized
INFO - 2016-02-27 20:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:38:10 --> Pagination Class Initialized
INFO - 2016-02-27 20:38:10 --> Helper loaded: text_helper
INFO - 2016-02-27 20:38:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:38:10 --> Final output sent to browser
DEBUG - 2016-02-27 23:38:10 --> Total execution time: 1.1356
INFO - 2016-02-27 20:39:39 --> Config Class Initialized
INFO - 2016-02-27 20:39:39 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:39:39 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:39:39 --> Utf8 Class Initialized
INFO - 2016-02-27 20:39:39 --> URI Class Initialized
INFO - 2016-02-27 20:39:39 --> Router Class Initialized
INFO - 2016-02-27 20:39:39 --> Output Class Initialized
INFO - 2016-02-27 20:39:39 --> Security Class Initialized
DEBUG - 2016-02-27 20:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:39:39 --> Input Class Initialized
INFO - 2016-02-27 20:39:39 --> Language Class Initialized
INFO - 2016-02-27 20:39:39 --> Loader Class Initialized
INFO - 2016-02-27 20:39:39 --> Helper loaded: url_helper
INFO - 2016-02-27 20:39:39 --> Helper loaded: file_helper
INFO - 2016-02-27 20:39:39 --> Helper loaded: date_helper
INFO - 2016-02-27 20:39:39 --> Helper loaded: form_helper
INFO - 2016-02-27 20:39:39 --> Database Driver Class Initialized
INFO - 2016-02-27 20:39:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:39:40 --> Controller Class Initialized
INFO - 2016-02-27 20:39:40 --> Model Class Initialized
INFO - 2016-02-27 20:39:40 --> Model Class Initialized
INFO - 2016-02-27 20:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:39:40 --> Pagination Class Initialized
INFO - 2016-02-27 20:39:40 --> Helper loaded: text_helper
INFO - 2016-02-27 20:39:40 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:39:40 --> Final output sent to browser
DEBUG - 2016-02-27 23:39:40 --> Total execution time: 1.1343
INFO - 2016-02-27 20:41:28 --> Config Class Initialized
INFO - 2016-02-27 20:41:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:41:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:41:28 --> Utf8 Class Initialized
INFO - 2016-02-27 20:41:28 --> URI Class Initialized
INFO - 2016-02-27 20:41:28 --> Router Class Initialized
INFO - 2016-02-27 20:41:28 --> Output Class Initialized
INFO - 2016-02-27 20:41:28 --> Security Class Initialized
DEBUG - 2016-02-27 20:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:41:28 --> Input Class Initialized
INFO - 2016-02-27 20:41:28 --> Language Class Initialized
INFO - 2016-02-27 20:41:28 --> Loader Class Initialized
INFO - 2016-02-27 20:41:28 --> Helper loaded: url_helper
INFO - 2016-02-27 20:41:28 --> Helper loaded: file_helper
INFO - 2016-02-27 20:41:28 --> Helper loaded: date_helper
INFO - 2016-02-27 20:41:28 --> Helper loaded: form_helper
INFO - 2016-02-27 20:41:28 --> Database Driver Class Initialized
INFO - 2016-02-27 20:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:41:29 --> Controller Class Initialized
INFO - 2016-02-27 20:41:29 --> Model Class Initialized
INFO - 2016-02-27 20:41:29 --> Model Class Initialized
INFO - 2016-02-27 20:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:41:29 --> Pagination Class Initialized
INFO - 2016-02-27 20:41:29 --> Helper loaded: text_helper
INFO - 2016-02-27 20:41:29 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:41:29 --> Final output sent to browser
DEBUG - 2016-02-27 23:41:29 --> Total execution time: 1.1842
INFO - 2016-02-27 20:42:57 --> Config Class Initialized
INFO - 2016-02-27 20:42:57 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:42:57 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:42:57 --> Utf8 Class Initialized
INFO - 2016-02-27 20:42:57 --> URI Class Initialized
INFO - 2016-02-27 20:42:57 --> Router Class Initialized
INFO - 2016-02-27 20:42:57 --> Output Class Initialized
INFO - 2016-02-27 20:42:57 --> Security Class Initialized
DEBUG - 2016-02-27 20:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:42:57 --> Input Class Initialized
INFO - 2016-02-27 20:42:57 --> Language Class Initialized
INFO - 2016-02-27 20:42:57 --> Loader Class Initialized
INFO - 2016-02-27 20:42:57 --> Helper loaded: url_helper
INFO - 2016-02-27 20:42:57 --> Helper loaded: file_helper
INFO - 2016-02-27 20:42:57 --> Helper loaded: date_helper
INFO - 2016-02-27 20:42:57 --> Helper loaded: form_helper
INFO - 2016-02-27 20:42:57 --> Database Driver Class Initialized
INFO - 2016-02-27 20:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:42:58 --> Controller Class Initialized
INFO - 2016-02-27 20:42:58 --> Model Class Initialized
INFO - 2016-02-27 20:42:58 --> Model Class Initialized
INFO - 2016-02-27 20:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:42:58 --> Pagination Class Initialized
INFO - 2016-02-27 20:42:58 --> Helper loaded: text_helper
INFO - 2016-02-27 20:42:58 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:42:58 --> Final output sent to browser
DEBUG - 2016-02-27 23:42:58 --> Total execution time: 1.1638
INFO - 2016-02-27 20:50:28 --> Config Class Initialized
INFO - 2016-02-27 20:50:28 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:28 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:28 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:28 --> URI Class Initialized
INFO - 2016-02-27 20:50:28 --> Router Class Initialized
INFO - 2016-02-27 20:50:28 --> Output Class Initialized
INFO - 2016-02-27 20:50:28 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:28 --> Input Class Initialized
INFO - 2016-02-27 20:50:28 --> Language Class Initialized
INFO - 2016-02-27 20:50:28 --> Loader Class Initialized
INFO - 2016-02-27 20:50:28 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:28 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:28 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:28 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:28 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:29 --> Controller Class Initialized
INFO - 2016-02-27 20:50:29 --> Model Class Initialized
INFO - 2016-02-27 20:50:29 --> Model Class Initialized
INFO - 2016-02-27 20:50:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:29 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:29 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:29 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:50:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:29 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:29 --> Total execution time: 1.1582
INFO - 2016-02-27 20:50:38 --> Config Class Initialized
INFO - 2016-02-27 20:50:38 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:38 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:38 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:39 --> URI Class Initialized
INFO - 2016-02-27 20:50:39 --> Router Class Initialized
INFO - 2016-02-27 20:50:39 --> Output Class Initialized
INFO - 2016-02-27 20:50:39 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:39 --> Input Class Initialized
INFO - 2016-02-27 20:50:39 --> Language Class Initialized
INFO - 2016-02-27 20:50:39 --> Loader Class Initialized
INFO - 2016-02-27 20:50:39 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:39 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:39 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:39 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:39 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:40 --> Controller Class Initialized
INFO - 2016-02-27 20:50:40 --> Model Class Initialized
INFO - 2016-02-27 20:50:40 --> Model Class Initialized
INFO - 2016-02-27 20:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:40 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:40 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:40 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:40 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:40 --> Total execution time: 1.1687
INFO - 2016-02-27 20:50:43 --> Config Class Initialized
INFO - 2016-02-27 20:50:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:43 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:43 --> URI Class Initialized
DEBUG - 2016-02-27 20:50:43 --> No URI present. Default controller set.
INFO - 2016-02-27 20:50:43 --> Router Class Initialized
INFO - 2016-02-27 20:50:43 --> Output Class Initialized
INFO - 2016-02-27 20:50:43 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:43 --> Input Class Initialized
INFO - 2016-02-27 20:50:43 --> Language Class Initialized
INFO - 2016-02-27 20:50:43 --> Loader Class Initialized
INFO - 2016-02-27 20:50:43 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:43 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:43 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:43 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:43 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:44 --> Controller Class Initialized
INFO - 2016-02-27 20:50:44 --> Model Class Initialized
INFO - 2016-02-27 20:50:44 --> Model Class Initialized
INFO - 2016-02-27 20:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:44 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:44 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:44 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-27 23:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:44 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:44 --> Total execution time: 1.1112
INFO - 2016-02-27 20:50:45 --> Config Class Initialized
INFO - 2016-02-27 20:50:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:45 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:45 --> URI Class Initialized
INFO - 2016-02-27 20:50:45 --> Router Class Initialized
INFO - 2016-02-27 20:50:45 --> Output Class Initialized
INFO - 2016-02-27 20:50:45 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:45 --> Input Class Initialized
INFO - 2016-02-27 20:50:45 --> Language Class Initialized
INFO - 2016-02-27 20:50:45 --> Loader Class Initialized
INFO - 2016-02-27 20:50:45 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:45 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:45 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:45 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:45 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:46 --> Controller Class Initialized
INFO - 2016-02-27 20:50:46 --> Model Class Initialized
INFO - 2016-02-27 20:50:46 --> Model Class Initialized
INFO - 2016-02-27 20:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:46 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:46 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:50:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:46 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:46 --> Total execution time: 1.1018
INFO - 2016-02-27 20:50:48 --> Config Class Initialized
INFO - 2016-02-27 20:50:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:48 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:48 --> URI Class Initialized
INFO - 2016-02-27 20:50:48 --> Router Class Initialized
INFO - 2016-02-27 20:50:48 --> Output Class Initialized
INFO - 2016-02-27 20:50:48 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:48 --> Input Class Initialized
INFO - 2016-02-27 20:50:48 --> Language Class Initialized
INFO - 2016-02-27 20:50:48 --> Loader Class Initialized
INFO - 2016-02-27 20:50:48 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:48 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:48 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:48 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:48 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:49 --> Controller Class Initialized
INFO - 2016-02-27 20:50:49 --> Model Class Initialized
INFO - 2016-02-27 20:50:49 --> Model Class Initialized
INFO - 2016-02-27 20:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:49 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:49 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:49 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:49 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:49 --> Total execution time: 1.1093
INFO - 2016-02-27 20:50:51 --> Config Class Initialized
INFO - 2016-02-27 20:50:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:51 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:51 --> URI Class Initialized
INFO - 2016-02-27 20:50:51 --> Router Class Initialized
INFO - 2016-02-27 20:50:51 --> Output Class Initialized
INFO - 2016-02-27 20:50:51 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:51 --> Input Class Initialized
INFO - 2016-02-27 20:50:51 --> Language Class Initialized
INFO - 2016-02-27 20:50:51 --> Loader Class Initialized
INFO - 2016-02-27 20:50:51 --> Helper loaded: url_helper
INFO - 2016-02-27 20:50:51 --> Helper loaded: file_helper
INFO - 2016-02-27 20:50:51 --> Helper loaded: date_helper
INFO - 2016-02-27 20:50:51 --> Helper loaded: form_helper
INFO - 2016-02-27 20:50:51 --> Database Driver Class Initialized
INFO - 2016-02-27 20:50:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:50:52 --> Controller Class Initialized
INFO - 2016-02-27 20:50:52 --> Model Class Initialized
INFO - 2016-02-27 20:50:52 --> Model Class Initialized
INFO - 2016-02-27 20:50:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:50:52 --> Pagination Class Initialized
INFO - 2016-02-27 20:50:52 --> Helper loaded: text_helper
INFO - 2016-02-27 20:50:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-27 23:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-27 23:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:50:52 --> Final output sent to browser
DEBUG - 2016-02-27 23:50:52 --> Total execution time: 1.1950
INFO - 2016-02-27 20:50:52 --> Config Class Initialized
INFO - 2016-02-27 20:50:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:52 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:52 --> URI Class Initialized
INFO - 2016-02-27 20:50:52 --> Router Class Initialized
INFO - 2016-02-27 20:50:52 --> Output Class Initialized
INFO - 2016-02-27 20:50:52 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:52 --> Input Class Initialized
INFO - 2016-02-27 20:50:52 --> Language Class Initialized
ERROR - 2016-02-27 20:50:52 --> 404 Page Not Found: Static/user
INFO - 2016-02-27 20:50:52 --> Config Class Initialized
INFO - 2016-02-27 20:50:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:50:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:50:52 --> Utf8 Class Initialized
INFO - 2016-02-27 20:50:52 --> URI Class Initialized
INFO - 2016-02-27 20:50:52 --> Router Class Initialized
INFO - 2016-02-27 20:50:52 --> Output Class Initialized
INFO - 2016-02-27 20:50:52 --> Security Class Initialized
DEBUG - 2016-02-27 20:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:50:52 --> Input Class Initialized
INFO - 2016-02-27 20:50:52 --> Language Class Initialized
ERROR - 2016-02-27 20:50:52 --> 404 Page Not Found: Static/user
INFO - 2016-02-27 20:51:15 --> Config Class Initialized
INFO - 2016-02-27 20:51:15 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:51:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:51:16 --> Utf8 Class Initialized
INFO - 2016-02-27 20:51:16 --> URI Class Initialized
INFO - 2016-02-27 20:51:16 --> Router Class Initialized
INFO - 2016-02-27 20:51:16 --> Output Class Initialized
INFO - 2016-02-27 20:51:16 --> Security Class Initialized
DEBUG - 2016-02-27 20:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:51:16 --> Input Class Initialized
INFO - 2016-02-27 20:51:16 --> Language Class Initialized
INFO - 2016-02-27 20:51:16 --> Loader Class Initialized
INFO - 2016-02-27 20:51:16 --> Helper loaded: url_helper
INFO - 2016-02-27 20:51:16 --> Helper loaded: file_helper
INFO - 2016-02-27 20:51:16 --> Helper loaded: date_helper
INFO - 2016-02-27 20:51:16 --> Helper loaded: form_helper
INFO - 2016-02-27 20:51:16 --> Database Driver Class Initialized
INFO - 2016-02-27 20:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:51:17 --> Controller Class Initialized
INFO - 2016-02-27 20:51:17 --> Model Class Initialized
INFO - 2016-02-27 20:51:17 --> Model Class Initialized
INFO - 2016-02-27 20:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:51:17 --> Pagination Class Initialized
INFO - 2016-02-27 20:51:17 --> Helper loaded: text_helper
INFO - 2016-02-27 20:51:17 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:51:17 --> Final output sent to browser
DEBUG - 2016-02-27 23:51:17 --> Total execution time: 1.1149
INFO - 2016-02-27 20:56:23 --> Config Class Initialized
INFO - 2016-02-27 20:56:23 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:56:23 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:56:23 --> Utf8 Class Initialized
INFO - 2016-02-27 20:56:23 --> URI Class Initialized
INFO - 2016-02-27 20:56:23 --> Router Class Initialized
INFO - 2016-02-27 20:56:23 --> Output Class Initialized
INFO - 2016-02-27 20:56:23 --> Security Class Initialized
DEBUG - 2016-02-27 20:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:56:23 --> Input Class Initialized
INFO - 2016-02-27 20:56:23 --> Language Class Initialized
INFO - 2016-02-27 20:56:23 --> Loader Class Initialized
INFO - 2016-02-27 20:56:23 --> Helper loaded: url_helper
INFO - 2016-02-27 20:56:23 --> Helper loaded: file_helper
INFO - 2016-02-27 20:56:23 --> Helper loaded: date_helper
INFO - 2016-02-27 20:56:23 --> Helper loaded: form_helper
INFO - 2016-02-27 20:56:23 --> Database Driver Class Initialized
INFO - 2016-02-27 20:56:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:56:24 --> Controller Class Initialized
INFO - 2016-02-27 20:56:24 --> Model Class Initialized
INFO - 2016-02-27 20:56:24 --> Model Class Initialized
INFO - 2016-02-27 20:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:56:24 --> Pagination Class Initialized
INFO - 2016-02-27 20:56:24 --> Helper loaded: text_helper
INFO - 2016-02-27 20:56:24 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:56:24 --> Final output sent to browser
DEBUG - 2016-02-27 23:56:24 --> Total execution time: 1.1054
INFO - 2016-02-27 20:56:44 --> Config Class Initialized
INFO - 2016-02-27 20:56:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:56:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:56:44 --> Utf8 Class Initialized
INFO - 2016-02-27 20:56:44 --> URI Class Initialized
INFO - 2016-02-27 20:56:44 --> Router Class Initialized
INFO - 2016-02-27 20:56:44 --> Output Class Initialized
INFO - 2016-02-27 20:56:44 --> Security Class Initialized
DEBUG - 2016-02-27 20:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:56:44 --> Input Class Initialized
INFO - 2016-02-27 20:56:44 --> Language Class Initialized
INFO - 2016-02-27 20:56:44 --> Loader Class Initialized
INFO - 2016-02-27 20:56:44 --> Helper loaded: url_helper
INFO - 2016-02-27 20:56:44 --> Helper loaded: file_helper
INFO - 2016-02-27 20:56:44 --> Helper loaded: date_helper
INFO - 2016-02-27 20:56:44 --> Helper loaded: form_helper
INFO - 2016-02-27 20:56:44 --> Database Driver Class Initialized
INFO - 2016-02-27 20:56:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:56:45 --> Controller Class Initialized
INFO - 2016-02-27 20:56:45 --> Model Class Initialized
INFO - 2016-02-27 20:56:45 --> Model Class Initialized
INFO - 2016-02-27 20:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:56:45 --> Pagination Class Initialized
INFO - 2016-02-27 20:56:45 --> Helper loaded: text_helper
INFO - 2016-02-27 20:56:45 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:56:45 --> Final output sent to browser
DEBUG - 2016-02-27 23:56:45 --> Total execution time: 1.1104
INFO - 2016-02-27 20:57:08 --> Config Class Initialized
INFO - 2016-02-27 20:57:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:57:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:57:08 --> Utf8 Class Initialized
INFO - 2016-02-27 20:57:08 --> URI Class Initialized
INFO - 2016-02-27 20:57:08 --> Router Class Initialized
INFO - 2016-02-27 20:57:08 --> Output Class Initialized
INFO - 2016-02-27 20:57:08 --> Security Class Initialized
DEBUG - 2016-02-27 20:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:57:08 --> Input Class Initialized
INFO - 2016-02-27 20:57:08 --> Language Class Initialized
INFO - 2016-02-27 20:57:08 --> Loader Class Initialized
INFO - 2016-02-27 20:57:08 --> Helper loaded: url_helper
INFO - 2016-02-27 20:57:08 --> Helper loaded: file_helper
INFO - 2016-02-27 20:57:08 --> Helper loaded: date_helper
INFO - 2016-02-27 20:57:08 --> Helper loaded: form_helper
INFO - 2016-02-27 20:57:08 --> Database Driver Class Initialized
INFO - 2016-02-27 20:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:57:09 --> Controller Class Initialized
INFO - 2016-02-27 20:57:09 --> Model Class Initialized
INFO - 2016-02-27 20:57:09 --> Model Class Initialized
INFO - 2016-02-27 20:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:57:09 --> Pagination Class Initialized
INFO - 2016-02-27 20:57:09 --> Helper loaded: text_helper
INFO - 2016-02-27 20:57:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:57:09 --> Final output sent to browser
DEBUG - 2016-02-27 23:57:09 --> Total execution time: 1.1283
INFO - 2016-02-27 20:58:44 --> Config Class Initialized
INFO - 2016-02-27 20:58:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:58:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:58:44 --> Utf8 Class Initialized
INFO - 2016-02-27 20:58:44 --> URI Class Initialized
INFO - 2016-02-27 20:58:44 --> Router Class Initialized
INFO - 2016-02-27 20:58:44 --> Output Class Initialized
INFO - 2016-02-27 20:58:44 --> Security Class Initialized
DEBUG - 2016-02-27 20:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:58:44 --> Input Class Initialized
INFO - 2016-02-27 20:58:44 --> Language Class Initialized
INFO - 2016-02-27 20:58:44 --> Loader Class Initialized
INFO - 2016-02-27 20:58:44 --> Helper loaded: url_helper
INFO - 2016-02-27 20:58:44 --> Helper loaded: file_helper
INFO - 2016-02-27 20:58:44 --> Helper loaded: date_helper
INFO - 2016-02-27 20:58:44 --> Helper loaded: form_helper
INFO - 2016-02-27 20:58:44 --> Database Driver Class Initialized
INFO - 2016-02-27 20:58:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:58:45 --> Controller Class Initialized
INFO - 2016-02-27 20:58:45 --> Model Class Initialized
INFO - 2016-02-27 20:58:45 --> Model Class Initialized
INFO - 2016-02-27 20:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:58:45 --> Pagination Class Initialized
INFO - 2016-02-27 20:58:45 --> Helper loaded: text_helper
INFO - 2016-02-27 20:58:45 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:58:45 --> Final output sent to browser
DEBUG - 2016-02-27 23:58:45 --> Total execution time: 1.1173
INFO - 2016-02-27 20:59:21 --> Config Class Initialized
INFO - 2016-02-27 20:59:21 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:59:21 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:59:21 --> Utf8 Class Initialized
INFO - 2016-02-27 20:59:21 --> URI Class Initialized
INFO - 2016-02-27 20:59:21 --> Router Class Initialized
INFO - 2016-02-27 20:59:21 --> Output Class Initialized
INFO - 2016-02-27 20:59:21 --> Security Class Initialized
DEBUG - 2016-02-27 20:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:59:21 --> Input Class Initialized
INFO - 2016-02-27 20:59:21 --> Language Class Initialized
INFO - 2016-02-27 20:59:21 --> Loader Class Initialized
INFO - 2016-02-27 20:59:21 --> Helper loaded: url_helper
INFO - 2016-02-27 20:59:21 --> Helper loaded: file_helper
INFO - 2016-02-27 20:59:21 --> Helper loaded: date_helper
INFO - 2016-02-27 20:59:21 --> Helper loaded: form_helper
INFO - 2016-02-27 20:59:21 --> Database Driver Class Initialized
INFO - 2016-02-27 20:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:59:22 --> Controller Class Initialized
INFO - 2016-02-27 20:59:22 --> Model Class Initialized
INFO - 2016-02-27 20:59:22 --> Model Class Initialized
INFO - 2016-02-27 20:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:59:22 --> Pagination Class Initialized
INFO - 2016-02-27 20:59:22 --> Helper loaded: text_helper
INFO - 2016-02-27 20:59:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:59:22 --> Final output sent to browser
DEBUG - 2016-02-27 23:59:22 --> Total execution time: 1.1083
INFO - 2016-02-27 20:59:33 --> Config Class Initialized
INFO - 2016-02-27 20:59:33 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:59:33 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:59:33 --> Utf8 Class Initialized
INFO - 2016-02-27 20:59:33 --> URI Class Initialized
INFO - 2016-02-27 20:59:33 --> Router Class Initialized
INFO - 2016-02-27 20:59:33 --> Output Class Initialized
INFO - 2016-02-27 20:59:33 --> Security Class Initialized
DEBUG - 2016-02-27 20:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:59:33 --> Input Class Initialized
INFO - 2016-02-27 20:59:33 --> Language Class Initialized
INFO - 2016-02-27 20:59:33 --> Loader Class Initialized
INFO - 2016-02-27 20:59:33 --> Helper loaded: url_helper
INFO - 2016-02-27 20:59:33 --> Helper loaded: file_helper
INFO - 2016-02-27 20:59:33 --> Helper loaded: date_helper
INFO - 2016-02-27 20:59:33 --> Helper loaded: form_helper
INFO - 2016-02-27 20:59:33 --> Database Driver Class Initialized
INFO - 2016-02-27 20:59:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:59:34 --> Controller Class Initialized
INFO - 2016-02-27 20:59:34 --> Model Class Initialized
INFO - 2016-02-27 20:59:34 --> Model Class Initialized
INFO - 2016-02-27 20:59:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:59:34 --> Pagination Class Initialized
INFO - 2016-02-27 20:59:34 --> Helper loaded: text_helper
INFO - 2016-02-27 20:59:34 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:59:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:59:34 --> Final output sent to browser
DEBUG - 2016-02-27 23:59:34 --> Total execution time: 1.1349
INFO - 2016-02-27 20:59:51 --> Config Class Initialized
INFO - 2016-02-27 20:59:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 20:59:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 20:59:51 --> Utf8 Class Initialized
INFO - 2016-02-27 20:59:51 --> URI Class Initialized
INFO - 2016-02-27 20:59:51 --> Router Class Initialized
INFO - 2016-02-27 20:59:51 --> Output Class Initialized
INFO - 2016-02-27 20:59:51 --> Security Class Initialized
DEBUG - 2016-02-27 20:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 20:59:51 --> Input Class Initialized
INFO - 2016-02-27 20:59:51 --> Language Class Initialized
INFO - 2016-02-27 20:59:51 --> Loader Class Initialized
INFO - 2016-02-27 20:59:51 --> Helper loaded: url_helper
INFO - 2016-02-27 20:59:51 --> Helper loaded: file_helper
INFO - 2016-02-27 20:59:51 --> Helper loaded: date_helper
INFO - 2016-02-27 20:59:51 --> Helper loaded: form_helper
INFO - 2016-02-27 20:59:51 --> Database Driver Class Initialized
INFO - 2016-02-27 20:59:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 20:59:53 --> Controller Class Initialized
INFO - 2016-02-27 20:59:53 --> Model Class Initialized
INFO - 2016-02-27 20:59:53 --> Model Class Initialized
INFO - 2016-02-27 20:59:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 20:59:53 --> Pagination Class Initialized
INFO - 2016-02-27 20:59:53 --> Helper loaded: text_helper
INFO - 2016-02-27 20:59:53 --> Helper loaded: cookie_helper
INFO - 2016-02-27 23:59:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-27 23:59:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-27 23:59:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-27 23:59:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-27 23:59:53 --> Final output sent to browser
DEBUG - 2016-02-27 23:59:53 --> Total execution time: 1.1000
INFO - 2016-02-27 21:01:31 --> Config Class Initialized
INFO - 2016-02-27 21:01:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:01:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:01:31 --> Utf8 Class Initialized
INFO - 2016-02-27 21:01:31 --> URI Class Initialized
INFO - 2016-02-27 21:01:31 --> Router Class Initialized
INFO - 2016-02-27 21:01:31 --> Output Class Initialized
INFO - 2016-02-27 21:01:31 --> Security Class Initialized
DEBUG - 2016-02-27 21:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:01:31 --> Input Class Initialized
INFO - 2016-02-27 21:01:31 --> Language Class Initialized
INFO - 2016-02-27 21:01:31 --> Loader Class Initialized
INFO - 2016-02-27 21:01:31 --> Helper loaded: url_helper
INFO - 2016-02-27 21:01:31 --> Helper loaded: file_helper
INFO - 2016-02-27 21:01:31 --> Helper loaded: date_helper
INFO - 2016-02-27 21:01:31 --> Helper loaded: form_helper
INFO - 2016-02-27 21:01:31 --> Database Driver Class Initialized
INFO - 2016-02-27 21:01:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:01:32 --> Controller Class Initialized
INFO - 2016-02-27 21:01:32 --> Model Class Initialized
INFO - 2016-02-27 21:01:32 --> Model Class Initialized
INFO - 2016-02-27 21:01:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:01:32 --> Pagination Class Initialized
INFO - 2016-02-27 21:01:32 --> Helper loaded: text_helper
INFO - 2016-02-27 21:01:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:02:14 --> Config Class Initialized
INFO - 2016-02-27 21:02:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:02:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:02:14 --> Utf8 Class Initialized
INFO - 2016-02-27 21:02:14 --> URI Class Initialized
INFO - 2016-02-27 21:02:14 --> Router Class Initialized
INFO - 2016-02-27 21:02:14 --> Output Class Initialized
INFO - 2016-02-27 21:02:14 --> Security Class Initialized
DEBUG - 2016-02-27 21:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:02:14 --> Input Class Initialized
INFO - 2016-02-27 21:02:14 --> Language Class Initialized
INFO - 2016-02-27 21:02:14 --> Loader Class Initialized
INFO - 2016-02-27 21:02:14 --> Helper loaded: url_helper
INFO - 2016-02-27 21:02:14 --> Helper loaded: file_helper
INFO - 2016-02-27 21:02:14 --> Helper loaded: date_helper
INFO - 2016-02-27 21:02:14 --> Helper loaded: form_helper
INFO - 2016-02-27 21:02:14 --> Database Driver Class Initialized
INFO - 2016-02-27 21:02:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:02:15 --> Controller Class Initialized
INFO - 2016-02-27 21:02:15 --> Model Class Initialized
INFO - 2016-02-27 21:02:15 --> Model Class Initialized
INFO - 2016-02-27 21:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:02:15 --> Pagination Class Initialized
INFO - 2016-02-27 21:02:15 --> Helper loaded: text_helper
INFO - 2016-02-27 21:02:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:02:45 --> Config Class Initialized
INFO - 2016-02-27 21:02:45 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:02:45 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:02:45 --> Utf8 Class Initialized
INFO - 2016-02-27 21:02:45 --> URI Class Initialized
INFO - 2016-02-27 21:02:45 --> Router Class Initialized
INFO - 2016-02-27 21:02:45 --> Output Class Initialized
INFO - 2016-02-27 21:02:45 --> Security Class Initialized
DEBUG - 2016-02-27 21:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:02:45 --> Input Class Initialized
INFO - 2016-02-27 21:02:45 --> Language Class Initialized
INFO - 2016-02-27 21:02:45 --> Loader Class Initialized
INFO - 2016-02-27 21:02:45 --> Helper loaded: url_helper
INFO - 2016-02-27 21:02:45 --> Helper loaded: file_helper
INFO - 2016-02-27 21:02:45 --> Helper loaded: date_helper
INFO - 2016-02-27 21:02:45 --> Helper loaded: form_helper
INFO - 2016-02-27 21:02:45 --> Database Driver Class Initialized
INFO - 2016-02-27 21:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:02:46 --> Controller Class Initialized
INFO - 2016-02-27 21:02:46 --> Model Class Initialized
INFO - 2016-02-27 21:02:46 --> Model Class Initialized
INFO - 2016-02-27 21:02:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:02:46 --> Pagination Class Initialized
INFO - 2016-02-27 21:02:46 --> Helper loaded: text_helper
INFO - 2016-02-27 21:02:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:06:56 --> Config Class Initialized
INFO - 2016-02-27 21:06:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:06:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:06:56 --> Utf8 Class Initialized
INFO - 2016-02-27 21:06:56 --> URI Class Initialized
INFO - 2016-02-27 21:06:56 --> Router Class Initialized
INFO - 2016-02-27 21:06:56 --> Output Class Initialized
INFO - 2016-02-27 21:06:56 --> Security Class Initialized
DEBUG - 2016-02-27 21:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:06:56 --> Input Class Initialized
INFO - 2016-02-27 21:06:56 --> Language Class Initialized
INFO - 2016-02-27 21:06:56 --> Loader Class Initialized
INFO - 2016-02-27 21:06:56 --> Helper loaded: url_helper
INFO - 2016-02-27 21:06:56 --> Helper loaded: file_helper
INFO - 2016-02-27 21:06:56 --> Helper loaded: date_helper
INFO - 2016-02-27 21:06:56 --> Helper loaded: form_helper
INFO - 2016-02-27 21:06:56 --> Database Driver Class Initialized
INFO - 2016-02-27 21:06:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:06:57 --> Controller Class Initialized
INFO - 2016-02-27 21:06:57 --> Model Class Initialized
INFO - 2016-02-27 21:06:57 --> Model Class Initialized
INFO - 2016-02-27 21:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:06:57 --> Pagination Class Initialized
INFO - 2016-02-27 21:06:57 --> Helper loaded: text_helper
INFO - 2016-02-27 21:06:57 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:08:08 --> Config Class Initialized
INFO - 2016-02-27 21:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:08:08 --> Utf8 Class Initialized
INFO - 2016-02-27 21:08:08 --> URI Class Initialized
INFO - 2016-02-27 21:08:08 --> Router Class Initialized
INFO - 2016-02-27 21:08:08 --> Output Class Initialized
INFO - 2016-02-27 21:08:08 --> Security Class Initialized
DEBUG - 2016-02-27 21:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:08:08 --> Input Class Initialized
INFO - 2016-02-27 21:08:08 --> Language Class Initialized
INFO - 2016-02-27 21:08:08 --> Loader Class Initialized
INFO - 2016-02-27 21:08:08 --> Helper loaded: url_helper
INFO - 2016-02-27 21:08:08 --> Helper loaded: file_helper
INFO - 2016-02-27 21:08:09 --> Helper loaded: date_helper
INFO - 2016-02-27 21:08:09 --> Helper loaded: form_helper
INFO - 2016-02-27 21:08:09 --> Database Driver Class Initialized
INFO - 2016-02-27 21:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:08:10 --> Controller Class Initialized
INFO - 2016-02-27 21:08:10 --> Model Class Initialized
INFO - 2016-02-27 21:08:10 --> Model Class Initialized
INFO - 2016-02-27 21:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:08:10 --> Pagination Class Initialized
INFO - 2016-02-27 21:08:10 --> Helper loaded: text_helper
INFO - 2016-02-27 21:08:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:08:29 --> Config Class Initialized
INFO - 2016-02-27 21:08:29 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:08:29 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:08:29 --> Utf8 Class Initialized
INFO - 2016-02-27 21:08:29 --> URI Class Initialized
INFO - 2016-02-27 21:08:29 --> Router Class Initialized
INFO - 2016-02-27 21:08:29 --> Output Class Initialized
INFO - 2016-02-27 21:08:29 --> Security Class Initialized
DEBUG - 2016-02-27 21:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:08:29 --> Input Class Initialized
INFO - 2016-02-27 21:08:29 --> Language Class Initialized
INFO - 2016-02-27 21:08:29 --> Loader Class Initialized
INFO - 2016-02-27 21:08:29 --> Helper loaded: url_helper
INFO - 2016-02-27 21:08:29 --> Helper loaded: file_helper
INFO - 2016-02-27 21:08:29 --> Helper loaded: date_helper
INFO - 2016-02-27 21:08:30 --> Helper loaded: form_helper
INFO - 2016-02-27 21:08:30 --> Database Driver Class Initialized
INFO - 2016-02-27 21:08:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:08:31 --> Controller Class Initialized
INFO - 2016-02-27 21:08:31 --> Model Class Initialized
INFO - 2016-02-27 21:08:31 --> Model Class Initialized
INFO - 2016-02-27 21:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:08:31 --> Pagination Class Initialized
INFO - 2016-02-27 21:08:31 --> Helper loaded: text_helper
INFO - 2016-02-27 21:08:31 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:10:00 --> Config Class Initialized
INFO - 2016-02-27 21:10:00 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:10:00 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:10:00 --> Utf8 Class Initialized
INFO - 2016-02-27 21:10:00 --> URI Class Initialized
INFO - 2016-02-27 21:10:00 --> Router Class Initialized
INFO - 2016-02-27 21:10:00 --> Output Class Initialized
INFO - 2016-02-27 21:10:00 --> Security Class Initialized
DEBUG - 2016-02-27 21:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:10:00 --> Input Class Initialized
INFO - 2016-02-27 21:10:00 --> Language Class Initialized
INFO - 2016-02-27 21:10:00 --> Loader Class Initialized
INFO - 2016-02-27 21:10:00 --> Helper loaded: url_helper
INFO - 2016-02-27 21:10:00 --> Helper loaded: file_helper
INFO - 2016-02-27 21:10:00 --> Helper loaded: date_helper
INFO - 2016-02-27 21:10:00 --> Helper loaded: form_helper
INFO - 2016-02-27 21:10:00 --> Database Driver Class Initialized
INFO - 2016-02-27 21:10:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:10:01 --> Controller Class Initialized
INFO - 2016-02-27 21:10:01 --> Model Class Initialized
INFO - 2016-02-27 21:10:01 --> Model Class Initialized
INFO - 2016-02-27 21:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:10:01 --> Pagination Class Initialized
INFO - 2016-02-27 21:10:01 --> Helper loaded: text_helper
INFO - 2016-02-27 21:10:01 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:10:19 --> Config Class Initialized
INFO - 2016-02-27 21:10:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:10:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:10:19 --> Utf8 Class Initialized
INFO - 2016-02-27 21:10:19 --> URI Class Initialized
INFO - 2016-02-27 21:10:19 --> Router Class Initialized
INFO - 2016-02-27 21:10:19 --> Output Class Initialized
INFO - 2016-02-27 21:10:19 --> Security Class Initialized
DEBUG - 2016-02-27 21:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:10:19 --> Input Class Initialized
INFO - 2016-02-27 21:10:19 --> Language Class Initialized
INFO - 2016-02-27 21:10:19 --> Loader Class Initialized
INFO - 2016-02-27 21:10:19 --> Helper loaded: url_helper
INFO - 2016-02-27 21:10:19 --> Helper loaded: file_helper
INFO - 2016-02-27 21:10:19 --> Helper loaded: date_helper
INFO - 2016-02-27 21:10:19 --> Helper loaded: form_helper
INFO - 2016-02-27 21:10:19 --> Database Driver Class Initialized
INFO - 2016-02-27 21:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:10:20 --> Controller Class Initialized
INFO - 2016-02-27 21:10:20 --> Model Class Initialized
INFO - 2016-02-27 21:10:20 --> Model Class Initialized
INFO - 2016-02-27 21:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:10:20 --> Pagination Class Initialized
INFO - 2016-02-27 21:10:20 --> Helper loaded: text_helper
INFO - 2016-02-27 21:10:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:10:22 --> Config Class Initialized
INFO - 2016-02-27 21:10:22 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:10:22 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:10:22 --> Utf8 Class Initialized
INFO - 2016-02-27 21:10:22 --> URI Class Initialized
INFO - 2016-02-27 21:10:22 --> Router Class Initialized
INFO - 2016-02-27 21:10:22 --> Output Class Initialized
INFO - 2016-02-27 21:10:22 --> Security Class Initialized
DEBUG - 2016-02-27 21:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:10:22 --> Input Class Initialized
INFO - 2016-02-27 21:10:22 --> Language Class Initialized
INFO - 2016-02-27 21:10:22 --> Loader Class Initialized
INFO - 2016-02-27 21:10:22 --> Helper loaded: url_helper
INFO - 2016-02-27 21:10:22 --> Helper loaded: file_helper
INFO - 2016-02-27 21:10:22 --> Helper loaded: date_helper
INFO - 2016-02-27 21:10:22 --> Helper loaded: form_helper
INFO - 2016-02-27 21:10:22 --> Database Driver Class Initialized
INFO - 2016-02-27 21:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:10:23 --> Controller Class Initialized
INFO - 2016-02-27 21:10:23 --> Model Class Initialized
INFO - 2016-02-27 21:10:23 --> Model Class Initialized
INFO - 2016-02-27 21:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:10:23 --> Pagination Class Initialized
INFO - 2016-02-27 21:10:23 --> Helper loaded: text_helper
INFO - 2016-02-27 21:10:23 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:10:24 --> Config Class Initialized
INFO - 2016-02-27 21:10:24 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:10:24 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:10:24 --> Utf8 Class Initialized
INFO - 2016-02-27 21:10:24 --> URI Class Initialized
INFO - 2016-02-27 21:10:24 --> Router Class Initialized
INFO - 2016-02-27 21:10:24 --> Output Class Initialized
INFO - 2016-02-27 21:10:24 --> Security Class Initialized
DEBUG - 2016-02-27 21:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:10:24 --> Input Class Initialized
INFO - 2016-02-27 21:10:24 --> Language Class Initialized
INFO - 2016-02-27 21:10:24 --> Loader Class Initialized
INFO - 2016-02-27 21:10:24 --> Helper loaded: url_helper
INFO - 2016-02-27 21:10:24 --> Helper loaded: file_helper
INFO - 2016-02-27 21:10:24 --> Helper loaded: date_helper
INFO - 2016-02-27 21:10:24 --> Helper loaded: form_helper
INFO - 2016-02-27 21:10:24 --> Database Driver Class Initialized
INFO - 2016-02-27 21:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:10:25 --> Controller Class Initialized
INFO - 2016-02-27 21:10:25 --> Model Class Initialized
INFO - 2016-02-27 21:10:25 --> Model Class Initialized
INFO - 2016-02-27 21:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:10:25 --> Pagination Class Initialized
INFO - 2016-02-27 21:10:25 --> Helper loaded: text_helper
INFO - 2016-02-27 21:10:25 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:14:55 --> Config Class Initialized
INFO - 2016-02-27 21:14:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:14:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:14:55 --> Utf8 Class Initialized
INFO - 2016-02-27 21:14:55 --> URI Class Initialized
INFO - 2016-02-27 21:14:55 --> Router Class Initialized
INFO - 2016-02-27 21:14:55 --> Output Class Initialized
INFO - 2016-02-27 21:14:55 --> Security Class Initialized
DEBUG - 2016-02-27 21:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:14:55 --> Input Class Initialized
INFO - 2016-02-27 21:14:55 --> Language Class Initialized
INFO - 2016-02-27 21:14:55 --> Loader Class Initialized
INFO - 2016-02-27 21:14:55 --> Helper loaded: url_helper
INFO - 2016-02-27 21:14:55 --> Helper loaded: file_helper
INFO - 2016-02-27 21:14:55 --> Helper loaded: date_helper
INFO - 2016-02-27 21:14:55 --> Helper loaded: form_helper
INFO - 2016-02-27 21:14:55 --> Database Driver Class Initialized
INFO - 2016-02-27 21:14:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:14:56 --> Controller Class Initialized
INFO - 2016-02-27 21:14:56 --> Model Class Initialized
INFO - 2016-02-27 21:14:56 --> Model Class Initialized
INFO - 2016-02-27 21:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:14:56 --> Pagination Class Initialized
INFO - 2016-02-27 21:14:56 --> Helper loaded: text_helper
INFO - 2016-02-27 21:14:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:21:42 --> Config Class Initialized
INFO - 2016-02-27 21:21:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:21:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:21:42 --> Utf8 Class Initialized
INFO - 2016-02-27 21:21:42 --> URI Class Initialized
INFO - 2016-02-27 21:21:42 --> Router Class Initialized
INFO - 2016-02-27 21:21:42 --> Output Class Initialized
INFO - 2016-02-27 21:21:42 --> Security Class Initialized
DEBUG - 2016-02-27 21:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:21:42 --> Input Class Initialized
INFO - 2016-02-27 21:21:42 --> Language Class Initialized
INFO - 2016-02-27 21:21:42 --> Loader Class Initialized
INFO - 2016-02-27 21:21:42 --> Helper loaded: url_helper
INFO - 2016-02-27 21:21:42 --> Helper loaded: file_helper
INFO - 2016-02-27 21:21:42 --> Helper loaded: date_helper
INFO - 2016-02-27 21:21:42 --> Helper loaded: form_helper
INFO - 2016-02-27 21:21:42 --> Database Driver Class Initialized
INFO - 2016-02-27 21:21:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:21:43 --> Controller Class Initialized
INFO - 2016-02-27 21:21:43 --> Model Class Initialized
INFO - 2016-02-27 21:21:43 --> Model Class Initialized
INFO - 2016-02-27 21:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:21:43 --> Pagination Class Initialized
INFO - 2016-02-27 21:21:43 --> Helper loaded: text_helper
INFO - 2016-02-27 21:21:43 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:22:14 --> Config Class Initialized
INFO - 2016-02-27 21:22:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:22:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:22:14 --> Utf8 Class Initialized
INFO - 2016-02-27 21:22:14 --> URI Class Initialized
INFO - 2016-02-27 21:22:14 --> Router Class Initialized
INFO - 2016-02-27 21:22:14 --> Output Class Initialized
INFO - 2016-02-27 21:22:14 --> Security Class Initialized
DEBUG - 2016-02-27 21:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:22:14 --> Input Class Initialized
INFO - 2016-02-27 21:22:14 --> Language Class Initialized
INFO - 2016-02-27 21:22:14 --> Loader Class Initialized
INFO - 2016-02-27 21:22:14 --> Helper loaded: url_helper
INFO - 2016-02-27 21:22:14 --> Helper loaded: file_helper
INFO - 2016-02-27 21:22:14 --> Helper loaded: date_helper
INFO - 2016-02-27 21:22:14 --> Helper loaded: form_helper
INFO - 2016-02-27 21:22:14 --> Database Driver Class Initialized
INFO - 2016-02-27 21:22:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:22:15 --> Controller Class Initialized
INFO - 2016-02-27 21:22:15 --> Model Class Initialized
INFO - 2016-02-27 21:22:15 --> Model Class Initialized
INFO - 2016-02-27 21:22:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:22:15 --> Pagination Class Initialized
INFO - 2016-02-27 21:22:15 --> Helper loaded: text_helper
INFO - 2016-02-27 21:22:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:22:27 --> Config Class Initialized
INFO - 2016-02-27 21:22:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:22:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:22:27 --> Utf8 Class Initialized
INFO - 2016-02-27 21:22:27 --> URI Class Initialized
INFO - 2016-02-27 21:22:27 --> Router Class Initialized
INFO - 2016-02-27 21:22:27 --> Output Class Initialized
INFO - 2016-02-27 21:22:27 --> Security Class Initialized
DEBUG - 2016-02-27 21:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:22:27 --> Input Class Initialized
INFO - 2016-02-27 21:22:27 --> Language Class Initialized
INFO - 2016-02-27 21:22:27 --> Loader Class Initialized
INFO - 2016-02-27 21:22:27 --> Helper loaded: url_helper
INFO - 2016-02-27 21:22:27 --> Helper loaded: file_helper
INFO - 2016-02-27 21:22:27 --> Helper loaded: date_helper
INFO - 2016-02-27 21:22:27 --> Helper loaded: form_helper
INFO - 2016-02-27 21:22:27 --> Database Driver Class Initialized
INFO - 2016-02-27 21:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:22:28 --> Controller Class Initialized
INFO - 2016-02-27 21:22:28 --> Model Class Initialized
INFO - 2016-02-27 21:22:28 --> Model Class Initialized
INFO - 2016-02-27 21:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:22:28 --> Pagination Class Initialized
INFO - 2016-02-27 21:22:28 --> Helper loaded: text_helper
INFO - 2016-02-27 21:22:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:22:30 --> Config Class Initialized
INFO - 2016-02-27 21:22:30 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:22:30 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:22:30 --> Utf8 Class Initialized
INFO - 2016-02-27 21:22:30 --> URI Class Initialized
INFO - 2016-02-27 21:22:30 --> Router Class Initialized
INFO - 2016-02-27 21:22:30 --> Output Class Initialized
INFO - 2016-02-27 21:22:30 --> Security Class Initialized
DEBUG - 2016-02-27 21:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:22:30 --> Input Class Initialized
INFO - 2016-02-27 21:22:30 --> Language Class Initialized
INFO - 2016-02-27 21:22:30 --> Loader Class Initialized
INFO - 2016-02-27 21:22:30 --> Helper loaded: url_helper
INFO - 2016-02-27 21:22:30 --> Helper loaded: file_helper
INFO - 2016-02-27 21:22:30 --> Helper loaded: date_helper
INFO - 2016-02-27 21:22:30 --> Helper loaded: form_helper
INFO - 2016-02-27 21:22:30 --> Database Driver Class Initialized
INFO - 2016-02-27 21:22:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:22:31 --> Controller Class Initialized
INFO - 2016-02-27 21:22:31 --> Model Class Initialized
INFO - 2016-02-27 21:22:31 --> Model Class Initialized
INFO - 2016-02-27 21:22:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:22:31 --> Pagination Class Initialized
INFO - 2016-02-27 21:22:31 --> Helper loaded: text_helper
INFO - 2016-02-27 21:22:31 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:22:32 --> Config Class Initialized
INFO - 2016-02-27 21:22:32 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:22:32 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:22:32 --> Utf8 Class Initialized
INFO - 2016-02-27 21:22:32 --> URI Class Initialized
INFO - 2016-02-27 21:22:32 --> Router Class Initialized
INFO - 2016-02-27 21:22:32 --> Output Class Initialized
INFO - 2016-02-27 21:22:32 --> Security Class Initialized
DEBUG - 2016-02-27 21:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:22:32 --> Input Class Initialized
INFO - 2016-02-27 21:22:32 --> Language Class Initialized
INFO - 2016-02-27 21:22:32 --> Loader Class Initialized
INFO - 2016-02-27 21:22:32 --> Helper loaded: url_helper
INFO - 2016-02-27 21:22:32 --> Helper loaded: file_helper
INFO - 2016-02-27 21:22:32 --> Helper loaded: date_helper
INFO - 2016-02-27 21:22:32 --> Helper loaded: form_helper
INFO - 2016-02-27 21:22:32 --> Database Driver Class Initialized
INFO - 2016-02-27 21:22:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:22:33 --> Controller Class Initialized
INFO - 2016-02-27 21:22:33 --> Model Class Initialized
INFO - 2016-02-27 21:22:33 --> Model Class Initialized
INFO - 2016-02-27 21:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:22:33 --> Pagination Class Initialized
INFO - 2016-02-27 21:22:33 --> Helper loaded: text_helper
INFO - 2016-02-27 21:22:33 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:23:39 --> Config Class Initialized
INFO - 2016-02-27 21:23:39 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:23:39 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:23:39 --> Utf8 Class Initialized
INFO - 2016-02-27 21:23:39 --> URI Class Initialized
INFO - 2016-02-27 21:23:39 --> Router Class Initialized
INFO - 2016-02-27 21:23:39 --> Output Class Initialized
INFO - 2016-02-27 21:23:39 --> Security Class Initialized
DEBUG - 2016-02-27 21:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:23:39 --> Input Class Initialized
INFO - 2016-02-27 21:23:39 --> Language Class Initialized
INFO - 2016-02-27 21:23:39 --> Loader Class Initialized
INFO - 2016-02-27 21:23:39 --> Helper loaded: url_helper
INFO - 2016-02-27 21:23:39 --> Helper loaded: file_helper
INFO - 2016-02-27 21:23:39 --> Helper loaded: date_helper
INFO - 2016-02-27 21:23:39 --> Helper loaded: form_helper
INFO - 2016-02-27 21:23:39 --> Database Driver Class Initialized
INFO - 2016-02-27 21:23:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:23:40 --> Controller Class Initialized
INFO - 2016-02-27 21:23:40 --> Model Class Initialized
INFO - 2016-02-27 21:23:40 --> Model Class Initialized
INFO - 2016-02-27 21:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:23:40 --> Pagination Class Initialized
INFO - 2016-02-27 21:23:40 --> Helper loaded: text_helper
INFO - 2016-02-27 21:23:40 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:23:51 --> Config Class Initialized
INFO - 2016-02-27 21:23:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:23:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:23:51 --> Utf8 Class Initialized
INFO - 2016-02-27 21:23:51 --> URI Class Initialized
DEBUG - 2016-02-27 21:23:51 --> No URI present. Default controller set.
INFO - 2016-02-27 21:23:51 --> Router Class Initialized
INFO - 2016-02-27 21:23:51 --> Output Class Initialized
INFO - 2016-02-27 21:23:51 --> Security Class Initialized
DEBUG - 2016-02-27 21:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:23:51 --> Input Class Initialized
INFO - 2016-02-27 21:23:51 --> Language Class Initialized
INFO - 2016-02-27 21:23:51 --> Loader Class Initialized
INFO - 2016-02-27 21:23:51 --> Helper loaded: url_helper
INFO - 2016-02-27 21:23:51 --> Helper loaded: file_helper
INFO - 2016-02-27 21:23:51 --> Helper loaded: date_helper
INFO - 2016-02-27 21:23:51 --> Helper loaded: form_helper
INFO - 2016-02-27 21:23:51 --> Database Driver Class Initialized
INFO - 2016-02-27 21:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:23:52 --> Controller Class Initialized
INFO - 2016-02-27 21:23:52 --> Model Class Initialized
INFO - 2016-02-27 21:23:52 --> Model Class Initialized
INFO - 2016-02-27 21:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:23:52 --> Pagination Class Initialized
INFO - 2016-02-27 21:23:52 --> Helper loaded: text_helper
INFO - 2016-02-27 21:23:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:23:54 --> Config Class Initialized
INFO - 2016-02-27 21:23:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:23:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:23:54 --> Utf8 Class Initialized
INFO - 2016-02-27 21:23:54 --> URI Class Initialized
INFO - 2016-02-27 21:23:54 --> Router Class Initialized
INFO - 2016-02-27 21:23:54 --> Output Class Initialized
INFO - 2016-02-27 21:23:54 --> Security Class Initialized
DEBUG - 2016-02-27 21:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:23:54 --> Input Class Initialized
INFO - 2016-02-27 21:23:54 --> Language Class Initialized
INFO - 2016-02-27 21:23:54 --> Loader Class Initialized
INFO - 2016-02-27 21:23:54 --> Helper loaded: url_helper
INFO - 2016-02-27 21:23:54 --> Helper loaded: file_helper
INFO - 2016-02-27 21:23:54 --> Helper loaded: date_helper
INFO - 2016-02-27 21:23:54 --> Helper loaded: form_helper
INFO - 2016-02-27 21:23:54 --> Database Driver Class Initialized
INFO - 2016-02-27 21:23:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:23:55 --> Controller Class Initialized
INFO - 2016-02-27 21:23:55 --> Model Class Initialized
INFO - 2016-02-27 21:23:55 --> Model Class Initialized
INFO - 2016-02-27 21:23:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:23:55 --> Pagination Class Initialized
INFO - 2016-02-27 21:23:55 --> Helper loaded: text_helper
INFO - 2016-02-27 21:23:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:23:58 --> Config Class Initialized
INFO - 2016-02-27 21:23:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:23:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:23:58 --> Utf8 Class Initialized
INFO - 2016-02-27 21:23:58 --> URI Class Initialized
INFO - 2016-02-27 21:23:58 --> Router Class Initialized
INFO - 2016-02-27 21:23:58 --> Output Class Initialized
INFO - 2016-02-27 21:23:58 --> Security Class Initialized
DEBUG - 2016-02-27 21:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:23:58 --> Input Class Initialized
INFO - 2016-02-27 21:23:58 --> Language Class Initialized
INFO - 2016-02-27 21:23:58 --> Loader Class Initialized
INFO - 2016-02-27 21:23:58 --> Helper loaded: url_helper
INFO - 2016-02-27 21:23:58 --> Helper loaded: file_helper
INFO - 2016-02-27 21:23:58 --> Helper loaded: date_helper
INFO - 2016-02-27 21:23:58 --> Helper loaded: form_helper
INFO - 2016-02-27 21:23:58 --> Database Driver Class Initialized
INFO - 2016-02-27 21:23:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:23:59 --> Controller Class Initialized
INFO - 2016-02-27 21:23:59 --> Model Class Initialized
INFO - 2016-02-27 21:23:59 --> Model Class Initialized
INFO - 2016-02-27 21:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:23:59 --> Pagination Class Initialized
INFO - 2016-02-27 21:23:59 --> Helper loaded: text_helper
INFO - 2016-02-27 21:23:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:24:01 --> Config Class Initialized
INFO - 2016-02-27 21:24:01 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:24:01 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:24:01 --> Utf8 Class Initialized
INFO - 2016-02-27 21:24:01 --> URI Class Initialized
INFO - 2016-02-27 21:24:01 --> Router Class Initialized
INFO - 2016-02-27 21:24:01 --> Output Class Initialized
INFO - 2016-02-27 21:24:01 --> Security Class Initialized
DEBUG - 2016-02-27 21:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:24:01 --> Input Class Initialized
INFO - 2016-02-27 21:24:01 --> Language Class Initialized
INFO - 2016-02-27 21:24:01 --> Loader Class Initialized
INFO - 2016-02-27 21:24:01 --> Helper loaded: url_helper
INFO - 2016-02-27 21:24:01 --> Helper loaded: file_helper
INFO - 2016-02-27 21:24:01 --> Helper loaded: date_helper
INFO - 2016-02-27 21:24:01 --> Helper loaded: form_helper
INFO - 2016-02-27 21:24:02 --> Database Driver Class Initialized
INFO - 2016-02-27 21:24:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:24:03 --> Controller Class Initialized
INFO - 2016-02-27 21:24:03 --> Model Class Initialized
INFO - 2016-02-27 21:24:03 --> Model Class Initialized
INFO - 2016-02-27 21:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:24:03 --> Pagination Class Initialized
INFO - 2016-02-27 21:24:03 --> Helper loaded: text_helper
INFO - 2016-02-27 21:24:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:24:06 --> Config Class Initialized
INFO - 2016-02-27 21:24:06 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:24:06 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:24:06 --> Utf8 Class Initialized
INFO - 2016-02-27 21:24:06 --> URI Class Initialized
INFO - 2016-02-27 21:24:06 --> Router Class Initialized
INFO - 2016-02-27 21:24:06 --> Output Class Initialized
INFO - 2016-02-27 21:24:06 --> Security Class Initialized
DEBUG - 2016-02-27 21:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:24:06 --> Input Class Initialized
INFO - 2016-02-27 21:24:06 --> Language Class Initialized
INFO - 2016-02-27 21:24:06 --> Loader Class Initialized
INFO - 2016-02-27 21:24:06 --> Helper loaded: url_helper
INFO - 2016-02-27 21:24:06 --> Helper loaded: file_helper
INFO - 2016-02-27 21:24:06 --> Helper loaded: date_helper
INFO - 2016-02-27 21:24:06 --> Helper loaded: form_helper
INFO - 2016-02-27 21:24:06 --> Database Driver Class Initialized
INFO - 2016-02-27 21:24:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:24:07 --> Controller Class Initialized
INFO - 2016-02-27 21:24:07 --> Model Class Initialized
INFO - 2016-02-27 21:24:07 --> Model Class Initialized
INFO - 2016-02-27 21:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:24:07 --> Pagination Class Initialized
INFO - 2016-02-27 21:24:07 --> Helper loaded: text_helper
INFO - 2016-02-27 21:24:07 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:24:08 --> Config Class Initialized
INFO - 2016-02-27 21:24:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:24:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:24:08 --> Utf8 Class Initialized
INFO - 2016-02-27 21:24:08 --> URI Class Initialized
INFO - 2016-02-27 21:24:08 --> Router Class Initialized
INFO - 2016-02-27 21:24:08 --> Output Class Initialized
INFO - 2016-02-27 21:24:08 --> Security Class Initialized
DEBUG - 2016-02-27 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:24:08 --> Input Class Initialized
INFO - 2016-02-27 21:24:08 --> Language Class Initialized
INFO - 2016-02-27 21:24:08 --> Loader Class Initialized
INFO - 2016-02-27 21:24:09 --> Helper loaded: url_helper
INFO - 2016-02-27 21:24:09 --> Helper loaded: file_helper
INFO - 2016-02-27 21:24:09 --> Helper loaded: date_helper
INFO - 2016-02-27 21:24:09 --> Helper loaded: form_helper
INFO - 2016-02-27 21:24:09 --> Database Driver Class Initialized
INFO - 2016-02-27 21:24:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:24:10 --> Controller Class Initialized
INFO - 2016-02-27 21:24:10 --> Model Class Initialized
INFO - 2016-02-27 21:24:10 --> Model Class Initialized
INFO - 2016-02-27 21:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:24:10 --> Pagination Class Initialized
INFO - 2016-02-27 21:24:10 --> Helper loaded: text_helper
INFO - 2016-02-27 21:24:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:24:14 --> Config Class Initialized
INFO - 2016-02-27 21:24:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:24:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:24:14 --> Utf8 Class Initialized
INFO - 2016-02-27 21:24:14 --> URI Class Initialized
INFO - 2016-02-27 21:24:14 --> Router Class Initialized
INFO - 2016-02-27 21:24:14 --> Output Class Initialized
INFO - 2016-02-27 21:24:14 --> Security Class Initialized
DEBUG - 2016-02-27 21:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:24:14 --> Input Class Initialized
INFO - 2016-02-27 21:24:14 --> Language Class Initialized
INFO - 2016-02-27 21:24:14 --> Loader Class Initialized
INFO - 2016-02-27 21:24:14 --> Helper loaded: url_helper
INFO - 2016-02-27 21:24:14 --> Helper loaded: file_helper
INFO - 2016-02-27 21:24:14 --> Helper loaded: date_helper
INFO - 2016-02-27 21:24:14 --> Helper loaded: form_helper
INFO - 2016-02-27 21:24:14 --> Database Driver Class Initialized
INFO - 2016-02-27 21:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:24:15 --> Controller Class Initialized
INFO - 2016-02-27 21:24:15 --> Model Class Initialized
INFO - 2016-02-27 21:24:15 --> Model Class Initialized
INFO - 2016-02-27 21:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:24:15 --> Pagination Class Initialized
INFO - 2016-02-27 21:24:15 --> Helper loaded: text_helper
INFO - 2016-02-27 21:24:15 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:05 --> Config Class Initialized
INFO - 2016-02-27 21:25:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:05 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:05 --> URI Class Initialized
INFO - 2016-02-27 21:25:05 --> Router Class Initialized
INFO - 2016-02-27 21:25:05 --> Output Class Initialized
INFO - 2016-02-27 21:25:05 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:05 --> Input Class Initialized
INFO - 2016-02-27 21:25:05 --> Language Class Initialized
INFO - 2016-02-27 21:25:05 --> Loader Class Initialized
INFO - 2016-02-27 21:25:05 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:05 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:05 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:05 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:05 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:06 --> Controller Class Initialized
INFO - 2016-02-27 21:25:06 --> Model Class Initialized
INFO - 2016-02-27 21:25:06 --> Model Class Initialized
INFO - 2016-02-27 21:25:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:06 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:06 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:11 --> Config Class Initialized
INFO - 2016-02-27 21:25:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:11 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:11 --> URI Class Initialized
DEBUG - 2016-02-27 21:25:11 --> No URI present. Default controller set.
INFO - 2016-02-27 21:25:11 --> Router Class Initialized
INFO - 2016-02-27 21:25:11 --> Output Class Initialized
INFO - 2016-02-27 21:25:11 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:11 --> Input Class Initialized
INFO - 2016-02-27 21:25:11 --> Language Class Initialized
INFO - 2016-02-27 21:25:11 --> Loader Class Initialized
INFO - 2016-02-27 21:25:11 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:11 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:11 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:11 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:11 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:12 --> Controller Class Initialized
INFO - 2016-02-27 21:25:12 --> Model Class Initialized
INFO - 2016-02-27 21:25:12 --> Model Class Initialized
INFO - 2016-02-27 21:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:12 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:12 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:16 --> Config Class Initialized
INFO - 2016-02-27 21:25:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:16 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:16 --> URI Class Initialized
INFO - 2016-02-27 21:25:16 --> Router Class Initialized
INFO - 2016-02-27 21:25:16 --> Output Class Initialized
INFO - 2016-02-27 21:25:16 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:16 --> Input Class Initialized
INFO - 2016-02-27 21:25:16 --> Language Class Initialized
INFO - 2016-02-27 21:25:16 --> Loader Class Initialized
INFO - 2016-02-27 21:25:16 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:16 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:16 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:16 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:16 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:17 --> Controller Class Initialized
INFO - 2016-02-27 21:25:17 --> Model Class Initialized
INFO - 2016-02-27 21:25:17 --> Model Class Initialized
INFO - 2016-02-27 21:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:17 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:17 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:17 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:20 --> Config Class Initialized
INFO - 2016-02-27 21:25:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:20 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:20 --> URI Class Initialized
INFO - 2016-02-27 21:25:20 --> Router Class Initialized
INFO - 2016-02-27 21:25:20 --> Output Class Initialized
INFO - 2016-02-27 21:25:20 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:20 --> Input Class Initialized
INFO - 2016-02-27 21:25:20 --> Language Class Initialized
INFO - 2016-02-27 21:25:20 --> Loader Class Initialized
INFO - 2016-02-27 21:25:20 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:20 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:20 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:20 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:21 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:22 --> Controller Class Initialized
INFO - 2016-02-27 21:25:22 --> Model Class Initialized
INFO - 2016-02-27 21:25:22 --> Model Class Initialized
INFO - 2016-02-27 21:25:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:22 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:22 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:47 --> Config Class Initialized
INFO - 2016-02-27 21:25:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:47 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:47 --> URI Class Initialized
INFO - 2016-02-27 21:25:47 --> Router Class Initialized
INFO - 2016-02-27 21:25:47 --> Output Class Initialized
INFO - 2016-02-27 21:25:47 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:47 --> Input Class Initialized
INFO - 2016-02-27 21:25:47 --> Language Class Initialized
INFO - 2016-02-27 21:25:47 --> Loader Class Initialized
INFO - 2016-02-27 21:25:47 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:47 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:47 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:47 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:47 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:48 --> Controller Class Initialized
INFO - 2016-02-27 21:25:48 --> Model Class Initialized
INFO - 2016-02-27 21:25:48 --> Model Class Initialized
INFO - 2016-02-27 21:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:48 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:48 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:50 --> Config Class Initialized
INFO - 2016-02-27 21:25:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:51 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:51 --> URI Class Initialized
INFO - 2016-02-27 21:25:51 --> Router Class Initialized
INFO - 2016-02-27 21:25:51 --> Output Class Initialized
INFO - 2016-02-27 21:25:51 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:51 --> Input Class Initialized
INFO - 2016-02-27 21:25:51 --> Language Class Initialized
INFO - 2016-02-27 21:25:51 --> Loader Class Initialized
INFO - 2016-02-27 21:25:51 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:51 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:51 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:51 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:51 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:52 --> Controller Class Initialized
INFO - 2016-02-27 21:25:52 --> Model Class Initialized
INFO - 2016-02-27 21:25:52 --> Model Class Initialized
INFO - 2016-02-27 21:25:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:52 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:52 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:25:55 --> Config Class Initialized
INFO - 2016-02-27 21:25:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:25:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:25:55 --> Utf8 Class Initialized
INFO - 2016-02-27 21:25:55 --> URI Class Initialized
INFO - 2016-02-27 21:25:55 --> Router Class Initialized
INFO - 2016-02-27 21:25:55 --> Output Class Initialized
INFO - 2016-02-27 21:25:55 --> Security Class Initialized
DEBUG - 2016-02-27 21:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:25:55 --> Input Class Initialized
INFO - 2016-02-27 21:25:55 --> Language Class Initialized
INFO - 2016-02-27 21:25:55 --> Loader Class Initialized
INFO - 2016-02-27 21:25:55 --> Helper loaded: url_helper
INFO - 2016-02-27 21:25:55 --> Helper loaded: file_helper
INFO - 2016-02-27 21:25:55 --> Helper loaded: date_helper
INFO - 2016-02-27 21:25:55 --> Helper loaded: form_helper
INFO - 2016-02-27 21:25:55 --> Database Driver Class Initialized
INFO - 2016-02-27 21:25:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:25:56 --> Controller Class Initialized
INFO - 2016-02-27 21:25:56 --> Model Class Initialized
INFO - 2016-02-27 21:25:56 --> Model Class Initialized
INFO - 2016-02-27 21:25:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:25:56 --> Pagination Class Initialized
INFO - 2016-02-27 21:25:56 --> Helper loaded: text_helper
INFO - 2016-02-27 21:25:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:00 --> Config Class Initialized
INFO - 2016-02-27 21:26:00 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:00 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:00 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:00 --> URI Class Initialized
INFO - 2016-02-27 21:26:00 --> Router Class Initialized
INFO - 2016-02-27 21:26:00 --> Output Class Initialized
INFO - 2016-02-27 21:26:00 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:00 --> Input Class Initialized
INFO - 2016-02-27 21:26:00 --> Language Class Initialized
INFO - 2016-02-27 21:26:00 --> Loader Class Initialized
INFO - 2016-02-27 21:26:00 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:00 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:00 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:00 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:00 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:01 --> Controller Class Initialized
INFO - 2016-02-27 21:26:01 --> Model Class Initialized
INFO - 2016-02-27 21:26:01 --> Model Class Initialized
INFO - 2016-02-27 21:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:01 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:01 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:01 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:07 --> Config Class Initialized
INFO - 2016-02-27 21:26:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:07 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:07 --> URI Class Initialized
INFO - 2016-02-27 21:26:07 --> Router Class Initialized
INFO - 2016-02-27 21:26:07 --> Output Class Initialized
INFO - 2016-02-27 21:26:07 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:07 --> Input Class Initialized
INFO - 2016-02-27 21:26:07 --> Language Class Initialized
INFO - 2016-02-27 21:26:07 --> Loader Class Initialized
INFO - 2016-02-27 21:26:07 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:07 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:07 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:07 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:07 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:08 --> Controller Class Initialized
INFO - 2016-02-27 21:26:08 --> Model Class Initialized
INFO - 2016-02-27 21:26:08 --> Model Class Initialized
INFO - 2016-02-27 21:26:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:08 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:08 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:08 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:10 --> Config Class Initialized
INFO - 2016-02-27 21:26:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:10 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:10 --> URI Class Initialized
INFO - 2016-02-27 21:26:10 --> Router Class Initialized
INFO - 2016-02-27 21:26:10 --> Output Class Initialized
INFO - 2016-02-27 21:26:10 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:10 --> Input Class Initialized
INFO - 2016-02-27 21:26:10 --> Language Class Initialized
INFO - 2016-02-27 21:26:10 --> Loader Class Initialized
INFO - 2016-02-27 21:26:10 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:10 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:10 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:10 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:10 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:11 --> Controller Class Initialized
INFO - 2016-02-27 21:26:11 --> Model Class Initialized
INFO - 2016-02-27 21:26:11 --> Model Class Initialized
INFO - 2016-02-27 21:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:11 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:11 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:11 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:20 --> Config Class Initialized
INFO - 2016-02-27 21:26:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:20 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:20 --> URI Class Initialized
INFO - 2016-02-27 21:26:20 --> Router Class Initialized
INFO - 2016-02-27 21:26:20 --> Output Class Initialized
INFO - 2016-02-27 21:26:20 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:20 --> Input Class Initialized
INFO - 2016-02-27 21:26:20 --> Language Class Initialized
INFO - 2016-02-27 21:26:20 --> Loader Class Initialized
INFO - 2016-02-27 21:26:20 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:20 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:20 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:20 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:20 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:21 --> Controller Class Initialized
INFO - 2016-02-27 21:26:21 --> Model Class Initialized
INFO - 2016-02-27 21:26:21 --> Model Class Initialized
INFO - 2016-02-27 21:26:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:21 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:21 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:21 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:23 --> Config Class Initialized
INFO - 2016-02-27 21:26:23 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:23 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:23 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:23 --> URI Class Initialized
INFO - 2016-02-27 21:26:23 --> Router Class Initialized
INFO - 2016-02-27 21:26:23 --> Output Class Initialized
INFO - 2016-02-27 21:26:23 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:23 --> Input Class Initialized
INFO - 2016-02-27 21:26:23 --> Language Class Initialized
INFO - 2016-02-27 21:26:23 --> Loader Class Initialized
INFO - 2016-02-27 21:26:23 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:23 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:23 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:23 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:23 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:24 --> Controller Class Initialized
INFO - 2016-02-27 21:26:24 --> Model Class Initialized
INFO - 2016-02-27 21:26:24 --> Model Class Initialized
INFO - 2016-02-27 21:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:24 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:24 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:24 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:26:26 --> Config Class Initialized
INFO - 2016-02-27 21:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:26:26 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:26:26 --> Utf8 Class Initialized
INFO - 2016-02-27 21:26:26 --> URI Class Initialized
INFO - 2016-02-27 21:26:26 --> Router Class Initialized
INFO - 2016-02-27 21:26:26 --> Output Class Initialized
INFO - 2016-02-27 21:26:26 --> Security Class Initialized
DEBUG - 2016-02-27 21:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:26:26 --> Input Class Initialized
INFO - 2016-02-27 21:26:26 --> Language Class Initialized
INFO - 2016-02-27 21:26:26 --> Loader Class Initialized
INFO - 2016-02-27 21:26:26 --> Helper loaded: url_helper
INFO - 2016-02-27 21:26:26 --> Helper loaded: file_helper
INFO - 2016-02-27 21:26:26 --> Helper loaded: date_helper
INFO - 2016-02-27 21:26:26 --> Helper loaded: form_helper
INFO - 2016-02-27 21:26:26 --> Database Driver Class Initialized
INFO - 2016-02-27 21:26:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:26:27 --> Controller Class Initialized
INFO - 2016-02-27 21:26:27 --> Model Class Initialized
INFO - 2016-02-27 21:26:27 --> Model Class Initialized
INFO - 2016-02-27 21:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:26:27 --> Pagination Class Initialized
INFO - 2016-02-27 21:26:27 --> Helper loaded: text_helper
INFO - 2016-02-27 21:26:27 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:27:08 --> Config Class Initialized
INFO - 2016-02-27 21:27:08 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:27:08 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:27:08 --> Utf8 Class Initialized
INFO - 2016-02-27 21:27:08 --> URI Class Initialized
INFO - 2016-02-27 21:27:08 --> Router Class Initialized
INFO - 2016-02-27 21:27:08 --> Output Class Initialized
INFO - 2016-02-27 21:27:08 --> Security Class Initialized
DEBUG - 2016-02-27 21:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:27:08 --> Input Class Initialized
INFO - 2016-02-27 21:27:08 --> Language Class Initialized
INFO - 2016-02-27 21:27:08 --> Loader Class Initialized
INFO - 2016-02-27 21:27:08 --> Helper loaded: url_helper
INFO - 2016-02-27 21:27:08 --> Helper loaded: file_helper
INFO - 2016-02-27 21:27:08 --> Helper loaded: date_helper
INFO - 2016-02-27 21:27:08 --> Helper loaded: form_helper
INFO - 2016-02-27 21:27:08 --> Database Driver Class Initialized
INFO - 2016-02-27 21:27:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:27:09 --> Controller Class Initialized
INFO - 2016-02-27 21:27:09 --> Model Class Initialized
INFO - 2016-02-27 21:27:09 --> Model Class Initialized
INFO - 2016-02-27 21:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:27:09 --> Pagination Class Initialized
INFO - 2016-02-27 21:27:09 --> Helper loaded: text_helper
INFO - 2016-02-27 21:27:09 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:27:11 --> Config Class Initialized
INFO - 2016-02-27 21:27:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:27:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:27:11 --> Utf8 Class Initialized
INFO - 2016-02-27 21:27:11 --> URI Class Initialized
INFO - 2016-02-27 21:27:11 --> Router Class Initialized
INFO - 2016-02-27 21:27:11 --> Output Class Initialized
INFO - 2016-02-27 21:27:11 --> Security Class Initialized
DEBUG - 2016-02-27 21:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:27:11 --> Input Class Initialized
INFO - 2016-02-27 21:27:11 --> Language Class Initialized
INFO - 2016-02-27 21:27:11 --> Loader Class Initialized
INFO - 2016-02-27 21:27:11 --> Helper loaded: url_helper
INFO - 2016-02-27 21:27:11 --> Helper loaded: file_helper
INFO - 2016-02-27 21:27:11 --> Helper loaded: date_helper
INFO - 2016-02-27 21:27:11 --> Helper loaded: form_helper
INFO - 2016-02-27 21:27:11 --> Database Driver Class Initialized
INFO - 2016-02-27 21:27:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:27:12 --> Controller Class Initialized
INFO - 2016-02-27 21:27:12 --> Model Class Initialized
INFO - 2016-02-27 21:27:12 --> Model Class Initialized
INFO - 2016-02-27 21:27:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:27:12 --> Pagination Class Initialized
INFO - 2016-02-27 21:27:12 --> Helper loaded: text_helper
INFO - 2016-02-27 21:27:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:27:16 --> Config Class Initialized
INFO - 2016-02-27 21:27:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:27:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:27:16 --> Utf8 Class Initialized
INFO - 2016-02-27 21:27:16 --> URI Class Initialized
INFO - 2016-02-27 21:27:16 --> Router Class Initialized
INFO - 2016-02-27 21:27:16 --> Output Class Initialized
INFO - 2016-02-27 21:27:16 --> Security Class Initialized
DEBUG - 2016-02-27 21:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:27:16 --> Input Class Initialized
INFO - 2016-02-27 21:27:16 --> Language Class Initialized
INFO - 2016-02-27 21:27:16 --> Loader Class Initialized
INFO - 2016-02-27 21:27:16 --> Helper loaded: url_helper
INFO - 2016-02-27 21:27:16 --> Helper loaded: file_helper
INFO - 2016-02-27 21:27:16 --> Helper loaded: date_helper
INFO - 2016-02-27 21:27:16 --> Helper loaded: form_helper
INFO - 2016-02-27 21:27:16 --> Database Driver Class Initialized
INFO - 2016-02-27 21:27:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:27:17 --> Controller Class Initialized
INFO - 2016-02-27 21:27:17 --> Model Class Initialized
INFO - 2016-02-27 21:27:17 --> Model Class Initialized
INFO - 2016-02-27 21:27:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:27:17 --> Pagination Class Initialized
INFO - 2016-02-27 21:27:17 --> Helper loaded: text_helper
INFO - 2016-02-27 21:27:17 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:34:14 --> Config Class Initialized
INFO - 2016-02-27 21:34:14 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:34:14 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:34:14 --> Utf8 Class Initialized
INFO - 2016-02-27 21:34:14 --> URI Class Initialized
INFO - 2016-02-27 21:34:14 --> Router Class Initialized
INFO - 2016-02-27 21:34:14 --> Output Class Initialized
INFO - 2016-02-27 21:34:14 --> Security Class Initialized
DEBUG - 2016-02-27 21:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:34:14 --> Input Class Initialized
INFO - 2016-02-27 21:34:14 --> Language Class Initialized
INFO - 2016-02-27 21:34:14 --> Loader Class Initialized
INFO - 2016-02-27 21:34:14 --> Helper loaded: url_helper
INFO - 2016-02-27 21:34:14 --> Helper loaded: file_helper
INFO - 2016-02-27 21:34:14 --> Helper loaded: date_helper
INFO - 2016-02-27 21:34:14 --> Helper loaded: form_helper
INFO - 2016-02-27 21:34:15 --> Database Driver Class Initialized
INFO - 2016-02-27 21:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:34:16 --> Controller Class Initialized
INFO - 2016-02-27 21:34:16 --> Model Class Initialized
INFO - 2016-02-27 21:34:16 --> Model Class Initialized
INFO - 2016-02-27 21:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:34:16 --> Pagination Class Initialized
INFO - 2016-02-27 21:34:16 --> Helper loaded: text_helper
INFO - 2016-02-27 21:34:16 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:34:22 --> Config Class Initialized
INFO - 2016-02-27 21:34:22 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:34:22 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:34:22 --> Utf8 Class Initialized
INFO - 2016-02-27 21:34:22 --> URI Class Initialized
INFO - 2016-02-27 21:34:22 --> Router Class Initialized
INFO - 2016-02-27 21:34:22 --> Output Class Initialized
INFO - 2016-02-27 21:34:22 --> Security Class Initialized
DEBUG - 2016-02-27 21:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:34:22 --> Input Class Initialized
INFO - 2016-02-27 21:34:22 --> Language Class Initialized
INFO - 2016-02-27 21:34:22 --> Loader Class Initialized
INFO - 2016-02-27 21:34:22 --> Helper loaded: url_helper
INFO - 2016-02-27 21:34:22 --> Helper loaded: file_helper
INFO - 2016-02-27 21:34:22 --> Helper loaded: date_helper
INFO - 2016-02-27 21:34:22 --> Helper loaded: form_helper
INFO - 2016-02-27 21:34:22 --> Database Driver Class Initialized
INFO - 2016-02-27 21:34:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:34:23 --> Controller Class Initialized
INFO - 2016-02-27 21:34:23 --> Model Class Initialized
INFO - 2016-02-27 21:34:23 --> Model Class Initialized
INFO - 2016-02-27 21:34:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:34:23 --> Pagination Class Initialized
INFO - 2016-02-27 21:34:23 --> Helper loaded: text_helper
INFO - 2016-02-27 21:34:23 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:34:54 --> Config Class Initialized
INFO - 2016-02-27 21:34:54 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:34:54 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:34:54 --> Utf8 Class Initialized
INFO - 2016-02-27 21:34:54 --> URI Class Initialized
INFO - 2016-02-27 21:34:54 --> Router Class Initialized
INFO - 2016-02-27 21:34:54 --> Output Class Initialized
INFO - 2016-02-27 21:34:54 --> Security Class Initialized
DEBUG - 2016-02-27 21:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:34:54 --> Input Class Initialized
INFO - 2016-02-27 21:34:54 --> Language Class Initialized
INFO - 2016-02-27 21:34:54 --> Loader Class Initialized
INFO - 2016-02-27 21:34:54 --> Helper loaded: url_helper
INFO - 2016-02-27 21:34:54 --> Helper loaded: file_helper
INFO - 2016-02-27 21:34:54 --> Helper loaded: date_helper
INFO - 2016-02-27 21:34:54 --> Helper loaded: form_helper
INFO - 2016-02-27 21:34:54 --> Database Driver Class Initialized
INFO - 2016-02-27 21:34:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:34:55 --> Controller Class Initialized
INFO - 2016-02-27 21:34:55 --> Model Class Initialized
INFO - 2016-02-27 21:34:55 --> Model Class Initialized
INFO - 2016-02-27 21:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:34:55 --> Pagination Class Initialized
INFO - 2016-02-27 21:34:55 --> Helper loaded: text_helper
INFO - 2016-02-27 21:34:55 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:36:47 --> Config Class Initialized
INFO - 2016-02-27 21:36:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:36:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:36:47 --> Utf8 Class Initialized
INFO - 2016-02-27 21:36:47 --> URI Class Initialized
INFO - 2016-02-27 21:36:47 --> Router Class Initialized
INFO - 2016-02-27 21:36:47 --> Output Class Initialized
INFO - 2016-02-27 21:36:47 --> Security Class Initialized
DEBUG - 2016-02-27 21:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:36:47 --> Input Class Initialized
INFO - 2016-02-27 21:36:47 --> Language Class Initialized
INFO - 2016-02-27 21:36:47 --> Loader Class Initialized
INFO - 2016-02-27 21:36:47 --> Helper loaded: url_helper
INFO - 2016-02-27 21:36:47 --> Helper loaded: file_helper
INFO - 2016-02-27 21:36:47 --> Helper loaded: date_helper
INFO - 2016-02-27 21:36:47 --> Helper loaded: form_helper
INFO - 2016-02-27 21:36:47 --> Database Driver Class Initialized
INFO - 2016-02-27 21:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:36:48 --> Controller Class Initialized
INFO - 2016-02-27 21:36:48 --> Model Class Initialized
INFO - 2016-02-27 21:36:48 --> Model Class Initialized
INFO - 2016-02-27 21:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:36:48 --> Pagination Class Initialized
INFO - 2016-02-27 21:36:48 --> Helper loaded: text_helper
INFO - 2016-02-27 21:36:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:38:40 --> Config Class Initialized
INFO - 2016-02-27 21:38:40 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:38:40 --> Utf8 Class Initialized
INFO - 2016-02-27 21:38:40 --> URI Class Initialized
INFO - 2016-02-27 21:38:40 --> Router Class Initialized
INFO - 2016-02-27 21:38:40 --> Output Class Initialized
INFO - 2016-02-27 21:38:40 --> Security Class Initialized
DEBUG - 2016-02-27 21:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:38:40 --> Input Class Initialized
INFO - 2016-02-27 21:38:40 --> Language Class Initialized
INFO - 2016-02-27 21:38:40 --> Loader Class Initialized
INFO - 2016-02-27 21:38:40 --> Helper loaded: url_helper
INFO - 2016-02-27 21:38:40 --> Helper loaded: file_helper
INFO - 2016-02-27 21:38:40 --> Helper loaded: date_helper
INFO - 2016-02-27 21:38:40 --> Helper loaded: form_helper
INFO - 2016-02-27 21:38:40 --> Database Driver Class Initialized
INFO - 2016-02-27 21:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:38:41 --> Controller Class Initialized
INFO - 2016-02-27 21:38:41 --> Model Class Initialized
INFO - 2016-02-27 21:38:41 --> Model Class Initialized
INFO - 2016-02-27 21:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:38:41 --> Pagination Class Initialized
INFO - 2016-02-27 21:38:41 --> Helper loaded: text_helper
INFO - 2016-02-27 21:38:41 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:42:27 --> Config Class Initialized
INFO - 2016-02-27 21:42:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:42:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:42:27 --> Utf8 Class Initialized
INFO - 2016-02-27 21:42:27 --> URI Class Initialized
INFO - 2016-02-27 21:42:27 --> Router Class Initialized
INFO - 2016-02-27 21:42:27 --> Output Class Initialized
INFO - 2016-02-27 21:42:27 --> Security Class Initialized
DEBUG - 2016-02-27 21:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:42:27 --> Input Class Initialized
INFO - 2016-02-27 21:42:27 --> Language Class Initialized
INFO - 2016-02-27 21:42:27 --> Loader Class Initialized
INFO - 2016-02-27 21:42:27 --> Helper loaded: url_helper
INFO - 2016-02-27 21:42:27 --> Helper loaded: file_helper
INFO - 2016-02-27 21:42:27 --> Helper loaded: date_helper
INFO - 2016-02-27 21:42:27 --> Helper loaded: form_helper
INFO - 2016-02-27 21:42:27 --> Database Driver Class Initialized
INFO - 2016-02-27 21:42:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:42:28 --> Controller Class Initialized
INFO - 2016-02-27 21:42:28 --> Model Class Initialized
INFO - 2016-02-27 21:42:28 --> Model Class Initialized
INFO - 2016-02-27 21:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:42:28 --> Pagination Class Initialized
INFO - 2016-02-27 21:42:28 --> Helper loaded: text_helper
INFO - 2016-02-27 21:42:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:45:05 --> Config Class Initialized
INFO - 2016-02-27 21:45:05 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:45:05 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:45:05 --> Utf8 Class Initialized
INFO - 2016-02-27 21:45:05 --> URI Class Initialized
INFO - 2016-02-27 21:45:05 --> Router Class Initialized
INFO - 2016-02-27 21:45:05 --> Output Class Initialized
INFO - 2016-02-27 21:45:05 --> Security Class Initialized
DEBUG - 2016-02-27 21:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:45:05 --> Input Class Initialized
INFO - 2016-02-27 21:45:05 --> Language Class Initialized
INFO - 2016-02-27 21:45:05 --> Loader Class Initialized
INFO - 2016-02-27 21:45:05 --> Helper loaded: url_helper
INFO - 2016-02-27 21:45:05 --> Helper loaded: file_helper
INFO - 2016-02-27 21:45:05 --> Helper loaded: date_helper
INFO - 2016-02-27 21:45:05 --> Helper loaded: form_helper
INFO - 2016-02-27 21:45:05 --> Database Driver Class Initialized
INFO - 2016-02-27 21:45:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:45:06 --> Controller Class Initialized
INFO - 2016-02-27 21:45:06 --> Model Class Initialized
INFO - 2016-02-27 21:45:06 --> Model Class Initialized
INFO - 2016-02-27 21:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:45:06 --> Pagination Class Initialized
INFO - 2016-02-27 21:45:06 --> Helper loaded: text_helper
INFO - 2016-02-27 21:45:06 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:46:07 --> Config Class Initialized
INFO - 2016-02-27 21:46:07 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:46:07 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:46:07 --> Utf8 Class Initialized
INFO - 2016-02-27 21:46:07 --> URI Class Initialized
INFO - 2016-02-27 21:46:07 --> Router Class Initialized
INFO - 2016-02-27 21:46:07 --> Output Class Initialized
INFO - 2016-02-27 21:46:07 --> Security Class Initialized
DEBUG - 2016-02-27 21:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:46:07 --> Input Class Initialized
INFO - 2016-02-27 21:46:07 --> Language Class Initialized
INFO - 2016-02-27 21:46:07 --> Loader Class Initialized
INFO - 2016-02-27 21:46:07 --> Helper loaded: url_helper
INFO - 2016-02-27 21:46:07 --> Helper loaded: file_helper
INFO - 2016-02-27 21:46:07 --> Helper loaded: date_helper
INFO - 2016-02-27 21:46:07 --> Helper loaded: form_helper
INFO - 2016-02-27 21:46:07 --> Database Driver Class Initialized
INFO - 2016-02-27 21:46:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:46:08 --> Controller Class Initialized
INFO - 2016-02-27 21:46:08 --> Model Class Initialized
INFO - 2016-02-27 21:46:08 --> Model Class Initialized
INFO - 2016-02-27 21:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:46:08 --> Pagination Class Initialized
INFO - 2016-02-27 21:46:08 --> Helper loaded: text_helper
INFO - 2016-02-27 21:46:08 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:49:50 --> Config Class Initialized
INFO - 2016-02-27 21:49:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:49:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:49:50 --> Utf8 Class Initialized
INFO - 2016-02-27 21:49:50 --> URI Class Initialized
INFO - 2016-02-27 21:49:50 --> Router Class Initialized
INFO - 2016-02-27 21:49:50 --> Output Class Initialized
INFO - 2016-02-27 21:49:50 --> Security Class Initialized
DEBUG - 2016-02-27 21:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:49:50 --> Input Class Initialized
INFO - 2016-02-27 21:49:50 --> Language Class Initialized
INFO - 2016-02-27 21:49:50 --> Loader Class Initialized
INFO - 2016-02-27 21:49:50 --> Helper loaded: url_helper
INFO - 2016-02-27 21:49:50 --> Helper loaded: file_helper
INFO - 2016-02-27 21:49:50 --> Helper loaded: date_helper
INFO - 2016-02-27 21:49:50 --> Helper loaded: form_helper
INFO - 2016-02-27 21:49:50 --> Database Driver Class Initialized
INFO - 2016-02-27 21:49:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:49:51 --> Controller Class Initialized
INFO - 2016-02-27 21:49:51 --> Model Class Initialized
INFO - 2016-02-27 21:49:51 --> Model Class Initialized
INFO - 2016-02-27 21:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:49:51 --> Pagination Class Initialized
INFO - 2016-02-27 21:49:51 --> Helper loaded: text_helper
INFO - 2016-02-27 21:49:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:52:55 --> Config Class Initialized
INFO - 2016-02-27 21:52:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:52:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:52:55 --> Utf8 Class Initialized
INFO - 2016-02-27 21:52:55 --> URI Class Initialized
INFO - 2016-02-27 21:52:55 --> Router Class Initialized
INFO - 2016-02-27 21:52:55 --> Output Class Initialized
INFO - 2016-02-27 21:52:55 --> Security Class Initialized
DEBUG - 2016-02-27 21:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:52:55 --> Input Class Initialized
INFO - 2016-02-27 21:52:55 --> Language Class Initialized
INFO - 2016-02-27 21:52:55 --> Loader Class Initialized
INFO - 2016-02-27 21:52:55 --> Helper loaded: url_helper
INFO - 2016-02-27 21:52:55 --> Helper loaded: file_helper
INFO - 2016-02-27 21:52:55 --> Helper loaded: date_helper
INFO - 2016-02-27 21:52:55 --> Helper loaded: form_helper
INFO - 2016-02-27 21:52:55 --> Database Driver Class Initialized
INFO - 2016-02-27 21:52:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:52:56 --> Controller Class Initialized
INFO - 2016-02-27 21:52:56 --> Model Class Initialized
INFO - 2016-02-27 21:52:56 --> Model Class Initialized
INFO - 2016-02-27 21:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:52:56 --> Pagination Class Initialized
INFO - 2016-02-27 21:52:56 --> Helper loaded: text_helper
INFO - 2016-02-27 21:52:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:52:58 --> Config Class Initialized
INFO - 2016-02-27 21:52:58 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:52:58 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:52:58 --> Utf8 Class Initialized
INFO - 2016-02-27 21:52:58 --> URI Class Initialized
INFO - 2016-02-27 21:52:58 --> Router Class Initialized
INFO - 2016-02-27 21:52:58 --> Output Class Initialized
INFO - 2016-02-27 21:52:58 --> Security Class Initialized
DEBUG - 2016-02-27 21:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:52:58 --> Input Class Initialized
INFO - 2016-02-27 21:52:58 --> Language Class Initialized
INFO - 2016-02-27 21:52:58 --> Loader Class Initialized
INFO - 2016-02-27 21:52:58 --> Helper loaded: url_helper
INFO - 2016-02-27 21:52:58 --> Helper loaded: file_helper
INFO - 2016-02-27 21:52:58 --> Helper loaded: date_helper
INFO - 2016-02-27 21:52:58 --> Helper loaded: form_helper
INFO - 2016-02-27 21:52:58 --> Database Driver Class Initialized
INFO - 2016-02-27 21:52:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:52:59 --> Controller Class Initialized
INFO - 2016-02-27 21:52:59 --> Model Class Initialized
INFO - 2016-02-27 21:52:59 --> Model Class Initialized
INFO - 2016-02-27 21:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:52:59 --> Pagination Class Initialized
INFO - 2016-02-27 21:52:59 --> Helper loaded: text_helper
INFO - 2016-02-27 21:52:59 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:53:01 --> Config Class Initialized
INFO - 2016-02-27 21:53:01 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:53:01 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:53:01 --> Utf8 Class Initialized
INFO - 2016-02-27 21:53:01 --> URI Class Initialized
INFO - 2016-02-27 21:53:01 --> Router Class Initialized
INFO - 2016-02-27 21:53:01 --> Output Class Initialized
INFO - 2016-02-27 21:53:01 --> Security Class Initialized
DEBUG - 2016-02-27 21:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:53:01 --> Input Class Initialized
INFO - 2016-02-27 21:53:01 --> Language Class Initialized
INFO - 2016-02-27 21:53:01 --> Loader Class Initialized
INFO - 2016-02-27 21:53:01 --> Helper loaded: url_helper
INFO - 2016-02-27 21:53:01 --> Helper loaded: file_helper
INFO - 2016-02-27 21:53:01 --> Helper loaded: date_helper
INFO - 2016-02-27 21:53:01 --> Helper loaded: form_helper
INFO - 2016-02-27 21:53:01 --> Database Driver Class Initialized
INFO - 2016-02-27 21:53:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:53:02 --> Controller Class Initialized
INFO - 2016-02-27 21:53:02 --> Model Class Initialized
INFO - 2016-02-27 21:53:02 --> Model Class Initialized
INFO - 2016-02-27 21:53:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:53:02 --> Pagination Class Initialized
INFO - 2016-02-27 21:53:02 --> Helper loaded: text_helper
INFO - 2016-02-27 21:53:02 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:53:31 --> Config Class Initialized
INFO - 2016-02-27 21:53:31 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:53:31 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:53:31 --> Utf8 Class Initialized
INFO - 2016-02-27 21:53:31 --> URI Class Initialized
INFO - 2016-02-27 21:53:31 --> Router Class Initialized
INFO - 2016-02-27 21:53:31 --> Output Class Initialized
INFO - 2016-02-27 21:53:31 --> Security Class Initialized
DEBUG - 2016-02-27 21:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:53:31 --> Input Class Initialized
INFO - 2016-02-27 21:53:31 --> Language Class Initialized
INFO - 2016-02-27 21:53:31 --> Loader Class Initialized
INFO - 2016-02-27 21:53:31 --> Helper loaded: url_helper
INFO - 2016-02-27 21:53:31 --> Helper loaded: file_helper
INFO - 2016-02-27 21:53:31 --> Helper loaded: date_helper
INFO - 2016-02-27 21:53:31 --> Helper loaded: form_helper
INFO - 2016-02-27 21:53:31 --> Database Driver Class Initialized
INFO - 2016-02-27 21:53:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:53:32 --> Controller Class Initialized
INFO - 2016-02-27 21:53:32 --> Model Class Initialized
INFO - 2016-02-27 21:53:32 --> Model Class Initialized
INFO - 2016-02-27 21:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:53:32 --> Pagination Class Initialized
INFO - 2016-02-27 21:53:32 --> Helper loaded: text_helper
INFO - 2016-02-27 21:53:32 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:53:37 --> Config Class Initialized
INFO - 2016-02-27 21:53:37 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:53:37 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:53:37 --> Utf8 Class Initialized
INFO - 2016-02-27 21:53:37 --> URI Class Initialized
INFO - 2016-02-27 21:53:37 --> Router Class Initialized
INFO - 2016-02-27 21:53:37 --> Output Class Initialized
INFO - 2016-02-27 21:53:37 --> Security Class Initialized
DEBUG - 2016-02-27 21:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:53:37 --> Input Class Initialized
INFO - 2016-02-27 21:53:37 --> Language Class Initialized
INFO - 2016-02-27 21:53:37 --> Loader Class Initialized
INFO - 2016-02-27 21:53:37 --> Helper loaded: url_helper
INFO - 2016-02-27 21:53:37 --> Helper loaded: file_helper
INFO - 2016-02-27 21:53:37 --> Helper loaded: date_helper
INFO - 2016-02-27 21:53:37 --> Helper loaded: form_helper
INFO - 2016-02-27 21:53:37 --> Database Driver Class Initialized
INFO - 2016-02-27 21:53:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:53:38 --> Controller Class Initialized
INFO - 2016-02-27 21:53:38 --> Model Class Initialized
INFO - 2016-02-27 21:53:38 --> Model Class Initialized
INFO - 2016-02-27 21:53:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:53:38 --> Pagination Class Initialized
INFO - 2016-02-27 21:53:38 --> Helper loaded: text_helper
INFO - 2016-02-27 21:53:38 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:06 --> Config Class Initialized
INFO - 2016-02-27 21:54:06 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:06 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:06 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:06 --> URI Class Initialized
INFO - 2016-02-27 21:54:06 --> Router Class Initialized
INFO - 2016-02-27 21:54:06 --> Output Class Initialized
INFO - 2016-02-27 21:54:06 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:06 --> Input Class Initialized
INFO - 2016-02-27 21:54:06 --> Language Class Initialized
INFO - 2016-02-27 21:54:06 --> Loader Class Initialized
INFO - 2016-02-27 21:54:06 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:06 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:06 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:06 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:06 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:07 --> Controller Class Initialized
INFO - 2016-02-27 21:54:07 --> Model Class Initialized
INFO - 2016-02-27 21:54:07 --> Model Class Initialized
INFO - 2016-02-27 21:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:07 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:07 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:07 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:11 --> Config Class Initialized
INFO - 2016-02-27 21:54:11 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:11 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:11 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:11 --> URI Class Initialized
INFO - 2016-02-27 21:54:11 --> Router Class Initialized
INFO - 2016-02-27 21:54:11 --> Output Class Initialized
INFO - 2016-02-27 21:54:11 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:11 --> Input Class Initialized
INFO - 2016-02-27 21:54:11 --> Language Class Initialized
INFO - 2016-02-27 21:54:11 --> Loader Class Initialized
INFO - 2016-02-27 21:54:11 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:11 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:11 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:11 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:11 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:12 --> Controller Class Initialized
INFO - 2016-02-27 21:54:12 --> Model Class Initialized
INFO - 2016-02-27 21:54:12 --> Model Class Initialized
INFO - 2016-02-27 21:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:12 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:12 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:12 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:13 --> Config Class Initialized
INFO - 2016-02-27 21:54:13 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:13 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:13 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:13 --> URI Class Initialized
INFO - 2016-02-27 21:54:13 --> Router Class Initialized
INFO - 2016-02-27 21:54:13 --> Output Class Initialized
INFO - 2016-02-27 21:54:13 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:13 --> Input Class Initialized
INFO - 2016-02-27 21:54:13 --> Language Class Initialized
INFO - 2016-02-27 21:54:13 --> Loader Class Initialized
INFO - 2016-02-27 21:54:13 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:13 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:13 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:13 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:13 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:14 --> Controller Class Initialized
INFO - 2016-02-27 21:54:14 --> Model Class Initialized
INFO - 2016-02-27 21:54:14 --> Model Class Initialized
INFO - 2016-02-27 21:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:14 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:14 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:14 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:41 --> Config Class Initialized
INFO - 2016-02-27 21:54:41 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:41 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:41 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:41 --> URI Class Initialized
INFO - 2016-02-27 21:54:41 --> Router Class Initialized
INFO - 2016-02-27 21:54:41 --> Output Class Initialized
INFO - 2016-02-27 21:54:41 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:41 --> Input Class Initialized
INFO - 2016-02-27 21:54:41 --> Language Class Initialized
INFO - 2016-02-27 21:54:41 --> Loader Class Initialized
INFO - 2016-02-27 21:54:41 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:41 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:41 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:41 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:41 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:42 --> Controller Class Initialized
INFO - 2016-02-27 21:54:42 --> Model Class Initialized
INFO - 2016-02-27 21:54:42 --> Model Class Initialized
INFO - 2016-02-27 21:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:42 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:42 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:42 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:42 --> Config Class Initialized
INFO - 2016-02-27 21:54:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:42 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:42 --> URI Class Initialized
INFO - 2016-02-27 21:54:42 --> Router Class Initialized
INFO - 2016-02-27 21:54:42 --> Output Class Initialized
INFO - 2016-02-27 21:54:42 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:42 --> Input Class Initialized
INFO - 2016-02-27 21:54:42 --> Language Class Initialized
INFO - 2016-02-27 21:54:42 --> Loader Class Initialized
INFO - 2016-02-27 21:54:42 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:42 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:42 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:42 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:42 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:43 --> Controller Class Initialized
INFO - 2016-02-27 21:54:43 --> Model Class Initialized
INFO - 2016-02-27 21:54:43 --> Model Class Initialized
INFO - 2016-02-27 21:54:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:43 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:43 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:43 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:54:51 --> Config Class Initialized
INFO - 2016-02-27 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:54:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:54:51 --> Utf8 Class Initialized
INFO - 2016-02-27 21:54:51 --> URI Class Initialized
INFO - 2016-02-27 21:54:51 --> Router Class Initialized
INFO - 2016-02-27 21:54:51 --> Output Class Initialized
INFO - 2016-02-27 21:54:51 --> Security Class Initialized
DEBUG - 2016-02-27 21:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:54:51 --> Input Class Initialized
INFO - 2016-02-27 21:54:51 --> Language Class Initialized
INFO - 2016-02-27 21:54:51 --> Loader Class Initialized
INFO - 2016-02-27 21:54:51 --> Helper loaded: url_helper
INFO - 2016-02-27 21:54:51 --> Helper loaded: file_helper
INFO - 2016-02-27 21:54:51 --> Helper loaded: date_helper
INFO - 2016-02-27 21:54:51 --> Helper loaded: form_helper
INFO - 2016-02-27 21:54:51 --> Database Driver Class Initialized
INFO - 2016-02-27 21:54:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:54:52 --> Controller Class Initialized
INFO - 2016-02-27 21:54:52 --> Model Class Initialized
INFO - 2016-02-27 21:54:52 --> Model Class Initialized
INFO - 2016-02-27 21:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:54:52 --> Pagination Class Initialized
INFO - 2016-02-27 21:54:52 --> Helper loaded: text_helper
INFO - 2016-02-27 21:54:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 21:55:29 --> Config Class Initialized
INFO - 2016-02-27 21:55:29 --> Hooks Class Initialized
DEBUG - 2016-02-27 21:55:29 --> UTF-8 Support Enabled
INFO - 2016-02-27 21:55:29 --> Utf8 Class Initialized
INFO - 2016-02-27 21:55:29 --> URI Class Initialized
INFO - 2016-02-27 21:55:29 --> Router Class Initialized
INFO - 2016-02-27 21:55:29 --> Output Class Initialized
INFO - 2016-02-27 21:55:29 --> Security Class Initialized
DEBUG - 2016-02-27 21:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 21:55:29 --> Input Class Initialized
INFO - 2016-02-27 21:55:29 --> Language Class Initialized
INFO - 2016-02-27 21:55:29 --> Loader Class Initialized
INFO - 2016-02-27 21:55:29 --> Helper loaded: url_helper
INFO - 2016-02-27 21:55:29 --> Helper loaded: file_helper
INFO - 2016-02-27 21:55:29 --> Helper loaded: date_helper
INFO - 2016-02-27 21:55:29 --> Helper loaded: form_helper
INFO - 2016-02-27 21:55:29 --> Database Driver Class Initialized
INFO - 2016-02-27 21:55:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 21:55:30 --> Controller Class Initialized
INFO - 2016-02-27 21:55:30 --> Model Class Initialized
INFO - 2016-02-27 21:55:30 --> Model Class Initialized
INFO - 2016-02-27 21:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 21:55:30 --> Pagination Class Initialized
INFO - 2016-02-27 21:55:30 --> Helper loaded: text_helper
INFO - 2016-02-27 21:55:30 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:00:42 --> Config Class Initialized
INFO - 2016-02-27 22:00:42 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:00:42 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:00:42 --> Utf8 Class Initialized
INFO - 2016-02-27 22:00:42 --> URI Class Initialized
INFO - 2016-02-27 22:00:42 --> Router Class Initialized
INFO - 2016-02-27 22:00:42 --> Output Class Initialized
INFO - 2016-02-27 22:00:42 --> Security Class Initialized
DEBUG - 2016-02-27 22:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:00:42 --> Input Class Initialized
INFO - 2016-02-27 22:00:42 --> Language Class Initialized
INFO - 2016-02-27 22:00:42 --> Loader Class Initialized
INFO - 2016-02-27 22:00:42 --> Helper loaded: url_helper
INFO - 2016-02-27 22:00:42 --> Helper loaded: file_helper
INFO - 2016-02-27 22:00:42 --> Helper loaded: date_helper
INFO - 2016-02-27 22:00:42 --> Helper loaded: form_helper
INFO - 2016-02-27 22:00:42 --> Database Driver Class Initialized
INFO - 2016-02-27 22:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:00:43 --> Controller Class Initialized
INFO - 2016-02-27 22:00:43 --> Model Class Initialized
INFO - 2016-02-27 22:00:43 --> Model Class Initialized
INFO - 2016-02-27 22:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:00:43 --> Pagination Class Initialized
INFO - 2016-02-27 22:00:43 --> Helper loaded: text_helper
INFO - 2016-02-27 22:00:43 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:00:47 --> Config Class Initialized
INFO - 2016-02-27 22:00:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:00:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:00:47 --> Utf8 Class Initialized
INFO - 2016-02-27 22:00:47 --> URI Class Initialized
INFO - 2016-02-27 22:00:47 --> Router Class Initialized
INFO - 2016-02-27 22:00:47 --> Output Class Initialized
INFO - 2016-02-27 22:00:47 --> Security Class Initialized
DEBUG - 2016-02-27 22:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:00:47 --> Input Class Initialized
INFO - 2016-02-27 22:00:47 --> Language Class Initialized
INFO - 2016-02-27 22:00:47 --> Loader Class Initialized
INFO - 2016-02-27 22:00:47 --> Helper loaded: url_helper
INFO - 2016-02-27 22:00:47 --> Helper loaded: file_helper
INFO - 2016-02-27 22:00:47 --> Helper loaded: date_helper
INFO - 2016-02-27 22:00:47 --> Helper loaded: form_helper
INFO - 2016-02-27 22:00:47 --> Database Driver Class Initialized
INFO - 2016-02-27 22:00:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:00:48 --> Controller Class Initialized
INFO - 2016-02-27 22:00:48 --> Model Class Initialized
INFO - 2016-02-27 22:00:48 --> Model Class Initialized
INFO - 2016-02-27 22:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:00:48 --> Pagination Class Initialized
INFO - 2016-02-27 22:00:48 --> Helper loaded: text_helper
INFO - 2016-02-27 22:00:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:00:48 --> Config Class Initialized
INFO - 2016-02-27 22:00:48 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:00:48 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:00:48 --> Utf8 Class Initialized
INFO - 2016-02-27 22:00:48 --> URI Class Initialized
INFO - 2016-02-27 22:00:48 --> Router Class Initialized
INFO - 2016-02-27 22:00:48 --> Output Class Initialized
INFO - 2016-02-27 22:00:48 --> Security Class Initialized
DEBUG - 2016-02-27 22:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:00:48 --> Input Class Initialized
INFO - 2016-02-27 22:00:48 --> Language Class Initialized
INFO - 2016-02-27 22:00:48 --> Loader Class Initialized
INFO - 2016-02-27 22:00:48 --> Helper loaded: url_helper
INFO - 2016-02-27 22:00:48 --> Helper loaded: file_helper
INFO - 2016-02-27 22:00:48 --> Helper loaded: date_helper
INFO - 2016-02-27 22:00:48 --> Helper loaded: form_helper
INFO - 2016-02-27 22:00:48 --> Database Driver Class Initialized
INFO - 2016-02-27 22:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:00:49 --> Controller Class Initialized
INFO - 2016-02-27 22:00:49 --> Model Class Initialized
INFO - 2016-02-27 22:00:49 --> Model Class Initialized
INFO - 2016-02-27 22:00:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:00:49 --> Pagination Class Initialized
INFO - 2016-02-27 22:00:49 --> Helper loaded: text_helper
INFO - 2016-02-27 22:00:49 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:00:56 --> Config Class Initialized
INFO - 2016-02-27 22:00:56 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:00:56 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:00:56 --> Utf8 Class Initialized
INFO - 2016-02-27 22:00:56 --> URI Class Initialized
INFO - 2016-02-27 22:00:56 --> Router Class Initialized
INFO - 2016-02-27 22:00:56 --> Output Class Initialized
INFO - 2016-02-27 22:00:56 --> Security Class Initialized
DEBUG - 2016-02-27 22:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:00:56 --> Input Class Initialized
INFO - 2016-02-27 22:00:56 --> Language Class Initialized
INFO - 2016-02-27 22:00:56 --> Loader Class Initialized
INFO - 2016-02-27 22:00:56 --> Helper loaded: url_helper
INFO - 2016-02-27 22:00:56 --> Helper loaded: file_helper
INFO - 2016-02-27 22:00:56 --> Helper loaded: date_helper
INFO - 2016-02-27 22:00:56 --> Helper loaded: form_helper
INFO - 2016-02-27 22:00:56 --> Database Driver Class Initialized
INFO - 2016-02-27 22:00:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:00:57 --> Controller Class Initialized
INFO - 2016-02-27 22:00:57 --> Model Class Initialized
INFO - 2016-02-27 22:00:57 --> Model Class Initialized
INFO - 2016-02-27 22:00:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:00:57 --> Pagination Class Initialized
INFO - 2016-02-27 22:00:57 --> Helper loaded: text_helper
INFO - 2016-02-27 22:00:57 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:16 --> Config Class Initialized
INFO - 2016-02-27 22:02:16 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:16 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:16 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:16 --> URI Class Initialized
INFO - 2016-02-27 22:02:16 --> Router Class Initialized
INFO - 2016-02-27 22:02:16 --> Output Class Initialized
INFO - 2016-02-27 22:02:16 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:16 --> Input Class Initialized
INFO - 2016-02-27 22:02:16 --> Language Class Initialized
INFO - 2016-02-27 22:02:16 --> Loader Class Initialized
INFO - 2016-02-27 22:02:16 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:16 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:16 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:16 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:16 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:18 --> Controller Class Initialized
INFO - 2016-02-27 22:02:18 --> Model Class Initialized
INFO - 2016-02-27 22:02:18 --> Model Class Initialized
INFO - 2016-02-27 22:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:18 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:18 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:18 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:19 --> Config Class Initialized
INFO - 2016-02-27 22:02:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:19 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:19 --> URI Class Initialized
INFO - 2016-02-27 22:02:19 --> Router Class Initialized
INFO - 2016-02-27 22:02:19 --> Output Class Initialized
INFO - 2016-02-27 22:02:19 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:19 --> Input Class Initialized
INFO - 2016-02-27 22:02:19 --> Language Class Initialized
INFO - 2016-02-27 22:02:19 --> Loader Class Initialized
INFO - 2016-02-27 22:02:19 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:19 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:19 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:19 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:19 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:21 --> Controller Class Initialized
INFO - 2016-02-27 22:02:21 --> Model Class Initialized
INFO - 2016-02-27 22:02:21 --> Model Class Initialized
INFO - 2016-02-27 22:02:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:21 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:21 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:21 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:21 --> Config Class Initialized
INFO - 2016-02-27 22:02:21 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:21 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:21 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:21 --> URI Class Initialized
INFO - 2016-02-27 22:02:21 --> Router Class Initialized
INFO - 2016-02-27 22:02:21 --> Output Class Initialized
INFO - 2016-02-27 22:02:21 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:21 --> Input Class Initialized
INFO - 2016-02-27 22:02:21 --> Language Class Initialized
INFO - 2016-02-27 22:02:21 --> Loader Class Initialized
INFO - 2016-02-27 22:02:21 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:21 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:21 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:21 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:21 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:22 --> Controller Class Initialized
INFO - 2016-02-27 22:02:22 --> Model Class Initialized
INFO - 2016-02-27 22:02:22 --> Model Class Initialized
INFO - 2016-02-27 22:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:22 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:22 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:22 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:27 --> Config Class Initialized
INFO - 2016-02-27 22:02:27 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:27 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:27 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:27 --> URI Class Initialized
INFO - 2016-02-27 22:02:27 --> Router Class Initialized
INFO - 2016-02-27 22:02:27 --> Output Class Initialized
INFO - 2016-02-27 22:02:27 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:27 --> Input Class Initialized
INFO - 2016-02-27 22:02:27 --> Language Class Initialized
INFO - 2016-02-27 22:02:27 --> Loader Class Initialized
INFO - 2016-02-27 22:02:27 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:27 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:27 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:27 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:27 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:28 --> Controller Class Initialized
INFO - 2016-02-27 22:02:28 --> Model Class Initialized
INFO - 2016-02-27 22:02:28 --> Model Class Initialized
INFO - 2016-02-27 22:02:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:28 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:28 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:28 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:52 --> Config Class Initialized
INFO - 2016-02-27 22:02:52 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:52 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:52 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:52 --> URI Class Initialized
INFO - 2016-02-27 22:02:52 --> Router Class Initialized
INFO - 2016-02-27 22:02:52 --> Output Class Initialized
INFO - 2016-02-27 22:02:52 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:53 --> Input Class Initialized
INFO - 2016-02-27 22:02:53 --> Language Class Initialized
INFO - 2016-02-27 22:02:53 --> Loader Class Initialized
INFO - 2016-02-27 22:02:53 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:53 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:53 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:53 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:53 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:54 --> Controller Class Initialized
INFO - 2016-02-27 22:02:54 --> Model Class Initialized
INFO - 2016-02-27 22:02:54 --> Model Class Initialized
INFO - 2016-02-27 22:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:54 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:54 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:54 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:55 --> Config Class Initialized
INFO - 2016-02-27 22:02:55 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:55 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:55 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:55 --> URI Class Initialized
INFO - 2016-02-27 22:02:55 --> Router Class Initialized
INFO - 2016-02-27 22:02:55 --> Output Class Initialized
INFO - 2016-02-27 22:02:55 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:55 --> Input Class Initialized
INFO - 2016-02-27 22:02:55 --> Language Class Initialized
INFO - 2016-02-27 22:02:55 --> Loader Class Initialized
INFO - 2016-02-27 22:02:55 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:55 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:55 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:55 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:55 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:56 --> Controller Class Initialized
INFO - 2016-02-27 22:02:56 --> Model Class Initialized
INFO - 2016-02-27 22:02:56 --> Model Class Initialized
INFO - 2016-02-27 22:02:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:56 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:56 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:56 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:02:57 --> Config Class Initialized
INFO - 2016-02-27 22:02:57 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:02:57 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:02:57 --> Utf8 Class Initialized
INFO - 2016-02-27 22:02:57 --> URI Class Initialized
INFO - 2016-02-27 22:02:57 --> Router Class Initialized
INFO - 2016-02-27 22:02:57 --> Output Class Initialized
INFO - 2016-02-27 22:02:57 --> Security Class Initialized
DEBUG - 2016-02-27 22:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:02:57 --> Input Class Initialized
INFO - 2016-02-27 22:02:57 --> Language Class Initialized
INFO - 2016-02-27 22:02:57 --> Loader Class Initialized
INFO - 2016-02-27 22:02:57 --> Helper loaded: url_helper
INFO - 2016-02-27 22:02:57 --> Helper loaded: file_helper
INFO - 2016-02-27 22:02:57 --> Helper loaded: date_helper
INFO - 2016-02-27 22:02:57 --> Helper loaded: form_helper
INFO - 2016-02-27 22:02:57 --> Database Driver Class Initialized
INFO - 2016-02-27 22:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:02:58 --> Controller Class Initialized
INFO - 2016-02-27 22:02:58 --> Model Class Initialized
INFO - 2016-02-27 22:02:58 --> Model Class Initialized
INFO - 2016-02-27 22:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:02:58 --> Pagination Class Initialized
INFO - 2016-02-27 22:02:58 --> Helper loaded: text_helper
INFO - 2016-02-27 22:02:58 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:03 --> Config Class Initialized
INFO - 2016-02-27 22:03:03 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:03 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:03 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:03 --> URI Class Initialized
INFO - 2016-02-27 22:03:03 --> Router Class Initialized
INFO - 2016-02-27 22:03:03 --> Output Class Initialized
INFO - 2016-02-27 22:03:03 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:04 --> Input Class Initialized
INFO - 2016-02-27 22:03:04 --> Language Class Initialized
INFO - 2016-02-27 22:03:04 --> Loader Class Initialized
INFO - 2016-02-27 22:03:04 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:04 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:04 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:04 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:04 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:05 --> Controller Class Initialized
INFO - 2016-02-27 22:03:05 --> Model Class Initialized
INFO - 2016-02-27 22:03:05 --> Model Class Initialized
INFO - 2016-02-27 22:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:05 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:05 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:05 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:40 --> Config Class Initialized
INFO - 2016-02-27 22:03:40 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:40 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:40 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:40 --> URI Class Initialized
INFO - 2016-02-27 22:03:40 --> Router Class Initialized
INFO - 2016-02-27 22:03:40 --> Output Class Initialized
INFO - 2016-02-27 22:03:40 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:40 --> Input Class Initialized
INFO - 2016-02-27 22:03:40 --> Language Class Initialized
INFO - 2016-02-27 22:03:40 --> Loader Class Initialized
INFO - 2016-02-27 22:03:40 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:40 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:40 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:40 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:40 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:41 --> Controller Class Initialized
INFO - 2016-02-27 22:03:41 --> Model Class Initialized
INFO - 2016-02-27 22:03:41 --> Model Class Initialized
INFO - 2016-02-27 22:03:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:41 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:41 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:41 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:41 --> Config Class Initialized
INFO - 2016-02-27 22:03:41 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:41 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:41 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:41 --> URI Class Initialized
INFO - 2016-02-27 22:03:41 --> Router Class Initialized
INFO - 2016-02-27 22:03:41 --> Output Class Initialized
INFO - 2016-02-27 22:03:41 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:41 --> Input Class Initialized
INFO - 2016-02-27 22:03:41 --> Language Class Initialized
INFO - 2016-02-27 22:03:41 --> Loader Class Initialized
INFO - 2016-02-27 22:03:41 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:41 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:41 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:41 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:41 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:42 --> Controller Class Initialized
INFO - 2016-02-27 22:03:42 --> Model Class Initialized
INFO - 2016-02-27 22:03:42 --> Model Class Initialized
INFO - 2016-02-27 22:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:42 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:42 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:42 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:43 --> Config Class Initialized
INFO - 2016-02-27 22:03:43 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:43 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:43 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:43 --> URI Class Initialized
INFO - 2016-02-27 22:03:43 --> Router Class Initialized
INFO - 2016-02-27 22:03:43 --> Output Class Initialized
INFO - 2016-02-27 22:03:43 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:43 --> Input Class Initialized
INFO - 2016-02-27 22:03:43 --> Language Class Initialized
INFO - 2016-02-27 22:03:43 --> Loader Class Initialized
INFO - 2016-02-27 22:03:43 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:43 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:43 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:43 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:43 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:44 --> Controller Class Initialized
INFO - 2016-02-27 22:03:44 --> Model Class Initialized
INFO - 2016-02-27 22:03:44 --> Model Class Initialized
INFO - 2016-02-27 22:03:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:44 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:44 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:44 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:44 --> Config Class Initialized
INFO - 2016-02-27 22:03:44 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:44 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:44 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:44 --> URI Class Initialized
INFO - 2016-02-27 22:03:44 --> Router Class Initialized
INFO - 2016-02-27 22:03:44 --> Output Class Initialized
INFO - 2016-02-27 22:03:44 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:44 --> Input Class Initialized
INFO - 2016-02-27 22:03:45 --> Language Class Initialized
INFO - 2016-02-27 22:03:45 --> Loader Class Initialized
INFO - 2016-02-27 22:03:45 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:45 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:45 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:45 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:45 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:46 --> Controller Class Initialized
INFO - 2016-02-27 22:03:46 --> Model Class Initialized
INFO - 2016-02-27 22:03:46 --> Model Class Initialized
INFO - 2016-02-27 22:03:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:46 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:46 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:46 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:47 --> Config Class Initialized
INFO - 2016-02-27 22:03:47 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:47 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:47 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:47 --> URI Class Initialized
INFO - 2016-02-27 22:03:47 --> Router Class Initialized
INFO - 2016-02-27 22:03:47 --> Output Class Initialized
INFO - 2016-02-27 22:03:47 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:47 --> Input Class Initialized
INFO - 2016-02-27 22:03:47 --> Language Class Initialized
INFO - 2016-02-27 22:03:47 --> Loader Class Initialized
INFO - 2016-02-27 22:03:47 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:47 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:47 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:47 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:47 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:48 --> Controller Class Initialized
INFO - 2016-02-27 22:03:48 --> Model Class Initialized
INFO - 2016-02-27 22:03:48 --> Model Class Initialized
INFO - 2016-02-27 22:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:48 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:48 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:48 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:50 --> Config Class Initialized
INFO - 2016-02-27 22:03:50 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:50 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:50 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:50 --> URI Class Initialized
INFO - 2016-02-27 22:03:50 --> Router Class Initialized
INFO - 2016-02-27 22:03:50 --> Output Class Initialized
INFO - 2016-02-27 22:03:50 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:50 --> Input Class Initialized
INFO - 2016-02-27 22:03:50 --> Language Class Initialized
INFO - 2016-02-27 22:03:50 --> Loader Class Initialized
INFO - 2016-02-27 22:03:50 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:50 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:50 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:50 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:50 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:51 --> Controller Class Initialized
INFO - 2016-02-27 22:03:51 --> Model Class Initialized
INFO - 2016-02-27 22:03:51 --> Model Class Initialized
INFO - 2016-02-27 22:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:51 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:51 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:51 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:03:51 --> Config Class Initialized
INFO - 2016-02-27 22:03:51 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:03:51 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:03:51 --> Utf8 Class Initialized
INFO - 2016-02-27 22:03:51 --> URI Class Initialized
INFO - 2016-02-27 22:03:51 --> Router Class Initialized
INFO - 2016-02-27 22:03:51 --> Output Class Initialized
INFO - 2016-02-27 22:03:51 --> Security Class Initialized
DEBUG - 2016-02-27 22:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:03:51 --> Input Class Initialized
INFO - 2016-02-27 22:03:51 --> Language Class Initialized
INFO - 2016-02-27 22:03:51 --> Loader Class Initialized
INFO - 2016-02-27 22:03:51 --> Helper loaded: url_helper
INFO - 2016-02-27 22:03:51 --> Helper loaded: file_helper
INFO - 2016-02-27 22:03:51 --> Helper loaded: date_helper
INFO - 2016-02-27 22:03:51 --> Helper loaded: form_helper
INFO - 2016-02-27 22:03:51 --> Database Driver Class Initialized
INFO - 2016-02-27 22:03:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:03:52 --> Controller Class Initialized
INFO - 2016-02-27 22:03:52 --> Model Class Initialized
INFO - 2016-02-27 22:03:52 --> Model Class Initialized
INFO - 2016-02-27 22:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:03:52 --> Pagination Class Initialized
INFO - 2016-02-27 22:03:52 --> Helper loaded: text_helper
INFO - 2016-02-27 22:03:52 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:04:09 --> Config Class Initialized
INFO - 2016-02-27 22:04:09 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:04:09 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:04:09 --> Utf8 Class Initialized
INFO - 2016-02-27 22:04:09 --> URI Class Initialized
INFO - 2016-02-27 22:04:09 --> Router Class Initialized
INFO - 2016-02-27 22:04:09 --> Output Class Initialized
INFO - 2016-02-27 22:04:09 --> Security Class Initialized
DEBUG - 2016-02-27 22:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:04:09 --> Input Class Initialized
INFO - 2016-02-27 22:04:09 --> Language Class Initialized
INFO - 2016-02-27 22:04:09 --> Loader Class Initialized
INFO - 2016-02-27 22:04:09 --> Helper loaded: url_helper
INFO - 2016-02-27 22:04:09 --> Helper loaded: file_helper
INFO - 2016-02-27 22:04:09 --> Helper loaded: date_helper
INFO - 2016-02-27 22:04:09 --> Helper loaded: form_helper
INFO - 2016-02-27 22:04:09 --> Database Driver Class Initialized
INFO - 2016-02-27 22:04:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:04:10 --> Controller Class Initialized
INFO - 2016-02-27 22:04:10 --> Model Class Initialized
INFO - 2016-02-27 22:04:10 --> Model Class Initialized
INFO - 2016-02-27 22:04:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:04:10 --> Pagination Class Initialized
INFO - 2016-02-27 22:04:10 --> Helper loaded: text_helper
INFO - 2016-02-27 22:04:10 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:04:10 --> Config Class Initialized
INFO - 2016-02-27 22:04:10 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:04:10 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:04:10 --> Utf8 Class Initialized
INFO - 2016-02-27 22:04:10 --> URI Class Initialized
INFO - 2016-02-27 22:04:10 --> Router Class Initialized
INFO - 2016-02-27 22:04:10 --> Output Class Initialized
INFO - 2016-02-27 22:04:10 --> Security Class Initialized
DEBUG - 2016-02-27 22:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:04:10 --> Input Class Initialized
INFO - 2016-02-27 22:04:10 --> Language Class Initialized
INFO - 2016-02-27 22:04:10 --> Loader Class Initialized
INFO - 2016-02-27 22:04:10 --> Helper loaded: url_helper
INFO - 2016-02-27 22:04:10 --> Helper loaded: file_helper
INFO - 2016-02-27 22:04:10 --> Helper loaded: date_helper
INFO - 2016-02-27 22:04:10 --> Helper loaded: form_helper
INFO - 2016-02-27 22:04:10 --> Database Driver Class Initialized
INFO - 2016-02-27 22:04:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:04:11 --> Controller Class Initialized
INFO - 2016-02-27 22:04:11 --> Model Class Initialized
INFO - 2016-02-27 22:04:11 --> Model Class Initialized
INFO - 2016-02-27 22:04:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:04:11 --> Pagination Class Initialized
INFO - 2016-02-27 22:04:11 --> Helper loaded: text_helper
INFO - 2016-02-27 22:04:11 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:04:19 --> Config Class Initialized
INFO - 2016-02-27 22:04:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:04:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:04:19 --> Utf8 Class Initialized
INFO - 2016-02-27 22:04:19 --> URI Class Initialized
INFO - 2016-02-27 22:04:19 --> Router Class Initialized
INFO - 2016-02-27 22:04:19 --> Output Class Initialized
INFO - 2016-02-27 22:04:19 --> Security Class Initialized
DEBUG - 2016-02-27 22:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:04:19 --> Input Class Initialized
INFO - 2016-02-27 22:04:19 --> Language Class Initialized
INFO - 2016-02-27 22:04:19 --> Loader Class Initialized
INFO - 2016-02-27 22:04:19 --> Helper loaded: url_helper
INFO - 2016-02-27 22:04:19 --> Helper loaded: file_helper
INFO - 2016-02-27 22:04:19 --> Helper loaded: date_helper
INFO - 2016-02-27 22:04:19 --> Helper loaded: form_helper
INFO - 2016-02-27 22:04:19 --> Database Driver Class Initialized
INFO - 2016-02-27 22:04:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:04:20 --> Controller Class Initialized
INFO - 2016-02-27 22:04:20 --> Model Class Initialized
INFO - 2016-02-27 22:04:20 --> Model Class Initialized
INFO - 2016-02-27 22:04:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:04:20 --> Pagination Class Initialized
INFO - 2016-02-27 22:04:20 --> Helper loaded: text_helper
INFO - 2016-02-27 22:04:20 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:04:20 --> Config Class Initialized
INFO - 2016-02-27 22:04:20 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:04:20 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:04:20 --> Utf8 Class Initialized
INFO - 2016-02-27 22:04:20 --> URI Class Initialized
INFO - 2016-02-27 22:04:20 --> Router Class Initialized
INFO - 2016-02-27 22:04:20 --> Output Class Initialized
INFO - 2016-02-27 22:04:20 --> Security Class Initialized
DEBUG - 2016-02-27 22:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:04:20 --> Input Class Initialized
INFO - 2016-02-27 22:04:20 --> Language Class Initialized
INFO - 2016-02-27 22:04:20 --> Loader Class Initialized
INFO - 2016-02-27 22:04:20 --> Helper loaded: url_helper
INFO - 2016-02-27 22:04:20 --> Helper loaded: file_helper
INFO - 2016-02-27 22:04:20 --> Helper loaded: date_helper
INFO - 2016-02-27 22:04:20 --> Helper loaded: form_helper
INFO - 2016-02-27 22:04:20 --> Database Driver Class Initialized
INFO - 2016-02-27 22:04:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:04:21 --> Controller Class Initialized
INFO - 2016-02-27 22:04:21 --> Model Class Initialized
INFO - 2016-02-27 22:04:21 --> Model Class Initialized
INFO - 2016-02-27 22:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:04:21 --> Pagination Class Initialized
INFO - 2016-02-27 22:04:21 --> Helper loaded: text_helper
INFO - 2016-02-27 22:04:21 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:09:02 --> Config Class Initialized
INFO - 2016-02-27 22:09:02 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:09:02 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:09:02 --> Utf8 Class Initialized
INFO - 2016-02-27 22:09:02 --> URI Class Initialized
INFO - 2016-02-27 22:09:02 --> Router Class Initialized
INFO - 2016-02-27 22:09:02 --> Output Class Initialized
INFO - 2016-02-27 22:09:02 --> Security Class Initialized
DEBUG - 2016-02-27 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:09:02 --> Input Class Initialized
INFO - 2016-02-27 22:09:02 --> Language Class Initialized
INFO - 2016-02-27 22:09:02 --> Loader Class Initialized
INFO - 2016-02-27 22:09:02 --> Helper loaded: url_helper
INFO - 2016-02-27 22:09:02 --> Helper loaded: file_helper
INFO - 2016-02-27 22:09:02 --> Helper loaded: date_helper
INFO - 2016-02-27 22:09:02 --> Helper loaded: form_helper
INFO - 2016-02-27 22:09:02 --> Database Driver Class Initialized
INFO - 2016-02-27 22:09:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:09:03 --> Controller Class Initialized
INFO - 2016-02-27 22:09:03 --> Model Class Initialized
INFO - 2016-02-27 22:09:03 --> Model Class Initialized
INFO - 2016-02-27 22:09:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:09:03 --> Pagination Class Initialized
INFO - 2016-02-27 22:09:03 --> Helper loaded: text_helper
INFO - 2016-02-27 22:09:03 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:09:03 --> Config Class Initialized
INFO - 2016-02-27 22:09:03 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:09:03 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:09:03 --> Utf8 Class Initialized
INFO - 2016-02-27 22:09:03 --> URI Class Initialized
INFO - 2016-02-27 22:09:03 --> Router Class Initialized
INFO - 2016-02-27 22:09:03 --> Output Class Initialized
INFO - 2016-02-27 22:09:03 --> Security Class Initialized
DEBUG - 2016-02-27 22:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:09:03 --> Input Class Initialized
INFO - 2016-02-27 22:09:03 --> Language Class Initialized
INFO - 2016-02-27 22:09:03 --> Loader Class Initialized
INFO - 2016-02-27 22:09:03 --> Helper loaded: url_helper
INFO - 2016-02-27 22:09:03 --> Helper loaded: file_helper
INFO - 2016-02-27 22:09:03 --> Helper loaded: date_helper
INFO - 2016-02-27 22:09:03 --> Helper loaded: form_helper
INFO - 2016-02-27 22:09:03 --> Database Driver Class Initialized
INFO - 2016-02-27 22:09:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:09:04 --> Controller Class Initialized
INFO - 2016-02-27 22:09:04 --> Model Class Initialized
INFO - 2016-02-27 22:09:04 --> Model Class Initialized
INFO - 2016-02-27 22:09:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:09:04 --> Pagination Class Initialized
INFO - 2016-02-27 22:09:04 --> Helper loaded: text_helper
INFO - 2016-02-27 22:09:04 --> Helper loaded: cookie_helper
INFO - 2016-02-27 22:09:19 --> Config Class Initialized
INFO - 2016-02-27 22:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-27 22:09:19 --> UTF-8 Support Enabled
INFO - 2016-02-27 22:09:19 --> Utf8 Class Initialized
INFO - 2016-02-27 22:09:19 --> URI Class Initialized
INFO - 2016-02-27 22:09:19 --> Router Class Initialized
INFO - 2016-02-27 22:09:19 --> Output Class Initialized
INFO - 2016-02-27 22:09:19 --> Security Class Initialized
DEBUG - 2016-02-27 22:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-27 22:09:19 --> Input Class Initialized
INFO - 2016-02-27 22:09:19 --> Language Class Initialized
INFO - 2016-02-27 22:09:19 --> Loader Class Initialized
INFO - 2016-02-27 22:09:19 --> Helper loaded: url_helper
INFO - 2016-02-27 22:09:19 --> Helper loaded: file_helper
INFO - 2016-02-27 22:09:19 --> Helper loaded: date_helper
INFO - 2016-02-27 22:09:19 --> Helper loaded: form_helper
INFO - 2016-02-27 22:09:19 --> Database Driver Class Initialized
INFO - 2016-02-27 22:09:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-27 22:09:20 --> Controller Class Initialized
INFO - 2016-02-27 22:09:20 --> Model Class Initialized
INFO - 2016-02-27 22:09:20 --> Model Class Initialized
INFO - 2016-02-27 22:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-27 22:09:20 --> Pagination Class Initialized
INFO - 2016-02-27 22:09:20 --> Helper loaded: text_helper
INFO - 2016-02-27 22:09:20 --> Helper loaded: cookie_helper
