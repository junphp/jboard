<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-04-16 09:38:30 --> Config Class Initialized
INFO - 2016-04-16 09:38:30 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:38:30 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:38:30 --> Utf8 Class Initialized
INFO - 2016-04-16 09:38:30 --> URI Class Initialized
DEBUG - 2016-04-16 09:38:30 --> No URI present. Default controller set.
INFO - 2016-04-16 09:38:30 --> Router Class Initialized
INFO - 2016-04-16 09:38:30 --> Output Class Initialized
INFO - 2016-04-16 09:38:30 --> Security Class Initialized
DEBUG - 2016-04-16 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:38:30 --> Input Class Initialized
INFO - 2016-04-16 09:38:30 --> Language Class Initialized
INFO - 2016-04-16 09:38:30 --> Loader Class Initialized
INFO - 2016-04-16 09:38:30 --> Helper loaded: url_helper
INFO - 2016-04-16 09:38:30 --> Helper loaded: file_helper
INFO - 2016-04-16 09:38:30 --> Helper loaded: date_helper
INFO - 2016-04-16 09:38:30 --> Helper loaded: form_helper
INFO - 2016-04-16 09:38:30 --> Database Driver Class Initialized
INFO - 2016-04-16 09:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:38:33 --> Controller Class Initialized
INFO - 2016-04-16 09:38:33 --> Model Class Initialized
INFO - 2016-04-16 09:38:33 --> Model Class Initialized
INFO - 2016-04-16 09:38:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:38:33 --> Pagination Class Initialized
INFO - 2016-04-16 09:38:33 --> Helper loaded: text_helper
INFO - 2016-04-16 09:38:33 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-16 12:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-16 12:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-16 12:38:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-16 12:38:33 --> Final output sent to browser
DEBUG - 2016-04-16 12:38:33 --> Total execution time: 2.8661
INFO - 2016-04-16 09:38:48 --> Config Class Initialized
INFO - 2016-04-16 09:38:48 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:38:48 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:38:48 --> Utf8 Class Initialized
INFO - 2016-04-16 09:38:48 --> URI Class Initialized
INFO - 2016-04-16 09:38:48 --> Router Class Initialized
INFO - 2016-04-16 09:38:48 --> Output Class Initialized
INFO - 2016-04-16 09:38:48 --> Security Class Initialized
DEBUG - 2016-04-16 09:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:38:48 --> Input Class Initialized
INFO - 2016-04-16 09:38:48 --> Language Class Initialized
INFO - 2016-04-16 09:38:48 --> Loader Class Initialized
INFO - 2016-04-16 09:38:48 --> Helper loaded: url_helper
INFO - 2016-04-16 09:38:48 --> Helper loaded: file_helper
INFO - 2016-04-16 09:38:48 --> Helper loaded: date_helper
INFO - 2016-04-16 09:38:48 --> Helper loaded: form_helper
INFO - 2016-04-16 09:38:48 --> Database Driver Class Initialized
INFO - 2016-04-16 09:38:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:38:49 --> Controller Class Initialized
INFO - 2016-04-16 09:38:49 --> User Agent Class Initialized
INFO - 2016-04-16 09:38:49 --> Final output sent to browser
DEBUG - 2016-04-16 09:38:49 --> Total execution time: 1.2102
INFO - 2016-04-16 09:38:58 --> Config Class Initialized
INFO - 2016-04-16 09:38:58 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:38:58 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:38:58 --> Utf8 Class Initialized
INFO - 2016-04-16 09:38:58 --> URI Class Initialized
DEBUG - 2016-04-16 09:38:58 --> No URI present. Default controller set.
INFO - 2016-04-16 09:38:58 --> Router Class Initialized
INFO - 2016-04-16 09:38:58 --> Output Class Initialized
INFO - 2016-04-16 09:38:58 --> Security Class Initialized
DEBUG - 2016-04-16 09:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:38:58 --> Input Class Initialized
INFO - 2016-04-16 09:38:58 --> Language Class Initialized
INFO - 2016-04-16 09:38:58 --> Loader Class Initialized
INFO - 2016-04-16 09:38:58 --> Helper loaded: url_helper
INFO - 2016-04-16 09:38:58 --> Helper loaded: file_helper
INFO - 2016-04-16 09:38:58 --> Helper loaded: date_helper
INFO - 2016-04-16 09:38:58 --> Helper loaded: form_helper
INFO - 2016-04-16 09:38:58 --> Database Driver Class Initialized
INFO - 2016-04-16 09:38:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:38:59 --> Controller Class Initialized
INFO - 2016-04-16 09:38:59 --> Model Class Initialized
INFO - 2016-04-16 09:38:59 --> Model Class Initialized
INFO - 2016-04-16 09:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:38:59 --> Pagination Class Initialized
INFO - 2016-04-16 09:38:59 --> Helper loaded: text_helper
INFO - 2016-04-16 09:38:59 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-16 12:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-16 12:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-16 12:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-16 12:38:59 --> Final output sent to browser
DEBUG - 2016-04-16 12:38:59 --> Total execution time: 1.1054
INFO - 2016-04-16 09:39:01 --> Config Class Initialized
INFO - 2016-04-16 09:39:01 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:39:01 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:39:01 --> Utf8 Class Initialized
INFO - 2016-04-16 09:39:01 --> URI Class Initialized
INFO - 2016-04-16 09:39:01 --> Router Class Initialized
INFO - 2016-04-16 09:39:01 --> Output Class Initialized
INFO - 2016-04-16 09:39:01 --> Security Class Initialized
DEBUG - 2016-04-16 09:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:39:01 --> Input Class Initialized
INFO - 2016-04-16 09:39:01 --> Language Class Initialized
INFO - 2016-04-16 09:39:01 --> Loader Class Initialized
INFO - 2016-04-16 09:39:01 --> Helper loaded: url_helper
INFO - 2016-04-16 09:39:01 --> Helper loaded: file_helper
INFO - 2016-04-16 09:39:01 --> Helper loaded: date_helper
INFO - 2016-04-16 09:39:01 --> Helper loaded: form_helper
INFO - 2016-04-16 09:39:01 --> Database Driver Class Initialized
INFO - 2016-04-16 09:39:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:39:02 --> Controller Class Initialized
INFO - 2016-04-16 09:39:02 --> Model Class Initialized
INFO - 2016-04-16 09:39:02 --> Model Class Initialized
INFO - 2016-04-16 09:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:39:02 --> Pagination Class Initialized
INFO - 2016-04-16 09:39:02 --> Helper loaded: text_helper
INFO - 2016-04-16 09:39:02 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-16 12:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-16 12:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-04-16 12:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-04-16 12:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-16 12:39:02 --> Final output sent to browser
DEBUG - 2016-04-16 12:39:02 --> Total execution time: 1.2303
INFO - 2016-04-16 09:40:49 --> Config Class Initialized
INFO - 2016-04-16 09:40:49 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:40:49 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:40:49 --> Utf8 Class Initialized
INFO - 2016-04-16 09:40:49 --> URI Class Initialized
INFO - 2016-04-16 09:40:49 --> Router Class Initialized
INFO - 2016-04-16 09:40:49 --> Output Class Initialized
INFO - 2016-04-16 09:40:49 --> Security Class Initialized
DEBUG - 2016-04-16 09:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:40:49 --> Input Class Initialized
INFO - 2016-04-16 09:40:49 --> Language Class Initialized
INFO - 2016-04-16 09:40:49 --> Loader Class Initialized
INFO - 2016-04-16 09:40:49 --> Helper loaded: url_helper
INFO - 2016-04-16 09:40:49 --> Helper loaded: file_helper
INFO - 2016-04-16 09:40:49 --> Helper loaded: date_helper
INFO - 2016-04-16 09:40:49 --> Helper loaded: form_helper
INFO - 2016-04-16 09:40:49 --> Database Driver Class Initialized
INFO - 2016-04-16 09:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:40:50 --> Controller Class Initialized
INFO - 2016-04-16 09:40:50 --> Model Class Initialized
INFO - 2016-04-16 09:40:50 --> Model Class Initialized
INFO - 2016-04-16 09:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:40:50 --> Pagination Class Initialized
INFO - 2016-04-16 09:40:50 --> Helper loaded: text_helper
INFO - 2016-04-16 09:40:50 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-16 12:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-16 12:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-04-16 12:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-04-16 12:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-16 12:40:50 --> Final output sent to browser
DEBUG - 2016-04-16 12:40:50 --> Total execution time: 1.1102
INFO - 2016-04-16 09:41:16 --> Config Class Initialized
INFO - 2016-04-16 09:41:16 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:41:16 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:41:16 --> Utf8 Class Initialized
INFO - 2016-04-16 09:41:16 --> URI Class Initialized
INFO - 2016-04-16 09:41:16 --> Router Class Initialized
INFO - 2016-04-16 09:41:16 --> Output Class Initialized
INFO - 2016-04-16 09:41:16 --> Security Class Initialized
DEBUG - 2016-04-16 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:41:16 --> Input Class Initialized
INFO - 2016-04-16 09:41:16 --> Language Class Initialized
INFO - 2016-04-16 09:41:16 --> Loader Class Initialized
INFO - 2016-04-16 09:41:16 --> Helper loaded: url_helper
INFO - 2016-04-16 09:41:16 --> Helper loaded: file_helper
INFO - 2016-04-16 09:41:16 --> Helper loaded: date_helper
INFO - 2016-04-16 09:41:16 --> Helper loaded: form_helper
INFO - 2016-04-16 09:41:16 --> Database Driver Class Initialized
INFO - 2016-04-16 09:41:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:41:17 --> Controller Class Initialized
INFO - 2016-04-16 09:41:17 --> User Agent Class Initialized
INFO - 2016-04-16 09:41:17 --> Final output sent to browser
DEBUG - 2016-04-16 09:41:17 --> Total execution time: 1.1037
INFO - 2016-04-16 09:41:49 --> Config Class Initialized
INFO - 2016-04-16 09:41:49 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:41:49 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:41:49 --> Utf8 Class Initialized
INFO - 2016-04-16 09:41:49 --> URI Class Initialized
INFO - 2016-04-16 09:41:49 --> Router Class Initialized
INFO - 2016-04-16 09:41:49 --> Output Class Initialized
INFO - 2016-04-16 09:41:49 --> Security Class Initialized
DEBUG - 2016-04-16 09:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:41:49 --> Input Class Initialized
INFO - 2016-04-16 09:41:49 --> Language Class Initialized
INFO - 2016-04-16 09:41:49 --> Loader Class Initialized
INFO - 2016-04-16 09:41:49 --> Helper loaded: url_helper
INFO - 2016-04-16 09:41:49 --> Helper loaded: file_helper
INFO - 2016-04-16 09:41:49 --> Helper loaded: date_helper
INFO - 2016-04-16 09:41:49 --> Helper loaded: form_helper
INFO - 2016-04-16 09:41:49 --> Database Driver Class Initialized
INFO - 2016-04-16 09:41:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:41:50 --> Controller Class Initialized
INFO - 2016-04-16 09:41:50 --> Model Class Initialized
INFO - 2016-04-16 09:41:50 --> Model Class Initialized
INFO - 2016-04-16 09:41:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:41:50 --> Pagination Class Initialized
INFO - 2016-04-16 09:41:50 --> Helper loaded: text_helper
INFO - 2016-04-16 09:41:50 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 12:41:51 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 4
INFO - 2016-04-16 09:42:17 --> Config Class Initialized
INFO - 2016-04-16 09:42:17 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:42:17 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:42:17 --> Utf8 Class Initialized
INFO - 2016-04-16 09:42:17 --> URI Class Initialized
INFO - 2016-04-16 09:42:17 --> Router Class Initialized
INFO - 2016-04-16 09:42:17 --> Output Class Initialized
INFO - 2016-04-16 09:42:17 --> Security Class Initialized
DEBUG - 2016-04-16 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:42:17 --> Input Class Initialized
INFO - 2016-04-16 09:42:17 --> Language Class Initialized
INFO - 2016-04-16 09:42:17 --> Loader Class Initialized
INFO - 2016-04-16 09:42:17 --> Helper loaded: url_helper
INFO - 2016-04-16 09:42:17 --> Helper loaded: file_helper
INFO - 2016-04-16 09:42:17 --> Helper loaded: date_helper
INFO - 2016-04-16 09:42:17 --> Helper loaded: form_helper
INFO - 2016-04-16 09:42:17 --> Database Driver Class Initialized
INFO - 2016-04-16 09:42:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:42:18 --> Controller Class Initialized
INFO - 2016-04-16 09:42:18 --> Model Class Initialized
INFO - 2016-04-16 09:42:18 --> Model Class Initialized
INFO - 2016-04-16 09:42:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:42:18 --> Pagination Class Initialized
INFO - 2016-04-16 09:42:18 --> Helper loaded: text_helper
INFO - 2016-04-16 09:42:18 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 12:42:20 --> Final output sent to browser
DEBUG - 2016-04-16 12:42:20 --> Total execution time: 3.4304
INFO - 2016-04-16 09:45:12 --> Config Class Initialized
INFO - 2016-04-16 09:45:12 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:45:12 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:45:12 --> Utf8 Class Initialized
INFO - 2016-04-16 09:45:12 --> URI Class Initialized
INFO - 2016-04-16 09:45:12 --> Router Class Initialized
INFO - 2016-04-16 09:45:12 --> Output Class Initialized
INFO - 2016-04-16 09:45:12 --> Security Class Initialized
DEBUG - 2016-04-16 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:45:12 --> Input Class Initialized
INFO - 2016-04-16 09:45:12 --> Language Class Initialized
INFO - 2016-04-16 09:45:12 --> Loader Class Initialized
INFO - 2016-04-16 09:45:12 --> Helper loaded: url_helper
INFO - 2016-04-16 09:45:12 --> Helper loaded: file_helper
INFO - 2016-04-16 09:45:12 --> Helper loaded: date_helper
INFO - 2016-04-16 09:45:12 --> Helper loaded: form_helper
INFO - 2016-04-16 09:45:12 --> Database Driver Class Initialized
INFO - 2016-04-16 09:45:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:45:13 --> Controller Class Initialized
INFO - 2016-04-16 09:45:13 --> Model Class Initialized
INFO - 2016-04-16 09:45:13 --> Model Class Initialized
INFO - 2016-04-16 09:45:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:45:13 --> Pagination Class Initialized
INFO - 2016-04-16 09:45:13 --> Helper loaded: text_helper
INFO - 2016-04-16 09:45:13 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:45:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 12:45:15 --> Final output sent to browser
DEBUG - 2016-04-16 12:45:15 --> Total execution time: 3.2234
INFO - 2016-04-16 09:45:15 --> Config Class Initialized
INFO - 2016-04-16 09:45:15 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:45:15 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:45:15 --> Utf8 Class Initialized
INFO - 2016-04-16 09:45:15 --> URI Class Initialized
INFO - 2016-04-16 09:45:15 --> Router Class Initialized
INFO - 2016-04-16 09:45:15 --> Output Class Initialized
INFO - 2016-04-16 09:45:15 --> Security Class Initialized
DEBUG - 2016-04-16 09:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:45:15 --> Input Class Initialized
INFO - 2016-04-16 09:45:15 --> Language Class Initialized
INFO - 2016-04-16 09:45:15 --> Loader Class Initialized
INFO - 2016-04-16 09:45:15 --> Helper loaded: url_helper
INFO - 2016-04-16 09:45:15 --> Helper loaded: file_helper
INFO - 2016-04-16 09:45:15 --> Helper loaded: date_helper
INFO - 2016-04-16 09:45:15 --> Helper loaded: form_helper
INFO - 2016-04-16 09:45:15 --> Database Driver Class Initialized
INFO - 2016-04-16 09:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:45:16 --> Controller Class Initialized
INFO - 2016-04-16 09:45:16 --> User Agent Class Initialized
INFO - 2016-04-16 09:45:16 --> Final output sent to browser
DEBUG - 2016-04-16 09:45:16 --> Total execution time: 1.1082
INFO - 2016-04-16 09:47:30 --> Config Class Initialized
INFO - 2016-04-16 09:47:30 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:47:30 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:47:30 --> Utf8 Class Initialized
INFO - 2016-04-16 09:47:30 --> URI Class Initialized
INFO - 2016-04-16 09:47:30 --> Router Class Initialized
INFO - 2016-04-16 09:47:30 --> Output Class Initialized
INFO - 2016-04-16 09:47:30 --> Security Class Initialized
DEBUG - 2016-04-16 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:47:30 --> Input Class Initialized
INFO - 2016-04-16 09:47:30 --> Language Class Initialized
INFO - 2016-04-16 09:47:30 --> Loader Class Initialized
INFO - 2016-04-16 09:47:30 --> Helper loaded: url_helper
INFO - 2016-04-16 09:47:30 --> Helper loaded: file_helper
INFO - 2016-04-16 09:47:30 --> Helper loaded: date_helper
INFO - 2016-04-16 09:47:30 --> Helper loaded: form_helper
INFO - 2016-04-16 09:47:30 --> Database Driver Class Initialized
INFO - 2016-04-16 09:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:47:31 --> Controller Class Initialized
INFO - 2016-04-16 09:47:31 --> Model Class Initialized
INFO - 2016-04-16 09:47:31 --> Model Class Initialized
INFO - 2016-04-16 09:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:47:32 --> Pagination Class Initialized
INFO - 2016-04-16 09:47:32 --> Helper loaded: text_helper
INFO - 2016-04-16 09:47:32 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 12:47:32 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 8
INFO - 2016-04-16 09:48:19 --> Config Class Initialized
INFO - 2016-04-16 09:48:19 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:48:19 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:48:19 --> Utf8 Class Initialized
INFO - 2016-04-16 09:48:19 --> URI Class Initialized
INFO - 2016-04-16 09:48:19 --> Router Class Initialized
INFO - 2016-04-16 09:48:19 --> Output Class Initialized
INFO - 2016-04-16 09:48:19 --> Security Class Initialized
DEBUG - 2016-04-16 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:48:19 --> Input Class Initialized
INFO - 2016-04-16 09:48:19 --> Language Class Initialized
INFO - 2016-04-16 09:48:19 --> Loader Class Initialized
INFO - 2016-04-16 09:48:19 --> Helper loaded: url_helper
INFO - 2016-04-16 09:48:19 --> Helper loaded: file_helper
INFO - 2016-04-16 09:48:19 --> Helper loaded: date_helper
INFO - 2016-04-16 09:48:19 --> Helper loaded: form_helper
INFO - 2016-04-16 09:48:19 --> Database Driver Class Initialized
INFO - 2016-04-16 09:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:48:20 --> Controller Class Initialized
INFO - 2016-04-16 09:48:20 --> Model Class Initialized
INFO - 2016-04-16 09:48:20 --> Model Class Initialized
INFO - 2016-04-16 09:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:48:20 --> Pagination Class Initialized
INFO - 2016-04-16 09:48:20 --> Helper loaded: text_helper
INFO - 2016-04-16 09:48:20 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 12:48:22 --> Final output sent to browser
DEBUG - 2016-04-16 12:48:22 --> Total execution time: 2.8529
INFO - 2016-04-16 09:48:22 --> Config Class Initialized
INFO - 2016-04-16 09:48:22 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:48:22 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:48:22 --> Utf8 Class Initialized
INFO - 2016-04-16 09:48:22 --> URI Class Initialized
INFO - 2016-04-16 09:48:22 --> Router Class Initialized
INFO - 2016-04-16 09:48:22 --> Output Class Initialized
INFO - 2016-04-16 09:48:22 --> Security Class Initialized
DEBUG - 2016-04-16 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:48:22 --> Input Class Initialized
INFO - 2016-04-16 09:48:22 --> Language Class Initialized
INFO - 2016-04-16 09:48:22 --> Loader Class Initialized
INFO - 2016-04-16 09:48:22 --> Helper loaded: url_helper
INFO - 2016-04-16 09:48:22 --> Helper loaded: file_helper
INFO - 2016-04-16 09:48:22 --> Helper loaded: date_helper
INFO - 2016-04-16 09:48:22 --> Helper loaded: form_helper
INFO - 2016-04-16 09:48:22 --> Database Driver Class Initialized
INFO - 2016-04-16 09:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:48:23 --> Controller Class Initialized
INFO - 2016-04-16 09:48:23 --> User Agent Class Initialized
INFO - 2016-04-16 09:48:23 --> Final output sent to browser
DEBUG - 2016-04-16 09:48:23 --> Total execution time: 1.0999
INFO - 2016-04-16 09:53:20 --> Config Class Initialized
INFO - 2016-04-16 09:53:20 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:53:20 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:53:20 --> Utf8 Class Initialized
INFO - 2016-04-16 09:53:20 --> URI Class Initialized
INFO - 2016-04-16 09:53:20 --> Router Class Initialized
INFO - 2016-04-16 09:53:20 --> Output Class Initialized
INFO - 2016-04-16 09:53:20 --> Security Class Initialized
DEBUG - 2016-04-16 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:53:20 --> Input Class Initialized
INFO - 2016-04-16 09:53:20 --> Language Class Initialized
INFO - 2016-04-16 09:53:20 --> Loader Class Initialized
INFO - 2016-04-16 09:53:20 --> Helper loaded: url_helper
INFO - 2016-04-16 09:53:20 --> Helper loaded: file_helper
INFO - 2016-04-16 09:53:20 --> Helper loaded: date_helper
INFO - 2016-04-16 09:53:20 --> Helper loaded: form_helper
INFO - 2016-04-16 09:53:20 --> Database Driver Class Initialized
INFO - 2016-04-16 09:53:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:53:21 --> Controller Class Initialized
INFO - 2016-04-16 09:53:21 --> Model Class Initialized
INFO - 2016-04-16 09:53:21 --> Model Class Initialized
INFO - 2016-04-16 09:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:53:21 --> Pagination Class Initialized
INFO - 2016-04-16 09:53:21 --> Helper loaded: text_helper
INFO - 2016-04-16 09:53:21 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:53:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 12:53:22 --> Final output sent to browser
DEBUG - 2016-04-16 12:53:22 --> Total execution time: 2.9302
INFO - 2016-04-16 09:53:23 --> Config Class Initialized
INFO - 2016-04-16 09:53:23 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:53:23 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:53:23 --> Utf8 Class Initialized
INFO - 2016-04-16 09:53:23 --> URI Class Initialized
INFO - 2016-04-16 09:53:23 --> Router Class Initialized
INFO - 2016-04-16 09:53:23 --> Output Class Initialized
INFO - 2016-04-16 09:53:23 --> Security Class Initialized
DEBUG - 2016-04-16 09:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:53:23 --> Input Class Initialized
INFO - 2016-04-16 09:53:23 --> Language Class Initialized
INFO - 2016-04-16 09:53:23 --> Loader Class Initialized
INFO - 2016-04-16 09:53:23 --> Helper loaded: url_helper
INFO - 2016-04-16 09:53:23 --> Helper loaded: file_helper
INFO - 2016-04-16 09:53:23 --> Helper loaded: date_helper
INFO - 2016-04-16 09:53:23 --> Helper loaded: form_helper
INFO - 2016-04-16 09:53:23 --> Database Driver Class Initialized
INFO - 2016-04-16 09:53:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:53:24 --> Controller Class Initialized
INFO - 2016-04-16 09:53:24 --> User Agent Class Initialized
INFO - 2016-04-16 09:53:24 --> Final output sent to browser
DEBUG - 2016-04-16 09:53:24 --> Total execution time: 1.0952
INFO - 2016-04-16 09:56:08 --> Config Class Initialized
INFO - 2016-04-16 09:56:08 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:56:08 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:56:08 --> Utf8 Class Initialized
INFO - 2016-04-16 09:56:08 --> URI Class Initialized
INFO - 2016-04-16 09:56:08 --> Router Class Initialized
INFO - 2016-04-16 09:56:08 --> Output Class Initialized
INFO - 2016-04-16 09:56:08 --> Security Class Initialized
DEBUG - 2016-04-16 09:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:56:08 --> Input Class Initialized
INFO - 2016-04-16 09:56:08 --> Language Class Initialized
INFO - 2016-04-16 09:56:08 --> Loader Class Initialized
INFO - 2016-04-16 09:56:08 --> Helper loaded: url_helper
INFO - 2016-04-16 09:56:08 --> Helper loaded: file_helper
INFO - 2016-04-16 09:56:08 --> Helper loaded: date_helper
INFO - 2016-04-16 09:56:08 --> Helper loaded: form_helper
INFO - 2016-04-16 09:56:08 --> Database Driver Class Initialized
INFO - 2016-04-16 09:56:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:56:09 --> Controller Class Initialized
INFO - 2016-04-16 09:56:09 --> Model Class Initialized
INFO - 2016-04-16 09:56:09 --> Model Class Initialized
INFO - 2016-04-16 09:56:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 09:56:09 --> Pagination Class Initialized
INFO - 2016-04-16 09:56:09 --> Helper loaded: text_helper
INFO - 2016-04-16 09:56:09 --> Helper loaded: cookie_helper
INFO - 2016-04-16 12:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 12:56:12 --> Final output sent to browser
DEBUG - 2016-04-16 12:56:12 --> Total execution time: 4.2829
INFO - 2016-04-16 09:56:12 --> Config Class Initialized
INFO - 2016-04-16 09:56:12 --> Hooks Class Initialized
DEBUG - 2016-04-16 09:56:12 --> UTF-8 Support Enabled
INFO - 2016-04-16 09:56:12 --> Utf8 Class Initialized
INFO - 2016-04-16 09:56:12 --> URI Class Initialized
INFO - 2016-04-16 09:56:12 --> Router Class Initialized
INFO - 2016-04-16 09:56:12 --> Output Class Initialized
INFO - 2016-04-16 09:56:12 --> Security Class Initialized
DEBUG - 2016-04-16 09:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 09:56:12 --> Input Class Initialized
INFO - 2016-04-16 09:56:12 --> Language Class Initialized
INFO - 2016-04-16 09:56:12 --> Loader Class Initialized
INFO - 2016-04-16 09:56:13 --> Helper loaded: url_helper
INFO - 2016-04-16 09:56:13 --> Helper loaded: file_helper
INFO - 2016-04-16 09:56:13 --> Helper loaded: date_helper
INFO - 2016-04-16 09:56:13 --> Helper loaded: form_helper
INFO - 2016-04-16 09:56:13 --> Database Driver Class Initialized
INFO - 2016-04-16 09:56:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 09:56:14 --> Controller Class Initialized
INFO - 2016-04-16 09:56:14 --> User Agent Class Initialized
INFO - 2016-04-16 09:56:14 --> Final output sent to browser
DEBUG - 2016-04-16 09:56:14 --> Total execution time: 1.0991
INFO - 2016-04-16 10:03:42 --> Config Class Initialized
INFO - 2016-04-16 10:03:42 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:03:42 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:03:42 --> Utf8 Class Initialized
INFO - 2016-04-16 10:03:42 --> URI Class Initialized
INFO - 2016-04-16 10:03:42 --> Router Class Initialized
INFO - 2016-04-16 10:03:42 --> Output Class Initialized
INFO - 2016-04-16 10:03:42 --> Security Class Initialized
DEBUG - 2016-04-16 10:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:03:42 --> Input Class Initialized
INFO - 2016-04-16 10:03:42 --> Language Class Initialized
INFO - 2016-04-16 10:03:42 --> Loader Class Initialized
INFO - 2016-04-16 10:03:42 --> Helper loaded: url_helper
INFO - 2016-04-16 10:03:42 --> Helper loaded: file_helper
INFO - 2016-04-16 10:03:42 --> Helper loaded: date_helper
INFO - 2016-04-16 10:03:42 --> Helper loaded: form_helper
INFO - 2016-04-16 10:03:42 --> Database Driver Class Initialized
INFO - 2016-04-16 10:03:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:03:43 --> Controller Class Initialized
INFO - 2016-04-16 10:03:43 --> Model Class Initialized
INFO - 2016-04-16 10:03:43 --> Model Class Initialized
INFO - 2016-04-16 10:03:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:03:43 --> Pagination Class Initialized
INFO - 2016-04-16 10:03:43 --> Helper loaded: text_helper
INFO - 2016-04-16 10:03:43 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:03:46 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
INFO - 2016-04-16 13:03:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:03:46 --> Final output sent to browser
DEBUG - 2016-04-16 13:03:46 --> Total execution time: 3.3602
INFO - 2016-04-16 10:03:46 --> Config Class Initialized
INFO - 2016-04-16 10:03:46 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:03:46 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:03:46 --> Utf8 Class Initialized
INFO - 2016-04-16 10:03:46 --> URI Class Initialized
INFO - 2016-04-16 10:03:46 --> Router Class Initialized
INFO - 2016-04-16 10:03:46 --> Output Class Initialized
INFO - 2016-04-16 10:03:46 --> Security Class Initialized
DEBUG - 2016-04-16 10:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:03:46 --> Input Class Initialized
INFO - 2016-04-16 10:03:46 --> Language Class Initialized
INFO - 2016-04-16 10:03:46 --> Loader Class Initialized
INFO - 2016-04-16 10:03:46 --> Helper loaded: url_helper
INFO - 2016-04-16 10:03:46 --> Helper loaded: file_helper
INFO - 2016-04-16 10:03:46 --> Helper loaded: date_helper
INFO - 2016-04-16 10:03:46 --> Helper loaded: form_helper
INFO - 2016-04-16 10:03:46 --> Database Driver Class Initialized
INFO - 2016-04-16 10:03:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:03:47 --> Controller Class Initialized
INFO - 2016-04-16 10:03:47 --> User Agent Class Initialized
INFO - 2016-04-16 10:03:47 --> Final output sent to browser
DEBUG - 2016-04-16 10:03:47 --> Total execution time: 1.1109
INFO - 2016-04-16 10:04:11 --> Config Class Initialized
INFO - 2016-04-16 10:04:11 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:04:11 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:04:11 --> Utf8 Class Initialized
INFO - 2016-04-16 10:04:11 --> URI Class Initialized
INFO - 2016-04-16 10:04:11 --> Router Class Initialized
INFO - 2016-04-16 10:04:11 --> Output Class Initialized
INFO - 2016-04-16 10:04:11 --> Security Class Initialized
DEBUG - 2016-04-16 10:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:04:11 --> Input Class Initialized
INFO - 2016-04-16 10:04:11 --> Language Class Initialized
INFO - 2016-04-16 10:04:11 --> Loader Class Initialized
INFO - 2016-04-16 10:04:11 --> Helper loaded: url_helper
INFO - 2016-04-16 10:04:11 --> Helper loaded: file_helper
INFO - 2016-04-16 10:04:11 --> Helper loaded: date_helper
INFO - 2016-04-16 10:04:11 --> Helper loaded: form_helper
INFO - 2016-04-16 10:04:11 --> Database Driver Class Initialized
INFO - 2016-04-16 10:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:04:12 --> Controller Class Initialized
INFO - 2016-04-16 10:04:12 --> Model Class Initialized
INFO - 2016-04-16 10:04:12 --> Model Class Initialized
INFO - 2016-04-16 10:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:04:12 --> Pagination Class Initialized
INFO - 2016-04-16 10:04:12 --> Helper loaded: text_helper
INFO - 2016-04-16 10:04:12 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:16 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
INFO - 2016-04-16 13:04:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:04:16 --> Final output sent to browser
DEBUG - 2016-04-16 13:04:16 --> Total execution time: 4.9479
INFO - 2016-04-16 10:04:16 --> Config Class Initialized
INFO - 2016-04-16 10:04:16 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:04:16 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:04:16 --> Utf8 Class Initialized
INFO - 2016-04-16 10:04:16 --> URI Class Initialized
INFO - 2016-04-16 10:04:16 --> Router Class Initialized
INFO - 2016-04-16 10:04:16 --> Output Class Initialized
INFO - 2016-04-16 10:04:16 --> Security Class Initialized
DEBUG - 2016-04-16 10:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:04:16 --> Input Class Initialized
INFO - 2016-04-16 10:04:16 --> Language Class Initialized
INFO - 2016-04-16 10:04:16 --> Loader Class Initialized
INFO - 2016-04-16 10:04:16 --> Helper loaded: url_helper
INFO - 2016-04-16 10:04:16 --> Helper loaded: file_helper
INFO - 2016-04-16 10:04:16 --> Helper loaded: date_helper
INFO - 2016-04-16 10:04:16 --> Helper loaded: form_helper
INFO - 2016-04-16 10:04:16 --> Database Driver Class Initialized
INFO - 2016-04-16 10:04:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:04:17 --> Controller Class Initialized
INFO - 2016-04-16 10:04:17 --> User Agent Class Initialized
INFO - 2016-04-16 10:04:17 --> Final output sent to browser
DEBUG - 2016-04-16 10:04:17 --> Total execution time: 1.1095
INFO - 2016-04-16 10:04:53 --> Config Class Initialized
INFO - 2016-04-16 10:04:53 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:04:53 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:04:53 --> Utf8 Class Initialized
INFO - 2016-04-16 10:04:53 --> URI Class Initialized
INFO - 2016-04-16 10:04:53 --> Router Class Initialized
INFO - 2016-04-16 10:04:53 --> Output Class Initialized
INFO - 2016-04-16 10:04:53 --> Security Class Initialized
DEBUG - 2016-04-16 10:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:04:53 --> Input Class Initialized
INFO - 2016-04-16 10:04:53 --> Language Class Initialized
INFO - 2016-04-16 10:04:53 --> Loader Class Initialized
INFO - 2016-04-16 10:04:53 --> Helper loaded: url_helper
INFO - 2016-04-16 10:04:53 --> Helper loaded: file_helper
INFO - 2016-04-16 10:04:53 --> Helper loaded: date_helper
INFO - 2016-04-16 10:04:53 --> Helper loaded: form_helper
INFO - 2016-04-16 10:04:53 --> Database Driver Class Initialized
INFO - 2016-04-16 10:04:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:04:54 --> Controller Class Initialized
INFO - 2016-04-16 10:04:54 --> Model Class Initialized
INFO - 2016-04-16 10:04:55 --> Model Class Initialized
INFO - 2016-04-16 10:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:04:55 --> Pagination Class Initialized
INFO - 2016-04-16 10:04:55 --> Helper loaded: text_helper
INFO - 2016-04-16 10:04:55 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 16
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 17
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 20
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Undefined variable: items_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:04:56 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
INFO - 2016-04-16 13:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:04:56 --> Final output sent to browser
DEBUG - 2016-04-16 13:04:56 --> Total execution time: 2.8920
INFO - 2016-04-16 10:05:21 --> Config Class Initialized
INFO - 2016-04-16 10:05:21 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:05:21 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:05:21 --> Utf8 Class Initialized
INFO - 2016-04-16 10:05:21 --> URI Class Initialized
INFO - 2016-04-16 10:05:21 --> Router Class Initialized
INFO - 2016-04-16 10:05:21 --> Output Class Initialized
INFO - 2016-04-16 10:05:21 --> Security Class Initialized
DEBUG - 2016-04-16 10:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:05:21 --> Input Class Initialized
INFO - 2016-04-16 10:05:21 --> Language Class Initialized
INFO - 2016-04-16 10:05:21 --> Loader Class Initialized
INFO - 2016-04-16 10:05:21 --> Helper loaded: url_helper
INFO - 2016-04-16 10:05:21 --> Helper loaded: file_helper
INFO - 2016-04-16 10:05:21 --> Helper loaded: date_helper
INFO - 2016-04-16 10:05:21 --> Helper loaded: form_helper
INFO - 2016-04-16 10:05:21 --> Database Driver Class Initialized
INFO - 2016-04-16 10:05:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:05:22 --> Controller Class Initialized
INFO - 2016-04-16 10:05:22 --> Model Class Initialized
INFO - 2016-04-16 10:05:22 --> Model Class Initialized
INFO - 2016-04-16 10:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:05:22 --> Pagination Class Initialized
INFO - 2016-04-16 10:05:22 --> Helper loaded: text_helper
INFO - 2016-04-16 10:05:22 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:05:24 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:05:24 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:05:24 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
ERROR - 2016-04-16 13:05:24 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 22
INFO - 2016-04-16 13:05:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:05:24 --> Final output sent to browser
DEBUG - 2016-04-16 13:05:24 --> Total execution time: 3.0969
INFO - 2016-04-16 10:09:18 --> Config Class Initialized
INFO - 2016-04-16 10:09:18 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:09:18 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:09:18 --> Utf8 Class Initialized
INFO - 2016-04-16 10:09:18 --> URI Class Initialized
INFO - 2016-04-16 10:09:18 --> Router Class Initialized
INFO - 2016-04-16 10:09:18 --> Output Class Initialized
INFO - 2016-04-16 10:09:18 --> Security Class Initialized
DEBUG - 2016-04-16 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:09:18 --> Input Class Initialized
INFO - 2016-04-16 10:09:18 --> Language Class Initialized
INFO - 2016-04-16 10:09:18 --> Loader Class Initialized
INFO - 2016-04-16 10:09:18 --> Helper loaded: url_helper
INFO - 2016-04-16 10:09:18 --> Helper loaded: file_helper
INFO - 2016-04-16 10:09:18 --> Helper loaded: date_helper
INFO - 2016-04-16 10:09:18 --> Helper loaded: form_helper
INFO - 2016-04-16 10:09:18 --> Database Driver Class Initialized
INFO - 2016-04-16 10:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:09:19 --> Controller Class Initialized
INFO - 2016-04-16 10:09:19 --> Model Class Initialized
INFO - 2016-04-16 10:09:19 --> Model Class Initialized
INFO - 2016-04-16 10:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:09:19 --> Pagination Class Initialized
INFO - 2016-04-16 10:09:19 --> Helper loaded: text_helper
INFO - 2016-04-16 10:09:19 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:09:21 --> Severity: Notice --> Undefined variable: image_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:09:21 --> Severity: Notice --> Undefined variable: image_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:09:21 --> Severity: Notice --> Undefined variable: image_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
ERROR - 2016-04-16 13:09:21 --> Severity: Notice --> Undefined variable: image_list C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 21
INFO - 2016-04-16 13:09:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:09:21 --> Final output sent to browser
DEBUG - 2016-04-16 13:09:21 --> Total execution time: 2.8802
INFO - 2016-04-16 10:09:47 --> Config Class Initialized
INFO - 2016-04-16 10:09:47 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:09:47 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:09:47 --> Utf8 Class Initialized
INFO - 2016-04-16 10:09:47 --> URI Class Initialized
INFO - 2016-04-16 10:09:47 --> Router Class Initialized
INFO - 2016-04-16 10:09:47 --> Output Class Initialized
INFO - 2016-04-16 10:09:47 --> Security Class Initialized
DEBUG - 2016-04-16 10:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:09:47 --> Input Class Initialized
INFO - 2016-04-16 10:09:47 --> Language Class Initialized
INFO - 2016-04-16 10:09:47 --> Loader Class Initialized
INFO - 2016-04-16 10:09:47 --> Helper loaded: url_helper
INFO - 2016-04-16 10:09:47 --> Helper loaded: file_helper
INFO - 2016-04-16 10:09:47 --> Helper loaded: date_helper
INFO - 2016-04-16 10:09:47 --> Helper loaded: form_helper
INFO - 2016-04-16 10:09:47 --> Database Driver Class Initialized
INFO - 2016-04-16 10:09:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:09:48 --> Controller Class Initialized
INFO - 2016-04-16 10:09:48 --> Model Class Initialized
INFO - 2016-04-16 10:09:48 --> Model Class Initialized
INFO - 2016-04-16 10:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:09:48 --> Pagination Class Initialized
INFO - 2016-04-16 10:09:48 --> Helper loaded: text_helper
INFO - 2016-04-16 10:09:48 --> Helper loaded: cookie_helper
INFO - 2016-04-16 13:09:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:09:51 --> Final output sent to browser
DEBUG - 2016-04-16 13:09:51 --> Total execution time: 3.6615
INFO - 2016-04-16 10:15:32 --> Config Class Initialized
INFO - 2016-04-16 10:15:32 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:15:32 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:15:32 --> Utf8 Class Initialized
INFO - 2016-04-16 10:15:32 --> URI Class Initialized
INFO - 2016-04-16 10:15:32 --> Router Class Initialized
INFO - 2016-04-16 10:15:32 --> Output Class Initialized
INFO - 2016-04-16 10:15:32 --> Security Class Initialized
DEBUG - 2016-04-16 10:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:15:32 --> Input Class Initialized
INFO - 2016-04-16 10:15:32 --> Language Class Initialized
INFO - 2016-04-16 10:15:32 --> Loader Class Initialized
INFO - 2016-04-16 10:15:32 --> Helper loaded: url_helper
INFO - 2016-04-16 10:15:32 --> Helper loaded: file_helper
INFO - 2016-04-16 10:15:32 --> Helper loaded: date_helper
INFO - 2016-04-16 10:15:32 --> Helper loaded: form_helper
INFO - 2016-04-16 10:15:32 --> Database Driver Class Initialized
INFO - 2016-04-16 10:15:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:15:33 --> Controller Class Initialized
INFO - 2016-04-16 10:15:33 --> Model Class Initialized
INFO - 2016-04-16 10:15:33 --> Model Class Initialized
INFO - 2016-04-16 10:15:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:15:33 --> Pagination Class Initialized
INFO - 2016-04-16 10:15:33 --> Helper loaded: text_helper
INFO - 2016-04-16 10:15:33 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:15:33 --> Severity: Parsing Error --> syntax error, unexpected 'end' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 27
INFO - 2016-04-16 10:15:55 --> Config Class Initialized
INFO - 2016-04-16 10:15:55 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:15:55 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:15:55 --> Utf8 Class Initialized
INFO - 2016-04-16 10:15:55 --> URI Class Initialized
INFO - 2016-04-16 10:15:55 --> Router Class Initialized
INFO - 2016-04-16 10:15:55 --> Output Class Initialized
INFO - 2016-04-16 10:15:55 --> Security Class Initialized
DEBUG - 2016-04-16 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:15:55 --> Input Class Initialized
INFO - 2016-04-16 10:15:55 --> Language Class Initialized
INFO - 2016-04-16 10:15:55 --> Loader Class Initialized
INFO - 2016-04-16 10:15:55 --> Helper loaded: url_helper
INFO - 2016-04-16 10:15:55 --> Helper loaded: file_helper
INFO - 2016-04-16 10:15:55 --> Helper loaded: date_helper
INFO - 2016-04-16 10:15:55 --> Helper loaded: form_helper
INFO - 2016-04-16 10:15:55 --> Database Driver Class Initialized
INFO - 2016-04-16 10:15:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:15:56 --> Controller Class Initialized
INFO - 2016-04-16 10:15:56 --> Model Class Initialized
INFO - 2016-04-16 10:15:56 --> Model Class Initialized
INFO - 2016-04-16 10:15:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:15:56 --> Pagination Class Initialized
INFO - 2016-04-16 10:15:56 --> Helper loaded: text_helper
INFO - 2016-04-16 10:15:56 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:15:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
INFO - 2016-04-16 10:16:07 --> Config Class Initialized
INFO - 2016-04-16 10:16:07 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:16:07 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:16:07 --> Utf8 Class Initialized
INFO - 2016-04-16 10:16:07 --> URI Class Initialized
INFO - 2016-04-16 10:16:07 --> Router Class Initialized
INFO - 2016-04-16 10:16:07 --> Output Class Initialized
INFO - 2016-04-16 10:16:07 --> Security Class Initialized
DEBUG - 2016-04-16 10:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:16:07 --> Input Class Initialized
INFO - 2016-04-16 10:16:07 --> Language Class Initialized
INFO - 2016-04-16 10:16:07 --> Loader Class Initialized
INFO - 2016-04-16 10:16:07 --> Helper loaded: url_helper
INFO - 2016-04-16 10:16:07 --> Helper loaded: file_helper
INFO - 2016-04-16 10:16:07 --> Helper loaded: date_helper
INFO - 2016-04-16 10:16:07 --> Helper loaded: form_helper
INFO - 2016-04-16 10:16:07 --> Database Driver Class Initialized
INFO - 2016-04-16 10:16:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:16:08 --> Controller Class Initialized
INFO - 2016-04-16 10:16:08 --> Model Class Initialized
INFO - 2016-04-16 10:16:08 --> Model Class Initialized
INFO - 2016-04-16 10:16:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:16:08 --> Pagination Class Initialized
INFO - 2016-04-16 10:16:08 --> Helper loaded: text_helper
INFO - 2016-04-16 10:16:08 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:16:10 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
INFO - 2016-04-16 13:16:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:16:10 --> Final output sent to browser
DEBUG - 2016-04-16 13:16:10 --> Total execution time: 3.1761
INFO - 2016-04-16 10:18:38 --> Config Class Initialized
INFO - 2016-04-16 10:18:38 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:18:38 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:18:38 --> Utf8 Class Initialized
INFO - 2016-04-16 10:18:38 --> URI Class Initialized
INFO - 2016-04-16 10:18:38 --> Router Class Initialized
INFO - 2016-04-16 10:18:39 --> Output Class Initialized
INFO - 2016-04-16 10:18:39 --> Security Class Initialized
DEBUG - 2016-04-16 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:18:39 --> Input Class Initialized
INFO - 2016-04-16 10:18:39 --> Language Class Initialized
INFO - 2016-04-16 10:18:39 --> Loader Class Initialized
INFO - 2016-04-16 10:18:39 --> Helper loaded: url_helper
INFO - 2016-04-16 10:18:39 --> Helper loaded: file_helper
INFO - 2016-04-16 10:18:39 --> Helper loaded: date_helper
INFO - 2016-04-16 10:18:39 --> Helper loaded: form_helper
INFO - 2016-04-16 10:18:39 --> Database Driver Class Initialized
INFO - 2016-04-16 10:18:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:18:40 --> Controller Class Initialized
INFO - 2016-04-16 10:18:40 --> Model Class Initialized
INFO - 2016-04-16 10:18:40 --> Model Class Initialized
INFO - 2016-04-16 10:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:18:40 --> Pagination Class Initialized
INFO - 2016-04-16 10:18:40 --> Helper loaded: text_helper
INFO - 2016-04-16 10:18:40 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:18:42 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
INFO - 2016-04-16 13:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:18:42 --> Final output sent to browser
DEBUG - 2016-04-16 13:18:42 --> Total execution time: 3.0611
INFO - 2016-04-16 10:19:08 --> Config Class Initialized
INFO - 2016-04-16 10:19:08 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:19:08 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:19:08 --> Utf8 Class Initialized
INFO - 2016-04-16 10:19:08 --> URI Class Initialized
INFO - 2016-04-16 10:19:08 --> Router Class Initialized
INFO - 2016-04-16 10:19:08 --> Output Class Initialized
INFO - 2016-04-16 10:19:08 --> Security Class Initialized
DEBUG - 2016-04-16 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:19:08 --> Input Class Initialized
INFO - 2016-04-16 10:19:08 --> Language Class Initialized
INFO - 2016-04-16 10:19:08 --> Loader Class Initialized
INFO - 2016-04-16 10:19:08 --> Helper loaded: url_helper
INFO - 2016-04-16 10:19:08 --> Helper loaded: file_helper
INFO - 2016-04-16 10:19:08 --> Helper loaded: date_helper
INFO - 2016-04-16 10:19:09 --> Helper loaded: form_helper
INFO - 2016-04-16 10:19:09 --> Database Driver Class Initialized
INFO - 2016-04-16 10:19:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:19:10 --> Controller Class Initialized
INFO - 2016-04-16 10:19:10 --> Model Class Initialized
INFO - 2016-04-16 10:19:10 --> Model Class Initialized
INFO - 2016-04-16 10:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:19:10 --> Pagination Class Initialized
INFO - 2016-04-16 10:19:10 --> Helper loaded: text_helper
INFO - 2016-04-16 10:19:10 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 26
ERROR - 2016-04-16 13:19:11 --> Severity: Notice --> Undefined variable: item_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 28
INFO - 2016-04-16 13:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:19:11 --> Final output sent to browser
DEBUG - 2016-04-16 13:19:11 --> Total execution time: 3.0250
INFO - 2016-04-16 10:19:29 --> Config Class Initialized
INFO - 2016-04-16 10:19:29 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:19:29 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:19:29 --> Utf8 Class Initialized
INFO - 2016-04-16 10:19:29 --> URI Class Initialized
INFO - 2016-04-16 10:19:29 --> Router Class Initialized
INFO - 2016-04-16 10:19:29 --> Output Class Initialized
INFO - 2016-04-16 10:19:29 --> Security Class Initialized
DEBUG - 2016-04-16 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:19:29 --> Input Class Initialized
INFO - 2016-04-16 10:19:29 --> Language Class Initialized
INFO - 2016-04-16 10:19:29 --> Loader Class Initialized
INFO - 2016-04-16 10:19:29 --> Helper loaded: url_helper
INFO - 2016-04-16 10:19:29 --> Helper loaded: file_helper
INFO - 2016-04-16 10:19:29 --> Helper loaded: date_helper
INFO - 2016-04-16 10:19:29 --> Helper loaded: form_helper
INFO - 2016-04-16 10:19:29 --> Database Driver Class Initialized
INFO - 2016-04-16 10:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:19:30 --> Controller Class Initialized
INFO - 2016-04-16 10:19:30 --> Model Class Initialized
INFO - 2016-04-16 10:19:30 --> Model Class Initialized
INFO - 2016-04-16 10:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:19:30 --> Pagination Class Initialized
INFO - 2016-04-16 10:19:30 --> Helper loaded: text_helper
INFO - 2016-04-16 10:19:30 --> Helper loaded: cookie_helper
INFO - 2016-04-16 13:19:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:19:32 --> Final output sent to browser
DEBUG - 2016-04-16 13:19:32 --> Total execution time: 3.0431
INFO - 2016-04-16 10:31:46 --> Config Class Initialized
INFO - 2016-04-16 10:31:46 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:31:46 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:31:46 --> Utf8 Class Initialized
INFO - 2016-04-16 10:31:46 --> URI Class Initialized
INFO - 2016-04-16 10:31:46 --> Router Class Initialized
INFO - 2016-04-16 10:31:46 --> Output Class Initialized
INFO - 2016-04-16 10:31:46 --> Security Class Initialized
DEBUG - 2016-04-16 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:31:46 --> Input Class Initialized
INFO - 2016-04-16 10:31:46 --> Language Class Initialized
INFO - 2016-04-16 10:31:46 --> Loader Class Initialized
INFO - 2016-04-16 10:31:46 --> Helper loaded: url_helper
INFO - 2016-04-16 10:31:46 --> Helper loaded: file_helper
INFO - 2016-04-16 10:31:46 --> Helper loaded: date_helper
INFO - 2016-04-16 10:31:46 --> Helper loaded: form_helper
INFO - 2016-04-16 10:31:46 --> Database Driver Class Initialized
INFO - 2016-04-16 10:31:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:31:47 --> Controller Class Initialized
INFO - 2016-04-16 10:31:47 --> Model Class Initialized
INFO - 2016-04-16 10:31:47 --> Model Class Initialized
INFO - 2016-04-16 10:31:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:31:47 --> Pagination Class Initialized
INFO - 2016-04-16 10:31:47 --> Helper loaded: text_helper
INFO - 2016-04-16 10:31:47 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 25
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 25
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 25
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 25
ERROR - 2016-04-16 13:31:51 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
INFO - 2016-04-16 13:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:31:51 --> Final output sent to browser
DEBUG - 2016-04-16 13:31:51 --> Total execution time: 4.5348
INFO - 2016-04-16 10:32:03 --> Config Class Initialized
INFO - 2016-04-16 10:32:03 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:32:03 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:32:03 --> Utf8 Class Initialized
INFO - 2016-04-16 10:32:03 --> URI Class Initialized
INFO - 2016-04-16 10:32:03 --> Router Class Initialized
INFO - 2016-04-16 10:32:03 --> Output Class Initialized
INFO - 2016-04-16 10:32:03 --> Security Class Initialized
DEBUG - 2016-04-16 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:32:03 --> Input Class Initialized
INFO - 2016-04-16 10:32:03 --> Language Class Initialized
INFO - 2016-04-16 10:32:03 --> Loader Class Initialized
INFO - 2016-04-16 10:32:03 --> Helper loaded: url_helper
INFO - 2016-04-16 10:32:03 --> Helper loaded: file_helper
INFO - 2016-04-16 10:32:03 --> Helper loaded: date_helper
INFO - 2016-04-16 10:32:03 --> Helper loaded: form_helper
INFO - 2016-04-16 10:32:03 --> Database Driver Class Initialized
INFO - 2016-04-16 10:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:32:04 --> Controller Class Initialized
INFO - 2016-04-16 10:32:04 --> Model Class Initialized
INFO - 2016-04-16 10:32:04 --> Model Class Initialized
INFO - 2016-04-16 10:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:32:04 --> Pagination Class Initialized
INFO - 2016-04-16 10:32:04 --> Helper loaded: text_helper
INFO - 2016-04-16 10:32:04 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:32:06 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:32:06 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:32:06 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:32:06 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
INFO - 2016-04-16 13:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:32:06 --> Final output sent to browser
DEBUG - 2016-04-16 13:32:06 --> Total execution time: 3.0143
INFO - 2016-04-16 10:34:53 --> Config Class Initialized
INFO - 2016-04-16 10:34:53 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:34:53 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:34:53 --> Utf8 Class Initialized
INFO - 2016-04-16 10:34:53 --> URI Class Initialized
INFO - 2016-04-16 10:34:53 --> Router Class Initialized
INFO - 2016-04-16 10:34:53 --> Output Class Initialized
INFO - 2016-04-16 10:34:53 --> Security Class Initialized
DEBUG - 2016-04-16 10:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:34:53 --> Input Class Initialized
INFO - 2016-04-16 10:34:53 --> Language Class Initialized
INFO - 2016-04-16 10:34:53 --> Loader Class Initialized
INFO - 2016-04-16 10:34:53 --> Helper loaded: url_helper
INFO - 2016-04-16 10:34:53 --> Helper loaded: file_helper
INFO - 2016-04-16 10:34:53 --> Helper loaded: date_helper
INFO - 2016-04-16 10:34:53 --> Helper loaded: form_helper
INFO - 2016-04-16 10:34:53 --> Database Driver Class Initialized
INFO - 2016-04-16 10:34:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:34:54 --> Controller Class Initialized
INFO - 2016-04-16 10:34:54 --> Model Class Initialized
INFO - 2016-04-16 10:34:54 --> Model Class Initialized
INFO - 2016-04-16 10:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:34:54 --> Pagination Class Initialized
INFO - 2016-04-16 10:34:54 --> Helper loaded: text_helper
INFO - 2016-04-16 10:34:54 --> Helper loaded: cookie_helper
ERROR - 2016-04-16 13:34:57 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:34:57 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:34:57 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
ERROR - 2016-04-16 13:34:57 --> Severity: Notice --> Undefined variable: avaliable C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php 29
INFO - 2016-04-16 13:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:34:57 --> Final output sent to browser
DEBUG - 2016-04-16 13:34:57 --> Total execution time: 4.5458
INFO - 2016-04-16 10:36:02 --> Config Class Initialized
INFO - 2016-04-16 10:36:02 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:36:02 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:36:02 --> Utf8 Class Initialized
INFO - 2016-04-16 10:36:02 --> URI Class Initialized
INFO - 2016-04-16 10:36:02 --> Router Class Initialized
INFO - 2016-04-16 10:36:02 --> Output Class Initialized
INFO - 2016-04-16 10:36:02 --> Security Class Initialized
DEBUG - 2016-04-16 10:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:36:02 --> Input Class Initialized
INFO - 2016-04-16 10:36:02 --> Language Class Initialized
INFO - 2016-04-16 10:36:02 --> Loader Class Initialized
INFO - 2016-04-16 10:36:02 --> Helper loaded: url_helper
INFO - 2016-04-16 10:36:02 --> Helper loaded: file_helper
INFO - 2016-04-16 10:36:02 --> Helper loaded: date_helper
INFO - 2016-04-16 10:36:02 --> Helper loaded: form_helper
INFO - 2016-04-16 10:36:02 --> Database Driver Class Initialized
INFO - 2016-04-16 10:36:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:36:03 --> Controller Class Initialized
INFO - 2016-04-16 10:36:03 --> Model Class Initialized
INFO - 2016-04-16 10:36:03 --> Model Class Initialized
INFO - 2016-04-16 10:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:36:03 --> Pagination Class Initialized
INFO - 2016-04-16 10:36:03 --> Helper loaded: text_helper
INFO - 2016-04-16 10:36:03 --> Helper loaded: cookie_helper
INFO - 2016-04-16 13:36:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:36:06 --> Final output sent to browser
DEBUG - 2016-04-16 13:36:06 --> Total execution time: 4.0790
INFO - 2016-04-16 10:45:09 --> Config Class Initialized
INFO - 2016-04-16 10:45:09 --> Hooks Class Initialized
DEBUG - 2016-04-16 10:45:09 --> UTF-8 Support Enabled
INFO - 2016-04-16 10:45:09 --> Utf8 Class Initialized
INFO - 2016-04-16 10:45:09 --> URI Class Initialized
INFO - 2016-04-16 10:45:09 --> Router Class Initialized
INFO - 2016-04-16 10:45:09 --> Output Class Initialized
INFO - 2016-04-16 10:45:09 --> Security Class Initialized
DEBUG - 2016-04-16 10:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-16 10:45:09 --> Input Class Initialized
INFO - 2016-04-16 10:45:09 --> Language Class Initialized
INFO - 2016-04-16 10:45:09 --> Loader Class Initialized
INFO - 2016-04-16 10:45:09 --> Helper loaded: url_helper
INFO - 2016-04-16 10:45:09 --> Helper loaded: file_helper
INFO - 2016-04-16 10:45:09 --> Helper loaded: date_helper
INFO - 2016-04-16 10:45:09 --> Helper loaded: form_helper
INFO - 2016-04-16 10:45:09 --> Database Driver Class Initialized
INFO - 2016-04-16 10:45:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-16 10:45:10 --> Controller Class Initialized
INFO - 2016-04-16 10:45:10 --> Model Class Initialized
INFO - 2016-04-16 10:45:10 --> Model Class Initialized
INFO - 2016-04-16 10:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-16 10:45:10 --> Pagination Class Initialized
INFO - 2016-04-16 10:45:10 --> Helper loaded: text_helper
INFO - 2016-04-16 10:45:10 --> Helper loaded: cookie_helper
INFO - 2016-04-16 13:45:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\price.php
INFO - 2016-04-16 13:45:14 --> Final output sent to browser
DEBUG - 2016-04-16 13:45:14 --> Total execution time: 4.1787
