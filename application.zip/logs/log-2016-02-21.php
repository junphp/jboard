<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-21 09:09:08 --> Config Class Initialized
INFO - 2016-02-21 09:09:08 --> Hooks Class Initialized
DEBUG - 2016-02-21 09:09:08 --> UTF-8 Support Enabled
INFO - 2016-02-21 09:09:08 --> Utf8 Class Initialized
INFO - 2016-02-21 09:09:08 --> URI Class Initialized
DEBUG - 2016-02-21 09:09:08 --> No URI present. Default controller set.
INFO - 2016-02-21 09:09:08 --> Router Class Initialized
INFO - 2016-02-21 09:09:08 --> Output Class Initialized
INFO - 2016-02-21 09:09:08 --> Security Class Initialized
DEBUG - 2016-02-21 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 09:09:08 --> Input Class Initialized
INFO - 2016-02-21 09:09:08 --> Language Class Initialized
INFO - 2016-02-21 09:09:08 --> Loader Class Initialized
INFO - 2016-02-21 09:09:08 --> Helper loaded: url_helper
INFO - 2016-02-21 09:09:08 --> Helper loaded: file_helper
INFO - 2016-02-21 09:09:08 --> Helper loaded: date_helper
INFO - 2016-02-21 09:09:08 --> Helper loaded: form_helper
INFO - 2016-02-21 09:09:08 --> Database Driver Class Initialized
INFO - 2016-02-21 09:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 09:09:09 --> Controller Class Initialized
INFO - 2016-02-21 09:09:09 --> Model Class Initialized
INFO - 2016-02-21 09:09:09 --> Model Class Initialized
INFO - 2016-02-21 09:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 09:09:09 --> Pagination Class Initialized
INFO - 2016-02-21 09:09:09 --> Helper loaded: text_helper
INFO - 2016-02-21 09:09:09 --> Helper loaded: cookie_helper
INFO - 2016-02-21 12:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 12:09:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 12:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-21 12:09:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 10:24:18 --> Config Class Initialized
INFO - 2016-02-21 10:24:18 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:24:18 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:24:18 --> Utf8 Class Initialized
INFO - 2016-02-21 10:24:18 --> URI Class Initialized
DEBUG - 2016-02-21 10:24:18 --> No URI present. Default controller set.
INFO - 2016-02-21 10:24:18 --> Router Class Initialized
INFO - 2016-02-21 10:24:18 --> Output Class Initialized
INFO - 2016-02-21 10:24:18 --> Security Class Initialized
DEBUG - 2016-02-21 10:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:24:18 --> Input Class Initialized
INFO - 2016-02-21 10:24:18 --> Language Class Initialized
INFO - 2016-02-21 10:24:18 --> Loader Class Initialized
INFO - 2016-02-21 10:24:18 --> Helper loaded: url_helper
INFO - 2016-02-21 10:24:18 --> Helper loaded: file_helper
INFO - 2016-02-21 10:24:18 --> Helper loaded: date_helper
INFO - 2016-02-21 10:24:18 --> Helper loaded: form_helper
INFO - 2016-02-21 10:24:18 --> Database Driver Class Initialized
INFO - 2016-02-21 10:24:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:24:19 --> Controller Class Initialized
INFO - 2016-02-21 10:24:19 --> Model Class Initialized
INFO - 2016-02-21 10:24:19 --> Model Class Initialized
INFO - 2016-02-21 10:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:24:19 --> Pagination Class Initialized
INFO - 2016-02-21 10:24:19 --> Helper loaded: text_helper
INFO - 2016-02-21 10:24:19 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 13:24:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-21 13:24:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 10:24:23 --> Config Class Initialized
INFO - 2016-02-21 10:24:23 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:24:23 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:24:23 --> Utf8 Class Initialized
INFO - 2016-02-21 10:24:23 --> URI Class Initialized
INFO - 2016-02-21 10:24:23 --> Router Class Initialized
INFO - 2016-02-21 10:24:23 --> Output Class Initialized
INFO - 2016-02-21 10:24:23 --> Security Class Initialized
DEBUG - 2016-02-21 10:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:24:23 --> Input Class Initialized
INFO - 2016-02-21 10:24:23 --> Language Class Initialized
INFO - 2016-02-21 10:24:23 --> Loader Class Initialized
INFO - 2016-02-21 10:24:23 --> Helper loaded: url_helper
INFO - 2016-02-21 10:24:23 --> Helper loaded: file_helper
INFO - 2016-02-21 10:24:23 --> Helper loaded: date_helper
INFO - 2016-02-21 10:24:23 --> Helper loaded: form_helper
INFO - 2016-02-21 10:24:23 --> Database Driver Class Initialized
INFO - 2016-02-21 10:24:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:24:24 --> Controller Class Initialized
INFO - 2016-02-21 10:24:24 --> Model Class Initialized
INFO - 2016-02-21 10:24:24 --> Model Class Initialized
INFO - 2016-02-21 10:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:24:24 --> Pagination Class Initialized
INFO - 2016-02-21 10:24:24 --> Helper loaded: text_helper
INFO - 2016-02-21 10:24:24 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 13:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:24:24 --> Final output sent to browser
DEBUG - 2016-02-21 13:24:24 --> Total execution time: 1.1407
INFO - 2016-02-21 10:35:58 --> Config Class Initialized
INFO - 2016-02-21 10:35:58 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:35:58 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:35:58 --> Utf8 Class Initialized
INFO - 2016-02-21 10:35:58 --> URI Class Initialized
INFO - 2016-02-21 10:35:58 --> Router Class Initialized
INFO - 2016-02-21 10:35:58 --> Output Class Initialized
INFO - 2016-02-21 10:35:58 --> Security Class Initialized
DEBUG - 2016-02-21 10:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:35:58 --> Input Class Initialized
INFO - 2016-02-21 10:35:58 --> Language Class Initialized
INFO - 2016-02-21 10:35:58 --> Loader Class Initialized
INFO - 2016-02-21 10:35:58 --> Helper loaded: url_helper
INFO - 2016-02-21 10:35:58 --> Helper loaded: file_helper
INFO - 2016-02-21 10:35:58 --> Helper loaded: date_helper
INFO - 2016-02-21 10:35:58 --> Helper loaded: form_helper
INFO - 2016-02-21 10:35:58 --> Database Driver Class Initialized
INFO - 2016-02-21 10:35:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:35:59 --> Controller Class Initialized
INFO - 2016-02-21 10:35:59 --> Model Class Initialized
INFO - 2016-02-21 10:35:59 --> Model Class Initialized
INFO - 2016-02-21 10:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:35:59 --> Pagination Class Initialized
INFO - 2016-02-21 10:35:59 --> Helper loaded: text_helper
INFO - 2016-02-21 10:35:59 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:36:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:36:00 --> Final output sent to browser
DEBUG - 2016-02-21 13:36:00 --> Total execution time: 1.1851
INFO - 2016-02-21 10:36:00 --> Config Class Initialized
INFO - 2016-02-21 10:36:00 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:36:00 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:36:00 --> Utf8 Class Initialized
INFO - 2016-02-21 10:36:00 --> URI Class Initialized
INFO - 2016-02-21 10:36:00 --> Router Class Initialized
INFO - 2016-02-21 10:36:00 --> Output Class Initialized
INFO - 2016-02-21 10:36:00 --> Security Class Initialized
DEBUG - 2016-02-21 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:36:00 --> Input Class Initialized
INFO - 2016-02-21 10:36:00 --> Language Class Initialized
ERROR - 2016-02-21 10:36:00 --> 404 Page Not Found: Static/user
INFO - 2016-02-21 10:36:08 --> Config Class Initialized
INFO - 2016-02-21 10:36:08 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:36:08 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:36:08 --> Utf8 Class Initialized
INFO - 2016-02-21 10:36:08 --> URI Class Initialized
INFO - 2016-02-21 10:36:08 --> Router Class Initialized
INFO - 2016-02-21 10:36:08 --> Output Class Initialized
INFO - 2016-02-21 10:36:08 --> Security Class Initialized
DEBUG - 2016-02-21 10:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:36:08 --> Input Class Initialized
INFO - 2016-02-21 10:36:08 --> Language Class Initialized
INFO - 2016-02-21 10:36:08 --> Loader Class Initialized
INFO - 2016-02-21 10:36:08 --> Helper loaded: url_helper
INFO - 2016-02-21 10:36:08 --> Helper loaded: file_helper
INFO - 2016-02-21 10:36:08 --> Helper loaded: date_helper
INFO - 2016-02-21 10:36:08 --> Helper loaded: form_helper
INFO - 2016-02-21 10:36:08 --> Database Driver Class Initialized
INFO - 2016-02-21 10:36:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:36:09 --> Controller Class Initialized
INFO - 2016-02-21 10:36:09 --> Model Class Initialized
INFO - 2016-02-21 10:36:09 --> Model Class Initialized
INFO - 2016-02-21 10:36:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:36:09 --> Pagination Class Initialized
INFO - 2016-02-21 10:36:09 --> Helper loaded: text_helper
INFO - 2016-02-21 10:36:09 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 13:36:09 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 118 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 152
ERROR - 2016-02-21 13:36:09 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 154
ERROR - 2016-02-21 13:36:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '50 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 50 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-02-21 13:36:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 10:36:15 --> Config Class Initialized
INFO - 2016-02-21 10:36:15 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:36:15 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:36:15 --> Utf8 Class Initialized
INFO - 2016-02-21 10:36:15 --> URI Class Initialized
INFO - 2016-02-21 10:36:15 --> Router Class Initialized
INFO - 2016-02-21 10:36:15 --> Output Class Initialized
INFO - 2016-02-21 10:36:15 --> Security Class Initialized
DEBUG - 2016-02-21 10:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:36:15 --> Input Class Initialized
INFO - 2016-02-21 10:36:15 --> Language Class Initialized
INFO - 2016-02-21 10:36:15 --> Loader Class Initialized
INFO - 2016-02-21 10:36:15 --> Helper loaded: url_helper
INFO - 2016-02-21 10:36:15 --> Helper loaded: file_helper
INFO - 2016-02-21 10:36:15 --> Helper loaded: date_helper
INFO - 2016-02-21 10:36:15 --> Helper loaded: form_helper
INFO - 2016-02-21 10:36:15 --> Database Driver Class Initialized
INFO - 2016-02-21 10:36:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:36:16 --> Controller Class Initialized
INFO - 2016-02-21 10:36:16 --> Model Class Initialized
INFO - 2016-02-21 10:36:16 --> Model Class Initialized
INFO - 2016-02-21 10:36:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:36:16 --> Pagination Class Initialized
INFO - 2016-02-21 10:36:16 --> Helper loaded: text_helper
INFO - 2016-02-21 10:36:16 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:36:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:36:16 --> Final output sent to browser
DEBUG - 2016-02-21 13:36:16 --> Total execution time: 1.3034
INFO - 2016-02-21 10:36:16 --> Config Class Initialized
INFO - 2016-02-21 10:36:16 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:36:16 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:36:16 --> Utf8 Class Initialized
INFO - 2016-02-21 10:36:16 --> URI Class Initialized
INFO - 2016-02-21 10:36:16 --> Router Class Initialized
INFO - 2016-02-21 10:36:16 --> Output Class Initialized
INFO - 2016-02-21 10:36:16 --> Security Class Initialized
DEBUG - 2016-02-21 10:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:36:16 --> Input Class Initialized
INFO - 2016-02-21 10:36:16 --> Language Class Initialized
ERROR - 2016-02-21 10:36:16 --> 404 Page Not Found: Static/user
INFO - 2016-02-21 10:40:17 --> Config Class Initialized
INFO - 2016-02-21 10:40:17 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:17 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:17 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:17 --> URI Class Initialized
INFO - 2016-02-21 10:40:17 --> Router Class Initialized
INFO - 2016-02-21 10:40:17 --> Output Class Initialized
INFO - 2016-02-21 10:40:17 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:17 --> Input Class Initialized
INFO - 2016-02-21 10:40:17 --> Language Class Initialized
INFO - 2016-02-21 10:40:17 --> Loader Class Initialized
INFO - 2016-02-21 10:40:17 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:17 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:17 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:17 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:17 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:18 --> Controller Class Initialized
INFO - 2016-02-21 10:40:18 --> Model Class Initialized
INFO - 2016-02-21 10:40:18 --> Model Class Initialized
INFO - 2016-02-21 10:40:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:18 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:18 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:18 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 13:40:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:18 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:18 --> Total execution time: 1.1666
INFO - 2016-02-21 10:40:21 --> Config Class Initialized
INFO - 2016-02-21 10:40:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:21 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:21 --> URI Class Initialized
INFO - 2016-02-21 10:40:21 --> Router Class Initialized
INFO - 2016-02-21 10:40:21 --> Output Class Initialized
INFO - 2016-02-21 10:40:21 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:21 --> Input Class Initialized
INFO - 2016-02-21 10:40:21 --> Language Class Initialized
INFO - 2016-02-21 10:40:21 --> Loader Class Initialized
INFO - 2016-02-21 10:40:21 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:21 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:21 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:21 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:21 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:22 --> Controller Class Initialized
INFO - 2016-02-21 10:40:22 --> Model Class Initialized
INFO - 2016-02-21 10:40:22 --> Model Class Initialized
INFO - 2016-02-21 10:40:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:22 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:22 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:22 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:22 --> Total execution time: 1.1708
INFO - 2016-02-21 10:40:22 --> Config Class Initialized
INFO - 2016-02-21 10:40:22 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:22 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:22 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:22 --> URI Class Initialized
INFO - 2016-02-21 10:40:22 --> Router Class Initialized
INFO - 2016-02-21 10:40:22 --> Output Class Initialized
INFO - 2016-02-21 10:40:22 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:22 --> Input Class Initialized
INFO - 2016-02-21 10:40:22 --> Language Class Initialized
ERROR - 2016-02-21 10:40:22 --> 404 Page Not Found: Static/user
INFO - 2016-02-21 10:40:28 --> Config Class Initialized
INFO - 2016-02-21 10:40:28 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:28 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:28 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:28 --> URI Class Initialized
INFO - 2016-02-21 10:40:28 --> Router Class Initialized
INFO - 2016-02-21 10:40:28 --> Output Class Initialized
INFO - 2016-02-21 10:40:28 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:28 --> Input Class Initialized
INFO - 2016-02-21 10:40:28 --> Language Class Initialized
INFO - 2016-02-21 10:40:28 --> Loader Class Initialized
INFO - 2016-02-21 10:40:28 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:28 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:28 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:28 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:28 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:29 --> Controller Class Initialized
INFO - 2016-02-21 10:40:29 --> Model Class Initialized
INFO - 2016-02-21 10:40:29 --> Model Class Initialized
INFO - 2016-02-21 10:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:29 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:29 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:29 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:29 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:29 --> Total execution time: 1.1960
INFO - 2016-02-21 10:40:31 --> Config Class Initialized
INFO - 2016-02-21 10:40:31 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:31 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:31 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:31 --> URI Class Initialized
INFO - 2016-02-21 10:40:31 --> Router Class Initialized
INFO - 2016-02-21 10:40:31 --> Output Class Initialized
INFO - 2016-02-21 10:40:31 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:31 --> Input Class Initialized
INFO - 2016-02-21 10:40:31 --> Language Class Initialized
INFO - 2016-02-21 10:40:31 --> Loader Class Initialized
INFO - 2016-02-21 10:40:31 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:31 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:31 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:32 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:32 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:33 --> Controller Class Initialized
INFO - 2016-02-21 10:40:33 --> Model Class Initialized
INFO - 2016-02-21 10:40:33 --> Model Class Initialized
INFO - 2016-02-21 10:40:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:33 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:33 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:33 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:33 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:33 --> Total execution time: 1.3521
INFO - 2016-02-21 10:40:34 --> Config Class Initialized
INFO - 2016-02-21 10:40:34 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:34 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:34 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:34 --> URI Class Initialized
INFO - 2016-02-21 10:40:34 --> Router Class Initialized
INFO - 2016-02-21 10:40:34 --> Output Class Initialized
INFO - 2016-02-21 10:40:34 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:34 --> Input Class Initialized
INFO - 2016-02-21 10:40:34 --> Language Class Initialized
INFO - 2016-02-21 10:40:34 --> Loader Class Initialized
INFO - 2016-02-21 10:40:34 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:34 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:34 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:34 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:34 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:35 --> Controller Class Initialized
INFO - 2016-02-21 10:40:35 --> Model Class Initialized
INFO - 2016-02-21 10:40:35 --> Model Class Initialized
INFO - 2016-02-21 10:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:35 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:35 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:35 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:35 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:35 --> Total execution time: 1.1802
INFO - 2016-02-21 10:40:37 --> Config Class Initialized
INFO - 2016-02-21 10:40:37 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:37 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:37 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:37 --> URI Class Initialized
INFO - 2016-02-21 10:40:37 --> Router Class Initialized
INFO - 2016-02-21 10:40:37 --> Output Class Initialized
INFO - 2016-02-21 10:40:37 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:37 --> Input Class Initialized
INFO - 2016-02-21 10:40:37 --> Language Class Initialized
INFO - 2016-02-21 10:40:37 --> Loader Class Initialized
INFO - 2016-02-21 10:40:37 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:37 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:37 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:37 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:37 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:38 --> Controller Class Initialized
INFO - 2016-02-21 10:40:38 --> Model Class Initialized
INFO - 2016-02-21 10:40:38 --> Model Class Initialized
INFO - 2016-02-21 10:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:38 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:38 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:38 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:38 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:38 --> Total execution time: 1.3248
INFO - 2016-02-21 10:40:40 --> Config Class Initialized
INFO - 2016-02-21 10:40:40 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:40 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:40 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:40 --> URI Class Initialized
INFO - 2016-02-21 10:40:40 --> Router Class Initialized
INFO - 2016-02-21 10:40:40 --> Output Class Initialized
INFO - 2016-02-21 10:40:40 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:40 --> Input Class Initialized
INFO - 2016-02-21 10:40:40 --> Language Class Initialized
INFO - 2016-02-21 10:40:40 --> Loader Class Initialized
INFO - 2016-02-21 10:40:40 --> Helper loaded: url_helper
INFO - 2016-02-21 10:40:40 --> Helper loaded: file_helper
INFO - 2016-02-21 10:40:40 --> Helper loaded: date_helper
INFO - 2016-02-21 10:40:40 --> Helper loaded: form_helper
INFO - 2016-02-21 10:40:40 --> Database Driver Class Initialized
INFO - 2016-02-21 10:40:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:40:41 --> Controller Class Initialized
INFO - 2016-02-21 10:40:41 --> Model Class Initialized
INFO - 2016-02-21 10:40:41 --> Model Class Initialized
INFO - 2016-02-21 10:40:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:40:41 --> Pagination Class Initialized
INFO - 2016-02-21 10:40:41 --> Helper loaded: text_helper
INFO - 2016-02-21 10:40:41 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:40:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:40:41 --> Final output sent to browser
DEBUG - 2016-02-21 13:40:41 --> Total execution time: 1.2182
INFO - 2016-02-21 10:40:41 --> Config Class Initialized
INFO - 2016-02-21 10:40:41 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:41 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:41 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:41 --> URI Class Initialized
INFO - 2016-02-21 10:40:41 --> Router Class Initialized
INFO - 2016-02-21 10:40:41 --> Output Class Initialized
INFO - 2016-02-21 10:40:41 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:41 --> Input Class Initialized
INFO - 2016-02-21 10:40:41 --> Language Class Initialized
ERROR - 2016-02-21 10:40:41 --> 404 Page Not Found: Static/user
INFO - 2016-02-21 10:40:47 --> Config Class Initialized
INFO - 2016-02-21 10:40:47 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:40:47 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:40:47 --> Utf8 Class Initialized
INFO - 2016-02-21 10:40:47 --> URI Class Initialized
INFO - 2016-02-21 10:40:47 --> Router Class Initialized
INFO - 2016-02-21 10:40:47 --> Output Class Initialized
INFO - 2016-02-21 10:40:47 --> Security Class Initialized
DEBUG - 2016-02-21 10:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:40:47 --> Input Class Initialized
INFO - 2016-02-21 10:40:47 --> Language Class Initialized
ERROR - 2016-02-21 10:40:47 --> 404 Page Not Found: Static/user
INFO - 2016-02-21 10:41:51 --> Config Class Initialized
INFO - 2016-02-21 10:41:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:41:51 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:41:51 --> Utf8 Class Initialized
INFO - 2016-02-21 10:41:51 --> URI Class Initialized
INFO - 2016-02-21 10:41:51 --> Router Class Initialized
INFO - 2016-02-21 10:41:51 --> Output Class Initialized
INFO - 2016-02-21 10:41:51 --> Security Class Initialized
DEBUG - 2016-02-21 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:41:51 --> Input Class Initialized
INFO - 2016-02-21 10:41:51 --> Language Class Initialized
INFO - 2016-02-21 10:41:51 --> Loader Class Initialized
INFO - 2016-02-21 10:41:51 --> Helper loaded: url_helper
INFO - 2016-02-21 10:41:51 --> Helper loaded: file_helper
INFO - 2016-02-21 10:41:51 --> Helper loaded: date_helper
INFO - 2016-02-21 10:41:51 --> Helper loaded: form_helper
INFO - 2016-02-21 10:41:51 --> Database Driver Class Initialized
INFO - 2016-02-21 10:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:41:52 --> Controller Class Initialized
INFO - 2016-02-21 10:41:52 --> Model Class Initialized
INFO - 2016-02-21 10:41:52 --> Model Class Initialized
INFO - 2016-02-21 10:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:41:52 --> Pagination Class Initialized
INFO - 2016-02-21 10:41:53 --> Helper loaded: text_helper
INFO - 2016-02-21 10:41:53 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 13:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:41:53 --> Final output sent to browser
DEBUG - 2016-02-21 13:41:53 --> Total execution time: 1.1291
INFO - 2016-02-21 10:41:54 --> Config Class Initialized
INFO - 2016-02-21 10:41:54 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:41:54 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:41:54 --> Utf8 Class Initialized
INFO - 2016-02-21 10:41:54 --> URI Class Initialized
INFO - 2016-02-21 10:41:54 --> Router Class Initialized
INFO - 2016-02-21 10:41:54 --> Output Class Initialized
INFO - 2016-02-21 10:41:54 --> Security Class Initialized
DEBUG - 2016-02-21 10:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:41:54 --> Input Class Initialized
INFO - 2016-02-21 10:41:54 --> Language Class Initialized
INFO - 2016-02-21 10:41:54 --> Loader Class Initialized
INFO - 2016-02-21 10:41:54 --> Helper loaded: url_helper
INFO - 2016-02-21 10:41:54 --> Helper loaded: file_helper
INFO - 2016-02-21 10:41:54 --> Helper loaded: date_helper
INFO - 2016-02-21 10:41:54 --> Helper loaded: form_helper
INFO - 2016-02-21 10:41:54 --> Database Driver Class Initialized
INFO - 2016-02-21 10:41:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:41:55 --> Controller Class Initialized
INFO - 2016-02-21 10:41:55 --> Model Class Initialized
INFO - 2016-02-21 10:41:55 --> Model Class Initialized
INFO - 2016-02-21 10:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:41:55 --> Pagination Class Initialized
INFO - 2016-02-21 10:41:55 --> Helper loaded: text_helper
INFO - 2016-02-21 10:41:55 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:41:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:41:56 --> Final output sent to browser
DEBUG - 2016-02-21 13:41:56 --> Total execution time: 1.1899
INFO - 2016-02-21 10:41:57 --> Config Class Initialized
INFO - 2016-02-21 10:41:57 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:41:57 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:41:57 --> Utf8 Class Initialized
INFO - 2016-02-21 10:41:57 --> URI Class Initialized
INFO - 2016-02-21 10:41:57 --> Router Class Initialized
INFO - 2016-02-21 10:41:57 --> Output Class Initialized
INFO - 2016-02-21 10:41:57 --> Security Class Initialized
DEBUG - 2016-02-21 10:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:41:57 --> Input Class Initialized
INFO - 2016-02-21 10:41:57 --> Language Class Initialized
INFO - 2016-02-21 10:41:57 --> Loader Class Initialized
INFO - 2016-02-21 10:41:57 --> Helper loaded: url_helper
INFO - 2016-02-21 10:41:57 --> Helper loaded: file_helper
INFO - 2016-02-21 10:41:57 --> Helper loaded: date_helper
INFO - 2016-02-21 10:41:57 --> Helper loaded: form_helper
INFO - 2016-02-21 10:41:57 --> Database Driver Class Initialized
INFO - 2016-02-21 10:41:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:41:58 --> Controller Class Initialized
INFO - 2016-02-21 10:41:58 --> Model Class Initialized
INFO - 2016-02-21 10:41:58 --> Model Class Initialized
INFO - 2016-02-21 10:41:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:41:58 --> Pagination Class Initialized
INFO - 2016-02-21 10:41:58 --> Helper loaded: text_helper
INFO - 2016-02-21 10:41:58 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:41:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 13:41:58 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 118 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 152
ERROR - 2016-02-21 13:41:58 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 154
ERROR - 2016-02-21 13:41:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '47 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 47 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-02-21 13:41:59 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 10:42:00 --> Config Class Initialized
INFO - 2016-02-21 10:42:00 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:42:00 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:42:00 --> Utf8 Class Initialized
INFO - 2016-02-21 10:42:00 --> URI Class Initialized
INFO - 2016-02-21 10:42:00 --> Router Class Initialized
INFO - 2016-02-21 10:42:00 --> Output Class Initialized
INFO - 2016-02-21 10:42:00 --> Security Class Initialized
DEBUG - 2016-02-21 10:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:42:00 --> Input Class Initialized
INFO - 2016-02-21 10:42:00 --> Language Class Initialized
INFO - 2016-02-21 10:42:00 --> Loader Class Initialized
INFO - 2016-02-21 10:42:00 --> Helper loaded: url_helper
INFO - 2016-02-21 10:42:00 --> Helper loaded: file_helper
INFO - 2016-02-21 10:42:00 --> Helper loaded: date_helper
INFO - 2016-02-21 10:42:00 --> Helper loaded: form_helper
INFO - 2016-02-21 10:42:00 --> Database Driver Class Initialized
INFO - 2016-02-21 10:42:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:42:01 --> Controller Class Initialized
INFO - 2016-02-21 10:42:01 --> Model Class Initialized
INFO - 2016-02-21 10:42:01 --> Model Class Initialized
INFO - 2016-02-21 10:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:42:01 --> Pagination Class Initialized
INFO - 2016-02-21 10:42:01 --> Helper loaded: text_helper
INFO - 2016-02-21 10:42:01 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:42:01 --> Final output sent to browser
DEBUG - 2016-02-21 13:42:01 --> Total execution time: 1.1816
INFO - 2016-02-21 10:42:19 --> Config Class Initialized
INFO - 2016-02-21 10:42:19 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:42:19 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:42:19 --> Utf8 Class Initialized
INFO - 2016-02-21 10:42:19 --> URI Class Initialized
INFO - 2016-02-21 10:42:19 --> Router Class Initialized
INFO - 2016-02-21 10:42:19 --> Output Class Initialized
INFO - 2016-02-21 10:42:19 --> Security Class Initialized
DEBUG - 2016-02-21 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:42:19 --> Input Class Initialized
INFO - 2016-02-21 10:42:19 --> Language Class Initialized
INFO - 2016-02-21 10:42:19 --> Loader Class Initialized
INFO - 2016-02-21 10:42:19 --> Helper loaded: url_helper
INFO - 2016-02-21 10:42:19 --> Helper loaded: file_helper
INFO - 2016-02-21 10:42:19 --> Helper loaded: date_helper
INFO - 2016-02-21 10:42:19 --> Helper loaded: form_helper
INFO - 2016-02-21 10:42:19 --> Database Driver Class Initialized
INFO - 2016-02-21 10:42:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:42:20 --> Controller Class Initialized
INFO - 2016-02-21 10:42:20 --> Model Class Initialized
INFO - 2016-02-21 10:42:20 --> Model Class Initialized
INFO - 2016-02-21 10:42:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:42:20 --> Pagination Class Initialized
INFO - 2016-02-21 10:42:20 --> Helper loaded: text_helper
INFO - 2016-02-21 10:42:20 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 13:42:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:42:20 --> Final output sent to browser
DEBUG - 2016-02-21 13:42:20 --> Total execution time: 1.1520
INFO - 2016-02-21 10:42:35 --> Config Class Initialized
INFO - 2016-02-21 10:42:35 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:42:35 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:42:35 --> Utf8 Class Initialized
INFO - 2016-02-21 10:42:35 --> URI Class Initialized
INFO - 2016-02-21 10:42:35 --> Router Class Initialized
INFO - 2016-02-21 10:42:35 --> Output Class Initialized
INFO - 2016-02-21 10:42:35 --> Security Class Initialized
DEBUG - 2016-02-21 10:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:42:35 --> Input Class Initialized
INFO - 2016-02-21 10:42:35 --> Language Class Initialized
INFO - 2016-02-21 10:42:35 --> Loader Class Initialized
INFO - 2016-02-21 10:42:35 --> Helper loaded: url_helper
INFO - 2016-02-21 10:42:35 --> Helper loaded: file_helper
INFO - 2016-02-21 10:42:35 --> Helper loaded: date_helper
INFO - 2016-02-21 10:42:35 --> Helper loaded: form_helper
INFO - 2016-02-21 10:42:35 --> Database Driver Class Initialized
INFO - 2016-02-21 10:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:42:36 --> Controller Class Initialized
INFO - 2016-02-21 10:42:36 --> Model Class Initialized
INFO - 2016-02-21 10:42:36 --> Model Class Initialized
INFO - 2016-02-21 10:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:42:36 --> Pagination Class Initialized
INFO - 2016-02-21 10:42:36 --> Helper loaded: text_helper
INFO - 2016-02-21 10:42:36 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:42:36 --> Final output sent to browser
DEBUG - 2016-02-21 13:42:36 --> Total execution time: 1.2009
INFO - 2016-02-21 10:43:12 --> Config Class Initialized
INFO - 2016-02-21 10:43:12 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:12 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:12 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:12 --> URI Class Initialized
DEBUG - 2016-02-21 10:43:12 --> No URI present. Default controller set.
INFO - 2016-02-21 10:43:12 --> Router Class Initialized
INFO - 2016-02-21 10:43:12 --> Output Class Initialized
INFO - 2016-02-21 10:43:12 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:12 --> Input Class Initialized
INFO - 2016-02-21 10:43:12 --> Language Class Initialized
INFO - 2016-02-21 10:43:12 --> Loader Class Initialized
INFO - 2016-02-21 10:43:12 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:12 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:12 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:12 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:12 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:13 --> Controller Class Initialized
INFO - 2016-02-21 10:43:13 --> Model Class Initialized
INFO - 2016-02-21 10:43:13 --> Model Class Initialized
INFO - 2016-02-21 10:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:13 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:13 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:13 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 13:43:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-21 13:43:13 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 10:43:14 --> Config Class Initialized
INFO - 2016-02-21 10:43:14 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:14 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:14 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:14 --> URI Class Initialized
INFO - 2016-02-21 10:43:14 --> Router Class Initialized
INFO - 2016-02-21 10:43:14 --> Output Class Initialized
INFO - 2016-02-21 10:43:14 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:14 --> Input Class Initialized
INFO - 2016-02-21 10:43:14 --> Language Class Initialized
INFO - 2016-02-21 10:43:14 --> Loader Class Initialized
INFO - 2016-02-21 10:43:14 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:14 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:14 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:14 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:14 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:16 --> Controller Class Initialized
INFO - 2016-02-21 10:43:16 --> Model Class Initialized
INFO - 2016-02-21 10:43:16 --> Model Class Initialized
INFO - 2016-02-21 10:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:16 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:16 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:16 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:43:16 --> Final output sent to browser
DEBUG - 2016-02-21 13:43:16 --> Total execution time: 1.2006
INFO - 2016-02-21 10:43:18 --> Config Class Initialized
INFO - 2016-02-21 10:43:18 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:18 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:18 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:18 --> URI Class Initialized
INFO - 2016-02-21 10:43:18 --> Router Class Initialized
INFO - 2016-02-21 10:43:18 --> Output Class Initialized
INFO - 2016-02-21 10:43:18 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:18 --> Input Class Initialized
INFO - 2016-02-21 10:43:18 --> Language Class Initialized
INFO - 2016-02-21 10:43:18 --> Loader Class Initialized
INFO - 2016-02-21 10:43:18 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:18 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:18 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:18 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:18 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:19 --> Controller Class Initialized
INFO - 2016-02-21 10:43:19 --> Model Class Initialized
INFO - 2016-02-21 10:43:19 --> Model Class Initialized
INFO - 2016-02-21 10:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:19 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:19 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:19 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:43:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 13:43:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:43:19 --> Final output sent to browser
DEBUG - 2016-02-21 13:43:19 --> Total execution time: 1.1455
INFO - 2016-02-21 10:43:21 --> Config Class Initialized
INFO - 2016-02-21 10:43:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:21 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:21 --> URI Class Initialized
INFO - 2016-02-21 10:43:21 --> Router Class Initialized
INFO - 2016-02-21 10:43:21 --> Output Class Initialized
INFO - 2016-02-21 10:43:21 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:21 --> Input Class Initialized
INFO - 2016-02-21 10:43:21 --> Language Class Initialized
INFO - 2016-02-21 10:43:21 --> Loader Class Initialized
INFO - 2016-02-21 10:43:21 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:21 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:21 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:21 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:21 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:22 --> Controller Class Initialized
INFO - 2016-02-21 10:43:22 --> Model Class Initialized
INFO - 2016-02-21 10:43:22 --> Model Class Initialized
INFO - 2016-02-21 10:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:22 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:23 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:23 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:43:23 --> Final output sent to browser
DEBUG - 2016-02-21 13:43:23 --> Total execution time: 1.1843
INFO - 2016-02-21 10:43:26 --> Config Class Initialized
INFO - 2016-02-21 10:43:26 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:26 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:26 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:26 --> URI Class Initialized
INFO - 2016-02-21 10:43:26 --> Router Class Initialized
INFO - 2016-02-21 10:43:26 --> Output Class Initialized
INFO - 2016-02-21 10:43:26 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:26 --> Input Class Initialized
INFO - 2016-02-21 10:43:26 --> Language Class Initialized
INFO - 2016-02-21 10:43:26 --> Loader Class Initialized
INFO - 2016-02-21 10:43:26 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:26 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:26 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:26 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:26 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:27 --> Controller Class Initialized
INFO - 2016-02-21 10:43:27 --> Model Class Initialized
INFO - 2016-02-21 10:43:27 --> Model Class Initialized
INFO - 2016-02-21 10:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:27 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:27 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:27 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:43:27 --> Final output sent to browser
DEBUG - 2016-02-21 13:43:27 --> Total execution time: 1.2023
INFO - 2016-02-21 10:43:30 --> Config Class Initialized
INFO - 2016-02-21 10:43:30 --> Hooks Class Initialized
DEBUG - 2016-02-21 10:43:30 --> UTF-8 Support Enabled
INFO - 2016-02-21 10:43:30 --> Utf8 Class Initialized
INFO - 2016-02-21 10:43:30 --> URI Class Initialized
INFO - 2016-02-21 10:43:30 --> Router Class Initialized
INFO - 2016-02-21 10:43:30 --> Output Class Initialized
INFO - 2016-02-21 10:43:30 --> Security Class Initialized
DEBUG - 2016-02-21 10:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 10:43:30 --> Input Class Initialized
INFO - 2016-02-21 10:43:30 --> Language Class Initialized
INFO - 2016-02-21 10:43:30 --> Loader Class Initialized
INFO - 2016-02-21 10:43:30 --> Helper loaded: url_helper
INFO - 2016-02-21 10:43:30 --> Helper loaded: file_helper
INFO - 2016-02-21 10:43:30 --> Helper loaded: date_helper
INFO - 2016-02-21 10:43:30 --> Helper loaded: form_helper
INFO - 2016-02-21 10:43:30 --> Database Driver Class Initialized
INFO - 2016-02-21 10:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 10:43:31 --> Controller Class Initialized
INFO - 2016-02-21 10:43:31 --> Model Class Initialized
INFO - 2016-02-21 10:43:31 --> Model Class Initialized
INFO - 2016-02-21 10:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 10:43:31 --> Pagination Class Initialized
INFO - 2016-02-21 10:43:31 --> Helper loaded: text_helper
INFO - 2016-02-21 10:43:31 --> Helper loaded: cookie_helper
INFO - 2016-02-21 13:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 13:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 13:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 13:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 13:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 13:43:31 --> Final output sent to browser
DEBUG - 2016-02-21 13:43:31 --> Total execution time: 1.1890
INFO - 2016-02-21 12:20:54 --> Config Class Initialized
INFO - 2016-02-21 12:20:54 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:20:54 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:20:54 --> Utf8 Class Initialized
INFO - 2016-02-21 12:20:54 --> URI Class Initialized
INFO - 2016-02-21 12:20:54 --> Router Class Initialized
INFO - 2016-02-21 12:20:54 --> Output Class Initialized
INFO - 2016-02-21 12:20:54 --> Security Class Initialized
DEBUG - 2016-02-21 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:20:54 --> Input Class Initialized
INFO - 2016-02-21 12:20:54 --> Language Class Initialized
INFO - 2016-02-21 12:20:54 --> Loader Class Initialized
INFO - 2016-02-21 12:20:54 --> Helper loaded: url_helper
INFO - 2016-02-21 12:20:54 --> Helper loaded: file_helper
INFO - 2016-02-21 12:20:54 --> Helper loaded: date_helper
INFO - 2016-02-21 12:20:54 --> Helper loaded: form_helper
INFO - 2016-02-21 12:20:54 --> Database Driver Class Initialized
INFO - 2016-02-21 12:20:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:20:55 --> Controller Class Initialized
INFO - 2016-02-21 12:20:55 --> Model Class Initialized
INFO - 2016-02-21 12:20:55 --> Model Class Initialized
INFO - 2016-02-21 12:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:20:55 --> Pagination Class Initialized
INFO - 2016-02-21 12:20:55 --> Helper loaded: text_helper
INFO - 2016-02-21 12:20:55 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:20:55 --> Final output sent to browser
DEBUG - 2016-02-21 15:20:55 --> Total execution time: 1.1546
INFO - 2016-02-21 12:21:04 --> Config Class Initialized
INFO - 2016-02-21 12:21:04 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:04 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:04 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:04 --> URI Class Initialized
INFO - 2016-02-21 12:21:04 --> Router Class Initialized
INFO - 2016-02-21 12:21:04 --> Output Class Initialized
INFO - 2016-02-21 12:21:04 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:04 --> Input Class Initialized
INFO - 2016-02-21 12:21:04 --> Language Class Initialized
INFO - 2016-02-21 12:21:04 --> Loader Class Initialized
INFO - 2016-02-21 12:21:04 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:04 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:04 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:04 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:04 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:05 --> Controller Class Initialized
INFO - 2016-02-21 12:21:05 --> Model Class Initialized
INFO - 2016-02-21 12:21:05 --> Model Class Initialized
INFO - 2016-02-21 12:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:05 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:05 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:05 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:21:05 --> Final output sent to browser
DEBUG - 2016-02-21 15:21:05 --> Total execution time: 1.1457
INFO - 2016-02-21 12:21:16 --> Config Class Initialized
INFO - 2016-02-21 12:21:16 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:16 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:16 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:16 --> URI Class Initialized
INFO - 2016-02-21 12:21:16 --> Router Class Initialized
INFO - 2016-02-21 12:21:16 --> Output Class Initialized
INFO - 2016-02-21 12:21:16 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:16 --> Input Class Initialized
INFO - 2016-02-21 12:21:16 --> Language Class Initialized
INFO - 2016-02-21 12:21:16 --> Loader Class Initialized
INFO - 2016-02-21 12:21:16 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:16 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:16 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:16 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:16 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:17 --> Controller Class Initialized
INFO - 2016-02-21 12:21:17 --> Model Class Initialized
INFO - 2016-02-21 12:21:17 --> Model Class Initialized
INFO - 2016-02-21 12:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:17 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:17 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:17 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:21:17 --> Final output sent to browser
DEBUG - 2016-02-21 15:21:17 --> Total execution time: 1.1979
INFO - 2016-02-21 12:21:28 --> Config Class Initialized
INFO - 2016-02-21 12:21:28 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:28 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:28 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:28 --> URI Class Initialized
INFO - 2016-02-21 12:21:28 --> Router Class Initialized
INFO - 2016-02-21 12:21:28 --> Output Class Initialized
INFO - 2016-02-21 12:21:28 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:28 --> Input Class Initialized
INFO - 2016-02-21 12:21:28 --> Language Class Initialized
INFO - 2016-02-21 12:21:28 --> Loader Class Initialized
INFO - 2016-02-21 12:21:28 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:28 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:28 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:28 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:28 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:29 --> Controller Class Initialized
INFO - 2016-02-21 12:21:29 --> Model Class Initialized
INFO - 2016-02-21 12:21:29 --> Model Class Initialized
INFO - 2016-02-21 12:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:29 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:29 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:29 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:21:29 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 156
INFO - 2016-02-21 12:21:29 --> Config Class Initialized
INFO - 2016-02-21 12:21:29 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:29 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:29 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:29 --> URI Class Initialized
INFO - 2016-02-21 12:21:29 --> Router Class Initialized
INFO - 2016-02-21 12:21:29 --> Output Class Initialized
INFO - 2016-02-21 12:21:29 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:29 --> Input Class Initialized
INFO - 2016-02-21 12:21:29 --> Language Class Initialized
INFO - 2016-02-21 12:21:29 --> Loader Class Initialized
INFO - 2016-02-21 12:21:29 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:29 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:29 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:29 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:29 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:30 --> Controller Class Initialized
INFO - 2016-02-21 12:21:30 --> Model Class Initialized
INFO - 2016-02-21 12:21:30 --> Model Class Initialized
INFO - 2016-02-21 12:21:30 --> Form Validation Class Initialized
INFO - 2016-02-21 12:21:30 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 12:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 12:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-21 12:21:30 --> Final output sent to browser
DEBUG - 2016-02-21 12:21:30 --> Total execution time: 1.1600
INFO - 2016-02-21 12:21:33 --> Config Class Initialized
INFO - 2016-02-21 12:21:33 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:33 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:33 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:33 --> URI Class Initialized
INFO - 2016-02-21 12:21:33 --> Router Class Initialized
INFO - 2016-02-21 12:21:33 --> Output Class Initialized
INFO - 2016-02-21 12:21:33 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:33 --> Input Class Initialized
INFO - 2016-02-21 12:21:33 --> Language Class Initialized
INFO - 2016-02-21 12:21:33 --> Loader Class Initialized
INFO - 2016-02-21 12:21:33 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:33 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:33 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:33 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:33 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:34 --> Controller Class Initialized
INFO - 2016-02-21 12:21:34 --> Model Class Initialized
INFO - 2016-02-21 12:21:34 --> Model Class Initialized
INFO - 2016-02-21 12:21:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:34 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:34 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:34 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:21:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:21:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:21:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:21:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:21:34 --> Final output sent to browser
DEBUG - 2016-02-21 15:21:34 --> Total execution time: 1.1137
INFO - 2016-02-21 12:21:41 --> Config Class Initialized
INFO - 2016-02-21 12:21:41 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:41 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:41 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:41 --> URI Class Initialized
INFO - 2016-02-21 12:21:41 --> Router Class Initialized
INFO - 2016-02-21 12:21:41 --> Output Class Initialized
INFO - 2016-02-21 12:21:41 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:41 --> Input Class Initialized
INFO - 2016-02-21 12:21:41 --> Language Class Initialized
INFO - 2016-02-21 12:21:41 --> Loader Class Initialized
INFO - 2016-02-21 12:21:41 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:41 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:41 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:41 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:41 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:42 --> Controller Class Initialized
INFO - 2016-02-21 12:21:42 --> Model Class Initialized
INFO - 2016-02-21 12:21:42 --> Model Class Initialized
INFO - 2016-02-21 12:21:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:42 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:42 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:42 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:21:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:21:42 --> Final output sent to browser
DEBUG - 2016-02-21 15:21:42 --> Total execution time: 1.1455
INFO - 2016-02-21 12:21:57 --> Config Class Initialized
INFO - 2016-02-21 12:21:57 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:57 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:57 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:57 --> URI Class Initialized
INFO - 2016-02-21 12:21:57 --> Router Class Initialized
INFO - 2016-02-21 12:21:57 --> Output Class Initialized
INFO - 2016-02-21 12:21:57 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:57 --> Input Class Initialized
INFO - 2016-02-21 12:21:57 --> Language Class Initialized
INFO - 2016-02-21 12:21:57 --> Loader Class Initialized
INFO - 2016-02-21 12:21:57 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:57 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:57 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:57 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:57 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:58 --> Controller Class Initialized
INFO - 2016-02-21 12:21:58 --> Model Class Initialized
INFO - 2016-02-21 12:21:58 --> Model Class Initialized
INFO - 2016-02-21 12:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:21:58 --> Pagination Class Initialized
INFO - 2016-02-21 12:21:58 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:58 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:21:58 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 156
INFO - 2016-02-21 12:21:58 --> Config Class Initialized
INFO - 2016-02-21 12:21:58 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:21:58 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:21:58 --> Utf8 Class Initialized
INFO - 2016-02-21 12:21:58 --> URI Class Initialized
INFO - 2016-02-21 12:21:58 --> Router Class Initialized
INFO - 2016-02-21 12:21:58 --> Output Class Initialized
INFO - 2016-02-21 12:21:58 --> Security Class Initialized
DEBUG - 2016-02-21 12:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:21:58 --> Input Class Initialized
INFO - 2016-02-21 12:21:58 --> Language Class Initialized
INFO - 2016-02-21 12:21:58 --> Loader Class Initialized
INFO - 2016-02-21 12:21:58 --> Helper loaded: url_helper
INFO - 2016-02-21 12:21:58 --> Helper loaded: file_helper
INFO - 2016-02-21 12:21:58 --> Helper loaded: date_helper
INFO - 2016-02-21 12:21:58 --> Helper loaded: form_helper
INFO - 2016-02-21 12:21:58 --> Database Driver Class Initialized
INFO - 2016-02-21 12:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:21:59 --> Controller Class Initialized
INFO - 2016-02-21 12:21:59 --> Model Class Initialized
INFO - 2016-02-21 12:21:59 --> Model Class Initialized
INFO - 2016-02-21 12:21:59 --> Form Validation Class Initialized
INFO - 2016-02-21 12:21:59 --> Helper loaded: text_helper
INFO - 2016-02-21 12:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 12:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 12:21:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-21 12:21:59 --> Final output sent to browser
DEBUG - 2016-02-21 12:21:59 --> Total execution time: 1.1307
INFO - 2016-02-21 12:22:36 --> Config Class Initialized
INFO - 2016-02-21 12:22:36 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:22:36 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:22:36 --> Utf8 Class Initialized
INFO - 2016-02-21 12:22:36 --> URI Class Initialized
INFO - 2016-02-21 12:22:36 --> Router Class Initialized
INFO - 2016-02-21 12:22:36 --> Output Class Initialized
INFO - 2016-02-21 12:22:36 --> Security Class Initialized
DEBUG - 2016-02-21 12:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:22:36 --> Input Class Initialized
INFO - 2016-02-21 12:22:36 --> Language Class Initialized
INFO - 2016-02-21 12:22:36 --> Loader Class Initialized
INFO - 2016-02-21 12:22:36 --> Helper loaded: url_helper
INFO - 2016-02-21 12:22:36 --> Helper loaded: file_helper
INFO - 2016-02-21 12:22:36 --> Helper loaded: date_helper
INFO - 2016-02-21 12:22:36 --> Helper loaded: form_helper
INFO - 2016-02-21 12:22:36 --> Database Driver Class Initialized
INFO - 2016-02-21 12:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:22:37 --> Controller Class Initialized
INFO - 2016-02-21 12:22:37 --> Model Class Initialized
INFO - 2016-02-21 12:22:37 --> Model Class Initialized
INFO - 2016-02-21 12:22:37 --> Form Validation Class Initialized
INFO - 2016-02-21 12:22:37 --> Helper loaded: text_helper
INFO - 2016-02-21 12:22:37 --> Config Class Initialized
INFO - 2016-02-21 12:22:37 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:22:37 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:22:37 --> Utf8 Class Initialized
INFO - 2016-02-21 12:22:37 --> URI Class Initialized
INFO - 2016-02-21 12:22:37 --> Router Class Initialized
INFO - 2016-02-21 12:22:37 --> Output Class Initialized
INFO - 2016-02-21 12:22:37 --> Security Class Initialized
DEBUG - 2016-02-21 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:22:37 --> Input Class Initialized
INFO - 2016-02-21 12:22:37 --> Language Class Initialized
INFO - 2016-02-21 12:22:37 --> Loader Class Initialized
INFO - 2016-02-21 12:22:37 --> Helper loaded: url_helper
INFO - 2016-02-21 12:22:37 --> Helper loaded: file_helper
INFO - 2016-02-21 12:22:37 --> Helper loaded: date_helper
INFO - 2016-02-21 12:22:37 --> Helper loaded: form_helper
INFO - 2016-02-21 12:22:37 --> Database Driver Class Initialized
INFO - 2016-02-21 12:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:22:38 --> Controller Class Initialized
INFO - 2016-02-21 12:22:38 --> Model Class Initialized
INFO - 2016-02-21 12:22:38 --> Model Class Initialized
INFO - 2016-02-21 12:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:22:38 --> Pagination Class Initialized
INFO - 2016-02-21 12:22:38 --> Helper loaded: text_helper
INFO - 2016-02-21 12:22:38 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:22:38 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 156
INFO - 2016-02-21 15:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:22:38 --> Form Validation Class Initialized
INFO - 2016-02-21 15:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:22:38 --> Final output sent to browser
DEBUG - 2016-02-21 15:22:38 --> Total execution time: 1.1196
INFO - 2016-02-21 12:22:56 --> Config Class Initialized
INFO - 2016-02-21 12:22:56 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:22:56 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:22:56 --> Utf8 Class Initialized
INFO - 2016-02-21 12:22:56 --> URI Class Initialized
INFO - 2016-02-21 12:22:56 --> Router Class Initialized
INFO - 2016-02-21 12:22:56 --> Output Class Initialized
INFO - 2016-02-21 12:22:56 --> Security Class Initialized
DEBUG - 2016-02-21 12:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:22:56 --> Input Class Initialized
INFO - 2016-02-21 12:22:56 --> Language Class Initialized
INFO - 2016-02-21 12:22:56 --> Loader Class Initialized
INFO - 2016-02-21 12:22:56 --> Helper loaded: url_helper
INFO - 2016-02-21 12:22:56 --> Helper loaded: file_helper
INFO - 2016-02-21 12:22:56 --> Helper loaded: date_helper
INFO - 2016-02-21 12:22:56 --> Helper loaded: form_helper
INFO - 2016-02-21 12:22:56 --> Database Driver Class Initialized
INFO - 2016-02-21 12:22:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:22:57 --> Controller Class Initialized
INFO - 2016-02-21 12:22:57 --> Model Class Initialized
INFO - 2016-02-21 12:22:57 --> Model Class Initialized
INFO - 2016-02-21 12:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:22:57 --> Pagination Class Initialized
INFO - 2016-02-21 12:22:57 --> Helper loaded: text_helper
INFO - 2016-02-21 12:22:57 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:22:57 --> Final output sent to browser
DEBUG - 2016-02-21 15:22:57 --> Total execution time: 1.1538
INFO - 2016-02-21 12:23:00 --> Config Class Initialized
INFO - 2016-02-21 12:23:00 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:23:00 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:23:00 --> Utf8 Class Initialized
INFO - 2016-02-21 12:23:00 --> URI Class Initialized
INFO - 2016-02-21 12:23:00 --> Router Class Initialized
INFO - 2016-02-21 12:23:00 --> Output Class Initialized
INFO - 2016-02-21 12:23:00 --> Security Class Initialized
DEBUG - 2016-02-21 12:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:23:00 --> Input Class Initialized
INFO - 2016-02-21 12:23:00 --> Language Class Initialized
INFO - 2016-02-21 12:23:00 --> Loader Class Initialized
INFO - 2016-02-21 12:23:00 --> Helper loaded: url_helper
INFO - 2016-02-21 12:23:00 --> Helper loaded: file_helper
INFO - 2016-02-21 12:23:00 --> Helper loaded: date_helper
INFO - 2016-02-21 12:23:00 --> Helper loaded: form_helper
INFO - 2016-02-21 12:23:00 --> Database Driver Class Initialized
INFO - 2016-02-21 12:23:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:23:01 --> Controller Class Initialized
INFO - 2016-02-21 12:23:01 --> Model Class Initialized
INFO - 2016-02-21 12:23:01 --> Model Class Initialized
INFO - 2016-02-21 12:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:23:01 --> Pagination Class Initialized
INFO - 2016-02-21 12:23:01 --> Helper loaded: text_helper
INFO - 2016-02-21 12:23:01 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:23:01 --> Final output sent to browser
DEBUG - 2016-02-21 15:23:01 --> Total execution time: 1.1313
INFO - 2016-02-21 12:23:14 --> Config Class Initialized
INFO - 2016-02-21 12:23:14 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:23:14 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:23:14 --> Utf8 Class Initialized
INFO - 2016-02-21 12:23:14 --> URI Class Initialized
INFO - 2016-02-21 12:23:14 --> Router Class Initialized
INFO - 2016-02-21 12:23:14 --> Output Class Initialized
INFO - 2016-02-21 12:23:14 --> Security Class Initialized
DEBUG - 2016-02-21 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:23:14 --> Input Class Initialized
INFO - 2016-02-21 12:23:14 --> Language Class Initialized
INFO - 2016-02-21 12:23:14 --> Loader Class Initialized
INFO - 2016-02-21 12:23:14 --> Helper loaded: url_helper
INFO - 2016-02-21 12:23:14 --> Helper loaded: file_helper
INFO - 2016-02-21 12:23:14 --> Helper loaded: date_helper
INFO - 2016-02-21 12:23:14 --> Helper loaded: form_helper
INFO - 2016-02-21 12:23:14 --> Database Driver Class Initialized
INFO - 2016-02-21 12:23:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:23:15 --> Controller Class Initialized
INFO - 2016-02-21 12:23:15 --> Model Class Initialized
INFO - 2016-02-21 12:23:15 --> Model Class Initialized
INFO - 2016-02-21 12:23:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:23:15 --> Pagination Class Initialized
INFO - 2016-02-21 12:23:15 --> Helper loaded: text_helper
INFO - 2016-02-21 12:23:15 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:23:15 --> Severity: Warning --> Missing argument 1 for Jboard::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 156
INFO - 2016-02-21 15:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:23:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:23:15 --> Form Validation Class Initialized
INFO - 2016-02-21 15:23:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-21 15:23:15 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 183
ERROR - 2016-02-21 15:23:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), 'oh my ' at line 1 - Invalid query: INSERT INTO  (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), 'oh my test', '9', 'oda', '<p>asdsad</p>\r\n')
INFO - 2016-02-21 15:23:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 12:25:43 --> Config Class Initialized
INFO - 2016-02-21 12:25:43 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:25:43 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:25:43 --> Utf8 Class Initialized
INFO - 2016-02-21 12:25:43 --> URI Class Initialized
INFO - 2016-02-21 12:25:43 --> Router Class Initialized
INFO - 2016-02-21 12:25:43 --> Output Class Initialized
INFO - 2016-02-21 12:25:43 --> Security Class Initialized
DEBUG - 2016-02-21 12:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:25:43 --> Input Class Initialized
INFO - 2016-02-21 12:25:43 --> Language Class Initialized
INFO - 2016-02-21 12:25:43 --> Loader Class Initialized
INFO - 2016-02-21 12:25:43 --> Helper loaded: url_helper
INFO - 2016-02-21 12:25:43 --> Helper loaded: file_helper
INFO - 2016-02-21 12:25:43 --> Helper loaded: date_helper
INFO - 2016-02-21 12:25:43 --> Helper loaded: form_helper
INFO - 2016-02-21 12:25:43 --> Database Driver Class Initialized
INFO - 2016-02-21 12:25:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:25:44 --> Controller Class Initialized
INFO - 2016-02-21 12:25:44 --> Model Class Initialized
INFO - 2016-02-21 12:25:44 --> Model Class Initialized
INFO - 2016-02-21 12:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:25:44 --> Pagination Class Initialized
INFO - 2016-02-21 12:25:44 --> Helper loaded: text_helper
INFO - 2016-02-21 12:25:44 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:25:44 --> Final output sent to browser
DEBUG - 2016-02-21 15:25:44 --> Total execution time: 1.1904
INFO - 2016-02-21 12:25:49 --> Config Class Initialized
INFO - 2016-02-21 12:25:49 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:25:49 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:25:49 --> Utf8 Class Initialized
INFO - 2016-02-21 12:25:49 --> URI Class Initialized
INFO - 2016-02-21 12:25:49 --> Router Class Initialized
INFO - 2016-02-21 12:25:49 --> Output Class Initialized
INFO - 2016-02-21 12:25:49 --> Security Class Initialized
DEBUG - 2016-02-21 12:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:25:49 --> Input Class Initialized
INFO - 2016-02-21 12:25:49 --> Language Class Initialized
INFO - 2016-02-21 12:25:49 --> Loader Class Initialized
INFO - 2016-02-21 12:25:49 --> Helper loaded: url_helper
INFO - 2016-02-21 12:25:49 --> Helper loaded: file_helper
INFO - 2016-02-21 12:25:49 --> Helper loaded: date_helper
INFO - 2016-02-21 12:25:49 --> Helper loaded: form_helper
INFO - 2016-02-21 12:25:49 --> Database Driver Class Initialized
INFO - 2016-02-21 12:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:25:50 --> Controller Class Initialized
INFO - 2016-02-21 12:25:50 --> Model Class Initialized
INFO - 2016-02-21 12:25:50 --> Model Class Initialized
INFO - 2016-02-21 12:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:25:50 --> Pagination Class Initialized
INFO - 2016-02-21 12:25:50 --> Helper loaded: text_helper
INFO - 2016-02-21 12:25:50 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:25:50 --> Final output sent to browser
DEBUG - 2016-02-21 15:25:50 --> Total execution time: 1.1288
INFO - 2016-02-21 12:26:14 --> Config Class Initialized
INFO - 2016-02-21 12:26:14 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:26:14 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:26:14 --> Utf8 Class Initialized
INFO - 2016-02-21 12:26:14 --> URI Class Initialized
INFO - 2016-02-21 12:26:14 --> Router Class Initialized
INFO - 2016-02-21 12:26:14 --> Output Class Initialized
INFO - 2016-02-21 12:26:14 --> Security Class Initialized
DEBUG - 2016-02-21 12:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:26:14 --> Input Class Initialized
INFO - 2016-02-21 12:26:14 --> Language Class Initialized
INFO - 2016-02-21 12:26:14 --> Loader Class Initialized
INFO - 2016-02-21 12:26:14 --> Helper loaded: url_helper
INFO - 2016-02-21 12:26:14 --> Helper loaded: file_helper
INFO - 2016-02-21 12:26:14 --> Helper loaded: date_helper
INFO - 2016-02-21 12:26:14 --> Helper loaded: form_helper
INFO - 2016-02-21 12:26:14 --> Database Driver Class Initialized
INFO - 2016-02-21 12:26:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:26:15 --> Controller Class Initialized
INFO - 2016-02-21 12:26:15 --> Model Class Initialized
INFO - 2016-02-21 12:26:15 --> Model Class Initialized
INFO - 2016-02-21 12:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:26:15 --> Pagination Class Initialized
INFO - 2016-02-21 12:26:15 --> Helper loaded: text_helper
INFO - 2016-02-21 12:26:15 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:26:15 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-02-21 15:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:26:15 --> Form Validation Class Initialized
INFO - 2016-02-21 15:26:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-21 15:26:15 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 191
ERROR - 2016-02-21 15:26:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), 'lalave' at line 1 - Invalid query: INSERT INTO  (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), 'lalavell', '9', 'oda', '<p>cool freamwork</p>\r\n')
INFO - 2016-02-21 15:26:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 12:28:02 --> Config Class Initialized
INFO - 2016-02-21 12:28:02 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:28:02 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:28:02 --> Utf8 Class Initialized
INFO - 2016-02-21 12:28:02 --> URI Class Initialized
INFO - 2016-02-21 12:28:02 --> Router Class Initialized
INFO - 2016-02-21 12:28:02 --> Output Class Initialized
INFO - 2016-02-21 12:28:02 --> Security Class Initialized
DEBUG - 2016-02-21 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:28:02 --> Input Class Initialized
INFO - 2016-02-21 12:28:02 --> Language Class Initialized
INFO - 2016-02-21 12:28:02 --> Loader Class Initialized
INFO - 2016-02-21 12:28:02 --> Helper loaded: url_helper
INFO - 2016-02-21 12:28:02 --> Helper loaded: file_helper
INFO - 2016-02-21 12:28:02 --> Helper loaded: date_helper
INFO - 2016-02-21 12:28:02 --> Helper loaded: form_helper
INFO - 2016-02-21 12:28:02 --> Database Driver Class Initialized
INFO - 2016-02-21 12:28:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:28:03 --> Controller Class Initialized
INFO - 2016-02-21 12:28:03 --> Model Class Initialized
INFO - 2016-02-21 12:28:03 --> Model Class Initialized
INFO - 2016-02-21 12:28:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:28:03 --> Pagination Class Initialized
INFO - 2016-02-21 12:28:03 --> Helper loaded: text_helper
INFO - 2016-02-21 12:28:03 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:28:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:28:03 --> Final output sent to browser
DEBUG - 2016-02-21 15:28:03 --> Total execution time: 1.1967
INFO - 2016-02-21 12:28:55 --> Config Class Initialized
INFO - 2016-02-21 12:28:55 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:28:55 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:28:55 --> Utf8 Class Initialized
INFO - 2016-02-21 12:28:55 --> URI Class Initialized
INFO - 2016-02-21 12:28:55 --> Router Class Initialized
INFO - 2016-02-21 12:28:55 --> Output Class Initialized
INFO - 2016-02-21 12:28:55 --> Security Class Initialized
DEBUG - 2016-02-21 12:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:28:55 --> Input Class Initialized
INFO - 2016-02-21 12:28:55 --> Language Class Initialized
INFO - 2016-02-21 12:28:55 --> Loader Class Initialized
INFO - 2016-02-21 12:28:55 --> Helper loaded: url_helper
INFO - 2016-02-21 12:28:55 --> Helper loaded: file_helper
INFO - 2016-02-21 12:28:55 --> Helper loaded: date_helper
INFO - 2016-02-21 12:28:55 --> Helper loaded: form_helper
INFO - 2016-02-21 12:28:55 --> Database Driver Class Initialized
INFO - 2016-02-21 12:28:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:28:56 --> Controller Class Initialized
INFO - 2016-02-21 12:28:56 --> Model Class Initialized
INFO - 2016-02-21 12:28:56 --> Model Class Initialized
INFO - 2016-02-21 12:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:28:56 --> Pagination Class Initialized
INFO - 2016-02-21 12:28:56 --> Helper loaded: text_helper
INFO - 2016-02-21 12:28:56 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:28:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:28:56 --> Final output sent to browser
DEBUG - 2016-02-21 15:28:56 --> Total execution time: 1.1363
INFO - 2016-02-21 12:29:14 --> Config Class Initialized
INFO - 2016-02-21 12:29:14 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:29:14 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:29:14 --> Utf8 Class Initialized
INFO - 2016-02-21 12:29:14 --> URI Class Initialized
INFO - 2016-02-21 12:29:14 --> Router Class Initialized
INFO - 2016-02-21 12:29:14 --> Output Class Initialized
INFO - 2016-02-21 12:29:14 --> Security Class Initialized
DEBUG - 2016-02-21 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:29:14 --> Input Class Initialized
INFO - 2016-02-21 12:29:14 --> Language Class Initialized
INFO - 2016-02-21 12:29:14 --> Loader Class Initialized
INFO - 2016-02-21 12:29:14 --> Helper loaded: url_helper
INFO - 2016-02-21 12:29:14 --> Helper loaded: file_helper
INFO - 2016-02-21 12:29:14 --> Helper loaded: date_helper
INFO - 2016-02-21 12:29:14 --> Helper loaded: form_helper
INFO - 2016-02-21 12:29:14 --> Database Driver Class Initialized
INFO - 2016-02-21 12:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:29:15 --> Controller Class Initialized
INFO - 2016-02-21 12:29:15 --> Model Class Initialized
INFO - 2016-02-21 12:29:15 --> Model Class Initialized
INFO - 2016-02-21 12:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:29:15 --> Pagination Class Initialized
INFO - 2016-02-21 12:29:15 --> Helper loaded: text_helper
INFO - 2016-02-21 12:29:15 --> Helper loaded: cookie_helper
ERROR - 2016-02-21 15:29:15 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-02-21 15:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:29:15 --> Form Validation Class Initialized
INFO - 2016-02-21 15:29:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-21 12:29:15 --> Config Class Initialized
INFO - 2016-02-21 12:29:15 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:29:15 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:29:15 --> Utf8 Class Initialized
INFO - 2016-02-21 12:29:15 --> URI Class Initialized
INFO - 2016-02-21 12:29:15 --> Router Class Initialized
INFO - 2016-02-21 12:29:15 --> Output Class Initialized
INFO - 2016-02-21 12:29:15 --> Security Class Initialized
DEBUG - 2016-02-21 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:29:15 --> Input Class Initialized
INFO - 2016-02-21 12:29:15 --> Language Class Initialized
INFO - 2016-02-21 12:29:15 --> Loader Class Initialized
INFO - 2016-02-21 12:29:15 --> Helper loaded: url_helper
INFO - 2016-02-21 12:29:15 --> Helper loaded: file_helper
INFO - 2016-02-21 12:29:15 --> Helper loaded: date_helper
INFO - 2016-02-21 12:29:15 --> Helper loaded: form_helper
INFO - 2016-02-21 12:29:15 --> Database Driver Class Initialized
INFO - 2016-02-21 12:29:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:29:16 --> Controller Class Initialized
INFO - 2016-02-21 12:29:16 --> Model Class Initialized
INFO - 2016-02-21 12:29:16 --> Model Class Initialized
INFO - 2016-02-21 12:29:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:29:16 --> Pagination Class Initialized
INFO - 2016-02-21 12:29:16 --> Helper loaded: text_helper
INFO - 2016-02-21 12:29:16 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:29:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:29:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:29:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 15:29:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:29:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:29:16 --> Final output sent to browser
DEBUG - 2016-02-21 15:29:16 --> Total execution time: 1.2305
INFO - 2016-02-21 12:29:26 --> Config Class Initialized
INFO - 2016-02-21 12:29:26 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:29:26 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:29:26 --> Utf8 Class Initialized
INFO - 2016-02-21 12:29:26 --> URI Class Initialized
INFO - 2016-02-21 12:29:26 --> Router Class Initialized
INFO - 2016-02-21 12:29:26 --> Output Class Initialized
INFO - 2016-02-21 12:29:26 --> Security Class Initialized
DEBUG - 2016-02-21 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:29:27 --> Input Class Initialized
INFO - 2016-02-21 12:29:27 --> Language Class Initialized
INFO - 2016-02-21 12:29:27 --> Loader Class Initialized
INFO - 2016-02-21 12:29:27 --> Helper loaded: url_helper
INFO - 2016-02-21 12:29:27 --> Helper loaded: file_helper
INFO - 2016-02-21 12:29:27 --> Helper loaded: date_helper
INFO - 2016-02-21 12:29:27 --> Helper loaded: form_helper
INFO - 2016-02-21 12:29:27 --> Database Driver Class Initialized
INFO - 2016-02-21 12:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:29:28 --> Controller Class Initialized
INFO - 2016-02-21 12:29:28 --> Model Class Initialized
INFO - 2016-02-21 12:29:28 --> Model Class Initialized
INFO - 2016-02-21 12:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:29:28 --> Pagination Class Initialized
INFO - 2016-02-21 12:29:28 --> Helper loaded: text_helper
INFO - 2016-02-21 12:29:28 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 15:29:28 --> Severity: Notice --> Undefined property: Wall::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 352
ERROR - 2016-02-21 15:29:28 --> Severity: Error --> Call to a member function del_user_id() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 352
INFO - 2016-02-21 12:31:01 --> Config Class Initialized
INFO - 2016-02-21 12:31:01 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:01 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:01 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:01 --> URI Class Initialized
INFO - 2016-02-21 12:31:01 --> Router Class Initialized
INFO - 2016-02-21 12:31:01 --> Output Class Initialized
INFO - 2016-02-21 12:31:01 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:01 --> Input Class Initialized
INFO - 2016-02-21 12:31:01 --> Language Class Initialized
INFO - 2016-02-21 12:31:01 --> Loader Class Initialized
INFO - 2016-02-21 12:31:01 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:01 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:01 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:01 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:01 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:02 --> Controller Class Initialized
INFO - 2016-02-21 12:31:02 --> Model Class Initialized
INFO - 2016-02-21 12:31:02 --> Model Class Initialized
INFO - 2016-02-21 12:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:02 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:02 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:02 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 15:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:02 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:02 --> Total execution time: 1.2059
INFO - 2016-02-21 12:31:04 --> Config Class Initialized
INFO - 2016-02-21 12:31:04 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:04 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:04 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:04 --> URI Class Initialized
INFO - 2016-02-21 12:31:04 --> Router Class Initialized
INFO - 2016-02-21 12:31:04 --> Output Class Initialized
INFO - 2016-02-21 12:31:04 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:04 --> Input Class Initialized
INFO - 2016-02-21 12:31:04 --> Language Class Initialized
INFO - 2016-02-21 12:31:04 --> Loader Class Initialized
INFO - 2016-02-21 12:31:04 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:04 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:04 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:04 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:04 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:05 --> Controller Class Initialized
INFO - 2016-02-21 12:31:05 --> Model Class Initialized
INFO - 2016-02-21 12:31:05 --> Model Class Initialized
INFO - 2016-02-21 12:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:05 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:05 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:05 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-21 15:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:05 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:05 --> Total execution time: 1.1838
INFO - 2016-02-21 12:31:18 --> Config Class Initialized
INFO - 2016-02-21 12:31:18 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:18 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:18 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:18 --> URI Class Initialized
INFO - 2016-02-21 12:31:18 --> Router Class Initialized
INFO - 2016-02-21 12:31:18 --> Output Class Initialized
INFO - 2016-02-21 12:31:18 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:18 --> Input Class Initialized
INFO - 2016-02-21 12:31:18 --> Language Class Initialized
INFO - 2016-02-21 12:31:18 --> Loader Class Initialized
INFO - 2016-02-21 12:31:18 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:18 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:18 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:18 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:18 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:19 --> Controller Class Initialized
INFO - 2016-02-21 12:31:19 --> Model Class Initialized
INFO - 2016-02-21 12:31:19 --> Model Class Initialized
INFO - 2016-02-21 12:31:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:19 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:19 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:19 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 15:31:19 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `jboard`
INFO - 2016-02-21 15:31:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-21 12:31:21 --> Config Class Initialized
INFO - 2016-02-21 12:31:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:21 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:21 --> URI Class Initialized
INFO - 2016-02-21 12:31:21 --> Router Class Initialized
INFO - 2016-02-21 12:31:21 --> Output Class Initialized
INFO - 2016-02-21 12:31:21 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:21 --> Input Class Initialized
INFO - 2016-02-21 12:31:21 --> Language Class Initialized
INFO - 2016-02-21 12:31:21 --> Loader Class Initialized
INFO - 2016-02-21 12:31:21 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:21 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:21 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:21 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:21 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:22 --> Controller Class Initialized
INFO - 2016-02-21 12:31:22 --> Model Class Initialized
INFO - 2016-02-21 12:31:22 --> Model Class Initialized
INFO - 2016-02-21 12:31:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:22 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:22 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-21 15:31:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:22 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:22 --> Total execution time: 1.1735
INFO - 2016-02-21 12:31:25 --> Config Class Initialized
INFO - 2016-02-21 12:31:25 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:25 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:25 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:25 --> URI Class Initialized
INFO - 2016-02-21 12:31:25 --> Router Class Initialized
INFO - 2016-02-21 12:31:25 --> Output Class Initialized
INFO - 2016-02-21 12:31:25 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:25 --> Input Class Initialized
INFO - 2016-02-21 12:31:25 --> Language Class Initialized
INFO - 2016-02-21 12:31:25 --> Loader Class Initialized
INFO - 2016-02-21 12:31:25 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:25 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:25 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:25 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:25 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:26 --> Controller Class Initialized
INFO - 2016-02-21 12:31:26 --> Model Class Initialized
INFO - 2016-02-21 12:31:26 --> Model Class Initialized
INFO - 2016-02-21 12:31:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:26 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:26 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:26 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:26 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:26 --> Total execution time: 1.1938
INFO - 2016-02-21 12:31:35 --> Config Class Initialized
INFO - 2016-02-21 12:31:35 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:35 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:35 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:35 --> URI Class Initialized
INFO - 2016-02-21 12:31:35 --> Router Class Initialized
INFO - 2016-02-21 12:31:35 --> Output Class Initialized
INFO - 2016-02-21 12:31:35 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:35 --> Input Class Initialized
INFO - 2016-02-21 12:31:35 --> Language Class Initialized
INFO - 2016-02-21 12:31:35 --> Loader Class Initialized
INFO - 2016-02-21 12:31:35 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:35 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:35 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:35 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:35 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:36 --> Controller Class Initialized
INFO - 2016-02-21 12:31:36 --> Model Class Initialized
INFO - 2016-02-21 12:31:36 --> Model Class Initialized
INFO - 2016-02-21 12:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:36 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:36 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:36 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-21 15:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:36 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:36 --> Total execution time: 1.1517
INFO - 2016-02-21 12:31:38 --> Config Class Initialized
INFO - 2016-02-21 12:31:38 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:38 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:38 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:38 --> URI Class Initialized
INFO - 2016-02-21 12:31:38 --> Router Class Initialized
INFO - 2016-02-21 12:31:38 --> Output Class Initialized
INFO - 2016-02-21 12:31:38 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:38 --> Input Class Initialized
INFO - 2016-02-21 12:31:38 --> Language Class Initialized
INFO - 2016-02-21 12:31:38 --> Loader Class Initialized
INFO - 2016-02-21 12:31:38 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:38 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:38 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:38 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:38 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:39 --> Controller Class Initialized
INFO - 2016-02-21 12:31:39 --> Model Class Initialized
INFO - 2016-02-21 12:31:39 --> Model Class Initialized
INFO - 2016-02-21 12:31:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:39 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:39 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:39 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-21 15:31:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-21 15:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 15:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:31:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:39 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:39 --> Total execution time: 1.1598
INFO - 2016-02-21 12:31:48 --> Config Class Initialized
INFO - 2016-02-21 12:31:48 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:48 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:48 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:48 --> URI Class Initialized
INFO - 2016-02-21 12:31:48 --> Router Class Initialized
INFO - 2016-02-21 12:31:48 --> Output Class Initialized
INFO - 2016-02-21 12:31:48 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:48 --> Input Class Initialized
INFO - 2016-02-21 12:31:48 --> Language Class Initialized
INFO - 2016-02-21 12:31:48 --> Loader Class Initialized
INFO - 2016-02-21 12:31:48 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:48 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:48 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:48 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:48 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:49 --> Controller Class Initialized
INFO - 2016-02-21 12:31:49 --> Model Class Initialized
INFO - 2016-02-21 12:31:49 --> Model Class Initialized
INFO - 2016-02-21 12:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:49 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:49 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:49 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:49 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:49 --> Total execution time: 1.1666
INFO - 2016-02-21 12:31:51 --> Config Class Initialized
INFO - 2016-02-21 12:31:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:51 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:51 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:51 --> URI Class Initialized
INFO - 2016-02-21 12:31:51 --> Router Class Initialized
INFO - 2016-02-21 12:31:51 --> Output Class Initialized
INFO - 2016-02-21 12:31:51 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:51 --> Input Class Initialized
INFO - 2016-02-21 12:31:51 --> Language Class Initialized
INFO - 2016-02-21 12:31:51 --> Loader Class Initialized
INFO - 2016-02-21 12:31:51 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:51 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:51 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:51 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:51 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:52 --> Controller Class Initialized
INFO - 2016-02-21 12:31:52 --> Model Class Initialized
INFO - 2016-02-21 12:31:52 --> Model Class Initialized
INFO - 2016-02-21 12:31:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:52 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:52 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:52 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-21 15:31:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-21 15:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-21 15:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:31:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:52 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:52 --> Total execution time: 1.1700
INFO - 2016-02-21 12:31:53 --> Config Class Initialized
INFO - 2016-02-21 12:31:53 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:31:53 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:31:53 --> Utf8 Class Initialized
INFO - 2016-02-21 12:31:53 --> URI Class Initialized
INFO - 2016-02-21 12:31:53 --> Router Class Initialized
INFO - 2016-02-21 12:31:53 --> Output Class Initialized
INFO - 2016-02-21 12:31:53 --> Security Class Initialized
DEBUG - 2016-02-21 12:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:31:53 --> Input Class Initialized
INFO - 2016-02-21 12:31:53 --> Language Class Initialized
INFO - 2016-02-21 12:31:53 --> Loader Class Initialized
INFO - 2016-02-21 12:31:53 --> Helper loaded: url_helper
INFO - 2016-02-21 12:31:53 --> Helper loaded: file_helper
INFO - 2016-02-21 12:31:53 --> Helper loaded: date_helper
INFO - 2016-02-21 12:31:53 --> Helper loaded: form_helper
INFO - 2016-02-21 12:31:53 --> Database Driver Class Initialized
INFO - 2016-02-21 12:31:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:31:54 --> Controller Class Initialized
INFO - 2016-02-21 12:31:54 --> Model Class Initialized
INFO - 2016-02-21 12:31:54 --> Model Class Initialized
INFO - 2016-02-21 12:31:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:31:54 --> Pagination Class Initialized
INFO - 2016-02-21 12:31:54 --> Helper loaded: text_helper
INFO - 2016-02-21 12:31:54 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-21 15:31:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:31:54 --> Final output sent to browser
DEBUG - 2016-02-21 15:31:54 --> Total execution time: 1.1239
INFO - 2016-02-21 12:45:39 --> Config Class Initialized
INFO - 2016-02-21 12:45:39 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:45:39 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:45:39 --> Utf8 Class Initialized
INFO - 2016-02-21 12:45:39 --> URI Class Initialized
INFO - 2016-02-21 12:45:39 --> Router Class Initialized
INFO - 2016-02-21 12:45:39 --> Output Class Initialized
INFO - 2016-02-21 12:45:39 --> Security Class Initialized
DEBUG - 2016-02-21 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:45:39 --> Input Class Initialized
INFO - 2016-02-21 12:45:39 --> Language Class Initialized
INFO - 2016-02-21 12:45:39 --> Loader Class Initialized
INFO - 2016-02-21 12:45:39 --> Helper loaded: url_helper
INFO - 2016-02-21 12:45:39 --> Helper loaded: file_helper
INFO - 2016-02-21 12:45:39 --> Helper loaded: date_helper
INFO - 2016-02-21 12:45:39 --> Helper loaded: form_helper
INFO - 2016-02-21 12:45:39 --> Database Driver Class Initialized
INFO - 2016-02-21 12:45:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:45:40 --> Controller Class Initialized
INFO - 2016-02-21 12:45:40 --> Model Class Initialized
INFO - 2016-02-21 12:45:40 --> Model Class Initialized
INFO - 2016-02-21 12:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:45:40 --> Pagination Class Initialized
INFO - 2016-02-21 12:45:40 --> Helper loaded: text_helper
INFO - 2016-02-21 12:45:40 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:45:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:45:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:45:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-21 15:45:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:45:40 --> Final output sent to browser
DEBUG - 2016-02-21 15:45:40 --> Total execution time: 1.1593
INFO - 2016-02-21 12:45:48 --> Config Class Initialized
INFO - 2016-02-21 12:45:48 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:45:48 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:45:48 --> Utf8 Class Initialized
INFO - 2016-02-21 12:45:48 --> URI Class Initialized
INFO - 2016-02-21 12:45:48 --> Router Class Initialized
INFO - 2016-02-21 12:45:48 --> Output Class Initialized
INFO - 2016-02-21 12:45:48 --> Security Class Initialized
DEBUG - 2016-02-21 12:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:45:48 --> Input Class Initialized
INFO - 2016-02-21 12:45:48 --> Language Class Initialized
INFO - 2016-02-21 12:45:48 --> Loader Class Initialized
INFO - 2016-02-21 12:45:48 --> Helper loaded: url_helper
INFO - 2016-02-21 12:45:48 --> Helper loaded: file_helper
INFO - 2016-02-21 12:45:48 --> Helper loaded: date_helper
INFO - 2016-02-21 12:45:48 --> Helper loaded: form_helper
INFO - 2016-02-21 12:45:48 --> Database Driver Class Initialized
INFO - 2016-02-21 12:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:45:49 --> Controller Class Initialized
INFO - 2016-02-21 12:45:49 --> Model Class Initialized
INFO - 2016-02-21 12:45:49 --> Model Class Initialized
INFO - 2016-02-21 12:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:45:49 --> Pagination Class Initialized
INFO - 2016-02-21 12:45:49 --> Helper loaded: text_helper
INFO - 2016-02-21 12:45:49 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:45:49 --> Final output sent to browser
DEBUG - 2016-02-21 15:45:49 --> Total execution time: 1.1124
INFO - 2016-02-21 12:46:53 --> Config Class Initialized
INFO - 2016-02-21 12:46:53 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:46:53 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:46:53 --> Utf8 Class Initialized
INFO - 2016-02-21 12:46:53 --> URI Class Initialized
INFO - 2016-02-21 12:46:53 --> Router Class Initialized
INFO - 2016-02-21 12:46:53 --> Output Class Initialized
INFO - 2016-02-21 12:46:53 --> Security Class Initialized
DEBUG - 2016-02-21 12:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:46:53 --> Input Class Initialized
INFO - 2016-02-21 12:46:53 --> Language Class Initialized
INFO - 2016-02-21 12:46:53 --> Loader Class Initialized
INFO - 2016-02-21 12:46:53 --> Helper loaded: url_helper
INFO - 2016-02-21 12:46:53 --> Helper loaded: file_helper
INFO - 2016-02-21 12:46:53 --> Helper loaded: date_helper
INFO - 2016-02-21 12:46:53 --> Helper loaded: form_helper
INFO - 2016-02-21 12:46:53 --> Database Driver Class Initialized
INFO - 2016-02-21 12:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:46:54 --> Controller Class Initialized
INFO - 2016-02-21 12:46:54 --> Model Class Initialized
INFO - 2016-02-21 12:46:54 --> Model Class Initialized
INFO - 2016-02-21 12:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:46:54 --> Pagination Class Initialized
INFO - 2016-02-21 12:46:54 --> Helper loaded: text_helper
INFO - 2016-02-21 12:46:54 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:46:54 --> Final output sent to browser
DEBUG - 2016-02-21 15:46:54 --> Total execution time: 1.1381
INFO - 2016-02-21 12:48:15 --> Config Class Initialized
INFO - 2016-02-21 12:48:15 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:48:15 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:48:15 --> Utf8 Class Initialized
INFO - 2016-02-21 12:48:15 --> URI Class Initialized
INFO - 2016-02-21 12:48:15 --> Router Class Initialized
INFO - 2016-02-21 12:48:15 --> Output Class Initialized
INFO - 2016-02-21 12:48:15 --> Security Class Initialized
DEBUG - 2016-02-21 12:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:48:15 --> Input Class Initialized
INFO - 2016-02-21 12:48:15 --> Language Class Initialized
INFO - 2016-02-21 12:48:15 --> Loader Class Initialized
INFO - 2016-02-21 12:48:15 --> Helper loaded: url_helper
INFO - 2016-02-21 12:48:15 --> Helper loaded: file_helper
INFO - 2016-02-21 12:48:15 --> Helper loaded: date_helper
INFO - 2016-02-21 12:48:15 --> Helper loaded: form_helper
INFO - 2016-02-21 12:48:15 --> Database Driver Class Initialized
INFO - 2016-02-21 12:48:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:48:16 --> Controller Class Initialized
INFO - 2016-02-21 12:48:16 --> Model Class Initialized
INFO - 2016-02-21 12:48:16 --> Model Class Initialized
INFO - 2016-02-21 12:48:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:48:16 --> Pagination Class Initialized
INFO - 2016-02-21 12:48:16 --> Helper loaded: text_helper
INFO - 2016-02-21 12:48:16 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:48:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:48:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:48:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:48:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:48:16 --> Final output sent to browser
DEBUG - 2016-02-21 15:48:16 --> Total execution time: 1.1635
INFO - 2016-02-21 12:48:30 --> Config Class Initialized
INFO - 2016-02-21 12:48:30 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:48:30 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:48:30 --> Utf8 Class Initialized
INFO - 2016-02-21 12:48:30 --> URI Class Initialized
INFO - 2016-02-21 12:48:30 --> Router Class Initialized
INFO - 2016-02-21 12:48:30 --> Output Class Initialized
INFO - 2016-02-21 12:48:30 --> Security Class Initialized
DEBUG - 2016-02-21 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:48:30 --> Input Class Initialized
INFO - 2016-02-21 12:48:30 --> Language Class Initialized
INFO - 2016-02-21 12:48:30 --> Loader Class Initialized
INFO - 2016-02-21 12:48:30 --> Helper loaded: url_helper
INFO - 2016-02-21 12:48:30 --> Helper loaded: file_helper
INFO - 2016-02-21 12:48:30 --> Helper loaded: date_helper
INFO - 2016-02-21 12:48:30 --> Helper loaded: form_helper
INFO - 2016-02-21 12:48:30 --> Database Driver Class Initialized
INFO - 2016-02-21 12:48:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:48:31 --> Controller Class Initialized
INFO - 2016-02-21 12:48:31 --> Model Class Initialized
INFO - 2016-02-21 12:48:31 --> Model Class Initialized
INFO - 2016-02-21 12:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:48:31 --> Pagination Class Initialized
INFO - 2016-02-21 12:48:31 --> Helper loaded: text_helper
INFO - 2016-02-21 12:48:31 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-21 15:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-21 15:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:48:31 --> Final output sent to browser
DEBUG - 2016-02-21 15:48:31 --> Total execution time: 1.1110
INFO - 2016-02-21 12:48:39 --> Config Class Initialized
INFO - 2016-02-21 12:48:39 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:48:39 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:48:39 --> Utf8 Class Initialized
INFO - 2016-02-21 12:48:39 --> URI Class Initialized
INFO - 2016-02-21 12:48:39 --> Router Class Initialized
INFO - 2016-02-21 12:48:39 --> Output Class Initialized
INFO - 2016-02-21 12:48:39 --> Security Class Initialized
DEBUG - 2016-02-21 12:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:48:39 --> Input Class Initialized
INFO - 2016-02-21 12:48:39 --> Language Class Initialized
INFO - 2016-02-21 12:48:39 --> Loader Class Initialized
INFO - 2016-02-21 12:48:39 --> Helper loaded: url_helper
INFO - 2016-02-21 12:48:39 --> Helper loaded: file_helper
INFO - 2016-02-21 12:48:39 --> Helper loaded: date_helper
INFO - 2016-02-21 12:48:39 --> Helper loaded: form_helper
INFO - 2016-02-21 12:48:39 --> Database Driver Class Initialized
INFO - 2016-02-21 12:48:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:48:40 --> Controller Class Initialized
INFO - 2016-02-21 12:48:40 --> Model Class Initialized
INFO - 2016-02-21 12:48:40 --> Model Class Initialized
INFO - 2016-02-21 12:48:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:48:40 --> Pagination Class Initialized
INFO - 2016-02-21 12:48:40 --> Helper loaded: text_helper
INFO - 2016-02-21 12:48:40 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:48:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:48:40 --> Final output sent to browser
DEBUG - 2016-02-21 15:48:40 --> Total execution time: 1.1316
INFO - 2016-02-21 12:51:51 --> Config Class Initialized
INFO - 2016-02-21 12:51:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:51:51 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:51:51 --> Utf8 Class Initialized
INFO - 2016-02-21 12:51:51 --> URI Class Initialized
INFO - 2016-02-21 12:51:51 --> Router Class Initialized
INFO - 2016-02-21 12:51:51 --> Output Class Initialized
INFO - 2016-02-21 12:51:51 --> Security Class Initialized
DEBUG - 2016-02-21 12:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:51:51 --> Input Class Initialized
INFO - 2016-02-21 12:51:51 --> Language Class Initialized
INFO - 2016-02-21 12:51:51 --> Loader Class Initialized
INFO - 2016-02-21 12:51:51 --> Helper loaded: url_helper
INFO - 2016-02-21 12:51:51 --> Helper loaded: file_helper
INFO - 2016-02-21 12:51:51 --> Helper loaded: date_helper
INFO - 2016-02-21 12:51:51 --> Helper loaded: form_helper
INFO - 2016-02-21 12:51:51 --> Database Driver Class Initialized
INFO - 2016-02-21 12:51:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:51:52 --> Controller Class Initialized
INFO - 2016-02-21 12:51:52 --> Model Class Initialized
INFO - 2016-02-21 12:51:52 --> Model Class Initialized
INFO - 2016-02-21 12:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:51:52 --> Pagination Class Initialized
INFO - 2016-02-21 12:51:52 --> Helper loaded: text_helper
INFO - 2016-02-21 12:51:52 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:51:52 --> Final output sent to browser
DEBUG - 2016-02-21 15:51:52 --> Total execution time: 1.1684
INFO - 2016-02-21 12:52:46 --> Config Class Initialized
INFO - 2016-02-21 12:52:46 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:52:46 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:52:46 --> Utf8 Class Initialized
INFO - 2016-02-21 12:52:46 --> URI Class Initialized
INFO - 2016-02-21 12:52:46 --> Router Class Initialized
INFO - 2016-02-21 12:52:46 --> Output Class Initialized
INFO - 2016-02-21 12:52:47 --> Security Class Initialized
DEBUG - 2016-02-21 12:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:52:47 --> Input Class Initialized
INFO - 2016-02-21 12:52:47 --> Language Class Initialized
INFO - 2016-02-21 12:52:47 --> Loader Class Initialized
INFO - 2016-02-21 12:52:47 --> Helper loaded: url_helper
INFO - 2016-02-21 12:52:47 --> Helper loaded: file_helper
INFO - 2016-02-21 12:52:47 --> Helper loaded: date_helper
INFO - 2016-02-21 12:52:47 --> Helper loaded: form_helper
INFO - 2016-02-21 12:52:47 --> Database Driver Class Initialized
INFO - 2016-02-21 12:52:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:52:48 --> Controller Class Initialized
INFO - 2016-02-21 12:52:48 --> Model Class Initialized
INFO - 2016-02-21 12:52:48 --> Model Class Initialized
INFO - 2016-02-21 12:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:52:48 --> Pagination Class Initialized
INFO - 2016-02-21 12:52:48 --> Helper loaded: text_helper
INFO - 2016-02-21 12:52:48 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:52:48 --> Final output sent to browser
DEBUG - 2016-02-21 15:52:48 --> Total execution time: 1.1884
INFO - 2016-02-21 12:54:21 --> Config Class Initialized
INFO - 2016-02-21 12:54:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:54:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:54:21 --> Utf8 Class Initialized
INFO - 2016-02-21 12:54:21 --> URI Class Initialized
INFO - 2016-02-21 12:54:21 --> Router Class Initialized
INFO - 2016-02-21 12:54:21 --> Output Class Initialized
INFO - 2016-02-21 12:54:21 --> Security Class Initialized
DEBUG - 2016-02-21 12:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:54:21 --> Input Class Initialized
INFO - 2016-02-21 12:54:21 --> Language Class Initialized
INFO - 2016-02-21 12:54:21 --> Loader Class Initialized
INFO - 2016-02-21 12:54:21 --> Helper loaded: url_helper
INFO - 2016-02-21 12:54:21 --> Helper loaded: file_helper
INFO - 2016-02-21 12:54:21 --> Helper loaded: date_helper
INFO - 2016-02-21 12:54:21 --> Helper loaded: form_helper
INFO - 2016-02-21 12:54:21 --> Database Driver Class Initialized
INFO - 2016-02-21 12:54:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:54:22 --> Controller Class Initialized
INFO - 2016-02-21 12:54:22 --> Model Class Initialized
INFO - 2016-02-21 12:54:22 --> Model Class Initialized
INFO - 2016-02-21 12:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:54:22 --> Pagination Class Initialized
INFO - 2016-02-21 12:54:22 --> Helper loaded: text_helper
INFO - 2016-02-21 12:54:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:54:22 --> Final output sent to browser
DEBUG - 2016-02-21 15:54:22 --> Total execution time: 1.1657
INFO - 2016-02-21 12:54:46 --> Config Class Initialized
INFO - 2016-02-21 12:54:46 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:54:46 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:54:46 --> Utf8 Class Initialized
INFO - 2016-02-21 12:54:46 --> URI Class Initialized
INFO - 2016-02-21 12:54:46 --> Router Class Initialized
INFO - 2016-02-21 12:54:46 --> Output Class Initialized
INFO - 2016-02-21 12:54:46 --> Security Class Initialized
DEBUG - 2016-02-21 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:54:46 --> Input Class Initialized
INFO - 2016-02-21 12:54:46 --> Language Class Initialized
INFO - 2016-02-21 12:54:46 --> Loader Class Initialized
INFO - 2016-02-21 12:54:46 --> Helper loaded: url_helper
INFO - 2016-02-21 12:54:46 --> Helper loaded: file_helper
INFO - 2016-02-21 12:54:46 --> Helper loaded: date_helper
INFO - 2016-02-21 12:54:46 --> Helper loaded: form_helper
INFO - 2016-02-21 12:54:46 --> Database Driver Class Initialized
INFO - 2016-02-21 12:54:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:54:47 --> Controller Class Initialized
INFO - 2016-02-21 12:54:47 --> Model Class Initialized
INFO - 2016-02-21 12:54:47 --> Model Class Initialized
INFO - 2016-02-21 12:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:54:47 --> Pagination Class Initialized
INFO - 2016-02-21 12:54:47 --> Helper loaded: text_helper
INFO - 2016-02-21 12:54:47 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:54:47 --> Final output sent to browser
DEBUG - 2016-02-21 15:54:47 --> Total execution time: 1.1293
INFO - 2016-02-21 12:54:51 --> Config Class Initialized
INFO - 2016-02-21 12:54:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:54:51 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:54:51 --> Utf8 Class Initialized
INFO - 2016-02-21 12:54:51 --> URI Class Initialized
INFO - 2016-02-21 12:54:51 --> Router Class Initialized
INFO - 2016-02-21 12:54:51 --> Output Class Initialized
INFO - 2016-02-21 12:54:51 --> Security Class Initialized
DEBUG - 2016-02-21 12:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:54:51 --> Input Class Initialized
INFO - 2016-02-21 12:54:51 --> Language Class Initialized
INFO - 2016-02-21 12:54:51 --> Loader Class Initialized
INFO - 2016-02-21 12:54:51 --> Helper loaded: url_helper
INFO - 2016-02-21 12:54:51 --> Helper loaded: file_helper
INFO - 2016-02-21 12:54:51 --> Helper loaded: date_helper
INFO - 2016-02-21 12:54:51 --> Helper loaded: form_helper
INFO - 2016-02-21 12:54:51 --> Database Driver Class Initialized
INFO - 2016-02-21 12:54:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:54:52 --> Controller Class Initialized
INFO - 2016-02-21 12:54:52 --> Model Class Initialized
INFO - 2016-02-21 12:54:52 --> Model Class Initialized
INFO - 2016-02-21 12:54:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:54:52 --> Pagination Class Initialized
INFO - 2016-02-21 12:54:52 --> Helper loaded: text_helper
INFO - 2016-02-21 12:54:52 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:54:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:54:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:54:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:54:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:54:52 --> Final output sent to browser
DEBUG - 2016-02-21 15:54:52 --> Total execution time: 1.1490
INFO - 2016-02-21 12:55:06 --> Config Class Initialized
INFO - 2016-02-21 12:55:06 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:55:06 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:55:06 --> Utf8 Class Initialized
INFO - 2016-02-21 12:55:06 --> URI Class Initialized
INFO - 2016-02-21 12:55:06 --> Router Class Initialized
INFO - 2016-02-21 12:55:06 --> Output Class Initialized
INFO - 2016-02-21 12:55:06 --> Security Class Initialized
DEBUG - 2016-02-21 12:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:55:06 --> Input Class Initialized
INFO - 2016-02-21 12:55:06 --> Language Class Initialized
INFO - 2016-02-21 12:55:06 --> Loader Class Initialized
INFO - 2016-02-21 12:55:06 --> Helper loaded: url_helper
INFO - 2016-02-21 12:55:06 --> Helper loaded: file_helper
INFO - 2016-02-21 12:55:06 --> Helper loaded: date_helper
INFO - 2016-02-21 12:55:06 --> Helper loaded: form_helper
INFO - 2016-02-21 12:55:06 --> Database Driver Class Initialized
INFO - 2016-02-21 12:55:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:55:07 --> Controller Class Initialized
INFO - 2016-02-21 12:55:07 --> Model Class Initialized
INFO - 2016-02-21 12:55:07 --> Model Class Initialized
INFO - 2016-02-21 12:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:55:07 --> Pagination Class Initialized
INFO - 2016-02-21 12:55:07 --> Helper loaded: text_helper
INFO - 2016-02-21 12:55:07 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:55:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:55:07 --> Final output sent to browser
DEBUG - 2016-02-21 15:55:07 --> Total execution time: 1.1541
INFO - 2016-02-21 12:55:21 --> Config Class Initialized
INFO - 2016-02-21 12:55:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:55:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:55:21 --> Utf8 Class Initialized
INFO - 2016-02-21 12:55:21 --> URI Class Initialized
INFO - 2016-02-21 12:55:21 --> Router Class Initialized
INFO - 2016-02-21 12:55:21 --> Output Class Initialized
INFO - 2016-02-21 12:55:21 --> Security Class Initialized
DEBUG - 2016-02-21 12:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:55:21 --> Input Class Initialized
INFO - 2016-02-21 12:55:21 --> Language Class Initialized
INFO - 2016-02-21 12:55:21 --> Loader Class Initialized
INFO - 2016-02-21 12:55:21 --> Helper loaded: url_helper
INFO - 2016-02-21 12:55:21 --> Helper loaded: file_helper
INFO - 2016-02-21 12:55:21 --> Helper loaded: date_helper
INFO - 2016-02-21 12:55:21 --> Helper loaded: form_helper
INFO - 2016-02-21 12:55:21 --> Database Driver Class Initialized
INFO - 2016-02-21 12:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:55:22 --> Controller Class Initialized
INFO - 2016-02-21 12:55:22 --> Model Class Initialized
INFO - 2016-02-21 12:55:22 --> Model Class Initialized
INFO - 2016-02-21 12:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:55:22 --> Pagination Class Initialized
INFO - 2016-02-21 12:55:22 --> Helper loaded: text_helper
INFO - 2016-02-21 12:55:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:55:22 --> Final output sent to browser
DEBUG - 2016-02-21 15:55:22 --> Total execution time: 1.1753
INFO - 2016-02-21 12:56:43 --> Config Class Initialized
INFO - 2016-02-21 12:56:43 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:56:43 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:56:43 --> Utf8 Class Initialized
INFO - 2016-02-21 12:56:43 --> URI Class Initialized
INFO - 2016-02-21 12:56:43 --> Router Class Initialized
INFO - 2016-02-21 12:56:43 --> Output Class Initialized
INFO - 2016-02-21 12:56:43 --> Security Class Initialized
DEBUG - 2016-02-21 12:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:56:43 --> Input Class Initialized
INFO - 2016-02-21 12:56:43 --> Language Class Initialized
INFO - 2016-02-21 12:56:43 --> Loader Class Initialized
INFO - 2016-02-21 12:56:43 --> Helper loaded: url_helper
INFO - 2016-02-21 12:56:43 --> Helper loaded: file_helper
INFO - 2016-02-21 12:56:43 --> Helper loaded: date_helper
INFO - 2016-02-21 12:56:43 --> Helper loaded: form_helper
INFO - 2016-02-21 12:56:43 --> Database Driver Class Initialized
INFO - 2016-02-21 12:56:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:56:44 --> Controller Class Initialized
INFO - 2016-02-21 12:56:44 --> Model Class Initialized
INFO - 2016-02-21 12:56:44 --> Model Class Initialized
INFO - 2016-02-21 12:56:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:56:44 --> Pagination Class Initialized
INFO - 2016-02-21 12:56:44 --> Helper loaded: text_helper
INFO - 2016-02-21 12:56:44 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:56:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:56:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:56:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:56:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:56:44 --> Final output sent to browser
DEBUG - 2016-02-21 15:56:44 --> Total execution time: 1.1727
INFO - 2016-02-21 12:57:21 --> Config Class Initialized
INFO - 2016-02-21 12:57:21 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:57:21 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:57:21 --> Utf8 Class Initialized
INFO - 2016-02-21 12:57:21 --> URI Class Initialized
INFO - 2016-02-21 12:57:21 --> Router Class Initialized
INFO - 2016-02-21 12:57:21 --> Output Class Initialized
INFO - 2016-02-21 12:57:21 --> Security Class Initialized
DEBUG - 2016-02-21 12:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:57:21 --> Input Class Initialized
INFO - 2016-02-21 12:57:21 --> Language Class Initialized
INFO - 2016-02-21 12:57:21 --> Loader Class Initialized
INFO - 2016-02-21 12:57:21 --> Helper loaded: url_helper
INFO - 2016-02-21 12:57:21 --> Helper loaded: file_helper
INFO - 2016-02-21 12:57:21 --> Helper loaded: date_helper
INFO - 2016-02-21 12:57:21 --> Helper loaded: form_helper
INFO - 2016-02-21 12:57:21 --> Database Driver Class Initialized
INFO - 2016-02-21 12:57:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:57:22 --> Controller Class Initialized
INFO - 2016-02-21 12:57:22 --> Model Class Initialized
INFO - 2016-02-21 12:57:22 --> Model Class Initialized
INFO - 2016-02-21 12:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:57:22 --> Pagination Class Initialized
INFO - 2016-02-21 12:57:22 --> Helper loaded: text_helper
INFO - 2016-02-21 12:57:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:57:22 --> Final output sent to browser
DEBUG - 2016-02-21 15:57:22 --> Total execution time: 1.1389
INFO - 2016-02-21 12:57:48 --> Config Class Initialized
INFO - 2016-02-21 12:57:48 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:57:48 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:57:48 --> Utf8 Class Initialized
INFO - 2016-02-21 12:57:48 --> URI Class Initialized
INFO - 2016-02-21 12:57:48 --> Router Class Initialized
INFO - 2016-02-21 12:57:48 --> Output Class Initialized
INFO - 2016-02-21 12:57:48 --> Security Class Initialized
DEBUG - 2016-02-21 12:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:57:48 --> Input Class Initialized
INFO - 2016-02-21 12:57:48 --> Language Class Initialized
INFO - 2016-02-21 12:57:48 --> Loader Class Initialized
INFO - 2016-02-21 12:57:48 --> Helper loaded: url_helper
INFO - 2016-02-21 12:57:48 --> Helper loaded: file_helper
INFO - 2016-02-21 12:57:48 --> Helper loaded: date_helper
INFO - 2016-02-21 12:57:48 --> Helper loaded: form_helper
INFO - 2016-02-21 12:57:48 --> Database Driver Class Initialized
INFO - 2016-02-21 12:57:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:57:49 --> Controller Class Initialized
INFO - 2016-02-21 12:57:49 --> Model Class Initialized
INFO - 2016-02-21 12:57:49 --> Model Class Initialized
INFO - 2016-02-21 12:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:57:49 --> Pagination Class Initialized
INFO - 2016-02-21 12:57:49 --> Helper loaded: text_helper
INFO - 2016-02-21 12:57:49 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:57:49 --> Final output sent to browser
DEBUG - 2016-02-21 15:57:49 --> Total execution time: 1.1619
INFO - 2016-02-21 12:58:09 --> Config Class Initialized
INFO - 2016-02-21 12:58:09 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:58:09 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:58:09 --> Utf8 Class Initialized
INFO - 2016-02-21 12:58:09 --> URI Class Initialized
INFO - 2016-02-21 12:58:09 --> Router Class Initialized
INFO - 2016-02-21 12:58:09 --> Output Class Initialized
INFO - 2016-02-21 12:58:09 --> Security Class Initialized
DEBUG - 2016-02-21 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:58:09 --> Input Class Initialized
INFO - 2016-02-21 12:58:09 --> Language Class Initialized
INFO - 2016-02-21 12:58:09 --> Loader Class Initialized
INFO - 2016-02-21 12:58:09 --> Helper loaded: url_helper
INFO - 2016-02-21 12:58:09 --> Helper loaded: file_helper
INFO - 2016-02-21 12:58:09 --> Helper loaded: date_helper
INFO - 2016-02-21 12:58:09 --> Helper loaded: form_helper
INFO - 2016-02-21 12:58:09 --> Database Driver Class Initialized
INFO - 2016-02-21 12:58:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:58:10 --> Controller Class Initialized
INFO - 2016-02-21 12:58:10 --> Model Class Initialized
INFO - 2016-02-21 12:58:10 --> Model Class Initialized
INFO - 2016-02-21 12:58:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:58:10 --> Pagination Class Initialized
INFO - 2016-02-21 12:58:10 --> Helper loaded: text_helper
INFO - 2016-02-21 12:58:10 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:58:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:58:10 --> Final output sent to browser
DEBUG - 2016-02-21 15:58:10 --> Total execution time: 1.1632
INFO - 2016-02-21 12:58:20 --> Config Class Initialized
INFO - 2016-02-21 12:58:20 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:58:20 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:58:20 --> Utf8 Class Initialized
INFO - 2016-02-21 12:58:20 --> URI Class Initialized
INFO - 2016-02-21 12:58:20 --> Router Class Initialized
INFO - 2016-02-21 12:58:20 --> Output Class Initialized
INFO - 2016-02-21 12:58:20 --> Security Class Initialized
DEBUG - 2016-02-21 12:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:58:20 --> Input Class Initialized
INFO - 2016-02-21 12:58:20 --> Language Class Initialized
INFO - 2016-02-21 12:58:20 --> Loader Class Initialized
INFO - 2016-02-21 12:58:20 --> Helper loaded: url_helper
INFO - 2016-02-21 12:58:20 --> Helper loaded: file_helper
INFO - 2016-02-21 12:58:20 --> Helper loaded: date_helper
INFO - 2016-02-21 12:58:20 --> Helper loaded: form_helper
INFO - 2016-02-21 12:58:20 --> Database Driver Class Initialized
INFO - 2016-02-21 12:58:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:58:22 --> Controller Class Initialized
INFO - 2016-02-21 12:58:22 --> Model Class Initialized
INFO - 2016-02-21 12:58:22 --> Model Class Initialized
INFO - 2016-02-21 12:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:58:22 --> Pagination Class Initialized
INFO - 2016-02-21 12:58:22 --> Helper loaded: text_helper
INFO - 2016-02-21 12:58:22 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:58:22 --> Final output sent to browser
DEBUG - 2016-02-21 15:58:22 --> Total execution time: 1.1625
INFO - 2016-02-21 12:58:35 --> Config Class Initialized
INFO - 2016-02-21 12:58:35 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:58:35 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:58:35 --> Utf8 Class Initialized
INFO - 2016-02-21 12:58:35 --> URI Class Initialized
INFO - 2016-02-21 12:58:35 --> Router Class Initialized
INFO - 2016-02-21 12:58:35 --> Output Class Initialized
INFO - 2016-02-21 12:58:35 --> Security Class Initialized
DEBUG - 2016-02-21 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:58:35 --> Input Class Initialized
INFO - 2016-02-21 12:58:35 --> Language Class Initialized
INFO - 2016-02-21 12:58:35 --> Loader Class Initialized
INFO - 2016-02-21 12:58:35 --> Helper loaded: url_helper
INFO - 2016-02-21 12:58:35 --> Helper loaded: file_helper
INFO - 2016-02-21 12:58:35 --> Helper loaded: date_helper
INFO - 2016-02-21 12:58:35 --> Helper loaded: form_helper
INFO - 2016-02-21 12:58:35 --> Database Driver Class Initialized
INFO - 2016-02-21 12:58:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:58:36 --> Controller Class Initialized
INFO - 2016-02-21 12:58:36 --> Model Class Initialized
INFO - 2016-02-21 12:58:36 --> Model Class Initialized
INFO - 2016-02-21 12:58:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:58:36 --> Pagination Class Initialized
INFO - 2016-02-21 12:58:36 --> Helper loaded: text_helper
INFO - 2016-02-21 12:58:36 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:58:36 --> Final output sent to browser
DEBUG - 2016-02-21 15:58:36 --> Total execution time: 1.1795
INFO - 2016-02-21 12:58:44 --> Config Class Initialized
INFO - 2016-02-21 12:58:44 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:58:44 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:58:44 --> Utf8 Class Initialized
INFO - 2016-02-21 12:58:44 --> URI Class Initialized
INFO - 2016-02-21 12:58:44 --> Router Class Initialized
INFO - 2016-02-21 12:58:44 --> Output Class Initialized
INFO - 2016-02-21 12:58:44 --> Security Class Initialized
DEBUG - 2016-02-21 12:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:58:44 --> Input Class Initialized
INFO - 2016-02-21 12:58:44 --> Language Class Initialized
INFO - 2016-02-21 12:58:44 --> Loader Class Initialized
INFO - 2016-02-21 12:58:44 --> Helper loaded: url_helper
INFO - 2016-02-21 12:58:44 --> Helper loaded: file_helper
INFO - 2016-02-21 12:58:44 --> Helper loaded: date_helper
INFO - 2016-02-21 12:58:44 --> Helper loaded: form_helper
INFO - 2016-02-21 12:58:44 --> Database Driver Class Initialized
INFO - 2016-02-21 12:58:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:58:45 --> Controller Class Initialized
INFO - 2016-02-21 12:58:45 --> Model Class Initialized
INFO - 2016-02-21 12:58:45 --> Model Class Initialized
INFO - 2016-02-21 12:58:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:58:45 --> Pagination Class Initialized
INFO - 2016-02-21 12:58:45 --> Helper loaded: text_helper
INFO - 2016-02-21 12:58:45 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:58:45 --> Final output sent to browser
DEBUG - 2016-02-21 15:58:45 --> Total execution time: 1.0987
INFO - 2016-02-21 12:58:50 --> Config Class Initialized
INFO - 2016-02-21 12:58:50 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:58:50 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:58:50 --> Utf8 Class Initialized
INFO - 2016-02-21 12:58:50 --> URI Class Initialized
INFO - 2016-02-21 12:58:50 --> Router Class Initialized
INFO - 2016-02-21 12:58:50 --> Output Class Initialized
INFO - 2016-02-21 12:58:50 --> Security Class Initialized
DEBUG - 2016-02-21 12:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:58:50 --> Input Class Initialized
INFO - 2016-02-21 12:58:50 --> Language Class Initialized
INFO - 2016-02-21 12:58:50 --> Loader Class Initialized
INFO - 2016-02-21 12:58:50 --> Helper loaded: url_helper
INFO - 2016-02-21 12:58:50 --> Helper loaded: file_helper
INFO - 2016-02-21 12:58:50 --> Helper loaded: date_helper
INFO - 2016-02-21 12:58:50 --> Helper loaded: form_helper
INFO - 2016-02-21 12:58:50 --> Database Driver Class Initialized
INFO - 2016-02-21 12:58:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:58:51 --> Controller Class Initialized
INFO - 2016-02-21 12:58:51 --> Model Class Initialized
INFO - 2016-02-21 12:58:51 --> Model Class Initialized
INFO - 2016-02-21 12:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:58:51 --> Pagination Class Initialized
INFO - 2016-02-21 12:58:51 --> Helper loaded: text_helper
INFO - 2016-02-21 12:58:51 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:58:51 --> Final output sent to browser
DEBUG - 2016-02-21 15:58:51 --> Total execution time: 1.1551
INFO - 2016-02-21 12:59:00 --> Config Class Initialized
INFO - 2016-02-21 12:59:00 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:59:00 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:59:00 --> Utf8 Class Initialized
INFO - 2016-02-21 12:59:00 --> URI Class Initialized
INFO - 2016-02-21 12:59:00 --> Router Class Initialized
INFO - 2016-02-21 12:59:00 --> Output Class Initialized
INFO - 2016-02-21 12:59:00 --> Security Class Initialized
DEBUG - 2016-02-21 12:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:59:00 --> Input Class Initialized
INFO - 2016-02-21 12:59:00 --> Language Class Initialized
INFO - 2016-02-21 12:59:00 --> Loader Class Initialized
INFO - 2016-02-21 12:59:00 --> Helper loaded: url_helper
INFO - 2016-02-21 12:59:00 --> Helper loaded: file_helper
INFO - 2016-02-21 12:59:00 --> Helper loaded: date_helper
INFO - 2016-02-21 12:59:00 --> Helper loaded: form_helper
INFO - 2016-02-21 12:59:00 --> Database Driver Class Initialized
INFO - 2016-02-21 12:59:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:59:01 --> Controller Class Initialized
INFO - 2016-02-21 12:59:01 --> Model Class Initialized
INFO - 2016-02-21 12:59:01 --> Model Class Initialized
INFO - 2016-02-21 12:59:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:59:01 --> Pagination Class Initialized
INFO - 2016-02-21 12:59:01 --> Helper loaded: text_helper
INFO - 2016-02-21 12:59:01 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:59:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:59:01 --> Final output sent to browser
DEBUG - 2016-02-21 15:59:01 --> Total execution time: 1.1745
INFO - 2016-02-21 12:59:11 --> Config Class Initialized
INFO - 2016-02-21 12:59:11 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:59:11 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:59:11 --> Utf8 Class Initialized
INFO - 2016-02-21 12:59:11 --> URI Class Initialized
INFO - 2016-02-21 12:59:11 --> Router Class Initialized
INFO - 2016-02-21 12:59:11 --> Output Class Initialized
INFO - 2016-02-21 12:59:11 --> Security Class Initialized
DEBUG - 2016-02-21 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:59:11 --> Input Class Initialized
INFO - 2016-02-21 12:59:11 --> Language Class Initialized
INFO - 2016-02-21 12:59:11 --> Loader Class Initialized
INFO - 2016-02-21 12:59:11 --> Helper loaded: url_helper
INFO - 2016-02-21 12:59:11 --> Helper loaded: file_helper
INFO - 2016-02-21 12:59:11 --> Helper loaded: date_helper
INFO - 2016-02-21 12:59:11 --> Helper loaded: form_helper
INFO - 2016-02-21 12:59:11 --> Database Driver Class Initialized
INFO - 2016-02-21 12:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:59:12 --> Controller Class Initialized
INFO - 2016-02-21 12:59:12 --> Model Class Initialized
INFO - 2016-02-21 12:59:12 --> Model Class Initialized
INFO - 2016-02-21 12:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:59:12 --> Pagination Class Initialized
INFO - 2016-02-21 12:59:12 --> Helper loaded: text_helper
INFO - 2016-02-21 12:59:12 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:59:12 --> Final output sent to browser
DEBUG - 2016-02-21 15:59:12 --> Total execution time: 1.1522
INFO - 2016-02-21 12:59:28 --> Config Class Initialized
INFO - 2016-02-21 12:59:28 --> Hooks Class Initialized
DEBUG - 2016-02-21 12:59:28 --> UTF-8 Support Enabled
INFO - 2016-02-21 12:59:28 --> Utf8 Class Initialized
INFO - 2016-02-21 12:59:28 --> URI Class Initialized
INFO - 2016-02-21 12:59:28 --> Router Class Initialized
INFO - 2016-02-21 12:59:28 --> Output Class Initialized
INFO - 2016-02-21 12:59:28 --> Security Class Initialized
DEBUG - 2016-02-21 12:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 12:59:28 --> Input Class Initialized
INFO - 2016-02-21 12:59:28 --> Language Class Initialized
INFO - 2016-02-21 12:59:28 --> Loader Class Initialized
INFO - 2016-02-21 12:59:28 --> Helper loaded: url_helper
INFO - 2016-02-21 12:59:28 --> Helper loaded: file_helper
INFO - 2016-02-21 12:59:28 --> Helper loaded: date_helper
INFO - 2016-02-21 12:59:28 --> Helper loaded: form_helper
INFO - 2016-02-21 12:59:28 --> Database Driver Class Initialized
INFO - 2016-02-21 12:59:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 12:59:29 --> Controller Class Initialized
INFO - 2016-02-21 12:59:29 --> Model Class Initialized
INFO - 2016-02-21 12:59:29 --> Model Class Initialized
INFO - 2016-02-21 12:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 12:59:29 --> Pagination Class Initialized
INFO - 2016-02-21 12:59:29 --> Helper loaded: text_helper
INFO - 2016-02-21 12:59:29 --> Helper loaded: cookie_helper
INFO - 2016-02-21 15:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 15:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 15:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 15:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 15:59:29 --> Final output sent to browser
DEBUG - 2016-02-21 15:59:29 --> Total execution time: 1.1181
INFO - 2016-02-21 13:00:00 --> Config Class Initialized
INFO - 2016-02-21 13:00:00 --> Hooks Class Initialized
DEBUG - 2016-02-21 13:00:00 --> UTF-8 Support Enabled
INFO - 2016-02-21 13:00:00 --> Utf8 Class Initialized
INFO - 2016-02-21 13:00:00 --> URI Class Initialized
INFO - 2016-02-21 13:00:00 --> Router Class Initialized
INFO - 2016-02-21 13:00:00 --> Output Class Initialized
INFO - 2016-02-21 13:00:00 --> Security Class Initialized
DEBUG - 2016-02-21 13:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 13:00:00 --> Input Class Initialized
INFO - 2016-02-21 13:00:00 --> Language Class Initialized
INFO - 2016-02-21 13:00:00 --> Loader Class Initialized
INFO - 2016-02-21 13:00:00 --> Helper loaded: url_helper
INFO - 2016-02-21 13:00:00 --> Helper loaded: file_helper
INFO - 2016-02-21 13:00:00 --> Helper loaded: date_helper
INFO - 2016-02-21 13:00:00 --> Helper loaded: form_helper
INFO - 2016-02-21 13:00:00 --> Database Driver Class Initialized
INFO - 2016-02-21 13:00:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 13:00:01 --> Controller Class Initialized
INFO - 2016-02-21 13:00:01 --> Model Class Initialized
INFO - 2016-02-21 13:00:01 --> Model Class Initialized
INFO - 2016-02-21 13:00:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 13:00:01 --> Pagination Class Initialized
INFO - 2016-02-21 13:00:01 --> Helper loaded: text_helper
INFO - 2016-02-21 13:00:01 --> Helper loaded: cookie_helper
INFO - 2016-02-21 16:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 16:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 16:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 16:00:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 16:00:01 --> Final output sent to browser
DEBUG - 2016-02-21 16:00:01 --> Total execution time: 1.1284
INFO - 2016-02-21 13:00:07 --> Config Class Initialized
INFO - 2016-02-21 13:00:07 --> Hooks Class Initialized
DEBUG - 2016-02-21 13:00:07 --> UTF-8 Support Enabled
INFO - 2016-02-21 13:00:07 --> Utf8 Class Initialized
INFO - 2016-02-21 13:00:07 --> URI Class Initialized
INFO - 2016-02-21 13:00:07 --> Router Class Initialized
INFO - 2016-02-21 13:00:07 --> Output Class Initialized
INFO - 2016-02-21 13:00:07 --> Security Class Initialized
DEBUG - 2016-02-21 13:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 13:00:07 --> Input Class Initialized
INFO - 2016-02-21 13:00:07 --> Language Class Initialized
INFO - 2016-02-21 13:00:07 --> Loader Class Initialized
INFO - 2016-02-21 13:00:07 --> Helper loaded: url_helper
INFO - 2016-02-21 13:00:07 --> Helper loaded: file_helper
INFO - 2016-02-21 13:00:07 --> Helper loaded: date_helper
INFO - 2016-02-21 13:00:07 --> Helper loaded: form_helper
INFO - 2016-02-21 13:00:07 --> Database Driver Class Initialized
INFO - 2016-02-21 13:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 13:00:08 --> Controller Class Initialized
INFO - 2016-02-21 13:00:08 --> Model Class Initialized
INFO - 2016-02-21 13:00:08 --> Model Class Initialized
INFO - 2016-02-21 13:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 13:00:08 --> Pagination Class Initialized
INFO - 2016-02-21 13:00:08 --> Helper loaded: text_helper
INFO - 2016-02-21 13:00:08 --> Helper loaded: cookie_helper
INFO - 2016-02-21 16:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 16:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 16:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 16:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 16:00:08 --> Final output sent to browser
DEBUG - 2016-02-21 16:00:08 --> Total execution time: 1.1299
INFO - 2016-02-21 13:13:18 --> Config Class Initialized
INFO - 2016-02-21 13:13:18 --> Hooks Class Initialized
DEBUG - 2016-02-21 13:13:18 --> UTF-8 Support Enabled
INFO - 2016-02-21 13:13:18 --> Utf8 Class Initialized
INFO - 2016-02-21 13:13:18 --> URI Class Initialized
INFO - 2016-02-21 13:13:18 --> Router Class Initialized
INFO - 2016-02-21 13:13:18 --> Output Class Initialized
INFO - 2016-02-21 13:13:18 --> Security Class Initialized
DEBUG - 2016-02-21 13:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 13:13:18 --> Input Class Initialized
INFO - 2016-02-21 13:13:18 --> Language Class Initialized
INFO - 2016-02-21 13:13:18 --> Loader Class Initialized
INFO - 2016-02-21 13:13:18 --> Helper loaded: url_helper
INFO - 2016-02-21 13:13:18 --> Helper loaded: file_helper
INFO - 2016-02-21 13:13:18 --> Helper loaded: date_helper
INFO - 2016-02-21 13:13:18 --> Helper loaded: form_helper
INFO - 2016-02-21 13:13:18 --> Database Driver Class Initialized
INFO - 2016-02-21 13:13:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 13:13:19 --> Controller Class Initialized
INFO - 2016-02-21 13:13:19 --> Model Class Initialized
INFO - 2016-02-21 13:13:19 --> Model Class Initialized
INFO - 2016-02-21 13:13:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 13:13:19 --> Pagination Class Initialized
INFO - 2016-02-21 13:13:19 --> Helper loaded: text_helper
INFO - 2016-02-21 13:13:19 --> Helper loaded: cookie_helper
INFO - 2016-02-21 16:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 16:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 16:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 16:13:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 16:13:19 --> Final output sent to browser
DEBUG - 2016-02-21 16:13:19 --> Total execution time: 1.1667
INFO - 2016-02-21 13:19:30 --> Config Class Initialized
INFO - 2016-02-21 13:19:30 --> Hooks Class Initialized
DEBUG - 2016-02-21 13:19:30 --> UTF-8 Support Enabled
INFO - 2016-02-21 13:19:30 --> Utf8 Class Initialized
INFO - 2016-02-21 13:19:30 --> URI Class Initialized
INFO - 2016-02-21 13:19:30 --> Router Class Initialized
INFO - 2016-02-21 13:19:30 --> Output Class Initialized
INFO - 2016-02-21 13:19:30 --> Security Class Initialized
DEBUG - 2016-02-21 13:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-21 13:19:30 --> Input Class Initialized
INFO - 2016-02-21 13:19:30 --> Language Class Initialized
INFO - 2016-02-21 13:19:30 --> Loader Class Initialized
INFO - 2016-02-21 13:19:30 --> Helper loaded: url_helper
INFO - 2016-02-21 13:19:30 --> Helper loaded: file_helper
INFO - 2016-02-21 13:19:30 --> Helper loaded: date_helper
INFO - 2016-02-21 13:19:30 --> Helper loaded: form_helper
INFO - 2016-02-21 13:19:30 --> Database Driver Class Initialized
INFO - 2016-02-21 13:19:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-21 13:19:31 --> Controller Class Initialized
INFO - 2016-02-21 13:19:31 --> Model Class Initialized
INFO - 2016-02-21 13:19:31 --> Model Class Initialized
INFO - 2016-02-21 13:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-21 13:19:31 --> Pagination Class Initialized
INFO - 2016-02-21 13:19:31 --> Helper loaded: text_helper
INFO - 2016-02-21 13:19:31 --> Helper loaded: cookie_helper
INFO - 2016-02-21 16:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-21 16:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-21 16:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-21 16:19:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-21 16:19:31 --> Final output sent to browser
DEBUG - 2016-02-21 16:19:31 --> Total execution time: 1.3767
