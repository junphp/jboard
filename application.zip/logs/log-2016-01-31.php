<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-31 12:31:10 --> Config Class Initialized
INFO - 2016-01-31 12:31:10 --> Hooks Class Initialized
DEBUG - 2016-01-31 12:31:10 --> UTF-8 Support Enabled
INFO - 2016-01-31 12:31:10 --> Utf8 Class Initialized
INFO - 2016-01-31 12:31:10 --> URI Class Initialized
DEBUG - 2016-01-31 12:31:10 --> No URI present. Default controller set.
INFO - 2016-01-31 12:31:10 --> Router Class Initialized
INFO - 2016-01-31 12:31:10 --> Output Class Initialized
INFO - 2016-01-31 12:31:10 --> Security Class Initialized
DEBUG - 2016-01-31 12:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 12:31:10 --> Input Class Initialized
INFO - 2016-01-31 12:31:10 --> Language Class Initialized
INFO - 2016-01-31 12:31:10 --> Loader Class Initialized
INFO - 2016-01-31 12:31:10 --> Helper loaded: url_helper
INFO - 2016-01-31 12:31:10 --> Helper loaded: file_helper
INFO - 2016-01-31 12:31:10 --> Helper loaded: date_helper
INFO - 2016-01-31 12:31:10 --> Database Driver Class Initialized
INFO - 2016-01-31 12:31:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 12:31:12 --> Controller Class Initialized
INFO - 2016-01-31 12:31:12 --> Model Class Initialized
INFO - 2016-01-31 12:31:12 --> Model Class Initialized
INFO - 2016-01-31 12:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 12:31:12 --> Pagination Class Initialized
INFO - 2016-01-31 12:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 12:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-31 12:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 12:31:12 --> Final output sent to browser
DEBUG - 2016-01-31 12:31:12 --> Total execution time: 2.2541
INFO - 2016-01-31 12:31:38 --> Config Class Initialized
INFO - 2016-01-31 12:31:38 --> Hooks Class Initialized
DEBUG - 2016-01-31 12:31:38 --> UTF-8 Support Enabled
INFO - 2016-01-31 12:31:38 --> Utf8 Class Initialized
INFO - 2016-01-31 12:31:38 --> URI Class Initialized
INFO - 2016-01-31 12:31:38 --> Router Class Initialized
INFO - 2016-01-31 12:31:38 --> Output Class Initialized
INFO - 2016-01-31 12:31:38 --> Security Class Initialized
DEBUG - 2016-01-31 12:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 12:31:38 --> Input Class Initialized
INFO - 2016-01-31 12:31:38 --> Language Class Initialized
INFO - 2016-01-31 12:31:38 --> Loader Class Initialized
INFO - 2016-01-31 12:31:38 --> Helper loaded: url_helper
INFO - 2016-01-31 12:31:38 --> Helper loaded: file_helper
INFO - 2016-01-31 12:31:38 --> Helper loaded: date_helper
INFO - 2016-01-31 12:31:38 --> Database Driver Class Initialized
INFO - 2016-01-31 12:31:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 12:31:39 --> Controller Class Initialized
INFO - 2016-01-31 12:31:39 --> Model Class Initialized
INFO - 2016-01-31 12:31:39 --> Model Class Initialized
INFO - 2016-01-31 12:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 12:31:40 --> Pagination Class Initialized
INFO - 2016-01-31 12:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 12:31:40 --> Helper loaded: text_helper
INFO - 2016-01-31 12:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 12:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 12:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 12:31:40 --> Final output sent to browser
DEBUG - 2016-01-31 12:31:40 --> Total execution time: 1.3324
INFO - 2016-01-31 13:04:06 --> Config Class Initialized
INFO - 2016-01-31 13:04:06 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:04:06 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:04:06 --> Utf8 Class Initialized
INFO - 2016-01-31 13:04:06 --> URI Class Initialized
DEBUG - 2016-01-31 13:04:06 --> No URI present. Default controller set.
INFO - 2016-01-31 13:04:06 --> Router Class Initialized
INFO - 2016-01-31 13:04:06 --> Output Class Initialized
INFO - 2016-01-31 13:04:06 --> Security Class Initialized
DEBUG - 2016-01-31 13:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:04:06 --> Input Class Initialized
INFO - 2016-01-31 13:04:06 --> Language Class Initialized
INFO - 2016-01-31 13:04:06 --> Loader Class Initialized
INFO - 2016-01-31 13:04:06 --> Helper loaded: url_helper
INFO - 2016-01-31 13:04:06 --> Helper loaded: file_helper
INFO - 2016-01-31 13:04:06 --> Helper loaded: date_helper
INFO - 2016-01-31 13:04:06 --> Database Driver Class Initialized
INFO - 2016-01-31 13:04:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:04:07 --> Controller Class Initialized
INFO - 2016-01-31 13:04:07 --> Model Class Initialized
INFO - 2016-01-31 13:04:07 --> Model Class Initialized
INFO - 2016-01-31 13:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:04:07 --> Pagination Class Initialized
INFO - 2016-01-31 13:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-31 13:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:04:07 --> Final output sent to browser
DEBUG - 2016-01-31 13:04:07 --> Total execution time: 1.1386
INFO - 2016-01-31 13:05:38 --> Config Class Initialized
INFO - 2016-01-31 13:05:38 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:05:38 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:05:38 --> Utf8 Class Initialized
INFO - 2016-01-31 13:05:38 --> URI Class Initialized
INFO - 2016-01-31 13:05:38 --> Router Class Initialized
INFO - 2016-01-31 13:05:38 --> Output Class Initialized
INFO - 2016-01-31 13:05:38 --> Security Class Initialized
DEBUG - 2016-01-31 13:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:05:38 --> Input Class Initialized
INFO - 2016-01-31 13:05:38 --> Language Class Initialized
INFO - 2016-01-31 13:05:38 --> Loader Class Initialized
INFO - 2016-01-31 13:05:38 --> Helper loaded: url_helper
INFO - 2016-01-31 13:05:38 --> Helper loaded: file_helper
INFO - 2016-01-31 13:05:38 --> Helper loaded: date_helper
INFO - 2016-01-31 13:05:38 --> Database Driver Class Initialized
INFO - 2016-01-31 13:05:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:05:39 --> Controller Class Initialized
INFO - 2016-01-31 13:05:39 --> Model Class Initialized
INFO - 2016-01-31 13:05:39 --> Model Class Initialized
INFO - 2016-01-31 13:05:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:05:39 --> Pagination Class Initialized
INFO - 2016-01-31 13:05:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:05:39 --> Helper loaded: text_helper
INFO - 2016-01-31 13:05:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 13:05:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 13:05:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:05:39 --> Final output sent to browser
DEBUG - 2016-01-31 13:05:39 --> Total execution time: 1.2293
INFO - 2016-01-31 13:05:52 --> Config Class Initialized
INFO - 2016-01-31 13:05:52 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:05:52 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:05:52 --> Utf8 Class Initialized
INFO - 2016-01-31 13:05:52 --> URI Class Initialized
INFO - 2016-01-31 13:05:52 --> Router Class Initialized
INFO - 2016-01-31 13:05:52 --> Output Class Initialized
INFO - 2016-01-31 13:05:52 --> Security Class Initialized
DEBUG - 2016-01-31 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:05:52 --> Input Class Initialized
INFO - 2016-01-31 13:05:52 --> Language Class Initialized
INFO - 2016-01-31 13:05:52 --> Loader Class Initialized
INFO - 2016-01-31 13:05:52 --> Helper loaded: url_helper
INFO - 2016-01-31 13:05:52 --> Helper loaded: file_helper
INFO - 2016-01-31 13:05:52 --> Helper loaded: date_helper
INFO - 2016-01-31 13:05:52 --> Database Driver Class Initialized
INFO - 2016-01-31 13:05:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:05:53 --> Controller Class Initialized
INFO - 2016-01-31 13:05:53 --> Model Class Initialized
INFO - 2016-01-31 13:05:53 --> Model Class Initialized
INFO - 2016-01-31 13:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:05:53 --> Pagination Class Initialized
INFO - 2016-01-31 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:05:53 --> Helper loaded: text_helper
INFO - 2016-01-31 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:05:53 --> Final output sent to browser
DEBUG - 2016-01-31 13:05:53 --> Total execution time: 1.2952
INFO - 2016-01-31 13:06:05 --> Config Class Initialized
INFO - 2016-01-31 13:06:05 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:06:05 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:06:05 --> Utf8 Class Initialized
INFO - 2016-01-31 13:06:05 --> URI Class Initialized
INFO - 2016-01-31 13:06:05 --> Router Class Initialized
INFO - 2016-01-31 13:06:05 --> Output Class Initialized
INFO - 2016-01-31 13:06:05 --> Security Class Initialized
DEBUG - 2016-01-31 13:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:06:05 --> Input Class Initialized
INFO - 2016-01-31 13:06:05 --> Language Class Initialized
INFO - 2016-01-31 13:06:05 --> Loader Class Initialized
INFO - 2016-01-31 13:06:05 --> Helper loaded: url_helper
INFO - 2016-01-31 13:06:05 --> Helper loaded: file_helper
INFO - 2016-01-31 13:06:05 --> Helper loaded: date_helper
INFO - 2016-01-31 13:06:05 --> Database Driver Class Initialized
INFO - 2016-01-31 13:06:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:06:07 --> Controller Class Initialized
INFO - 2016-01-31 13:06:07 --> Model Class Initialized
INFO - 2016-01-31 13:06:07 --> Model Class Initialized
INFO - 2016-01-31 13:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:06:07 --> Pagination Class Initialized
INFO - 2016-01-31 13:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:06:07 --> Helper loaded: text_helper
INFO - 2016-01-31 13:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 13:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 13:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:06:07 --> Final output sent to browser
DEBUG - 2016-01-31 13:06:07 --> Total execution time: 1.1626
INFO - 2016-01-31 13:06:09 --> Config Class Initialized
INFO - 2016-01-31 13:06:09 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:06:09 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:06:09 --> Utf8 Class Initialized
INFO - 2016-01-31 13:06:09 --> URI Class Initialized
INFO - 2016-01-31 13:06:09 --> Router Class Initialized
INFO - 2016-01-31 13:06:09 --> Output Class Initialized
INFO - 2016-01-31 13:06:09 --> Security Class Initialized
DEBUG - 2016-01-31 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:06:09 --> Input Class Initialized
INFO - 2016-01-31 13:06:09 --> Language Class Initialized
INFO - 2016-01-31 13:06:09 --> Loader Class Initialized
INFO - 2016-01-31 13:06:09 --> Helper loaded: url_helper
INFO - 2016-01-31 13:06:09 --> Helper loaded: file_helper
INFO - 2016-01-31 13:06:09 --> Helper loaded: date_helper
INFO - 2016-01-31 13:06:09 --> Database Driver Class Initialized
INFO - 2016-01-31 13:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:06:10 --> Controller Class Initialized
INFO - 2016-01-31 13:06:10 --> Model Class Initialized
INFO - 2016-01-31 13:06:10 --> Model Class Initialized
INFO - 2016-01-31 13:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:06:10 --> Pagination Class Initialized
INFO - 2016-01-31 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:06:10 --> Helper loaded: text_helper
INFO - 2016-01-31 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:06:10 --> Final output sent to browser
DEBUG - 2016-01-31 13:06:10 --> Total execution time: 1.1384
INFO - 2016-01-31 13:06:14 --> Config Class Initialized
INFO - 2016-01-31 13:06:14 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:06:14 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:06:14 --> Utf8 Class Initialized
INFO - 2016-01-31 13:06:14 --> URI Class Initialized
DEBUG - 2016-01-31 13:06:14 --> No URI present. Default controller set.
INFO - 2016-01-31 13:06:14 --> Router Class Initialized
INFO - 2016-01-31 13:06:14 --> Output Class Initialized
INFO - 2016-01-31 13:06:14 --> Security Class Initialized
DEBUG - 2016-01-31 13:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:06:14 --> Input Class Initialized
INFO - 2016-01-31 13:06:14 --> Language Class Initialized
INFO - 2016-01-31 13:06:14 --> Loader Class Initialized
INFO - 2016-01-31 13:06:14 --> Helper loaded: url_helper
INFO - 2016-01-31 13:06:14 --> Helper loaded: file_helper
INFO - 2016-01-31 13:06:14 --> Helper loaded: date_helper
INFO - 2016-01-31 13:06:14 --> Database Driver Class Initialized
INFO - 2016-01-31 13:06:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:06:15 --> Controller Class Initialized
INFO - 2016-01-31 13:06:15 --> Model Class Initialized
INFO - 2016-01-31 13:06:15 --> Model Class Initialized
INFO - 2016-01-31 13:06:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:06:15 --> Pagination Class Initialized
INFO - 2016-01-31 13:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-31 13:06:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:06:15 --> Final output sent to browser
DEBUG - 2016-01-31 13:06:15 --> Total execution time: 1.0690
INFO - 2016-01-31 13:06:21 --> Config Class Initialized
INFO - 2016-01-31 13:06:21 --> Hooks Class Initialized
DEBUG - 2016-01-31 13:06:21 --> UTF-8 Support Enabled
INFO - 2016-01-31 13:06:21 --> Utf8 Class Initialized
INFO - 2016-01-31 13:06:21 --> URI Class Initialized
INFO - 2016-01-31 13:06:21 --> Router Class Initialized
INFO - 2016-01-31 13:06:21 --> Output Class Initialized
INFO - 2016-01-31 13:06:21 --> Security Class Initialized
DEBUG - 2016-01-31 13:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-31 13:06:21 --> Input Class Initialized
INFO - 2016-01-31 13:06:21 --> Language Class Initialized
INFO - 2016-01-31 13:06:21 --> Loader Class Initialized
INFO - 2016-01-31 13:06:21 --> Helper loaded: url_helper
INFO - 2016-01-31 13:06:21 --> Helper loaded: file_helper
INFO - 2016-01-31 13:06:21 --> Helper loaded: date_helper
INFO - 2016-01-31 13:06:21 --> Database Driver Class Initialized
INFO - 2016-01-31 13:06:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-31 13:06:22 --> Controller Class Initialized
INFO - 2016-01-31 13:06:22 --> Model Class Initialized
INFO - 2016-01-31 13:06:22 --> Model Class Initialized
INFO - 2016-01-31 13:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-31 13:06:22 --> Pagination Class Initialized
INFO - 2016-01-31 13:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-31 13:06:22 --> Helper loaded: text_helper
INFO - 2016-01-31 13:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-31 13:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-31 13:06:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-31 13:06:22 --> Final output sent to browser
DEBUG - 2016-01-31 13:06:22 --> Total execution time: 1.1491
